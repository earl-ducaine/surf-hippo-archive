/*
 * Copyright (C) 2003 by the Regents of the University of California.
 *  
 * Copyright (C) 2002-2003 by University of Maryland, College Park, MD 20742 
 * All rights reserved. 
 * 
 * This code is based on code in Piccolo.
 * 
 * Piccolo was written at the Human-Computer Interaction Laboratory 
 * www.cs.umd.edu/hcil by Jesse Grosjean under the supervision of Ben Bederson. 
 * The Piccolo website is www.cs.umd.edu/hcil/piccolo 
 */
package edu.berkeley.guir.damask.view.nodes;

import java.awt.geom.Point2D;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;
import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.util.PPickPath;
import edu.umd.cs.piccolox.handles.PBoundsHandle;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/**
 * <b>BoundsHandle</b> is just like Piccolo's PBoundsHandle, except that 
 * the mouse cursor does not change when the mouse button is released.
 *  
 * <P>
 * @version 1.0
 * @author Jesse Grosjean
 * @author James Lin
 */
public class BoundsHandle extends PBoundsHandle {
   
   private PBasicInputEventHandler handleCursorHandler;
   
   /**
    * Adds handles to the given node.
    */
   public static void addHandlesTo(PNode aNode) {
      addHandlesTo(aNode, null, false, false);
   }

   /**
    * Adds handles to the given node, which will stick to the given camera.
    */
   public static void addStickyHandlesTo(PNode aNode, PCamera camera) {
      addHandlesTo(aNode, camera, true, false);
   }

   /**
    * Adds handles to the given node, which will stick to the given
    * camera in the x and y axes, while staying constant along the z axis.
    */
   public static void addStickyZHandlesTo(PNode aNode, PCamera camera) {
      addHandlesTo(aNode, camera, false, true);
   }

   /**
    * Adds handles to the given node.
    * 
    * @param aNode the node to add handles to
    * @param camera the camera that the handles will stick to, or null
    *                if the handles should not be sticky
    * @param useSticky true if the handles will stick to the given camera
    * @param useStickyZ true if the handles will stick to the given
    *                    camera in the x and y axes, while staying
    *                    constant along the z axis.
    */
   public static void addHandlesTo(
      final PNode aNode,
      final PCamera camera,
      final boolean useSticky,
      final boolean useStickyZ) {

      addHandlesTo(aNode, camera, useSticky, useStickyZ, BoundsHandle.class);
   }
   

   /**
    * Adds handles to the given node.
    * 
    * @param aNode the node to add handles to
    * @param camera the camera that the handles will stick to, or null
    *                if the handles should not be sticky
    * @param useSticky true if the handles will stick to the given camera
    * @param useStickyZ true if the handles will stick to the given
    *                    camera in the x and y axes, while staying
    *                    constant along the z axis.
    * @param handleClass the class of handles to add
    */
   protected static void addHandlesTo(
      final PNode aNode,
      final PCamera camera,
      final boolean useSticky,
      final boolean useStickyZ,
      final Class handleClass) {

      try {
         final Constructor handleConstructor =
            handleClass.getConstructor(new Class[] { PBoundsLocator.class });
            
         final PBoundsLocator[] locators = BoundsHandle.createLocators(aNode);
         final BoundsHandle[] handles = new BoundsHandle[locators.length];
         
         for (int i = 0, n = handles.length; i < n; i++) {
            handles[i] =
               (BoundsHandle)handleConstructor.newInstance(
                  new Object[] { locators[i] });
         }

         if (useStickyZ) {
            for (int i = 0, n = handles.length; i < n; i++) {
               final BoundsHandle handle = handles[i];
               aNode.addChild(handle);
               StickyTransformManager.setupStickyZ(
                  handle,
                  camera,
                  new Point2D.Double(0.5, 0.5));
               handle.relocateHandle();
            }
         }
         else if (useSticky) {
            for (int i = 0, n = handles.length; i < n; i++) {
               final BoundsHandle handle = handles[i];
               camera.addChild(handle);
            }
         }
         else {
            for (int i = 0, n = handles.length; i < n; i++) {
               final BoundsHandle handle = handles[i];
               aNode.addChild(handle);
            }
         }
      }
      catch (SecurityException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (NoSuchMethodException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (IllegalArgumentException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (InstantiationException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (IllegalAccessException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (InvocationTargetException e) {
         DamaskAppExceptionHandler.log(e);
      }
   }


   /**
    * Returns an array of locators for each side and corner of the specified
    * node.
    */
   public static PBoundsLocator[] createLocators(final PNode aNode) {
      return new PBoundsLocator[] {
         PBoundsLocator.createEastLocator(aNode),
         PBoundsLocator.createWestLocator(aNode),
         PBoundsLocator.createNorthLocator(aNode),
         PBoundsLocator.createSouthLocator(aNode),
         PBoundsLocator.createNorthEastLocator(aNode),
         PBoundsLocator.createNorthWestLocator(aNode),
         PBoundsLocator.createSouthEastLocator(aNode),
         PBoundsLocator.createSouthWestLocator(aNode)};
   }
   
   /**
    * Removes handles from the specified node.
    */
   public static void removeHandlesFrom(PNode aNode) {
      removeHandlesFrom(aNode, BoundsHandle.class);
   }

   
   /**
    * Removes handles that are instances of the specified class
    * from the specified node.
    */
   protected static void removeHandlesFrom(PNode aNode, Class handleClass) {
      ArrayList handles = new ArrayList();

      for (Iterator i = aNode.getChildrenIterator(); i.hasNext(); ) {
         PNode each = (PNode) i.next();
         if (handleClass.isInstance(each)) {
            handles.add(each);
         }
      }
      aNode.removeChildren(handles);      
   }


   /**
    * Removes any sticky handles from the specified node that are
    * attached to the specified camera. 
    */
   public static void removeStickyHandlesFrom(PNode aNode, PCamera camera) {
      removeStickyHandlesFrom(aNode, camera, BoundsHandle.class);
   }


   /**
    * Removes any sticky handles that are instances of the specified class
    * from the specified node that are attached to the specified camera. 
    */
   protected static void removeStickyHandlesFrom(
      PNode aNode,
      PCamera camera,
      Class handleClass) {

      final Set handlesToRemove = new HashSet();
      for (Iterator i = camera.getChildrenIterator(); i.hasNext();) {
         final PNode child = (PNode)i.next();
         if (handleClass.isInstance(child)) {
            final PBoundsHandle handle = (PBoundsHandle)child;
            final PBoundsLocator l = (PBoundsLocator)handle.getLocator();
            final PNode n = l.getNode();
            if (n == aNode) {
               handlesToRemove.add(handle);
            }
         }
      }
      camera.removeChildren(handlesToRemove);
   }

   
   public BoundsHandle(PBoundsLocator aLocator) {
      super(aLocator);
   }
   
   protected void installHandleEventHandlers() {
      super.installHandleEventHandlers();
      handleCursorHandler = new PBasicInputEventHandler() {
         boolean cursorPushed = false;       
         public void mouseEntered(PInputEvent aEvent) {
            if (!cursorPushed) {
               aEvent.pushCursor(getCursorFor(((PBoundsLocator)getLocator()).getSide()));
               cursorPushed = true;
            }
         }
         public void mouseExited(PInputEvent aEvent) {
            PPickPath focus = aEvent.getInputManager().getMouseFocus();
            if (cursorPushed) {
               if (focus == null || focus.getPickedNode() != BoundsHandle.this) {
                  aEvent.popCursor();
                  cursorPushed = false;
               }
            }
         }
      };
      addInputEventListener(handleCursorHandler);
   }  
}
