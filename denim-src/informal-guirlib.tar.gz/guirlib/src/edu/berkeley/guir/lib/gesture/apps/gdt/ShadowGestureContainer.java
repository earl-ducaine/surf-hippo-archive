package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.*;
import java.util.*;

/** This class looks like a real GestureContainer, but its containees
    have other parents (and not necessarily the same one).  Removing a
    member of the ShadowGestureContainer removes it from its real
    parent, too. */
public class ShadowGestureContainer extends AbstractGestureContainer {
  List gestureObjectList;
  Class[] childTypes;

  public ShadowGestureContainer(List gestureObjectList)
  {
    super();
    this.gestureObjectList = gestureObjectList;
    Set typeSet =
      new HashSet(Misc.mapcar(gestureObjectList,
			      new Misc.UnaryOperator() {
				public Object operate(Object obj) {
				  return obj.getClass();
				}
			      }));
    childTypes = (Class[]) typeSet.toArray(new Class[0]);
  }

  public Class[] getChildTypes()
  {
    return childTypes;
  }

  protected List getChildren()
  {
    return gestureObjectList;
  }

  /** remove the object from this container and from its real parent */
  public void remove(GestureObject obj)
  {
    remove(obj, true);
  }

  /** Remove the object from this container.  If fromParent, remove
      from actual parent as well. */
  public void remove(GestureObject obj, boolean fromParent)
  {
    if (obj != null) {
      GestureContainer parent = obj.getParent();
      if ((parent != null) && fromParent) {
	parent.remove(obj);
      }
      if (obj instanceof GestureContainer) {
	((GestureContainer) obj).
	  removeCollectionListener(collectionListener);
      }
      List members = getChildren();
      int index = members.indexOf(obj);
      members.remove(index);
      fireCollectionEvent(CollectionEvent.ELEMENT_REMOVED, obj, index);
      propChangeSupport.firePropertyChange(CHILDREN_PROP, obj, null);
    }
  }
}
