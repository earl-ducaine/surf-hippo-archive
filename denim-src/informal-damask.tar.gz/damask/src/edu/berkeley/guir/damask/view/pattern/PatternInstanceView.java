package edu.berkeley.guir.damask.view.pattern;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.damask.pattern.PatternInstanceMember;
import edu.berkeley.guir.damask.view.DamaskLayer;
import edu.berkeley.guir.damask.view.InteractionElementView;
import edu.berkeley.guir.lib.collection.WeakHashSet;
import edu.umd.cs.piccolo.PLayer;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PText;


/** 
 * A view of a pattern instance.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-21-2004 James Lin
 *                               Created PatternInstanceView.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 03-21-2004
 */
public class PatternInstanceView extends InteractionElementView {
   private static final Color BOUNDARY_COLOR = Color.BLUE;
   private static final Color TEXT_COLOR = new Color(0, 0, 255, 127);
   private static final float TEXT_SIZE = 18.0f;
   private static final Stroke BOUNDARY_STROKE =
      new BasicStroke(
         1,
         BasicStroke.CAP_BUTT,
         BasicStroke.JOIN_MITER,
         1,
         new float[] { 2, 2 },
         0);
	
   private final MemberViewBoundsTransformHandler boundsTransformHandler =
      new MemberViewBoundsTransformHandler();
   private final MemberViewParentHandler parentHandler =
      new MemberViewParentHandler();
   private final Set/*<InteractionElementView>*/ memberViews =
      new HashSet/*<InteractionElementView>*/();
   
   private final Map/*<InteractionElementView, Set<PNode>>*/
      ancestors = new HashMap/*<InteractionElementView, Set<PNode>>*/();
   
   private final Map/*<PNode, Set<InteractionElementView>>*/
      descendants = new HashMap/*<PNode, Set<InteractionElementView>>*/();
   
   private final PText patternName;
   
   private static boolean autoReshape = true;
   private static WeakHashSet instances = new WeakHashSet();
   
   public PatternInstanceView(final PatternInstance patternInstance) {
      super(patternInstance);
      setStrokePaint(BOUNDARY_COLOR);
      setStroke(BOUNDARY_STROKE);
      patternName = new PText(patternInstance.getPattern().getName());
      patternName.setPaint(TEXT_COLOR);
      patternName.setFont(patternName.getFont().deriveFont(TEXT_SIZE));
      addChild(patternName);
      instances.add(this);
      setPickable(false);
   }


   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();

      final DamaskLayer layer = getLayer();
      
      for (Iterator i =
         ((PatternInstance)getModel()).getMembers(getDeviceType()).iterator();
         i.hasNext();
         ) {
         final PatternInstanceMember member = (PatternInstanceMember)i.next();
         final InteractionElementView memberView = layer.getView(member);
         if (memberView != null) {
            addMemberView(memberView);
         }
      }
      if (autoReshape) {
         reshape();
      }
   }
   
   // @Override
   public void dispose() {
      for (Iterator i = new HashSet(memberViews).iterator(); i.hasNext(); ) {
         final InteractionElementView memberView =
            (InteractionElementView)i.next();
         removeMemberView(memberView);
      }
   }

   
   /**
    * Start listening to the bounds and transform changes of the ancestors of
    * the specified member view. 
    */
   private void startListeningToAncestors(
      final InteractionElementView memberView) {
      
      PNode parent = memberView.getParent();
      while ((parent != null) && !(parent instanceof PLayer)) {
         final Set ancestorsOfMemberView =
            (Set)DamaskUtils.defaultGet(
               ancestors,
               memberView,
               new HashSet/*<InteractionElementView>*/());
         ancestorsOfMemberView.add(parent);
         
         final Set memberViewOfParent =
            (Set)DamaskUtils.defaultGet(
               descendants,
               parent,
               new HashSet/*<InteractionElementView>*/());
         
         if (memberViewOfParent.isEmpty()) {
            parent.addPropertyChangeListener(
               PNode.PROPERTY_BOUNDS,
               boundsTransformHandler);
            
            parent.addPropertyChangeListener(
               PNode.PROPERTY_TRANSFORM,
               boundsTransformHandler);
         }
         
         memberViewOfParent.add(memberView);
         
         parent = parent.getParent();
      }
   }

   
   /**
    * Stop listening to the bounds and transform changes of the ancestors of
    * the specified member view. 
    */
   private void stopListeningToAncestors(
      final InteractionElementView memberView) {
      
      final Set/*<PNode>*/ ancestorsOfMemberView =
         (Set)ancestors.get(memberView);
      
      if (ancestorsOfMemberView != null) { 
         for (Iterator i = ancestorsOfMemberView.iterator(); i.hasNext(); ) {
            final PNode ancestor = (PNode)i.next();
            final Set/*<InteractionElementView>*/ descendantsForAncestor =
               (Set)descendants.get(ancestor); 
            descendantsForAncestor.remove(memberView);
            if (descendantsForAncestor.isEmpty()) {
               descendants.remove(ancestor);
               ancestor.removePropertyChangeListener(
                  PNode.PROPERTY_BOUNDS, boundsTransformHandler);
               ancestor.removePropertyChangeListener(
                  PNode.PROPERTY_TRANSFORM, boundsTransformHandler);
            }
         }
         
         ancestorsOfMemberView.clear();
      }
   }
   
   // Overrides method in parent class.
   public DeviceType getDeviceType() {
      final DamaskLayer layer = getLayer();
      if (layer != null) {
         return layer.getDeviceType();
      }
      else {
         return null;
      }
   }

   
   /**
    * Adds the specified view as a member of this pattern instance view.
    */
   public void addMemberView(final InteractionElementView memberView) {
      memberViews.add(memberView);
      
      memberView.addPropertyChangeListener(PROPERTY_PARENT, parentHandler);
      
      memberView.addPropertyChangeListener(
         PNode.PROPERTY_BOUNDS,
         boundsTransformHandler);
      
      memberView.addPropertyChangeListener(
         PNode.PROPERTY_TRANSFORM,
         boundsTransformHandler);
      
      startListeningToAncestors(memberView);
   }

   
   /**
    * Removes the specified view as a member of this pattern instance view.
    */
   public void removeMemberView(final InteractionElementView memberView) {
      memberViews.remove(memberView);
      
      memberView.removePropertyChangeListener(PROPERTY_PARENT, parentHandler);
      
      memberView.removePropertyChangeListener(
         PNode.PROPERTY_BOUNDS,
         boundsTransformHandler);
      
      memberView.removePropertyChangeListener(
         PNode.PROPERTY_TRANSFORM,
         boundsTransformHandler);
      
      stopListeningToAncestors(memberView);
   }

   
   /**
    * Sets whether pattern instance views should automatically reshape
    * themselves depending on their contents.
    */
   public static void setAutoReshape(final boolean flag) {
      autoReshape = flag;
   }
   

   /**
    * Reshapes all instances of PatternInstanceView.
    */
   public static void reshapeAll() {
      for (Iterator i = instances.iterator(); i.hasNext(); ) {
         final PatternInstanceView view = (PatternInstanceView)i.next();
         view.reshape();
      }
   }
   
   
   /**
    * Changes the bounds of this pattern instance view depending on the bounds
    * of the members of the instance.
    */
   protected void reshape() {
      Rectangle2D shape = null;
      for (Iterator i = memberViews.iterator(); i.hasNext(); ) {
         final InteractionElementView memberView =
            (InteractionElementView)i.next();
         if (memberView.getVisible()) {
            final Rectangle2D memberGlobalBounds = memberView.getBounds();
            memberView.localToGlobal(memberGlobalBounds);
            if (!memberGlobalBounds.isEmpty()) {
               if (shape == null) {
                  shape = memberGlobalBounds;
               }
               else {
                  shape.add(memberGlobalBounds);
               }
            }
         }
      }
      if (shape != null) {
         setPathTo(shape);
         patternName.setBounds(
            shape.getX(),
            shape.getY(),
            patternName.getWidth(),
            patternName.getHeight());
      }
   }
   

   /**
    * Handles events from the view objects of the pattern instance's members. 
    */
   public class MemberViewBoundsTransformHandler implements
   PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent evt) {
         if (autoReshape) {
            reshape();
         }
      }
   }
   

   /**
    * Handles events from the view objects of the pattern instance's members. 
    */
   public class MemberViewParentHandler implements PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent evt) {
         final InteractionElementView memberView =
            (InteractionElementView)evt.getSource();
         
         stopListeningToAncestors(memberView);
         startListeningToAncestors(memberView);
         if (autoReshape) {
            reshape();
         }
      }
   }
}
