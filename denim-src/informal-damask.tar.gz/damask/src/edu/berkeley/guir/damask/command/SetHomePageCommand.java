package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionGraph;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that sets the home page of an interaction graph.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  06-12-2004 James Lin
 *                               Created SetHomePageCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 06-12-2004
 */
public class SetHomePageCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final InteractionGraph graph;
   private final DeviceType deviceType;
   private final Page newHomePage;
   private final Page oldHomePage;
   
   /**
    * Constructs the command.
    *  
    * @param graph the graph to edit
    * @param deviceType the type of device for which to set the home page
    * @param homePage the new home page of the graph
    */      
   public SetHomePageCommand(
      final InteractionGraph graph,
      final DeviceType deviceType,
      final Page homePage) {

      this.graph = graph;
      this.deviceType = deviceType;
      newHomePage = homePage;
      oldHomePage = graph.getHomePage(deviceType);
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Set home page of " + graph + ": " +
         oldHomePage + "->" + newHomePage;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      graph.setHomePage(deviceType, newHomePage);
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      graph.setHomePage(deviceType, oldHomePage);
   }
}
