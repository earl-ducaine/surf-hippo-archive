package edu.berkeley.guir.denim.interpreters;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import java.awt.geom.*;


/**
 * Inserts instances of the component associated with the rubber stamp.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-31-1999 JL
 *                    Created class RubberStampInterpreter.
 * </PRE>
 *
 * @see    edu.berkeley.guir.denim.toolbox.RubberStamp
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version Version 1.0.0, 10-31-1999
 */
public class RubberStampInterpreter
   extends DefaultInterpreterImpl
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 92871681562654911L;
//   private static final Debug debug = new Debug(Debug.ON);

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   DenimComponent component;
   DenimComponentInstance newInstance;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs a rubber stamp interpreter.
    */
   public RubberStampInterpreter() {
      super();
      commonInitializations();
   }

   //-----------------------------------------------------------------

   /**
    * Constructs a rubber stamp interpreter as a copy of the given
    * interpreter.
    */
   public RubberStampInterpreter(RubberStampInterpreter intrp) {
      //// 1. Since this interpreter is stateless, we can do this safely.
      this();
   }

   //-----------------------------------------------------------------

   /**
    * Perform initializations common to all constructors.
    */
   private void commonInitializations() {
      setName("Denim Rubber Stamp Interpreter");
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   XXXXX METHODS   =====================================================

   /**
    * Sets the component which the rubber stamp interpreter should insert
    * an instance of.
    */
   public void setComponentType(DenimComponent c) {
      component = c;
   }

   //===   XXXXX METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   /**
    * Puts an instance of the rubber stamp's component at the point where
    * the user tapped the rubber stamp.
    */
   public void handleNewStroke(NewStrokeEvent evt) {
      DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject();
      
      sheet.bufferUpcomingRender(1000);
      
      sheet.setGobWithFocus(null);
      TimedStroke stk  = evt.getStroke();
      Point2D p        = stk.getEndPoint2D(COORD_ABS);
      Point2D localPt  = GraphicalObjectLib.absoluteToLocal(sheet, p);

      newInstance = component.newInstance();

      sheet.add(newInstance, GraphicalObjectGroup.KEEP_REL_POS);
      
      newInstance.moveTo(COORD_REL, localPt);

      // Make sure this new instance can't receive any events
      // until the tool attached to this interpreter is dropped.
      // (Dropping the tool will automatically enable events
      // for this instance.)
      newInstance.getInkInterpreter().setEnabled(false);
      newInstance.setAddLeftButtonStrokes(false);

      evt.setConsumed();
      
      sheet.bufferUpcomingRender(1);
   }

   //-----------------------------------------------------------------

   /**
    * Moves the instance of the rubber stamp's component to the point where
    * the user has "dragged" the rubber stamp.
    */
   public void handleUpdateStroke(UpdateStrokeEvent evt) {

      DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject();
      sheet.bufferUpcomingRender(1000);

      TimedStroke stk  = evt.getStroke();
      Point2D p        = stk.getEndPoint2D(COORD_ABS);

      Point2D localPt  = GraphicalObjectLib.absoluteToLocal(sheet, p);

      newInstance.moveTo(COORD_REL, localPt);
      Debug.println("move to: " + localPt.getX() + ", " + localPt.getY());

      evt.setConsumed();
      
      sheet.bufferUpcomingRender(1);      
   }

   //-----------------------------------------------------------------

   /**
    * Inserts the instance of the rubber stamp's component at the point where
    * the user released the rubber stamp.
    */

   public void handleSingleStroke(SingleStrokeEvent evt) {
      DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject();

      TimedStroke stk  = evt.getStroke();
      Point2D p = stk.getEndPoint2D(COORD_ABS);
            
      // added by Shelley
      Point2D upLeftPoint = null;
      GraphicalObject findPanel = DenimUtils.findPanel(sheet, p);
      if ((findPanel instanceof DenimPanel) && 
          ((Denim.getDeviceInfo().getName() == DeviceType.SMARTPHONE.getName()))) {
            
         DenimSketch findSketch = ((DenimPanel)findPanel).getSketch();
         upLeftPoint = new Point2D.Double(findSketch.getBounds2D(COORD_ABS).getX()+1,
                                          findSketch.getBounds2D(COORD_ABS).getY()+1 );
         p = upLeftPoint;    
         newInstance.moveTo(COORD_REL,
                            findSketch.getBounds2D(COORD_ABS).getX(),
                            findSketch.getBounds2D(COORD_ABS).getY());
 
//         System.out.println("now p is upLeftPoint <- handleSingleStorke <- RubberStampInterpreter.");          
      }      
      
      sheet.bufferUpcomingRender(1000);
      sheet.disableDamage();

      // 1. Now that the designer has stopped dragging the instance around,
      //    we can remove it from the sheet.
      sheet.remove(newInstance);

      if (newInstance instanceof DenimCustomComponentInstance) {
         DenimPanel instPanel = (DenimPanel)newInstance.getDisplayedState();
         instPanel.getLabel().setVisible(false);
         instPanel.getLabel().getPhrase().setVisible(false);
      }


      // 2. Find the panel which contains the point where mouse was clicked
      GraphicalObject shallow = DenimUtils.findPanel(sheet, p);

      DenimPanel panel;
      DenimSketch sketch;
      MacroCommand macro = new MacroCommand();

      // 3. a) If there is a panel, add the instance to the panel
      if (shallow instanceof DenimPanel) {
         Debug.println("Found panel");
         panel = (DenimPanel)shallow;
         sketch = panel.getSketch();
         
         GraphicalObjectGroup parent;
         DenimGroup group = DenimUtils.findDeepestNestedDenimGroup(sketch, p);
         if (group == null) {
            parent = sketch;

            // if newInstance is an instance of SMARTPHONE
            // then we are going to move newInstance to the top-left corner of sketch           
            if (Denim.getDeviceInfo().getName() == DeviceType.SMARTPHONE.getName()) {
               
               macro.addCommand(
                  new InsertCommand(parent, newInstance, GraphicalObjectGroup.KEEP_ABS_POS));
               
               
                                          
            } else {

               macro.addCommand(
                  new InsertCommand(parent, newInstance, GraphicalObjectGroup.KEEP_REL_POS));
            
               // Calculate new transform that will keep the instance in the same
               // absolute location
               AffineTransform newXform = new AffineTransform();
               while (parent.getUniqueID() != sheet.getUniqueID()) {
                  Debug.println("  Adding inverse of " + DenimUtils.toShortString(parent));
                  newXform.concatenate(parent.getInverseTransform(COORD_REL));
                  parent = parent.getParentGroup();
               }
               newXform.concatenate(newInstance.getTransform(COORD_REL));
               macro.addCommand(new SetTransformCommand(newInstance, newXform));            
            }        
            
         } else {
            parent = group;
            macro.addCommand(
               new InsertCommand(parent, newInstance, GraphicalObjectGroup.KEEP_REL_POS));

            // Calculate new transform that will keep the instance in the same
            // absolute location
            AffineTransform newXform = new AffineTransform();
            while (parent.getUniqueID() != sheet.getUniqueID()) {
               Debug.println("  Adding inverse of " + DenimUtils.toShortString(parent));
               newXform.concatenate(parent.getInverseTransform(COORD_REL));
               parent = parent.getParentGroup();
            }
            newXform.concatenate(newInstance.getTransform(COORD_REL));
            macro.addCommand(new SetTransformCommand(newInstance, newXform));         
         }
         
         // 4. Insert the instance into the panel at the clicked point
         cmdqueue.doCommand(macro);
   
         // TODO: make this an undoable command
         panel.componentInstanceIsAdded(newInstance);
      }
      
      /*
      debug.println("panel abs bounds: " + panel.getBounds2D(COORD_ABS));
      debug.println("newInstance rel bounds: " + newInstance.getBounds2D(COORD_REL));
      debug.println("newInstance abs bounds: " + newInstance.getBounds2D(COORD_ABS));
      debug.println("newInstance abs xform: " + newInstance.getTransform(COORD_ABS));
      debug.println("newInstance xform: " + newInstance.getTransformRef());
      nParent = newInstance.getParentGroup();
      while (nParent != null) {
         debug.println("  " + DenimUtils.toShortString(nParent) + " xform: " + nParent.getTransformRef());
         nParent = nParent.getParentGroup();
      }
      dpanel = (DenimPanel)newInstance.getDisplayedState();
      debug.println("panel xform: " + dpanel.getTransformRef());
      debug.println("sketch xform: " + dpanel.getSketch().getTransformRef());
      debug.displayObjectTree(dpanel.getSketch());*/
      sheet.enableDamage();
      
      sheet.damage(DAMAGE_IDLE);
      
      evt.setConsumed();
      
      sheet.flushRenderRequests();
      
      sheet.setModified(true);
 
   }

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      return (new RubberStampInterpreter(this));
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
