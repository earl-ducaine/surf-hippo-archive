package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that removes a component from a component group.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  01-07-2004 James Lin
 *                               Created RemoveComponentFromGroupCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 01-07-2004
 */
public class RemoveComponentFromGroupCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final ComponentGroup group;
   private final Component component;
   
   /**
    * Constructs the command to remove the specified component from the
    * specified group.
    *  
    * @param group      the group to remove the component from
    * @param component  the component to remove
    */      
   public RemoveComponentFromGroupCommand(
      final ComponentGroup group,
      final Component component) {

      this.group = group;
      this.component = component;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Remove component " + component + " from group " + group;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      group.remove(component);
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      group.add(component);
   }
}
