package edu.berkeley.guir.suede;
/**
 ** Creates a dialog box with message.
 */

import java.awt.*;
import java.awt.event.*;
import java.util.Date;

/**
 * Outputs two dialog boxes and calibrates the silence.
 */
public class Calibrator extends Dialog implements ActionListener {
      
    boolean id = false;
    Button ok;
    long currTime;
	Frame calFrame;

    Calibrator(Frame frame){
		super(frame, "", true);	
		calFrame = frame;
		setLayout(new BorderLayout());		
		addMessage("Calibration complete!");
		addOKButton();
		
		pack();
	
		this.setSize(300, 100);
		System.out.println("calibrator initiated");
    }
	
	public void commenceCalibration() {
		showNotificationAndSample(calFrame);
		setFrameLocation(calFrame);
		setVisible(true);		
	}
	
    private void showNotificationAndSample(Frame frame) {
		NotifyMsg nm = new NotifyMsg(frame);
		long currTime = new Date().getTime();
		long newTime = currTime + 3000;
		long nextTime;
		String percentComplete = "0%";
		Label percentLabel = new Label( percentComplete );
		percentLabel.setAlignment(Label.CENTER);
		nm.add( percentLabel, BorderLayout.SOUTH );
		nm.setVisible( true );
		
		try {
			int c = 0;
			Thread.sleep(500);
			while (true) {
				Thread.sleep(50);
			
				if ( c == 50 ) {
					new CardSound().sampleSilence();
				} else if ( c == 100 ) {
					break;
				}
			
				c+=5;
				percentLabel.setText( "" + c + "%" );
				nm.setVisible( true );
			}
			
			Thread.sleep(200);
			nm.setVisible( false );
		} catch ( InterruptedException e ) {
			// Whatever...
		}
	}
	private void addMessage(String s) {
		Label l = new Label();
		l.setText(s);
		l.setAlignment(Label.CENTER);
		add(l, BorderLayout.CENTER);
    }
	
    private void addOKButton() {
		Panel p = new Panel();
		p.setLayout(new FlowLayout());
		p.add(ok = new Button("OK"));
		ok.addActionListener(this); 
		add(p, BorderLayout.SOUTH);
    }
	
    private void setFrameLocation(Frame frame) {
		Point p = frame.getLocationOnScreen();
		Dimension d = frame.getSize();
        setLocation(p.x + d.width/4, p.y + d.height/3);
    }


    public void actionPerformed(ActionEvent ae){
		if(ae.getSource() == ok) {
			setVisible(false);
		}
    }
	

    private class NotifyMsg extends Dialog {
		public NotifyMsg(Frame frame) {
			super(frame);
			setLayout(new BorderLayout());
			Label l = new Label("Please remain silent during audio calibration...");
			l.setAlignment(Label.CENTER);
			add(l, BorderLayout.CENTER);
			Point p = frame.getLocationOnScreen();
			Dimension d = frame.getSize();
			setLocation(p.x + d.width/4, p.y + d.height/3);
			pack();
		    this.setSize(300, 100);
		}

    }
}



