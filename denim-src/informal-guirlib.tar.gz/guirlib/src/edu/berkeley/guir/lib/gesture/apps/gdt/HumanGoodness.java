package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.GestureSet;
import edu.berkeley.guir.lib.gesture.util.Misc;
import java.util.*;

/** Computes how good the gesture set is for the Human */
public class HumanGoodness {
  protected GestureSet gestureSet;
  
  public HumanGoodness(GestureSet gs)
  {
    gestureSet = gs;
  }

  /** How good the set currently is.  Higher is better. */
  public double getGoodness()
  {
    Map noticeSummary = NoticeHandler.getNoticeSummary(gestureSet);
    Set noticeSet;
    double result = 0;
    Class c;
    
    c = HumanSimilarityNotice.class;
    if (noticeSummary.containsKey(c)) {
      noticeSet = (Set) Misc.
	accept((Set) noticeSummary.get(c),
		new Misc.Acceptor() {
		  public boolean accept(Object obj)
		  {
		    HumanSimilarityNotice n = (HumanSimilarityNotice) obj;
		    return !n.isWithinGroup();
		  }
		});
      result -= 5 * countUniqueGestures(noticeSet);
    }
    
    return result*10 + 1000;
  }

  /** return how many gesture objects are affected by all notices on
      the list */
  protected int countUniqueGestures(Collection noticeList)
  {
    Set gestureSet = new HashSet();
    for (Iterator iter = noticeList.iterator(); iter.hasNext();) {
      Notice notice = (Notice) iter.next();
      gestureSet.addAll(notice.getObjectList());
    }
    return gestureSet.size();
  }
}
