package edu.berkeley.guir.denim.interpreters;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.Sheet;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.interpreter.stroke.ImmediateInkFeedbackInterpreter;

import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

/**
 * Decides whether strokes added to the sheet should be turned into a label
 * or added to an existing label (or neither).
 * <P>
 * See the notes for {@link #handleSingleStroke(SingleStrokeEvent)} to see the
 * rules for determining whether a stroke belongs to a label.
 * </P>
 *
 * <PRE>
 * Revisions:  1.0.0  08-31-1999 MWN
 *                    Created. Actually created a while ago, but it's never
 *                    too late to document your code.
 *             1.0.1  11-21-1999 MWN
 *                    Changed so that strokes starting inside sketches
 *                    are accepted by the label interpreter when the sketches
 *                    aren't visible (b/c of Semantic Zoom)
 *             2.0.0  03-07-2000 JH
 *                    Fixing to make it work with new bounds methods in
 *                    SATINv2.
 * 			   2.0.1  11-07-2002 YL
 * 					  Cleared up redundant render from handleSingleStroke
 * 					  Supported idle rendering & active feedback
 * 			   2.0.1  01-06-2003 YL
 * 					  Changed group policy to separate sketches from typed text
 * 			   2.0.1  01-16-2003 YL
 * 					  Expanded grouping sensitive area and fixed the zero boundary bugs
 * 					  
 * 
 * </PRE>
 *
 * @see     DenimLabel
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~newman">Mark Newman</A> (
 *          <A HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.3RC1
 * @version Version 2.0.0, 01-16-2003
 */
public class LabelInterpreter
   extends    DefaultInterpreterImpl
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 5877893579578688717L;

   //===   CONSTANTS   =========================================================
   //===========================================================================


   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   // for debugging
   private static int numInvocations;
   
   //-----------------------------------------------------------------

   // used for checking whether stroke looks like text
   private ScribbledTextInterpreter phraseInterp;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   COMMANDS   ==========================================================

   /**
    * Adds a stroke to a label.
    *
    * <PRE>
    * Revisions:  1.0.0  04-10-2001 JL
    *                    Created class AddStrokeToScribbleCommand
    * </PRE>
    *
    * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
    *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
    * @since   JDK 1.2
    * @version Version 1.0.0, 04-10-2001
    */
   public class AddStrokeToLabelCommand
      extends UndoableCommand {

      //=======================================================================
      //===   INSTANCE VARIABLES   ============================================

      private DenimLabel      label;
      private Rectangle2D     oldLabelLocBds;     // original local bds of label
      private Rectangle2D     newLabelLocBds;     // new local bds of label
      private AffineTransform oldLabelXform;
      private AffineTransform newLabelXform;
      private DenimText       phrase;
      private AffineTransform oldPhraseXform;
      private TimedStroke     stk;
      private UndoableCommand addStkToScribbleCmd;

      //===   INSTANCE VARIABLES   ============================================
      //=======================================================================



      //=======================================================================
      //===   CONSTRUCTORS   ==================================================

      /**
       * Construct the command.
       *
       * @param scribble  the scribble to add the stroke to
       * @param newStk    the stroke to add
       */
      public AddStrokeToLabelCommand(DenimLabel label,
                                     TimedStroke stk) {
         this.label = label;
         this.stk = stk;
      } // of constructor

      //===   CONSTRUCTORS   ==================================================
      //=======================================================================



      //=======================================================================
      //===   NAME ACCESSOR METHODS   =========================================

      public String getPresentationName() {
         return ("add stroke to label");
      } // of getPresentationName

      //===   NAME ACCESSOR METHODS   =========================================
      //=======================================================================


      //=======================================================================
      //===   COMMAND   =======================================================

      /**
       * Notifies the command system that this command can be redone.
       */
      public boolean canRedo() {
         return true;
      } // of method

      //-----------------------------------------------------------------

      public void run() {
         //// 0. Initializations, and store "before" state.
         phrase = label.getPhrase();
         if (!(phrase instanceof ScribbledText)) {
            return;
         }
         oldLabelXform = label.getTransformRef();
         oldPhraseXform = phrase.getTransformRef();
         oldLabelLocBds = label.getBounds2D(COORD_LOCAL);

         //// 1. Add the stroke to the label.
         addStkToScribbleCmd = (UndoableCommand)
            phraseInterp.getAddStrokeToScribbleCommand((ScribbledText)phrase,
                                                        stk);
         addStkToScribbleCmd.run();

         //// 2. Resize the label to wrap around the phrase.
         ////    TODO: Make this undoable.
         Rectangle2D origPhraseAbsBounds =
            DenimUtils.trueLocalToAbs(phrase, phrase.getBounds2D(COORD_LOCAL));

         Rectangle2D unnormalizedLabelLocalBounds =
            DenimUtils.trueAbsToLocal(label, origPhraseAbsBounds);

         Rectangle2D labelLocalBounds =
            new Rectangle2D.Double(0,
                                   0,
                                   unnormalizedLabelLocalBounds.getWidth(),
                                   unnormalizedLabelLocalBounds.getHeight());

         label.setBoundingPoints2D(COORD_LOCAL, labelLocalBounds);
         phrase.moveTo(COORD_REL, 0, 0);
         Rectangle2D phraseAbsBounds = phrase.getBounds2D(COORD_ABS);

         /*System.out.println("phrase abs bds orig: " + origPhraseAbsBounds);
         System.out.println("phrase abs bds: " + phraseAbsBounds);
         System.out.println("label loc bds: " + labelLocalBounds);
         System.out.println("      rel bds: " + label.getBounds2D(COORD_REL));
         System.out.println("label abs bds: " + label.getBounds2D(COORD_ABS));
         System.out.println();*/

         //// 3. If the label has grown downwards or leftwards, move the panel
         ////    so that the text in the label stays in the same place.
         DenimPanel panel = label.getPanel();
         panel.moveBy(COORD_ABS,
                      origPhraseAbsBounds.getX() - phraseAbsBounds.getX(),
                      origPhraseAbsBounds.getY() - phraseAbsBounds.getY());

         //// 4. Adjust the width of the stroke
         stk.getStyleRef().setLineWidth
            ((float)(1.0 / DenimUtils.getTrueAbsXform(stk).getScaleX()));

         //// 5. Store "after" state
         newLabelXform = label.getTransformRef();
         newLabelLocBds = label.getBounds2D(COORD_LOCAL);
         
         /**
          * set sketch's cache invalid
          */
         ((DenimSheet)panel.getSheet()).setModified(true);
      } // of method

      //-----------------------------------------------------------------

      public void redo() {
         addStkToScribbleCmd.redo();
         label.setTransform(newLabelXform);
         label.setBoundingPoints2D(COORD_LOCAL, newLabelLocBds);
         phrase.moveTo(COORD_REL, 0, 0);
      } // of method

      //-----------------------------------------------------------------

      public void undo() {
         Sheet sheet = label.getSheet();
         sheet.bufferUpcomingRender(100);
         
         addStkToScribbleCmd.undo();
         label.setTransform(oldLabelXform);
         label.setBoundingPoints2D(COORD_LOCAL, oldLabelLocBds);
         phrase.setTransform(oldPhraseXform);
         
         label.damage(DAMAGE_IDLE);
         sheet.flushRenderRequests();
         
      } // of method

      //===   COMMAND   =======================================================
      //=======================================================================

   } // of class


   //===   COMMANDS   ==========================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs a label interpeter.
    */
   public LabelInterpreter() {
      super();
      phraseInterp = new ScribbledTextInterpreter();
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   STROKE METHODS   ====================================================

   /**
    * The rules for determining whether a stroke belongs to a label are:
    * Individual strokes that should be added to a label are ones that
    * <OL>
    *    <LI>  are letters, portions of letters, or handwritten words.
    *          Thus disallowed strokes are those that are:
    *          <UL>
    *               <LI> taller than letter height (where letter height should
    *                    ideally be defined on a per-user basis)</LI>
    *               <LI> long and mostly straight (having a small absolute
    *                    angle as compared to its length)</LI>
    *          </UL>
    *    </LI>
    *    <LI>  originate in the region defined by
    *          <PRE>
    *          (x, y)                             (x + width + inter-word space, y)
    *          (x, y + height + inter-line space) (x + width + inter-word space, y + height + inter-line space)
    *          </PRE>
    *          ... for some existing label
    *    </LI>
    * </OL>
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      final GraphicalObjectGroup parent =
         (GraphicalObjectGroup)getAttachedGraphicalObject();

      final DenimSheet sheet = (DenimSheet)parent.getSheet();
      if (sheet.getDenimUI().getCurrentTool() == null) {
         return;
      }

      //// 0.1. If too short, then ignore.
      final TimedStroke stk = evt.getStroke();
      if (stk.getLength2D(COORD_ABS) < MIN_SCRIBBLE_STK_LEN) {
         return;
      }
      
      stk.getStyleRef().setDrawColor(ImmediateInkFeedbackInterpreter.inkColor);

      //// 1. If this stroke starts inside a panel, see if it's in a sketch.
      ////    if so, it's probably meant to be an arrow
      GraphicalObjectCollection gobcol =
         parent.getGraphicalObjects(
            COORD_ABS,
            stk.getStartPoint2D(COORD_ABS),
            FIRST,
            SHALLOW,
            NEAR);
      GraphicalObject gob = gobcol.getFirst();
      if (gob instanceof DenimPanel) {
         final DenimPanel panel = (DenimPanel)gob;
         gobcol =
            panel.getGraphicalObjects(
               COORD_ABS,
               stk.getStartPoint2D(COORD_ABS),
               FIRST,
               SHALLOW,
               NEAR);
         gob = gobcol.getFirst();
         if (gob instanceof DenimSketch && ((DenimSketch)gob).isVisible()) {
            return;
         }
      }

      //// 2. Determine whether this stroke looks like handwritten text
      ////    If not, bail.
      if (!phraseInterp
         .looksLikeText(
            stk,
            GraphicalObjectLib.getScaleFactor(COORD_REL, parent))) {
         return;
      }

      //// 3. Disable the damage so it doesn't look like we've gone beserk.
      getAttachedGraphicalObject().disableDamage();

      //// 4. Determine whether this stroke is sufficiently close to
      ////    another label
      final DenimLabel nearLabel = findNearLabel(getAllLabels(parent), stk);

      //// 5. Create a new label around this stroke,
      ////    or add stroke to nearest one

      final DenimLabel thisLabel;
      if (nearLabel == null) {
         thisLabel = createNewLabel(stk);
      }
      else {
         thisLabel = nearLabel;
         addStrokeToLabel(nearLabel, stk);
      }
      thisLabel.activeFeedback();

      evt.setConsumed(true);

      //// 6. Re-enable damage so we can draw correctly.
      getAttachedGraphicalObject().enableDamage();

      final int damageMode;
      
      if (sheet.isIdleRenderingMode()) {
         damageMode = SatinConstants.DAMAGE_IDLE;
      }
      else {
         damageMode = SatinConstants.DAMAGE_LATER;
      }

      if (thisLabel != null) {
         thisLabel.damage(damageMode);
      }
      if (thisLabel.getPhrase() != null) {
         thisLabel.getPhrase().damage(damageMode);
      }
      if (thisLabel.getPanel().getSketch() != null) {
         thisLabel.getPanel().getSketch().damage(damageMode);
      }
      
      sheet.setModified(true);

   } // of method

   //-----------------------------------------------------------------

   /**
    * Return all of the labels within the given graphical object group.
    */
   private LinkedList getAllLabels(GraphicalObjectGroup group) {
      LinkedList        list;
      Iterator          iter;
      GraphicalObject   gob;
      DenimPanel        panel;

      list = new LinkedList();

      iter = group.getForwardIterator();
      while (iter.hasNext()) {
         gob = (GraphicalObject) iter.next();
         if (gob instanceof DenimPanel) {
            panel = (DenimPanel) gob;
            list.add(panel.getLabel());
         }
      }
      return list;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Takes a list of labels and determines whether this stroke is close
    * enough to one of them. The following priority is given (since a stroke
    * could hit in multiple labels):
    * <UL>
    *    <LI>a hit inside a label
    *    <LI>a hit to the right of a label
    *    <LI>a hit below a label
    * </UL>
    * Actually it would be nice to do:
    * <UL>
    *    <LI>a hit inside a label
    *    <LI>a hit to the right or below that most closely matches in time...
    * </UL>
    */
   private DenimLabel findNearLabel(List labels, TimedStroke stk) {
      DenimLabel           lbl                 = null;
      Rectangle2D          lblBounds;
      Rectangle2D          lblBoundsExtra      = new Rectangle2D.Float();
      Rectangle2D          stkBounds;
      Point2D              stkPt               = stk.getStartPoint2D(COORD_ABS);
      DenimLabel           bestGuessDirectHit  = null;
      DenimLabel           bestGuessNearHit    = null;
      DenimLabel           bestGuessOutsideHit = null;
      int                  listSize            = labels.size();
      ListIterator         it;

      stkBounds = stk.getBounds2D(COORD_ABS);

      // to avoid zero width or height
            
      if(stkBounds.getWidth()<2)
      	stkBounds.setFrame(stkBounds.getMinX(),stkBounds.getMinY(),2, stkBounds.getHeight());

      if(stkBounds.getHeight()<2)
      	stkBounds.setFrame(stkBounds.getMinX(),stkBounds.getMinY(),stkBounds.getWidth(), 2);

      //// 1. Go through each of the labels...
      it = labels.listIterator(listSize);
      while (it.hasPrevious()) {
         lbl       = (DenimLabel)it.previous();
         
         if(lbl.getPhrase() instanceof TypedText)
         	continue;
         	
         lblBounds = lbl.getBounds2D(COORD_ABS);
         
         // minimum height limit 30
         double delta = lblBounds.getHeight()<30?30:lblBounds.getHeight();
         
         lblBoundsExtra.setRect(
                lblBounds.getX(),          lblBounds.getY(),
                lblBounds.getWidth() + 30, delta);

         //// 1.1. First check if the stroke is inside a label...
         if (lblBounds.contains(stkPt)) {
            //// Direct hit always wins. no need to keep searching.
            bestGuessDirectHit = lbl;
            break;
         }
         //// 1.2. ...else see if the stroke is "near" the current label...
         else if (lblBounds.intersects(stkBounds)) {
            bestGuessNearHit = lbl;
            break;
         }
         //// 1.3. ...else see if the stroke is to the right.
         else if (lblBoundsExtra.intersects(stkBounds)) {
            bestGuessOutsideHit = lbl;
            break;
         }
      } // of for

      //// 2. Return our best guess as to which label is nearest
      ////    the beginning of the stroke
      if (bestGuessDirectHit != null) {
         return bestGuessDirectHit;
      }
      else if (bestGuessNearHit != null) {
         return bestGuessNearHit;
      }
      else if (bestGuessOutsideHit != null) {
         return bestGuessOutsideHit;
      }
      else {
         return null;
      }
   } // of method



   //-----------------------------------------------------------------

   /**
    * Creates a new label with the given stroke.
    */
   private DenimLabel createNewLabel(TimedStroke stk) {
      ScribbledText           phrase;
      DenimLabel              label;
      DenimSketch             sketch;
      DenimPanel              panel;
      GraphicalObjectGroup    parent;
      Rectangle2D             bounds;
      double                  scaleFactor;

      parent = (GraphicalObjectGroup) this.getAttachedGraphicalObject();

      //debug.println("LabelInterpreter: parent = " + parent.getClass() +
      //                   ":" + parent.getUniqueID());

      //phrase      = new Phrase();
      phrase      = new ScribbledText();
      bounds      = stk.getBounds2D(COORD_ABS);
      scaleFactor = GraphicalObjectLib.getScaleFactor(COORD_ABS, parent);

      //// 1. Create phrase.
      ////    Give it a bogus temp location.
      phrase.setBoundingPoints2D(COORD_ABS, new Rectangle(0, 0, 20, 20));
      parent.add(phrase, GraphicalObjectGroup.KEEP_ABS_POS);

      phrase.setBoundingPoints2D(COORD_ABS, bounds);
      phrase.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);

      //// 2. Create label.
      label  = new DenimLabel(phrase);
      bounds = label.getBounds2D(COORD_ABS);
      
      //// 3. Create sketch.
      sketch = new DenimSketch(new Rectangle2D.Double(
                                 bounds.getX(),
                                 bounds.getY() + bounds.getHeight(),
                                 //(int)(DEFAULT_SKETCH_WIDTH  * scaleFactor),
                                 //(int)(DEFAULT_SKETCH_HEIGHT * scaleFactor)));
											(int)(DenimSketch.getDefaultSketchWidth()  * scaleFactor),
											(int)(DenimSketch.getDefaultSketchHeight() * scaleFactor)));

      //// 4. Create panel.
      panel = new DenimPanel(new Rectangle(0, 0, 1, 1));

      //debug.println("Adding " + panel.getClass() + ":" +
      //                   panel.getUniqueID() + " to " +
      //                   parent.getClass() + ":" + parent.getUniqueID());

      //// throw this into the command queue, so it can be undone
      MacroCommand cmd = new MacroCommand();
      cmd.addCommand(new InsertCommand(parent, panel,
                                       GraphicalObjectGroup.KEEP_ABS_POS));
      cmd.addCommand(new SetSheetModifiedCommand((DenimSheet)parent.getSheet(),
                                                 true));
      cmdqueue.doCommand(cmd);

      //debug.println("Done. parent is " + panel.getParentGroup().getClass());
      //debug.println("Kids (" + parent.numElements() + "): ");
      //for (int i = 0; i < parent.numElements(); i++) {
         //debug.println("  " + i + ": " + parent.get(i).getClass() +
         //                   ":" + parent.get(i).getUniqueID());
      //}

      panel.setLabel(label);
      panel.setSketch(sketch);

      // HACK: Fix view for sketch, now that it has been added to sheet
      label.initAfterAddLabelToSheet();
      sketch.initAfterAddSketchToSheet();

      //// 5. Adjust the width of the stroke
      stk.getStyleRef().setLineWidth
         ((float)(1.0 / DenimUtils.getTrueAbsXform(stk).getScaleX()));
         
      return label;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Adds the given stroke to the given label.
    */
   private void addStrokeToLabel(DenimLabel label, TimedStroke stk) {
      cmdqueue.doCommand(new AddStrokeToLabelCommand(label, stk));
   } // of method

   //-----------------------------------------------------------------

   public String getName() {
      return new String("LabelInterpreter");
   }

   //-----------------------------------------------------------------

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      return new LabelInterpreter(); // nothing to clone
   }

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
