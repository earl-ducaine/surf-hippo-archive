package edu.berkeley.guir.lib.gesture;

import java.lang.System;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import edu.berkeley.guir.lib.gesture.util.*;

/**
 *
 * Displays a gesture category (i.e., delete), and area for adding new
 * examples.
 *
 */
public class GestureCategoryFrame extends JFrame
implements Observer, ItemListener {
  private JLabel statusWindow;
  private GestureInteractor drawingArea;
  private GestureCategoryDisplay gestureCategoryDisplay;
  private JScrollPane scrollPane;
  private JLabel exampleCounter;
  JMenuItem deleteMenuItem, cutMenuItem, copyMenuItem, pasteMenuItem;
  Gesture clipboard;
  boolean experimentMode = false;
  boolean authorVisible = false;
  
  final String version = "gdt 1.0";
  
  public GestureCategoryFrame()
  {
    this(new GestureCategory());
  }
  
  public GestureCategoryFrame(GestureCategory gc)
  {
    this(gc, false, true);
  }
  
  public GestureCategoryFrame(GestureCategory gc, boolean experimenting,
			      boolean showAuthor)
  {
    super();
    experimentMode = experimenting;
    authorVisible = showAuthor;
    setGestureCategoryInternal(gc);
    buildUI(gc);
  }

  public void setGestureCategory(GestureCategory gc)
  {
    setGestureCategoryInternal(gc);
    gestureCategoryDisplay.setGestureCategory(gc);
  }
  
  private void setGestureCategoryInternal(GestureCategory gestureCategory)
  {
    if (gestureCategory != null) {
      gestureCategory.deleteObserver(this);
    }
    if (gestureCategory != null)
      gestureCategory.addObserver(this);

    resetName(gestureCategory);
  }

  private void resetName(GestureCategory gestureCategory)
  {
    String name = (gestureCategory.getName() == null) ?
      "(unnamed)" : gestureCategory.getName();
    setTitle("gdt: " + name);
  }
  
  public GestureCategoryDisplay getGestureCategoryDisplay()
  {
    return gestureCategoryDisplay;
  }

  /**
   * Set up frame contents
   */
  protected void buildUI(GestureCategory gestureCategory)
  {
    // Frame contains a menubar and a SplitPane, which contains a
    // GestureCategoryDisplay on top and a container on the bottom
    // with some controls and the example drawing area.
    JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);

    // make menu bar
    JMenuBar menuBar = constructMenuBar();
    setJMenuBar(menuBar);
    
    // make gesture category display
    gestureCategoryDisplay = new GestureCategoryDisplay(gestureCategory,
							authorVisible);
    //gestureCategoryDisplay.rebuildUI();
    gestureCategoryDisplay.setBorder(BorderFactory.createEtchedBorder());
    gestureCategoryDisplay.addItemListener(this);
    scrollPane = new JScrollPane(gestureCategoryDisplay);
    scrollPane.setPreferredSize(new Dimension(200, 200));
    scrollPane.setMinimumSize(new Dimension(100, 100));
    gestureCategoryDisplay.setScroller(scrollPane);

    // make name field
    final JTextField nameField = new JTextField(gestureCategory.getName());
    DocumentListener nameChangeListener = new DocumentListener() {
      public void update(DocumentEvent e)
      {
	try {
	  getGestureCategoryDisplay().getGestureCategory().
	    setName(e.getDocument().
		    getText(0, e.getDocument().getLength()));
	}
	catch (BadLocationException exception) {
	  System.err.println("gdt bogosity: got exception: " + exception);
	}
      }
      public void insertUpdate(DocumentEvent e)
      {
	update(e);
      }
      public void removeUpdate(DocumentEvent e)
      {
	update(e);
      }
      public void changedUpdate(DocumentEvent e)
      {
	update(e);
      }
    };
    nameField.getDocument().addDocumentListener(nameChangeListener);

    JPanel namePanel = new JPanel(new BorderLayout());
    JLabel nameLabel = new JLabel("Name");
    namePanel.add(nameLabel, BorderLayout.WEST);
    namePanel.add(nameField, BorderLayout.CENTER);

    JPanel topPanel = new JPanel(new BorderLayout());
    topPanel.add(namePanel, BorderLayout.NORTH);
    topPanel.add(scrollPane, BorderLayout.CENTER);
    
    splitPane.setTopComponent(topPanel);
				    
    //gestureCategoryDisplay.setPreferredSize(new Dimension(300,100));

    // make drawing area & controls
    JPanel extras = new JPanel();
    extras.setDoubleBuffered(true);
    extras.setLayout(new BorderLayout(5,5));

    drawingArea = new GestureInteractor();
    drawingArea.addChangeListener(new ChangeListener() {
      JScrollPane sp = scrollPane;
      public void stateChanged(ChangeEvent e)
      {
	GestureInteractor interactor = (GestureInteractor) e.getSource();
	Gesture	g = interactor.getGesture();
	//System.out.println("From interactor:");
	//g.printTiming(System.out);
	Gesture copy = new Gesture(g);
	//System.out.println("Copy:");
	//copy.printTiming(System.out);
	GestureCategory gc =
	  gestureCategoryDisplay.getGestureCategory();
	copy.setAuthor(gc.getAuthor());
	copy.normalize();
	gc.addGesture(copy);

	Component gestureDisplay =
	  gestureCategoryDisplay.
	  getComponent(gestureCategoryDisplay.getComponentCount()-1);
	scrollPane.getViewport().
	  scrollRectToVisible(gestureDisplay.getBounds());
      }
    });
    drawingArea.setMinimumSize(new Dimension(200,200));
    drawingArea.setSize(new Dimension(200,200));
    drawingArea.setBorder(BorderFactory.createLoweredBevelBorder());

    JLabel drawingLabel = new JLabel("Draw new examples below");
    drawingLabel.setHorizontalAlignment(SwingConstants.RIGHT);
    exampleCounter = new JLabel();
    exampleCounter.setBorder(BorderFactory.createEtchedBorder());
    updateExampleCounter();
    Box infoPanel = new Box(BoxLayout.X_AXIS);
    infoPanel.add(exampleCounter);
    infoPanel.add(Box.createHorizontalGlue());
    infoPanel.add(drawingLabel);

    extras.add(drawingArea, BorderLayout.CENTER);
    extras.add(infoPanel, BorderLayout.NORTH);
    splitPane.setBottomComponent(extras);
	       
    // Make what the user says go
    HystericResizer hr = new HystericResizer();
    getRootPane().addComponentListener(hr);
    
    // put the contents all in the frame
    getContentPane().add(splitPane);
  }

  /**
   * Create the menu bar */
  protected JMenuBar constructMenuBar()
  {
    JMenuBar mb = new JMenuBar();

    JMenu fileMenu = new JMenu("File");
    // todo: add more to file menu
    if (!experimentMode) {
      JMenuItem openItem = new JMenuItem("Open");
      ActionListener openListener = new ActionListener() {
	public void actionPerformed(ActionEvent e)
	  {
	    FileDialog fileChooser = 
	      new FileDialog((Frame) scrollPane.getTopLevelAncestor(),
			     "Open", FileDialog.LOAD);
	    fileChooser.setFilenameFilter(new myFilenameFilter());
	    fileChooser.show();
	    String baseName = fileChooser.getFile();
	    if (baseName != null) {
	      // ok
	      File f = new File(fileChooser.getDirectory(), baseName);
	      openFile(f);
	    }
	    else {
	      // cancel
	    }
	  }
      };
      openItem.addActionListener(openListener);
      fileMenu.add(openItem);

      JMenuItem saveItem = new JMenuItem("Save");
      ActionListener saveListener = new ActionListener() {
	public void actionPerformed(ActionEvent e)
	  {
	    FileDialog fileChooser =
	      new FileDialog((Frame) scrollPane.getTopLevelAncestor(),
			     "Save", FileDialog.SAVE);
	    fileChooser.setFilenameFilter(new myFilenameFilter());
	    fileChooser.show();
	    String baseName = fileChooser.getFile();
	    if (baseName != null) {
	      // ok
	      File f = new File(fileChooser.getDirectory(), baseName);
	      try {
		FileOutputStream ostream = new FileOutputStream(f);
		ObjectOutputStream objStream =
		  new ObjectOutputStream(ostream);
		objStream.writeObject(version);
		objStream.writeObject(gestureCategoryDisplay.
				      getGestureCategory());
		objStream.flush();
		ostream.close();
	      }
	      catch (IOException exception) {
		System.err.println("Error saving file " + f + ": " +
				   exception);
	      }
	    }
	    else {
	      message("Save cancelled");
	    }
	  }
      };
      saveItem.addActionListener(saveListener);
      fileMenu.add(saveItem);
    }
    
    JMenuItem item = new JMenuItem("Rename");
    ActionListener listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	final JDialog dialog = new JDialog(GestureCategoryFrame.this,
					   "Rename class");
	final JTextField text = new JTextField("");
	dialog.getContentPane().add(text, "Center");
	JButton closeButton = new JButton("Ok");
	ActionListener l = new ActionListener() {
	  public void actionPerformed(ActionEvent e2)
	  {
	    GestureCategoryFrame frame = GestureCategoryFrame.this;
	    frame.getGestureCategoryDisplay().getGestureCategory().
	      setName(text.getText());
	    dialog.dispose();
	  }
	};
	closeButton.addActionListener(l);
	dialog.getContentPane().add(closeButton, "South");
	dialog.pack();
	dialog.show();
      }
    };
    item.addActionListener(listener);
    fileMenu.add(item);

    JMenuItem close = new JMenuItem("Close");
    ActionListener closeListener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	setVisible(false);
      }
    };
    close.addActionListener(closeListener);
    fileMenu.add(close);
      
    mb.add(fileMenu);

    JMenu menu = new JMenu("Edit");
    deleteMenuItem = new JMenuItem("Delete");
    ActionListener deleteListener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	deleteSelection();
      }
    };
    deleteMenuItem.addActionListener(deleteListener);
    deleteMenuItem.setEnabled(false);
    menu.add(deleteMenuItem);
    item = new JMenuItem("Cut");
    cutMenuItem = item;
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	setClipboard();
	deleteSelection();
      }
    };
    item.addActionListener(listener);
    item.setEnabled(false);
    menu.add(item);
    item = new JMenuItem("Copy");
    copyMenuItem = item;
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	copyClipboard();
      }
    };
    item.addActionListener(listener);
    item.setEnabled(false);
    menu.add(item);
    item = new JMenuItem("Paste");
    pasteMenuItem = item;
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	gestureCategoryDisplay.getGestureCategory().
	  addGesture((Gesture) getClipboard().clone());
      }
    };
    item.addActionListener(listener);
    item.setEnabled(false);
    menu.add(item);
    mb.add(menu);
    
    
    JMenu viewMenu = new JMenu("View");

    JMenuItem featureItem = new JMenuItem("Features");
    ActionListener featureListener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	Gesture selection = gestureCategoryDisplay.getSelection();
	if (selection != null)
	  new FeatureFrame(selection);
	// todo: pop up error message if no gesture selected
      }
    };
    featureItem.addActionListener(featureListener);
    viewMenu.add(featureItem);

    JMenuItem pointsItem = new JMenuItem("Toggle points");
    ActionListener pointsListener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	GestureDisplay gestureDisplay =
	  gestureCategoryDisplay.getSelectionDisplay();
	if (gestureDisplay != null)
	  gestureDisplay.setShowPoints(!gestureDisplay.getShowPoints());
      }
    };
    pointsItem.addActionListener(pointsListener);
    viewMenu.add(pointsItem);

    if (!experimentMode) {
      item = new JMenuItem("Star plot");
      listener = new ActionListener() {
	public void actionPerformed(ActionEvent e)
	  {
	    Gesture selection = gestureCategoryDisplay.getSelection();
	    if (selection != null) {
	      StarPlotFrame spf =
		new StarPlotFrame(new FeatureVector(selection),
				  "Star plot");
	      spf.pack();
	      spf.show();
	    }
	    // todo: pop up error message if no gesture selected
	  }
      };
      item.addActionListener(listener);
      viewMenu.add(item);

      item = new JMenuItem("Toggle narrowing");
      listener = new ActionListener() {
	public void actionPerformed(ActionEvent e)
	  {
	    GestureDisplay gestureDisplay =
	      gestureCategoryDisplay.getSelectionDisplay();
	    if (gestureDisplay != null)
	      gestureDisplay.toggleNarrowed();
	  }
      };
      item.addActionListener(listener);
      viewMenu.add(item);
    }

    mb.add(viewMenu);

    if (!experimentMode) {
      menu = new JMenu("Debug");

      item = new JMenuItem("Pack");
      item.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e)
	  {
	    invalidate();
	    validate();
	    pack();
	  }
      });
      menu.add(item);

      item = new JMenuItem("Rebuild GCD");
      item.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e)
	  {
	    gestureCategoryDisplay.rebuildUI();
	  }
      });
      menu.add(item);

      /* todo?
      item = new JMenuItem("Gesture stats");
      item.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e)
	  {
	    int i = 0;
	    for (Enumeration enum =
		   gestureCategoryDisplay.getGestureCategory().elements();
		 enum.hasMoreElements();
		 i++) {
	      Gesture g = (Gesture) enum.nextElement();
	      System.err.println(i + "\t" + g.size() + "\t" +
				 g.isEnabled() +
				 "\t" + debug.toString(g.getBounds()));
	    }
	  }
      });
      menu.add(item);
      */

      item = new JMenuItem("Timing");
      item.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e)
	{
	  Gesture selection = gestureCategoryDisplay.getSelection();
	  if (selection != null) {
	    selection.printTiming(System.out);
	  }
	}
      });
      menu.add(item);
	
      mb.add(menu);
    }
    
    // todo: add more menus
    return mb;
  }

  /**
   * Display message in status window
   */
  public void message(String msg)
  {
    statusWindow.setText(msg);
  }

  /**
   * Open given file and replace current GestureSet with contents of file.
   * If file does not contain a correct version String followed by
   * a GestureCategory object, an error message is printed and
   * the existing Category remains.
   */
  void openFile(File f)
  {
    try {
      ObjectInputStream p = new ObjectInputStream(new FileInputStream(f));
      String v = (String) p.readObject();
      if (!version.equals(v)) {
	System.err.println("Error while reading file '"+ f + "': expected version '" + version + "' but got version '" + v + "'");
      }
      gestureCategoryDisplay.getGestureCategory().
	replace((GestureCategory) p.readObject());

      p.close();
      // todo: maybe change this to be the name of the category
      setTitle(f.getName());
    }
    catch (ClassNotFoundException e) {
      System.err.println("Cannot find required class while reading file '"+ f + "': " + e);
    }
    catch (InvalidClassException e) {
      System.err.println("Problem with a class while reading file '"+ f + "': " + e);
    }
    catch (StreamCorruptedException e) {
      System.err.println("File '"+ f + "' is corrupted: " + e);
    }
    catch (OptionalDataException e) {
      System.err.println("Expected an object but got primitive data while reading file '"+ f + "': " + e);
    }
    catch (IOException ioexception) {
      System.err.println("I/O error reading file '"+ f + "': " + ioexception);
    }
  }

  /**
   * As of Swing 0.7, this doesn't work, but I'll leave it in anyway.
   */
  class myFilenameFilter implements FilenameFilter
  {
    public boolean accept(File dir, String name)
    {
      return name.endsWith(".gc");
    }
  }

  public void update(Observable o, Object arg)
  {
    if ((o != null) && (o instanceof GestureCategory)) {
      if ((arg != null) && (arg instanceof String))
	resetName((GestureCategory) o);
      else {
	updateExampleCounter();
	drawingArea.setGesture(null);
      }
    }
  }

  private void updateExampleCounter()
  {
    exampleCounter.setText(gestureCategoryDisplay.getGestureCategory().
			   size() + " examples");
  }
  
  // editing functions
  
  void setClipboard()
  {
    clipboard = gestureCategoryDisplay.getSelection();
    pasteMenuItem.setEnabled(true);
  }

  void copyClipboard()
  {
    clipboard = (Gesture)
      gestureCategoryDisplay.getSelection().clone();
    pasteMenuItem.setEnabled(true);
  }

  Gesture getClipboard()
  {
    return clipboard;
  }

  void deleteSelection()
  {
    gestureCategoryDisplay.getGestureCategory().
      removeGesture(gestureCategoryDisplay.getSelection());
    deleteMenuItem.setEnabled(false);
    cutMenuItem.setEnabled(false);
    copyMenuItem.setEnabled(false);
  }

  /**
   * When a gesture is (de)selected in the GestureCategoryDisplay,
   * this routine is called.
   */
  public void itemStateChanged(ItemEvent e)
  {
    // note: assumes that only one thing can be selected at a time
    int state = e.getStateChange();
    if (state == ItemEvent.SELECTED) {
      deleteMenuItem.setEnabled(true);
      cutMenuItem.setEnabled(true);
      copyMenuItem.setEnabled(true);
    }
    else if (state == ItemEvent.DESELECTED) {
      deleteMenuItem.setEnabled(false);
      cutMenuItem.setEnabled(false);
      copyMenuItem.setEnabled(false);
    }
    else {
      System.err.println("GestureSetFrame: Unknown item state " + state);
    }
  }

  public static void main(String[] args)
  {
    JFrame frame = new GestureCategoryFrame();

    frame.pack();
    frame.show();
  }
}
