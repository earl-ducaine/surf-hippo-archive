package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.*;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.*;

public class GestureContainerPanel extends SelectablePanel
  implements GestureObjectDisplay, GDTConstants, ClipboardOwner {
  protected CollectionListener listener = new MyCollectionListener();
  protected JScrollPane scrollPane;
  private GestureContainer gestureContainer;
  protected EventListenerList listenerList = new EventListenerList();
  private ActionListener forwardingActionListener = new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      fireActionEvent(e);
    }
  };
  protected PropertyChangeListener propChangeListener =
    new EnableListener(this);
  protected double scale = 1.0;
  
  public GestureContainerPanel()
  {
    this(null, null);
  }

  public GestureContainerPanel(GestureContainer object)
  {
    this(object, null);
  }

  public GestureContainerPanel(JScrollPane scrollPane)
  {
    this(null, scrollPane);
  }
  
  public GestureContainerPanel(GestureContainer object,
			       JScrollPane scrollPane)
  {
    super();
    this.scrollPane = scrollPane;
    setGestureContainer(object);
    getSelectionModel().
      addListSelectionListener(new ListSelectionListener() {
	public void valueChanged(ListSelectionEvent e) {
	  CommandUtil.
	    fireMenuValidChangeEvent(listenerList,
				     new ChangeEvent(GestureContainerPanel.
						     this));
	}
      });
  }

  public void setGestureContainer(GestureContainer object)
  {
    if (gestureContainer != object) {
      if (gestureContainer != null) {
	gestureContainer.removePropertyChangeListener(propChangeListener);
	gestureContainer.removeCollectionListener(listener);
      }
      gestureContainer = object;
      buildUI();
      if (gestureContainer != null) {
	gestureContainer.addCollectionListener(listener);
	gestureContainer.addPropertyChangeListener(propChangeListener);
      }
    }
  }

  public GestureContainer getGestureContainer()
  {
    return gestureContainer;
  }

  public GestureObject getDisplayedObject()
  {
    return gestureContainer;
  }
  
  protected void buildUI()
  {
    removeAll();
    if (gestureContainer != null) {
      FlowScrollLayout layout = new FlowScrollLayout(scrollPane, this, true);
      layout.setAlignment(FlowLayout.LEFT);
      setLayout(layout);
      for (Iterator iter = gestureContainer.iterator(); iter.hasNext();) {
	GestureObject gestureObj = (GestureObject) iter.next();
	addGestureObject(gestureObj, scrollPane);
      }
      setBorder(BorderFactory.
		createTitledBorder(null, gestureContainer.getName(),
				   TitledBorder.CENTER,
				   TitledBorder.DEFAULT_POSITION));
    }
  }

  protected void insertGestureObjects(int startIndex, GestureObject[] objs)
  {
    for (int i = 0; i < objs.length; i++) {
      addGestureObject(objs[i], scrollPane, startIndex+i);
    }
    revalidate();
  }

  protected void addGestureObject(GestureObject gestureObj,
				  JScrollPane scrollPane)
  {
    addGestureObject(gestureObj, scrollPane, -1);
  }

  protected void addGestureObject(GestureObject gestureObj,
				  JScrollPane scrollPane, int index)
  {
    JComponent widget = DisplayFactory.createThumbnail(gestureObj,
						       scrollPane);
    if (widget instanceof SelectablePanel) {
      ((SelectablePanel) widget).setSelectable(false);
    }
    add(widget, index);
    /*
    if (widget instanceof GestureObjectDisplay) {
      ((GestureObjectDisplay) widget).
	addActionListener(forwardingActionListener);
    }
    */
  }

  protected void removeForwardingListener(int childIndex) {
    Component comp = getComponent(childIndex);
    if (comp instanceof GestureObjectDisplay) {
      ((GestureObjectDisplay) comp).
       removeActionListener(forwardingActionListener);
    }
  }
  
  public void remove(int i)
  {
    removeForwardingListener(i);
    super.remove(i);
  }

  public void removeAll()
  {
    int numComponents = getComponentCount();
    for (int i = 0; i < numComponents; i++) {
      removeForwardingListener(i);
    }
    super.removeAll();
  }
  
  public void setGestureObject(GestureObject object)
  {
    if ((object == null) || (object instanceof GestureContainer)) {
      setGestureContainer((GestureContainer) object);
    }
    else {
      throw new IllegalArgumentException("Only GestureCategory is allowed, not " + object.getClass().getName() + " (" + object + ")");
    }
  }

  public String getInputGestureTitle()
  {
    return "Draw a gesture";
  }

  public boolean gestureDrawn(Gesture g)
  {
    return false;
  }

  public boolean canAcceptGesture()
  {
    return false;
  }
  
  public void addActionListener(ActionListener l)
  {
    listenerList.add(ActionListener.class, l);
  }

  public void removeActionListener(ActionListener l)
  {
    listenerList.remove(ActionListener.class, l);
  }

  protected void fireActionEvent(GestureObjectDisplay display,
				 String command, int modifiers)
  {
    ActionEvent event = null;
    Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ActionListener.class) {
	if (event == null)
	  event = new ActionEvent(display, ActionEvent.ACTION_PERFORMED,
				  command, modifiers);
	((ActionListener)listeners[i+1]).actionPerformed(event);
      }
    }
  }
  
  protected void fireActionEvent(ActionEvent event)
  {
    Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ActionListener.class) {
	((ActionListener)listeners[i+1]).actionPerformed(event);
      }
    }
  }

  //----------------------------------------------------------------------
  // Commander stuff

  public boolean isCommandValid(int id)
  {
    boolean valid;
    List selection;
    switch (id) {
    case CUT_ACTION:
    case COPY_ACTION:
    case DELETE_ACTION:
    case DUMP_HUMAN_COORDS_ACTION:
      selection = getSelectedObjects();
      valid = selection.size() > 0;
      break;
      /* todo: enable this?
    case RENAME_ACTION:
      */
    case PASTE_ACTION:
      //System.out.println("GCP paste action for " + this);
      Transferable transferable =
	GDTClipboard.getClipboard().getContents(this);
      valid = (transferable != null) && canPaste(transferable);
      break;
    case ENABLE_ACTION:
    case DISABLE_ACTION:
      valid = true;
      break;
    case ZOOM_IN_ACTION:
    case ZOOM_OUT_ACTION:
      valid = true;
      break;
    case RESET_ZOOM_ACTION:
      valid = (scale != 1.0);
      break;
    default:
      List childCommanders = getChildCommanders();
      valid = CommandUtil.isCommandValid(id, childCommanders);
    }
    return valid;
  }

  protected boolean canPaste(Transferable t)
  {
    /*
    System.out.print("canPaste: ");
    if (t == null) {
      System.out.println("empty clipboard");
    }
    else {
      System.out.println("flavors:");
      DataFlavor[] flavors = t.getTransferDataFlavors();
      for (int i = 0; i < flavors.length; i++) {
	System.out.println("\t" + flavors[i].getHumanPresentableName());
      }
    }
    */
    return (t != null) &&
      (t.isDataFlavorSupported(GestureFlavorFactory.GESTURE_OBJECT_FLAVOR) ||
       t.isDataFlavorSupported(GestureFlavorFactory.
			       GESTURE_OBJECT_COLLECTION_FLAVOR));
  }

  public void doCommand(int id)
  {
    List selectedObjs;
    switch (id) {
    case CUT_ACTION:
      doCopy();
      doDelete();
      break;
    case COPY_ACTION:
      doCopy();
      break;
    case DELETE_ACTION:
      doDelete();
      break;
    case PASTE_ACTION:
      doPaste();
      break;
    case ENABLE_ACTION:
      selectedObjs = getSelectedGestureObjects();
      if (selectedObjs == null) {
	getDisplayedObject().setEnabled(true);
      }
      else {
	GDTUtil.setProperty(selectedObjs, GestureObject.ENABLED_PROP,
			    new Boolean(true));
      }
      CommandUtil.fireMenuValidChangeEvent(listenerList,
					   new ChangeEvent(this));
      break;
    case DISABLE_ACTION:
      selectedObjs = getSelectedGestureObjects();
      if (selectedObjs == null) {
	getDisplayedObject().setEnabled(false);
      }
      else {
	GDTUtil.setProperty(selectedObjs, GestureObject.ENABLED_PROP,
			    new Boolean(false));
      }
      CommandUtil.fireMenuValidChangeEvent(listenerList,
					   new ChangeEvent(this));
      break;
    case ZOOM_IN_ACTION:
      setScale(scale*2);
      break;
    case ZOOM_OUT_ACTION:
      setScale(scale/2);
      break;
    case RESET_ZOOM_ACTION:
      setScale(1.0);
      break;
    case DUMP_HUMAN_COORDS_ACTION:
      doDumpHumanCoords();
      break;
    default:
      List childCommanders = getChildCommanders();
      CommandUtil.doCommand(id, childCommanders);
      break;
    }
  }

  protected void doDumpHumanCoords()
  {
    List selectedObjs = getSelectedGestureObjects();
    for (Iterator iter = selectedObjs.iterator(); iter.hasNext();) {
      GestureObject obj = (GestureObject) iter.next();
      if (obj instanceof GestureCategory) {
	GestureCategory cat = (GestureCategory) obj;
	System.out.println(cat.getName() + "\t" +
			   toString(HumanCoords.averageCoords(cat)));
      }
      else if (obj instanceof Gesture) {
	Gesture gesture = (Gesture) obj;
	GestureCategory cat = (GestureCategory) gesture.getParent();
	System.out.println(cat.getName() + " #" +
			   cat.getGestureIndex(gesture) + "\t" +
			   toString(HumanCoords.computeCoords(gesture)));
      }
    }
  }

  protected static String toString(double[] x)
  {
    StringBuffer result = new StringBuffer();
    for (int i = 0; i < x.length; i++) {
      result.append(" ");
      result.append(x[i]);
    }
    return result.toString();
  }
  
  protected List getChildCommanders()
  {
    ArrayList result = new ArrayList();
    Component[] components = getComponents();
    for (int i = 0; (i < components.length); i++) {
      if (components[i] instanceof Commander) {
	result.add(components[i]);
      }
    }
    return result;
  }

  private static String toString(GestureObject g)
  {
    return g.toString()
      /* + ((g instanceof Gesture) ?
	 ("/" + ((Gesture) g).getPoints().toString()) : "")*/
      ;
  }

  protected List getSelectedGestureObjects()
  {
    return (List) Misc.mapcar(getSelectedObjects(),
			      new Misc.UnaryOperator() {
      public Object operate(Object obj) {
	GestureObject gestureObj = (GestureObject)
	  ((GestureObjectDisplay) obj).getDisplayedObject();
	return gestureObj;
      }
    });
  }
  
  public void doCopy()
  {
    Collection selectedObjects =
      Misc.mapcar(getSelectedObjects(), new Misc.UnaryOperator() {
	public Object operate(Object obj) {
	  GestureObject gestureObj = (GestureObject)
	  ((GestureObjectDisplay) obj).getDisplayedObject();
	  return gestureObj;
	}
      });
    Clipboard clipboard = GDTClipboard.getClipboard();
    Transferable transferable = new GestureTransferable(selectedObjects);
    clipboard.setContents(transferable, this);
    CommandUtil.fireMenuValidChangeEvent(listenerList,
					 new ChangeEvent(this));
  }
  
  public void doDelete()
  {
    List selectedDisplays = getSelectedObjects();
    for (Iterator iter = selectedDisplays.iterator(); iter.hasNext();) {
      GestureObjectDisplay display = (GestureObjectDisplay) iter.next();
      //System.out.println("deleting: " + display.getDisplayedObject());
      gestureContainer.remove(display.getDisplayedObject());
    }
  }
  
  public void doPaste()
  {
    Transferable transferable = GDTClipboard.getClipboard().
      getContents(this);
    if (transferable.
	isDataFlavorSupported(GestureFlavorFactory.GESTURE_OBJECT_FLAVOR)) {
      // single object
      try {
	GestureObject obj = (GestureObject) transferable.
	  getTransferData(GestureFlavorFactory.GESTURE_OBJECT_FLAVOR);
	gestureContainer.add(obj);
      }
      catch (UnsupportedFlavorException e) {
	System.err.println("Transferable claimed it supported GESTURE_OBJECT_FLAVOR but it lied");
      }
      catch (IOException e) {
	JOptionPane.showMessageDialog(this, "Could not paste due to I/O error.", "Paste failed", JOptionPane.ERROR_MESSAGE);
      }
    }
    else if (transferable.
	     isDataFlavorSupported(GestureFlavorFactory.GESTURE_OBJECT_COLLECTION_FLAVOR)) {
      // collection of gesture objs
      try {
	Collection collection = (Collection) transferable.
	  getTransferData(GestureFlavorFactory.
			  GESTURE_OBJECT_COLLECTION_FLAVOR);
	for (Iterator iter = collection.iterator(); iter.hasNext();) {
	  GestureObject obj = (GestureObject) iter.next();
	  //System.out.println("From clipboard: " + toString(obj));
	  GestureObject newObj = (GestureObject) obj.clone();
	  gestureContainer.add(newObj);
	}
      }
      catch (UnsupportedFlavorException e) {
	System.err.println("Transferable claimed it supported GESTURE_COLLECTION_OBJECT_FLAVOR but it lied");
      }
      catch (IOException e) {
	JOptionPane.showMessageDialog(this, "Could not paste due to I/O error.", "Paste failed", JOptionPane.ERROR_MESSAGE);
      }
    }
    else {
      DataFlavor[] flavors = transferable.getTransferDataFlavors();
      System.err.println("ERROR: bad transferable: " +
			 flavors[0].getHumanPresentableName());
    }
  }
  
  public void addMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.add(ChangeListener.class, listener);
  }

  public void removeMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.remove(ChangeListener.class, listener);
  }

  /** for ClipboardOwner */
  public void lostOwnership(Clipboard clipboard,
			    Transferable contents)
  {
    // we don't care
  }

  public Dimension getPreferredSize()
  {
    Dimension result;
    Dimension ourDim = super.getPreferredSize();
    Border border = getBorder();
    if ((border != null) && (border instanceof TitledBorder)) {
      Dimension borderDim = ((TitledBorder) border).getMinimumSize(this);
      int newWidth = (int) Math.max(borderDim.getWidth(), ourDim.getWidth());
      int newHeight = (int) Math.max(borderDim.getHeight(),
				     ourDim.getHeight());
      result = new Dimension(newWidth, newHeight);
    }
    else {
      result = ourDim;
    }
    return result;
  }
  
  protected MouseListener getMouseListener()
  {
    return new GCMouseListener();
  }

  public void paint(Graphics g)
  {
    Graphics2D g2d = (Graphics2D) g;
    AffineTransform t = g2d.getTransform();
    g2d.scale(scale, scale);
    super.paint(g);
    g2d.setTransform(t);
  }

  public void setScale(double s)
  {
    scale = s;
    repaint();
  }

  public double getScale()
  {
    return scale;
  }
  
  //----------------------------------------------------------------------
  // helper classes
  
  protected class GCMouseListener
    extends SelectablePanel.SelectMouseListener {
    public void mouseClicked(MouseEvent e)
    {
      /*
      System.out.println("Got " + e.getClickCount() + " click(s) in " +
			 gestureContainer.getName());
      */
      if (e.getClickCount() == 2) {
	Point location = e.getPoint();
	// todo: fix this: the next line causes a class cast exception
	// if the user clicked on the background instead of a child
	// component
	Component child = ((SelectablePanel.SingletonContainer)
			   getComponentAt(location)).getContainee();
	if (child instanceof GestureObjectDisplay) {
	  fireActionEvent((GestureObjectDisplay) child, "OPEN",
			  e.getModifiers());
	}
      }
      else {
	super.mouseClicked(e);
      }
      /*
      else if (SwingUtilities.isRightMouseButton(e)) {
		Point location = e.getPoint();
	Component child = getComponentAt(location);
	if (child instanceof GestureObjectDisplay) {
	  GestureObject obj = ((GestureObjectDisplay) child).
	    getDisplayedObject();
	  System.out.print(obj);
	  if (obj instanceof Gesture) {
	    TimedPolygon p = ((Gesture) obj).getPoints();
	    System.out.print("\t" + p + "\t" + p.xpoints);
	  }
	  System.out.println();
	}
      }
      */
    }
  }
  
  protected class MyCollectionListener extends CollectionAdapter {
    public void elementAdded(CollectionEvent e)
    {
      GestureObject[] newObjs = (GestureObject[]) e.getElements();
      GestureContainerPanel.this.insertGestureObjects(e.getStartIndex(),
						      newObjs);
      revalidate();
      repaint();
    }

    public void elementRemoved(CollectionEvent e)
    {
      for (int i = 0; i < e.getElementCount(); i++) {
	GestureContainerPanel.this.remove(e.getStartIndex()+i);
      }
      revalidate();
      repaint();
      CommandUtil.
	fireMenuValidChangeEvent(listenerList, new
				 ChangeEvent(GestureContainerPanel.this));
    }
  }
}
