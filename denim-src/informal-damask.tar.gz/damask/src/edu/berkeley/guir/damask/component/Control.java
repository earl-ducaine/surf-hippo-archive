package edu.berkeley.guir.damask.component;

import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.connection.*;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.damask.pattern.PatternInstanceMember;
import edu.berkeley.guir.damask.userevent.DamaskUserEvent;
import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.util.StringLib;

/** 
 * An abstracted user interface control, like an entry field, a select-one
 * control, or a command button.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2003 James Lin
 *                               Created Control.
 *             1.1.0  12-18-2003 James Lin
 *                               Made Control a ConnectionDest.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-20-2003
 */
public abstract class Control extends Component
implements ConnectionSource, ConnectionDest, PatternInstanceMember {

   private Set/*<NavConnection>*/ outNavConnections =
      new HashSet/*<NavConnection>*/();
   private Set/*<NavConnection>*/ inNavConnections =
      new HashSet/*<NavConnection>*/();
   private Map/*<DeviceType, PageRegion>*/ regions =
      new HashMap/*<DeviceType, PageRegion>*/();
   private Set/*<PatternInstance>*/ patternInstances =
      new HashSet/*<PatternInstance>*/();
   
   private ControlEventSource eventSource = new ControlEventSource();
   private ConnectionSourceEventSource connectionSourceEventSource =
      new ConnectionSourceEventSource();
   private ConnectionDestEventSource connectionDestEventSource =
      new ConnectionDestEventSource();
   
   private ControlVoiceEventSource voiceEventSource =
      new ControlVoiceEventSource();


   // A condition is a mapping of controls to states. If, at run-time for a
   // dialog, the states of the controls match the controls-to-states map for a
   // particular condition, then the dialog is said to be in that condition.
   // Not all of the controls may matter for determining what condition a dialog
   // is in. For example, it's possible for a condition to say that the
   // state of one check box must be checked, but the state of another check
   // box does not matter.  
   //
   // There are two data structures for keeping track of conditions. 
   // 
   // * conditionSignificance[dialog, condition] returns whether the control's
   //   state is relevant in determining whether the specified condition is met.
   //   The default value is false.
   // 
   // * conditionStates[dialog, condition] returns the state of that
   //   the specified control must be in for the specified condition to match,
   //   if conditionSignificance[dialog, condition] is true. If it's false,
   //   then conditionStates[dialog, condition] returns the state that the
   //   control should display by default in that condition at design time.

   private Map/*<Dialog, List<Object>>*/ conditionStates =
      new HashMap/*<Dialog, List<Object>>*/();
   private Map/*<Dialog, List<Boolean>>*/ conditionSignificance =
      new HashMap/*<Dialog, List<Boolean>>*/();
   
   // Special properties for voice views
   private Rectangle2D voicePromptBounds = null;
   private String voicePromptText = null;
   private Map/*<Integer, Line2D>*/ voiceResponseLines =
      new TreeMap/*<Integer, Line2D>*/();
   private Control voiceResponseSource = null;
   private Map/*<Integer, ConnectionDest>*/ voiceResponseDests =
      new TreeMap/*<Integer, ConnectionDest>*/();
   private Control nextVoiceControl = null;
   private List/*<String>*/ voiceResponseText = new ArrayList/*<String>*/();
   
   private VoiceResponseEndpointHandler responseEndpointHandler =
      new VoiceResponseEndpointHandler();
   private ConnectionHandler connectionHandler = new ConnectionHandler();
   private ElementContainerListener pageRegionHandler = new PageRegionHandler();

   //===========================================================================

   /**
    * Constructs a control.
    * 
    * @param deviceType the device type that this control supports. Can be
    * DeviceType.ALL.
    */
   public Control(final DeviceType deviceType) {
      super(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Constructs a control which supports the specified device type, copying
    * properties from the specified control. 
    * 
    * @param deviceType the device type that this control supports. Can be
    * DeviceType.ALL.
    */
   public Control(final Control control, final DeviceType deviceType) {
      super(control, deviceType);
      copyStates(control, this);
      if (deviceType.getSpecificDeviceTypes().contains(DeviceType.VOICE)) {
         if (control.getVoicePromptBounds() != null) {
            voicePromptBounds = (Rectangle2D)control.getVoicePromptBounds().clone();
         }
      }
      voicePromptText = control.voicePromptText;
      for (Iterator i = voiceResponseLines.keySet().iterator(); i.hasNext(); ) {
         final Integer key = (Integer)i.next();
         voiceResponseLines.put(key, control.voiceResponseLines.get(key));
      }
      voiceResponseText = new ArrayList/*<String>*/(control.voiceResponseText);
   }

   //---------------------------------------------------------------------------

   /**
    * Frees up any resources associated with this object.
    */   
   public void dispose() {
      super.dispose();
      for (Iterator i = new HashSet(patternInstances).iterator(); i.hasNext(); ) {
         final PatternInstance instance = (PatternInstance)i.next();
         instance.remove(this);
      }
   }

   //===========================================================================
   
   /**
    * Automatically positions this component for the specified device type.
    */
   protected final void autoPosition(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      
      if (deviceType == DeviceType.VOICE) {
         if (getVoicePromptBounds() == null) {
            autoPositionForVoice();
         }
      }
      else {
         if (getBounds(deviceType) == null) {
            if (deviceType == DeviceType.DESKTOP) {
               autoPositionForDesktop();
            }
            else if (deviceType == DeviceType.SMARTPHONE) {
               autoPositionForSmartphone();
            }
         }
      }
   }

   /**
    * Fills in the bounds and transform for this component for the
    * desktop, based on what controls are before and after it.
    */
   protected abstract void autoPositionForDesktop();

   /**
    * Fills in the bounds and transform for this component for the
    * smartphone, based on what controls are before and after it.
    */
   protected abstract void autoPositionForSmartphone();

   /**
    * Fills in the bounds and transform for this component for
    * voice, based on what controls are before and after it.
    */
   protected abstract void autoPositionForVoice();

   /**
    * Sets up the responses for this control for voice,
    * based on what controls are before and after it.
    */
   protected abstract void setupVoiceResponses();

   //===========================================================================
   
   /**
    * Returns the region of the page that this control lives in, from the
    * given device type's perspective.
    */
   public PageRegion getPageRegion(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      return (PageRegion)regions.get(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the region of the page that this control lives in, from the
    * given device type's perspective. Only called by PageRegion.add()
    * and dispose().
    */
   public void setPageRegion(
      final DeviceType deviceType,
      final PageRegion region) {
         
      deviceType.verifyTypeIsNotAll();

      // If the region hasn't changed, then exit
      final PageRegion oldRegion = (PageRegion)regions.get(deviceType);
      if (oldRegion == region) {
         return;
      }

      // Change the page region
      regions.put(deviceType, region);

      final Dialog newDialog;
      if (region == null) {
         newDialog = null;
      }
      else {
         newDialog = region.getPage().getDialog();
      }
      
      // Initialize voice-specific properties
      if (deviceType == DeviceType.VOICE) {
         if (getVoiceResponseSource() != null) {
            setVoiceResponseSource(null);
         }
         if (oldRegion != null) {
            oldRegion.removeElementContainerListener(pageRegionHandler);
            for (int i = 0,
                  n = oldRegion.getPage().getDialog().getNumConditions();
                  i < n; i++) {
               setVoiceResponseDest(i, null);
               setVoiceResponseLine(i, null);
            }
         }

         voiceResponseLines.clear();
         voiceResponseDests.clear();
         
         if (region != null) {
            region.addElementContainerListener(pageRegionHandler);
         }
      }

      // Position the control inside this region, if necessary
      if (newDialog != null) {
         autoPosition(deviceType);
      }

      // If the control already has states for this dialog, then leave
      // them alone
      if ((newDialog != null) && conditionStates.containsKey(newDialog)) {
      }
      else {
         // Erase old conditional states
         if (oldRegion != null) {
            final Dialog oldDialog = oldRegion.getPage().getDialog();
            conditionStates.remove(oldDialog);
            conditionSignificance.remove(oldDialog);
         }
         
         // Initialize conditional states
         if (newDialog != null) {
            final List statesList = new ArrayList();
            final List sigList = new ArrayList();
         
            conditionStates.put(newDialog, statesList);
            conditionSignificance.put(newDialog, sigList);
            for (int i = 0, n = newDialog.getNumConditions(); i < n; i++) {
               statesList.add(getDefaultState());
               sigList.add(Boolean.FALSE);
            }
         }
      }
      
      firePageRegionChanged(deviceType);
   }

   //---------------------------------------------------------------------------
   
   public Page getPage(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      
      final PageRegion pageRegion = getPageRegion(deviceType);
      if (pageRegion == null) {
         return null;
      }
      else {
         return pageRegion.getPage();
      }
   }

   //---------------------------------------------------------------------------
   
   public Dialog getDialog() {
      Dialog dialog = null;
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         final Page page = getPage(aDeviceType);
         if (page != null) {
            dialog = page.getDialog();
         }
      }
      return dialog;
   }

   //===========================================================================
   
   /**
    * Returns the interaction graph that the page is in, or null if it's not
    * in any graph.
    */
   public InteractionGraph getInteractionGraph() {
      InteractionGraph graph = null;
      
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType deviceType = (DeviceType)i.next();
         final Page p = getPage(deviceType);
         if (p != null) {
            final InteractionGraph pageGraph = p.getInteractionGraph();
            if (pageGraph != null) {
               graph = pageGraph;
               break;
            }
         }
      }
      
      return graph;
   }

   //===========================================================================
   
   public Collection/*<PatternInstance>*/ getPatternInstanceMemberships() {
      return Collections.unmodifiableCollection(patternInstances);
   }
   
   //---------------------------------------------------------------------------

   public void addToPatternInstance(PatternInstance pi) {
      patternInstances.add(pi);
   }
   
   //---------------------------------------------------------------------------

   public boolean removeFromPatternInstance(PatternInstance pi) {
      return patternInstances.remove(pi);
   }

   //===========================================================================
   
   /**
    * Returns the control that is before this one, for the specified
    * device type.
    */
   public Control getControlBefore(final DeviceType deviceType) {
      final List/*<Control>*/ controls =
         getPageRegion(deviceType).getControls();
      final int index = controls.indexOf(this);
      if (index == 0) {
         return null;
      }
      else {
         return (Control)controls.get(index - 1);
      }
   }
   
   //---------------------------------------------------------------------------

   /**
    * Returns the control that is after this one, for the specified
    * device type.
    */
   public Control getControlAfter(final DeviceType deviceType) {
      final List/*<Control>*/ controls =
         getPageRegion(deviceType).getControls();
      final int index = controls.indexOf(this);
      if (index == controls.size() - 1) {
         return null;
      }
      else {
         return (Control)controls.get(index + 1);
      }
   }

   //===========================================================================

   /**
    * Adds the specified control listener to receive events from this control.
    */
   public void addControlListener(final ControlListener listener) {
      eventSource.addControlListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified control listener so that it no longer receives
    * events from this control.
    */
   public void removeControlListener(final ControlListener listener) {
      eventSource.removeControlListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires controlStateChanged events to listeners.
    */
   protected void fireControlStateChanged(final DeviceType deviceType) {
      eventSource.fireControlStateChanged(this, deviceType);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires controlSignificanceChanged events to listeners.
    */
   protected void fireControlSignificanceChanged(final DeviceType deviceType) {
      eventSource.fireControlSignificanceChanged(this, deviceType);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires pageRegionChanged events to listeners.
    */
   protected void firePageRegionChanged(final DeviceType deviceType) {
      eventSource.firePageRegionChanged(this, deviceType);
   }

   //===========================================================================

   /**
    * Adds the specified control listener to receive events from this control.
    */
   public void addConnectionDestListener(final ConnectionDestListener listener) {
      connectionDestEventSource.addConnectionDestListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified control listener so that it no longer receives
    * events from this control.
    */
   public void removeConnectionDestListener(final ConnectionDestListener listener) {
      connectionDestEventSource.removeConnectionDestListener(listener);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Fires inConnectionAdded events to listeners.
    */
   protected void fireInConnectionAdded(final Connection connection) {
      connectionDestEventSource.fireInConnectionAdded(this, connection);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires inConnectionRemoved events to listeners.
    */
   protected void fireInConnectionRemoved(final Connection connection) {
      connectionDestEventSource.fireInConnectionRemoved(this, connection);
   }

   //===========================================================================

   /**
    * Adds the specified control listener to receive events from this control.
    */
   public void addConnectionSourceListener(final ConnectionSourceListener listener) {
      connectionSourceEventSource.addConnectionSourceListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified control listener so that it no longer receives
    * events from this control.
    */
   public void removeConnectionSourceListener(final ConnectionSourceListener listener) {
      connectionSourceEventSource.removeConnectionSourceListener(listener);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Fires outConnectionAdded events to listeners.
    */
   protected void fireOutConnectionAdded(final Connection connection) {
      connectionSourceEventSource.fireOutConnectionAdded(this, connection);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires outConnectionRemoved events to listeners.
    */
   protected void fireOutConnectionRemoved(final Connection connection) {
      connectionSourceEventSource.fireOutConnectionRemoved(this, connection);
   }

   //===========================================================================

   /**
    * Adds the specified control listener to receive events from this control.
    */
   public void addControlVoiceListener(final ControlVoiceListener listener) {
      voiceEventSource.addControlVoiceListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified control listener so that it no longer receives
    * events from this control.
    */
   public void removeControlVoiceListener(final ControlVoiceListener listener) {
      voiceEventSource.removeControlVoiceListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires responseSourceChanged events to listeners.
    */
   protected void firePromptTextChanged() {
      voiceEventSource.firePromptTextChanged(this);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires responseSourceChanged events to listeners.
    */
   protected void firePromptBoundsChanged() {
      voiceEventSource.firePromptBoundsChanged(this);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires responseSourceChanged events to listeners.
    */
   protected void fireResponseSourceChanged() {
      voiceEventSource.fireResponseSourceChanged(this);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires responseDestChanged events to listeners.
    */
   protected void fireResponseDestChanged(final int condition) {
      voiceEventSource.fireResponseDestChanged(this, condition);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires responseLineChanged events to listeners.
    */
   protected void fireResponseLineChanged(final int condition) {
      voiceEventSource.fireResponseLineChanged(this, condition);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires responseSourceChanged events to listeners.
    */
   protected void fireResponseTextChanged() {
      voiceEventSource.fireResponseTextChanged(this);
   }

   //===========================================================================
   
   /**
    * Returns the content of this control. This method should be overridden by
    * controls that actually have content to return.
    */
   public abstract Content getContent();
   
   //===========================================================================
   
   /**
    * Returns the default state of this control.
    */
   public Object getDefaultState() {
      return null;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns whether the state of this control matters for determining whether
    * the specified dialog is in the specified condition.
    */
   public boolean isStateSignificantForCondition(
      final Dialog dialog,
      final int condition) {

      return ((Boolean) ((List)conditionSignificance.get(dialog)).get(condition))
         .booleanValue();
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets whether the state of this control matters for determining whether
    * the specified dialog is in the specified condition.
    */
   public void setStateSignificantForCondition(
      final Dialog dialog,
      final int condition,
      final boolean significant) {

      ((List)conditionSignificance.get(dialog)).set(
         condition,
         Boolean.valueOf(significant));
      
      fireControlSignificanceChanged(dialog.getDeviceType());
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns a set of dialogs for which there is associated states.
    */
   public Set/*<Dialog>*/ getDialogsWithState() {
      return Collections.unmodifiableSet(conditionStates.keySet());
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the state that this control should be in for the specified page
    * to be in the specified condition. If
    * isStateSignificantForCondition(dialog, condition) is false, then
    * this method returns the state that this control should be in
    * when the specified condition is displayed in Design mode. 
    */
   public Object getStateForCondition(final Dialog dialog, final int condition) {
      return ((List)conditionStates.get(dialog)).get(condition);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the state that this control should be in for the specified page
    * to be in the specified condition. 
    */
   public void setStateForCondition(
      final Dialog dialog,
      final int condition,
      final Object state) {

      ((List)conditionStates.get(dialog)).set(condition, state);
      
      fireControlStateChanged(dialog.getDeviceType());
   }

   //---------------------------------------------------------------------------
   
   /**
    * Adds a condition for the specified dialog. Called only by
    * {@see edu.berkeley.guir.damask.dialog.Dialog#addCondition()}.
    */
   public void addCondition(final Dialog dialog) {
      ((List)conditionStates.get(dialog)).add(getDefaultState());
      ((List)conditionSignificance.get(dialog)).add(Boolean.FALSE);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Adds a condition for the specified dialog at the specified index.
    * Called only by
    * {@see edu.berkeley.guir.damask.dialog.Dialog#addCondition(int)}
    */
   public void addCondition(final Dialog dialog, final int index) {
      ((List)conditionStates.get(dialog)).add(index, getDefaultState());
      ((List)conditionSignificance.get(dialog)).add(index, Boolean.FALSE);
      
      for (Iterator i = voiceResponseDests.keySet().iterator(); i.hasNext(); ) {
         final Integer conditionNum = (Integer)i.next();
         if (conditionNum.intValue() >= index) {
            final ConnectionDest dest = (ConnectionDest)voiceResponseDests.remove(conditionNum);
            voiceResponseDests.put(new Integer(conditionNum.intValue() + 1), dest);
         }
      }
      for (Iterator i = voiceResponseLines.keySet().iterator(); i.hasNext(); ) {
         final Integer conditionNum = (Integer)i.next();
         if (conditionNum.intValue() >= index) {
            final Line2D line = (Line2D)voiceResponseLines.remove(conditionNum);
            voiceResponseLines.put(new Integer(conditionNum.intValue() + 1), line);
         }
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Removes a condition for the specified dialog at the specified index.
    * Called only by
    * {@see edu.berkeley.guir.damask.dialog.Dialog#removeCondition(int)}
    */
   public void removeCondition(final Dialog dialog, final int index) {
      ((List)conditionStates.get(dialog)).remove(index);
      ((List)conditionSignificance.get(dialog)).remove(index);
      voiceResponseLines.remove(new Integer(index));
      voiceResponseDests.remove(new Integer(index));
      
      for (Iterator i = voiceResponseDests.keySet().iterator(); i.hasNext(); ) {
         final Integer conditionNum = (Integer)i.next();
         if (conditionNum.intValue() > index) {
            final ConnectionDest dest = (ConnectionDest)voiceResponseDests.remove(conditionNum);
            voiceResponseDests.put(new Integer(conditionNum.intValue() - 1), dest);
         }
      }
      for (Iterator i = voiceResponseLines.keySet().iterator(); i.hasNext(); ) {
         final Integer conditionNum = (Integer)i.next();
         if (conditionNum.intValue() > index) {
            final Line2D line = (Line2D)voiceResponseLines.remove(conditionNum);
            voiceResponseLines.put(new Integer(conditionNum.intValue() - 1), line);
         }
      }
   }

   //===========================================================================
   
   protected AffineTransform getGlobalTransform(final DeviceType deviceType) {
      final AffineTransform transform = getTransform(deviceType);
      
      final PageRegion pageRegion = getPageRegion(deviceType);
      if (pageRegion != null) {
         transform.preConcatenate(pageRegion.getTransform());
      }
      final Page page = getPage(deviceType);
      if (page != null) {
         transform.preConcatenate(page.getTransform());
      }
      final Dialog dialog = getDialog();
      if (dialog != null) {
         transform.preConcatenate(dialog.getTransform(deviceType));
      }
      
      return transform;
   }

   //---------------------------------------------------------------------------

   // Implements method in ConnectionEndpoint.
   public Rectangle2D localToGlobal(
      final DeviceType deviceType,
      final Rectangle2D rect) {

      return GeomLib.transformRectangle(getGlobalTransform(deviceType), rect);
   }

   //---------------------------------------------------------------------------

   // Implements method in ConnectionEndpoint.
   public Rectangle2D globalToLocal(
      final DeviceType deviceType,
      final Rectangle2D rect) {

      try {
         return GeomLib.transformRectangle(
            getGlobalTransform(deviceType).createInverse(),
            rect);
      }
      catch (NoninvertibleTransformException e) {
         // should never happen
         DamaskAppExceptionHandler.log(e);
      }
      return null;
   }

   //---------------------------------------------------------------------------

   /**
    * Converts the specified rectangle from local coordinates to the
    * parent's coordinates.
    */
   public Rectangle2D localToParent(
      final DeviceType deviceType,
      final Rectangle2D rect) {

      return GeomLib.transformRectangle(getTransform(deviceType), rect);
   }

   //---------------------------------------------------------------------------

   /**
    * Converts the specified rectangle from the parent's coordinate system to
    * local coordinates.
    */
   public Rectangle2D parentToLocal(
      final DeviceType deviceType,
      final Rectangle2D rect) {

      try {
         return GeomLib.transformRectangle(
            getTransform(deviceType).createInverse(),
            rect);
      }
      catch (NoninvertibleTransformException e) {
         // should never happen
         DamaskAppExceptionHandler.log(e);
      }
      return null;
   }

   //===========================================================================
   
   /**
    * Returns the bounds of the voice prompt view of this control.
    */
   public Rectangle2D getVoicePromptBounds() {
      if (voicePromptBounds == null) {
         return null;
      }
      else {
         return (Rectangle2D)voicePromptBounds.clone();
      }
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the text of the voice prompt view of this control, and changes the
    * bounds to fit the text.
    */
   public void setVoicePromptText(final String text) {
      voicePromptText = text;
      firePromptTextChanged();
      
      setVoicePromptBounds(
         DamaskAppUtils.getRenderedTextBounds(
            text, DeviceType.VOICE.getDefaultFontSize()));
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the text of the voice prompt view of this control.
    */
   public String getVoicePromptText() {
      return voicePromptText;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the bounds of the voice prompt view of this control.
    */
   public void setVoicePromptBounds(final Rectangle2D voicePromptBounds) {
      this.voicePromptBounds = voicePromptBounds;
      updateVoiceBounds();
      firePromptBoundsChanged();
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns the source of the voice response view of this control.
    */
   public Control getVoiceResponseSource() {
      return voiceResponseSource;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the source of the voice response view of this control.
    */
   protected void setVoiceResponseSource(final Control voiceResponseSource) {
      if (this.voiceResponseSource == voiceResponseSource) {
         return;
      }
      
      if (this.voiceResponseSource != null) {
         this.voiceResponseSource.removeInteractionElementListener(
            responseEndpointHandler);
      }
      this.voiceResponseSource = voiceResponseSource;
      if (this.voiceResponseSource != null) {
         this.voiceResponseSource.addInteractionElementListener(
            responseEndpointHandler);
      }
      fireResponseSourceChanged();
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns the destination of the voice response view of this control.
    */
   public ConnectionDest getVoiceResponseDest(final int condition) {
      return (ConnectionDest)voiceResponseDests.get(new Integer(condition));
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the destination of the voice response view of this control.
    */
   protected void setVoiceResponseDest(
      final int condition, final ConnectionDest responseDest) {

      final ConnectionDest oldDest = getVoiceResponseDest(condition);
      
      if (oldDest == responseDest) {
         return;
      }
      
      if (oldDest != null) {
         oldDest.removeInteractionElementListener(responseEndpointHandler);
      }
      voiceResponseDests.put(new Integer(condition), responseDest);
      if (responseDest != null) {
         responseDest.addInteractionElementListener(
            responseEndpointHandler);
      }
      fireResponseDestChanged(condition);
   }
   
   //---------------------------------------------------------------------------
   
   private void updateVoiceResponseDestFromConnection(
      final NavConnection connection) {
      setVoiceResponseDest(
         connection.getCondition(), connection.getDest(DeviceType.VOICE));
   }

   //---------------------------------------------------------------------------

   /**
    * Returns the line of the voice response view of this control.
    */
   public Line2D getVoiceResponseLine(final int condition) {
      if (condition >= voiceResponseLines.size()) {
         return null;
      }
      
      final Line2D line = (Line2D)voiceResponseLines.get(new Integer(condition));
      if (line == null) {
         return null;
      }
      else {
         return (Line2D)line.clone();
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Returns all of the lines of the voice response view of this control.
    * 
    * @return a Map that maps a condition number to a line
    */
   public Map/*<Integer, Line2D>*/ getVoiceResponseLines() {
      final Map/*<Integer, Line2D>*/ result = new HashMap/*<Integer, Line2D>*/();
      for (Iterator i = voiceResponseLines.keySet().iterator(); i.hasNext(); ) {
         final Integer condition = (Integer)i.next();
         final Line2D line = (Line2D)voiceResponseLines.get(condition);
         result.put(condition, line == null ? null : line.clone());
      }
      return result;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the line of the voice prompt view of this control.
    */
   public void setVoiceResponseLine(final int condition,
                                    final Line2D voiceResponseLine) {
      voiceResponseLines.put(
         new Integer(condition),
         voiceResponseLine == null ? null : voiceResponseLine.clone());
      updateVoiceBounds();
      fireResponseLineChanged(condition);
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns the list of text in the balloon of the voice response view of
    * this control.
    */
   public List/*<String>*/ getVoiceResponseTextList() {
      return new ArrayList/*<String>*/(voiceResponseText);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Returns the list of text in the balloon of the voice response view of
    * this control.
    */
   public Rectangle2D getVoiceResponseTextListBounds() {
      final StringBuffer b = new StringBuffer();
      for (Iterator i = voiceResponseText.iterator(); i.hasNext(); ) {
         final String s = (String)i.next();
         b.append(s);
         if (i.hasNext()) {
            b.append('\n');
         }
      }
      return
         DamaskAppUtils.getRenderedTextBounds(
            b.toString(), DeviceType.VOICE.getDefaultFontSize());
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns the ith item of text in the balloon of the voice response view
    * of this control.
    */
   public String getVoiceResponseText(final int index) {
      return (String)voiceResponseText.get(index);
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Adds the text to the end of the list of text in the balloon of the
    * voice response view of this control.
    */
   protected void addVoiceResponseText(final String text) {
      voiceResponseText.add(text);
      fireResponseTextChanged();
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Adds the text to the list of text in the balloon of the voice response
    * view of this control at the specified index.
    */
   protected void addVoiceResponseText(final int index, final String text) {
      voiceResponseText.add(index, text);
      fireResponseTextChanged();
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Removes the text at the specified index in the balloon of the voice
    * response view of this control.
    */
   protected void removeVoiceResponseText(final int index) {
      voiceResponseText.remove(index);
      fireResponseTextChanged();
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the text at the specified index in the balloon of the voice response
    * view of this control.
    */
   protected void setVoiceResponseText(final int index, final String text) {
      voiceResponseText.set(index, text);
      fireResponseTextChanged();
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets all of the text in the balloon of the voice response view of this
    * control.
    */
   protected void setVoiceResponseTextList(final List/*<String>*/ textList) {
      voiceResponseText.clear();
      voiceResponseText.addAll(textList);
      fireResponseTextChanged();
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Clears the text in the balloon of the voice response view of this
    * control.
    */
   protected void clearVoiceResponseTextList() {
      voiceResponseText.clear();
      fireResponseTextChanged();
   }

   //---------------------------------------------------------------------------
   
   private void updateVoiceBounds() {
      // Prevent endless loop of update->set->update->set->...
      if (voiceResponseSource == this) {
         voiceResponseSource.removeInteractionElementListener(
            responseEndpointHandler);
      }
      
      // Set the bounds to be the union of all of the responses and the prompt.
      Rectangle2D allResponsesBounds = null;
      for (Iterator i = voiceResponseLines.values().iterator(); i.hasNext(); ) {
         final Line2D line = (Line2D)i.next();
         if (line != null) {
            if (allResponsesBounds == null) {
               allResponsesBounds = line.getBounds2D();
            }
            else {
               Rectangle2D.union(allResponsesBounds, line.getBounds2D(), 
                                 allResponsesBounds);
            }
         }
      }
      
      if ((voicePromptBounds == null) && (allResponsesBounds == null)) {
         setBounds(DeviceType.VOICE, null);
      }
      else if (voicePromptBounds == null) {
         setBounds(DeviceType.VOICE, allResponsesBounds);
      }
      else if (allResponsesBounds == null) {
         setBounds(DeviceType.VOICE, (Rectangle2D)voicePromptBounds.clone());
      }
      else {
         setBounds(
            DeviceType.VOICE,
            voicePromptBounds.createUnion(allResponsesBounds));
      }

      if (voiceResponseSource == this) {
         voiceResponseSource.addInteractionElementListener(
            responseEndpointHandler);
      }
   }
   
   //===========================================================================
   
   public Collection/*<Connection>*/ getOutConnections() {
      return DamaskUtils.unmodifiableCollection(outNavConnections);
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns the connection whose source is this control and matches the
    * specified device type, user event type, and condition.
    */
   public NavConnection getOutConnection(
      final DeviceType connectionOrigDeviceType,
      final boolean forAllDeviceTypes,
      final DamaskUserEvent userEvent,
      final int condition) {
      
      NavConnection result = null; 
      
      for (Iterator i = getOutConnections().iterator(); i.hasNext(); ) {
         final NavConnection connection = (NavConnection)i.next();
         if ((connection.getOrigSpecifiedDeviceType() ==
              connectionOrigDeviceType) &&
             (connection.isForAllDeviceTypes() == forAllDeviceTypes) &&
             (connection.getUserEvent().matches(userEvent)) &&
             (connection.getCondition() == condition)) {
            result = connection;
            break;
         }
      }
      
      return result;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns the connection whose source is this control and matches the
    * specified device type, user event type, and condition.
    */
   public NavConnection getOutConnection(
      final DeviceType connectionDeviceType,
      final DamaskUserEvent userEvent,
      final int condition) {
      
      NavConnection result = null; 
      
      for (Iterator i = getOutConnections().iterator(); i.hasNext(); ) {
         final NavConnection connection = (NavConnection)i.next();
         if (connection.isVisibleToDeviceType(connectionDeviceType) && 
             connection.getUserEvent().matches(userEvent) &&
             (connection.getCondition() == condition)) {
            result = connection;
            break;
         }
      }
      
      return result;
   }

   //---------------------------------------------------------------------------

   public void addOutConnection(final Connection outConnection) {
      if (!outNavConnections.contains(outConnection)) {
         outNavConnections.add(outConnection);
         outConnection.addConnectionListener(connectionHandler);
         fireOutConnectionAdded(outConnection);
      }
   }
   
   //---------------------------------------------------------------------------

   public void removeOutConnection(final Connection outConnection) {
      if (outNavConnections.contains(outConnection)) {
         outNavConnections.remove(outConnection);
         fireOutConnectionRemoved(outConnection);
      }
   }

   //===========================================================================

   public Collection/*<Connection>*/ getInConnections() {
      return DamaskUtils.unmodifiableCollection(inNavConnections);
   }

   //---------------------------------------------------------------------------

   public void addInConnection(final Connection inConnection) {
      if (!inNavConnections.contains(inConnection)) {
         inNavConnections.add(inConnection);
         fireInConnectionAdded(inConnection);
      }
   }

   //---------------------------------------------------------------------------

   public void removeInConnection(final Connection inConnection) {
      if (inNavConnections.contains(inConnection)) {
         inNavConnections.remove(inConnection);
         fireInConnectionRemoved(inConnection);
      }
   }

   //===========================================================================
   
   private static void copyStates(final Control source, final Control dest) {
      for (Iterator i = source.conditionStates.keySet().iterator(); i.hasNext();) {
         final Dialog dialog = (Dialog)i.next();
         dest.conditionStates.put(
            dialog,
            new ArrayList((List)source.conditionStates.get(dialog)));
         dest.conditionSignificance.put(
            dialog,
            new ArrayList/*<boolean>*/(
               (List)source.conditionSignificance.get(dialog)));
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      Control clone = (Control)super.clone();
      clone.outNavConnections = new HashSet();
      clone.inNavConnections = new HashSet();
      clone.regions = new HashMap();
      clone.patternInstances = new HashSet();

      clone.eventSource = new ControlEventSource();

      clone.conditionStates = new HashMap();
      clone.conditionSignificance = new HashMap();
      
      clone.voiceEventSource = new ControlVoiceEventSource();
      clone.voicePromptText = voicePromptText;
      if (voicePromptBounds != null) {
         clone.voicePromptBounds = (Rectangle2D)voicePromptBounds.clone();
      }
      clone.voiceResponseDests = new TreeMap/*<Integer, ConnectionDest>*/();
      clone.voiceResponseLines = new TreeMap/*<Integer, Line2D>*/();
      for (Iterator i = voiceResponseLines.keySet().iterator(); i.hasNext(); ) {
         final Integer key = (Integer)i.next();
         clone.voiceResponseLines.put(key, voiceResponseLines.get(key));
      }
      clone.voiceResponseSource = null;
      clone.voiceResponseText = new ArrayList/*<String>*/(voiceResponseText);
      clone.responseEndpointHandler =
         new VoiceResponseEndpointHandler();
      clone.connectionHandler = new ConnectionHandler();
      clone.pageRegionHandler = new PageRegionHandler();
      
      copyStates(this, clone);
      
      return clone;
   }

   //===========================================================================
   
   /**
    * Returns a string representation of this component, with the given indent
    * level.
    */
   public String toLongString(int indentLevel, DeviceType deviceType) {
      final StringBuffer sb = new StringBuffer();
      sb.append(StringLib.spaces(indentLevel * DamaskUtils.INDENT_SPACES));
      sb.append(toString());
      sb.append(": ");
      
      if (isVisibleToDeviceType(DeviceType.DESKTOP)) {
         sb.append("Desktop [bounds=" +
                   getBounds(DeviceType.DESKTOP) +
                   ", transform=" + getTransform(DeviceType.DESKTOP) +
                   "] ");
      }
      if (isVisibleToDeviceType(DeviceType.SMARTPHONE)) {
         sb.append("Smartphone [bounds=" +
                   getBounds(DeviceType.SMARTPHONE) +
                   ", transform=" + getTransform(DeviceType.SMARTPHONE) +
                   "] ");
      }
      if (isVisibleToDeviceType(DeviceType.VOICE)) {
         sb.append("Voice [promptBounds=" +
                   getVoicePromptBounds() +
                   ", transform=" + getTransform(DeviceType.VOICE) +
                   "] ");
      }
      
      return sb.toString();
   }
   
   //===========================================================================
   
   public String toLongString() {
      return toLongString(0, DeviceType.ALL);
   }

   //===========================================================================
   
   /**
    * Physically places this object at the bottom of the region for the
    * specified device type.
    */
   protected void placeAfterAllControls(final DeviceType deviceType) {
      final PageRegion targetRegion = getPageRegion(deviceType);
      
      double controlBoundsMaxY = 0;
      for (Iterator i = targetRegion.getControls().iterator(); i.hasNext(); ) {
         final Control targetRegionControl = (Control)i.next();
         if (targetRegionControl != this) {
            controlBoundsMaxY =
               Math.max(
                  controlBoundsMaxY,
                  targetRegionControl.getBoundsInParentCoords(deviceType).getMaxY());
         }
      }
      setTransform(
         deviceType,
         AffineTransform.getTranslateInstance(0, controlBoundsMaxY + 5));
   }
      
   /**
    * Physically places this object below the control that appears before
    * it in the list of controls, or above the control that appears after
    * it, for the specified device type.
    * 
    * Doesn't do a good job, so placeAtBottomOfRegion() is replacing it for now.
    */
   protected void placeAfterPrevControl(final DeviceType deviceType) {
      final Control controlAfter =
         DamaskUtils.getNextLowLevelControl(getPageRegion(deviceType), this);
      final AffineTransform newTransform;
      Rectangle2D controlAfterBoundsInParentCoords = null;
      if (controlAfter != null) {
         controlAfterBoundsInParentCoords =
            controlAfter.getBoundsInParentCoords(deviceType);
      }
      if (controlAfterBoundsInParentCoords != null) {
         newTransform =
            AffineTransform.getTranslateInstance(
               controlAfterBoundsInParentCoords.getX(),
               controlAfterBoundsInParentCoords.getY());
      }
      else {
         final Control controlBefore =
            DamaskUtils.getPreviousLowLevelControl(
               getPageRegion(deviceType), this);
         if (controlBefore != null) {
            final Rectangle2D controlBeforeBoundsInParentCoords =
               controlBefore.getBoundsInParentCoords(deviceType);
            if (controlBeforeBoundsInParentCoords != null) {
               newTransform =
                  AffineTransform.getTranslateInstance(
                     controlBeforeBoundsInParentCoords.getX(),
                     controlBeforeBoundsInParentCoords.getMaxY());
            }
            else {
               newTransform = new AffineTransform();
            }
         }
         else {
            newTransform = new AffineTransform();
         }
      }
      
      setTransform(deviceType, newTransform);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Places the voice prompt for this control under the voice prompt of
    * the previous control.
    */
   protected void placeVoicePromptUnderPreviousPrompt() {
      Control controlBefore =
         DamaskUtils.getPreviousLowLevelControl(
            getPageRegion(DeviceType.VOICE), this);

      if (controlBefore == null) {
         Page page = getPage(DeviceType.VOICE);
         int pageIndex =
            page.getDialog().getPages(DeviceType.VOICE).indexOf(page) - 1;
         if (pageIndex > 0) {
            page = page.getDialog().getPage(DeviceType.VOICE, pageIndex);
            List controls = page.getRegion(Direction.CENTER).getControls();
            while (controls.isEmpty() && pageIndex > 0) {
               pageIndex--;
               page = page.getDialog().getPage(DeviceType.VOICE, pageIndex);
               controls = page.getRegion(Direction.CENTER).getControls();
            }
            if (!controls.isEmpty()) {
               controlBefore = (Control)controls.get(controls.size() - 1);
            }
         }
      }
      
      // Case 1: There is no previous control => Place this prompt in the
      // upper left-hand corner.
      if (controlBefore == null) {
         setTransform(DeviceType.VOICE, new AffineTransform());
      }
      
      // Case 2: Previous control is a trigger (which cannot point to this
      // control) => Find the closest previous control with a prompt, and
      // place this prompt a fixed distance under that previous prompt.
      
      // Case 3: Previous control is content (and guaranteed to have a prompt)
      // => Place this prompt a fixed distance under the previous content's
      // prompt.
      else if (controlBefore instanceof Content || 
               controlBefore instanceof Trigger ||
               controlBefore instanceof SelectOne) {
         final Control prevControlWithPrompt =
            DamaskUtils.getPreviousControlWithPrompt(
               getPageRegion(DeviceType.VOICE), this);
         
         if (prevControlWithPrompt == null) {
            setTransform(DeviceType.VOICE, new AffineTransform());
         }
         else {
            final Rectangle2D prevPromptBoundsInParent =
               prevControlWithPrompt.localToParent(
                  DeviceType.VOICE, prevControlWithPrompt.getVoicePromptBounds());
            
            setTransform(
               DeviceType.VOICE,
               AffineTransform.getTranslateInstance(
                  prevPromptBoundsInParent.getMinX(),
                  prevPromptBoundsInParent.getMaxY() + Response.DEFAULT_LENGTH));
         }
      }
      
      // Case 4: Previous control is something else (and guaranteed to have
      // a prompt and one response) => Place this prompt under the response
      else {
         final Line2D responseLine = controlBefore.getVoiceResponseLine(0);
         //HACK "if" guard should not be necessary
         if (responseLine != null && getVoicePromptBounds() != null) {
            setTransform(
               DeviceType.VOICE,
               AffineTransform.getTranslateInstance(
                  responseLine.getX2() - getVoicePromptBounds().getWidth()/2,
                  responseLine.getY2()));
         }
         else {
            setTransform(DeviceType.VOICE, new AffineTransform());
         }
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Points the response in this control to the next prompt.
    */
   protected void redirectResponseToNextPrompt() {
      final Control controlAfter =
         DamaskUtils.getNextControlWithPrompt(
            getPageRegion(DeviceType.VOICE), this);

      final Control responseSource = getVoiceResponseSource();
      
      final Rectangle2D balloonBounds = getVoiceResponseTextListBounds();
      if ((responseSource == null) && (controlAfter == null)) {
         setVoiceResponseLine(
            0,
            new Line2D.Double(
               balloonBounds.getWidth() / 2,
               0,
               balloonBounds.getWidth() / 2,
               Math.max(
                  Response.DEFAULT_LENGTH,
                  balloonBounds.getHeight() +
                     Response.MIN_RESPONSE_LENGTH_OUTSIDE_BALLOON)));
         setVoiceResponseDest(0, null);
      }
      else {
         final Rectangle2D sourceBounds;
         if (responseSource == null) {
            sourceBounds = null;
         }
         else {
            sourceBounds =
               globalToLocal(
                  DeviceType.VOICE,
                  responseSource.localToGlobal(
                     DeviceType.VOICE,
                     responseSource.getVoicePromptBounds()));
         }
         
         if (controlAfter == null) {
            setVoiceResponseLine(
               0,
               new Line2D.Double(
                  sourceBounds.getCenterX(),
                  sourceBounds.getCenterY(),
                  sourceBounds.getCenterX(),
                  sourceBounds.getCenterY() +
                  Math.max(
                     Response.DEFAULT_LENGTH,
                     balloonBounds.getHeight() +
                        Response.MIN_RESPONSE_LENGTH_OUTSIDE_BALLOON)));
            setVoiceResponseDest(0, null);
         }
         else {
            final Rectangle2D controlAfterPromptBounds =
               globalToLocal(
                  DeviceType.VOICE,
                  controlAfter.localToGlobal(
                     DeviceType.VOICE,
                     controlAfter.getVoicePromptBounds()));
         
            final double startX;
            final double startY;
            if (sourceBounds == null) {
               startX = controlAfterPromptBounds.getCenterX();
               startY = controlAfterPromptBounds.getCenterY() -
                  Math.max(
                     Response.DEFAULT_LENGTH,
                     balloonBounds.getHeight() +
                        Response.MIN_RESPONSE_LENGTH_OUTSIDE_BALLOON);
            }
            else {
               startX = sourceBounds.getCenterX();
               startY = sourceBounds.getCenterY();
            }
            
            setVoiceResponseLine(
               0,
               new Line2D.Double(
                  startX,
                  startY,
                  controlAfterPromptBounds.getCenterX(),
                  controlAfterPromptBounds.getCenterY()));
            setVoiceResponseDest(0, controlAfter);
         }
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Moves all subsequent responses so that the originate
    * from this control.
    */
   protected void reanchorSubsequentResponsesToThisPrompt() {
      final List/*<Control>*/ voiceRegionControls =
         getPageRegion(DeviceType.VOICE).getControls();
      final int thisIndex = voiceRegionControls.indexOf(this);
      
      final Rectangle2D promptBoundsInGlobalCoords =
         localToGlobal(DeviceType.VOICE, getVoicePromptBounds());
   
      for (Iterator i = voiceRegionControls.listIterator(thisIndex + 1);
           i.hasNext();) {
         final Control aNextControl = (Control) i.next();
         if (aNextControl.getVoicePromptBounds() != null) {
            break;
         }
         for (int j = 0, n = getDialog().getNumConditions(); j < n; j++) {
            final Line2D response = aNextControl.getVoiceResponseLine(j);
            if (response != null) {
               final Rectangle2D promptBoundsInANextControlCoords =
                  aNextControl.globalToLocal(
                     DeviceType.VOICE,
                     promptBoundsInGlobalCoords);
      
               aNextControl.setVoiceResponseLine(
                  j,
                  new Line2D.Double(
                     promptBoundsInANextControlCoords.getCenterX(),
                     promptBoundsInANextControlCoords.getCenterY(),
                     response.getX2(),
                     response.getY2()));
               aNextControl.setVoiceResponseSource(this);
            }
         }
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Sets up a control which, in the voice view, consists of one
    * prompt and one response.
    */
   protected void setupVoiceResponsesForControlWithPromptAndResponse() {
      final Control controlAfter =
         DamaskUtils.getNextLowLevelControl(
            getPageRegion(DeviceType.VOICE), this);
      
      // If the next part is a response that represents a Trigger,
      // then make the Trigger the response of the select-many item.
      if (controlAfter instanceof Trigger) {
         // Set my response line null.
         setVoiceResponseLine(0, null);
         // Reanchor the trigger's response to start from me.
         reanchorSubsequentResponsesToThisPrompt();
      }
      else {
         setVoiceResponseSource(this);
         redirectResponseToNextPrompt();
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets up a control, which, in the voice view, only consists
    * of a response.
    */
   protected void setupVoiceResponseForControlWithResponseOnly() {
      // Find the previous control with a prompt. That will be the source
      // of the response.
      final Control prevControlWithPrompt = 
         DamaskUtils.getPreviousControlWithPrompt(
            getPageRegion(DeviceType.VOICE), this);
   
      final Control nextControl =
         DamaskUtils.getNextLowLevelControl(
            getPageRegion(DeviceType.VOICE), this);
   
      // Set up the response
      if ((prevControlWithPrompt == null) && (nextControl == null)) {
         final Rectangle2D balloonBounds =
            DamaskAppUtils.getRenderedTextBounds(
               StringLib.join(getVoiceResponseTextList(), "\n"),
               DeviceType.VOICE.getDefaultFontSize());
         setVoiceResponseLine(
            0,
            new Line2D.Double(
               balloonBounds.getWidth() / 2,
               0,
               balloonBounds.getWidth() / 2,
               Math.max(
                  Response.DEFAULT_LENGTH,
                  balloonBounds.getHeight() +
                     Response.MIN_RESPONSE_LENGTH_OUTSIDE_BALLOON)));
         setVoiceResponseSource(null);
         setVoiceResponseDest(0, null);
      }
      // If the next control is a trigger...
      else if (nextControl instanceof Trigger) {
         setVoiceResponseLine(0, null);  // since the trigger overrides
         setVoiceResponseSource(null);
         setVoiceResponseDest(0, null);
      }
      else {
         setVoiceResponseSource(prevControlWithPrompt);
         redirectResponseToNextPrompt();
      }
   }   
   
   //---------------------------------------------------------------------------
   
   // @Override
   public Rectangle2D getVoiceResponseDestBounds() {
      return getVoicePromptBounds();
   }

   //---------------------------------------------------------------------------

   private void recalculateVoiceResponseLines() {
      for (int i = 0, n = getDialog().getNumConditions(); i < n; i++) {
         recalculateVoiceResponseLine(i);
      }
   }

   private void recalculateVoiceResponseLine(int i) {
      final Line2D oldLine = getVoiceResponseLine(i);
      final Control source = getVoiceResponseSource();
      final ConnectionDest dest = getVoiceResponseDest(i);

      if (oldLine == null) {
         return;
      }

      final double dx = oldLine.getX2() - oldLine.getX1();
      final double dy = oldLine.getY2() - oldLine.getY1();
      
      final Rectangle2D sourcePromptBounds;
      if (source != null) {
         sourcePromptBounds =
            globalToLocal(
               DeviceType.VOICE,
               source.localToGlobal(
                  DeviceType.VOICE, source.getVoicePromptBounds()));
      }
      else {
         sourcePromptBounds = null;
      }
      
      final Rectangle2D destPromptBounds;
      if (dest != null) {
         destPromptBounds =
            globalToLocal(
               DeviceType.VOICE,
               dest.localToGlobal(
                  DeviceType.VOICE, dest.getVoiceResponseDestBounds()));
      }
      else {
         destPromptBounds = null;
      }
      
      // If the destination is below the source, then anchor the response
      // near the lower left corner. Otherwise, anchor to the upper right.
      if ((source == null) && (dest == null)) {
         
      }
      else if (source == null) {
         final double destAnchorX;
         final double destAnchorY;
         if (dy >= 0) {
            destAnchorX =
               destPromptBounds.getX() + 0.25 * destPromptBounds.getWidth(); 
            destAnchorY =
               destPromptBounds.getY() + 0.75 * destPromptBounds.getHeight(); 
         }
         else {
            destAnchorX =
               destPromptBounds.getX() + 0.75 * destPromptBounds.getWidth(); 
            destAnchorY =
               destPromptBounds.getY() + 0.25 * destPromptBounds.getHeight(); 
         }
         setVoiceResponseLine(
            i,
            new Line2D.Double(
               destAnchorX - dx,
               destAnchorY - dy,
               destAnchorX,
               destAnchorY));
      }
      else if (dest == null) {
         final double sourceAnchorX;
         final double sourceAnchorY;
         if (dy >= 0) {
            sourceAnchorX =
               sourcePromptBounds.getX() + 0.25 * sourcePromptBounds.getWidth(); 
            sourceAnchorY =
               sourcePromptBounds.getY() + 0.75 * sourcePromptBounds.getHeight(); 
         }
         else {
            sourceAnchorX =
               sourcePromptBounds.getX() + 0.75 * sourcePromptBounds.getWidth(); 
            sourceAnchorY =
               sourcePromptBounds.getY() + 0.25 * sourcePromptBounds.getHeight(); 
         }
         setVoiceResponseLine(
            i,
            new Line2D.Double(
               sourceAnchorX,
               sourceAnchorY,
               sourceAnchorX + dx,
               sourceAnchorY + dy));
      }
      else {
         final double fracX;
         final double fracY;
         if (destPromptBounds.getCenterY() >= sourcePromptBounds.getCenterY()) {
            fracX = 0.25;
            fracY = 0.75;
         }
         else {
            fracX = 0.75;
            fracY = 0.25;
         }
         setVoiceResponseLine(
            i,
            new Line2D.Double(
               sourcePromptBounds.getX() + fracX * sourcePromptBounds.getWidth(),
               sourcePromptBounds.getY() + fracY * sourcePromptBounds.getHeight(),
               destPromptBounds.getX() + fracX * destPromptBounds.getWidth(),
               destPromptBounds.getY() + fracY * destPromptBounds.getHeight()));
      }
   }

   //===========================================================================
   
   /**
    * Listens to changes in the endpoints of the connection. 
    */
   private class VoiceResponseEndpointHandler implements
   InteractionElementListener, ControlVoiceListener {
      
      public void elementBoundsUpdated(InteractionElementEvent e) {
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
         if (e.getDeviceType() == DeviceType.VOICE) {
            recalculateVoiceResponseLines();
         }
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }

      public void promptTextChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void promptBoundsChanged(ControlVoiceEvent e) {
         recalculateVoiceResponseLines();
      }

      public void responseSourceChanged(ControlVoiceEvent e) {
      }

      public void responseDestChanged(ControlVoiceEvent e) {
      }

      public void responseLineChanged(ControlVoiceEvent e) {
      }

      public void responseTextChanged(ControlVoiceEvent e) {
      }
   }
   
   //===========================================================================
   
   /**
    * Handles events from outgoing connections. 
    */
   private class ConnectionHandler implements ConnectionListener {

      // @Override
      public void sourceChanged(ConnectionEvent e) {
      }

      // @Override
      public void destChanged(ConnectionEvent e) {
         if (e.getDeviceType() == DeviceType.VOICE) {
            updateVoiceResponseDestFromConnection(
               (NavConnection)e.getConnection());
            recalculateVoiceResponseLine(
               ((NavConnection)e.getConnection()).getCondition());
         }
      }

      // @Override
      public void shapeChanged(ConnectionEvent e) {
      }

      // @Override
      public void userEventChanged(ConnectionEvent e) {
      }

      // @Override
      public void conditionChanged(ConnectionEvent e) {
      }
   }

   //===========================================================================
   
   /**
    * Listens to elements being added and removed from the same page region
    * as this control's. 
    */
   private class PageRegionHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         final PageRegion voiceRegion = getPageRegion(DeviceType.VOICE); 
         if (voiceRegion != null &&
             voiceRegion.getControls().indexOf(Control.this) != -1) {
            // If this element was just added, or if the element just added was
            // was added just after this control, then update the voice
            // responses.
            if (e.getElement() == Control.this) {
               setupVoiceResponses();
               nextVoiceControl = voiceRegion.getNextControl(Control.this);
            }
            else {
               final Control newNext = voiceRegion.getNextControl(Control.this);
               if (e.getElement() == newNext) {
                  setupVoiceResponses();
                  nextVoiceControl = newNext;
               }
            }
         }
      }

      public void elementRemoved(ElementContainerEvent e) {
         final PageRegion voiceRegion = getPageRegion(DeviceType.VOICE); 
         if (voiceRegion != null &&
             voiceRegion.getControls().indexOf(Control.this)
               != -1) {
            // If the element after this control was just removed, then update
            // the voice responses.
            if (e.getElement() == nextVoiceControl) {
               setupVoiceResponses();
               nextVoiceControl = voiceRegion.getNextControl(Control.this);
            }
         }
      }
   }
}
