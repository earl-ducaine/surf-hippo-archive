package edu.berkeley.guir.denim;

/**
 * @author Jenny
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class ScenarioNode {
   private DenimPanel panel;
   private Scenario.Time time;
      
   public ScenarioNode() {
      this(null, new Scenario.Time("0:00"));
   }
   
   public ScenarioNode(DenimPanel panel) {
      this(panel, new Scenario.Time("0:00"));
   }

   public ScenarioNode(DenimPanel panel, String time) {
      this(panel, new Scenario.Time(time));
   }

   public ScenarioNode(DenimPanel panel, long time) {
      this(panel, new Scenario.Time(time));  
   }
   
   public ScenarioNode(DenimPanel panel, Scenario.Time time) {
      this.panel = panel;
      this.time = time;
   }

   public String getStringTime() {
         return time.toString();
   }

   public String getMiliTime() {
      return time.toStringSec();
   }
   
   public long getLongTime() {
      return time.getMSec();  
   }
   public Scenario.Time getTime() {
      return this.time;
   }
   
   public DenimPanel getPanel() {
      return panel;
   }

   public boolean setTime(String time, Scenario parent) {
      Scenario.Time ti = new Scenario.Time(time);
      if(ti.isTimeFormat()) {
         //parent.updateTime(Scenario.timeDiff(this.time, time));
         parent.adjustTime(ti.getDiff(this.time));
         this.time = ti;
         return true;
      } else
         return false;
   }
   
   //note this should only be used by the scenario maanger
   public void setTime(Scenario.Time time) {
         this.time = time;
   }

   public void setPanel(DenimPanel panel) {
      this.panel = panel;
   }

   public ScenarioNode deepClone() {
      return new ScenarioNode(this.panel, this.time);
   }
}
