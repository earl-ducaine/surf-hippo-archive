//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tree;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * An element in the tree. Contains children.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.5/1.0.0, Apr 09 2002, JIH
 *               Created 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.4
 * @version GUIRLib-v1.5/1.0.0, Apr 09 2002 JIH
 */
public class TreeNode {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    List     children   = new LinkedList();  // set of children TreeNodes
    TreeNode parent     = null;              // reference back to parent
    Object   value      = null;              // value contained within
    boolean  flagIgnore = false;             // ignore for paths, etc? for roots

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    /**
     * Does nothing special.
     */
    public TreeNode() {
    } // of constructor

    //----------------------------------------------------------------

    public TreeNode(Object newValue) {
        setValue(newValue);
    } // of method

    //----------------------------------------------------------------

    /**
     * Copy constructor, shallow copy on both the node and on
     * the Object that the node contains.
     *
     * @param node is the TreeNode to copy into this new instance.
     */
    public TreeNode(TreeNode node) {
        this.children   = (List) ((LinkedList) node.children).clone();
        this.parent     = node.parent;
        this.value      = node.value;
        this.flagIgnore = node.flagIgnore;
    } // of constructor

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================




    //==========================================================================
    //===   ROOT NODE METHODS   ================================================

    /**
     * Set whether this node should be ignored when determining paths
     * (but not for adding paths). Useful for root nodes.
     */
    public void setIgnore(boolean flag) {
        flagIgnore = flag;
    } // of method

    //----------------------------------------------------------------

    public boolean isIgnored() {
        return (flagIgnore);
    } // of method

    //===   ROOT NODE METHODS   ================================================
    //==========================================================================




    //==========================================================================
    //===   VALUE METHODS   ====================================================

    /**
     * Objects added should implement the .equals() method correctly.
     *
     * @param newValue is the value of this node. Safe to set to null.
     */
    public void setValue(Object newValue) {
        value = newValue;
    } // of method

    //----------------------------------------------------------------

    public Object getValue() {
        return (value);
    } // of method

    //----------------------------------------------------------------

    public void clearValue() {
        value = null;
    } // of method

    //----------------------------------------------------------------

    public boolean containsValue(Object obj) {
        return (obj.equals(value));
    } // of method

    //===   VALUE METHODS   ====================================================
    //==========================================================================




    //==========================================================================
    //===   PARENT METHODS   ===================================================

    public void setParent(TreeNode node) {
        parent = node;
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the parent of this node. Null if no parent (ie a root).
     */
    public TreeNode getParent() {
        return (parent);
    } // of method

    //===   PARENT METHODS   ===================================================
    //==========================================================================




    //==========================================================================
    //===   PATH METHODS  ======================================================

    /**
     * Get the path one would take from the root of the tree to this node.
     * Assumes root has no parent.
     * Basically just goes up the tree via the parent until it hits the root.
     */
    public TreePath getPathFromRoot() {
        TreeNode currNode = this;
        TreePath path     = new TreePath();

        do {
            if (currNode.isIgnored() == false) {
                path.addToFront(currNode);
            }
            currNode = currNode.getParent();
        } while (currNode != null);

        return (path);
    } // of method

    //----------------------------------------------------------------

    /**
     * Check if the specified path is valid or not (ie exists).
     */
    public boolean isValidPath(TreePath path) {
        TreeNode node = getNodeFromPath(path);
        return (node != null);
    } // of method

    //----------------------------------------------------------------

    /**
     * Given a path, get the corresponding node in the tree.
     *
     * @return the node, or null if it isn't there.
     */
    public TreeNode getNodeFromPath(TreePath path) {
        TreeNode currNode = this;
        Iterator it       = path.values();
        Object   val;

        while (it.hasNext()) {
            val      = it.next();
            currNode = currNode.getChild(val);
            if (currNode == null) {
                return (null);
            }
        }

        return (currNode);
    } // of method

    //===   PATH METHODS  ======================================================
    //==========================================================================




    //==========================================================================
    //===   TREE METHODS  ======================================================

    public void addChild(TreeNode node) {
        children.add(node);
        node.setParent(this);
    } // of method

    //----------------------------------------------------------------

    /**
     * Add the path to this tree, creating new nodes if needed.
     * Creates new TreeNodes internally, TreeNodes in parameter path
     * not modified, nor are they added to the tree.
     */
    public void addPath(TreePath path) {
        Iterator it   = path.path();
        TreeNode curr = this;
        TreeNode next = null;
        TreeNode pnode;
        Object   val;

        while (it.hasNext()) {
            pnode = (TreeNode) it.next();
            val   = pnode.getValue();
            next  = curr.getChild(val);

            //// If the node does not exist, create and add it.
            if (next == null) {
                next = new TreeNode(val);
                curr.addChild(next);
            }

            //// Prepare for next iteration.
            curr = next;
            next = null;
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Remove the leaf node of the specified path from the tree.
     *
     * @return true if removed, false otherwise.
     */
    public boolean removePath(TreePath path) {
        TreeNode node   = getNodeFromPath(path);
        TreeNode parent;

        //// 1. No node returned, so it does not exist.
        if (node == null) {
            return false;
        }

        //// 2. Get the parent, and then remove the node from the parent.
        parent = node.getParent();
        return (parent.removeChild(node));
    } // of method

    //----------------------------------------------------------------

    /**
     * @return The TreeNode containing the specified value (.equals()), or
     *         null if the value does not exist.
     */
    public TreeNode getChild(Object val) {
        Iterator it   = children.iterator();
        TreeNode node = null;

        while (it.hasNext()) {
            node = (TreeNode) it.next();
            if (val.equals(node.getValue())) {
                return (node);
            }
        }
        return (null);
    } // of method

    //----------------------------------------------------------------

    public boolean removeChild(TreeNode node) {
        node.setParent(null);
        return (children.remove(node));
    } // of method

    //----------------------------------------------------------------

    public boolean hasChildren() {
        return (children.size() > 0);
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the Nth tree node. Ordering is based on order they were added.
     */
    public TreeNode getChild(int n) {
        TreeNode node = (TreeNode) children.get(n);
        return (node);
    } // of method

    //----------------------------------------------------------------

    /**
     * Number of children, shallow (ie 1-level);
     */
    public int numChildren() {
        return (children.size());
    } // of method

    //----------------------------------------------------------------

    /**
     * Get one level depth of children as an Iterator.
     */
    public Iterator children() {
        return (children.iterator());
    } // of method


    /**
     * Get one level depth of children as a List.
     */
    public List childrenAsList() {
        return (new LinkedList(children));
    } // of method

    //----------------------------------------------------------------

    /**
     * Get all children (regardless of depth) as an Iterator in pre-order.
     */
    public Iterator allChildrenPreOrder() {
        return (allChildrenPreOrderAsList().iterator());
    } // of method


    /**
     * Get all children (regardless of depth) as a List in pre-order.
     */
    public List allChildrenPreOrderAsList() {
        TreeTraversalOpAllChildren op = new TreeTraversalOpAllChildren();
        preOrder(op);
        return (op.childrenAsList());
    } // of method

    //----------------------------------------------------------------

    /**
     * Get all children (regardless of depth) as an Iterator in post-order.
     */
    public Iterator allChildrenPostOrder() {
        return (allChildrenPostOrderAsList().iterator());
    } // of method


    /**
     * Get all children (regardless of depth) as a List in post-order.
     */
    public List allChildrenPostOrderAsList() {
        TreeTraversalOpAllChildren op = new TreeTraversalOpAllChildren();
        postOrder(op);
        return (op.childrenAsList());
    } // of method

    //----------------------------------------------------------------

    /**
     * Get all children (regardless of depth) as an Iterator in breadth-order.
     */
    public Iterator allChildrenBreadthOrder() {
        return (allChildrenBreadthOrderAsList().iterator());
    } // of method


    /**
     * Get all children (regardless of depth) as a List in breadth-order.
     */
    public List allChildrenBreadthOrderAsList() {
        TreeTraversalOpAllChildren op = new TreeTraversalOpAllChildren();
        breadthOrder(op);
        return (op.childrenAsList());
    } // of method

    //===   TREE METHODS  ======================================================
    //==========================================================================




    //==========================================================================
    //===   TREE TRAVERSAL METHODS   ===========================================

    /**
     * Depth-first traversal, perform the operation on current node first, 
     * then all children.
     */
    public void preOrder(TreeTraversalOp op) {
        preOrderHelper(op, 0);
    } // of method


    /**
     * Helper method to keep track of depth.
     */
    private void preOrderHelper(TreeTraversalOp op, int depth) {
        Iterator it = children.iterator();
        TreeNode node;

        op.onNode(this, depth);

        while (it.hasNext()) {
            node = (TreeNode) it.next();
            node.preOrderHelper(op, depth + 1);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Depth-first traversal, perform the operation on all children first, 
     * and then current node.
     */
    public void postOrder(TreeTraversalOp op) {
        postOrderHelper(op, 0);
    } // of method


    /**
     * Helper method to keep track of depth.
     */
    private void postOrderHelper(TreeTraversalOp op, int depth) {
        Iterator it = children.iterator();
        TreeNode node;

        while (it.hasNext()) {
            node = (TreeNode) it.next();
            node.postOrderHelper(op, depth + 1);
        }

        op.onNode(this, depth);
    } // of method

    //----------------------------------------------------------------

    static class BreadthNode {
        TreeNode node;
        int      depth;

        public BreadthNode(TreeNode newNode, int newDepth) {
            node  = newNode;
            depth = newDepth;
        } // of constructor
    } // of inner class


    /**
     * Breadth-first traversal, perform the operation on current node
     * first, and then on first level of children, then second level, etc.
     */
    public void breadthOrder(TreeTraversalOp op) {
        LinkedList  searchQueue  = new LinkedList();  // complete queue
        LinkedList  currentQueue = new LinkedList();  // temp queue
        TreeNode    node;
        int         depth;
        BreadthNode bnode;
        Iterator    it;

        //// 1. Seed the search queue.
        bnode = new BreadthNode(this, 0);
        currentQueue.add(bnode);

        //// 2. Process the current queue.
        while (currentQueue.size() > 0) {
            bnode = (BreadthNode) currentQueue.removeFirst();
            node  = bnode.node;
            depth = bnode.depth;
            searchQueue.add(bnode);

            it = node.children();
            while (it.hasNext()) {
                node  = (TreeNode) it.next();
                bnode = new BreadthNode(node, depth + 1);
                currentQueue.add(bnode);
            }
        }

        //// 3. Perform the operation on all nodes.
        it = searchQueue.iterator();
        while (it.hasNext()) {
            bnode = (BreadthNode) it.next();
            op.onNode(bnode.node, bnode.depth);
        }
    } // of method

    //===   TREE TRAVERSAL METHODS   ===========================================
    //==========================================================================




    //==========================================================================
    //===   TREE LEAF METHODS   ================================================

    /**
     * Get an iterator of TreeNodes over leaf nodes in this tree.
     */
    public Iterator getLeafNodes() {
        TreeTraversalOpLeafNodes op = new TreeTraversalOpLeafNodes();
        preOrder(op);
        return (op.getLeafNodes());
    } // of method

    //----------------------------------------------------------------

    /**
     * Get an iterator of TreePaths over leaf nodes in this tree.
     */
    public Iterator getLeafPaths() {
        Iterator it        = getLeafNodes();
        List     listPaths = new LinkedList();
        TreeNode node;
        TreePath path;

        while (it.hasNext()) {
            node = (TreeNode) it.next();
            path = node.getPathFromRoot();
            listPaths.add(path);
        }

        return (listPaths.iterator());
    } // of method

    //===   TREE LEAF METHODS   ================================================
    //==========================================================================




    //==========================================================================
    //===   EQUALS   ===========================================================

    public boolean equals(Object obj) {
        //// 1. Optimization check.
        if (this == obj) {
            return (true);
        }

        //// 2. Check internal values.
        if (obj instanceof TreeNode) {
            TreeNode node  = (TreeNode) obj;
            Object   valAA = node.getValue();
            Object   valBB = getValue();

            if (valAA == null || valBB == null) {
                return (valAA == valBB);
            }
            else {
                return (valBB.equals(valAA));
            }
        }
        return (false);
    } // of method

    //----------------------------------------------------------------

    public int hashCode() {
        if (getValue() == null) {
            return (0);
        }
        else {
            return (getValue().hashCode());
        }
    } // of method

    //===   EQUALS   ===========================================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        return ("{" + value);
    } // of method

    //----------------------------------------------------------------

    /**
     * Get a String representing the tree structure.
     */
    public String toDebugString() {
        TreeTraversalOpToString op = new TreeTraversalOpToString();
        preOrder(op);
        return (op.getString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   MAIN   =============================================================

    public static void main(String[] argv) {
        TreeNode nodeAA = new TreeNode(new Character('A'));
        TreeNode nodeBB = new TreeNode(new Character('B'));
        TreeNode nodeCC = new TreeNode(new Character('C'));
        TreeNode nodeDD = new TreeNode(new Character('D'));
        TreeNode nodeEE = new TreeNode(new Character('E'));
        TreeNode nodeFF = new TreeNode(new Character('F'));
        TreeNode nodeGG = new TreeNode(new Character('G'));
        TreeNode nodeHH = new TreeNode();

        nodeAA.addChild(nodeBB);
        nodeAA.addChild(nodeCC);
        nodeAA.addChild(nodeDD);

        nodeBB.addChild(nodeEE);
        nodeBB.addChild(nodeFF);

        nodeFF.addChild(nodeGG);
        nodeFF.addChild(nodeHH);

        System.out.println(nodeAA.toDebugString());
        System.out.println(nodeAA.numChildren());


System.out.println("-----");
nodeAA.setIgnore(true);
System.out.println(nodeAA.toDebugString());
System.out.println("-----");

        Iterator it = nodeAA.getLeafNodes();
        while (it.hasNext()) {
            System.out.println("--" + it.next());
        }

        System.out.println(nodeAA.getPathFromRoot());
        System.out.println(nodeBB.getPathFromRoot());
        System.out.println(nodeGG.getPathFromRoot());
        System.out.println(nodeHH.getPathFromRoot());

System.out.println("-----");

        TreePath p;
        
        TreeNode nodeBBBB = new TreeNode(new Character('B'));
        TreeNode nodeEEEE = new TreeNode(new Character('E'));
        TreeNode nodeIIII = new TreeNode(new Character('I'));
        p = new TreePath(nodeBBBB, nodeEEEE, nodeIIII);
        System.out.println(p);
        System.out.println(nodeIIII.getPathFromRoot());
        nodeAA.addPath(p);
System.out.println("-----");
        System.out.println(nodeIIII.getPathFromRoot());
        System.out.println(nodeAA.toDebugString());

        p = new TreePath(new Character('J'), new Character('K'));
        System.out.println(p);
        nodeAA.addPath(p);
        System.out.println(nodeAA.toDebugString());

System.out.println("-----");

        TreeTraversalOpToString op1 = new TreeTraversalOpToString();
        TreeTraversalOpToString op2 = new TreeTraversalOpToString();
        TreeTraversalOpToString op3 = new TreeTraversalOpToString();


        nodeAA.preOrder(op1);
        nodeAA.postOrder(op2);
        nodeAA.breadthOrder(op3);

        System.out.println("pre");
        System.out.println(op1.getString());
        System.out.println("post");
        System.out.println(op2.getString());
        System.out.println("breadth");
        System.out.println(op3.getString());

System.out.println("-----");

        nodeAA.removePath(p);
        System.out.println(nodeAA.toDebugString());

        nodeAA.removePath(nodeBB.getPathFromRoot());
        System.out.println(nodeAA.toDebugString());

    } // of method

    //===   MAIN   =============================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2002 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/


