package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.lib.satin.command.MacroCommand;

/** 
 * A macro command that also modifies the interaction graph.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  12-17-2003 James Lin
 *                               Created ModifyGraphMacroCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 @version Version 1.0.0, 12-17-2003
 */
public class ModifyGraphMacroCommand
   extends MacroCommand
   implements ModifyGraphCommand {
}
