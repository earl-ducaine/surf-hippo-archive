package edu.berkeley.guir.suede;

public class DesignScriptNodeModel extends AbstScriptNodeModel
{
  public DesignScriptNodeModel(String label, boolean flavor) {    
      super(label);
      m_script = new DesignScriptNodeView(flavor, this);
      m_samplingGraph.setElement(m_script);
      m_script.setPlayable(false);
  }
}