//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tree;

import java.util.*;

/**
 * A path in the tree.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.5/1.0.0, Apr 09 2002, JIH
 *               Created 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.4
 * @version GUIRLib-v1.5/1.0.0, Apr 09 2002 JIH
 */
public class TreePath {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    LinkedList list = new LinkedList();

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    /**
     * Does nothing special.
     */
    public TreePath() {
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Create a TreePath with this node.
     */
    public TreePath(TreeNode nodeAA) {
        addToBack(nodeAA);
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a TreePath with these nodes (in order).
     */
    public TreePath(TreeNode nodeAA, TreeNode nodeBB) {
        addToBack(nodeAA);
        addToBack(nodeBB);
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a TreePath with these nodes (in order).
     */
    public TreePath(TreeNode nodeAA, TreeNode nodeBB, TreeNode nodeCC) {
        addToBack(nodeAA);
        addToBack(nodeBB);
        addToBack(nodeCC);
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a TreePath with this object.
     */
    public TreePath(Object objAA) {
        addObjectToBack(objAA);
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a TreePath with these objects (in order).
     */
    public TreePath(Object objAA, Object objBB) {
        addObjectToBack(objAA);
        addObjectToBack(objBB);
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a TreePath with these objects (in order).
     */
    public TreePath(Object objAA, Object objBB, Object objCC) {
        addObjectToBack(objAA);
        addObjectToBack(objBB);
        addObjectToBack(objCC);
    } // of method

    //----------------------------------------------------------------

    /**
     * Copy constructor. Shallow copy.
     *
     * @param tp is the graph to copy into this new instance.
     */
    public TreePath(TreePath tp) {
        list = new LinkedList(tp.list);
    } // of constructor

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================



    //==========================================================================
    //===   TREEPATH METHODS   =================================================

    /**
     * Add to the front of the path.
     */
    public void addToFront(TreeNode node) {
        list.addFirst(node);
    } // of method


    /**
     * Add to the back of the path.
     */
    public void addToBack(TreeNode node) {
        list.addLast(node);
    } // of method

    
    /**
     * Add all treenodes in the list.
     */
    public void addAll(List newlist) {
        Iterator it = newlist.iterator();
        TreeNode node;

        while (it.hasNext()) {
            node = (TreeNode) it.next();
            list.add(node);
        }
    } // of method

    //----------------------------------------------------------------

    public void addObjectToFront(Object obj) {
        addToFront(new TreeNode(obj));
    } // of method


    public void addObjectToBack(Object obj) {
        addToBack(new TreeNode(obj));
    } // of method


    /**
     * Add a list of objects to the end of this path.
     */
    public void addAllObjects(List newlist) {
        Iterator it = newlist.iterator();
        Object   val;

        while (it.hasNext()) {
            val = it.next();
            addObjectToBack(val);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Get an iterator on the nodes this path contains.
     */
    public Iterator path() {
        return (pathAsList().iterator());
    } // of method

    //----------------------------------------------------------------

    /**
     * Return a list version of the nodes this path contains.
     * Modifying this list has no effect (but modifying the objects 
     * contained within may).
     */
    public List pathAsList() {
        return (new LinkedList(list));
    } // of method

    //----------------------------------------------------------------

    /**
     * Get an iterator on the values this path contains.
     */
    public Iterator values() {
        return (valuesAsList().iterator());
    } // of method

    //----------------------------------------------------------------

    /**
     * Return a list version of the values this path contains.
     * Modifying this list has no effect (but modifying the objects 
     * contained within may).
     */
    public List valuesAsList() {
        LinkedList list = new LinkedList();
        Iterator   it   = path();
        TreeNode   node;

        while (it.hasNext()) {
            node = (TreeNode) it.next();
            list.add(node.getValue());
        }

        return (list);
    } // of method

    //===   TREEPATH METHODS   =================================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        StringBuffer strbuf = new StringBuffer();
        Iterator     it     = values();

        strbuf.append("Path: [");
        while (it.hasNext()) {
            strbuf.append(it.next() + ", ");
        }
        strbuf.append("]");

        return (strbuf.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2002 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
