package edu.berkeley.guir.damask.view.voice;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.view.InteractionElementViewInterface;
import edu.berkeley.guir.damask.view.voice.dialog.Form;

/**
 * A marker interface that marks a class as a source of a response.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-18-2004 James Lin
 *                               Created ResponseSource.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-18-2004
 */
public interface ResponseSource extends InteractionElementViewInterface {
   
   /**
    * Returns the point at which the response should anchor itself.
    */
   Point2D getAnchorPt();
   
   /**
    * Returns the rectangle outside of which the arrow should begin.
    */
   Rectangle2D getSourceBounds();
   
   /**
    * Returns the form that this object is in.
    */
   Form getForm();
}
