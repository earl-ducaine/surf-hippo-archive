package edu.berkeley.guir.damask.view;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Iterator;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.event.InteractionElementEvent;
import edu.berkeley.guir.damask.event.InteractionElementListener;
import edu.berkeley.guir.damask.view.nodes.DamaskPPath;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.util.*;

/** 
 * A view of an interaction element model object.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-19-2003 James Lin
 *                               Created InteractionElementView
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 11-19-2003
 */
public abstract class InteractionElementView extends DamaskPPath {

   private final InteractionElement model;
   private boolean selectable = true;
   private boolean movable = true;
   private boolean resizable = true;
   private boolean stretchedWhenResized = true;
   private boolean useStickyZHandles = true;
   private final InteractionElementListener elementHandler =
      new ElementHandler();
   private final PropertyChangeListener parentChildrenChangeHandler =
      new ParentChildrenChangeHandler();
   
   /**
    * Initializes this object using information from the specified model.
    */
   protected InteractionElementView(final InteractionElement model) {
      this(model, true);
   }

   /**
    * Initializes this object using information from the specified model.
    * 
    * @param model the model for which this view is created
    * @param useDefaultElementListener true if this instance should add
    * an InteractionElementListener that automatically adjusts the bounds
    * and transform of the view by listening to changes in the model
    */
   protected InteractionElementView(
      final InteractionElement model,
      final boolean useDefaultElementListener) {

      this.model = model;

      if (useDefaultElementListener && (model != null)) {
         model.addInteractionElementListener(elementHandler);
      }

      addPropertyChangeListener(
         PNode.PROPERTY_PARENT,
         new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
               if (getParent() != null) {
                  getParent().addPropertyChangeListener(
                     PNode.PROPERTY_CHILDREN, parentChildrenChangeHandler);
               }
            }
         }
      );
   }

   /**
    * Initializes this object after it has been added to a parent.
    */
   protected void initAfterAddToParent() {
      final InteractionElement model = getModel();
      if (model != null) {
         final DeviceType deviceType = getDeviceType();
         final Rectangle2D bounds = model.getBounds(deviceType);
         if (bounds != null) {
            setBounds(bounds);
            setPathTo(bounds);
         }
         setTransform(model.getTransform(deviceType));
      }
      getParent().removePropertyChangeListener(
         PNode.PROPERTY_CHILDREN, parentChildrenChangeHandler);
   }

   /**
    * Frees up any resources associated with this object.
    */
   public void dispose() {
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof InteractionElementView) {
            ((InteractionElementView)child).dispose();
         }
      }
      if (model != null) {
         model.removeInteractionElementListener(elementHandler);
      }
   }

   /**
    * Returns the layer that this node is in.
    */
   public final DamaskLayer getLayer() {
      PNode ancestor = this;
      while (ancestor != null) {
         ancestor = ancestor.getParent();
         if (ancestor instanceof DamaskLayer) {
            return (DamaskLayer)ancestor;
         }
         else if (ancestor instanceof DamaskCamera) {
            return (DamaskLayer)((DamaskCamera)ancestor).getLayer(0);
         }
      }
      return null;
   }

   /**
    * Returns the model object, of which this object is a view. 
    */
   public InteractionElement getModel() {
      return model;
   }

   /**
    * Returns, if the parent of this object is a selectable parent, whether this
    * object is selectable.
    */
   public boolean isSelectable() {
      return selectable;
   }

   /**
    * Sets, if the parent of this object is a selectable parent, whether this
    * object is selectable.
    */
   public void setSelectable(final boolean flag) {
      selectable = flag;
   }

   /**
    * Returns whether this object is resizable.
    */
   public boolean isResizable() {
      return resizable;
   }

   /**
    * Sets whether this object is resizable.
    */
   public void setResizable(final boolean flag) {
      resizable = flag;
   }

   /**
    * Returns whether this object gets stretched when it is resized (as opposed
    * to only its bounds getting resized).
    */
   public boolean isStretchedWhenResized() {
      return stretchedWhenResized;
   }

   /**
    * Sets whether this object gets stretched when it is resized (as opposed
    * to only its bounds getting resized).
    */
   public void setStretchedWhenResized(final boolean flag) {
      stretchedWhenResized = flag;
   }

   /**
    * Returns whether this object can be moved when selected.
    */
   public boolean isMovable() {
      return movable;
   }

   /**
    * Sets whether this object can be moved when selected.
    */
   public void setMovable(final boolean flag) {
      movable = flag;
   }

   /**
    * Returns whether the selection handles attached to this object should be
    * sticky-Z.
    */
   public boolean getUseStickyZHandles() {
      return useStickyZHandles;
   }

   /**
    * Sets whether the selection handles attached to this object should be
    * sticky-Z.
    */
   public void setUseStickyZHandles(final boolean flag) {
      useStickyZHandles = flag;
   }

   /**
    * Returns the device type for which this object is a view for.
    */
   public abstract DeviceType getDeviceType();


   //=========================================================================
   // The code below was copied from edu.umd.cs.piccolox.nodes.PClip.

   protected void clipPaint(PPaintContext paintContext) {
      Paint p = getPaint();
      if (p != null) {
         Graphics2D g2 = paintContext.getGraphics();
         g2.setPaint(p);
         g2.fill(getPathReference());
      }
      paintContext.pushClip(getPathReference());
   }

   protected void clipPaintAfterChildren(PPaintContext paintContext) {
      paintContext.popClip(getPathReference());
      if (getStroke() != null && getStrokePaint() != null) {
         Graphics2D g2 = paintContext.getGraphics();
         g2.setPaint(getStrokePaint());
         g2.setStroke(getStroke());
         g2.draw(getPathReference());
      }
   }

   public boolean clipFullPick(PPickPath pickPath) {
      if (getPickable() && fullIntersects(pickPath.getPickBounds())) {
         pickPath.pushNode(this);
         pickPath.pushTransform(getTransformReference(false));

         if (pick(pickPath)) {
            return true;
         }

         if (getChildrenPickable()
            && getPathReference().intersects(pickPath.getPickBounds())) {
            int count = getChildrenCount();
            for (int i = count - 1; i >= 0; i--) {
               PNode each = getChild(i);
               if (each.fullPick(pickPath))
                  return true;
            }
         }

         if (pickAfterChildren(pickPath)) {
            return true;
         }

         pickPath.popTransform(getTransformReference(false));
         pickPath.popNode(this);
      }

      return false;
   }

   // The code above was copied from edu.umd.cs.piccolox.nodes.PClip.
   //=========================================================================


   /**
    * Returns the event handler that listens to events from a model object.
    */
   public InteractionElementListener getElementHandler() {
      return elementHandler;
   }

   /**
    * Handles events from the model object. 
    */
   private class ElementHandler implements InteractionElementListener {
      public void elementBoundsUpdated(InteractionElementEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            final Rectangle2D bounds =
               e.getElement().getBounds(e.getDeviceType());
            if (bounds == null) {
               resetBounds();
            }
            else {
               setBounds(bounds);
            }
         }
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            final AffineTransform newTransform =
               e.getElement().getTransform(e.getDeviceType());
            final AffineTransform oldTransform = getTransform();
            if (!oldTransform.equals(newTransform)) {
               setTransform(newTransform);
            }
         }
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }

   /**
    * Handles changes to the parent's children list.
    */
   private class ParentChildrenChangeHandler implements PropertyChangeListener {
      // @Override
      public void propertyChange(PropertyChangeEvent evt) {
         initAfterAddToParent();
         getParent().removePropertyChangeListener(
            PNode.PROPERTY_CHILDREN, parentChildrenChangeHandler);
      }
   }
}
