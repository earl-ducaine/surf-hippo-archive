package edu.berkeley.guir.denim;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.*;

import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.WindowConstants;
import javax.swing.event.MouseInputAdapter;

import edu.berkeley.guir.denim.awtevent.UIEvent;
import edu.berkeley.guir.denim.awtevent.UIListener;

/**
 * The user interface of the entire Denim application. See the
 * <a href="http://guir.berkeley.edu/projects/denim/">Denim</a> project page
 * for details.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-11-1999 James Lin
 *                               Created Denim
 *                    08-21-1999 James Lin
 *                               Split Denim into Denim and DenimWindow
 *                    01-11-2001 James Lin
 *                               Split DenimWindow into DenimWindow and DenimUI
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 07-11-1999
 */

public class DenimWindow extends JFrame
                         implements DenimConstants {

   private DenimUI ui;
   private WindowListener winListener;
   private JDialog radarViewWindow;

   //===========================================================================
   //===   INNER CLASSES   =====================================================

   /**
    * Responds to window events.
    */
   class DenimWindowListener extends WindowAdapter {
      public void windowClosing(WindowEvent e) {
         if (ui.getSheet().getPieMenu().promptSaveBeforeExiting() == true) {
            Denim.removeWindow(DenimWindow.this);
         }
      }
   } // of class

   //-----------------------------------------------------------------

   /**
    * Responds to UI events.
    */
   class DenimWindowUIListener implements UIListener {
      
      public void projectNameChanged(UIEvent e) {
         // Set the title bar of the main window
         String titleStr = ui.getFriendlyProjectName();
         if (!System.getProperty("os.name").equals("Mac OS X")) {
            titleStr += " - Denim";
         }
         DenimWindow.this.setTitle(titleStr);
         
         // Set the title bar of the radar view window
         titleStr = ui.getFriendlyProjectName() + " [Radar View]";
         if (!System.getProperty("os.name").equals("Mac OS X")) {
            titleStr += " - Denim";
         }
         DenimWindow.this.radarViewWindow.setTitle(titleStr);
      }
      
      public void sheetPainted(UIEvent e) {
          if (e.getPercent() >= 0.5) {
              DenimWindow.this.getRadarView().damageRadar(null);
              return;
          }

          DenimWindow.this.getRadarView().damageRadar(e.getPaintedRectangle());
      } // of method
   } // of inner class

   //-----------------------------------------------------------------

   /**
    * A listener that swallows all mouse events.
    */
   class EmptyListener extends MouseInputAdapter {
   }

   //-----------------------------------------------------------------

   /**
    * A component that swallows all mouse events.
    */
   class EventSwallowerGlassPane extends JComponent {
      EventSwallowerGlassPane() {
         EmptyListener emptyListener = new EmptyListener();
         this.addMouseListener(emptyListener);
         this.addMouseMotionListener(emptyListener);
      }
   }

   //===   INNER CLASSES   =====================================================
   //===========================================================================


   //===========================================================================
   //===   DENIM WINDOW METHODS   ==============================================

   /**
    * Constructs a DenimWindow with a zoom bar and toolbox.
    */
   public DenimWindow(boolean simplified) {
   	
   	  if(simplified)
   	  {
		ui = new DenimUI(true, simplified);

		String iconFileName;
		if (System.getProperty("os.name").equals("Mac OS X")) {
		   iconFileName = "images/icons/mac/doc_48x48x24b.gif";
		}
		else {
		   iconFileName = "images/icons/windows/doc_16x16x256.gif";
		}

		// Set the icon
		Image image = Toolkit.getDefaultToolkit().
		   createImage(Denim.class.getResource(iconFileName));
		this.setIconImage(image);
   	  }
   	  else
   	  {
		ui = new DenimUI();
		setContentPane(ui);

		String iconFileName;
		if (System.getProperty("os.name").equals("Mac OS X")) {
		   iconFileName = "images/icons/mac/doc_48x48x24b.gif";
		}
		else {
		   iconFileName = "images/icons/windows/doc_16x16x256.gif";
		}

		// Set the icon
		Image image = Toolkit.getDefaultToolkit().
		   createImage(Denim.class.getResource(iconFileName));
		this.setIconImage(image);

		ui.addUIListener(new DenimWindowUIListener());

		// Do not automatically close window when "close window" button is
		// pressed
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		winListener = new DenimWindowListener();
		addWindowListener(winListener);

		// Set up the radar view
		RadarViewPanel radarView = new RadarViewPanel(ui.getSheet());
		radarView.setPreferredSize(new Dimension(RadarViewPanel.INITIAL_WIDTH,
												 RadarViewPanel.INITIAL_HEIGHT));

		radarViewWindow = new JDialog(this, "Radar View", false);
		radarViewWindow.setLocation(500, 200);
		radarViewWindow.setSize(200, 200);
		radarViewWindow.setContentPane(radarView);

		// Set up a glass pane which will intercept and swallow all events.
		// The glass pane will be visible only when the DENIM design is being
		// saved.
		setGlassPane(new EventSwallowerGlassPane());
   	  	
   	  }
   }
   
   //-----------------------------------------------------------------

   public void initAfterConstruction() {
      ui.initAfterConstruction();
      ui.setProjectName(null);
   }

   //-----------------------------------------------------------------

   /**
    * Returns the user interface of DENIM.
    */
   public DenimUI getDenimUI() {
      return ui;
   }

   //-----------------------------------------------------------------
   
   /**
    * Returns the window containing the radar view.
    */
   public JDialog getRadarViewWindow() {
      return radarViewWindow;
   }


   //-----------------------------------------------------------------
   
   /**
    * Returns the radar view.
    */
   public RadarViewPanel getRadarView() {
      return (RadarViewPanel)radarViewWindow.getContentPane();
   }
   
   //-----------------------------------------------------------------

   /**
    * Enables or disables the close button.
    */
   public void setCloseButtonEnabled(boolean flag) {
      if (flag) {
         addWindowListener(winListener);
      }
      else {
         WindowListener[] wls =
            (WindowListener[])(this.getListeners(WindowListener.class));
         for (int i = 0; i < wls.length; i++) {
            removeWindowListener(wls[i]);
         }
      }
   }

   //-----------------------------------------------------------------

   /**
    * Enables or disables the ability for the contents of this window to
    * handle events.
    */
   public void setContentsEnabled(boolean flag) {
      getGlassPane().setVisible(!flag);
   }

   //-----------------------------------------------------------------

   /**
    * Sets whether the window is busy. If it is busy, then the cursor is
    * changed to an hourglass, the close button is disabled, and the contents
    * of the window cannot respond to any events.
    */
   public void setBusy(boolean isBusy) {
      if (isBusy) {
         //// Disable the window, so the user can't muck with anything while
         //// saving.
         setCloseButtonEnabled(false);
         setContentsEnabled(false);

         //// Set the cursor to the wait cursor.
         setCursor(DenimUtils.getWaitCursor());
      }
      else {
         //// Enable the window.
         setContentsEnabled(true);
         setCloseButtonEnabled(true);

         //// Reset the cursor.
         setCursor(Cursor.getDefaultCursor());
      }
   }

   //===   DENIM WINDOW METHODS   ==============================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
