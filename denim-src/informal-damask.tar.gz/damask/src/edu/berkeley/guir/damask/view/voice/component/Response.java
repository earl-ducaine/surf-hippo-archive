package edu.berkeley.guir.damask.view.voice.component;

import java.awt.*;
import java.awt.geom.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;
import java.util.List;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.nodes.DamaskPPath;
import edu.berkeley.guir.damask.view.voice.*;
import edu.berkeley.guir.damask.view.voice.dialog.Form;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.awt.geom.Polygon2D;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.nodes.PText;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolo.util.PPaintContext;

/** 
 * Represents a response that the user says.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-18-2004 James Lin
 *                               Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 */
public class Response extends VoicePart {
   public static final String NULL_DISPLAY_STRING = "Text";
   private static final Paint TEXT_FILL_PAINT = new Color(205, 255, 191);
   private static final Paint TEXT_BORDER_PAINT = new Color(19, 142, 52);
   private static final int HOTSPOT_RADIUS = 10;
   public static final int DEFAULT_LENGTH = 225;
   public static final int MIN_RESPONSE_LENGTH_OUTSIDE_BALLOON = 40;
   public static final int SYNC_BUTTON_WIDTH = 10;
   private static final int SYNC_BUTTON_HEIGHT = 20;
   private static final Paint SYNC_ON_COLOR = TEXT_BORDER_PAINT;
   private static final Paint SYNC_OFF_COLOR = new Color(148, 220, 169);
   
   private static final int INSET = 6;
   private static final int VOICE_BALLOON_POINT_Y = 10;
   
   private ResponseSource source;
   private ResponseDest dest;
   
   private NavConnection navConnection;

   private DamaskPPath arrow = new DamaskPPath();
   private HotSpot startHotSpot =
      new HotSpot(
         new Ellipse2D.Double(0, 0, HOTSPOT_RADIUS * 2, HOTSPOT_RADIUS * 2));
   private HotSpot endHotSpot =
      new HotSpot(
         new Ellipse2D.Double(0, 0, HOTSPOT_RADIUS * 2, HOTSPOT_RADIUS * 2));

   private final ElementHandler elementHandler = new ElementHandler();
   private final ControlVoiceHandler controlVoiceHandler =
      new ControlVoiceHandler();
   private final EndpointHandler endpointHandler = new EndpointHandler();
   
   private final TextGroup textGroup = new TextGroup();
   private final PNode lineGroup = new PNode();

   private SyncButton syncButton = null;
   
   private int condition;
   
   /**
    * Creates a response with the specified input as the backing model.
    */
   public Response(final VoiceContent voiceContent,
                   final ResponseInternalDest dest) {
      super(voiceContent.getModel(), false);
      init(voiceContent, dest);
   }
   
   /**
    * Creates a response with the specified input as the backing model.
    */
   public Response(final VoiceSelectManyItem voiceSelectManyItem,
                   final ResponseInternalDest dest) {
      super(voiceSelectManyItem.getModel(), false);
      init(voiceSelectManyItem, dest);
   }
   
   /**
    * Creates a response with the specified input as the backing model.
    */
   public Response(final VoiceSelectOne voiceSelectOne,
                   final ResponseSource source,  //HACK should be VoiceContent
                   final ResponseInternalDest dest) {
      super(voiceSelectOne.getModel(), false);
      init(source, dest);
   }
   
   /**
    * Creates a response with the specified input as the backing model.
    */
   public Response(final VoiceTextInput voiceTextInput,
                   final ResponseSource source,  //HACK should be VoiceContent
                   final ResponseInternalDest dest) {
      super(voiceTextInput.getModel(), false);
      init(source, dest);
   }
   
   /**
    * Creates a response with the specified input as the backing model.
    */
   public Response(final VoiceTrigger voiceTrigger,
                   final ResponseSource source, final NavConnection connection){
      super(voiceTrigger.getModel(), false);
      this.navConnection = connection;
      init(source, null);
   }

   
   private void init(final ResponseSource source, final ResponseDest dest) {
      setPaint(null);
      setStrokePaint(null);
      ((Control)getModel()).addControlVoiceListener(controlVoiceHandler);
      
      setResizable(false);
      setSelectable(false);
      
      arrow.setPickable(false);

      startHotSpot.setPaint(DamaskAppUtils.NO_COLOR);
      startHotSpot.setStrokePaint(DamaskAppUtils.NO_COLOR);
      endHotSpot.setPaint(DamaskAppUtils.NO_COLOR);
      endHotSpot.setStrokePaint(DamaskAppUtils.NO_COLOR);
      
      addPropertyChangeListener(
         PNode.PROPERTY_PARENT,
         new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
               if (getParent() != null) {
                  setSource(source);
                  if (navConnection != null) {
                     updateDestFromConnection();
                  }
                  else {
                     setDest(dest);
                  }
               }
            }
         }
      );

      textGroup.setPaint(TEXT_FILL_PAINT);
      textGroup.setStrokePaint(TEXT_BORDER_PAINT);

      lineGroup.setPickable(false);
      addChild(lineGroup);
   }

   
   // @Override
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      final Control model = (Control)getModel();
      model.addInteractionElementListener(elementHandler);
      condition = getForm().getDesignTimeCondition();
      
      setTransform(new AffineTransform());
      
      // Add arrow
      updateArrowFromModel();
      addChild(arrow);
      arrow.setPickable(false);
      
      // Add draggable endpoints
      addChild(startHotSpot);
      addChild(endHotSpot);
      
      // Set up the response's text
      addChild(textGroup);
      updateTextString();
   }


   // Overrides method in parent class.
   public void dispose() {
      super.dispose();
      syncButton.dispose();
      
      final Control model = (Control)getModel();
      model.removeControlVoiceListener(controlVoiceHandler);
      if (model != null) {
         model.removeInteractionElementListener(elementHandler);
      }
      
      if (source != null) {
         source.removePropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
         source.removePropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         
         final Form form = source.getForm();
         if (form != null) {
            form.removePropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
            form.removePropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         }
      }
      if (dest != null) {
         dest.removePropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
         dest.removePropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         
         final Form form = dest.getForm();
         if (form != null) {
            form.removePropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
            form.removePropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         }
      }
   }
   

   /**
    * Returns the prompt which this object is a response to.
    */
   public ResponseSource getSource() {
      return source;
   }

   /**
    * Sets the prompt which this object is a response to.
    */
   public void setSource(final ResponseSource source) {
      if (this.source != null) {
         this.source.removePropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
         this.source.removePropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         
         final Form form = this.source.getForm();
         if (form != null) {
            form.removePropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
            form.removePropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         }
      }
      this.source = source;
      updateArrowFromModel();
      if (source != null) {
         source.addPropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
         source.addPropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         
         final Form form = source.getForm();
         if (form != null) {
            form.addPropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
            form.addPropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         }
      }
      setMovable((source == null) && (dest == null));
   }

   
   /**
    * Returns the prompt to be played after this response is given.
    */
   public ResponseDest getDest() {
      return dest;
   }

   /**
    * Sets the prompt to be played after this response is given.
    */
   public void setDest(final ResponseDest dest) {
      if (this.dest != null) {
         this.dest.removePropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
         this.dest.removePropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         
         final Form form = this.dest.getForm();
         if (form != null) {
            form.removePropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
            form.removePropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         }
      }
      this.dest = dest;
      updateArrowFromModel();
      if (dest != null) {
         dest.addPropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
         dest.addPropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         
         final Form form = dest.getForm();
         if (form != null) {
            form.addPropertyChangeListener(PNode.PROPERTY_BOUNDS, endpointHandler);
            form.addPropertyChangeListener(PNode.PROPERTY_TRANSFORM, endpointHandler);
         }
      }
      setMovable((source == null) && (dest == null));
   }


   /**
    * Updates the destination of this response based on the response's
    * connection.
    */
   protected void updateDestFromConnection() {
      if (navConnection == null) {
         return;
      }
      
      setDest((ResponseDest)getLayer().getView(
         navConnection.getDest(DeviceType.VOICE)));
   }
   
   
   // @Override
   protected void layoutChildren() {
      boolean hasResponseText = true;
      
      lineGroup.removeAllChildren();
      
      // Lay out text nodes vertically
      double height = 0;
      final PBounds textGroupBounds = new PBounds();
      for (Iterator i = textGroup.getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof PText) {
            final PText textNode = (PText)child;
            textNode.setOffset(0, height);
            height += textNode.getHeight();
            textGroupBounds.add(textNode.localToParent(textNode.getBounds()));
         }
      }
      
      // Center text nodes vertically
      //Rectangle2D textGroupBounds = textGroup.getFullBounds();
      for (Iterator i = textGroup.getChildrenIterator(); i.hasNext();) {
         final PNode child = (PNode)i.next();
         if (child instanceof PText) {
            final PText textNode = (PText)child;
            double width = textNode.getWidth();
            textNode.offset((textGroupBounds.getWidth() - width) / 2, 0);
         }
      }
      
      
      // Draw voice balloon around text group
      {
         PBounds newTextBounds = new PBounds();
         PText firstTextNode = null;
         for (Iterator i = textGroup.getChildrenIterator(); i.hasNext(); ) {
            final PNode child = (PNode)i.next();
            if (child instanceof PText) {
               final PText textNode = (PText)child;
               if (firstTextNode == null) {
                  firstTextNode = textNode;
               }
               newTextBounds.add(textNode.localToParent(textNode.getBounds()));
            }
         }
         newTextBounds = new PBounds(
            newTextBounds.getX() - SYNC_BUTTON_WIDTH,
            newTextBounds.getY() - INSET,
            newTextBounds.getWidth() + SYNC_BUTTON_WIDTH + INSET,
            newTextBounds.getHeight() + INSET*2);
         
         if (firstTextNode == null || firstTextNode.getText().trim().equals("")) {
            hasResponseText = false;
            textGroupBounds.setFrame(
               newTextBounds.getX(), newTextBounds.getY(), 20, 20);
            textGroup.setPathTo(DamaskAppUtils.createDiamond(textGroupBounds));
         }
         else {
            textGroup.setPathTo(
               DamaskAppUtils.createVoiceBalloon(
                  newTextBounds,
                  20, 20, 20, 15, VOICE_BALLOON_POINT_Y, 25));
         }
      }
      
      // Center text nodes on arrow
      final Rectangle2D arrowBounds = arrow.getBounds();
      if (hasResponseText) {
         textGroup.setOffset(
            (arrowBounds.getWidth() - textGroupBounds.getWidth()) / 2 +
               arrowBounds.getX(),
            (arrowBounds.getHeight() - textGroupBounds.getHeight()) / 2 +
               arrowBounds.getY());
      }
      else {
         textGroup.setOffset(
            arrowBounds.getWidth() / 2 + arrowBounds.getX(),
            arrowBounds.getHeight() / 2 + arrowBounds.getY());
      }

      // Draw lines between the text nodes
      {
         final PBounds newTextGroupBounds = textGroup.getBounds();
         textGroup.localToParent(newTextGroupBounds);
         
         final List/*<PText>*/ textNodes = new ArrayList/*<PText>*/();
         for (Iterator i = textGroup.getChildrenIterator(); i.hasNext(); ) {
            final PNode child = (PNode)i.next();
            if (child instanceof PText) {
               textNodes.add((PText)child);
            }
         }
         
         for (Iterator i = textNodes.iterator(); i.hasNext(); ) {
            final PText textNode = (PText)i.next();
            if (i.hasNext()) {
               final Rectangle2D textBounds = textNode.getBounds();
               textNode.localToGlobal(textBounds);
               lineGroup.globalToLocal(textBounds);
               final PPath line =
                  new PPath(
                     new Line2D.Double(
                        newTextGroupBounds.getX() + SYNC_BUTTON_WIDTH + 5,
                        textBounds.getMaxY(),
                        newTextGroupBounds.getMaxX() - 5,
                        textBounds.getMaxY()));
               line.setStrokePaint(TEXT_BORDER_PAINT);
               lineGroup.addChild(line);
            }
         }
         
         // Draw vertical line separating text from sync button
         if (hasResponseText) {
            final PPath verticalLine = new PPath(
               new Line2D.Double(
                  newTextGroupBounds.getX() + SYNC_BUTTON_WIDTH,
                  newTextGroupBounds.getMinY() + 5,
                  newTextGroupBounds.getX() + SYNC_BUTTON_WIDTH,
                  newTextGroupBounds.getMaxY() - VOICE_BALLOON_POINT_Y - 5));
            verticalLine.setStrokePaint(TEXT_BORDER_PAINT);
            lineGroup.addChild(verticalLine);
         }
      }
      lineGroup.moveToFront();
   }
   
   protected void updateTextString() {
      final List/*<String>*/ responseTextList =
         ((Control)getModel()).getVoiceResponseTextList();

      // Make sure the number of text nodes is the same as the number of
      // possible text responses
      for (Iterator i = textGroup.getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof PText) {
            i.remove();
         }
      }

      for (Iterator i = responseTextList.iterator(); i.hasNext(); ) {
         final String text = (String)i.next();
         final PText textNode = new PText();
         textNode.setPickable(false);
         DamaskAppUtils.setFontSize(
            textNode, DeviceType.VOICE.getDefaultFontSize());
         if (text == null) {
            textNode.setText(NULL_DISPLAY_STRING);
         }
         else {
            textNode.setText(text);
         }
         textGroup.addChild(textNode);
      }

      // Set up the button that determines whether the voice text syncs
      // with the desktop/smartphone text
      if (syncButton != null) {
         syncButton.dispose();
         syncButton.removeFromParent();
      }
      syncButton =
         new SyncButton(
            new Rectangle2D.Double(
               0,
               0,
               SYNC_BUTTON_WIDTH,
               SYNC_BUTTON_HEIGHT),
            getContentModels(),
            SYNC_ON_COLOR,
            SYNC_OFF_COLOR);
      syncButton.setOffset(-SYNC_BUTTON_WIDTH, 0);
      if (getContentSource().isForAllDeviceTypes()) {
         textGroup.addChild(syncButton);
      }
   }
   
   /**
    * Returns the control where the response text is really coming from.
    */
   protected Control getContentSource() {
      final Control control = (Control)getModel();
      Control contentSourceControl = control;
      if (control instanceof Trigger && getDeviceType() != null) {
         final PageRegion region = control.getPageRegion(getDeviceType());
         if (region != null) {
            final Control beforeControl = region.getPreviousControl(control);
            if (beforeControl instanceof SelectOne ||
                beforeControl instanceof SelectMany ||
                beforeControl instanceof TextInput) {
               contentSourceControl = beforeControl;
            }
         }
      }
      return contentSourceControl;
   }
   
   /**
    * Returns the list of contents that this response shows.
    */
   protected List/*<Content>*/ getContentModels() {
      final List/*<Content>*/ result = new ArrayList/*<Content>*/();
      
      final Control contentSourceControl = getContentSource();
      
      if (contentSourceControl instanceof Trigger) {
         result.add(((Trigger)contentSourceControl).getContent());
      }
      else if (contentSourceControl instanceof SelectOne) {
         for (Iterator i = ((SelectOne)contentSourceControl).getItems().iterator();
              i.hasNext(); ) {
            final SelectOne.Item item = (SelectOne.Item)i.next();
            result.add(item.getContent());
         }
      }
      return result;
   }
   
   
   /**
    * Updates the arrow's path depending on the views of the source and
    * destination.
    */
   private void updateArrowFromView() {
      Point2D sourcePt = null;
      Point2D destPt = null;
      
      final Polygon2D poly =
         GeomLib.pathIteratorToPolygon2D(
            getPathReference().getPathIterator(new AffineTransform()));
      
      if (poly.npoints == 0) {
         return;
      }
      
      // If the line in the model is null, then don't display an arrow
      if (((Control)getModel()).getVoiceResponseLine(condition) == null) {
         updateArrow(null);
         return;
      }
      
      final double dx = poly.xpoints[poly.npoints - 1] - poly.xpoints[0];
      final double dy = poly.ypoints[poly.npoints - 1] - poly.ypoints[0];
      
      if (source == null && dest == null) {
         sourcePt = new Point2D.Double(poly.xpoints[0], poly.ypoints[0]);
         destPt =
            new Point2D.Double(
               poly.xpoints[poly.npoints - 1], poly.ypoints[poly.npoints - 1]);
      }
      else {
         if (source != null) {
            sourcePt = source.getAnchorPt();
            source.localToGlobal(sourcePt);
            globalToLocal(sourcePt);
         }
         if (dest != null) {
            destPt = dest.getAnchorPt();
            dest.localToGlobal(destPt);
            globalToLocal(destPt);
         }
         if (source == null) {  // dest != null
            sourcePt = 
               new Point2D.Double(destPt.getX() - dx, destPt.getY() - dy);
         }
         if (dest == null) {    // source != null
            destPt =
               new Point2D.Double(sourcePt.getX() + dx, sourcePt.getY() + dy);
         }
         
         final Point2D origSourcePt = sourcePt;
         if (source instanceof VoiceControl) {
            final Prompt prompt = ((VoiceControl)source).getPrompt();
            final Rectangle2D promptBounds = prompt.getBounds();
            prompt.localToGlobal(promptBounds);
            globalToLocal(promptBounds);
            
            final double fracX;
            final double fracY;
            if (destPt.getY() > sourcePt.getY()) {
               fracX = 0.25;
               fracY = 0.75;
            }
            else {
               fracX = 0.75;
               fracY = 0.25;
            }
            sourcePt =
               new Point2D.Double(
                  promptBounds.getX() + fracX * promptBounds.getWidth(),
                  promptBounds.getY() + fracY * promptBounds.getHeight());
         }
         if (dest instanceof VoiceControl) {
            final Prompt prompt = ((VoiceControl)dest).getPrompt();
            final Rectangle2D promptBounds = prompt.getBounds();
            prompt.localToGlobal(promptBounds);
            globalToLocal(promptBounds);
            
            final double fracX;
            final double fracY;
            if (destPt.getY() > origSourcePt.getY()) {
               fracX = 0.25;
               fracY = 0.75;
            }
            else {
               fracX = 0.75;
               fracY = 0.25;
            }
            destPt =
               new Point2D.Double(
                  promptBounds.getX() + fracX * promptBounds.getWidth(),
                  promptBounds.getY() + fracY * promptBounds.getHeight());
         }
         if (source == null) {  // dest != null
            sourcePt = 
               new Point2D.Double(destPt.getX() - dx, destPt.getY() - dy);
         }
         if (dest == null) {    // source != null
            destPt =
               new Point2D.Double(sourcePt.getX() + dx, sourcePt.getY() + dy);
         }
      }
      
      updateArrow(new Line2D.Double(sourcePt, destPt));
   }
   
   
   /**
    * Updates the arrow's path depending on the models of the source and
    * destination.
    */
   private void updateArrowFromModel() {
      updateArrow(((Control)getModel()).getVoiceResponseLine(condition));
   }
   
   
   /**
    * Changes the arrow's path to the specified line. Automatically clips the
    * line so that it doesn't overlap a prompt.
    */
   public void updateArrow(final Line2D newLine) {
      if (newLine == null) {
         // hide the response -- the ViewControl will actually remove it
         setVisible(false);
      }
      else {
         setVisible(true);
         setPathTo(newLine);
         
         Point2D startPoint = newLine.getP1();
         if (source != null) {
            final Rectangle2D sourceBounds = source.getSourceBounds();
            source.localToGlobal(sourceBounds);
            globalToLocal(sourceBounds);
            
            final List/*<Point2D>*/intersectPts =
               GeomLib.calcIntersectPoints(newLine, sourceBounds);
            if (!intersectPts.isEmpty()) {
               startPoint = (Point2D) intersectPts.get(0);
            }
         }

         Point2D endPoint = newLine.getP2();
         if (dest != null) {
            final Rectangle2D destBounds = dest.getDestBounds();
            dest.localToGlobal(destBounds);
            globalToLocal(destBounds);

            final List/*<Point2D>*/intersectPts =
               GeomLib.calcIntersectPoints(newLine, destBounds);
            if (!intersectPts.isEmpty()) {
               endPoint = (Point2D) intersectPts.get(0);
            }
         }
         startHotSpot.setOffset(
            startPoint.getX() - HOTSPOT_RADIUS,
            startPoint.getY() - HOTSPOT_RADIUS);
         endHotSpot.setOffset(
            endPoint.getX() - HOTSPOT_RADIUS,
            endPoint.getY() - HOTSPOT_RADIUS);
         arrow.setPathTo(new Line2D.Double(startPoint, endPoint));
      }
   }

   // Overrides method in parent class.
   protected void paint(PPaintContext paintContext) {
      super.paint(paintContext);
      
      // If an end is not attached to anything, paint that end white. 
      final Paint startFillPaint;
      if (source == null) {
         startFillPaint = Color.WHITE;
      }
      else {
         startFillPaint = arrow.getStrokePaint();
      }
      final Paint startBorderPaint = arrow.getStrokePaint();
      
      final Paint endFillPaint;
      if (dest == null) {
         endFillPaint = Color.WHITE;
      }
      else {
         endFillPaint = arrow.getStrokePaint();
      }
      final Paint endBorderPaint = arrow.getStrokePaint();
      
      DamaskAppUtils.drawArrowheads(arrow, paintContext, startFillPaint, startBorderPaint, endFillPaint, endBorderPaint);     
   }


   /**
    * Returns the draggable hot spot at the start of the response.
    */
   public HotSpot getStartHotSpot() {
      return startHotSpot;
   }


   /**
    * Returns the draggable hot spot at the end of the response.
    */
   public HotSpot getEndHotSpot() {
      return endHotSpot;
   }


   /**
    * Updates the source of this response based on the model.
    */
   protected void updateSourceFromModel() {
      final Control control = (Control)getModel();
      final VoiceLayer layer = (VoiceLayer)getLayer();
      if (layer == null) {
         return;
      }
      
      final VoiceControl voiceControl = 
         (VoiceControl)layer.getView(control.getVoiceResponseSource());
      
      setSource((ResponseSource)voiceControl);
   }


   /**
    * Updates the destination of this response based on the model.
    */
   public void updateDestFromModel() {
      final Control control = (Control)getModel();
      final VoiceLayer layer = (VoiceLayer)getLayer();
      if (layer == null) {
         return;
      }
      
      final InteractionElementView destView = 
         layer.getView(control.getVoiceResponseDest(condition));

      setDest((ResponseDest)destView);
   }


   /**
    * Adjusts the transparency of the specified prompt, depending on
    * what its device type is and what the current device-type layer is. 
    */
   protected void deviceTypeLayerChanged() {
      final DamaskLayer layer = getLayer();
      if (layer == null) {
         return;
      }

      final Control control = (Control)getModel(); 
      final DeviceType controlDeviceType = control.getDeviceType();
      
      if (controlDeviceType == layer.getDeviceTypeForNewElement()) {
         DamaskAppUtils.setInternalColorAlpha(
            this, VoiceLayer.THIS_LAYER_ALPHA);
      }
      else {
         DamaskAppUtils.setInternalColorAlpha(
            this, VoiceLayer.OTHER_LAYER_ALPHA);
      }
      
      final Control beforeControl =
         control.getPageRegion(getDeviceType()).getPreviousControl(control);
      if (beforeControl instanceof SelectOne ||
          beforeControl instanceof SelectMany ||
          beforeControl instanceof TextInput) {
         final DeviceType beforeControlDeviceType = beforeControl.getDeviceType();

         if (beforeControlDeviceType == layer.getDeviceTypeForNewElement()) {
            DamaskAppUtils.setInternalColorAlpha(
               textGroup, VoiceLayer.THIS_LAYER_ALPHA);
         }
         else {
            DamaskAppUtils.setInternalColorAlpha(
               textGroup, VoiceLayer.OTHER_LAYER_ALPHA);
         }
      }
      
      repaint();
   }


   /**
    * Handles events from the model object. 
    */
   private class ElementHandler implements InteractionElementListener {
      public void elementBoundsUpdated(InteractionElementEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            updateArrowFromModel();
         }
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }
   
   
   /**
    * Handles events from the model object. 
    */
   private class ControlVoiceHandler implements ControlVoiceListener {

      // @Override
      public void responseSourceChanged(ControlVoiceEvent e) {
         updateSourceFromModel();
      }

      // @Override
      public void responseDestChanged(ControlVoiceEvent e) {
         if (e.getCondition() == condition) {
            updateDestFromModel();
         }
      }

      // @Override
      public void responseLineChanged(ControlVoiceEvent e) {
         if (e.getCondition() == condition) {
            updateArrowFromModel();
         }
      }

      // @Override
      public void responseTextChanged(ControlVoiceEvent e) {
         updateTextString();
      }

      // @Override
      public void promptTextChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void promptBoundsChanged(ControlVoiceEvent e) {
      }
   }
   
   
   /**
    * Listens to the objects at both ends of the response. 
    */
   private class EndpointHandler implements PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent e) {
         updateArrowFromView();
      }
   }

   /**
    * One piece of text within the response. 
    */
   public static class TextGroup extends PPath {
      /**
       * Returns the response that this hot spot belongs to.
       */
      public Response getResponse() {
         return (Response)getParent();
      }
   }

   /**
    * The start or end point of the response. 
    */
   public static class HotSpot extends PPath {
      public HotSpot() {
         super();
      }
      
      public HotSpot(Shape aShape) {
         super(aShape);
      }
      
      public HotSpot(Shape aShape, Stroke aStroke) {
         super(aShape, aStroke);
      }
      
      /**
       * Returns the response that this hot spot belongs to.
       */
      public Response getResponse() {
         return (Response)getParent();
      }
   }
}
