//// See bottom of file for software license
package edu.berkeley.guir.lib.util.comparator;

import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Combines several comparators.
 * Uses first one, if tie, uses next one, etc.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Feb 10 2003, JIH
 */
public class ChainComparator
    implements Comparator {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    List listComparators = new LinkedList();

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================





    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Empty constructor, be sure to initialize before using.
     * By default, returns equal if not initialized.
     */
    public ChainComparator() {
    } // of method

    //----------------------------------------------------------------

    public ChainComparator(Comparator cAA) {
        add(cAA);
    } // of method

    /**
     * Add these two Comparators in the order specified.
     */
    public ChainComparator(Comparator cAA, Comparator cBB) {
        add(cAA);
        add(cBB);
    } // of method

    /**
     * Add these three Comparators in the order specified.
     */
    public ChainComparator(Comparator cAA, Comparator cBB, Comparator cCC) {
        add(cAA);
        add(cBB);
        add(cCC);
    } // of method


    /**
     * Add these three Comparators in the order specified.
     */
    public ChainComparator(Comparator cAA, Comparator cBB, 
                           Comparator cCC, Comparator cDD) {
        add(cAA);
        add(cBB);
        add(cCC);
        add(cDD);
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================





    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    /**
     * Add a comparator.
     */
    public void add(Comparator c) {
        listComparators.add(c);
    } // of method

    //----------------------------------------------------------------

    /**
     * Remove a comparator.
     */
    public void remove(Comparator c) {
        listComparators.remove(c);
    } // of method

    //----------------------------------------------------------------

    /**
     * Clear out all comparators.
     */
    public void clear() {
        listComparators.clear();
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================





    //==========================================================================
    //===   COMPARATOR METHODS   ===============================================

    public int compare(Object objAA, Object objBB) {
        Iterator   it  = listComparators.iterator();
        Comparator c;
        int        val = 0;

        while (it.hasNext()) {
            c   = (Comparator) it.next();
            val = c.compare(objAA, objBB);
            if (val != 0) {
                return (val);
            }
        }

        return (val);
    } // of method

    //===   COMPARATOR METHODS   ===============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
