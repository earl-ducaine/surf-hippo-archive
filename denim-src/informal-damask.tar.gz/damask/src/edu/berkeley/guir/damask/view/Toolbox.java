package edu.berkeley.guir.damask.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.view.DamaskDocument.DamaskCanvasGroup;
import edu.berkeley.guir.damask.view.appevent.*;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.berkeley.guir.damask.view.voice.VoiceCanvas;

/** 
 * The toolbox in Damask.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-28-2003 James Lin
 *                               Created Toolbox
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-28-2003
 */
public class Toolbox extends JToolBar {
   private DamaskFrame frame;  // null if the toolbox is standalone 
                               // and free floating (i.e., on a Mac)
   private DamaskFrame currentFrame = null;
   private DamaskCanvas currentCanvas = null;
   private final ButtonGroup toolsButtonGroup = new ButtonGroup();
   
   private final CanvasListener canvasHandler = new CanvasHandler();
   private final ChangeListener canvasChangeHandler =
      new CanvasChangeHandler();

   private JToggleButton pointerButton;
   
   public static class OutputModality {
      private String name;

      public static final OutputModality VISUAL = new OutputModality("Visual");
      public static final OutputModality VOICE = new OutputModality("Voice");

      private OutputModality (String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   private OutputModality currentModality;
   private final Map/*<OutputModality, List<JToggleButton>>*/
      outputSpecificTools =
      new HashMap/*<OutputModality, List<JToggleButton>>*/(); 
   private final Map/*<OutputModality, JToggleButton>*/ currentTool =
      new HashMap/*<OutputModality, JToggleButton>*/();
   private static final int FIRST_OUTPUT_SPECIFIC_TOOL_INDEX = 3;

   /**
    * Constructs the toolbox.
    */
   public Toolbox() {
      super(SwingConstants.VERTICAL);
      setFloatable(false);
   }
   
   
   /**
    * Adds a button with the given action to the toolbox.
    */
   private JToggleButton createToolButton(final Action action) {
      final JToggleButton newButton = new JToggleButton(action);

      newButton.setText("");
      newButton.setDisabledIcon(
         (Icon)action.getValue(DamaskAppUtils.PROPERTY_DISABLED_ICON));
      newButton.setMaximumSize(
         new Dimension(Integer.MAX_VALUE, newButton.getMaximumSize().height));
      newButton.setHorizontalAlignment(SwingConstants.LEFT);
      
      return newButton;
   }
   
   
   /**
    * Adds the specified button to the toolbox.
    */
   private void addButton(final JToggleButton newButton) {
      addButton(newButton, getComponentCount());
   }
   
   
   /**
    * Adds the specified button to the toolbox at the specified index.
    */
   private void addButton(final JToggleButton newButton, final int index) {
      add(newButton, index);
      toolsButtonGroup.add(newButton);
   }

   
   /**
    * Adds the specified list of buttons to the toolbox. If the list contains
    * a null entry, then a separator will be added at that position.
    */
   private void addButtons(final List/*<JToggleButton>*/ newButtons) {
      for (Iterator i = newButtons.iterator(); i.hasNext(); ) {
         final JToggleButton newButton = (JToggleButton)i.next();
         if (newButton == null) {
            addSeparator();
         }
         else {
            addButton(newButton);
         }
      }
   }

   
   /**
    * Adds the specified list of buttons to the toolbox. If the list contains
    * a null entry, then a separator will be added at that position.
    */
   private void addButtons(final List/*<JToggleButton>*/ newButtons,
         int index) {
      for (Iterator i = newButtons.iterator(); i.hasNext(); ) {
         final JToggleButton newButton = (JToggleButton)i.next();
         if (newButton == null) {
            addSeparator(index);
         }
         else {
            addButton(newButton, index);
         }
         index++;
      }
   }

   
   /**
    * Adds a separator at the specified index.
    */
   private void addSeparator(int index) {
      final JToolBar.Separator s = new JToolBar.Separator(null);
      if (getOrientation() == VERTICAL) {
         s.setOrientation(JSeparator.HORIZONTAL);
      }
      else {
         s.setOrientation(JSeparator.VERTICAL);
      }
      add(s, index);
   }


   /**
    * Initializes the toolbox after it has been added to a frame.
    */
   public void initialize() {
      // Initialize the buttons for desktop and smartphone
      final List/*<JToggleButton>*/ visualButtons =
         new ArrayList/*<JToggleButton>*/();
      outputSpecificTools.put(OutputModality.VISUAL, visualButtons);
      
      final JToggleButton pageButton =
         createToolButton(
            new ToolAction(
               "Page/Pencil",
               getToolboxIcon("pencil.gif"),
               KeyEvent.VK_P,
               VisualCanvas.PENCIL_MODE));
      
      visualButtons.add(pageButton);

      visualButtons.add(createToolButton(
         new ToolAction(
            "Eraser",
            getToolboxIcon("eraser.gif"),
            KeyEvent.VK_E,
            VisualCanvas.ERASER_MODE)));

      visualButtons.add(createToolButton(
         new ToolAction(
            "Text",
            getToolboxIcon("text.gif"),
            KeyEvent.VK_T,
            VisualCanvas.TEXT_MODE)));

      visualButtons.add(null);

      visualButtons.add(createToolButton(
         new ToolAction(
            "Button",
            getToolboxIcon("button.gif"),
            KeyEvent.VK_B,
            VisualCanvas.BUTTON_MODE)));

      visualButtons.add(createToolButton(
         new ToolAction(
            "Check Box",
            getToolboxIcon("check_box.gif"),
            KeyEvent.VK_C,
            VisualCanvas.CHECK_BOX_MODE)));

      visualButtons.add(createToolButton(
         new ToolAction(
            "Radio Button",
            getToolboxIcon("radio_button.gif"),
            KeyEvent.VK_R,
            VisualCanvas.RADIO_BUTTON_MODE)));

      visualButtons.add(createToolButton(
         new ToolAction(
            "List Box",
            getToolboxIcon("list_box.gif"),
            KeyEvent.VK_L,
            VisualCanvas.LIST_BOX_MODE)));

      visualButtons.add(createToolButton(
         new ToolAction(
            "Drop-Down Box",
            getToolboxIcon("combo_box.gif"),
            KeyEvent.VK_O,
            VisualCanvas.COMBO_BOX_MODE)));

      visualButtons.add(createToolButton(
         new ToolAction(
            "Text Box",
            getToolboxIcon("text_box.gif"),
            KeyEvent.VK_E,
            VisualCanvas.TEXT_BOX_MODE)));

      visualButtons.add(createToolButton(
         new ToolAction(
            "Panel",
            getToolboxIcon("panel.gif"),
            KeyEvent.VK_N,
            VisualCanvas.PANEL_MODE)));

      visualButtons.add(null);

      visualButtons.add(createToolButton(
         new ToolAction(
            "Split",
            getToolboxIcon("split.gif"),
            KeyEvent.VK_S,
            VisualCanvas.SPLIT_MODE)));

      visualButtons.add(createToolButton(
         new ToolAction(
            "Merge",
            getToolboxIcon("merge.gif"),
            KeyEvent.VK_S,
            VisualCanvas.MERGE_MODE)));

      visualButtons.add(null);

      visualButtons.add(createToolButton(
         new ToolAction(
            "Change Control State",
            getToolboxIcon("change_state.gif"),
            KeyEvent.VK_S,
            VisualCanvas.CHANGE_CONTROL_STATE_MODE)));

      // Initialize the buttons for voice
      final List/*<JToggleButton>*/ voiceButtons =
         new ArrayList/*<JToggleButton>*/();
      outputSpecificTools.put(OutputModality.VOICE, voiceButtons);

      final JToggleButton voiceDrawButton =
         createToolButton(
            new ToolAction(
               "Draw",
               getToolboxIcon("pencil.gif"),
               KeyEvent.VK_P,
               VoiceCanvas.DRAW_MODE));
      
      voiceButtons.add(voiceDrawButton);

      voiceButtons.add(createToolButton(
         new ToolAction(
            "Eraser",
            getToolboxIcon("eraser.gif"),
            KeyEvent.VK_E,
            VoiceCanvas.ERASER_MODE)));

      
      // Add the buttons
      addSeparator();
      
      pointerButton =
         createToolButton(
            new ToolAction(
               "Select/Move",
               getToolboxIcon("pointer.gif"),
               KeyEvent.VK_V,
               DamaskCanvas.SELECTION_MODE));
      
      addButton(pointerButton);
            
      addButton(
         createToolButton(
            new ToolAction(
               "Pan",
               getToolboxIcon("hand.gif"),
               KeyEvent.VK_A,
               DamaskCanvas.HAND_MODE)));
      
      addSeparator();

      currentModality = OutputModality.VISUAL;
      addButtons(visualButtons);
      
      // In the Mac version, there is one standalone floating toolbox that 
      // affects all frames (in which case the root of the toolbox is not a
      // DamaskFrame). In the Windows version, there is a toolbox toolbar
      // attach to each frame (in which case the root is a DamaskFrame).
      final Component root = SwingUtilities.getRoot(this);
      if (root instanceof DamaskFrame) {
         frame = (DamaskFrame)root;
         setCurrentFrame(frame);
      }
      else {
         frame = null;
         DamaskApp.addAppListener(new AppHandler());
      }

      // Make the page tool selected by default.
      currentTool.put(OutputModality.VISUAL, pageButton);
      currentTool.put(OutputModality.VOICE, voiceDrawButton);
      
      pageButton.doClick();
   }
   
   
   /**
    * Returns the image icon with the given file name.
    */
   protected ImageIcon getToolboxIcon(final String fileName) {
      final Image image = Toolkit.getDefaultToolkit().createImage(
         DamaskApp.class.getResource("images/toolbox/" + fileName));
      return new ImageIcon(image);
   }
   
   
   /**
    * Returns a collection of canvases that this toolbox affects. 
    */
   private Collection getCanvases() {
      final Set canvases;
      
      // If this toolbox is standalone, then it affects all canvases
      if (frame == null) {
         canvases = new HashSet();
         
         // For each document...
         final List docs = DamaskApp.getDocuments();
         for (Iterator i = docs.iterator(); i.hasNext(); ) {
            
            final DamaskDocument doc = (DamaskDocument)i.next();
            
            // For each canvas group...
            for (Iterator j = doc.getCanvasGroups().iterator(); j.hasNext(); ) {
               final DamaskCanvasGroup group = (DamaskCanvasGroup)j.next();
               
               // For each canvas...
               for (Iterator k = group.getCanvases().iterator(); k.hasNext();) {
                  final DamaskCanvas canvas = (DamaskCanvas)k.next();
                  canvases.add(canvas);
               }
            }
         }
      }
      // Otherwise, it only affects canvases within the toolbox's frame
      else {
         final DamaskCanvasGroup group = frame.getCanvasGroup();
         canvases = new HashSet(group.getCanvases());
      }
      return canvases;
   }


   /**
    * Returns the currently active frame.
    */
   private DamaskFrame getCurrentFrame() {
      return currentFrame;
   }


   /**
    * Sets the currently active frame.
    */
   private void setCurrentFrame(DamaskFrame currentFrame) {
      if (currentFrame != null) {
         currentFrame.removeCanvasChangeListener(canvasChangeHandler);
      }
      this.currentFrame = currentFrame;
      if (currentFrame != null) {
         setCurrentCanvas(currentFrame.getCurrentCanvas());
         currentFrame.addCanvasChangeListener(canvasChangeHandler);
      }
   }


   /**
    * Sets the currently active canvas.
    */
   private void setCurrentCanvas(final DamaskCanvas canvas) {
      if (currentCanvas != null) {
         currentCanvas.removeCanvasListener(canvasHandler);
      }
      currentCanvas = canvas;
      if (currentCanvas != null) {
         currentCanvas.addCanvasListener(canvasHandler);
         updateDeviceTypeSpecificTools();
      }
   }
   
   
   /**
    * Adds or removes tools depending on the current canvas' output modality.
    */
   private void updateDeviceTypeSpecificTools() {
      if (currentModality == OutputModality.VISUAL
            && currentCanvas.getDeviceType().isVisual()) {
         return;
      }
      if (currentModality == OutputModality.VOICE
            && currentCanvas.getDeviceType() == DeviceType.VOICE) {
         return;
      }

      // Get the currently selected button and save it
      for (int i = 0, n = getComponentCount(); i < n; i++) {
         final Component toolBarComponent = getComponentAtIndex(i);
         if (toolBarComponent instanceof JToggleButton) {
            final JToggleButton tool = (JToggleButton)toolBarComponent;
            if (toolsButtonGroup.isSelected(tool.getModel())) {
               currentTool.put(currentModality, tool);
               break;
            }
         }
      }
      
      // Remove the old output-specific tools.
      while (FIRST_OUTPUT_SPECIFIC_TOOL_INDEX < getComponentCount()) {
         remove(FIRST_OUTPUT_SPECIFIC_TOOL_INDEX);
      }

      if (currentCanvas.getDeviceType().isVisual()) {
         currentModality = OutputModality.VISUAL;
      }
      else {
         currentModality = OutputModality.VOICE;
      }
      
      // Add the new output-specific tools.
      final List/*<JToggleButton>*/ newButtons =
         (List)outputSpecificTools.get(currentModality);
      if (!newButtons.isEmpty()) {
         addSeparator(FIRST_OUTPUT_SPECIFIC_TOOL_INDEX);
         addButtons(newButtons, FIRST_OUTPUT_SPECIFIC_TOOL_INDEX + 1);
      }
      repaint();
      
      ((JToggleButton)currentTool.get(currentModality)).doClick();
   }


   /**
    * An action that affects how a Damask canvas behaves with a given tool. 
    */
   private class ToolAction extends AbstractAction {
      private String eventModeName;
      
      public ToolAction(
         String text,
         ImageIcon icon,
         int mnemonic,
         String appModeName) {

         super(text, icon);
         putValue(Action.SHORT_DESCRIPTION, text);
         putValue(Action.MNEMONIC_KEY, new Integer(mnemonic));
         this.eventModeName = appModeName;
      }

      public void actionPerformed(ActionEvent e) {
         for (Iterator i = getCanvases().iterator(); i.hasNext(); ) {
            final DamaskCanvas canvas = (DamaskCanvas)i.next();
            canvas.setModeByName(eventModeName);
         }
      }
   }


   /**
    * Listens to global app events. 
    */
   private class AppHandler implements AppListener {
      public void currentFrameChanged(AppEvent e) {
         setCurrentFrame(DamaskApp.getCurrentFrame());
      }
   }
   
   /**
    * Listens to canvas change events. 
    */
   private class CanvasChangeHandler implements ChangeListener {
      public void stateChanged(ChangeEvent e) {
         setCurrentCanvas(getCurrentFrame().getCurrentCanvas());
      }
   }


   /**
    * Handles canvas events.  
    */
   private class CanvasHandler implements CanvasListener {
      public void selectionChanged(CanvasEvent e) {
         assert e.getCanvas()
            == currentCanvas : "should be receiving events from "
               + currentCanvas
               + ", not "
               + e.getCanvas();
      }

      public void selectedPageChanged(CanvasEvent e) {
      }
   }   
}
