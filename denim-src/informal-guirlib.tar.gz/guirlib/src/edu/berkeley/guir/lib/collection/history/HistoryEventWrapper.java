//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.history;

import java.util.Date;

/**
 * A wrapper around a single event. This is meant for subclassing.
 * The idea here is that the base class that will always be used in APIs
 * is the HistoryEvent, and that extra functionality would be added via
 * wrappers. This approach solves the problem of returning instances higher up
 * in the class hierarchy.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Mar 07 2003, JH
 */
public class HistoryEventWrapper 
    extends HistoryEvent {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    HistoryEvent wrappedEvent;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Basic initializations.
     */
    public HistoryEventWrapper(HistoryEvent newWrappedEvent) {
        wrappedEvent = newWrappedEvent;
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   WRAPPED EVENT   ====================================================

    public void setWrappedEvent(HistoryEvent newWrappedEvent) {
        wrappedEvent = newWrappedEvent;
    } // of method

    //----------------------------------------------------------------

    public HistoryEvent getWrappedEvent() {
        return (wrappedEvent);
    } // of method

    //===   WRAPPED EVENT   ====================================================
    //==========================================================================




    //==========================================================================
    //===   ACCESSOR / MODIFIER METHODS   ======================================

    public void setValue(String strKey, String strVal) {
        wrappedEvent.setValue(strKey, strVal);
    } // of method

    public String getValue(String strKey) {
        return (wrappedEvent.getValue(strKey));
    } // of method

    //----------------------------------------------------------------

    /**
     * Set the date and time of this event.
     * For example, "Wed Nov 06 17:07:17 PST 2003".
     * This date format can be generated via {@link java.util.Date}.
     */
    public void setDate(String str) {
        wrappedEvent.setDate(str);
    } // of method


    public void setDate(Date d) {
        wrappedEvent.setDate(d);
    } // of method


    public String getDate() {
        return (wrappedEvent.getDate());
    } // of method


    /**
     * Update to the current time.
     */
    public void touchDate() {
        wrappedEvent.touchDate();
    } // of method

    //===   ACCESSOR / MODIFIER METHODS   ======================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        return (wrappedEvent.toString());
    } // of method

    //----------------------------------------------------------------

    public String toString(boolean flagPrintKeys) {
        return (wrappedEvent.toString(flagPrintKeys, getKeyOrdering()));
    } // of method

    //----------------------------------------------------------------

    public String toString(boolean flagPrintKeys, String[] keyOrdering) {
        return (wrappedEvent.toString(flagPrintKeys, keyOrdering));
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   HASHCODE   =========================================================

    public int hashCode() {
        return (mapHistory.hashCode());
    } // of method

    //===   HASHCODE   =========================================================
    //==========================================================================
} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
