package edu.berkeley.guir.damask.view.visual;

import java.awt.Component;
import java.awt.Point;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.geom.Rectangle2D;
import java.util.*;

import javax.swing.*;

import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.component.TextInput;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.appevent.RunCanvasEventSource;
import edu.berkeley.guir.damask.view.appevent.RunCanvasListener;
import edu.berkeley.guir.damask.view.visual.component.*;
import edu.berkeley.guir.damask.view.visual.dialog.*;
import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolo.PNode;

/** 
 * The contents of the Run window.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  12-31-2003 James Lin
 *                               Created DamaskRunCanvas
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-28-2003
 */
public class DamaskRunCanvas extends PCanvas implements PageViewContainer {

   private Page currentPage = null;
   private PageView currentPageView = null;

   private final Stack backStack = new Stack();
   private final Stack forwardStack = new Stack();

   private ControlView focus = null;
   
   private RunCanvasEventSource eventSource = new RunCanvasEventSource();
   
   private final Map/*<JTextField, TextInput>*/ textFieldToTextInput =
      new HashMap();
      
   private final Map/*<TextInput, String>*/ textInputToText = new HashMap();
   
   private JScrollBar horizontalScrollBar = null;
   private JScrollBar verticalScrollBar = null;
   private AdjustmentListener horizontalScrollBarHandler =
      new HorizontalScrollBarHandler();
   private AdjustmentListener verticalScrollBarHandler =
      new VerticalScrollBarHandler();
   private int horizontalValue = 0;
   private int verticalValue = 0;
   
   /**
    * Constructs a Run canvas. 
    */
   public DamaskRunCanvas() {
      setLayout(null);
       
      // Remove Piccolo's default panning
      removeInputEventListener(getPanEventHandler());
   }
   

   /**
    * Adds the specified listener to receive DamaskRunCanvas events.
    */
   public synchronized void addRunCanvasListener(final RunCanvasListener listener) {
      eventSource.addRunCanvasListener(listener);
   }


   /**
    * Removes the specified listener so that it no longer receives
    * DamaskRunCanvas events.
    */
   public synchronized void removeRunCanvasListener(final RunCanvasListener listener) {
      eventSource.removeRunCanvasListener(listener);
   }


   /**
    * Fires a loadCompleted event.
    */
   protected void fireLoadCompleted() {
      eventSource.fireLoadCompleted(this);
   }


   /**
    * Returns the control view that has the focus in this window.
    */
   public ControlView getFocus() {
      return focus;
   }

   
   /**
    * Sets the focus to the specified control view.
    */
   public void setFocus(final ControlView controlView) {
      focus = controlView;
   }


   /**
    * Displays a view of the specified page in the Run window, as the result
    * of clicking on a hyperlink.
    */
   public void goToPage(final Page page) {
      if (currentPage != null) {
         backStack.push(currentPage);
      }
      forwardStack.clear();
      currentPage = page;

      displayCurrentPage();
   }
   
   
   /**
    * Displays the page that would appear when the user presses the Back
    * button.
    */
   public void goBack() {
      forwardStack.push(currentPage);
      currentPage = (Page)backStack.pop();

      displayCurrentPage();
   }
   

   /**
    * Returns whether Back navigation is possible.
    */
   public boolean canGoBack() {
      return !backStack.isEmpty();
   }

   
   /**
    * Displays the page that would appear when the user presses the Forward
    * button.
    */
   public void goForward() {
      backStack.push(currentPage);
      currentPage = (Page)forwardStack.pop();

      displayCurrentPage();
   }
   
   
   /**
    * Returns whether Forward navigation is possible.
    */
   public boolean canGoForward() {
      return !forwardStack.isEmpty();
   }


   /**
    * Returns the view of the current page in this canvas.
    */
   public PageView getCurrentPageView() {
      return currentPageView;
   }
   
   
   /**
    * Sets the scroll pane that this canvas lives in. This allows the text
    * boxes to scroll properly with the scroll pane.
    */
   public void setContainingScrollPane(final JScrollPane scrollPane) {
      if (horizontalScrollBar != null) {
         horizontalScrollBar.removeAdjustmentListener(horizontalScrollBarHandler);
      }
      if (verticalScrollBar != null) {
         verticalScrollBar.removeAdjustmentListener(verticalScrollBarHandler);
      }
      
      horizontalScrollBar = scrollPane.getHorizontalScrollBar();
      verticalScrollBar = scrollPane.getVerticalScrollBar();
      
      horizontalScrollBar.addAdjustmentListener(horizontalScrollBarHandler);
      verticalScrollBar.addAdjustmentListener(verticalScrollBarHandler);
   }

   
   /**
    * Displays a view of the current page in the Run canvas.
    */
   protected void displayCurrentPage() {
      // Clear the Run window's canvas.
      getLayer().removeAllChildren();
      
      // Store the contents of each JTextField, and remove any JTextFields
      // in this canvas.
      for (int i = getComponentCount() - 1; i >= 0; i--) {
         final java.awt.Component component = getComponent(i);
         if (component instanceof JTextField) {
            final JTextField textField = (JTextField)component;
            final TextInput textInput =
               (TextInput)textFieldToTextInput.get(textField);
            textInputToText.put(textInput, textField.getText());
            textFieldToTextInput.remove(textField);
            remove(i);
         }
      }

      // Create a view of the page. Set it in Run mode so that it properly
      // receives and processes user events.
      currentPageView = new PageView(currentPage, false);
      currentPageView.setInRunMode(true);
      currentPageView.setListenToTransformChanges(false);

      // Add the page view to the canvas.
      getLayer().removeAllChildren();      
      getLayer().addChild(currentPageView);
      
      // Force the page view to layout its children, so we get the
      // correct height of the title bar.
      currentPageView.getFullBounds();

      // Show page title.
      final Rectangle2D titleBarFullBounds =
         currentPageView.getTitleBar().getPathReference().getBounds2D();

      currentPageView.getTitleBar().localToGlobal(titleBarFullBounds);
      currentPageView.getParent().globalToLocal(titleBarFullBounds);
      
      currentPageView.setOffset(0, titleBarFullBounds.getHeight());
      
      // Get rid of internal borders.
      currentPageView.getTitleBar().setStrokePaint(null);
      currentPageView.getContents().setStrokePaint(null);
      for (Iterator i = currentPageView.getContents().getChildrenIterator();
         i.hasNext(); ) {
         final PageRegionView pageRegionView = (PageRegionView)i.next();
         pageRegionView.setStrokePaint(null);
         
         for (Iterator j = pageRegionView.getChildrenIterator(); j.hasNext();) {
            final PNode child = (PNode)j.next();
            if (child instanceof TextBox) {
               // Replace each text box with a JTextField.
               final TextBox textBox = (TextBox)child;
               final JTextField textField = new JTextField();
               final Rectangle2D textBoxGlobalBds = textBox.getBounds();
               child.localToGlobal(textBoxGlobalBds);
               textField.setLocation(
                  (int)textBoxGlobalBds.getX() - horizontalValue,
                  (int)textBoxGlobalBds.getY() - verticalValue);
               textField.setSize(
                  (int)textBoxGlobalBds.getWidth(),
                  (int)textBoxGlobalBds.getHeight());
                  
               // If the user has previously entered text for this text box
               // during this Run session, then use that text. Otherwise, get
               // the text from the text box's model.
               final TextInput textInput = (TextInput)textBox.getModel();
               String textBoxString = (String)textInputToText.get(textInput);
               if (textBoxString == null) {
                  final Dialog controlDialog = textInput.getDialog();
                  textBoxString =
                     (String)textInput.getStateForCondition(
                        controlDialog, controlDialog.getInitialCondition());
               }
               textField.setText(textBoxString);
               textFieldToTextInput.put(textField, textInput);
               
               add(textField);
            }
         }
      }
      
      // Fire a loadCompleted event.
      fireLoadCompleted();
   }


   // Overrides method in PageViewContainer.
   public void setControlState(final Control control, final Object state) {
      ((ControlView)DamaskAppUtils.getView(getLayer(), control)).setState(
         state);
   }


   // Overrides method in PageViewContainer.
   public int getSelectedPageCondition() {
      final Map/*<Control, int>*/ controlStates = new HashMap();
      
      // Get the states of the controls.
      for (Iterator i =
         ((PageViewContents)currentPageView.getContents()).getRegionViews().iterator();
         i.hasNext(); ) {

         final PageRegionView regionView = (PageRegionView)i.next();

         for (Iterator j = regionView.getChildrenIterator(); j.hasNext(); ) {
            final ComponentView componentView = (ComponentView)j.next();
            if (componentView instanceof ControlView) {
               final ControlView controlView = (ControlView)componentView;
               controlStates.put(
                  controlView.getModel(), controlView.getState());
            }
         }
      }
      
      return currentPage.getDialog().getCondition(controlStates);
   }
   
   
   /**
    * Handles events from any horizontal scroll bar that surrounds this canvas. 
    */
   private class HorizontalScrollBarHandler implements AdjustmentListener {
      // @Override
      public void adjustmentValueChanged(AdjustmentEvent e) {
         int dx = e.getValue() - horizontalValue;
         for (int i = 0, n = getComponentCount(); i < n; i++) {
            final Component component = getComponent(i);
            final Point oldLocation = component.getLocation();
            component.setLocation(oldLocation.x - dx, oldLocation.y);
         }
         horizontalValue = e.getValue();
      }
   }
   
   
   /**
    * Handles events from any vertical scroll bar that surrounds this canvas. 
    */
   private class VerticalScrollBarHandler implements AdjustmentListener {
      // @Override
      public void adjustmentValueChanged(AdjustmentEvent e) {
         int dy = e.getValue() - verticalValue;
         for (int i = 0, n = getComponentCount(); i < n; i++) {
            final Component component = getComponent(i);
            final Point oldLocation = component.getLocation();
            component.setLocation(oldLocation.x, oldLocation.y - dy);
         }
         verticalValue = e.getValue();
      }
   }
}
