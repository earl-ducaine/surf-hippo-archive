//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.util.*;
import java.io.*;
import java.awt.*;
import java.util.*;

/**
 * The interface for styles, for Screen Data Objects. Styles dictate how
 * GraphicalObjects are drawn.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Oct 06 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class Style
   implements SatinConstants,
              Serializable, 
              Cloneable {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 8995939835246826178L;

   //===========================================================================

   //// Fill-Style
   public static final byte TRANSPARENT = 0;

   //// Draw Function
   /** Clear out what is underneath */
   public static final byte DRAW_CLEAR        = 0;
   public static final byte DRAW_SET          = 1;
   public static final byte DRAW_COPY         = 2;
   public static final byte DRAW_NOOP         = 3;
   public static final byte DRAW_COPYINVERTED = 4;
   public static final byte DRAW_INVERT       = 5;
   public static final byte DRAW_OR           = 6;
   public static final byte DRAW_AND          = 7;
   public static final byte DRAW_XOR          = 8;
   public static final byte DRAW_EQUIV        = 9;
   public static final byte DRAW_NAND         = 10;
   public static final byte DRAW_NOR          = 11;
   public static final byte DRAW_ANDINVERTED  = 12;
   public static final byte DRAW_ANDREVERSE   = 13;
   public static final byte DRAW_ORINVERTED   = 14;
   public static final byte DRAW_ORREVERSE    = 15;

   //===========================================================================

   //// Line-Styles

   /** @see java.awt.BasicStroke#CAP_BUTT   */
   public static final int CAP_BUTT     = BasicStroke.CAP_BUTT;

   /** @see java.awt.BasicStroke#CAP_ROUND  */
   public static final int CAP_ROUND    = BasicStroke.CAP_ROUND;

   /** @see java.awt.BasicStroke#CAP_SQUARE */
   public static final int CAP_SQUARE   = BasicStroke.CAP_SQUARE;

   /** @see java.awt.BasicStroke#JOIN_BEVEL */
   public static final int JOIN_BEVEL   = BasicStroke.JOIN_BEVEL;

   /** @see java.awt.BasicStroke#JOIN_MITER */
   public static final int JOIN_MITER   = BasicStroke.JOIN_MITER;

   /** @see java.awt.BasicStroke#JOIN_ROUND */
   public static final int JOIN_ROUND   = BasicStroke.JOIN_ROUND;

   //===========================================================================

   private static final Font DEFAULT_FONT = 
         new Font("SansSerif", Font.PLAIN, 12);

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS METHODS AND VARIABLES   =======================================

   static private Class baseClass = null;
   
   static {
      //// 1. Global inits.
      glprops.setProperty(SATIN_DATA_DIRECTORY_GPROPERTY,
                          SATIN_DATA_DIRECTORY_DEFAULT);
   } // of static init

   //===   CLASS METHODS AND VARIABLES   =======================================
   //===========================================================================



   //===========================================================================
   //===   INNER CLASSES   =====================================================

   final class SatinStroke
      extends    BasicStroke
      implements Serializable {

      public SatinStroke() {
         super();
      } // of default constructor

      public SatinStroke(float width) {
         super(width);
      } // of constructor

      public SatinStroke(float width, int cap, int join) {
         super(width, cap, join);
      } // of constructor

      public SatinStroke(float width, int cap, int join, float miterlimit) {
         super(width, cap, join, miterlimit);
      } // of constructor

      public SatinStroke(float width, int cap, int join, float miterlimit, 
         float[] dash, float dash_phase) {

         super(width, cap, join, miterlimit, dash, dash_phase);
      } // of constructor

      public SatinStroke(BasicStroke stk) {
         super(stk.getLineWidth(),  stk.getEndCap(),    stk.getLineJoin(), 
               stk.getMiterLimit(), stk.getDashArray(), stk.getDashPhase());
      } // of constructor

      public Shape createStrokedShape(Shape s) {
         return (super.createStrokedShape(s));
      } // of createStrokeShape

      public boolean equals(Object obj) {
         return (super.equals(obj));
      } // of equals

      public float[] getDashArray() {
         return (super.getDashArray());
      } // of getDashArray

      public float getDashPhase() {
         return (super.getDashPhase());
      } // of getDashPhase

      public int getEndCap() {
         return (super.getEndCap());
      } // of getEndCap

      public int getLineJoin() {
         return (super.getLineJoin());
      } // of getLineJoin

      public float getLineWidth() {
         return (super.getLineWidth());
      } // of getLineWidth

      public float getMiterLimit() {
         return (super.getMiterLimit());
      } // of getMiterLimit

      public int hashCode() {
         return (super.hashCode());
      } // of hashCode

   } // of inner class SatinStroke

   //===   INNER CLASSES   =====================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private Color       fillColor   = Color.gray;
   private Color       drawColor   = Color.black;
   private Color       fontColor   = Color.black;
   private Font        drawFont    = DEFAULT_FONT;
   private SatinStroke drawStroke  = new SatinStroke();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTOR   =======================================================

   /**
    * Create a Style with default parameters.
    */
   public Style() {
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a clone of the specified Style.
    *
    * @param s is the Style to copy.
    */
   public Style(Style s) {
      setDrawStroke(s.getDrawStroke());
      setDrawColor(s.getDrawColor());
      setFillColor(s.getFillColor());
      setFontColor(s.getFontColor());
      setDrawFont(s.getDrawFont());
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * @param strFileName is the name of the style properties file in
    *                    Satin's data directory to load up.
    */
   public Style(String strFileName) {
      this(strFileName, new Style());
   } // of constructor

   //-----------------------------------------------------------------

   /**
    *
    * @param strFileName is the name of the style properties file in
    *                    Satin's data directory to load up.
    * @param defaults    is the default Style to use if some of the
    *                    style properties do not exist.
    */
   public Style(String strFileName, Style defaults) {
      this(defaults);

      try {
         Debug.println("Loading style properties file " + 
                         glprops.getProperty(SATIN_DATA_DIRECTORY_GPROPERTY) + 
                         strFileName);

         InputStream istream = null;
         if (baseClass != null) {
            istream =
               baseClass.getResourceAsStream(
                  glprops.getProperty(SATIN_DATA_DIRECTORY_GPROPERTY) +
                  strFileName);
         }
         if (istream == null) {
            istream =
               new FileInputStream(
                  (String) glprops.getProperty(SATIN_DATA_DIRECTORY_GPROPERTY) +
                  strFileName);
         }
         Properties props = readProperties(istream);
         setProperties(props);
      }
      catch (FileNotFoundException e) {
         Debug.println("Error finding file - using defaults instead");
      }
   } // of constructor

   //-----------------------------------------------------------------

   public Style(Properties props) {
      setProperties(props);
   } // of constructor

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================



   //===========================================================================
   //===   INNER CLASSES FOR PROPERTIES INITIALIZATION   =======================

   /**
    * Implements the Strategy pattern for handling floating point values.
    */
   abstract class ParseFloat {
      abstract public void setStyleValue(float val);
      abstract public String getName();
   } // of inner class

   //-----------------------------------------------------------------

   class HandleDashPhase extends ParseFloat {
      public final void setStyleValue(float val) {
         setDashPhase(val);
      } // of setStyleValue

      public final String getName() {
         return ("Miter Limit");
      } // of getName
   } // of inner class HandleDashPhase 

   //-----------------------------------------------------------------

   class HandleMiterLimit extends ParseFloat {
      public final void setStyleValue(float val) {
         setMiterLimit(val);
      } // of setStyleValue

      public final String getName() {
         return ("Miter Limit");
      } // of getName
   } // of inner class HandleMiterLimit 

   //-----------------------------------------------------------------

   class HandleLineWidth extends ParseFloat {
      public final void setStyleValue(float val) {
         setLineWidth(val);
      } // of setStyleValue

      public final String getName() {
         return ("Line Width");
      } // of getName
   } // of inner class HandleLineWidth 

   //-----------------------------------------------------------------

   class HandleDrawTransparency extends ParseFloat {
      public final void setStyleValue(float val) {
         setDrawTransparency(val);
      } // of setStyleValue
      
      public final String getName() {
         return ("Draw Transparency");
      } // of getName
   } // of inner class HandleDrawTransparency

   //-----------------------------------------------------------------

   class HandleFillTransparency extends ParseFloat {
      public final void setStyleValue(float val) {
         setFillTransparency(val);
      } // of setStyleValue
      
      public final String getName() {
         return ("Fill Transparency");
      } // of getName
   } // of inner class HandleFillTransparency

   //===   INNER CLASSES FOR PROPERTIES INITIALIZATION   =======================
   //===========================================================================



   //===========================================================================
   //===   PROPERTIES INITIALIZATION   =========================================

   private Properties readProperties(InputStream istream) {
      Properties props = new Properties();
      try {
         props.load(istream);
      }
      catch (IOException e) {
         Debug.println("Error reading file - using defaults");
         Debug.println(e);
      }
      return (props);
   } // of readProperties

   //-----------------------------------------------------------------

   /**
    * Parse the properties into values for Style.
    */
   private void setProperties(Properties props) {
      handleLineWidth(props.getProperty(KEY_STYLE_LINEWIDTH));
      handleDrawFont(props.getProperty(KEY_STYLE_DRAWFONT));
      handleDrawColor(props.getProperty(KEY_STYLE_DRAWCOLOR));
      handleDrawTransparency(props.getProperty(KEY_STYLE_DRAWTRANSPARENCY));
      handleFillColor(props.getProperty(KEY_STYLE_FILLCOLOR));
      handleFillTransparency(props.getProperty(KEY_STYLE_FILLTRANSPARENCY));

      handleEndCap(props.getProperty(KEY_STYLE_ENDCAP));
      handleLineJoin(props.getProperty(KEY_STYLE_LINEJOIN));
      handleMiterLimit(props.getProperty(KEY_STYLE_MITERLIMIT));

      handleDashPhase(props.getProperty(KEY_STYLE_DASHPHASE));
      handleDashArray(props.getProperty(KEY_STYLE_DASHARRAY));
   } // of setProperties

   //-----------------------------------------------------------------

   /**
    * Either one of the basic java.awt.Colors, or a 4-tuple specifying rgba.
    */
   private void handleDrawColor(String str) {
      //// 1. Ignore if there is no value.
      if (str == null || str.equals("")) {
         return;
      }

      //// 2. Otherwise parse and set the value.
      try {
         Color newColor = ParserLib.parseColor(str);
         setDrawColor(newColor);
      }
      catch (Exception e) {
         Debug.println("Error parsing draw color - using default value");
      }
   } // of handleDrawColor

   //-----------------------------------------------------------------

   private void handleFillColor(String str) {
      //// 1. Ignore if there is no value.
      if (str == null || str.equals("")) {
         return;
      }

      //// 2. Otherwise parse and set the value.
      try {
         Color newColor = ParserLib.parseColor(str);
         setFillColor(newColor);
      }
      catch (Exception e) {
         Debug.println("Error parsing fill color - using default value");
      }
   } // of method

   //-----------------------------------------------------------------

   private void handleDrawFont(String str) {
      //// 1. Ignore if there is no value.
      if (str == null || str.equals("")) {
         return;
      }

      //// 2. Otherwise parse and set the value.
      Font font = Font.decode(str);
      if (font == null) {
         Debug.println("Error parsing draw font - using default value");
      }
      else {
         setDrawFont(font);
      }
   } // of method

   //-----------------------------------------------------------------

   private void handleFillTransparency(String str) {
      handleFloat(new HandleFillTransparency(), str);
   } // of method

   //-----------------------------------------------------------------

   private void handleDrawTransparency(String str) {
      handleFloat(new HandleDrawTransparency(), str);
   } // of method

   //-----------------------------------------------------------------

   private void handleMiterLimit(String str) {
      handleFloat(new HandleMiterLimit(), str);
   } // of method

   //-----------------------------------------------------------------

   private void handleLineWidth(String str) {
      handleFloat(new HandleLineWidth(), str);
   } // of method

   //-----------------------------------------------------------------

   private void handleDashPhase(String str) {
      handleFloat(new HandleDashPhase(), str);
   } // of method

   //-----------------------------------------------------------------

   private void handleDashArray(String str) {
      //// 1. Ignore if there is no value.
      if (str == null || str.equals("")) {
         return;
      }

      //// 2. Otherwise parse and set the value.
      try {
         float[] fArray = ParserLib.parseFloatArray(str);
         setDashArray(fArray);
      }
      catch (Exception e) {
         Debug.println("Error parsing dash array - using default value");
      }
   } // of method

   //-----------------------------------------------------------------

   private void handleEndCap(String str) {
      //// 1. Ignore if there is no value.
      if (str == null || str.equals("")) {
         return;
      }

      //// 2. Otherwise parse and set the value.
      if (str.equalsIgnoreCase("butt")) {
         setEndCap(BasicStroke.CAP_BUTT);
         return;
      }
      if (str.equalsIgnoreCase("round")) {
         setEndCap(BasicStroke.CAP_ROUND);
         return;
      }
      if (str.equalsIgnoreCase("square")) {
         setEndCap(BasicStroke.CAP_SQUARE);
         return;
      }

      Debug.println("Error parsing end cap - using default value");
   } // of method

   //-----------------------------------------------------------------

   private void handleLineJoin(String str) {
      //// 1. Ignore if there is no value.
      if (str == null || str.equals("")) {
         return;
      }

      //// 2. Otherwise parse and set the value.
      if (str.equalsIgnoreCase("miter")) {
         setLineJoin(BasicStroke.JOIN_MITER);
         return;
      }
      if (str.equalsIgnoreCase("round")) {
         setLineJoin(BasicStroke.JOIN_ROUND);
         return;
      }
      if (str.equalsIgnoreCase("bevel")) {
         setLineJoin(BasicStroke.JOIN_BEVEL);
         return;
      }

      Debug.println("Error parsing end cap - using default value");
   } // of method

   //-----------------------------------------------------------------

   /**
    * Implements Strategy pattern for handling floating point values.
    */
   private void handleFloat(ParseFloat strategy, String str) {
      //// 1. Ignore if there is no value.
      if (str == null || str.equals("")) {
         return;
      }

      //// 2. Otherwise parse and set the value.
      try {
         float f = Float.valueOf(str).floatValue();
         strategy.setStyleValue(f);
      }
      catch (Exception e) {
         Debug.println("Error parsing " + strategy.getName() + 
                       " - using default value");
      }
   } // of method

   //-----------------------------------------------------------------
   
   /**
    * Gets the class so that when a style is created with a properties
    * filename, this style will first look at the data/ directory off of
    * the directory in which the class is located. (This works within
    * Jar files, too.) If null, then this style will look at the
    * data/ directory relative to the directory in which the Java
    * interpreter was started.
    */
   static public Class getPropertiesBaseLocation() {
      return baseClass;
   } // of method

   //-----------------------------------------------------------------
   
   /**
    * Sets the class so that when a style is created with a properties
    * filename, this style will first look at the data/ directory off of
    * the directory in which the class is located. (This works within
    * Jar files, too.) If set to null, then this style will look at the
    * data/ directory relative to the directory in which the Java
    * interpreter was started.
    */
   static public void setPropertiesBaseLocation(Class newBaseClass) {
      baseClass = newBaseClass;
   } // of method
   
   //===   PROPERTIES INITIALIZATION   =========================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Get the drawing style.
    *
    * @return a BasicStroke.
    */
   public BasicStroke getDrawStroke() {
      return (drawStroke);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Return a copy of the dash array (not a reference to the original one!).
    *
    * @see java.awt.BasicStroke#getDashArray()
    */
   public float[] getDashArray() {
      float[] fArray       = drawStroke.getDashArray();
      float[] fArrayReturn = new float[fArray.length];

      for (int i = 0; i < fArray.length; i++) {
         fArrayReturn[i] = fArray[i];
      }

      return (fArrayReturn);
   } // of method

   //-----------------------------------------------------------------

   /**
    * For internal use only, retrieves a reference as opposed to a copy.
    */
   private float[] getDashArrayImpl() {
      return (drawStroke.getDashArray());
   } // of method

   //-----------------------------------------------------------------

   /**
    * @see java.awt.BasicStroke#getDashPhase()
    */
   public float getDashPhase() {
      return (drawStroke.getDashPhase());
   } // of method

   //-----------------------------------------------------------------

   /**
    * @see java.awt.BasicStroke#getEndCap()
    */
   public int getEndCap() {
      return (drawStroke.getEndCap());
   } // of method

   //-----------------------------------------------------------------

   /**
    * @see java.awt.BasicStroke#getLineJoin()
    */
   public int getLineJoin() {
      return (drawStroke.getLineJoin());
   } // of method

   //-----------------------------------------------------------------

   /**
    * @see java.awt.BasicStroke#getLineWidth()
    */
   public float getLineWidth() {
      return (drawStroke.getLineWidth());
   } // of method

   //-----------------------------------------------------------------

   /**
    * @see java.awt.BasicStroke#getMiterLimit()
    */
   public float getMiterLimit() {
      return (drawStroke.getMiterLimit());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the color to draw lines with.
    *
    * @return the line drawing color.
    */
   public Color getDrawColor() {
      return (drawColor);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the font style.
    *
    * @return a font.
    */
   public Font getDrawFont() {
      return (drawFont);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Just get the name of the font, for optimization purposes.
    */
   public String getDrawFontName() {
       return (drawFont.getFontName());
   } // of method

   //-----------------------------------------------------------------

   public Color getFontColor() {
      return (fontColor);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the color to fill with.
    *
    * @return the fill color.
    */
   public Color getFillColor() {
      return (fillColor);
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Set the drawing style.
    *
    * @param s is the drawing style to set to.
    */
   public void setDrawStroke(BasicStroke s) {
      drawStroke = new SatinStroke(s);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the dash array for the pen used to draw with this style.
    *
    * @see   java.awt.BasicStroke#getDashArray()
    * @param fArray the array representing the dashing pattern
    */
   public void setDashArray(float[] fArray) {
      //// 1. Set the value. Creating a new object because BasicStroke is 
      ////    missing modifier methods.
      drawStroke = new 
         SatinStroke(getLineWidth(),  getEndCap(), getLineJoin(),
                     getMiterLimit(), fArray,      getDashPhase());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the dash phase for the pen used to draw with this style.
    *
    * @see   java.awt.BasicStroke#getDashPhase()
    * @param newDashPhase is the offset to start the dashing pattern
    */
   public void setDashPhase(float newDashPhase) {
      //// 1. Set the value. Creating a new object because BasicStroke is 
      ////    missing modifier methods.
      drawStroke = new 
         SatinStroke(getLineWidth(),  getEndCap(),        getLineJoin(),
                     getMiterLimit(), getDashArrayImpl(), newDashPhase);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the end cap for the pen used to draw with this style.
    *
    * @see   java.awt.BasicStroke#getEndCap()
    * @param newEndCap is the decoration of the ends.
    */
   public void setEndCap(int newEndCap) {
      //// 1. Set the value. Creating a new object because BasicStroke is 
      ////    missing modifier methods.
      drawStroke = new 
         SatinStroke(getLineWidth(),  newEndCap,          getLineJoin(),
                     getMiterLimit(), getDashArrayImpl(), getDashPhase());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the line join for the pen used to draw with this style.
    *
    * @see   java.awt.BasicStroke#getLineJoin()
    * @param newLineJoin is the decoration applied where path segments meet.
    */
   public void setLineJoin(int newLineJoin) {
      //// 1. Set the value. Creating a new object because BasicStroke is 
      ////    missing modifier methods.
      drawStroke = new 
         SatinStroke(getLineWidth(),  getEndCap(),        newLineJoin,
                     getMiterLimit(), getDashArrayImpl(), getDashPhase());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the line width for the pen used to draw with this style.
    *
    * @see   java.awt.BasicStroke#getLineWidth()
    * @param newLineWidth is the width of the pen.
    */
   public void setLineWidth(float newLineWidth) {
      //// 1. Set the value. Creating a new object because BasicStroke is 
      ////    missing modifier methods.
      drawStroke = new 
         SatinStroke(newLineWidth,    getEndCap(),        getLineJoin(),
                     getMiterLimit(), getDashArrayImpl(), getDashPhase());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the miter limit for the pen used to draw with this style.
    *
    * @see   java.awt.BasicStroke#getMiterLimit()
    * @param newMiterLimit is the limit to trim the miter join.
    */
   public void setMiterLimit(float newMiterLimit) {
      //// 1. Set the value. Creating a new object because BasicStroke is 
      ////    missing modifier methods.
      drawStroke = new 
         SatinStroke(getLineWidth(), getEndCap(),        getLineJoin(),
                     newMiterLimit,  getDashArrayImpl(), getDashPhase());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the font to use.
    *
    * @param newFont is the font to set to.
    */
   public void setDrawFont(Font newFont) {
      drawFont = newFont;
   } // of method

   //-----------------------------------------------------------------

   public void setFontColor(Color newColor) {
      fontColor = newColor;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the drawing color.
    *
    * @param newColor is the color to set to.
    */
   public void setDrawColor(Color newColor) {
      drawColor = newColor;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the drawing color in HSV format.
    *
    * @param h is the hue value.
    * @param s is the saturation value.
    * @param v is the brightness value.
    */
   public void setDrawColorHSV(float h, float s, float v) {
      drawColor = new Color(Color.HSBtoRGB(h, s, v));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the drawing color in RGB format.
    *
    * @param r is the red value (0-255).
    * @param g is the green value (0-255).
    * @param b is the blue value (0-255).
    * @param a is the transparency value (0-255).
    */
   public void setDrawColorRGBA(int r, int g, int b, int a) {
      drawColor = new Color(r, g, b, a);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the drawing color in RGB format.
    *
    * @param r is the red value (0.00 - 1.00).
    * @param g is the green value (0.00 - 1.00).
    * @param b is the blue value (0.00 - 1.00).
    * @param a is the transparency value (0.00 - 1.00).
    */
   public void setDrawColorRGBA(float r, float g, float b, float a) {
      int rr = (int) (r * 255);
      int gg = (int) (g * 255);
      int bb = (int) (b * 255);
      int aa = (int) (a * 255);

      setDrawColorRGBA(rr, gg, bb, aa);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the transparency for drawing.
    *
    * @param aa is the transparency value, from 0 to 1, 0 being transparent and
    *           1 being solid.
    */
   public void setDrawTransparency(float aa) {
      setDrawTransparency((int) (aa * 255));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the transparency for draw.
    *
    * @param aa is the transparency value (0-255).
    */
   public void setDrawTransparency(int aa) {
      int rr = drawColor.getRed();
      int gg = drawColor.getGreen();
      int bb = drawColor.getBlue();

      setDrawColorRGBA(rr, gg, bb, aa);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the fill color.
    *
    * @param newColor is the color to set to.
    */
   public void setFillColor(Color newColor) {
      fillColor = newColor;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the fill color in HSV format.
    *
    * @param h is the hue value.
    * @param s is the saturation value.
    * @param v is the brightness value.
    */
   public void setFillColorHSV(float h, float s, float v) {
      fillColor = new Color(Color.HSBtoRGB(h, s, v));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the fill color in RGB format.
    *
    * @param r is the red value (0-255).
    * @param g is the green value (0-255).
    * @param b is the blue value (0-255).
    * @param a is the transparency value (0-255).
    */
   public void setFillColorRGBA(int r, int g, int b, int a) {
      fillColor = new Color(r, g, b, a);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the fill color in RGB format.
    *
    * @param r is the red value (0.00 - 1.00).
    * @param g is the green value (0.00 - 1.00).
    * @param b is the blue value (0.00 - 1.00).
    * @param a is the transparency value (0.00 - 1.00).
    */
   public void setFillColorRGBA(float r, float g, float b, float a) {
      int rr = (int) (r * 255);
      int gg = (int) (g * 255);
      int bb = (int) (b * 255);
      int aa = (int) (a * 255);

      setFillColorRGBA(rr, gg, bb, aa);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the transparency for fill.
    *
    * @param aa is the transparency value (0.00 - 1.00).
    */
   public void setFillTransparency(float aa) {
      setFillTransparency((int) (255 * aa));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the transparency for fill.
    *
    * @param aa is the transparency value (0-255).
    */
   public void setFillTransparency(int aa) {
      int rr = fillColor.getRed();
      int gg = fillColor.getGreen();
      int bb = fillColor.getBlue();

      setFillColorRGBA(rr, gg, bb, aa);
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   /**
    * Debugging info.
    */
   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();
      
      new StringBuffer();
      strbuf.append("FillColor:      " + fillColor  + "\n");
      strbuf.append("DrawColor:      " + drawColor  + "\n");
      strbuf.append("DrawFont:       " + drawFont   + "\n");
      strbuf.append("DrawStroke:     " + StringLib.toString(drawStroke));

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Make a clone of this Style.
    */
   public Object clone() {

      Style newStyle = new Style(this);
      return (newStyle);

   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) {
      System.out.println(new Style());
      System.out.println(new Style("SampleStyle.properties"));
   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
