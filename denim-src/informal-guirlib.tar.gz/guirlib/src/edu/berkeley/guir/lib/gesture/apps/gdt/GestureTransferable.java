package edu.berkeley.guir.lib.gesture.apps.gdt;

// probably should go in edu.berkeley.guir.lib.gesture someday

import java.awt.datatransfer.*;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.Misc;
import java.util.*;
import java.io.IOException;

public class GestureTransferable implements Transferable {
  private Object data;
  private DataFlavor flavor;
  
  public GestureTransferable(GestureObject gestureObj)
  {
    data = gestureObj;
    flavor = GestureFlavorFactory.getDataFlavor(gestureObj.getClass());
  }

  public GestureTransferable(Collection collection)
  {
    data = collection;
    Class biggestClass = getBiggestElementClass(collection);
    //System.out.println("GT: " + biggestClass);
    flavor = GestureFlavorFactory.getCollectionDataFlavor(biggestClass);
    if (flavor == null) {
      System.err.println("ERROR: can't find a flavor for " + biggestClass);
    }
  }

  /** returns the Class of the "biggest" element. GestureSet is
      biggest, Gesture smallest.  Order is
      GestureSet:GestureGroup:GestureCategory:Gesture. */
  public static Class getBiggestElementClass(Collection collection)
  {
    Object obj = Misc.findLargest(collection, new Comparator() {
      public int compare(Object a, Object b) {
	return compareGestureTypes(a.getClass(), b.getClass());
      }
    });
    return obj.getClass();
  }

  protected static final Class[] CLASS_ORDER = {
    Gesture.class, GestureCategory.class, GestureGroup.class,
    GestureSet.class
  };
  protected static int compareGestureTypes(Class a, Class b)
  {
    int indexA = Misc.indexOf(CLASS_ORDER, a);
    int indexB = Misc.indexOf(CLASS_ORDER, b);
    return (indexA == indexB) ? 0 : ((indexA < indexB) ? -1 : 1);
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    DataFlavor genericFlavor = (data instanceof Collection) ?
      GestureFlavorFactory.GESTURE_OBJECT_COLLECTION_FLAVOR :
      GestureFlavorFactory.GESTURE_OBJECT_FLAVOR;
    DataFlavor[] result = { flavor, genericFlavor };
    return result;
  }

  public boolean isDataFlavorSupported(DataFlavor flavor)
  {
    DataFlavor[] flavors = getTransferDataFlavors();
    return Misc.indexOf(flavors, flavor) != -1;
  }

  /** Return true if either the normal data flavor or the collection
      data flavor for c are supported.  See also
      GestureFlavorFactory. */
  public boolean isClassSupported(Class c)
  {
    return isDataFlavorSupported(GestureFlavorFactory.getDataFlavor(c)) ||
      isDataFlavorSupported(GestureFlavorFactory.
			    getCollectionDataFlavor(c));
  }
  
  public Object getTransferData(DataFlavor flavor)
    throws UnsupportedFlavorException, IOException
  {
    if (isDataFlavorSupported(flavor)) {
      return data;
    }
    else {
      throw new UnsupportedFlavorException(flavor);
    }
  }
}
