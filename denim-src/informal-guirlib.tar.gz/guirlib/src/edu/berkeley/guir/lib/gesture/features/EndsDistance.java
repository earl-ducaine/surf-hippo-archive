package edu.berkeley.guir.lib.gesture.features;

import java.lang.Math;
import java.awt.Polygon;
import edu.berkeley.guir.lib.gesture.*;

/**
 * Distance between first and last point
 */
public class EndsDistance extends Feature {
  public final double minValue = 0;
  public final double maxValue = Double.POSITIVE_INFINITY;
  
  public EndsDistance()
  {
    super();
  }

  public EndsDistance(Gesture g)
  {
    super(g);
  }

  protected void computeValue()
  {
    Polygon points = gesture.getPointsRef();
    if (points.npoints > 0) {
      double dx = points.xpoints[points.npoints-1] - points.xpoints[0];
      double dy = points.ypoints[points.npoints-1] - points.ypoints[0];
      value = Math.sqrt(dx*dx + dy*dy);
    }
    else
      value = 0;
    valueOk = true;
  }

  public String getName()
  {
    return new String("distance between first and last points");
  }

  public double getMinValue()
  {
    return minValue;
  }
  
  public double getMaxValue()
  {
    return maxValue;
  }

  public void scale(double factor)
  {
    gesture.normalize();
    TimedPolygon points = gesture.getPointsRef();
    int i;

    for (i = 0; i < points.npoints; i++) {
      points.xpoints[i] *= factor;
      points.ypoints[i] *= factor;
    }
    gesture.setPoints(points);
  }
}
