//// See bottom of file for software license
package edu.berkeley.guir.lib.io;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Miscellaneous IO utilities, including:
 * <UL>
 *   <LI>Empty InputStreams, OutputStreams, Readers, and Writers
 *   <LI>Some predefined file filters
 *   <LI>Recursively traversing a directory to retrieve all files
 *   <LI>Reading in all bytes or chars in a file
 * </UL>
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Mar 07 2004, JH
 */
public class IOLib {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * A file filter that accepts everything.
     */
    public static final FileFilter FILE_FILTER_EMPTY = new EmptyFileFilter();

    /**
     * A file filter that accepts *.xml files.
     */
    public static final FileFilter FILE_FILTER_XML  = new XmlFileFilter();

    /**
     * Accepts directories, not files.
     */
    public static final FileFilter FILE_FILTER_DIR  = new DirectoryFileFilter();

    /**
     * Accepts files, not directories.
     */
    public static final FileFilter FILE_FILTER_FILE = new FileFileFilter();

    //----------------------------------------------------------------

    public static final InputStream  INPUTSTREAM_EMPTY  = 
                                                     new EmptyInputStream();
    public static final OutputStream OUTPUTSTREAM_EMPTY = 
                                                    new EmptyOutputStream();
    public static final Reader       READER_EMPTY       = new EmptyReader();
    public static final Writer       WRITER_EMPTY       = new EmptyWriter();

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   STREAM INNER CLASSES   =============================================

    /**
     * InputStream that does absolutely nothing.
     */
    static public class EmptyInputStream extends InputStream {
        public int available() {
            return (0);
        } // of method

        public void close() {
            //// ignore
        } // of method

        public void mark(int readlimit) {
            //// ignore
        } // of method

        public boolean markSupported() {
            return (false);
        } // of method

        public int read() {
            return (-1);
        } // of method

        public int read(byte[] b) {
            return (-1);
        } // of method

        public int read(byte[] b, int off, int len) {
            return (-1);
        } // of method

        public void reset() {
        } // of method

        public long skip(long n) {
            return (0);
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * OutputStream that does absolutely nothing.
     */
    static public class EmptyOutputStream extends OutputStream {
        public void close() {
            //// ignore
        } // of method

        public void flush() {
            //// ignore
        } // of method

        public void write(byte[] b) {
            //// ignore
        } // of method

        public void write(byte[] b, int off, int len) {
            //// ignore
        } // of method

        public void write(int b) {
            //// ignore
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * Reader that does absolutely nothing.
     */
    static public class EmptyReader extends Reader {
        public void close() {
            //// ignore
        } // of method

        public void mark(int readAheadLimit) {
            //// ignore
        } // of method

        public boolean markSupported() {
            return (false);
        } // of method

        public int read() {
            return (-1);
        } // of method

        public int read(char[] c) {
            return (-1);
        } // of method

        public int read(char[] c, int off, int len) {
            return (-1);
        } // of method

        public boolean ready() {
            return (false);
        } // of method

        public void reset() {
        } // of method

        public long skip(long n) {
            return (0);
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * Writer that does absolutely nothing.
     */
    static public class EmptyWriter extends Writer {
        public void close() { } // of method
        public void flush() { } // of method
        public void write(char[] c) { } // of method
        public void write(char[] c, int off, int len) { } // of method
        public void write(int c) { } // of method
        public void write(String str) { } // of method
        public void write(String str, int off, int len) { } // of method
    } // of inner class

    //===   STREAM INNER CLASSES   =============================================
    //==========================================================================




    //==========================================================================
    //===   FILE FILTER INNER CLASSES   ========================================

    /**
     * A file filter that contains multiple file filters.
     * @see IOLib.AndFileFilter
     * @see IOLib.OrFileFilter
     */
    static abstract public class MultiFileFilter implements FileFilter {
        List listFilters = new LinkedList();

        public MultiFileFilter() {
        } // of constructor

        public MultiFileFilter(FileFilter filterAA) {
            addFilter(filterAA);
        } // of constructor

        public MultiFileFilter(FileFilter filterAA, FileFilter filterBB) {
            addFilter(filterAA);
            addFilter(filterBB);
        } // of constructor

        public MultiFileFilter(FileFilter filterAA, FileFilter filterBB,
                               FileFilter filterCC) {
            addFilter(filterAA);
            addFilter(filterBB);
            addFilter(filterCC);
        } // of constructor

        public MultiFileFilter(FileFilter filterAA, FileFilter filterBB,
                               FileFilter filterCC, FileFilter filterDD) {
            addFilter(filterAA);
            addFilter(filterBB);
            addFilter(filterCC);
            addFilter(filterDD);
        } // of constructor

        public void addFilter(FileFilter filter) {
            listFilters.add(filter);
        } // of method

        public Iterator filters() {
            return (listFilters.iterator());
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * A file filter that contains multiple file filters.
     * It does an AND operation on the filters contained.
     * For example, if one filter that accepted *.xml and 
     * another that accepted *.txt were put into this filter,
     * then no files would be accepted.
     */
    static public class AndFileFilter extends MultiFileFilter {

        public AndFileFilter() {
        } // of constructor

        public AndFileFilter(FileFilter filterAA) {
            super(filterAA);
        } // of constructor

        public AndFileFilter(FileFilter filterAA, FileFilter filterBB) {
            super(filterAA, filterBB);
        } // of constructor

        public AndFileFilter(FileFilter filterAA, FileFilter filterBB,
                             FileFilter filterCC) {
            super(filterAA, filterBB, filterCC);
        } // of constructor

        public AndFileFilter(FileFilter filterAA, FileFilter filterBB,
                             FileFilter filterCC, FileFilter filterDD) {
            super(filterAA, filterBB, filterCC, filterDD);
        } // of constructor

        public boolean accept(File pathname) {
            Iterator   it = filters();
            FileFilter filter;

            while (it.hasNext()) {
                filter = (FileFilter) it.next();
                if (filter.accept(pathname) == false) {
                    return (false);
                }
            }
            return (true);
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * A file filter that contains multiple file filters.
     * It does an OR operation on the filters contained.
     * For example, if one filter that accepted *.xml and 
     * another that accepted *.txt were put into this filter,
     * then any file that was either *.txt or *.xml would be accepted.
     */
    static public class OrFileFilter extends MultiFileFilter {

        public OrFileFilter() {
        } // of constructor

        public OrFileFilter(FileFilter filterAA) {
            super(filterAA);
        } // of constructor

        public OrFileFilter(FileFilter filterAA, FileFilter filterBB) {
            super(filterAA, filterBB);
        } // of constructor

        public OrFileFilter(FileFilter filterAA, FileFilter filterBB,
                            FileFilter filterCC) {
            super(filterAA, filterBB, filterCC);
        } // of constructor

        public OrFileFilter(FileFilter filterAA, FileFilter filterBB,
                            FileFilter filterCC, FileFilter filterDD) {
            super(filterAA, filterBB, filterCC, filterDD);
        } // of constructor

        public boolean accept(File pathname) {
            Iterator   it = filters();
            FileFilter filter;

            while (it.hasNext()) {
                filter = (FileFilter) it.next();
                if (filter.accept(pathname) == true) {
                    return (true);
                }
            }
            return (false);
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * A file filter that accepts all.
     */
    static public class EmptyFileFilter implements FileFilter {
        public boolean accept(File pathname) {
            return (true);
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * Checks if it is a File (but not a directory).
     */
    static public class FileFileFilter implements FileFilter {
        public boolean accept(File pathname) {
            return (pathname.isDirectory() == false);
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * Checks if it is a directory (but not a file).
     */
    static public class DirectoryFileFilter implements FileFilter {
        public boolean accept(File pathname) {
            return (pathname.isDirectory() == true);
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * A filter that accepts files with a specific extension,
     * ex. *.xml.
     */
    static public class ExtensionFileFilter implements FileFilter {
        String strExtension;

        /**
         * @param newExtension is ".xml" or such.
         */
        public ExtensionFileFilter(String newExtension) {
            if (newExtension.startsWith(".")) {
                strExtension = newExtension;
            }
            else {
                strExtension = "." + newExtension;
            }
        } // of constructor

        public boolean accept(File pathname) {
            String strFileName = pathname.getName();
            if (strFileName.endsWith(strExtension)) {
                return (true);
            }
            return (false);
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * A file filter that accepts things ending in ".xml"
     */
    static public class XmlFileFilter extends ExtensionFileFilter {
        public XmlFileFilter() {
            super(".xml");
        } // of constructor
    } // of inner class

    //----------------------------------------------------------------

    /**
     * A filter that accepts files that match the specified pattern.
     * The regex is done via standard Java pattern matching.
     */
    static public class PatternFileFilter implements FileFilter {
        String strPattern;

        /**
         * @param aPattern is some pattern.
         */
        public PatternFileFilter(String aPattern) {
            strPattern = aPattern;
        } // of constructor

        public boolean accept(File pathname) {
            String strFileName = pathname.getName();
            return (strFileName.matches(strPattern));
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * Create a file filter based on a start and end time.
     * Accepts files whose last-modified is between the two times.
     */
    static public class DateFileFilter implements FileFilter {

        long startTime;
        long endTime;

        public DateFileFilter(long aStartTime, long aEndTime) {
            startTime = aStartTime;
            endTime   = aEndTime;
        } // of constructor

        public boolean accept(File pathname) {
            long lastModified = pathname.lastModified();
            if (startTime <= lastModified && lastModified <= endTime) {
                return (true);
            }
            return (false);
        } // of method

    } // of inner class

    //===   FILE FILTER INNER CLASSES   ========================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    /**
     * No instances allowed.
     */
    private IOLib() {
    } // of method

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================




    //==========================================================================
    //===   STRING METHODS   ===================================================

    /**
     * Check if the given String contains the specified String.
     */
    public static boolean doesContainString(String strBody, String strSearch) {
        return (doesContainStrings(strBody, new String[] {strSearch} ));
    } // of method

    //----------------------------------------------------------------

    /**
     * Check if the given String contains all of the specified Strings.
     */
    public static boolean doesContainString(String strBody, 
                                            String strAA, String strBB) {
        return (doesContainStrings(strBody, new String[] {strAA, strBB} ));
    } // of method

    //----------------------------------------------------------------

    /**
     * Check if the given String contains all of the specified Strings.
     */
    public static boolean doesContainStrings(String strBody, String[] strArr) {
        //// 1. Check if it does not contain each String.
        for (int i = 0; i < strArr.length; i++) {
            if (strBody.indexOf(strArr[i]) < 0) {
                return (false);
            }
        }
        return (true);
    } // of method

    //===   STRING METHODS   ===================================================
    //==========================================================================




    //==========================================================================
    //===   FILE UTILITY METHODS   =============================================

    /**
     * Sort the files (in place) so that newest files are first.
     * Right now a slow non-optimal sort, more of a proof of concept.
     * Optimize this later. xxx
     */
    public static File[] sortFilesByDate(File[] files) {
        File tmp;     // swap variable
        long iDate;   // date of file on index i, larger values == newer
        long jDate;   // date of file on index j

        for (int i = 0; i < files.length; i++) {
            for (int j = i + 1; j < files.length; j++) {
                iDate = files[i].lastModified();
                jDate = files[j].lastModified();
                if (jDate > iDate) {
                    tmp      = files[i];
                    files[i] = files[j];
                    files[j] = tmp;
                }
            }
        }

        return (files);
    } // of method

    //----------------------------------------------------------------

    /**
     * Get all files in current directory with the specified extension.
     */
    public static File[] getFilesWithExtension(File fDir, String strExtension) {
        return (fDir.listFiles(new ExtensionFileFilter(strExtension)));
    } // of method

    /**
     * Get all files in current directory with the specified pattern.
     */
    public static File[] getFilesMatchingPattern(File fDir, String strPattern) {
        return (fDir.listFiles(new PatternFileFilter(strPattern)));
    } // of method

    //----------------------------------------------------------------

    /**
     * Recursively get all files in the specified directory.
     * Doesn't include directories, just files.
     */
    public static File[] getAllFiles(File fDir) {
        //// 0. Error case.
        if (fDir.isDirectory() == false) {
            return (new File[0]);
        }

        //// 1. 
        List   listFiles = new ArrayList();
        File[] files     = fDir.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isDirectory() == true) {
                listFiles.addAll(Arrays.asList(getAllFiles(files[i])));
            }
            else {
                listFiles.add(files[i]);
            }
        }
        return ((File[]) listFiles.toArray(new File[0]));
    } // of method

    //===   FILE UTILITY METHODS   =============================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY METHODS   ==================================================

    /**
     * Check if a given file contains the specified String.
     */
    public static boolean doesContainString(File f, String str) 
        throws IOException {

        return (doesContainStrings(f, new String[] {str} ));
    } // of method

    //----------------------------------------------------------------

    /**
     * Check if a given file contains the specified String.
     */
    public static boolean doesContainString(File f, String strAA, String strBB) 
        throws IOException {

        return (doesContainStrings(f, new String[] {strAA, strBB} ));
    } // of method

    //----------------------------------------------------------------

    /**
     * Check if a given file contains the specified Strings.
     */
    public static boolean doesContainStrings(File f, String[] strArr)
        throws IOException {

        //// 1. Slurp all of the bytes in the file into a String.
        StringBuffer strFile = IOLib.readAll(f);
        return (doesContainStrings(strFile.toString(), strArr));
    } // of method

    //==========================================================================

    /**
     * Read up to len number of chars.
     */
    public static StringBuffer read(File f, int len) 
        throws IOException {

        return ( read(new FileReader(f), len) );
    } // of method

    //--------------------

    /**
     * Read up to len number of chars.
     */
    public static StringBuffer read(InputStream istream, int len) 
        throws IOException {

        return ( read(new InputStreamReader(istream), len) );
    } // of method

    //--------------------

    /**
     * Read up to len number of chars.
     */
    public static StringBuffer read(Reader rdr, int len) 
        throws IOException {

        char[]       cbuf   = new char[len];       // buffer for reading
        int          nread;                        // num chars from last read 
        StringBuffer strbuf = new StringBuffer();

        if (! (rdr instanceof BufferedReader)) {
            rdr = new BufferedReader(rdr);
        }

        while ((nread = rdr.read(cbuf)) > 0) {
            strbuf.append(cbuf, 0, nread);
        }
        return (strbuf);
    } // of method

    //==========================================================================

    /**
     * Read in all of the bytes in the specified file.
     * Reads text, not binary.
     */
    public static StringBuffer readAll(File f) 
        throws IOException {
        return ( readAll(new FileReader(f), new StringBuffer()) );
    } // of method

    //--------------------

    /**
     * Read in all of the bytes in the specified file into the specified
     * StringBuffer. Reads text, not binary.
     */
    public static StringBuffer readAll(File f, StringBuffer strbuf)
        throws IOException {

        return ( readAll(new FileReader(f), strbuf) );
    } // of method

    //----------------------------------------------------------------

    /**
     * Read in all of the bytes in the specified InputStream.
     * Reads text, not binary.
     */
    public static StringBuffer readAll(InputStream istream) 
        throws IOException {

        return ( readAll(new InputStreamReader(istream), new StringBuffer()) );
    } // of method

    //--------------------

    /**
     * Read in all of the bytes in the specified InputStream.
     * Reads text, not binary.
     */
    public static StringBuffer readAll(InputStream  istream, 
                                       StringBuffer strbuf) 
        throws IOException {

        return (readAll(new InputStreamReader(istream), strbuf) );
    } // of method

    //----------------------------------------------------------------

    /**
     * Read in all of the data in the specified Reader.
     * Reads text, not binary.
     */
    public static StringBuffer readAll(Reader rdr) 
        throws IOException {

        return ( readAll(rdr, new StringBuffer()) );
    } // of method

    //--------------------

    /**
     * Read in all of the data in the specified Reader.
     * Reads text, not binary.
     * @param chStop is a char to stop on, ex. (char) 0
     */
    public static StringBuffer readAll(Reader rdr, char chStop) 
        throws IOException {

        return ( readAll(rdr, new StringBuffer(), chStop) );
    } // of method

    //--------------------

    /**
     * Read in all of the data in the specified Reader.
     * Reads text, not binary.
     */
    public static StringBuffer readAll(Reader rdr, StringBuffer strbuf)
        throws IOException {

        char[] cbuf   = new char[4096];      // buffer for reading
        int    nread;                        // num chars from last read 

        if (! (rdr instanceof BufferedReader)) {
            rdr = new BufferedReader(rdr);
        }

        while ((nread = rdr.read(cbuf)) > 0) {
            strbuf.append(cbuf, 0, nread);
        }

        return (strbuf);
    } // of method

    //--------------------

    /**
     * Read in all of the data in the specified Reader.
     * Reads text, not binary.
     * @param chStop is a char to stop on, ex. (char) 0
     */
    public static StringBuffer readAll(Reader       rdr, 
                                       StringBuffer strbuf,
                                       char         chStop)
        throws IOException {

        char[] cbuf   = new char[4096];      // buffer for reading
        int    nread;                        // num chars from last read 

        if (! (rdr instanceof BufferedReader)) {
            rdr = new BufferedReader(rdr);
        }

        while ((nread = rdr.read(cbuf)) > 0) {
            if (cbuf[nread - 1] == chStop) {
                strbuf.append(cbuf, 0, nread - 1);
                break;
            }
            else {
                strbuf.append(cbuf, 0, nread);
            }
        }
        return (strbuf);
    } // of method

    //----------------------------------------------------------------

    /**
     * Read in all of the bytes.
     */
    public static byte[] readAllBytes(File f)
        throws IOException {

        return ( readAllBytes(new FileInputStream(f)) );
    } // of method


    /**
     * Read in all of the bytes.
     */
    public static byte[] readAllBytes(InputStream istream) 
        throws IOException {

        ByteArrayOutputStream bostream = new ByteArrayOutputStream();
        byte[]                bbuf     = new byte[4096];
        int                   nread;

        if (! (istream instanceof BufferedInputStream)) {
            istream = new BufferedInputStream(istream);
        }

        while ((nread = istream.read(bbuf)) > 0) {
            bostream.write(bbuf, 0, nread);
        }

        return (bostream.toByteArray());
    } // of method

    //----------------------------------------------------------------

    /**
     * Read in exactly one line from an InputStream.
     * @return a String, or null if end of stream.
     * @see #readLine(InputStream,byte[],int,int)
     */
    public static String readLine(InputStream istream) 
        throws IOException {

        byte[]       buf    = new byte[128];
        StringBuffer strbuf = null;
        int          nread;

        //// 1. Try to read a line.
        while ((nread = readLine(istream, buf, 0, buf.length)) > 0) {
            //// Check if we have to read again.
            //// If so, use the StringBuffer.
            if (nread >= buf.length) {
                strbuf = new StringBuffer(new String(buf, 0, nread));
            }
            else {
                if (strbuf != null) {
                    strbuf.append(new String(buf, 0, nread));
                }

                break;
            }
        }

        //// 2. Return a String or null if end of stream.
        if (nread <= 0) {
            return (null);
        }
        else if (strbuf == null) {
            return (new String(buf, 0, nread));
        }
        else {
            return (strbuf.toString());
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Read in a line from an InputStream.
     * Line is defined as ending in '\n'
     * @return number of bytes read, or -1 if end of stream.
     */
    public static int readLine(InputStream istream, 
                               byte[] buf, int off, int len)
        throws IOException {

        //// 1. Early exit case.
        if (len <= 0) {
            return 0;
        }

        //// 2. Read in all values until we are done.
        int count = 0;
        int val;

        while ((val = istream.read()) != -1) {
            buf[off++] = (byte) val;
            count++;
            if (val == '\n' || count == len) {
                break;
            }
        }

        //// 3. Return -1 if we are done.
        if (count > 0) {
            return (count);
        }
        else {
            return (-1);
        }
    } // of method

    //===   UTILITY METHODS   ==================================================
    //==========================================================================





    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static InputStream createInputStream() {
        StringBuffer strbuf = new StringBuffer();
        strbuf.append("GET /index.html HTTP/1.0\r\n");
        strbuf.append("header1: val1\r\n");
        strbuf.append("header2: val2\r\n");
        strbuf.append("header3: val3\r\n");
        strbuf.append("\r\n");
        strbuf.append("msg msg msg\r\n");
        strbuf.append("msg msg msg\r\n");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("0123456789");
        strbuf.append("AAAAAAAAAA\r\n");
        strbuf.append("0123456789");
        strbuf.append("AAAAAAAAAA\r\n");


        char[]      cbuf    = strbuf.toString().toCharArray();
        byte[]      bbuf    = new byte[cbuf.length];

        for (int i = 0; i < cbuf.length; i++) {
            bbuf[i] = (byte) cbuf[i];
        }
        InputStream istream = new ByteArrayInputStream(bbuf);

        return (istream);
    } // of method

    //----------------------------------------------------------------

    private static void runTestAAA() throws Exception {
        // System.out.println(readAll(new File("IOLib.java")));

        String      str;
        InputStream istream = createInputStream();

        while ((str = readLine(istream)) != null) {
            System.out.print(str);
        }
    } // of method

    //// test the recursive read
    private static void runTestBBB() {
        File[] files = getAllFiles(new File(System.getProperty("user.dir")));
        for (int i = 0; i < files.length; i++) {
            System.out.println(files[i]);
        }
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestBBB();
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/

