package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.awt.*;
import javax.swing.*;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.event.*;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.*;
import java.util.*;
import java.io.*;
import java.awt.event.*;
import java.text.ParseException;
import javax.swing.tree.*;
import java.awt.print.*;
import java.util.List;
import java.beans.*;
import edu.berkeley.guir.lib.gesture.Properties;

/** The main top-level window in gdt */
public class MainFrame extends JFrame
  implements GDTConstants {
  static private Map fileErrors = new HashMap();
  static {
    fileErrors.put(GestureFile.UnsupportedVersionException.class,
		   "That file version cannot be read.");
    fileErrors.put(ClassNotFoundException.class,
		   "A required class was not found (corrupted file?).");
    fileErrors.put(InvalidClassException.class,
		   "Couldn't parse a class (corrupted file?).");
    fileErrors.put(InvalidObjectException.class,
		   "Couldn't parse an object (corrupted file?).");
    fileErrors.put(IOException.class, "File I/O error.");
    fileErrors.put(FileNotFoundException.class, "File not found.");
    fileErrors.put(ParseException.class,
		   "Parse error (probably an ill-formed number).");
  }
  /** This property is a boolean value that indicates whether notices
      should be displayed by widgets. */
  public static final String	NOTICE_VISIBILITY_CHANGE_PROP =
    "NOTICE_VISIBILITY_CHANGE_PROP";
  // for action dispatch
  private static final String	ACTION_ID	= "action id";

  // data
  protected GestureFile		gestureFile = null;
  protected GesturePackage	gesturePackage = null;
  protected PageFormat		pageFormat = null;
  protected Classifier		classifier = null;
  protected GestureCategory	recognizedCategory = null;
  protected boolean		trainingInProgress = false;
  protected SwingWorker		trainingWorker = null;
  protected SwingWorker		testWorker = null;
  /** Number of "background" tasks that are reading data.  If this
      number is > 0, then changes to the data should be prohibited,
      otherwise the results of the background tasks will be
      inconsistent. */
  protected int			dataReaderCount = 0;
  /** This variable indicates whether the cursor should show the busy
      (or wait) cursor.  If it's > 0, then the busy cursor should be
      shown. */
  protected int			busyCount = 0;
  /** whether debug menu is on the menu bar or not */
  protected static boolean	debugMenuExists = true;
  /** whether warnings (aka notices) are enabled at all */
  protected static boolean	warningsEnabled = true;
  protected Analyzers		analyzers = new Analyzers(this);
  protected HumanGoodness	humanGoodness = null;
  protected RecognizerGoodness	recognizerGoodness = null;

  // file state
  protected final int		SAVED		= 2;
  protected final int		AUTOSAVED	= 1;
  protected final int		NOT_SAVED	= 0;
  protected int			saveLevel	= SAVED;
  protected String		lastDirectory	= ".";
  /** time between autosaves, in milliseconds */
  protected static int		autoSaveInterval	= 5 * 60 * 1000;
  /** Whether to use an autosave file or not */
  protected boolean		useAutoSave	= true;
  
  // UI components
  protected SummaryLog		summaryLog = null;
  protected NoticeHandler	noticeHandler = null;
  protected GestureInteractor	inputArea = null;
  protected CompositeGestureTree		gestureTrees = null;
  protected GestureTree		trainingTree = null;
  protected GestureTree		testTree = null;
  protected GestureDesktop	desktop = null;
  protected Vector		childCommanders = new Vector();
  protected JMenuItem		trainMenuItem;
  protected JMenuItem		testMenuItem;
  protected JCheckBoxMenuItem	warningsToggleMenuItem;
  protected JLabel		recognizerGoodnessLabel;
  protected JLabel		humanGoodnessLabel;

  // selection status
  /** The object(s) that are currently selected (e.g., GestureCategory) */
  protected List			currentSelection = null;
  /* the display managing the currently selected objects (either
     gestureTree or desktop)*/
  protected JComponent		selectionDisplay = null;
  protected boolean		inUpdateSelection = false;

  // event listeners
  protected PropertyChangeListener propChangeListener =
    new MyPropertyChangeListener();
  protected CollectionListener	collectionListener = new
    MyCollectionListener();
  protected PropertyChangeListener classifierListener =
    new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent e)
      {
	updateMenuItem(trainMenuItem);
      }
    };
  
  //----------------------------------------------------------------------
  // methods
  
  public MainFrame()
  {
    this(null);
  }
  
  public MainFrame(GestureFile f)
  {
    buildUI();
    if (f != null) {
      openFile(f);
    }
    else {
      setFile(f);
    }
    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
	if (doClose()) {
	  dispose();
	}
      }
    });
    updateMenuBar();
    Action autoSaveAction = new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
	doAutoSaveIfNecessary();
      }
    };
    new Timer(autoSaveInterval, autoSaveAction).start();
  }

  protected void buildUI()
  {
    JMenuBar menuBar = buildMenuBar();
    getRootPane().setJMenuBar(menuBar);

    Container contents = getContentPane();
    contents.setLayout(new BorderLayout());
    JSplitPane logSplitter = new JSplitPane(JSplitPane.VERTICAL_SPLIT, true);
    logSplitter.setResizeWeight(0.7);
    contents.add(logSplitter, BorderLayout.CENTER);

    summaryLog = new SummaryLog(this);
    summaryLog.setPreferredSize(new Dimension(200, 50));
    logSplitter.setBottomComponent(summaryLog);
    noticeHandler = new NoticeHandler(summaryLog);

    // centerArea contains the desktop on the right, and the trees and
    // input area on the left
    JSplitPane centerArea = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
					   true);
    centerArea.setResizeWeight(0.33);
    logSplitter.setTopComponent(centerArea);

    JSplitPane leftPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, true);
    leftPane.setResizeWeight(0.75);
    centerArea.setLeftComponent(leftPane);
    
    inputArea = new GestureInteractor();
    inputArea.setMinimumSize(new Dimension(50,50));
    inputArea.setEnabled(false);
    inputArea.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
	if (((GestureAcceptor) selectionDisplay).
	    gestureDrawn(inputArea.getGesture())) {
	  inputArea.setGesture(null);
	}
      }
    });
    leftPane.setBottomComponent(inputArea);

    gestureTrees = new CompositeGestureTree();
    //gestureTree.setPreferredSize(new Dimension(150,150));
    trainingTree = gestureTrees.getTrainingTree();
    testTree = gestureTrees.getTestTree();
    ChangeListener standardMenuChangeListener = new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
      	updateMenuBar();
      }
    };
    installTree(trainingTree, standardMenuChangeListener);
    installTree(testTree, standardMenuChangeListener);
    
    gestureTrees.setPreferredSize(new Dimension(200,400));

    JPanel treePanel = new JPanel(new BorderLayout());
    JPanel metricsPanel = buildMetricsPanel();
    treePanel.add(metricsPanel, BorderLayout.NORTH);
    treePanel.add(gestureTrees, BorderLayout.CENTER);
    leftPane.setTopComponent(treePanel);

    inputArea.setPreferredSize(new Dimension(150,150));
    
    desktop = new GestureDesktop();
    desktop.setMinimumSize(new Dimension(50,50));
    desktop.setPreferredSize(new Dimension(300,300));
    // notice if the active frame changes
    desktop.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
	updateSelection(desktop);
	updateInputArea();
      }
    });
    desktop.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
	updateSelection(desktop);
      }
    });
    // if anything happens that may change the status of the menu bar,
    // update it
    desktop.addMenuValidChangeListener(standardMenuChangeListener);
    selectionDisplay = desktop;
    childCommanders.add(desktop);

    centerArea.setRightComponent(desktop);
    updateMenuBar();
    updateInputArea();
  }

  protected JPanel buildMetricsPanel()
  {
    Border padding = BorderFactory.createEmptyBorder(0, 0, 0, 5);
    JPanel result = new JPanel(new GridLayout(2, 1));
    JPanel humanPanel = new JPanel(new BorderLayout());
    JLabel humanLabel = new JLabel("Human goodness");
    humanGoodnessLabel = new JLabel("?");
    humanGoodnessLabel.setHorizontalAlignment(SwingConstants.RIGHT);
    humanGoodnessLabel.setBorder(padding);
    //humanGoodnessLabel.setOpaque(true);
    humanPanel.add(humanLabel, BorderLayout.WEST);
    humanPanel.add(humanGoodnessLabel, BorderLayout.CENTER);
    humanPanel.setToolTipText("How well humans will be able to learn and remember the gestures.  1000 is the best value.");
    result.add(humanPanel);

    JPanel recognizerPanel = new JPanel(new BorderLayout());
    JLabel recognizerLabel = new JLabel("Recognizer goodness");
    recognizerGoodnessLabel = new JLabel("?");
    recognizerGoodnessLabel.setHorizontalAlignment(SwingConstants.RIGHT);
    recognizerGoodnessLabel.setBorder(padding);
    recognizerPanel.setToolTipText("How easily the computer can recognize the gestures.  1000 is the best value.");
    //recognizerGoodnessLabel.setOpaque(true);
    recognizerPanel.add(recognizerLabel, BorderLayout.WEST);
    recognizerPanel.add(recognizerGoodnessLabel, BorderLayout.CENTER);
    result.add(recognizerPanel);

    return result;
  }
  
  protected void installTree(final GestureTree tree,
			     ChangeListener standardMenuChangeListener)
  {
    TreeSelectionListener treeSelectionListener =
      new TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent e) {
	updateSelection(tree);
	updateInputArea();
      }
    };
    tree.addTreeSelectionListener(treeSelectionListener);
    tree.addMenuValidChangeListener(standardMenuChangeListener);
    childCommanders.add(tree);
  }
  
  //----------------------------------------------------------------------
  // menu bar

  public static void setWarningsEnabled(boolean on)
  {
    warningsEnabled = on;
  }

  public static boolean areWarningsEnabled()
  {
    return warningsEnabled;
  }

  public boolean areNoticesVisible()
  {
    return areWarningsEnabled() && warningsToggleMenuItem.getState();
  }

  public static void setDebugMenu(boolean on)
  {
    debugMenuExists = on;
  }
  
  private JMenuItem addMenuItem(JMenu menu, final int actionID,
				String label)
  {
    Action action = new AbstractAction(label) {
      public void actionPerformed(ActionEvent e) {
	doCommand(actionID);
      }
    };
    action.putValue(ACTION_ID, new Integer(actionID));
    
    JMenuItem item = new JMenuItem(action);
    menu.add(item);
    return item;
  }

  private JMenuItem addMenuItem(JMenu menu, final int actionID,
				final String enabledLabel,
				final String disabledLabel)
  {
    final JMenuItem item = addMenuItem(menu, actionID, enabledLabel);
    item.getAction().addPropertyChangeListener(new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent e) {
	if (e.getPropertyName().equals("enabled")) {
	  boolean value = ((Boolean) e.getNewValue()).booleanValue();
	  /*
	  System.out.println("Enable value: " + value);
	  */
	  item.setText(value ? enabledLabel : disabledLabel);
	}
      }
    });
    return item;
  }

  private JMenuItem addMenuItem(JMenu menu, final int actionID,
				final String label, char key, int modifiers)
  {
    JMenuItem item = addMenuItem(menu, actionID, label);
    /** due to a bug in BasicMenuItemUI, this doesn't work
    item.setAccelerator(KeyStroke.getKeyStroke(new Character(key),
					       modifiers));
    */
    String stringCode = "" + Character.toUpperCase(key);
    KeyStroke tempStroke = KeyStroke.getKeyStroke(stringCode);
    item.setAccelerator(KeyStroke.getKeyStroke(tempStroke.getKeyCode(),
					       modifiers));
    return item;
  }

  private JMenuItem addMenuItem(JMenu menu, final int actionID,
				final String label,
				int keyCode, int modifiers)
  {
    JMenuItem item = addMenuItem(menu, actionID, label);
    item.setAccelerator(KeyStroke.getKeyStroke(keyCode, modifiers));
    return item;
  }

  private JCheckBoxMenuItem addCBMenuItem(JMenu menu,
					  final int actionID,
					  String label,
					  boolean on)
  {
    Action action = new AbstractAction(label) {
      public void actionPerformed(ActionEvent e) {
	doCommand(actionID);
      }
    };
    action.putValue(ACTION_ID, new Integer(actionID));
    
    JCheckBoxMenuItem item = new JCheckBoxMenuItem(action);
    item.setState(on);
    menu.add(item);
    return item;
  }

  protected JMenuBar buildMenuBar()
  {
    int modifiers = java.awt.Event.ALT_MASK;
    JMenuBar mb = new JMenuBar();

    JMenu menu;

    menu = new JMenu("File");
    addMenuItem(menu, NEW_PACKAGE_ACTION, "New Package");
    menu.addSeparator();
    addMenuItem(menu, OPEN_ACTION, "Open...", KeyEvent.VK_O, modifiers);
    addMenuItem(menu, SAVE_ACTION, "Save", 's', modifiers);
    addMenuItem(menu, SAVE_AS_ACTION, "Save As...");
    /* not implemented
    addMenuItem(menu, SAVE_ALL_ACTION, "Save All");
    addMenuItem(menu, SAVE_TEST_SET_ACTION, "Save Test Set");
    */
    menu.addSeparator();
    addMenuItem(menu, PAGE_SETUP_ACTION, "Page Setup...");
    addMenuItem(menu, PRINT_ACTION, "Print...", 'p', modifiers);
    menu.addSeparator();
    addMenuItem(menu, CLOSE_ACTION, "Close", 'w', modifiers);
    addMenuItem(menu, QUIT_ACTION, "Quit", 'q', modifiers);

    mb.add(menu);
    
    menu = new JMenu("Edit");
    addMenuItem(menu, CUT_ACTION, "Cut", 'x', modifiers);
    addMenuItem(menu, COPY_ACTION, "Copy", 'c', modifiers);
    addMenuItem(menu, PASTE_ACTION, "Paste", 'v', modifiers);
    addMenuItem(menu, DELETE_ACTION, "Delete", 'd', modifiers);
    /* todo3: uncomment when undo/redo is implemented
    menu.addSeparator();
    addMenuItem(menu, UNDO_ACTION, "Undo", 'z', modifiers);
    addMenuItem(menu, REDO_ACTION, "Redo", 'y', modifiers);
    */
    /* uncomment when prefs are implemented
    menu.addSeparator();
    addMenuItem(menu, PREFERENCES_ACTION, "Preferences");
    */
    
    mb.add(menu);

    menu = new JMenu("View");
    addMenuItem(menu, NEW_VIEW_ACTION, "New View");
    if (warningsEnabled) {
      menu.addSeparator();
      warningsToggleMenuItem =
	addCBMenuItem(menu, WARNINGS_TOGGLE_ACTION, "Show Suggestions", true);
      addMenuItem(menu, CLEAR_WARNINGS_ACTION, "Clear Suggestions");
    }
    /* todo3: uncomment when zooming is implemented
    menu.addSeparator();
    addMenuItem(menu, ZOOM_IN_ACTION, "Zoom In");
    addMenuItem(menu, ZOOM_OUT_ACTION, "Zoom Out");
    addMenuItem(menu, RESET_ZOOM_ACTION, "Reset Zoom");
    */
    mb.add(menu);
      
    menu = new JMenu("Gesture");
    addMenuItem(menu, NEW_GESTURE_ACTION, "New Gesture Category");
    addMenuItem(menu, NEW_GROUP_ACTION, "New Group");
    addMenuItem(menu, NEW_TEST_SET_ACTION, "New Test Set");
    menu.addSeparator();
    addMenuItem(menu, RENAME_ACTION, "Rename...");
    addMenuItem(menu, ENABLE_ACTION, "Enable");
    addMenuItem(menu, DISABLE_ACTION, "Disable");
    menu.addSeparator();
    trainMenuItem = addMenuItem(menu, TRAIN_SET_ACTION, "Train Set",
				"Set Is Trained");
    addMenuItem(menu, ANALYZE_SET_ACTION, "Analyze Set");
    testMenuItem = addMenuItem(menu, TEST_RECOGNITION_ACTION,
			       "Test Recognition");
    mb.add(menu);

    /*
    menu = new JMenu("Expert");
    */
    
    if (debugMenuExists) {
      menu = new JMenu("Debug");
      addMenuItem(menu, VALIDATE_PARENTS_ACTION, "Validate Parents");
      addMenuItem(menu, DUMP_HUMAN_COORDS_ACTION, "Dump Human Coordinates");
      mb.add(menu);
    }

    menu = new JMenu("Help");
    addMenuItem(menu, HELP_TUTORIAL_ACTION, "Tutorial");
    addMenuItem(menu, HELP_REFERENCE_ACTION, "Reference");
    menu.addSeparator();
    addMenuItem(menu, HELP_ABOUT_ACTION, "About");
    mb.add(menu);

    //addMenuItem(menu, _ACTION, "");
    return mb;
  }

  public void doCommand(int actionID)
  {
    PrinterJob printJob;
    switch (actionID) {
      //--------------------
      // file case
    case NEW_PACKAGE_ACTION:
      MainFrame newFrame = WindowManager.createMainFrame();
      newFrame.pack();
      newFrame.show();
      updateMenuBar();
      newFrame.updateMenuBar();
      break;
    case NEW_TEST_SET_ACTION:
      doNewTestSet();
      break;
    case OPEN_ACTION:
      doOpen();
      break;
    case SAVE_ACTION:
      if (gestureFile != null) {
	doSave();
      }
      else {
	doSaveAs();
      }
      break;
    case SAVE_AS_ACTION:
      doSaveAs();
      break;
    case SAVE_ALL_ACTION:
      // todo
      break;
    case SAVE_TEST_SET_ACTION:
      // todo
      break;
    case PAGE_SETUP_ACTION:
      printJob = PrinterJob.getPrinterJob();
      if (pageFormat == null) {
	pageFormat = printJob.defaultPage();
      }
      pageFormat = printJob.pageDialog(pageFormat);
      break;
    case PRINT_ACTION:
      printJob = PrinterJob.getPrinterJob();
      final JInternalFrame activeFrame = desktop.getSelectedFrame();
      printJob.setPrintable(new Printable() {
	public int print(Graphics graphics,
			 PageFormat pageFormat,
			 int pageIndex) throws PrinterException {
	  if (pageIndex > 0) {
	    return Printable.NO_SUCH_PAGE;
	  }
	  ((Graphics2D) graphics).translate(pageFormat.getImageableX(),
					    pageFormat.getImageableY());
	  activeFrame.paint(graphics);
	  return Printable.PAGE_EXISTS;
	}
      });
      if (printJob.printDialog()) {
	try {
	  printJob.print();
	} catch (Exception ex) {
	  ex.printStackTrace();
	}
      }
      break;
    case CLOSE_ACTION:
      if (doClose()) {
	dispose();
      }
      break;
    case QUIT_ACTION:
      // todo: check for unsaved files (maybe perform close on all
      // windows?)
      if (WindowManager.closeAll()) {
	System.exit(0);
      }
      break;
    case PREFERENCES_ACTION:
      // todo
      break;
    case NEW_VIEW_ACTION:
      if (currentSelection != null) {
	for (Iterator iter = currentSelection.iterator(); iter.hasNext();) {
	  Object obj = iter.next();
	  if (obj instanceof GestureObject) {
	    desktop.showFrame((GestureObject) obj);
	  }
	}
      }
      break;
    case WARNINGS_TOGGLE_ACTION:
      warningsEnabled = warningsToggleMenuItem.getState();
      //analyzers.setAnalysisEnabled(warningsEnabled);
      trainingTree.invalidate();
      trainingTree.repaint();
      testTree.invalidate();
      testTree.repaint();
      desktop.repaint();
      firePropertyChange(NOTICE_VISIBILITY_CHANGE_PROP,
			 new Boolean(!warningsEnabled),
			 new Boolean(warningsEnabled));
      break;
    case CLEAR_WARNINGS_ACTION:
      summaryLog.clear();
      break;
    case TRAIN_SET_ACTION:
      train();
      break;
    case ANALYZE_SET_ACTION:
      // todo
      break;
    case TEST_RECOGNITION_ACTION:
      testRecognition();
      break;
    case VALIDATE_PARENTS_ACTION:
      doValidateParents();
      break;
    case HELP_TUTORIAL_ACTION:
      ReferenceManager.getManager().showTutorial(this);
      break;
    case HELP_REFERENCE_ACTION:
      ReferenceManager.getManager().showReferenceManual(this);
      break;
    case HELP_ABOUT_ACTION:
      showAboutBox();
      break;
    default:
      Commander selectionHolder = (Commander) selectionDisplay;
      if (selectionHolder != null) {
	selectionHolder.doCommand(actionID);
      }
      break;
    }
  }

  public boolean isCommandValid(int actionID)
  {
    boolean valid;
    switch (actionID) {
    case NEW_PACKAGE_ACTION:
    case NEW_TEST_SET_ACTION:
    case OPEN_ACTION:
      valid = true;
      break;
    case SAVE_ACTION:
      valid = (saveLevel != SAVED);
      break;
    case SAVE_AS_ACTION:
    case SAVE_ALL_ACTION:
    case PAGE_SETUP_ACTION:
    case PRINT_ACTION:
      valid = true;
      break;
    case CLOSE_ACTION:
      // don't enable close if this is the only window
      valid = WindowManager.getFrameCount() > 1;
      break;
    case QUIT_ACTION:
      valid = true;
      break;
    case PREFERENCES_ACTION:
      valid = false;
      break;
    case SAVE_TEST_SET_ACTION:
      // todo
      valid = false;
      break;
    case NEW_VIEW_ACTION:
      valid = (currentSelection != null) && (currentSelection.size() > 0);
      break;
    case WARNINGS_TOGGLE_ACTION:
    case CLEAR_WARNINGS_ACTION:
      valid = true;
      break;
    case ZOOM_IN_ACTION:
    case ZOOM_OUT_ACTION:
    case RESET_ZOOM_ACTION:
      // todo3: someday make a zoom widget and use it.  Enable this then.
      valid = false;
      break;
    case TRAIN_SET_ACTION:
      valid = (classifier != null) && !classifier.isTrained() &&
	!trainingInProgress;
      break;
    case ANALYZE_SET_ACTION:
      // todo: enable & implement this
      valid = false;
      break;
    case TEST_RECOGNITION_ACTION:
      // Allow the recognition of any gestureObject to be tested
      valid = false;
      if (currentSelection != null) {
	for (Iterator iter = currentSelection.iterator();
	     iter.hasNext() && !valid;) {
	  Object obj = iter.next();
	  if (obj instanceof GestureObject) {
	    valid = true;
	  }
	}
      }
      break;
    case VALIDATE_PARENTS_ACTION:
      valid = (currentSelection != null) && (currentSelection.size() > 0);
      break;
    case HELP_TUTORIAL_ACTION:
    case HELP_REFERENCE_ACTION:
    case HELP_ABOUT_ACTION:
      valid = true;
      break;
    default:
      Commander selectionHolder = (Commander) selectionDisplay;
      if (selectionHolder != null) {
	valid = selectionHolder.isCommandValid(actionID);
      }
      else {
	valid = false;
      }
      break;
    }
    return valid;
  }

  //----------------------------------------------------------------------
  private void doNewTestSet()
  {
    System.out.println("MF: doNewTestSet");
    GestureSet gs = new GestureSet();
    gs.setName(Gensym.next("testset"));
    copyStructure(gs, gesturePackage.getTrainingSet());
    gesturePackage.getTestSets().add(gs);
  }

  private void copyStructure(GestureContainer newContainer,
			     GestureContainer oldContainer)
  {
    for (Iterator iter = oldContainer.iterator(); iter.hasNext();) {
      GestureObject obj = (GestureObject) iter.next();
      if (obj instanceof GestureContainer) {
	GestureContainer oldChild = (GestureContainer) obj;
	GestureContainer newChild = null;
	try {
	   newChild = (GestureContainer) oldChild.getClass().newInstance();
	}
	catch (InstantiationException e) { }
	catch (IllegalAccessException e) { }
	if (newChild == null) {
	  // newInstance failed
	  message
	    ("WARNING: There was a problem making a new container like '" +
	     oldContainer.getName() + "'.\n");
	  continue;
	}
	newChild.setName(oldChild.getName());
	copyStructure(newChild, oldChild);
	newContainer.add(newChild);
      }
    }
  }
  
  private void doValidateParents()
  {
    if (currentSelection != null) {
      doValidateParents(currentSelection.iterator(), "SELECTION");
    }
  }

  private void doValidateParents(Iterator children, String parentName)
  {
    for (int i = 0; children.hasNext(); i++) {
      Object obj = children.next();
      if (obj instanceof Gesture) {
	Gesture gesture = (Gesture) obj;
	if (gesture.getParent() == null) {
	  System.out.println("No parent for gesture #" + i + " of " +
			     parentName);
	}
      }
      else if (obj instanceof GestureContainer) {
	GestureContainer container = (GestureContainer) obj;
	if (container.getParent() == null) {
	  System.out.println("No parent for child " + container.getName() +
			     " of " + parentName);
	}
	doValidateParents(container.iterator(), container.getName());
      }
    }
  }

  private void openFile(final GestureFile gf)
  {
    boolean tempDisableAutosave = false;
    if (gf.doesNewerAutoSaveExist()) {
      int option = JOptionPane.
	showConfirmDialog(this, "Autosave file exists for file '" +
			  gf.getFile() +
			  "' (and is newer).  Use autosave file?",
			  "Use autosave file?", JOptionPane.YES_NO_OPTION);
      /** whether to disable auto save for the new file */
      switch (option) {
      case JOptionPane.NO_OPTION:
	gf.setUseAutosave(false);
	break;
      case JOptionPane.YES_OPTION:
	message("Loading autosave file for '" + gf.getFile() + "'.");
	message("Further autosave disabled until the file is saved.");
	tempDisableAutosave = true;
	break;
      }
    }
    final boolean disableAutosave = tempDisableAutosave;
    // use a SwingWorker to do the actual read so that it doens't
    // happen on the event thread
    SwingWorker worker = new SwingWorker() {
      /** returns the GestureFile that was opened, or an exception if
          an exception occurred */
      public Object construct()
      {
	Object result;
	try {
	  gf.read();
	  result = gf;
	}
	catch (Exception e) {
	  result = e;
	}
	return result;
      }

      public void finished()
      {
	try {
	  Object result = getValue();
	  if (result instanceof Exception) {
	    if (result instanceof FileNotFoundException) {
	      String m = "Couldn't find file '" + gf.getFile().getName() +
	      "'.";
	      message(m);
	      MainFrame.this.showErrorDialog("File not found", m,
					     (Exception) result);
	    }
	    else {
	      showErrorDialog("File read error",
			      gf.getFile().getName()
			      + ": Internal error while reading file."
			      + "  (This should never happen.) " + result,
			      (Exception) result);
	    }
	  }
	  else if (result instanceof GestureFile) {
	    lastDirectory = gf.getFile().getParent();
	    if ((gestureFile == null) && (saveLevel == SAVED)) {
	      // if it's a blank that hasn't been edited, reuse the frame
	      setFile(gf);
	      setSaveLevel(gf.wasAutoSaveRead() ? AUTOSAVED : SAVED);
	      useAutoSave = !disableAutosave;
	    }
	    else {
	      MainFrame newFrame = WindowManager.createMainFrame(gf);
	      newFrame.setSaveLevel(gf.wasAutoSaveRead() ?
				    AUTOSAVED : SAVED);
	      newFrame.useAutoSave = !disableAutosave;
	      newFrame.pack();
	      newFrame.show();
	      updateMenuBar();
	      newFrame.updateMenuBar();
	    }
	  }
	  else {
	    System.err.println("BOGUS: file open SwingWorker returned non-Exception, non-GestureFile value: " + result);
	    showErrorDialog("File open error",
			    gf.getFile().getName()
			    + ": Internal error while reading file."
			    + "  (This should never happen.) " + result,
			    (Exception) result);
	  }
	}
	finally {
	  lessBusy();
	}
      }
    };
    moreBusy();
    worker.start();
  }

  private void doOpen()
  {
    JFileChooser fileChooser = new JFileChooser(lastDirectory);
    fileChooser.addChoosableFileFilter(GestureFile.getFileFilter());
    int returnVal = fileChooser.showOpenDialog(this);
    switch (returnVal) {
    case JFileChooser.APPROVE_OPTION:
      GestureFile gf = new GestureFile(fileChooser.getSelectedFile());
      openFile(gf);
      break;
    case JFileChooser.CANCEL_OPTION:
      message("Open cancelled");
      break;
    default:
      System.err.println("Bogosity from JFileChooser");
      break;
    }
  }

  private void doAutoSaveIfNecessary()
  {
    if ((saveLevel == NOT_SAVED) && (gestureFile != null) && useAutoSave) {
      summaryLog.append("Autosaving...");
      try {
	gestureFile.writeAutoSave();
	setSaveLevel(AUTOSAVED);
	summaryLog.append("done.");
      }
      catch (IOException e) {
	showFileErrorDialog(gestureFile.getFile(), "Error saving file", e);
      }
      finally {
	summaryLog.append("\n");
      }
    }
  }

  private void removeAutoSaveFile()
  {
    if (gestureFile != null) {
      File autoSaveFile = gestureFile.getAutoSaveFile();
      if (autoSaveFile.exists()) {
	if (autoSaveFile.delete()) {
	  message("Could not delete auto save file '" + autoSaveFile + "'");
	}
      }
    }
  }
  
  private void doSave()
  {
    try {
      gestureFile.write();
      setSaveLevel(SAVED);
      useAutoSave = true;
      removeAutoSaveFile();
    }
    catch (IOException e) {
      showFileErrorDialog(gestureFile.getFile(), "Error saving file", e);
    }
  }
  
  private void doSaveAs()
  {
    JFileChooser fileChooser = new JFileChooser(lastDirectory);
    fileChooser.setDialogTitle("Save As");
    fileChooser.addChoosableFileFilter(GestureFile.getFileFilter());
    int returnVal = fileChooser.showSaveDialog(this);
    switch (returnVal) {
    case JFileChooser.APPROVE_OPTION:
      File saveFile = fileChooser.getSelectedFile();
      if (saveFile.exists()) {
	int option = JOptionPane.
	  showConfirmDialog(this, "File '" + saveFile +
			    "' exists.  Overwrite it?", "Overwrite file?",
			    JOptionPane.YES_NO_OPTION);
	switch (option) {
	case JOptionPane.NO_OPTION:
	  // bail out
	  message("Save As cancelled");
	  return;
	case JOptionPane.YES_OPTION:
	  break;
	}
      }
      gestureFile = new GestureFile(saveFile, gesturePackage);
      gesturePackage.setName(saveFile.getName());
      doSave();
      updateTitle();
      lastDirectory = saveFile.getParent();
      break;
    case JFileChooser.CANCEL_OPTION:
      message("Save As cancelled");
      break;
    default:
      System.err.println("Bogosity from JFileChooser");
      break;
    }
  }

  /** If the file has changed, ask the user if they want to save it,
      and if so, do the save.  Does not dispose() the frame. */
  public boolean doClose()
  {
    boolean result = true;
    if (saveLevel != SAVED) {
      int option = JOptionPane.
	showConfirmDialog(this, "Package '" + gesturePackage.getName()
			  + "' has changed since"
			  + " it was last saved.  Save it now?",
			  "Save file?",
			  JOptionPane.YES_NO_CANCEL_OPTION);
      switch (option) {
      case JOptionPane.YES_OPTION:
	if (gestureFile == null) {
	  doSaveAs();
	}
	else {
	  doSave();
	}
	break;
      case JOptionPane.NO_OPTION:
	break;
      case JOptionPane.CANCEL_OPTION:
	result = false;
	break;
      }
    }
    removeAutoSaveFile();
    return result;
  }
  
  private void setSaveLevel(int newLevel)
  {
    if (newLevel != saveLevel) {
      saveLevel = newLevel;
      updateTitle();
      updateMenuBar();
      if ((saveLevel == SAVED) && (gestureFile != null)) {
	// remove auto-save file if it exists
	File asFile = gestureFile.getAutoSaveFile();
	if (asFile.exists())
	  asFile.delete();
      }
    }
  }

  public void setFile(GestureFile f)
  {
    gestureFile = f;
    if (f == null) {
      GesturePackage pkg = new GesturePackage();
      pkg.setName("(unnamed)");
      setGesturePackage(pkg);
    }
    else {
      setGesturePackage(gestureFile.getGesturePackage());
    }
    updateTitle();
  }

  public GestureDesktop getDesktop()
  {
    return desktop;
  }
  
  public Classifier getClassifier()
  {
    return classifier;
  }
  
  public GesturePackage getGesturePackage()
  {
    return gesturePackage;
  }
  
  public void setGesturePackage(GesturePackage gp)
  {
    if (gesturePackage != gp) {
      if (gesturePackage != null) {
	classifier.removePropertyChangeListener(classifierListener);
	gesturePackage.removePropertyChangeListener(propChangeListener);
	gesturePackage.removeCollectionListener(collectionListener);
	noticeHandler.unregisterGesturePackage();
      }
      gesturePackage = gp;
      gestureTrees.setModel(new GestureTreeModel(gesturePackage));
      if (gesturePackage != null) {
	GestureSet trainingSet = gesturePackage.getTrainingSet();
	classifier = new Classifier(trainingSet);
	classifier.addPropertyChangeListener(classifierListener);
	gesturePackage.addPropertyChangeListener(propChangeListener);
	gesturePackage.addCollectionListener(collectionListener);
	noticeHandler.registerGesturePackage(gesturePackage);
	humanGoodness = new HumanGoodness(trainingSet);
	recognizerGoodness = new RecognizerGoodness(trainingSet);
      }
      else {
	classifier = null;
	humanGoodness = null;
	recognizerGoodness = null;
      }
      analyzers.restartTasks();
    }
  }

  public SummaryLog getSummaryLog()
  {
    return summaryLog;
  }
  
  /* Make sure the frame title reflects the file state. */
  private void updateTitle()
  {
    String name;

    if (gestureFile == null) {
      name = "(unnamed)";
    }
    else {
      name = gestureFile.getFile().getName();
    }
    String saveState = (saveLevel == SAVED) ? "" : " (*)";
    String title = name + saveState + " - gdt";
    setTitle(title);
  }
  
  public void showFileErrorDialog(File f, String message, Exception e)
  {
    showErrorDialog("File error", "Error accessing file '" + f + "':" +
		    message, e);
  }

  public void showErrorDialog(final String title, final String message,
			      final Exception exception)
  {
    SwingUtilities.invokeLater(new Thread() {
      public void run() {
	if (exception == null) {
	  JOptionPane.showMessageDialog(MainFrame.this, message, title,
					JOptionPane.ERROR_MESSAGE);
	}
	else {
	  Object[] options = {"Ok", "Dump stack"};
	  int choice =
	    JOptionPane.showOptionDialog(MainFrame.this, message, title,
					 JOptionPane.DEFAULT_OPTION,
					 JOptionPane.ERROR_MESSAGE, null,
					 options, options[0]);
	  if (choice == 1) {
	    // stack dump
	    exception.printStackTrace();
	  }
	}
      }
    });
  }

  protected void showPath(TreePath path)
  {
    if (path != null) {
      TreePath[] paths = { path };
      showPaths(paths);
    }
  }

  /*
  protected void showPaths(TreePath[] paths)
  {
    showPaths(paths, trainingTree);
    showPaths(paths, testTree);
  }
  */
  
  protected void showPaths(TreePath[] paths)
  {
    for (int i = 0; i < paths.length; i++) {
      Object lastComponent = paths[i].getLastPathComponent();
      Object selectedObj = GestureTree.getUserObject(lastComponent);
      if (selectedObj != null) {
	int pathLength = paths[i].getPathCount();
	if (selectedObj instanceof GestureObject) {
	  GestureContainer parent =
	    ((GestureObject) selectedObj).getParent();
	  String parentName;
	  if (parent != null) {
	    parentName = parent.getName();
	  }
	  else {
	    parentName = "(none)";
	  }
	  desktop.showFrame((GestureObject) selectedObj, parentName);
	}
	else {
	  System.out.println("Can't display " + selectedObj +
			     "[" + selectedObj.getClass().getName() +
			     "]");
	}
	// else it's the root, so don't show it
      }
    }
  }

  /** Append a message (+ newline) to the log.  This is safe to invoke
      from any thread. */
  public void message(final String string)
  {
    if (SwingUtilities.isEventDispatchThread()) {
      summaryLog.message(string);
    }
    else {
      SwingUtilities.invokeLater(new Runnable() {
	public void run() {
	  summaryLog.message(string);
	}
      });
    }
  }

  /** Update the display of the metrics.  Safe to call from any thread. */
  public void updateMetrics()
  {
    String humanString, recognizerString;
    if (humanGoodness != null) {
      humanString = Misc.toString(humanGoodness.getGoodness(), 3);
    }
    else {
      humanString = "N/A";
    }
    if (recognizerGoodness != null) {
      recognizerString = Misc.toString(recognizerGoodness.getGoodness(), 3);
    }
    else {
      recognizerString = "N/A";
    }
    if (SwingUtilities.isEventDispatchThread()) {
      updateMetricsImpl(humanString, recognizerString);
    }
    else {
      final String h = humanString;
      final String r = recognizerString;
      SwingUtilities.invokeLater(new Runnable() {
	public void run() {
	  updateMetricsImpl(h, r);
      	}
      });
    }
  }

  /** Really updates the metrics.  Should only be called from the
      event dispatct thread. */
  protected void updateMetricsImpl(String humanString,
				   String recognizerString)
  {
    humanGoodnessLabel.setText(humanString);
    humanGoodnessLabel.setForeground(Color.black);
    humanGoodnessLabel.repaint();
    recognizerGoodnessLabel.setText(recognizerString);
    recognizerGoodnessLabel.setForeground(Color.black);
    recognizerGoodnessLabel.repaint();
  }
  
  public Analyzers getAnalyzers()
  {
    return analyzers;
  }

  public NoticeHandler getNoticeHandler()
  {
    return noticeHandler;
  }
  
  private void packageChanged()
  {
    System.out.println("packageChanged");
    if (trainingInProgress) {
      System.err.println("BOGOSITY: the set was changed during training");
    }
    setSaveLevel(NOT_SAVED);
    updateTitle();
    updateInputArea();
    updateMenuBar();
    //humanGoodnessLabel.setBackground(Color.gray);
    //recognizerGoodnessLabel.setBackground(Color.gray);
    humanGoodnessLabel.setForeground(Color.darkGray);
    recognizerGoodnessLabel.setForeground(Color.darkGray);
  }
  
  /** update the selection and its owner */
  protected void updateSelection(JComponent origin)
  {
    if (!inUpdateSelection) {
      try {
	inUpdateSelection = true;
	if (selectionDisplay != origin) {
	  // deselect old selection display
	  if (selectionDisplay == desktop) {
	    //desktop.setSelectedFrame(null);
	    JInternalFrame selectedFrame = desktop.getSelectedFrame();
	    if (selectedFrame != null) {
	      try {
		selectedFrame.setSelected(false);
	      }
	      catch (PropertyVetoException e) {
	      }
	    }
	  }
	  else if (selectionDisplay instanceof GestureTree) {
	    ((GestureTree) selectionDisplay).clearSelection();
	  }
	  else if (selectionDisplay != null) {
	    System.err.println("ERROR: selection owned by unknown widget: "
			       + selectionDisplay);
	  }
	  selectionDisplay = origin;
	}
	if (selectionDisplay == desktop) {
	  currentSelection = desktop.getSelectedGestureObjects();
	}
	else if (selectionDisplay instanceof GestureTree) {
	  currentSelection = ((GestureTree) selectionDisplay).
	    getSelectedObjects();
	}
	else {
	  System.err.println("ERROR: selection changed by unknown widget: "
			     + selectionDisplay);
	}
	updateMenuBar();
      }
      finally {
	inUpdateSelection = false;
      }
    }
  }
  
  /** Update the enabled state of the inputArea */
  protected void updateInputArea()
  {
    GestureAcceptor acceptor = (GestureAcceptor) selectionDisplay;
    boolean on = !trainingInProgress && acceptor.canAcceptGesture();

    /*
    System.out.println("Input area is on: " + on);
    */
    inputArea.setEnabled(on);
    Border newBorder;
    if (on) {
      newBorder = BorderFactory.
	createTitledBorder(null, acceptor.getInputGestureTitle());
    }
    else if (trainingInProgress) {
      newBorder = BorderFactory.
	createTitledBorder(null, "Training in progress...");
    }
    else {
      newBorder = null;
    }
    inputArea.setBorder(newBorder);
  }

  /** Update the enabled/disabled status of the menu bar */
  protected void updateMenuBar()
  {
    //System.out.println("updating menubar");
    JMenuBar mb = getRootPane().getJMenuBar();
    updateMenuElements(mb.getSubElements());
  }

  /** Update the enabled/disabled status of several MenuElements */
  protected void updateMenuElements(MenuElement[] elements)
  {
    if (elements != null) {
      for (int i = 0; i < elements.length; i++) {
	Component comp = elements[i].getComponent();
	if (comp instanceof JMenuItem) {
	  updateMenuItem((JMenuItem) comp);
	}
	updateMenuElements(elements[i].getSubElements());
      }
    }
  }

  protected void updateMenuItem(JMenuItem item)
  {
    Action action = item.getAction();
    if (action != null) {
      Integer intID = (Integer) action.getValue(ACTION_ID);
      if (intID != null) {
	int id = intID.intValue();
	boolean on;
	if ((dataReaderCount > 0) &&
	    (GDTUtil.contains(CHANGE_ACTIONS, id))) {
	  on = false;
	}
	else {
	  on = isCommandValid(id);
	}
	action.setEnabled(on);
      }
    }
  }
  
  /** make sure the classifier is trained */
  protected void train()
  {
    if (!classifier.isTrained()) {
      dataReaderCount++;
      trainingInProgress = true;
      updateMenuItem(trainMenuItem);
      updateInputArea();
      summaryLog.append("Training the recognizer... ");
      final JButton stopButton =
	summaryLog.appendButton("Stop", new ActionListener() {
	  public void actionPerformed(ActionEvent e) {
	    trainingWorker.interrupt();
	  }
	});
      stopButton.setEnabled(true);
      summaryLog.append("\n");
      
      trainingWorker = new SwingWorker() {
	/** returns null if training successful, otherwise returns an
	    exception */
	public Object construct()
	{
	  try {
	    classifier.train();
	  }
	  catch (TrainingException e) {
	    return e;
	  }
	  catch (InterruptedException e) {
	    return e;
	  }
	  catch (Exception e) {
	    System.err.println("WARNING: an unexpected exception occurred: "
			       + e);
	    e.printStackTrace();
	    return e;
	  }
	  return null;
	}

	public void finished()
	{
	  stopButton.setEnabled(false);
	  Object result = getValue();
	  if (result == null) {
	    message("Training succeeded");
	  }
	  else if (result instanceof InterruptedException) {
	    message("Training stopped");
	  }
	  else {
	    message("Training failed: " + result.toString());
	    // show a dialog if it's a bizarre error (not a
	    // TrainingException)
	    if (!(result instanceof TrainingException)) {
	      showErrorDialog("Training failed",
			      "Training failed",
			      (Exception) result);
	    }
	  }
	  trainingInProgress = false;
	  dataReaderCount--;
	  updateMenuBar();
	  updateInputArea();
	}
      };
      trainingWorker.start();
    }
  }
  
  public void recognizeGesture(final Gesture gesture)
  {
    if (recognizedCategory != null) {
      recognizedCategory.unsetProperty(CORRECT_RECOG_PROP);
      recognizedCategory = null;
    }
    train();
    SwingWorker worker = new SwingWorker() {
      /** returns result of classifier, or an Exception if one
          occurred */
      public Object construct()
      {
	// if training is happening, wait for it
	if (trainingWorker != null) {
	  Object trainingResult = trainingWorker.get();
	  if (trainingResult instanceof Exception) {
	    return trainingResult;
	  }
	}
	return classifier.classifyWithoutTraining(gesture);
      }

      public void finished()
      {
	Object result = getValue();
	if (result instanceof InterruptedException) {
	  message("Recognition was stopped");
	}
	else if (result instanceof TrainingException) {
	  showErrorDialog("Training failed",
			  "Could not train recognizer.  Try adding more gestures or more gesture categories.",
			  (Exception) result);
	}
	else if (result instanceof Exception) {
	  message("Recognition failed: " + result.toString());
	  showErrorDialog("Recognition failed",
			  "Recognition failed",
			  (Exception) result);
	}
	else {
	  if ((result == null) ||
	      (((Classifier.Result) result).category == null)) {
	    message("No match");
	  }
	  else {
	    Classifier.Result r = (Classifier.Result) result;
	    String catName = r.category.getName();
	    message("Recognized as: " + catName + "\t" +
		    Misc.toString(r.accuracy, 3) + "\t" +
		    Misc.toString(r.distToMean, 3));
	    r.category.setProperty(CORRECT_RECOG_PROP, r);
	    recognizedCategory = r.category;
	  }
	}
	dataReaderCount--;
	updateMenuBar();
      }
    };
    dataReaderCount++;
    updateMenuBar();
    worker.start();
  }

  private void testRecognition()
  {
    if (!classifier.isTrained()) {
      summaryLog.append("Need to train before testing recognition. ");
      train();
    }
    final Iterator selectionIterator = currentSelection.iterator();
    
    final JButton stopButton = new JButton("Stop");
    stopButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	testWorker.interrupt();
      }
    });
    stopButton.setMargin(new Insets(0,2,0,2));
    testWorker = new SwingWorker() {
      /** returns null if test successful, otherwise returns an
	  exception */
      public Object construct()
      {
	if (trainingWorker != null) {
	  // wait for it
	  Object trainingResult = trainingWorker.get();
	  if (trainingResult instanceof Exception) {
	    return trainingResult;
	  }
	}
	SwingUtilities.invokeLater(new Runnable() {
	  public void run() {
	    summaryLog.append("Testing recognition... ");
	    summaryLog.append(stopButton);
	    summaryLog.append("\n");
	  }
	});
	List misrecogGestures = null;
	try {
	  misrecogGestures = classifier.testRecognition(selectionIterator);
	}
	catch (TrainingException e) {
	  return e;
	}
	catch (InterruptedException e) {
	  return e;
	}
	catch (Exception e) {
	  System.err.println("WARNING: unexpected exception: " + e);
	  e.printStackTrace();
	  return e;
	}
	return misrecogGestures;
      }

      public void finished()
      {
	stopButton.setEnabled(false);
	Object result = getValue();
	if (result instanceof List) {
	  List misrecogGestures = (List) result;
	  int misrecogCount = misrecogGestures.size();
	  /*
	  System.out.println("MF: recog tested: " + misrecogCount +
			     " misrecognitions");
	  */
	  summaryLog.append("Recognition tested.");
	  if (misrecogCount > 0) {
	    summaryLog.append("\n");
	    Notice notice = new MisrecognitionNotice(MainFrame.this,
						     misrecogGestures);
	    notice.displaySummary(summaryLog);
	  }
	  else {
	    summaryLog.append(" All gestures recognized correctly.\n");
	  }
	}
	else if (result instanceof InterruptedException) {
	  message("Recognition testing stopped");
	}
	else {
	  message("Recognition testing failed: " + result.toString());
	  showErrorDialog("Recognition testing failed",
			  "Recognition testing failed",
			  (Exception) result);
	}
	dataReaderCount--;
	updateMenuItem(testMenuItem);
	updateInputArea();
      }
    };
    dataReaderCount++;
    testWorker.start();
  }

  protected void showAboutBox()
  {
    JLabel label = new JLabel("quill: Created by A. Chris Long");
    JOptionPane.showMessageDialog(this, label, "quill: About",
				  JOptionPane.INFORMATION_MESSAGE);
  }
  
  public void moreBusy()
  {
    //System.err.println(">>> moreBusy\t" + busyCount);
    busyCount++;
    if (busyCount == 1) {
      Component glassPane = getGlassPane();
      glassPane.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
      glassPane.setVisible(true);
    }
  }

  public void lessBusy()
  {
    //System.err.println("<<< lessBusy\t" + busyCount);
    if (busyCount == 0) {
      System.err.println("WARNING: BOGOSITY: lessBusy() called when system is not busy");
      debug.printStackTrace(System.err);
    }
    else {
      busyCount--;
      if (busyCount == 0) {
	Component glassPane = getGlassPane();
	glassPane.setCursor(Cursor.
			    getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	glassPane.setVisible(false);
      }
    }
  }

  /** Set the cursor to be the busy cursor, run the runnable on the
      event thread, and set the cursor back.  Really long-running
      tasks should probably run on a separate thread entirely. */
  public void doLongTask(final Runnable runnable)
  {
    moreBusy();
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
	try {
	  runnable.run();
	}
	finally {
	  lessBusy();
	}
      }
    });
  }

  /** Set the background color of the summary log.  Can be called from
      any thread. */
  public void setLogBackground(final Color c)
  {
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
	getSummaryLog().setTextBackground(c);
      }
    });
  }
  
  protected class MyPropertyChangeListener
    implements PropertyChangeListener {
    public void propertyChange(PropertyChangeEvent e)
    {
      e = Properties.getRootEvent(e);
      if (Properties.isPropertyPersistent(e.getPropertyName())) {
	/*
	System.out.println("packageChanged due to prop " +
			   e.getPropertyName());
	*/
	packageChanged();
      }
    }
  }

  protected class MyCollectionListener implements CollectionListener {
    public void elementAdded(CollectionEvent e)
    {
      System.out.println("add");
      packageChanged();
    }
    
    public void elementRemoved(CollectionEvent e)
    {
      System.out.println("remove");
      packageChanged();
    }
    
    public void elementChanged(CollectionEvent e)
    {
      System.out.println("change");
      packageChanged();
    }
  }

}
