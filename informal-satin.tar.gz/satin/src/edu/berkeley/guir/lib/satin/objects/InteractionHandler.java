//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import java.io.Serializable;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;

/**
 *
 *
 *
 * <P>
 * Everything in here is in local coordinates. That is, (0,0) is defined to be
 * the top-left corner of the GraphicalObject, without any transforms applied
 * anywhere.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 01 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class InteractionHandler 
   implements SatinConstants, Serializable, Cloneable {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -6003131899410378232L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   protected GraphicalObjectImpl attach;     // the GraphicalObject we are attached to
   protected Interpreter         cmdintrp;   // the gesture interpreter
   protected Interpreter         inkintrp;   // the ink interpreter

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTOR   =======================================================

   /**
    * For cloning.
    */
   private InteractionHandler() {
   } // of default constructor

   //===========================================================================

   /**
    * Copy constructor.
    */
   public InteractionHandler(InteractionHandler handler) {
      this.attach   = handler.attach;
      this.cmdintrp = (Interpreter) handler.cmdintrp.clone();
      this.inkintrp = (Interpreter) handler.inkintrp.clone();
   } // of copy constructor

   //===========================================================================

   /**
    * 
    */
   public InteractionHandler(GraphicalObjectImpl gob) {
      attach    = gob;
      setGestureInterpreter(new DefaultInterpreterImpl());
      setInkInterpreter(new DefaultInterpreterImpl());
   } // of constructor

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================



   //===========================================================================
   //===    MODIFIER METHODS   =================================================

   /**
    * Set the GraphicalObject this handler is attached to.
    */
   public GraphicalObject setAttachedGraphicalObject(GraphicalObjectImpl gob) {
      attach = gob;
      cmdintrp.setAttachedGraphicalObject(gob);
      inkintrp.setAttachedGraphicalObject(gob);
      return (gob);
   } // of setAttachedGraphicalObject

   //===    MODIFIER METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===    INTERPRETER METHODS   ==============================================

   public Interpreter getGestureInterpreter() {
      return (cmdintrp);
   } // of getGestureInterpreter

   //===========================================================================

   public Interpreter setGestureInterpreter(Interpreter intrp) {
      cmdintrp = intrp;
      intrp.setAttachedGraphicalObject(attach);
      return (intrp);
   } // of setGestureInterpreter

   //===========================================================================

   public Interpreter getInkInterpreter() {
      return (inkintrp);
   } // of getInkInterpreter

   //===========================================================================

   public Interpreter setInkInterpreter(Interpreter intrp) {
      inkintrp = intrp;
      intrp.setAttachedGraphicalObject(attach);
      return (intrp);
   } // of setInkInterpreter

   //===    INTERPRETER METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   DISPATCHING METHODS   ===============================================

   /**
    *
    */
   public void onNewStroke(NewStrokeEvent evt) {
      //// 1. Preprocess the stroke as a gesture first.
      if (evt.isConsumed() == true) {
         return;
      }
      attach.preProcessNewStroke(evt);

      //// 2. Redispatch the stroke.
      if (evt.isConsumed() == true) {
         return;
      }
      attach.redispatchNewStroke(evt);

      //// 3. Postprocess the stroke as ink.
      if (evt.isConsumed() == true) {
         return;
      }
      attach.postProcessNewStroke(evt);

      //// 4. Handle the stroke ourself.
      if (evt.isConsumed() == true) {
         return;
      }
      attach.handleNewStroke(evt);
   } // of onNewStroke

   //-----------------------------------------------------------------

   public void preProcessNewStroke(NewStrokeEvent evt) {
      if (cmdintrp.isEnabled()          == true && 
          cmdintrp.isEventAccepted(evt) == true) {
         cmdintrp.handleNewStroke(evt);
      }
   } // of preprocessNewStroke

   //-----------------------------------------------------------------

   public void redispatchNewStroke(NewStrokeEvent evt) {
   } // of redispatchNewStroke

   //-----------------------------------------------------------------

   public void postProcessNewStroke(NewStrokeEvent evt) {
      if (inkintrp.isEnabled()          == true &&
          inkintrp.isEventAccepted(evt) == true) {
         inkintrp.handleNewStroke(evt);
      }
   } // of postProcessNewStroke

   //-----------------------------------------------------------------

   public void handleNewStroke(NewStrokeEvent evt) {
   } // of handleNewStroke

   //===========================================================================

   public void onUpdateStroke(UpdateStrokeEvent evt) {
      //// 1. Preprocess the stroke as a gesture first.
      if (evt.isConsumed() == true) {
         return;
      }
      attach.preProcessUpdateStroke(evt);

      //// 2. Redispatch the stroke.
      if (evt.isConsumed() == true) {
         return;
      }
      attach.redispatchUpdateStroke(evt);

      //// 3. Postprocess the stroke as ink.
      if (evt.isConsumed() == true) {
         return;
      }
      attach.postProcessUpdateStroke(evt);

      //// 4. Handle the stroke ourself.
      if (evt.isConsumed() == true) {
         return;
      }
      attach.handleUpdateStroke(evt);
   } // of onUpdateStroke

   //-----------------------------------------------------------------

   public void preProcessUpdateStroke(UpdateStrokeEvent evt) {
      if (cmdintrp.isEnabled()          == true &&
          cmdintrp.isEventAccepted(evt) == true) {
         cmdintrp.handleUpdateStroke(evt);
      }
   } // of preprocessUpdateStroke

   //-----------------------------------------------------------------

   public void redispatchUpdateStroke(UpdateStrokeEvent evt) {
   } // of redispatchUpdateStroke

   //-----------------------------------------------------------------

   public void postProcessUpdateStroke(UpdateStrokeEvent evt) {
      if (inkintrp.isEnabled()          == true &&
          inkintrp.isEventAccepted(evt) == true) {
         inkintrp.handleUpdateStroke(evt);
      }
   } // of postProcessUpdateStroke

   //-----------------------------------------------------------------

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
   } // of handleUpdateStroke

   //===========================================================================

   public void onSingleStroke(SingleStrokeEvent evt) {
      //// 1. Preprocess the stroke as a gesture first.
      if (evt.isConsumed() == true) {
         return;
      }
      //debug.println(GraphicalObjectLib.toShortString(attach) + ": preprocess");
      attach.preProcessSingleStroke(evt);

      //// 2. Redispatch the stroke.
      if (evt.isConsumed() == true) {
         return;
      }
      //debug.println(GraphicalObjectLib.toShortString(attach) + ": redispatch");
      attach.redispatchSingleStroke(evt);

      //// 3. Postprocess the stroke as ink.
      if (evt.isConsumed() == true) {
         return;
      }
      //debug.println(GraphicalObjectLib.toShortString(attach) + ": postprocess");
      attach.postProcessSingleStroke(evt);

      //// 4. Handle the stroke ourself.
      if (evt.isConsumed() == true) {
         return;
      }
      //debug.println(GraphicalObjectLib.toShortString(attach) + ": handle");
      attach.handleSingleStroke(evt);
      
      //debug.println();
   } // of onSingleStroke

   //-----------------------------------------------------------------

   public void preProcessSingleStroke(SingleStrokeEvent evt) {
      if (cmdintrp.isEnabled()          == true &&
          cmdintrp.isEventAccepted(evt) == true) {
         cmdintrp.handleSingleStroke(evt);
      }
   } // of preprocessSingleStroke

   //-----------------------------------------------------------------

   public void redispatchSingleStroke(SingleStrokeEvent evt) {
   } // of redispatchSingleStroke

   //-----------------------------------------------------------------

   public void postProcessSingleStroke(SingleStrokeEvent evt) {
      if (inkintrp.isEnabled()          == true &&
          inkintrp.isEventAccepted(evt) == true) {
         inkintrp.handleSingleStroke(evt);
      }
   } // of postProcessSingleStroke

   //-----------------------------------------------------------------

   public void handleSingleStroke(SingleStrokeEvent evt) {
   } // of handleSingleStroke

   //===   DISPATCHING METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 1. Append data.
      strbuf.append("Gesture Interpreter: " + cmdintrp.toString() + "\n");
      strbuf.append("Ink Interpreter:     " + inkintrp.toString());

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (new InteractionHandler(this));
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
