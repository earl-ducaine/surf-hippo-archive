package edu.berkeley.guir.damask.event;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.component.Control;

/** 
 * A source of ControlVoiceEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-01-2004 James Lin
 *                               Created ControlVoiceEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-01-2004
 */
public class ControlVoiceEventSource {
   
   private Vector/*<ControlVoiceListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public synchronized void addControlVoiceListener(final ControlVoiceListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public synchronized void removeControlVoiceListener(
      final ControlVoiceListener listener) {

      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires promptTextChanged events to listeners.
    */
   public void firePromptTextChanged(final Control e) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ControlVoiceEvent event =
         new ControlVoiceEvent(
            e,
            ControlVoiceEvent.PROMPT_TEXT_CHANGED,
            ControlVoiceEvent.ALL_CONDITIONS);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ControlVoiceListener listener = (ControlVoiceListener)i.next();
         listener.promptTextChanged(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires promptBoundsChanged events to listeners.
    */
   public void firePromptBoundsChanged(final Control e) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ControlVoiceEvent event =
         new ControlVoiceEvent(
            e,
            ControlVoiceEvent.PROMPT_BOUNDS_CHANGED,
            ControlVoiceEvent.ALL_CONDITIONS);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ControlVoiceListener listener = (ControlVoiceListener)i.next();
         listener.promptBoundsChanged(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires responseSourceChanged events to listeners.
    */
   public void fireResponseSourceChanged(final Control e) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ControlVoiceEvent event =
         new ControlVoiceEvent(
            e,
            ControlVoiceEvent.RESPONSE_SOURCE_CHANGED,
            ControlVoiceEvent.ALL_CONDITIONS);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ControlVoiceListener listener = (ControlVoiceListener)i.next();
         listener.responseSourceChanged(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires responseDestChanged events to listeners.
    */
   public void fireResponseDestChanged(final Control e, final int condition) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ControlVoiceEvent event =
         new ControlVoiceEvent(
            e, ControlVoiceEvent.RESPONSE_DEST_CHANGED, condition);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ControlVoiceListener listener = (ControlVoiceListener)i.next();
         listener.responseDestChanged(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires responseLineChanged events to listeners.
    */
   public void fireResponseLineChanged(final Control e, final int condition) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ControlVoiceEvent event =
         new ControlVoiceEvent(
            e, ControlVoiceEvent.RESPONSE_LINE_CHANGED, condition);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ControlVoiceListener listener = (ControlVoiceListener)i.next();
         listener.responseLineChanged(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires responseTextChanged events to listeners.
    */
   public void fireResponseTextChanged(final Control e) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ControlVoiceEvent event =
         new ControlVoiceEvent(
            e,
            ControlVoiceEvent.RESPONSE_TEXT_CHANGED,
            ControlVoiceEvent.ALL_CONDITIONS);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ControlVoiceListener listener = (ControlVoiceListener)i.next();
         listener.responseTextChanged(event);
      }
   }
}
