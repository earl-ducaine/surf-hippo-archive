//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import java.util.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.graphics.*;

/**
 * Let's you explicitly choose one of many views.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 20 2000, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3RC3
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class MultiplexedMultiViewImpl 
   extends DefaultMultiViewImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 3427621134004369722L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   View       currentView  = null;
   int        currentIndex = 0;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Does nothing.
    */
   public MultiplexedMultiViewImpl() {
      commonInitializations();
   } // of default constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      //// 1. Do initializations.
      setName("MultiplexedMultiViewImpl");
   } // of method

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * If no views are currently contained, makes the first view added the
    * current view.
    */
   public View add(View v) {
      super.add(v);
      if (currentView == null) {
         currentView = v;
      }
      return (v);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set which view is active.
    */
   public void setCurrent(int index) {
      currentIndex = index;
      currentView  = get(index);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set which view is active.
    */
   public void setCurrent(View v) {
      if (this.contains(v) == true) {
         currentView = v;
      }
      else {
         throw new RuntimeException("Does not contain this view");
      }
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   public Polygon2D getBoundingPoints2DRef() {
      return (currentView.getBoundingPoints2DRef());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Modified from parent class to just return the currently selected view.
    */
   protected Iterator getValidViews() {
      LinkedList list = new LinkedList();
      list.add(currentView);
      return (list.iterator());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Checks if the selected view is visible.
    */
   public boolean isVisible() {
      return (currentView.isVisible());
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   RENDERING METHODS   =================================================

   public void render(SatinGraphics g) {
      if (currentView != null) {
         currentView.render(g);
      }
   } // of method

   //===   RENDERING METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================


   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new MultiplexedMultiViewImpl()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Clone chain.
    */
   protected MultiplexedMultiViewImpl clone(MultiplexedMultiViewImpl vm) {
      //// 1. Clone chain.
      super.clone(vm);

      //// 2. Do clone work.
      vm.setCurrent(this.currentIndex);

      //// 3. Return.
      return (vm);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
