
Poly-pen Version 0.3.5
======================

This is poly-pen, a graphic proxy layer for Common Lisp.

It links hi-level operations to low-level back-ends libraries.  It
offers a simple interface to image generation and a few hi-level
operations like plots and color maps.  You can find example images
with the generation code in the index.html file.

It's installable via ASDF, should know the drill.  Check index.html
(or doc.pdf) for a basic tutorial, check the code and play in the REPL
for more.

Updated should be announced at http://ygingras.net/poly-pen

This release adds Gimp gradients support.
