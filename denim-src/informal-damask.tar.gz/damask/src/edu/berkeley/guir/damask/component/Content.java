package edu.berkeley.guir.damask.component;

import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.event.ContentEventSource;
import edu.berkeley.guir.damask.event.ContentListener;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.berkeley.guir.lib.collection.Map2D;

/** 
 * A piece of content, which can be an image, a string, or a collection of
 * strokes (represented as a set of GeneralPaths).
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-05-2003 James Lin
 *                               Created Content (which has been renamed
 *                                                several times)
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-05-2003
 */
public class Content extends Control {

   //---------------------------------------------------------------------------

   public static class DisplayMode {
      private String name;

      private DisplayMode(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }

   public static final DisplayMode INK = new DisplayMode("Ink");
   public static final DisplayMode TEXT = new DisplayMode("Text");
   public static final DisplayMode IMAGE = new DisplayMode("Picture");

   private static final DisplayMode[] SUPPORTED_DISPLAY_MODES =
      { INK, TEXT, IMAGE };
   
//   private ElementContainerListener pageRegionHandler = new PageRegionHandler();

   /**
    * Returns a collection of devices that is supported by Damask. 
    */
   public static Collection/*<DisplayMode>*/ getSupportedDisplayModes() {
      return Collections.unmodifiableCollection(
         Arrays.asList(SUPPORTED_DISPLAY_MODES));
   }

   //---------------------------------------------------------------------------

   private static final int DEFAULT_FONT_SIZE =
      DamaskAppUtils.getDefaultFont().getSize();

   private String text = "";
   private boolean syncPromptTextWithText = true;
   private Map/*<DeviceType, Integer>*/ textSize = new HashMap();
   private List/*<GeneralPath>*/ strokes = new ArrayList();
   private BufferedImage image = null;
   private Map/*<DisplayMode, Rectangle2D>*/ fullSize = new HashMap();
   private Map2D/*<DeviceType, DisplayMode, Double>*/ stretchX = new Map2D();
   private Map2D/*<DeviceType, DisplayMode, Double>*/ stretchY = new Map2D();
   private Map/*<DeviceType, DisplayMode>*/ preferredDisplayMode =
      new HashMap();

   private ContentEventSource contentEventSource = new ContentEventSource();

   //===========================================================================

   /**
    * Constructs an empty piece of content.
    */
   public Content(final DeviceType deviceType) {
      super(deviceType);
      init();
   }

   //---------------------------------------------------------------------------

   /**
    * Constructs a piece of content with the specified device type, copying
    * properties from the specified content.
    */
   public Content(final Content content, final DeviceType deviceType) {
      super(content, deviceType);
      init();
      copyData(content, this);
   }

   //---------------------------------------------------------------------------

   /**
    * Constructs a piece of content with the given string.
    */
   public Content(final DeviceType deviceType, final String text) {
      this(deviceType);
      this.text = text;
      setFullSizeBounds(
         TEXT,
         DamaskAppUtils.getRenderedTextBounds(text, DEFAULT_FONT_SIZE));
      if (isVisibleToDeviceType(DeviceType.VOICE)) {
         super.setVoicePromptText(text);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Constructs a piece of content with the given ink stroke.
    */
   public Content(final DeviceType deviceType, final GeneralPath stroke) {
      this(deviceType);
      strokes.add(stroke);

      setFullSizeBounds(INK, stroke.getBounds2D());
      if (isVisibleToDeviceType(DeviceType.VOICE)) {
         super.setVoicePromptText(Response.NULL_DISPLAY_STRING);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Constructs a piece of content with the given collection of ink strokes.
    */
   public Content(
      final DeviceType deviceType,
      final Collection/*<GeneralPath>*/ strokes) {
         
      this(deviceType);
      this.strokes = new ArrayList(strokes);
      
      setFullSizeBounds(INK, DamaskAppUtils.getUnionBounds(strokes));
      if (isVisibleToDeviceType(DeviceType.VOICE)) {
         super.setVoicePromptText(Response.NULL_DISPLAY_STRING);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Constructs a piece of content with the given image.
    */
   public Content(final DeviceType deviceType, final BufferedImage image) {
      this(deviceType);
      this.image = image;
      
      setFullSizeBounds(
         IMAGE,
         new Rectangle2D.Double(
            image.getMinX(),
            image.getMinY(),
            image.getWidth(),
            image.getHeight()));
      if (isVisibleToDeviceType(DeviceType.VOICE)) {
         super.setVoicePromptText(Response.NULL_DISPLAY_STRING);
      }
   }

   //---------------------------------------------------------------------------
   
   private void init() {
      // Initialize table of font sizes
      final int defaultFontSize = DamaskAppUtils.getDefaultFont().getSize();
      for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
         i.hasNext();
         ) {

         final DeviceType aDeviceType = (DeviceType)i.next();
         textSize.put(aDeviceType, new Integer(defaultFontSize));
      }
   }

   //===========================================================================

   /**
    * Returns the sketched version of this piece of content.
    * 
    * @return a collection of GeneralPaths
    */
   public Collection/*<GeneralPath>*/ getStrokes() {
      return strokes;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the sketched version of this piece of content to the specified
    * collection of ink strokes.
    */
   public void setStrokes(final Collection/*<GeneralPath>*/ strokes) {
      this.strokes = new ArrayList(strokes);
      setFullSizeBounds(
         INK,
         DamaskAppUtils.getUnionBounds(strokes));
      
      fireStrokesChanged();
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the specified stroke to the sketched version of this piece of
    * content.
    */
   public void addStroke(final GeneralPath stroke) {
      strokes.add(stroke);
      
      final Rectangle2D oldFullSizeBounds = getFullSizeBounds(INK);
      if (oldFullSizeBounds == null) {
         setFullSizeBounds(INK, stroke.getBounds2D());
      }
      else {
         setFullSizeBounds(
            INK,
            stroke.getBounds2D().createUnion(oldFullSizeBounds));
      }
      
      fireStrokeAdded(stroke);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the sketched version of this piece of content to the specified
    * collection of ink strokes.
    */
   public void removeStroke(final GeneralPath stroke) {
      final int index = strokes.indexOf(stroke);
      if (index != -1) {
         strokes.remove(stroke);
         setFullSizeBounds(
            INK,
            DamaskAppUtils.getUnionBounds(strokes));
         fireStrokeRemoved(stroke);
      }
   }

   //===========================================================================

   /**
    * Returns the text version of this piece of content.
    */
   public String getText() {
      return text;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the text version of this piece of content to the specified string.
    */
   public void setText(final String string) {
      text = string;
      setFullSizeBounds(
         TEXT,
         DamaskAppUtils.getRenderedTextBounds(text, DEFAULT_FONT_SIZE));
      fireTextChanged();
      
      if (isVisibleToDeviceType(DeviceType.VOICE)) {
         if (syncPromptTextWithText) {
            super.setVoicePromptText(string);
         }
      }
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the text of the voice prompt view of this control, and changes the
    * bounds to fit the text.
    */
   // @Override
   public void setVoicePromptText(final String text) {
      if (syncPromptTextWithText) {
         setText(text);
      }
      else {
         super.setVoicePromptText(text);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns whether the text in the voice prompt is kept consistent with
    * the text of this content.
    */
   public boolean isPromptTextSyncedWithText() {
      return syncPromptTextWithText;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets whether the text in the voice prompt is kept consistent with
    * the text of this content.
    */
   public void setPromptTextSyncedWithText(final boolean flag) {
      syncPromptTextWithText = flag;
      if (flag) {
         firePromptTextIsSyncedWithText();
      }
      else {
         firePromptTextIsUnsyncedWithText();
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Returns whether this piece of content is a voice placeholder that
    * can be replaced.
    */
   public boolean isVoicePlaceholder() {
      return (getDeviceType() == DeviceType.VOICE) &&
             syncPromptTextWithText &&
             (text.length() == 0);
   }

   //===========================================================================

   /**
    * Returns the font size of the text version of this piece of content.
    */
   public int getTextSize(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      return ((Integer)textSize.get(deviceType)).intValue();
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the font size of the text version of this piece of content.
    */
   public void setTextSize(final DeviceType deviceType, final int size) {
      final Rectangle2D fullBounds = getFullSizeBounds(TEXT);
      final Rectangle2D newBounds =
         DamaskAppUtils.getRenderedTextBounds(text, size);

      final double scaleX;
      if ((fullBounds == null) || (fullBounds.getWidth() == 0)) {
         scaleX = 1;
      }
      else {
         scaleX = newBounds.getWidth() / fullBounds.getWidth();
      }
      final double scaleY;
      if ((fullBounds == null) || (fullBounds.getHeight() == 0)) {
         scaleY = 1;
      }
      else {
         scaleY = newBounds.getHeight() / fullBounds.getHeight();
      }

      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext();
         ) {

         final DeviceType aDeviceType = (DeviceType)i.next();
         textSize.put(aDeviceType, new Integer(size));
         
         setStretchX(aDeviceType, TEXT, scaleX);
         setStretchY(aDeviceType, TEXT, scaleY);
         
         if (aDeviceType == DeviceType.VOICE) {
            setVoicePromptBounds(newBounds);
         }
         else if (getPreferredDisplayMode(aDeviceType) == TEXT) {
            super.setBounds(aDeviceType, newBounds);
         }
         fireTextChanged();
      }
   }

   //===========================================================================

   /**
    * Returns the image version of this piece of content.
    */
   public BufferedImage getImage() {
      return image;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the image version of this piece of content to the specified image.
    */
   public void setImage(final BufferedImage image) {
      this.image = image;
      setFullSizeBounds(
         IMAGE,
         new Rectangle2D.Double(
            image.getMinX(),
            image.getMinY(),
            image.getWidth(),
            image.getHeight()));
      fireImageChanged();
   }

   //===========================================================================

   /**
    * Returns the preferred display mode of this content for the specified
    * device type.
    */
   public DisplayMode getPreferredDisplayMode(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      DisplayMode result = (DisplayMode)preferredDisplayMode.get(deviceType);
      
      if (result == null) {
         if (getImage() != null) {
            result = IMAGE;
         }
         else if (getText().length() != 0) {
            result = TEXT;
         }
         else {
            result = INK;
         }
         preferredDisplayMode.put(deviceType, result);
      }
      
      return result;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the preferred display mode of this content for the specified
    * device type.
    */
   public void setPreferredDisplayMode(
      final DeviceType deviceType,
      final DisplayMode displayMode) {

      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext(); ) {
         
         final DeviceType aDeviceType = (DeviceType)i.next();
         final DisplayMode oldMode = getPreferredDisplayMode(aDeviceType);
         preferredDisplayMode.put(aDeviceType, displayMode);

         firePreferredDisplayModeChanged(aDeviceType, oldMode);

         // Change bounds reported by getBounds
         final Rectangle2D fullBounds = getFullSizeBounds(displayMode);
         if (fullBounds != null) {
            super.setBounds(
               aDeviceType,
               new Rectangle2D.Double(
                  fullBounds.getX(),
                  fullBounds.getY(),
                  fullBounds.getWidth() * getStretchX(aDeviceType, displayMode),
                  fullBounds.getHeight()
                     * getStretchY(aDeviceType, displayMode)));
         }
         else {
            super.setBounds(aDeviceType, new Rectangle2D.Double(0, 0, 0, 0));
         }
      }
   }
   
   //===========================================================================

   /**
    * Returns the content of this control, which is itself.
    */
   public Content getContent() {
      return this;
   }

   //===========================================================================

   /**
    * Returns how much the content is stretched in the x direction, for the
    * specified device type and display mode, or throws an exception if the
    * specified device type does not have any content in the specified mode.
    */   
   private double getStretchX(
      final DeviceType deviceType,
      final DisplayMode mode) {

      final Double result = (Double)stretchX.get(deviceType, mode);
      return result.doubleValue();
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns how much the content is stretched in the y direction, for the
    * specified device type and display mode, or throws an exception if the
    * specified device type does not have any content in the specified mode.
    */   
   private double getStretchY(
      final DeviceType deviceType,
      final DisplayMode mode) {

      final Double result = (Double)stretchY.get(deviceType, mode);
      return result.doubleValue();
   }

   //===========================================================================
   
   /**
    * Sets how much the content is stretched in the x direction, for the
    * specified device type and display mode.
    */   
   private void setStretchX(
      final DeviceType deviceType,
      final DisplayMode mode,
      final double value) {

      stretchX.put(deviceType, mode, new Double(value));      
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets how much the content is stretched in the y direction, for the
    * specified device type and display mode.
    */   
   private void setStretchY(
      final DeviceType deviceType,
      final DisplayMode mode,
      final double value) {

      stretchY.put(deviceType, mode, new Double(value));      
   }

   //===========================================================================

   /**
    * Returns the local bounds of this element without being stretched, given
    * the specified display mode.
    */
   public Rectangle2D getFullSizeBounds(final DisplayMode displayMode) {
      return (Rectangle2D)fullSize.get(displayMode);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Updates the full-sized bounds, and also updates the bounds by scaling
    * the full-sized bounds by the values in stretchX and stretchY.
    */
   protected void setFullSizeBounds(
      final DisplayMode displayMode,
      final Rectangle2D fullSizeBounds) {
      
      final Rectangle2D oldFullSizeBounds = getFullSizeBounds(displayMode);
      fullSize.put(displayMode, fullSizeBounds);
      
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         final Rectangle2D oldBounds = getBounds(aDeviceType);

         if ((oldBounds != null) && (oldFullSizeBounds != null) &&
             (!oldFullSizeBounds.isEmpty())) {
            final double stretchXForADeviceType =
               getStretchX(aDeviceType, displayMode);

            final double stretchYForADeviceType =
               getStretchY(aDeviceType, displayMode);

            final Rectangle2D newBounds =
               new Rectangle2D.Double(
                  oldBounds.getX()
                     + (fullSizeBounds.getX() - oldFullSizeBounds.getX())
                        * stretchXForADeviceType,
                  oldBounds.getY()
                     + (fullSizeBounds.getY() - oldFullSizeBounds.getY())
                        * stretchYForADeviceType,
                  fullSizeBounds.getWidth() * stretchXForADeviceType,
                  fullSizeBounds.getHeight() * stretchYForADeviceType);
         
            if (getPreferredDisplayMode(aDeviceType) == displayMode) {
               super.setBounds(aDeviceType, newBounds);
            }
         }
         else {
            setStretchX(aDeviceType, displayMode, 1);
            setStretchY(aDeviceType, displayMode, 1);
         }
      }
   }
   
   //===========================================================================

   /**
    * Sets the bounds of this content without stretching it.
    */
   public void setBoundsWithoutStretching(
      final DeviceType deviceType,
      final Rectangle2D newBounds) {
         
      super.setBounds(deviceType, newBounds);
   }
   
   //---------------------------------------------------------------------------

   public void setBounds(
      final DeviceType deviceType,
      final Rectangle2D newBounds) {

      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext();
         ) {
         final DeviceType aDeviceType = (DeviceType)i.next();

         final DisplayMode displayMode = getPreferredDisplayMode(aDeviceType);
         final Rectangle2D fullBounds = getFullSizeBounds(displayMode);
         
         if (newBounds == null) {
            stretchX.put(aDeviceType, displayMode, null);
            stretchY.put(aDeviceType, displayMode, null);
         }
         else if (fullBounds != null) {
            if (fullBounds.getWidth() == 0) {
               setStretchX(aDeviceType, displayMode, 1);
            }
            else {
               setStretchX(
                  aDeviceType,
                  displayMode,
                  newBounds.getWidth() / fullBounds.getWidth());
            }
            if (fullBounds.getHeight() == 0) {
               setStretchY(aDeviceType, displayMode, 1);
            }
            else {
               setStretchY(
                  aDeviceType,
                  displayMode,
                  newBounds.getHeight() / fullBounds.getHeight());
            }
         }
         else {
            setStretchX(aDeviceType, displayMode, 1);
            setStretchY(aDeviceType, displayMode, 1);
         }
      }
      super.setBounds(deviceType, newBounds);
   }

   //===========================================================================

   /**
    * Adds the specified element listener to receive events from this element.
    */
   public void addContentEventListener(final ContentListener listener) {
      contentEventSource.addContentListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified element listener so that it no longer receives
    * events from this element.
    */
   public void removeContentEventListener(final ContentListener listener) {
      contentEventSource.removeContentListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires strokeAdded events to listeners.
    */
   protected void fireStrokeAdded(final GeneralPath path) {
      contentEventSource.fireStrokeAdded(this, path);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires strokeRemoved events to listeners.
    */
   protected void fireStrokeRemoved(final GeneralPath path) {
      contentEventSource.fireStrokeRemoved(this, path);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires strokesChanged events to listeners.
    */
   protected void fireStrokesChanged() {
      contentEventSource.fireStrokesChanged(this);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires textChanged events to listeners.
    */
   protected void fireTextChanged() {
      contentEventSource.fireTextChanged(this);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires imageChanged events to listeners.
    */
   protected void fireImageChanged() {
      contentEventSource.fireImageChanged(this);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires preferredDisplayModeChanged events to listeners.
    */
   protected void firePreferredDisplayModeChanged(
      final DeviceType deviceType,
      final DisplayMode oldMode) {

      contentEventSource.firePreferredDisplayModeChanged(
         this,
         deviceType,
         oldMode,
         getPreferredDisplayMode(deviceType));
   }

   //---------------------------------------------------------------------------

   /**
    * Fires promptTextIsSyncedWithText events to listeners.
    */
   protected void firePromptTextIsSyncedWithText() {
      contentEventSource.firePromptTextIsSyncedWithText(this);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires promptTextIsUnsyncedWithText events to listeners.
    */
   protected void firePromptTextIsUnsyncedWithText() {
      contentEventSource.firePromptTextIsUnsyncedWithText(this);
   }

   //===========================================================================
   
//   // @Override
//   public void setPageRegion(DeviceType aDeviceType, PageRegion aRegion) {
//      final PageRegion oldRegion = getPageRegion(aDeviceType);
//      super.setPageRegion(aDeviceType, aRegion);
//
//      // If the region hasn't changed, then exit
//      if (oldRegion == aRegion) {
//         return;
//      }
//      
//      // Initialize voice-specific properties
//      if (aDeviceType == DeviceType.VOICE) {
//         if (oldRegion != null) {
//            oldRegion.removeElementContainerListener(pageRegionHandler);
//         }
//         if (aRegion != null) {
//            aRegion.addElementContainerListener(pageRegionHandler);
//         }
//      }
//   }

   //---------------------------------------------------------------------------

   // @Override
   protected void autoPositionForDesktop() {
      setBounds(DeviceType.DESKTOP,
                getFullSizeBounds(getPreferredDisplayMode(DeviceType.DESKTOP)));

      placeAfterAllControls(DeviceType.DESKTOP);
   }

   //---------------------------------------------------------------------------

   // @Override
   protected void autoPositionForSmartphone() {
      Rectangle2D newBounds =
         getFullSizeBounds(getPreferredDisplayMode(DeviceType.SMARTPHONE));
      
      if (newBounds.getHeight() >
          DeviceType.SMARTPHONE.getPreferredContentHeight()) {

         final double frac = DeviceType.SMARTPHONE.getPreferredContentHeight()
               / newBounds.getHeight();

         newBounds = new Rectangle2D.Double(
            newBounds.getX(),
            newBounds.getY(),
            newBounds.getWidth() * frac,
            newBounds.getHeight() * frac);
      }
      
      setBounds(DeviceType.SMARTPHONE, newBounds);
      
      placeAfterAllControls(DeviceType.SMARTPHONE);
   }

   //---------------------------------------------------------------------------

   // @Override
   protected void autoPositionForVoice() {
      setTextSize(DeviceType.VOICE, DeviceType.VOICE.getDefaultFontSize());
      setVoicePromptBounds(
         DamaskAppUtils.getRenderedTextBounds(
            getVoicePromptText(), DeviceType.VOICE.getDefaultFontSize()));

      placeVoicePromptUnderPreviousPrompt();
   }

   //---------------------------------------------------------------------------

   // @Override
   protected void setupVoiceResponses() {
      final Control controlAfter =
         DamaskUtils.getNextLowLevelControl(
            getPageRegion(DeviceType.VOICE), this);

      if ((controlAfter != null) &&
          (controlAfter.getVoicePromptBounds() != null)) {
         createEmptyResponseToNextPrompt();
      }
      else {
         setVoiceResponseLine(0, null);
         setVoiceResponseSource(null);
         setVoiceResponseDest(0, null);

         // move all subsequent responses so that the originate
         // from the new control
         reanchorSubsequentResponsesToThisPrompt();
      }
   }

   //===========================================================================
   
   /**
    * Creates an empty response between this object and the next prompt.
    */
   private void createEmptyResponseToNextPrompt() {
      final Control controlAfter =
         DamaskUtils.getNextLowLevelControl(
            getPageRegion(DeviceType.VOICE), this);

      // create an empty response from newControl
      final Rectangle2D controlAfterBoundsInParent =
         controlAfter.getBoundsInParentCoords(DeviceType.VOICE);

      final Rectangle2D controlAfterBoundsInNewControl = 
         parentToLocal(DeviceType.VOICE, controlAfterBoundsInParent);

      setVoiceResponseLine(
         0,
         new Line2D.Double(
            getVoicePromptBounds().getCenterX(),
            getVoicePromptBounds().getCenterY(),
            controlAfterBoundsInNewControl.getCenterX(),
            controlAfterBoundsInNewControl.getCenterY()));
      setVoiceResponseSource(this);
      setVoiceResponseDest(0, controlAfter);
   }

   //===========================================================================

   private static void copyData(final Content source, final Content dest) {
      if (source.image != null) {
         dest.image =
            new BufferedImage(
               source.image.getWidth(),
               source.image.getHeight(),
               source.image.getType());
         source.image.copyData(dest.image.getRaster());
      }
      dest.strokes = new ArrayList();
      for (Iterator i = source.strokes.iterator(); i.hasNext();) {
         final GeneralPath stroke = (GeneralPath)i.next();
         dest.strokes.add(stroke.clone());
      }
      dest.text = source.text;
      dest.textSize = new HashMap(source.textSize);
      dest.fullSize = new HashMap(source.fullSize);
      dest.stretchX = new Map2D(source.stretchX);
      dest.stretchY = new Map2D(source.stretchY);
      dest.preferredDisplayMode = new HashMap(source.preferredDisplayMode);
      dest.contentEventSource = new ContentEventSource();
   }

   //---------------------------------------------------------------------------

   public Object clone() {
      final Content clone = (Content)super.clone();
      copyData(this, clone);
      return clone;
   }

   //---------------------------------------------------------------------------

   public Component createCopy(DeviceType deviceType) {
      return new Content(this, deviceType);
   }

   //===========================================================================

   /**
    * Returns a string version of the contents of this piece of content.
    */
   public String contentsToString() {
      StringBuffer sb = new StringBuffer();
      sb.append(text);
      if (text.equals("") && (strokes != null)) {
         sb.append(" (sketch)");
      }
      if (image != null) {
         sb.append(" (image)");
      }
      return sb.toString();
   }

   //---------------------------------------------------------------------------

   public String toString() {
      return super.toString() + " - " + contentsToString();
   }

   //===========================================================================
   
//   private class PageRegionHandler implements ElementContainerListener {
//      public void elementAdded(ElementContainerEvent e) {
//      }
//
//      public void elementRemoved(ElementContainerEvent e) {
//         final Control controlAfter =
//            DamaskUtils.getNextLowLevelControl(
//               getPageRegion(DeviceType.VOICE), Content.this);
//
//         if ((controlAfter != null) &&
//               (controlAfter.getVoicePromptBounds() != null)) {
//            createEmptyResponseToNextPrompt();
//         }
//
//         else {
//            setVoiceResponseSource(null);
//            setVoiceResponseDest(0, null);
//            setVoiceResponseLine(0, null);
//
//            // move all subsequent responses so that the originate
//            // from the new control
//            reanchorSubsequentResponsesToThisPrompt();
//         }
//      }
//   }
}
