package edu.berkeley.guir.damask.view.appevent;

import java.util.EventListener;

/** 
 * The listener interface for receiving global app events.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  05-31-2004 James Lin
 *                               Created AppListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 05-31-2004
 */
public interface AppListener extends EventListener {
   
   /**
    * Invoked when the frame which has the focus has changed.
    */
   void currentFrameChanged(AppEvent e);
}
