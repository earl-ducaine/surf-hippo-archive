//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tuple;

import edu.berkeley.guir.lib.collection.tuple.comparator.TupleComparator;
import edu.berkeley.guir.lib.collection.tuple.filter.TupleFilter;
import edu.berkeley.guir.lib.collection.tuple.filter.TupleFilterByAttribute;
import edu.berkeley.guir.lib.collection.tuple.filter.TupleFilterByType;
import edu.berkeley.guir.lib.util.StringLib;
import edu.berkeley.guir.lib.web.HtmlCodec;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.IOException;
import java.io.Reader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * A Tuple, a set of key-value pairs.
 * The key is a String, and the value is either a String or a Tuple.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Nov 13 2002 JIH
 */
public class Tuple {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * An empty iterator.
     */
    private static final Iterator EMPTY_ITERATOR = 
                                            Collections.EMPTY_LIST.iterator();

    //----------------------------------------------------------------

    /**
     * Key for tuples that keep their own size.
     */
    public static final String KEY_SIZE = "size";


    /**
     * Number of spaces to indent.
     */
    public static final int INDENT = 3;


    /**
     * A parser for plain vanilla Tuples.
     */
    private static TupleParser PARSER = new TupleParserDefaultImpl();


    /**
     * An empty and immutable Tuple.
     */
    public static Tuple EMPTY = TupleLib.EMPTY;

    //----------------------------------------------------------------

    /**
     * Standard formatting for dates.
     */
    public static final DateFormat DEFAULT_DATEFORMAT = 
                                 new SimpleDateFormat("yyyy.MMM.dd HH:mm:ss z");

    //----------------------------------------------------------------

    private static final String TRUE  = "true";
    private static final String FALSE = "false";

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   CLASS VARIABLES   ==================================================

    /**
     * Set the parser used to parse tuples.
     */
    public static void setTupleParser(TupleParser newTupleParser) {
        PARSER = newTupleParser;
    } // of method

    //----------------------------------------------------------------

    /**
     * Parse an XML String into a {@link Tuple}.
     */
    public static Tuple parse(String str) 
        throws TupleParserException {

        return (PARSER.parse(str));
    } // of method


    /**
     * Parse the InputStream into a {@link Tuple}.
     * Closes stream when done.
     */
    public static Tuple parse(InputStream istream) 
        throws TupleParserException {

        return (PARSER.parse(istream));
    } // of method


    /**
     * Parse the Reader into a {@link Tuple}.
     * Closes reader when done.
     */
    public static Tuple parse(Reader rdr) 
        throws TupleParserException {

        return (PARSER.parse(rdr));
    } // of method

    //----------------------------------------------------------------

    /**
     * "Standard" date format used for all tuple-related classes.
     */
    static DateFormat dformat = DEFAULT_DATEFORMAT;

    /**
     * Set the DateFormat used by all tuple-related classes.
     */
    public static void setDateFormat(DateFormat newDateFormat) {
        dformat = newDateFormat;
    } // of method

    /**
     * Get the DateFormat used by all tuple-related classes.
     */
    public static DateFormat getDateFormat() {
        return (dformat);
    } // of method

    //----------------------------------------------------------------

    /**
     * Handles xpath queries within this Tuple.
     */
    static TupleXPathHandler xpathHandler = TupleXPathHandler.EMPTY;

    /**
     * Set the module that does xpath queries.
     */
    public static void setXPathHandler(TupleXPathHandler xph) {
        xpathHandler = xph;
    } // of method

    /**
     * Get the module that does xpath queries.
     */
    public static TupleXPathHandler getXPathHandler() {
        return (xpathHandler);
    } // of method

    //===   CLASS VARIABLES   ==================================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY METHODS - XML ESCAPE   =====================================

    /**
     * Purify a String for XML. This means getting
     * rid of ampersands &amp;, less-than &lt;, and greater than &gt;.
     * Just replace by spaces. If we don't do this, then XML parsing chokes.
     */
    public static String xmlEncode(String str) {
        str = str.replaceAll("&", "&amp;");
        str = str.replaceAll("<", "&lt;");
        str = str.replaceAll(">", "&gt;");
        return (str);
    } // of method

    //===   UTILITY METHODS - XML ESCAPE   =====================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    String  strTupleType    = "undefined"; // basically, the XML tag
    Map     mapAttributes   = null;        // created lazily
    List    listTuples      = null;        // created lazily
    boolean flagDynamicSize = false;       // #tuples contained as an attribute?
                                           // treat dynamic (t) or static (f)?

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Empty constructor.
     */
    public Tuple() {
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Note, <B>this does not parse</B>.
     * @param strTupleType is the name of the tuple, ie the XML tag.
     * @see Tuple#parse(String)
     * @see Tuple#parse(InputStream)
     * @see Tuple#parse(Reader)
     */
    public Tuple(String strTupleType) {
        setTupleType(strTupleType);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param strTupleType  is the name of the tuple, ie the XML tag.
     * @param mapAttributes is the name of the attributes.
     */
    public Tuple(String strTupleType, Map mapAttributes) {
        setTupleType(strTupleType);
        setAttributes(mapAttributes);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param strTupleType  is the name of the tuple, ie the XML tag.
     * @param mapAttributes is the name of the attributes.
     * @param listTuples    is the list of tuples contained by this tuple.
     */
    public Tuple(String strTupleType, Map mapAttributes, List listTuples) {
        setTupleType(strTupleType);
        setAttributes(mapAttributes);
        addTuples(listTuples);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Read in a Tuple from File.
     */
    public Tuple(File f) 
        throws IOException, TupleParserException {

        FileReader rdr = new FileReader(f);
        Tuple      t   = PARSER.parse(rdr);
        this.setTo(t);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Read in a Tuple from Reader.
     */
    public Tuple(Reader rdr)
        throws TupleParserException {

        Tuple      t   = PARSER.parse(rdr);
        this.setTo(t);
    } // of method

    //----------------------------------------------------------------

    /**
     * Copy constructor, deep copy.
     * @param t is the Tuple to deep-copy.
     */
    public Tuple(Tuple t) {
        this.setTupleType(t.getTupleType());
        this.setAttributes(t.getAttributes());

        Iterator it = t.tuples();
        Tuple    tTmp;
        while (it.hasNext()) {
            tTmp = (Tuple) it.next();
            this.addTuple(new Tuple(tTmp));
        }
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Copy the attributes over.
     * Be sure to call setTupleType(), otherwise the Tuple will
     * be "undefined".
     */
    public Tuple(Map m) {
        this.setAttributes(m);
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert a org.w3c.dom.Element into a Tuple.
     */
    public Tuple(Element elem) {
        //// 1. Set the tuple type.
        setTupleType(elem.getNodeName());

        //// 2. Set the attributes.
        NamedNodeMap map = elem.getAttributes();
        Node         n;
        for (int i = 0; i < map.getLength(); i++) {
            n = map.item(i);
            setAttribute(n.getNodeName(), n.getNodeValue());
        }

        //// 3. Set the children tuples.
        NodeList list = elem.getChildNodes();
        for (int i = 0; i < list.getLength(); i++) {
            n = list.item(i);
            if (n instanceof Element) {
                addTuple(new Tuple((Element) n));
            }
        }
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Lazily create the map of attributes on demand.
     */
    private void initAttributes() {
        if (mapAttributes == null) {
            mapAttributes = new LinkedHashMap();
        }
    } // of method


    /**
     * Lazily create the map of tuples on demand.
     */
    private void initTuples() {
        if (listTuples == null) {
            listTuples = new LinkedList();
        }
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   TUPLE TYPE METHODS   ===============================================

    /**
     * @param newTupleType is the name of the tuple, ie the root-level XML tag.
     */
    public void setTupleType(String newTupleType) {
        if (newTupleType == null) {
            throw new IllegalArgumentException("Tuple type cannot be null");
        }
        strTupleType = newTupleType;
    } // of method


    /**
     * The XML tag portion, ex. &lt;tag&gt;
     */
    public String getTupleType() {
        return (strTupleType);
    } // of method


    /**
     * Check if the root-level XML tag matches.
     */
    public boolean isTupleType(String strTupleType) {
        return (getTupleType().equals(strTupleType));
    } // of method

    //===   TUPLE TYPE METHODS   ===============================================
    //==========================================================================




    //==========================================================================
    //===   SIZE METHODS   =====================================================

    /**
     * Update the size attribute.
     */
    private void updateSize() {
        if (flagDynamicSize == true) {
            setAttribute(KEY_SIZE, "" + getNumTuples());
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Set whether or not this Tuple should have a "size" attribute
     * that is dynamically adjusted based on the number of Tuples contained.
     */
    public void setDynamicSize(boolean flag) {
        flagDynamicSize = flag;
    } // of method


    /**
     * Check whether or not this Tuple has a dynamic "size" attribute.
     */
    public boolean hasDynamicSize() {
        return (flagDynamicSize);
    } // of method

    //===   SIZE METHODS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   ATTRIBUTE METHODS   ================================================

    /**
     * Clear out the previous attributes, copy over from the specified map.
     */
    public void setAttributes(Map map) {
        Iterator it = map.keySet().iterator();
        String   strKey;
        String   strVal;

        initAttributes();

        while (it.hasNext()) {
            strKey = (String) it.next();
            strVal = (String) map.get(strKey);
            if (strKey == null || strVal == null) {
                continue;
            }
            mapAttributes.put(strKey, strVal);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Set an attribute. If value is null, removes it.
     * Meant for text, not binary data.
     *
     * @param strKey is the key (usually denoted as a constant
     *               in the class, for example ATTR_DATATYPE)
     * @param strVal is the value. Calls (@link #xmlEncode(String)}
     *               so that the XML parser will not choke on it later on.
     * @see #xmlEncode(String)
     */
    public void setAttribute(String strKey, String strVal) {
        initAttributes();
        if (strVal == null) {
            mapAttributes.remove(strKey);
        }
        else {
            mapAttributes.put(strKey, xmlEncode(strVal));
        }
    } // of method


    /**
     * Convenience method for setting a boolean attribute.
     */
    public void setAttribute(String strKey, boolean flag) {
        String str = TRUE;

        if (flag == false) {
            str = FALSE;
        }
        setAttribute(strKey, str);
    } // of method

    /**
     * Convenience method, converts val to a String.
     */
    public void setAttribute(String strKey, int val) {
        setAttribute(strKey, "" + val);
    } // of method

    /**
     * Convenience method, converts val to a String.
     */
    public void setAttribute(String strKey, long val) {
        setAttribute(strKey, "" + val);
    } // of method

    /**
     * Convenience method, converts val to a String.
     */
    public void setAttribute(String strKey, double val) {
        setAttribute(strKey, "" + val);
    } // of method

    //----------------------------------------------------------------

    /**
     * Get an attribute as a String.
     * @return null if it does not exist.
     */
    public String getAttribute(String strKey) {
        if (mapAttributes == null) {
            return (null);
        }
        else {
            if (KEY_SIZE.equals(strKey)) {
                updateSize();
            }
            String str = (String) mapAttributes.get(strKey);
            return (HtmlCodec.decode(str));
        }
    } // of method


    public boolean getAttributeAsBoolean(String strKey) {
        String str = getAttribute(strKey);
        if ("true".equalsIgnoreCase(str)) {
            return (true);
        }
        return (false);
    } // of method

    /**
     * @throws NumberFormatException if cannot parse
     */
    public int getAttributeAsInt(String strKey) {
        return (Integer.parseInt(getAttribute(strKey)));
    } // of method

    /**
     * @throws NumberFormatException if cannot parse
     */
    public long getAttributeAsLong(String strKey) {
        return (Long.parseLong(getAttribute(strKey)));
    } // of method

    /**
     * @throws NumberFormatException if cannot parse
     */
    public double getAttributeAsDouble(String strKey) {
        return (Double.parseDouble(getAttribute(strKey)));
    } // of method

    //----------------------------------------------------------------

    /**
     * Get rid of all attributes.
     */
    public void clearAttributes() {
        mapAttributes = null;
    } // of method

    //----------------------------------------------------------------

    /**
     * Get an iterator on the keys.
     */
    public Iterator attributeKeys() {
        if (mapAttributes == null) {
            return (EMPTY_ITERATOR);
        }
        else {
            return (mapAttributes.keySet().iterator());
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Get a copy of the attributes.
     * @return if there are no attributes, return an empty and immutable map.
     */
    public Map getAttributes() {
        updateSize();
        if (mapAttributes == null) {
            return (Collections.EMPTY_MAP);
        }
        else {
            return (new LinkedHashMap(mapAttributes));
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the number of attributes.
     */
    public int getNumAttributes() {
        updateSize();
        if (mapAttributes == null) {
            return (0);
        }
        else {
            return (mapAttributes.size());
        }
    } // of method

    //===   ATTRIBUTE METHODS   ================================================
    //==========================================================================




    //==========================================================================
    //===   GENERAL TUPLE METHODS   ============================================

    /**
     * Set the internals of this Tuple to point to the internals of the 
     * specified one. Thus, changes to one will be reflected in the other.
     */
    public void setTo(Tuple t) {
        this.strTupleType    = t.strTupleType;
        this.mapAttributes   = t.mapAttributes;
        this.listTuples      = t.listTuples;
        this.flagDynamicSize = t.flagDynamicSize;
    } // of method

    //----------------------------------------------------------------

    /**
     * Sort the contained tuples.
     */
    public void sortTuples(TupleComparator c) {
        Collections.sort(listTuples, c);
    } // of method

    //----------------------------------------------------------------

    /**
     * Add a set of Tuples. Will be added in the order of the List iterator.
     * @param list is a List of Tuple objects.
     */
    public void addTuples(List list) {
        Iterator it = list.iterator();
        while (it.hasNext()) {
            addTuple((Tuple) it.next());
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Add a tuple (to the back).
     */
    public void addTuple(Tuple tuple) {
        initTuples();
        listTuples.add(tuple);
    } // of method

    //----------------------------------------------------------------

    /**
     * Get an Iterator on the tuples (in the order they were added).
     */
    public Iterator tuples() {
        if (listTuples == null) {
            return (EMPTY_ITERATOR);
        }
        else {
            return (listTuples.iterator());
        }
    } // of method


    /**
     * Get an Iterator on the tuples after sorting.
     */
    public Iterator tuples(TupleComparator c) {
        List listTuples = getTuples(c);
        return (listTuples.iterator());
    } // of method

    //----------------------------------------------------------------

    /**
     * Get rid of all tuples.
     */
    public void clearTuples() {
        listTuples = null;
    } // of method

    //----------------------------------------------------------------

    /**
     * Remove a tuple. Checks equals().
     */
    public void removeTuple(Tuple t) {
        if (listTuples != null) {
            listTuples.remove(t);
        }
    } // of method

    /**
     * Remove all tuples of the type specified.
     */
    public void removeTuplesByType(String strTupleType) {
        initTuples();
        List listRemoveTuples = getTuplesByType(strTupleType);
        listTuples.removeAll(listRemoveTuples);
    } // of method


    /**
     * Remove all of the tuples with the specified attribute key defined.
     */
    public void removeTuplesByAttribute(String strAttribute) {
        initTuples();
        List listRemoveTuples = getTuplesByAttribute(strAttribute);
        listTuples.removeAll(listRemoveTuples);
    } // of method


    /**
     * Remove the first tuple with the specified attribute key defined,
     * with a value that matches the specified pattern.
     * @see java.lang.String#matches(String)
     */
    public void removeTuplesByAttribute(String strAttribute, String strPattern){
        initTuples();
        List listRemoveTuples = getTuplesByAttribute(strAttribute, strPattern);
        listTuples.removeAll(listRemoveTuples);
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the Nth Tuple contained by this Tuple.
     */
    public Tuple getTuple(int i) {
        initTuples();
        return ((Tuple) listTuples.get(i));
    } // of method


    /**
     * Get the first Tuple contained by this Tuple.
     * Returns null if there are no tuples.
     */
    public Tuple getFirstTuple() {
        if (listTuples == null) {
            return (null);
        }
        else {
            return ((Tuple) listTuples.get(0));
        }
    } // of method


    /**
     * Get the last Tuple contained by this Tuple.
     * Returns null if there are no tuples.
     */
    public Tuple getLastTuple() {
        if (listTuples == null) {
            return (null);
        }
        else {
            return ((Tuple) listTuples.get(listTuples.size() - 1));
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Get a copy of the list of tuples.
     * @return if there are no tuples, return an empty and immutable list.
     */
    public List getTuples() {
        if (listTuples == null) {
            return (Collections.EMPTY_LIST);
        }
        else {
            return (new LinkedList(listTuples));
        }
    } // of method


    /**
     * Get a copy of the list of tuples, sorted.
     */
    public List getTuples(TupleComparator c) {
        if (listTuples == null) {
            return (Collections.EMPTY_LIST);
        }
        else {
            List list = new LinkedList(listTuples);
            Collections.sort(list, c);
            return (list);
        }
    } // of method


    public List getTuples(TupleFilter f) {
        if (listTuples == null) {
            return (Collections.EMPTY_LIST);
        }
        else {
            return (f.keepAccepted(listTuples));
        }
    } // of method


    /**
     * Get the first tuple of the specified type.
     * @return null if not there.
     */
    public Tuple getTupleByType(String strTupleType) {
        Iterator it = tuples();
        Tuple    t;

        while (it.hasNext()) {
            t = (Tuple) it.next();
            if (strTupleType.equals(t.getTupleType())) {
                return (t);
            }
        }
        return (null);
    } // of method


    /**
     * Get all of the tuples of the specified type.
     */
    public List getTuplesByType(String strTupleType) {
        return (getTuples(new TupleFilterByType(strTupleType)));
    } // of method


    /**
     * Get the first tuple with the specified attribute key defined.
     */
    public Tuple getTupleByAttribute(String strAttribute) {
        Iterator it   = tuples();
        Tuple    t;

        while (it.hasNext()) {
            t = (Tuple) it.next();
            if (t.getAttribute(strAttribute) != null) {
                return (t);
            }
        }
        return (null);
    } // of method


    /**
     * Get all of the tuples with the specified attribute key defined.
     */
    public List getTuplesByAttribute(String strAttribute) {
        return (getTuples(new TupleFilterByAttribute(strAttribute)));
    } // of method


    /**
     * Get the first tuple with the specified attribute key defined,
     * with a value that matches the specified pattern.
     * @see java.lang.String#matches(String)
     */
    public Tuple getTupleByAttribute(String strAttribute, String strPattern) {
        Iterator it   = tuples();
        Tuple    t;
        String   attr;

        while (it.hasNext()) {
            t    = (Tuple) it.next();
            attr = t.getAttribute(strAttribute);

            if (attr == null) {
                continue;
            }

            if (attr.matches(strPattern)) {
                return (t);
            }
        }
        return (null);
    } // of method


    /**
     * Get all of the tuples with the specified attribute key defined,
     * with a value that matches the specified pattern.
     * @see java.lang.String#matches(String)
     */
    public List getTuplesByAttribute(String strAttribute, String strPattern) {
       return (getTuples(new TupleFilterByAttribute(strAttribute, strPattern)));
    } // of method

    //----------------------------------------------------------------

    /**
     * Sort the tuples using the specified comparator.
     * Can use TupleComparator.
     */
    public void sortTuples(Comparator c) {
        Collections.sort(listTuples, c);
    } // of method

    //----------------------------------------------------------------

    /**
     * Return the number of tuples contained.
     */
    public int getNumTuples() {
        if (listTuples == null) {
            return (0);
        }
        else {
            return (listTuples.size());
        }
    } // of method

    //===   GENERAL TUPLE METHODS   ============================================
    //==========================================================================




    //==========================================================================
    //===   GENERIC ACCESSOR   =================================================

    /**
     * Currently throws UnsupportedOperationException, because it doesn't 
     * have built-in support for XPath. Subclasses should implement.
     * <P>
     * We need a means to support generic access to tuple values and 
     * attributes. I'll leave this unimplemented for now, but place it here 
     * both as a reminder and so that dependent classes can still compile. It 
     * remains to be decided if we want type-checking to be performed by the 
     * tuple itself or at a higher level. Currently the condition classes do
     * their own type-checking. --jheer 11.19
     * @see TupleTypes
     *
     * @param strXPath is an XPath to the field we want.
     * @return the requested value as an unprocessed String, or null if
     *         it does not exist.
     * @throws Exception on a serious xpath Tuple processing error.
     */
    public String getXPath(String strXPath) throws Exception {
        return (getXPathHandler().getXPath(this, strXPath));
    } // of method

    //===   GENERIC ACCESSOR   =================================================
    //==========================================================================




    //==========================================================================
    //====  OBJECT METHODS  ====================================================

    /**
     * Returns a hashCode for this ContextTuple. Uses the entity-name,
     * entity-type, entity-link, and tuple type to compute the hash.
     * @return a hash code (integer) for this ContextTuple
     */
    public int hashCode() {
        return getHashKey().hashCode();
    } // of method
    
    //----------------------------------------------------------------

    private String getMapHashCode() {
        if (mapAttributes == null) {
            return ("null");
        }
        else {
            return ("" + mapAttributes.hashCode());
        }
    } // of method


    private String getListHashCode() {
        if (listTuples == null) {
            return ("null");
        }
        else {
            return ("" + listTuples.hashCode());
        }
    } // of method


    /**
     * Returns a String representing a hash key for this ContextTuple.
     * That is, the hash value of this String is the same as the hash value
     * for this tuple.
     * @return the hash key String
     */
    public String getHashKey() {
        //// mapAttributes and listTuples return different values
        //// depending on what they contain, so this should work.
        return ( "" + strTupleType + getMapHashCode() + getListHashCode());
    } // of method

    //----------------------------------------------------------------

    /**
     * Compares two context tuples for equality. Here we define equality to
     * mean that the two tuples represent the same object. This means they
     * can differ in their fields and still be equal.
     * @param obj the Object to compare to
     * @return true if the this object and the argument object are equal,
     *         where equal is defined as described above. false otherwise.
     */
    public boolean equals(Object obj) {
        //// 1. Quick check.
        if ((obj instanceof Tuple) == false) {
            return (false);
        }

        Tuple tAA = this;
        Tuple tBB = (Tuple) obj;

        //// 2. Another quick check for equality.
        if (tAA == tBB) {
            return (true);
        }

        //// 3. Check the hashkeys.
        return tAA.getHashKey().equals(tBB.getHashKey());
    } // of method

    //===   OBJECT METHODS  ====================================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    /**
     * Get the order in which the keys will be printed out.
     * By default does it alphabetically. OK to specify keys that
     * do not exist (will be ignored on printing.) Thus ok to 
     * return a static List. Keys not specified will be ignored in printing.
     */
    public List getKeyOrder() {
        if (getNumAttributes() <= 0) {
            return (Collections.EMPTY_LIST);
        }

        List listKeys = new LinkedList(mapAttributes.keySet());
        Collections.sort(listKeys);
        return (listKeys);
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert a map to a String along one line, rather than aligned
     * by the '='. For example, {"key1"="abc", "key2"="123"} becomes
     * <PRE>
     *    key1="abc" key2="123"
     * </PRE>
     */
    protected String mapToSingleLine(Map map) {
        Iterator     it     = getKeyOrder().iterator();
        StringBuffer strbuf = new StringBuffer();
        String       strKey;
        String       strVal;

        while (it.hasNext()) {
            strKey = (String) it.next();
            strVal = (String) map.get(strKey);
            strbuf.append(strKey);
            strbuf.append("=\"");
            strbuf.append(strVal);
            strbuf.append("\" ");
        }

        return (strbuf.toString());
    } // of method


    /**
     * Helper method that figures out what the start tag for the XML tuple
     * is supposed to look like.
     *
     * @param strbuf is the StringBuffer to append to.
     * @param indent is the number of spaces to indent.
     * @param flagMulti is true if multiple lines, false if single line.
     */
    protected void handleStartTag(StringBuffer strbuf, 
                                  int          indent, 
                                  boolean      flagMulti) {
        //// Four different cases:
        ////   (a) Has Attributes, has Tuples  <Tag ...> ... </Tag>
        ////   (b) Has Attributes, no  Tuples  <Tag .../> 
        ////   (c) No  Attributes, has Tuples  <Tag>     ... </Tag>
        ////   (d) No  Attributes, no  Tuples  <Tag/>

        //// 1. Quick check for case (d).
        if (getNumAttributes() <= 0 && getNumTuples() <= 0) {
            strbuf.append(StringLib.blank(indent));
            strbuf.append("<");
            strbuf.append(getTupleType());
            strbuf.append("/>");
            return;
        }

        //// 2. Quick check for case (c).
        if (getNumAttributes() <= 0 && getNumTuples() > 0) {
            strbuf.append(StringLib.blank(indent));
            strbuf.append("<");
            strbuf.append(getTupleType());
            strbuf.append(">");
            return;
        }

        String strBalancedMap;

        //// 3.1. Handle attributes spanning multiple lines.
        if (flagMulti == true) {
            //// 3.1.1. Otherwise, handle cases (a) and (b).
            ////        Get the map in String format.
            ////        Balance it, so that all the '=' line up.
            ////        Shift it over by the length of the node name.
            strBalancedMap = StringLib.alignRight(mapAttributes,
                                                  getKeyOrder(),
                                                  "=\"", "\"");
            int shiftRight = getTupleType().length() + 1;


            //// 3.1.2. Figure out the max we can shift back left,
            ////        ie how many spaces there are in the first line.
            int    shiftLeft   = 0;
            int    len         = strBalancedMap.length();
            for (int i = 0; i < len; i++) {
                if (strBalancedMap.charAt(i) != ' ') {
                    break;
                }
                shiftLeft++;
            }


            //// 3.1.3. The amount we should actually shift over
            ////        is Math.max(2, shiftRight - shiftLeft).
            ////        The 2 is a minimum to shift over, so that
            ////        the tag always leads all attributes.
            int oldShiftRight = shiftRight + indent;

            shiftRight     = Math.max(2, shiftRight - shiftLeft) + indent;
            strBalancedMap = strBalancedMap.replaceAll("\n", 
                                        "\n" + StringLib.blank(shiftRight + 1));


            //// 3.1.4. Now we need to fix the first line.
            ////        Cut oldShiftRight - shiftRight number of spaces.
            if (oldShiftRight - shiftRight > 0) {
                strBalancedMap = strBalancedMap.substring(
                                          oldShiftRight - shiftRight);
            }
        }
        //// 3.2. Handle attributes on one line.
        else {
            strBalancedMap = mapToSingleLine(mapAttributes);
        }


        //// 7.1. Case (b), no tuples.
        if (getNumTuples() <= 0) {
            strbuf.append(StringLib.blank(indent));
            strbuf.append("<");
            strbuf.append(getTupleType());
            strbuf.append(" ");
            strbuf.append(strBalancedMap);
            strbuf.append(" />");
            return;
        }
        //// 7.2. Case (a), has tuples.
        else {
            strbuf.append(StringLib.blank(indent));
            strbuf.append("<");
            strbuf.append(getTupleType());
            strbuf.append(" ");
            strbuf.append(strBalancedMap);
            strbuf.append(">");
            return;
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Helper method that figures out what the contained tuples
     * are supposed to look like.
     *
     * @param strbuf is the StringBuffer to append to.
     * @param indent is the number of spaces to indent.
     */
    protected void handleTuples(StringBuffer strbuf, 
                                int          indent, 
                                boolean      flagMulti) {
        Iterator it = tuples();
        Tuple    t;

        while (it.hasNext()) {
            t = (Tuple) it.next();
            strbuf.append("\n");
            t.toString(strbuf, indent + INDENT, flagMulti);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Helper method that figures out what the closing tag is
     * supposed to look like.
     *
     * @param strbuf is the StringBuffer to append to.
     * @param indent is the number of spaces to indent.
     */
    protected void handleEndTag(StringBuffer strbuf, int indent) {

        //// Four different cases:
        ////   (a) Has Attributes, has Tuples  <Tag ...> ... </Tag>
        ////   (b) Has Attributes, no  Tuples  <Tag .../> 
        ////   (c) No  Attributes, has Tuples  <Tag>     ... </Tag>
        ////   (d) No  Attributes, no  Tuples  <Tag/>

        //// 1.1. If case (b) or (d), do nothing.
        if (getNumTuples() <= 0) {
            return;
        }
        //// 1.2. If case (a) or (c), add the close tag.
        else {
            strbuf.append("\n");
            strbuf.append(StringLib.blank(indent));
            strbuf.append("</");
            strbuf.append(getTupleType());
            strbuf.append(">\n");
            return;
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * @param indent is the number of spaces to indent.
     */
    public void toString(StringBuffer strbuf, int indent, boolean flagMulti) {
        updateSize();
        handleStartTag(strbuf, indent, flagMulti);
        handleTuples(strbuf,   indent, flagMulti);
        handleEndTag(strbuf,   indent);
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert the Tuple to an XML String.
     */
    public String toString() {
        return (toString(true));
    } // of method


    /**
     * @param flagMultiLineAttributes is true if the attributes should be
     *                                nicely aligned by their '=', false if
     *                                they are to be on one line.
     */
    public String toString(boolean flagMultiLineAttributes) {
        StringBuffer strbuf = new StringBuffer();
        toString(strbuf, 0, flagMultiLineAttributes);
        return (strbuf.toString());
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert the Tuple to an XML String.
     * In this case, does the same thing as toString().
     * Here for consistency.
     */
    public String toXml() {
        return (toXml(true));
    } // of method


    /**
     * @param flagMultiLineAttributes is true if the attributes should be
     *                                nicely aligned by their '=', false if
     *                                they are to be on one line.
     */
    public String toXml(boolean flagMultiLineAttributes) {
        return (toString(flagMultiLineAttributes));
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static Tuple getTestInstanceAAA() {
        return (new Tuple("Empty"));
    } // of method


    public static Tuple getTestInstanceBBB() {
        Tuple t = new Tuple("Test");
        t.setAttribute("type",        "location.room");
        t.setAttribute("description", "location of an entity");
        t.setAttribute("entity-name", "bart simpson");
        return (t);
    } // of method


    public static Tuple getTestInstanceCCC() {
        Tuple t = getTestInstanceBBB();
        t.setDynamicSize(true);
        t.addTuple(getTestInstanceAAA());
        t.addTuple(getTestInstanceAAA());
        t.addTuple(getTestInstanceBBB());
        return (t);
    } // of method

    public static Tuple getTestInstanceDDD() {
        Tuple t = getTestInstanceCCC();
        t.addTuple(getTestInstanceCCC());
        return (t);
    } // of method

    //----------------------------------------------------------------

    // print out a tuple, parse it, and print the parsed result
    // just to make sure it is doing things right
    private static void printAndParseTuple(Tuple t) throws Exception {
        String strAA = t.toString();
        System.out.println("---the tuple------");
        System.out.println(strAA);

        String strBB;
        System.out.println("---the parsed tuple------");
        Tuple ct = PARSER.parse(t.toString());
        System.out.println(ct.getClass());
        strBB = ct.toString();
        System.out.println(strBB);

        System.out.println("--- equal? --- " + (strAA.equals(strBB)));
    } // of method

    //--------------------

    private void runTestAAA() {
        System.out.println(getTestInstanceAAA());
        System.out.println();
        System.out.println(getTestInstanceBBB());
        System.out.println();
        System.out.println(getTestInstanceCCC());
        System.out.println();

        Tuple tZZ = new Tuple();
        Tuple tAA = getTestInstanceAAA();
        Tuple tBB = getTestInstanceBBB();
        Tuple tCC = getTestInstanceCCC();

        tZZ.setTo(tAA);
        System.out.println(tZZ.equals(tAA));
        System.out.println(tZZ.equals(getTestInstanceAAA()));


        // PARSER.parse("blahblahblah");
        // PARSER.parse("<hi there>");
        // PARSER.parse("<hi />");
    } // of method

    //--------------------

    //// Test timing
    private static void runTestBBB() throws Exception {
        long  startTime;
        Tuple t;

        startTime = System.currentTimeMillis();
        t         = new Tuple("Test");
        System.out.println(System.currentTimeMillis() - startTime);


        startTime = System.currentTimeMillis();
        t         = Tuple.parse("<test value=\"blah\"></test>");
        System.out.println(System.currentTimeMillis() - startTime);


        startTime = System.currentTimeMillis();
        t         = Tuple.parse("<test2 value=\"blix\"></test2>");
        System.out.println(System.currentTimeMillis() - startTime);
    } // of method

    //--------------------

    //// Test xpath retrieval
    private static void runTestCCC() throws Exception {
        System.out.println(getTestInstanceBBB());
        System.out.println(getTestInstanceBBB().getXPath("/Test/@description"));
        System.out.println(getTestInstanceBBB().getXPath("/Test/@entity-name"));
        System.out.println(getTestInstanceBBB().getXPath("/Test/@blah"));
        System.out.println("");
        System.out.println("");
        System.out.println(getTestInstanceDDD());
        System.out.println(getTestInstanceDDD().getXPath("/Test/Test"));
    } // of method

    //--------------------

    //// Try printing the attributes on one line
    private static void runTestDDD() throws Exception {
        System.out.println(getTestInstanceAAA().toString(false));
        System.out.println(getTestInstanceBBB().toString(false));
        System.out.println(getTestInstanceCCC().toString(false));
        System.out.println(getTestInstanceDDD().toString(false));
    } // of method

    //--------------------

    private static void runTestEEE() throws Exception {
        Tuple t = getTestInstanceAAA();

        System.out.println("-------------");
        System.out.println(t);
        System.out.println("-------------");
        System.out.println( t.getTuplesByType("blah") );
        System.out.println("-------------");
        t.removeTuplesByType("blah");
        System.out.println(t);
    } // of method

    //--------------------

    //// Test xmlEncode()
    private static void runTestFFF() {
        System.out.println(xmlEncode("1234567890"));
        System.out.println(xmlEncode("&1234567&890"));
        System.out.println(xmlEncode("<1234567&890>"));
    } // of method

    //--------------------

    private static void runTestGGG() throws Exception {
        Tuple t = new Tuple();
        t.setAttribute("keyAA", "valAA");
        t.setAttribute("keyAA", "val&amp;BB");
        t.setAttribute("keyAA", "&lt;html&gt;");
        System.out.println(t);
        System.out.println("------------------");

        t = new Tuple(Tuple.parse(t.toString()));
        System.out.println(t);
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestGGG();
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
