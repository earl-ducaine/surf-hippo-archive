package edu.berkeley.guir.damask.event;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Control;

/** 
 * A source of ControlEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-01-2004 James Lin
 *                               Created ControlEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-01-2004
 */
public class ControlEventSource {
   
   private Vector/*<ControlListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public synchronized void addControlListener(final ControlListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public synchronized void removeControlListener(
      final ControlListener listener) {

      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires controlStateChanged events to listeners.
    */
   public void fireControlStateChanged(
      final Control e,
      final DeviceType deviceType) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ControlEvent event =
         new ControlEvent(e, ControlEvent.STATE_CHANGED, deviceType);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ControlListener listener = (ControlListener)i.next();
         listener.controlStateChanged(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires controlSignificanceChanged events to listeners.
    */
   public void fireControlSignificanceChanged(
      final Control e,
      final DeviceType deviceType) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ControlEvent event =
         new ControlEvent(e, ControlEvent.SIGNIFICANCE_CHANGED, deviceType);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ControlListener listener = (ControlListener)i.next();
         listener.controlSignificanceChanged(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires pageRegionChanged events to listeners.
    */
   public void firePageRegionChanged(
      final Control e,
      final DeviceType deviceType) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ControlEvent event =
         new ControlEvent(e, ControlEvent.PAGE_REGION_CHANGED, deviceType);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ControlListener listener = (ControlListener)i.next();
         listener.pageRegionChanged(event);
      }
   }
}
