package edu.berkeley.guir.damask.view.appevent;

import java.util.EventListener;

/** 
 * The listener interface for receiving events indicating that a document
 * has been changed.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-21-2003 James Lin
 *                               Created DocumentListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-21-2003
 */
public interface DocumentListener extends EventListener {
   
   /**
    * Invoked when a document has been modified.
    */
   void documentModified(DocumentEvent e);
   
   /**
    * Invoked when a document has been "cleaned" (i.e., there are no
    * unsaved changes).
    */
   void documentCleaned(DocumentEvent e);
   
   /**
    * Invoked when a document has been named or renamed.
    */
   void documentRenamed(DocumentEvent e);
   
   /**
    * Invoked when a document has been closed.
    */
   void documentClosed(DocumentEvent e);
   
   /**
    * Invoked when a document becomes busy. 
    */
   void documentBusyStarted(DocumentEvent e);
   
   /**
    * Invoked when a document stops being busy. 
    */
   void documentBusyStopped(DocumentEvent e);
   
   /**
    * Invoked when a canvas group for a document is added. 
    */
   void canvasGroupAdded(DocumentEvent e);
   
   /**
    * Invoked when a canvas group for a document is removed. 
    */
   void canvasGroupRemoved(DocumentEvent e);
}
