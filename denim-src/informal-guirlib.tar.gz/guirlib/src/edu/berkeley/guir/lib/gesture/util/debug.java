package edu.berkeley.guir.lib.gesture.util;

import java.awt.*;
import java.io.PrintStream;

/**
 * various routines useful for debugging
 */
public class debug
{

  private debug()
  {
  }
  
  public static String toString(Dimension d)
  {
    return d.width + "x" + d.height;
  }
  
  public static String sizesToString(Component c)
  {
    String result = "";
    
    result += toString(c.getSize());
    result += "\t";
    result += toString(c.getMinimumSize());
    result += "\t";
    result += toString(c.getPreferredSize());
    result += "\t";
    result += toString(c.getMaximumSize());
    return result;
  }

  public static String toString(Rectangle r)
  {
    return r.width + "x" + r.height + "+" + r.x + "+" + r.y;
  }

  public static String toString(Point p)
  {
    return p.x + "x" + p.y;
  }

  public static void printComponents(Container container, PrintStream out)
  {
    Component[] children = container.getComponents();
    if (children != null) {
      for (int i = 0; i < children.length; i++) {
	out.println("  " + i + "\t" + children[i]);
      }
    }
  }

  public static void printStackTrace(PrintStream printStream)
  {
    try {
      throw new Exception("Backtrace");
    }
    catch (Exception e) {
      e.printStackTrace(printStream);
    }
  }
}
