package edu.berkeley.guir.denim;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;

import edu.berkeley.guir.denim.dialogs.FileDialogs;
import edu.berkeley.guir.denim.dialogs.ScenarioManagerDialog;
import edu.berkeley.guir.lib.satin.image.SatinImageLib;

/**
 * The window that is opened when editing or creating scenarios
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  
 * </PRE>
 *
 * @author  Jenny Lee</A> (
 *          <A HREF="mailto:deneb717@uclink.berkeley.edu">deneb717@uclink.berkeley.edu</A> )
 * @author  John Brian Kirby</A> (
 *          <A HREF="mailto:jbkirby@uclink.berkeley.edu">jbkirby@uclink.berkeley.edu</A> )
 *
 * @since   JDK 1.4
 * @version Version 
 */
public class DenimScenarioEditor extends DenimRunWindow {

/*  private JToolBar navigationToolbar;
   private JToolBar maintenanceToolbar;
   private JToolBar recordToolbar;
*/
   
   private JPanel navigationPanel;
   private JPanel timeInfoPanel;
   private JPanel maintenancePanel;
   private JPanel recordPanel;
   private JPanel metaPanel;  // Contains the maintenance and record panels.
   
   JLabel timeOnPageLabel;
   JLabel totalTimeLabel;
   
   TimeTracker timeOnPageTracker;
   TimeTracker totalTimeTracker;
   
   private JSplitPane splitPane;
   
   private int labelPanelWidth = 0;
   private int labelPanelHeight = 0;
   private int nextRecordedLabelYLoc = 0;
   
   private JScrollPane scrollPane;
   
   private JPanel labelPanel;
   
   private JButton backButton;
   private JButton forwardButton;
   private JButton refreshButton;
   private JButton recordButton;
   private JButton stopButton;
   private JButton undoButton;
   private JButton playButton;
   private JButton pauseButton;
   private JButton saveButton;
   private JButton cancelButton;
   
   private ImageIcon recordIcon = new ImageIcon(Denim.class.getResource("images/toolbar/record.gif"));
   private ImageIcon stopIcon = new ImageIcon(Denim.class.getResource("images/toolbar/stop_record.gif"));
   private ImageIcon playIcon = new ImageIcon(Denim.class.getResource("images/toolbar/play_button.gif"));
   
   private JTextField nameField;
   
   private Scenario currentScenario;
   private LinkedList tempScenList;
   private ScenarioNode tempNode;
   
   private javax.swing.Timer pageTimer;
   private Timer playTimer = new Timer();;
   
   private boolean isPlaying = false;
   private boolean isRecording = false;
   private boolean isUndo;
   
   private ScenarioManagerDialog scenManager;
   private DenimScenarioEditor scenEditor;
   
   private DenimPanel currentPanel;
   private ScenarioNode scenarioNodeBuffer;
   
   /**
    * This constructor is called to create a new, empty Scenario beginning
    * at the sheet's home panel.
    */
   public DenimScenarioEditor(DenimSheet sheet, ScenarioManagerDialog managerDialog) {
      this(new Scenario(), new ScenarioNode(sheet.getHomePanel()), sheet, managerDialog);
   }
   
   /** 
    * This is our main constructor, called from all lesser constructors.
    */
   public DenimScenarioEditor(Scenario scenario, ScenarioNode startingNode, DenimSheet sheet, ScenarioManagerDialog managerDialog) {
 
      super(scenario.getTitle(), startingNode.getPanel());
      currentScenario = scenario;
      scenManager = managerDialog;
      scenManager.incEditCount();
      scenEditor = this;    
      
      
      
      // This should be set by the record button to allow browsing without
      // recording.
      // isRecording = true;
      
      metaPanel = new JPanel();
      metaPanel.setLayout(new BoxLayout(metaPanel, BoxLayout.Y_AXIS));
      
      timeInfoPanel = new JPanel();
      timeInfoPanel.setLayout(new BoxLayout(timeInfoPanel, BoxLayout.Y_AXIS));
      
      timeOnPageTracker = new TimeTracker(startingNode.getLongTime());
      totalTimeTracker = new TimeTracker(scenario.getLongTime());
      
      timeOnPageLabel = new JLabel(timeOnPageTracker.toString());
      totalTimeLabel = new JLabel(totalTimeTracker.toString());
      
      timeInfoPanel.setLayout(new GridLayout(2,2, 2, 0));
      
      timeInfoPanel.add(new JLabel("Time on page: "));
      timeInfoPanel.add(timeOnPageLabel);
      timeInfoPanel.add(new JLabel("Total time: "));
      timeInfoPanel.add(totalTimeLabel);
    
      pageTimer = new javax.swing.Timer(100, pageTimerListener);
      
      labelPanel = new JPanel();
      labelPanel.setLayout(new BoxLayout(labelPanel, BoxLayout.Y_AXIS));
      labelPanel.setBackground(Color.WHITE);
      labelPanel.setPreferredSize(new Dimension(50, 10));
      labelPanelWidth = labelPanel.getWidth();
      labelPanelHeight = labelPanel.getHeight();
      
      scrollPane = new JScrollPane(labelPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      
      splitPane =
         new JSplitPane(
            JSplitPane.HORIZONTAL_SPLIT,
            scrollPane,
            runSheet);
      //splitPane.setContinuousLayout(true);
      splitPane.setOneTouchExpandable(false);
      splitPane.addPropertyChangeListener(JSplitPane.DIVIDER_LOCATION_PROPERTY, new splitPanePropertyChange());
            
      // Setup editor toolbars.
      setupNavigationPanel();
      setupMaintenancePanel();
      setupRecordPanel();
      
      metaPanel.add(maintenancePanel);
      metaPanel.add(recordPanel);
  
      nameField.setText(getTitle());
  
      // Clean up the RunSheet layout in preparation for our new, futuristic
      // ScenarioEditor layout.
      this.getContentPane().remove(toolbar);
      this.getContentPane().remove(runSheet);
      //this.getContentPane().setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
      
      // These arrangements are very temporary- gotta make it look good in the future!
      
      this.getContentPane().add(navigationPanel, BorderLayout.NORTH);
      this.getContentPane().add(splitPane, BorderLayout.CENTER);
      this.getContentPane().add(metaPanel, BorderLayout.SOUTH);
      
      //here is the window handler
      WindowHandler wh = new WindowHandler();
      this.addWindowListener(wh);
      
      if(currentScenario.getNodes().size() > 0) loadScen();
      
      // TODO: Clean up these values.
      setSize(runSheet.getVisibleWidth() + labelPanelWidth + 15,
              runSheet.getVisibleHeight() + 70);
      
   }
   
   public void loadScen() {
      DenimLabel curLabel;
      int max = Integer.MIN_VALUE, cVal;
      for(Iterator i = currentScenario.getNodes().iterator(); i.hasNext(); ) {

         curLabel =  ((ScenarioNode)i.next()).getPanel().getLabel();
         cVal = addSideLabel(curLabel.getPhrase());
         max = (cVal > max) ? cVal : max;
                  
      }
      resetWidth(max);
      labelPanel.revalidate();
   }
   
   class WindowHandler extends WindowAdapter {
      // Handler for window closing event. 
      public void windowClosing(WindowEvent e) {
         scenManager.decEditCount();
         //System.exit(0); // End the application
      }
   }
   
   /**
    * Creates and returns the upper toolbar containing the navigation buttons.
    */
   private void setupNavigationPanel() {
      //navigationToolbar = new JToolBar();
      navigationPanel = new JPanel();
      navigationPanel.setLayout(new BoxLayout(navigationPanel, BoxLayout.X_AXIS));
      
      //// 1. Set up the back button.
      backButton =
         new JButton(
            "Back",
            new ImageIcon(Denim.class.getResource("images/toolbar/back.gif")));
      backButton.addActionListener(new BackButtonAction());
      backButton.setDisabledIcon(
         new ImageIcon(
            Denim.class.getResource("images/toolbar/back_disabled.gif")));
      backButton.setEnabled(false);
      navigationPanel.add(backButton);
      
      //// 2. Set up the forward button.
      forwardButton =
         new JButton(
            "Forward",
            new ImageIcon(
               Denim.class.getResource("images/toolbar/forward.gif")));
      forwardButton.addActionListener(new NextButtonAction());
      forwardButton.setDisabledIcon(
         new ImageIcon(
            Denim.class.getResource("images/toolbar/forward_disabled.gif")));
      forwardButton.setEnabled(false);
      navigationPanel.add(forwardButton);

      //// 3. Set up the refresh button.
      refreshButton =
         new JButton(
            "Refresh",
            new ImageIcon(
               Denim.class.getResource("images/toolbar/refresh.gif")));
      refreshButton.addActionListener(new RefreshButtonAction());
      refreshButton.setEnabled(true);
      navigationPanel.add(refreshButton);
      
      navigationPanel.add(Box.createRigidArea(new Dimension(5,0)));
      navigationPanel.add(timeInfoPanel);
      navigationPanel.add(Box.createHorizontalGlue());

      navigationPanel.setBorder(BorderFactory.createEtchedBorder());

   } // of method

   /**
    * Creates and returns the maintenance toolbar containing metadata about the current scenario.
    */
   private void setupMaintenancePanel() {
      maintenancePanel = new JPanel();

      maintenancePanel.add(new JLabel("Scenario Name: "));

      //// 1. Set up the name text field
      nameField = new JTextField("", 20);
      /* probably don't need this line
      nameField.addActionListener(new NameFieldAction()); */
      maintenancePanel.add(nameField);

      //// 2. Set up the Save button
      // SHOULD WE RENAME THIS 'SAVE'?
      
      saveButton = new JButton("Save");
      saveButton.addActionListener(new SaveButtonAction());
      saveButton.setEnabled(true);
      saveButton.setVisible(true);
      maintenancePanel.add(saveButton);

      //// 2. Set up the Cancel button
      cancelButton = new JButton("Cancel");
      cancelButton.addActionListener(new CancelButtonAction());
      cancelButton.setEnabled(true);
      cancelButton.setVisible(true);
      maintenancePanel.add(cancelButton);

   } // of method

   /**
    * Creates and returns the record toolbar with playback buttons.
    */
   private void setupRecordPanel() {
      recordPanel = new JPanel();
      recordPanel.setLayout(new BoxLayout(recordPanel, BoxLayout.X_AXIS));
      //recordToolbar.setOrientation(SwingConstants.VERTICAL);
      
      recordPanel.add(Box.createHorizontalGlue());
      
      //// 4. Set up the play button
      // SHOULD WE CALL THIS 'PREVIEW'?
      
      playButton = 
         new JButton(
            "Play",
            playIcon);
      playButton.addActionListener(new PlayButtonAction());
      playButton.setEnabled(true);
      playButton.setVisible(true);
      recordPanel.add(playButton);
      
      pauseButton = 
         new JButton(
            "Pause",
            new ImageIcon(
               Denim.class.getResource("images/toolbar/pause.gif")));
      pauseButton.addActionListener(new PauseButtonAction());
      pauseButton.setEnabled(false);
      pauseButton.setVisible(true);
      recordPanel.add(pauseButton);
      
      //// 1. Set up the record button
      recordButton =
         new JButton(
            "Record",
            recordIcon);
      recordButton.addActionListener(new RecordButtonAction());
      recordButton.setEnabled(true);
      recordButton.setVisible(true);
      recordPanel.add(recordButton);

      //// 2. Set up the undo button
      undoButton = 
         new JButton(
            "Undo",
            new ImageIcon(
               Denim.class.getResource("images/toolbar/undo.gif")));
      undoButton.addActionListener(new UndoButtonAction());
      undoButton.setEnabled(false);
      undoButton.setVisible(true);
      recordPanel.add(undoButton);

      //// 3. Set up the stop button
      /*
      stopButton =
         new JButton(
            "Stop",
            new ImageIcon(
               Denim.class.getResource("images/toolbar/stop_record.gif")));
      stopButton.addActionListener(new StopButtonAction());
      stopButton.setVisible(true);
      stopButton.setEnabled(false);
      recordPanel.add(stopButton);
      */
      
   } // of method
   
   public boolean isRecording() {
      return isRecording;
   }

   public JPanel getLabelPanel() {
      return labelPanel;
   }
   
   public void realAssert(boolean exp, String txt) {
      if(!exp) throw new Error("Assertion Error"+txt);
   }
   
   public int addSideLabel(DenimText phrase) {
          phrase.getStyleRef().setFillColor(Color.white);
         BufferedImage img = SatinImageLib.toImage(phrase);
         Icon icon = new ImageIcon(img);
         JLabel label = new JLabel();
         label.setIcon(icon);
         label.setBounds(0, 0, img.getWidth(null), img.getHeight(null));
         labelPanel.add(label);
         label.setLocation(0, nextRecordedLabelYLoc);
         nextRecordedLabelYLoc = nextRecordedLabelYLoc + (int)label.getHeight();

         // Resize the labelPanel to take into account the new label.
         labelPanelWidth = (int)Math.max(labelPanelWidth, label.getWidth());
         labelPanelHeight += label.getHeight();
         labelPanel.setPreferredSize(new Dimension(labelPanelWidth, labelPanelHeight));
         
         return labelPanelWidth;
   }
   
   public void resetWidth(int widthChange) {
         widthChange = labelPanelWidth - widthChange;
         // Reposition the split pane divider (NOTE: the addition of 4 pixels
         // ensures that the scroll pane's horizontal scroll bar won't show up
         // all the time.
         // TODO: Establish a constant MAX_LABEL_PANEL_WIDTH, a number of pixels
         // beyond which the label panel will not widen to prevent the panel from
         // becoming annoyingly large. 
         if (widthChange > 0) {
            splitPane.setDividerLocation(labelPanelWidth + 4);
            this.setSize(this.getWidth() + widthChange, this.getHeight());
         }
   }
   
   
   
   
   public void recordPanel(DenimPanel p, boolean restart) {  
      if (restart) {
         nextRecordedLabelYLoc = 0;
         //recordedPanels = new ArrayList();
      }
      
      // This must be replaced with a modification of the Scenario object.
      //recordedPanels.add(p);
      // position label
      if(!isUndo) {
         resetWidth(addSideLabel(p.getLabel().getPhrase()));
         labelPanel.revalidate();
         
         //labelPanel.revalidate();
         //wants time in milliseconds -- 
         if(scenarioNodeBuffer != null) { 
            scenarioNodeBuffer.setTime(new Scenario.Time(timeOnPageTracker.mSeconds));
           ((LinkedList)currentScenario.getNodes()).addLast(scenarioNodeBuffer);
         }
         scenarioNodeBuffer = new ScenarioNode(p);
         undoButton.setEnabled(true);
         // TODO: Record the elapsed timeOnPage to the ScenarioNode once it's been
         //       adapted to take seconds instead of Strings.
         timeOnPageTracker.setSeconds(0);
      } 
 /*     } else {
         isUndo = false;
         
         phrase = ((DenimPanel)nextPanels.firstElement()).getLabel().getPhrase();
         phrase.getStyleRef().setFillColor(Color.white);
         BufferedImage img = SatinImageLib.toImage(phrase);
         Icon icon = new ImageIcon(img);
         JLabel label = new JLabel();
         label.setIcon(icon);
         label.setBounds(0, 0, img.getWidth(null), img.getHeight(null));
         labelPanel.remove(label);
         label.setLocation(0, nextRecordedLabelYLoc);
         nextRecordedLabelYLoc = nextRecordedLabelYLoc + (int)label.getHeight();
         
//         for(int i = 0; i < labelPanel.countComponents(); i++) {
//            JLabel temp = (JLabel)labelPanel.getComponent(i);
//            if(temp.getIcon().equals(icon))
//               labelPanel.remove(temp);
//         } // jenjen

         // re-position split panel divider after resizing frame
         splitPaneDivider = (int)Math.max(splitPaneDivider, label.getWidth());
         labelPanelHeight += label.getHeight();
         labelPanel.setPreferredSize(new Dimension(splitPaneDivider, labelPanelHeight));
         //setBounds(getX(), getY(), splitPaneDivider+runSheet.getVisibleWidth(), getHeight());
         labelPanel.revalidate();
         splitPane.setDividerLocation(splitPaneDivider + 3);
         //splitPane.setOneTouchExpandable(false);
         
         currentScenario.getNodes().remove(new ScenarioNode(p));
         if(currentScenario.getNodes().size() == 0)
            undoButton.setEnabled(false);
      }
*/      
      labelPanel.validate();
      scrollPane.validate();
      labelPanel.repaint();
   }
   
   /** 
    * Button behavior invariants:
    * 
    * Record and Stop are mutually exclusive actions, so should be controlled by alternating the
    *  function of a single button.  Since the initial page from which a traversal originates (the
    *  home page) is an important part of a scenario, if the scenario is empty when record is pushed,
    *  we should record the current page as part of the scenario in addition to any link traversals
    *  that follow.  If some traversals are recorded, then recording is stopped and the user navigates
    *  to some other page and hits record again, we have to go back to the last page that was recorded
    *  to make sure that scenarios remain valid site traversals.  Perhaps we should prompt the user
    *  before doing this?
    * 
    * Play is only defined for scenarios with at least one recorded page (for which playback would
    *  simply display that page).  Hence we should disable it for new scenarios which have not yet
    *  had a home page recorded by the process above.
    * 
    * Undo should at least undo the most recent action.  Perhaps we want to keep a queue of user 
    *  actions to support multi-level undo?  The button should also be disabled until at least one
    *  action has been recorded, as well as when the action queue is empty.
    * 
    * Cancel should simply close the editor, making no changes to existing scenarios and discarding
    *  newly created ones.
    * 
    * Save should be disabled during recording.
    */
   
   class RefreshButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         if(isRecording) {
            tempNode = new ScenarioNode(currentPanel);
            currentScenario.getNodes().add(tempNode);
         }
         renderPanel(DenimScenarioEditor.this.currentPanel);
         
      }
   } // of inner class 
   
   class SaveButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         
         // This will always add an entirely new scenario to the sheet's list;
         // change this when the manager provides a better method.      
         Scenario toRep;
         if((toRep = scenManager.getNameIn(nameField.getText())) == null) {
            currentScenario.setTitle(nameField.getText());
         } else {
            int i = FileDialogs.showPromptForScenarioOvewrite(scenEditor, nameField.getText());
            if(i != 1)
               return;
            scenManager.removeScenario(toRep);
         }
         

         //note that the overall time rarely adds up to the sum of page times
         //currentScenario.setTime( new Scenario.Time(totalTimeTracker.mSeconds));
         currentScenario.validateTime();
         scenManager.addScenario(currentScenario);
         scenManager.decEditCount();
         scenEditor.dispose();
      
      }
   } // of inner class

   //------------------------------------------------------------------

   class CancelButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         scenEditor.dispose();
      }
   } // of inner class
   
   //------------------------------------------------------------------
   
   class RecordButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         isRecording = !isRecording;
         if (isRecording) {
            recordButton.setText("Stop");
            recordButton.setIcon(stopIcon);
            saveButton.setEnabled(false);
            if(currentScenario.nodes.size() != 0)
               undoButton.setEnabled(true);
            pageTimer.start();
            
            // Record the currently displayed page as the start point of this scenario.
            recordPanel(runSheet.getPanel(), false);
         } else {
            if(scenarioNodeBuffer != null) { 
               scenarioNodeBuffer.setTime(new Scenario.Time(timeOnPageTracker.mSeconds));
               currentScenario.getNodes().add(scenarioNodeBuffer);
            }
            recordButton.setText("Record");
            recordButton.setIcon(recordIcon);
            saveButton.setEnabled(true);
            undoButton.setEnabled(false);
            pageTimer.restart();
            pageTimer.stop();

         }
         recordPanel.repaint();
      }
   } // of inner class
   
   //------------------------------------------------------------------
   
   class StopRecordButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {

      }
   } // of inner class

   //------------------------------------------------------------------


   class PlayBack extends TimerTask {
      ScenarioNode curScenNode;
      Iterator scens;
      
      public PlayBack(Iterator scens) {
         this.scens = scens;
      }
      
       public void run() {
         if(scens.hasNext()) {
            playTimer = new Timer();
            ScenarioNode curScenNode = (ScenarioNode)scens.next();
           currentPanel = curScenNode.getPanel();
           renderPanel(currentPanel);
          
           timeOnPageLabel.setText(curScenNode.getStringTime());
            
           playTimer.schedule(new PlayBack(this.scens), curScenNode.getLongTime());
         } else {
           scheduled = false;
           isPlaying = !isPlaying;
           playTimer.cancel();
           playButton.setText("Play");
           playButton.setIcon(playIcon);
           saveButton.setEnabled(true);
           recordPanel.repaint();
         }
       }
   }
   
   boolean scheduled;
   class PlayButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         isPlaying = !isPlaying;
         if (isPlaying) {
            playButton.setText("Stop");
            playButton.setIcon(stopIcon);
            saveButton.setEnabled(false);
            recordPanel.repaint();
            playScenario();
            
         } else {
            scheduled = false;
            playTimer.cancel();
            playButton.setText("Play");
            playButton.setIcon(playIcon);
            saveButton.setEnabled(true);
            recordPanel.repaint();
         }
      }
   }
   
   public void playScenario() {
         Iterator scens = currentScenario.iterator();
         playTimer = new Timer();
         TimerTask task = new PlayBack(scens);
         
         if(scens.hasNext()) {
            
            // wait ten seconds before executing...

            System.out.println("starting scheduled loop");
            // wait ten seconds before executing...
            if(!scheduled) {
               playTimer.schedule( task, 0 );
               scheduled = true; 
            }        
         }
      } // of inner class
   
  
   //------------------------------------------------------------------
   
      /**
    * Goes to the previous panel in the history stack, or does nothing if
    * there isn't one.
    */
   public void gotoPreviousPanel() {
      if (!prevPanels.empty()) {
         nextPanels.push(currentPanel);
         //debug.println("new next = " + currentPanel.getUniqueID());
         currentPanel = (DenimPanel)prevPanels.pop();
         
         // QUESTION: Do we really want to record back button actions as traversals?
         // Would it be more appropriate to _remove_ the last panel?  I guess it's a
         // matter of taste...
         
         currentScenario.getNodes().add(new ScenarioNode(currentPanel));
         
         renderPanel(currentPanel);
         //debug.println("displaying = " + currentPanel.getUniqueID());
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Goes to the next panel in the history stack, or does nothing if
    * there isn't one.
    */
   public void gotoNextPanel() {
      if (!nextPanels.empty()) {
         prevPanels.push(currentPanel);
         //debug.println("new previous = " + currentPanel.getUniqueID());
         currentPanel = (DenimPanel)nextPanels.pop();
         
         currentScenario.getNodes().add(new ScenarioNode(currentPanel));
         
         renderPanel(currentPanel);
         //debug.println("displaying = " + currentPanel.getUniqueID());
      }
   } // of method
   
  //-----------------------------------------------------------------
   
   class UndoButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         isUndo = true;
         
         // I don't think we can assume that the undo behaves exactly like back,
         // for example, if the user hits back and THEN undo, we'd like to undo
         // the back command, not go back again.  We should maintain a record of
         // user actions to support this (depth TBD). -JBK
         
         if(currentScenario.size() != 0) {
            currentScenario.nodes.removeLast();
            
         }
         // add more code to remove panel from split pane
         
         gotoPreviousPanel();
      }
   } // of inner class

   //------------------------------------------------------------------

   class PauseButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         if(!playButton.isEnabled()) {
            playButton.setEnabled(true);
         }
         if(isRecording == true) {
            isRecording = false;
            recordButton.setEnabled(true);
            undoButton.setEnabled(false);
         }
         stopButton.setEnabled(false);
         recordPanel.repaint();
      }
   } // of inner class
   
   /**
    * Listens for messages from the pageTimer, which should fire once per second
    * while in record mode.  Increments the second values of the per-page and
    * per-scenario TimeTrackers.
    */
   ActionListener pageTimerListener = new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
         timeOnPageTracker.incSeconds(100);
         totalTimeTracker.incSeconds(100); 
         timeOnPageLabel.setText(timeOnPageTracker.toString());
         totalTimeLabel.setText(totalTimeTracker.toString());
         
      }
   };
   
   class splitPanePropertyChange implements PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent evt) {
         //scrollPane.repaint();
         //runSheet.repaint();
         //System.out.println("Intercepted splitPane property change.");
         runSheet.damage(DAMAGE_LATER);
         runSheet.repaint();
         scenEditor.update();
      }
   }
  
   /**
    * Formats an internal representation based on seconds elapsed into a more
    * traditional hour:minute:second tuple via the toString() method.
    */
   
   
   /*
    * note I think that milliseconds are a much more reasonble unit of measure ment.
   class TimeTracker {
      long seconds;
      
      public TimeTracker() {
         seconds = 0;
      }
   
      public TimeTracker(long seconds) {
         this.seconds = seconds;
      }
     
      public TimeTracker(int hours, int minutes, int seconds) {
         this.seconds = seconds + (60 * minutes) + (3600 * hours);
      }
      
      public void setSeconds(long seconds) {
         this.seconds = seconds;
      }
      
      /**
       * Increment the second count for this tracker.
      
      public void incSeconds() {
         seconds++;
      }
      
      public String toString() {
         String result = new String();
         
         // For easier reading, only show the hour field for times > 59mins, 59 secs.
         if (seconds < 3600) {
            result = (seconds / 60) + ":" + ((seconds % 60 < 10) ? "0":"") + (seconds % 60); 
         } else {
            result = (seconds / 3600) + ":" + ((seconds % 3600) / 60) + ":" + (((seconds % 3600) % 60 < 10) ? "0":"") + ((seconds % 3600) % 60); 
         }        
         return result;
      }
   
   }
   */
   
    class TimeTracker {
      long mSeconds;
      
      public TimeTracker() {
         mSeconds = 0;
      }
   
      public TimeTracker(long seconds) {
         this.mSeconds = seconds;
      }
     
      public TimeTracker(int hours, int minutes, int seconds) {
         this.mSeconds = seconds + (60 * minutes) + (3600 * hours);
      }
      
      public void setSeconds(long seconds) {
         this.mSeconds = seconds;
      }
      
      /**
       * Increment the second count for this tracker.
      */
      public void incSeconds(long mInc) {
         mSeconds+=mInc;
      }
      
      public String toString() {
         /*
         String result = new String();
         
         long seconds = (int)mSeconds / 1000;
         // For easier reading, only show the hour field for times > 59mins, 59 secs.
         if (mSeconds < 3600) {
            result = (seconds / (60)) + ":" + ((seconds % 60 < 10) ? "0":"") + (seconds % 60); 
         } else {
            result = (seconds / (3600)) + ":" + ((seconds % 3600) / 60) + ":" + (((seconds % 3600) % 60 < 10) ? "0":"") + ((seconds % 3600) % 60); 
         }        
         return result;
         */
         return new Scenario.Time(mSeconds).toString();
      }
   
   }
}







