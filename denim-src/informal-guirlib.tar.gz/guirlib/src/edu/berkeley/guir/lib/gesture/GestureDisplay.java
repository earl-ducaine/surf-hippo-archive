package edu.berkeley.guir.lib.gesture;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.DateFormat;
import javax.swing.*;

/**
 * Display a single gesture.  Can display auxiliary data such as
 * author and creation date.
 */
public class GestureDisplay extends JPanel implements Observer {
  final static DateFormat dateFormat =
    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
  Gesture gesture;
  GesturePointsDisplay gpDisplay;
  JTextField authorField;
  JLabel creationDateLabel;
  Box infoPanel;
  boolean authorVisible = false;
  static Class displayClass = GesturePointsDisplay.class;
  
  public GestureDisplay()
  {
    this(null);
  }

  public GestureDisplay(Gesture g)
  {
    this(g, 0, 0);
  }

  public GestureDisplay(Gesture g, JScrollPane scrollPane)
  {
    this(g);
  }

  /**
   * Set offsets and gesture at the same time
   */
  public GestureDisplay(Gesture g, int xoffset, int yoffset)
  {
    super();
    gesture = g;
    try {
      gpDisplay = (GesturePointsDisplay) displayClass.newInstance();
    }
    catch (InstantiationException e) { /* todo */ }
    catch (IllegalAccessException e) { /* todo */ }
    gpDisplay.setGesture(g);
    gpDisplay.setOffset(xoffset, yoffset);
    //gpDisplay = new GesturePointsDisplay(g, xoffset, yoffset);
    buildUI();
  }

  public Gesture getGesture()
  {
    return gesture;
  }

  public void setGesture(Gesture g)
  {
    gesture = g;
    gpDisplay.setGesture(g);
    updateProperties();
  }
  
  public void update(Observable gesture, Object arg)
  {
    if (arg != null) {
      updateProperties();
    }
  }

  protected void buildUI()
  {
    setLayout(new BorderLayout());
    add(gpDisplay, BorderLayout.CENTER);
    // It's probably not ideal to create this if it won't ever
    // get shown, but it's easier this way
    infoPanel = new Box(BoxLayout.Y_AXIS);
    authorField = new JTextField();
    authorField.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e)
	{
	  gesture.setAuthor(authorField.getText());
	}
    });
    infoPanel.add(authorField);
    creationDateLabel = new JLabel();
    infoPanel.add(creationDateLabel);
    if (authorVisible) {
      add(infoPanel, BorderLayout.SOUTH);
    }
    setBackground(Color.white);
    updateProperties();
  }

  protected void rebuildUI()
  {
    removeAll();
    buildUI();
  }
  
  protected void updateProperties()
  {
    if (gesture != null) {
      String author = gesture.getAuthor();
      authorField.setText((author == null) ? "(unknown author)" : author);
      Date date = gesture.getCreationDate();
      // handle old files that don't have creation date set
      String dateText;
      if (date == null) {
	dateText = "(unknown date)";
      }
      else {
	dateText = dateFormat.format(date);
      }
      creationDateLabel.setText(dateText);
      repaint();
    }
  }
  
  // convenience functions
  
  public void setSelected(boolean on)
  {
    gpDisplay.setSelected(on);
  }

  public boolean getSelected()
  {
    return gpDisplay.getSelected();
  }

  public boolean toggleSelected()
  {
    return gpDisplay.toggleSelected();
  }

  /**
   * Whether to draw the individual points that compose the gesture
   */
  public void setShowPoints(boolean on)
  {
    gpDisplay.setShowPoints(on);
  }

  public boolean getShowPoints()
  {
    return gpDisplay.getShowPoints();
  }

  public boolean getShowSelected()
  {
    return gpDisplay.getShowSelected();
  }

  public void setOffset(int x, int y)
  {
    gpDisplay.setOffset(x, y);
  }

  /**
   * If true, disables showing the fact that the gesture is selected
   */
  public void setShowSelected(boolean on)
  {
    gpDisplay.setShowSelected(on);
  }

  /**
   * Borrowed narrowing from emacs.  Right now, makes narrowed things
   * highlight instead of hiding non-narrowed things.
   */
  public void setNarrowed(boolean on)
  {
    gpDisplay.setNarrowed(on);
  }

  public void toggleNarrowed()
  {
    gpDisplay.toggleNarrowed();
  }

  public void setAuthorVisible(boolean on)
  {
    if (authorVisible != on) {
      authorVisible = on;
      if (on) {
	add(infoPanel, BorderLayout.SOUTH);
      }
      else {
	remove(infoPanel);
      }
      validate();
    }
  }

  public GesturePointsDisplay getGesturePointsDisplay()
  {
    return gpDisplay;
  }

  static public void setPointsDisplayClass(Class displayClass)
  {
    if (!GesturePointsDisplay.class.isAssignableFrom(displayClass)) {
      throw new IllegalArgumentException
	("displayClass must be a GesturePointsDisplay");
    }
    if (GestureDisplay.displayClass != displayClass) {
      GestureDisplay.displayClass = displayClass;
    }
  }
}
