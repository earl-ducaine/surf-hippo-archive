package edu.berkeley.guir.damask.event;

import java.util.EventListener;

/** 
 * The listener interface for receiving events regarding when something about
 * a dialog has changed. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-10-2004 James Lin
 *                               Created DialogListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-10-2004
 */
public interface DialogListener extends EventListener {
   
   /**
    * Invoked when the initial condition of a dialog is changed.
    */
   void initialConditionChanged(DialogEvent e);
}
