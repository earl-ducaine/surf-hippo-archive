package edu.berkeley.guir.denim.io;

import java.io.*;

import org.w3c.dom.*;

import edu.berkeley.guir.lib.satin.SatinConstants;


//===========================================================================
//===   SATINSHEETDOMWRITER  =====================================================

/**
 * Takes the DOM representing the sheet and writes it out to a file as XML.
 * Converting the sheet to a DOM is done by {@link DOMUtils}.
 */
public class SVGDOMWriter
   /* Based on DOMWriter
    *
    * (C) Copyright IBM Corp. 1999  All rights reserved.
    *
    * US Government Users Restricted Rights Use, duplication or
    * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
    *
    * The program is provided "as is" without any warranty express or
    * implied, including the warranty of non-infringement and the implied
    * warranties of merchantibility and fitness for a particular purpose.
    * IBM will not be liable for any damages suffered by you as a result
    * of using the Program. In no event will IBM be liable for any
    * special, indirect or consequential damages or lost profits even if
    * IBM has been advised of the possibility of their occurrence. IBM
    * will not be liable for any third party claims against you.
    */


   implements SatinConstants {

   private FileOutputStream fostream;
   private StringWriter strWriter;
   private PrintWriter out;
   private boolean canonical = false;

   public SVGDOMWriter(String filename)
   throws FileNotFoundException, UnsupportedEncodingException {
      fostream = new FileOutputStream(filename);
      strWriter = null;
      out = new PrintWriter(fostream);
   }

   public SVGDOMWriter(StringWriter strWriter) {
      fostream = null;
      this.strWriter = strWriter;
      out = new PrintWriter(strWriter);
   }

   public String toString() {
      if (strWriter != null) {
         return strWriter.toString();
      }
      else {
         return null;
      }
   }

   public void close() throws IOException {
      if (fostream != null) {
         fostream.flush();
         fostream.close();
      }
      else {
         strWriter.flush();
         strWriter.close();
      }
   }

   /** Prints the specified node, recursively. */
   public void print(Node node) {

      // is there anything to do?
      if ( node == null ) {
         return;
      }

      int type = node.getNodeType();
      switch ( type ) {
         // print document
         case Node.DOCUMENT_NODE: {
               out.println("<?xml version=\"1.0\"?>");
               Element root = ((Document)node).getDocumentElement();
               out.print("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 20001102//EN\" ");
               out.print("\"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\">");
               print(root);
               out.flush();
               break;
            }

            // print element with attributes
         case Node.ELEMENT_NODE: {
               out.print('<');
               out.print(node.getNodeName());
               Attr attrs[] = sortAttributes(node.getAttributes());
               for ( int i = 0; i < attrs.length; i++ ) {
                  Attr attr = attrs[i];
                  out.print(' ');
                  out.print(attr.getNodeName());
                  out.print("=\"");
                  out.print(normalize(attr.getNodeValue()));
                  out.print('"');
               }
               out.print('>');
               NodeList children = node.getChildNodes();
               if ( children != null ) {
                  int len = children.getLength();
                  for ( int i = 0; i < len; i++ ) {
                     print(children.item(i));
                  }
               }
               break;
            }

            // handle entity reference nodes
         case Node.ENTITY_REFERENCE_NODE: {
               if ( canonical ) {
                  NodeList children = node.getChildNodes();
                  if ( children != null ) {
                     int len = children.getLength();
                     for ( int i = 0; i < len; i++ ) {
                        print(children.item(i));
                     }
                  }
               } else {
                  out.print('&');
                  out.print(node.getNodeName());
                  out.print(';');
               }
               break;
            }

            // print cdata sections
         case Node.CDATA_SECTION_NODE: {
               if ( canonical ) {
                  out.print(normalize(node.getNodeValue()));
               } else {
                  out.print("<![CDATA[");
                  out.print(node.getNodeValue());
                  out.print("]]>");
               }
               break;
            }

            // print text
         case Node.TEXT_NODE: {
               out.print(normalize(node.getNodeValue()));
               break;
            }

            // print processing instruction
         case Node.PROCESSING_INSTRUCTION_NODE: {
               out.print("<?");
               out.print(node.getNodeName());
               String data = node.getNodeValue();
               if ( data != null && data.length() > 0 ) {
                  out.print(' ');
                  out.print(data);
               }
               out.print("?>");
               break;
            }
      }

      if ( type == Node.ELEMENT_NODE ) {
         out.print("</");
         out.print(node.getNodeName());
         out.print('>');
      }

      out.flush();

   } // print(Node)

   /** Returns a sorted list of attributes. */
   protected Attr[] sortAttributes(NamedNodeMap attrs) {

      int len = (attrs != null) ? attrs.getLength() : 0;
      Attr array[] = new Attr[len];
      for ( int i = 0; i < len; i++ ) {
         array[i] = (Attr)attrs.item(i);
      }
      for ( int i = 0; i < len - 1; i++ ) {
         String name  = array[i].getNodeName();
         int    index = i;
         for ( int j = i + 1; j < len; j++ ) {
            String curName = array[j].getNodeName();
            if ( curName.compareTo(name) < 0 ) {
               name  = curName;
               index = j;
            }
         }
         if ( index != i ) {
            Attr temp    = array[i];
            array[i]     = array[index];
            array[index] = temp;
         }
      }

      return (array);

   } // sortAttributes(NamedNodeMap):Attr[]


   /** Normalizes the given string. */
   protected String normalize(String s) {
      StringBuffer str = new StringBuffer();

      int len = (s != null) ? s.length() : 0;
      for ( int i = 0; i < len; i++ ) {
         char ch = s.charAt(i);
         if ((int)ch > 127) {
            str.append("&#");
            str.append(Integer.toString(ch));
            str.append(";");
         }
         else {
            switch ( ch ) {
               case '<': {
                     str.append("&lt;");
                     break;
                  }
               case '>': {
                     str.append("&gt;");
                     break;
                  }
               case '&': {
                     str.append("&amp;");
                     break;
                  }
               case '"': {
                     str.append("&quot;");
                     break;
                  }
               case '\r':
               case '\n': {
                     if ( canonical ) {
                        str.append("&#");
                        str.append(Integer.toString(ch));
                        str.append(';');
                        break;
                     }
                     // else, default append char
                  }
               default: {
                     str.append(ch);
                  }
            }
         }
      }
      return (str.toString());

   } // normalize(String):String

}

//===  SVGDOMWriter  =====================================================
//===========================================================================
