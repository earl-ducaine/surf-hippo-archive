package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.awtevent.*;
import edu.berkeley.guir.denim.dialogs.*;
import edu.berkeley.guir.denim.lib.*;
import edu.berkeley.guir.denim.toolbox.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.satin.objects.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.util.*;

import javax.help.*;
import javax.swing.*;

/**
 * The user interface of the entire Denim application. See the
 * <a href="http://guir.berkeley.edu/projects/denim/">Denim</a> project page
 * for details.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-11-1999 James Lin
 *                               Created Denim
 *                    08-21-1999 James Lin
 *                               Split Denim into Denim and DenimWindow
 *                    01-11-2001 James Lin
 *                               Split DenimWindow into DenimWindow and DenimUI
 *                    11-15-2002 Yang Li
 * 								 Support pencil-special immediate feedback
 *                    07-12-2003 Yang Li
 *                          Enabled Tap selection
 * 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 1.0.0, 07-12-2003
 * 
 */

public class DenimUI extends JPanel implements DenimConstants
{

	//===========================================================================
	//===   CONSTANTS   =========================================================

	//static final long serialVersionUID = 2818732831452563248L;

	//===   CONSTANTS   =========================================================
	//===========================================================================

	//===========================================================================
	//===   CLASS VARIABLES   ===================================================

	//===   CLASS VARIABLES   ===================================================
	//===========================================================================

	//===========================================================================
	//===   INNER CLASSES   =====================================================

	public class DenimKeyListener implements KeyListener
	{
		public void keyReleased(KeyEvent evt)
		{
			//debug.println(evt);
			if (evt.getKeyCode() == KeyEvent.VK_DELETE)
			{
				// Delete the selected objects
				DenimUI.this.getSheet().deleteObjects(cmdsubsys.getSelected());
				repaint();
			}
		} // of keyReleased

		public void keyPressed(KeyEvent evt)
		{
		} // of keyPressed

		public void keyTyped(KeyEvent evt)
		{
		} // of keyTyped
	} // of inner class DenimKeyListener

	//=================================================================

	class MenuButton extends JButton implements ActionListener, KeyListener
	{

		MenuButton()
		{
			super(
				"Menu",
				new ImageIcon(Denim.class.getResource("images/menu_icon.gif")));
			setVerticalTextPosition(SwingConstants.CENTER);
			setHorizontalTextPosition(SwingConstants.RIGHT);
			//setBackground(MENU_BUTTON_BACKGROUND_COLOR);
			this.addActionListener(this);
			this.addKeyListener(this);
		}

		public void actionPerformed(ActionEvent e)
		{
			sheet.getPieMenu().showInCenter();
		}

		public void keyPressed(KeyEvent evt)
		{
			if (evt.getKeyCode() == KeyEvent.VK_ESCAPE)
			{
				if (sheet.getPieMenu().isShowing())
				{
					sheet.getPieMenu().setVisible(false);
				}
			}
		} // of keyReleased

		public void keyReleased(KeyEvent evt)
		{
		}

		public void keyTyped(KeyEvent evt)
		{
		}
	}

	//=================================================================

	/**
	 * HACK:
	 */
	class CloseComponentButton extends JButton implements ActionListener
	{
		DenimComponent component;

		CloseComponentButton(String text, DenimComponent c)
		{
			super(text);
			component = c;
			addActionListener(this);
		}

		public void actionPerformed(ActionEvent e)
		{
			hideComponent(component);
			sheet.remove(this);
		}
	}

	//===   INNER CLASSES   =====================================================
	//===========================================================================

	//===========================================================================
	//===   INSTANCE VARIABLES   ================================================

	private DenimSheet sheet;
	private Toolbox toolbox;
	private JToolBar zoomBar;
	private JPanel workArea; // part of window w/o zoom bar
	private HashMap componentPatches;
	private DenimRunWindow runWindow;
	private static String projectName;
	private boolean simplified = false;
	
	transient private boolean hasDecorations;
	transient private Tool currentTool;
	transient private Set tools;
	transient private ToolContainer containerWithTool;
	transient private ToolContainer lastContainerWithTool;
	transient private ZoomSlider zoomSlider;
	transient private Vector uiListeners = new Vector();
    
	//===   INSTANCE VARIABLES   ================================================
	//===========================================================================

	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	/**
	 * Constructs a DenimUI with a zoom bar and toolbox.
	 */
	public DenimUI()
	{
		this(true);
	}

	/**
	 * for Component Editor
	 */

	public DenimUI(boolean hasDecorations, boolean simplified)
	{
		this.hasDecorations = hasDecorations;
		this.simplified = true;
		this.componentPatches = new HashMap();
		this.sheet = new DenimSheet(this, simplified);

		this.setBorder(BorderFactory.createEtchedBorder());
		
		this.toolbox = new Toolbox(true);
		this.tools = new HashSet();

		this.zoomBar = new JToolBar();

		this.sheet.setVisible(true);

		this.toolbox.setVisible(true);

		this.zoomSlider = new ZoomSlider(JSlider.VERTICAL, 0, 100, 70);
		this.zoomSlider.setSheetReference(sheet);
		this.zoomBar.setFloatable(false);
		this.zoomBar.add(zoomSlider);
		this.zoomSlider.setValue(30); // to fire a change event

		this.setLayout(new BorderLayout());
		this.setBackground(ZOOM_SLIDER_BACKGROUND_COLOR);

		// The left side of the window contains the zoom slider
		// and a button for the pie menu
		JPanel leftArea = new JPanel();
		leftArea.setLayout(new BorderLayout());
		leftArea.add(zoomBar, BorderLayout.CENTER);

		if (hasDecorations)
		{
			this.add(leftArea, BorderLayout.WEST);
		}

		this.workArea = new JPanel();
		this.workArea.setLayout(new BorderLayout());
		this.workArea.add(sheet, BorderLayout.CENTER);

		if (hasDecorations)
		{
			this.workArea.add(this.toolbox, BorderLayout.SOUTH);
		}

		this.add(workArea, BorderLayout.CENTER);
		this.containerWithTool = null;

		// Preload text insert dialog
        /*
		TextInsertDialog textDialog =
			new TextInsertDialog(
				(Window) SwingUtilities.getRoot(this),
				new JTextArea(),
				0,
				0,
				"",
				"");
                */
	}

	/**
	 * Constructs a DenimUI. If the parameter is true, then a zoom bar
	 * and toolbox are included in the interface.
	 */
	public DenimUI(boolean hasDecorations)
	{
		super();

		this.hasDecorations = hasDecorations;
		this.componentPatches = new HashMap();
		Denim.updateSplashWindow(0, "Initializing canvas");
		this.sheet = new DenimSheet(this, false);

		this.toolbox = new Toolbox(false);
		this.tools = new HashSet();

		this.zoomBar = new JToolBar();

		this.sheet.setVisible(true);

		this.toolbox.setVisible(true);

		this.zoomSlider = new ZoomSlider(JSlider.VERTICAL, 0, 100, 70);
		this.zoomSlider.setSheetReference(sheet);
		this.zoomBar.setFloatable(false);
		this.zoomBar.add(zoomSlider);
		this.zoomSlider.setValue(30); // to fire a change event

		this.setLayout(new BorderLayout());
		this.setBackground(ZOOM_SLIDER_BACKGROUND_COLOR);

		// The left side of the window contains the zoom slider
		// and a button for the pie menu
		JPanel leftArea = new JPanel();
		leftArea.setLayout(new BorderLayout());
		leftArea.add(zoomBar, BorderLayout.CENTER);

		leftArea.add(new MenuButton(), BorderLayout.NORTH);
		if (hasDecorations)
		{
			this.add(leftArea, BorderLayout.WEST);
		}

		this.workArea = new JPanel();
		this.workArea.setLayout(new BorderLayout());
		this.workArea.add(sheet, BorderLayout.CENTER);
		if (hasDecorations)
		{
			this.workArea.add(this.toolbox, BorderLayout.SOUTH);
		}
		this.add(workArea, BorderLayout.CENTER);

		this.containerWithTool = null;

		// Preload text insert dialog
/*		TextInsertDialog textDialog =
			new TextInsertDialog(
				(Window) SwingUtilities.getRoot(this),
				new JTextArea(),
				0,
				0,
				"",
				"");*/
	}

	//===   CONSTRUCTORS   ======================================================
	//===========================================================================

	public boolean isSimplified() {
		return this.simplified;
	}
    

	
	//===========================================================================
	//===   EVENT RELATED METHODS   =============================================

	/**
	 * Adds the given listener to UI events.
	 */
	public synchronized void addUIListener(UIListener uil)
	{
		if (!uiListeners.contains(uil))
		{
			uiListeners.addElement(uil);
		}
	}

	/**
	 * Removes the given listener to UI events.
	 */
	public synchronized void removeUIListener(UIListener uil)
	{
		uiListeners.removeElement(uil);
	}

	/**
	 * Fires a projectNameChanged event to all UIEvent listeners.
	 */
	private void fireProjectNameChanged()
	{
		Vector uils;
		synchronized (this)
		{
			uils = (Vector) uiListeners.clone();
		}

		int size = uils.size();
		if (size == 0)
		{
			return;
		}

		UIEvent event = new UIEvent(this, null, 0);

		for (int i = 0; i < size; i++)
		{
			UIListener listener = (UIListener) uils.elementAt(i);
			listener.projectNameChanged(event);
		}
	}

	/**
	 * Fires a sheetPainted event to all UIEvent listeners.
	 */
	private void fireSheetPainted(Rectangle2D rect)
	{
		Vector uils;
		synchronized (this)
		{
			uils = (Vector) uiListeners.clone();
		}

		int size = uils.size();
		if (size == 0)
		{
			return;
		}

		Rectangle bounds = DenimUI.this.getSheet().getBounds();
		UIEvent event =
			new UIEvent(
				this,
				rect,
				(float) ((rect.getWidth() * rect.getHeight())
					/ (bounds.getWidth() * bounds.getHeight())));

		for (int i = 0; i < size; i++)
		{
			UIListener listener = (UIListener) uils.elementAt(i);
			listener.sheetPainted(event);
		}
	}

	//===   EVENT RELATED METHODS   =============================================
	//===========================================================================

	//===========================================================================
	//===   DENIM UI METHODS   ==================================================

	/**
	 * Returns the name of the project that the designer is currently working
	 * on.
	 */
	public static String getProjectName()
	{
		return projectName;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the name of the project, or "Untitled" if it does not have one.
	 */
	public String getFriendlyProjectName()
	{
		if (projectName == null
			|| projectName.substring(0, 7).equals("C:\\null"))
		{
			return "Untitled";
		}
		else
		{
			return projectName;
		}
	}

	//-----------------------------------------------------------------

	/**
	 * Sets the name of the project that the designer is currently working
	 * on.
	 */
	public void setProjectName(String newProjectName)
	{
		projectName = newProjectName;
		fireProjectNameChanged();
		//setTitle(getFriendlyProjectName() + " - Denim");
	}

	//-----------------------------------------------------------------

	/**
	 * Called when the sheet has been painted.
	 */
	void sheetPainted(Rectangle2D rect)
	{
		fireSheetPainted(rect);
	}

	//-----------------------------------------------------------------

	/**
	 * Completes the initialization.
	 */
	public void initAfterConstruction()
	{
		if (hasDecorations)
		{
			// The constructors called inside init() assume that the DenimUI
			// instance already exists, so it must be called after the
			// constructor is called.
			ToolsArea toolsArea = getToolbox().getToolsArea();
			toolsArea.init(this);
			toolsArea.getDefaultTool().grab();
		}
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the sheet, which contains the designer's sketches and traps
	 * a tool's events when it is being used.
	 *
	 */
	public DenimSheet getSheet()
	{
		return sheet;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the toolbox, which contains the storage area for tools and the
	 * clean-up button.
	 *
	 */
	public Toolbox getToolbox()
	{
		return toolbox;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the zoom bar, which contains the slider that controls the
	 * current zoom level of the sheet.
	 *
	 */
	public JToolBar getZoomBar()
	{
		return zoomBar;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the zoom slider, which controls the current zoom level of the
	 * sheet.
	 *
	 */
	public ZoomSlider getZoomSlider()
	{
		return zoomSlider;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the tool currently being used by the designer.
	 */
	public Tool getCurrentTool()
	{
		return currentTool;
	}

	//-----------------------------------------------------------------

	/**
	 * Stores the tool currently being used by the designer.
	 */
	public void setCurrentTool(Tool newTool)
	{

		if (newTool != null)
		{
			if (newTool.getName() != "Pencil"
				&& newTool.getName() != "Grouping Pencil")
			{
				sheet.getIIFInterpreter().setEnabled(false);
			}
			else
			{
				sheet.getIIFInterpreter().setEnabled(true);
			}
			sheet.setEnableLeftTapSelection(false);
		}
		// since the arrow cursor is only used for selection and dragging now
		else
		{
			sheet.getIIFInterpreter().setEnabled(false);
			sheet.setInkOn(false);
			sheet.setEnableLeftTapSelection(true);
		}

		currentTool = newTool;
	}

	//-----------------------------------------------------------------

	/**
	 * Adds a tool to the window's collection of tools. This lets the window
	 * keep track of what tools are available.
	 */
	public void addTool(Tool newTool)
	{
		tools.add(newTool);
		//debug.println("DenimUI: adding " + newTool.getClass());
	}

	//-----------------------------------------------------------------

	/**
	 * Gets an iterator to the tools collection.
	 */
	public Iterator getToolsIterator()
	{
		return tools.iterator();
	}

	//-----------------------------------------------------------------

	/**
	 * Depending on the given flag, show only the annotation tools or all of
	 * the tools.
	 */
	public void setAnnotationOnlyMode(boolean flag)
	{
		Iterator it = getToolsIterator();

		if (flag)
		{
			if (currentTool != null
				&& !(currentTool instanceof AnnotationPen)
				&& !(currentTool instanceof AnnotationMicrophone))
			{
				//debug.println("DenimSheet: dropping " + win.getCurrentTool().getClass());

				Point dropPt =
					new Point(
						lastContainerWithTool.getLastX(),
						lastContainerWithTool.getLastY());

				if (lastContainerWithTool instanceof Tool)
				{
					Tool tool = (Tool) lastContainerWithTool;
					Container parent = tool.getParent();
					Point parentPt =
						SwingUtilities.convertPoint(tool, dropPt, parent);
					currentTool.drop(parent, parentPt);
				}
				else
				{
					currentTool.drop((Container) lastContainerWithTool, dropPt);
				}
			}
		}

		while (it.hasNext())
		{
			Tool tool = (Tool) it.next();
			if (!(tool instanceof AnnotationMicrophone
				|| tool instanceof AnnotationPen))
			{
				//debug.println("Tool: " + (tool == null ? null : tool.getClass()));
				tool.setVisible(!flag);
			}
		}
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the component which contains the mouse cursor.
	 */
	public ToolContainer getContainerWithTool()
	{
		return containerWithTool;
	}

	//-----------------------------------------------------------------

	/**
	 * Sets the component which contains the mouse cursor.
	 */
	public void setContainerWithTool(ToolContainer c)
	{
		if (c == null && containerWithTool != null)
		{
			lastContainerWithTool = containerWithTool;
		}
		else
		{
			lastContainerWithTool = c;
		}
		containerWithTool = c;
	}

	//-----------------------------------------------------------------

	/**
	 * Open a pane in the window, and display the specified component in it.
	 */
	public void showComponent(DenimComponent c, int x, int y)
	{
		DenimFramedPatch fp = new DenimFramedPatch(c, c.getName());
		sheet.addToFront(fp, GraphicalObjectGroup.KEEP_REL_POS);
		fp.moveTo(COORD_ABS, x, y);
		fp.initArrows();
		sheet.readjustArrows();

		//debug.println("showing component: " + c);
	}

	//-----------------------------------------------------------------

	/**
	 * Close the pane with the specified component in it.
	 */
	public void hideComponent(DenimComponent c)
	{
		Patch componentPatch = (Patch) (componentPatches.get(c));

		sheet.remove(componentPatch);
	}

	//-----------------------------------------------------------------

	/**
	 * Open a new window, and "run" the storyboard starting at the
	 * specified panel.
	 */
	public void startRunMode(DenimPanel startingPanel)
	{
		String titleName = getFriendlyProjectName();
		titleName += " [Run]";
		if (!System.getProperty("os.name").equals("Mac OS X"))
		{
			titleName += " - Denim";
		}
		runWindow = new DenimRunWindow(titleName, startingPanel);
		runWindow.show();

		// debug.println("startingPanel after: " + startingPanel);
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the window where the storyboard is run.
	 */
	public DenimRunWindow getRunWindow()
	{
		return runWindow;
	}

	public void setRunWindow(DenimRunWindow w)
	{
		runWindow = w;
	}

	//-----------------------------------------------------------------

	/**
	 * Shows the Help window.
	 */
	public void showHelpWindow()
	{
		showHelpWindow(
			new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "Contents"));
	}

	//-----------------------------------------------------------------

	/**
	 * Shows the Help window.
	 */
	public void showHelpWindow(ActionEvent evt)
	{
		try
		{
			setCursor(DenimUtils.getWaitCursor());
			URL hsURL = HelpSet.findHelpSet(null, "denim.hs");
			//debug.println("hsURL = " + hsURL);
			HelpSet hs = new HelpSet(null, hsURL);
			HelpBroker hb = hs.createHelpBroker();
			new CSH.DisplayHelpFromSource(hb).actionPerformed(evt);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		setCursor(Cursor.getDefaultCursor());
	}

	//-----------------------------------------------------------------

	/**
	 * Sets the cursor.
	 */
	public void setCursor(Cursor newCursor)
	{
		if (newCursor == Cursor.getDefaultCursor() && currentTool != null)
		{
			sheet.setCursor(currentTool.getToolCursor());
			toolbox.getToolsArea().setCursor(currentTool.getToolCursor());
		}
		else
		{
			sheet.setCursor(newCursor);
			toolbox.getToolsArea().setCursor(newCursor);
		}
		zoomBar.setCursor(newCursor);
		toolbox.getBtnCleanUp().setCursor(newCursor);
	}

	//===   DENIM UI METHODS   ==================================================
	//===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
