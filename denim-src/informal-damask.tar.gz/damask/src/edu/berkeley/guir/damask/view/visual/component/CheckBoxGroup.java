package edu.berkeley.guir.damask.view.visual.component;

import java.util.*;

import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.component.SelectMany;
import edu.berkeley.guir.damask.event.ElementContainerEvent;
import edu.berkeley.guir.damask.event.ElementContainerListener;
import edu.umd.cs.piccolo.PNode;

/** 
 * An invisible group that contains check boxes.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  12-16-2003 James Lin
 *                               Created CheckBoxGroup.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 12-16-2003
 */
public class CheckBoxGroup extends ControlView {
   
   private final CheckBoxHandler checkBoxHandler = new CheckBoxHandler();
   private final Map/*<SelectMany.Item, CheckBox>*/ views =
      new HashMap()/*<SelectMany.Item, CheckBox>*/;
   private Set/*<SelectMany.Item>*/ selectedItems = new HashSet();
   private boolean childrenSelectable = true;
      
   
   /**
    * Constructs a check box group and associates it with the specified
    * select-many object. 
    */
   public CheckBoxGroup(final SelectMany selectMany) {
      super(selectMany);
      selectMany.addElementContainerListener(checkBoxHandler);
      super.setSelectable(false);
   }
   
   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      for (Iterator i = ((SelectMany)getModel()).getItems().iterator();
         i.hasNext();
         ) {
         final SelectMany.Item selectManyItem = (SelectMany.Item)i.next();
         final CheckBox checkBox = new CheckBox(selectManyItem);
         
         addChild(checkBox);
         checkBox.setInRunMode(isInRunMode());
         views.put(selectManyItem, checkBox);
      }
   }

   
   // Overrides method in parent class.
   public void dispose() {
      super.dispose();
      ((SelectMany)getModel()).removeElementContainerListener(checkBoxHandler);
   }


   // Overrides method in parent class.
   public void setInRunMode(boolean flag) {
      super.setInRunMode(flag);
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final CheckBox checkBox = (CheckBox)i.next();
         checkBox.setInRunMode(flag);
      }
   }


   // Overrides method in parent class.
   public void setSelectable(boolean flag) {
      childrenSelectable = flag;
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof CheckBox) {
            ((CheckBox)child).setSelectable(flag);
         }
      }
   }


   // Overrides method in ancestor class.
   public void setPickable(boolean flag) {
      super.setPickable(flag);
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         child.setPickable(flag);
      }
   }


   /**
    * Returns a set of the selected items in this group.
    * 
    * @return a Set of SelectMany.Item
    */
   public Object getState() {
      return Collections.unmodifiableSet(selectedItems);
   }


   /**
    * Sets the selected items in this group. Also checks or unchecks the
    * appropriate check boxes within this group.
    * 
    * @param state a Collection of SelectMany.Item
    */
   public void setState(final Object state) {
      selectedItems = new HashSet((Collection)state);
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final CheckBox checkBox = (CheckBox)i.next();
         checkBox.setChecked(selectedItems.contains(checkBox.getModel()));
      }
   }


   // Overrides abstract method in parent class.
   public Object getEditableContents() {
      return getContent();
   }

   /**
    * Returns the content of this group, which is always null.
    */
   public Label getContent() {
      return null;
   }


   /**
    * Adds the specified check box to the set of selected items.
    */
   protected void addSelectedCheckBox(final CheckBox checkBox) {
      selectedItems.add(checkBox.getModel());
      checkBox.setChecked(true);
   }

   /**
    * Removes the specified check box from the set of selected items.
    */
   protected void removeSelectedCheckBox(final CheckBox checkBox) {
      selectedItems.remove(checkBox.getModel());
      checkBox.setChecked(false);
   }
   

   /** 
    * Handles element container events.
    */
   public class CheckBoxHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         final SelectMany.Item selectManyItem = (SelectMany.Item)e.getElement();
         final CheckBox checkBox = new CheckBox(selectManyItem);
   
         addChild(checkBox);
         checkBox.setInRunMode(isInRunMode());
         checkBox.setSelectable(childrenSelectable);
         checkBox.setPickable(getPickable());
         views.put(selectManyItem, checkBox);
      }
   
      public void elementRemoved(ElementContainerEvent e) {
         final InteractionElement element = e.getElement();
         final PNode elementView = (PNode)views.get(element);
   
         elementView.removeFromParent();
         views.remove(element);
      }
   }
}
