package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;

/*Abstract class for all group node views
*/
public abstract class AbstGroupNodeView extends AbstNodeView implements Cloneable{
	public  static final Color  NODE_FILL = new Color(100,150,220);
	protected static final int  DEFAULT_WIDTH     = 160;
	protected static final int  DEFAULT_HEIGHT    = 50;
	public static final int     VER_NODE_DIST     = 2;
	public static final int     HOR_NODE_DIST     = 18;
	public static final int     TEXT_HEIGHT       = 24;

   
	protected JTextField m_textField   = new JTextField("");
   
	protected int min_width = 0;
    
	public AbstGroupNodeView (SuedeModel model, GroupNodeModel nodeModel){
		   super(model, nodeModel);
	}
    
	public Dimension getPreferredSize() {
		Vector components = ((GroupNodeModel)m_nodemodel).getComponents();
		int w = ((GroupNodeModel)m_nodemodel).getWidth();
		int h = TEXT_HEIGHT;
		if(components.size()>0)
			h = (components.size()*(((SingleNodeModel)components.get(0)).getView().getHeight()+VER_NODE_DIST))+TEXT_HEIGHT;
		return new Dimension(w,h);
	}
    
	public void resize() {
		int h = 0;
		int i = 0;
		Vector components = ((GroupNodeModel)m_nodemodel).getComponents();
		for (; i<components.size(); i++) {
			if(i!=0) {
				((AbstNodeModel)components.get(i)).setLocation(m_nodemodel.getX()+HOR_NODE_DIST, m_nodemodel.getY()+h+VER_NODE_DIST);
					h+=((AbstNodeModel)components.get(i)).getHeight()+VER_NODE_DIST;
			}
			else {
				((AbstNodeModel)components.get(i)).setLocation(m_nodemodel.getX()+HOR_NODE_DIST, m_nodemodel.getY()+TEXT_HEIGHT);
					h=((AbstNodeModel)components.get(i)).getHeight()+TEXT_HEIGHT;
			}
		}
			setSize(((GroupNodeModel)m_nodemodel).getWidth(), h); 
	}
    
	public void setName(String name) {
		super.setName(name);
		m_textField.setText(name);
		//gets the width of the text as minimum width for the node
		int l = (name).length();
		int w = (m_textField.getFont()).getSize() * l;
		min_width = w;
		if(getWidth()<min_width) {
			((GroupNodeModel)m_nodemodel).setBounds(new Rectangle(m_nodemodel.getX(), m_nodemodel.getY(),min_width, getHeight()));   
		}
	}


	public String getName() {
		return m_textField.getText();
	}

	public void paintComponent(Graphics g) {
	  super.paintComponent(g);
	  Graphics2D g2d = (Graphics2D)g;
	  g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	  g2d.setColor(NODE_FILL);
	  g2d.fill(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, ARC, ARC));
	}
  

	public Point getLocationForComponent(AbstNodeView node) {
		Vector components = ((GroupNodeModel)m_nodemodel).getComponents();
		int temp = 0;
		int i = 0;
		for (; i<=components.indexOf(node.getNodeModel()); i++) {
			if(i!= 0)
				temp += ((AbstNodeModel)components.get(i-1)).getHeight()+VER_NODE_DIST;
			else
				temp = TEXT_HEIGHT;
		  }
		return new Point(m_nodemodel.getX() + HOR_NODE_DIST, m_nodemodel.getY() + temp);
	}

	public void addToGroup(AbstNodeModel node) {
		Vector components = ((GroupNodeModel)m_nodemodel).getComponents();
		node.setGroupName(((GroupNodeModel)m_nodemodel).getGroupName());
		int temp = 0;
		int i = 0;
		for (; i<components.size(); i++) {
			if(i!= 0)
				temp += ((AbstNodeModel)components.get(i-1)).getHeight()+VER_NODE_DIST;
			else
				temp = TEXT_HEIGHT;
			((AbstNodeModel)components.get(i)).setLocation(getX() + HOR_NODE_DIST, getY() + temp);
		  }
	   ((GroupNodeModel)m_nodemodel).setBounds(new Rectangle(getX(), getY(),Math.max(AbstSingleNodeView.DEFAULT_WIDTH + TEXT_HEIGHT, getWidth()),
				Math.max(temp+((AbstNodeModel)components.get(i-1)).getHeight(), getHeight())));
          
		repaint();
	}


	public void removeFromGroup(AbstNodeModel node) {
		Vector components = ((GroupNodeModel)m_nodemodel).getComponents();
		node.setGroupName("");
		int temp = 0;
		int i = 0;
		for (; i<components.size(); i++) {
			if(i!= 0)
				temp += ((AbstNodeModel)components.get(i-1)).getHeight()+VER_NODE_DIST;
			else
				temp = TEXT_HEIGHT;
			((AbstNodeModel)components.get(i)).setLocation(getX() + HOR_NODE_DIST, getY() + temp);
		  }
		if(--i>=0)
			((GroupNodeModel)m_nodemodel).setBounds(new Rectangle(getX(), getY(), Math.max(AbstSingleNodeView.DEFAULT_WIDTH+ TEXT_HEIGHT, getWidth()), 
				 Math.max(temp+((AbstNodeModel)components.get(i)).getHeight(), getHeight())));
		else
			((GroupNodeModel)m_nodemodel).setBounds(new Rectangle(getX(), getY(), Math.max(AbstSingleNodeView.DEFAULT_WIDTH+ TEXT_HEIGHT, getWidth()), 
				 getHeight()));
	}
    
	public void handleMouseDragged() {
		Vector components = ((GroupNodeModel)m_nodemodel).getComponents();
		int temp = 0;
		int i = 0;
		for (; i<components.size(); i++) {
			if(i!= 0)
				temp += ((AbstNodeModel)components.get(i-1)).getHeight()+VER_NODE_DIST;
			else
				temp = TEXT_HEIGHT;
			((AbstNodeModel)components.get(i)).setLocation(getX() + HOR_NODE_DIST, getY() + temp);
		  }
	}
    
    
	public void handleMouseReleased (Component c) {    
	}
    
    
	public void handleMouseClicked (MouseEvent e) {
	   if (SwingUtilities.isMiddleMouseButton(e) && ! (m_nodemodel.getSuedeModel()).getAnalysisMode() ) {
		 (m_nodemodel.getSuedeModel()).deleteCard(this.getNodeModel());
	   }
	   //allows user to create single nodes inside groups
	   //HV Oct1703
	  /* if(SwingUtilities.isRightMouseButton(e)) {
		  Point p = e.getPoint();
		  SwingUtilities.convertPointToScreen(p, e.getComponent());
		  SwingUtilities.convertPointFromScreen(p, (m_nodemodel.getSuedeModel()).getContentPane());
		 ((m_nodemodel.getSuedeModel()).addSingleNode(p)).setGroup((GroupNodeModel)m_nodemodel);
	   }*/
	}
   
	//////////////////////Hongvan's code/////////////////////////
	public void handleMousePressed (MouseEvent e) {
		showPopup(e);
	}
    
	public void showPopup(MouseEvent e) {
		//Response cards are not supposed to be added into a GroupCard
		newResponseCard.setEnabled(false);
		if (e.isPopupTrigger()) {
			popup.show(e.getComponent(),e.getX(), e.getY());
	}
	}
    
	/** allows user to create single nodes inside groups
	 **/
	public void handleCreateNewPromptCard () {
		Point p = mouseEvent.getPoint();
		if (! (m_nodemodel.getSuedeModel()).getAnalysisMode()) {
		SwingUtilities.convertPointToScreen(p, mouseEvent.getComponent());
		SwingUtilities.convertPointFromScreen(p, (m_nodemodel.getSuedeModel()).getContentPane());
		((m_nodemodel.getSuedeModel()).addSingleNode(p)).setGroup((GroupNodeModel)m_nodemodel);
		}
	}
    
	/**Copy the whole group */
	public void handleCopyAction () {
		if ( ! (m_nodemodel.getSuedeModel()).getAnalysisMode() ) {
		//Temporarily let it point to promptCard instead of creating a new clone.   
		//m_nodemodel.getSuedeModel().copiedObj = this;
		SuedeModel.copiedObj = this;
		//m_nodemodel.getSuedeModel().copiedLinkObj = null;
		SuedeModel.copiedLinkObj = null;
		}
	}
    
	public void handleCutAction () {
		SuedeModel suedeModel = m_nodemodel.getSuedeModel();
		if ( ! suedeModel.getAnalysisMode() ) {
			//m_nodemodel.getSuedeModel().copiedLinkObj = null;
			SuedeModel.copiedLinkObj = null;
			//We have to use clone() here to be able to copy all the prompt cards
			//belonging to this card.
			//suedeModel.copiedObj = (AbstGroupNodeView)this.clone();
			SuedeModel.copiedObj = (AbstGroupNodeView)this.clone();
			suedeModel.deleteCard(this.getNodeModel());
		}
	}
    
	/**Just Paste a node (PromptCard) for now, not a whole group*/
	public void handlePasteAction () {
		Point p = mouseEvent.getPoint();
		SuedeModel suedeModel = m_nodemodel.getSuedeModel();
		//if (!suedeModel.getAnalysisMode() && suedeModel.copiedObj != null) {
		if (!suedeModel.getAnalysisMode() && SuedeModel.copiedObj != null) {
			//Pasting a promptcard inside a group
			//if (suedeModel.copiedObj instanceof AbstSingleNodeView) {
			if (SuedeModel.copiedObj instanceof AbstSingleNodeView) {
				SingleNodeModel newNode = suedeModel.addSingleNode(p);
				newNode.setGroup ((GroupNodeModel)m_nodemodel);
				/*suedeModel.copyNodetoNode(newNode, 
				(SingleNodeModel)(suedeModel.copiedObj).getNodeModel());
				*/
				suedeModel.copyNodetoNode(newNode, 
								(SingleNodeModel)(SuedeModel.copiedObj).getNodeModel());
			}
			//else if (suedeModel.copiedObj instanceof AbstGroupNodeView) {
			else if (SuedeModel.copiedObj instanceof AbstGroupNodeView) {
				//doing nothing. Pasting a group on another group is not allowed
			}
	}
	}
    
		///////////////Hongvan's code/////////////////////////
	 /**
   * Generate a copy of this AbstSingleNodeView.
   * @param - none
   * @return
   *   The return value is a copy of this sequence. Subsequent changes to the
   *   copy will not affect the original, nor vice versa. Note that the return
   *   value must be type cast to a <CODE>AbstGroupNodeView</CODE> before it can be used.
   **/
   public Object clone()
   {  // Clone a AbstGroupNodeView object.
	  AbstGroupNodeView answer;

	  try
	  {
		answer = (AbstGroupNodeView) super.clone( );
	  }
	  catch (CloneNotSupportedException e)
	  {  // This exception should not occur. But if it does, it would probably
		 // indicate a programming error that made super.clone unavailable.
		 // The most common error would be forgetting the "Implements Cloneable"

		 // clause at the start of this class.
		 throw new RuntimeException
		 ("This class does not implement Cloneable");
	  }
	  answer.m_nodemodel = (GroupNodeModel)m_nodemodel.clone();
	  return answer;
   }
//////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
    
	//{{DECLARE_CONTROLS
	//}}
}