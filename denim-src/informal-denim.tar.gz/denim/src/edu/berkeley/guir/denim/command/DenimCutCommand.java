//// See bottom of source code for software license

package edu.berkeley.guir.denim.command;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.util.*;
import java.util.*;

/**
 * Cuts a Denim Object to the clipboard.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 15 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class DenimCutCommand
   extends DenimDeleteCommand {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 6107827467298680138L;

   //===   CONSTANTS   =========================================================
   //===========================================================================


   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   static {
      CutCommand.setClipboard(DenimConstants.denimClipboard);
   }

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================


   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   // set of objects that will be copied to the clipboard when cut
   protected Set objsToCopy = new TreeSet(new LayerReverseComparator());

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public DenimCutCommand() {
      super();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create the cut command object, cutting the specified GraphicalObject into
    * the clipboard.
    *
    * @param gob is the Graphical Object to cut.
    */
   public DenimCutCommand(GraphicalObject gob) {
      super(gob);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Make the specified collection of Graphical Objects the list of Graphical
    * Objects to cut into the clipboard.
    *
    * @param it is an Iterator of Graphical Objects.
    */
   public DenimCutCommand(Iterator it) {
      while (it.hasNext()) {
         Object obj = it.next();
         if (obj instanceof GraphicalObject) {
            addGraphicalObject((GraphicalObject) obj);
            addArrowsWithin((GraphicalObject) obj);
         }
      }
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Make the specified collection of Graphical Objects the list of Graphical
    * Objects to cut into the clipboard.
    *
    * @param gobs is a Vector of Graphical Objects.
    */
   public DenimCutCommand(Vector gobs) {
      super(gobs);
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================


   //===========================================================================
   //===   CLASS METHODS   =====================================================

   //===   CLASS METHODS   =====================================================
   //===========================================================================


   //===========================================================================
   //===   CUT METHODS   =======================================================

   /**
    * Add a Graphical Object to the list of Graphical Objects to be cut.
    * Make sure the objects will be copied to the clipboard.
    *
    * @param gob is the Graphical Object to cut.
    */
   public void addGraphicalObject(GraphicalObject gob) {
      super.addGraphicalObject(gob);
      objsToCopy.add(gob);
   } // of addGraphicalObject

   //-----------------------------------------------------------------

   /**
    * Remove a Graphical Object from the list of Graphical Objects to be cut.
    * Does nothing if the Graphical Object was not in the list.
    *
    * @param gob is the Graphical Object to remove from the cut command.
    */
   public void removeGraphicalObject(GraphicalObject gob) {
      super.removeGraphicalObject(gob);
      objsToCopy.remove(gob);
   } // of removeGraphicalObject

   //-----------------------------------------------------------------

   /**
    * Clear the list of Graphical Objects to be cut.
    */
   public void clearGraphicalObjects() {
      super.clearGraphicalObjects();
      objsToCopy.clear();
   } // of clearGraphicalObjects

   //===   CUT METHODS   =======================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      return ("Cut Denim Object to clipboard");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   ACTION METHODS   ====================================================

   public void run() {
      if (objsToCopy.isEmpty()) {
         return;
      }
      //// 1. Copy to the clipboard.
      CutCommand.getClipboard().clearClipboard();
      CutCommand.getClipboard().copyToClipboard(objsToCopy.iterator());

      //// 2. Delete the copied Graphical Objects.
      super.run();
   } // of method

   //===   ACTION METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
