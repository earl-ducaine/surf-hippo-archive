package edu.berkeley.guir.lib.satin.interpreter.stroke;

import java.awt.*;
import java.awt.geom.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;

/**
 * Immediate Ink Feedback Interpreter to work with idle rendering mode.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v2.1-2.0.0, Nov 12 2002, YL
 *               Created class
 * 
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version SATIN-v2.1-2.0.0, Nov 12 2002
 */


public class ImmediateInkFeedbackInterpreter 
					extends InterpreterImpl{
   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================


   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================

   Point2D prePosition = new Point2D.Double();
   

   public static Color inkColor = Color.black;
   double inkWidth = 1.0;
   

   
   public ImmediateInkFeedbackInterpreter() {
   	
   }
   
   //-----------------------------------------------------------------
   
   public void setInkWidth(double w)
   {
   		inkWidth = w;		
   }

   //-----------------------------------------------------------------
      
   public double getInkWidth()
   {
   		return inkWidth;
   }

   //-----------------------------------------------------------------
      
   public void setInkColor(Color inkC)
   {
   	   inkColor = inkC;
   }

   //-----------------------------------------------------------------
      
   public Color getInkColor()
   {
   		return inkColor;
   }
   
   //===========================================================================
   //===   STROKE METHODS   ====================================================

   public void handleNewStroke(NewStrokeEvent evt) {
   	
   		prePosition = (Point2D)evt.getStroke().getStartPoint2D(COORD_ABS).clone();
   	
   } // of handleNewStroke

   //-----------------------------------------------------------------

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
   	
		Point2D currentPoint = evt.getStroke().getEndPoint2D(COORD_ABS);

		Graphics2D g = (Graphics2D)getAttachedGraphicalObject().getSheet().getGraphics();   	
		
		Color oldColor = g.getColor();
		Stroke w = g.getStroke();
		
		if(evt.isRightButton())
		{
			g.setColor(Color.lightGray);
			g.setStroke(new BasicStroke(6));
		}
		else
		{
			g.setStroke(new BasicStroke((int)inkWidth));
			g.setColor(inkColor);
		}
		
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		g.drawLine((int)prePosition.getX(),(int)prePosition.getY(),
					(int)currentPoint.getX(),(int)currentPoint.getY());
							
		g.setColor(oldColor);
		g.setStroke(w);
		
		prePosition = (Point2D)currentPoint.clone();
						
   } // of handleUpdateStroke

   //-----------------------------------------------------------------


   public void handleSingleStroke(SingleStrokeEvent evt) {

    	Point2D currentPoint = evt.getStroke().getEndPoint2D(COORD_ABS);

		Graphics2D g = (Graphics2D)getAttachedGraphicalObject().getSheet().getGraphics();   	

		Color oldColor = g.getColor();
		Stroke w = g.getStroke();
		
		if(evt.isRightButton())
		{
			g.setColor(Color.lightGray);
			g.setStroke(new BasicStroke(6));
		}
		else
		{
			g.setStroke(new BasicStroke((int)inkWidth));
			g.setColor(inkColor);
		}
					
		g.drawLine((int)prePosition.getX(),(int)prePosition.getY(),
						(int)currentPoint.getX(),(int)currentPoint.getY());
						
		g.setColor(oldColor);
		g.setStroke(w);

		prePosition = (Point2D)currentPoint.clone();

   } // of method

   //===   STROKE METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (new ImmediateInkFeedbackInterpreter());
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
