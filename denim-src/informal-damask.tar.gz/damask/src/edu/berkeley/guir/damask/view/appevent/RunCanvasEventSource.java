package edu.berkeley.guir.damask.view.appevent;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.view.visual.DamaskRunCanvas;

/** 
 * A source of RunCanvas events.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  12-31-2003 James Lin
 *                               Created RunCanvasEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 12-31-2003
 */
public class RunCanvasEventSource {
   
   private Vector/*<RunCanvasListener>*/ eventListeners = new Vector();


   /**
    * Adds the specified listener to receive RunCanvas events.
    */
   public synchronized void addRunCanvasListener(RunCanvasListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }


   /**
    * Removes the specified listener so that it no longer receives
    * RunCanvas events.
    */
   public synchronized void removeRunCanvasListener(RunCanvasListener listener) {
      eventListeners.remove(listener);
   }

   
   /**
    * Fires loadCompleted events to listeners.
    */
   public void fireLoadCompleted(final DamaskRunCanvas canvas) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final RunCanvasEvent event =
         new RunCanvasEvent(canvas, RunCanvasEvent.LOAD_COMPLETED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final RunCanvasListener listener = (RunCanvasListener)i.next();
         listener.loadCompleted(event);
      }
   }
}
