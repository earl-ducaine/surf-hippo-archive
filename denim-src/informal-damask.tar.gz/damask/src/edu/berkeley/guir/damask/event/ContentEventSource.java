package edu.berkeley.guir.damask.event;

import java.awt.geom.GeneralPath;
import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Content;

/** 
 * A source of ContentEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-23-2004 James Lin
 *                               Created ContentEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 04-23-2004
 */
public class ContentEventSource {
   
   private Vector/*<ContentListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified listener to receive events from the Content.
    */
   public synchronized void addContentListener(
      final ContentListener listener) {
      
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified listener so that it no longer receives
    * events from the content.
    */
   public synchronized void removeContentListener(
      final ContentListener listener) {

      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires strokeAdded events to listeners.
    */
   public void fireStrokeAdded(final Content e, final GeneralPath path) {
      final Vector el;
      synchronized (this) {
         el = (Vector)eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ContentEvent event =
         new ContentEvent(
            e,
            ContentEvent.STROKE_ADDED,
            e.getDeviceType(),
            null,
            path);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ContentListener listener = (ContentListener)i.next();
         listener.strokeAdded(event);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Fires contentChanged events to listeners.
    */
   public void fireStrokeRemoved(final Content e, final GeneralPath path) {
      final Vector el;
      synchronized (this) {
         el = (Vector)eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ContentEvent event =
         new ContentEvent(
            e,
            ContentEvent.STROKE_REMOVED,
            e.getDeviceType(),
            null,
            path);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ContentListener listener = (ContentListener)i.next();
         listener.strokeRemoved(event);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Fires contentChanged events to listeners.
    */
   public void fireStrokesChanged(final Content e) {
      final Vector el;
      synchronized (this) {
         el = (Vector)eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ContentEvent event =
         new ContentEvent(
            e,
            ContentEvent.STROKES_CHANGED,
            e.getDeviceType(),
            null,
            null);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ContentListener listener = (ContentListener)i.next();
         listener.strokesChanged(event);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Fires contentChanged events to listeners.
    */
   public void fireTextChanged(final Content e) {
      final Vector el;
      synchronized (this) {
         el = (Vector)eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ContentEvent event =
         new ContentEvent(
            e,
            ContentEvent.TEXT_CHANGED,
            e.getDeviceType(),
            null,
            null);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ContentListener listener = (ContentListener)i.next();
         listener.textChanged(event);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Fires contentChanged events to listeners.
    */
   public void fireImageChanged(final Content e) {
      final Vector el;
      synchronized (this) {
         el = (Vector)eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ContentEvent event =
         new ContentEvent(
            e,
            ContentEvent.IMAGE_CHANGED,
            e.getDeviceType(),
            null,
            null);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ContentListener listener = (ContentListener)i.next();
         listener.imageChanged(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires preferredDisplayModeChanged events to listeners.
    */
   public void firePreferredDisplayModeChanged(
      final Content content,
      final DeviceType deviceType,
      final Content.DisplayMode oldMode,
      final Content.DisplayMode newMode) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ContentEvent event =
         new ContentEvent(
            content,
            ContentEvent.PREFERRED_DISPLAY_MODE_CHANGED,
            deviceType,
            oldMode,
            newMode);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final ContentListener listener = (ContentListener)i.next();
         listener.preferredDisplayModeChanged(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires promptTextIsSyncedWithText events to listeners.
    */
   public void firePromptTextIsSyncedWithText(final Content content) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ContentEvent event =
         new ContentEvent(
            content,
            ContentEvent.PROMPT_TEXT_SYNCED,
            content.getDeviceType(),
            null,
            null);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final ContentListener listener = (ContentListener)i.next();
         listener.promptTextIsSyncedWithText(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires promptTextIsUnsyncedWithText events to listeners.
    */
   public void firePromptTextIsUnsyncedWithText(final Content content) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ContentEvent event =
         new ContentEvent(
            content,
            ContentEvent.PROMPT_TEXT_UNSYNCED,
            content.getDeviceType(),
            null,
            null);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final ContentListener listener = (ContentListener)i.next();
         listener.promptTextIsUnsyncedWithText(event);
      }
   }
}
