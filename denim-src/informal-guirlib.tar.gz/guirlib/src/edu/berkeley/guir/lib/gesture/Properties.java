package edu.berkeley.guir.lib.gesture;

import edu.berkeley.guir.lib.gesture.util.TokenReader;
import edu.berkeley.guir.lib.gesture.util.Misc;
import java.io.Writer;
import java.io.Reader;
import java.io.IOException;
import java.util.Map;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Iterator;
import java.text.ParseException;
import java.beans.PropertyChangeEvent;

/** Provide I/O for properties.  At present only correctly
    reconstructs property values that are Strings. */
public class Properties {
  public static final String END_STRING = "endproperties";
  private static Set transientProperties = new HashSet();

  private Properties() {}

  public static PropertyChangeEvent getRootEvent(PropertyChangeEvent e)
  {
    while (e.getPropertyName() ==
	   GestureContainer.CHILD_CHANGE_PROP) {
      e = (PropertyChangeEvent) e.getNewValue();
    }
    return e;
  }
  
  public static void setPropertyPersistence(String name, boolean persistent)
  {
    if (persistent) {
      transientProperties.remove(name);
    }
    else {
      transientProperties.add(name);
    }
  }

  public static boolean isPropertyPersistent(String name)
  {
    return !transientProperties.contains(name);
  }

  /** return true if the object has the property propName, and its
      value is a non-empty Collection */
  public static boolean hasNonEmptyCollection(GestureObject gestureObj,
					      String propName)
  {
    boolean result;
    Object value;
    result = gestureObj.hasProperty(propName) &&
      ((value = gestureObj.getProperty(propName)) != null) &&
      (value instanceof Collection) &&
      (((Collection) value).size() > 0);
    return result;
  }

  /** Deep copy a property map (persistent properties only) */
  public static Map deepCopy(Map properties)
  {
    return Misc.deepCopy(properties, new Misc.MapAcceptor() {
      public boolean accept(Object key, Object value) {
	return isPropertyPersistent((String) key);
      }
    });
  }
  
  public static void writeProperties(Writer writer, Map properties)
    throws IOException
  {
    for (Iterator iter = properties.entrySet().iterator();
	 iter.hasNext();) {
      Map.Entry entry = (Map.Entry) iter.next();
      if (isPropertyPersistent((String) entry.getKey())) {
	writeProperty(writer, entry);
      }
    }
    writer.write(END_STRING);
    writer.write('\n');
  }

  public static void writeProperty(Writer writer, Map.Entry entry)
    throws IOException
  {
    writer.write(Misc.escapeString((String) entry.getKey()));
    writer.write('\t');
    Object value = entry.getValue();
    writer.write(Misc.escapeString(value.toString()));
    writer.write('\n');
  }

  public static Map readProperties(TokenReader reader)
    throws ParseException, IOException
  {
    Map result = new HashMap();
    boolean done = false;
    while (!done) {
      String nextToken = reader.readToken();
      if (nextToken.equals(END_STRING)) {
	done = true;
      }
      else {
	reader.unreadString(nextToken);
	readProperty(reader, result);
      }
    }
    return result;
  }

  public static void readProperty(Reader r, Map map)
    throws ParseException, IOException
  {
    String name = Misc.readEscapedString(r, true);
    String value = Misc.readEscapedString(r, true);
    map.put(name, value);
  }
}
