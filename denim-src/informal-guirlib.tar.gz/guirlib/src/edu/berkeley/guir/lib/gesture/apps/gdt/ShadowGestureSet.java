package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.*;
import java.util.List;
import java.util.Collection;

/** like GestureSet, but the parent pointer in its children is not
    changed */
public class ShadowGestureSet extends GestureSet {
  public ShadowGestureSet()
  {
    super();
  }

  public ShadowGestureSet(Collection children)
  {
    super(children);
  }

  public void add(GestureObject obj)
  {
    if (isChildType(obj.getClass())) {
      List members = getChildren();
      if (!members.contains(obj)) {
	members.add(obj);
	if (obj.getParent() == null) {
	  obj.setParent(this);
	}
	if (obj instanceof GestureContainer) {
	  ((GestureContainer) obj).
	    addCollectionListener(collectionListener);
	}
	obj.addPropertyChangeListener(propChangeListener);
	fireCollectionEvent(CollectionEvent.ELEMENT_ADDED, obj, -1);
	propChangeSupport.firePropertyChange(CHILDREN_PROP, null, obj);
      }
    }
    else {
      throw new
	IllegalArgumentException("Objects of type " +
				 obj.getClass().getName() +
				 " cannot be added to " + this + " [" +
				 this.getClass().getName() + "].");
    }
  }
  
  public void remove(GestureObject obj)
  {
    if (obj != null) {
      if (obj instanceof GestureContainer) {
	((GestureContainer) obj).
	  removeCollectionListener(collectionListener);
      }
      List members = getChildren();
      int index = members.indexOf(obj);
      members.remove(index);
      if (obj.getParent() == this) {
	obj.setParent(null);
      }
      fireCollectionEvent(CollectionEvent.ELEMENT_REMOVED, obj, index);
      propChangeSupport.firePropertyChange(CHILDREN_PROP, obj, null);
    }
  }
}
