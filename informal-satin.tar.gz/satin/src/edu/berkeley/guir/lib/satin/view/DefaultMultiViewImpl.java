//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import java.awt.geom.*;
import java.io.*;
import java.util.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.util.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.objects.*;

/**
 * A sample implementation of a MultiView, which just displays the
 * view with the greatest display value.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 11 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class DefaultMultiViewImpl
   extends    ViewImpl
   implements MultiView {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 3427621134004369722L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   VIEW COMPARATOR INNER CLASS   =======================================

   /**
    * Compares two View's display values, in order to sort the views.
    * Returns values in reverse, so that we will sort in descending order.
    */
   final class ViewComparator implements Comparator, Serializable {
      public final int compare(Object obj1, Object obj2) {
         float v1 = ((View) obj1).getViewDisplayValue();
         float v2 = ((View) obj2).getViewDisplayValue();

         if (v1 < v2) {
            return (1);
         }
         else if (v1 > v2) {
            return (-1);
         }
         else {
            return (0);
         }
      } // of compare
   } // of inner class ViewComparator 

   //===   VIEW COMPARATOR INNER CLASS   =======================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   LinkedList listViews = new LinkedList();       // our list of views
   Comparator comp      = new ViewComparator();   // compares view values

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Does nothing.
    */
   public DefaultMultiViewImpl() {
      commonInitializations();
   } // of default constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      //// 1. Do initializations.
      setName("DefaultMultiViewImpl");
   } // of method

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Recursively calls setBoundingPoints2DRef() on all of the contained views.
    * <P>
    * Chewbacca is a Wookie. Wookies are from Endor. Does this make sense? 
    * Or course it doesn't make sense! If it doesn't make sense, you 
    * must acquit!
    */
   public void setBoundingPoints2DRef(Polygon2D p) {
      Iterator it = listViews.iterator();
      View     v;

      while (it.hasNext()) {
         v = (View) it.next();
         v.setBoundingPoints2DRef(p);
      }

/*
      int size = listViews.size();

      //// 1.1. Do nothing.
      if (size <= 0) {
         //// ignore
      }
      //// 1.2. Get the view and resize it.
      else if (listViews.size() == 1) {
         View v = (View) listViews.getFirst();
         v.setBoundingPoints2DRef(p);
      }
      //// 1.3. Throw an exception.
      else {
         throw new RuntimeException("Multiple Views - setBoundingPoints2DRef() doesn't make sense");
      }
*/
   } // of method

   //-----------------------------------------------------------------

   /**
    * Also modify the attached GraphicalObject for every contained View.
    *
    * @param gob is the GraphicalObject to attach.
    */
   public GraphicalObject setAttachedGraphicalObject(GraphicalObject gob) {
      super.setAttachedGraphicalObject(gob);

      Iterator it = listViews.iterator();
      View     v;
      while (it.hasNext()) {
         v = (View) it.next();
         v.setAttachedGraphicalObject(gob);
      }

      return (gob);
   } // of method

   //-----------------------------------------------------------------

   public View add(View v) {
      listViews.add(v);
      v.setAttachedGraphicalObject(gob);
      return (v);
   } // of method

   //-----------------------------------------------------------------

   public View remove(View v) {
      listViews.remove(v);
      return (v);
   } // of method

   //-----------------------------------------------------------------

   public void clear() {
      listViews.clear();
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Returns the bounding box of all of the contained AND visible views.
    */
   public Polygon2D getBoundingPoints2DRef() {
      //// A. Acquire soft-state.
      Rectangle2D r    = (Rectangle2D) poolRects.getObject();
      Rectangle2D rtmp;
      Polygon2D   p;
      View        v;
      boolean     flagFirst = true;

      //// 1. Get the bounding box.
      Iterator it = this.iterator();
      while (it.hasNext()) {
         //// 1.1. Get the next view.
         v    = (View) it.next();

         //// 1.2. Ignore invisible views.
         if (v.getViewDisplayValue() <= 0.0) {
            continue;
         }

         //// 1.3. Get the bounds and take the union.
         p    = v.getBoundingPoints2DRef();
         rtmp = p.getBounds2D();

         if (flagFirst == true) {
            flagFirst = false;
            r.setRect(rtmp);
         }
         else {
            Rectangle2D.union(r, rtmp, r);
         }
      } 

      //// 2. Set the bounds.
      p = super.getBoundingPoints2DRef();
      p.setToShape(r);

      //// B. Release soft-state.
      poolRects.releaseObject(r);

      return (p);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get an iterator over the views, sorted by their display values (high to
    * low, descending order).
    */
   public Iterator iterator() {
      sortViewsByDisplayValue();
      return (listViews.iterator());
   } // of method

   //-----------------------------------------------------------------

   public View get(int index) {
      if (index < 0 || index >= size()) {
         return (null);
      }
      return ((View) listViews.get(index));
   } // of method

   //-----------------------------------------------------------------

   public boolean contains(View v) {
      return (listViews.contains(v));
   } // of method

   //-----------------------------------------------------------------

   public int size() {
      return (listViews.size());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get an iterator over the valid views (views with display values greater 
    * than 0), sorted by their display values (high to low, descending order).
    */
   protected Iterator getValidViews() {
      //// 1. Sort the views by display values.
      sortViewsByDisplayValue();

      View v;
      int  i;

      //// 2. Now iterate over the views.
      for (i = 0; i < listViews.size(); i++) {
         v = (View) listViews.get(i);
         if (v.getViewDisplayValue() <= 0) {
            //// 2.1. Return the correct subset.
            return (listViews.subList(0, i).iterator());
         }
      }

      //// 3. Otherwise, if we reached the end, then return everything.
      return (listViews.iterator());
   } // of method

   //-----------------------------------------------------------------

   /**
    * @return Always returns 1.
    */
   public float getViewDisplayValue() {
      return (1);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Checks if any contained views are visible.
    */
   public boolean isVisible() {
      Iterator it = listViews.iterator();
      View     v;

      while (it.hasNext()) {
         v = (View) it.next();
         if (v.isVisible()) {
            return (true);
         }
      }

      return (false);
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   RENDERING METHODS   =================================================

   /**
    * Sort the views by their display values, from high to low values
    * (descending order).
    */
   protected void sortViewsByDisplayValue() {
      //// 1. Only use the collections sort if there are many views,
      ////    since it uses mergesort.
      int size = listViews.size();
      if (size > 0) {
         //// 1.1. Do a mergesort if lots of items.
         if (size > 10) {
            Collections.sort(listViews, comp);
         }
         //// 1.2. Otherwise do a bubble sort.
         else {
            boolean flagSwapped = true;
            Object  obj1;
            Object  obj2;
            for (int i = size - 1; (i >= 0) && flagSwapped; i--) {
               for (int j = 0; j < i; j++) {
                  flagSwapped = false;
                  obj1 = listViews.get(j);
                  obj2 = listViews.get(j+1);
                  if (comp.compare(obj1, obj2) > 0) {
                     listViews.set(j,   obj2);
                     listViews.set(j+1, obj1);
                  }
               }
            }

         } // of else
      }
   } // of method

   //-----------------------------------------------------------------

   public void render(SatinGraphics g) {
      sortViewsByDisplayValue();
      if (listViews.size() > 0) {
         ((View) listViews.get(0)).render(g);
      }
   } // of method

   //===   RENDERING METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   /**
    * Print out a list of all of the contained views.
    */
   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 1. Superclass info.
      Iterator     it     = listViews.iterator();
      strbuf.append(super.toString());

      //// 2. Initial string.
      strbuf.append("\nBounds:              " + 
            StringLib.toString(getBoundingPoints2DRef().getBounds2D()));
      strbuf.append("\nContained Views:\n");

      //// 3. List of all views.
      while (it.hasNext()) {
         strbuf.append(StringLib.indent(it.next().toString(), 3));
         if (it.hasNext()) {
            strbuf.append("\n\n");
         }
      }

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new DefaultMultiViewImpl()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Clone chain.
    */
   protected DefaultMultiViewImpl clone(DefaultMultiViewImpl vm) {
      //// 1. Clone chain.
      super.clone(vm);

      //// 2.1. Do clone work.
      vm.comp      = new ViewComparator();
      vm.listViews = new LinkedList();

      //// 2.2. Do a deep clone of the views.
      Iterator it  = listViews.iterator();
      View     v;
      while (it.hasNext()) {
         v = (View) it.next();
         vm.listViews.add((View) v.clone());
      }

      //// 2.3. Re-set the attached Graphical Object.
      vm.setAttachedGraphicalObject(this.getAttachedGraphicalObject());

      //// 3. Return.
      return (vm);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
