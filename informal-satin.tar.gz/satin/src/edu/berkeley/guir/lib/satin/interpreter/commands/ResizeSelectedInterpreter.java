//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter.commands;

import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.interpreter.*;

/**
 * Resize selected GraphicalObjects.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 02 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class ResizeSelectedInterpreter 
   extends InterpreterImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -184293472626407622L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTANTS   =========================================================

   private static final int BOUNDS_THRESHOLD = 10;

   private static final int TOPLEFT     = 8;
   private static final int TOP         = 9;
   private static final int TOPRIGHT    = 10;
   private static final int RIGHT       = 11;
   private static final int BOTTOMRIGHT = 12;
   private static final int BOTTOM      = 13;
   private static final int BOTTOMLEFT  = 14;
   private static final int LEFT        = 15;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   protected GraphicalObject  selgob;     // the gob to resize
   protected int              position;   // TOPLEFT, TOP, RIGHT, etc...

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public ResizeSelectedInterpreter() {
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Move Selected Item Interpreter");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   /**
    * See if the specified point is "near" the specified GraphicalObject.
    */
   private boolean isNearBounds(GraphicalObject gob, Point2D pt) {
      Rectangle2D bds      = gob.getBounds2D(COORD_ABS);
      Line2D      line     = new Line2D.Float();
      Point2D     ptCorner = new Point2D.Float();
      double      x1       = bds.getX();
      double      y1       = bds.getY();
      double      x2       = bds.getX() + bds.getWidth();
      double      y2       = bds.getY() + bds.getHeight();

      //// 1. First case, top-left of rectangle...
      ptCorner.setLocation(x1, y1);
      if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
         position = TOPLEFT;
         return (true);
      }

      //// 2. Second case, top-right of rectangle...
      ptCorner.setLocation(x2, y1);
      if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
         position = TOPRIGHT;
         return (true);
      }

      //// 3. Third case, bottom-right of rectangle...
      ptCorner.setLocation(x2, y2);
      if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
         position = BOTTOMRIGHT;
         return (true);
      }

      //// 4. Fourth case, bottom-left of rectangle...
      ptCorner.setLocation(x1, y2);
      if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
         position = BOTTOMLEFT;
         return (true);
      }

      //// 5. Fifth case, top of rectangle...
      line.setLine(x1, y1, x2, y1);
      if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
         position = TOP;
         return (true);
      }

      //// 6. Sixth case, right side of rectangle...
      line.setLine(x2, y1, x2, y2);
      if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
         position = RIGHT;
         return (true);
      }

      //// 7. Seventh case, bottom side of rectangle...
      line.setLine(x1, y2, x2, y2);
      if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
         position = BOTTOM;
         return (true);
      }

      //// 8. Eighth case, left side of rectangle...
      line.setLine(x1, y1, x1, y2);
      if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
         position = LEFT;
         return (true);
      }

      return (false);
   } // of isNearBounds

   //-----------------------------------------------------------------

   public void handleNewStroke(NewStrokeEvent evt) {
      TimedStroke     stk    = evt.getStroke();
      GraphicalObject gob    = getAttachedGraphicalObject();
      GraphicalObject gobTmp = null;

      //// 1. See if we are over a selected GraphicalObject.
      selgob = null;
      if (gob instanceof GraphicalObjectGroup) {
         Point2D                   ptPress = stk.getStartPoint2D(COORD_ABS);
         GraphicalObjectGroup      gobgrp  = (GraphicalObjectGroup) gob;
         GraphicalObjectCollection gobcol;

         gobcol = gobgrp.getGraphicalObjects(COORD_ABS, ptPress, 
                                             FIRST, SHALLOW, NEAR);
         if (gobcol.numElements() > 0) {
            gobTmp = (GraphicalObject) gobcol.get(0);
         }

         //// 1.1. If the item is selected, then see if we are near
         ////      one of the bounds. If so, keep a reference to it.
         if (cmdsubsys.isSelected(gobTmp)) {
            if (isNearBounds(gobTmp, ptPress)) {
               selgob = gobTmp;
               evt.setConsumed();
               evt.setShouldRender(false);
            }
         }
      }
   } // of handleNewStroke

   //-----------------------------------------------------------------

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      if (selgob != null) {
         TimedStroke     stk       = evt.getStroke();
         Point2D         pt        = stk.getEndPoint2D(COORD_ABS);
         Rectangle2D     oldBounds = selgob.getBounds2D(COORD_ABS);
         Rectangle2D     newBounds = getNewBounds(selgob, pt);
         AffineTransform tx;

/*
         //// Just zoom everything.
         tx = AffineTransformLib.resize(oldBounds, newBounds);
         selgob.applyTransform(tx);
*/

/*
         //// Just resize the bounding points. Makes it rectangular.
         selgob.setBoundingPoints2D(COORD_ABS, newBounds);
*/

         //// 1. Get the transform that will resize us correctly.
         tx = AffineTransformLib.resize(oldBounds, newBounds);
         
         //// 2. Get the bounding points, but modify it.
         /*selgob.setBoundingPoints2D(COORD_ABS, 
	   selgob.getBoundingPoints2D(COORD_ABS, tx, null));*/

	 selgob.applyTransform(tx);

         evt.setConsumed();
         evt.setShouldRender(false);
      }
   } // of handleUpdateStroke

   //-----------------------------------------------------------------

   public void handleSingleStroke(SingleStrokeEvent evt) {
      if (selgob != null) {
         evt.setConsumed();
         evt.setShouldRender(false);
      }
      selgob = null;
   } // of handleSingleStroke

   //-----------------------------------------------------------------

   protected Rectangle2D getNewBounds(GraphicalObject gob, Point2D pt) {
      Rectangle2D bounds = gob.getBounds2D(COORD_ABS);

      double x1 = bounds.getX();
      double y1 = bounds.getY();
      double x2 = bounds.getX() + bounds.getWidth();
      double y2 = bounds.getY() + bounds.getHeight();

      switch (position) {
         case TOPLEFT:     x1 = pt.getX();
                           y1 = pt.getY();
                           break;
         case TOP:         y1 = pt.getY();
                           break;
         case TOPRIGHT:    x2 = pt.getX();
                           y1 = pt.getY();
                           break;
         case RIGHT:       x2 = pt.getX();
                           break;
         case BOTTOMRIGHT: x2 = pt.getX();
                           y2 = pt.getY();
                           break;
         case BOTTOM:      y2 = pt.getY();
                           break;
         case BOTTOMLEFT:  x1 = pt.getX();
                           y2 = pt.getY();
                           break;
         case LEFT:        x1 = pt.getX();
                           break;
      } // of switch

      bounds.setRect(x1, y1, x2 - x1, y2 - y1);
      return (bounds);
   } // of getNewBounds

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (new ResizeSelectedInterpreter());
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
