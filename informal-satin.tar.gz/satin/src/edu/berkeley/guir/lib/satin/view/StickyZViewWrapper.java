//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;

/**
 * Wraps up a view to be non-zoomable.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 16 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3RC1
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class StickyZViewWrapper 
   extends StickyViewWrapper {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -1212309582093653860L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   double desiredScale = 1;     // the scale to "stick" at

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Does nothing.
    */
   public StickyZViewWrapper() {
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Wrap a view into a sticky-Z wrapper, making it appear normal sized
    * despite any kind of zooming.
    */
   public StickyZViewWrapper(View v) {
      super(v);
      setView(v);
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   public StickyZViewWrapper(View v, double newScale) {
      super(v);
      setView(v);
      setDesiredScale(newScale);
   } // of constructor

   //-----------------------------------------------------------------

   public StickyZViewWrapper(View v, double newScale, double startScale, 
                             double endScale) {
      super(v);
      setView(v);
      setDesiredScale(newScale);
      setDisplayRange(startScale, endScale);
   } // of constructor

   //-----------------------------------------------------------------

   public StickyZViewWrapper(View v, double newScale, double fIn, 
                             double startScale, double endScale, double fOut) {
      super(v);
      setView(v);
      setDesiredScale(newScale);
      setDisplayRange(fIn, startScale, endScale, fOut);
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Sticky Z Wrapper");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   protected AffineTransform getStickyTransform(AffineTransform txTmp) {
      //// 1. Figure out the absolute transform and apply the inverse
      ////    so that we will always be the same, ie Sticky-Z.
      getAttachedGraphicalObject().getTransform(COORD_ABS, txTmp);
      double curScale = AffineTransformLib.getScaleFactor(txTmp);
      double scale    = desiredScale / curScale;

      //// 2. Set the inverse transform.
      txTmp.setToScale(scale, scale);
      return (txTmp);
   } // of method

   //-----------------------------------------------------------------

   public double getDesiredScale() {
      return (desiredScale);
   } // of getDesiredScale

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Set the scale this thing is supposed to appear (absolute scale).
    */
   public double setDesiredScale(double newScale) {
      desiredScale = newScale;
      return (newScale);
   } // of setDesiredScale

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new StickyZViewWrapper()));
   } // of method

   //-----------------------------------------------------------------

   protected StickyZViewWrapper clone(StickyZViewWrapper vw) {
      //// 1. Clone chain.
      super.clone(vw);

      //// 2. Do clone work.
      vw.desiredScale = this.desiredScale;

      //// 3. Return.
      return (vw);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
