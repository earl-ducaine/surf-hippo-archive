package edu.berkeley.guir.lib.gesture.features;

import java.lang.Math;
import java.awt.Rectangle;
import edu.berkeley.guir.lib.gesture.*;

/**
 * Angle of the bounding box
 */
public class BoundsAngle extends Feature {
  public final double minValue = 0;
  public final double maxValue = Math.PI / 2.0;
  
  public BoundsAngle()
  {
    super();
  }

  public BoundsAngle(Gesture g)
  {
    super(g);
  }

  protected void computeValue()
  {
    Rectangle bounds = gesture.getBounds();

    value = Math.atan2(bounds.height, bounds.width);
    valueOk = true;
  }

  public String getName()
  {
    return new String("angle of bounding box");
  }

  public double getMinValue()
  {
    return minValue;
  }
  
  public double getMaxValue()
  {
    return maxValue;
  }

  public void scale(double factor)
  {
    gesture.normalize();
    TimedPolygon points = gesture.getPointsRef();
    int i;

    // could scale by shrinking or by growing.  To avoid the gesture
    // becoming tiny, always make it grow
    
    for (i = 0; i < points.npoints; i++) {
      if (factor < 1) {
	// to increase angle, make it taller
	points.ypoints[i] /= factor;
      }
      else {
	// to decrease angle, make it wider
	points.xpoints[i] *= factor;
      }
    }
    gesture.setPoints(points);
  }
}
