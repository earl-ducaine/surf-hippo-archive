package edu.berkeley.guir.denim.interpreters;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.DenimSketch;
import edu.berkeley.guir.denim.ScribbledText;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.lib.awt.geom.Polygon2D;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.DefaultInterpreterImpl;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

/**
 * Handles grouping objects within Denim sketches together.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-16-2002 JL
 *                    Created class GroupInterpreter.
 *             2.0.0  08-07-2004 YL
 *                    Enabled splitting gesture
 * </PRE>
 *
 * @see    DenimGroup
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2.2
 * @version Version 2.0.0, 08-07-2004
 */
public class GroupInterpreter
   extends DefaultInterpreterImpl
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //static final long serialVersionUID = -8017215452120447905L;

   //===   CONSTANTS   =========================================================
   //===========================================================================


   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   private static List instances = new ArrayList();

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs a group interpreter.
    */
   public GroupInterpreter() {
      super();
      commonInitializations();
   }

   /**
    * Constructs a group interpreter as a copy of the given
    * interpreter.
    */
   public GroupInterpreter(GroupInterpreter intrp) {
      //// 1. Since this interpreter is stateless, we can do this safely.
      this();
      commonInitializations();
   }

   //-----------------------------------------------------------------

   /**
    * Perform initializations common to all constructors.
    */
   private void commonInitializations() {
      setName("Denim Group Interpreter");

      //// Have the class keep track of this instance
      instances.add(this);
      
      if (DenimSketch.getPrototypeGroupInterpreter() != null) {
         setEnabledLocally(DenimSketch.getPrototypeGroupInterpreter().isEnabled());
      }
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   /**
    * Called when the user finishes drawing a stroke. Takes everything drawn
    * within the stroke, and puts them in a group.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
       if(this.getAttachedGraphicalObject() instanceof DenimSheet.RootGraphicalObject)
       {
          DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject().getSheet();
          TimedStroke stk = evt.getStroke();
          GraphicalObjectGroup parent = null;
          
          double currentScale = sheet.getAbsScale();
          if (currentScale > (DenimConstants.SITEMAP_SCALE_FACTOR + DenimConstants.BETWEEN_OVERVIEW_SITEMAP_SCALE_FACTOR)/ 2
                  &&currentScale < (DenimConstants.SITEMAP_SCALE_FACTOR + DenimConstants.BETWEEN_SITEMAP_STORYBOARD_SCALE_FACTOR)/ 2)
          {
              parent = sheet;
          }
          else
          {
              Rectangle2D range = stk.getBounds2D(COORD_ABS);
              Iterator it = sheet.getReverseIterator();
              while(it.hasNext())
              {
                  GraphicalObject gob = (GraphicalObject)it.next();
                  Rectangle2D box = gob.getBounds2D(COORD_ABS);
                  if(gob instanceof DenimPanel&&box.contains(range.getCenterX(),range.getCenterY()))
                  {
                      parent = ((DenimPanel)gob).getSketch();
                      break;
                  }
              }
          }
          
          if(parent!=null)
          {
              //if it's a splitting gesture
              Polygon2D poly = stk.getPolygon2D(COORD_ABS);
              double len = getTotalLen(poly);
              if(len > 30)
              {
                  double factor = linearDetection(poly, len);
                  if(factor>0.7)
                  {
                      Rectangle2D box = stk.getBounds2D(COORD_ABS);
                      GraphicalObjectCollection col = 
                          parent.getGraphicalObjects(COORD_ABS, 
                                  new Point2D.Double(box.getCenterX(),box.getCenterY()), 
                                          ALL, SHALLOW, CONTAINS);
                      Iterator it = col.getForwardIterator();
                      while(it.hasNext()) 
                      {
                         GraphicalObject gob = (GraphicalObject)it.next();
                         if(gob instanceof ScribbledText||
                                 (gob instanceof DenimPanel&&((DenimPanel)gob).getLabel().getCaption() instanceof ScribbledText))
                         {
                             boolean isVertical = box.getHeight()>box.getWidth()?true:false;
                             SatinConstants.cmdqueue.doCommand( 
                                     new SplitCommand(parent, gob,
                                             new Point2D.Double(box.getCenterX(),box.getCenterY()), isVertical));
                             break;
                         }
                      }
                  }
                  else // if not, it's grouping gesture
                  {
                      SatinConstants.cmdqueue.doCommand(new GroupCommand(parent, stk));
                  }
              }

          }
       }
       evt.setConsumed(true);          
   }

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================

   /**
    * Enables or disables <i>all</i> instances of GroupInterpreter.
    */
   public void setEnabled(boolean flag) {
      setAllEnabled(flag);
   }

   //-----------------------------------------------------------------
   
   public static double getTotalLen(Polygon2D poly) {
       double len = 0;
       for(int i=1; i<poly.npoints; i++)
       {
           double v11 = poly.xpoints[i]-poly.xpoints[i-1];
           double v12 = poly.ypoints[i]-poly.ypoints[i-1];
           double v1_len = Math.sqrt(Math.pow(v11,2)+Math.pow(v12,2));
           len += v1_len;
       }
       return len;
   }
   
   public static double linearDetection(Polygon2D poly, double totallen) {
       
       Point2D sp = new Point2D.Double(poly.xpoints[0],poly.ypoints[0]);
       Point2D ep = new Point2D.Double(poly.xpoints[poly.npoints-1],poly.ypoints[poly.npoints-1]);
       
       return  sp.distance(ep)/totallen;
   }

   //-----------------------------------------------------------------

   /**
    * Enables or disables <i>all</i> instances of GroupInterpreter.
    */   
   public static void setAllEnabled(boolean flag) {
      for (Iterator it = instances.iterator(); it.hasNext(); ) {
         ((GroupInterpreter)it.next()).setEnabledLocally(flag);
      }
   }

   //-----------------------------------------------------------------

   private void setEnabledLocally(boolean flag) {
      super.setEnabled(flag);
   }


   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      return (new GroupInterpreter(this));
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
