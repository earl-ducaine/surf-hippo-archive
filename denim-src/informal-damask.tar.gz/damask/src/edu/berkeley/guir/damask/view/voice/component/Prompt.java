package edu.berkeley.guir.damask.view.voice.component;

import java.awt.Color;
import java.awt.Insets;
import java.awt.geom.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.border.EmptyBorder;
import javax.swing.text.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.command.SetVoicePromptTextCommand;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.event.StyledTextEventHandler;
import edu.berkeley.guir.damask.view.voice.VoiceCanvas;
import edu.berkeley.guir.damask.view.voice.VoiceLayer;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PText;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolox.nodes.PStyledText;

/** 
 * Represents a prompt that the computer says.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-18-2004 James Lin
 *                               Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 */
public class Prompt extends VoicePart {
   private static final int CORNER_RADIUS = 10;
   private static final Color BORDER_COLOR = new Color(186, 125, 0);
   private static final Color INTERIOR_COLOR = new Color(255, 239, 165);
   private static final Color SYNC_ON_COLOR = BORDER_COLOR;
   private static final Color SYNC_OFF_COLOR = new Color(223, 214, 175);

   private static final int INSET = 6;
   
   private final ControlVoiceHandler voiceHandler = new ControlVoiceHandler();
   private final PText text = new PText();
   private SyncButton syncButton;
   private final ElementHandler elementHandler = new ElementHandler();

   /**
    * Creates a prompt with the specified control.
    */
   public Prompt(final VoiceControl voiceControl) {
      super(voiceControl.getModel(), false);
      init();
   }

   
   private void init() {
      setPaint(INTERIOR_COLOR);
      setStrokePaint(BORDER_COLOR);
      setResizable(false);
      DamaskAppUtils.setFontSize(text, DeviceType.VOICE.getDefaultFontSize());
   }
   
   
   // @Override
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();

      final Control model = (Control)getModel();

      model.addControlVoiceListener(voiceHandler);
      final Rectangle2D modelPromptBounds = model.getVoicePromptBounds();
      text.setBounds(modelPromptBounds);
      
      setPathTo(
         new RoundRectangle2D.Double(
            modelPromptBounds.getX() - INSET - CORNER_RADIUS,
            modelPromptBounds.getY() - INSET,
            modelPromptBounds.getWidth() + CORNER_RADIUS + INSET*2,
            modelPromptBounds.getHeight() + INSET*2,
            CORNER_RADIUS,
            CORNER_RADIUS));
      setTransform(new AffineTransform());
      
      // Setup the label's text
      text.setPickable(false);
      setTextString(model.getVoicePromptText());
      
      addChild(text);

      model.addInteractionElementListener(elementHandler);

      // Set up the button that determines whether the voice text syncs
      // with the desktop/smartphone text
      final List/*<Content>*/ contentModel = new ArrayList/*<Content>*/();
      contentModel.add(getContentModel());
      syncButton =
         new SyncButton(
            new Rectangle2D.Double(
               getBounds().getX(),
               getBounds().getY(),
               CORNER_RADIUS,
               (float) getHeight()),
            contentModel,
            SYNC_ON_COLOR,
            SYNC_OFF_COLOR);
      if (model.isForAllDeviceTypes()) {
         addChild(syncButton);
      }
   }


   // Overrides method in parent class.
   public void dispose() {
      super.dispose();
      syncButton.dispose();
      ((Control)getModel()).removeControlVoiceListener(voiceHandler);
   }


   /**
    * Gets the text node contained in this prompt.
    */
   protected PText getText() {
      return text;
   }


   /**
    * Gets the text contained in this prompt.
    */
   public String getTextString() {
      return text.getText();
   }


   /**
    * Returns the content that supplies the text for this prompt.
    */
   private Content getContentModel() {
      final Control control = (Control)getModel();
      if (control instanceof Content) {
         return (Content)control;
      }
      else {
         return ((SelectMany.Item)control).getContent();
      }
   }

   
   /**
    * Sets the text contained in this prompt.
    */
   protected void setTextString(final String newString) {
      text.setText(newString);
   }


   /**
    * Adjusts the transparency of the specified prompt, depending on
    * what its device type is and what the current device-type layer is. 
    */
   protected void deviceTypeLayerChanged() {
      final DeviceType componentDeviceType =
         ((Component)getModel()).getDeviceType();

      final DamaskLayer layer = getLayer();
      if (layer == null) {
         return;
      }
      if (componentDeviceType == layer.getDeviceTypeForNewElement()) {
         DamaskAppUtils.setInternalColorAlpha(
            this, VoiceLayer.THIS_LAYER_ALPHA);
      }
      else {
         DamaskAppUtils.setInternalColorAlpha(
            this, VoiceLayer.OTHER_LAYER_ALPHA);
      }
      
      repaint();
   }
   
   
   /**
    * Handles events from the model object. 
    */
   private class ElementHandler implements InteractionElementListener {
      public void elementBoundsUpdated(InteractionElementEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            final Rectangle2D modelPromptBounds =
               ((Control)e.getElement()).getVoicePromptBounds();
            setPathTo(
               new RoundRectangle2D.Double(
                  modelPromptBounds.getX() - CORNER_RADIUS - INSET,
                  modelPromptBounds.getY() - INSET,
                  modelPromptBounds.getWidth() + CORNER_RADIUS + INSET*2,
                  modelPromptBounds.getHeight() + INSET*2,
                  CORNER_RADIUS,
                  CORNER_RADIUS));
         }
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }
   
   
   /**
    * Handles events from the model object. 
    */
   private class ControlVoiceHandler implements ControlVoiceListener {

      // @Override
      public void promptTextChanged(ControlVoiceEvent e) {
         assert e.getSource() == getModel();
         setTextString(((Control)getModel()).getVoicePromptText());
      }

      // @Override
      public void promptBoundsChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseSourceChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseDestChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseLineChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseTextChanged(ControlVoiceEvent e) {
      }
   }

   
   /**
    * The event handler for entering text within a response.
    */
   public static class TextHandler extends StyledTextEventHandler {
      private Prompt pickedPrompt;
      private final PStyledText styledText = createText();
         
      public TextHandler() {
         super();
         init();
      }

      public TextHandler(JTextComponent editor) {
         super(editor);
         init();
      }

      private void init() {
         DamaskAppUtils.setFont(styledText, DamaskAppUtils.getDefaultFont());
      }
      
      // Ignore all mouse presses. This event handler is called by
      // DragFromPromptHandler instead.
      public void mousePressed(PInputEvent event) {
      }
      
      public void startEditing(final PInputEvent event, final Prompt prompt) {
         final VoiceCanvas canvas = (VoiceCanvas)event.getComponent();
         canvas.setTextEditing(true);
         
         canvas.setActiveTextHandler(this);

         final DamaskLayer layer = prompt.getLayer();
         
//         if (((Control)prompt.getModel()).getDeviceType() !=
//             layer.getDeviceTypeForNewElement()) {
//            if (!DamaskAppUtils.askToChangeLayers(layer,
//               (JComponent)event.getComponent())) {
//               pickedPrompt = null;
//               return;
//            }
//         }
         
         pickedPrompt = prompt;

         DamaskAppUtils.setText(styledText, pickedPrompt.getTextString());
         
         DamaskAppUtils.setFontSize(
            styledText, pickedPrompt.getText().getFont().getSize());
      
         final Insets pInsets = styledText.getInsets();

         layer.addChild(styledText);
         // will be removed in stopEditing()

         final PBounds textGlobalBounds =
            pickedPrompt.getText().getFullBounds();
         pickedPrompt.getText().getParent().localToGlobal(textGlobalBounds);
            
         final Point2D position = textGlobalBounds.getOrigin();

         styledText.setOffset(
            position.getX() - pInsets.left,
            position.getY() - pInsets.top);
         
         startEditing(event, styledText);
      }


      public void stopEditing() {
         if (canvas instanceof DamaskCanvas) {
            ((DamaskCanvas)canvas).setTextEditing(false);
         }
         
         if (editedText != null) {
            final DamaskCanvas damaskCanvas = (DamaskCanvas)canvas;
            final Document editedDoc = editedText.getDocument(); 
            editedDoc.removeDocumentListener(docListener);
            editedText.setEditing(false);
            editedText.syncWithDocument();

            editedText.removeFromParent();
            
            // If the document is empty...
            if (editedText.getDocument().getLength() == 0) {
            }
            else {
               try {
                  damaskCanvas.getDocument().getCommandQueue().doCommand(
                     damaskCanvas,
                     new SetVoicePromptTextCommand(
                        pickedPrompt.getContentModel(),
                        editedDoc.getText(0, editedDoc.getLength())));
               }
               
               catch (BadLocationException e) {
                  // should never happen
                  DamaskAppExceptionHandler.log(e);
               }
            }

            editor.setVisible(false);
            canvas.repaint();

            editedText = null;
         }
      }

      protected JTextComponent createDefaultEditor() {
         final JTextComponent tComp = super.createDefaultEditor();
         tComp.setBorder(new EmptyBorder(0, 0, 0, 0));
         return tComp;
      }
   }
}
