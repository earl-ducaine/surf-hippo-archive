package edu.berkeley.guir.damask.component;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.view.visual.component.ComboBox;
import edu.berkeley.guir.damask.view.visual.component.ListBox;
import edu.berkeley.guir.lib.awt.geom.GeomLib;

/** 
 * A control which presents a list of choices that can be
 * made by the end user.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-21-2003 James Lin
 *                               Created SelectBase.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-21-2003
 */
public abstract class Select extends Control {
   private List/*<Item>*/ items = new ArrayList/*<Item>*/();
   private ElementContainerSource containerSource =
      new ElementContainerSource();

   private Map/*<DeviceType, Style>*/ styles =
      new HashMap/*<DeviceType, Style>*/();
   private ItemHandler itemHandler = new ItemHandler();

   // Initialize default insets
   private static final Rectangle2D DEFAULT_VISUAL_COMPACT_BOUNDS =
      ListBox.createTempView().getBounds();
   private static final Rectangle2D DEFAULT_VISUAL_MINIMAL_BOUNDS =
      ComboBox.createTempView().getBounds();
   
   //===========================================================================

   protected Select(final DeviceType deviceType) {
      super(deviceType);

      // Make the default setting "full" for all devices. This
      // gets partially overridden in SelectOne and SelectMany.
      for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
         i.hasNext();
         ) {

         final DeviceType aDeviceType = (DeviceType)i.next();
         styles.put(aDeviceType, FULL);
      }
   }


   protected Select(final Select select, final DeviceType deviceType) {
      super(select, deviceType);
      styles = new HashMap/*<DeviceType, Style>*/(select.styles);
      
      // Items are added by constructor in concrete subclasses
   }


   // @Override
   protected void autoPositionForDesktop() {
      // If a smartphone version exists, then use its style.
      final Style phoneStyle = (Style)styles.get(DeviceType.SMARTPHONE);
      if (phoneStyle != null) {
         setStyle(DeviceType.DESKTOP, phoneStyle);
      }
      
      if (getStyle(DeviceType.DESKTOP) == COMPACT) {
         setBounds(DeviceType.DESKTOP, DEFAULT_VISUAL_COMPACT_BOUNDS);
      }
      else if (getStyle(DeviceType.DESKTOP) == MINIMAL) {
         setBounds(DeviceType.DESKTOP, DEFAULT_VISUAL_MINIMAL_BOUNDS);
      }
      
      placeAfterAllControls(DeviceType.DESKTOP);
   }

   // @Override
   protected void autoPositionForSmartphone() {
      // If a desktop version exists, then use its style.
      final Style desktopStyle = (Style)styles.get(DeviceType.DESKTOP);
      if (desktopStyle != null) {
         setStyle(DeviceType.SMARTPHONE, desktopStyle);
      }

      if (getStyle(DeviceType.SMARTPHONE) == COMPACT) {
         setBounds(DeviceType.SMARTPHONE, DEFAULT_VISUAL_COMPACT_BOUNDS);
      }
      else if (getStyle(DeviceType.SMARTPHONE) == MINIMAL) {
         setBounds(DeviceType.SMARTPHONE, DEFAULT_VISUAL_MINIMAL_BOUNDS);
      }
      
      placeAfterAllControls(DeviceType.SMARTPHONE);
   }

   /**
    * Returns the style of this control for the specified device type. 
    */
   public Style getStyle(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(deviceType),
         this + " supports " + getDeviceType() + ", not " + deviceType);
      final Style style = (Style)styles.get(deviceType);
      return style;
   }


   /**
    * Sets the style for the specified device type. 
    */
   public void setStyle(final DeviceType deviceType, final Style style) {
      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(deviceType),
         this + " supports " + getDeviceType() + ", not " + deviceType);
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext();
         ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         styles.put(aDeviceType, style);
      }
   }
   
   
   /**
    * Adds the specified item to the end of the list in this control.
    */
   public final void addItem(final Item item) {
      addItem(items.size(), item);
   }
   
   
   /**
    * Adds the specified item at the specified position in this control.
    */
   public void addItem(final int index, final Item item) {
      final PageRegion voiceRegion = getPageRegion(DeviceType.VOICE); 
      if (voiceRegion != null &&
          voiceRegion.getControls().indexOf(this) != -1) {
         voiceRegion.prepareLayoutVoiceControls();
      }
      
      items.add(index, item);
      item.setParent(this);
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         final PageRegion aRegion = getPageRegion(aDeviceType);
         if (aRegion != null) {
            item.setPageRegion(aDeviceType, aRegion);
         }
      }
      item.addInteractionElementListener(itemHandler);
      fireElementAdded(index, item);
      updateBounds(getDeviceType());
      
      if (voiceRegion != null &&
          voiceRegion.getControls().indexOf(this) != -1) {
         voiceRegion.layoutVoiceControls();
      }
   }
   
   
   /**
    * Returns a reference to an unmodifiable list of items in this control.
    * 
    * @return a list of Select.Item
    */
   public List/*<Item>*/ getItems() {
      return Collections.unmodifiableList(items);
   }
   
   
   /**
    * Removes the item at the specified position in this control.
    * 
    * @return the item that was removed
    */
   public Item removeItem(final int index) {
      final PageRegion voiceRegion = getPageRegion(DeviceType.VOICE); 
      if (voiceRegion != null &&
          voiceRegion.getControls().indexOf(this) != -1) {
         voiceRegion.prepareLayoutVoiceControls();
      }
      
      final Item item = (Item)items.remove(index);
      item.removeInteractionElementListener(itemHandler); 
      fireElementRemoved(index, item);
      updateBounds(getDeviceType());
      
      if (voiceRegion != null &&
          voiceRegion.getControls().indexOf(this) != -1) {
         voiceRegion.layoutVoiceControls();
      }
      
      return item;
   }
   
   
   /**
    * Removes the specified item from this control.
    * 
    * @return true if the item was in this control in the first place
    */
   public final boolean removeItem(final Item item) {
      final int index = items.indexOf(item);
      if (index != -1) {
         removeItem(index);
         return true;
      }
      else {
         return false;
      }
   }


   // @Override
   public void setPageRegion(final DeviceType aDeviceType,
                             final PageRegion aRegion) {
      super.setPageRegion(aDeviceType, aRegion);
      for (Iterator i = getItems().iterator(); i.hasNext(); ) {
         final Item item = (Item)i.next();
         item.setPageRegion(aDeviceType, aRegion);
      }
   }

   
   /**
    * Returns the content of this control, which is always null.
    */
   public Content getContent() {
      return null;
   }


   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public void addElementContainerListener(
      final ElementContainerListener listener) {
         
      containerSource.addElementContainerListener(listener);
   }


   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public void removeElementContainerListener(
      final ElementContainerListener listener) {
      
      containerSource.removeElementContainerListener(listener);
   }

   
   /**
    * Fires elementAdded events to listeners.
    */
   protected void fireElementAdded(final int index, final Item item) {
      containerSource.fireElementAdded(this, DeviceType.ALL, index, item);
   }


   /**
    * Fires elementRemoved events to listeners.
    */
   protected void fireElementRemoved(final int index, final Item item) {
      containerSource.fireElementRemoved(this, DeviceType.ALL, index, item);
   }
   
   
   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      final Select clone = (Select)super.clone();
      clone.containerSource = new ElementContainerSource();
      clone.itemHandler = clone.new ItemHandler();
      
      clone.items = new ArrayList();
      for (Iterator i = items.iterator(); i.hasNext(); ) {
         final Item item = (Item)i.next();
         clone.addItem((Item)item.clone());
      }
      clone.styles = new HashMap/*<DeviceType, Style>*/(styles);
      
      return clone;
   }


   /**
    * Finds the item that is "before" the specified rectangular region,
    * or null if there isn't any.
    */
   public Item getItemBefore(
      final DeviceType pageDeviceType,
      final DeviceType newControlDeviceType,
      final AffineTransform newControlTransform,
      final Rectangle2D newControlBounds) {
   
      return (Item)DamaskUtils.getControlBefore(
         pageDeviceType,
         getItems().iterator(),
         newControlDeviceType,
         newControlTransform,
         newControlBounds);
   }
   

   /**
    * If the style of this object is FULL, then sets the bounds of this object 
    * to the union of the bounds of all of the items in this object.
    */
   private void updateBounds(final DeviceType deviceType) {
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator(); i
            .hasNext();) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         if (getStyle(aDeviceType) == FULL) {
            Rectangle2D newBounds = null;
            for (Iterator j = getItems().iterator(); j.hasNext(); ) {
               final Select.Item item = (Select.Item)j.next();
               final Rectangle2D itemBounds =
                  item.getBoundsInParentCoords(aDeviceType);
               if (itemBounds == null) {
               }
               else if (newBounds == null) {
                  newBounds = itemBounds;
               }
               else {
                  Rectangle2D.union(newBounds, itemBounds, newBounds);
               }
            }
            if (newBounds != null) {
               setBounds(aDeviceType, newBounds);
            }
         }
      }
   }


   /**
    * If the style of this object is FULL, then identity transform. Otherwise,
    * returns the normal bounds.
    */
   public AffineTransform getTransform(final DeviceType deviceType) {
      if (getStyle(deviceType) == FULL) {
         return new AffineTransform();
      }
      else {
         return super.getTransform(deviceType);
      }
   }

   
   //===========================================================================

   /**
    * Handles events from the items within this control.
    */
   private class ItemHandler implements InteractionElementListener {
      // Ensures that the items do not overlap vertically
      private void reshape(final DeviceType deviceType) {
         Rectangle2D prevItemBounds = null;
         for (Iterator i = getItems().iterator(); i.hasNext(); ) {
            final Item item = (Item)i.next();
            final AffineTransform itemTransform = item.getTransform(deviceType);
            final Rectangle2D itemBounds = item.getBoundsInParentCoords(deviceType);
            if ((itemBounds != null) && (prevItemBounds != null)) {
               if (itemBounds.getMinY() < prevItemBounds.getMaxY()) {
                  final AffineTransform translateY =
                     AffineTransform.getTranslateInstance(
                        0,
                        prevItemBounds.getMaxY() - itemBounds.getMinY());
                  itemTransform.preConcatenate(translateY);
                  item.setTransform(deviceType, itemTransform);
                  GeomLib.transformRectangle(translateY, itemBounds);
               }
            }
            prevItemBounds = itemBounds;
         }
      }

      public void elementBoundsUpdated(InteractionElementEvent e) {
         if (getStyle(e.getDeviceType()) != FULL) {
            reshape(e.getDeviceType());
         }
         updateBounds(e.getDeviceType());
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
         updateBounds(e.getDeviceType());
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }
   
   //===========================================================================

   public static class Style {
      private String name;

      private Style(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   public static final Style FULL = new Style("full");
   public static final Style COMPACT = new Style("compact");
   public static final Style MINIMAL = new Style("minimal");
   private static final Style[] VALUES = new Style[] {MINIMAL, COMPACT, FULL};
   
   
   /**
    * Returns a list of styles that this object supports.
    */
   public static List/*<Style>*/ getSupportedStyles() {
      return Arrays.asList(VALUES);
   }

   //===========================================================================

   public abstract static class Item extends Control {
      private Content content;
      private Select parent = null;

      // The difference in bounding box between the item and the item's caption
      private Map/*<DeviceType, Insets2D>*/ insetsForDevice =
         new HashMap()/*<DeviceType, Insets2D>*/;

      /**
       * Constructs an item with the given content.
       */
      public Item(final Content content) {
         super(content.getDeviceType());
         this.content = content;
         init();
      }
      
      /**
       * Constructs an item for the specified device type, copying properties
       * from the specified item.
       */
      public Item(final Item item, final DeviceType deviceType) {
         super(item, deviceType);
         this.content = new Content(item.getContent(), deviceType);

         for (Iterator i =
            content.getDeviceType().getSpecificDeviceTypes().iterator();
            i.hasNext();
            ) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            insetsForDevice.put(aDeviceType,
                                item.insetsForDevice.get(aDeviceType));
         }
         
         init();
      }

      private void init() {
         final ContentHandler contentHandler = new ContentHandler();
         content.addInteractionElementListener(contentHandler);
         content.addContentEventListener(contentHandler);
      }

      
      // @Override
      public Control getControlBefore(final DeviceType deviceType) {
         final List/*<Item>*/ items = getParent().getItems();
         final int index = items.indexOf(this);
         if (index == 0) {
            return null;
         }
         else {
            return (Control)items.get(index - 1);
         }
      }
      

      // @Override
      public Control getControlAfter(final DeviceType deviceType) {
         final List/*<Item>*/ items = getParent().getItems();
         final int index = items.indexOf(this);
         if (index == items.size() - 1) {
            return null;
         }
         else {
            return (Control)items.get(index + 1);
         }
      }

      // @Override
      protected void autoPositionForDesktop() {
         final Rectangle2D fullBounds =
            content.getFullSizeBounds(
               content.getPreferredDisplayMode(DeviceType.DESKTOP));
         
         final Insets2D insets = getContentInsets(DeviceType.DESKTOP);
         
         content.setBounds(
            DeviceType.DESKTOP,
            new Rectangle2D.Double(fullBounds.getX() + insets.getLeft(),
               fullBounds.getY() + insets.getTop(),
               fullBounds.getWidth(),
               fullBounds.getHeight()));

         updateBounds(DeviceType.DESKTOP);
         
         final Select parent = getParent();
         if (parent == null || parent.getStyle(DeviceType.DESKTOP) == FULL) {
            placeAfterAllControls(DeviceType.DESKTOP);
         }
      }

      // @Override
      protected void autoPositionForSmartphone() {
         final Rectangle2D fullBounds =
            content.getFullSizeBounds(
               content.getPreferredDisplayMode(DeviceType.SMARTPHONE));
         
         final Insets2D insets = getContentInsets(DeviceType.SMARTPHONE);
         
         content.setBounds(
            DeviceType.SMARTPHONE,
            new Rectangle2D.Double(fullBounds.getX() + insets.getLeft(),
               fullBounds.getY() + insets.getTop(),
               fullBounds.getWidth(),
               fullBounds.getHeight()));

         updateBounds(DeviceType.SMARTPHONE);
         
         final Select parent = getParent();
         if (parent == null || parent.getStyle(DeviceType.SMARTPHONE) == FULL) {
            placeAfterAllControls(DeviceType.SMARTPHONE);
         }
      }

      /**
       * Returns the content of this item. 
       */
      public Content getContent() {
         return content;
      }

      /**
       * Sets the content of this item.
       */
      protected void setContent(final Content content) {
         this.content = content;
      }
      
      /**
       * Returns the control that this item is in. 
       */
      public Select getParent() {
         return parent;
      }
      
      /**
       * Sets the control that this item is in.
       */
      protected void setParent(final Select parent) {
         this.parent = parent;
      }
      
      // @Override
      public Page getPage(DeviceType deviceType) {
         if (parent == null) {
            return null;
         }
         else {
            return parent.getPage(deviceType);
         }
      }

      
      // @Override
      public void setPageRegion(
         final DeviceType deviceType,
         final PageRegion region) {

         final PageRegion oldRegion = getPageRegion(deviceType);
         if (oldRegion == region) {
            return;
         }
         
         // Set the insets, and adjust the bounds to reflect the insets
         if (getContentInsets(deviceType) == null) {
            setContentInsets(
               deviceType,
               getDefaultInsets(deviceType, getParent().getStyle(deviceType)));
         }

         super.setPageRegion(deviceType, region);
      }
      
      
      /**
       * Returns the default difference between the bounding box of this
       * control and this control's content for the specified device type
       * and style.
       */
      public abstract Insets2D getDefaultInsets(
         final DeviceType deviceType, final Style style);
      
      
      /**
       * Returns the difference between the bounding box of this control and this
       * control's content for the specified device type.
       */
      public Insets2D getContentInsets(final DeviceType deviceType) {
         deviceType.verifyTypeIsNotAll();
         return (Insets2D)insetsForDevice.get(deviceType);
      }

      /**
       * Sets the difference between the bounding box of this control and this
       * control's content for the specified device type. Calling this method
       * does <i>not</i> automatically change the bounds of this control.
       */
      public void setContentInsets(
         final DeviceType deviceType,
         final double top,
         final double left,
         final double bottom,
         final double right) {
            
         setContentInsets(deviceType, new Insets2D(top, left, bottom, right));
      }
      
      /**
       * Sets the difference between the bounding box of this item and this
       * control's content for the specified device type. Calling this method
       * does <i>not</i> automatically change the bounds of this control.
       */
      public void setContentInsets(
         final DeviceType deviceType,
         final Insets2D insets) {
         for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
            i.hasNext();
            ) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            insetsForDevice.put(aDeviceType, insets);
         }
      }

      /**
       * Sets the bounds of this item based on the item's content and
       * insets for the specified device type.
       */
      private void updateBounds(final DeviceType deviceType) {
         final Content content = getContent();
         for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
            i.hasNext();
            ) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            if (aDeviceType == DeviceType.VOICE) {
               updateVoiceDisplayProperties();
            }
            else {
               final Rectangle2D contentBounds =
                  content.getBoundsInParentCoords(aDeviceType);
               Insets2D insets = getContentInsets(aDeviceType);
               if (insets == null) {
                  insets = new Insets2D(0, 0, 0, 0);
               }
               setBounds(
                  aDeviceType,
                  new Rectangle2D.Double(
                     contentBounds.getX() - insets.getLeft(),
                     contentBounds.getY() - insets.getTop(),
                     contentBounds.getWidth()
                        + insets.getLeft()
                        + insets.getRight(),
                     contentBounds.getHeight()
                        + insets.getTop()
                        + insets.getBottom()));
            }
         }
      }
      
      protected abstract void updateVoiceDisplayProperties();
      
      // Overrides method in ancestor class.
      public Object clone() {
         final Item clone = (Item)super.clone();
         clone.parent = null;
         if (content != null) {
            clone.content = (Content)content.clone();
            final ContentHandler cloneContentHandler =
               clone.new ContentHandler();
            clone.content.addInteractionElementListener(cloneContentHandler);
            clone.content.addContentEventListener(cloneContentHandler);
         }
         clone.insetsForDevice = new HashMap(insetsForDevice);
         return clone;
      }

      // Overrides method in Control class.
      public Object getDefaultState() {
         return Boolean.FALSE;
      }


      // Overrides method in ancestor class.
      public String toString() {
         return super.toString() + " - " + content.contentsToString();
      }


      private class ContentHandler implements InteractionElementListener,
      ContentListener {
         public void elementBoundsUpdated(InteractionElementEvent e) {
            if (e.getElement() == getContent()) {
               updateBounds(e.getDeviceType());
            }
         }

         public void elementTransformUpdated(InteractionElementEvent e) {
            if (e.getElement() == getContent()) {
               updateBounds(e.getDeviceType());
            }
         }

         public void elementBorderUpdated(InteractionElementEvent e) {
         }

         public void preferredDisplayModeChanged(ContentEvent e) {
            if (e.getContent() == getContent()) {
               updateBounds(e.getDeviceType());
            }
         }

         // @Override
         public void strokeAdded(ContentEvent e) {
            if (e.getContent() == getContent()) {
               updateBounds(e.getDeviceType());
            }
         }

         // @Override
         public void strokeRemoved(ContentEvent e) {
            if (e.getContent() == getContent()) {
               updateBounds(e.getDeviceType());
            }
         }

         // @Override
         public void strokesChanged(ContentEvent e) {
            if (e.getContent() == getContent()) {
               updateBounds(e.getDeviceType());
            }
         }

         // @Override
         public void textChanged(ContentEvent e) {
            if (e.getContent() == getContent()) {
               updateBounds(e.getDeviceType());
            }
         }

         // @Override
         public void voiceTextChanged(ContentEvent e) {
            if (e.getContent() == getContent()) {
               updateBounds(e.getDeviceType());
            }
         }

         // @Override
         public void imageChanged(ContentEvent e) {
            if (e.getContent() == getContent()) {
               updateBounds(e.getDeviceType());
            }
         }

         // @Override
         public void promptTextIsSyncedWithText(ContentEvent e) {
         }

         // @Override
         public void promptTextIsUnsyncedWithText(ContentEvent e) {
         }
      }
   }
}

