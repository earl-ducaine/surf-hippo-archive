//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.recognizer.rubine;

import java.util.*;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.collection.*;

public class RubineClassifier 
   extends Classifier {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //private static final double EPSILON = 1E-6;   // for singular matrix check
   public  static final String DOT     = "dot";  // the name of a dot stroke

   //===   CONSTANTS   =========================================================
   //===========================================================================

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private boolean  flagTrained        = false;
   private boolean  flagConserveMemory = true;
   private Map      idealGesturePoints = new HashMap();  // maps name of gesture
                                                         // to TimedPolygon
   private String[] gestureCategoryNames;
   private String   dotCategoryName = null;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public RubineClassifier() {
      this(null);
   }

   //-----------------------------------------------------------------

   /**
    * Initializes the classifier with the given gesture set. Does not
    * automatically train.
    */
   public RubineClassifier(GestureSet gs) {
      super(gs);
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   OTHER METHODS   =====================================================

     
  /**
   * (Re)trains the current Classifier.
   * 
   * <p>If getConserveMemory() returns true, then after this method is
   * called, the following methods will return null:
   * 
   * <ul>
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#getGestureSet()}
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#classifyWithoutTraining(Gesture)}
   * </ul>
   * 
   * <p>Also, the following methods will throw NullPointerException:
   * 
   * <ul>
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#categoryDistance(GestureCategory, GestureCategory)}
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#distanceToCategory(Gesture, GestureCategory)}
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#getNormalizedDistancesByFeature(Gesture, String)}
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#getNormalizedDistancesByFeature(Gesture, GestureCategory)}
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#getTrainingCategories()}
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#findPrincipleFeature(int, int)}
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#dumpMFV(PrintStream)}
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#dump(PrintStream)}
   * <li>{@link edu.berkeley.guir.lib.gesture.Classifier#dumpRelativeVariance(PrintStream)}
   * </ul>
   */
   public synchronized void train()
      throws TrainingException, InterruptedException {
      super.train();
      
      FeatureFactory.clearCache();
      
      // Save the names and the ideal examples for the gesture categories.
      gestureCategoryNames = new String[enabledCategories.size()];
      idealGesturePoints.clear();
      
      int i = 0;
      for (Iterator iter = enabledCategories.iterator(); iter.hasNext(); i++) {
         GestureCategory gestureCategory = (GestureCategory) iter.next();
         String gestureName = gestureCategory.getName().trim();
         gestureCategoryNames[i] = gestureName;

         idealGesturePoints.put(gestureName,
                                super.getIdealGesturePoints(gestureName));

         // If the set of categories include the dot category, remember this
         if (gestureCategory == dotCategory) {
            dotCategoryName = gestureName;
         }
      }

      if (flagConserveMemory) {
         // Now that the recognizer has been trained and the ideal gesture
         // examples saved, remove the training gesture examples from memory.
         gestureSet = null;
         enabledCategories = null;
      }
      
      flagTrained = true;
   }
   
   //-----------------------------------------------------------------

/*   public TimedPolygon hackIdealGesturePoints(String gestureName) {   

      String source = gestureName.trim();
      int i = 0;
      for(; i<nameOfGesture.size(); i++)
      {
         String target = ((String)nameOfGesture.get(i)).trim();
         if(source.equals(target))
            break;
      }
      
      if(i>=nameOfGesture.size())
         return null;
      else
         return (TimedPolygon)sampleOfGesture.get(i);
   }
*/   
   public TimedPolygon getIdealGesturePoints(String gestureName) {
      String clearupString = gestureName.trim();
      return (TimedPolygon) idealGesturePoints.get(clearupString);
//      return this.hackIdealGesturePoints(gestureName);
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Gets whether to aggressively conserve memory. If true,
    * then several methods will not work properly after train() is
    * called.
    * 
    * @see #train()
    * 
    */
   public boolean getConserveMemory() {
      return flagConserveMemory;
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Sets whether to aggressively conserve memory. If set to true,
    * then several methods will not work properly after train() is
    * called.
    * 
    * @see #train()
    * 
    */
   public void setConserveMemory(boolean flag) {
      flagConserveMemory = flag;
   }
   
   //===   OTHER METHODS   =====================================================
   //===========================================================================

   
   //===========================================================================
   //===   CLASSIFICATION METHODS   ============================================

   /**
    * An internal version of classify for use with Satin.
    * I know that copying and pasting code is generally a bad practice, but
    * it will take a significant amount of work to unify and separate the two.
    */         
   protected SortedValueNumMap classify_satin(Gesture gesture) 
      throws Exception {

      //// 1. Make sure recognizer is trained.
      if (flagTrained == false) {
         flagTrained = true;
         train();
      }
      FeatureFactory.setCaching(false);

      //// This map contains the name of objects recognized
      //// as well as the raw values. The values will be scaled
      //// to percentages by the RubineRecognizer wrapper.
      SortedValueNumMap map = new SortedValueNumMap();
      map.setAscending(false);

      //// 2. Check for dot first.
      if (gesture.size() == 1) {
         if (dotCategory == null) {
            map.put(DOT, 1.0);
            return (map);
         }
         if (dotCategoryName != null) {
            map.put(dotCategoryName, 1.0);
            return (map);
         }
         map.put(DOT, 1.0);
         return (map);
      }

      //// 3. Compute discriminant.  Higher disc -> higher probability that
      ////    it's the right category.
      int    numCategories = gestureCategoryNames.length;
      double disc[]        = new double[numCategories];

      for (int catIndex = 0; catIndex < numCategories; catIndex++) {
         double sum = weights[catIndex][0];
         for (int featureNum = 0; featureNum < featureClasses.length;
                                                              featureNum++) {
            Feature feature =
               FeatureFactory.getFeature(featureClasses[featureNum], gesture);
            sum += weights[catIndex][featureNum+1] * feature.getValue();
         }
         disc[catIndex] = sum;
      }

      //// 4. Calculate accuracies.
      FeatureVector fv = new FeatureVector(gesture);
      for (int i = 0; i < numCategories; i++) {
         if (!gestureCategoryNames[i].equals(dotCategoryName)) {
            map.put(gestureCategoryNames[i], 
                MahalanobisDistance(fv.getValues(), meanFeatureValues[i]));
         }
      }

      FeatureFactory.setCaching(true);
      return map;

   } // of method

   
   //-----------------------------------------------------------------

   /**
    * @param disc          is the array of dicriminants.
    * @param j             is the entry in disc whose accuracy we want
    */
   protected double calculateAccuracy(double[] disc, int j) {
      double denom = 0;
      for (int i = 0; i < disc.length; i++) {
         // quick check to avoid computing negligible term
         double d = disc[i] - disc[j];
         if (d > -7.0) {
            denom += Math.exp(d);
         }
      }
      return (denom);
   } // of method

   //===   CLASSIFICATION METHODS   ============================================
   //===========================================================================

}

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/



