package edu.berkeley.guir.damask.command;

import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that changes the bounds of an interaction element.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-09-2003 James Lin
 *                               Created UpdateBoundsCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-09-2003
 */
public class SetBoundsCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final InteractionElement element;
   private final DeviceType deviceType;
   private final PageRegion region;
   
   private final Rectangle2D newBounds;
   private final Rectangle2D oldBounds;

   /**
    * Constructs the command.
    * 
    * @param element the element whose bounds is to be updated
    * @param newBounds the new bounds of the element
    */
   public SetBoundsCommand(
      final InteractionElement element,
      final DeviceType deviceType,
      final Rectangle2D newBounds) {
         
      this.element = element;
      this.deviceType = deviceType;
      this.region = null;
      this.newBounds = newBounds;
      oldBounds = element.getBounds(deviceType);
   }


   /**
    * Constructs the command.
    * 
    * @param group the component group whose bounds is to be updated
    * @param pageRegion the page region for which the group's bounds is
    *                    to be updated
    * @param newBounds the new bounds of the group
    */
   public SetBoundsCommand(
      final ComponentGroup group,
      final PageRegion region,
      final Rectangle2D newBounds) {
         
      this.element = group;
      this.deviceType = null;
      this.region = region;
      this.newBounds = newBounds;
      oldBounds = group.getBoundsInPageRegion(region);
   }


   // Overrides method in superclass.   
   public String getPresentationName() {
      if (element instanceof ComponentGroup) {
         final ComponentGroup group = (ComponentGroup)element;
         return "Set bounds of " + group + " in " + region + ": "
            + oldBounds + "->" + newBounds;
      }
      else {
         return "Set bounds of " + element + " for " + deviceType + ": "
            + oldBounds + "->" + newBounds;
      }
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      if (element instanceof ComponentGroup) {
         ((ComponentGroup)element).setBoundsInPageRegion(region, newBounds);
      }
      else {
         element.setBounds(deviceType, newBounds);
      }
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      if (element instanceof ComponentGroup) {
         ((ComponentGroup)element).setBoundsInPageRegion(region, oldBounds);
      }
      else {
         element.setBounds(deviceType, oldBounds);
      }
   }
}
