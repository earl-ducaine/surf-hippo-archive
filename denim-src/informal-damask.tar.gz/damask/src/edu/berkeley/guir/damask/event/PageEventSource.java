package edu.berkeley.guir.damask.event;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.dialog.Page;

/** 
 * A source of PageEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-21-2004 James Lin
 *                               Created PageEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 02-21-2004
 */
public class PageEventSource {
   
   private Vector/*<ConnectionListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified listener to receive events from a page.
    */
   public synchronized void addPageListener(final PageListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified listener so that it no longer receives
    * events from a page.
    */
   public synchronized void removePageListener(final PageListener listener) {
      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires templateAdded events to listeners.
    */
   public void fireTemplateAdded(
      final Page page,
      final Page newTemplate) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final PageEvent event =
         new PageEvent(
            page,
            PageEvent.TEMPLATE_ADDED,
            newTemplate);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final PageListener listener = (PageListener)i.next();
         listener.templateAdded(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires templateRemoved events to listeners.
    */
   public void fireTemplateRemoved(
      final Page page,
      final Page oldTemplate) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final PageEvent event =
         new PageEvent(
            page,
            PageEvent.TEMPLATE_REMOVED,
            oldTemplate);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final PageListener listener = (PageListener)i.next();
         listener.templateRemoved(event);
      }
   }
}
