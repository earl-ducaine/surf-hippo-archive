I'm going to try adding this little hierarchy at its root.
Currently I've got the "src" directory with one Java and one text file.
The "src" directory, like all directories, doesn't actually exist in the 
repository.

A line added to HEAD, without the eclipse branches visible yet.

An inserted line in eclipse-branch-2 with Tortoise.  Will conflict.

Here's an out-of-order line in eclipse-branch-2, to test the diff engine.

This line in eclipse-test-branch...
