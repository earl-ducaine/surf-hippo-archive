package edu.berkeley.guir.damask.view;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Dictionary;
import java.util.Hashtable;

import javax.swing.*;

/**
 * The zoom slider for Damask.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-19-2003 James Lin
 *                               Created ZoomSliderBar.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-19-2003
 */
public class ZoomSlider extends JSlider {

   // Constants for keystrokes
   
   // "CTRL" represents Ctrl in Windows, Command in Mac, and whatever they
   // use in Unix
   private static final KeyStroke CTRL_EQUALS =
      KeyStroke.getKeyStroke(
         '=',
         Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(),
         false);

   private static final KeyStroke CTRL_ADD =
      KeyStroke.getKeyStroke(
         KeyEvent.VK_ADD,
         Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(),
         false);

   private static final KeyStroke CTRL_HYPHEN =
      KeyStroke.getKeyStroke(
         '-',
         Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(),
         false);

   private static final KeyStroke CTRL_SUBTRACT =
      KeyStroke.getKeyStroke(
         KeyEvent.VK_SUBTRACT,
         Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(),
         false);

   // Constants for action map
   private static final String ZOOM_IN_ACTION = "zoom in";
   private static final String ZOOM_OUT_ACTION = "zoom out";

   // Fields
   private final Action zoomInAction = new ZoomInAction();
   private final Action zoomOutAction = new ZoomOutAction();
   
   
   /**
    * Constructs the zoom slider bar.
    */
   public ZoomSlider(final BoundedRangeModel sliderModel) {
      super(SwingConstants.VERTICAL);
      setModel(sliderModel);
      setSnapToTicks(true);
      setPaintTicks(true);
      setMajorTickSpacing(1);
      setInverted(true);

      // Bind shortcut keys for zooming in and out
      getActionMap().put(ZOOM_IN_ACTION, zoomInAction);
      getActionMap().put(ZOOM_OUT_ACTION, zoomOutAction);

      getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
         CTRL_EQUALS,
         ZOOM_IN_ACTION);

      getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
         CTRL_ADD,
         ZOOM_IN_ACTION);

      getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
         CTRL_HYPHEN,
         ZOOM_OUT_ACTION);
         
      getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
         CTRL_SUBTRACT,
         ZOOM_OUT_ACTION);
         
      // Create labels
      final Dictionary labelTable = new Hashtable();

      labelTable.put(
         new Integer(DamaskCanvas.SITEMAP),
         getSliderLabel("Site Map", "site_map.gif"));
      labelTable.put(
         new Integer(DamaskCanvas.PAGE),
         getSliderLabel("Page", "page.gif"));
      labelTable.put(
         new Integer(DamaskCanvas.BELOW_DETAIL),
         getSliderLabel("Detail", "detail.gif"));
      setLabelTable(labelTable);
      setPaintLabels(true);
   }
   
   /**
    * Returns a label with the specified text underneath an image with the
    * given file name.
    */
   protected JLabel getSliderLabel(final String text, final String fileName) {
      final Image image = Toolkit.getDefaultToolkit().createImage(
         DamaskApp.class.getResource("images/slider/" + fileName));
      final JLabel label = new JLabel(text);
      label.setIcon(new ImageIcon(image));
      label.setHorizontalTextPosition(SwingConstants.CENTER);
      label.setVerticalTextPosition(SwingConstants.BOTTOM);
      return label;
   }

   /**
    * An action to zoom in. 
    */
   private class ZoomInAction extends AbstractAction {
      public void actionPerformed(ActionEvent e) {
         ZoomSlider.this.setValue(ZoomSlider.this.getValue() + 1);
      }
   }

   /**
    * An action to zoom out. 
    */
   private class ZoomOutAction extends AbstractAction {
      public void actionPerformed(ActionEvent e) {
         ZoomSlider.this.setValue(ZoomSlider.this.getValue() - 1);
      }
   }
}
