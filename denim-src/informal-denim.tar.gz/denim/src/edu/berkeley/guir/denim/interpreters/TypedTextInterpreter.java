package edu.berkeley.guir.denim.interpreters;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.dialogs.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.recognizer.*;
import edu.berkeley.guir.lib.satin.recognizer.rubine.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.rubine.*;
import edu.berkeley.guir.lib.satin.stroke.*;

import java.awt.Window;
import java.awt.geom.*;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * Recognizes a typed text gesture and inserts or edits typed text in a
 * Denim design.
 *
 * <PRE>
 * Revisions:  1.0.0  03-03-2000 Will Lee (maintained by James Lin)
 *                    Created class TextInterpreter.
 *             2.0.0  10-19-2000 JL
 *                    Renamed to TypedTextInterpreter
 *             3.0.0  10-25-2001 JL
 *                    Moved most of the functionality to TypedTextHandler,
 *                    so that the code could be shared with DenimPieMenu
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version Version 3.0.0, 10-25-2001
 */
public class TypedTextInterpreter
   extends RubineInterpreter
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -7643165059746165900L;

   //===   CONSTANTS   =========================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs a text insert interpreter.
    */
   public TypedTextInterpreter() {
      super("denim_all.gsa", Denim.class, true);
      //System.out.println("...... After setting up rubine interpreter");
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Perform initializations common to all constructors.
    */
   private void commonInitializations() {
      setName("Denim TextInsert Interpreter");
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   STROKE HANDLING METHODS   ===========================================

   /**
    * Start to insert a text box in the area
    */
   public void handleSingleStroke(SingleStrokeEvent evt, Classification c) {
      GraphicalObject gob   = getAttachedGraphicalObject();
      DenimSheet      sheet = (DenimSheet) gob.getSheet();
      String          str   = (String) c.getFirstKey();
      TimedStroke     stk   = evt.getStroke();

      //// 1. If the stroke is too short, ignore
      if (stk.getLength2D(COORD_ABS) < 20) {
         Debug.println("Stroke too short");
         return;
      }

      Debug.println("key = " + str);
      if (str.startsWith("text_insert")) {
         Classifier currentClassifier = ((RubineRecognizer) getRecognizer()).getClassifier();
         DenimUtils.provideFeedback(currentClassifier, "text_insert_med",
                sheet, stk.getLocation2D(COORD_ABS));

         //// 2. We first have to check whether its tip is overlapping
         ////    other text. if so, we open a dialog box with a textArea
         ////    indicating what should be put in.

         ////    Otherwise, if the gesture is not overlapping existing text,
         ////    then we create a new panel.
         Point2D pt = pointingAt(stk);
         TypedTextHandler handler = new TypedTextHandler(
                               pt, getAttachedGraphicalObject().getSheet());
         handler.run();

         evt.setConsumed();
      }
   }

   //===   STROKE HANDLING METHODS   ===========================================
   //===========================================================================


   //===========================================================================
   //===   HELPER METHODS   ====================================================

   /**
    * Returns the point that the ^ sign is pointing
    */
   private Point2D pointingAt(TimedStroke stk) {
      Rectangle2D stkbounds = stk.getBounds2D(COORD_ABS);
      //debug.println("caret pointing at " + stkbounds.getCenterX() + "," + stkbounds.getY());
      return new Point2D.Double(stkbounds.getCenterX(), stkbounds.getY());
   }

   //===   HELPER METHODS   ====================================================
   //===========================================================================


   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      return (new TypedTextInterpreter());
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
