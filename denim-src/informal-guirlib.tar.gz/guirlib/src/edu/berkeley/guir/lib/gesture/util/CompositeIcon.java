package edu.berkeley.guir.lib.gesture.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.awt.Component;
import java.awt.Graphics;
import javax.swing.Icon;

/** Let widgets treat multiple Icons as one. */
public class CompositeIcon implements Icon
{
  List icons;
  
  public CompositeIcon()
  {
    this(new ArrayList());
  }

  public CompositeIcon(List iconList)
  {
    icons = iconList;
  }

  public void paintIcon(Component c, Graphics g, int x, int y)
  {
    for (Iterator iter = icons.iterator(); iter.hasNext();) {
      Icon icon = (Icon) iter.next();
      icon.paintIcon(c, g, x, y);
      x += icon.getIconWidth();
    }
  }

  public int getIconHeight()
  {
    int maxHeight = 0;
    for (Iterator iter = icons.iterator(); iter.hasNext();) {
      Icon icon = (Icon) iter.next();
      maxHeight = Math.max(icon.getIconHeight(), maxHeight);
    }
    return maxHeight;
  }

  public int getIconWidth()
  {
    int width = 0;
    for (Iterator iter = icons.iterator(); iter.hasNext();) {
      Icon icon = (Icon) iter.next();
      width += icon.getIconWidth();
    }
    return width;
  }

  public void add(Icon icon)
  {
    icons.add(icon);
  }

  public void clear()
  {
    icons.clear();
  }
}
