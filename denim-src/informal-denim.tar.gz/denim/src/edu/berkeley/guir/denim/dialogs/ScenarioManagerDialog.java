package edu.berkeley.guir.denim.dialogs;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FocusTraversalPolicy;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;

import edu.berkeley.guir.denim.DenimConstants;
import edu.berkeley.guir.denim.DenimScenarioEditor;
import edu.berkeley.guir.denim.DenimSheet;
import edu.berkeley.guir.denim.DenimText;
import edu.berkeley.guir.denim.DenimUI;
import edu.berkeley.guir.denim.Scenario;
import edu.berkeley.guir.denim.ScenarioNode;
import edu.berkeley.guir.lib.satin.image.SatinImageLib;
/**
 *
 * @author  Andrew Cuneo
 *
 *The biggest challenge in writing this was getting the tables to resize dynamically...
 *the best solution i could come up with was to capture an event when the window was resized,
 *and then to like wise resize my tables via 'setPreferredScrollableViewportSize' and absolute
 *coordinates, in componentResized() so if you significantly alter the look of the page, this
 *is where you should go to make it have the correct proportions 
 */

public class ScenarioManagerDialog
   extends JDialog
   implements ActionListener, ComponentListener, DenimConstants {

   //constants
   public static final int TABLE_ROW_HEIGHT = 25;

   public static final int DEFAULT_WIN_SIZE_X = 420;
   public static final int DEFAULT_WIN_SIZE_Y = 400;

   public static final int SCEN_TABLE_CORRECTION_X = 205;
   public static final int SCEN_TABLE_CORRECTION_Y = 60;

   public static final int NODE_TABLE_CORRECTION_X = 150;
   public static final int NODE_TABLE_CORRECTION_Y = 105;

   public static final int MAX_NUMBER_EDITORS = 1;

   private final String[] cols_scen = { "Scenario Name", "Time" };

   Container c;
   //set up the test data
   //let's set it all to null
   LinkedList rows_scen = new LinkedList();
   private ImageIcon[][] IA = {
   }; //should be n_scen X max_num_nodes 
   private String[][] nodeTimes = {
   }; //should be n_scen X max_num_nodes

   public DenimSheet sheet, labelSheet=new DenimSheet(new DenimUI(), false);
   
   private ScenarioManagerDialog scenManager;

   //add later 
   /*
      item = pieProject.add("Scenario Editor");
      item.addActionListener (new PieProjectScenarioEditorListener());
      item.setEnabled(true);
   */

   int selectedIndex = -1;
   int selectedNodeIndex = -1;
   LinkedList myTableItems;
   private Image[] images;
   private LinkedList rowsNode;
   private ImageIcon[][] loaded_icons;
   private boolean initialized = false;
   private ScenarioPlannerFocusPolicy SPFP;
   private ScenarioTablePanel scenPanel, nodePanel, myPanel;
   private int editorCount = 0;
   private DenimScenarioEditor editor;
   String[] NorthSouthConsts =
      { BorderLayout.NORTH, BorderLayout.CENTER, BorderLayout.SOUTH };
   String[] EastWestConsts =
      { BorderLayout.WEST, BorderLayout.CENTER, BorderLayout.EAST };
   String[] cols_node = { "Page Label", "Time" };

   /** Creates a new instance of dialouge */
   public ScenarioManagerDialog(Frame frame, DenimSheet sh) {

      super(frame, false);
      
      this.sheet = sh;
      this.scenManager = this;
      setTitle("Scenario Manager");

      //calcScenTimes();

      //start GUI Stuff...
      c = getContentPane();
      SPFP = new ScenarioPlannerFocusPolicy();

      //setup up the Panes
      JPanel centerPanel, scenarioPanel, tablePanel;
      scenarioPanel = new JPanel(new BorderLayout());
      centerPanel = new JPanel(new BorderLayout());
      tablePanel = new JPanel(new BorderLayout());
      JLabel titlePane = new JLabel(" ");
      titlePane.setFont(new Font("Arial", Font.PLAIN, 12));

      loadScenariosFromSheet();

      //set up the arrays...
      loaded_icons = new ImageIcon[sheet.getScenarios().size()][];
      
      
      scenPanel =
         new ScenarioTablePanel(
            myTableItems,
            cols_scen,
            "Scenarios",
            3,
            15,
            "Scenario",
            this);
      nodePanel =
         new ScenarioTablePanel(
            new LinkedList(),
            cols_node,
            "Pages",
            3,
            25,
            "Node",
            this);

      //set up panels
      String[] sS =
         { "Add New", "Open", "Duplicate", "Delete"};
      scenPanel.add(makeRightPanel(sS, scenPanel), BorderLayout.EAST);
      //String[] sN = new String[0];
      //nodePanel.add(makeRightPanel(sN, nodePanel), BorderLayout.EAST);
      setUpScenButtonListeners();
      turnOffScenButtons();
      enabledNodeButtons(false);
      SPFP.addComponent(scenPanel.sideButtons[0]);
      tablePanel.add(scenPanel, BorderLayout.NORTH);
      tablePanel.add(nodePanel, BorderLayout.CENTER);

      centerPanel.add(titlePane, BorderLayout.NORTH);
      centerPanel.add(tablePanel, BorderLayout.CENTER);

      scenarioPanel.add(centerPanel, BorderLayout.CENTER);
      scenarioPanel.add(new JLabel("       "), BorderLayout.WEST);
      scenarioPanel.add(new JLabel("             "), BorderLayout.EAST);

      c.add(scenarioPanel);

      // PropertyChangeListener scenPCL = scenPanel.table.getPropertyChangeListeners();

      //set up the selection model for the scenario table..
      ListSelectionModel scenRowSM = scenPanel.table.getSelectionModel();
      //scenPanel.addT

      scenRowSM.addListSelectionListener(new ListSelectionListener() {
         public void valueChanged(ListSelectionEvent e) {
            //Ignore extra messages.

            if (e.getValueIsAdjusting())
               return;

            ListSelectionModel lsm = (ListSelectionModel) e.getSource();
            rowsNode = new LinkedList();
            if (!lsm.isSelectionEmpty()) {
               int selectedRow = lsm.getMinSelectionIndex();
               if (sheet.getScenarios().size() <= 0
                  || selectedRow >= sheet.getScenarios().size()) {
                  nodePanel.mainLabel.setText("Pages");
               } else {
                  selectedIndex = lsm.getMinSelectionIndex();
                  //get the scenario for the selected row and the iterator for his nodes...                   
                  rowsNode = getNodesForDisplay((Scenario) sheet.getScenarios().get(selectedRow));
               }
               
            }
            turnOnScenButtons();
            updateTable(nodePanel, rowsNode);
         }
      });

      //set up the selection model for the node table..
      ListSelectionModel nodeRowSM = nodePanel.table.getSelectionModel();
      nodeRowSM.addListSelectionListener(new ListSelectionListener() {
         public void valueChanged(ListSelectionEvent e) {
            //Ignore extra messages.
            if (e.getValueIsAdjusting())
               return;

            ListSelectionModel lsm = (ListSelectionModel) e.getSource();
            if (lsm.isSelectionEmpty()) {
               nodePanel.STM.update(new LinkedList());
               //disable node panel buttons
               enabledNodeButtons(false);
               nodePanel.table.updateUI();
            } else {

               selectedNodeIndex = lsm.getMinSelectionIndex();
               //enable node panel buttons
               enabledNodeButtons(true);
               nodePanel.updateUI();
            }
            //update everything
            //updateTable(
         }
      });

      //window handeling stuff
      WindowHandler wh = new WindowHandler();
      addWindowListener(wh);
      setFocusTraversalPolicy(SPFP);
      addComponentListener(this);
      pack();
   }

   public void updateTable(ScenarioTablePanel panel, List data) {
      panel.STM.update((LinkedList)data);
      panel.table.updateUI();
      panel.updateUI();
      panel.revalidate();
   }

   public void loadScenariosFromSheet() {
      myTableItems = new LinkedList();
      Scenario cScen;
      Iterator it = sheet.getScenarios().iterator();

      while (it.hasNext()) {
         cScen = (Scenario) it.next();
         myTableItems.add(
            new TableItem((Object) cScen.getTitle(), cScen.getStringTime()));
      }
   }
   
   public LinkedList getNodesForDisplay(Scenario toCopy) {
      LinkedList toRet = new LinkedList();
      Iterator it = toCopy.iterator();
      //int cnt = 0;
      //boolean flag = false;
      DenimText phrase;
      ScenarioNode curSN;
      ImageIcon icon;
      while (it.hasNext()) {
         
         curSN =
            (ScenarioNode) it.next();
         phrase = curSN.getPanel().getLabel().getPhrase();
         phrase.getStyleRef().setFillColor(DENIM_SCRIBBLED_BG_COLOR);
         
         icon = new ImageIcon(SatinImageLib.toImage(phrase));        
         
         toRet.add(
               new TableItem(
                  processGraphic(icon),
                  curSN.getStringTime()));    
      }
      return toRet;
   }

   public void setUpScenButtonListeners() {
      scenPanel.sideButtons[0].addActionListener(
         new ScenarioEditorListener());
   }

   public void turnOnScenButtons() {
      for (int i = 0; i < scenPanel.sideButtons.length; i++) {
         scenPanel.sideButtons[i].setEnabled(true);
      }
   }
   
   public void enabledNodeButtons(boolean sw) {
      if(nodePanel.sideButtons != null) {
         for (int i = 0; i < nodePanel.sideButtons.length; i++) {
          nodePanel.sideButtons[i].setEnabled(sw);
         }
      }
   }

   public Scenario getNameIn(String name) {
      Scenario toRet = null, buf;
      for(Iterator i = sheet.getScenarios().iterator(); i.hasNext(); ) {
         buf = (Scenario)i.next();
         if(buf.getTitle().equals(name)) {
            toRet = buf; break;       
         }
      }
      return toRet;
   }
   
   public void turnOffScenButtons() {
      int cnt = 1;
      if (sheet.getHomePanel() == null) {
         cnt--;
      }

      for (int i = cnt; i < scenPanel.sideButtons.length; i++) {
         scenPanel.sideButtons[i].setEnabled(false);
      }

   }
   public JPanel makeRightPanel(String[] names, ScenarioTablePanel tomake) {
      JPanel buttonPanels[] = new JPanel[(names.length-1) / 4 + 1];
      JPanel buttonSubPanel;
      JPanel buttonPanelHolder = new JPanel(new BorderLayout()),
         toRet = new JPanel();

      tomake.sideButtons = new JButton[names.length];
      //run
      //tomake.sideButtons[0] = new JButton(names[0]);
      for (int i = 0; i < names.length; i++) {
         tomake.sideButtons[i] = new JButton(names[i]);
         SPFP.addComponent(tomake.sideButtons[i]);
         //tomake.sideButtons[i-1].setNextFocusableComponent(tomake.sideButtons[i]);
      }
      int k = names.length;

      for(int i = 0; i < buttonPanels.length; i++) buttonPanels[i] = new JPanel();

      //make n/4 columns of icons
      for (int i = 0; i - 1 < (int) (k-1) / 4; i++) {
         buttonPanels[i] = new JPanel(new BorderLayout());
         for (int j = 0;
            j < 2 && (2 * (i + j)) < tomake.sideButtons.length;
            j++) {
               buttonSubPanel = new JPanel(new BorderLayout());
               for(int m = 0; m < 2; m++) {
                  buttonSubPanel.add(
                  makeButtonPanel(tomake.sideButtons[2 * (i + j)+m]),
                  NorthSouthConsts[m]);
               }
               buttonPanels[(int)j/2].add(buttonSubPanel,NorthSouthConsts[j%2]);
               
         }
      }
      //will accept input of > 12, but will only display 12...
      JPanel tmp;
      for (int i = 0; i < buttonPanels.length && i < 3; i++) {
         tmp = new JPanel();
         tmp.add(buttonPanels[i]);
         buttonPanelHolder.add(tmp, EastWestConsts[i]);
      }
      toRet.add(buttonPanelHolder);
      return toRet;
   }

   public JPanel makeButtonPanel(JButton button) {
      JPanel toRet = new JPanel(new BorderLayout());
      button.addActionListener(this);
      toRet.add(button, BorderLayout.CENTER);
      toRet.add(new JLabel("   "), BorderLayout.SOUTH);

      return toRet;
   }

   /*
    *Action Listening Stuff and implementation of button functionality
    */

   public void actionPerformed(ActionEvent actionEvent) {
      /*
       * dispatch the side button clicks -- note that these 
       * also note that all of the below functions use a 
       * datamember to know which row is selected, which is why they
       * don't need any parameters
      */
      if (actionEvent.getSource() == scenPanel.sideButtons[1])
         editScenario();     
      else if (actionEvent.getSource() == scenPanel.sideButtons[3])
         removeScenario();
      else if (actionEvent.getSource() == scenPanel.sideButtons[2])
         duplicateScenario();
   }
   
   
   public void editScenario() {
      if (this.selectedIndex != -1) {
         Scenario toEdit = ((Scenario) sheet.getScenarios().get(selectedIndex)).deepClone();
         if(editorCount < MAX_NUMBER_EDITORS) {
            if(toEdit.size() > 0) {
               editor =
                     new DenimScenarioEditor(toEdit, ((ScenarioNode)toEdit.getNodes().get(0)), sheet, scenManager);
                  editor.show();
            }
         } else {
             if(editor != null) {
                editor.toFront();
                editor.show();
             } 
         }
      }
      return;
   }

   public void duplicateScenario() {
      if (this.selectedIndex != -1) {

         sheet.getScenarios().add(
            selectedIndex + 1,
            (((Scenario) sheet.getScenario(this.selectedIndex))
               .deepClone(
                  findN(
                     ((Scenario) sheet.getScenarios().get(selectedIndex))
                        .getTitle()))));

         loadScenariosFromSheet();
         scenPanel.table.getSelectionModel().setSelectionInterval(
            selectedIndex + 1,
            selectedIndex + 1);
         updateTable(scenPanel, myTableItems);
         sheet.setModified(true);
         //selectedIndex++;
      }
   }

   /*
    * note that this naming strategy is intended to make the 
    * scenarios smart duplicators, that is if duplicate scenario A
    * i'll get scenario A copy
    * and if i duplicate scenario A copy,
    * i'll get scenario A copy 1
    * not scenario A copy copy
    * the reason why i scan the list is that 
    * it seems to make more sense then adding a bunch of stuff
    * to the scenario class.
    * also, i usually expect there to be > 20 items in the list
    * so these searchs will be fast.
    * in findN, it's n as in myScenTitle copy N
   */
   public String findN(String toMatch) {
      //first we need to analyize the list of scenarios to see what
      //layer's have the same name
      //we'll do it in place  
      int m = 0;
      int index = toMatch.indexOf("copy");
      String shortTitle, curShTitle;
      if (index == -1)
         shortTitle = toMatch;
      else
         shortTitle = toMatch.substring(0, index - 1);
      int curInd;

      Iterator it = sheet.getScenarios().iterator();
      Scenario t;

      while (it.hasNext()) {
         t = (Scenario) it.next();
         curInd = t.getTitle().indexOf("copy");
         if (curInd > 0) {
            curShTitle = t.getTitle().substring(0, curInd - 1);
            if (shortTitle.equals(curShTitle))
               m = max(m, getNumber(t.getTitle()));
         }
      }

      return shortTitle + " copy " + " " + (m + 1);
   }

   int max(int a, int b) {
      if (b > a)
         return b;
      else
         return a;
   }

   /*
    * note: rewrite this function to set a limit, say a 4 digit number, and just parse backwards
    * 
    */
   int getNumber(String scenTitle) {
      int cnt = 4, toRet = 0;
      boolean found = false;
      while (cnt > 0) {
         if (Character.isDigit(scenTitle.charAt(scenTitle.length() - cnt))) {
            found = true;
            toRet =
               toRet * 10
                  + ((int) scenTitle.charAt(scenTitle.length() - cnt) - '0');
         } else if (found) {
            found = false;
            toRet = 0;
         }
         cnt--;
      }
      return toRet;
   }

   public int updateScenario(String newData, int row, int type, String owner) {
      //don't sanity check args, so that an appropriate error happens
      if (sheet != null) {
         Scenario toUpdate = (Scenario) sheet.getScenarios().get(selectedIndex);
         if (owner == "Node") {
            ScenarioNode itemTU =
               (ScenarioNode) toUpdate.getNodes().get(row);
            if (type == 1 && itemTU.setTime(newData, toUpdate)) {
               loadScenariosFromSheet();
               updateTable(scenPanel, myTableItems);
               return 0;
            } else {
               return 1;
            }
         } else {
            //type 0 == name
            if (type == 0)
               toUpdate.setTitle(newData);
            else
               return 1;
         }
      }
     // SatinConstants.cmdqueue.doCommand(new Command());
      return 0;
   }

   public void removeScenario() {
      if (this.selectedIndex != -1) {
         sheet.getScenarios().remove(selectedIndex);
         loadScenariosFromSheet();
         //clear the node table
         updateTable(nodePanel, new LinkedList());
         //update the parent table
         updateTable(scenPanel, myTableItems);
         if (selectedIndex == sheet.getScenarios().size())
            selectedIndex = -1;
         else
            updateTable(nodePanel,  getNodesForDisplay((Scenario) sheet.getScenarios().get(selectedIndex)));
         sheet.setModified(true);
      }
   }
   
   public boolean removeScenario(Scenario scen) {
      return sheet.getScenarios().remove(scen);
   }
   
   public void removeNode() {
      if (this.selectedIndex != -1 && this.selectedNodeIndex != -1) {
         Scenario toUpdate = (Scenario) sheet.getScenarios().get(selectedIndex);
         toUpdate.getNodes().remove(selectedNodeIndex);
         updateTable(nodePanel,  getNodesForDisplay((Scenario) sheet.getScenarios().get(selectedIndex)));
         sheet.setModified(true);
      }
   }

   /*
    *compenent listener interface stuff
    * note that here is the resize code 
    */
   public void componentHidden(java.awt.event.ComponentEvent componentEvent) {
   }

   public void componentMoved(java.awt.event.ComponentEvent componentEvent) {
   }

   public void componentResized(java.awt.event.ComponentEvent componentEvent) {
      if (!initialized) {
         setSize(DEFAULT_WIN_SIZE_X, DEFAULT_WIN_SIZE_Y);
         initialized = true;
      }
      int h = getHeight();
      int w = getWidth();
      scenPanel.table.setPreferredScrollableViewportSize(
         new Dimension(
            w - SCEN_TABLE_CORRECTION_X,
            h / 2 - SCEN_TABLE_CORRECTION_Y));
      scenPanel.table.updateUI();
      nodePanel.table.setPreferredScrollableViewportSize(
         new Dimension(
            w - NODE_TABLE_CORRECTION_X,
            h / 2 - NODE_TABLE_CORRECTION_Y));
      nodePanel.table.updateUI();
      validate();
      repaint();
   }

   public void componentShown(java.awt.event.ComponentEvent componentEvent) {
   }

   class WindowHandler extends WindowAdapter {
      // Handler for window closing event. 
      public void windowClosing(WindowEvent e) {
         //System.exit(0); // End the application
         
      }
   }
   
   public void decEditCount() {
      editorCount--;
      if(selectedIndex != -1) {
         updateTable(nodePanel,  getNodesForDisplay((Scenario) sheet.getScenarios().get(selectedIndex)));
         sheet.setModified(true);
      }
   }
   
   public void incEditCount() {
      editorCount++;
   }   

   public ImageIcon processGraphic(ImageIcon toScale) {
      float multiplier =
         (float) ((float) TABLE_ROW_HEIGHT / toScale.getIconHeight());
      return new ImageIcon(
         toScale.getImage().getScaledInstance(
            (int) (toScale.getIconWidth() * multiplier),
            TABLE_ROW_HEIGHT,
            Image.SCALE_SMOOTH));
   }
   /*
   class PieProjectScenarioEditorListener implements ActionListener {
      public void actionPerformed(ActionEvent evt) {
         sheet.getDenimUI().startScenarioEditor();
      }
   }
   */
   
   /**
    * NOTE: Changed method name from setScenario to more accurately describe
    * what it does.  We're going to need a method for updating existing scenarios
    * that have been edited.  -JBK
    */
   public void addScenario(Scenario toAdd) {
      /*
      Scenario toAdd = new Scenario(name);
      for (Iterator it = nodes.iterator(); it.hasNext();) {
         ScenarioNode temp = (ScenarioNode) it.next();
         toAdd.getNodes().add(temp);
      }
      */
      sheet.addScenario(toAdd);
      loadScenariosFromSheet();
       updateTable(scenPanel, myTableItems);
   }
   
   public void updateScenario(Scenario toUpdate) {
      int k;
      if((k = sheet.getScenarios().indexOf(toUpdate)) != -1)
         sheet.getScenarios().set(k, (Object)toUpdate);
      else 
      //not sure what do to here, should i supress the error or not?
         sheet.addScenario(toUpdate);
      loadScenariosFromSheet();
       updateTable(scenPanel, myTableItems);
   }

   class ScenarioEditorListener implements ActionListener {
      public void actionPerformed(ActionEvent evt) {
         if (scenManager != null) {
            if(editorCount < MAX_NUMBER_EDITORS) {
               editor =
                  new DenimScenarioEditor(sheet, scenManager);
					// hack:  make sure the DenimUI knows about this run window
					// so that GotoPanel knows what to do
               sheet.getDenimUI().setRunWindow(editor);
               editor.show();
            } else {
               if(editor!=null)editor.toFront();
            }
         }
      }
   }
}

//helper classes

/*
 * ScenarioTable.java
 *
 * Created on November 8, 2002, 2:56 AM
 */

class ScenarioTablePanel extends JPanel {
   public JTable table;
   public JButton[] sideButtons;
   public JLabel mainLabel;
   public ScenarioTableModel STM;
   public ScenarioTablePanel(
      LinkedList myScenarios,
      String[] cols,
      String Name,
      int n,
      int rh,
      String type,
      ScenarioManagerDialog parentWin) {
      mainLabel = new JLabel(Name);
      mainLabel.setFont(new Font("Arial", Font.PLAIN, 14));

      setLayout(new BorderLayout());

      add(mainLabel, BorderLayout.NORTH);
      add(
         makeMainPanel(myScenarios, cols, rh, type, parentWin),
         BorderLayout.CENTER);
   }

   public JPanel makeMainPanel(
      LinkedList rows,
      String[] cols,
      int row_height,
      String type,
      ScenarioManagerDialog parentWin) {
      JPanel toRet = new JPanel();
      STM = new ScenarioTableModel(rows, cols, type, parentWin);
      table = new JTable(STM);
      table.setRowHeight(row_height);
      table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

      table.setShowGrid(false);
      table.setShowHorizontalLines(false);
      TableColumn column = table.getColumnModel().getColumn(0);
      column.setPreferredWidth(150);

      //set up alignments
      DefaultTableCellRenderer cellR =
         (DefaultTableCellRenderer) table.getDefaultRenderer(
            cols[0].getClass());
      cellR.setHorizontalAlignment(SwingConstants.CENTER);

      JPanel tableHoldingPanel = new JPanel();
      JScrollPane tablePanel = new JScrollPane(table);
      tablePanel.getViewport().setBackground(Color.WHITE);
      tableHoldingPanel.add(tablePanel);
      toRet.add(tableHoldingPanel);
      return toRet;
   }

}

class ScenarioTableModel extends AbstractTableModel {
   private Object[][] data;
   private String[] columnNames;
   private String owner;
   private ScenarioManagerDialog parentWin;

   /** Creates a new instance of ScenarioTableModel */
   public ScenarioTableModel(
      LinkedList passedData,
      String[] passedColNames,
      String owner,
      ScenarioManagerDialog parentWin) {
      this.owner = owner;
      if (passedData == null)
         data = new Object[0][0];
      assignData(passedData, passedColNames.length);
      columnNames = passedColNames;
      this.parentWin = parentWin;
   }

   /*note the toAssign must be a linked list of scenarios*/
   public void assignData(LinkedList toAssign, int numCols) {
      data = new Object[toAssign.size()][2];
      TableItem cTableItem;
      Iterator it = toAssign.iterator();

      int i = 0;
      while (it.hasNext()) {
         cTableItem = (TableItem) it.next();
         data[i][0] = cTableItem.getData();
         data[i][1] = cTableItem.getTime();
         i++;
      }
   }

   public int getColumnCount() {
      return columnNames.length;
   }

   public int getRowCount() {
      return data.length;
   }

   public String getColumnName(int col) {
      return columnNames[col];
   }

   public Object getValueAt(int row, int col) {
      return data[row][col];
   }

   /*
    * JTable uses this method to determine the default renderer/
    * editor for each cell.  If we didn't implement this method,
    * then the last column would contain text ("true"/"false"),
    * rather than a check box.
   */
   public java.lang.Class getColumnClass(int c) {
      if (data.length == 0)
         return java.lang.String.class;
      return getValueAt(0, c).getClass();
   }

   public boolean isCellEditable(int row, int col) {
      return !(getColumnClass(col) == javax.swing.ImageIcon.class || (col == 1 && owner.equals("Scenario")));
   }

   public void update(LinkedList newData) {
      assignData(newData, columnNames.length);
   }

   public void setValueAt(Object value, int row, int col) {
     if(parentWin.updateScenario((String) value, row, col, owner) == 0) {
      data[row][col] = value;
      parentWin.sheet.setModified(true);
     }
   }  

}

class ScenarioPlannerFocusPolicy extends FocusTraversalPolicy {

   private LinkedList components;
   private ListIterator li;

   public ScenarioPlannerFocusPolicy() {
      components = new LinkedList();
   }

   /**
    * @see java.awt.FocusTraversalPolicy#getComponentAfter(java.awt.Container, java.awt.Component)
    */
   public Component getComponentAfter(Container arg0, Component arg1) {
      li = components.listIterator();
      while (li.hasNext()) {
         if (li.next().equals(arg1))
            if (li.hasNext())
               return (Component) li.next();
      }
      return null;
   }

   /**
    * @see java.awt.FocusTraversalPolicy#getComponentBefore(java.awt.Container, java.awt.Component)
    */
   public Component getComponentBefore(Container arg0, Component arg1) {
      li = components.listIterator();
      while (li.hasNext()) {
         if (li.next().equals(arg1))
            if (li.hasPrevious())
               return (Component) li.next();
      }
      return null;
   }

   /**
    * @see java.awt.FocusTraversalPolicy#getFirstComponent(java.awt.Container)
    */
   public Component getFirstComponent(Container arg0) {
      return (Component) components.get(0);
   }

   /**
    * @see java.awt.FocusTraversalPolicy#getLastComponent(java.awt.Container)
    */
   public Component getLastComponent(Container arg0) {
      return (Component) components.get(components.size() - 1);
   }

   /**
    * @see java.awt.FocusTraversalPolicy#getDefaultComponent(java.awt.Container)
    */
   public Component getDefaultComponent(Container arg0) {
      return (Component) components.get(0);
   }

   public void addComponent(Component arg0) {
      components.add(arg0);
   }

}

/*
 * this class is used to allow both the display function to use one function 
 * to display both the 2 X n table of scenario names/times and the
 * 2 x N table of imageicons/times 
 */
class TableItem {
   Object data; //either a name or an image icon
   String time;

   public TableItem(Object data, String time) {
      this.data = data;
      this.time = time;
   }

   public String getTime() {
      return time;
   }

   public Object getData() {
      return data;
   }

}

/**
 * Dialog box that asks user to insert typed text.
 *
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  05-11-1999 Benson Limketkai
 *                               Created ScenarioManagerDialog
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 04-30-1999
 */
/*
public class ScenarioManagerDialog extends JDialog {
   private JOptionPane optionPane;
   private DenimSheet  sheet;

   private static final int DEFAULT_WIDTH = 420;
   private static final int DEFAULT_HEIGHT = 200;
   private static final Debug debug = new Debug(Debug.ON);

   //------------------------------------------------------------------

   public ScenarioManagerDialog(Window win, DenimSheet sheet) {
      super();
      commonInitializations(sheet);
   }
   //------------------------------------------------------------------

   public ScenarioManagerDialog(Frame frame, DenimSheet sheet) {
      super(frame, false);
      commonInitializations(sheet);
   }

   //------------------------------------------------------------------

   private void commonInitializations(DenimSheet newSheet) {
      this.sheet = newSheet;

      setResizable(false);
      setBounds(320, 480, DEFAULT_WIDTH, DEFAULT_HEIGHT);
      setTitle("Scenario Manager");

      Set scenarioNames = sheet.getScenarioNames();


      final JList listArea = new JList(scenarioNames.toArray());
      //listArea.setBorder(BorderFactory.createLineBorder(Color.black));

      final JScrollPane areaScrollPane = new JScrollPane(listArea);
      areaScrollPane.setVerticalScrollBarPolicy
         (JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
      areaScrollPane.setHorizontalScrollBarPolicy
         (JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      areaScrollPane.setPreferredSize(new Dimension(250, 100));

      Object[] array = {"Existing Scenarios:", areaScrollPane};

      final String btnString1 = "Edit";
      final String btnString2 = "Run";
      final String btnString3 = "Delete";
      final String btnString4 = "Close";

      // removed "Edit" button
      Object[] options = {btnString2, btnString3, btnString4};

      optionPane = new JOptionPane(array,
                                   JOptionPane.PLAIN_MESSAGE,
                                   JOptionPane.YES_NO_OPTION,
                                   null,
                                   options,
                                   options[0]);
      setContentPane(optionPane);
      setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
      addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent we) {
           // * Instead of directly closing the window,
           // * we're going to change the JOptionPane's
           // * value property.
            optionPane.setValue(new Integer(JOptionPane.CLOSED_OPTION));
         }
      });


      optionPane.addPropertyChangeListener(new PropertyChangeListener() {
         public void propertyChange(PropertyChangeEvent e) {
            String prop = e.getPropertyName();

            if (isVisible()
            && (e.getSource() == optionPane)
            && (prop.equals(JOptionPane.VALUE_PROPERTY) ||
            prop.equals(JOptionPane.INPUT_VALUE_PROPERTY))) {
               Object value = optionPane.getValue();

               if (value == JOptionPane.UNINITIALIZED_VALUE) {
                  //ignore reset
                  return;
               }

               // Reset the JOptionPane's value.
               // If you don't do this, then if the user
               // presses the same button next time, no
               // property change event will be fired.
               optionPane.setValue(JOptionPane.UNINITIALIZED_VALUE);

               if (value.equals(btnString1)) { // edit
               }
               else if (value.equals(btnString2)) { // run
                  String name = (String)listArea.getSelectedValue();
                  if (name == null) {
                     return;
                  }
                  List scenario = sheet.getScenario(name);
                  JFrame frame = (JFrame)SwingUtilities.getRoot(sheet);
                  DenimRunWindow run = new DenimRunWindow("Denim",
                     (DenimPanel)scenario.get(0), true);
                  run.setScenario(scenario);
                  run.setRunScenario(true);
                  run.setVisible(true);
                  setVisible(false);
               }
               else if (value.equals(btnString3)) { // delete
                  sheet.deleteScenario((String)listArea.getSelectedValue());
                  listArea.setListData(sheet.getScenarioNames().toArray());
                  listArea.repaint();
                  areaScrollPane.validate();
               }
               else if (value.equals(btnString4)) { // cancel
                  setVisible(false);
               }
            }
         }
      });
   }
}
*/
//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
