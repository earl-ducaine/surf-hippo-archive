package edu.berkeley.guir.lib.gesture;

import java.lang.String;

/**
 * What you get if something goes wrong while training a Classifier.
 */
public class TrainingException extends Exception
{
  public TrainingException()
  {
    super();
  }

  public TrainingException(String detail)
  {
    super(detail);
  }
}
