package edu.berkeley.guir.damask.view.nodes;

import java.awt.Point;

import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.util.PAffineTransform;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * A border that resizes the node that it is attached to, and whose thickness
 * stays constant if the canvas is zoomed in or out.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-30-2003 James Lin
 *                               Created StickySizingBorder.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-29-2003
 */
public class StickySizingBorder extends SizingBorder {
   
   protected PCamera constraintCamera;
   protected PAffineTransform lastCameraTransform;


   /**
    * Creates a sizing border with the specified locator.
    */
   public StickySizingBorder(PBoundsLocator aLocator, PCamera constraintCamera) {
      super(aLocator);
      this.constraintCamera = constraintCamera;
      relocateHandle();
   }

   /**
    * Adds a border to the given node that stick to the given camera.
    */
   public static void addStickySizingBorderTo(
      PBoundsLocator locator,
      PCamera camera) {
         
      StickySizingBorder border = new StickySizingBorder(locator, camera);
      locator.getNode().addChild(border);
      StickyTransformManager.setupStickyZ(border, camera, new Point(0,0));
      border.relocateHandle(); 
   }


   /**
    * Adds borders to the given node that stick to the given camera.
    */
   public static void addStickySizingBordersTo(PNode aNode, PCamera camera) {
      StickySizingBorder[] borders = new StickySizingBorder[] { 
         new StickySizingBorder(PBoundsLocator.createEastLocator(aNode), camera),
         new StickySizingBorder(PBoundsLocator.createWestLocator(aNode), camera),
         new StickySizingBorder(PBoundsLocator.createNorthLocator(aNode), camera),
         new StickySizingBorder(PBoundsLocator.createSouthLocator(aNode), camera),
         new StickySizingBorder(PBoundsLocator.createNorthEastLocator(aNode), camera),
         new StickySizingBorder(PBoundsLocator.createNorthWestLocator(aNode), camera),
         new StickySizingBorder(PBoundsLocator.createSouthEastLocator(aNode), camera),
         new StickySizingBorder(PBoundsLocator.createSouthWestLocator(aNode), camera),
      };
      
      for (int i = 0, n = borders.length; i < n; i++) {
         final StickySizingBorder border = borders[i];
         aNode.addChild(border);
         StickyTransformManager.setupStickyZ(border, camera, new Point(0,0));
         border.relocateHandle(); 
      }
   }


   // Overrides method in superclass.
   protected double getNodeRenderedWidth() {
      final PNode node = ((PBoundsLocator)getLocator()).getNode();
      if (constraintCamera == null) {
         return node.getWidth();
      }
      else {
         final double s = constraintCamera.getViewScale();
         return node.getWidth() * s;
      }
   }

   
   // Overrides method in superclass.
   protected double getNodeRenderedHeight() {
      final PNode node = ((PBoundsLocator)getLocator()).getNode();
      if (constraintCamera == null) {
         return node.getHeight();
      }
      else {
         final double s = constraintCamera.getViewScale();
         return node.getHeight() * s;
      }
   }
}
