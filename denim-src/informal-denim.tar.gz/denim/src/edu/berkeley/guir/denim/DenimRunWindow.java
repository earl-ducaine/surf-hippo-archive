package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.dialogs.*;
import edu.berkeley.guir.lib.satin.image.SatinImageLib;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.Border;

import java.util.List;

/**
 * The window that is opened when the "Run" command in the pie menu is
 * spcified. This window contains a {@link DenimRunSheet Run sheet}.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-14-2000  William Lee
 *                                Created.
 *             1.1.0  03-07-2000  James Lin
 *                                Moved History stacks from DenimRunSheet.
 *                                Added Refresh.
 * </PRE>
 *
 * @author  William Lee</A> (
 *          <A HREF="mailto:willlee@uclink4.berkeley.edu">willlee@uclink4.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 02-14-2000
 */
public class DenimRunWindow
   extends    JFrame
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   protected DenimRunSheet runSheet;
   protected DenimSheet    sheet;
   protected JToolBar      toolbar;
   private JButton       backButton;
   private JButton       forwardButton;
   private JButton       refreshButton;
   private JButton       recordButton;
   private JButton       stopButton;

   private DenimPanel    currentPanel;
   private JPanel        labelPanel;
   private JSplitPane    splitPanel;
   private JScrollPane   scrollPane;
   private int           splitPanelDivider;
   protected Stack         prevPanels;      // stack of panels to display when
                                          //  Back is pressed
   protected Stack         nextPanels;      // stack of panels to display when
                                          //  Forward is pressed

   private List          recordedPanels;  // list of panels viewed while
                                          //  recording in Run mode

   private int           nextRecordedLabelYLoc;
   private boolean       recording;
   private boolean       runningScenario; // true when the run window is
                                          //  running the scenario
   private List          currentScenario; // list of panels of pages in the
                                          //  current scenario
   
   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs a default DenimRumWindow
    */
   public DenimRunWindow () {
      super();
   }

   /**
    * Constructs a DenimRunWindow.
    *
    * @param title          the title of the window
    * @param startingPanel  the first panel to display in the window
    */
   public DenimRunWindow(String title, DenimPanel startingPanel) {
      this(title, startingPanel, false);
   }

   /**
    * Constructs a DenimRunWindow.
    *
    * @param title          the title of the window
    * @param startingPanel  the first panel to display in the window
    */
   public DenimRunWindow(String title, DenimPanel startingPanel, boolean scenarioMode) {

      setupToolBar();
      currentPanel = startingPanel;
      recording    = false;
      prevPanels   = new Stack();
      nextPanels   = new Stack();


      // Shelley Shen -- Notice this is the first time creating runsheet
      runSheet     = new DenimRunSheet(this, startingPanel, scenarioMode);

      // set up a overall run window frame
      JPanel content = new JPanel(new BorderLayout());
//      content.add(toolbar,  BorderLayout.NORTH);

      // Shelley
      if (Denim.getDeviceInfo().getName() == DeviceType.SMARTPHONE.getName()) {
         // contentPane will contain a run sheet
         JPanel contentPane = new JPanel(new BorderLayout());

         contentPane.setPreferredSize(
            new Dimension(runSheet.getVisibleWidth(),runSheet.getVisibleHeight()));

         // customize a compound border
         Border   raisedbevel, loweredbevel, compound;
         raisedbevel = BorderFactory.createRaisedBevelBorder();
         loweredbevel = BorderFactory.createLoweredBevelBorder();
         compound = BorderFactory.createCompoundBorder(raisedbevel, loweredbevel);

         contentPane.setBorder(compound);
         contentPane.setBackground(Color.lightGray);

         contentPane.add(runSheet, BorderLayout.CENTER);

         content.add(contentPane, BorderLayout.CENTER);
         content.add(new DenimMobilePanel(runSheet), BorderLayout.SOUTH);

         pack();
         setVisible(true);

      } else {

         content.add(toolbar,  BorderLayout.NORTH);
         content.add(runSheet, BorderLayout.CENTER);
      }

      setContentPane(content);

      sheet = (DenimSheet)startingPanel.getSheet();

      // Shelley: set up the size of DenimRunWindow
      if (Denim.getDeviceInfo().getName() == DeviceType.SMARTPHONE.getName()) {
         setSize(runSheet.getVisibleWidth(),
                 runSheet.getVisibleHeight() + 240);
      } else {
         setSize(runSheet.getVisibleWidth(),
                 runSheet.getVisibleHeight() + 50);
      }

      setTitle(title);
      renderPanel(startingPanel);

      DenimRunWindowListener listenToMe = new DenimRunWindowListener();
      this.addWindowListener(listenToMe);

   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   RUN WINDOW METHODS   ================================================

   /**
    * Creates and returns the toolbar for DenimRunWindow.
    */
   private void setupToolBar() {
      toolbar = new JToolBar();

//      toolbar.repaint();

      //// 1. Set up the back button.
      backButton = new JButton("Back" , new ImageIcon
         (Denim.class.getResource("images/toolbar/back.gif")));
      backButton.addActionListener(new BackButtonAction());
      backButton.setEnabled(true);
      toolbar.add(backButton);

      //// 2. Set up the forward button.
      forwardButton = new JButton("Forward", new ImageIcon
         (Denim.class.getResource("images/toolbar/forward.gif")));
      forwardButton.addActionListener(new NextButtonAction());
      forwardButton.setEnabled(true);
      toolbar.add(forwardButton);

      //// 3. Set up the refresh button.
      refreshButton = new JButton("Refresh", new ImageIcon
         (Denim.class.getResource("images/toolbar/refresh.gif")));
      refreshButton.addActionListener(new RefreshButtonAction());
      refreshButton.setEnabled(true);
      toolbar.add(refreshButton);
      toolbar.addSeparator();

/* "Record Scenario" button commented out for minor release.  --marcr
      //// 4. Set up the record scenarios button.
      recordButton = new JButton("Record Scenario", new ImageIcon
         (Denim.class.getResource("images/toolbar/record.gif")));
      recordButton.addActionListener(new RecordButtonAction());
      recordButton.setEnabled(true);
      toolbar.add(recordButton);

      //// 5. Set up the stop recording button.
      stopButton = new JButton("Stop Recording", new ImageIcon
         (Denim.class.getResource("images/toolbar/stop_record.gif")));
      stopButton.addActionListener(new StopRecordButtonAction());
      stopButton.setEnabled(false);
*/

   } // of method

   //------------------------------------------------------------------

   /**
    * Enables or disables the toolbar buttons as appropriate.
    */
   void update() {
      backButton.setEnabled(hasPreviousPanel());
      forwardButton.setEnabled(hasNextPanel());
   } // of method

   //------------------------------------------------------------------

   /**
    * Set the mode for this RunWindow to run a scenario according to b.  This
    * means it would disable the buttons for record and hyperlink.
    * TODO: disable the hyperlink
    */
   public void setRunScenario(boolean b) {
      runningScenario = b;
      if (b) {
         toolbar.remove(recordButton);
         recordButton.setEnabled(false);
         stopButton.setEnabled(false);
         backButton.setEnabled(false);
         forwardButton.setEnabled(false);
         // disable the stack
         if (currentScenario != null) {
            // push the scenario in the forwrad stack
            Stack newforward = new Stack();
            Stack tmpstack = new Stack();
            boolean isFirst = true;
            for (Iterator it = currentScenario.iterator() ; it.hasNext() ;) {
               // don't push the first panel of the scenario on the stack
               Object tmpobj = it.next();
               if (isFirst == true) {
                  isFirst = false;
               } else {
                  tmpstack.push(tmpobj);
               }
            }
            // reverse the order
            while (!tmpstack.empty()) {
               newforward.push(tmpstack.pop());
            }
            nextPanels = newforward;
            // zero out the previous stack, if there is any
            prevPanels = new Stack();
            // see if we have reactivate the nextPanel button
            if ( hasNextPanel()) {
               forwardButton.setEnabled(true);
            }
         }
      } else {
         stopButton.setEnabled(true);
         recordButton.setEnabled(true);
         nextPanels = new Stack(); // empty the nextPanel stack
         prevPanels = new Stack(); // empty the prevPanel stack
      }
   }

   //------------------------------------------------------------------

   /**
    * Set the scenario for this run window.
    * @param scen vector that contains the denim panels
    */
   public void setScenario(List scen) {
      currentScenario = scen;
   }

   //------------------------------------------------------------------

   /**
    * Displays the given panel in the window.
    */
   public void renderPanel(DenimPanel panel) {
      currentPanel = panel;
      runSheet.renderPanel(panel);
      //panel.setActive(true);
   } // of method

   //===   RUN WINDOW METHODS   ================================================
   //===========================================================================

   public DenimPanel getPanel() {
      return currentPanel;
   }


   //===========================================================================
   //===   BROWSER METHODS   ===================================================

   /**
    * Stores the panel being displayed in the history stack.
    */
   public void pushCurrentPanel() {
      prevPanels.push(currentPanel);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Returns true if there is a panel before the current one in the
    * history stack.
    */
   public boolean hasPreviousPanel() {
      return !prevPanels.empty();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Returns true if there is a panel ahead of the current one in the
    * history stack.
    */
   public boolean hasNextPanel() {
      return !nextPanels.empty();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Goes to the previous panel in the history stack, or does nothing if
    * there isn't one.
    */
   public void gotoPreviousPanel() {
      if (!prevPanels.empty()) {
         nextPanels.push(currentPanel);
         //debug.println("new next = " + currentPanel.getUniqueID());
         currentPanel = (DenimPanel)prevPanels.pop();
         renderPanel(currentPanel);
         //debug.println("displaying = " + currentPanel.getUniqueID());
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Goes to the next panel in the history stack, or does nothing if
    * there isn't one.
    */
   public void gotoNextPanel() {
      if (!nextPanels.empty()) {
         prevPanels.push(currentPanel);
         //debug.println("new previous = " + currentPanel.getUniqueID());
         currentPanel = (DenimPanel)nextPanels.pop();
         renderPanel(currentPanel);
         //debug.println("displaying = " + currentPanel.getUniqueID());
      }
   } // of method

   //-----------------------------------------------------------------

   public DenimPanel getCurrentPanel() {
      return currentPanel;
   }

   //-----------------------------------------------------------------

   /**
    * Clears any panels ahead of the current panel in the history stack.
    */
   public void clearNextPanels() {
      nextPanels.removeAllElements();
   } // of method

   //===   BROWSER METHODS   ===================================================
   //===========================================================================



   //------------------------------------------------------------------

   /**
    * Inner classes to implement the back and next button's action
    */
   class BackButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         gotoPreviousPanel();
      }
   } // of inner class

   //------------------------------------------------------------------

   class NextButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         gotoNextPanel();
      }
   } // of inner class

   //------------------------------------------------------------------

   class RefreshButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
    	 DenimRunWindow.this.runSheet.reset();
         renderPanel(DenimRunWindow.this.currentPanel);
      }
   } // of inner class


   //------------------------------------------------------------------

   class RecordButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         labelPanel        = new JPanel(null);
         recording         = true;
         splitPanelDivider = 0;

         toolbar.remove(recordButton);
         recordButton.setEnabled(false);
         refreshButton.setEnabled(false);
         stopButton.setEnabled(true);
         toolbar.add(stopButton);
         toolbar.repaint();

         JPanel contentPane = (JPanel)getContentPane();
         contentPane.remove(runSheet);
         labelPanel.setBackground(new Color(255,255,255));
         scrollPane = new JScrollPane(labelPanel);
         //scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
//         splitPanel = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, labelPanel, runSheet);
         splitPanel = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane, runSheet);
         splitPanel.setContinuousLayout(true);
         splitPanel.setOneTouchExpandable(false);
         recordPanel(currentPanel, true);
         contentPane.add(splitPanel, BorderLayout.CENTER);
         setContentPane(contentPane);
         labelPanel.repaint();
      }
   } // of inner class

   public void recordPanel(DenimPanel p, boolean restart) {
      if (restart) {
         nextRecordedLabelYLoc = 0;
         recordedPanels = new ArrayList();
      }

      recordedPanels.add(p);
      // position label
      DenimText phrase = p.getLabel().getPhrase();
      phrase.getStyleRef().setFillColor(Color.white);
      BufferedImage img = SatinImageLib.toImage(phrase);
      Icon icon = new ImageIcon(img);
      JLabel label = new JLabel();
      label.setIcon(icon);
      label.setBounds(0, 0, img.getWidth(null), img.getHeight(null));
      labelPanel.add(label);
      label.setLocation(0, nextRecordedLabelYLoc);
      nextRecordedLabelYLoc = nextRecordedLabelYLoc + (int)label.getSize().getHeight();

      // re-position split panel divider after resizing frame
      splitPanelDivider = (int)Math.max(splitPanelDivider, label.getSize().getWidth());
      setBounds(getX(), getY(), splitPanelDivider+runSheet.getVisibleWidth(), getHeight());
      validate();
      splitPanel.setDividerLocation(splitPanelDivider);
      splitPanel.setOneTouchExpandable(false);

      labelPanel.repaint();
      labelPanel.validate();
      scrollPane.validate();
   }

   //------------------------------------------------------------------

   class StopRecordButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent evt) {
         recording = false;
         toolbar.remove(stopButton);
         stopButton.setEnabled(false);
         refreshButton.setEnabled(true);
         recordButton.setEnabled(true);
         toolbar.add(recordButton);
         toolbar.repaint();

         SaveScenarioDialog saveDlg =
            new SaveScenarioDialog(DenimRunWindow.this, sheet);
         saveDlg.setVisible(true);
         sheet.setScenario(saveDlg.getText(), recordedPanels);

         JPanel contentPane = (JPanel)getContentPane();
         contentPane.remove(splitPanel);
         contentPane.add(runSheet, BorderLayout.CENTER);
         setContentPane(contentPane);
         setBounds(getX(), getY(), runSheet.getVisibleWidth(), getHeight());
      }
   } // of inner class

   //------------------------------------------------------------------

   public boolean isRecording() {
      return recording;
   }

   //------------------------------------------------------------------

   public JPanel getLabelPanel() {
      return labelPanel;
   }

   //===   RUN WINDOW METHODS   ================================================
   //===========================================================================

   class DenimRunWindowListener implements WindowListener {

      public DenimRunWindowListener() {
      }

      public void windowClosing(WindowEvent e) {
         DenimRunWindow.this.getPanel().setActive(false);
      }

      public void windowClosed(WindowEvent e) {
         DenimRunWindow.this.getPanel().setActive(false);
      }

      public void windowOpened(WindowEvent e) {
         DenimRunWindow.this.getPanel().setActive(true);
      }

      public void windowIconified(WindowEvent e) {
         DenimRunWindow.this.getPanel().setActive(false);
      }

      public void windowDeiconified(WindowEvent e) {
         DenimRunWindow.this.getPanel().setActive(true);
      }

      public void windowActivated(WindowEvent e) {
         DenimRunWindow.this.getPanel().setActive(true);
      }

      public void windowDeactivated(WindowEvent e) {
         DenimRunWindow.this.getPanel().setActive(false);
      }
   }// of class


}// of DenimRunWindow Class
//==============================================================================

/*
Copyright (c) 2000-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
