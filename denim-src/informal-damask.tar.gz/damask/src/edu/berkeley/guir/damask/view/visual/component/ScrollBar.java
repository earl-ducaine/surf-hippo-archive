package edu.berkeley.guir.damask.view.visual.component;

import java.awt.Color;
import java.awt.geom.*;
import java.util.Iterator;

import edu.berkeley.guir.damask.view.DamaskCanvas;
import edu.umd.cs.piccolo.event.*;
import edu.umd.cs.piccolo.nodes.PPath;


/**
 * A scroll bar for a list box.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-03-2004 James Lin
 *                               Created ScrollBar.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 02-03-2004
 */
class ScrollBar extends PPath {
   public static int WIDTH = 20;
   protected static int BUTTON_SIZE = WIDTH;
   protected static int SHAFT_JUMP = 5;
   
   private final UpButton upButton = new UpButton();
   private final DownButton downButton = new DownButton();
   private final Elevator elevator = new Elevator();
   private final ListBox listBox;
   
   private boolean inRunMode = false;
   private final PInputEventListener runModeEventHandler =
      new RunModeEventHandler();
      
   private boolean shaftHasFocus = false;

   
   public ScrollBar(final ListBox listBox) {
      setStrokePaint(Color.BLACK);
      setPaint(Color.LIGHT_GRAY);
      
      this.listBox = listBox;

      addChild(upButton);
      addChild(downButton);
      addChild(elevator);
   }

   /**
    * Returns the associated list box.
    */
   public ListBox getListBox() {
      return listBox;
   }

   /**
    * Enables or disables the event listeners for Run mode.
    */
   public void setInRunMode(boolean flag) {
      inRunMode = flag;
      upButton.setInRunMode(flag);
      downButton.setInRunMode(flag);
      elevator.setInRunMode(flag);
      if (inRunMode) {
         addInputEventListener(runModeEventHandler);
      }
      else {
         removeInputEventListener(runModeEventHandler);
      }
   }

   
   /**
    * Returns the up button.
    */
   protected UpButton getUpButton() {
      return upButton;
   }

   
   /**
    * Returns the down button.
    */
   protected DownButton getDownButton() {
      return downButton;
   }

   
   /**
    * Returns the elevator.
    */
   protected Elevator getElevator() {
      return elevator;
   }


   /**
    * Returns the height of the shaft in which the elevator slides.
    */
   protected double getShaftHeight() {
      return getHeight() - (2 * BUTTON_SIZE);
   }


   /**
    * The event handler for a list box in Run mode.
    */
   private static class RunModeEventHandler extends PBasicInputEventHandler {
      private int numScrollLines;
      
      public void mousePressed(PInputEvent event) {
         if (event.getPickedNode() instanceof ScrollBar) {
            final ScrollBar scrollBar = (ScrollBar)event.getPickedNode();
            final Point2D position = event.getPositionRelativeTo(scrollBar);
            
            final Rectangle2D elevatorBounds = scrollBar.elevator.getBounds();
            scrollBar.elevator.localToGlobal(elevatorBounds);
            scrollBar.globalToLocal(elevatorBounds);
            
            if (position.getY() < elevatorBounds.getY()) {
               numScrollLines = SHAFT_JUMP;
            }
            else {
               numScrollLines = -SHAFT_JUMP;
            }
            scrollBar.getListBox().doScrollActivity(numScrollLines);
            scrollBar.shaftHasFocus = true;
         }
      }
      
      public void mouseReleased(PInputEvent event) {
         if (event.getPickedNode() instanceof ScrollBar) {
            final ScrollBar scrollBar = (ScrollBar)event.getPickedNode();
            scrollBar.getListBox().doScrollActivity(0);
            scrollBar.shaftHasFocus = false;
         }
      }

      public void mouseEntered(PInputEvent event) {
         if (event.getPickedNode() instanceof ScrollBar) {
            final ScrollBar scrollBar = (ScrollBar)event.getPickedNode();
            if (scrollBar.shaftHasFocus) {
               scrollBar.getListBox().doScrollActivity(numScrollLines);
            }
         }
      }
      
      public void mouseExited(PInputEvent event) {
         if (event.getPickedNode() instanceof ScrollBar) {
            final ScrollBar scrollBar = (ScrollBar)event.getPickedNode();
            if (scrollBar.shaftHasFocus) {
               scrollBar.getListBox().doScrollActivity(0);
            }
         }
      }
   }
   
   
   /**
    * The up arrow button in the scroll bar. 
    */
   protected static class UpButton extends PPath {
      private final PPath upArrow;
      private final PInputEventListener runModeEventHandler =
         new RunModeEventHandler();
      private boolean hasFocus = false;

      public UpButton() {
         setPathTo(new Rectangle2D.Double(0, 0, BUTTON_SIZE, BUTTON_SIZE));
         setPaint(Color.WHITE);
      
         final GeneralPath upArrowPath = new GeneralPath();
         upArrowPath.moveTo(BUTTON_SIZE / 2, 0);
         upArrowPath.lineTo(BUTTON_SIZE - 5, BUTTON_SIZE / 3);
         upArrowPath.lineTo(5, BUTTON_SIZE / 3);
         upArrowPath.closePath();
         
         upArrow = new PPath(upArrowPath);
         upArrow.setPaint(Color.BLACK);
         upArrow.setPickable(false);
      
         addChild(upArrow);
         upArrow.setOffset(0, BUTTON_SIZE / 3);
      }

      /**
       * Returns the associated scroll bar.
       */
      public ScrollBar getScrollBar() {
         return (ScrollBar)getParent();
      }

      /**
       * Enables or disables the event handler for run mode.
       */
      public void setInRunMode(final boolean inRunMode) {
         if (inRunMode) {
            addInputEventListener(runModeEventHandler);
         }
         else {
            removeInputEventListener(runModeEventHandler);
         }
      }

      /**
       * Sets whether this button is active.
       */      
      public void setActive(final boolean flag) {
         if (flag) {
            setPaint(Color.BLACK);
            upArrow.setStrokePaint(Color.WHITE);
            upArrow.setPaint(Color.WHITE);
            getScrollBar().getListBox().doScrollActivity(1);
         }
         else {
            setPaint(Color.WHITE);
            upArrow.setStrokePaint(Color.BLACK);
            upArrow.setPaint(Color.BLACK);
            getScrollBar().getListBox().doScrollActivity(0);
         }
      }

      /**
       * The event handler for a scroll box up arrow in Run mode.
       */
      private static class RunModeEventHandler extends PBasicInputEventHandler {
         public void mousePressed(PInputEvent event) {
            final UpButton upButton = (UpButton)event.getPickedNode();
            upButton.setActive(true);
            upButton.hasFocus = true;
         }
      
         public void mouseReleased(PInputEvent event) {
            final UpButton upButton = (UpButton)event.getPickedNode();
            upButton.setActive(false);
            upButton.hasFocus = false;
            if (event.getComponent() instanceof DamaskCanvas) {
               // Tell the models of the list box items that their transforms
               // have changed.
               final ListBox listBox = upButton.getScrollBar().getListBox();
               listBox.setItemModelsTransforms(); 
            }
         }

         public void mouseEntered(PInputEvent event) {
            final UpButton upButton = (UpButton)event.getPickedNode();
            if (upButton.hasFocus) {
               upButton.setActive(true);
            }
         }
      
         public void mouseExited(PInputEvent event) {
            final UpButton upButton = (UpButton)event.getPickedNode();
            if (upButton.hasFocus) {
               upButton.setActive(false);
            }
         }
      }
   }
   
   
   /**
    * The down arrow button in the scroll bar. 
    */
   protected static class DownButton extends PPath {
      private final PPath downArrow;
      private final PInputEventListener runModeEventHandler =
         new RunModeEventHandler();
      private boolean hasFocus = false;

      public DownButton() {
         setPathTo(new Rectangle2D.Double(0, 0, BUTTON_SIZE, BUTTON_SIZE));
         setPaint(Color.WHITE);

         final GeneralPath downArrowPath = new GeneralPath();
         downArrowPath.moveTo(BUTTON_SIZE / 2, BUTTON_SIZE / 3);
         downArrowPath.lineTo(BUTTON_SIZE - 5, 0);
         downArrowPath.lineTo(5, 0);
         downArrowPath.closePath();
         
         downArrow = new PPath(downArrowPath);
         downArrow.setPaint(Color.BLACK);
         downArrow.setPickable(false);
      
         addChild(downArrow);
         downArrow.setOffset(0, BUTTON_SIZE / 3);
      }

      /**
       * Returns the associated scroll bar.
       */
      public ScrollBar getScrollBar() {
         return (ScrollBar)getParent();
      }

      /**
       * Enables or disables the event handler for run mode.
       */
      public void setInRunMode(final boolean inRunMode) {
         if (inRunMode) {
            addInputEventListener(runModeEventHandler);
         }
         else {
            removeInputEventListener(runModeEventHandler);
         }
      }

      /**
       * Sets whether this button is active.
       */      
      public void setActive(final boolean flag) {
         if (flag) {
            setPaint(Color.BLACK);
            downArrow.setStrokePaint(Color.WHITE);
            downArrow.setPaint(Color.WHITE);
            getScrollBar().getListBox().doScrollActivity(-1);
         }
         else {
            setPaint(Color.WHITE);
            downArrow.setStrokePaint(Color.BLACK);
            downArrow.setPaint(Color.BLACK);
            getScrollBar().getListBox().doScrollActivity(0);
         }
      }

      /**
       * The event handler for a scroll box down arrow in Run mode.
       */
      private static class RunModeEventHandler extends PBasicInputEventHandler {
         public void mousePressed(PInputEvent event) {
            final DownButton downButton = (DownButton)event.getPickedNode();
            downButton.setActive(true);
            downButton.hasFocus = true;
         }
      
         public void mouseReleased(PInputEvent event) {
            final DownButton downButton = (DownButton)event.getPickedNode();
            downButton.setActive(false);
            downButton.hasFocus = false;
            if (event.getComponent() instanceof DamaskCanvas) {
               // Tell the models of the list box items that their transforms
               // have changed.
               final ListBox listBox = downButton.getScrollBar().getListBox();
               listBox.setItemModelsTransforms(); 
            }
         }

         public void mouseEntered(PInputEvent event) {
            final DownButton downButton = (DownButton)event.getPickedNode();
            if (downButton.hasFocus) {
               downButton.setActive(true);
            }
         }
      
         public void mouseExited(PInputEvent event) {
            final DownButton downButton = (DownButton)event.getPickedNode();
            if (downButton.hasFocus) {
               downButton.setActive(false);
            }
         }
      }
   }
   
   
   /**
    * The elevator (i.e., scroll box, scroller) in the scroll bar. 
    */
   protected static class Elevator extends PPath {
      private final PInputEventListener runModeEventHandler =
         new RunModeEventHandler();

      public static final int MIN_HEIGHT = 4;
      private static final int MIN_HEIGHT_WITH_GRIP_LINES = 13;
      private static final int GRIP_LINES_GAP = 3;
      private boolean focus = false;
      
      public Elevator() {
         setStrokePaint(Color.BLACK);
         setPaint(Color.WHITE);

         // Add grip lines         
         for (int i = -1; i <= 1; i++) {
            final PPath gripLine = new PPath();
            gripLine.setPickable(false);
            addChild(gripLine);
         }
      }

      /**
       * Returns the associated scroll bar.
       */
      public ScrollBar getScrollBar() {
         return (ScrollBar)getParent();
      }

      // Overrides method in superclass.
      protected void layoutChildren() {
         // Position grip lines
         final Iterator it = getChildrenIterator();
         for (int i = -1; i <= 1; i++) {
            final PPath grip = (PPath)it.next();
            grip.setPathTo(
               new Line2D.Double(
                  WIDTH / 3,
                  (getHeight() / 2) + (i * GRIP_LINES_GAP),
                  WIDTH * 2 / 3,
                  (getHeight() / 2) + (i * GRIP_LINES_GAP)));
            grip.setVisible(getHeight() >= MIN_HEIGHT_WITH_GRIP_LINES);
         }
      }

      public void setInRunMode(boolean inRunMode) {
         if (inRunMode) {
            addInputEventListener(runModeEventHandler);
         }
         else {
            removeInputEventListener(runModeEventHandler);
         }
      }

      public boolean hasFocus() {
         return focus;
      }

      /**
       * The event handler for the elevator in Run mode.
       */
      private static class RunModeEventHandler extends PBasicInputEventHandler {
         private Point2D lastPosition;
         private Point2D lastScrollPosition;
         
         private double dyToScroll1Line;

         public void mousePressed(PInputEvent event) {
            final Elevator elevator = (Elevator)event.getPickedNode();
            final ScrollBar scrollBar = elevator.getScrollBar();

            elevator.focus = true;

            final double childrenHeight =
               scrollBar.getListBox().getLastItemMaxY()
                  - scrollBar.getListBox().getFirstItemMinY();

            dyToScroll1Line =
               scrollBar.getShaftHeight()
                  * ListBox.DEFAULT_LINE_HEIGHT / childrenHeight;

            lastPosition = event.getPosition();
            lastScrollPosition = event.getPosition();
         }
      
         public void mouseDragged(PInputEvent event) {
            final Elevator elevator = ((Elevator)event.getPickedNode());
            final Point2D currentPosition = event.getPosition();

            final double dySinceLastScroll =
               lastScrollPosition.getY() - currentPosition.getY();
            if (Math.abs(dySinceLastScroll) >= dyToScroll1Line) {
               final int dLines = (int) (dySinceLastScroll / dyToScroll1Line);
               elevator.getScrollBar().getListBox().scrollItems(dLines);
               lastScrollPosition = currentPosition;
            }
            lastPosition = event.getPosition();
         }
      
         public void mouseReleased(PInputEvent event) {
            final Elevator elevator = ((Elevator)event.getPickedNode());
            elevator.focus = false;
         }
      }
   }
}