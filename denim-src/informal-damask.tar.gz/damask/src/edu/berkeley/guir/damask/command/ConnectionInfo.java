package edu.berkeley.guir.damask.command;

import java.awt.geom.GeneralPath;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.connection.*;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.userevent.DamaskUserEvent;

/**
 * Stores information about a connection, to be later used in undo.
 */
class ConnectionInfo {
   private final DeviceType deviceType;
   private final boolean forAllDevices;
   private final ConnectionSource source;
   private final ConnectionDest dest;
   private final Map/*<DeviceType, GeneralPath>*/ shapes = new HashMap();
   private final DamaskUserEvent userEvent;
   private final int condition;
      
   public ConnectionInfo(final Connection connection) {
      this.deviceType = connection.getOrigSpecifiedDeviceType();
      this.forAllDevices = connection.isForAllDeviceTypes();
      this.source = connection.getConnectionSource(deviceType);
      this.dest = connection.getConnectionDest(deviceType);
      for (Iterator i = connection.getDeviceTypesVisibleTo().iterator();
         i.hasNext(); ) {
         
         final DeviceType deviceType = (DeviceType)i.next();
         shapes.put(deviceType, connection.getShape(deviceType));
      }
      if (connection instanceof NavConnection) {
         final NavConnection navConnection = (NavConnection)connection;
         this.userEvent = navConnection.getUserEvent();
         this.condition = navConnection.getCondition();
      }
      else {
         this.userEvent = null;
         this.condition = -1;
      }
   }
   
   
   /**
    * Given a collection of Connections, returns a set of 
    * corresponding ConnectionInfos.
    */
   public static Set createSet(final Collection/*<Connection>*/ connections) {
      final Set connectionInfos = new HashSet();
      for (Iterator i = connections.iterator(); i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         connectionInfos.add(new ConnectionInfo(connection));
      }
      return connectionInfos;
   }

   
   public DeviceType getSpecifiedDeviceType() {
      return deviceType;
   }


   public boolean isForAllDevices() {
      return forAllDevices;
   }


   public GeneralPath getShape(final DeviceType deviceType) {
      return (GeneralPath)shapes.get(deviceType);
   }


   public ConnectionSource getSourceForSpecifiedDeviceType() {
      return source;
   }


   public DamaskUserEvent getUserEvent() {
      return userEvent;
   }


   public int getCondition() {
      return condition;
   }


   public ConnectionDest getDestForSpecifiedDeviceType() {
      return dest;
   }
   
   public boolean isNav() {
      return (userEvent != null) && (condition != -1);
   }
   
   
   public Connection createConnection() {
      final Connection newConnection;
      if (condition == -1) {
         newConnection = new OrgConnection(
            deviceType,
            forAllDevices,
            (Page)source,
            (Page)dest,
            (GeneralPath)shapes.get(deviceType));
      }
      else {
         newConnection = new NavConnection(
            deviceType,
            forAllDevices,
            (Control)source,
            userEvent,
            condition,
            dest,
            (GeneralPath)shapes.get(deviceType));
      }
      if (forAllDevices) {
         for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
            i.hasNext(); ) {
               
            final DeviceType aDeviceType = (DeviceType)i.next();
            newConnection.setShape(
               aDeviceType,
               (GeneralPath)shapes.get(deviceType));
         }
      }
      return newConnection;
   }
   
   /**
    * Finds a connection with the same info as this info in the specified
    * interaction graph.
    */
   public Connection findConnection(final InteractionGraph graph) {
      Connection result = null;
      final Collection/*<Connection>*/ connections = graph.getConnections();
      for (Iterator i = connections.iterator(); i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         boolean match =
            (connection.getOrigSpecifiedDeviceType() == deviceType) &&
            (connection.isForAllDeviceTypes() == forAllDevices) &&
            (connection.getConnectionSource(deviceType) == source) &&
            (connection.getConnectionDest(deviceType) == dest);
         if (connection instanceof OrgConnection) {
            match &= (userEvent == null) && (condition == -1);
         }
         else {
            match
               &= ((NavConnection)connection).getUserEvent().matches(userEvent)
               && (((NavConnection)connection).getCondition() == condition);
         }
         if (match) {
            result = connection;
            break;
         }
      }
      return result;
   }
}
