package edu.berkeley.guir.lib.gesture;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import edu.berkeley.guir.lib.gesture.util.FlowScrollPanel;

/**
 * Displays the elements (i.e. GestureCategories) of a GestureSet.
 * Emits an ItemEvent when a Category is (de)selected.
 */
public class GestureSetDisplay extends FlowScrollPanel
implements Observer, ItemSelectable
{
  private GestureSet gestureSet;
  private GestureCategoryThumbnail selectedCategoryThumbnail;
  protected EventListenerList itemListenerList = new EventListenerList();
  int maxChildHeight = 0;
  boolean experimentMode;
  boolean authorsVisible = false;

  public GestureSetDisplay(GestureSet gs)
  {
    this(gs, false);
  }
  
  public GestureSetDisplay(boolean experimenting)
  {
    this(new GestureSet(), experimenting);
  }

  public GestureSetDisplay(GestureSet gs, boolean experimenting)
  {
    super();
    experimentMode = experimenting;
    setGestureSet(gs);
    initUI();
  }

  public void setGestureSet(GestureSet gs)
  {
    if (gestureSet != null) {
      gestureSet.deleteObserver(this);
    }
    gestureSet = gs;
    if (gs != null) {
      gs.addObserver(this);
    }
    rebuildUI();
    repaint();
  }

  public GestureSet getGestureSet()
  {
    return gestureSet;
  }

  /**
   * Note: assumes that our only children are GestureCategoryThumbnails
   */
  public GestureCategoryThumbnail getGestureCategoryThumbnail(int gcIndex)
  {
    return (GestureCategoryThumbnail) (getComponents()[gcIndex]);
  }
  
  boolean isDisplayed(GestureCategory gc)
  {
    boolean found = false;
    
    Component[] components = getComponents();
    for (int i = 0; (i < components.length) && !found; i++) {
      JComponent c = (JComponent) components[i];
      if (c instanceof GestureCategoryThumbnail) {
	GestureCategoryThumbnail gct = (GestureCategoryThumbnail) c;
	if (gct.getGestureCategory() == gc)
	  found = true;
      }
    }
    return found;
  }
  
  /**
   * Normally, o is a GestureSet and arg is the GestureCategory that changed
   */
  public void update(Observable o, Object arg)
  {
    if ((arg != null) && (arg instanceof GestureCategory)) {
      GestureSet gs = (GestureSet) o;
      GestureCategory gc = (GestureCategory) arg;
      if (!isDisplayed(gc))
	addGestureCategory(gc);
    }
    else if ((arg != null) && (arg instanceof String)) {
      // don't need to do anything for name or author changes
    }
    else {
      // something more drastic happened
      rebuildUI();

      // deselect selectedCategoryThumbnail, if there is one
      if (!isAncestorOf(selectedCategoryThumbnail)) {
	GestureCategoryThumbnail oldSelection = selectedCategoryThumbnail;
	selectedCategoryThumbnail = null;
	fireItemChange(ItemEvent.ITEM_STATE_CHANGED,
		       oldSelection, ItemEvent.DESELECTED);
      }
    }
  }

  public void addGestureCategory(GestureCategory gestureCategory)
  {
    addGestureCategory(gestureCategory, false);
  }

  /**
   * Add a new GestureCategory to the GestureSet, and bring up its
   * corresponding GestureCategoryFrame if showFrame is true.
   */
  public void addGestureCategory(GestureCategory gestureCategory,
				 boolean showFrame)
  {
    GestureCategoryThumbnail gct =
      new GestureCategoryThumbnail(gestureCategory, experimentMode,
				   authorsVisible);

    //gct.setBorder(BorderFactory.createEtchedBorder());
    if (showFrame)
      gct.showCategoryFrame();

    regularizeChildSizes(gct);

    gct.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e)
      {
	GestureCategoryThumbnail gestureCategoryThumbnail =
	  (GestureCategoryThumbnail) e.getSource();
	regularizeChildSizes(gestureCategoryThumbnail);
      }
    });
    
    add(gct);
    revalidate();
    pack();
  }

  void regularizeChildSizes(GestureCategoryThumbnail gct)
  {
    boolean changed = false;
    
    int newHeight = gct.getMinimumSize().height;
    if (newHeight > maxChildHeight) {
      // make all children this new height
      Component[] components = getComponents();
      for (int i = 0; i < components.length; i++) {
	JComponent c = (JComponent) components[i];
	int oldWidth = c.getMinimumSize().width;
	c.setPreferredSize(new Dimension(oldWidth, newHeight));
      }
      maxChildHeight = newHeight;
      changed = true;
    }
    else if (newHeight < maxChildHeight) {
      gct.setPreferredSize(new Dimension(gct.getMinimumSize().width,
					 maxChildHeight));
      changed = true;
    }

    if (changed) {
      revalidate();
      pack();
    }
  }
       
  /**
   * Convenience method
   */
  void pack()
  {
    Window w = (Window) getTopLevelAncestor();
    if (w != null)
      w.pack();
  }
  
  protected void initUI()
  {
    setBackground(Color.white);
    setMinimumSize(new Dimension(10,10));
    addMouseListener(new MouseHandler());
    /*
    FullFlowLayout layout = new FullFlowLayout();
    setLayout(layout);
    */
    ((FlowLayout) getLayout()).setHgap(0);
  }

  void rebuildUI()
  {
    removeAll();

    maxChildHeight = 0;
    for (Iterator iter = gestureSet.iterator(); iter.hasNext();) {
      GestureCategory gestureCategory =
	(GestureCategory) iter.next();
      addGestureCategory(gestureCategory);
    }
    repaint();
  }

  public boolean isOpaque()
  {
    return true;
  }

  /**
   * Return the GestureCategoryThumbnail corresponding to the
   * current selection (or null if there isn't one).
   */
  public GestureCategoryThumbnail getSelectionDisplay()
  {
    return selectedCategoryThumbnail;
  }

  /**
   * Return the currently selected GestureCategory (or null if there
   * isn't one).
   */
  public GestureCategory getSelection()
  {
    return (selectedCategoryThumbnail == null) ? (null) :
      selectedCategoryThumbnail.getGestureCategory();
  }

  /**
   * This component does tile its children
   */
  public boolean isOptimizedDrawingEnabled()
  {
    return true;
  }
  
  /**
   * Current mouse behavior: button 1 selects, button 2 brings up
   * the appropriate GestureCategoryFrame
   */
  class MouseHandler extends MouseAdapter
  {
    /**
     * This works around a bug in AWT that causes the modifiers to sometimes
     * be 0, not BUTTON1_MASK, when mouse button 1 is pressed.
     */
    boolean mouse1(MouseEvent e)
    {
      int mods = e.getModifiers();
      return (mods == 0) || ((mods & InputEvent.BUTTON1_MASK) != 0);
    }
    
    public void mousePressed(MouseEvent e)
    {
      Point p = new Point(e.getPoint());
      
      Component component = getComponentAt(p);
      if ((component != null) &&
	  (component instanceof GestureCategoryThumbnail)) {
	GestureCategoryThumbnail newSelection =
	  (GestureCategoryThumbnail) component;
	if (mouse1(e)) {
	  // button 1 = selection
	  if (selectedCategoryThumbnail == newSelection)
	    setSelection(null);
	  else
	    setSelection(newSelection);
	}
	else if ((e.getModifiers() & InputEvent.BUTTON3_MASK) != 0) {
	  // button 3 = open
	  newSelection.showCategoryFrame();
	}
      }
    }
  }

  public void setSelection(GestureCategoryThumbnail newSelection)
  {
    GestureCategoryThumbnail oldSelection =
      selectedCategoryThumbnail;
    if (newSelection != oldSelection) {
      selectedCategoryThumbnail = newSelection;
      if (oldSelection != null) {
	oldSelection.setSelected(false);
	fireItemChange(ItemEvent.ITEM_STATE_CHANGED,
		       oldSelection, ItemEvent.DESELECTED);
      }
      if (selectedCategoryThumbnail != null) {
	selectedCategoryThumbnail.setSelected(true);
	fireItemChange(ItemEvent.ITEM_STATE_CHANGED,
		       selectedCategoryThumbnail, ItemEvent.SELECTED);
      }
    }
  }
  
  /**
   * Returns an array of selected GestureCategoryThumbnails or null if none
   * are selected.  Currently, this array will have one element.
   */
  public Object[] getSelectedObjects()
  {
    Object[] result = {selectedCategoryThumbnail};
    
    if (selectedCategoryThumbnail == null)
      result = null;

    return result;
  }

  public void addItemListener(ItemListener l)
  {
    itemListenerList.add(ItemListener.class, l);
  }

  public void removeItemListener(ItemListener l)
  {
    itemListenerList.remove(ItemListener.class, l);
  }

  protected void fireItemChange(int type, GestureCategoryThumbnail item,
				int selectState)
  {
    ItemEvent event = null;
    Object[] listeners = itemListenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ItemListener.class) {
	if (event == null)
	  event = new ItemEvent(this, type, item, selectState);
	((ItemListener)listeners[i+1]).itemStateChanged(event);
      }
    }
  }

  /**
   * Create, display, and raise the corresponding GestureCategoryFrame
   */
  public GestureCategoryFrame showCategoryFrame(GestureCategory category)
  {
    Component[] components = getComponents();
    boolean done = false;
    GestureCategoryFrame result = null;

    for (int i = 0; (i < components.length) && !done; i++) {
      if (components[i] instanceof GestureCategoryThumbnail) {
	GestureCategoryThumbnail gct = (GestureCategoryThumbnail)
	  components[i];
	if (gct.getGestureCategory() == category) {
	  result = gct.showCategoryFrame();
	  done = true;
	}
      }
    }
    return result;
  }

  public void setAuthorsVisible(boolean on)
  {
    if (authorsVisible != on) {
      authorsVisible = on;

      Component[] components = getComponents();

      for (int i = 0; i < components.length; i++) {
	if (components[i] instanceof GestureCategoryThumbnail) {
	  GestureCategoryThumbnail gct = (GestureCategoryThumbnail)
	    components[i];
	  gct.setAuthorVisible(on);
	}
      }
    }
  }
}
