package edu.berkeley.guir.damask.view.examples;

import java.awt.Color;
import java.awt.event.InputEvent;
import java.awt.geom.Point2D;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PInputEventFilter;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolox.PFrame;
import edu.umd.cs.piccolox.event.PSelectionEventHandler;

/**
 * This example shows how the selection event handler works.  
 * It creates a bunch of objects that can be selected.
 */
public class SelectionExample extends PFrame {
   public SelectionExample() {
      super();
   }

   public SelectionExample(PCanvas aCanvas) {
      super(false, aCanvas);
   }

   public void initialize() {
      for (int i = 0; i < 5; i++) {
         for (int j = 0; j < 5; j++) {
            Point2D[] points =
               new Point2D[] {
                  new Point2D.Double(i * 60, j * 60),
                  new Point2D.Double(i * 60 + 50, j * 60 + 50)};
            PNode rect = PPath.createPolyline(points);
            //PNode rect = PPath.createRectangle(i * 60, j * 60, 50, 50);
            rect.setPaint(Color.blue);
            getCanvas().getLayer().addChild(rect);
         }
      }

      // Turn off default navigation event handlers
      getCanvas().removeInputEventListener(getCanvas().getPanEventHandler());
      //getCanvas().removeInputEventListener(getCanvas().getZoomEventHandler());

      // Create a selection event handler
      PSelectionEventHandler selectionEventHandler =
         new PSelectionEventHandler(
            getCanvas().getLayer(),
            getCanvas().getLayer());
      selectionEventHandler.setEventFilter(new PInputEventFilter(InputEvent.BUTTON1_MASK));
      getCanvas().addInputEventListener(selectionEventHandler);
      getCanvas().getRoot().getDefaultInputManager().setKeyboardFocus(
         selectionEventHandler);
   }

   public static void main(String[] args) {
      new SelectionExample();
   }
}
