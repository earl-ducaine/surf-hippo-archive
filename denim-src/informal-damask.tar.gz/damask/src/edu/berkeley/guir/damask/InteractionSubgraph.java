package edu.berkeley.guir.damask;

import java.util.*;

import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.lib.util.ClassLib;
import edu.berkeley.guir.lib.util.StringLib;

/**
 * A representation of a subgraph of interaction sequences, similar to a bunch
 * of storyboards where the common screens are merged together.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2004 James Lin
 *                               Created InteractionGraph.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-20-2004
 */

public class InteractionSubgraph implements Cloneable {
   private List/*<Dialog>*/ dialogs = new ArrayList();
   private List/*<Connection>*/ connections = new ArrayList();
   private List/*<PatternInstance>*/ patternInstances = new ArrayList();
   private List/*<Dialog>*/ templates = new ArrayList();
   
   //===========================================================================
   
   /**
    * Constructs an interaction subgraph.
    */
   public InteractionSubgraph() {
   }
   
   /**
    * Constructs an interaction subgraph.
    */
   public InteractionSubgraph(final InteractionGraph graph2) {
      final List dialogs2 = new ArrayList(graph2.getDialogs());
      for (Iterator i = dialogs2.iterator(); i.hasNext(); ) {
         final Dialog d = (Dialog)i.next();
         add(d);
      }
   
      final List connections2 = new ArrayList(graph2.getConnections());
      for (Iterator i = connections2.iterator(); i.hasNext(); ) {
         final Connection c = (Connection)i.next();
         add(c);
      }
   
      final List patternInstances2 = new ArrayList(graph2.getPatternInstances());
      for (Iterator i = patternInstances2.iterator(); i.hasNext(); ) {
         final PatternInstance pi = (PatternInstance)i.next();
         add(pi);
      }
   }

   //===========================================================================

   /**
    * Adds the given dialog to the subgraph.
    */
   public void add(final Dialog dialog) {
      dialogs.add(dialog);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given dialog from the subgraph.
    * 
    * @return whether the specified dialog was removed (i.e., whether it was
    * in the graph in the first place)
    */
   public boolean remove(final Dialog dialog) {
      final int index = dialogs.indexOf(dialog);
      if (index != -1) {
         dialogs.remove(index);
         return true;
      }
      else {
         return false;
      }
   }

   //===========================================================================

   /**
    * Returns all of the dialogs in this subgraph.
    */
   public List/*<Dialog>*/ getDialogs() {
      return DamaskUtils.unmodifiableList(dialogs);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns all of the dialogs in this subgraph that have at least one page
    * for the given device.
    */
   public List/*<Dialog>*/ getDialogs(final DeviceType deviceType) {
      final List dialogsToReturn = new ArrayList();

      for (Iterator i = getDialogs().iterator(); i.hasNext(); ) {
         final Dialog dialog = (Dialog)i.next();
         final Collection pagesForDialog = dialog.getPages(deviceType);
         if (!pagesForDialog.isEmpty()) {
            dialogsToReturn.add(dialog);
         }
      }
      return dialogsToReturn;
   }

   //===========================================================================

   /**
    * Adds the given connection to the subgraph.
    */
   public void add(final Connection connection) {
      connections.add(connection);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given connection from the subgraph.
    */
   public boolean remove(final Connection connection) {
      final int index = connections.indexOf(connection);
      if (index != -1) {
         connections.remove(index);
         return true;
      }
      else {
         return false;
      }
   }

   //===========================================================================

   /**
    * Returns all of the connections in this subgraph.
    */
   public Collection/*<Connection>*/ getConnections() {
      return DamaskUtils.unmodifiableCollection(connections);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns all of the connections in this subgraph that are visible to
    * the given device type.
    */
   public Collection/*<Connection>*/ getConnections(final DeviceType deviceType) {
      final Set connectionsToReturn = new HashSet();

      for (Iterator i = getConnections().iterator(); i.hasNext(); ) {
         final Connection c = (Connection)i.next();
         if (c.isVisibleToDeviceType(deviceType)) {
            connectionsToReturn.add(c);
         }
      }
      return connectionsToReturn;
   }

   //===========================================================================

   /**
    * Adds the given pattern instance to the subgraph.
    */
   public void add(final PatternInstance p) {
      patternInstances.add(p);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given pattern instance from the subgraph.
    */
   public boolean remove(final PatternInstance p) {
      final int index = patternInstances.indexOf(p);
      if (index != -1) {
         patternInstances.remove(index);
         return true;
      }
      else {
         return false;
      }
   }

   //===========================================================================

   /**
    * Returns all of the pattern instances in this subgraph.
    */
   public Collection/*<PatternInstance>*/ getPatternInstances() {
      return DamaskUtils.unmodifiableCollection(patternInstances);
   }

   //===========================================================================

   /**
    * Adds the given dialog to the subgraph as a template.
    */
   public void addTemplate(final Dialog template) {
      templates.add(template);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given dialog template from the subgraph.
    * 
    * @return whether the specified dialog was removed (i.e., whether it was
    * in the graph in the first place)
    */
   public boolean removeTemplate(final Dialog template) {
      final int index = templates.indexOf(template);
      if (index != -1) {
         templates.remove(index);
         return true;
      }
      else {
         return false;
      }
   }

   //===========================================================================

   /**
    * Returns all of the templates in this subgraph.
    */
   public List/*<Dialog>*/ getTemplates() {
      return DamaskUtils.unmodifiableList(templates);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns all of the templates in this subgraph that have at least one page
    * for the given device.
    */
   public List/*<Dialog>*/ getTemplates(final DeviceType deviceType) {
      final List templatesToReturn = new ArrayList();

      for (Iterator i = getTemplates().iterator(); i.hasNext(); ) {
         final Dialog dialog = (Dialog)i.next();
         final Collection pagesForDialog = dialog.getPages(deviceType);
         if (!pagesForDialog.isEmpty()) {
            templatesToReturn.add(dialog);
         }
      }
      return templatesToReturn;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the default template for this subgraph, which is always the first
    * template in the graph's list of templates.
    */
   public Dialog getDefaultTemplate() {
      return (Dialog)templates.get(0);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the default template page for this subgraph.
    */
   public Page getDefaultTemplatePage(final DeviceType deviceType) {
      return getDefaultTemplate().getFirstPage(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns whether the specified dialog is a template.
    */
   public boolean isTemplate(final Dialog dialog) {
      return getTemplates().contains(dialog);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns whether the specified page is a template.
    */
   public boolean isTemplate(final Page page) {
      return isTemplate(page.getDialog());
   }

   //===========================================================================

   /**
    * Returns a string representation of this component, including the children
    * for <em>all</em> devices.
    */
   public String toLongString() {
      final StringBuffer sb = new StringBuffer();

      // 1. Write ourself
      sb.append(ClassLib.getShortClassName(this) + "\n");

      // 2. For each device, recursively write the pages and connections
      for (Iterator i = Damask.getSupportedDeviceTypes().iterator(); i.hasNext(); ) {
         final DeviceType device = (DeviceType) i.next();
         sb.append(device + ":\n");
         sb.append(" -Dialogs: " + getDialogs(device).size() + "\n");
         sb.append(dialogsToString(device));
         sb.append(" -Connections: " + getConnections(device).size() + "\n");
         sb.append(connectionsToString(device));
         sb.append("\n");
      }

      // 3. Write the pattern instances
      sb.append("* Pattern instances: " + getPatternInstances().size() + "\n");
      sb.append(patternInstancesToString());

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of this component, including the
    * children for the given device.
    */
   public String toString(final DeviceType deviceType) {
      // 0. Make sure we have a concrete device; any is not acceptable here.
      assert deviceType != DeviceType.ALL: "Device cannot be ALL";

      final StringBuffer sb = new StringBuffer();

      // 1. Write ourself
      sb.append(getClass().toString() + "\n");

      // 2. Recursively write the children
      sb.append("* Dialogs for " + deviceType + ": " + getDialogs(deviceType).size() + "\n");
      sb.append(dialogsToString(deviceType));

      // 3. Write the connections
      sb.append("* Connections: " + getConnections(deviceType).size() + "\n");
      sb.append(connectionsToString(deviceType));

      // 4. Write the pattern instances
      sb.append("* Pattern instances: " + getPatternInstances().size() + "\n");
      sb.append(patternInstancesToString());

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of all the pages in this graph for the
    * given device.
    */
   private String dialogsToString(final DeviceType deviceType) {
      final StringBuffer sb = new StringBuffer();

      for (Iterator i = getDialogs(deviceType).iterator(); i.hasNext(); ) {
         final Dialog d = (Dialog)i.next();
         sb.append(d.toLongString(1, deviceType));
         sb.append("\n");
      }

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of all the connections in this graph.
    */
   private String connectionsToString(final DeviceType deviceType) {
      final StringBuffer sb = new StringBuffer();

      for (Iterator i = getConnections(deviceType).iterator(); i.hasNext(); ) {
         final Connection c = (Connection)i.next();
         sb.append(StringLib.spaces(DamaskUtils.INDENT_SPACES));
         sb.append(c.toLongString(1, deviceType));
         sb.append("\n");
      }

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of all the pattern instances in
    * this graph.
    */
   private String patternInstancesToString() {
      final StringBuffer sb = new StringBuffer();

      for (Iterator i = getPatternInstances().iterator(); i.hasNext(); ) {
         final PatternInstance pi = (PatternInstance)i.next();
         sb.append(StringLib.spaces(DamaskUtils.INDENT_SPACES));
         sb.append(pi.toLongString());
			sb.append("\n");
      }

      return sb.toString();
   }
}
