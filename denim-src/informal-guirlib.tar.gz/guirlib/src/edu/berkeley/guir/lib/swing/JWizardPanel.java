//// See bottom of file for software license
package edu.berkeley.guir.lib.swing;

import java.awt.LayoutManager;
import javax.swing.JPanel;

/**
 * A single panel used for a Wizard process funnel.
 * This panel can be considered an encapsulated state (or step)
 * in the Wizard. 
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified July 10 2003, JH
 */
public class JWizardPanel
    extends JPanel {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * Used to denote a next-state that completes the wizard, ie "Finished".
     */
    public static final String FINISHED = "Finished";

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    JWizard wiz;                     // the wizard we are a part of
    String  strName;                 // name of the panel, for Wizard usage

    String  strBack;                 // state to go to when "back" is hit
    String  strNext;                 // state to go to when "next" is hit

    boolean flagBackEnabled = true;  // can go back
    boolean flagNextEnabled = true;  // can go next

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * @param newName is the name of this panel, for Wizard usage.
     */
    public JWizardPanel(String newName) {
        super();
        setStateName(newName);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param newName is the name of this panel, for Wizard usage.
     */
    public JWizardPanel(boolean isDoubleBuffered, String newName) {
        super(isDoubleBuffered);
        setStateName(newName);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param newName is the name of this panel, for Wizard usage.
     */
    public JWizardPanel(LayoutManager layout, String newName) {
        super(layout);
        setStateName(newName);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param newName is the name of this panel, for Wizard usage.
     */
    public JWizardPanel(LayoutManager layout, 
                        boolean       isDoubleBuffered, 
                        String        newName) {
        super(layout, isDoubleBuffered);
        setStateName(newName);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param newName is the name of this panel, for Wizard usage.
     * @param strNext is the wizard state to transition to when "next" is hit.
     *                Use null for "finished"
     * @param strBack is the wizard state to transition to when "back" is hit.
     *                Use null to specify first state (ie no back allowed)
     */
    public JWizardPanel(String newName, String strNext, String strBack) {
        this(newName);
        setNextState(strNext);
        setBackState(strBack);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param newName is the name of this panel, for Wizard usage.
     * @param strNext is the wizard state to transition to when "next" is hit.
     *                Use null for "finished"
     * @param strBack is the wizard state to transition to when "back" is hit.
     *                Use null to specify first state (ie no back allowed)
     */
    public JWizardPanel(boolean isDoubleBuffered, 
                        String  newName, 
                        String  strNext, 
                        String  strBack) {
        this(isDoubleBuffered, newName);
        setNextState(strNext);
        setBackState(strBack);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param newName is the name of this panel, for Wizard usage.
     * @param strNext is the wizard state to transition to when "next" is hit.
     *                Use null for "finished"
     * @param strBack is the wizard state to transition to when "back" is hit.
     *                Use null to specify first state (ie no back allowed)
     */
    public JWizardPanel(LayoutManager layout, 
                        String        newName,
                        String        strNext,
                        String        strBack) {
        this(layout, newName);
        setNextState(strNext);
        setBackState(strBack);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param newName is the name of this panel, for Wizard usage.
     * @param strNext is the wizard state to transition to when "next" is hit.
     *                Use null for "finished"
     * @param strBack is the wizard state to transition to when "back" is hit.
     *                Use null to specify first state (ie no back allowed)
     */
    public JWizardPanel(LayoutManager layout, 
                        boolean       isDoubleBuffered, 
                        String        newName,
                        String        strNext,
                        String        strBack) {
        this(layout, isDoubleBuffered, newName);
        setNextState(strNext);
        setBackState(strBack);
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   ACCESSOR / MODIFIER METHODS   ======================================

    /**
     * Set the wizard this panel is associated with.
     * Called automatically when this panel is added via
     * {@link JWizard#addPanel(JWizardPanel)}
     */
    public void setWizard(JWizard newWiz) {
        wiz = newWiz;
    } // of method

    /**
     * Get the wizard this panel is associated with.
     */
    public JWizard getWizard() {
        return (wiz);
    } // of method

    /**
     * Called when the enabled / disabled state of the panel is modified.
     */
    protected void update() {
        if (getWizard() == null) {
            return;
        }
        getWizard().onUpdate(this);
    } // of method

    //----------------------------------------------------------------

    /**
     * Set the abstract name of this wizard panel.
     */
    public void setStateName(String newName) {
        strName = newName;
    } // of method

    /**
     * Get the abstract name of this wizard panel.
     */
    public String getStateName() {
        return (strName);
    } // of method

    //----------------------------------------------------------------

    /**
     * Set the state that we should go to when "back" is hit.
     */
    public void setBackState(String newBackState) {
        strBack = newBackState;
    } // of method

    /**
     * Get the state that we should go to when "back" is hit.
     * Called automatically when the "back" button is hit.
     */
    public String getBackState() {
        return (strBack);
    } // of method

    /**
     * Set whether the end-user can click on "back" or not.
     * Might be disabled because first panel cannot go back.
     */
    public void setBackEnabled(boolean flagEnabled) {
        flagBackEnabled = flagEnabled;
        update();
    } // of method

    /**
     * Check if the back button is enabled or not.
     */
    public boolean isBackEnabled() {
        return (flagBackEnabled);
    } // of method

    //----------------------------------------------------------------

    /**
     * Set the state that we should go to when "next" is hit.
     * Return "Finished" (case-insensitive) to denote finished state.
     */
    public void setNextState(String newNextState) {
        strNext = newNextState;
    } // of method

    /**
     * Get the state that we should go to when "next" is hit.
     * Called automatically when the "next" button is hit.
     */
    public String getNextState() {
        return (strNext);
    } // of method

    /**
     * Set whether the end-user can click on "next" or not.
     * Might be disabled because not all required input is there.
     */
    public void setNextEnabled(boolean flagEnabled) {
        flagNextEnabled = flagEnabled;
        update();
    } // of method

    /**
     * Check if the next button is enabled or not.
     */
    public boolean isNextEnabled() {
        return (flagNextEnabled);
    } // of method

    //===   ACCESSOR / MODIFIER METHODS   ======================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static void main(String[] argv) throws Exception {
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
