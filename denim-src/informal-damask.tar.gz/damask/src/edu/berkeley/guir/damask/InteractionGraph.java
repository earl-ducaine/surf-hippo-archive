package edu.berkeley.guir.damask;

import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.pattern.*;
import edu.berkeley.guir.lib.util.ClassLib;
import edu.berkeley.guir.lib.util.StringLib;

/**
 * A representation of a graph of interaction sequences, similar to a bunch
 * of storyboards where the common screens are merged together.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-19-2003 James Lin
 *                               Created InteractionGraph.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-19-2003
 */

public class InteractionGraph implements Cloneable {
   private List/*<Dialog>*/ dialogs = new ArrayList();
   private List/*<Connection>*/ connections = new ArrayList();
   private List/*<PatternInstance>*/ patternInstances = new ArrayList();
   private List/*<TemplateDialog>*/ templates = new ArrayList();
   
   private Map/*<DeviceType, Page>*/ homePages = new HashMap();
   
   private InteractionGraphSource graphEventSource =
      new InteractionGraphSource();

   private ElementContainerSource containerEventSource =
      new ElementContainerSource();

   //===========================================================================
   
   /**
    * Constructs an interaction graph.
    */
   public InteractionGraph() {
      final Content defaultTitle = new Content(DeviceType.ALL, "Default");
      // 12 is arbitrary
      defaultTitle.setTextSize(DeviceType.ALL, 12);
      final TemplateDialog defaultTemplate =
         new TemplateDialog(DeviceType.ALL, defaultTitle);
      addTemplate(defaultTemplate);
   }

   //===========================================================================

   /**
    * Disposes the resources associated with this graph.
    */
   public void dispose() {
      for (Iterator i = new ArrayList(patternInstances).iterator(); i.hasNext(); ) {
         final PatternInstance pi = (PatternInstance)i.next();
         remove(pi);
         pi.dispose();
      }
      for (Iterator i = new ArrayList(connections).iterator(); i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         remove(connection);
         connection.dispose();
      }
      for (Iterator i = new ArrayList(dialogs).iterator(); i.hasNext(); ) {
         final Dialog dialog = (Dialog)i.next();
         remove(dialog);
         dialog.dispose();
      }
      for (Iterator i = new ArrayList(templates).iterator(); i.hasNext(); ) {
         final TemplateDialog template = (TemplateDialog)i.next();
         removeTemplate(template);
         template.dispose();
      }
   }

   //===========================================================================

   /**
    * Adds the given dialog to the interaction graph.
    */
   public void add(final Dialog dialog) {
      add(dialog, true);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Adds the given dialog to the interaction graph.
    * 
    * @param dialog                the dialog to add
    * @param applyDefaultTemplate  true if the default template should be
    *                               applied to every page in the dialog
    */
   public void add(final Dialog dialog, final boolean applyDefaultTemplate) {
      final InteractionGraph oldGraph = dialog.getInteractionGraph();
      if (oldGraph != null) {
         oldGraph.remove(dialog);
      }
      dialog.setInteractionGraph(this);
      dialogs.add(dialog);
      fireElementAdded(dialogs.size() - 1, dialog);
      
      for (Iterator i = dialog.getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();

         // Set the template of the dialog's pages to the default template of
         // this graph
         if (applyDefaultTemplate) {
            for (Iterator j = dialog.getPages(aDeviceType).iterator();
               j.hasNext(); ) {

               final Page aPage = (Page) j.next();
               aPage.addTemplate(getDefaultTemplatePage(aDeviceType));
            }
         }

         // If this graph doesn't have a home page for particular
         // device, and this dialog supports that device, then set
         // it to the first page of this dialog
         if (getHomePage(aDeviceType) == null) {
            setHomePage(aDeviceType, dialog.getFirstPage(aDeviceType));
         }
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given dialog from the interaction graph.
    * 
    * @return whether the specified dialog was removed (i.e., whether it was
    * in the graph in the first place)
    */
   public boolean remove(final Dialog dialog) {
      final int index = dialogs.indexOf(dialog);
      if (index != -1) {
         
         // Reassign home page if necessary
         for (Iterator i = Damask.getSupportedDeviceTypes().iterator(); i.hasNext(); ) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            final Page aHomePage = getHomePage(aDeviceType);
            if (aHomePage != null && aHomePage.getDialog() == dialog) {
               setHomePage(aDeviceType, null);
               for (Iterator j = getDialogs().iterator(); j.hasNext(); ) {
                  final Dialog aDialog = (Dialog)j.next();
                  if (aDialog != dialog &&
                      aDialog.isVisibleToDeviceType(aDeviceType)) {
                     setHomePage(aDeviceType, aDialog.getFirstPage(aDeviceType));
                     break;
                  }
               }
            }
         }
         
         dialogs.remove(index);
         dialog.setInteractionGraph(null);
         fireElementRemoved(index, dialog);
         return true;
      }
      else {
         return false;
      }
   }

   //===========================================================================

   /**
    * Returns all of the dialogs in this graph.
    */
   public List/*<Dialog>*/ getDialogs() {
      return DamaskUtils.unmodifiableList(dialogs);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns all of the dialogs in this graph that have at least one page
    * for the given device type.
    */
   public List/*<Dialog>*/ getDialogs(final DeviceType deviceType) {
      final List dialogsToReturn = new ArrayList();

      for (Iterator i = getDialogs().iterator(); i.hasNext(); ) {
         final Dialog dialog = (Dialog)i.next();
         final Collection pagesForDialog = dialog.getPages(deviceType);
         if (!pagesForDialog.isEmpty()) {
            dialogsToReturn.add(dialog);
         }
      }
      return dialogsToReturn;
   }

   //===========================================================================
   
   /**
    * Returns the home page for the specified device type, or null if there
    * isn't one.
    */
   public Page getHomePage(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      return (Page)homePages.get(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the home page for the specified device type to the specified page.
    */
   public void setHomePage(final DeviceType deviceType, final Page page) {
      deviceType.verifyTypeIsNotAll();
      if (page == null) {
         homePages.remove(deviceType);
      }
      else {
         DamaskUtils.checkValidArgument(
            deviceType == page.getDeviceType(),
            "The device type of "
               + page
               + " ("
               + page.getDeviceType()
               + ") does not match "
               + deviceType);
         homePages.put(deviceType, page);
      }
      fireHomePageChanged(deviceType);
   }

   //===========================================================================

   /**
    * Adds the given connection to the interaction graph.
    */
   public void add(final Connection connection) {
      final InteractionGraph oldGraph = connection.getInteractionGraph();
      if (oldGraph != null) {
         oldGraph.remove(connection);
      }
      connection.setInteractionGraph(this);
      connections.add(connection);
      fireElementAdded(connections.size() - 1, connection);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given connection from the interaction graph.
    */
   public boolean remove(final Connection connection) {
      final int index = connections.indexOf(connection);
      if (index != -1) {
         connections.remove(index);
         connection.setInteractionGraph(null);
         fireElementRemoved(index, connection);
         return true;
      }
      else {
         return false;
      }
   }

   //===========================================================================

   /**
    * Returns all of the connections in this graph.
    */
   public Collection/*<Connection>*/ getConnections() {
      return DamaskUtils.unmodifiableCollection(connections);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns all of the connections in this graph that are visible to
    * the given device type.
    */
   public Collection/*<Connection>*/ getConnections(final DeviceType deviceType) {
      final Set connectionsToReturn = new HashSet();

      for (Iterator i = getConnections().iterator(); i.hasNext(); ) {
         final Connection c = (Connection)i.next();
         if (c.isVisibleToDeviceType(deviceType)) {
            connectionsToReturn.add(c);
         }
      }
      return connectionsToReturn;
   }

   //===========================================================================

   /**
    * Adds the given pattern instance to the interaction graph.
    */
   public void add(final PatternInstance p) {
      final InteractionGraph oldGraph = p.getInteractionGraph();
      if (oldGraph != null) {
         oldGraph.remove(p);
      }
      p.setInteractionGraph(this);
      patternInstances.add(p);
      fireElementAdded(patternInstances.size() - 1, p);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given pattern instance from the interaction graph.
    */
   public boolean remove(final PatternInstance p) {
      final int index = patternInstances.indexOf(p);
      if (index != -1) {
         patternInstances.remove(index);
         p.setInteractionGraph(null);
         fireElementRemoved(index, p);
         return true;
      }
      else {
         return false;
      }
   }

   //===========================================================================

   /**
    * Returns all of the pattern instances in this graph.
    */
   public Collection/*<PatternInstance>*/ getPatternInstances() {
      return DamaskUtils.unmodifiableCollection(patternInstances);
   }

   //===========================================================================

   /**
    * Adds the given dialog to the interaction graph as a template.
    */
   public void addTemplate(final TemplateDialog template) {
      final InteractionGraph oldGraph = template.getInteractionGraph();
      if (oldGraph != null) {
         oldGraph.remove(template);
      }
      template.setInteractionGraph(this);
      templates.add(template);
      fireElementAdded(templates.size() - 1, template);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given dialog template from the interaction graph.
    * 
    * @return whether the specified dialog was removed (i.e., whether it was
    * in the graph in the first place)
    */
   public boolean removeTemplate(final TemplateDialog template) {
      final int index = templates.indexOf(template);
      if (index != -1) {
         // If any page has the specified template as a template, remove
         // the template from that page.
         for (Iterator i = getDialogs().iterator(); i.hasNext(); ) {
            final Dialog dialog = (Dialog)i.next();
            for (Iterator j = dialog.getDeviceTypesVisibleTo().iterator(); j.hasNext(); ) {
               final DeviceType deviceType = (DeviceType)j.next();
               for (Iterator k = dialog.getPages(deviceType).iterator(); k.hasNext(); ) {
                  final Page page = (Page)k.next();
                  final List/*<Page>*/ templatesToRemove = new ArrayList();
                  for (Iterator m = page.getTemplates().iterator(); m.hasNext(); ) {
                     final Page pageTemplate = (Page)m.next();
                     if (pageTemplate.getDialog() == template) {
                        templatesToRemove.add(pageTemplate);
                     }
                  }
                  for (Iterator m = templatesToRemove.iterator(); m.hasNext(); ) {
                     final Page pageTemplate = (Page)m.next();
                     page.removeTemplate(pageTemplate);
                  }
               }
            }
         }
         
         templates.remove(index);
         template.setInteractionGraph(null);
         fireElementRemoved(index, template);
         return true;
      }
      else {
         return false;
      }
   }

   //===========================================================================

   /**
    * Returns all of the templates in this graph.
    */
   public List/*<TemplateDialog>*/ getTemplates() {
      return DamaskUtils.unmodifiableList(templates);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns all of the templates in this graph that have at least one page
    * for the given device.
    */
   public List/*<TemplateDialog>*/ getTemplates(final DeviceType deviceType) {
      final List/*<TemplateDialog>*/ templatesToReturn = new ArrayList();

      for (Iterator i = getTemplates().iterator(); i.hasNext(); ) {
         final TemplateDialog dialog = (TemplateDialog)i.next();
         final Collection pagesForDialog = dialog.getPages(deviceType);
         if (!pagesForDialog.isEmpty()) {
            templatesToReturn.add(dialog);
         }
      }
      return templatesToReturn;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the default template for this graph, which is always the first
    * template in the graph's list of templates.
    */
   public TemplateDialog getDefaultTemplate() {
      return (TemplateDialog)templates.get(0);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the default template page for this graph.
    */
   public Page getDefaultTemplatePage(final DeviceType deviceType) {
      return getDefaultTemplate().getFirstPage(deviceType);
   }

   //===========================================================================

   private void createClone(
      final InteractionGraph clone,
      final Collection dialogsToClone,
      final Collection connectionsToClone,
      final Collection patternInstancesToClone) {

      clone.containerEventSource = new ElementContainerSource();
      clone.graphEventSource = new InteractionGraphSource();
      
      // Clear all of the dialogs, connections, and pattern instances from
      // the clone.
      clone.dialogs = new ArrayList();
      clone.connections = new ArrayList();
      clone.patternInstances = new ArrayList();

      // Find all dialogs, connections, and pattern instances that the
      // original pattern instance points to, clone them, and add them
      // to the graph clone.
      for (Iterator i = dialogsToClone.iterator(); i.hasNext(); ) {
         final Dialog dialog = (Dialog)i.next();
         final Dialog cloneDialog = (Dialog)dialog.clone();
         clone.add(cloneDialog); 
      }

      for (Iterator i = connectionsToClone.iterator(); i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         final Connection cloneConnection = (Connection)connection.clone();
         clone.add(cloneConnection);
      }

      for (Iterator i = patternInstancesToClone.iterator(); i.hasNext(); ) {
         final PatternInstance patternInstance = (PatternInstance)i.next();
         final PatternInstance clonePatternInstance =
            (PatternInstance)patternInstance.clone();
         clone.add(clonePatternInstance);
      }

      // Go through all of the pattern instances that were just cloned, and
      // fix their references so that they point to the cloned objects, not
      // the originals.
      for (Iterator i = clone.getPatternInstances().iterator(); i.hasNext();) {
         final PatternInstance pi = (PatternInstance)i.next();
         
         for (Iterator j = new HashSet(pi.getMembers()).iterator(); j.hasNext(); ) {
            final PatternInstanceMember m = (PatternInstanceMember)j.next();
            pi.remove(m);
            assert m.getMostRecentCloneIfAlive() != null:
               "clone of d should still be alive";
            pi.add((PatternInstanceMember)m.getMostRecentCloneIfAlive());
         }
      }
   }

   //---------------------------------------------------------------------------

   public Object clone() {
      try {
         final InteractionGraph clone = (InteractionGraph)super.clone();
         
         createClone(
            clone,
            getDialogs(),
            getConnections(),
            getPatternInstances());
   
         return clone;
      }
      catch (CloneNotSupportedException e) {
         throw new Error("Object doesn't support clone - yeah right");
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Clones the given collection of dialogs, connections, and pattern
    * instances in this interaction graph and creates a new interaction
    * graph from the clones.
    */ 
   protected InteractionGraph createPartialClone(
      final Collection dialogsToClone,
      final Collection connectionsToClone,
      final Collection patternInstancesToClone) {

      final InteractionGraph newGraph = new InteractionGraph();
      
      createClone(
         newGraph,
         dialogsToClone,
         connectionsToClone,
         patternInstancesToClone);
      
      return newGraph;
   }

   //===========================================================================
   
   /**
    * Takes the contents of the given graph and moves them to this graph.
    */
   public void merge(final InteractionGraph graph2) {
      final List dialogs2 = new ArrayList(graph2.getDialogs());
      for (Iterator i = dialogs2.iterator(); i.hasNext(); ) {
         final Dialog d = (Dialog)i.next();
         add(d);
      }
      
      final List connections2 = new ArrayList(graph2.getConnections());
      for (Iterator i = connections2.iterator(); i.hasNext(); ) {
         final Connection c = (Connection)i.next();
         add(c);
      }
      
      final List patternInstances2 = new ArrayList(graph2.getPatternInstances());
      for (Iterator i = patternInstances2.iterator(); i.hasNext(); ) {
         final PatternInstance pi = (PatternInstance)i.next();
         add(pi);
      }
   }

   //===========================================================================

   /**
    * Creates a new instance of the given pattern and merges it into this
    * graph. The two given pages will be combined (they must be the same device
    * type).
    * 
    * <p>NOTE: Merge only happens for the page's device (the device the user is
    * currently working on). For all other devices, the page(s) in
    * mergePatternPage's Dialog are put in mergeGraphPage's Dialog.
    *
    * @param pattern the pattern whose instance will be merged into this graph
    * @param mergePatternPage the page within the pattern solution that will
    *         be merged with a page in this graph, or null if the pattern is
    *         not to be merged with any page.
    * @param mergeGraphPage the page in this graph which will be merged with
    *         a page in the pattern instance, or null if the pattern is
    *         not to be merged with any page.
    */
   public InteractionSubgraph mergePatternInstance(
      final Pattern pattern,
      final Page mergePatternPage,
      final Point2D mergePoint,
      final Page mergeGraphPage,
      final Set/*<Component>*/ newComponentsInMergeGraphDialog) {

      if ((mergePatternPage != null) && (mergeGraphPage != null)) {
         DamaskUtils.checkValidArgument(
            mergePatternPage.getDeviceType() == mergeGraphPage.getDeviceType(),
            "mergePatternPage and mergeGraphPage should have the same device type");
      }

      // 1. Instantiate the pattern.
      final InteractionSubgraph subgraph = pattern.createPatternInstance(this);
      
      //It's possible that the user doesn't want to merge (that instead they
      //dropped it loose into the design), so make sure both aren't null
      if (mergePatternPage != null) {
         
         // 2. Find the page in the pattern instance that corresponds to
         //    mergePatternPage, which is within the pattern solution.
         //    We'll call this page mergeInstancePage.
         final Page mergeInstancePage =
            (Page) mergePatternPage.getMostRecentCloneIfAlive();
            
         assert mergeInstancePage != null:
            "mergePatternPage's clone should still be alive";

         // 3. Find the dialogs of mergeInstancePage and mergeGraphPage.
         final Dialog mergeInstanceDialog = mergeInstancePage.getDialog();
         final Dialog mergeGraphDialog;
         if (mergeGraphPage == null) {
            mergeGraphDialog = null;
         }
         else {
            mergeGraphDialog = mergeGraphPage.getDialog();
         }

         // 4. Move the pages in the pattern instance so that they
         //    are in the same relative position to the merged page.
         final Rectangle2D mergeInstanceRect =
            mergeInstancePage.localToGlobal(
               mergeInstancePage.getDeviceType(),
               mergeInstancePage.getBounds());

         for (Iterator i =
            Damask.getSupportedDeviceTypes().iterator();
            i.hasNext();
            ) {
            final DeviceType deviceType = (DeviceType)i.next();
            
            double dx = Double.NaN;
            double dy = Double.NaN;
            
            if (mergeGraphDialog != null) {
               if (mergeGraphDialog.isVisibleToDeviceType(deviceType)) {
                  final Page mergeGraphPageForDeviceType;
                  if (mergeGraphPage.getDeviceType() == deviceType) {
                     mergeGraphPageForDeviceType = mergeGraphPage; 
                  }
                  else {
                     mergeGraphPageForDeviceType =
                        mergeGraphDialog.getFirstPage(deviceType);
                  }

                  final Rectangle2D mergeGraphRect =
                     mergeGraphPageForDeviceType.localToGlobal(
                        mergeGraphPageForDeviceType.getDeviceType(),
                        mergeGraphPageForDeviceType.getBounds());

                  dx = mergeGraphRect.getX() - mergeInstanceRect.getX();
                  dy = mergeGraphRect.getY() - mergeInstanceRect.getY();
               }
            }
            else if (mergePoint != null) {
               dx = mergePoint.getX() - mergeInstanceRect.getX();
               dy = mergePoint.getY() - mergeInstanceRect.getY();
            }
            
            if ((dx != Double.NaN) && (dy != Double.NaN)) {
               final AffineTransform translate =
                  AffineTransform.getTranslateInstance(dx, dy);
         
               for (Iterator j = subgraph.getDialogs().iterator(); j.hasNext(); ) {
                  final Dialog dialog = (Dialog)j.next();
                  if (deviceType == DeviceType.VOICE) {
                     final AffineTransform dialogTransform =
                        dialog.getTransform(deviceType);
                     dialogTransform.preConcatenate(translate);
                     dialog.setTransform(deviceType, dialogTransform);
                  }
                  else {
                     for (Iterator k = dialog.getPages(deviceType).iterator(); 
                        k.hasNext();) {
                        final Page page = (Page) k.next();
                        final AffineTransform pageTransform =
                           page.getTransform();
                        pageTransform.preConcatenate(translate);
                        page.setTransform(pageTransform);
                     }
                  }
               }
            }
         }
         
         if (mergeGraphDialog != null) {
            // 5. Keep track of the components being merged into
            //    mergeGraphDialog.
            for (Iterator i =
               mergeInstanceDialog.getDeviceTypesVisibleTo().iterator();
               i.hasNext(); ) {
               final DeviceType aDeviceType = (DeviceType)i.next();
               for (Iterator j =
                  mergeInstanceDialog.getPages(aDeviceType).iterator();
                  j.hasNext(); ) {
                  final Page aPage = (Page)j.next();
                  for (Iterator k = aPage.getRegions().iterator(); k.hasNext(); ) {
                     final PageRegion aRegion = (PageRegion)k.next();
                     newComponentsInMergeGraphDialog.addAll(aRegion.getControls());
                  }
               }
            }
            newComponentsInMergeGraphDialog.addAll(mergeInstanceDialog.getGroups());
            
            // 6. Merge those dialogs together.
            mergeGraphDialog.merge(mergeInstanceDialog);
         }
      }
      
      // 7. Reanchor the connections.
      for (Iterator i = subgraph.getConnections().iterator(); i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         for (Iterator j = connection.getDeviceTypesVisibleTo().iterator();
              j.hasNext(); ) {
            final DeviceType deviceType = (DeviceType)j.next();
            connection.refresh(deviceType);
         }
      }
      
      return subgraph;
   }

   //===========================================================================
   
   /**
    * Adds the specified listener to receive events from this graph.
    */
   public void addInteractionGraphListener(
      final InteractionGraphListener listener) {

      graphEventSource.addInteractionGraphListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified listener so that it no longer receives
    * events from this graph.
    */
   public void removeInteractionGraphListener(
      final InteractionGraphListener listener) {

      graphEventSource.removeInteractionGraphListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires homePageChanged events to listeners.
    */
   private void fireHomePageChanged(final DeviceType deviceType) {
      graphEventSource.fireHomePageChanged(this, deviceType);
   }

   //===========================================================================
   
   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public void addElementContainerListener(
      final ElementContainerListener listener) {

      containerEventSource.addElementContainerListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public void removeElementContainerListener(
      final ElementContainerListener listener) {

      containerEventSource.removeElementContainerListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementAdded events to listeners.
    */
   private void fireElementAdded(final int index, final InteractionElement e) {
      containerEventSource.fireElementAdded(this, null, index, e);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires elementRemoved events to listeners.
    */
   private void fireElementRemoved(final int index, final InteractionElement e){
      containerEventSource.fireElementRemoved(this, null, index, e);
   }

   //===========================================================================

   /**
    * Returns a string representation of this component, including the children
    * for <em>all</em> devices.
    */
   public String toLongString() {
      final StringBuffer sb = new StringBuffer();

      // 1. Write ourself
      sb.append(ClassLib.getShortClassName(this) + "\n");

      // 2. For each device, recursively write the pages and connections
      for (Iterator i = Damask.getSupportedDeviceTypes().iterator(); i.hasNext(); ) {
         final DeviceType device = (DeviceType) i.next();
         sb.append(device + ":\n");
         sb.append(" -Dialogs: " + getDialogs(device).size() + "\n");
         sb.append(dialogsToString(device));
         sb.append(" -Connections: " + getConnections(device).size() + "\n");
         sb.append(connectionsToString(device));
         sb.append("\n");
      }

      // 3. Write the pattern instances
      sb.append("* Pattern instances: " + getPatternInstances().size() + "\n");
      sb.append(patternInstancesToString());

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of this component, including the
    * children for the given device.
    */
   public String toString(final DeviceType deviceType) {
      // 0. Make sure we have a concrete device; any is not acceptable here.
      assert deviceType != DeviceType.ALL: "Device cannot be ALL";

      final StringBuffer sb = new StringBuffer();

      // 1. Write ourself
      sb.append(getClass().toString() + "\n");

      // 2. Recursively write the children
      sb.append("* Dialogs for " + deviceType + ": " + getDialogs(deviceType).size() + "\n");
      sb.append(dialogsToString(deviceType));

      // 3. Write the connections
      sb.append("* Connections: " + getConnections(deviceType).size() + "\n");
      sb.append(connectionsToString(deviceType));

      // 4. Write the pattern instances
      sb.append("* Pattern instances: " + getPatternInstances().size() + "\n");
      sb.append(patternInstancesToString());

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of all the pages in this graph for the
    * given device.
    */
   private String dialogsToString(final DeviceType deviceType) {
      final StringBuffer sb = new StringBuffer();

      for (Iterator i = getDialogs(deviceType).iterator(); i.hasNext(); ) {
         final Dialog d = (Dialog)i.next();
         sb.append(d.toLongString(1, deviceType));
         sb.append("\n");
      }

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of all the connections in this graph.
    */
   private String connectionsToString(final DeviceType deviceType) {
      final StringBuffer sb = new StringBuffer();

      for (Iterator i = getConnections(deviceType).iterator(); i.hasNext(); ) {
         final Connection c = (Connection)i.next();
         sb.append(StringLib.spaces(DamaskUtils.INDENT_SPACES));
         sb.append(c.toLongString(1, deviceType));
         sb.append("\n");
      }

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of all the pattern instances in
    * this graph.
    */
   private String patternInstancesToString() {
      final StringBuffer sb = new StringBuffer();

      for (Iterator i = getPatternInstances().iterator(); i.hasNext(); ) {
         final PatternInstance pi = (PatternInstance)i.next();
         sb.append(StringLib.spaces(DamaskUtils.INDENT_SPACES));
         sb.append(pi.toLongString());
			sb.append("\n");
      }

      return sb.toString();
   }
}
