//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.history;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedList;
import java.util.StringTokenizer;

/**
 * Basic parser for HistoryEvents. Just reads it in and parses it,
 * returning a HistoryEvent instance.
 * <P>
 * This parser handles two separate conditions. One is when the key-value
 * pair is fully named, for example "[a=b][c=d]". The other is when only
 * the value is named, for example "[b][d]". In the latter, an ordering of keys
 * must be provided, so that we will know what to call each field.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 20 2003, JH
 */
public class HistoryEventParserDefaultImpl 
    implements HistoryEventParser {

    //==========================================================================
    //===   FACTORY METHODS   ==================================================

    /**
     * Return a new HistoryEvent. Override this method if needed
     * to return subclasses. Not advised.
     */
    protected HistoryEvent createNewHistoryEvent() {
        return (new HistoryEvent());
    } // of method

    //===   FACTORY METHODS   ==================================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    String[] keyOrdering;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Expects fully named history event, for example
     * "[keyAA=valAA][keyBB=valBB]".
     */
    public HistoryEventParserDefaultImpl() {
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Create a parser that expects keys in the specified order.
     * Expects individual history events to look like "[valAA][valBB][valCC]".
     * The key ordering will be mapped onto the values. For example, if the key
     * ordering were {"keyAA", "keyBB", "keyCC"}, then the result would be
     * {"keyAA"="valAA", "keyBB"="valBB", "keyCC"="valCC"}
     */
    public HistoryEventParserDefaultImpl(String[] newKeyOrdering) {
        keyOrdering = newKeyOrdering;
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   PARSER METHODS   ===================================================

    /**
     * Slice up a single key-value pair into a key and value.
     * @return a size 2 array, String[0] = key, String[1] = value.
     */
    protected String[] getKeyValue(String str) {
        String[] strKeyVal = new String[2];
        int      index     = str.indexOf("=");

        strKeyVal[0] = str.substring(0, index);
        strKeyVal[1] = str.substring(index + 1);

        return (strKeyVal);
    } // of method


    /**
     * Slice up the line into a bunch of key-value pairs.
     * Assumes String is of format "[a=b][c=d]"
     * @return a List of String[2], String[0]==key and String[1]==value
     */
    protected List getKeyValuePairs(String strLine) {
        StringTokenizer strtok = new StringTokenizer(strLine,
                                                 HistoryEvent.FIELD_DELIMITER);
        String          strPair;
        List            listPairs = new LinkedList();

        while (strtok.hasMoreTokens()) {
            strPair = strtok.nextToken();
            listPairs.add(getKeyValue(strPair));
        }

        return (listPairs);
    } // of method


    /**
     * Assumes String is of format "[b][d]"
     * Assumes keyOrdering has been defined already.
     * @return a List of String[2], String[0]==key and String[1]==value
     */
    protected List getValues(String strLine) {
        StringTokenizer strtok     = new StringTokenizer(strLine, 
                                                 HistoryEvent.FIELD_DELIMITER);
        List            listPairs  = new LinkedList();
        int             i          = 0;
        String[]        pair;

        while (strtok.hasMoreTokens()) {
            pair    = new String[2];
            pair[0] = keyOrdering[i++];
            pair[1] = strtok.nextToken();
            listPairs.add(pair);
        }

        return (listPairs);
    } // of method


    /**
     * Parse a single line representing a HistoryEvent.
     */
    protected HistoryEvent parseLine(String strLine) {
        //// 1. Create the event.
        HistoryEvent evt = createNewHistoryEvent();

        //// 2. Parse the line.
        List listPairs;
        if (keyOrdering == null) {
            listPairs = getKeyValuePairs(strLine);
        }
        else {
            listPairs = getValues(strLine);
        }
        
        //// 3. Go through each pair.
        Iterator it         = listPairs.iterator();
        String[] strKeyVal;

        while (it.hasNext()) {
            strKeyVal = (String[]) it.next();
            evt.setValue(strKeyVal[0], strKeyVal[1]);
        }

        return (evt);
    } // of method

    //----------------------------------------------------------------

    public List parse(InputStream istream) 
        throws IOException {

        return (parse(new InputStreamReader(istream)));
    } // of method


    public List parse(Reader rdr) 
        throws IOException {

        List   listEvents = new LinkedList();
        String strLine;

        //// 1. Make it a buffered reader.
        ////    Useful because of readLine() method.
        BufferedReader brdr;
        if (rdr instanceof BufferedReader) {
            brdr = (BufferedReader) rdr;
        }
        else {
            brdr = new BufferedReader(rdr);
        }


        //// 2. Read a line and parse it.
        while ((strLine = brdr.readLine()) != null) {
            listEvents.add(parseLine(strLine));
        }


        //// 3. Return.
        return (listEvents);
    } // of method

    //===   PARSER METHODS   ===================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
