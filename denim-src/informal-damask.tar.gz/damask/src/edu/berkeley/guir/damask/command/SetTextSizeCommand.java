package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that sets the font size of a piece of text.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  06-12-2004 James Lin
 *                               Created SetHomePageCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 06-12-2004
 */
public class SetTextSizeCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final Content content;
   private final DeviceType deviceType;
   private final int newSize;
   private final int oldSize;
   
   /**
    * Constructs the command.
    *  
    * @param graph the graph to edit
    * @param deviceType the type of device for which to set the home page
    * @param homePage the new home page of the graph
    */      
   public SetTextSizeCommand(
      final Content content,
      final DeviceType deviceType,
      final int size) {

      this.content = content;
      this.deviceType = deviceType;
      newSize = size;
      oldSize = content.getTextSize(deviceType);
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Set text size of " + content +
         " for " + deviceType + ": " + oldSize + "->" + newSize;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      content.setTextSize(deviceType, newSize);
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      content.setTextSize(deviceType, oldSize);
   }
}
