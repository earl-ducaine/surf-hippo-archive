package edu.berkeley.guir.lib.awt;

import java.awt.AWTException;
import java.awt.event.InputEvent;
import java.awt.Robot;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * Plays back recorded events from a file with a Robot object.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 *
 * @author  Lisa Chan (
 *          <A HREF="mailto:lisachan@cory.eecs.berkeley.edu">lisachan@cory.eecs.berkeley.edu</A> )
 * @since   JDK 1.3
 * @version GUIRLib-v1.4-1.1.0, Mar 23 2001
 */
public class EventPlayer {
   protected BufferedReader in;
   protected Robot          robot;
   protected float          speedFactor;

   /**
    * Constructs a new event player, which will read in events stored in
    * the file with the given name.
    */
   public EventPlayer(String filename)
   throws AWTException, FileNotFoundException {
      in          = new BufferedReader(new FileReader(filename));
      robot       = new Robot();
      speedFactor = 1.0f;
   }

   /**
    * Constructs a new event player, which will read in events stored in
    * the file with the given name.
    * Optional 3rd argument allows a speed factor to be specified; 
    * delay times are multiplied by it to increase or decrease delays.
    */
   public EventPlayer(String filename, float speedFactor)
   throws AWTException, FileNotFoundException {
      in               = new BufferedReader(new FileReader(filename));
      robot            = new Robot();
      this.speedFactor = speedFactor;
   }

   /**
    *  Reads mouse and key events from a file and plays back using a Robot.
    */
   public void play() {

      try {
         String line = in.readLine();

         while (line != null) {

            int delay = Integer.parseInt(line.substring(0, line.indexOf("ms")));

            int offset = line.indexOf("MouseEvent[ MOUSE");
            if (offset == -1) {
               offset = line.indexOf("KeyEvent[ KEY");
            }

            // Multiply by speed factor, making sure not to change a 
            // hold-to-select action to something else or vice versa.
            int newdelay = (int)(delay * speedFactor);
            if (newdelay<0) newdelay=0;
            if (newdelay>2000) newdelay=2000;
            delay=newdelay;
            
            if (line.startsWith("MouseEvent[ MOUSE_MOVED", offset)) {
               String coords = line.substring(line.indexOf("(")+1,
                                              line.lastIndexOf(")-S"));
               int x = Integer.parseInt(coords.substring(0,
                                        coords.indexOf(",")));
               int y = 0;
               if (coords.indexOf(")") == -1) { // in case an extra point gets
                                                // recorded--it has happened 
                                                // though i don't know why!
                  y = Integer.parseInt(coords.substring(coords.indexOf(",")+1));
               }
               else {
                  y = Integer.parseInt
                     (coords.substring(coords.indexOf(",")+1,
                                       coords.indexOf(")")));
               }

               robot.delay(delay);
               robot.mouseMove(x, y);
            }

            else if (line.startsWith("MouseEvent[ MOUSE_PRESSED", offset)) {
               int button = -1;
               if (line.indexOf("LT") != -1) {
                  button = InputEvent.BUTTON1_MASK;
               }
               else if (line.indexOf("MI") != -1) {
                  button = InputEvent.BUTTON2_MASK;
               }
               else if (line.indexOf("RT") != -1) {
                  button = InputEvent.BUTTON3_MASK;
               }

               robot.delay(delay);
               robot.mousePress(button);
            }

            else if (line.startsWith("MouseEvent[ MOUSE_RELEASED", offset)) {
               int button = -1;
               if (line.indexOf("LT") != -1) {
                  button = InputEvent.BUTTON1_MASK;
               }
               else if (line.indexOf("MI") != -1) {
                  button = InputEvent.BUTTON2_MASK;
               }
               else if (line.indexOf("RT") != -1) {
                  button = InputEvent.BUTTON3_MASK;
               }

               robot.delay(delay);
               robot.mouseRelease(button);

            }

            else if (line.startsWith("KeyEvent[ KEY_PRESSED", offset)) {
               int keyCode = getKeyCode(line);
               robot.delay(delay);
               robot.keyPress(keyCode);
            }

            else if (line.startsWith("KeyEvent[ KEY_RELEASED", offset)) {
               int keyCode = getKeyCode(line);
               robot.delay(delay);
               robot.keyRelease(keyCode);
            }

            line = in.readLine();
         }
      }
      catch (IOException e) {
         System.out.println("ERROR IOException: " + e);
      }

   } // of parse

   /**
    * Parses and returns the key code for the key event of the line.
    */
   private int getKeyCode(String line) {
      int offset = 7; // offset to get to N in KeyCodeN
      String keyString = line.substring(line.lastIndexOf("KeyCode")+offset,
                                        line.indexOf("]"));
      return Integer.parseInt(keyString);
   }

} // of class

//==============================================================================

/*
  Copyright (c) 2002 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
