//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.util;

import java.awt.*;
import java.util.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.util.RandomLib;

/**
 * Utilities for getting random GraphicalObjects.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 02 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
final public class SatinRandomLib {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private static final Random rand = new Random(13948371L);

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   RANDOM UTILITY METHODS   ============================================

   /**
    * Generate a Graphical Object Collection with the specified number 
    * of strokes.
    */
   public static GraphicalObjectCollection 
   getRandomGraphicalObjectCollection(Rectangle rect, int numStks) {
      GraphicalObjectCollection gobcol = new GraphicalObjectCollectionImpl();

      for (int i = 0; i < numStks; i++) {
         gobcol.add(getRandomStroke(rect, 4));
      }

      return (gobcol);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Generate a stroke that fits in the specified rectangle and has the
    * specified number of points.
    */
   public static TimedStroke getRandomStroke(Rectangle rect, int npoints) {
      TimedStroke stk = new TimedStroke();

      for (int i = 0; i < npoints; i++) {
         stk.addPoint(RandomLib.nextInt(rand, rect.x, rect.x + rect.width),
                      RandomLib.nextInt(rand, rect.y, rect.y + rect.width));
      }

      return (stk);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a randomly-generated square patch that fits inside the bounds 
    * of the specified rect.
    */
   public static Patch getRandomPatch(Rectangle rect) {
      //// 1. Get the dimensions.
      int x = RandomLib.nextInt(rand, rect.x, rect.x + rect.width);
      int y = RandomLib.nextInt(rand, rect.y, rect.y + rect.height);
      int w = RandomLib.nextInt(rand, 0, rect.x + rect.width - x);
      int h = RandomLib.nextInt(rand, 0, rect.y + rect.height - y);

      //// 2. Create a new patch that fits in those dimensions.
      Rectangle bounds = new Rectangle(x, y, w, h);
      return (new PatchImpl(bounds));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a randomly-generated square patch with a semantic zoom view that 
    * fits inside the bounds of the specified rect.
    */
   public static Patch getRandomSemanticZoomPatch(Rectangle rect) {
      //// 1. Get the dimensions.
      int x = RandomLib.nextInt(rand, rect.x, rect.x + rect.width);
      int y = RandomLib.nextInt(rand, rect.y, rect.y + rect.height);
      int w = RandomLib.nextInt(rand, 0, rect.x + rect.width - x);
      int h = RandomLib.nextInt(rand, 0, rect.y + rect.height - y);

      //// 2. Create a new patch that fits in those dimensions.
      Rectangle bounds = new Rectangle(x, y, w, h);
      PatchImpl p      = new PatchImpl(bounds);

      //// 3. Set up the semantic zoom part.
      SemanticZoomView          v;
      SemanticZoomMultiViewImpl med;
      double                    fIn    = RandomLib.nextDouble(rand, 0, 1);
      double                    start  = RandomLib.nextDouble(rand, 1, 2);
      double                    end    = RandomLib.nextDouble(rand, 2, 3);
      double                    fOut   = RandomLib.nextDouble(rand, 3, 4);

      v   = new SemanticZoomViewWrapper(p.getView());
      v.setDisplayRange(fIn, start, end, fOut);
      med = new SemanticZoomMultiViewImpl();
      med.add(v);
      p.setView(med);

      return (p);
   } // of method

   //===   RANDOM UTILITY METHODS   ============================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static void main(String[] argv) {
      RandomLib s = new RandomLib();
      s.addPoint(10, 10);
      s.addPoint(20, 10);
      s.addPoint(10, 20);
      s.addPoint(5, 20);
      s.addPoint(10, 5);   // bounds should be (5, 5) (20, 20)
      System.out.println(s.getGObBounds());
      System.out.println(s);
      System.out.println();

      RandomLib s2 = (RandomLib) s.clone();
      System.out.println(s2.getGObBounds());
      System.out.println(s2);

   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of Class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
