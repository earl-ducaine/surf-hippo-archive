package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.Misc;
import edu.berkeley.guir.lib.gesture.util.Gensym;
import edu.berkeley.guir.lib.gesture.util.CompositeIcon;
import java.util.*;
import java.awt.event.*;
import javax.swing.tree.*;
import java.util.List;
import java.util.ArrayList;
import java.awt.datatransfer.*;
import java.io.IOException;
import javax.swing.text.BadLocationException;

public class GestureTree extends JTree
  implements Commander, GestureAcceptor, GDTConstants, ClipboardOwner {
  protected EventListenerList listenerList = new EventListenerList();
  GestureContainer editValue = null;
  protected Classifier classifier = null;
  protected GestureAcceptor addAcceptor		= new AddAcceptor();
  protected GestureAcceptor replaceAcceptor	= new ReplaceAcceptor();
  protected GestureAcceptor recognizeAcceptor	= new RecognizeAcceptor();
  
  public GestureTree()
  {
    super((TreeModel)null);
    // prevent double-click from expanding/collapsing
    setToggleClickCount(0);
    setShowsRootHandles(true);
    setEditable(true);
    DefaultTreeCellRenderer renderer = new GestureTreeCellRenderer();
    setCellRenderer(renderer);
    setCellEditor(new DefaultTreeCellEditor(this, renderer,
					    new GestureCellEditor()));
    addMouseListener(new MyMouseListener());
  }

  protected MainFrame getMainFrame()
  {
    MainFrame mf = (MainFrame) SwingUtilities.
      getAncestorOfClass(MainFrame.class, this);
    return mf;
  }
  
  /** model must be an instance of GestureTreeModel (or subclass) */
  public void setModel(TreeModel model)
  {
    if ((model != null) && !(model instanceof GestureTreeModel)) {
      throw new
	IllegalArgumentException("Only GestureTreeModel is allowed, not "
				 + model.getClass().getName() +
				 " (" + model + ")");
    }
    super.setModel(model);
  }
  
  public boolean isPathEditable(TreePath path)
  {
    GestureTreeModel model = (GestureTreeModel) getModel();
    return model.isNodeRenamable((TreeNode) path.getLastPathComponent());
  }
  
  /** convenience method */
  public static Object getUserObject(Object obj)
  {
    return ((DefaultMutableTreeNode) obj).getUserObject();
  }

  public boolean isCommandValid(int id)
  {
    boolean valid;
    switch (id) {
    case CUT_ACTION:
    case COPY_ACTION:
    case DELETE_ACTION:
      /*
	These are valid iff any of the selected rows are normal
	(i.e. not root, Test or Training).
      */
      int[] selectedRows = getSelectionRows();
      valid = false;
      if (selectedRows != null) {
	// only the first row cannot be selected
	for (int i = 0; (i < selectedRows.length) && !valid; i++) {
	  if (selectedRows[i] != 0) {
	    valid = true;
	  }
	}
      }
      break;
    case PASTE_ACTION:
      Transferable transferable =
	GDTClipboard.getClipboard().getContents(this);
      valid = (transferable != null) && canPaste(transferable);
      break;
    case NEW_GESTURE_ACTION:
      valid = canAdd(GestureCategory.class);
      break;
    case NEW_GROUP_ACTION:
      valid = canAdd(GestureGroup.class);
      break;
    case RENAME_ACTION:
      valid = (getSelectionCount() == 1) &&
	isPathEditable(getSelectionPath());
      break;
    case ENABLE_ACTION:
      valid = !isSelectionEmpty();
      break;
    case DISABLE_ACTION:
      valid = !isSelectionEmpty();
      break;
    case TEST_RECOGNITION_ACTION:
      valid = (getSelectionCount() == 1) &&
	(getSelectedObject() instanceof GestureTestSet);
    default:
      valid = false;
      break;
    }
    return valid;
  }

  /** c can be added if there one selection and if it or any of its
      ancestors accept children of type c.  (For some multiselections
      it makes sense to be able to add, but in general it's too hard
      to figure out so I'm disallowing it for now.) */
  protected boolean canAdd(Class c)
  {
    boolean valid;
    if (getSelectionCount() == 1) {
      TreePath path = getSelectionPath();
      valid = findParent(c, path) != null;
    }
    else {
      valid = false;
    }
    return valid;
  }

  /** get the user object for the leaf (i.e. last node) of the path */
  protected Object getLeafUserObject(TreePath path)
  {
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)
	path.getLastPathComponent();
    return node.getUserObject();
  }
  
  /** Searches path, bottom-to-top, for a node whose user object has
      children of type c.  Returns null if no such node found. */
  protected DefaultMutableTreeNode findParent(Class c, TreePath path)
  {
    DefaultMutableTreeNode result = null;
    while ((path != null) && (result == null)) {
      DefaultMutableTreeNode node = (DefaultMutableTreeNode)
	path.getLastPathComponent();
      Object userObj = node.getUserObject();
      if ((userObj instanceof GestureContainer) &&
	  ((GestureContainer) userObj).isChildType(c)) {
	result = node;
      }
      else {
	path = path.getParentPath();
      }
    }
    return result;
  }
  
  /** Return first selected object (probably only useful if
      getSelectionCount()==1). */
  public Object getSelectedObject()
  {
    TreePath[] selectedPaths = getSelectionPaths();
    return ((DefaultMutableTreeNode) selectedPaths[0].
	    getLastPathComponent()).getUserObject();
  }

  /** returns a list of selected GestureObjects */
  public List getSelectedObjects()
  {
    List selection;
    TreePath[] selectedPaths = getSelectionPaths();
    if (selectedPaths == null) {
      selection = null;
    }
    else {
      List list = Arrays.asList(selectedPaths);
      selection = (List) Misc.mapcar(list, new Misc.UnaryOperator() {
	public Object operate(Object obj) {
	  TreePath p = (TreePath) obj;
	  DefaultMutableTreeNode n = (DefaultMutableTreeNode)
	    p.getLastPathComponent();
	  return n.getUserObject();
	}
      });
    }
    return selection;
  }

  protected boolean canPaste(Transferable t)
  {
    return getPasteTarget(t) != null;
  }

  protected GestureContainer getPasteTarget(Transferable t)
  {
    GestureContainer target = null;
    Object selectedObj;
    if ((t instanceof GestureTransferable) && (getSelectionCount() == 1) &&
	((selectedObj = getSelectedObject()) instanceof GestureContainer)) {
      GestureTransferable gt = (GestureTransferable) t;
      if (canPaste(gt, (GestureContainer) selectedObj)) {
	target = (GestureContainer) selectedObj;
      }
      else {
	TreePath selectionPath = getSelectionPath();
	TreePath parentPath = selectionPath.getParentPath();
	if (parentPath != null) {
	  DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode)
	    parentPath.getLastPathComponent();
	  GestureContainer parent = (GestureContainer)
	    parentNode.getUserObject();
	  if (canPaste(gt, parent)) {
	    target = parent;
	  }
	}
      }
    }
    return target;
  }
  
  protected boolean canPaste(GestureTransferable t,
			     GestureContainer container)
  {
    boolean result = false;
    Class[] childTypes = container.getChildTypes();
    for (int i = 0; (i < childTypes.length) && !result; i++) {
      if (t.isClassSupported(childTypes[i])) {
	result = true;
      }
    }
    return result;
  }
  
  public void doCommand(int id)
  {
    DefaultMutableTreeNode node;
    GestureContainer container;
    switch (id) {
    case CUT_ACTION:
      doCopy();
      doDelete();
      break;
    case COPY_ACTION:
      doCopy();
      break;
    case DELETE_ACTION:
      doDelete();
      break;
    case PASTE_ACTION:
      doPaste();
      break;
    case NEW_GESTURE_ACTION:
      node = findParent(GestureCategory.class, getSelectionPath());
      container = (GestureContainer) node.getUserObject();
      container.add(new GestureCategory(Gensym.
					next(GESTURE_CATEGORY_PREFIX)));
      break;
    case NEW_GROUP_ACTION:
      node = findParent(GestureGroup.class, getSelectionPath());
      container = (GestureContainer) node.getUserObject();
      container.add(new GestureGroup(Gensym.next(GESTURE_GROUP_PREFIX)));
      break;
    case RENAME_ACTION:
      startEditingAtPath(getSelectionPath());
      break;
    case ENABLE_ACTION:
      GDTUtil.setProperty(getSelectedObjects(), GestureObject.ENABLED_PROP,
			  new Boolean(true));
      break;
    case DISABLE_ACTION:
      GDTUtil.setProperty(getSelectedObjects(), GestureObject.ENABLED_PROP,
			  new Boolean(false));
      break;
    case TEST_RECOGNITION_ACTION:
      // todo
      System.out.println("Not yet implemented");
      break;
   default:
      System.err.println("GestureTree: cannot perform action " + id);
      break;
    }
  }

  /** returns a list of TreePaths where each TreePath is selected and
      none is a descendant or ancestor of any other */
  protected List getTopLevelSelectionPaths()
  {
    TreePath[] selectionPaths = getSelectionPaths();
    List result;
    if (selectionPaths != null) {
      result = new ArrayList();
      for (int i = 0; i < selectionPaths.length; i++) {
	boolean isDescendant = false;
	// go through the ones we've already picked.  If the new one
	// is a descendant of an old one, don't add it.  If the new
	// one is an ancestor of any old ones, remove the old one(s),
	// then add the new one after finding all its descendants.
	for (Iterator iter = result.iterator(); iter.hasNext();) {
	  TreePath oldPath = (TreePath) iter.next();
	  if (oldPath.isDescendant(selectionPaths[i])) {
	    isDescendant = true;
	  }
	  else if (selectionPaths[i].isDescendant(oldPath)) {
	    iter.remove();
	  }
	}
	if (!isDescendant) {
	  result.add(selectionPaths[i]);
	}
      }
    }
    else {
      result = null;
    }
    return result;
  }

  public void doCopy()
  {
    List selectedObjects = getSelectedObjects();
    Clipboard clipboard = GDTClipboard.getClipboard();
    Transferable transferable = new GestureTransferable(selectedObjects);
    clipboard.setContents(transferable, this);
    CommandUtil.fireMenuValidChangeEvent(listenerList,
					 new ChangeEvent(this));
  }
  
  public void doPaste()
  {
    Transferable transferable = GDTClipboard.getClipboard().
      getContents(this);
    GestureContainer target = getPasteTarget(transferable);
    if (transferable.
	isDataFlavorSupported(GestureFlavorFactory.GESTURE_OBJECT_FLAVOR)) {
      // single object
      try {
	GestureObject obj = (GestureObject) transferable.
	  getTransferData(GestureFlavorFactory.GESTURE_OBJECT_FLAVOR);
	target.add(obj);
      }
      catch (UnsupportedFlavorException e) {
	System.err.println("Transferable claimed it supported GESTURE_OBJECT_FLAVOR but it lied");
      }
      catch (IOException e) {
	JOptionPane.showMessageDialog(this, "Could not paste due to I/O error.", "Paste failed", JOptionPane.ERROR_MESSAGE);
      }
    }
    else if (transferable.
	     isDataFlavorSupported(GestureFlavorFactory.
				   GESTURE_OBJECT_COLLECTION_FLAVOR)) {
      // collection of gesture objs
      try {
	Collection collection = (Collection) transferable.
	  getTransferData(GestureFlavorFactory.
			  GESTURE_OBJECT_COLLECTION_FLAVOR);
	for (Iterator iter = collection.iterator(); iter.hasNext();) {
	  GestureObject obj = (GestureObject) iter.next();
	  /*
	  System.out.println("From clipboard: " + obj.toString());
	  */
	  target.add((GestureObject) obj.clone());
	}
      }
      catch (UnsupportedFlavorException e) {
	System.err.println("Transferable claimed it supported GESTURE_COLLECTION_OBJECT_FLAVOR but it lied");
      }
      catch (IOException e) {
	JOptionPane.showMessageDialog(this, "Could not paste due to I/O error.", "Paste failed", JOptionPane.ERROR_MESSAGE);
      }
    }
    else {
      DataFlavor[] flavors = transferable.getTransferDataFlavors();
      System.err.println("ERROR: bad transferable: " +
			 flavors[0].getHumanPresentableName());
    }
  }
  
  public void doDelete()
  {
    List selectionPaths = getTopLevelSelectionPaths();
    for (Iterator iter = selectionPaths.iterator(); iter.hasNext();) {
      TreePath path = (TreePath) iter.next();
      DefaultMutableTreeNode node = (DefaultMutableTreeNode)
	path.getLastPathComponent();
      DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode)
	node.getParent();
      if (parentNode != null) {
	GestureObject userObj = (GestureObject) node.getUserObject();
	GestureContainer container = (GestureContainer)
	  parentNode.getUserObject();
	container.remove(userObj);
      }
    }
  }
  
  /** for ClipboardOwner */
  public void lostOwnership(Clipboard clipboard, Transferable contents)
  {
    // we don't care
  }

  public void addMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.add(ChangeListener.class, listener);
  }

  public void removeMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.remove(ChangeListener.class, listener);
  }

  public boolean canAcceptGesture()
  {
    return getSelectionCount() > 0;
  }

  /** return an int that tells how to handle a gesture */
  protected GestureAcceptor getGestureAcceptor()
  {
    GestureAcceptor result;
    if (getSelectionCount() == 1) {
      GestureObject selection = (GestureObject) getSelectedObject();
      if (selection instanceof GestureCategory) {
	result = addAcceptor;
      }
      else if (selection instanceof Gesture) {
	result = replaceAcceptor;
      }
      else {
	result = recognizeAcceptor;
      }
    }
    else if (getSelectionCount() > 1) {
      result = recognizeAcceptor;
    }
    else {
      result = null;
    }
    return result;
  }
  
  public String getInputGestureTitle()
  {
    return getGestureAcceptor().getInputGestureTitle();
  }
  
  public boolean gestureDrawn(Gesture gesture)
  {
    return getGestureAcceptor().gestureDrawn(gesture);
  }

  //----------------------------------------------------------------------
  // Helper classes
  //
  
  private JTextField textEditWidget = new JTextField();
  class GestureCellEditor extends DefaultCellEditor {
    public GestureCellEditor()
    {
      super(textEditWidget);
    }

    public Component getTreeCellEditorComponent(JTree tree, Object value,
						boolean isSelected,
						boolean expanded,
						boolean leaf, int row)
    {
      String stringValue = tree.convertValueToText(value, isSelected,
						   expanded, leaf, row,
						   false);

      delegate.setValue(stringValue);
      editValue = (GestureContainer) getUserObject(value);
      return editorComponent;
    }

    public Object getCellEditorValue()
    {
      String stringValue = (String) delegate.getCellEditorValue();
      editValue.setName(stringValue);
      return editValue;
    }
  }

  static protected Icon LEAF_ICON = new
    ImageIcon(GestureTree.class.getResource("images/gesture.bm"));
  
  protected class GestureTreeCellRenderer extends DefaultTreeCellRenderer {
    public Font ENABLED_FONT = UIManager.getFont("Tree.font");
    public Font DISABLED_FONT = ENABLED_FONT.deriveFont(Font.ITALIC);
    public Color RECOG_COLOR = Color.green.darker();
    public Color NON_RECOG_COLOR = Color.black;

    public GestureTreeCellRenderer()
    {
      super();
      setLeafIcon(LEAF_ICON);
    }
    
    public Component
      getTreeCellRendererComponent(JTree tree,
				   Object value, boolean sel,
				   boolean expanded, boolean leaf,
				   int row, boolean hasFocus)
    {
      Component result = super.
	getTreeCellRendererComponent(tree, value, sel, expanded, leaf,
				     row, hasFocus);
      boolean isEnabled = true;
      boolean isRecognized = false;
      if (value instanceof DefaultMutableTreeNode) {
	DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
	Object userObj = node.getUserObject();
	if (userObj instanceof GestureObject) {
	  GestureObject gestureObj = (GestureObject) userObj;
	  isEnabled = gestureObj.isEnabled();
	  if ((userObj instanceof GestureContainer) &&
	      ((GestureContainer) userObj).
	      hasProperty(CORRECT_RECOG_PROP)) {
	    isRecognized = true;
	  }
	  if (NoticeHandler.hasNoticesInTree(gestureObj) &&
	      getMainFrame().areNoticesVisible()) {
	    // this cast is based on what we know about
	    // DefaultTreeCellRenderer
	    JLabel label = (JLabel) result;
	    Icon oldIcon;
	    if ((oldIcon = label.getIcon()) == null) {
	      label.setIcon(NoticeHandler.NOTICE_ICON);
	    }
	    else {
	      CompositeIcon newIcon = new CompositeIcon();
	      newIcon.add(oldIcon);
	      newIcon.add(NoticeHandler.NOTICE_ICON);
	      label.setIcon(newIcon);
	    }
	  }
	}
      }
      result.setForeground(isRecognized ? RECOG_COLOR : NON_RECOG_COLOR);
      result.setFont(isEnabled ? ENABLED_FONT : DISABLED_FONT);
      return result;
    }
  }

  protected boolean isWarningHit(TreePath path, int x)
  {
    boolean result = false;
    Object userObj = getLeafUserObject(path);
    if (userObj instanceof GestureObject) {
      GestureObject gestureObj = (GestureObject) userObj;
      if (NoticeHandler.hasNoticesInTree(gestureObj)) {
	Rectangle bounds = getPathBounds(path);
	int delta = x - bounds.x;
	result = (delta > 16) && (delta < 32);
      }
    }
    return result;
  }

  protected Notice getFirstNotice(GestureObject gestureObj)
  {
    Notice result = null;
    if (NoticeHandler.hasNotices(gestureObj)) {
      List notices = (List)
	gestureObj.getProperty(NoticeHandler.NOTICE_LIST_PROP);
      result = (Notice) notices.get(0);
    }
    else if (NoticeHandler.hasNoticesInTree(gestureObj)) {
      List objs = (List)
	gestureObj.getProperty(NoticeHandler.NOTICE_DESCENDENTS_PROP);
      GestureObject obj = (GestureObject) objs.get(0);
      result = getFirstNotice(obj);
    }
    return result;
  }
  
  protected class MyMouseListener extends MouseAdapter {
    public void mouseClicked(MouseEvent e) { 
      TreePath selectedPath =
	  GestureTree.this.getPathForLocation(e.getX(), e.getY());
      if ((selectedPath != null) && getMainFrame().areNoticesVisible() &&
	  isWarningHit(selectedPath, e.getX())) {
	GestureObject gestureObj = (GestureObject)
	  getLeafUserObject(selectedPath);
	Notice firstNotice = getFirstNotice(gestureObj);
	/*
	List notices = (List)
	  gestureObj.getProperty(NoticeHandler.NOTICE_LIST_PROP);
	Notice firstNotice = (Notice) notices.get(0);
	*/
	int position = firstNotice.getPosition().getOffset();
	/*
	System.out.println("Scrolling to " + position + " for " +
			   firstNotice.getName());
	*/
	JTextPane textPane = getMainFrame().getSummaryLog().getTextPane();
	try {
	  Rectangle rect = textPane.modelToView(position);
	  /*
	  System.out.println("\trect = " + rect);
	  */
	  textPane.scrollRectToVisible(rect);
	}
	catch (BadLocationException exception) {
	  System.err.println("WARNING: can't find the notice: " +
			     firstNotice);
	}
      }
      else if (SwingUtilities.isRightMouseButton(e)) {
	if (selectedPath != null) {
	  GestureTree.this.startEditingAtPath(selectedPath);
	}	  
      }
      else if (e.getClickCount() == 2) {
	getMainFrame().showPath(selectedPath);
      }
    } 
  }

  //----------------------------------------------------------------------
  // helper GestureAcceptors

  protected class AddAcceptor implements GestureAcceptor {
    public boolean canAcceptGesture()
    {
      return (getSelectionCount() == 1) &&
	(getSelectedObject() instanceof GestureCategory);
    }
    
    public String getInputGestureTitle()
    {
      return "Draw a gesture to add to the category";
    }
    
    /** return true if the input area should be cleared */
    public boolean gestureDrawn(Gesture g)
    {
      GestureCategory category = (GestureCategory) getSelectedObject();
      g.normalize();
      category.add(g);
      return true;
    }
  }

  protected class ReplaceAcceptor implements GestureAcceptor {
    public boolean canAcceptGesture()
    {
      return (getSelectionCount() == 1) &&
	(getSelectedObject() instanceof Gesture);
    }
    
    public String getInputGestureTitle()
    {
      return "Draw a replacement gesture";
    }
    
    /** return true if the input area should be cleared */
    public boolean gestureDrawn(Gesture g)
    {
      Gesture selectedGesture = (Gesture) getSelectedObject();
      g.normalize();
      selectedGesture.setPoints(g.getPoints());
      return true;
    }
  }

  protected class RecognizeAcceptor implements GestureAcceptor {
    public boolean canAcceptGesture()
    {
      return true;
    }
    
    public String getInputGestureTitle()
    {
      return "Draw a gesture to be recognized";
    }
    
    /** return true if the input area should be cleared */
    public boolean gestureDrawn(Gesture g)
    {
      getMainFrame().recognizeGesture(g);
      return false;
    }
  }
}
