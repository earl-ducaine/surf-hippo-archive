GUIRLib Release 1.5
Jason I. Hong (jasonh@cs.berkeley.edu)
Jun 20, 2003

--------------------------------------------------------------------------------

Java source and class files written by Group for User Interface Research,
UC Berkeley. Please see the copyright in file copyright.txt   .

You can download updates at http://guir.berkeley.edu/projects/guirlib

--------------------------------------------------------------------------------

USING GUIRLIB

There is a pre-built GUIRLib.jar file under distro\GUIRLib.jar

--------------------------------------------------------------------------------

GUIRLIB DIRECTORY STRUCTURE

This describes the general directory structure used for this project.

   - bin       (contains executables, script files)
   - distro    (*.jar files of GUIRLib that can be distributed)
   - lib       (*.jar files required for compilation, currently none)
   - resources (javadoc, bug reports, configuration files, etc)

--------------------------------------------------------------------------------

BUILDING GUIRLIB

Here are the packages you need.

Basics:
   - JDK 1.4 (or better)      (http://java.sun.com)
   - Tomcat 4.1.18 Web Server (http://jakarta.apache.org/tomcat)

And then either:
   - Ant 1.5.1 (or better)    (http://ant.apache.org)
or:
   - Eclipse (optional) 
     Eclipse is an open source IDE for developing Java apps,
     and includes CVS support, including secure communications. 
     See our web page on setting up eclipse for Confab at:
        http://guir.berkeley.edu/internal/howto/eclipse-sourceforge/


INSTALLATION
1. Download and install JDK1.4 or better 
   http://java.sun.com/

   The current implementation of Confab is in Java.

   (I installed mine to c:\jdk)


2. Download and install Jakarta ANT 1.5.1 or better
   http://ant.apache.org/

   ANT is like a Java-based version of 'make'.
   This is used to build the Confab class files.

   (I installed mine to c:\java\ant)


   If you use Eclipse, it compiles Confab class files for you, but you'll
   still want to use ANT to deploy the class files to Tomcat as described
   below.


3. Setup path and classpaths.

   In Win2K and WinXP, you can create environment variables via:
      Control Panel -> System -> Advanced -> Environment Variables

   Create them under "User Variables" rather than "System Variables"
   
   Create a JAVA_HOME environment variable that points to the JDK installation
   (ex if you installed to "c:\jdk", then setup JAVA_HOME=c:\jdk)
   (WinXP and Win2K don't handle spaces in paths very well, so unless
    you know what you are doing, don't install it to "c:\program files\jdk"
    or anyt other path that uses spaces)

   Create a ANT_HOME environment variable that points to ANT

   Add ant's bin directory and Java's bin directory to your path
   (ex if ant was installed to c:\ant and JDK to c:\jdk, then set 
    PATH="%PATH%;c:\jdk\bin;c:\ant\bin")

   Add tools.jar to classpath. This is needed for ant.
   (ex if JDK is in c:\jdk, then setup
    CLASSPATH=%CLASSPATH%;c:\jdk\lib\tools.jar)
   (In WinXP, you can do CLASSPATH=%CLASSPATH%;%JAVA_HOME%\lib\tools.jar,
    but not in Win2K)


5. Now test that everything works.

   Type 'java' and see if Java starts running.
   Type 'ant' and see if ant tries to build (it will say can't find build.xml)


6. Building GUIRLib

   There are a bunch of targets in the build.xml for ant. Here are the
   most important:

      ant            - By itself, it builds the class files
      ant jar        - Builds the class files and the GUIRLib jar file
      ant javadoc    - Builds the javadoc for GUIRLib
      ant clean      - Gets rid of class files, jar files, and javadoc



--------------------------------------------------------------------------------

SKIPPING ANT

If you don't want to install ant, then you can just build the class
files using javac. I haven't tried this, since I use ant, but here are
the steps that should work:

1. Set your classpath to guirlib's src directory

2. Go into the specific directory with the classes you want, 
   ex. src\edu\berkeley\guir\lib\collection

3. Type in javac *.java

4. The class files should have been built in the source directories.




