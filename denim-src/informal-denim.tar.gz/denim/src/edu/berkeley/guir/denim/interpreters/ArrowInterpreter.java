package edu.berkeley.guir.denim.interpreters;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import java.awt.geom.*;
import java.util.*;
import javax.swing.*;

/**
 * Decides whether a stroke should become an arrow.
 * <P>
 * See the notes for handleSingleStroke() to see the rules for determining
 * whether a stroke is an arrow.
 * </P>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-31-1999 MWN
 *                    Created. Actually created a while ago, but it's never
 *                    too late to document your code.
 *             1.0.1  11-21-1999 MWN
 *                    Changed so that strokes starting inside sketches
 *                    are rejected by the arrow interpreter if the sketch
 *                    is not visible.
 *             1.0.2  02-16-2000 JL
 *                    Separated the code for deciding whether a stroke should
 *                    be an arrow into a separate method.
 *             1.0.3  02-28-2000 JL
 *                    Now inherits from DefaultInterpreterImpl
 * 			   1.0.4  01-06-2003 YL
 * 					  Disabled event type editing by holding that causes accidently popup of piemenu
 *             1.0.5  07-07-2003 MR and YL
 *                    Enabled DenimGroup as hyperlink source
 * 
 * </PRE>
 *
 * @see Arrow
 * @author  <A HREF="http://www.cs.berkeley.edu/~newman/">Mark Newman</A> (
 *          <A HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~marcr/">Marc Ringuette</A> (
 *          <A HREF="mailto:marcr@cs.berkeley.edu">marcr@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 1.0.5, 07-07-2003
 */

public class ArrowInterpreter 
   extends    DefaultInterpreterImpl 
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 3154981302567057624L;

   // Constants for handling the popup event selection menu
   // NOTE: To disable the menus, set STILL_TIME to 0!
   //       To enable the menus, set STILL_TIME to a reasonable value like 1000
   static final double UPDATESTROKE_STILL_DIST = 4;
   static final int UPDATESTROKE_STILL_TIME = 1000;

   //===   CONSTANTS   =========================================================
   //===========================================================================

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   // Variables for handling the popup-piemenu for selecting event type
//   private TimedStroke updateStroke;
   private Point2D updateStrokeOldEnd = new Point2D.Double(0,0);
   private Point2D updateStrokeEnd = new Point2D.Double(100,100);
//   private TimedStroke singleStroke;
//   private javax.swing.Timer mouseStillTimer;
//   private EventTypePieMenu eventTypePieMenu = null;
   private Set hyperlinkEvents;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs an ArrowInterpreter.
    */
   public ArrowInterpreter () {
      super();
      setName("Denim Arrow Interpreter");

      DenimComponentRegistry reg = DenimComponentRegistry.getInstance();
      DenimHyperlink hyperlink = ((DenimHyperlink)(reg.getComponent("DenimHyperlink")));
      hyperlinkEvents = hyperlink.getEvents();
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   //===========================================================================
   //===   INNER CLASSES   =====================================================

    /**
     * A timer that determines wether a piemenu should be shown for
     * chosing event type (see EventTypePieMenu)
     */
 /*   class MouseStillAction
      implements ActionListener {
      
      private javax.swing.Timer theTimer;
      private DenimSheet sheet;
      
      public MouseStillAction (javax.swing.Timer aTimer, DenimSheet sheet) {
         super();
         this.sheet = sheet;
         theTimer = aTimer;
      }
      public void actionPerformed(ActionEvent aEvt) {
         // Make sure that is does not fire again for this event
         theTimer.stop();

         // Test if this stroke is really a arrow stroke
         if (updateStroke != null) {
            if (isArrow(updateStroke)) {
               // Send a mouseUp event to finish the stroke
               try {
                  Robot mouseRobot = new Robot() ;
                  mouseRobot.mouseRelease(InputEvent.BUTTON1_MASK);
               } catch (AWTException e) {} 
               
               // Display a menu where the event type can be chosen
               eventTypePieMenu = new EventTypePieMenu(sheet, updateStroke);
               eventTypePieMenu.showAtCursor();
            }
         }
      }
   }
*/
    /**
     * A piemenu that allows the user to select the event type for an arrow 
     * (opened when the mouse is hold still at a destination point)
     */
/*  class EventTypePieMenu
      extends PieMenu
      implements DenimConstants {
      
      private DenimSheet sheet;
      private TimedStroke updateStroke;

      EventTypePieMenu(DenimSheet sheet, TimedStroke updateStroke) {
         super();

         this.sheet = sheet;
         this.addPopupMenuListener(new MenuListener());

         Set evts = getEvents(updateStroke);
         JMenuItem item;
         Iterator it = evts.iterator();
         while (it.hasNext()) {
            String str = (String)it.next();
            item = this.add(formatString(str));
            item.addActionListener(new SelectionListener(this, str));
         }
      }
      
      String formatString(String longString) {
         StringBuffer res = new StringBuffer();
         StringTokenizer st = new StringTokenizer(longString, " ");
         while (st.hasMoreTokens()) {
            res.append(st.nextToken()+"\n");
         }
         
         return new String(res);
      }
      
      class SelectionListener implements ActionListener {
         EventTypePieMenu pieMenu;
         String eventType;
         
         public SelectionListener(EventTypePieMenu pieMenu, String eventType) {
            super();
            this.pieMenu = pieMenu;
            this.eventType = eventType;
         }
         
         public void actionPerformed(ActionEvent evt) {
            if (eventType == DenimIntrinsicComponent.TIMER) {
               // This is a Timer event:
               // We should prompt the user for the delay
               String message = "Please enter the Timer delay (in seconds)";
               int delay = -1;
               while (delay == -1) {
                  String delayStr = JOptionPane.showInputDialog
                     (null, message, "Denim", JOptionPane.QUESTION_MESSAGE);
                  // if (JOptionPane.getValue() != null) 
                  delay = parseTime(delayStr);
               }

               // Encode the delay info the eventType
               // (e.g. Timer:75 for a timer with a 75 seconds delay)
               eventType = eventType + ":" + delay;
            }

            // Handle the stroke
            handleArrowStroke(singleStroke, eventType);
	    singleStroke.delete();
	    ArrowInterpreter.this.getAttachedGraphicalObject().getSheet().damage(DAMAGE_NOW);
	
         }
         
         // Parse the string bdeimeString as seconds
         // Returns -1 if timeString cannot be parsed
         public int parseTime(String timeString) {
            int result = -1;

            try {
               result = Integer.parseInt(timeString);
            } catch (NumberFormatException e) {
            }

            return result;
         }
         
      }
      
      class MenuListener implements PopupMenuListener {
         public void popupMenuCanceled(PopupMenuEvent evt) {
            sheet.remove(singleStroke);
         }
         public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {}
         public void popupMenuWillBecomeVisible(PopupMenuEvent e) {}
      }
      
      void showAtCursor() {
         if (!isShowing()) {
            showNow(sheet, sheet.getLastX(), sheet.getLastY());
         }
      }
   }
*/
   //===   INNER CLASSES   =====================================================
   //===========================================================================

   //===========================================================================
   //===   ARROW METHODS   =====================================================

   /**
    * Given the start point of an arrow in absolute coordinates within the
    * given group, returns the object the start of the arrow should attach
    * itself to, if any.
    * 
    * @param gobgrp     the group which contains the start point
    * @param startPoint the start point of the stroke in absolute
    *                   coordinates
    * @return           the object the start of the arrow should attach
    *                   itself to, or null
    */
   public GraphicalObject getArrowStartAnchor(GraphicalObjectGroup gobgrp,
                                              Point2D startPoint) {
      GraphicalObject           startAnchor = null;
      GraphicalObject           startObj = null;
      GraphicalObject           startObjChild = null;
      GraphicalObject           startObjGrandchild;

      //// 1. Find the panel at the point.
      startObj = DenimUtils.findPanel(gobgrp, startPoint);
      
      //// 2. If it isn't a panel, then ignore it.
      ////    DenimPanels are the only things that contain stuff we're
      ////    interested in.

      if (!(startObj instanceof DenimPanel)) {
         return null;
      }

      //// 3. If we do have a panel, then the next shallowest
      ////    object should either be a label or a sketch.
      startObjChild = DenimUtils.getTopmostComponentContainingAbsPt
         ((DenimPanel)startObj, startPoint);
      
      //// 3.1. If it is a label, then just use the label as the start anchor.
      if (startObjChild instanceof DenimLabel) {
         startAnchor = startObjChild;
      }
      //// 3.2. If it is a sketch, go one level deeper to get the ink.
      else if (startObjChild instanceof DenimSketch) {
         
         //// 3.2.1. But ignore groups containing components first.
         GraphicalObject startObjNotGroup = startObjChild;
         do {
            GraphicalObjectGroup maybeGroupParent =
               (GraphicalObjectGroup)startObjNotGroup;
   
            startObjNotGroup = DenimUtils.getTopmostComponentContainingAbsPt
               (maybeGroupParent, startPoint);
         
         } while (startObjNotGroup instanceof DenimGroup && 
                   !((DenimGroup)startObjNotGroup).getShouldGroupContainedAnchors());
          
         if (startObjNotGroup!=null) {
             startObjGrandchild = DenimUtils.getTopmostComponentAtAbsPtExcept//getNearestComponentAtAbsPtExcept
                   (startObjNotGroup.getParentGroup(), startPoint, Arrow.class);
         } 
         else 
             startObjGrandchild = null;

         //// 3.2.2. If the arrow originates from within the sketch directly...
         if (startObjGrandchild == null ||
             startObjGrandchild instanceof Arrow) {
            startAnchor = startObjChild;
         }
         //// 3.2.3. ...otherwise if the object is not already a 
         ////        component instance, make it a hyperlink.
         else {
            startAnchor = startObjGrandchild;
         }
      }
      else {
         return null;
      }
      
      return startAnchor;
   } // of method
   
   //-----------------------------------------------------------------

   /**
    * Given the end point of an arrow in absolute coordinates within the
    * given group, returns the object the end of the arrow should attach
    * itself to, if any.
    * 
    * @param gobgrp     the group which contains the end point
    * @param endPoint   the end point of the stroke in absolute
    *                   coordinates
    * @return           the object the end of the arrow should attach
    *                   itself to, or null
    */
   public ArrowDest getArrowEndAnchor(GraphicalObjectGroup gobgrp,
                                            Point2D endPoint) {
      //// Get the shallowest object at the end point which is
      //// a panel
      GraphicalObject shallowEndAnchor = DenimUtils.findPanel(gobgrp, endPoint);
      
      if (shallowEndAnchor instanceof DenimPanel) {
         ////  If we did have a panel, then the next shallowest
         ////  object should either be a label or a sketch.
		 GraphicalObject obj = DenimUtils.getTopmostComponentContainingAbsPt
		 			((DenimPanel)shallowEndAnchor, endPoint);
		 if(obj instanceof ArrowDest)		
         	return ((ArrowDest) obj);
         else
         	return null;
      }
      	// else return the custom component at that point or null - if there 
      	// isn't such graphical object at that point
      	else if (gobgrp instanceof DenimCustomComponent){
	  	return ((ArrowDest) gobgrp);
      }
      else{
	  	return null;
      }
     
   } // of method
   
   //-----------------------------------------------------------------

   /**
    * Returns whether the two given graphical objects are in the same
    * panel.
    */
   private boolean isInSamePanel(GraphicalObject startObj, 
                                 ArrowDest endObj) {
       //// 1. If a dangling arrow - then not in same panel.
       if (endObj instanceof DenimCustomComponent){
	   return (false);
       }
      //// 2. endObj should be DenimSketch or DenimLabel, so get its panel.
      DenimPanel endPanel = endObj.getPanel();
      
      //// 3. Check startObj's ancestors to see if any of them is the same
      ////    as endObj's panel.
      GraphicalObject gob = startObj;
      while (gob != null) {
         if (gob == endPanel) {
            return (true);
         }
         gob = gob.getParentGroup();
      }
      return (false);

   } // of method

   //-----------------------------------------------------------------

   /**
    * Returns whether the arrow to add between the two given objects
    * would be either be a navigational arrow or
    * (an organizational arrow and there are no navigational arrows between
    * the two given objects).
    */
   private boolean isNavOrValidOrg(GraphicalObject startObj, 
                                   ArrowDest endObj) {
      if (startObj instanceof DenimLabel || startObj instanceof DenimSketch) {
         DenimPanel panel = (DenimPanel)startObj.getParentGroup();
         Set navArrows = panel.getNavArrowsWithDestPanel(endObj);

         if (navArrows == null) {
            return true;
         }
         else {
            // TODO: flicker the nav arrows that exist
            return false;
         }
      }
      else {
         return true;
      }
   } // of method

   //-----------------------------------------------------------------

/*   public void handleNewStroke(NewStrokeEvent evt) {
      // Create a timer that should fire if the mouse is held still
      // (the timer is controlled in handleUpdateStroke)
      
      if (UPDATESTROKE_STILL_TIME > 0) {
         GraphicalObjectGroup parent = (GraphicalObjectGroup) this.getAttachedGraphicalObject();
         DenimSheet sheet = (DenimSheet)parent.getSheet();
         mouseStillTimer = new javax.swing.Timer(UPDATESTROKE_STILL_TIME, null);
         mouseStillTimer.addActionListener(new MouseStillAction(mouseStillTimer, sheet));
         mouseStillTimer.start();
      }

      eventTypePieMenu = null;
   }

   //-----------------------------------------------------------------

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      if (UPDATESTROKE_STILL_TIME > 0) {
         // Check to see whether the mouse is being hold still
         updateStroke = evt.getStroke();
         updateStrokeEnd = evt.getUntransformedStroke().getEndPoint2D(COORD_ABS);
         if (updateStrokeOldEnd.distance(updateStrokeEnd) > UPDATESTROKE_STILL_DIST) {
            // It has been moved to far: Restart the mouse still timer, and reset position
            mouseStillTimer.restart();
            updateStrokeOldEnd = updateStrokeEnd;
         }
      }
   }
*/
   //-----------------------------------------------------------------

   /**
    * Handle the new stroke: Check if it is an arrow, and create new
    * arrow if so.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      // Cancel the piemenu timer
//      if (UPDATESTROKE_STILL_TIME > 0) {
//         mouseStillTimer.stop();
//      }

      // Initialize state
//      updateStroke = null;
      TimedStroke singleStroke = evt.getStroke();
      
      // Handle stroke (if there isn't a piemenu open)
      if (isArrow(singleStroke)) {
         evt.setConsumed(true);

//         if (eventTypePieMenu == null) {
            // Create an arrow
            handleArrowStroke(singleStroke, DenimIntrinsicComponent.LEFT_CLICK);
//         } else {
            // Re-ad the feedback
//            GraphicalObjectGroup parent = (GraphicalObjectGroup) this.getAttachedGraphicalObject();
//            DenimSheet sheet = (DenimSheet)parent.getSheet();
//            sheet.add(singleStroke);
//         }
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Tests whether aStroke is an arrow.
    * It's an arrow if it starts in a label or a sketch and ends in a panel
    * (i.e., either a label or sketch or a custom component)
    */
   public boolean isArrow(TimedStroke aStroke) {
      GraphicalObjectGroup parent = (GraphicalObjectGroup) this.getAttachedGraphicalObject();
      Point2D         startPoint = aStroke.getStartPoint2D(COORD_ABS);
      Point2D         endPoint   = aStroke.getEndPoint2D(COORD_ABS);
      GraphicalObject startObj   = getArrowStartAnchor(parent, startPoint);
      ArrowDest       endObj     = getArrowEndAnchor(parent, endPoint);
      
      boolean             result = false;

      if (startObj != null) {
         if (endObj instanceof DenimCustomComponent) {
            if (DenimUtils.isInCustomComponent(startObj)) {
               result = true;
            }
         }
         else {
            if (endObj != null){
		if (!isInSamePanel(startObj, endObj) &&
		    isNavOrValidOrg(startObj, endObj)) {
		    result = true;
		}
	    }
         }
      }
      
      return result;
   }

   //-----------------------------------------------------------------

   /**
    * Handle the stroke as a new arrow
    */
   public void handleArrowStroke(TimedStroke stk, String eventType) {
      // Create a new command
      MacroCommand cmd = new MacroCommand();

      // Calc arrow properties
      GraphicalObjectGroup parent = (GraphicalObjectGroup) this.getAttachedGraphicalObject();
      Point2D         startPoint = stk.getStartPoint2D(COORD_ABS);
      Point2D         endPoint   = stk.getEndPoint2D(COORD_ABS);

      GraphicalObject startObj   = getArrowStartAnchor(parent, startPoint);
      ArrowDest       endObj     = getArrowEndAnchor(parent, endPoint);

      String          outputEvent = DenimConstants.DEFAULT_EVENT;

      // taking care of dangling arrow (custom event)
      if ( (startObj != null) &&
	   (endObj instanceof DenimCustomComponent) &&
	   (DenimUtils.isInCustomComponent(startObj)) ){

      	  outputEvent = JOptionPane.showInputDialog
	      (null, "Please enter event name", "Denim", 
	       JOptionPane.QUESTION_MESSAGE);

	  // add the event to the custom component's event list
	  ((DenimCustomComponent) endObj).addEvent(outputEvent);

      }
      // Check validity
      else {

         assert endObj instanceof ArrowDest;
         // "end anchor of arrow must implement ArrowDest, can't be " +
         //             endObj.getClass()
      }
      
      // Transform the arrow from the sheet's coordinate system to the arrow's
      // new parent
      TimedStroke newStk = new TimedStroke(stk);
      newStk.applyTransform(parent.getSheet().getTransform(COORD_REL));
      newStk.applyTransform(parent.getInverseTransform(COORD_ABS));
      
      // Insert the arrow
      InsertArrowCommand acmd = new InsertArrowCommand(parent,
              newStk,
              eventType,
              outputEvent,
              startObj,
              endObj); 
      cmd.addCommand(acmd);
      cmd.addCommand
         (new SetSheetModifiedCommand((DenimSheet)parent.getSheet(), true));
      cmdqueue.doCommand(cmd);
   }

   //-----------------------------------------------------------------

   /**
    * Get the events for the component that has origin in the stroke
    */
   public Set getEvents(TimedStroke stk) {
      Set res = null;

      GraphicalObjectGroup parent = (GraphicalObjectGroup) this.getAttachedGraphicalObject();
      Point2D         startPoint = stk.getStartPoint2D(COORD_ABS);

      GraphicalObject startObj   = getArrowStartAnchor(parent, startPoint);
      
      if (startObj instanceof DenimComponentInstance) {
         DenimComponentInstance componentInstance = (DenimComponentInstance)startObj;
         DenimComponent component = componentInstance.getComponentType();
         res = component.getEvents();
      } else {
         res = hyperlinkEvents;
      }

      return res;
   }

   //===   ARROW METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Returns a nice name for the interpreter.
    */
   public String getName() {
      return new String("ArrowInterpreter");
   }

   //-----------------------------------------------------------------

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      return new ArrowInterpreter(); // nothing to clone
   }

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 1999 - 2001 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
