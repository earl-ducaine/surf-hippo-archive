//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter.commands;
 
import java.awt.event.*;
import java.util.EventObject;
import javax.swing.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.stroke.*;

/**
 * Hold and hold on a GraphicalObject to select.
 * By default accepts left button only.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jun 27 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.0.1, Nov 21 2000 JH
 *               Fixed the filter check to use distance relative from start
 *               rather than total length.
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class HoldSelectInterpreter 
   extends AbstractSelectInterpreter {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 1209384023928599658L;
   public static final int holdTimeForSelect = 1000; // ms

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INNER CLASS TIMER CALLBACK   ========================================

   /**
    * The timer for hold-select.
    */
   class HoldSelectAction extends AbstractAction {
      int holdStrokeNum;

      public HoldSelectAction(int num) {
         setHoldStrokeNum(num);
      } // of constructor

      public void actionPerformed(ActionEvent evt) {
         if (holdStrokeNum == curStrokeNum) {
            isHold = true;
            
            selectClosestGob(lastEvt);
 
         }
      } // of method

      /**
       * Which stroke number to look for.
       */
      public void setHoldStrokeNum(int num) {
         holdStrokeNum = num;
      } // of method

   } // of inner class

   //===   INNER CLASS TIMER CALLBACK   ========================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   protected javax.swing.Timer timer;             // timer for tapping / holding
   protected boolean           isHold;            // true if holding button down
   protected boolean           isConsumingEvents; // true if we are consuming
   protected boolean           didToggle;         // true if an object was
                                                  // selected or unselected
   protected StrokeEvent       lastEvt;           // last event sent to us
   protected int               curStrokeNum = 0;  // which stroke num we are on
   protected HoldSelectAction  holdAction;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public HoldSelectInterpreter() {
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      //// 1. Set up name and events handled.
      setName("Hold Select Interpreter");

      //// 2. Set up the timer.
      timer      = new javax.swing.Timer(holdTimeForSelect, new HoldSelectAction(0));
      timer.setRepeats(false);
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   SELECT METHODS   ====================================================

   /**
    * Select the closest graphical object. This is the method called by the
    * Timer, so override this method if you want additional behavior.
    *
    * @param  lastEvent is the last stroke event that occurred.
    * @return true if we selected something, false otherwise.
    */
   protected boolean selectClosestGob(StrokeEvent lastEvent) {
      //// 1. If the length is too long, it's not a tap.
      TimedStroke stk = lastEvent.getStroke();
      
      if (!StrokeLib.isTap(stk)) {
         return (false);
      }
      
      //// 2. Get the select candidates.
      GraphicalObjectCollection gobcol = getCandidates(stk);
      GraphicalObject           selgob = getSelectCandidate(gobcol);

      //// 3. Select or deselect.
      boolean flagSelected = false;
      if (selgob != null) {
         flagSelected = toggleSelectGraphicalObject(selgob);
         didToggle = true;
         isConsumingEvents = true;
      }

      //// 4. Return whether we selected something or not.
      return (flagSelected);
   } // of method

   //===   SELECT METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   STROKE EVENT METHODS   ==============================================

   public boolean isEventAccepted(StrokeEvent evt) {
      boolean flag = super.isEventAccepted(evt);

      if (flag == false) {
         curStrokeNum++;
      }
      return (flag);
   } // of method


   public boolean isEventAccepted(EventObject evt) {
      boolean flag = super.isEventAccepted(evt);

      if (flag == false) {
         curStrokeNum++;
      }
      return (flag);
   } // of method

   //-----------------------------------------------------------------

   public void handleNewStroke(NewStrokeEvent evt) {
      //// 0. Increment the stroke count.
      curStrokeNum++;

      //// 1. Store last event.
      lastEvt           = evt;

      //// 2. Reset values for holding.
      isHold            = false;
      isConsumingEvents = false;
      didToggle         = false;

      //// 3. Start your engines!
      timer.removeActionListener(holdAction);
      holdAction = new HoldSelectAction(curStrokeNum);
      timer.addActionListener(holdAction);
      timer.start();
   } // of method

   //-----------------------------------------------------------------

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      //// 1. Store last event.
      lastEvt = evt;

      //// 2. Consume event if we are consuming.
      if (isConsumingEvents == true) {
         evt.setConsumed(true);
      }
   } // of method

   //-----------------------------------------------------------------

   public void handleSingleStroke(SingleStrokeEvent evt) {
      //// 1. Store last event.
      lastEvt = evt;

      //// 2. Stop the holding.
      timer.stop();

      //// 3. If we did hold, then consume the event.
      if (isHold == true && didToggle == true) {
         evt.setShouldRender(false);
      }
      if (isConsumingEvents == true) {
         evt.setConsumed(true);
         
         //// 3.1. Force a final, higher quality image rendering.
         getAttachedGraphicalObject().damage(DAMAGE_NOW);
      }
   } // of method

   //===   STROKE EVENT METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (new HoldSelectInterpreter());
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
