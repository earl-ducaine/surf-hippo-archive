package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;

/** 
 * An event that indicates that an interaction element has been moved
 * or its content has been updated.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-08-2003 James Lin
 *                               Created InteractionElementContainerEvent
 *                    08-13-2003 James Lin
 *                               Renamed to ElementContainerEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-08-2003
 */
public class ElementContainerEvent extends EventObject {
   
   private final Type eventType;
   private final DeviceType deviceType;
   private final int index;
   private final InteractionElement element;
   
   public static final int UNKNOWN_INDEX = -1;
   
   //===========================================================================

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type ADDED = new Type("interaction element added");

   public static final Type REMOVED = new Type("interaction element removed");

   //===========================================================================

   /**
    * Constructs a ElementContainerEvent, which gets fired when
    * an InteractionElement is added or removed from a container.
    * 
    * @param source the component group that was cloned 
    * @param origToClone a map that maps the original object to its clone.
    * The keys in the map must be the original group that was cloned and all
    * of its children.
    */
   public ElementContainerEvent(
      final Object source,
      final Type eventType,
      final DeviceType deviceType,
      final int index,
      final InteractionElement element) {

      super(source);
      this.eventType = eventType;
      this.deviceType = deviceType;
      this.index = index;
      this.element = element;
   }
   
   //===========================================================================

   /**
    * Returns the interaction element that was added or removed.
    */
   public InteractionElement getElement() {
      return element;
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the device type affected by the event.
    */
   public DeviceType getDeviceType() {
      return deviceType;
   }

   //===========================================================================
   
   /**
    * Returns the index of the element affected by the event.
    */
   public int getIndex() {
      return index;
   }
}
