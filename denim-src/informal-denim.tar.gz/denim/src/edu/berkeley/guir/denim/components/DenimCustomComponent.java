//==============================================================================
//===   DenimCustomComponent.java   ============================================

package edu.berkeley.guir.denim.components;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.denim.interpreters.*;
import edu.berkeley.guir.denim.toolbox.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.util.*;
import edu.berkeley.guir.lib.debugging.Debug;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.Iterator;
import java.util.*;

/**
 * A DENIM component that has been defined by the user. A custom component is
 * created by selecting the panels that the user wants as the definition of the
 * component and then tapping the
 * {@link edu.berkeley.guir.denim.toolbox.BlankRubberStamp blank rubber stamp}
 * on them. Each custom component type is a separate instance of
 * DenimCustomComponent.
 * 
 * <P>
 * This software is distributed under the <A
 * HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt"> Berkeley Software
 * License </A>.
 * 
 * <PRE>
 * 
 * Revisions: 1.0.0 08-05-1999 James Lin Created DenimCustomComponent
 *            2.0.0 08-11-2004 Yang Li added a new constructor
 * 
 * 
 * </PRE>
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin </A>( <A
 *         HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu </A>)
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since JDK 1.2
 * @version Version 2.0.0, 08-11-2004
 */
public class DenimCustomComponent extends DenimComponent implements Resizable,
        DenimConstants, ArrowDest {

    //===========================================================================
    //=== CONSTANTS =========================================================

    static final long serialVersionUID = 5034282253810134121L;

    //=== CONSTANTS =========================================================
    //===========================================================================

    //===========================================================================
    //=== NONLOCAL VARIABLES ================================================

    private DenimPanel leftMostPanel; // a reference to the left most panel

    // in the component definition
    // this is the "first" panel by default
    private HashMap incomingArrows; // keeps track of incoming arrows

    //private Patch storyboard;

    //=== NONLOCAL VARIABLES ================================================
    //===========================================================================

    //===========================================================================
    //=== CONSTRUCTORS ======================================================

    /**
     * Creates a new custom component with the given name and rubber stamp icon.
     * No behavior is defined for this component.
     */
    DenimCustomComponent(String newName, Icon stampIcon) {
        this(newName, stampIcon, null);
    }

    //-----------------------------------------------------------------

    /**
     * Creates a new custom component with the given rubber stamp icon, and
     * behavior determined by the given collection of panels. A name is
     * generated automatically.
     */
    public DenimCustomComponent(Icon stampIcon,
            GraphicalObjectCollection storyboard) {
        this(null, stampIcon, storyboard);
    }

    //-----------------------------------------------------------------

    private void addGobToMacroCommand(GraphicalObject gob, int selobjx,
            int selobjy, MacroCommand macro) {
        GraphicalObjectGroup oldParent = gob.getParentGroup();

        Point2D pt = gob.getLocation2D(COORD_REL);

        macro.addCommand(new SetLocationCommand(gob, pt.getX() - selobjx
                + DEFAULT_GUTTER_WIDTH, pt.getY() - selobjy
                + DEFAULT_GUTTER_HEIGHT));

        macro.addCommand(new RemoveCommand(oldParent, gob));
        macro.addCommand(new InsertCommand(this, gob,
                GraphicalObjectGroup.KEEP_REL_POS));
    }

    //-----------------------------------------------------------------

    /**
     * Creates a new custom component with the given name, rubber stamp icon,
     * and behavior determined by the given collection of panels.
     */
    public DenimCustomComponent(String newName, Icon stampIcon,
            GraphicalObjectCollection storyboard) {
        super();

        incomingArrows = new HashMap();

        Style style = getStyleRef();
        style.setDrawColor(DEFAULT_COMPONENT_COLOR);
        style.setFillColor(DEFAULT_COMPONENT_COLOR);

        MacroCommand macro = new MacroCommand();

        int smallestX = Integer.MAX_VALUE;

        name = newName;
        //stamp = new RubberStamp(stampIcon, this);
        stamp = null;

        Rectangle2D bounds = storyboard.getCollectionBounds2D(COORD_REL);
        bounds.setRect(bounds.getX(), bounds.getY(), bounds.getWidth() + 2
                * DEFAULT_GUTTER_WIDTH, bounds.getHeight() + 2
                * DEFAULT_GUTTER_HEIGHT);

        this.setBoundingPoints2D(COORD_REL, bounds);
        storyboard.sort(new LayerComparator());

        if (storyboard != null) {
            int selobjx = (int) storyboard.getCollectionBounds2D(COORD_REL)
                    .getX();
            int selobjy = (int) storyboard.getCollectionBounds2D(COORD_REL)
                    .getY();

            //Debug.println("grabbing: rel - " +
            // storyboard.getCollectionBounds());
            Iterator iterator = storyboard.getReverseIterator();

            while (iterator.hasNext()) {
                GraphicalObject gob = (GraphicalObject) iterator.next();

                // only add DenimPanels and Arrows to components
                if ((gob instanceof DenimPanel) || (gob instanceof Arrow)) {
                    addGobToMacroCommand(gob, selobjx, selobjy, macro);

                    if (gob instanceof DenimPanel) {
                        // add panel to set of possible states
                        states.add(gob);
                        if ((leftMostPanel == null)
                                || (gob.getBounds().x < smallestX)
                                || ((gob.getBounds().x == smallestX) && (gob
                                        .getBounds().y < leftMostPanel
                                        .getBounds().y))) {
                            leftMostPanel = (DenimPanel) gob;
                            smallestX = gob.getBounds().x;
                        }
                    } else { // if gob is an arrow
                        addGobToMacroCommand(((Arrow) gob).getOrigStroke(),
                                selobjx, selobjy, macro);
                    }
                }
            }
        }

        Debug.println("macro before: " + macro);
        RegisterComponentCommand regCmd = new RegisterComponentCommand(this);
        Debug.println("adding: " + regCmd);
        macro.addCommand(regCmd);
        Debug.println("macro after: " + macro);

        Arrow.setIgnoreEndpointMove(true);
        Debug.println("executing: " + macro);
        cmdqueue.doCommand(macro);
        Arrow.setIgnoreEndpointMove(false);

        this.setInkInterpreter(new ArrowInterpreter());

        this.getStyleRef().setFillColor(new Color(0, 0, 0, 0));

        //// Add close button
        /*
         * JButton closeButton = new JButton("X"); closeButton.setBounds(0, 0,
         * 30, 30);
         * 
         * GObJComponentWrapper closeButtonGob = new
         * GObJComponentWrapper(closeButton);
         * closeButtonGob.setLocation(this.getWidth() - 5, 5);
         * this.add(closeButtonGob);
         */
        Debug.println("Just created: " + this.getName());
    }

    //////////////////////////////////////////////////////////////////////////
    // using cut and paste command
    //////////////////////////////////////////////////////////////////////////
/*
    public DenimCustomComponent(String newName,
            GraphicalObjectCollection storyboard) {

        super();
        incomingArrows = new HashMap();

        Style style = getStyleRef();
        style.setDrawColor(DEFAULT_COMPONENT_COLOR);
        style.setFillColor(DEFAULT_COMPONENT_COLOR);

        MacroCommand macro = new MacroCommand();

        int smallestX = Integer.MAX_VALUE;

        name = newName;
        stamp = null;
        
        Rectangle2D bounds = storyboard.getCollectionBounds2D(COORD_REL);
        bounds.setRect(bounds.getX(), bounds.getY(), bounds.getWidth() + 2
                * DEFAULT_GUTTER_WIDTH, bounds.getHeight() + 2
                * DEFAULT_GUTTER_HEIGHT);

        this.setBoundingPoints2D(COORD_REL, bounds);
        storyboard.sort(new LayerComparator());

        if (storyboard != null) {
            int selobjx = (int) storyboard.getCollectionBounds2D(COORD_REL)
                    .getX();
            int selobjy = (int) storyboard.getCollectionBounds2D(COORD_REL)
                    .getY();
            Iterator iterator = storyboard.getReverseIterator();
            while (iterator.hasNext()) {
                GraphicalObject gob = (GraphicalObject) iterator.next();

                // only add DenimPanels and Arrows to components
                if ((gob instanceof DenimPanel) || (gob instanceof Arrow)) {
                    //addGobToMacroCommand(gob, selobjx, selobjy, macro);
                    if (gob instanceof DenimPanel) {
                        // add panel to set of possible states
                        states.add(gob);
                        if ((leftMostPanel == null)
                                || (gob.getBounds().x < smallestX)
                                || ((gob.getBounds().x == smallestX) && (gob
                                        .getBounds().y < leftMostPanel
                                        .getBounds().y))) {
                            leftMostPanel = (DenimPanel) gob;
                            smallestX = gob.getBounds().x;
                        }
                    } else { // if gob is an arrow
                        //addGobToMacroCommand(((Arrow) gob).getOrigStroke(),
                        //        selobjx, selobjy, macro);
                    }
                }
            }
        }

        Iterator it = storyboard.getForwardIterator();
        DenimCutCommand cutcmd = new DenimCutCommand(it);
        macro.addCommand(cutcmd);

        DenimPasteCommand pastecmd = new DenimPasteCommand(this, DEFAULT_GUTTER_WIDTH, DEFAULT_GUTTER_HEIGHT);
        macro.addCommand(pastecmd);

        RegisterComponentCommand regCmd = new RegisterComponentCommand(this);
        macro.addCommand(regCmd);

        GraphicalObjectGroup parent = storyboard.getFirst().getParentGroup();
        parent.add(this);

        cmdqueue.doCommand(macro);
        
        parent.remove(this);

        this.setInkInterpreter(new ArrowInterpreter());
        this.getStyleRef().setFillColor(new Color(0, 0, 0, 0));
    }
*/
    //=== CONSTRUCTORS ======================================================
    //===========================================================================

    public ArrayList getStatesRef() {
        return states;
    }
    
    public void update(GraphicalObjectCollection storyboard) {
        
        //ArrayList oldStates = (ArrayList)states.clone();
        
        this.states.clear();//HashSet();
        this.supportedEvents.clear();
        this.incomingArrows.clear();
        
        this.clear();

        MacroCommand macro = new MacroCommand();

        int smallestX = Integer.MAX_VALUE;

        Rectangle2D bounds = storyboard.getCollectionBounds2D(COORD_REL);
        bounds.setRect(bounds.getX(), bounds.getY(), bounds.getWidth() + 2
                * DEFAULT_GUTTER_WIDTH, bounds.getHeight() + 2
                * DEFAULT_GUTTER_HEIGHT);

        this.setBoundingPoints2D(COORD_REL, bounds);
        storyboard.sort(new LayerComparator());

        if (storyboard != null) {
            int selobjx = (int) storyboard.getCollectionBounds2D(COORD_REL)
                    .getX();
            int selobjy = (int) storyboard.getCollectionBounds2D(COORD_REL)
                    .getY();

            //Debug.println("grabbing: rel - " +
            // storyboard.getCollectionBounds());
            Iterator iterator = storyboard.getReverseIterator();

            while (iterator.hasNext()) {
                GraphicalObject gob = (GraphicalObject) iterator.next();

                // only add DenimPanels and Arrows to components
                if ((gob instanceof DenimPanel) || (gob instanceof Arrow)) {
                    addGobToMacroCommand(gob, selobjx, selobjy, macro);

                    if (gob instanceof DenimPanel) {
                        // add panel to set of possible states
                        states.add(gob);
                        if ((leftMostPanel == null)
                                || (gob.getBounds().x < smallestX)
                                || ((gob.getBounds().x == smallestX) && (gob
                                        .getBounds().y < leftMostPanel
                                        .getBounds().y))) {
                            leftMostPanel = (DenimPanel) gob;
                            smallestX = gob.getBounds().x;
                        }
                    } else { // if gob is an arrow
                        addGobToMacroCommand(((Arrow) gob).getOrigStroke(),
                                selobjx, selobjy, macro);
                    }
                }
            }
        }

        Arrow.setIgnoreEndpointMove(true);
        cmdqueue.doCommand(macro);
        Arrow.setIgnoreEndpointMove(false);
        
        Iterator it = instances.iterator();
        while(it.hasNext())
        {
            DenimCustomComponentInstance ins = (DenimCustomComponentInstance)it.next();
            /*int index = oldStates.indexOf(ins.getDisplayedState());
            if(index==-1)
                index = 0;
                */
            Iterator sit = states.iterator();
            boolean found = false;
            while(sit.hasNext())
            {
                DenimPanel p = (DenimPanel)sit.next();
                if(p.getStateID()==((DenimPanel)ins.getDisplayedState()).getStateID())
                {
                    ins.setDisplayedState(p);
                    found = true;
                    break;
                }
            }
            
            if(found==false)
            {
                System.err.println("Cannot find right state, assign a default state");
                ins.setDisplayedState((GraphicalObject)this.states.get(0));
            }
                //ins.setDisplayedState((GraphicalObject)this.states.get(index));
        }
        
        //oldStates.clear();
    }
    
    //-----------------------------------------------------------------

    /**
     * Sets the name of the custom component type to the given name.
     */
    public void setName(String newName) {
        super.setName(newName);

        if (stamp != null) {
            stamp.setName(newName);
        }
    }

    //-----------------------------------------------------------------

    /**
     * Creates a new instance of this custom component.
     */
    public DenimComponentInstance newInstance() {
        return new DenimCustomComponentInstance(this);
    }

    //-----------------------------------------------------------------

    public boolean isIntrinsic() {
        return false;
    }

    //-----------------------------------------------------------------

    /**
     * Returns the left most panel of the component. This is important because
     * when an instance of this component is first created, the instance shows
     * the left most panel.
     * 
     * Called only by DenimCustomComponentInstance().
     */
    public DenimPanel getLeftMostPanel() {
        return leftMostPanel;
    }

    //-----------------------------------------------------------------

    /**
     * Returns the fact that the contents of this component should not be
     * stretched when its patch is resized.
     */
    public boolean isStretchedWhenResized() {
        return false;
    }

    //-----------------------------------------------------------------

    //===========================================================================
    //=== ARROW DEST METHODS ================================================

    public DenimPanel getPanel() {
        return null;
    } // of method

    //-----------------------------------------------------------------

    public void trackIncomingArrow(Arrow arrow) {
        GraphicalObject source = arrow.getSource();
        incomingArrows.put(source, arrow);
    } // of method

    //-----------------------------------------------------------------

    public void untrackIncomingArrow(Arrow arrow) {
        incomingArrows.remove(arrow.getSource());
    } // of method

    //-----------------------------------------------------------------

    public Set getIncomingArrows() {
        return new HashSet(incomingArrows.values());
    }

    //-----------------------------------------------------------------

    public boolean hasIncomingArrow(Arrow arrow) {
        return incomingArrows.containsKey(arrow.getSource());
    } // of method

    //=== ARROW DEST METHODS ================================================
    //===========================================================================
    //----------------------------------------

    /**
     * clear all references hold by this object (In the namespace of this class)
     */

    public void deepClear() {
        super.deepClear();
        leftMostPanel = null;

        if (incomingArrows != null) {
            incomingArrows.clear();
            incomingArrows = null;
        }
    }
} // of class

//==============================================================================

/*
 * Copyright (c) 1999 - 2001 Regents of the University of California. All rights
 * reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. All advertising materials mentioning features or use of this software must
 * display the following acknowledgement:
 * 
 * This product includes software developed by the Group for User Interface
 * Research at the University of California at Berkeley.
 * 
 * 4. The name of the University may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
