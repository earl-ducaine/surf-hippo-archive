package edu.berkeley.guir.damask.view.voice.component;

import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.DamaskLayer;
import edu.berkeley.guir.damask.view.voice.VoiceLayer;

/** 
 * A view of a Damask control.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  08-15-2004 James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public abstract class VoiceControl extends VoiceComponent {
   private Prompt prompt;
   private Map/*<Integer, Response>*/ responses =
      new HashMap/*<Integer, Response>*/();
   
   /**
    * Creates a view of the specified control.
    */
   protected VoiceControl(final Control model) {
      super(model);
      setStrokePaint(null);
      setResizable(false);
   }

   // @Override
   public void dispose() {
      super.dispose();

      if (prompt != null) {
         prompt.removeFromParent();
         prompt.dispose();
      }

      for (Iterator i = responses.values().iterator(); i.hasNext(); ) {
         final Response response = (Response)i.next();
         if (response != null) {
            response.removeFromParent();
            response.dispose();
         }
      }
   }

   /**
    * Returns the prompt associated with this control.
    */
   public Prompt getPrompt() {
      return prompt;
   }
   
   /**
    * Sets the prompt associated with this control.
    */
   protected void setPrompt(final Prompt prompt) {
      if (this.prompt != null) {
         this.prompt.removeFromParent();
      }
      this.prompt = prompt;
      if (this.prompt != null) {
         addChild(0, prompt);
      }
   }
   
   /**
    * Returns the response associated with this control and the
    * specified condition.
    */
   public Response getResponse(final int condition) {
      return (Response)responses.get(new Integer(condition));
   }
   
   /**
    * Sets the response associated with this control and the
    * specified condition.
    */
   protected void setResponse(final int condition, final Response response) {
      final Response oldResponse = getResponse(condition);
      if (oldResponse != null) {
         oldResponse.removeFromParent();
      }
      responses.put(new Integer(condition), response);
      if (response != null) {
         addChild(response);
      }
      final DamaskLayer layer = getLayer();
      if (layer != null) {
         if (oldResponse != null) {
            layer.removeSelectableParent(oldResponse);
         }
         if (response != null) {
            layer.addSelectableParent(response);
         }
      }
   }


   /**
    * Adjusts the transparency of the specified prompt, depending on
    * what its device type is and what the current device-type layer is. 
    */
   public void deviceTypeLayerChanged() {
      if (prompt != null) {
         prompt.deviceTypeLayerChanged();
      }
      for (Iterator i = responses.values().iterator(); i.hasNext(); ) {
         final Response response = (Response)i.next();
         response.deviceTypeLayerChanged();
      }
   }
}
