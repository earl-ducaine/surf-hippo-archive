//// See bottom of source code for software license.
package edu.berkeley.guir.lib.debugging.introspect;

import java.lang.reflect.Field;

/**
 * Callback for Java object introspection traversal. 
 *
 * <P>
 * Unfortunately, this class requires JDK1.3, because it uses the 
 * {@link java.lang.reflect.Modifier} class to access values outside of 
 * our access scope.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @see Introspect#parseObject(Object, IntrospectHandler)
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
public abstract class IntrospectHandler 
   implements IntrospectConstants {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   IntrospectFilter filter;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public IntrospectHandler() {
   } // of constructor

   //-----------------------------------------------------------------

   public IntrospectHandler(IntrospectFilter newFilter) {
      setFilter(newFilter);
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   FILTER METHODS   ====================================================

   /**
    * Set the current filter.
    *
    * @param newFilter is null to clear out the current filter.
    */
   public void setFilter(IntrospectFilter newFilter) {
      filter = newFilter;
   } // of method

   /**
    * Get the current filter.
    *
    * @return the current IntrospectFilter, or null if there is none.
    */
   public IntrospectFilter getFilter() {
      return (filter);
   } // of method

   //===   FILTER METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   INTROSPECTION CALLBACK METHODS   ====================================

   /**
    * Start traversal.
    */
   public void onRoot(Object obj) {
   } // of method

   /**
    * @param depth is the depth of the node in the tree.
    * @param f     is the Field information, and is null for the start object.
    * @param obj   is the object value, which may or may not be null.
    */
   public void onObject(int depth, Field f, Object obj) {
   } // of method

   /**
    * @param depth is the depth of the node in the tree.
    * @param f     is the Field information, and is null for the start object.
    * @param arr   is the array, which may or may not be null.
    */
   public void onArray(int depth, Field f, Object arr) {
   } // of method

   /**
    * Rather than calling onObject or onArray, calls this if value is null.
    */
   public void onNull(int depth, Field f) {
   } // of method

   //-----------------------------------------------------------------

   public void onBoolean(int depth, Field f, boolean val) { }
   public void onChar(int depth, Field f, char val) { }
   public void onByte(int depth, Field f, byte val) { }
   public void onShort(int depth, Field f, short val) { }
   public void onInt(int depth, Field f, int val) { }
   public void onLong(int depth, Field f, long val) { }
   public void onFloat(int depth, Field f, float val) { }
   public void onDouble(int depth, Field f, double val) { }

   //-----------------------------------------------------------------

   /**
    * Error in processing.
    */
   public void onException(int depth, Field f, Exception e) {
      e.printStackTrace();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Should return the correct
    * value as to whether we should recurse on this object.
    *
    * @return true if no filter, otherwise re-dispatches to filter.
    */
   public boolean shouldRecurse(int depth, Field f, Object obj) {
      if (filter != null) {
         return (filter.shouldRecurse(depth, f, obj));
      }
      return (true);
   } // of method

   /**
    * Accept this field or not?
    *
    * @return true if no filter, otherwise re-dispatches to filter.
    */
   public boolean acceptField(int depth, Field f, Object obj) {
      if (filter != null) {
         return (filter.acceptField(depth, f, obj));
      }
      return (true);
   } // of method

   //===   INTROSPECTION CALLBACK METHODS   ====================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
