//// See bottom of file for software license
package edu.berkeley.guir.lib.swing.dialog;

import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * Libraries for dialog boxes.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Mar 22 2004 JIH
 */
public class DialogLib {

    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    private DialogLib() {
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   DIALOG HELPERS   ===================================================

    public static int showConfirmHelper(JOptionPane pane,
                                        String      strTitle,
                                        Icon        iconRightSide) {

        //// 1. Throw into a dialog box. Use this approach rather
        ////    than JOptionPane b/c we want to have the image on the side.
        JDialog   dialog  = pane.createDialog(null, strTitle);
        Container pCenter = dialog.getContentPane();
        JPanel    p       = new JPanel(new BorderLayout());

        p.add(pCenter, BorderLayout.CENTER);
        p.add(new JLabel(iconRightSide), BorderLayout.EAST);
        p.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        //// 2. Show the dialog.
        dialog.setContentPane(p);
        dialog.pack();
        dialog.show();

        //// 3.
        Object   selectedValue = pane.getValue();
        Object[] options       = pane.getOptions();

        if(selectedValue == null) {
            return JOptionPane.CLOSED_OPTION;
        }
        if( options == null) {
            if(selectedValue instanceof Integer) {
                return ((Integer)selectedValue).intValue();
            }
            return JOptionPane.CLOSED_OPTION;
        }
        for(int counter = 0, maxCounter = options.length;
            counter < maxCounter; counter++) {
            if(options[counter].equals(selectedValue))
                return counter;
        }
        return JOptionPane.CLOSED_OPTION;
    } // of method

    //===   DIALOG HELPERS   ===================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static void main(String[] argv) {

    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
