//// See bottom of file for software license
package edu.berkeley.guir.lib.swing.list;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

/**
 * Special renderer for Rows, an inner class defined here.
 * This renderer can be used for displaying things in a JList or
 * JComboBox with each column aligned properly.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 06 2004
 */
public class TableListCellRenderer
    extends DefaultListCellRenderer {

    //==========================================================================
    //===   INNER CLASS - LIST DATA LISTENER   =================================

    /**
     * Listen for changes to the JList.
     */
    class InternalListDataListener implements ListDataListener {
        public void contentsChanged(ListDataEvent evt) {
            updateTable();
        } // of method

        public void intervalAdded(ListDataEvent evt) {
            updateTable();
        } // of method

        public void intervalRemoved(ListDataEvent evt) {
            updateTable();
        } // of method
    } // of inner class

    //===   INNER CLASS - LIST DATA LISTENER   =================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    //// The JList we are rendering. Keep a ref so we can tell if it 
    //// has changed or not, so we can cache our results.
    JList            list;
    ListDataListener lstnr = new InternalListDataListener();

    //----------------------------------------------------------------

    Row[]            table;
    int[]            widths;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   RENDERING METHODS   ================================================

    protected static Row[] createTable(ListModel model) {
        Row[] table = new Row[model.getSize()];

        for (int i = 0; i < model.getSize(); i++) {
            table[i] = (Row) model.getElementAt(i);
        }
        return (table);
    } // of method

    //----------------------------------------------------------------

    /**
     * Update the cached versions of the String[][] table and widths.
     */
    protected void updateTable() {
        if (list.getModel().getSize() > 0) {
            try {
                table  = createTable(list.getModel());
                widths = ListLib.calcWidths(table);
            }
            catch (Exception e) {
                table  = null;
                widths = null;
            }
        }
        else {
            table  = null;
            widths = null;
        }
    } // of method

    //--------------------

    /**
     * Update what JList we are rendering. If it changes, then update our 
     * cached table and widths (see {@link #updateTable()}). Also add a
     * listener to automatically update our cached copy if any change occurs.
     */
    protected void updateJList(JList aList) {
        if (aList == list) {
            // do nothing
        }
        else {
            //// 1. Remove the listener from the old JList
            if (list != null) {
                list.getModel().removeListDataListener(lstnr);
            }

            //// 2. Add the listener to the new JList
            list = aList;
            list.getModel().addListDataListener(lstnr);

            //// 3. Update the cached table and widths
            updateTable();
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a single row to display.
     */
    protected JPanel createRow(JList list, int rowIndex) {
        //// 1. Update the list and cached data if needed.
        updateJList(list);

        //// 2. Lots of setup in terms of GUI and figuring out widths
        ////    so that things will be aligned properly.
        ListModel  model  = list.getModel();
        JPanel     p      = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
        Row        row    = (Row) model.getElementAt(rowIndex);
        JLabel     lbl;
        Dimension  dim;

        //// 3. For each col in the specified row...
        for (int i = 0; i < row.numCols(); i++) {
            //// 3.1. Create a label and add it to a panel.
            lbl = new JLabel(row.get(i).toString());
            lbl.setFont(list.getFont());
            p.add(lbl);

            //// 3.2. Fix the size of the label so that every 
            ////      label in the same column is the same width.
            if (row.isIgnoredForWidthCalculations() == false) {
                dim = lbl.getPreferredSize();
                dim.setSize(widths[i] + 3, dim.getHeight());
                lbl.setMinimumSize(dim);
                lbl.setPreferredSize(dim);
            }
        }

        //// 4. Done, return the containing panel.
        p.invalidate();
        return (p);
    } // of method

    //----------------------------------------------------------------

    public Component getListCellRendererComponent(JList   list,
                                                  Object  value,
                                                  int     index,
                                                  boolean isSelected,
                                                  boolean cellHasFocus) {
        ListModel  model = list.getModel();
        Object     obj   = model.getElementAt(index);
        JComponent comp;

        //// 1.1. Render a String[]...
        if (obj instanceof SeparatorRow) {
            return (SeparatorRow.JSEPARATOR);
        }
        if (obj instanceof Row) {
            comp = createRow(list, index);
            if (isSelected == true) {
                comp.setForeground(list.getSelectionForeground());
                comp.setBackground(list.getSelectionBackground());
            }
            else {
                comp.setForeground(list.getForeground());
                comp.setBackground(list.getBackground());
            }
            return (comp);
        }
        //// 1.2. Render everything else...
        else {
            return (super.getListCellRendererComponent(list, value, index,
                                                    isSelected, cellHasFocus));
        }
    } // of method

    //===   RENDERING METHODS   ================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static Row[] getTestTableInstanceAAA() {
        return (
            new Row[] {
                new SimpleRow("valIIAAA", "\u2013", "valI",   "va123478lIIII"),
                new SimpleRow("valAAAAA", "\u2013", "valAAA", "val123478AAAA"),
                new SimpleRow("valBBAAA", "\u2013", "valBBB", "val123478BBBB"),
                new SimpleRow("valCCAAA", "\u2014", "valCCC", "val123478CCCC"),
                new SimpleRow("valDDAAA", "\u2014", "valGGG", "val123478JJJJ"),
                SeparatorRow.SEPARATOR,
                new SimpleRow("valEEAAA", "\u2014", "55valHHH", "val123478KKKK")
            }
        );
    } // of method

    //----------------------------------------------------------------

    //// Test as a JComboBox
    private static void runTestCCC() {
        JFrame    f        = new JFrame();
        JComboBox comboBox = new JComboBox(getTestTableInstanceAAA());

        comboBox.setRenderer(new TableListCellRenderer());

        f.getContentPane().setLayout(new FlowLayout());
        f.getContentPane().add(comboBox);
        f.pack();
        f.setVisible(true);
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestCCC();
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
