package edu.berkeley.guir.lib.gesture.apps;

import edu.berkeley.guir.lib.gesture.*;
import java.io.*;
import java.text.*;

/** Exists for the sole purpose of reading in data in the format used
 * by agate (a gesture trainer & recognizer written for Amulet)
 * and running it through my Classifier and printing the results.
 */
public class ct
{
  public static void main(String[] args)
  {
    if (args.length == 0) {
      System.err.println("usage: ct datafile");
      System.exit(-1);
    }
    Reader in;
    try {
      in = new FileReader(args[0]);
      GestureSet set = readExamples(in);
      saveSet(new File("ct.data"), set);
      if (set != null) {
	//try {
	  Classifier c = new Classifier(set);
	  c.dump(System.out);
	//}
	//catch (TrainingException e) {
	//  System.err.println("ct: problem training gesture set: " + e);
	//  System.exit(2);
	//}
      }
    }
    catch (FileNotFoundException e) {
      System.err.println("ct: file " + args[0] + " not found");
      System.exit(1);
    }
  }

  public static GestureSet readExamples(Reader reader)
  {
    LineNumberReader in = new LineNumberReader(reader);
    GestureSet result = new GestureSet();

    String line;

    try {
      // read version line
      line = in.readLine();
      // and # of classes
      line = in.readLine();
      MessageFormat format = new MessageFormat("{0,number} classes");
      Object[] o = format.parse(line);
      int numExamples = ((Long) format.parse(line)[0]).intValue();
      for (int i = 0; i < numExamples; i++) {
	in.readLine();
      }
      MessageFormat pointFormat = new MessageFormat("{0,number} {1,number}");
      boolean done = false;
      while (!done) {
	line = in.readLine();
	if (line == null)
	  done = true;
	else if (line.charAt(0) == 'x') {
	  // found an example
	  String name = line.substring(1);
	  name.trim();
	  String points = in.readLine();
	  points.trim();
	  //System.err.println("adding points to " + name + ":");
	  //System.err.println(points);
	  GestureCategory gc = result.getCategory(name);
	  if (gc == null) {
	    gc = new GestureCategory();
	    gc.setName(name);
	    //result.addCategory(gc);
	    result.add(gc);
	  }
	  Gesture g = new Gesture();
	  ParsePosition pos = new ParsePosition(0);
	  // parse the point string into an array of Points
	  while (pos.getIndex() < points.length()) {
	    while (points.charAt(pos.getIndex()) == ' ')
	      pos.setIndex(pos.getIndex()+1);
	    Object[] objs = pointFormat.parse(points, pos);
	    int x = ((Long) objs[0]).intValue();
	    int y = ((Long) objs[1]).intValue();
	    //System.err.println(x + "," + y);
	    g.addPoint(x, y);
	  }
	  g.normalize();
	  gc.addGesture(g);
	}
      }
    }
    catch (IOException e) {
      System.err.println("ct: error while reading input file: " + e);
    }
    catch (ParseException e) {
      System.err.println("ct: error while reading input file: " + e);
    }
    return result;
  }

  public static void saveSet(File f, GestureSet gs)
  {
    final String version = "gdt 1.0";
    try {
      FileOutputStream ostream = new FileOutputStream(f);
      ObjectOutputStream objStream = new ObjectOutputStream(ostream);
      objStream.writeObject(version);
      objStream.writeObject(gs);
      objStream.flush();
      ostream.close();
    }
    catch (IOException exception) {
      System.err.println("Error saving file " + f + ": " + exception);
    }
  }
}
