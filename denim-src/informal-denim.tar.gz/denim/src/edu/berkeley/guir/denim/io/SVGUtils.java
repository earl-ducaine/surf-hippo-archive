package edu.berkeley.guir.denim.io;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.Sheet;
import edu.berkeley.guir.lib.awt.geom.*;
import java.awt.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;

import org.w3c.dom.*;
import org.apache.batik.parser.*;
import org.apache.batik.ext.awt.geom.ExtendedGeneralPath;

import edu.berkeley.guir.denim.*;


/**
 * Contains functions to convert Satin sheets and its contents to and from
 * an SVG file.
 *
 * <PRE>
 * Revisions:  1.0.0  12-01-2002  
 *                    Created SVGUtils
 * </PRE>
 *
 * @author <A HREF="http://eric-chung.com">Eric Chung</A> (
 *         <A HREF="mailto:e_chung@uclink.berkeley.edu">e_chung@uclink.berkeley.edu</A> )
 * @since   JDK 1.4
 * @version Version 1.0.0, 12-01-2002
 */

public class SVGUtils implements SatinConstants {

   static final String SATIN_SHEET_TAG = "SatinSheet";
   static final String SVG_TAG = "svg";
   static final String GROUP_TAG = "g";
   static final String POLYLINE_TAG = "polyline";
   static final String PATH_TAG = "path";   
   static final String TEXT_TAG = "text";
   static final String D_TAG = "d";
   static final String POINTS_TAG = "points";
   static final String STROKE_TAG = "stroke";
   static final String STROKEWIDTH_TAG = "stroke-width";   
   static final String TRANSFORM_TAG = "transform";   
   static final String FILL_TAG = "fill";
   static final String NONE_TAG = "none";
   static final String RECT_TAG = "rect";
   static final String WIDTH_TAG = "width";
   static final String HEIGHT_TAG = "height";
   static final String STYLE_TAG = "style";
   
   //===========================================================================
   //===   BEGIN IMPORT METHODS   ==============================================

   /**
    * Parses a polyline's points and returns a TimedStroke 
    * representing those points.
    */
   public static TimedStroke createTimedStrokeFromPolylineElement(Element e) {
      TimedStroke stk = new TimedStroke();
      StringTokenizer tokenizer = new StringTokenizer(e.getAttribute(POINTS_TAG));

      while (tokenizer.hasMoreTokens()) { 
         String currentToken = tokenizer.nextToken(); 
         String[] coordinates = currentToken.split(",");
         stk.addPoint(Double.parseDouble(coordinates[0]), Double.parseDouble(coordinates[1]));
      }   

      stk.doneAddingPoints();
      return stk;      
   }

   /**
    * Parses a path's points and returns a TimedStroked
    * representing those points
    */
   public static TimedStroke createTimedStrokeFromPathElement(Element e) throws IOException {
      TimedStroke stk = new TimedStroke();
      Reader reader = new StringReader(e.getAttribute(D_TAG));

      Shape pathShape = AWTPathProducer.createShape(reader, java.awt.geom.GeneralPath.WIND_EVEN_ODD);    
      ExtendedGeneralPath generalPath = new ExtendedGeneralPath(pathShape);
      AffineTransform at = new AffineTransform();
      PathIterator iterator = generalPath.getPathIterator(at, 1.0);

      double[] coords = new double[6];

      while(!iterator.isDone()) {
         iterator.currentSegment(coords);
         stk.addPoint(coords[0], coords[1]);
         iterator.next();
      }

      stk.doneAddingPoints();
      return stk;      
   }


   /**
    * Reads in an SVG element, checks for any glyphs, then draws them
    * as TimedStrokes. The TimedStrokes are added to the strokeGroup reference
    */
   public static GraphicalObjectGroup changeSheetFromSVGElement(Element e, GraphicalObjectGroup strokeGroup) throws IOException {
      // Make sure element has right tag
      assert e.getTagName().equals(SVG_TAG) :
                      "Element " + e.getTagName() + " is not svg";

      NodeList children = e.getChildNodes();
      int len = children.getLength();

      // For each of the rest of the children, get and add the graphical object
      for (int i = 0; i < len; i++) {
         Node child = children.item(i);
         String childName = child.getNodeName();

         if (childName.equals(PATH_TAG)) {
            TimedStroke stk = createTimedStrokeFromPathElement((Element)child);
            strokeGroup.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);
         }       
         
         if (childName.equals(POLYLINE_TAG)) {
            TimedStroke stk = createTimedStrokeFromPolylineElement((Element)child);
            strokeGroup.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);
         }
         
         if (childName.equals(GROUP_TAG)) {
            changeSheetFromSVGElement((Element)child, strokeGroup);
         }
      }
      
      return strokeGroup;
   }
   
   /**
    * Reads in a gob and an element, determines the gob's properties
    * and appends it as the proper svg element to Element e.
    */
   static void drawGob(Document doc, Element e, GraphicalObject gob) {
      // If a gob is an instance of a Patch, determine its
      // boundary points and draw it as a polyline.
      if(gob instanceof DenimSketch || gob instanceof DenimLabel) {
         if(gob.isVisible()) {
            Element gobPath = doc.createElement(POLYLINE_TAG);
            Polygon2D poly = gob.getBoundingPoints2D(SatinConstants.COORD_ABS);
            String pointlist = new String();

            // determine the gob's fill color
            String fillColor;
            Style gobStyle = gob.getStyleRef();
            Color gobFillColor = gobStyle.getFillColor();
           
            int colorRed = gobFillColor.getRed();
            int colorGreen = gobFillColor.getGreen();
            int colorBlue = gobFillColor.getBlue();          
            fillColor = "rgb(" + colorRed + "," + colorGreen + "," + colorBlue + ")";         

            // determine the gob's stroke color
            Color gobStrokeColor = gobStyle.getDrawColor();           
            colorRed = gobStrokeColor.getRed();
            colorGreen = gobStrokeColor.getGreen();
            colorBlue = gobStrokeColor.getBlue();
            String strokeColor = "rgb(" + colorRed + "," + colorGreen + "," + colorBlue + ")";                       

            for (int i = 0; i < poly.npoints; i++) {
               pointlist = pointlist + " " + poly.xpoints[i] + "," + poly.ypoints[i];
            }
                 
            gobPath.setAttributeNS(null, FILL_TAG, NONE_TAG);
            gobPath.setAttributeNS(null, POINTS_TAG, pointlist);
            gobPath.setAttributeNS(null, STYLE_TAG, "stroke:"+ strokeColor + ";stroke-width:1" + ";fill:" + fillColor);   
            
            e.appendChild(gobPath);
         }
      }	
   }

   //===========================================================================
   //===   BEGIN EXPORT METHODS   ==============================================

   /**
    * Converts a GraphicalObject to an SVG element by 
    * creating the bounding box for the gob itself,
    * and then applying conversions to the gob's children, 
    * including other gobs or TimedStrokes.
    */
   static Element toSVGElement(Document doc, GraphicalObject gob) {
      // Create a group for this GraphicalObject
      Element e;
      e = doc.createElement(GROUP_TAG);
 	  	     
      // Draw the gob as a polyline in SVG
      drawGob(doc, e, gob);

      // Iterate through this gob's children
      GraphicalObjectCollection gobCollection = (GraphicalObjectCollection) gob;
      Iterator it = gobCollection.getReverseIterator();
      
      while (it.hasNext()) {
         GraphicalObject gobChild = (GraphicalObject)it.next();
         Element transformed;
         transformed = doc.createElement(GROUP_TAG);

         // If this gobChild is a TimedStroke, convert it into a polyline
         if (gobChild instanceof TimedStroke) {      	 
            if (gobChild.isVisible()) {           	
                 transformed.appendChild(toSVGElement(doc, (TimedStroke)gobChild));
                 e.appendChild(transformed);
            }
         }

         // If this gobChild is a gob, call the function on the gobChild                
         if (gobChild instanceof GraphicalObjectGroup) {
            if (gobChild.isVisible()) {
                 // Special hack for fixing DenimLabel exports
                 if(gobChild instanceof DenimLabel) {                                
                    transformed.appendChild(toSVGElement(doc, (DenimLabel)gobChild));
                    e.appendChild(transformed);           
                 } else {
                    transformed.appendChild(toSVGElement(doc, gobChild));
                    e.appendChild(transformed);           
                 } 
            }
         }

         // If this gobChild is a TypedText, convert it into a polyline
         if (gobChild instanceof TypedText) {          
            if (gobChild.isVisible()) {             
                 transformed.appendChild(toSVGElement(doc, (TypedText)gobChild));
                 e.appendChild(transformed);
            }
         }
         
         else {
            assert false:
               "What? A Satin Sheet shouldn't contain " + gobChild.getClass();
         }
      }      
      
      return e;
   }


   /**
    * Handles converting DenimLabels into SVG elements.
    */
   
   static Element toSVGElement(Document doc, DenimLabel label) {
      Element e;

      GraphicalObjectGroup panel = label.getParentGroup();
      Rectangle2D labelRect = panel.getBounds2D(SatinConstants.COORD_ABS);

      // Determine the location of the parent of the DenimLabel                    
      double x = labelRect.getX();
      double y = labelRect.getY();

      String labelText = getLabelText(label);      

      if(labelText != null) {
         e = doc.createElement(TEXT_TAG);
         Text textNode = doc.createTextNode(labelText);
         e.setAttributeNS(null, "font-family", "Comic");
         e.setAttributeNS(null, "font-size", String.valueOf(26));
         e.setAttributeNS(null, "x", Double.toString(x));
         e.setAttributeNS(null, "y", Double.toString(y));          
         e.setAttributeNS(null, "fill", "black");                           
         e.appendChild(textNode);     
      } else {
         e = doc.createElement(POLYLINE_TAG);
         String pointlist = getLabelStrokes(label, x, y);
         e.setAttributeNS(null, POINTS_TAG, pointlist);
         e.setAttributeNS(null, FILL_TAG, NONE_TAG);
         e.setAttributeNS(null, STYLE_TAG, "stroke:black;stroke-width:1.5");   
      }      
      return e;
   }

   /**
    * Helper method for toSVGELement(Document doc, DenimLabel label)
    * which identifies the label text associated with a DenimLabel
    */
    
   static String getLabelText(GraphicalObjectCollection collection) {
      Iterator it = collection.getReverseIterator();
      String labelText;
      
      while (it.hasNext()) {
         GraphicalObject gobChild = (GraphicalObject)it.next();
         
         if(gobChild instanceof TypedText) {
            TypedText typedText = (TypedText) gobChild;
            labelText = typedText.getText();
            return labelText;
         }        
      }
      
      return null;      
   }

   /**
    * Helper method for toSVGELement(Document doc, DenimLabel label)
    * which identifies the label timedstrokes associated with a DenimLabel
    */

   static String getLabelStrokes(GraphicalObjectCollection collection, double xOffset, double yOffset) {
      Iterator it = collection.getReverseIterator();
      
      // Outer loop of iteration looking for any patches within DenimLabel
      while (it.hasNext()) {
         GraphicalObject gobChild = (GraphicalObject)it.next();

         if(gobChild instanceof Patch) {
            String pointlist = new String();
            GraphicalObjectCollection labelStrokes = (GraphicalObjectCollection) gobChild;
            Iterator labelIt = labelStrokes.getReverseIterator();

            // Inner loop which looks for any Timedstrokes within the Patches
            while (labelIt.hasNext()) {
               GraphicalObject labelChild = (GraphicalObject)labelIt.next();
               if(labelChild instanceof TimedStroke) {
                  TimedStroke stk = new TimedStroke((TimedStroke) labelChild);                                     
                  TimedPolygon2D poly = stk.getPolygon2D(SatinConstants.COORD_REL);
         
                  for (int i = 0; i < poly.npoints; i++) {
                     pointlist = pointlist + " " + (poly.xpoints[i] + xOffset) + "," + (poly.ypoints[i] + yOffset - 20);
                  }  
               }         
            } // of inner loop
            return pointlist;
         }
      } // of outer loop
      
      return null;                 
   }

   /**
    * Converts a TimedStroke into an SVG element polyline of form
 	 * 
    * <g translate=(x,y)>
    *   <polyline points="x1,y1 x2,y2 ..."></polyline>
    * </g>
    */
   static Element toSVGElement(Document doc, TimedStroke stk) {
      Element e;
      String pointlist = new String();

      e = doc.createElement(POLYLINE_TAG);   

      TimedPolygon2D poly = stk.getPolygon2D(SatinConstants.COORD_ABS);
           
      for (int i = 0; i < poly.npoints; i++) {
         pointlist = pointlist + " " + poly.xpoints[i] + "," + poly.ypoints[i];
      }

      // determine the stroke color attribute in rgb format
      String strokeColor;
      Style strokeStyle = stk.getStyleRef();
      Color drawColor = strokeStyle.getDrawColor();
           
      int colorRed = drawColor.getRed();
      int colorGreen = drawColor.getGreen();
      int colorBlue = drawColor.getBlue();
           
      strokeColor = "rgb(" + colorRed + "," + colorGreen + "," + colorBlue + ")";         
                   
      e.setAttributeNS(null, FILL_TAG, NONE_TAG);
      e.setAttributeNS(null, POINTS_TAG, pointlist);
      e.setAttributeNS(null, STYLE_TAG, "stroke:" + strokeColor + ";stroke-width:1.5");   
   
      return e;
   }
   
   /**
    * Converts a TypedText Graphical Object into an SVG element text of form
    *
    */
   static Element toSVGElement(Document doc, TypedText text) {
      Element e;
      e = doc.createElement(TEXT_TAG);
     
      Text textNode = doc.createTextNode(text.getText());
      Font textFont = text.getFont();  

      String svgTextColor;
      Color textColor = text.getColor();

      int colorRed = textColor.getRed();
      int colorGreen = textColor.getGreen();
      int colorBlue = textColor.getBlue();
           
      svgTextColor = "rgb(" + colorRed + "," + colorGreen + "," + colorBlue + ")";   

      AffineTransform tx = text.getTransform(SatinConstants.COORD_ABS);
      e.setAttributeNS(null, "font-family", "Comic");
      e.setAttributeNS(null, "font-size", String.valueOf(textFont.getSize2D()));
      e.setAttributeNS(null, "x", Double.toString(tx.getTranslateX()));
      e.setAttributeNS(null, "y", Double.toString(tx.getTranslateY() + 25));      
      e.setAttributeNS(null, "fill", svgTextColor);            
                     
      e.appendChild(textNode);
   
      return e;
   }   

   /**
    * Converts a Satin Sheet into an SVG DOM element. This function specifies
    * the svg file width and height. The sheet is passed as a GraphicalObject
    * into toSVGElement.
    */
   public static Element toSVGElement(Document doc, Sheet sheet) {
      Element e = doc.createElement(SATIN_SHEET_TAG);
      e = doc.createElement(SVG_TAG);

      Rectangle2D boundary = sheet.getBounds();         
      String width = String.valueOf(boundary.getWidth());
      String height = String.valueOf(boundary.getHeight());      
          
      e.setAttributeNS(null, WIDTH_TAG, width);
      e.setAttributeNS(null, HEIGHT_TAG, height);
      e.appendChild(toSVGElement(doc, (GraphicalObject)sheet));
     
      return e;    
   }
}
//==============================================================================

/*
Copyright (c) 1999-2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/