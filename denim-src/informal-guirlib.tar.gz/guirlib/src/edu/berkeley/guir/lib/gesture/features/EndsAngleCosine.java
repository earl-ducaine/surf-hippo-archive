package edu.berkeley.guir.lib.gesture.features;

import java.lang.Math;
import java.awt.Polygon;
import edu.berkeley.guir.lib.gesture.*;

/**
 * Cosine of the angle between the first and last points
 */
public class EndsAngleCosine extends Feature {
  public double minValue = -1;
  public double maxValue = 1;
  double rolloff = (4*4);
  double EPSILON = 1e-4;
  
  public EndsAngleCosine()
  {
    super();
  }

  public EndsAngleCosine(Gesture g)
  {
    super(g);
  }

  protected void computeValue()
  {
    Polygon p = gesture.getPointsRef();

    if (p.npoints < 3) {
      value = 0;
    }
    else {
      double x0 = p.xpoints[0];
      double y0 = p.ypoints[0];
      double xn = p.xpoints[p.npoints-1];
      double yn = p.ypoints[p.npoints-1];
      double hypot = Math.sqrt((xn-x0)*(xn-x0) + (yn-y0)*(yn-y0));
      double factor = hypot * hypot / rolloff;
      if (factor > 1)
	factor = 1;
      factor = (hypot > EPSILON) ? factor/hypot : 0;
      
      value = (xn - x0) * factor;
    }
    valueOk = true;
  }

  public double getMinValue()
  {
    return minValue;
  }
  
  public double getMaxValue()
  {
    return maxValue;
  }

  public String getName()
  {
    return new String("cosine of angle between first and last points");
  }

  // could try rotation here if this doesn't work well
  public void scale(double factor)
  {
    gesture.normalize();
    TimedPolygon points = gesture.getPoints();
    double x0 = points.xpoints[0];
    double xn = points.xpoints[points.npoints-1];

    boolean scalex = ((factor-1)*(xn-x0)) > 0;
    double f = (factor>=1) ? factor : (1.0/factor);
    
    for (int i = 0; i < points.npoints; i++) {
      if (scalex) {
	points.xpoints[i] *= f;
      }
      else {
	points.ypoints[i] *= f;
      }
    }

    gesture.setPoints(points);
  }
}
