//// See bottom of source code for software license
package edu.berkeley.guir.lib.satin.objects;

import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.debugging.Debug;
import edu.berkeley.guir.lib.satin.graphics.SatinGraphics;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;

/**
 * A GraphicalObject holding an image.
 * <P>
 * Sample usage:
 * <CODE>
 *  import edu.berkeley.guir.lib.satin.SatinConstants;
 *  import edu.berkeley.guir.lib.satin.Sheet;
 *  import edu.berkeley.guir.lib.satin.objects.GObImage;
 *  import javax.swing.JFrame;
 *
 *  public class Test {
 *
 *      public static void main(String[] argv) throws Exception {
 *
 *          Sheet  sheet = new Sheet();
 *          JFrame f     = new JFrame();
 *
 *          // Setup the sheet
 *          f.setSize(300, 300);
 *          f.getContentPane().add(sheet);
 *          f.setVisible(true);
 *
 *          // Reads from current directory
 *          GObImage gimg = new GObImage("img.jpg");
 *
 *          // Add image to sheet
 *          sheet.add(gimg);
 *      } // of main
 *  }
 * </CODE>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jun 20 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.1.0, Nov 10 2000, JH
 *               Fixed image loading race conditions.
 *               Added optional borders to the image.
 *             - SATIN-v2.1-1.2.0, Jun 17 2003, JH
 *               Fixed bug on loading images larger than Sheet
 *               Cleaned up formatting of code
 *               Added sample usage
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class GObImage
   extends    GraphicalObjectImpl
   implements ImageObserver {

   //===========================================================================
   //===   CLASS METHODS AND VARIABLES   =======================================

   static final long serialVersionUID = -3561711969729745457L;

   //===   CLASS METHODS AND VARIABLES   =======================================
   //===========================================================================




   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   transient Image         img;
   transient BufferedImage bimg;

   //// Have we received all bits yet?
   boolean flagUpdated    = false;
   boolean flagDrawBorder = true;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create an empty image GraphicalObject.
    */
   protected GObImage() {
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a GraphicalObject around the image specified.
    *
    * @param img is a reference to the Image object to display.
    */
   public GObImage(Image img) {
      this.img = img;
      flagUpdated = true;
      updateImageBoundingPoints();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a GraphicalObject of the image given the specified filename.
    *
    * @param strFileName is the name of the image file to load.
    *                    It can load up whatever files Java can, so as of
    *                    JDK1.3 this includes GIF, JPG, and PNG.
    */
   public GObImage(String strFileName) throws FileNotFoundException {
      Toolkit tk = Toolkit.getDefaultToolkit();
      
      // make sure that the file exist
      if (new File(strFileName).canRead()) {
          // create an image from the file
          img = tk.createImage(strFileName);
          updateImageBoundingPoints();
      } 
      else {
           throw new FileNotFoundException();
      }
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a GraphicalObject of the image given the specified url.
    *
    * @param url is the URL object to load up.
    *            It can load up whatever files Java can, so as of JDK1.3
    *            this includes GIF, JPG, and PNG.
    */
   public GObImage(URL url) {
      Toolkit tk = Toolkit.getDefaultToolkit();
      img = tk.createImage(url);
      updateImageBoundingPoints();
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   IMAGE OBSERVER METHODS   ============================================

   /**
    * Updated info on the friendly image file we contain.
    */
   public synchronized boolean imageUpdate(Image img, 
                                           int   infoFlags, 
                                           int   x, 
                                           int   y, 
                                           int   width, 
                                           int   height) {
      if (img == null){
         return true;
      }
      
      disableNotify();
      
      ////0.5 don't want to render unless ALLBITS is the state.
      flagUpdated = false;


      //// 1. Check out load status.
      int status = Toolkit.getDefaultToolkit().checkImage(img, -1, -1, null);

      //// 1.1. Error in reading, abort.
      if ((status & ImageObserver.ABORT) > 0) {
          //// error, but not sure what's the right thing to do here...
          // throw new RuntimeException("Image load error - ABORT");
      }
      //// 1.2. Success, finished loading.
      if ((status & ImageObserver.ALLBITS) > 0) {
         Polygon p = GeomLib.makePolygon(new Rectangle(0, 0, 
                               img.getWidth(null), img.getHeight(null)));
         super.setBoundingPoints2D(COORD_LOCAL, p);
         flagUpdated = true;
         damage(DAMAGE_NOW);
         return false;
      }
      //// 1.3. Some error.
      if ((status & ImageObserver.ERROR) > 0) {
         //// error, but not sure what's the right thing to do here...
         // throw new RuntimeException("Image load error - ERROR");
      }
      

      enableNotify();

      damage(DAMAGE_LATER);

      return (true);
   } // of method

   //===   IMAGE OBSERVER METHODS   ============================================
   //===========================================================================

 


   //===========================================================================
   //===   ACCESSOR METHODS  ===================================================

   public Image getImage(){
      return img;
   } // of method

   /**
    * Returns true if all of the bits have been loaded
    * Otherwise, it returns false
    */
   public boolean isFullyLoaded() {
      return flagUpdated;
   } // of method

   //===   ACCESSOR METHODS         ============================================
   //===========================================================================
   



   //===========================================================================
   //===   DRAWING METHODS   ===================================================

   /**
    * Set whether a border should be drawn around this iamge.
    */
   public void setDrawBorder(boolean flag) {
      flagDrawBorder = flag;
   } // of method

   public boolean getDrawBorder() {
      return (flagDrawBorder);
   } // of method

   //===   DRAWING METHODS   ===================================================
   //===========================================================================




   //===========================================================================
   //===   POSITION METHODS   ==================================================

   private void updateImageBoundingPoints() {
      Polygon p = GeomLib.makePolygon(new Rectangle(0, 0, 
                                  img.getWidth(this), img.getHeight(this)));
      super.setBoundingPoints2D(COORD_LOCAL, p);
   } // of method

   //===   POSITION METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   RENDERING   =========================================================

   protected void defaultRender(SatinGraphics g) {
      //// 1. Draw the border.
      if (flagDrawBorder == true) {
         g.draw(getLocalBoundingPoints2DRef());
      }


      //// 2. If we haven't loaded up the image yet don't try
      ////    to render.
      if (flagUpdated == false) {
         Toolkit.getDefaultToolkit().prepareImage(img, -1, -1, this);
         return;
      }

      //// 3. Cache a copy of the image as a buffered image.
      if (bimg == null) {
         if (img instanceof BufferedImage) {
            bimg = (BufferedImage) img;
         }
         else {
            bimg = new BufferedImage(img.getWidth(null), img.getHeight(null),
                                     BufferedImage.TYPE_INT_ARGB);
            bimg.createGraphics().drawImage(img, 0, 0, this);
         }
      }

      //// 4. Render the image.
      g.drawImage(bimg, 0, 0, GObImage.this);
   } // of method

   //===   RENDERING   =========================================================
   //===========================================================================




   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (this.clone(new GObImage()));
   } // of method

   //-----------------------------------------------------------------

   public GObImage clone(GObImage gobClone) {
      super.clone(gobClone);

      int          width   = bimg.getWidth();
      int          height  = bimg.getHeight();
      int[]        values  = new int[width * height];

      bimg.getRGB(0, 0, width, height, values, 0, width);
      gobClone.bimg = new BufferedImage(width, height, 
                                        BufferedImage.TYPE_INT_ARGB);
      gobClone.bimg.setRGB(0, 0, width, height, values, 0, width);

      return (gobClone);
   } // of method

   //-----------------------------------------------------------------

   public Object deepClone() {
      return (this.clone());
   } // of method

   //-----------------------------------------------------------------

   public GObImage deepClone(GObImage gobClone) {
      return (this.clone(gobClone));
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================




   //===========================================================================
   //===   SERIALIZATION METHODS   =============================================

   private void readObject(java.io.ObjectInputStream oistream) 
      throws IOException {

      try {
         oistream.defaultReadObject();

         int   width  = oistream.readInt();
         int   height = oistream.readInt();
         int[] values = (int[]) oistream.readObject();

         bimg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
         bimg.setRGB(0, 0, width, height, values, 0, width);
      }
      catch (Exception e) {
         Debug.println(e);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Write out the image bits too.
    */
   private void writeObject(java.io.ObjectOutputStream oostream)
      throws IOException {

      oostream.defaultWriteObject();

      int          width   = bimg.getWidth();
      int          height  = bimg.getHeight();
      int[]        values  = new int[width * height];

      bimg.getRGB(0, 0, width, height, values, 0, width);

      oostream.writeInt(width);
      oostream.writeInt(height);
      oostream.writeObject(values);
   } // of method

   //===   SERIALIZATION METHODS   =============================================
   //===========================================================================




   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static void main(String[] argv) {
   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/


