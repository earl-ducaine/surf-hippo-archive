//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import edu.berkeley.guir.lib.collection.Queue;
import java.util.Iterator;

/**
 * A breadth first search for Graph.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Dec 20 1997, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.5/1.2.0, Nov 22 2002, JH
 *               Updated for new Graph APIs
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.1.4
 * @version GUIRLib-v1.5/1.2.0, Nov 22 2002
 */
public class GraphSearchBreadthFirst
   implements GraphSearch {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   Graph     g;                 // our reference to the graph

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   SEARCH METHODS   ====================================================

   /**
    * Perform a breadth-first search on the graph, with the specified start
    * and target nodes. Breadth-first-search is guaranteed to return the
    * path with the shortest number of "hops" (ie edges).
    *
    * @param  g is the graph we are searching in.
    * @param  strFrom is the name of the starting node.
    * @param  strTo   is the name of the target node.
    * @return Returns the first successful Path found from the start node
    *         to the target node. The Path is empty if no successful Path
    *         is found, or if either the start or target node does not
    *         exist in the Graph.
    */
   public GraphPath search(Graph g, String strFrom, String strTo) {

      GraphPath p = new GraphPath();

      this.g = g;

      //// 1. Ensure that the start and ending nodes are in the Graph
      if (g.nodeExists(strFrom) && g.nodeExists(strTo)) {
         p = breadthFirstSearchHelper(strFrom, strTo);
      }

      return(p);

   } // of method

   //-----------------------------------------------------------------

   /**
    * The helper method for breadthFirstSearch.
    *
    * @param  strTo    is the name of the destination node. It is assumed that
    *                  this node exists.
    * @param  q        is the queue for breadth first search
    * @return true if the path was found, false otherwise.
    */
   private GraphPath breadthFirstSearchHelper(String strFrom, String strTo) {

      Queue        q = new Queue();     // open nodes to explore
      GraphPath    p = new GraphPath(); // path to current node we are at
      GraphNode    nodeAt;              // the node where we currently are
      String       strNodeNext;         // the name of the next open node
      GraphNode    nodeNext;            // the next open node

      try {
         //// 1. Initializations - add in the start node
         p.addNode(g.getNode(strFrom));
         q.enqueue(p);

         while (q.size() > 0) {
            //// 2. Try to dequeue the next thing
            p           = (GraphPath) q.dequeue();
            nodeAt      = p.getLastNode();
            // System.out.println("searching path " + p);

            //// 3. Get the list of nodes connected to this one
            Iterator it = nodeAt.getOutlinks();
            while (it.hasNext()) {
               GraphPath newpath;
               newpath      = (GraphPath) p.clone();
               strNodeNext  = (String) it.next();
               nodeNext     = g.getNode(strNodeNext);
               newpath.addNode(nodeNext, g.getWeight(nodeAt, nodeNext));

               //// 4. See if we are at the destination
               if (strTo.equals(nodeNext.getName())) {
                  return(newpath);
               } 
               else {
                  // System.out.println("Adding path " + newpath);
                  q.enqueue(newpath);
               }
            }
         } // of while queue has elements

      }
      catch (Exception e) {
         //// If this happens you are seriously screwed
         // System.out.println(e);
         e.printStackTrace();
         p = new GraphPath();
      }

      //// 5. If we reached here, then no Path was found, so failure.
      return (new GraphPath());

   } // of method

   //===   SEARCH METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
