package edu.berkeley.guir.denim.dialogs;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.image.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.util.List;
import java.util.ArrayList;

/**
 * The window that is opened when editing or creating scenarios
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  
 * </PRE>
 *
 * @author  Jenny Lee</A> (
 *          <A HREF="mailto:deneb717@uclink.berkeley.edu">deneb717@uclink.berkeley.edu</A> )
 * @author  John Brian Kirby</A> (
 *          <A HREF="mailto:jbkirby@uclink.berkeley.edu">jbkirby@uclink.berkeley.edu</A> )
 *
 * @since   JDK 1.4
 * @version Version 
 */
public class NewScenarioDialog extends JDialog implements DenimConstants {

   private DenimScenarioEditorSheet editorSheet;
   private DenimPanel currentPanel;
   private DenimPanel startingPanel;
   private DenimSheet sheet;

   private Scenario panelList;
   private JToolBar navigationToolbar;
   private JToolBar maintenanceToolbar;
   private JToolBar recordToolbar;

   private Stack prevPanels; // stack of panels to display when
   //  Back is pressed
   private Stack nextPanels; // stack of panels to display when
   //  Forward is pressed

   private JPanel contentPane;
   private JPanel labelPanel;
   private JSplitPane splitPanel;
   private JScrollPane scrollPane;
   private ArrayList recordedPanels; // list of panels viewed while
   //  recording in Run mode

   private int splitPanelDivider;
   private int nextRecordedLabelYLoc;

   private JButton backButton;
   private JButton forwardButton;
   private JButton refreshButton;
   private JButton recordButton;
   private JButton stopButton;
   private JButton undoButton;
   private JButton playButton;
   private JButton doneButton;
   private JButton cancelButton;

   private JTextField nameField;

   private boolean recording;
   private boolean playing;
   private boolean runningScenario; // true when the run window is
   //  running the scenario
   private List currentScenario; // list of panels of pages in the
   //  current scenario

   public NewScenarioDialog(DenimPanel initialPanel) {
      JPanel contentPane = new JPanel(new BorderLayout());

      setupNavigationToolBar();
      setupMaintenanceToolBar();
      setupRecordToolBar();

      sheet = (DenimSheet)initialPanel.getSheet();

      currentPanel = initialPanel;
      startingPanel = initialPanel;
      
      recording    = false;
      prevPanels   = new Stack();
      nextPanels   = new Stack();
      // commented out becaouse of conflicts, must fix.. (JL)
      // editorSheet  = new DenimScenarioEditorSheet(this, startingPanel, true);  // Scenario mode set to false for now.
      
      contentPane.add(navigationToolbar, BorderLayout.NORTH);
      contentPane.add(editorSheet, BorderLayout.CENTER);
      contentPane.add(maintenanceToolbar, BorderLayout.SOUTH);
      contentPane.add(recordToolbar, BorderLayout.EAST);
      setContentPane(contentPane);
      
    

      setSize(600, 700);
      setTitle("Scenario Editor");
      //panelList = initialPanel;
      
      DenimScenarioEditorListener listenToMe = new DenimScenarioEditorListener();
      this.addWindowListener(listenToMe);
      
      /*
      JPanel contentPane = new JPanel(new BorderLayout());
      setupToolBar();
      currentPanel = startingPanel;
      recording    = false;
      prevPanels   = new Stack();
      nextPanels   = new Stack();
      runSheet     = new DenimScenarioEditorSheet(this, startingPanel, scenarioMode);

      contentPane.add(toolbar,  BorderLayout.NORTH);
      contentPane.add(runSheet, BorderLayout.CENTER);
      setContentPane(contentPane);

      sheet = (DenimSheet)startingPanel.getSheet();


      //// Doesn't quite work since toolbar height is 0.
      setSize(runSheet.getVisibleWidth(),
              runSheet.getVisibleHeight() + toolbar.getHeight());

      setSize(runSheet.getVisibleWidth(),
              runSheet.getVisibleHeight() + 50);

      setTitle(title);
      renderPanel(startingPanel);


      DenimRunWindowListener listenToMe = new DenimRunWindowListener();
      this.addWindowListener(listenToMe);
      */
   }

   /**
    * Creates and returns the upper toolbar, containing the navigation buttons.
    */
   private void setupNavigationToolBar() {
      navigationToolbar = new JToolBar();

      //// 1. Set up the back button.
      backButton =
         new JButton(
            "Back",
            new ImageIcon(Denim.class.getResource("images/toolbar/back.gif")));
      backButton.addActionListener(new BackButtonAction());
      backButton.setDisabledIcon(
         new ImageIcon(
            Denim.class.getResource("images/toolbar/back_disabled.gif")));
      backButton.setEnabled(false);
      navigationToolbar.add(backButton);

      //// 2. Set up the forward button.
      forwardButton =
         new JButton(
            "Forward",
            new ImageIcon(
               Denim.class.getResource("images/toolbar/forward.gif")));
      forwardButton.addActionListener(new NextButtonAction());
      forwardButton.setDisabledIcon(
         new ImageIcon(
            Denim.class.getResource("images/toolbar/forward_disabled.gif")));
      forwardButton.setEnabled(false);
      navigationToolbar.add(forwardButton);

      //// 3. Set up the refresh button.
      refreshButton =
         new JButton(
            "Refresh",
            new ImageIcon(
               Denim.class.getResource("images/toolbar/refresh.gif")));
      refreshButton.addActionListener(new RefreshButtonAction());
      refreshButton.setEnabled(true);
      navigationToolbar.add(refreshButton);
      navigationToolbar.addSeparator();

   } // of method

   /**
    * Creates and returns the toolbar for DenimScenarioEditor.
    */
   private void setupMaintenanceToolBar() {
      maintenanceToolbar = new JToolBar();

      //// 1. Set up the name text field
      nameField = new JTextField("Name", 20);
      /* probably don't need this line
      nameField.addActionListener(new NameFieldAction()); */
      maintenanceToolbar.add(nameField);

      //// 2. Set up the done button
      doneButton = new JButton("Done");
      doneButton.addActionListener(new DoneButtonAction());
      doneButton.setEnabled(true);
      doneButton.setVisible(true);
      maintenanceToolbar.add(doneButton);

      //// 2. Set up the Cancel button
      cancelButton = new JButton("Cancel");
      cancelButton.addActionListener(new CancelButtonAction());
      cancelButton.setEnabled(true);
      cancelButton.setVisible(true);
      maintenanceToolbar.add(cancelButton);

   } // of method

   /**
    * Creates and returns the toolbar for DenimScenarioEditor.
    */
   private void setupRecordToolBar() {
      recordToolbar = new JToolBar();
      recordToolbar.setOrientation(SwingConstants.VERTICAL);

      //// 1. Set up the record button
      recordButton =
         new JButton(
            "Record",
            new ImageIcon(
               Denim.class.getResource("images/toolbar/record.gif")));
      recordButton.addActionListener(new RecordButtonAction());
      recordButton.setEnabled(true);
      recordButton.setVisible(true);
      recordToolbar.add(recordButton);

      //// 2. Set up the undo button
      undoButton = new JButton("Undo");
      undoButton.addActionListener(new UndoButtonAction());
      undoButton.setEnabled(false);
      undoButton.setVisible(true);
      recordToolbar.add(undoButton);

      //// 3. Set up the stop button
      stopButton =
         new JButton(
            "Stop",
            new ImageIcon(
               Denim.class.getResource("images/toolbar/stop_record.gif")));
      stopButton.addActionListener(new StopRecordButtonAction());
      stopButton.setVisible(true);
      stopButton.setEnabled(false);
      recordToolbar.add(stopButton);

      //// 4. Set up the play button
      playButton = new JButton("Play");
      playButton.addActionListener(new PlayButtonAction());
      playButton.setEnabled(true);
      playButton.setVisible(true);
      recordToolbar.add(playButton);

   } // of method

   //------------------------------------------------------------------

   /**
    * Set the mode for this RunWindow to run a scenario according to b.  This
    * means it would disable the buttons for record and hyperlink.
    * TODO: disable the hyperlink
    */
   public void setRunScenario(boolean b) {
      runningScenario = b;
      if (b) {
         recordToolbar.remove(recordButton);
         recordButton.setEnabled(false);
         stopButton.setEnabled(false);
         backButton.setEnabled(false);
         forwardButton.setEnabled(false);
         // disable the stack
         if (currentScenario != null) {
            // push the scenario in the forwrad stack
            Stack newforward = new Stack();
            Stack tmpstack = new Stack();
            boolean isFirst = true;
            for (Iterator it = currentScenario.iterator(); it.hasNext();) {
               // don't push the first panel of the scenario on the stack
               Object tmpobj = it.next();
               if (isFirst == true) {
                  isFirst = false;
               } else {
                  tmpstack.push(tmpobj);
               }
            }
            // reverse the order
            while (!tmpstack.empty()) {
               newforward.push(tmpstack.pop());
            }
            nextPanels = newforward;
            // zero out the previous stack, if there is any
            prevPanels = new Stack();
            // see if we have reactivate the nextPanel button
            if (hasNextPanel()) {
               forwardButton.setEnabled(true);
            }
         }
      } else {
         stopButton.setEnabled(true);
         recordButton.setEnabled(true);
         nextPanels = new Stack(); // empty the nextPanel stack
         prevPanels = new Stack(); // empty the prevPanel stack
      }
   }
   
   /**
    * Enables or disables the toolbar buttons as appropriate.
    */
   void update() {
      backButton.setEnabled(hasPreviousPanel());
      forwardButton.setEnabled(hasNextPanel());
   } // of method

   //------------------------------------------------------------------

   /**
    * Set the scenario for this run window.
    * @param scen vector that contains the denim panels
    */
   public void setScenario(List scen) {
      currentScenario = scen;
   }

   //------------------------------------------------------------------

   /**
    * Displays the given panel in the window.
    */
   public void renderPanel(DenimPanel panel) {
      currentPanel = panel;
      editorSheet.renderPanel(panel);
      //panel.setActive(true);
   } // of method

   //===   RUN WINDOW METHODS   ================================================
   //===========================================================================

   public DenimPanel getPanel() {
      return currentPanel;
   }

   //===========================================================================
   //===   BROWSER METHODS   ===================================================


  
   /**
    * Stores the panel being displayed in the history stack.
    */
   public void pushCurrentPanel() {
      prevPanels.push(currentPanel);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Returns true if there is a panel before the current one in the
    * history stack.
    */
   public boolean hasPreviousPanel() {
      return !prevPanels.empty();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Returns true if there is a panel ahead of the current one in the
    * history stack.
    */
   public boolean hasNextPanel() {
      return !nextPanels.empty();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Goes to the previous panel in the history stack, or does nothing if
    * there isn't one.
    */
   public void gotoPreviousPanel() {
      if (!prevPanels.empty()) {
         nextPanels.push(currentPanel);
         //debug.println("new next = " + currentPanel.getUniqueID());
         currentPanel = (DenimPanel) prevPanels.pop();
         renderPanel(currentPanel);
         //debug.println("displaying = " + currentPanel.getUniqueID());
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Goes to the next panel in the history stack, or does nothing if
    * there isn't one.
    */
   public void gotoNextPanel() {
      if (!nextPanels.empty()) {
         prevPanels.push(currentPanel);
         //debug.println("new previous = " + currentPanel.getUniqueID());
         currentPanel = (DenimPanel) nextPanels.pop();
         renderPanel(currentPanel);
         //debug.println("displaying = " + currentPanel.getUniqueID());
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Clears any panels ahead of the current panel in the history stack.
    */
   public void clearNextPanels() {
      nextPanels.removeAllElements();
   } // of method

   //===   BROWSER METHODS   ===================================================
   //===========================================================================

   //------------------------------------------------------------------

   /**
    * Inner classes to implement the back and next button's action
    */
   class BackButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         gotoPreviousPanel();
      }
   } // of inner class

   //------------------------------------------------------------------

   class NextButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         gotoNextPanel();
      }
   } // of inner class

   //------------------------------------------------------------------

   class RefreshButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         
      }
   } // of inner class

   //------------------------------------------------------------------

   class PlayButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         playButton.setEnabled(false);
         stopButton.setEnabled(true);
         recordToolbar.repaint();
      }
   } // of inner class

   //------------------------------------------------------------------

   class UndoButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         
      }
   } // of inner class

   //------------------------------------------------------------------

   class DoneButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {

      }
   } // of inner class

   //------------------------------------------------------------------

   class CancelButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         
      }
   } // of inner class

   //------------------------------------------------------------------

   class RecordButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         labelPanel = new JPanel(null);
         recording = true;
         splitPanelDivider = 0;

         recordButton.setEnabled(false);
         refreshButton.setEnabled(false);
         stopButton.setEnabled(true);
         recordToolbar.repaint();

         JPanel contentPane = (JPanel) getContentPane();
         contentPane.remove(editorSheet);
         labelPanel.setBackground(new Color(255, 255, 255));
         scrollPane = new JScrollPane(labelPanel);
         // following two lines were commented out
         //scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
         //splitPanel = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, labelPanel, editorSheet);
         splitPanel =
            new JSplitPane(
               JSplitPane.HORIZONTAL_SPLIT,
               scrollPane,
               editorSheet);
         splitPanel.setContinuousLayout(true);
         splitPanel.setOneTouchExpandable(false);
         recordPanel(currentPanel, true);
         contentPane.add(splitPanel, BorderLayout.CENTER);
         setContentPane(contentPane);
         labelPanel.repaint();
      }
   } // of inner class

   public void recordPanel(DenimPanel p, boolean restart) {
      if (restart) {
         nextRecordedLabelYLoc = 0;
         recordedPanels = new ArrayList();
      }

      recordedPanels.add(p);
      // position label
      DenimText phrase = p.getLabel().getPhrase();
      phrase.getStyleRef().setFillColor(Color.white);
      BufferedImage img = SatinImageLib.toImage(phrase);
      Icon icon = new ImageIcon(img);
      JLabel label = new JLabel();
      label.setIcon(icon);
      label.setBounds(0, 0, img.getWidth(null), img.getHeight(null));
      labelPanel.add(label);
      label.setLocation(0, nextRecordedLabelYLoc);
      nextRecordedLabelYLoc =
         nextRecordedLabelYLoc + (int) label.getSize().getHeight();

      // re-position split panel divider after resizing frame
      splitPanelDivider =
         (int) Math.max(splitPanelDivider, label.getSize().getWidth());
      /*
      setBounds(
         getX(),
         getY(),
         splitPanelDivider + editorSheet.getVisibleWidth(),
         getHeight());
      */
      validate();
      splitPanel.setDividerLocation(splitPanelDivider);
      splitPanel.setOneTouchExpandable(false);

      labelPanel.repaint();
      labelPanel.validate();
      scrollPane.validate();
   }

   //------------------------------------------------------------------

   class StopRecordButtonAction implements ActionListener {
      public void actionPerformed(ActionEvent evt) {
         recording = false;
         stopButton.setEnabled(false);
         refreshButton.setEnabled(true);
         recordButton.setEnabled(true);
         playButton.setEnabled(true);
         recordToolbar.repaint();

         /* This needs to be repaired. -JBK
         SaveScenarioDialog saveDlg =
            new SaveScenarioDialog(DenimRunWindow.this, sheet);
         saveDlg.setVisible(true);
         sheet.setScenario(saveDlg.getText(), recordedPanels);
         */

         JPanel contentPane = (JPanel) getContentPane();
         contentPane.remove(splitPanel);
         contentPane.add(editorSheet, BorderLayout.CENTER);
         setContentPane(contentPane);
         // setBounds(getX(), getY(), editorSheet.getVisibleWidth(), getHeight());
      }
   } // of inner class

   //------------------------------------------------------------------

   public boolean isRecording() {
      return recording;
   }

   //------------------------------------------------------------------

   public JPanel getLabelPanel() {
      return labelPanel;
   }

   //===   RUN WINDOW METHODS   ================================================
   //===========================================================================

   class DenimScenarioEditorListener implements WindowListener {

      public DenimScenarioEditorListener() {
      }

      public void windowClosing(WindowEvent e) {
         NewScenarioDialog.this.getPanel().setActive(false);
      }

      public void windowClosed(WindowEvent e) {
         NewScenarioDialog.this.getPanel().setActive(false);
      }

      public void windowOpened(WindowEvent e) {
         NewScenarioDialog.this.getPanel().setActive(true);
      }

      public void windowIconified(WindowEvent e) {
         NewScenarioDialog.this.getPanel().setActive(false);
      }

      public void windowDeiconified(WindowEvent e) {
         NewScenarioDialog.this.getPanel().setActive(true);
      }

      public void windowActivated(WindowEvent e) {
         NewScenarioDialog.this.getPanel().setActive(true);
      }

      public void windowDeactivated(WindowEvent e) {
         NewScenarioDialog.this.getPanel().setActive(false);
      }
   } // of class
}