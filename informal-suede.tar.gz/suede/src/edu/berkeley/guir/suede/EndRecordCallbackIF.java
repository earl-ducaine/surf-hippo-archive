package edu.berkeley.guir.suede;

public interface EndRecordCallbackIF {
  
  public void callmeWhenDoneRecording();
  
  
}