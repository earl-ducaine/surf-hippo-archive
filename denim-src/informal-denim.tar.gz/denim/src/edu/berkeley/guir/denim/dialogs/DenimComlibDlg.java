//// See bottom of source code for software license
package edu.berkeley.guir.denim.dialogs;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.table.*;
import javax.swing.event.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;



/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 *             Created on May 27, 2004 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class DenimComlibDlg extends JDialog 
				implements SatinConstants {
	
	static final int width = 300;
	static final int height = 400;
	
	DenimSheet sheet = null;
	JTable table;
	JButton use = new JButton("Insert");
    
    LinkedList denimCustomComponents = null;
		
	TableModel dataModel = new AbstractTableModel() {
		public int getColumnCount() {
			return 1;
		}
		
		public int getRowCount() {
			return denimCustomComponents.size();//DenimComponentRegistry.getInstance().getComponents().size()-7;
		}
		
		public Object getValueAt(int row, int col) {
			return
                (String)denimCustomComponents.get(row);
				//(String)DenimComponentRegistry.getInstance().
				//				getComponentNames().toArray()[row+7];
		}
		
		public String getColumnName(int index) {
			return "Name";
		}
	};				

 
	public DenimComlibDlg(DenimWindow win) {
		
		super(win, "Denim Custom Components", true);
		
		sheet = win.getDenimUI().getSheet();
		
		this.setResizable(false);
		double w = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double h = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setBounds((int)((w-width)/2), (int)((h-height)/2),
							width, height);
		
		//Collection col = DenimComponentRegistry.getInstance().getComponents();
        denimCustomComponents = (LinkedList)DenimComponentRegistry.getInstance().getCustomComponentNames();
						
		table = new JTable();
		this.getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);
		table.setModel(dataModel);
		table.revalidate();
				
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
/*		table.getSelectionModel().addListSelectionListener(
					new ListSelectionListener() {

			public void valueChanged(ListSelectionEvent e) {
				int current = table.getSelectedRow();
				if(current<0||current>table.getRowCount())
				{
					use.setEnabled(false);				
				}
			}
		});
*/
		JPanel btns = new JPanel();
		this.getContentPane().add(btns, BorderLayout.SOUTH);
		
		btns.add(use);
		use.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				String name = (String)dataModel.getValueAt(table.getSelectedRow(),0);
				useComponent(name);
				DenimComlibDlg.this.setVisible(false);
			}
		});
		
		JButton cancel = new JButton("Cancel");
		btns.add(cancel);
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				DenimComlibDlg.this.setVisible(false);
			}
		});
		
/*		JButton edit = new JButton("Edit");
		btns.add(edit);
		edit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				String name = (String)dataModel.getValueAt(table.getSelectedRow(),0);
				DenimComponentEditor dce = new DenimComponentEditor(false, name);
				dce.setVisible(true);
			}
		});
		
		JButton delete = new JButton("Delete");
		btns.add(delete);
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				String name = (String)dataModel.getValueAt(table.getSelectedRow(),0);
				DenimComponent dc = DenimComponentRegistry.getInstance().getComponent(name);
				if(dc.isIntrinsic())
					return;
				DenimComponentRegistry.getInstance().unregisterComponent(name);
				table.revalidate();
			}
		});*/
	}
	
	public void useComponent(String name) {
		
		sheet.bufferUpcomingRender(1000);
		
		sheet.setGobWithFocus(null);
		Point2D abspoint = new Point2D.Double(sheet.getLastX(), sheet.getLastY());
	    DenimComponent component = DenimComponentRegistry.getInstance().getComponent(name);
	    DenimComponentInstance newInstance = component.newInstance();
		Point2D localPt  = GraphicalObjectLib.absoluteToLocal(sheet, abspoint);
		sheet.add(newInstance, GraphicalObjectGroup.KEEP_REL_POS);
		newInstance.moveTo(COORD_REL, localPt);

	    newInstance.getInkInterpreter().setEnabled(false);
	    newInstance.setAddLeftButtonStrokes(false);
	    sheet.remove(newInstance);

		if (newInstance instanceof DenimCustomComponentInstance) {
			DenimPanel instPanel = (DenimPanel)newInstance.getDisplayedState();
			instPanel.getLabel().setVisible(false);
			instPanel.getLabel().getPhrase().setVisible(false);
		}

		GraphicalObject shallow = DenimUtils.findPanel(sheet, abspoint);

		DenimPanel panel;
		DenimSketch sketch;
		MacroCommand macro = new MacroCommand();
        
       // System.err.println(shallow.getClass().toString());
        
		if (shallow instanceof DenimPanel) 
		{
			panel = (DenimPanel)shallow;
			sketch = panel.getSketch();
			GraphicalObjectGroup parent;
			DenimGroup group = DenimUtils.findDeepestNestedDenimGroup(sketch, abspoint);
			
			if (group == null) {
				 parent = sketch;
				 macro.addCommand(
					   new InsertCommand(parent, newInstance, GraphicalObjectGroup.KEEP_REL_POS));
            
				 AffineTransform newXform = new AffineTransform();
 				 while (parent.getUniqueID() != sheet.getUniqueID()) {
					 newXform.concatenate(parent.getInverseTransform(COORD_REL));
					 parent = parent.getParentGroup();
				 }
				 newXform.concatenate(newInstance.getTransform(COORD_REL));
                 
                 // keep the instance in the sketch
                 double xratio = (sketch.getBounds2D(COORD_ABS).getMaxX()-abspoint.getX())/newInstance.getWidth2D(COORD_ABS);//LOCAL);
                 double yratio = (sketch.getBounds2D(COORD_ABS).getMaxY()-abspoint.getY())/newInstance.getHeight2D(COORD_ABS);//LOCAL);
                 /*
				 Point2D sketchLocal  = 
					 GraphicalObjectLib.absoluteToLocal(sketch, abspoint);
				 
                 double xratio = (sketch.getBounds2D(COORD_LOCAL).getMaxX()-sketchLocal.getX())/newInstance.getWidth2D(COORD_LOCAL);
                 double yratio = (sketch.getBounds2D(COORD_LOCAL).getMaxY()-sketchLocal.getY())/newInstance.getHeight2D(COORD_LOCAL);
                 */
                 double ratio = xratio>yratio?yratio:xratio;
                 if(ratio>1)
                     ratio = 1;
                 
                 //System.err.println(xratio + "," + yratio);
                 newXform.concatenate(AffineTransform.getScaleInstance(ratio, ratio));
                 
				 macro.addCommand(new SetTransformCommand(newInstance, newXform));            
			}        
            else 
            {
				 parent = group;
				 macro.addCommand(
					new InsertCommand(parent, newInstance, GraphicalObjectGroup.KEEP_REL_POS));

				 // Calculate new transform that will keep the instance in the same
				 // absolute location
				 AffineTransform newXform = new AffineTransform();
				 while (parent.getUniqueID() != sheet.getUniqueID()) {
					newXform.concatenate(parent.getInverseTransform(COORD_REL));
					parent = parent.getParentGroup();
				 }
				 newXform.concatenate(newInstance.getTransform(COORD_REL));
				 macro.addCommand(new SetTransformCommand(newInstance, newXform));         
            }
         
			cmdqueue.doCommand(macro);
			panel.componentInstanceIsAdded(newInstance);
		}
		
		sheet.bufferUpcomingRender(1);
		sheet.flushRenderRequests();
	}
}


//==============================================================================

/*
Copyright (c) 2003-2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
    must display the following acknowledgement:

        This product includes software developed by the Group for User 
        Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
    derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/