//// See bottom of source code for software license
package edu.berkeley.guir.lib.awt.geom;

import java.awt.*;
import java.awt.geom.*;
import java.util.LinkedList;
import java.util.WeakHashMap;

/**
 * Miscellaneous geometry utilities.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
final public class GeomLib {

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * No instances allowed.
    */
   private GeomLib() {
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MISC UTILITIES   ====================================================

   /**
    * Got sick of writing this piece of code over and over. Silly Polygon
    * should be cloneable.
    *
    * @return a clone of the specified Polygon.
    */
   public final static Polygon clonePolygon(Polygon p) {
      int   nPts = p.npoints;
      int[] xPts = new int[nPts];
      int[] yPts = new int[nPts];

      System.arraycopy(p.xpoints, 0, xPts, 0, nPts);
      System.arraycopy(p.ypoints, 0, yPts, 0, nPts);

      return (new Polygon(xPts, yPts, nPts));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Make a Polygon out of a Rectangle.
    *
    * @param  rect is a Rectangle to make into a Polygon.
    * @return a Polygon the same as the Rectangle.
    */
   public final static Polygon makePolygon(Rectangle rect) {
      Polygon p = new Polygon();
      p.addPoint(rect.x,              rect.y);
      p.addPoint(rect.x + rect.width, rect.y);
      p.addPoint(rect.x + rect.width, rect.y + rect.height);
      p.addPoint(rect.x,              rect.y + rect.height);

      return (p);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Make a Polygon out of a Rectangle.
    *
    * @param  rect is a Rectangle to make into a Polygon.
    * @return a Polygon the same as the Rectangle.
    */
   public final static Polygon makePolygon(Rectangle2D rect) {
      Polygon p = new Polygon();
      int x = (int) rect.getX();
      int y = (int) rect.getY();
      int w = (int) rect.getWidth();
      int h = (int) rect.getHeight();

      p.addPoint(x,     y);
      p.addPoint(x + w, y);
      p.addPoint(x + w, y + h);
      p.addPoint(x,     y + h);

      return (p);
   } // of method

   //-----------------------------------------------------------------

   public final static Polygon makePolygon(Shape s) {
      ShapeLineIterator it   = new ShapeLineIterator(s);
      Polygon           p    = new Polygon();
      Line2D            line = new Line2D.Double();

      if (it.hasNext()) {
         it.next(line);
         p.addPoint((int) line.getX2(), (int) line.getY2());
      }

      while (it.hasNext()) {
         it.next(line);
         p.addPoint((int) line.getX2(), (int) line.getY2());
      }

      return (p);
   } // of method

   //===========================================================================

   public final static Rectangle2D makeRectangle(float x1, float y1, 
                                                 float x2, float y2) {
       return (makeRectangle(x1, y1, x2, y2, 0));
   } // of method

   //-----------------------------------------------------------------

   public final static Rectangle2D makeRectangle(float x1, float y1, 
                                                 float x2, float y2, 
                                                 float halo) {

       return (new Rectangle2D.Float(
                    (float) Math.min(x1, x2) - halo,
                    (float) Math.min(y1, y2) - halo,
                    (float) Math.abs(x2 - x1) + 2*halo,
                    (float) Math.abs(y2 - y1) + 2*halo)  );

   } // of method

   //-----------------------------------------------------------------

   public final static Rectangle2D makeRectangle(Point2D ptAA, Point2D ptBB) {
       return (makeRectangle((float) ptAA.getX(), (float) ptAA.getY(),
                             (float) ptBB.getX(), (float) ptBB.getY(),
                             0));
   } // of method

   //-----------------------------------------------------------------

   public final static Rectangle2D makeRectangle(Point2D ptAA, Point2D ptBB,
                                                 float halo) {
       return (makeRectangle((float) ptAA.getX(), (float) ptAA.getY(),
                             (float) ptBB.getX(), (float) ptBB.getY(),
                             halo));
   } // of method

   //===   MISC UTILITIES   ====================================================
   //===========================================================================



   //===========================================================================
   //===   GRAPHICS SIMPLIFICATION UTILITIES   =================================

   static WeakHashMap cache = new WeakHashMap(500);

   //-----------------------------------------------------------------

   public static final Polygon simplify(int[] xpoints, int[] ypoints, 
                                        int npoints) {

      //// 0.1. Quick check. No point in doing anything if too simple.
      if (npoints < 8) {
         return (new Polygon(xpoints, ypoints, npoints));
      }

      //// 0.2. See if it is already cached.
      Object obj = cache.get(xpoints);
      if (obj != null) {
         return ((Polygon) obj);
      }

      double[] dThetaArray = new double[npoints];
      Polygon  simplePoly  = new Polygon();
      double   thetaOld;
      double   thetaNew;

      //// 1. Calculate the absolute delta of the angle for each point.
      thetaNew       = Math.atan2(xpoints[0], ypoints[0]);
      dThetaArray[0] = Double.MAX_VALUE;
      for (int i = 1; i < dThetaArray.length; i++) {
         thetaOld       = thetaNew;
         thetaNew       = Math.atan2(xpoints[i], ypoints[i]);
         dThetaArray[i] = Math.abs(thetaNew - thetaOld);
      }

      //// 2. Add local minima points.
      for (int i = 0; i < dThetaArray.length; i++) {
         //// 2.1. Always add the first point to the polygon.
         ////      Also, always add the last point to the polygon.
         if (i == 0 || i == dThetaArray.length - 1) {
            simplePoly.addPoint(xpoints[i], ypoints[i]);
         }
         //// 2.2. Normal case.
         else {
            if (dThetaArray[i] <= dThetaArray[i - 1] &&
                dThetaArray[i] <= dThetaArray[i + 1]) {
               simplePoly.addPoint(xpoints[i], ypoints[i]);
            }
         }
      }

      cache.put(xpoints, simplePoly);

      return (simplePoly);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Given a polygon, return a "simpler" version of it.
    */
   public static final Polygon simplify(Polygon p) {
      return (simplify(p.xpoints, p.ypoints, p.npoints));
   } // of method

   //===   GRAPHICS SIMPLIFICATION UTILITIES   =================================
   //===========================================================================



   //===========================================================================
   //===   TRANSFORM METHODS   =================================================

   /**
    * Find txC, where <CODE>[txA] * [txB] = [txB] * [txC]</CODE>.
    * Used for calculating AffineTransforms and Sticky Graphical Objects.
    *
    * @param txA   is as stated in the equation above.
    * @param txB   is as stated in the equation above.
    * @param txOut is storage space, use null to create new storage.
    */
   public static AffineTransform calcPassthrough(AffineTransform txA, 
                                                 AffineTransform txB,
                                                 AffineTransform txOut) {
      //// 1. Create storage if necessary.
      if (txOut == null) {
         txOut = new AffineTransform();
      }

      //// 2. 
      txOut.setTransform(txA);
      txOut.concatenate(txB);
      try {
         txOut.preConcatenate(txB.createInverse());
      }
      catch (Exception e) {
         System.err.println("This error should never happen");
         System.err.println(e);
      }
      return (txOut);
   } // of method

   //===========================================================================

   private static float[] polygonToArray(Polygon p) {
      //// 1. First, convert the points of the Polygon into a floating
      ////    point array.
      float[] fptsOld = new float[2*p.npoints];

      //// 2. Populate the array.
      int index;
      for (int i = 0; i < p.npoints; i++) {
         index = 2*i;
         fptsOld[index]     = p.xpoints[i];
         fptsOld[index + 1] = p.ypoints[i];
      }

      //// 3. Return the array.
      return (fptsOld);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Run the transformation on a polygon, returning the same polygon with
    * transformed coordinates.
    *
    * @param  tx is the AffineTransform to execute on the Polygon.
    * @param  p  is Polygon to transform. p is modified.
    * @return a new Polygon with transformed coordinates.
    */
   public static Polygon transformPolygonInPlace(AffineTransform tx, 
                                                 Polygon p) {
      //// 1. First, convert the points of the Polygon into a floating
      ////    point array.
      float[] fpts = polygonToArray(p);

      //// 2. Transform the array.
      tx.transform(fpts, 0, fpts, 0, p.npoints);

      //// 3. Convert back to a polygon.
      for (int i = 0; i < fpts.length; i++) {
         if (i % 2 == 0) {
            p.xpoints[i / 2] = (int) fpts[i];
         }
         else {
            p.ypoints[i / 2] = (int) fpts[i];
         }
      }

      //// 4. Return our recalculated baby.
      return(p);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Run the transformation on a polygon, returning a new polygon with
    * transformed coordinates.
    *
    * @param  tx is the AffineTransform to execute on the Polygon.
    * @param  p  is Polygon to transform. p is NOT modified in any way.
    * @return a new Polygon with transformed coordinates. Please note that
    *         you may want to keep the original Polygon around, since
    *         we have to do some rounding, meaning that this new Polygon
    *         may not necessarily have the same shape as the original.
    */
   public static Polygon transformPolygon(AffineTransform tx, Polygon p) {
      return (transformPolygonInPlace(tx, clonePolygon(p)));
   } // of method

   //===========================================================================

   /**
    * @see #transformRectangle(AffineTransform, Rectangle2D, Rectangle2D)
    */
   public static Rectangle2D transformRectangle(AffineTransform tx, 
                                                Rectangle2D rSrc) {
      return (transformRectangle(tx, rSrc, new Rectangle2D.Double()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Apply a transform to a Rectangle. Note that this doesn't quite make sense
    * if there are shears or rotations. In these cases, we just take the
    * bounding points. 
    *
    * @param  tx   is the transform to apply.
    * @param  rSrc is the source rectangle to start with.
    * @param  rDst is the destination rectangle after transformation. Okay if
    *              same as rSrc.
    * @return a reference to rDst.
    */
   public static Rectangle2D transformRectangle(AffineTransform tx, 
                                          Rectangle2D rSrc, Rectangle2D rDst) {

      //// 1. Convert source rectangle into array of points.
      double[] rectArray = new double[8];
      rectArray[0] = rSrc.getX();                        // top-left
      rectArray[1] = rSrc.getY();
      rectArray[2] = rSrc.getX() + rSrc.getWidth();      // top-right
      rectArray[3] = rSrc.getY();
      rectArray[4] = rSrc.getX() + rSrc.getWidth();      // bottom-right
      rectArray[5] = rSrc.getY() + rSrc.getHeight();
      rectArray[6] = rSrc.getX();                        // bottom-left
      rectArray[7] = rSrc.getY() + rSrc.getHeight();

      //// 2. Apply transform on array of points.
      tx.transform(rectArray, 0, rectArray, 0, 4);

      //// 3. Convert array of points into bounding box.
      ////    Hopefully optimized for speed.
      double  x1;
      double  y1;
      double  x2;
      double  y2;
      short   min;

      //// 3.1. Figure out the left side and the right side.
      if (rectArray[0] < rectArray[2]) {
         //// r[0] < r[2]
         min = 0;
      }
      else {
         //// r[2] < r[0]
         min = 2;
      }
      if (rectArray[4] < rectArray[6]) {
         //// r[4] < r[6]
         x1 = Math.min(rectArray[4], rectArray[min]);
         x2 = Math.max(rectArray[6], rectArray[(min + 2) % 4]);
      }
      else {
         //// r[6] < r[4]
         x1 = Math.min(rectArray[6], rectArray[min]);
         x2 = Math.max(rectArray[4], rectArray[(min + 2) % 4]);
      }

      //// 3.2. Figure out the top side and the bottom side.
      if (rectArray[1] < rectArray[3]) {
         //// r[1] < r[3]
         min = 1;
      }
      else {
         //// r[3] < r[1]
         min = 3;
      }
      if (rectArray[5] < rectArray[7]) {
         //// r[5] < r[7]
         y1 = Math.min(rectArray[5], rectArray[min]);
         y2 = Math.max(rectArray[7], rectArray[(min + 2) % 4]);
      }
      else {
         //// r[7] < r[5]
         y1 = Math.min(rectArray[7], rectArray[min]);
         y2 = Math.max(rectArray[5], rectArray[(min + 2) % 4]);
      }

      rDst.setRect(x1, y1, x2 - x1, y2 - y1);
      return (rDst);
   } // of method

   //===   TRANSFORM METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   SHAPE UTILITY METHODS   =============================================

   /**
    * Convert a path iterator into a polygon. 
    */
   public static final Polygon pathIteratorToPolygon(PathIterator it) {
      Polygon p        = new Polygon();
      float[] ptsArray = new float[6];

      while (!it.isDone()) {
         int segmentType = it.currentSegment(ptsArray);
         Point2D newPt = getEndPointOfPathIteratorSegment(segmentType, ptsArray);
         if (newPt != null) { 
            p.addPoint((int)newPt.getX(), (int)newPt.getY());
         }
         it.next();
      }

      return (p);
   } // of method

   //-----------------------------------------------------------------
   
   /**
    * Convert a path iterator into a polygon with floating-point coordinates. 
    */
   public static final Polygon2D pathIteratorToPolygon2D(PathIterator it) {
      Polygon2D p        = new Polygon2D();
      float[] ptsArray   = new float[6];

      p.setClosed(false);
      while (!it.isDone()) {
         int segmentType = it.currentSegment(ptsArray);
         Point2D newPt = getEndPointOfPathIteratorSegment(segmentType, ptsArray);
         if (newPt != null) { 
            p.addPoint(newPt);
         }
         else {
            p.setClosed(true);
         }
         it.next();
      }

      return (p);
   } // of method

   //-----------------------------------------------------------------
   
   /**
    * Given a segment returned by PathIterator, returns the end point of
    * the segment, or null if the segment is a
    * {@link java.awt.geom.PathIterator#SEG_CLOSE}.
    * 
    * @param segmentType the path-segment type:
    * {@link java.awt.geom.PathIterator#SEG_MOVETO},
    * {@link java.awt.geom.PathIterator#SEG_LINETO},
    * {@link java.awt.geom.PathIterator#SEG_QUADTO},
    * {@link java.awt.geom.PathIterator#SEG_CUBICTO}, or
    * {@link java.awt.geom.PathIterator#SEG_CLOSE}
    * @param coords an array of 6 floats that store the coordinates
    */
   public static final Point2D getEndPointOfPathIteratorSegment(
      int segmentType,
      float[] coords) {
      
      Point2D endPoint = null; 
            
      if ((segmentType == PathIterator.SEG_LINETO)
         || (segmentType == PathIterator.SEG_MOVETO)) {
         endPoint = new Point2D.Float(coords[0], coords[1]);
      }
      else if (segmentType == PathIterator.SEG_QUADTO) {
         endPoint = new Point2D.Float(coords[2], coords[3]);
      }
      else if (segmentType == PathIterator.SEG_CUBICTO) {
         endPoint = new Point2D.Float(coords[4], coords[5]);
      }
      
      return endPoint;
   }

   //-----------------------------------------------------------------

   /**
    * Merge two polygons together, if they intersect. Otherwise, just return
    * the first polygon.
    * <P>
    * This is useful for making Patch areas larger.
    */
   public static final Polygon mergePolygons(Polygon a, Polygon b) {
      //// 1. If the bounding boxes do not intersect, then do nothing and
      ////    just return the first polygon.
      Rectangle rectA = a.getBounds();
      Rectangle rectB = b.getBounds();
      if (!rectA.intersects(rectB)) {
         return (a);
      }

      //// 2. Otherwise, add them together.
      Area areaA = new Area(a);
      Area areaB = new Area(b);
      areaA.add(areaB);

      //// 3. If the merged area is not a closed path, then just stick
      ////    with the original shape.
      if (!areaA.isSingular()) {
         return (a);
      }

      //// 4. Otherwise, convert the area into a Polygon.
      PathIterator it = areaA.getPathIterator(new AffineTransform());
      return (pathIteratorToPolygon(it));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Cut polygon b out of the boundaries of polygon a.
    */
   public static final Polygon cutPolygon(Polygon a, Polygon b) {
      //// 1. If the bounding boxes do not intersect, then do nothing and
      ////    just return the first polygon.
      Rectangle rectA = a.getBounds();
      Rectangle rectB = b.getBounds();
      if (!rectA.intersects(rectB)) {
         return (a);
      }

      //// 2. Otherwise, add them together.
      Area areaA = new Area(a);
      Area areaB = new Area(b);
      areaA.subtract(areaB);

      //// 3. If the merged area is not a closed path, then just stick
      ////    with the original shape.
      if (!areaA.isSingular()) {
         return (a);
      }

      //// 4. Otherwise, convert the area into a Polygon.
      PathIterator it = areaA.getPathIterator(new AffineTransform());
      return (pathIteratorToPolygon(it));
   } // of method

   //===   SHAPE UTILITY METHODS   =============================================
   //===========================================================================




   //===========================================================================
   //===   DISTANCE METHODS   ==================================================

   public final static double minDistance(Shape saa, Shape sbb) {
      double       mind = Double.MAX_VALUE;
      double       tmpd = Double.MAX_VALUE;
      float[]      ptaa = new float[6];
      float[]      ptbb = new float[6];
      PathIterator itaa;
      PathIterator itbb;

      itaa = saa.getPathIterator(null);
      while (itaa.isDone() == false) {
         itaa.currentSegment(ptaa);
         itbb   = sbb.getPathIterator(null);
         while (itbb.isDone() == false) {
            itbb.currentSegment(ptbb);
            tmpd = GeomLib.distance(ptaa[0], ptaa[1], ptbb[0], ptbb[1]);
            mind = Math.min(mind, tmpd);
            itbb.next();
         }
         itaa.next();
      } // of while itaa

      return (mind);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Calculate the minimum distance from all points in the Polygon to
    * the specified point. Make sure that the two are in the same coordinate
    * space.
    *
    * <P>
    * Technically, this implementation is not correct, since we should really
    * be checking the minimum distance from the specified point to all of the
    * line segments in the Polygon. This was just easier to write and seems
    * good enough for most purposes.
    *
    * @param  p is the Polygon to check.
    * @param  x is the x-coordinate to check from.
    * @param  y is the y-coordinate to check from.
    * @return the distance from (x,y) to the closest point in Polygon p.
    */
   public final static float minDistance(Polygon p, int x, int y) {
      double            minDistance = Float.MAX_VALUE;
      Line2D            line        = new Line2D.Float();
      ShapeLineIterator it;
      double            tmpDistance;

      //// 1. For each line in the polygon...
      it = new ShapeLineIterator(p.getPathIterator(new AffineTransform()));
      while (it.hasNext()) {

         //// 1.1. Get the distance value of the point from this line.
         ////      Update min distance value.
         line        = it.next(line);
         tmpDistance = line.ptSegDist(x, y);
         if (tmpDistance < minDistance) {
            minDistance = tmpDistance;
         }
      }
      return((float) minDistance);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Figure out the min distance between two polygons.
    */
   public final static float minDistance(Polygon polyA, Polygon polyB) {
      float min = Float.MAX_VALUE;

      for (int i = 0; i < polyB.npoints; i++) {
         min = Math.min(min, minDistance(polyA, 
                                      polyB.xpoints[i], polyB.ypoints[i]));
      }

      return (min);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Calculate the distance from the (x,y) point to the center of the
    * specified Rectangle. Make sure that the two are in the same coordinate
    * space.
    *
    * @param  r    is the Rectangle whose center point we will use.
    * @param  x    is the x-coordinate of the other point to use.
    * @param  y    is the y-coordinate of the other point to use.
    * @return the distance from rect's center to (x,y).
    */
   public final static float minDistanceToCenter(Rectangle r, int x, int y) {
      //// 1. Find the minimum distance from the specified point to
      ////    the center of the group.
      return(distance(x, y, r.width / 2, r.height / 2));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Calculate the Euclidean distance from point 1 to point 2.
    *
    * @param x1 is the x-coordinate of the first point.
    * @param y1 is the y-coordinate of the first point.
    * @param x2 is the x-coordinate of the second point.
    * @param y2 is the y-coordinate of the second point.
    */
   public final static float distance(int x1, int y1, int x2, int y2) {
      return ((float) Math.sqrt((x1 - x2)*(x1 - x2)  +  (y1 - y2)*(y1 - y2)));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Calculate the Euclidean distance from point 1 to point 2.
    *
    * @param x1 is the x-coordinate of the first point.
    * @param y1 is the y-coordinate of the first point.
    * @param x2 is the x-coordinate of the second point.
    * @param y2 is the y-coordinate of the second point.
    */
   public final static float distance(double x1, double y1, 
                                      double x2, double y2) {
      return ((float) Math.sqrt((x1 - x2)*(x1 - x2)  +  (y1 - y2)*(y1 - y2)));
   } // of method

   //-----------------------------------------------------------------

   public final static float distance(Point2D p1, Point2D p2) {
      return (distance(p1.getX(), p1.getY(), p2.getX(), p2.getY()));
   } // of method

   //===   DISTANCE METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   INTERSECTION METHODS   ==============================================

   /**
    * Get a list of all points where the line intersects with the Shape.
    */
   public final static java.util.List calcIntersectPoints(Line2D l, Shape s) {
      ShapeLineIterator it   = new ShapeLineIterator(s);
      LinkedList        list = new LinkedList();
      Line2D            line;
      Point2D           pt;

      while (it.hasNext()) {
         line = it.next();
         pt   = calcIntersectPoint(l, line);
         if (pt != null) {
            list.add(pt);
         }
      }

      return (list);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Figure out where these two lines intersect.
    *
    * @return null if no intersect.
    */
   public final static Point2D calcIntersectPoint(Line2D lAA, Line2D lBB) {
      return (calcIntersectPoint(lAA.getX1(), lAA.getY1(),
                                 lAA.getX2(), lAA.getY2(),
                                 lBB.getX1(), lBB.getY1(),
                                 lBB.getX2(), lBB.getY2()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Figure out where these two lines intersect.
    *
    * @return null if no intersect.
    */
   public final static Point2D calcIntersectPoint(double xa1, double ya1, 
                                                  double xa2, double ya2,
                                                  double xb1, double yb1,
                                                  double xb2, double yb2) {
      Point2D pt = null;

      //// 1. Quick check.
      ////    One x in lAA has to be between lBB x1 and x2
      ////    One y in lAA has to be between lBB y1 and y2
      if (Line2D.linesIntersect(xa1, ya1, xa2, ya2,
                                xb1, yb1, xb2, yb2) == false) {
         return (pt);
      }

      //// 2. If we intersect, calculate intercept point.
      ////    Here is the equation (where x' y' is the intercept point):
      ////       x' = xb1 + b*(xb2 - xb1) = xa1 + a*(xa2 - xa1)
      ////       y' = yb1 + b*(yb2 - yb1) = ya1 + a*(ya2 - ya1)
      ////
      ////    Now we have two unknowns and two equations.
      ////
      double dxa = xa2 - xa1;
      double dya = ya2 - ya1;
      double dxb = xb2 - xb1;
      double dyb = yb2 - yb1;

      //// 3. Calculate _a_.
      double a   = (ya1*dxb - yb1*dxb - xa1*dyb + xb1*dyb) / 
                      (dxa*dyb - dya*dxb);

      pt = new Point2D.Double(xa1 + a*dxa, ya1 + a*dya);
      return (pt);
   } // of method

   //===   INTERSECTION METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

/*
   public static void main(String[] argv)
      throws Exception {

      System.out.println(calcIntersectPoint(-2, 0, 6, 4, 0, 0, 10, 10));
      System.out.println(calcIntersectPoint(6, 4, -2, 0, 0, 0, 10, 10));
      System.out.println(calcIntersectPoint(6, 4, -2, 0, 10, 10, 0, 0));

      Line2D      l = new Line2D.Float(0, 0, 10, 0);
      Rectangle2D r = new Rectangle2D.Float(3, -3, 3, 6);

      System.out.println(calcIntersectPoints(l, r));
   } // of method
*/

/*
   public static void main(String[] argv) 
      throws Exception {

      Polygon p = new Polygon();

      p.addPoint(0, 0);
      p.addPoint(10, 0);
      p.addPoint(10, 10);
      p.addPoint(0, 10);

System.out.println(edu.berkeley.guir.lib.util.StringLib.toString(simplify(p)));

      PathIterator it = p.getPathIterator(new AffineTransform());
      System.out.println(edu.berkeley.guir.lib.util.StringLib.toString(it));

      System.out.println(GeomLib.minDistance(p, 0, 0));
      System.out.println(GeomLib.minDistance(p, 12, 0));
      System.out.println(GeomLib.minDistance(p, 12, 5));

      System.out.println();

   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
