package edu.berkeley.guir.damask.view.visual.event;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.geom.*;
import java.util.Iterator;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.connection.ConnectionDest;
import edu.berkeley.guir.damask.connection.ConnectionSource;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.DamaskLayer.DeviceTypeLayer;
import edu.berkeley.guir.damask.view.nodes.DamaskPPath;
import edu.berkeley.guir.damask.view.nodes.DamaskWindowTitle;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.berkeley.guir.damask.view.visual.component.*;
import edu.berkeley.guir.damask.view.visual.component.Label;
import edu.berkeley.guir.damask.view.visual.dialog.*;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.satin.command.Command;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.berkeley.guir.lib.satin.stroke.StrokeLib;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.activities.PActivity;
import edu.umd.cs.piccolo.event.PDragSequenceEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.util.PBounds;

/** 
 * The event handler that handles the pencil tool.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-28-2003 James Lin
 *                               Created PencilEventHandler
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-28-2003
 */
public class PencilEventHandler extends PDragSequenceEventHandler {
   private static final double DEFAULT_DISTANCE_THRESHOLD = 200.0;
   private static final Color LAST_LABEL_COLOR = Color.GREEN;
   private static final Stroke DEFAULT_STROKE = new BasicStroke(1.0f);
   
   private DamaskPPath stroke = null;
   private Label lastLabel = null;
   private DamaskPPath lastStrokeInLabel = null;
   

   //Used for creating arrows
   private PNode startNode;

   public PencilEventHandler() {
      getEventFilter().setAndMask(InputEvent.BUTTON1_MASK);
   }
   
   // Overrides method in parent class.
   public void startDrag(PInputEvent e) {
      super.startDrag(e);
      startNode = e.getPath().getPickedNode();

      final Point2D p = e.getPosition();

      stroke = new DamaskPPath();
      stroke.setPickable(false);
      stroke.moveTo((float)p.getX(), (float)p.getY());
      stroke.setStroke(
         new BasicStroke((float) (1 / e.getCamera().getViewScale())));
         
      // This should add to front.
      final VisualCanvas canvas = ((VisualCanvas)e.getComponent());
      canvas.getLayer().addChild(stroke);
      
      // Stop any text editing
      canvas.stopTextEditing();
   }


   // Overrides method in parent class.
   public void drag(PInputEvent e) {
      super.drag(e);
      updateStroke(e);
   }


   // Overrides method in parent class.
   public void endDrag(PInputEvent e) {
      super.endDrag(e);
      updateStroke(e);

      // Remove the stroke so we can see what's underneath.
      stroke.removeFromParent();
      
      // Set the stroke width back to 1, so that PPath.setBounds(), which will
      // eventually get called on stroke, will behave as expected
      stroke.setStroke(DEFAULT_STROKE);
      
      final Point2D ptCameraCoords = e.getPositionRelativeTo(e.getCamera());
      final PNode endNode =
         e.getCamera()
          .pick(ptCameraCoords.getX(), ptCameraCoords.getY(), 1)
          .getPickedNode();

      final DamaskCanvas canvas = (DamaskCanvas)e.getComponent();

      // Check if the end point and start point are in the same page.
      final PageView startPageView =
         (PageView)DamaskAppUtils.getAncestor(startNode, PageView.class);

      final PageView endPageView =
         (PageView)DamaskAppUtils.getAncestor(endNode, PageView.class);

      // If the end point is not in a page, then tell the canvas.
      if (endPageView == null) {
         canvas.setInsideNode(null);
      }
      
      // If the start point or end point is in a page that is "This Device
      // Only", but the current layer is "All Device Types", then ignore this
      // stroke.
      final DamaskLayer layer = (DamaskLayer)canvas.getLayer();
      if (startPageView != null) {
         final Dialog startDialog =
            ((Page)startPageView.getModel()).getDialog();
         if (startDialog.getDeviceType() != DeviceType.ALL
            && layer.getDeviceTypeForNewElement() == DeviceType.ALL) {
            return;
         }
      }
      if (endPageView != null) {
         final Dialog endDialog =
            ((Page)endPageView.getModel()).getDialog();
         if (endDialog.getDeviceType() != DeviceType.ALL
            && layer.getDeviceTypeForNewElement() == DeviceType.ALL) {
            return;
         }
      }

      // If the end point and start point are in the same page, then the
      // stroke might be completely in the page and be added to the page.
      // If not, the stroke might be an arrow.
      if ((startPageView == endPageView) && (startPageView != null)) {
         createOrModifyContentIfPossible(canvas, layer, startPageView);
      }
      else {
         createConnectionIfPossible(canvas, layer, endNode);
      }
   }

   
   /**
    * Adds the stroke to existing content or creates new content from the
    * stroke, if appropriate.
    */
   private void createOrModifyContentIfPossible(
      final DamaskCanvas canvas,
      final DamaskLayer layer,
      final PageView startPageView) {

      final Page startPage = (Page)startPageView.getModel();

      // If the page is only for one device type, but we're trying to add an
      // all-device-type label, then don't allow that.
      if ((startPage.getDialog().getDeviceType() != DeviceType.ALL)
         && (layer.getDeviceTypeLayer() == DeviceTypeLayer.ALL)) {

         return;
      }

      // Compare the bounding box of stroke and the page in the canvas'
      // coordinates.
      final GeneralPath strokePath = (GeneralPath)stroke.getPathReference().clone();
      final Rectangle2D strokeBounds = strokePath.getBounds2D();
      DamaskAppUtils.localToGlobal(stroke, strokeBounds);
      
      // If the stroke's box lies within the page's title, then add the 
      // stroke to that title.
      final DamaskWindowTitle pViewTitle = startPageView.getTitleBar();
      final PBounds pViewTitleBounds = pViewTitle.getBounds();
      pViewTitle.localToGlobal(pViewTitleBounds);

      final Rectangle2D titleIntersection =
         pViewTitleBounds.createIntersection(strokeBounds);
      final double intersectionArea =
         titleIntersection.isEmpty()
            ? 0
            : titleIntersection.getHeight() * titleIntersection.getWidth();
      final double strokeArea =
         strokeBounds.isEmpty()
            ? 0
            : strokeBounds.getHeight() * strokeBounds.getWidth();

      if ((intersectionArea >= strokeArea * 0.5) &&
          (intersectionArea != 0) && (strokeArea != 0)) {
//         // If the stroke is only a click, filter it out.
//         if ((strokeBounds.getWidth() == 0)
//            && (strokeBounds.getHeight() == 0)) {
//            return;
//         }
//         // Transform the stroke's bounds to the page region's coordinate
//         // system.
//         DamaskAppUtils.globalToLocal(pViewTitle.getLabel(), strokeBounds);
//         DamaskAppUtils.resizeGeneralPath(strokePath, strokeBounds);
//      
//         final Content content = startPage.getTitle();
//      
//         final MacroCommand cmd = new ModifyGraphMacroCommand();
//         cmd.addCommand(
//            new AddStrokeCommand(
//               content,
//               createPathInContentFullBounds(
//                  strokePath,
//                  startPage.getDeviceType(),
//                  content)));
//         cmd.addCommand(
//            new SetContentDisplayModeCommand(
//               content, startPage.getDeviceType(), Content.INK));
//         canvas.getDocument().getCommandQueue().doCommand(canvas, cmd);
         return;
      }
      
      
      // If the stroke's box lies within the page's contents, then
      // add the stroke to that page.
      final PageViewContents pViewContents = (PageViewContents)startPageView.getContents();
      final PBounds pViewContentsBounds = pViewContents.getBounds();
      pViewContents.localToGlobal(pViewContentsBounds);

      if (DamaskAppUtils.containsRect(pViewContentsBounds, strokeBounds)) {
         final PageRegionView regionView =
            findContainingRegion(pViewContents, strokeBounds);
      
         // Transform the stroke's bounds to the page region's coordinate
         // system.
         DamaskAppUtils.globalToLocal(regionView, strokeBounds);
         final GeneralPath resizedPath =
            (GeneralPath)stroke.getPathReference().clone();
         DamaskAppUtils.resizeGeneralPath(resizedPath, strokeBounds);
         stroke.setPathTo(resizedPath);
      
         if (lastLabel != null) {
            lastLabel.setStrokePaint(null);
         }
         
         // Find out if the stroke is within an existing label. If so, add the
         // stroke to that label.
         Command cmd = getAddToExistingContentCommand(regionView);
         
         // Find out if the stroke is near the label most recently
         // added to the page region. If so, add the stroke to that label.
         if (cmd == null) {
            cmd = getAddToNearbyContentCommand(regionView);
         }
         
         // Otherwise, create a new label with the stroke.
         if (cmd == null) {
            cmd = getCreateNewContentCommand(layer, regionView);
         }
      
         canvas.getDocument().getCommandQueue().doCommand(canvas, cmd);
         if (!(cmd instanceof AddStrokeCommand)) {
            lastLabel = regionView.getMostRecentlyAddedLabel();
         }
         lastStrokeInLabel =
            (DamaskPPath)lastLabel.getStrokesContainer().getChild(
               lastLabel.getStrokesContainer().getChildrenCount() - 1);
         if (lastLabel != null) {
            lastLabel.setStrokePaint(LAST_LABEL_COLOR);
         }
      }
   }


   /**
    * Find the page region within the given contents that contains the given
    * rectangle.
    */
   private PageRegionView findContainingRegion(
      final PageViewContents pViewContents,
      final Rectangle2D strokeBounds) {
      
      // Figure out which page region the stroke belongs to
      double largestIntersectionArea = 0;
      PageRegionView regionView = null;
      
      for (Iterator k = pViewContents.getRegionViews().iterator();
         k.hasNext(); ) {
      
         final PageRegionView currentRegionView =
            (PageRegionView)k.next();
         final Rectangle2D currentRegionViewBounds =
            currentRegionView.getBounds();
         currentRegionView.localToGlobal(currentRegionViewBounds);

         final double intersectionArea;
         
         if ((strokeBounds.getWidth() == 0) && (strokeBounds.getHeight() == 0)){
            if (currentRegionViewBounds.contains(strokeBounds.getX(), strokeBounds.getY())) {
               intersectionArea = 1;
            }
            else {
               intersectionArea = 0;
            }
         }
         else if (strokeBounds.getWidth() == 0) {
            if (currentRegionViewBounds.getX() <= strokeBounds.getX() &&
                strokeBounds.getX() <= currentRegionViewBounds.getMaxX()) {
               if (strokeBounds.getY() <= currentRegionViewBounds.getY() &&
                   currentRegionViewBounds.getY() <= strokeBounds.getMaxY()) {
                  intersectionArea =
                     strokeBounds.getMaxY() - currentRegionViewBounds.getY();
               }
               else if (strokeBounds.getY() <= currentRegionViewBounds.getMaxY() &&
                     currentRegionViewBounds.getMaxY() <= strokeBounds.getMaxY()) {
                  intersectionArea =
                     currentRegionViewBounds.getMaxY() - strokeBounds.getY();
               }
               else if (currentRegionViewBounds.getY() <= strokeBounds.getY() &&
                     strokeBounds.getMaxY() <= currentRegionViewBounds.getMaxY()) {
                  intersectionArea = strokeBounds.getHeight();
               }
               else {
                  intersectionArea = 0;
               }
            }
            else {
               intersectionArea = 0;
            }
         }
         else if (strokeBounds.getHeight() == 0) {
            if (currentRegionViewBounds.getY() <= strokeBounds.getY() &&
                  strokeBounds.getY() <= currentRegionViewBounds.getMaxY()) {
               if (strokeBounds.getX() <= currentRegionViewBounds.getX() &&
                   currentRegionViewBounds.getX() <= strokeBounds.getMaxX()) {
                  intersectionArea =
                     strokeBounds.getMaxX() - currentRegionViewBounds.getX();
               }
               else if (strokeBounds.getX() <= currentRegionViewBounds.getMaxX()
                  && currentRegionViewBounds.getMaxX() <= strokeBounds.getMaxX()) {
                  intersectionArea =
                     currentRegionViewBounds.getMaxX() - strokeBounds.getX();
               }
               else if (currentRegionViewBounds.getX() <= strokeBounds.getX() &&
                     strokeBounds.getMaxX() <= currentRegionViewBounds.getMaxX()) {
                  intersectionArea = strokeBounds.getWidth();
               }
               else {
                  intersectionArea = 0;
               }
            }
            else {
               intersectionArea = 0;
            }
         }
         else {
            final Rectangle2D intersection =
               currentRegionViewBounds.createIntersection(strokeBounds);
            if (intersection.isEmpty()) {
               intersectionArea = 0;
            }
            else {
               intersectionArea =
                  intersection.getHeight() * intersection.getWidth();
            }
         }
         
         if (intersectionArea > largestIntersectionArea) {
            largestIntersectionArea = intersectionArea;
            regionView = currentRegionView;
         }
      }
      return regionView;
   }


   /**
    * Checks if there is existing content in which the stroke has been drawn,
    * and if so, creates a command to add the stroke to that content.
    */
   private Command getAddToExistingContentCommand(
      final PageRegionView regionView) {
         
      Command cmd = null;
      final GeneralPath strokePath =
         (GeneralPath)stroke.getPathReference().clone();
      final Rectangle2D strokeBounds = strokePath.getBounds2D();
      
      for (Iterator i = regionView.getChildrenIterator(); i.hasNext(); ) {
         final PNode node = (PNode)i.next();
         if (node instanceof ComponentView) {
            final ComponentView componentView = (ComponentView)node;
            final Object editableContents =
               componentView.getEditableContents();
            if (editableContents instanceof Label) {
               final Label label = (Label)editableContents;

               if ((label.getDisplayMode() == Content.INK)
                  && DamaskAppUtils.containsRect(
                        label.getFullBounds(), strokeBounds)) {
                  // Convert the stroke to the label's coordinate system
                  DamaskAppUtils.localToGlobal(regionView, strokeBounds);
                  DamaskAppUtils.globalToLocal(label, strokeBounds);
                  DamaskAppUtils.resizeGeneralPath(strokePath, strokeBounds);
                  
                  final Content content = (Content)label.getModel();
                  final PageRegion region = (PageRegion)regionView.getModel();
                  cmd =
                     new AddStrokeCommand(
                        content,
                        createPathInContentFullBounds(
                           strokePath,
                           region.getDeviceType(),
                           content));
                  break;
               }
            }
         }
      }
      return cmd;
   }


   /**
    * Checks if there is existing content near where the stroke has been drawn,
    * and if so, creates a command to add the stroke to that content.
    */
   private Command getAddToNearbyContentCommand(
      final PageRegionView regionView) {
         
      final GeneralPath strokePath =
         (GeneralPath)stroke.getPathReference().clone();
      Command cmd = null;         
      if ((lastStrokeInLabel != null)
         && lastLabel.getDisplayMode().equals(Content.INK)) {
         final Rectangle2D strokeBounds = strokePath.getBounds2D();
         
         // Convert the stroke to the coordinate system of the label
         // most recently added.
         DamaskAppUtils.localToGlobal(regionView, strokeBounds);
         DamaskAppUtils.globalToLocal(lastLabel, strokeBounds);
         
         DamaskAppUtils.resizeGeneralPath(strokePath, strokeBounds);
         
         final TimedStroke satinStroke =
            new TimedStroke(GeomLib.makePolygon(strokePath));
         
         final TimedStroke satinLastStroke =
            new TimedStroke(
               GeomLib.makePolygon(
                  lastStrokeInLabel.getPathReference()));
         if (StrokeLib
            .computeHandwritingDistance(satinStroke, satinLastStroke)
            < DEFAULT_DISTANCE_THRESHOLD) {
            
            final Content lastContent = (Content)lastLabel.getModel();
            final PageRegion region =
               (PageRegion)regionView.getModel();
            cmd =
               new AddStrokeCommand(
                  lastContent,
                  createPathInContentFullBounds(
                     strokePath,
                     region.getDeviceType(),
                     lastContent));
         }
      }
      return cmd;
   }


   /**
    * Creates new content from the stroke.
    */
   private Command getCreateNewContentCommand(
      final DamaskLayer layer,
      final PageRegionView regionView) {
         
      final GeneralPath strokePath =
         (GeneralPath)stroke.getPathReference().clone();
      final PageRegion region = (PageRegion)regionView.getModel();
      final Rectangle2D strokeBounds = strokePath.getBounds2D();
      final Rectangle2D newStrokeBounds =
         new Rectangle2D.Double(
            0, 0, strokeBounds.getWidth(), strokeBounds.getHeight());
      
      final DeviceType deviceType = layer.getDeviceTypeForNewElement();
      final AffineTransform transform =
         AffineTransform.getTranslateInstance(
            strokeBounds.getX(),
            strokeBounds.getY());
      strokePath.transform(
         AffineTransform.getTranslateInstance(
            -strokeBounds.getX(), -strokeBounds.getY()));
//      DamaskAppUtils.resizeGeneralPath(strokePath, newStrokeBounds);
      final Content content = new Content(deviceType, strokePath);
      content.setTransform(region.getDeviceType(), transform);
      content.setBounds(region.getDeviceType(), newStrokeBounds);
      
      final MacroCommand cmd = new ModifyGraphMacroCommand();
      DamaskUtils.addCommandsForAddingComponentToMacroCommand(cmd, content, region);
      return cmd;
   }


   /**
    * Creates a connetion from the stroke, if appropriate.
    */
   private void createConnectionIfPossible(
      final DamaskCanvas canvas,
      final DamaskLayer layer,
      PNode endNode) {

      boolean addedArrow = false;

      // We know the stroke is not completely within a page.
      
      // Check if the stroke is an arrow. A stroke is an arrow if:
      // * start point is within a ConnectionSource (control or page)
      // * end point is within a ConnectionDest (component group or page)
      
      // Starting with startNode, walk up the tree, looking for the first
      // InteractionElementView whose model is a ConnectionSource.
      while ((startNode != null)
         && !isModelInstanceOf(startNode, ConnectionSource.class)) {
         // When there is no parent, this returns null
         startNode = startNode.getParent();
      }
      if (startNode != null) {
         // We might have an arrow.
         // Starting with endNode, walk up the tree, looking for the first
         // InteractionElementView whose model is a page.
         // TODO generalize to ConnectionDest (i.e., also allow Controls)
      
         while ((endNode != null)
            && !isModelInstanceOf(endNode, Page.class)) {
            endNode = endNode.getParent();
            // when there is no parent, this returns null
         }
         if (endNode != null) {
            // Figure out condition of page
            final int condition;
            final InteractionElementView startElementView =
               (InteractionElementView)startNode;
            if (startElementView instanceof ControlView) {
               condition =
                  ((ControlView)startElementView)
                     .getPageView()
                     .getDesignTimeCondition();
            }
            else {
               condition = -1;  // value doesn't matter
            }
            
            final ConnectionSource newConnectionSource = (ConnectionSource)
                     ((InteractionElementView)startNode).getModel();
            final GeneralPath strokePath =
               (GeneralPath)stroke.getPathReference().clone();
            final AddConnectionCommand command =
               new AddConnectionCommand(
                  canvas.getDeviceType(),
                  layer.getDeviceTypeLayer()
                     == DamaskLayer.DeviceTypeLayer.ALL,
                  newConnectionSource,
                  new InvokeEvent(newConnectionSource),
                  condition,
                  (ConnectionDest)
                     ((InteractionElementView)endNode).getModel(),
                  strokePath);
            if (command.shouldRun()) {
               canvas.getDocument().getCommandQueue().doCommand(canvas, command);
               addedArrow = true;
            }
         }
      }
      // Otherwise, we do not have an arrow -- flicker the stroke
      if (!addedArrow) {
         canvas.getLayer().addChild(stroke);
         canvas.getRoot().addActivity(
            new FlickerStrokeActivity(stroke, 2000L, 500L));
      }
   }


   /**
    * Returns whether the specified node is an interaction element view whose
    * model is an instance of the specified class.
    */
   private boolean isModelInstanceOf(final PNode node, final Class aClass) {
      if (node instanceof InteractionElementView) {
         return aClass.isInstance(((InteractionElementView)node).getModel());
      }
      else {
         return false;
      }
   }


   private void updateStroke(PInputEvent e) {
      Point2D p = e.getPosition();
      stroke.lineTo((float)p.getX(), (float)p.getY());
   }
   
   
   /**
    * Returns a path that is the same as the specified path, scaled
    * to fit the full bounds of the specified content.
    */
   private GeneralPath createPathInContentFullBounds(
      final GeneralPath path,
      final DeviceType deviceType,
      final Content content) {

      final Rectangle2D contentFullBounds =
         content.getFullSizeBounds(Content.INK);

      final GeneralPath newPath = (GeneralPath)path.clone();
      
      if ((contentFullBounds == null)
         || (content.getPreferredDisplayMode(deviceType) != Content.INK)) {
         return newPath;
      }

      // If the content in the specified region has been shrunk or expanded,
      // then we must expand or shrink the specified path to match the content's
      // original bounds.
      final Rectangle2D contentOldBounds = content.getBounds(deviceType);
      final Rectangle2D pathBounds = path.getBounds2D();
      
      // Calculate the new x and width. They are scaled relative to the ratio
      // of the old and full width, unless either of them are 0.      
      final double newX;
      final double newWidth;
      if ((contentOldBounds.getWidth() < 1)
         || (contentFullBounds.getWidth() < 1)) {
         newX =
            pathBounds.getX()
               - contentOldBounds.getX()
               + contentFullBounds.getX();
         newWidth = pathBounds.getWidth();
      }
      else {
         final double strokeFracX =
            (pathBounds.getX() - contentOldBounds.getX())
               / contentOldBounds.getWidth();
         final double strokeFracWidth =
            pathBounds.getWidth() / contentOldBounds.getWidth();
            
         newX = strokeFracX * contentFullBounds.getWidth()
            + contentFullBounds.getX();
         newWidth = strokeFracWidth * contentFullBounds.getWidth();
      }

      // Calculate the new y and height. They are scaled relative to the ratio
      // of the old and full height, unless either of them are 0.      
      final double newY;
      final double newHeight;
      if ((contentOldBounds.getHeight() < 1)
         || (contentFullBounds.getHeight() < 1)) {
         newY =
            pathBounds.getY()
               - contentOldBounds.getY()
               + contentFullBounds.getY();
         newHeight = pathBounds.getHeight();
      }
      else {
         final double strokeFracY =
            (pathBounds.getY() - contentOldBounds.getY())
               / contentOldBounds.getHeight();
         final double strokeFracHeight =
            pathBounds.getHeight() / contentOldBounds.getHeight();
            
         newY = strokeFracY * contentFullBounds.getHeight()
            + contentFullBounds.getY();
         newHeight = strokeFracHeight * contentFullBounds.getHeight();
      }

      final Rectangle2D pathFullBounds =
         new Rectangle2D.Double(newX, newY, newWidth, newHeight);

      DamaskAppUtils.resizeGeneralPath(newPath, pathFullBounds);
      return newPath;
   }

   /**
    * An activity that continuously pans the canvas.
    */
   private static class FlickerStrokeActivity extends PActivity {
      private final DamaskPPath stroke;
      private boolean flag = false;
      
      private FlickerStrokeActivity(DamaskPPath stroke, long aDuration) {
         super(aDuration);
         this.stroke = stroke;
      }

      private FlickerStrokeActivity(DamaskPPath stroke, long aDuration, long aStepRate) {
         super(aDuration, aStepRate);
         this.stroke = stroke;
      }

      private FlickerStrokeActivity(DamaskPPath stroke, long aDuration, long aStepRate, long aStartTime) {
         super(aDuration, aStepRate, aStartTime);
         this.stroke = stroke;
      }

      protected void activityStep(long elapsedTime) {
         super.activityStep(elapsedTime);
         flag = !flag;
         stroke.setStrokePaint(flag ? Color.RED : Color.GRAY);
      }
      
      protected void activityFinished() {
         super.activityFinished();
         stroke.removeFromParent();
      }

   }
}
