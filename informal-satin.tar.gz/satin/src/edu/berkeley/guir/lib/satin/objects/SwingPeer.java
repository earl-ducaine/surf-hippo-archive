/*
 * Created on Aug 15, 2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package edu.berkeley.guir.lib.satin.objects;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.awt.geom.*;

/**
 * @author yangli
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class SwingPeer extends GraphicalObjectImpl {
	
	protected JComponent mRealCom = null;
	private AffineTransform mTrans = null;
	private Rectangle2D mIdealRect = null;
	
	private String mPeerID = new String();
	private static long peerCount = 0;
	private Rectangle mLatestBounds = null;
	
	public SwingPeer(JComponent com) {
		mRealCom = com;
		this.setBoundingPoints2D(COORD_REL, com.getBounds());
		mIdealRect = new Rectangle2D.Double(0,0,
						com.getBounds().getWidth(), com.getBounds().getHeight());
		peerCount++;
		mPeerID += peerCount;
		mRealCom.setName(mPeerID);
	}
	
	public String getName() {
		return mPeerID;
	}
	
	/*
	private void makeEverythingVisible(Component com) {
		
		com.setVisible(true);
		com.setEnabled(true);
		
		if(com instanceof Container)
		{
			Container container = (Container)com;
			for(int i=0; i<container.getComponentCount(); i++)
			{
				Component kid = container.getComponent(i);
				makeEverythingVisible(kid);
			}
		}
	}
	*/
	public JComponent getRealComponent() {
		return mRealCom;
	}
	
    public void updateComponent() {
        Rectangle2D box = this.getBounds2D(COORD_ABS);
        if(this.getSheet().getBounds2D(COORD_ABS).intersects(box)
                &&this.isVisible())
        {
            this.mRealCom.setVisible(true);
        }
        else
        {
            this.mRealCom.setVisible(false);
        }
    }

	public void defaultRender(SatinGraphics sg) {
		
	   if(sg.getIssuer().equals("sheet"))
	   {
			if(mTrans!=sg.getTransform())
			{
				mTrans = (AffineTransform)sg.getTransform().clone();
				Rectangle2D rect = GeomLib.transformRectangle(mTrans, mIdealRect);
				
				this.mLatestBounds = rect.getBounds();
				Rectangle box = new Rectangle(
									(int)rect.getMinX(),(int)rect.getMinY(),
									(int)rect.getWidth(),(int)rect.getHeight());
									
				Rectangle parentBounds = mRealCom.getParent().getBounds();
				if(box.getMaxX()<=10||
					box.getMinX()>=parentBounds.getMaxX()-10||
					box.getMinY()>=parentBounds.getMaxY()-10||
					box.getMaxY()<=10)
				{
					mRealCom.setVisible(false);						
				}
				else
				{
					mRealCom.setVisible(true);
					mRealCom.setBounds((int)box.getMinX(), (int)box.getMinY(), (int)box.getWidth(), (int)box.getHeight());
				}
				
//				this.makeEverythingVisible(mRealCom);
			}
	   }
	}
	
	public Rectangle getLatestBounds() {
		return mLatestBounds;
	}
	
	public void setSize(double w, double h) {
		this.setBoundingPoints2D(COORD_LOCAL,
					new Rectangle2D.Double( 
					this.getBounds2D(COORD_LOCAL).getMinX(),
					this.getBounds2D(COORD_LOCAL).getMinY(),
					w,h));
		mIdealRect = new Rectangle2D.Double(0, 0, w, h);
	}
	
	public void delete() {
		super.delete();
		Container co = mRealCom.getParent();
		if(co!=null)
			co.remove(mRealCom);
	}
	
	public void setVisible(boolean b) {
		this.mRealCom.setVisible(b);
		super.setVisible(b);
	}
}
