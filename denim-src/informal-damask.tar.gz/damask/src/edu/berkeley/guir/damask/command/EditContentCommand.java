package edu.berkeley.guir.damask.command;

import java.awt.image.BufferedImage;
import java.util.Collection;

import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that edits content.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  01-04-2004 James Lin
 *                               Created EditContentCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 01-04-2004
 */
public class EditContentCommand extends UndoableCommand
implements ModifyGraphCommand {

   private final boolean changeText;
   private final String oldText;
   private final String newText;
   private final boolean changeImage;
   private final BufferedImage oldImage;
   private final BufferedImage newImage;
   private final boolean changeStrokes;
   private final Collection/*<GeneralPath>*/ oldStrokes;
   private final Collection/*<GeneralPath>*/ newStrokes;
   
   private final Content content;
   
   /**
    * Constructs the command.
    *  
    * @param content the content to edit
    * @param newText the new text of the content
    */      
   public EditContentCommand(final Content content, final String newText) {
      this(content, true, newText, false, null, false, null);
   }
   
   /**
    * Constructs the command.
    *  
    * @param content the content to edit
    * @param newImage the new image of the content
    */      
   public EditContentCommand(
      final Content content,
      final BufferedImage newImage) {

      this(content, false, null, true, newImage, false, null);
   }
   
   /**
    * Constructs the command.
    *  
    * @param content the content to edit
    * @param changeText true if the content's text should be changed
    * @param newText the new text of the content
    * @param changeImage true if the content's image should be changed
    * @param newImage the new image of the content
    * @param changeStrokes true if the content's strokes should be changed
    * @param newStrokes the new strokes of the content
    */      
   protected EditContentCommand(
      final Content content,
      final boolean changeText,
      final String newText,
      final boolean changeImage,
      final BufferedImage newImage,
      final boolean changeStrokes,
      final Collection/*<GeneralPath>*/ newStrokes) {
      
      this.content = content;
      
      oldText = content.getText();
      this.changeText = changeText;
      this.newText = newText;
      
      oldImage = content.getImage();
      this.changeImage = changeImage;
      this.newImage = newImage;
      
      oldStrokes = content.getStrokes();
      this.changeStrokes = changeStrokes;
      this.newStrokes = newStrokes;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      final StringBuffer sb = new StringBuffer();
      sb.append("Edit content " + content + " ");
      if (changeText) {
         sb.append("text");
      }
      else if (changeImage) {
         sb.append("image");
      }
      else if (changeStrokes) {
         sb.append("strokes");
      }
      return sb.toString();
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      if (changeText) {
         content.setText(newText);
      }
      if (changeImage) {
         content.setImage(newImage);
      }
      if (changeStrokes) {
         content.setStrokes(newStrokes);
      }
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      if (changeText) {
         content.setText(oldText);
      }
      if (changeImage) {
         content.setImage(oldImage);
      }
      if (changeStrokes) {
         content.setStrokes(oldStrokes);
      }
   }
}
