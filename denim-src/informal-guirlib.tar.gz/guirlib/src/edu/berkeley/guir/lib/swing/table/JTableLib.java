//// See bottom of file for software license
package edu.berkeley.guir.lib.swing.table;

import java.awt.Component;
import java.awt.Dimension;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

/**
 * Utilities for manipulating JTables.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 06 2004
 */
public class JTableLib {

    //==========================================================================
    //===   TABLE METHODS   ====================================================

    public static void sizeAllColumnsToFitData(final JTable table) {
        sizeColumnsToFitData(0, table.getColumnCount(), table);
    } // of method

    //--------------------

    /**
     * @param flagAlsoCheckHeaders means to check the width of the headers too
     */
    public static void sizeAllColumnsToFitData(JTable  table,
                                               boolean flagAlsoCheckHeaders) {
        sizeColumnsToFitData(0, table.getColumnCount(), table,
                                                    flagAlsoCheckHeaders);
    } // of method

    //----------------------------------------------------------------

    public static void sizeColumnsToFitData(int    startCol, 
                                            int    endCol, 
                                            JTable table) {
        sizeColumnsToFitData(startCol, endCol, table, false);
    } // of method

    //--------------------

    /**
     * @param startCol is the column to start with (0 is first column)
     * @param endCol   is the column to end with (exclusive)
     * @param table    is the table to resize
     * @param flagAlsoCheckHeaders means to check the width of the headers too
     */
    public static void sizeColumnsToFitData(int     startCol, 
                                            int     endCol, 
                                            JTable  table,
                                            boolean flagAlsoCheckHeaders) {

        //// 1. For each column...
        for (int col = startCol; col < endCol; col++) {
            TableColumn curColumn = table.getColumn(table.getColumnName(col));

            //// 1.1. Skip invalid columns.
            if (curColumn == null) {
                continue;
            }

            //// 1.2. Translate to the model      
            int modelColumn = curColumn.getModelIndex();

            //// 1.3. Prepare to go thru each row for the widest piece of data.
            int maxColWidth = 0;
            int numRows     = table.getRowCount();
            int start       = 0;

            //// 1.4. Go thru each row for the widest piece of data.
            if (flagAlsoCheckHeaders == true) {
                start = -1;
            }

            //// 1.5. For each row...
            for (int row = start; row < numRows; row++) {
                TableCellRenderer curRend;
                Object            value;
                Component         curComp;
                Dimension         cellDim;

                //// 1.5.1. Get the cell renderer for that cell.
                curRend = table.getCellRenderer(row, modelColumn);

                //// 1.5.2. Get the value for that cell.
                if (row < 0) {
                    value = table.getColumnName(col);
                }
                else {
                    value = table.getValueAt(row, modelColumn);
                }

                //// 1.5.3. Calculate the width and store the widest one.
                curComp = curRend.getTableCellRendererComponent(table, value, 
                                                 true, true, row, modelColumn);
                cellDim = curComp.getPreferredSize();

                if (cellDim.width > maxColWidth) {
                    maxColWidth = cellDim.width;
                }
            }


            //// 2. Set the column width to fit the maximum             
            Dimension cellSpacing = table.getIntercellSpacing();
            curColumn.setPreferredWidth(maxColWidth + 
                                (cellSpacing != null ? cellSpacing.width : 1));
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Make the table fit the headers.
     */
    public static void sizeAllColumnsToFitHeaders(JTable table) {
        sizeColumnsToFitHeaders(0, table.getColumnCount(), table);
    } // of method

    //--------------------

    /**
     * Make the table fit the headers.
     */
    public static void sizeColumnsToFitHeaders(int    startCol,
                                               int    endCol,
                                               JTable table) {

        //// 1. For each column...
        for (int col = startCol; col < endCol; col++) {
            TableColumn curColumn = table.getColumn(table.getColumnName(col));

            //// 1.1. Skip invalid columns.
            if (curColumn == null) {
                continue;
            }

            //// 1.2. Translate to the model      
            int               modelColumn = curColumn.getModelIndex();
            Object            value       = table.getColumnName(col);
            Component         curComp;
            Dimension         cellDim;
            TableCellRenderer curRend;
            int               row         = -1;

            //// 1.3. Calculate the width and store the widest one.
            curRend = table.getCellRenderer(row, modelColumn);
            curComp = curRend.getTableCellRendererComponent(table, value, 
                                                 true, true, row, modelColumn);
            cellDim = curComp.getPreferredSize();


            //// 1.4. Set the column width to fit the maximum             
            Dimension cellSpacing = table.getIntercellSpacing();
            curColumn.setPreferredWidth((int) (cellDim.getWidth()) + 
                                (cellSpacing != null ? cellSpacing.width : 1));
        }
    } // of method

    //===   TABLE METHODS   ====================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
