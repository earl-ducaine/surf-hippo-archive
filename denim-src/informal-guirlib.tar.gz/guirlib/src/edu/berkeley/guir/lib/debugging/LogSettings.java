//// See bottom of file for software license
package edu.berkeley.guir.lib.debugging;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.logging.LogManager;

/**
 * Constants for handling logging.
 * Done this way to avoid the vagaries of locating configuration files
 * on various systems.
 * <P>
 * This class should be statically configured at compile-time.
 * <P>
 * For this to work, you have to specify this class on the command-line
 * as follows:
 * <CODE>
 *   java -Djava.util.logging.config.file=LogSettings [class]
 * </CODE>
 *
 * <P>
 * Here is a sample configuration file, to help explain how
 * things work.
 * <PRE>
 *  ############################################################
 *  #  	Default Logging Configuration File
 *  #
 *  # You can use a different file by specifying a filename
 *  # with the java.util.logging.config.file system property.  
 *  # For example java -Djava.util.logging.config.file=myfile
 *  ############################################################
 *
 *  ############################################################
 *  #  	Global properties
 *  ############################################################
 *
 *  # "handlers" specifies a comma separated list of log Handler 
 *  # classes.  These handlers will be installed during VM startup.
 *  # Note that these classes must be on the system classpath.
 *  # By default we only configure a ConsoleHandler, which will only
 *  # show messages at the INFO and above levels.
 *  handlers= java.util.logging.ConsoleHandler
 *
 *  # To also add the FileHandler, use the following line instead.
 *  #handlers= java.util.logging.FileHandler, java.util.logging.ConsoleHandler
 *
 *  # Default global logging level.
 *  # This specifies which kinds of events are logged across
 *  # all loggers.  For any given facility this global level
 *  # can be overriden by a facility specific level
 *  # Note that the ConsoleHandler also has a separate level
 *  # setting to limit messages printed to the console.
 *  # 
 *  # Options include:
 *  #    SEVERE (highest value)
 *  #    WARNING
 *  #    INFO
 *  #    CONFIG
 *  #    FINE
 *  #    FINER
 *  #    FINEST (lowest value)
 *  #    OFF
 *  .level= INFO
 *
 *  ############################################################
 *  # Handler specific properties.
 *  # Describes specific configuration info for Handlers.
 *  ############################################################
 *
 *  # default file output is in user's home directory.
 *  java.util.logging.FileHandler.pattern = %h/java%u.log
 *  java.util.logging.FileHandler.limit = 50000
 *  java.util.logging.FileHandler.count = 1
 *  java.util.logging.FileHandler.formatter = java.util.logging.XMLFormatter
 *
 *  # Limit the message that are printed on the console to INFO and above.
 *  java.util.logging.ConsoleHandler.level = INFO
 *  java.util.logging.ConsoleHandler.formatter = java.util.logging.SimpleFormatter
 *
 *  ############################################################
 *  # Facility specific properties.
 *  # Provides extra control for each logger.
 *  ############################################################
 *
 *  # For example, set the com.xyz.foo logger to only log SEVERE
 *  # messages:
 *  com.xyz.foo.level = SEVERE
 * </PRE>
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Jan 30 2004
 */
public class LogSettings {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    //// JDK 1.4 logging constants

    /** Highest level warning for Java logging */
    public static final String SEVERE  = "SEVERE";   // highest
    public static final String WARNING = "WARNING";
    public static final String INFO    = "INFO";
    public static final String CONFIG  = "CONFIG";
    public static final String FINE    = "FINE";
    public static final String FINER   = "FINER";
    /** Lowest level warning for Java logging */
    public static final String FINEST  = "FINEST";   // lowest
    public static final String OFF     = "OFF";

    //----------------------------------------------------------------

    //// Apache commons logging constants

    /** Highest level warning for Apache logging */
    public static final String APACHE_FATAL   = SEVERE;     // highest
    public static final String APACHE_ERROR   = SEVERE;
    public static final String APACHE_WARN    = WARNING;
    public static final String APACHE_INFO    = INFO;
    public static final String APACHE_DEBUG   = FINE;
    /** Lowest level warning for Apache logging */
    public static final String APACHE_TRACE   = FINEST;     // lowest

    //===   CONSTANTS   ========================================================
    //==========================================================================



    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    Properties props = new Properties();

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================



    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    public LogSettings() {
        //// 1. Init the properties.
        init();

        //// 2. Save the properties to a stream.
        ByteArrayOutputStream bostream;
        ByteArrayInputStream  bistream;

        try {
            bostream = new ByteArrayOutputStream();
            props.store(bostream, null);
            bistream = new ByteArrayInputStream(bostream.toByteArray());

            //// 2. Load the properties.
            LogManager.getLogManager().readConfiguration(bistream);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    } // of method

    //----------------------------------------------------------------

    protected void init() {
        //// 1. Initialize the handlers.
        props.setProperty("handlers", getHandlers());

        //// 2. Set the default levels
        props.setProperty(".level",   getDefaultLevel());

        //// 3. Set the console properties
        props.setProperty("java.util.logging.ConsoleHandler.level", 
                          getConsoleLevel());
        props.setProperty("java.util.logging.ConsoleHandler.formatter", 
                          getConsoleFormatter());

        //// 4. Set the file properties
        props.setProperty("java.util.logging.FileHandler.pattern", 
                          getFilePattern());
        props.setProperty("java.util.logging.FileHandler.limit", 
                          getFileLimit());
        props.setProperty("java.util.logging.FileHandler.count", 
                          getFileCount());
        props.setProperty("java.util.logging.FileHandler.formatter", 
                          getFileFormatter());


        //// 5. Set the levels for individual classes
        Map      map = getClassLevels();
        Iterator it  = map.keySet().iterator();
        String   strKey;
        String   strVal;

        while (it.hasNext()) {
            strKey = (String) it.next();
            strVal = (String) map.get(strKey);
            props.setProperty(strKey + ".level", strVal);
        }

    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================



    //==========================================================================
    //===   LOG PROPERTY ACCESSOR METHODS   ====================================

    /**
     * Get the handlers that the logger will use.
     * Currently returns <CODE>"java.util.logging.ConsoleHandler"</CODE>.
     * Return a comma-separated list, for example, 
     * <CODE>
     * "java.util.logging.FileHandler, java.util.logging.ConsoleHandler"
     * </CODE>
     */
    protected String getHandlers() {
        return ("java.util.logging.ConsoleHandler");
    } // of method

    //----------------------------------------------------------------

    /**
     * Default level for all.
     * Currently returns "INFO". 
     * Override if desired.
     */
    protected String getDefaultLevel() {
        return (INFO);
    } // of method

    //----------------------------------------------------------------

    /**
     * Default level for console.
     * Currently returns "INFO". 
     * Override if desired. 
     * This takes precedence over any levels specified for a specific class
     * (ie in {@link #getClassLevels()})
     */
    protected String getConsoleLevel() {
        return (INFO);
    } // of method

    /**
     * Default formatter for Console.
     * Currently returns "java.util.logging.SimpleFormatte"
     * Override if desired.
     */
    protected String getConsoleFormatter() {
        return ("java.util.logging.SimpleFormatter");
    } // of method

    //----------------------------------------------------------------

    /**
     * Default level for File (which is not on by default).
     * Currently returns "FINEST"
     * Override if desired.
     */
    protected String getFileLevel() {
        return (FINEST);
    } // of method

    /**
     * Default pattern for File.
     * Override if desired.
     * See <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/util/logging/FileHandler.html">FileHandler JavaDoc</A>
     */
    protected String getFilePattern() {
        return ("%h/java%u.log");
    } // of method

    /**
     * Default File limit.
     * Override if desired.
     * See <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/util/logging/FileHandler.html">FileHandler JavaDoc</A>
     */
    protected String getFileLimit() {
        return ("50000");
    } // of method

    /**
     * Default File count.
     * Override if desired.
     * See <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/util/logging/FileHandler.html">FileHandler JavaDoc</A>
     */
    protected String getFileCount() {
        return ("1");
    } // of method

    /**
     * Default File formatter.
     * Override if desired.
     * See <A HREF="http://java.sun.com/j2se/1.4.2/docs/api/java/util/logging/FileHandler.html">FileHandler JavaDoc</A>
     */
    protected String getFileFormatter() {
        return ("java.util.logging.XMLFormatter");
    } // of method

    //----------------------------------------------------------------

    /**
     * Set the debugging level for a specific log.
     * For example:
     * <CODE>
     *    map.put("packageA.classA", LogSettings.APACHE_FATAL);
     *    map.put("packageB.classB", LogSettings.APACHE_INFO);
     * </CODE>
     * Note that the handler also has a separate debugging level.
     * That is, you may have specified that class <CODE>classAA</CODE> 
     * have output level <CODE>LogSettings.APACHE_TRACE</CODE>, but
     * if the handler only has level <CODE>INFO</CODE> then the debugging
     * output will still be ignored. 
     */
    protected Map getClassLevels() {
        return (Collections.EMPTY_MAP);
    } // of method

    //===   LOG PROPERTY ACCESSOR METHODS   ====================================
    //==========================================================================



    //==========================================================================
    //===   SELF-TESTING MAIN     ==============================================

    public static void main(String[] argv) {

    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
