package edu.berkeley.guir.lib.gesture.apps;

import edu.berkeley.guir.lib.gesture.*;
import java.io.*;

public class gstogsa
{
  public static void main(String[] args)
  {
    if (args.length < 1) {
      System.err.println("gnames: usage: java gstogsa file.gs [file2.gs ...]");
      System.exit(-1);
    }

    for (int i = 0; i < args.length; i++) {
      GestureSetFrame frame =
	new GestureSetFrame("gstogsa", false);

      String oldName = args[i];
      File oldFile = new File(oldName);
      frame.openFile(oldFile);

      // change gs to gsa
      File newFile = new File(oldName + "a");
      if (newFile.exists()) {
	System.err.print("gstogsa: File '" + newFile.getPath() +
			 "' exists. Overwrite (y/n)? ");
	BufferedReader reader =
	  new BufferedReader(new InputStreamReader(System.in));
	try {
	  String answer = reader.readLine();
	  if (!answer.equals("y") && !answer.equals("yes")) {
	    System.exit(1);
	  }
	}
	catch (IOException e) {
	  System.err.println("gstogsa: Error reading standard input.  Aborting...");
	  System.exit(1);
	}
      }
      frame.saveFile(frame.makeTypedFile(newFile, "ASCII"));
    }
    
    System.exit(0);
  }

}
