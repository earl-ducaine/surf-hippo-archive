package edu.berkeley.guir.damask.view.visual.event;

import java.awt.event.InputEvent;
import java.awt.geom.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.command.ModifyGraphMacroCommand;
import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.berkeley.guir.damask.view.visual.VisualLayer;
import edu.berkeley.guir.damask.view.visual.dialog.*;
import edu.berkeley.guir.lib.satin.command.Command;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.event.*;
import edu.umd.cs.piccolo.util.PBounds;

/** 
 * The event handler that handles inserting components into pages.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-20-2003 James Lin
 *                               Created InsertComponentHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-20-2003
 */
public abstract class InsertComponentHandler extends PDragSequenceEventHandler {
   private final Class componentViewType;
   private PNode tempComponentView;

   /**
    * Constructs a handler which will instantiate a component of the specified
    * type.
    * 
    * @param componentViewType a class which is a descendant of
    * {@link edu.berkeley.guir.damask.view.visual.component.ComponentView}
    */
   public InsertComponentHandler(final Class componentViewType) {
      setEventFilter(new PInputEventFilter(InputEvent.BUTTON1_MASK));
      this.componentViewType = componentViewType;
   }


   /**
    * Create the initial component view, for when the user starts dragging. 
    */
   protected void createTempComponentView(final PInputEvent e) {
      try {
         final PLayer layer = ((PCanvas)e.getComponent()).getLayer();
         
         // call createTempView() on the component type
         final Method createTempViewMethod =
            componentViewType.getMethod("createTempView", null);
         tempComponentView = (PNode)createTempViewMethod.invoke(null, null);
      
         layer.addChild(tempComponentView);
         updateComponentView(e, tempComponentView);
      }
      catch (SecurityException e1) {
         DamaskAppExceptionHandler.log(e1);
      }
      catch (NoSuchMethodException e1) {
         DamaskAppExceptionHandler.log(e1);
      }
      catch (IllegalArgumentException e2) {
         DamaskAppExceptionHandler.log(e2);
      }
      catch (IllegalAccessException e2) {
         DamaskAppExceptionHandler.log(e2);
      }
      catch (InvocationTargetException e2) {
         DamaskAppExceptionHandler.log(e2.getCause());
         DamaskAppExceptionHandler.log(e2);
      }
   }


   /**
    * Updates the temporary view of a component while the mouse is being
    * dragged.
    */
   protected void updateComponentView(
      final PInputEvent e,
      final PNode componentView) {
         
      componentView.setOffset(e.getPosition());      
   }


   // @Override
   public void startDrag(PInputEvent e) {
      super.startDrag(e);        
      createTempComponentView(e);
   }

   // @Override
   public void drag(final PInputEvent e) {
      super.drag(e);
      updateComponentView(e, tempComponentView);
   }

   // @Override
   public void endDrag(final PInputEvent e) {
      super.endDrag(e);
      updateComponentView(e, tempComponentView);
      
      final PBounds componentBds = tempComponentView.getBounds();
      tempComponentView.localToGlobal(componentBds);
      tempComponentView.removeFromParent();
      
      // Calculate which page region to add the component to
      final Point2D ptCameraCoords = e.getPositionRelativeTo(e.getCamera());
      PNode endNode =
         e.getCamera()
          .pick(ptCameraCoords.getX(), ptCameraCoords.getY(), 1)
          .getPickedNode();

      // Check if the end point and start point are in the same page.
      final PageRegionView regionView =
         (PageRegionView)DamaskAppUtils.getAncestor(
            endNode, PageRegionView.class);
      
      if (regionView != null) {
         final VisualCanvas canvas = (VisualCanvas)e.getComponent();
         final VisualLayer layer = ((VisualLayer)canvas.getLayer());

         // We will make the component's width and height be in the same
         // units the same as the page region's coordinate system, so
         // transform the component's bounds to that system. 
         regionView.globalToLocal(componentBds);
         
         // Add the component.
         canvas.getDocument().getCommandQueue().doCommand(
            canvas,
            getInsertComponentCommand(
               layer.getDeviceTypeForNewElement(),
               (PageRegion)regionView.getModel(),
               AffineTransform.getTranslateInstance(
                  componentBds.getX(),
                  componentBds.getY()),
               new Rectangle2D.Double(
                  0,
                  0,
                  componentBds.getWidth(),
                  componentBds.getHeight())));
      }
   }  
   
   
   /**
    * Returns a command for inserting a new component.
    * 
    * @param region the page region to insert the component in 
    * @param transform the affine transform of the new component
    * @param bounds the bounds of the new component
    */
   protected Command getInsertComponentCommand(
      final DeviceType deviceType,
      final PageRegion region,
      final AffineTransform transform,
      final Rectangle2D bounds) {

      final Component newComponent =
         createNewComponent(deviceType, region, transform, bounds);
      
      final MacroCommand cmd = new ModifyGraphMacroCommand();
      DamaskUtils.addCommandsForAddingComponentToMacroCommand(cmd,
                                                        newComponent,
                                                        region);
      
      return cmd;
   }

   
   /**
    * Returns a new component to be added.
    */
   protected abstract Component createNewComponent(
      DeviceType deviceType,
      PageRegion region,
      AffineTransform transform,
      Rectangle2D bounds);
}
