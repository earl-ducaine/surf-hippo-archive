package edu.berkeley.guir.damask.view.visual;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.Transferable;
import java.awt.event.*;
import java.awt.geom.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;
import java.util.List;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.event.ChangeEvent;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.Direction;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.DamaskDocument.DamaskCanvasGroup;
import edu.berkeley.guir.damask.view.appevent.CanvasEvent;
import edu.berkeley.guir.damask.view.appevent.CanvasListener;
import edu.berkeley.guir.damask.view.event.EraserEventHandler;
import edu.berkeley.guir.damask.view.nodes.*;
import edu.berkeley.guir.damask.view.visual.component.*;
import edu.berkeley.guir.damask.view.visual.component.Label;
import edu.berkeley.guir.damask.view.visual.dialog.*;
import edu.berkeley.guir.damask.view.visual.event.*;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PInputEventFilter;
import edu.umd.cs.piccolo.event.PInputEventListener;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolox.handles.PBoundsHandle;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * The canvas in which the designer creates his or her visual design.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-14-2004 James Lin
 *                               Split VisualCanvas from DamaskCanvas.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 07-14-2004
 */
public class VisualCanvas extends DamaskCanvas implements PageViewContainer {
   private static final Point POINT00 = new Point(0, 0);
   // Logger
   private static final Logger logger =
      Logger.getLogger(DamaskCanvas.class.getName());
   
   // Constants for mode names
   public static final String PENCIL_MODE = "Page/Pencil";
   public static final String ERASER_MODE = "Eraser";
   public static final String TEXT_MODE = "Text";
   public static final String BUTTON_MODE = "Button";
   public static final String CHECK_BOX_MODE = "Check Box";
   public static final String RADIO_BUTTON_MODE = "Radio Button";
   public static final String LIST_BOX_MODE = "List Box";
   public static final String COMBO_BOX_MODE = "Drop-Down Box";
   public static final String TEXT_BOX_MODE = "Text Box";
   public static final String PANEL_MODE = "Group";
   public static final String SPLIT_MODE = "Split Page";
   public static final String MERGE_MODE = "Merge Pages";
   public static final String CHANGE_CONTROL_STATE_MODE =
      "Change Control State";

   // Piccolo event mode and handlers
   private final TextHandler textHandler = new TextHandler();
   private PInputEventListener appModeHandler = null;

   // Fields related to page manipulation
   private PageView selectedPageView = null;
   private PageRegionView selectedPageRegionView = null;
   
   // Fields related to changing the default state of a control view 
   private ControlView focus = null;

   // Actions for menu items
   private final Action cutPageAction = new CutPageAction();
   private final Action copyPageAction = new CopyPageAction();
   private final Action pastePageAction = new PastePageAction();
   private final Action deletePageAction = new DeletePageAction();
   private final Action setHomePageAction = new SetHomePageAction();

   private final Map/*<Content.DisplayMode, Action>*/
      changeContentDisplayModeActions = new HashMap();
   private final Action changeContentPictureAction =
      new ChangeContentPictureAction();
   
   // Actions for toolbar
   private final Action groupStrokesAction = new GroupStrokesAction();
   private final Action ungroupStrokesAction = new UngroupStrokesAction();

   private final Action runFromHomeAction = new RunFromHomeAction();
   private final Action runFromSelectedPageAction =
      new RunFromSelectedPageAction();
   
   // Labels whose mode can be changed through a menu
   private final Set/*<Label>*/ selectedLabels = new HashSet();

   // Pop up menus
   private final JPopupMenu pagePopupMenu = new JPopupMenu();
   private final JPopupMenu contentPopupMenu = new JPopupMenu();
   private final JRadioButtonMenuItem contentInkItem;
   private final JRadioButtonMenuItem contentTextItem;
   private final JRadioButtonMenuItem contentPictureItem;
   // dummy item so that we can make all of the above 3 unselected
   private final JRadioButtonMenuItem contentMixedItem;
   
   /**
    * Creates the canvas.
    * 
    * @param group the canvas group this canvas belongs to
    * @param deviceType the device type from which perspective to display
    * the document
    */
   public VisualCanvas(DamaskCanvasGroup group, DeviceType deviceType) {
      this(group, deviceType, 1.0);
   }

   
   /**
    * Creates the canvas.
    * 
    * @param group the canvas group this canvas belongs to
    * @param deviceType the device type from which perspective to display
    * the document
    * @param pageTitleScale the scale at which page titles should be drawn 
    */
   public VisualCanvas(DamaskCanvasGroup group, DeviceType deviceType,
         double pageTitleScale) {
      super(group, deviceType, pageTitleScale);

      // Listen to changes in my own selection
      addCanvasListener(new SelectionChangeHandler());

      // Initialize event handlers
      textHandler.setEventFilter(
         new PInputEventFilter(InputEvent.BUTTON1_MASK));

      addMode(
         new VisualMode(
            ERASER_MODE,
            new EraserEventHandler(),
            
            null,
            DamaskAppUtils.createCursor(
               "eraser.gif",
               new Point(0, 0),
               ERASER_MODE),
            null));
      
      addMode(
         new VisualMode(
            PENCIL_MODE,
            new PageEventHandler(),
            new PencilEventHandler(),
            
            DamaskAppUtils.createCursor(
               "page.gif",
               new Point(0, 0),
               "Page"),
            DamaskAppUtils.createCursor(
               "dot.gif",
               new Point(0, 0),
               PENCIL_MODE),
            null));

      addMode(
         new VisualMode(
            TEXT_MODE,
            textHandler,
            
            null,
            Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR), //TODO replace
            Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR)));

      addMode(
         new VisualMode(
            BUTTON_MODE,
            new InsertButtonHandler(),
            
            null,
            DamaskAppUtils.createCursor(
               "button.gif",
               new Point(0, 0),
               BUTTON_MODE),
            null));

      addMode(
         new VisualMode(
            CHECK_BOX_MODE,
            new InsertCheckBoxHandler(),
            
            null,
            DamaskAppUtils.createCursor(
               "check_box.gif",
               new Point(0, 0),
               CHECK_BOX_MODE),
            null));
      
      addMode(
         new VisualMode(
            RADIO_BUTTON_MODE,
            new InsertRadioButtonHandler(),
             
            null,
            DamaskAppUtils.createCursor(
               "radio_button.gif",
               new Point(0, 0),
               RADIO_BUTTON_MODE),
            null));

      addMode(
         new VisualMode(
            LIST_BOX_MODE,
            new InsertListBoxHandler(),
            
            null,
            DamaskAppUtils.createCursor(
               "list_box.gif",
               new Point(0, 0),
               LIST_BOX_MODE),
            null));

      addMode(
         new VisualMode(
            COMBO_BOX_MODE,
            new InsertComboBoxHandler(),
            
            null,
            DamaskAppUtils.createCursor(
               "combo_box.gif",
               new Point(0, 0),
               COMBO_BOX_MODE),
            null));

      addMode(
         new VisualMode(
            TEXT_BOX_MODE,
            new InsertTextBoxHandler(),
            
            null,
            DamaskAppUtils.createCursor(
               "text_box.gif",
               new Point(0, 0),
               TEXT_BOX_MODE),
            null));

      addMode(
         new VisualMode(
            PANEL_MODE,
            new InsertPanelHandler(),
            
            null,
            DamaskAppUtils.createCursor(
               "panel.gif",
               new Point(0, 0),
               PANEL_MODE),
            null));

      addMode(
         new VisualMode(
            SPLIT_MODE,
            new SplitEventHandler(),
            
            null,
            DamaskAppUtils.createCursor(
               "split.gif",
               new Point(7, 8),
               SPLIT_MODE),
            null));

      addMode(
         new VisualMode(
            MERGE_MODE,
            new MergeEventHandler(),
            
            null,
            DamaskAppUtils.createCursor(
               "merge.gif",
               new Point(7, 8),
               MERGE_MODE),
            null));

      addMode(
         new VisualMode(
            CHANGE_CONTROL_STATE_MODE,
            null,
         
            null,
            null,
            DamaskAppUtils.createCursor(
               "change_state.gif",
               new Point(0, 0),
               CHANGE_CONTROL_STATE_MODE)));
      
      // Initialize actions
      cutPageAction.setEnabled(false);
      copyPageAction.setEnabled(false);
      deletePageAction.setEnabled(false);
      setHomePageAction.setEnabled(false);
      
      groupStrokesAction.setEnabled(false);
      ungroupStrokesAction.setEnabled(false);

      runFromHomeAction.setEnabled(
         !getDocument().getGraph().getDialogs(getDeviceType()).isEmpty());
      runFromSelectedPageAction.setEnabled(false);
      
      final Collection labelDisplayModes = Content.getSupportedDisplayModes();
      for (Iterator i = labelDisplayModes.iterator(); i.hasNext();) {
         final Content.DisplayMode displayMode = (Content.DisplayMode)i.next();
         final Action action = new ChangeContentDisplayModeAction(displayMode);
         action.setEnabled(false);
         changeContentDisplayModeActions.put(displayMode, action);
      }
      
      changeContentPictureAction.setEnabled(false);
      
      // Initialize pop up menus
      {
         pagePopupMenu.add(new JMenuItem(cutPageAction));
         pagePopupMenu.add(new JMenuItem(copyPageAction));
         pagePopupMenu.add(new JMenuItem(getPasteAction()));
         pagePopupMenu.add(new JMenuItem(deletePageAction));
         pagePopupMenu.add(new JSeparator());
         pagePopupMenu.add(new JMenuItem(setHomePageAction));
         pagePopupMenu.add(new JSeparator());
         final JMenuItem runFromThisPageItem =
            new JMenuItem(getRunFromSelectedPageAction());
         runFromThisPageItem.setText("Run From This Page");
         runFromThisPageItem.setMnemonic(KeyEvent.VK_R);
         pagePopupMenu.add(runFromThisPageItem);
      }
         
      {
         contentPopupMenu.add(new JMenuItem(getCutAction()));
         contentPopupMenu.add(new JMenuItem(getCopyAction()));
         contentPopupMenu.add(new JMenuItem(getPasteAction()));
         contentPopupMenu.add(new JMenuItem(getDeleteAction()));

         contentPopupMenu.add(new JSeparator());
         
         final ButtonGroup displayModeGroup = new ButtonGroup();
         
         contentInkItem =
            new JRadioButtonMenuItem(
               getChangeContentDisplayModeAction(Content.INK));
         contentPopupMenu.add(contentInkItem);
         displayModeGroup.add(contentInkItem);

         contentTextItem =
            new JRadioButtonMenuItem(
               getChangeContentDisplayModeAction(Content.TEXT));
         contentPopupMenu.add(contentTextItem);
         displayModeGroup.add(contentTextItem);

         contentPictureItem =
            new JRadioButtonMenuItem(
               getChangeContentDisplayModeAction(Content.IMAGE));
         contentPopupMenu.add(contentPictureItem);
         displayModeGroup.add(contentPictureItem);

         contentMixedItem = new JRadioButtonMenuItem();
         displayModeGroup.add(contentInkItem);
         
         contentPopupMenu.add(new JSeparator());

         contentPopupMenu.add(new JMenuItem(changeContentPictureAction));
      }

      // Listen to changes in bounds and transform of camera
      final PCamera camera = getCamera();
      final PropertyChangeListener cameraTransformListener =
         new CameraTransformListener();

      camera.addPropertyChangeListener(
         PCamera.PROPERTY_VIEW_TRANSFORM,
         cameraTransformListener);
   }

   
   protected void beforeSetModeByName() {
      final DamaskAppMode appMode = getMode();
      if (appMode.getName().equals(CHANGE_CONTROL_STATE_MODE)) {
         // Turn off run mode in the canvas
         for (Iterator i =
            ((VisualLayer)getLayer())
               .getDialogViewsIncludingTemplates()
               .iterator();
            i.hasNext();
            ) {
         
            final DialogView dialogView = (DialogView)i.next();
            for (Iterator j = dialogView.getChildrenIterator(); j.hasNext(); ) {
               final PageView pageView = (PageView)j.next();
               pageView.setInRunMode(false);
            }
         }
         
         // Turn on pop up menu handler
         addInputEventListener(getPopupMenuEventHandler());
      }
      else if (appMode.getName().equals(TEXT_MODE)) {
         // Stop editing any text
         ((TextHandler)((VisualMode)appMode).getPageHandler()).stopEditing();
            
         // Make text boxes uneditable
         for (Iterator i =
            ((VisualLayer)getLayer())
               .getDialogViewsIncludingTemplates()
               .iterator();
            i.hasNext();
            ) {
         
            final DialogView dialogView = (DialogView)i.next();
            for (Iterator j = dialogView.getChildrenIterator();
               j.hasNext(); ) {
               final PageView pageView = (PageView)j.next();
               for (Iterator k =
                  pageView.getContents().getChildrenIterator();
                  k.hasNext(); ) {
                  final PageRegionView pageRegionView =
                     (PageRegionView)k.next();
      
                  for (Iterator m = pageRegionView.getChildrenIterator();
                     m.hasNext(); ) {
                     final PNode child = (PNode)m.next();
                     if (child instanceof TextBox) {
                        ((TextBox)child).setInRunMode(false);
                     }
                  }
               }
            }
         }
      }
      else if (appMode.getName().equals(SPLIT_MODE)) {
         ((SplitEventHandler)((VisualMode)appMode).getPageHandler()).cleanUp();
      }
   }

   protected void afterSetModeByName() {
      final DamaskAppMode appMode = getMode();
      if (appMode.getName().equals(CHANGE_CONTROL_STATE_MODE)) {
         // Turn on run mode in the canvas
         for (Iterator i =
            ((VisualLayer)getLayer())
               .getDialogViewsIncludingTemplates()
               .iterator();
            i.hasNext();
            ) {
         
            final DialogView dialogView = (DialogView)i.next();
            for (Iterator j = dialogView.getChildrenIterator(); j.hasNext(); ) {
               final PageView pageView = (PageView)j.next();
               pageView.setInRunMode(true);
            }
         }

         // Turn off pop up menu handler
         removeInputEventListener(getPopupMenuEventHandler());
      }
      else if (appMode.getName().equals(HAND_MODE)) {
         // Disable moving pages and resizing pages and page regions
         attachHandles(null, getCamera());
      }
      else if (appMode.getName().equals(TEXT_MODE)) {
         // Make text boxes editable
         for (Iterator i =
            ((VisualLayer)getLayer())
               .getDialogViewsIncludingTemplates()
               .iterator();
            i.hasNext();
            ) {
         
            final DialogView dialogView = (DialogView)i.next();
            for (Iterator j = dialogView.getChildrenIterator();
               j.hasNext(); ) {
               final PageView pageView = (PageView)j.next();
               for (Iterator k =
                  pageView.getContents().getChildrenIterator();
                  k.hasNext(); ) {
                  final PageRegionView pageRegionView =
                     (PageRegionView)k.next();
      
                  for (Iterator m = pageRegionView.getChildrenIterator();
                     m.hasNext(); ) {
                     final PNode child = (PNode)m.next();
                     if (child instanceof TextBox) {
                        ((TextBox)child).setInRunMode(true);
                     }
                  }
               }
            }
         }
      }
   }

   /**
    * Enables or disables the current mode's event handler. If the event
    * handler is being enabled, then the current handler is chosen depending
    * on whether the mouse cursor is currently over a page, a control, or
    * the background. 
    */
   protected void setModeEventHandlerEnabled(final boolean flag) {
      final PNode insideNode = getInsideNode();
      final DamaskAppMode appMode = getMode();
      if (!(appMode instanceof VisualMode)) {
         super.setModeEventHandlerEnabled(flag);
         return;
      }
      
      final VisualMode visualMode = (VisualMode)appMode;
      
      if (flag) {
         Cursor cursorToUse;
         if ((insideNode instanceof PageRegionView)
            || (insideNode instanceof DamaskWindowTitle)) {
            appModeHandler = visualMode.getPageHandler();
            cursorToUse = visualMode.getPageCursor();
         }
         else if (insideNode instanceof ComponentView) {
            final ComponentView componentView = (ComponentView)insideNode;
            
            appModeHandler = visualMode.getPageHandler();
            cursorToUse = visualMode.getControlCursor();
            
            if (appMode.getName() == PENCIL_MODE) {
               if (componentView.getParent() instanceof DamaskWindowTitle) {
                  final Object contents = componentView.getEditableContents();
                  if (((Label)contents).getDisplayMode() == Content.TEXT) {
                     appModeHandler = textHandler;
                     cursorToUse =
                        Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR);
                  }
               }
            }
         }
         else {
            appModeHandler = visualMode.getDefaultHandler();
            if ((insideNode instanceof PBoundsHandle)
               && !(insideNode instanceof NonResizableHandle)) {
               final PBoundsHandle handle = ((PBoundsHandle)insideNode);
               cursorToUse =
                  handle.getCursorFor(
                     ((PBoundsLocator)handle.getLocator()).getSide());
            }
            else {
               cursorToUse = appMode.getDefaultCursor();
            }
         }

         addInputEventListener(appModeHandler);
         setCursor(cursorToUse);
      }
      else {
         removeInputEventListener(appModeHandler);
         setCursor(null);
      }
   }


   /**
    * Stops any text editing in progress.
    */
   public void stopTextEditing() {
      textHandler.stopEditing();
   }


   /**
    * Sets the proper cursor. 
    */
   public void setProperCursor() {
      final DamaskAppMode appMode = getMode();
      if (appMode instanceof VisualMode) {
         final VisualMode visualMode = (VisualMode)appMode;
         final PNode insideNode = getInsideNode();
         if ((insideNode instanceof PageRegionView)
               || (insideNode instanceof DamaskWindowTitle)) {
               setCursor(visualMode.getPageCursor());
         }
         else if (insideNode instanceof ComponentView) {
            setCursor(visualMode.getControlCursor());
         }
         else {
            setCursor(visualMode.getDefaultCursor());
         }
      }
      else {
         super.setProperCursor();
      }
   }

   // Slider and zooming methods -----------------------------------------

   /**
    * Called when the slider's model changes.
    */
   protected void sliderModelStateChanged(final ChangeEvent e) {
      final PCamera camera = getCamera();
      final Point2D zoomCenter;
      
      if (isZoomCenteredAtUpperLeft()) {
         zoomCenter = POINT00; 
      }
      else if (getZoomCenterMousePosition() == null) {
         if (selectedPageView == null) {
            // Zoom about the center of the canvas.
            zoomCenter = camera.getViewBounds().getCenter2D();
         }
         else {
            // Zoom about the center of the selected page.
            final PBounds bounds = selectedPageView.getBounds();
            selectedPageView.localToGlobal(bounds);
            zoomCenter = bounds.getCenter2D();
         }
      }
      else {
         zoomCenter = getZoomCenterMousePosition();
      }
      
      camera.scaleViewAboutPoint(
         scaleFactor(getSliderModel().getValue()) / camera.getViewScale(),
         zoomCenter.getX(),
         zoomCenter.getY());
      
      logger.info(this + ": Zoom level changed to " +
                  getSliderModel().getValue());
   }

   
   // @Override
   protected Page getDropTarget(final Point2D layerDropPt) {
      // Find out what page the pattern instance is being dropped on,
      // if any.
      final List/*<DialogView>*/ dialogViews =
         ((VisualLayer)getLayer()).getDialogViews();
      Page dropPage = null;
      for (Iterator i = dialogViews.iterator(); i.hasNext();) {
         final DialogView dialogView = (DialogView)i.next();
         for (Iterator j = dialogView.getChildrenIterator();
            j.hasNext();
            ) {
            final PNode child = (PNode)j.next();
            final Rectangle2D childGlobalBounds = child.getBounds();
            child.localToGlobal(childGlobalBounds);
            
            if (childGlobalBounds.contains(layerDropPt)) {
               if (child instanceof PageView) {
                  dropPage = (Page)((PageView)child).getModel();
               }
            }
         }
      }
      return dropPage;
   }

   // Page manipulation methods ------------------------------------------
   
   /**
    * Attaches the drag bar and size grip to the given node, removing it
    * from any node it was previously attached to. 
    */
   public void attachHandles(final DamaskWindow pageView, final PCamera camera) {
      // Don't do anything if we are in Hand mode
      if ((getMode() != null) && HAND_MODE.equals(getMode().getName()) && (pageView != null)) {
         return;
      }
      
      if (pageView == selectedPageView) {
         return;
      }
      
      super.attachHandles(pageView, camera);
      
      if (selectedPageView != null) {
         ((PageViewContents)selectedPageView.getContents()).removeRegionResizingBorders();
      }
      
      selectedPageView = (PageView)pageView;
      fireSelectedPageChanged();
   
      if (selectedPageView != null) {
         ((PageViewContents)selectedPageView.getContents()).addRegionResizingBorders(camera);
         
         if (selectedPageRegionView == null ||
             selectedPageRegionView.getPageView() != selectedPageView) {
            setSelectedPageRegionView(
               ((PageViewContents)pageView.getContents()).getRegionView(
                  Direction.CENTER));
         }
      }
   }


   // Overrides method in PageViewContainer.
   public void setControlState(final Control control, final Object state) {
      final Dialog pageDialog = ((Page)(selectedPageView.getModel())).getDialog();
      final Dialog controlDialog = control.getDialog();
      final int condition;
      if (pageDialog == controlDialog) {
         condition = selectedPageView.getDesignTimeCondition();
      }
      else {
         // Control is actually in a template -- use condition from template
         condition = controlDialog.getInitialCondition();
      }
      control.setStateForCondition(controlDialog, condition, state);
   }


   // Overrides method in PageViewContainer.
   public int getSelectedPageCondition() {
      return selectedPageView.getDesignTimeCondition();
   }


   // Overrides method in PageViewContainer.
   public void goToPage(Page page) {
      // Pan camera to view of page.
      final PCamera camera = getCamera(); 
      final PBounds viewBounds = camera.getViewBounds();
      
      final PageView pageView =
         (PageView) ((DamaskLayer)getLayer()).getView(page);
      final Rectangle2D pageViewBdsInCameraCoords = pageView.getBounds();
      pageView.localToGlobal(pageViewBdsInCameraCoords);
      camera.globalToLocal(pageViewBdsInCameraCoords);

      final double deltaX =
         viewBounds.getCenterX() - pageViewBdsInCameraCoords.getCenterX();
      final double deltaY =
         viewBounds.getCenterY() - pageViewBdsInCameraCoords.getCenterY();

      AffineTransform at = camera.getViewTransform();
      at.translate(deltaX, deltaY);
      camera.animateViewToTransform(at, 500);
   }


   // Overrides method in PageViewContainer.
   public ControlView getFocus() {
      return focus;
   }


   // Overrides method in PageViewContainer.
   public void setFocus(final ControlView controlView) {
      focus = controlView;
   }


   /**
    * Returns the selected page view in this canvas.
    */
   public PageView getSelectedPageView() {
      return selectedPageView;
   }
   
   
   // @Override
   public Page getSelectedPage() {
      if (selectedPageView == null) {
         return null;
      }
      else {
         return (Page)selectedPageView.getModel();
      }
   }

   /**
    * Returns the selected page region view in this canvas. This will be
    * the recipient of any Paste actions.
    */
   public PageRegionView getSelectedPageRegionView() {
      return selectedPageRegionView;
   }


   /**
    * Sets the selected page region view in this canvas.
    */
   public void setSelectedPageRegionView(final PageRegionView regionView) {
      if (selectedPageRegionView != null) {
         selectedPageRegionView.setStrokePaint(PageRegionView.BORDER_COLOR);
      }
      selectedPageRegionView = regionView;
      if (selectedPageRegionView != null) {
         selectedPageRegionView.setStrokePaint(
            PageRegionView.SELECTED_BORDER_COLOR);
      }
   }

   // Overrides method in parent class.
   public PageRegion getPasteTargetPageRegion() {
      // If there isn't a selected page region, paste into the home page.
      final PageRegionView targetRegionView = getSelectedPageRegionView();
      final PageRegion targetRegion;
      if (targetRegionView == null) {
         final Page homePage =
            getDocument().getGraph().getHomePage(getDeviceType());
         if (homePage == null) {
            return null;
         }
         else {
            targetRegion = homePage.getRegion(Direction.CENTER);
         }
      }
      else {
         targetRegion = (PageRegion)targetRegionView.getModel();
      }
      return targetRegion;
   }
   
   
   /**
    * Returns the selected labels in this canvas.
    */
   public Collection/*<Label>*/ getSelectedLabels() {
      return Collections.unmodifiableCollection(selectedLabels);
   }
   

   /**
    * Returns the display mode of the selected labels in this canvas, or
    * null if the selected labels are not all in the same mode.
    */
   public Content.DisplayMode getSelectedLabelsMode() {   
      Content.DisplayMode selectedDisplayMode = null;
      boolean moreThanOneMode = false;
            
      for (Iterator i = selectedLabels.iterator(); i.hasNext(); ) {
         final Label label = (Label)i.next();
               
         if (selectedDisplayMode == null) {
            selectedDisplayMode = label.getDisplayMode();
         }
         else if (selectedDisplayMode != label.getDisplayMode()) {
            moreThanOneMode = true;
         }
      }
      
      if (moreThanOneMode) {
         return null;
      }
      else {
         return selectedDisplayMode;
      }
   }
   
   // Selection change methods ------------------------------------------

   /**
    * Handles changes what objects are selected on this canvas.
    */
   private class SelectionChangeHandler implements CanvasListener {
      public void selectionChanged(CanvasEvent e) {
         assert e.getCanvas() == VisualCanvas.this :
               "should be receiving events from "
               + VisualCanvas.this + ", not " + e.getCanvas();

         // Enable or disable the actions that allow the user to change
         // the display mode of content.
         selectedLabels.clear();
         for (Iterator i = getSelectedObjects().iterator(); i.hasNext(); ) {
            final PNode node = (PNode)i.next();
            if (node instanceof ComponentView) {
               final ComponentView componentView = (ComponentView)node;
               final Object editableContents =
                  componentView.getEditableContents();
               if (editableContents instanceof Label) {
                  selectedLabels.add(editableContents);
               }
            }
         }
         
         final boolean areLabelsSelected = !selectedLabels.isEmpty();
         for (Iterator i = changeContentDisplayModeActions.keySet().iterator();
            i.hasNext();
            ) {
            final Content.DisplayMode mode = (Content.DisplayMode)i.next();
            final Action action =
               (Action)changeContentDisplayModeActions.get(mode);
            action.setEnabled(areLabelsSelected);
         }
         
         changeContentPictureAction.setEnabled(selectedLabels.size() == 1);
         
         // If there is a selected label in ink mode, then enable
         // Ungroup Strokes. If there are at least 2 selected labels
         // in ink mode, then enable Group Strokes.
         int numInkLabels = 0;
         for (Iterator i = getSelectedObjects().iterator(); i.hasNext(); ) {
            final PNode node = (PNode)i.next();
            if (node instanceof Label) {
               if (((Label)node).getDisplayMode() == Content.INK) {
                  numInkLabels++;
               }
            }
         }
         ungroupStrokesAction.setEnabled(numInkLabels >= 1);
         groupStrokesAction.setEnabled(numInkLabels >= 2);
      }

      public void selectedPageChanged(CanvasEvent e) {
         assert e.getCanvas() == VisualCanvas.this :
            "should be receiving events from " +
            VisualCanvas.this + ", not " + e.getCanvas();

         final boolean hasSelectedPage = (selectedPageView != null);
         cutPageAction.setEnabled(hasSelectedPage);
         copyPageAction.setEnabled(hasSelectedPage);
         deletePageAction.setEnabled(hasSelectedPage);

         if (hasSelectedPage) {
            final boolean isSelectedPageHome =
               (getDocument().getGraph().getHomePage(getDeviceType())
                  == selectedPageView.getModel());
            setHomePageAction.setEnabled(!isSelectedPageHome);
         }
         else {
            setHomePageAction.setEnabled(false);
         }

         getRunFromSelectedPageAction().setEnabled(hasSelectedPage);
      }
   }   

   // Camera listener ------------------------------------------

   private class CameraTransformListener
      implements PropertyChangeListener {

      public void propertyChange(PropertyChangeEvent evt) {
         // Stop editing any text
         textHandler.stopEditing();
      }
   }

   // Popup menus ----------------------------------------------
   
   
   /**
    * Returns the proper pop-up context menu, depending on what objects
    * are currently selected.
    */
   public JPopupMenu getPopupMenu(
      final PNode pickedNode,
      final boolean isPickedNodeSelectable) {

      if (!isPickedNodeSelectable) {
         if ((pickedNode instanceof PageViewPart) ||
             (pickedNode instanceof DamaskWindowTitle)) {
            return pagePopupMenu;
         }
      }
      else {

         // If there are no selected labels, unselect all of the
         // display modes in the Content menu.
         if (selectedLabels.isEmpty()) {
            contentMixedItem.setSelected(true);
         }
         else {
            // Figure out which display mode in the Content menu to select.
            final Content.DisplayMode selectedDisplayMode =
               getSelectedLabelsMode();
            
            // Select the proper display mode in the Content menu,
            // depending the display mode of the selected labels.
            if (selectedDisplayMode == Content.INK) {
               contentInkItem.setSelected(true);
            }
            else if (selectedDisplayMode == Content.TEXT) {
               contentTextItem.setSelected(true);
            }
            else if (selectedDisplayMode == Content.IMAGE) {
               contentPictureItem.setSelected(true);
            }
            // If the selected labels do not all share the same display mode,
            // unselect all of the display modes in the Content menu.
            else {
               contentMixedItem.setSelected(true);
            }
         }                  

         // If the picked node is selectable, then pop up the menu depending on
         // the selected objects.
         if (pickedNode instanceof ComponentView) {
            final ComponentView componentView = (ComponentView)pickedNode;
            final Object contents = componentView.getEditableContents();
            if (contents instanceof Label) {
               return contentPopupMenu;
            }
            else {
               return super.getPopupMenu(pickedNode, isPickedNodeSelectable);
            }
         }
      }
      
      return null;
   }

   // Menu actions ---------------------------------------------

   /**
    * Returns the action that changes the display mode of the selected
    * label to the specified mode.
    */
   public Action getChangeContentDisplayModeAction(
      final Content.DisplayMode mode) {
      return (Action)changeContentDisplayModeActions.get(mode);
   }

   /**
    * Returns the action that changes the picture representation of the
    * selected label.
    */
   public Action getChangeContentPictureAction() {
      return changeContentPictureAction;
   }

   /**
    * Returns the action that copies the selected page into the clipboard.
    */
   public Action getCopyPageAction() {
      return copyPageAction;
   }

   /**
    * Returns the action that cuts the selected page into the clipboard.
    */
   public Action getCutPageAction() {
      return cutPageAction;
   }

   /**
    * Returns the action that deletes the selected page.
    */
   public Action getDeletePageAction() {
      return deletePageAction;
   }

   /**
    * Returns the action that pastes the contents of the clipboard if the
    * contents contain a page.
    */
   public Action getPastePageAction() {
      return pastePageAction;
   }

   /**
    * Returns the action that sets the home page to the selected page.
    */
   public Action getSetHomePageAction() {
      return setHomePageAction;
   }

   /**
    * Returns the action that runs the design from the home page.
    */
   //@Override
   public Action getRunFromHomeAction() {
      return runFromHomeAction;
   }

   /**
    * Returns the action that runs the design from the selected page.
    */
   //@Override
   public Action getRunFromSelectedPageAction() {
      return runFromSelectedPageAction;
   }


   /**
    * Returns the action that groups or regroups strokes.
    */
   public Action getGroupStrokesAction() {
      return groupStrokesAction;
   }


   /**
    * Returns the action that ungroups strokes.
    */
   public Action getUngroupStrokesAction() {
      return ungroupStrokesAction;
   }


   /**
    * Listens for cut page actions.
    */
   private class CutPageAction extends AbstractAction {
      public CutPageAction() {
         super("Cut Page");
         putValue(SHORT_DESCRIPTION, "Cuts the selected page into the clipboard");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_T));
      }
      
      public void actionPerformed(ActionEvent e) {
         getCopyPageAction().actionPerformed(e);
         getDeletePageAction().actionPerformed(e);
      }
   }


   /**
    * Listens for copy page actions.
    */
   private class CopyPageAction extends AbstractAction {
      public CopyPageAction() {
         super("Copy Page");
         putValue(SHORT_DESCRIPTION, "Copies the selected page into the clipboard");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_C));
      }
      
      public void actionPerformed(ActionEvent e) {
         logger.info("Begin copy page");
         final List/*<PageView>*/ selectedPageList =
            new ArrayList/*<PageView>*/();
         selectedPageList.add(getSelectedPageView());
         setObjectsToCopy(selectedPageList);
         final TransferHandler handler = getTransferHandler();
         handler.exportToClipboard(
            VisualCanvas.this,
            Toolkit.getDefaultToolkit().getSystemClipboard(),
            TransferHandler.COPY);
         getPasteAction().setEnabled(true);
         logger.info("End copy page");
      }
   }


   /**
    * Listens for paste page actions.
    */
   private class PastePageAction extends AbstractAction {
      public PastePageAction() {
         super("Paste Page");
         putValue(SHORT_DESCRIPTION, "Pastes the contents of the clipboard");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_P));
      }
      
      public void actionPerformed(ActionEvent e) {
         logger.info("Begin paste page");
         final Clipboard clipboard =
            Toolkit.getDefaultToolkit().getSystemClipboard();
         final Transferable clipData = clipboard.getContents(this);
         if (clipData != null) {
            final TransferHandler handler =
               getTransferHandler();
            if (handler
               .canImport(VisualCanvas.this, clipData.getTransferDataFlavors())) {
               handler.importData(VisualCanvas.this, clipData);
            }
         }
         logger.info("End paste page");
      }
   }


   /**
    * Listens for delete page actions.
    */
   private class DeletePageAction extends AbstractAction {
      public DeletePageAction() {
         super("Delete Page");
         putValue(SHORT_DESCRIPTION, "Deletes the selected page");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_D));
      }
      
      public void actionPerformed(ActionEvent e) {
         getDocument().getCommandQueue().doCommand(VisualCanvas.this,
            new RemoveDialogCommand(
               ((Page)getSelectedPageView().getModel()).getDialog()));
      }
   }


   /**
    * Listens for set home page actions.
    */
   private class SetHomePageAction extends AbstractAction {
      public SetHomePageAction() {
         super("Set as Home Page");
         putValue(SHORT_DESCRIPTION, "Sets the selected page as the home page");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_H));
      }
      
      public void actionPerformed(ActionEvent e) {
         final DamaskLayer layer = (DamaskLayer)getLayer();
         getDocument().getCommandQueue().doCommand(VisualCanvas.this,
            new SetHomePageCommand(
               layer.getDocument().getGraph(),
               layer.getDeviceType(),
               (Page)getSelectedPageView().getModel()));
         // Since the selected page is now the home page, we can
         // disable this command
         setEnabled(false);
      }
   }


   /**
    * Listens for run actions.
    */
   private class RunFromHomeAction extends AbstractAction {
      public RunFromHomeAction() {
         super("Run from Home Page");
         putValue(SHORT_DESCRIPTION, "Runs this document");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_H));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("run_from_home.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("run_from_home.png"));
      }

      public void actionPerformed(ActionEvent e) {
         final DamaskLayer layer = (DamaskLayer)getLayer();
         final DamaskDocument document = layer.getDocument();
         final DeviceType deviceType = layer.getDeviceType();
         final Page homePage = document.getGraph().getHomePage(deviceType);
         final JFrame runFrame;
         if (deviceType == DeviceType.SMARTPHONE) {
            runFrame =
               new DamaskPhoneRunFrame(
                  document.getDisplayedFileName(), homePage);
         }
         else {
            runFrame =
               new DamaskRunFrame(document.getDisplayedFileName(), homePage);
         }
         runFrame.setVisible(true);
      }
   }

   
   /**
    * Listens for run from selected page actions.
    */
   private class RunFromSelectedPageAction extends AbstractAction {
      public RunFromSelectedPageAction() {
         super("Run from Selected Page");
         putValue(SHORT_DESCRIPTION, "Runs this document from the selected page");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_S));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("run.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("run.png"));
      }

      public void actionPerformed(ActionEvent e) {
         final DamaskLayer layer = (DamaskLayer)getLayer();
         final DamaskDocument document = layer.getDocument();
         final Page selectedPage = getSelectedPage();
         final JFrame runFrame;
         if (layer.getDeviceType() == DeviceType.SMARTPHONE) {
            runFrame =
               new DamaskPhoneRunFrame(
                  document.getDisplayedFileName(), selectedPage);
         } 
         else {
            runFrame =
               new DamaskRunFrame(document.getDisplayedFileName(), selectedPage);
         }
         runFrame.setVisible(true);
      }
   }


   /**
    * Listens for change display mode of label actions.
    */
   private class ChangeContentDisplayModeAction extends AbstractAction {
      private final Content.DisplayMode mode;
      
      public ChangeContentDisplayModeAction(final Content.DisplayMode mode) {
         super(mode.toString());
         putValue(
            SHORT_DESCRIPTION,
            "Changes the representation of the selected label to "
               + mode.toString().toLowerCase());
         
         final int mnemonic = mode.toString().toLowerCase().charAt(0);  
         putValue(MNEMONIC_KEY, new Integer(mnemonic));
         this.mode = mode;
      }
      
      public void actionPerformed(ActionEvent e) {
         // Change the display mode of the labels' models [unless the user
         // chooses (Mixed)].
         final MacroCommand cmd = new ModifyGraphMacroCommand();
         for (Iterator i = selectedLabels.iterator(); i.hasNext(); ) {
            final Label label = (Label)i.next();
            if (label.getDisplayMode() != mode) {
               final Content content = (Content)label.getModel();
               cmd.addCommand(
                  new SetContentDisplayModeCommand(
                     content,
                     content.getDeviceType(),
                     mode));
            }
         }
         if (!cmd.isEmpty()) {
            getDocument().getCommandQueue().doCommand(VisualCanvas.this, cmd);
         }
      }
   }


   /**
    * Listens for change picture of label actions.
    */
   private class ChangeContentPictureAction extends AbstractAction {
      public ChangeContentPictureAction() {
         super("Change Picture...");
         putValue(
            SHORT_DESCRIPTION,
            "Changes the picture representation of the selected label to another picture");
         
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_C));
      }
      
      public void actionPerformed(ActionEvent e) {
         final Label label = (Label)selectedLabels.iterator().next();
         label.tryToChangeImage(VisualCanvas.this);
      }
   }


   /**
    * Listens for grouping strokes actions. 
    */
   private class GroupStrokesAction extends AbstractAction {
      public GroupStrokesAction() {
         super("Group ink strokes");
         putValue(SHORT_DESCRIPTION, "Groups the selected ink strokes");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_G));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("group.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("group.png"));
      }

      // @Override
      public void actionPerformed(ActionEvent e) {
         final Map/*<PageRegion, SortedSet<Content>>*/ contentToGroup =
            new HashMap/*<PageRegion, SortedSet<Content>>*/();

         for (Iterator i = getSelectedObjects().iterator(); i.hasNext(); ) {
            final PNode node = (PNode)i.next();

            if (node instanceof Label &&
                ((Label)node).getDisplayMode() == Content.INK) {
               
               final Content content =
                  (Content)((InteractionElementView)node).getModel();
               
               final PageRegion region =
                  content.getPageRegion(getDeviceType());
               
               Set/*<Content>*/ contentToGroupInRegion =
                  (Set)contentToGroup.get(region);
               
               if (contentToGroupInRegion == null) {
                  contentToGroupInRegion =
                     new TreeSet(new Comparator() {
                        public int compare(Object o1, Object o2) {
                           final PageRegion r1 =
                              ((Content)o1).getPageRegion(getDeviceType());
                           final PageRegion r2 =
                              ((Content)o2).getPageRegion(getDeviceType());
                           final int i1 =
                              r1.getControls().indexOf(o1);
                           final int i2 =
                              r2.getControls().indexOf(o2);
                           
                           if (i1 < i2) {
                              return -1;
                           }
                           else if (i1 == i2) {
                              return 0;
                           }
                           else {
                              return 1;
                           }
                        }
                     });
                  
                  contentToGroup.put(region, contentToGroupInRegion);
               }
               contentToGroupInRegion.add(content);
            }
         }
         
         final MacroCommand cmd = new ModifyGraphMacroCommand();
         for (Iterator i = contentToGroup.keySet().iterator(); i.hasNext(); ) {
            final PageRegion region = (PageRegion)i.next();
            final Collection/*<Content>*/ contents =
               (Collection)contentToGroup.get(region);
            cmd.addCommand(new GroupStrokesCommand(contents, getDeviceType()));
         }
         if (!cmd.isEmpty()) {
            getDocument().getCommandQueue().doCommand(VisualCanvas.this, cmd);
         }
      }
   }


   /**
    * Listens for grouping strokes actions. 
    */
   private class UngroupStrokesAction extends AbstractAction {
      public UngroupStrokesAction() {
         super("Ungroup ink strokes");
         putValue(SHORT_DESCRIPTION, "Ungroups the selected ink strokes");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_U));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("ungroup.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("ungroup.png"));
      }
      
      // @Override
      public void actionPerformed(ActionEvent e) {
         final List/*<Content>*/ contentToUngroup =
            new ArrayList/*<Content>*/();

         for (Iterator i = getSelectedObjects().iterator(); i.hasNext(); ) {
            final PNode node = (PNode)i.next();

            if (node instanceof Label &&
                ((Label)node).getDisplayMode() == Content.INK) {
               
               final Content content =
                  (Content)((InteractionElementView)node).getModel();
               
               contentToUngroup.add(content);
            }
         }
         
         final MacroCommand cmd = new ModifyGraphMacroCommand();
         for (Iterator i = contentToUngroup.iterator(); i.hasNext(); ) {
            final Content content = (Content)i.next();
            cmd.addCommand(new UngroupStrokesCommand(content));
         }
         if (!cmd.isEmpty()) {
            getDocument().getCommandQueue().doCommand(VisualCanvas.this, cmd);
         }
      }
   }
}
