package edu.berkeley.guir.denim.interpreters;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.commands.*;
import java.awt.geom.*;
import java.util.*;
import java.awt.event.*;

/**
 * Circle and hold to select object
 * 
 * 
 *
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-20-2003 YL
 *                    Created. 
 *             1.0.1  03-26-2003 YL
 *                    Completely merged SelectInterpreter's function back to this selection
 * 
 * </PRE>
 *
 * @see Arrow
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 1.0.4, 03-26-2003
 */

public class DragHoldInterpreter 
    extends    HoldSelectInterpreter 
   implements DenimConstants {
      
   // Constants for handling the popup event selection menu
   // NOTE: To disable the menus, set STILL_TIME to 0!
   //       To enable the menus, set STILL_TIME to a reasonable value like 1000
   static final double UPDATESTROKE_STILL_DIST = 6;
   static final int UPDATESTROKE_STILL_TIME = 1000;
   
   // Variables for handling the popup-piemenu for selecting event type
   private TimedStroke updateStroke;
   private Point2D updateStrokeOldEnd = new Point2D.Double(0,0);
   private Point2D updateStrokeEnd = new Point2D.Double(100,100);
   
   private StrokeEvent stkEvt = null;

   private javax.swing.Timer mouseStillTimer;
   
   private GraphicalObject selgob = null;
   
   private DenimSheet mySheet = null;

   private boolean contextFlag = false;
         

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs an ArrowInterpreter.
    */
   public DragHoldInterpreter () {
      setName("Circle-hold Selection");
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   //===========================================================================
   //===   INNER CLASSES   =====================================================

    /**
     * A timer that determines wether a piemenu should be shown for
     * chosing event type (see EventTypePieMenu)
     */
   class MouseStillAction
      implements ActionListener {
      
      private javax.swing.Timer theTimer;
      
      public MouseStillAction (javax.swing.Timer aTimer, DenimSheet sheet) {
         super();
         mySheet = sheet;
         theTimer = aTimer;
      }
      public void actionPerformed(ActionEvent aEvt) {
         // Make sure that is does not fire again for this event
         theTimer.stop();

         // Test if this stroke is really a arrow stroke
         if (updateStroke != null) {
            
  //        Rectangle2D box = updateStroke.getBounds2D(COORD_ABS);
            
  //        if(box.getWidth()*box.getHeight()>100)
  //        {
            
               if (makeObjectSelected(mySheet, updateStroke)) {
   
                  // Send a mouseUp event to finish the stroke
/*                try {
                     Robot mouseRobot = new Robot() ;
                     mouseRobot.mouseRelease(InputEvent.BUTTON1_MASK);
                  } catch (AWTException e) {} 
*/                
               }
   //       }
         }
      }
   }


   //-----------------------------------------------------------------
   
   /**
    * Get the possible Graphical Objects that the stroke 
    * could have intersected. You probably don't want to override this method.
    */

   protected GraphicalObjectCollection getCandidatesContains(TimedStroke stk) {

      Rectangle2D box = stk.getBounds2D(COORD_ABS);
      Point2D center = new Point2D.Double(box.getCenterX(), box.getCenterY());
      
      GraphicalObject           gob = getAttachedGraphicalObject();
      GraphicalObjectCollection out = new GraphicalObjectCollectionImpl();

      //// 1. Select or deselect the tapped Graphical Object.
      if (gob instanceof GraphicalObjectGroup) {
         GraphicalObjectGroup gobgrp = (GraphicalObjectGroup) gob;

         //// 1.1. Get shallow.
         if (flagShallow == true) {
            out = gobgrp.getGraphicalObjects(COORD_ABS,
                            center, 
                            ALL, 
                            SHALLOW, 
                            CONTAINS, 
                            DEFAULT_SELECT_THRESHOLD, 
                            null);
         }
         //// 1.2. Get deep.
         else {
            out = gobgrp.getGraphicalObjects(COORD_ABS, 
                            center, 
                            ALL, 
                            DEEP, 
                            CONTAINS, 
                            DEFAULT_SELECT_THRESHOLD, 
                            null);
         }
      }

      //// 2. Filter out things that cannot be selected.
      GraphicalObjectCollection gobcol;
      Iterator                  it;

      gobcol = (GraphicalObjectCollection) out.clone();
      it     = gobcol.getForwardIterator();
      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();
         if (gob.isSelectable() == false) {
            out.remove(gob);
         }
      }


      //// 3. Return the candidates.
      return (out);
   } // of method

   //-----------------------------------------------------------------   
   
   protected void getCandidateStroke(GraphicalObjectCollection goc, Sheet sheet, GraphicalObjectGroup group, TimedStroke stk) {

      if(group.isVisible()==false||sheet.getBounds2D(COORD_ABS).intersects(group.getBounds2D(COORD_ABS))==false)
         return;
         
      Rectangle2D box = stk.getBounds2D(COORD_ABS);

      Iterator it = group.getReverseIterator();
      
      while(it.hasNext())
      {
          GraphicalObject obj = (GraphicalObject)it.next();
          
          if(obj instanceof TimedStroke)
          {
             if(((TimedStroke)obj).getPolygon2D(COORD_ABS).intersects(box))
             {
               goc.add(obj);
             }
          }
          
          if(flagShallow==false)
          {
          
             if(obj instanceof DenimSketch)
             {
             getCandidateStroke(goc, sheet, (GraphicalObjectGroup)obj, stk);
             }
             
          }
          
      }    
   }
      
   //-----------------------------------------------------------------   
     
   protected boolean makeObjectSelected(Sheet sheet, TimedStroke stk) {

      double curscale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                       getAttachedGraphicalObject().getSheet());

      GraphicalObjectCollection gobcol = new GraphicalObjectCollectionImpl();
      selgob = null;
      contextFlag = false;
      
      mySheet.bufferUpcomingRender(1000);

      if (curscale >= INTERPRETER_TRANSITION) {

         setDeep();
         
         // get label first 
         
        //gobcol = getCandidatesContains(stk);
        //selgob = getSelectCandidate(gobcol);
        
        selgob = mySheet.getNearestObject(stk.getEndPoint2D(COORD_ABS));
        //new Point2D.Double(
          //  stk.getBounds2D(COORD_ABS).getCenterX(),
          //  stk.getBounds2D(COORD_ABS).getCenterY()));
        
         if(selgob!=null)
         {
            if(selgob instanceof DenimLabel)
            {
                selgob = ((DenimLabel)selgob).getPanel();                     
            }
            else if(selgob instanceof DenimSketch) // strokes inside page
            {
               gobcol.clear();
               getCandidateStroke(gobcol, sheet, sheet, stk);              
            
               if(gobcol.isEmpty()==false)
                  selgob = gobcol.getFirst();
               else
                 selgob = null; //((DenimSketch)selgob).getPanel();                          
                                // now we don't allow to choose a panel by selecting sketch in deep mode
            } 
            else 
            {
               if(selgob.getParentGroup() instanceof DenimComponentInstance)
               {
                  selgob = selgob.getParentGroup();
               }
            }
         }
         else // strokes on the sheet
         {
            gobcol.clear();
            getCandidateStroke(gobcol, sheet, sheet, stk);              

            if(gobcol.isEmpty()==false)
               selgob = gobcol.getFirst();
         }
        
      }
      else 
      {
          
          setShallow();
          
          // get panel first 
//       gobcol = getCandidatesContains(stk);
//       selgob = getSelectCandidate(gobcol);
         selgob = mySheet.getNearestObject(stk.getEndPoint2D(COORD_ABS));
         //selgob = mySheet.getNearestObject(new Point2D.Double(
           // stk.getBounds2D(COORD_ABS).getCenterX(),
           // stk.getBounds2D(COORD_ABS).getCenterY()));

         if(selgob!=null)
         {
   
            if(selgob instanceof DenimLabel)
            {
                selgob = ((DenimLabel)selgob).getPanel();
            }
            else if(selgob instanceof DenimSketch)
            {
                selgob = ((DenimSketch)selgob).getPanel();
            }
         }
         else // if not, then get strokes on the sheet
         {
            gobcol.clear();
            getCandidateStroke(gobcol, sheet, sheet, stk);                 
            if(gobcol.isEmpty()==false)
               selgob = gobcol.getFirst();
         }
         
      }

      if(selgob!=null)
      {

         mySheet.setCrosshairsVisible(false);
         
         if(stkEvt.getMouseEvent().isShiftDown()) {
            //// 1.1.1. If the object is already selected, unselect it.
            if (cmdsubsys.isSelected(selgob)) {
               cmdsubsys.removeSelected(selgob);
            }
            //// 1.1.2. If the object is not selected, add it to the group
            //// of selected objects.
            else {
               cmdsubsys.addSelected(selgob);
            }
         }
         else
         {
            Iterator oldIt = cmdsubsys.getSelected();
            
            while(oldIt.hasNext())
            {
               GraphicalObject obj = (GraphicalObject)oldIt.next();
               obj.damage(DAMAGE_IDLE);
            }

            if(selgob instanceof TimedStroke)
            {
               cmdsubsys.clearSelected();
               cmdsubsys.addSelected(selgob);
            }
            else
            {
               toggleSelectGraphicalObject(selgob);
            }
         }

         selgob.damage(DAMAGE_IDLE);
          
         contextFlag = true;
         sheet.clearCurrentStroke();
//         sheet.setCircleHoldStyle(true);

         if(stkEvt!=null)
         {         
            stkEvt.setConsumed(true);
         }
      }       
      else
      {
         if (StrokeLib.isTap(stk))
         {
            cmdsubsys.clearSelected();
            mySheet.setCrosshairsLocation(stk.getEndPoint2D(COORD_ABS));
            mySheet.setCrosshairsVisible(true);
            try
            {
               java.awt.Robot sender = new java.awt.Robot();
               sender.mouseRelease(MouseEvent.BUTTON1_MASK);
            }
            catch(java.awt.AWTException e)
            {
            }
         }
      }
        
      mySheet.bufferUpcomingRender(1);
      
      if(contextFlag)
      {
         if(mySheet.getCurrentStroke()!=null)
         {
            mySheet.getCurrentStroke().damage(DAMAGE_IDLE);
         }

         mySheet.setCrosshairsVisible(false);
     
      }
      
      mySheet.flushRenderRequests();
      
      /**
       * update focused panels so that selected panels have a cache
       */
     ((DenimSheet)this.getAttachedGraphicalObject().getSheet()).updateFocusedPanel();
     
      return contextFlag;
   }


   //-----------------------------------------------------------------

   public void handleNewStroke(NewStrokeEvent evt) {

      // Create a timer that should fire if the mouse is held still
      // (the timer is controlled in handleUpdateStroke)
      
      if(this.getAttachedGraphicalObject().getSheet().isRenderToScreen()==false)
         return;

      // Initialize state
      updateStroke = null;
      contextFlag = false;

      stkEvt = evt;
      
      if (UPDATESTROKE_STILL_TIME > 0) {
         GraphicalObjectGroup parent = (GraphicalObjectGroup) this.getAttachedGraphicalObject();
         DenimSheet sheet = (DenimSheet)parent.getSheet();
         mouseStillTimer = new javax.swing.Timer(UPDATESTROKE_STILL_TIME, null);
         mouseStillTimer.addActionListener(new MouseStillAction(mouseStillTimer, sheet));
         mouseStillTimer.start();
         updateStroke = evt.getStroke();
      }

   }

   //-----------------------------------------------------------------

   public void handleUpdateStroke(UpdateStrokeEvent evt) {

     
      if(this.getAttachedGraphicalObject().getSheet().isRenderToScreen()==false)
         return;
         
      stkEvt = evt;         
      
      if(contextFlag) // if it's sketch+hold and drag, we've got to terminate it and start drag
      {

        if (UPDATESTROKE_STILL_TIME > 0) {
            mouseStillTimer.stop();
        }
  
        evt.setConsumed(true);
        mySheet.damage(DAMAGE_IDLE);        

        if (selgob!=null&&cmdsubsys.isSelected(selgob)) {
      
            Point2D point = evt.getStroke().getEndPoint2D(COORD_ABS);
            mySheet.clearCurrentStroke();
          
//            ((DenimMoveSelectedInterpreter)mySheet.getMoveSelectedInterpreter())                
//                        .setLoopGesture((Polygon2D)evt.getStroke().getPolygon2D(COORD_ABS).clone());
            ((DenimMoveSelectedInterpreter)mySheet.getMoveSelectedInterpreter())
                  .simulateStart(point, selgob);

        }

        return;
        
      }

     
      if (UPDATESTROKE_STILL_TIME > 0) { 
         // Check to see whether the mouse is being hold still
         updateStroke = evt.getStroke();
         updateStrokeEnd = evt.getUntransformedStroke().getEndPoint2D(COORD_ABS);
         if (updateStrokeOldEnd.distance(updateStrokeEnd) > UPDATESTROKE_STILL_DIST) {
            // It has been moved to far: Restart the mouse still timer, and reset position
            mouseStillTimer.restart();
            updateStrokeOldEnd = updateStrokeEnd;
         }
      }

   }

   //-----------------------------------------------------------------

   public void handleSingleStroke(SingleStrokeEvent evt) {

      if(this.getAttachedGraphicalObject().getSheet().isRenderToScreen()==false)
         return;
         
      if (UPDATESTROKE_STILL_TIME > 0) {
         mouseStillTimer.stop();
      }

      if (contextFlag) 
      {
         evt.setConsumed(true);
         contextFlag = false;
     
         mySheet.damage(DAMAGE_IDLE);       
      }

      // Initialize state
      updateStroke = null;
      stkEvt = null;

   } // of method
   

}

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
