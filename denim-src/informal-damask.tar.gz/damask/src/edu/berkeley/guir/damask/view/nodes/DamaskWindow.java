package edu.berkeley.guir.damask.view.nodes;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.event.InteractionElementEvent;
import edu.berkeley.guir.damask.event.InteractionElementListener;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.DamaskLayer.DeviceTypeLayer;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PImage;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.util.PDimension;

/** 
 * A window that can be added to a DamaskLayer and dragged and resized by
 * the user.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  10-28-2004 James Lin
 *                               Created by generalizing PageView.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */
public abstract class DamaskWindow extends InteractionElementView {

   private static final Paint BORDER_COLOR = Color.LIGHT_GRAY.darker();
   private static final Image HOME_PAGE_IMAGE =
      Toolkit
         .getDefaultToolkit()
         .createImage(DamaskApp.class.getResource("images/page/home.png"));
 
   private DamaskWindowTitle titleBar;
   private Color origTitleBarTextColor;
   private PPath contents = null;
   private DragBar dragBar;
   private final PImage homeIcon = new PImage(HOME_PAGE_IMAGE, false);

   private boolean listenToTransformChanges = true;
   private final boolean grayOutTemplateElements;

   private boolean inRunMode = false;

   private boolean isHome = false;
   
   private ElementHandler elementHandler = new ElementHandler();

   /**
    * Constructs a window that is a view of the specified object.
    */
   protected DamaskWindow(final InteractionElement model) {
      this(model, true);
   }

   /**
    * Constructs a window that is a view of the specified object.
    * 
    * @param model the object of which the window is a view
    * @param grayOutTemplateElements true if template components within this
    * window should be grayed out
    */
   protected DamaskWindow(
      final InteractionElement model, final boolean grayOutTemplateElements) {
      
      super(model, false);
      model.addInteractionElementListener(elementHandler);
      
      setStrokePaint(null);
      this.grayOutTemplateElements = grayOutTemplateElements;
   }

   
   // @Override
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();

      contents = createContents();
      contents.setPaint(getContentsPaint());
      addChild(contents);
      // bounds of content are set in layoutChildren()

      titleBar = new DamaskWindowTitle();
      titleBar.setPaint(getTitleColor());
      titleBar.setStrokePaint(BORDER_COLOR);
      addChild(titleBar);
      origTitleBarTextColor = titleBar.getLabel().getLabelColor();
      // bounds of title bar are set in layoutChildren()
      
      homeIcon.setPickable(false);

      addInputEventListener(new BasicInputEventHandler());
      
      // Update window based on device-type layer
      deviceTypeLayerChanged();
   }
   
   /**
    * Creates the contents of this window.
    */
   protected abstract PPath createContents();
   
   /**
    * Returns the content object used for the title of this window.
    */
   protected abstract Content getTitleContent();
   
   //@Override
   public void dispose() {
      super.dispose();
      getModel().removeInteractionElementListener(elementHandler);
   }


   /**
    * Sets whether to listen to transform changes from this page view's
    * model.
    */
   public void setListenToTransformChanges(final boolean flag) {
      listenToTransformChanges = flag;
   }

   
   /**
    * Returns whether template elements within this window are grayed out.
    */
   protected boolean isTemplateElementsGrayedOut() {
      return grayOutTemplateElements;
   }
   
   /**
    * Returns the paint to paint the contents if this window is device-specific
    * and the current layer is All Devices.
    */
   protected abstract Paint getDeviceSpecificContentsPaintInAllLayer();

   /**
    * Returns the paint to paint the contents of this window.
    */
   protected abstract Paint getContentsPaint();

   /**
    * Returns the paint to paint the title bar of this window.
    */
   protected abstract Color getTitleColor();

   /**
    * Returns the paint to paint the title bar if this window is All Devices
    * and the current layer is This Device.
    */
   private Paint getAllDevicesTitlePaintInDeviceLayer() {
      final Color titlePaint = getTitleColor();
      return new GradientPaint(
         0, 0, titlePaint,
         20, 20, DamaskAppUtils.createDarkerColor(titlePaint, 0.85),
         true);
   }
 
   /**
    * Returns the dialog model object of this window.
    */
   protected abstract Dialog getDialogModel();
   
   /**
    * Called when the device-type layer of a layer is changed. 
    */
   protected void deviceTypeLayerChanged() {
      final DeviceType dialogDeviceType = getDialogModel().getDeviceType();
      final DamaskLayer layer = getLayer();
      if (layer == null) {
         return;
      }
      final DeviceTypeLayer deviceTypeLayer = layer.getDeviceTypeLayer();
      
      // If the device-type layer is ALL and the page is
      // device-specific, then gray out the page
      if (dialogDeviceType == layer.getDeviceType()
         && deviceTypeLayer == DeviceTypeLayer.ALL) {

         contents.setPaint(getDeviceSpecificContentsPaintInAllLayer());
         titleBar.getLabel().setLabelColor(DamaskAppUtils.createTransparentColor(origTitleBarTextColor, 50));
         titleBar.setStrokePaint(Color.LIGHT_GRAY);
         titleBar.setPaint(getTitleColor());
      }
      else if (dialogDeviceType == DeviceType.ALL &&
         deviceTypeLayer == DeviceTypeLayer.DEVICE) {

         contents.setPaint(getContentsPaint());
         titleBar.getLabel().setLabelColor(origTitleBarTextColor);
         titleBar.setStrokePaint(BORDER_COLOR);
         titleBar.setPaint(getAllDevicesTitlePaintInDeviceLayer());
      }
      else {
         contents.setPaint(getContentsPaint());
         titleBar.getLabel().setLabelColor(origTitleBarTextColor);
         titleBar.setStrokePaint(Color.LIGHT_GRAY);
         titleBar.setStrokePaint(BORDER_COLOR);
         titleBar.setPaint(getTitleColor());
      }
   }
   
   
   
   /**
    * Returns the contents of this page.
    */
   public PPath getContents() {
      return contents;
   }

   /**
    * Returns the title bar of this page.
    */
   public DamaskWindowTitle getTitleBar() {
      return titleBar;
   }

   
   // Overrides method in superclass.
   public void addChild(final int index, final PNode child) {
      super.addChild(index, child);
      if (child instanceof DragBar) {
         dragBar = (DragBar)child;
      }
   }

   // Overrides method in superclass.
   public PNode removeChild(int index) {
      final PNode child = super.removeChild(index);
      if (child == dragBar) {
         dragBar = null;
      }
      return child;
   }

   // Overrides method in superclass.
   protected void layoutChildren() {
      final double titleBarHeightInLocalCoords =
         titleBar.getPixelHeight() * titleBar.getTransform().getScaleY();

      // Ideally, this code would sit in DragBar, but I can't get it
      // to position and size itself correctly in that class. Oh well.
      if (dragBar != null) {
         // Convert width of page from page's coordinates to drag bar's
         // coordinates
         PDimension pageWidthDim = new PDimension(getWidth(), 0);
         localToGlobal(pageWidthDim);
         dragBar.globalToLocal(pageWidthDim);

         // Convert height of drag bar from drag bar's coordinates to
         // page's coordinates
         PDimension barHeightDim = new PDimension(0, dragBar.getIntHeight());
         dragBar.localToGlobal(barHeightDim);
         globalToLocal(barHeightDim);

         dragBar.setPathBounds(
            0,
            0,
            (float)pageWidthDim.getWidth(),
            dragBar.getIntHeight());
         dragBar.setOffset(
            0,
            -titleBarHeightInLocalCoords - barHeightDim.getHeight());
      }

      titleBar.setPathTo(
         new Rectangle2D.Double(
            0,
            0,
            getWidth() / titleBar.getTransform().getScaleX(),
            titleBar.getPixelHeight()));
      titleBar.setOffset(0, -titleBarHeightInLocalCoords);

      // Put the home icon in upper-right corner of the title bar
      final Rectangle2D titleBarBounds = titleBar.getBounds();
      final Rectangle2D homeIconBounds = homeIcon.getFullBounds();
      homeIcon.setOffset(
         titleBarBounds.getMaxX() - homeIconBounds.getWidth() - 5,
         titleBarBounds.getMinY() + 5);

      contents.setPathTo(new Rectangle2D.Double(0, 0, getWidth(), getHeight()));
   }

   // Overrides method in parent class.
   public DeviceType getDeviceType() {
      return ((Page)getModel()).getDeviceType();
   }

   /**
    * Returns whether this page view is in Run mode.
    */
   public boolean isInRunMode() {
      return inRunMode;
   }

   /**
    * Sets whether this page view is in Run mode, when the controls behave
    * as if the user is interacting with them.
    */
   public void setInRunMode(final boolean flag) {
      inRunMode = flag;
   }

   
   /**
    * Returns whether this page is the home page.
    */
   public boolean isHome() {
      return isHome;
   }
   
   
   /**
    * Sets whether this page is the home page. Called only by
    * edu.berkeley.guir.damask.view.DamaskLayer.GraphHandler.homePageChanged().
    */
   public void setHome(final boolean flag) {
      isHome = flag;
      if (isHome) {
         titleBar.addChild(homeIcon);
      }
      else {
         homeIcon.removeFromParent();
      }
   }
   
   /**
    * Listens for events from the model. 
    */
   private final class ElementHandler implements InteractionElementListener {
      public void elementBoundsUpdated(InteractionElementEvent e) {
         assert e.getSource()
            == getModel() : "Got event from "
               + e.getSource()
               + " which does not match "
               + getModel();

         final Rectangle2D bounds = getModel().getBounds(getDeviceType());
         setPathTo(bounds);
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
         assert e.getSource()
            == getModel() : "Got event from "
               + e.getSource()
               + " which does not match "
               + getModel();

         if (listenToTransformChanges) {
            AffineTransform transform = getModel().getTransform(getDeviceType());
            setTransform(transform);
         }
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }
   
   
   /**
    * Listens to mouse and key events in the page view and its contents..
    */
   private class BasicInputEventHandler extends PBasicInputEventHandler {
//      public void mouseClicked(PInputEvent event) {
//         if (event.getComponent() instanceof DamaskCanvas) {
//            final DamaskCanvas canvas = (DamaskCanvas)event.getComponent();
//            if (!canvas.isPageBoundsChanging() && event.getModifiers() == 16) {
//               getParent().moveToFront();
//               ((DialogView)getParent()).setPageContentsSelectable(true);
//               DamaskLayer mylayer = ((DialogView)getParent()).getLayer();
//               mylayer.updateArrows((DialogView)getParent());
//            }
//         }
//      }
      
      public void mouseEntered(PInputEvent event) {
         // If the user is using the drag bar or size grip on another
         // page, or if any mouse buttons are pressed, then ignore mouse
         // enter events into this page. This can happen if the user moves
         // the mouse so fast that the mouse is over this page instead of
         // the drag bar or size grip.
         if (event.getComponent() instanceof DamaskCanvas) {
            final DamaskCanvas canvas = (DamaskCanvas)event.getComponent();
            if (!canvas.isWindowBoundsChanging() && event.getModifiers() == 0) {
               canvas.setInsideNode(event.getPickedNode());
            }
         }
      }

      public void mouseExited(PInputEvent event) {
         if (event.getComponent() instanceof DamaskCanvas) {
            final DamaskCanvas canvas = (DamaskCanvas)event.getComponent();
            if (event.getModifiers() == 0) {
               canvas.setInsideNode(null);
            }
         }
      }

      public void mousePressed(PInputEvent event) {
         if (event.getComponent() instanceof VisualCanvas) {
            final VisualCanvas canvas = (VisualCanvas)event.getComponent();
            if (!canvas.isWindowBoundsChanging() && event.getModifiers() == 0) {
               //getParent().moveToFront();
               updateHandles(event);
            }
         }
      }
      
      private void updateHandles(PInputEvent event) {
         if (event.getComponent() instanceof DamaskCanvas) {
            ((DamaskCanvas)event.getComponent()).attachHandles(
               DamaskWindow.this,
               event.getCamera());
         }
      }
   }
}
