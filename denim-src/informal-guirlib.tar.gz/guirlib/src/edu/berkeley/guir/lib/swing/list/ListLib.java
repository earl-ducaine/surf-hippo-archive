//// See bottom of file for software license
package edu.berkeley.guir.lib.swing.list;

import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

/**
 * Miscellaneous utilities for manipulating String[][].
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 06 2004
 */
public class ListLib {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    public static final String MDASH = "\u2014";
    public static final String NDASH = "\u2013";

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY METHODS - DEBUGGING   ======================================

    /**
     * Print out a int[].
     */
    public static void debugln(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    } // of method

    //----------------------------------------------------------------

    /**
     * Print out a String[].
     */
    public static void debugln(String[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    } // of method

    //----------------------------------------------------------------

    /**
     * Print out a String[][].
     */
    public static void debugln(String[][] table) {
        for (int i = 0; i < table.length; i++) {
            debugln(table[i]);
        }
    } // of method

    //===   UTILITY METHODS - DEBUGGING   ======================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY METHODS - LIST MODEL CONVERSION   ==========================

    /**
     * Throws the Strings in a given column into a JLabel,
     * figures out widest.
     *
     * @param j is the column to check
     */
    public static int calcWidest(String[][] table, int j) {
        JFrame f        = new JFrame();   // stick into a bogus frame
        JPanel p        = new JPanel();
        JLabel lbl;
        int    maxWidth = 0;

        //// 1. Setup a bogus frame to add the JLabels into.
        ////    Needed to validate sizes correctly.
        f.getContentPane().add(p);

        //// 2. For each row...
        for (int i = 0; i < table.length; i++) {
            p.removeAll();
            lbl = new JLabel(table[i][j]);
            // System.out.println(table[i][j]);

            p.add(lbl);
            f.pack();
            maxWidth = Math.max(maxWidth, lbl.getWidth());
            // System.out.println(maxWidth);
        }

        //// 3. Cleanup and return.
        ////    Don't seem to need to dispose, should be gc'd anyway
        return (maxWidth);
    } // of method

    //--------------------

    /**
     * Calculate the widths for each column.
     *
     * @return int[numcols] filled with widths
     */
    public static int[] calcWidths(String[][] table) {
        int   len    = table[0].length;
        int[] widths = new int[len];

        for (int i = 0; i < len; i++) {
            widths[i] = calcWidest(table, i);
        }

        return (widths);
    } // of method

    //----------------------------------------------------------------

    /**
     * Throws the Strings in a given column into a JLabel,
     * figures out widest.
     *
     * @param j is the column to check
     */
    public static int calcWidest(Row[] table, int j) {
        JFrame f        = new JFrame();   // stick into a bogus frame
        JPanel p        = new JPanel();
        JLabel lbl;
        int    maxWidth = 0;

        //// 1. Setup a bogus frame to add the JLabels into.
        ////    Needed to validate sizes correctly.
        f.getContentPane().add(p);

        //// 2. For each row...
        for (int i = 0; i < table.length; i++) {
            p.removeAll();

            if (table[i].isIgnoredForWidthCalculations() == true) {
                continue;
            }
            else {
                lbl = new JLabel(table[i].get(j).toString());
            }

            p.add(lbl);
            f.pack();
            maxWidth = Math.max(maxWidth, lbl.getWidth());
        }

        //// 3. Cleanup and return.
        ////    Don't seem to need to dispose, should be gc'd anyway
        return (maxWidth);
    } // of method

    //--------------------

    /**
     * Calculate the widths for each column.
     *
     * @return int[numcols] filled with widths
     */
    public static int[] calcWidths(Row[] table) {
        int   len    = table[0].numCols();
        int[] widths = new int[len];

        for (int i = 0; i < len; i++) {
            widths[i] = calcWidest(table, i);
        }

        return (widths);
    } // of method

    //===   UTILITY METHODS - LIST MODEL CONVERSION   ==========================
    //==========================================================================




    //==========================================================================
    //===   UTILITY METHODS - GUI TREE TRAVERSAL   =============================

    /**
     * Traverse up the tree until we get the popup menu.
     */
    public static JPopupMenu getJPopupMenu(Container container) {
        if (container == null) {
            return (null);
        }
        else if (container instanceof JPopupMenu) {
            return (JPopupMenu) (container);
        }
        else {
            return (getJPopupMenu(container.getParent()));
        }
    } // of method

    //===   UTILITY METHODS - GUI TREE TRAVERSAL   =============================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
