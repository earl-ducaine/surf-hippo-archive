//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import java.util.*;

/**
 * The individual nodes in a BranchedCommandQueue
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~miksen/">Michael Thomsen</A> (
 *          <A HREF="mailto:miksen@cs.berkeley.edu">miksen@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 */

public class BranchedCommandQueueNode {
	private Command                     command;
	private BranchedCommandQueueNode    parent;
	private LinkedList                  children = new LinkedList();
	private BranchedCommandQueueNode    next;     // the chronologically next node
	private BranchedCommandQueueNode    previous; // the chronologicall previous node
	private boolean                     m_isBookmark = false;
	private int id;
	
	//variables for walking and coloring the history tree 
	private boolean visited         = false; // in this walk, have we seen this node yet
	private boolean firstInBranch   = false; // is this node the first node of a branch, aka an open paren
	private boolean lastInBranch    = false; // is this node the last node of the branch, aka a leaf node, aka a closed paren
	private boolean inCurrentBranch = false; // is this node in the current branch (as determined when marking)
	       
	public BranchedCommandQueueNode(Command cmd, BranchedCommandQueueNode parent,
											  BranchedCommandQueueNode prev, int id) {
		command = cmd;
		this.parent = parent;
		this.id = id;
		if (prev != null) {
			prev.setNext(this);
			previous = prev;
		} 
	}
		       
		       
	public BranchedCommandQueueNode createChild(Command cmd, BranchedCommandQueueNode previous, int id) {
		BranchedCommandQueueNode newNode = new BranchedCommandQueueNode(cmd, this, previous, id);
		children.add(newNode); 
		return newNode;
	}
	
	
	public void replaceWith( BranchedCommandQueueNode newNode ) {
		// find this node's place in parents list
		int thisIndex = parent.children.indexOf( this );
		if ( thisIndex == -1 ) {
			System.out.println( "BranchedCommandQueueNode.replaceWith(): error" );
			return;
		}
		
		// remove this node and add new node
		parent.children.remove( thisIndex );
		parent.children.add(  thisIndex, newNode );
		if ( parent.next == this )
			parent.next = newNode;
		
		// update new node
		newNode.parent = parent;
		newNode.previous = previous;
		
		// clear out this node
		parent = null;
		previous = null;
	}
		
	
	
	/**
	 * Sets whether this node has been bookmarked by the user.
	 */
	public void setIsBookmark( boolean isBookmark ) {
	    m_isBookmark = isBookmark;
	}
	
	/**
	 * Returns whether this node has been bookmarked by the user.
	 */
	public boolean getIsBookmark() {
	    return m_isBookmark;
	}
	
	        
	/**
	 * Returns true if this node has no children
	 */
	public boolean isLeaf() {
		return children.isEmpty();
	}
		        
	/**
	 * Returns true if this node is the top-most root node
	 */
	public boolean isRoot() {
		return (parent == null);
	}

	/**
	 * Returns true if this node is the first node in a branch
	 */
	public boolean isFirstInBranch () {
		return firstInBranch;
	}
	
	/**
	 * Sets that this node is the first node in a branch
	 */
	public void setIsFirstInBranch () {
		firstInBranch = true;
	}
	
	/**
	 * Unsets that this node is the first node in a branch
	 */
	public void unsetIsFirstInBranch () {
		firstInBranch = false;
	}
	
	/**
	 * Returns true if this node is the last node in a branch
	 */
	public boolean isLastInBranch() {
		return lastInBranch;
	}
	
	/**
	 * Sets that this node is the last node in a branch
	 */
	public void setIsLastInBranch () {
		lastInBranch = true;
	}
	
	/**
	 * Unsets that this node is the last node in a branch
	 */
	public void unsetIsLastInBranch () {
		lastInBranch = false;
	}
	
	/**
	 * Gets visited
	 */
	public boolean isVisited () {
		return visited;
	}
	
	/**
	 * Sets visited
	 */
	public void setVisited() {
		visited = true;
	}
	
	/**
	 * Gets inCurrentBranch
	 */
	public boolean isInCurrentBranch () {
		return inCurrentBranch;
	}
	
	/**
	 * Sets inCurrentBranch
	 */
	public void setInCurrentBranch() {
		inCurrentBranch = true;
	}
	
	/**
	 * Clear all markings on this node
	 */
	public void clearMarkings() {
		visited = false;
		firstInBranch = false;
		lastInBranch = false;
		inCurrentBranch = false;
	}
	
	/**
	 * Returns the command held by this node
	 */
	public Command getCommand() {
		return command;
	}
        
	/**
	 * Returns the id of this node
	 */
	public int getId() {
		return id;
	}
        
	/**
	 * Returns the parent of this node (null for the root)
	 */
	public BranchedCommandQueueNode getParent() {
		return parent;
	}

	/**
	 * Returns the first child of this node (null for leaf nodes)
	 */
	public BranchedCommandQueueNode getFirstChild() {
		return (BranchedCommandQueueNode)children.getFirst();
	}

	public LinkedList getPathToChild(BranchedCommandQueueNode childNode) {
		if (this == childNode) {
			LinkedList result = new LinkedList();
			return result;
		} else {
			Iterator it = children.iterator();
			while (it.hasNext()) {
				BranchedCommandQueueNode directChildNode = (BranchedCommandQueueNode) it.next();
				LinkedList subPath = directChildNode.getPathToChild(childNode);
				if (subPath != null) {
					subPath.addFirst(directChildNode);
					return subPath;
				}
			}
		}
		return null;
	}


	/**
	 * Returns the node that chronologically is the node next after us.
	 *
	 * Returns null if there isn't one 
	 */
	public BranchedCommandQueueNode getNext() {
		return next;
	}


	/**
	 * Set the node that chronologically is the node next after us
	 */
	public void setNext(BranchedCommandQueueNode next) {
		this.next = next;
	}
	
	
	/* Returns the node that chronologically is the node next after us.
	 *
	 * Returns null if there isn't one 
	 */
	public BranchedCommandQueueNode getPrevious() {
		return previous;
	}


	/**
	 * Returns a LinkedList of the nodes that are branches on us --
	 * that is the nodes that used to be after us, but have now been
	 * replaced by another node that chronologically is the node next
	 * after us
	 *
	 * Returns null if this there aren't any old branches -- that is if
	 * this node is a leaf, or is this node has only one child that
	 * thus is the next node
	 */
	public LinkedList getOldBranches() {
		if (children.size() <= 1) {
			return null;
		} else {
			LinkedList branches = (LinkedList)(children.clone());
			branches.remove(getNext());
			return branches;
		}
	}

	/**
	 * Returns true is @param u is us or one of our children
	 */
	public boolean hasAsChild(BranchedCommandQueueNode u) {
		if (this == u) {
			return true;
		} else {
			Iterator it = children.iterator();
			while (it.hasNext()) {
				BranchedCommandQueueNode child = (BranchedCommandQueueNode) it.next();
				if (child.hasAsChild(u)) {
					return true;
				}
			}
		}
		return false;
	}
		        
	/**
	 * Finds the path from this node to the least common ancestor of
	 * this node and @param u.
	 * 
	 * Least common ancestor (LCA) is theory slang for the deepest node
	 * that us and u are both children of.
	 *
	 * Returns an empty list if there is no LCA.  
	 *
	 * (3-21) added synchronized
	 */
	public synchronized LinkedList[] getCommonAncestorPaths(BranchedCommandQueueNode node) {
		LinkedList result[] = new LinkedList[2];

		//// Is node our child? If so, return the simple path down to node
		LinkedList downPath = this.getPathToChild(node);
		if (downPath != null) {
			result[0]=null;
			result[1]=downPath;
			return result;
		} else {
			//// Do we have a parent? If not, recursion ends
			if (parent == null) {
				result[0]=null;
				result[1]=null;
				return result;
			} else {
				//// Recurse
				downPath = parent.getPathToChild(node);
				if (downPath != null) {
					result[1]=downPath;
					LinkedList upPath = new LinkedList();
					upPath.add(this);
					result[0]=upPath;
					return result;
				} else {
					result = parent.getCommonAncestorPaths(node);
					if ((result == null) || (result[0] == null))
					   System.out.println("Warning: No Common Ancestor Path, but there should be! Is Node null?" + (node == null));
					else
					   result[0].addFirst(this);
					return result;
				}
			}
		}
	}


	/**
	 * Dump this node textually
	 */
	public void dump(int indent, boolean recurse) {
		String spacer = "";
		for (int i = 0; i<indent; i++) {
			spacer = spacer + " ";
		}

		String commandName;
		if (command != null) {
			commandName = command.getPresentationName();
		} else {
			commandName = "No command!";
		}
	       
		if (isLeaf()) {
			System.out.println(spacer + id + ": Leaf node (cmd "+commandName+")");
		} else {
			String type;
			if (isRoot()) {
				type = "Root";
			} else {
				type = "Internal";
			}

			System.out.println(spacer + id + ": " + type + " node with "+children.size()+
									 " children (cmd "+commandName+")");
			if (recurse) {
				Iterator it = children.iterator();
				while (it.hasNext()) {
					BranchedCommandQueueNode child = (BranchedCommandQueueNode) it.next();
					child.dump(indent+2, true);
				}
			}
		}
	}


} // of class

//==============================================================================

/*
  Copyright (c) 2000 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
