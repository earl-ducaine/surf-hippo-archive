package edu.berkeley.guir.suede;

import javax.swing.*;
import java.awt.geom.*;
import java.awt.*;
import edu.berkeley.guir.lib.swing.*;


public class SFeedbackLink extends JComponent{
    
    private Point      start     = new Point();
    private Point      finish    = new Point();
    private Color      fColor;
    private Arrowhead  m_arrow   = new Arrowhead();
    private boolean    is_script = false;
    
    public SFeedbackLink (int x, int y) {
        setLocation(x, y);
        setOpaque(false);
        add(m_arrow);
    }
    
    public void setStart(int x, int y) {
        start = new Point(x,y);
    }
    
    public void setFinish(int x, int y) {
        finish = new Point(x,y);
    }
   
   public int getFBounds() {
        return (int)(Math.sqrt((finish.x-start.x)*(finish.x-start.x)+(finish.y-start.y)*(finish.y-start.y)));
   }
   
   public void setFColor(Color c) {
        fColor = c;
   }
   
   public int getStartX() {
        return start.x;
   }
   
   public int getStartY() {
        return start.y;
   }
   
   public int getFinishX() {
        return finish.x;
   }
   
   public int getFinishY() {
        return finish.y;
   }
   
   public void setScript(boolean b) {
        is_script = b;
   }
   
   public void paintComponent(Graphics g) {
        if(is_script)
            paintScript(g);
        else
            paintDesign(g);
   }
   
   //paints the feedback in design area
    public void paintDesign(Graphics g) {
        double theta = Math.atan2(finish.y-start.y, finish.x-start.x);
        int arrowSize = 20;
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(fColor);
        g2d.drawLine(start.x, start.y, finish.x, finish.y);
        m_arrow.setArrowhead(finish, theta);
        m_arrow.setForeground(fColor);
        m_arrow.setVisible(true);
    }
    
    //takes care of the script-design feedback
    public void paintScript(Graphics g) {
        int w = (int)(Math.abs(finish.x - start.x));
        int h = (int)(Math.abs(finish.y-start.y));
        int[] balloon_x = new int[3];
        int[] balloon_y = new int[3];
        balloon_x[0]=start.x;   balloon_x[1]=start.x+20;   balloon_x[2]=start.x+7;
        balloon_y[0]=start.y+h-1; balloon_y[1]=start.y+h-12; balloon_y[2]=start.y+h-19;
        RoundRectangle2D.Float bg_shape = new RoundRectangle2D.Float(start.x, start.y, w-12, h-12,
                                                               AbstGroupNodeView.ARC, AbstGroupNodeView.ARC);
        Area balloon = new Area(bg_shape);
        balloon.add(new Area(new Polygon(balloon_x, balloon_y, 3)));
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(fColor);
        g2d.draw(balloon);
    }
     
}