package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;
import java.util.*;

/*
 * constructs the default view for group nodes, called each time a new group node is created.
 * all prompt nodes inside the group are collpased by default  
 */
public class GroupDefaultNodeView extends AbstGroupNodeView
{
    
	public GroupDefaultNodeView( SuedeModel model, GroupNodeModel nodeModel, SFeedbackGroup fbg){
		super(model, nodeModel);
		init();
	}

	public GroupDefaultNodeView (SuedeModel model, GroupNodeModel nodeModel, String s) {
        super(model, nodeModel);
        
        Vector components = ((GroupNodeModel)m_nodemodel).getComponents();
        for (int i=0; i<components.size(); i++) {
            ((AbstNodeModel)components.get(i)).consDefault();
            ((AbstNodeModel)components.get(i)).setLocation(m_nodemodel.getX()+HOR_NODE_DIST,
                                               m_nodemodel.getY()+i*(AbstSingleNodeView.CL_HEIGHT+VER_NODE_DIST)+TEXT_HEIGHT);
        }
    
        setSize(getPreferredSize());
        setName(s);
        init();
        m_textField.setText(s);
    }

    
    public void init() {
        setLayout(null);
        m_textField.setBounds(6,0,DEFAULT_WIDTH - TEXT_HEIGHT, TEXT_HEIGHT);
        m_textField.setVisible(true);
        m_textField.setOpaque(false);
        m_textField.setForeground(Color.white);
        m_textField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        m_textField.setFont(m_textField.getFont().deriveFont(Font.BOLD));
        add(m_textField);
    		setSize(20,40);
	}
	    
	public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Graphics2D g2d = (Graphics2D)g;
      g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      g2d.setColor(NODE_FILL);
      g2d.fill(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, ARC, ARC));
	}
}                                                                                          