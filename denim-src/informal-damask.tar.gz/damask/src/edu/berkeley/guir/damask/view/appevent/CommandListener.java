package edu.berkeley.guir.damask.view.appevent;

import java.util.EventListener;

/** 
 * The listener interface for receiving events indicating that a command has
 * been executed in the command queue. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-19-2003 James Lin
 *                               Created CommandListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-19-2003
 */
public interface CommandListener extends EventListener {
   
   /**
    * Invoked when a command has been executed.
    */
   void commandExecuted(CommandEvent e);
   
   /**
    * Invoked when a command has been undone.
    */
   void commandUndone(CommandEvent e);
   
   /**
    * Invoked when a command has been redone.
    */
   void commandRedone(CommandEvent e);
}
