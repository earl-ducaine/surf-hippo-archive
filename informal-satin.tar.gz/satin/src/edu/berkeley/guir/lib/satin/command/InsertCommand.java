//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import java.awt.geom.*;
import java.util.*;

/**
 * A Command to insert a new Graphical Object.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 12 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class InsertCommand
   extends CommandImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 7114369136904443157L;

   //===   CONSTANTS   =========================================================
   //===========================================================================

   public static final String TAG_NAME = "INSERT";

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   GraphicalObjectGroup gobs;  // a collection of Graphical Objects
   LinkedList           list = new LinkedList();
   int                  pos  = GraphicalObjectGroup.DEFAULT_POS_POLICY;
   Sheet						s	  = null;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public InsertCommand(GraphicalObjectGroup gobs) {
      this.gobs = gobs;
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create the insert command object.
    *
    * @param gobs is the Graphical Object Group to insert into.
    * @param gob  is the Graphical Object to insert.
    */
   public InsertCommand(GraphicalObjectGroup gobs, GraphicalObject gob) {
      addGraphicalObject(gob);
      this.gobs = gobs;
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create the insert command object.
    *
    * @param gobs is the Graphical Object Group to insert into.
    * @param gob  is the Graphical Object to insert.
    * @param pos  is either {@link GraphicalObjectGroup#KEEP_REL_POS} or
    *             {@link GraphicalObjectGroup#KEEP_ABS_POS}.
    */
   public 
   InsertCommand(GraphicalObjectGroup gobs, GraphicalObject gob, int pos) {
      addGraphicalObject(gob);
      this.gobs = gobs;
      this.pos  = pos;
   } // of constructor

   //-----------------------------------------------------------------

   public InsertCommand(GraphicalObjectGroup gobs, Iterator it, int pos) {
      while (it.hasNext()) {
         addGraphicalObject((GraphicalObject) it.next());
      }
      this.gobs = gobs;
      this.pos  = pos;
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   GROUP ADD METHODS   =================================================

   /**
    * Set the policy for how objects will be added, either keeping their
    * absolute position or their relative position.
    *
    * @param val is either {@link GraphicalObjectGroup#KEEP_ABS_POS} or
    *            {@link GraphicalObjectGroup#KEEP_REL_POS}.
    */
   public void setAddPolicy(int val) {
      this.pos = val;
   } // of setAddPolicy

   //===   GROUP ADD METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   LIST METHODS   ======================================================

   public void addGraphicalObject(GraphicalObject gob) {
      list.add(gob);
   } // of addGraphicalObject

   //-----------------------------------------------------------------

   public void removeGraphicalObject(GraphicalObject gob) {
      list.remove(gob);
   } // of removeGraphicalObject

   //-----------------------------------------------------------------

   public void clearGraphicalObjects() {
      list.clear();
   } // of clearGraphicalObjects

   //===   LIST METHODS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      return ("insert graphical object");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   STATUS ACCESSOR METHODS   ===========================================

   public boolean canRedo() {
      return (true);
   } // of canRedo

   //-----------------------------------------------------------------

   public boolean canUndo() {
      return (true);
   } // of canUndo

   //-----------------------------------------------------------------

   public boolean isSignificant() {
      return (true);
   } // of isSignificant
   
   public Sheet getAssociatedSheet(){
   	Iterator it = list.iterator();
   	if(it.hasNext()){
   		return ((GraphicalObject)it.next()).getSheet();
   	}else{
   		return null;
   	}
   }

   //===   STATUS ACCESSOR METHODS   ===========================================
   //===========================================================================



   //===========================================================================
   //===   ACTION METHODS   ====================================================

   public void run() {
      Iterator        it  = list.iterator();
      GraphicalObject gob = null;

      //System.err.print(gobs.getClass().toString());
      //// 1. Add each GraphicalObject in.
      while (it.hasNext()) {
      	 gob = (GraphicalObject) it.next();
         
         //System.err.print(" add " + gob.getClass().toString());
        
         gobs.addToFront(gob, pos);
      } 
      //System.err.println(" " + gobs.numElements());
      
      //// 2. Set the last gob added.
      if (gob != null) {
         cmdsubsys.setLastGraphicalObject(gob);
      }
   } // of run

   //-----------------------------------------------------------------

   public void redo() {
      Iterator        it  = list.iterator();
      GraphicalObject gob = null;

      //// 1. Add each GraphicalObject in.
      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();
         gobs.addToFront(gob, GraphicalObjectGroup.KEEP_REL_POS);
      }

      //// 2. Set the last gob added.
      if (gob != null) {
         cmdsubsys.setLastGraphicalObject(gob);
      }
   } // of redo

   //-----------------------------------------------------------------

   public synchronized void undo() {
      Iterator        it         = list.iterator();
      Rectangle2D     damageRect = null;
      Sheet           sheet      = null;
      GraphicalObject gob;

      //// 1. Delete the gobs and damage the areas.
      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();

         //// 2.1. Get a reference to the sheet.
         if (sheet == null) {
            sheet = gob.getSheet();
         }

         //// 2.2. Get the bounding box for damage purposes.
         if (damageRect == null) {
            damageRect = gob.getBounds2D(COORD_ABS);
         }
         else {
            damageRect = damageRect.createUnion(gob.getBounds2D(COORD_ABS));
         }

         //// 2.3. Delete the gob.
         gob.delete();
      }

      //// 3. Repaint the damaged areas.
      if (sheet != null) {
         sheet.damage(DAMAGE_LATER, damageRect);
      }

   } // of undo

   //-----------------------------------------------------------------

   public void die() {
   } // of die

   //===   ACTION METHODS   ====================================================
   //===========================================================================

   protected String getTagName() {
      return TAG_NAME;
   }
   
} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
