package edu.berkeley.guir.lib.satin.regression;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.util.*;
//import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.awt.geom.*;
//import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.metrics.*;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
//import java.util.Random;


public class RegressionTest 
   implements SatinConstants {

   Sheet     s;
   Rectangle rect;

//----------------------

   public RegressionTest() {
      JFrame f;
      s = new Sheet();
      f = new JFrame();

      s.setVisible(true);
      f.getContentPane().add(s);
      f.setSize(800, 800);
      f.show();
   }

//----------------------

   public class RegressionAddStroke extends ActionItem {

      public void init() {
         s.clear();
      }
   
      public final void doit() {
         s.addToBack(SatinRandomLib.getRandomStroke(rect, 10));
      }
   
      public String getName() {
         return ("Add Stroke");
      }
   }

//----------------------

   public class RegressionAddPatch extends ActionItem {

      public void init() {
         s.clear();
      }
   
      public final void doit() {
         s.addToFront(SatinRandomLib.getRandomPatch(rect));
      }
   
      public String getName() {
         return ("Add Patch");
      }
   } // of 

//----------------------

   public class RegressionTransform extends ActionItem {

      AffineTransform tx;
      String          str;

      public RegressionTransform(AffineTransform tx, String str) {
         this.tx  = tx;
         this.str = str;
      }
   
      public final void doit() {
         s.applyTransform(tx);
      }
   
      public String getName() {
         return (str);
      } // of 
   }

//----------------------

   public class AnimationTransform extends ActionItem {

      AffineTransform[] txArray;
      String            str;
      int               i = 0;

      public AnimationTransform(AffineTransform[] txArray, String str) {
         this.txArray = txArray;
         this.str     = str;
      } 

      public final void init() {
         GraphicalObjectLib.setAnimating(true);
      }

      public final void doit() {
         s.applyTransform(txArray[i++]);
      } 

      public final void cleanup() {
         GraphicalObjectLib.setAnimating(false);
      } // of cleanup

      public String getName() {
         return (str);
      } // of 

   } // of AnimationTransform 

//----------------------

   public static AffineTransform
   scaleAndKeepConstant(double scale, int x, int y) {

      AffineTransform tx;

      //// These are numbered backwards since you concatenate backwards
      //// with transforms.

      //// 3. Move back to where we were.
      tx = AffineTransform.getTranslateInstance(x, y);

      //// 2. Scale.
      tx.concatenate(AffineTransform.getScaleInstance(scale, scale));

      //// 1. Move the origin to the specified point.
      tx.concatenate(AffineTransform.getTranslateInstance(-x, -y));

      return (tx);
   } // of scaleAndKeepConstant

//----------------------

   public void suiteZoom() {
      AffineTransform tx;

      tx = scaleAndKeepConstant(1.01, s.getWidth()/2, s.getHeight()/2);
      Regression.run(new RegressionTransform(tx, "Zoom In"), 20);

      tx = scaleAndKeepConstant(0.99, s.getWidth()/2, s.getHeight()/2);
      Regression.run(new RegressionTransform(tx, "Zoom Out"), 20);

      tx = scaleAndKeepConstant(0.99, s.getWidth()/2, s.getHeight()/2);
      Regression.run(new RegressionTransform(tx, "Zoom Out"), 20);

      tx = scaleAndKeepConstant(1.01, s.getWidth()/2, s.getHeight()/2);
      Regression.run(new RegressionTransform(tx, "Zoom In"), 20);
   }

   public void suiteAnimate() {
      AffineTransform[] txArray;

      txArray = AffineTransformLib.animateSlowInSlowOut(scaleAndKeepConstant(3, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Zoom In"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Right"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(-Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Left"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(scaleAndKeepConstant(1.0/3.0, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Zoom Out"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Right"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(-Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Left"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(scaleAndKeepConstant(1.0/3.0, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Zoom Out"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Right"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(-Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Left"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(scaleAndKeepConstant(3, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Zoom In"), 20);

   } 



//----------------------


   public void test() {
      int x = (int) (-0.5*s.getWidth());
      int y = (int) (-0.5*s.getHeight());
      int w = 2*s.getWidth();
      int h = 2*s.getHeight();

      rect = new Rectangle(x, y, w, h);

System.out.println("Stroke tests");
      Regression.run(new RegressionAddStroke(), 100);
      Regression.run(new RegressionAddStroke(), 100);

      s.clear();
      for (int i = 0; i < 100; i++) {
         s.addToFront(SatinRandomLib.getRandomStroke(rect, 10));
      }
      suiteZoom();
      suiteAnimate();


System.out.println("Patch tests");
      s.clear();
      s.setTransform(new AffineTransform());
      Regression.run(new RegressionAddPatch(), 30);
      Regression.run(new RegressionAddPatch(), 30);

      s.clear();

/*      GraphicalObject              gob;
      SemanticZoomView             v;
      SemanticZoomMultiViewImpl med;
      Random                       rand = new Random();


      for (int i = 0; i < 20; i++) {
         double fIn    = rand.nextDouble(0, 1);
         double start  = rand.nextDouble(1, 2);
         double end    = rand.nextDouble(2, 3);
         double fOut   = rand.nextDouble(3, 4);

         gob  = s.addToFront(RandomLib.getRandomPatch(rect));
         med  = new SemanticZoomMultiViewImpl();
         v    = new SemanticZoomViewWrapper(s.getDefaultView());
         v.setDisplayRange(fIn, start, end, fOut);
         med.addView(v);
         gob.setView(med);
      }
*/
      for (int i = 0; i < 20; i++) {
         s.addToFront(SatinRandomLib.getRandomSemanticZoomPatch(rect));
      }


      suiteZoom();
      suiteAnimate();


System.out.println("Combined tests");
      for (int i = 0; i < 100; i++) {
         s.addToFront(SatinRandomLib.getRandomStroke(rect, 10));
      }
      suiteZoom();
      suiteAnimate();

      System.exit(0);

   } // of test

//----------------------

   public static void main(String[] argv) throws Exception {
      new RegressionTest().test();
   } // of main

//----------------------

}
