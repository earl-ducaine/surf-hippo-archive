package edu.berkeley.guir.damask.view.appevent;

import java.util.EventObject;

import edu.berkeley.guir.damask.view.DamaskLayer;

/** 
 * An event that indicates that the layer has been changed.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-21-2004 James Lin
 *                               Created LayerEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-21-2004
 */
public class LayerEvent extends EventObject {

   private final Type eventType;   
   
   //---------------------------------------------------------------------------

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   

   public static final Type DEVICE_TYPE_LAYER_CHANGED =
      new Type("device-type layer changed");

   //---------------------------------------------------------------------------

   /**
    * Constructs a CanvasEvent, that indicates that a document has been
    * changed.
    */
   public LayerEvent(final DamaskLayer source, final Type eventType) {
      super(source);
      this.eventType = eventType;
   }
   

   /**
    * Returns the layer that is the source of the event.
    */
   public DamaskLayer getLayer() {
      return (DamaskLayer)source;
   }
   
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
}
