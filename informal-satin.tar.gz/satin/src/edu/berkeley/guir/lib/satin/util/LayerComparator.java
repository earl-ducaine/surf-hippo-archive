//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.util;

import edu.berkeley.guir.lib.satin.objects.*;
import java.util.*;

/**
 * Compare GraphicalObjects by layers.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jul 22 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class LayerComparator
   implements Comparator {

   //===========================================================================

   /**
    * Compare two Lists of Integers representing layers (e.g. [1,2,1] and
    * [2,3]) or compare two GraphicalObjects.
    *
    * @return -1 if obj1 less-than    obj2 (obj1 above obj2),
    *          0 if obj1 equal-to     obj2 (same layer),
    *          1 if obj1 greater-than obj2 (obj2 above obj1).
    *          Also returns 0 if it cannot compare.
    */
   public int compare(Object obj1, Object obj2) {
      if (obj1 instanceof List && obj2 instanceof List) {
         return (GraphicalObjectLib.compareLayers((List) obj1, 
                                                   (List) obj2));
      }
      else
      if (obj1 instanceof GraphicalObject &&
          obj2 instanceof GraphicalObject) {
         return (GraphicalObjectLib.compareLayers((GraphicalObject) obj1,
                                                   (GraphicalObject) obj2));
      }
      return (0);
   } // of compare

   //===========================================================================

   public boolean equals(Object obj) {
      if (obj instanceof LayerComparator) {
         return (true);
      }
      return (false);
   } // of equals

   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static void main(String[] argv) {
      LayerComparator      comp   = new LayerComparator();
      GraphicalObjectGroup gobgrp = new GraphicalObjectGroupImpl();
      GraphicalObject gob0   = new edu.berkeley.guir.lib.satin.stroke.TimedStroke();
      GraphicalObject gob1   = new edu.berkeley.guir.lib.satin.stroke.TimedStroke();
      GraphicalObject gob2   = new edu.berkeley.guir.lib.satin.stroke.TimedStroke();

      gobgrp.addToBack(gob0);
      gobgrp.addToBack(gob1);
      gobgrp.addToBack(gob2);

      System.out.println(comp.compare(gob0, gob0));  // should be 0
      System.out.println(comp.compare(gob0, gob1));  // should be -1
      System.out.println(comp.compare(gob0, gob2));  // should be -1
      System.out.println(comp.compare(gob1, gob0));  // should be 1
      System.out.println(comp.compare(gob1, gob1));  // should be 0
      System.out.println(comp.compare(gob1, gob2));  // should be -1
      System.out.println(comp.compare(gob2, gob0));  // should be 1
      System.out.println(comp.compare(gob2, gob1));  // should be 1
      System.out.println(comp.compare(gob2, gob2));  // should be 0

      System.out.println();
      System.out.println();

      System.out.println(gobgrp);

      GraphicalObjectCollection gobcol = new GraphicalObjectCollectionImpl();
      gobcol.addToFront(gob0);
      gobcol.addToFront(gob2);
      gobcol.addToFront(gob1);

      System.out.println();
      System.out.println("--- before sort ---");
      System.out.println(gobcol);
      System.out.println("--- after sort ---");
      gobcol.sort(new LayerComparator());
      System.out.println(gobcol);

   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
