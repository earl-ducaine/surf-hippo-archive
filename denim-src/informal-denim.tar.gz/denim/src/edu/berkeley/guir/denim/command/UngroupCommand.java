package edu.berkeley.guir.denim.command;

import java.awt.geom.AffineTransform;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

import edu.berkeley.guir.denim.DenimGroup;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;
import edu.berkeley.guir.lib.satin.objects.GraphicalObject;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollection;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollectionImpl;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectGroup;

/**
 * Ungroups a bunch of graphical objects.
 *
 * <PRE>
 * Revisions:  1.0.0  08-19-2002 JL
 *                    Created class UngroupCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 08-19-2002
 */
public class UngroupCommand 
   extends UndoableCommand {

   //=======================================================================
   //===   INSTANCE VARIABLES   ============================================

   private GraphicalObjectGroup      parent;
   private DenimGroup                group;
   private AffineTransform           groupTransform;
   
   private GraphicalObjectCollection containedObjects;
   private Map                       containedObjectsToOldLayers;
   private Map                       containedObjectsToOldTransforms;
   
   //===   INSTANCE VARIABLES   ============================================
   //=======================================================================
      


   //=======================================================================
   //===   CONSTRUCTORS   ==================================================

   /**
    * Construct the command.
    * 
    * @param group   the group which will be ungrouped
    */
   public UngroupCommand(DenimGroup group) {
      super();
      this.group = group;
      this.groupTransform = group.getTransform(COORD_REL);

      this.parent = group.getParentGroup();
      
      containedObjects = new GraphicalObjectCollectionImpl();      
      containedObjectsToOldLayers = new WeakHashMap();
      containedObjectsToOldTransforms = new WeakHashMap();
   } // of constructor
      
   //===   CONSTRUCTORS   ==================================================
   //=======================================================================



   //=======================================================================
   //===   NAME ACCESSOR METHODS   =========================================

   public String getPresentationName() {
      return ("create new group");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =========================================
   //=======================================================================



   //=======================================================================
   //===   COMMAND   =======================================================

   /**
    * Notifies the command system that this command can be redone.
    */
   public boolean canRedo() {
      return true;
   } // of method

   //-----------------------------------------------------------------

   public void run() {
      containedObjects.clear();
      
      for (Iterator it = group.getForwardIterator(); it.hasNext(); ) {
         GraphicalObject gob = (GraphicalObject)it.next();
         containedObjects.add(gob);
      }
      
      for (Iterator it = containedObjects.getForwardIterator(); it.hasNext(); ) {
         GraphicalObject gob = (GraphicalObject)it.next();
         System.out.println("--- " + edu.berkeley.guir.denim.DenimUtils.toShortString(gob));
         containedObjectsToOldTransforms.put(gob, gob.getTransform(COORD_REL));
         containedObjectsToOldLayers.put(
            gob, new Integer(gob.getRelativeLayer()));
         //System.out.println("--- " + edu.berkeley.guir.denim.DenimUtils.toMedString(parent));
         parent.add(gob, GraphicalObjectGroup.KEEP_ABS_POS);
         //System.out.println("--- " + edu.berkeley.guir.denim.DenimUtils.toMedString(parent));
      }
      group.delete();
   } // of method
      
   //-----------------------------------------------------------------

   public void redo() {
      run();
   } // of method
      
   //-----------------------------------------------------------------

   public void undo() {
      group.setTransform(this.groupTransform);
      parent.add(group, GraphicalObjectGroup.KEEP_REL_POS);
      for (Iterator it = containedObjects.getForwardIterator(); it.hasNext(); ) {
         GraphicalObject gob = (GraphicalObject)it.next();
         parent.remove(gob);
         gob.setTransform(
            (AffineTransform)containedObjectsToOldTransforms.get(gob));
         group.add(gob, GraphicalObjectGroup.KEEP_REL_POS);
         gob.setRelativeLayer(
            ((Integer)containedObjectsToOldLayers.get(gob)).intValue());
      }
   } // of method

   //===   COMMAND   =======================================================
   //=======================================================================

} // of class
