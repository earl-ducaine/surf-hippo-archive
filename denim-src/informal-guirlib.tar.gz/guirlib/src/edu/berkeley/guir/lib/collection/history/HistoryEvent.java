//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.history;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * A single event.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 20 2003, JH
 */
public class HistoryEvent {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * Key for user.
     */
    public static final String KEY_USER = "user";

    /**
     * Key for date.
     */
    public static final String KEY_DATE = "date";

    /**
     * Default date.
     */
    public static final String VAL_DATE = "unknown";

    //----------------------------------------------------------------

    public static final String FIELD_DELIMITER = "$";

    //----------------------------------------------------------------

    /**
     * Parser for HistoryEvents.
     */
    public static final HistoryEventParser PARSER = 
                               new HistoryEventParserDefaultImpl();

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    Map mapHistory = new HashMap(8);

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Basic initializations.
     */
    public HistoryEvent() {
        mapHistory.put(KEY_DATE, VAL_DATE);
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   ACCESSOR / MODIFIER METHODS   ======================================

    public void setValue(String strKey, String strVal) {
       mapHistory.put(strKey, strVal);
    } // of method

    public String getValue(String strKey) {
       String strVal = (String) mapHistory.get(strKey);
       return (strVal);
    } // of method

    //----------------------------------------------------------------

    /**
     * Set the date and time of this event.
     * For example, "Wed Nov 06 17:07:17 PST 2003".
     * This date format can be generated via {@link java.util.Date}.
     */
    public void setDate(String str) {
        setValue(KEY_DATE, str);
    } // of method


    /**
     * @see HistoryLib#setDefaultDateFormat(DateFormat)
     */
    public void setDate(Date d) {
        setValue(KEY_DATE, HistoryLib.getDefaultDateFormat().format(d));
    } // of method


    public String getDate() {
        return (getValue(KEY_DATE));
    } // of method


    /**
     * Update to the current time.
     */
    public void touchDate() {
        setDate(new Date());
    } // of method

    //===   ACCESSOR / MODIFIER METHODS   ======================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    /**
     * Get an array of objects representing the keys in the order
     * that they should be printed out. Override this method.
     * Default is date and then rest of keys in any order.
     * Can return a static array.
     */
    protected String[] getKeyOrdering() {
        //// 1. Allocate space for the keys.
        Set      setKeys = mapHistory.keySet();
        String[] strKeys = new String[setKeys.size()];
        int      index   = 0;
        Object   key;

        //// 2. Put the date first.
        strKeys[index++] = KEY_DATE;

        //// 3. Add the rest of the keys.
        Iterator it = setKeys.iterator();
        while (it.hasNext()) {
            key = it.next();
            if (KEY_DATE.equals(key)) {
                continue;
            }
            strKeys[index++] = (String) key;
        }

        return (strKeys);
    } // of method

    //----------------------------------------------------------------

    public String toString() {
        return (toString(true));
    } // of method

    //--------------------

    /**
     * If flagPrintKeys is true, output is of form "[a=b][c=d]". If false,
     * output is of form "[b][d]"
     * @param flagPrintKeys is true if keys are to be printed, false otherwise.
     */
    public String toString(boolean flagPrintKeys) {
        return (toString(flagPrintKeys, getKeyOrdering()));
    } // of method

    //--------------------

    public String toString(boolean flagPrintKeys, String[] keyOrdering) {
        StringBuffer strbuf  = new StringBuffer();
        String[]     strKeys = keyOrdering;
        String       strVal;

        //// 1. Go through each one.
        for (int i = 0; i < strKeys.length; i++) {
            strVal = getValue(strKeys[i]);
            if (flagPrintKeys == true) {
                strbuf.append(strKeys[i]);
                strbuf.append("=");
            }
            strbuf.append(strVal);
            strbuf.append(FIELD_DELIMITER);
        }

        return (strbuf.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   EQUALS / COMPARABLE / HASHCODE   ===================================

    public boolean equals(Object obj) {
        //// 1. Quick checks.
        if (obj == this) {
            return (true);
        }
        if (! (obj instanceof HistoryEvent)) {
            return (false);
        }

        HistoryEvent evt = (HistoryEvent) obj;

        //// 2. Go field by field and check.
        return (this.mapHistory.equals(evt.mapHistory));
    } // of method

    //----------------------------------------------------------------

    public int compareTo(Object obj) {
        return (HistoryDefaultImpl.DEFAULT_COMPARATOR.compare(this, obj));
    } // of method

    //----------------------------------------------------------------

    public int hashCode() {
        return (mapHistory.hashCode());
    } // of method

    //===   EQUALS / COMPARABLE / HASHCODE   ===================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static HistoryEvent getTestInstanceAAA() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "123");
        evt.setValue("val", "ABC");
        evt.setDate(new Date(523456789));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceBBB() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "234");
        evt.setValue("val", "BCD");
        evt.setDate(new Date(613456789));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceCCC() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "345");
        evt.setValue("val", "CDE");
        evt.setDate(new Date(711456789));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceDDD() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "456");
        evt.setValue("val", "DEF");
        evt.setDate(new Date(811156789));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceEEE() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "567");
        evt.setValue("val", "EFG");
        evt.setDate(new Date(911116789));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceFFF() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "678");
        evt.setValue("val", "FGH");
        evt.setDate(new Date(511111789));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceGGG() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "8910");
        evt.setValue("val", "GHI");
        evt.setDate(new Date(611111189));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceHHH() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "91011");
        evt.setValue("val", "HIJ");
        evt.setDate(new Date(711111119));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceIII() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "101112");
        evt.setValue("val", "IJK");
        evt.setDate(new Date(811111111));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceJJJ() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "111213");
        evt.setValue("val", "JKL");
        evt.setDate(new Date(911112111));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceKKK() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "121314");
        evt.setValue("val", "KLM");
        evt.setDate(new Date(111112211));
        return (evt);
    } // of method

    //--------------------

    public static HistoryEvent getTestInstanceLLL() {
        HistoryEvent evt = new HistoryEvent();
        evt.setValue("ID",  "131415");
        evt.setValue("val", "LMN");
        evt.touchDate();
        return (evt);
    } // of method

    //----------------------------------------------------------------

    private static void test(HistoryEvent evt) {
        System.out.println(evt + " " + evt.hashCode());
    } // of method

    private static void runTestAAA() {
        test(getTestInstanceAAA());
        test(getTestInstanceBBB());
        test(getTestInstanceCCC());
        test(getTestInstanceDDD());
        test(getTestInstanceEEE());
        test(getTestInstanceFFF());
        test(getTestInstanceGGG());
        test(getTestInstanceHHH());
        test(getTestInstanceIII());
        test(getTestInstanceJJJ());
        test(getTestInstanceKKK());
        test(getTestInstanceLLL());
    } // of method

    //--------------------

    private static void runTestBBB() {
        HistoryEvent evtAA;
        HistoryEvent evtBB;

        evtAA = getTestInstanceAAA();
        evtBB = getTestInstanceBBB();
        System.out.println(evtAA.equals(evtBB));

        evtBB = getTestInstanceCCC();
        System.out.println(evtAA.equals(evtBB));

        evtBB = getTestInstanceDDD();
        System.out.println(evtAA.equals(evtBB));

        evtBB = getTestInstanceEEE();
        System.out.println(evtAA.equals(evtBB));
    } // of method

    //--------------------

    private static void runTestCCC() {
        HistoryEvent evtAA;
        HistoryEvent evtBB;

        evtAA = getTestInstanceAAA();
        evtBB = getTestInstanceBBB();
        System.out.println(evtAA.compareTo(evtBB));

        evtBB = getTestInstanceCCC();
        System.out.println(evtAA.compareTo(evtBB));

        evtBB = getTestInstanceDDD();
        System.out.println(evtAA.compareTo(evtBB));

        evtBB = getTestInstanceEEE();
        System.out.println(evtAA.compareTo(evtBB));
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestCCC();
    } // of method

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
