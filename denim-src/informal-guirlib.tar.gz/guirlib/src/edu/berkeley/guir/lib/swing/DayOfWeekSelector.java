//// See bottom of file for software license
package edu.berkeley.guir.lib.swing;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.swing.DefaultListSelectionModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import edu.berkeley.guir.lib.util.DayOfWeekLib;

/**
 * GUI widget for selecting day(s) of week.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 11 2004
 */
public class DayOfWeekSelector 
    extends JPanel {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    public static final int SUNDAY    = 0;
    public static final int MONDAY    = 1;
    public static final int TUESDAY   = 2;
    public static final int WEDNESDAY = 3;
    public static final int THURSDAY  = 4;
    public static final int FRIDAY    = 5;
    public static final int SATURDAY  = 6;

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   INNER CLASS - MY LIST SELECTION MODEL   ============================

    /**
     * Underlying List Selection Model.
     */
    class MyListSelectionModel extends DefaultListSelectionModel {

        /**
         * Select the specified.
         */
        public void addSelectionInterval(int start, int end) {
            super.addSelectionInterval(start, end);
            for (int i = start; i < end; i++) {
                setSelected(i, true);
            }
        } // of method

        //--------------------

        public void clearSelection() {
            setAllSelected(false);
        } // of method

        //--------------------

        public int getMaxSelectionIndex() {
            for (int i = buttons.length - 1; i >= 0; i--) {
                if (buttons[i].isSelected() == true) {
                    return (i);
                }
            }
            return (-1);
        } // of method

        public int getMinSelectionIndex() {
            for (int i = 0; i < buttons.length; i++) {
                if (buttons[i].isSelected() == true) {
                    return (i);
                }
            }
            return (-1);
        } // of method

        //--------------------

        public int getSelectionMode() {
            return (ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        } // of method

        //--------------------

        public boolean getValueIsAdjusting() {
            return (false);
        } // of method

        //--------------------

        public boolean isLeadAnchorNotificationEnabled() {
            return (false);
        } // of method

        //--------------------

        public boolean isSelectedIndex(int index) {
            return (isSelected(index));
        } // of method

        //--------------------

        public boolean isSelectionEmpty() {
            if (getMinSelectionIndex() >= 0) {
                return (false);
            }
            return (true);
        } // of method

        //--------------------

        public void setSelectionInterval(int start, int end) {
            setAllSelected(false);
            for (int i = start; i < end; i++) {
                setSelected(i, true);
            }
        } // of method

        //--------------------

        public void setSelectionMode(int val) {
            // ignore
        } // of method

        public void setValueIsAdjusting(boolean flag) {
            // ignore
        } // of method

        //--------------------

        public void fireValueChanged(int start, int end) {
            super.fireValueChanged(start, end);
        } // of method

    } // of inner class

    //----------------------------------------------------------------

    /**
     * Absorbs events from the buttons, re-fires them.
     */
    class MyItemListener implements ItemListener {
        public void itemStateChanged(ItemEvent evt) {
            int    index = -1;
            Object src   = evt.getSource();

            //// 1. Figure out which object was changed.
            for (int i = 0; i < buttons.length; i++) {
                if (buttons[i] == src) {
                    index = i;
                    break;
                }
            }
            if (index < 0) {
                return;
            }

            //// 2. Fire the list event.
            selModel.fireValueChanged(index, index);

            //// 3. Now fire the item event.
            evt.setSource(DayOfWeekSelector.this);
            fireItemEvent(evt);
        } // of method
    } // of method

    //----------------------------------------------------------------

    /**
     * For debugging.
     */
    class DebugItemListener implements ItemListener {
        public void itemStateChanged(ItemEvent evt) {
            System.out.println(evt);
            System.out.println(evt.getSource().getClass());
            System.out.println(getSelectedAsList());
            System.out.println(selModel.getMinSelectionIndex());
            System.out.println(selModel.getMaxSelectionIndex());
        } // of method
    } // of method

    //--------------------

    /**
     * For debugging.
     */
    class DebugListSelectionListener implements ListSelectionListener {
        public void valueChanged(ListSelectionEvent evt) {
            System.out.println(evt);
            System.out.println(getSelectedAsList());
            System.out.println(selModel.getMinSelectionIndex());
            System.out.println(selModel.getMaxSelectionIndex());
        } // of method
    } // of method

    //===   INNER CLASS - MY LIST SELECTION MODEL   ============================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    JToggleButton[]      buttons;
    MyListSelectionModel selModel;
    List                 listItemListeners = new LinkedList();

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Empty constructor, creates a Day of Week selector
     * with no days selected.
     */
    public DayOfWeekSelector() {
        commonInit();
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Creates a Day of Week selector with the specified day selected.
     * 0 is Sunday, 6 is Saturday.
     * @see #SUNDAY
     * @see #MONDAY
     * @see #TUESDAY
     * @see #WEDNESDAY
     * @see #THURSDAY
     * @see #FRIDAY
     * @see #SATURDAY
     */
    public DayOfWeekSelector(int day) {
        this();
        setSelected(day, true);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Creates a Day of Week selector with the specified interval
     * of days selected (both inclusive).
     * 0 is Sunday, 6 is Saturday.
     * <P>
     * For example, the following creates a DayOfWeekSelector with
     * Mon-Fri selected:
     * <PRE>
     *  new DayOfWeekSelector(1, 5);
     * </PRE>
     * @see #SUNDAY
     * @see #MONDAY
     * @see #TUESDAY
     * @see #WEDNESDAY
     * @see #THURSDAY
     * @see #FRIDAY
     * @see #SATURDAY
     */
    public DayOfWeekSelector(int start, int end) {
        this();
        for (int i = start; i <= end; i++) {   // <= not a bug, inclusive
            setSelected(i, true);
        }
    } // of constructor

    //----------------------------------------------------------------

    private void commonInit() {
        this.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
        createDayOfWeek();
        selModel = new MyListSelectionModel();

        //// Debugging
        // selModel.addListSelectionListener(new DebugListSelectionListener());
        // addItemListener(new DebugItemListener());
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   GUI CONSTRUCTION METHODS   =========================================

    protected void createDayOfWeek() {
        //// 1. Init the buttons.
        buttons = new JToggleButton[7];    // 7 days in a week
        buttons[0] = new JToggleButton("S");
        buttons[1] = new JToggleButton("M");
        buttons[2] = new JToggleButton("T");
        buttons[3] = new JToggleButton("W");
        buttons[4] = new JToggleButton("T");
        buttons[5] = new JToggleButton("F");
        buttons[6] = new JToggleButton("S");

        //// 2. Fix the margins.
        Insets insets = new Insets(1, 1, 1, 1);
        for (int i = 0; i < buttons.length; i++) {
            buttons[i].setMargin(insets);
        }

        //// 3. Add the buttons.
        ItemListener lstnr = new MyItemListener();

        for (int i = 0; i < buttons.length; i++) {
            this.add(buttons[i]);
            buttons[i].addItemListener(lstnr);
        }
    } // of method

    //----------------------------------------------------------------

    public Dimension getPreferredSize() {
        //// 1. Ensure that contained components are layed out correctly.
        this.validate();

        //// 2. Make the buttons the same size.
        ////    First calculate the max width and height.
        int       maxHeight = 0;
        int       maxWidth  = 0;
        Dimension dimTmp    = new Dimension();

        for (int i = 0; i < buttons.length; i++) {
            dimTmp    = buttons[i].getSize();
            maxHeight = (int) Math.max(dimTmp.getHeight(), maxHeight);
            maxWidth  = (int) Math.max(dimTmp.getWidth(),  maxWidth);
        }

        //// 3. Set the max width and height.
        dimTmp.setSize(maxWidth, maxHeight);
        for (int i = 0; i < buttons.length; i++) {
            buttons[i].setSize(dimTmp);
            buttons[i].setMinimumSize(dimTmp);
            buttons[i].setPreferredSize(dimTmp);
        }

        //// 4. Return.
        return (super.getPreferredSize());
    } // of method

    //===   GUI CONSTRUCTION METHODS   =========================================
    //==========================================================================




    //==========================================================================
    //===   ACCESSOR / MODIFIER METHODS   ======================================

    /**
     * Get the underlying List Selection Model.
     */
    public ListSelectionModel getListSelectionModel() {
        return (selModel);
    } // of method

    //--------------------

    public void addItemListener(ItemListener l) {
        listItemListeners.add(l);
    } // of method

    //--------------------

    public void removeItemListener(ItemListener l) {
        listItemListeners.remove(l);
    } // of method

    //--------------------

    /**
     * Fire off a notification.
     */
    protected void fireItemEvent(ItemEvent evt) {
        Iterator     it = listItemListeners.iterator();
        ItemListener lstnr;

        while (it.hasNext()) {
            lstnr = (ItemListener) it.next();
            lstnr.itemStateChanged(evt);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Select or deselect one.
     * @param index should be between 0 and 6 (inclusive)
     * @see #SUNDAY
     * @see #MONDAY
     * @see #TUESDAY
     * @see #WEDNESDAY
     * @see #THURSDAY
     * @see #FRIDAY
     * @see #SATURDAY
     */
    public void setSelected(int index, boolean flagSelected) {
        buttons[index].setSelected(flagSelected);
    } // of method

    //--------------------

    /**
     * Select (or deselect) an array of days.
     */
    public void setSelected(int[] daysArr, boolean flagSelected) {
        for (int i = 0; i < daysArr.length; i++) {
            setSelected(daysArr[i], flagSelected);
        }
    } // of method

    //--------------------

    /**
     * Set the following as selected (inclusive).
     */
    public void setSelected(int start, int end, boolean flagSelected) {
        for (int i = start; i <= end; i++) {   // <= not a bug, inclusive
            buttons[i].setSelected(flagSelected);
        }
    } // of method

    //--------------------

    /**
     * Select or deselect all.
     */
    public void setAllSelected(boolean flagSelected) {
        for (int i = 0; i < buttons.length; i++) {
            buttons[i].setSelected(flagSelected);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Check if the specified index is selected.
     * @param index should be between 0 and 6 (inclusive)
     * @see #SUNDAY
     * @see #MONDAY
     * @see #TUESDAY
     * @see #WEDNESDAY
     * @see #THURSDAY
     * @see #FRIDAY
     * @see #SATURDAY
     */
    public boolean isSelected(int index) {
        return (buttons[index].isSelected());
    } // of method

    //--------------------

    /**
     * Get an array of what indices are selected.
     * For example, if Sunday and Tuesday were selected, then return 
     * <CODE>[0, 2]</CODE>.
     */
    public int[] getSelectedAsIntArray() {
        List     listSelected = getSelectedAsList();
        Iterator it;
        Integer  value;
        int[]    arrSelected;
        int      index;

        //// 1. Return as an int array.
        arrSelected = new int[listSelected.size()];
        it          = listSelected.iterator();
        index       = 0;

        while (it.hasNext()) {
            value                = (Integer) it.next();
            arrSelected[index++] = value.intValue();
        }

        //// 2. Return.
        return (arrSelected);
    } // of method

    //--------------------

    /**
     * Return an array like {"Monday", "Tuesday", "Thursday"}
     * or {"Mon", "Tue", "Thu"}.
     *
     * @param flagFullDay is true to use full day names like "Monday",
     *                    false to use short names like "Mon"
     */
    public String[] getSelectedAsStringArray(boolean flagFullDay) {
        return(DayOfWeekLib.asStringArray(getSelectedAsIntArray(),flagFullDay));
    } // of method

    //--------------------
    
    /**
     * @return List of Integer
     */
    protected List getSelectedAsList() {
        List     listSelected = new LinkedList();
        Iterator it;

        //// 1. Figure out what is selected.
        for (int i = 0; i < buttons.length; i++) {
            if (buttons[i].isSelected() == true) {
                listSelected.add(new Integer(i));
            }
        }

        /// 2. Return.
        return (listSelected);
    } // of method

    //===   ACCESSOR / MODIFIER METHODS   ======================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    /**
     * Java Swing-like debug String.
     */
    public String toString() {
        return (super.toString() + ", selected: " + getSelectedAsList());
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert the array into a comma-separated String.
     * For example, [0] would be "Sunday", while [0,1,2] would be
     * "Sunday,Monday,Tuesday"
     *
     * @param flagUseFullDay is true for full day names, like "Monday", or
     *                       false for short day names, like "Mon"
     */
    public String toCSVDays(boolean flagUseFullDay) {
        return (DayOfWeekLib.toCSVDays(getSelectedAsIntArray(),flagUseFullDay));
    } // of method

    //--------------------

    /**
     * Convert what is selected into a String.
     * For example, [0] would be "Sunday", while [0,1,2] would be
     * "Sunday through Tuesday"
     *
     * @param strThru is what separates consecutive days. For example, "-"
     *                yields "Sun-Tue" while " thru " yields "Sun thru Tue"
     * @param flagUseFullDay is true for full day names, like "Monday", or
     *                       false for short day names, like "Mon"
     */
    public String toConsecutiveDays(String strThru, boolean flagUseFullDay) {

        return (DayOfWeekLib.toConsecutiveDays(getSelectedAsIntArray(),
                                                     strThru, flagUseFullDay));
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static void createFrame(DayOfWeekSelector comp) {
        JFrame f = new JFrame();
        f.getContentPane().add(comp);
        f.pack();
        f.setVisible(true);
    } // of method

    private static void runTestAAA() {
        createFrame(new DayOfWeekSelector());
        createFrame(new DayOfWeekSelector(1));
        createFrame(new DayOfWeekSelector(1, 5));
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) {
        runTestAAA();
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
