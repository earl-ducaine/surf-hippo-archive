package edu.berkeley.guir.damask.event;

import java.util.EventListener;

/** 
 * The listener interface for receiving events regarding a change in a control. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-01-2004 James Lin
 *                               Created ControlListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-01-2004
 */
public interface ControlListener extends EventListener {
   
   /**
    * Invoked when the state of a control has changed.
    */
   void controlStateChanged(ControlEvent e);
   
   /**
    * Invoked when the significance of a control's state to determining
    * a page's condition has changed.
    */
   void controlSignificanceChanged(ControlEvent e);
   
   /**
    * Invoked when the page region that the control is has changed.
    */
   void pageRegionChanged(ControlEvent e);
}
