package edu.berkeley.guir.lib.gesture.apps;

/*
 * prints out names of all gesture classes
 */

import edu.berkeley.guir.lib.gesture.*;
import java.io.File;
import java.io.PrintStream;
import java.util.Iterator;

public class gnames {
  public static void main(String[] argv)
  {
    if (argv.length != 1) {
      System.err.println("gnames: usage: java gnames gesturesetfile");
      System.exit(-1);
    }

    GestureSetFrame frame =
      new GestureSetFrame("gnames", false);

    frame.openFile(new File(argv[0]));

    GestureSet gs = frame.getGestureSetDisplay().getGestureSet();
    printNames(System.out, gs);
    System.exit(0);
  }

  static void printNames(PrintStream out, GestureSet gs)
  {
    for (Iterator it = gs.getCategories().iterator(); it.hasNext();) {
      GestureCategory gc = (GestureCategory)it.next();
      out.println(gc.getName());
    }
  }
}
