package edu.berkeley.guir.lib.collection;

import edu.berkeley.guir.lib.util.StringLib;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A two-dimensional map whose rows and columns are indexed by arbitrary
 * Java objects (like keys in a Java Map). Adding and removing rows are more
 * efficient than adding and removing columns.
 * <P>
 * By default, ordering of rows and cols is the same as they are added.
 * For example, 
 * <PRE>
 * grid.put("1", "A", "val1A");
 * grid.put("1", "C", "val1C");
 * grid.put("2", "B", "val2B");
 * </PRE>
 * creates a table that (when printed via {@link #toDebugString()}) looks like:
 *
 * <PRE>
 *    A     C     B
 * 1  val1A val1C
 * 2              val2B
 * </PRE>
 * Note that an alternative variation, 
 * {@link #toDebugString(List,List,int,boolean,boolean)}), lets you pass in a
 * List which specifies the ordering for printing, so you can do sorting on
 * the List if you want.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Last modified Jul 24 2003 JIH
 */
public class Map2D {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    ///// <Object rowHeader, Map<Object colHeader, Object>>
    private Map grid;

    //// <Object, Object>*/ 
    //// Maps name of column with actual object used as key into map
    private Map colHeaders; 
 
    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Constructs a new 2D map.
     */
    public Map2D() {
        grid       = new LinkedHashMap();
        colHeaders = new LinkedHashMap();
    } // of constructor

    //-----------------------------------------------------------------

    /**
     * Constructs a new 2D map with the contents of the given map.
     */
    public Map2D(Map2D old) {
        grid = new LinkedHashMap();
        Set oldRowHeaders = old.getRows();
        if (oldRowHeaders != null) {
            Iterator rowIt = oldRowHeaders.iterator();
            while (rowIt.hasNext()) {
                Object rowHeader = rowIt.next();
                Map rowData = (Map)old.grid.get(rowHeader);
                grid.put(rowHeader, new LinkedHashMap(rowData));
            }
       }

       colHeaders = new LinkedHashMap(old.colHeaders);
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    /**
     * Adds a row with the given header to the 2D map, or does nothing if
     * the header already exists. Returns whether the row was added.
     */
    public boolean addRow(Object header) {
       if (!containsRow(header)) {
          Map newRow = new LinkedHashMap();
          grid.put(header, newRow);
          return true;
       }
       else {
          return false;
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns whether there is a row with the given header.
     */
    public boolean containsRow(Object header) {
       return grid.containsKey(header);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Removes the row with the given header, if it exists.
     *
     * @return whether the grid had a row with the given header
     */
    public boolean removeRow(Object header) {
       boolean ret = containsRow(header);
       grid.remove(header);
       return ret;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Renames the row with the given header to the given new name, 
     * if it exists.
     *
     * @return whether the grid had a row with the given old header
     */
    public boolean renameRow(Object oldHeader, Object newHeader) {
       if (containsRow(oldHeader) && !containsRow(newHeader)) {
          grid.put(newHeader, grid.get(oldHeader));
          grid.remove(oldHeader);
          return true;
       }
       else {
          return false;
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Adds a column with the given header to the grid, or does nothing if
     * the header already exists. Returns whether the column was added.
     */
    public boolean addCol(Object header) {
       if (!containsCol(header)) {
          colHeaders.put(header, new Object());
          return true;
       }
       else {
          return false;
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns whether there is a column with the given header.
     */
    public boolean containsCol(Object header) {
       return colHeaders.containsKey(header);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Removes the column with the given header, if it exists.
     *
     * @return whether the grid had a column with the given header
     */
    public boolean removeCol(Object header) {
       boolean ret = containsCol(header);

       if (ret) {
          Object realHeader = colHeaders.get(header);
          colHeaders.remove(header);
          Iterator rowIt = grid.keySet().iterator();
          while (rowIt.hasNext()) {
             Map row = (Map)grid.get(rowIt.next());
             row.remove(realHeader);
          }
       }
       return ret;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Renames the column with the given header to the given new name.
     *
     * @return whether the grid had a row with the given old header
     */
    public boolean renameCol(Object oldHeader, Object newHeader) {
        if(newHeader==null)
        {
            System.err.println("new header for Map2D is null");
        }
        
       if (containsCol(oldHeader) && !containsCol(newHeader)) {
          colHeaders.put(newHeader, colHeaders.get(oldHeader));
          colHeaders.remove(oldHeader);
          return true;
       }
       else {
          return false;
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Shallow copies the data from one column to another.
     *
     * @return whether the data was copied
     */
    public boolean copyCol(Object fromHeader, Object toHeader) {
       Set rows = getRows();
       if (rows != null && containsCol(fromHeader) && containsCol(toHeader)) {
          Iterator rowIt = rows.iterator();
          while (rowIt.hasNext()) {
             Object rowHeader = rowIt.next();
             put(rowHeader, toHeader, get(rowHeader, fromHeader));
          }
          return true;
       }
       else {
          return false;
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Puts the data at the given row and column. Creates the row and column
     * if it does not exist.
     */
    public void put(Object rowHeader, Object colHeader, Object data) {
       // The following do nothing if the row and column already exist.
       //System.out.println("Before:");
       //System.out.println(this);
       addRow(rowHeader);
       //System.out.println("AddRow:");
       //System.out.println(this);
       addCol(colHeader);
       //System.out.println("AddCol:");
       //System.out.println(this);

       ((Map)grid.get(rowHeader)).put(colHeaders.get(colHeader), data);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Gets the data at the given row and column, or null if there is not any.
     */
    public Object get(Object rowHeader, Object colHeader) {
       Map row = (Map) grid.get(rowHeader);
       if (row != null) {
          return row.get(colHeaders.get(colHeader));
       }
       else {
          return null;
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Retrieves a single row with the specified row header.
     * For example:
     * <PRE>
     *    A    B    C
     * 1  abc  def  ghi
     * 2  jkl  mno  null
     * </PRE>
     *
     * Here are the return values:
     * <PRE>
     * getRow(1) = {A=abc,  B=def,  C=ghi}
     * getRow(2) = {A=jkl,  B=mno,  C=null}
     * getRow(3) = {A=null, B=null, C=null}
     * </PRE>
     */
    public Map getRow(Object rowHeader) {
        Map      row    = (Map) grid.get(rowHeader);
        Map      mapTmp = new LinkedHashMap();
        Iterator it     = colHeaders.keySet().iterator();
        Object   key;

        //// 1. For each col header...
        while (it.hasNext()) {
            key = it.next();

            //// 1.1. If the row doesn't exist, map the col header to null.
            if (row == null) {
                mapTmp.put(key, null);
            }
            //// 1.2. If the row does exist, retrieve the value and stick it in.
            else {
                mapTmp.put(key, row.get(colHeaders.get(key)));
            }
        }
        return (mapTmp);
    } // of method


    /**
     * Retrieves a single column with the specified column header.
     * This is slower than getRow(). For example:
     * <PRE>
     *    A    B    C
     * 1  abc  def  ghi
     * 2  jkl  mno  null
     * </PRE>
     *
     * Here are the return values:
     * <PRE>
     * getCol(A)   = {1=abc,  2=jkl}
     * getCol(B)   = {1=def,  2=mno}
     * getCol(ZZZ) = {1=null, 2=null}
     * </PRE>
     */
    public Map getCol(Object colHeader) {
        Iterator it = grid.keySet().iterator();
        Object   key;
        Map      mapTmp = new LinkedHashMap();

        while (it.hasNext()) {
            key = it.next();
            mapTmp.put(key, get(key, colHeader));
        }
        return (mapTmp);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns a set of row headers.
     */
    public Set getRows() {
       return grid.keySet();
    } // of method

    /**
     * Returns the number of rows.
     */
    public int numRows() {
        return (getRows().size());
    } // of method

    /**
     * Returns the name of the <code>n</code>th row.
     */
    public Object getRowHeader(int n) {
        Set      setRows = getRows();
        Object[] arr     = setRows.toArray();
        return (arr[n]);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns a set of column headers.
     * By default, the Set returns the headers in the order they were added.
     */
    public Set getCols() {
       return colHeaders.keySet();
    } // of method

    /**
     * Returns the number of cols.
     */
    public int numCols() {
        return (getCols().size());
    } // of method

    /**
     * Returns the name of the <code>n</code>th column.
     */
    public Object getColHeader(int n) {
        Set      setCols = getCols();
        Object[] arr     = setCols.toArray();
        return (arr[n]);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns the header of a row that matches the given collection of data,
     * or null if there is no match.
     */
    public Object matchRow(Map rowData) {
       Object matchedRowHeader = partialMatchRow(rowData);
       if (matchedRowHeader != null) {
          if (getCols().size() == rowData.size()) {
             return matchedRowHeader;
          }
          else {
             return null;
          }
       }
       return null;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns the header of a row that partially matches the given collection
     * of data, or null if there is no match.
     *
     * A collection of data partially matches a row if it is a superset
     * of the column, i.e., if every column name-data pair in the column is
     * also in the collection, although the collection may have other
     * column name-data pairs.
     */
    public Object partialMatchRow(Map rowData) {
       Set rows = getRows();
       if (rows == null) {
          return null;
       }
       Iterator rowIt = rows.iterator();
       while (rowIt.hasNext()) {
          Object rowHeader = rowIt.next();
          Map row = (Map)grid.get(rowHeader);

          boolean match = true;
          Iterator colIt = rowData.keySet().iterator();
          while (colIt.hasNext()) {
             Object colHeader = colIt.next();
             if (!row.get(colHeader).equals(rowData.get(colHeader))) {
                match = false;
             }
          }
          if (match) {
             return rowHeader;
          }
       }
       // must have no match
       return null;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns the header of a column that matches the given collection of data,
     * or null if there is no match.
     */
    public Object matchCol(Map colData) {
       Object matchedColHeader = partialMatchCol(colData);
       if (matchedColHeader != null) {
          if (getRows().size() == colData.size()) {
             return matchedColHeader;
          }
          else {
             return null;
          }
       }
       return null;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns the header of a column that partially matches the given
     * collection of data, or null if there is no partial match.
     *
     * A collection of data partially matches a column if it is a superset
     * of the column, i.e., if every row name-data pair in the column is also
     * in the collection, although the collection may have other row name-data
     * pairs.
     */
    public Object partialMatchCol(Map colData) {
       Set cols = getCols();
       if (cols == null) {
          return null;
       }
       Iterator colIt = cols.iterator();
       while (colIt.hasNext()) {
          Object colHeader = colIt.next();
          boolean match = true;
          Iterator rowIt = grid.keySet().iterator();
          while (rowIt.hasNext()) {
             Object rowHeader = rowIt.next();
             Object dataAtRowCol = get(rowHeader, colHeader);
             if (dataAtRowCol == null) {
                match = (colData.get(rowHeader) == null);
             }
             else if (!dataAtRowCol.equals(colData.get(rowHeader))) {
                match = false;
             }
          }
          if (match) {
             return colHeader;
          }
       }
       // must have no match
       return null;
    } // of method

    //-----------------------------------------------------------------
    
    /**
     * Removes all mappings from this map.
     */ 
    public void clear() {
       grid.clear();
       colHeaders.clear();
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns all of the values in this map. This operation takes
     * O(rows &times; cols).
     */
    public Collection values() {
        List       listValues = new LinkedList();
        Iterator   it         = getRows().iterator();
        Object     key;
        Map        mapTmp;

        //// 1. Add all known values.
        while (it.hasNext()) {
            key    = it.next();
            mapTmp = (Map) grid.get(key);
            if (mapTmp != null) {
                listValues.addAll(mapTmp.values());
            }
        }

        //// 2. Calculate the number of null values we should have.
        ////    It is (#rows * #cols - listValues.size())
        int numNulls = numRows() * numCols() - listValues.size();
        for (int i = 0; i < numNulls; i++) {
            listValues.add(null);
        }

        //// 3. Return.
        return (listValues);
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================





    //==========================================================================
    //===   TOSTRING   =========================================================

    /**
     * Prints out the Map2D nicely.
     */
    public String toString() {
       //return grid.toString();

       StringBuffer sb = new StringBuffer();
       Set cols = getCols();
       Iterator colIt;
       if (cols != null) {
          colIt = cols.iterator();
          sb.append('\t');
          while (colIt.hasNext()) {
             Object colHeader = colIt.next();
             sb.append(colHeader);
             sb.append('\t');
          }
          sb.append('\n');
       }

       Set rows = getRows();
       if (rows != null) {
          Iterator rowIt = rows.iterator();
          while (rowIt.hasNext()) {
             Object rowHeader = rowIt.next();
             sb.append(rowHeader);
             sb.append('\t');
             colIt = getCols().iterator();
             while (colIt.hasNext()) {
                Object colHeader = colIt.next();
                Object data = get(rowHeader, colHeader);
                sb.append(data);
                sb.append('\t');
             }
             sb.append('\n');
          }
       }

       if (rows == null && cols == null) {
          return "null";
       }

       return sb.toString();
    } // of method

    //-----------------------------------------------------------------

    /**
     * Prints out this Map2D with much more controlled formatting.
     */
    public String toDebugString() {
        return (toDebugString(1));
    } // of method

    //--------------------

    /**
     * Prints out this Map2D with much more controlled formatting.
     *
     * @param colSpacing     is the space between each column.
     */
    public String toDebugString(int colSpacing) {
        return (toDebugString(colSpacing, true, true));
    } // of method

    //--------------------

    /**
     * Prints out this Map2D with much more controlled formatting.
     *
     * @param colSpacing     is the space between each column.
     * @param flagTight      is true if each col is min length, false if the 
     *                       cols are uniform length
     * @param flagNoNull     is true to skip over null values, 
     *                       false to return "null".
     */
    public String toDebugString(int colSpacing, boolean flagTight, 
                                boolean flagNoNull) {
        return (toDebugString(new LinkedList(getRows()), 
                              new LinkedList(getCols()), 
                              colSpacing, flagTight, flagNoNull));
    } // of method

    //--------------------

    /**
     * Prints out this Map2D with much more controlled formatting.
     *
     * @param listRowHeaders is the rows in the order you want them displayed.
     * @param listColHeaders is the cols in the order you want them displayed.
     * @param colSpacing     is the space between each column.
     * @param flagTight      is true if each col is min length, false if the 
     *                       cols are uniform length
     * @param flagNoNull     is true to skip over null values, 
     *                       false to return "null".
     */
    public String toDebugString(List    listRowHeaders, 
                                List    listColHeaders,
                                int     colSpacing, 
                                boolean flagTight, 
                                boolean flagNoNull) {

        StringBuffer strbuf         = new StringBuffer();
        int[]        colWidths      = new int[numCols() + 1];  // +1 row hdrs
        int          numCols        = numCols();
        Iterator     itRows;
        Iterator     itCols;
        Object       rowKey;
        Object       colKey;

        //// 1.1. Calculate the non-uniform col width.
        ////      In this case, the width of each column is
        ////      equal to width of longest String. Each column width is
        ////      stored in colWidths[], with 0 being the row names.
        if (flagTight == true) {
            //// 1.1.1. Calculate width of row header column.
            colWidths[0] = StringLib.calcLongestStringLen(listRowHeaders,
                                                          flagNoNull);

            //// 1.1.2. Calculate max width of each column.
            ////        Max width = Max (width of col header, max width of vals)
            int widthHeader;
            int widthCol;
            Map colTmp;

            itCols = listColHeaders.iterator();
            for (int i = 0; i < numCols; i++) {
                colKey         = itCols.next();
                widthHeader    = colKey.toString().length();
                colTmp         = getCol(colKey);
                widthCol       = StringLib.calcLongestStringLen(colTmp.values(),
                                                                flagNoNull);
                colWidths[i+1] = Math.max(widthHeader, widthCol);
            }
        }
        //// 1.2. Calculate the uniform col width.
        ////      Just find the longest header or value and use that.
        else {
            int maxRowKeyLen;
            int maxColKeyLen;
            int maxValLen;
            int colWidth;

            maxRowKeyLen = StringLib.calcLongestStringLen(getRows(),flagNoNull);
            maxColKeyLen = StringLib.calcLongestStringLen(getCols(),flagNoNull);
            maxValLen    = StringLib.calcLongestStringLen(values(), flagNoNull);

            colWidth = Math.max(maxRowKeyLen, maxColKeyLen);
            colWidth = Math.max(colWidth,     maxValLen);

            for (int i = 0; i < colWidths.length; i++) {
                colWidths[i] = colWidth;
            }
        }

        //// 1.3. Add colspacing to each column.
        for (int i = 0; i < colWidths.length; i++) {
            colWidths[i] += colSpacing;
        }

        //// 1.4. Debugging.
        // for (int i = 0; i < colWidths.length; i++) {
        //     System.out.print(colWidths[i] + " ");
        // }
        // System.out.println();



        //// 2. Start formatting the output.

        //// 2.1. Add the column headers along the top.
        int i  = 1;
        itCols = listColHeaders.iterator();

        strbuf.append(StringLib.blank(colWidths[0]));
        while (itCols.hasNext()) {
            strbuf.append(StringLib.padAtEnd(itCols.next().toString(), 
                                             colWidths[i++]));
        }


        //// 2.2. Now append each row.
        Map    row;
        Object val;
        String strVal;

        //// 2.2. For each row....
        itRows = listRowHeaders.iterator();
        while (itRows.hasNext()) {
            //// 2.2.1. Add the row name.
            strbuf.append("\n");
            rowKey = itRows.next();
            row    = getRow(rowKey);
            strbuf.append(StringLib.padAtEnd(rowKey.toString(), colWidths[0]));
            itCols = listColHeaders.iterator();
            i      = 1;

            //// 2.2.2. Go through each column in the current row...
            while (itCols.hasNext()) {
                colKey = itCols.next();
                val    = row.get(colKey);

                //// 2.2.2.1. Handle what happens if there is a null value...
                if (val == null) {
                    if (flagNoNull == true) {
                        strVal = "";
                    }
                    else {
                        strVal = "null";
                    }
                }
                //// 2.2.2.2. Handle the normal case.
                else {
                    strVal = val.toString();
                }

                //// 2.2.2.3. Append the value as a String to the StringBuffer.
                strbuf.append(StringLib.padAtEnd(strVal, colWidths[i++]));
            }
        }

        //// 3. Return.
        return (strbuf.toString());

    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   CLONE   ============================================================

    public Object clone() {
       return new Map2D(this);
    } // of method

    //===   CLONE   ============================================================
    //==========================================================================




    //==========================================================================
    //===   MAIN   =============================================================

    // Get a simple test case
    public static Map2D getTestInstanceAAA() {
       Map2D grid = new Map2D();

       grid.put(new Integer(12345678), new Integer(1),"Long String name here!");
       grid.put(new Integer(5), new Integer(1), "Hey!");

       grid.put(new Integer(4), new Integer(2), "Hey!");
       //grid.put(new Integer(5), new Integer(2), "D'oh!");

       grid.put(new Integer(4), new Integer(5), "Yo!");
       grid.put(new Integer(5), new Integer(5), "Yo!");

       return (grid);
    } // of method

    //-----------------------------------------------------------------

    private static void runTestAAA() {
    } // of method

    //-----------------------------------------------------------------

    /**
     * Self-testing main
     */
    public static void main(String[] args) {
       Map2D grid = getTestInstanceAAA();
       System.out.println(grid);

       Map toMatch = new HashMap();
       toMatch.put(new Integer(4), "Yo!");
       toMatch.put(new Integer(5), "D'oh!");

       System.out.println(grid.matchCol(toMatch));

       grid.removeCol(new Integer(2));

       System.out.println(grid);

       Map2D grid2 = new Map2D(grid);

       System.out.println("Original: ");
       System.out.println(grid);

       System.out.println("Clone: ");
       System.out.println(grid2);

       grid2.put(new Integer(4), new Integer(5), "6");
       grid2.put(new Integer(5), new Integer(2), "3");

       System.out.println("Original: ");
       System.out.println(grid);

       System.out.println("Clone: ");
       System.out.println(grid2);

       System.out.println("All values: ");
       Iterator it = grid.values().iterator();
       while (it.hasNext()) {
           System.out.println("   " + it.next());
       }

       System.out.println();
       System.out.println();
       System.out.println();
       System.out.println(grid);
       System.out.println(grid.getRow(new Integer(4)));
       System.out.println(grid.getRow(new Integer(5)));
       System.out.println(grid.getRow(new Integer(9))); // empty
       System.out.println(grid.getCol(new Integer(1)));
       System.out.println(grid.getCol(new Integer(5)));
       System.out.println(grid.getCol(new Integer(9))); // empty
       System.out.println();
       System.out.println();
       System.out.println();

       System.out.println("AAA");
       System.out.println(grid.toDebugString(1, true, true));   // tight, nonull
       System.out.println("BBB");
       System.out.println(grid.toDebugString(2, true, false));  // tight, null
       System.out.println("CCC");
       System.out.println(grid.toDebugString(3, false, true));  // unifrm,nonull
       System.out.println("DDD");
       System.out.println(grid.toDebugString(4, false, false)); // unifrm,null
       System.out.println("EEE");
       System.out.println(grid.toDebugString(2));
       System.out.println(grid.toDebugString(5));
       System.out.println(grid.toDebugString(10));

    } // of method
    

    //===   MAIN   =============================================================
    //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
