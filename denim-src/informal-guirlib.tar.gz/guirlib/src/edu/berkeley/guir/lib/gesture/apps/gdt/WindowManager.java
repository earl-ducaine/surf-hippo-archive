package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.GestureFile;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

/** Manage the top-level windows of this application. */
public class WindowManager {
  private WindowManager() {}

  /** of JFrame (or subclasses, such as MainFrame) */
  protected static List windowList = new ArrayList();
  
  public static MainFrame createMainFrame()
  {
    MainFrame frame = new MainFrame();
    newFrame(frame);
    return frame;
  }

  public static MainFrame createMainFrame(GestureFile f)
  {
    MainFrame frame = new MainFrame(f);
    newFrame(frame);
    return frame;
  }

  protected static void newFrame(JFrame frame)
  {
    windowList.add(frame);
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosed(WindowEvent e) {
	windowList.remove(e.getSource());
	if (windowList.size() == 0) {
	  System.exit(0);
	}
      }
    });
  }
  
  public static JFrame[] getFrames()
  {
    return (JFrame[]) windowList.toArray();
  }

  public static int getFrameCount()
  {
    return windowList.size();
  }
  
  /** returns true if no closes were cancelled (i.e. if it's ok to
      proceed) */
  public static boolean closeAll()
  {
    for (Iterator iter = windowList.iterator(); iter.hasNext();) {
      JFrame frame = (JFrame) iter.next();
      if (frame instanceof MainFrame) {
	MainFrame mf = (MainFrame) frame;
	if (!mf.doClose()) {
	  return false;
	}
      }
      iter.remove();
      frame.dispose();
    }
    return true;
  }
}
