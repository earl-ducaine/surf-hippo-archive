package edu.berkeley.guir.lib.awt.image.eztwain;

/**
 * <PRE>
 * Revisions:  - GUIRLib-v1.0-1.0.0, Jan 21 2000, FL
 *               Created class
 *             - GUIRLib-v1.4-1.0.0, Aug 31 2000, JH
 *               Touched for GUIRLib release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~fli/">Francis Li</A> (
 *          <A HREF="mailto:fli@cs.berkeley.edu">fli@cs.berkeley.edu</A>)
 * @since   JDK 1.3
 * @version GUIRLib-v1.4-1.0.0, Aug 31 2000
 */
public class EZTwainWrapper 
{
   static
   {
      System.loadLibrary ("eztwrap");
   }

   public static final int TWAIN_BW = 0x0001;
   public static final int TWAIN_GRAY = 0x002;
   public static final int TWAIN_RGB = 0x0004;
   public static final int TWAIN_PALETTE = 0x0008;   
   public static final int TWAIN_ANYTYPE = 0x0000;
   
   public static final int TWAIN_PRESESSION = 1;      // source manager not loaded
   public static final int TWAIN_SM_LOADED = 2;       // source manager loaded
   public static final int TWAIN_SM_OPEN = 3;         // source manager open
   public static final int TWAIN_SOURCE_OPEN = 4;     // source open but not enabled
   public static final int TWAIN_SOURCE_ENABLED = 5;  // source enabled to acquire
   public static final int TWAIN_TRANSFER_READY = 6;  // image ready to transfer
   public static final int TWAIN_TRANSFERRING = 7;    // image in transit
   
   /** Creates new EZTwainWrapper */
   public EZTwainWrapper() 
   {
   }
   
   // Wrappers to EZTwain API
   public native void selectImageSource (int hwnd);
   
   public native int acquireNative (int hwnd, int pixTypes);
   public native void freeNative (int handle);
   
   public native int dibWidth (int handle);
   public native int dibHeight (int handle);
   public native int dibDepth (int handle);
   public native void dibReadRowRGB (int handle, int row, byte[] buf);

   public native int getState ();
   
   public native void setMultiTransfer (int val);
   public native int getMultiTransfer ();
   
   public native int closeSourceManager (int hwnd);
   public native int unloadSourceManager ();
   
   public native int closeSource ();
   public native int disableSource ();
   public native int enableSource (int hwnd);
   
   public static void main (String[] strArgs)
   {
      EZTwainWrapper source = new EZTwainWrapper ();
      source.selectImageSource (0);
   }
}

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/

