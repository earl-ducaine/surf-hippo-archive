package edu.berkeley.guir.lib.satin.objects;

import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.satin.view.*;
import java.util.List;

/**
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v2.1-1.0.0, Aug 24 2000, JH
 *               Created
 *             - SATIN-v2.1-1.1.0, Feb 26 2001, JL
 *               * Changed return type of getRelativeLayer() from String to int
 *               * Changed return type of getAbsoluteLayer() from String to
 *                 List of Integers
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class GraphicalObjectWrapper
   implements GraphicalObject {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   protected long                  id;          // our unique ID
   protected GraphicalObjectGroup parent;      // our parent object
   protected GraphicalObject      gob;         // the one we proxy
   private   GlobalID             globalID = null; // id tuple for distributed apps

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================

   //===========================================================================
   //===   CONSTRUCTOR   =======================================================

   /**
    * Create an empty proxy.
    */
   public GraphicalObjectWrapper() {
      id = GraphicalObjectLib.getUniqueID();
   } // of method

   /**
    * Create a proxy pointing to the specified Graphical Object.
    */
   public GraphicalObjectWrapper(GraphicalObject gob) {
      this();
      setGraphicalObject(gob);
   } // of method

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================



   //===========================================================================
   //===   PROXY METHODS   =====================================================

   public void setGraphicalObject(GraphicalObject newGob) {
      this.gob = newGob;

      //// Set the parent of the contained gob to be our parent.
      this.gob.setParentGroup(parent);
   } // of method

   public GraphicalObject getGraphicalObject() {
      return (gob);
   } // of method

   //===   PROXY METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   ID METHODS   ========================================================

   /**
    * Done on proxy, not on proxied object.
    */
   public long getUniqueID() {
      return (id);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Done on proxy, not on proxied object.
    */
   public void setUniqueID(long newID) {
      this.id = newID;

      // Make sure that any GraphicalObjects created afterwards cannot have
      // the same unique ID as this GraphicalObject
     /* if (newID >= GraphicalObjectLib.uniqueID) {
         GraphicalObjectLib.uniqueID = newID + 1;
      }
      */
   } // of method

   /**
    * For historical reasons, SATIN objs have two id's. an unique integer ID used for
    * single-machine applications, and a {hostname, id} pair used for distributed apps.
    * Note that the id in the pair will equal the local id on the machine that created
    * the object, but it will be different than the local id of that object on other
    * machines.
    */
   public void setGlobalID(String host, int id) {
      globalID = new GlobalID(host, id);
   }

   
   /**
    * For historical reasons, SATIN objs have two id's. an unique integer ID used for
    * single-machine applications, and a {hostname, id} pair used for distributed apps.
    * Note that the id in the pair will equal the local id on the machine that created
    * the object, but it will be different than the local id of that object on other
    * machines.
    */
   public void setGlobalID(GlobalID guid) {
      globalID = guid;  
   }


   /**
    * For historical reasons, SATIN objs have two id's. an unique integer ID used for
    * single-machine applications, and a {hostname, id} pair used for distributed apps.
    * Note that the id in the pair will equal the local id on the machine that created
    * the object, but it will be different than the local id of that object on other
    * machines.
    */
   public GlobalID getGlobalID() {
      return globalID;      
   }
   

   /**
    * For historical reasons, SATIN objs have two id's. an unique integer ID used for
    * single-machine applications, and a {hostname, id} pair used for distributed apps.
    * Note that the id in the pair will equal the local id on the machine that created
    * the object, but it will be different than the local id of that object on other
    * machines.
    */
   public String getGlobalIDXML() {
      return globalID.toXML();
   }

   
   //===   ID METHODS   ========================================================
   //===========================================================================



   //===========================================================================
   //===   PROPERTY METHODS   ==================================================

   public Iterator getPropertyNames() {
      return (gob.getPropertyNames());
   } // of method

   public Object getProperty(String strPropertyName) {
      return (gob.getProperty(strPropertyName));
   } // of method

   public void setProperty(String strPropertyName, Object newVal) {
      gob.setProperty(strPropertyName, newVal);
   } // of method

   public Object removeProperty(String strPropertyName) {
      return (gob.removeProperty(strPropertyName));
   } // of method

   //-----------------------------------------------------------------

   public List getIndexedProperty(String strPropertyName) {
      return (gob.getIndexedProperty(strPropertyName));
   } // of method

   public Object getIndexedProperty(String strPropertyName, int index) {
      return (gob.getIndexedProperty(strPropertyName, index));
   } // of method

   public void 
   setIndexedProperty(String strPropertyName, int index, Object newVal) {
      gob.setIndexedProperty(strPropertyName, index, newVal);
   } // of method

   public void addIndexedProperty(String strPropertyName, Object newVal) {
      gob.addIndexedProperty(strPropertyName, newVal);
   } // of method

   public Object removeIndexedProperty(String strPropertyName, int index) {
      return (gob.removeIndexedProperty(strPropertyName, index));
   } // of method

   public List removeIndexedProperty(String strPropertyName) {
      return (gob.removeIndexedProperty(strPropertyName));
   } // of method

   public void clearIndexedProperty(String strPropertyName) {
      gob.clearIndexedProperty(strPropertyName);
   } // of method

   //===   PROPERTY METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   VIEW METHODS   ======================================================

   public void setView(View v) {
      gob.setView(v);
   } // of method

   public View getView() {
      return (gob.getView());
   } // of method

   //===   VIEW METHODS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   INTERPRETER METHODS   ===============================================

   public Interpreter setGestureInterpreter(Interpreter intrp) {
      return (gob.setGestureInterpreter(intrp));
   } // of method

   public Interpreter getGestureInterpreter() {
      return (gob.getGestureInterpreter());
   } // of method

   public Interpreter setInkInterpreter(Interpreter intrp) {
      return (gob.setInkInterpreter(intrp));
   } // of method

   public Interpreter getInkInterpreter() {
      return (gob.getInkInterpreter());
   } // of method

   //===   INTERPRETER METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   STYLE METHODS   =====================================================

   public Style setStyle(Style newStyle) {
      return (gob.setStyle(newStyle));
   } // of method

   public Style getStyle() {
      return (gob.getStyle());
   } // of method

   public Style getStyleRef() {
      return (gob.getStyleRef());
   } // of method

   //===   STYLE METHODS   =====================================================
   //===========================================================================

   
   //===========================================================================
   //===   RESIZE MODE METHODS   ===============================================

   public void setResizeMode(int resizeMode) {
      gob.setResizeMode(resizeMode);
   }
   
   //-----------------------------------------------------------------

   public int getResizeMode() {
      return gob.getResizeMode();
   }

   //===   RESIZE MODE METHODS   ===============================================
   //===========================================================================


   //===========================================================================
   //===   LAYER METHODS   =====================================================

   public int getRelativeLayer() {
      return(gob.getRelativeLayer());
   } // of method

   public void setRelativeLayer(int layer) {
      gob.setRelativeLayer(layer);
   } // of method

   public java.util.List getAbsoluteLayer() {
      return(gob.getAbsoluteLayer());
   } // of method

   public void bringUpALayer() {
      gob.bringUpALayer();
   } // of method

   public void bringUpNLayers(int n) {
      gob.bringUpNLayers(n);
   } // of method

   public void bringDownALayer() {
      gob.bringDownALayer();
   } // of method

   public void bringDownNLayers(int n) {
      gob.bringDownNLayers(n);
   } // of method

   public void bringToTopLayer() {
      gob.bringToTopLayer();
   } // of method

   public void bringToBottomLayer() {
      gob.bringToBottomLayer();
   } // of method

   //===   LAYER METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   INIT METHODS   ======================================================

   public void initAfterAdd() {
      gob.initAfterAdd();
   } // of method

   //-----------------------------------------------------------------

   public void initAfterAddToSheet() {
      gob.initAfterAddToSheet();
   } // of method

   //===   INIT METHODS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   TRANSFORM METHODS   =================================================

   public void applyTransform(AffineTransform newTx) {
      gob.applyTransform(newTx);
   } // of method

   public void setTransform(AffineTransform newTx) {
      gob.setTransform(newTx);
   } // of method

   public AffineTransform getTransformRef() {
      return (gob.getTransformRef());
   } // of method

   public AffineTransform getTransform(int cdsys) {
      return (gob.getTransform(cdsys));
   } // of method

   public AffineTransform getTransform(int cdsys, AffineTransform outTx) {
      return (gob.getTransform(cdsys, outTx));
   } // of method

   public AffineTransform getInverseTransform(int cdsys) {
      return (gob.getInverseTransform(cdsys));
   } // of method

   public AffineTransform getInverseTransform(int cdsys, AffineTransform outTx){
      return (gob.getInverseTransform(cdsys, outTx));
   } // of method

   //===   TRANSFORM METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   MISCELLANEOUS LOCATION METHODS   ====================================

   public float minDistance(int cdsys, double x, double y) {
      return (gob.minDistance(cdsys, x, y));
   } // of method

   public float minDistance(int cdsys, Point2D pt) {
      return (gob.minDistance(cdsys, pt));
   } // of method

   //===   MISCELLANEOUS LOCATION METHODS   ====================================
   //===========================================================================



   //===========================================================================
   //===   VIEW ACCESSOR METHODS   =============================================

   public Point2D getLocation2D(int cdsys) {
      return (gob.getLocation2D(cdsys));
   } // of method

   public Point2D getLocation2D(int cdsys, AffineTransform tx, Point2D pt) {
      return (gob.getLocation2D(cdsys, tx, pt));
   } // of method

   public Rectangle2D getBounds2D(int cdsys) {
      return (gob.getBounds2D(cdsys));
   } // of method

   public Rectangle2D getBounds2D(int cdsys, AffineTransform tx, 
                                  Rectangle2D rect) {
      return (gob.getBounds2D(cdsys, tx, rect));
   } // of method

   public Polygon2D getBoundingPoints2D(int cdsys) {
      return (gob.getBoundingPoints2D(cdsys));
   } // of method

   public Polygon2D getBoundingPoints2D(int cdsys, AffineTransform tx, 
                                        Polygon2D poly) {
      return (gob.getBoundingPoints2D(cdsys, tx, poly));
   } // of method

   public float getWidth2D(int cdsys) {
      return (gob.getWidth2D(cdsys));
   } // of method

   public float getHeight2D(int cdsys) {
      return (gob.getHeight2D(cdsys));
   } // of method

   public void setHasClosedBoundingPoints(boolean flag) {
      gob.setHasClosedBoundingPoints(flag);
   } // of method

   public boolean hasClosedBoundingPoints() {
      return (gob.hasClosedBoundingPoints());
   } // of method

   //===   VIEW ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   GRAPHICAL OBJECT SHAPE METHODS   ====================================

   public boolean shapeContains(GraphicalObject gob) {
      return (gob.shapeContains(gob));
   } // of method

   public boolean shapeContains(int cdsys, Point2D pt) {
      return (gob.shapeContains(cdsys, pt));
   } // of method

   public boolean shapeContains(int cdsys, double x, double y) {
      return (gob.shapeContains(cdsys, x, y));
   } // of method

   public boolean shapeContains(int cdsys, Shape s) {
      return (gob.shapeContains(cdsys, s));
   } // of method

   public boolean shapeIntersects(GraphicalObject gob) {
      return (gob.shapeIntersects(gob));
   } // of method

   public boolean shapeIntersects(int cdsys, Shape s) {
      return (gob.shapeIntersects(cdsys, s));
   } // of method

   //===   GRAPHICAL OBJECT SHAPE METHODS   ====================================
   //===========================================================================



   //===========================================================================
   //===   SHAPE METHODS   =====================================================

   public boolean contains(double x, double y) {
      return (gob.contains(x, y));
   } // of method

   public boolean contains(double x, double y, double w, double h) {
      return (gob.contains(x, y, w, h));
   } // of method

   public boolean contains(Point2D p) {
      return (gob.contains(p));
   } // of method

   public boolean contains(Rectangle2D r) {
      return (gob.contains(r));
   } // of method

   public Rectangle getBounds() {
      return (gob.getBounds());
   } // of method

   public Rectangle2D getBounds2D() {
      return (gob.getBounds2D());
   } // of method

   public PathIterator getPathIterator(AffineTransform at) {
      return (gob.getPathIterator(at));
   } // of method

   public PathIterator getPathIterator(AffineTransform at, double flatness) {
      return (gob.getPathIterator(at, flatness));
   } // of method

   public boolean intersects(double x, double y, double w, double h) {
      return (gob.intersects(x, y, w, h));
   } // of method

   public boolean intersects(Rectangle2D r) {
      return (gob.intersects(r));
   } // of method

   //===   SHAPE METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   WATCHABLE METHODS   =================================================

   public Watcher addWatcher(Watcher w) {
      return (gob.addWatcher(w));
   } // of method

   public int countWatchers() {
      return (gob.countWatchers());
   } // of method

   public Watcher removeWatcher(Watcher w) {
      return (gob.removeWatcher(w));
   } // of method

   public void clearWatchers() {
      gob.clearWatchers();
   } // of method

   public void enableNotify() {
      gob.enableNotify();
   } // of method

   public void disableNotify() {
      gob.disableNotify();
   } // of method

   public boolean hasNotifyEnabled() {
      return (gob.hasNotifyEnabled());
   } // of method

   public void notifyWatchers() {
      gob.notifyWatchers();
   } // of method

   public void notifyWatchers(Object arg) {
      gob.notifyWatchers(arg);
   } // of method

   public void notifyWatchersUpdate(Object arg) {
      gob.notifyWatchersUpdate(arg);
   } // of method

   public void notifyWatchersUpdate(String strProperty,
         Object oldVal, Object newVal) {
      gob.notifyWatchersUpdate(strProperty, oldVal, newVal);
   } // of method

   public void notifyWatchersDelete() {
      gob.notifyWatchersDelete();
   } // of method

   //===   WATCHABLE METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   VIEW MODIFIER METHODS   =============================================

   public boolean isSelectable() {
      return (gob.isSelectable());
   } // of method

   public void setSelectable(boolean flag) {
      gob.setSelectable(flag);
   } // of method

   public void moveTo(int cdsys, double x, double y) {
      gob.moveTo(cdsys, x, y);
   } // of method

   public void moveTo(int cdsys, double x, double y, double theta) {
      gob.moveTo(cdsys, x, y, theta);
   } // of method

   public void moveTo(int cdsys, Point2D pt) {
      gob.moveTo(cdsys, pt);
   } // of method

   public void moveBy(int cdsys, double dx, double dy) {
      gob.moveBy(cdsys, dx, dy);
   } // of method

   public void moveBy(int cdsys, Point2D pt) {
      gob.moveBy(cdsys, pt);
   } // of method

   public void setBoundingPoints2D(int cdsys, Shape s) {
      gob.setBoundingPoints2D(cdsys, s);
   } // of method

   //===   VIEW MODIFIER METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   DISPATCHING METHODS   ===============================================

   public void onNewStroke(NewStrokeEvent evt) {
      gob.onNewStroke(evt);
   } // of method

   public void preProcessNewStroke(NewStrokeEvent evt) {
      gob.preProcessNewStroke(evt);
   } // of method

   public void redispatchNewStroke(NewStrokeEvent evt) {
      gob.redispatchNewStroke(evt);
   } // of method

   public void postProcessNewStroke(NewStrokeEvent evt) {
      gob.postProcessNewStroke(evt);
   } // of method

   public void handleNewStroke(NewStrokeEvent evt) {
      gob.handleNewStroke(evt);
   } // of method

   public void onUpdateStroke(UpdateStrokeEvent evt) {
      gob.onUpdateStroke(evt);
   } // of method

   public void preProcessUpdateStroke(UpdateStrokeEvent evt) {
      gob.preProcessUpdateStroke(evt);
   } // of method

   public void redispatchUpdateStroke(UpdateStrokeEvent evt) {
      gob.redispatchUpdateStroke(evt);
   } // of method

   public void postProcessUpdateStroke(UpdateStrokeEvent evt) {
      gob.postProcessUpdateStroke(evt);
   } // of method

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      gob.handleUpdateStroke(evt);
   } // of method

   public void onSingleStroke(SingleStrokeEvent evt) {
      gob.onSingleStroke(evt);
   } // of method

   public void preProcessSingleStroke(SingleStrokeEvent evt) {
      gob.preProcessSingleStroke(evt);
   } // of method

   public void redispatchSingleStroke(SingleStrokeEvent evt) {
      gob.redispatchSingleStroke(evt);
   } // of method

   public void postProcessSingleStroke(SingleStrokeEvent evt) {
      gob.postProcessSingleStroke(evt);
   } // of method

   public void handleSingleStroke(SingleStrokeEvent evt) {
      gob.handleSingleStroke(evt);
   } // of method

   //===   DISPATCHING METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   DISPLAY METHODS   ===================================================

   public void setVisible(boolean flag) {
      gob.setVisible(flag);
   } // of method

   public boolean isVisible() {
      return (gob.isVisible());
   } // of method

   public void disableDamage() {
      gob.disableDamage();
   } // of method

   public void enableDamage() {
      gob.enableDamage();
   } // of method

   public boolean hasDamageEnabled() {
      return (gob.hasDamageEnabled());
   } // of method

   public void setClipToBounds(boolean flag) {
      gob.setClipToBounds(flag);
   } // of method

   public boolean isClippedToBounds() {
      return (gob.isClippedToBounds());
   } // of method

   /**
    * Done on proxy, not on proxied object.
    */
   public void damage(int sync) {
      parent.damage(sync);
   } // of method

   /**
    * Done on proxy, not on proxied object.
    */
   public void damage(int sync, GraphicalObject gob) {
      parent.damage(sync, gob);
   } // of method

   /**
    * Done on proxy, not on proxied object.
    */
   public void damage(int sync, Rectangle2D rect) {
      parent.damage(sync, rect);
   } // of method

   /**
    * Done on proxy, not on proxied object.
    */
   public void damage(int sync, Rectangle2D oldRect, Rectangle2D newRect) {
      parent.damage(sync, oldRect, newRect);
   } // of method

   public void render(SatinGraphics g) {
      gob.render(g);
   } // of method

   //===   DISPLAY METHODS   ===================================================
   //===========================================================================



   //===========================================================================
   //===   PARENTAL METHODS   ==================================================

   /**
    * Done on proxy, not on proxied object.
    */
   public GraphicalObjectGroup getParentGroup() {
      return (parent);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Done on proxy, not on proxied object.
    */
   public void setParentGroup(GraphicalObjectGroup newParent) {
      //// 1. Check if null. No need to repaint. Actually need this check,
      ////    because removing from a group causes a call to this, which
      ////    can lead to infinite recursion.
      if (newParent == null) {
         parent = null;
         gob.setParentGroup(null);
         return;
      }

      //// 2. Check if newParent is really a new parent.
      if (newParent == parent) {
         return;
      }

      //// 3. Remove ourself from the old parent.
      if (parent != null) {
         parent.remove(this);
      }

      //// 4. Update our reference to our new parent.
      parent = newParent;
      gob.setParentGroup(newParent);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Done on proxy, not on proxied object.
    */
   public Sheet getSheet() {
      if (parent != null) {
         return parent.getSheet();
      }
      else {
         return null;
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Done on proxy, not on proxied object.
    */
   public void delete() {
      notifyWatchersDelete();
   } // of method

   //===   PARENTAL METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Done on proxy, not on proxied object.
    */
   public Object clone() {
      GraphicalObjectWrapper gobw = new GraphicalObjectWrapper();
      clone(gobw);
      return (gobw);
   } // of method


   /**
    * Clone our current state into the passed-in object.
    * Used for clone chaining.
    */
   protected GraphicalObjectWrapper clone(GraphicalObjectWrapper gobw) {
      gobw.parent = this.parent;
      gobw.gob    = this.gob;
      return (gobw);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Done on proxy, not on proxied object.
    */
   public Object deepClone() {
      GraphicalObjectWrapper gobw = new GraphicalObjectWrapper();
      deepClone(gobw);
      return (gobw);
   } // of method


   /**
    * Deep clone our current state into the passed-in object.
    * Used for clone chaining.
    */
   protected GraphicalObjectWrapper deepClone(GraphicalObjectWrapper gobw) {
      gobw.parent = this.parent;
      gobw.gob    = (GraphicalObject) this.gob.deepClone();
      return (gobw);
   } // of method

   //===   CLONE METHODS   =====================================================
   //===========================================================================

} // of interface 

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES { LOSS OF USE, DATA, OR PROFITS { OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
