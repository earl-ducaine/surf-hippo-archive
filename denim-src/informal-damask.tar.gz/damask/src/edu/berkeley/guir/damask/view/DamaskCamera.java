package edu.berkeley.guir.damask.view;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.activities.PActivity;

/** 
 * A custom camera for Damask.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  02-24-2004 James Lin
 *                               Created DamaskCamera.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 02-24-2004
 */
public class DamaskCamera extends PCamera {
   // Fields related to panning the camera
   private final int PAN_JUMP = 25;
   
   private final PanActivity panActivity = new PanActivity(-1);
   private boolean panActive = false;

   /**
    * Constructs a camera.
    */
   public DamaskCamera() {

      final PropertyChangeListener boundsTransformListener =
         new CameraBoundsTransformListener();

      addPropertyChangeListener(PNode.PROPERTY_BOUNDS, boundsTransformListener);
      addPropertyChangeListener(
         PCamera.PROPERTY_VIEW_TRANSFORM,
         boundsTransformListener);
   }

   /**
    * Returns the activity that pans this camera.
    */
   public PanActivity getPanActivity() {
      return panActivity;
   }
   
   
   /**
    * Pans this camera by the given amount, in view coordinates.
    */
   public void panView(final double dx, final double dy) {
      translateView(dx / getViewScale(), dy / getViewScale());
   }
   
   // Panning methods ----------------------------------------------------

   /**
    * Sets if a pan control is active.  
    */
   public void setPanning(boolean flag) {
      panActive = flag;
      if (panActive) {
         final PRoot root = getRoot();
         panView(
            panActivity.getDx() * PAN_JUMP,
            panActivity.getDy() * PAN_JUMP);

         // Do the rest of the scrolling after a short delay (500ms).
         panActivity.setStartTime(root.getGlobalTime() + 500);

         root.addActivity(panActivity);
      }
      else {
         panActivity.terminate();
      }
   }


   /**
    * Returns if a pan control is active. 
    */
   public boolean isPanning() {
      return panActive;
   }

   /**
    * An activity that continuously pans the canvas.
    */
   public class PanActivity extends PActivity {
      private double dx;
      private double dy;

      private PanActivity(long aDuration) {
         super(aDuration);
      }

      private PanActivity(long aDuration, long aStepRate) {
         super(aDuration, aStepRate);
      }

      private PanActivity(long aDuration, long aStepRate, long aStartTime) {
         super(aDuration, aStepRate, aStartTime);
      }

      protected void activityStep(long elapsedTime) {
         super.activityStep(elapsedTime);
         panView(dx * PAN_JUMP, dy * PAN_JUMP);
      }

      /**
       * Returns the change in x that will occur when this activity is active.
       */
      public double getDx() {
         return dx;
      }

      /**
       * Returns the change in y that will occur when this activity is active.
       */
      public double getDy() {
         return dy;
      }

      /**
       * Sets how much and in which direction the activity should pan
       * the canvas.
       */
      public void setDirection(double dx, double dy) {
         this.dx = dx;
         this.dy = dy;
      }
   }


   private class CameraBoundsTransformListener
      implements PropertyChangeListener {

      public void propertyChange(PropertyChangeEvent evt) {
         if (getLayer(0) instanceof DamaskLayer) {
            // Reposition template pane
            final TemplatePane templatePane =
               ((DamaskLayer)getLayer(0)).getTemplatePane();
            
            templatePane.reposition(DamaskCamera.this, false);
         }
      }
   }
}
