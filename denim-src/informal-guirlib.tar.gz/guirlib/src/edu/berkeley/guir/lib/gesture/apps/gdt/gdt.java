package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.lang.System;
import javax.swing.*;
import java.awt.Font;
import java.awt.Color;
import java.io.File;
import edu.berkeley.guir.lib.gesture.*;

/**
 * Gesture Design Tool.
 * Allows one or more filenames to be specified on the command line,
 * which will be opened.
 */
public class gdt implements GDTConstants {
  static {
    Properties.setPropertyPersistence(CORRECT_RECOG_PROP, false);
  }
  
  private gdt()
  {
  }
  
  public static void main(String argv[])
  {
    boolean experiment = false;
    boolean useDefaults = false;
    boolean showWarnings = true;
    
    int i;
    for (i = 0; (i < argv.length) && (argv[i].charAt(0) == '-'); i++) {
      if (argv[i].equals("-e")) {
	experiment = true;
      }
      else if (argv[i].equals("-defaults")) {
	useDefaults = true;
      }
      else if (argv[i].equals("-no-warnings")) {
	showWarnings = false;
      }
      else {
	System.err.println("gdt: Unknown option: " + argv[i]);
	System.err.println("gdt: usage: gdt [-e] [-defaults] [gesturefile1 [gesturefile2 ...]]");
      }
    }

    if (!useDefaults) {
      setDefaults();
    }
    MainFrame.setDebugMenu(!experiment);
    MainFrame.setWarningsEnabled(showWarnings);
    
    if (i < argv.length) {
      // load any files given on the command line
      for (; i < argv.length; i++) {
	GestureFile file = new GestureFile(new File(argv[i]));
	MainFrame frame = WindowManager.createMainFrame(file);
	frame.pack();
	frame.show();
      }
    }
    else {
      MainFrame frame = WindowManager.createMainFrame();
      frame.pack();
      frame.show();
    }
  }

  static void setDefaults()
  {
    Font bigFont = new Font("Serif", Font.PLAIN, 16);
    Font smallFont = new Font("Serif", Font.PLAIN, 14);
    UIManager.put("Label.font", bigFont);
    UIManager.put("Label.background", Color.lightGray);
    UIManager.put("Label.foreground", Color.black);
    UIManager.put("TitledBorder.font", smallFont);
    UIManager.put("TitledBorder.foreground", Color.black);
    UIManager.put("TitledBorder.titleColor", Color.black);
    // I don't know why I need to set the foreground color of labels.
    // You'd think that they would be black by default, but under
    // Swing 1.0.3 they're lavendar.
    /*
    UIManager.put("Label.foreground", Color.black);
    */
    UIManager.put("CheckBoxMenuItem.font", bigFont);
    UIManager.put("MenuItem.font", bigFont);
    UIManager.put("Menu.font", bigFont);
    UIManager.put("Button.font", bigFont);
    UIManager.put("ToggleButton.font", bigFont);
    UIManager.put("TextPane.font", bigFont);
    UIManager.put("TextField.font", bigFont);
    UIManager.put("Tree.font", bigFont);
    // Serif plain 14 point looks terrible in the summary log
    //UIManager.put(SummaryLog.FONT, smallFont);
  }
}
