package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.*;
import javax.swing.*;
import java.awt.datatransfer.Transferable;

public class GestureCategoryPanel extends GestureContainerPanel
  implements GestureObjectDisplay {

  public GestureCategoryPanel()
  {
    this(null);
  }

  public GestureCategoryPanel(GestureCategory gc)
  {
    this(gc, null);
  }
  
  public GestureCategoryPanel(GestureCategory gc, JScrollPane scrollPane)
  {
    super(gc, scrollPane);
  }

  protected void addGestureObject(GestureObject gestureObj,
				  JScrollPane scrollPane, int index)
  {
    JComponent widget = DisplayFactory.create(gestureObj, scrollPane);
    widget.setBorder(BorderFactory.createEtchedBorder());
    if (widget instanceof SelectablePanel) {
      ((SelectablePanel) widget).setSelectable(false);
    }
    add(widget, index);
  }

  public void setGestureContainer(GestureContainer container)
  {
    if ((container == null) || (container instanceof GestureCategory)) {
      super.setGestureContainer(container);
    }
    else {
      throw new IllegalArgumentException("Only GestureCategory is allowed, not " + container.getClass().getName() + " (" + container + ")");
    }
  }

  public boolean canAcceptGesture()
  {
    return true;
  }
  
  public boolean gestureDrawn(Gesture gesture)
  {
    GestureCategory gestureCategory = (GestureCategory)
      getGestureContainer();
    gesture.normalize();
    gestureCategory.addGesture(gesture);
    return true;
  }

  public String getInputGestureTitle()
  {
    return "Draw a new example gesture";
  }

  public boolean canPaste(Transferable t)
  {
    return t.isDataFlavorSupported(GestureFlavorFactory.
				   GESTURE_EXAMPLE_COLLECTION_FLAVOR) ||
      t.isDataFlavorSupported(GestureFlavorFactory.GESTURE_EXAMPLE_FLAVOR);
  }

  public boolean isCommandValid(int id)
  {
    boolean valid;
    switch (id) {
    case NEW_GESTURE_ACTION:
    case NEW_GROUP_ACTION:
      /* todo: enable this?
    case RENAME_ACTION:
      */
      valid = true;
      break;
    default:
      valid = super.isCommandValid(id);
      break;
    }
    return valid;
  }

  /** return the gesture set that contains this category */
  public GestureSet getContainingSet()
  {
    return (GestureSet)	AbstractGestureContainer.
      findAncestorOfClass(getDisplayedObject(), GestureSet.class);
  }
  
  public void doCommand(int id)
  {
    switch (id) {
    case NEW_GESTURE_ACTION:
      getContainingSet().
	add(new GestureCategory(Gensym.next(GESTURE_CATEGORY_PREFIX)));
      break;
    case NEW_GROUP_ACTION:
      getContainingSet().
	add(new GestureGroup(Gensym.next(GESTURE_GROUP_PREFIX)));
      break;
    default:
      super.doCommand(id);
      break;
    }
  }
}
