//// See bottom of file for software license
package edu.berkeley.guir.lib.collection;

import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedList;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * A queue of TimedEvents sorted by activation time.
 * To use this, create subclasses of TimedEvent and call enqueue().
 * The TimedEvents will then run at their specified time.
 * <P>
 * This TimedQueue is prioritized by time, so you can also
 * add in events with time 0 to always activate immediately.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Oct 22 2002 JIH
 */
public class TimedEventQueue {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    private static final boolean DEBUG = false;

    //----------------------------------------------------------------

    public static final DateFormat DATEFORMAT = 
                         new SimpleDateFormat("EEE yyyy.MMM.dd HH:mm:ss z");

    //===   CONSTANTS   ========================================================
    //==========================================================================



    //==========================================================================
    //===   INNER CLASS - TIMED EVENT THREAD   =================================

    /**
     * A low priority thread for executing TimedEvents.
     */
    class TimedEventThread 
        extends Thread {

        public TimedEventThread() {
            super("TimedEventThread");
            setPriority(Thread.MIN_PRIORITY);
        } // of method

        //--------------------------------------------------------

        /**
         * Call all the events that should have been run by now.
         */
        public void executeEvents() {
            List       listEvents = getAllEvents(System.currentTimeMillis());
            Iterator   it         = listEvents.iterator();
            TimedEvent evt;

            if (DEBUG == true) {
                System.out.println("----------------");
                System.out.println(TimedEventQueue.this);
            }

            //// 1. For each event that should be run...
            while (it.hasNext()) {
                evt = (TimedEvent) it.next();
                try {
                    //// 1.1. Run that event.
                    if (DEBUG == true) {
                        System.out.println("Running evt: " + evt);
                    }
                    evt.run();

                    //// 1.2. Re-enqueue it if it is recurring.
                    if (evt.isRecurring() == true) {
                        evt.updateActivationTime();
                        TimedEventQueue.this.enqueue(evt);
                        // System.out.println("requeuing done");
                    }
                }
                catch (Exception e) {
                    System.out.println("Ignoring error, continuing...");
                    e.printStackTrace();
                }
            }

        } // of method

        //--------------------------------------------------------

        /**
         * Sleep for a while.
         */
        private void doWait(long millis) {
            try {
                synchronized (monitor) {
                    monitor.wait(millis);
                }
            }
            catch (Exception e) {
            }
        } // of method

        //--------------------------------------------------------

        /**
         * Run through the events when their activation time comes up.
         */
        public void run() {
            while (flagContinue == true) {
                //// 1. If no TimedEvents, then sleep for a while.
                ////    Have to acquire the monitor lock before wait().
                if (isEmpty() == true) {
                    // System.out.println("waiting...");
                    doWait(0);
                }
                //// 2. See if there are events that should be run.
                ////    If not, sleep for a while. If so, run them.
                else {
                    //// Have to synchronize here to avoid a race condition
                    //// with enqueue. Sometimes things were enqueued after
                    //// the getNextEventTime() was called, leading to
                    //// incorrect sleeptimes.
                    synchronized (monitor) {
                        long curTime   = System.currentTimeMillis();
                        long nextTime  = getNextEventTime();
                        long sleepTime = nextTime - curTime;

                        if (sleepTime > 0) {
                            // System.out.println("sleeping " + sleepTime);
                            doWait(sleepTime);
                        }
                        else {
                            // System.out.println("executing");
                            executeEvents();
                        }
                    }
                }
            } // of while
        } // of method

    } // of inner class

    //===   INNER CLASS - TIMED EVENT THREAD   =================================
    //==========================================================================



    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    //// Our ordered list of events.
    List    listEvents = Collections.synchronizedList(new LinkedList());

    //// Exit out of thread flag
    boolean flagContinue = true;

    //// The thread that executes TimedEvents
    Thread  timedEventThread = new TimedEventThread();

    //// A shared monitor for putting the TimedEventThread to sleep.
    Object  monitor = this;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================



    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    public TimedEventQueue() {
        timedEventThread.setDaemon(true);
        timedEventThread.start();
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================



    //==========================================================================
    //===   SHUTDOWN   =========================================================

    /**
     * Stop the TimedEventQueue. Events can still be enqueued, 
     * but will be ignored.
     */
    public void shutdown() {
        flagContinue = false;
        timedEventThread.interrupt();
    } // of method

    //===   SHUTDOWN   =========================================================
    //==========================================================================



    //==========================================================================
    //===   ENQUEUE / DEQUEUE METHODS   ========================================

    /**
     * Find the first index with time less than the specified millis.
     * For example, if the times were:
     * <PRE>
     *    [0]  [1]  [2]  [3]  [4]
     *    100  130  160  200  275
     *
     *    findIndex(0)   = 0;
     *    findIndex(110) = 1;
     *    findIndex(150) = 1;
     *    findIndex(170) = 3;
     *    findIndex(200) = 4;
     *    findIndex(500) = 5;   // greater than last index
     * </PRE>
     */
    private int findIndex(long millis) {
        Iterator   it    = listEvents.iterator();
        int        index = 0;
        TimedEvent tmpevt;

        while (it.hasNext()) {
            tmpevt = (TimedEvent) it.next();
            if ( millis < tmpevt.getActivationTime() ) {
                return (index);
            }
            index++;
        }
        return (index);
    } // of method

    //----------------------------------------------------------------

    /**
     * Enqueue the event at the right place with respect to time.
     */
    public synchronized void enqueue(TimedEvent evt) {
        //// 1. Figure out where to insert something.
        int index = findIndex( evt.getActivationTime() );
        // System.out.println("adding " + index + " " + evt);

        //// 2. Insert at index.
        listEvents.add(index, evt);

        //// 3. Wake up the thread.
        synchronized (monitor) {
            monitor.notifyAll();
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Check when the next event should activate.
     */
    public synchronized long getNextEventTime() {
        if (isEmpty() == true) {
            return (Long.MAX_VALUE);
        }

        TimedEvent evt = (TimedEvent) listEvents.get(0);
        return (evt.getActivationTime());
    } // of method

    //----------------------------------------------------------------

    /**
     * Remove the next event.
     */
    public synchronized TimedEvent dequeue() {
        return ((TimedEvent) listEvents.remove(0));
    } // of method

    //----------------------------------------------------------------

    /**
     * Get (and dequeue) all events that should have activated 
     * by the time specified.
     *
     * @return a List of TimedEvents.
     */
    public synchronized List getAllEvents(long millis) {
        int  index      = findIndex(millis);
        List listBefore = new LinkedList();

        for (int i = 0; i < index; i++) {
            listBefore.add( dequeue() );
        } 

        return (listBefore);
    } // of method

    //===   ENQUEUE / DEQUEUE METHODS   ========================================
    //==========================================================================



    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    /**
     * See how many events there are.
     */
    public int size() {
        return (listEvents.size());
    } // of method

    //----------------------------------------------------------------

    /**
     * Check if the queue is empty.
     */
    public boolean isEmpty() {
        return (size() <= 0);
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================



    //==========================================================================
    //===   TOSTRING   =========================================================

    public synchronized String toString() {
        StringBuffer strbuf = new StringBuffer();
        Iterator     it     = listEvents.iterator();
        TimedEvent   evt;
        long         activationTime;
        Date         d;

        strbuf.append("TimedEventQueue\n");

        while (it.hasNext()) {
            evt            = (TimedEvent) it.next();
            activationTime = evt.getActivationTime();
            d              = new Date(activationTime);

            strbuf.append("   run: " + DATEFORMAT.format(d) + 
                          " " + evt.toString());
            strbuf.append("\n");
        }
        return (strbuf.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================



    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    //// Generate a timed event with a random activation time
    //// 1-60 seconds ahead of the current time.
    public static TimedEvent getTestTimedEvent() {
        TimedEvent evt     = new TimedEvent.TestTimedEvent();
        long       curtime = System.currentTimeMillis();
        long       acttime = (long) (60 * 1000 * Math.random());
        evt.setActivationTime(curtime + acttime);
        evt.setRecurring(10000);

        return (evt);
    } // of method

    //==========================================================================

    private static void runTestAAA() throws Exception {
        TimedEventQueue q = new TimedEventQueue();
        TimedEvent      evt;

        System.out.println(q);
        Thread.sleep(2000);

        for (int i = 0; i < 5; i++) {
            evt = getTestTimedEvent();
            System.out.println("adding " + evt);
            q.enqueue(evt);
            System.out.println(q);
        }

        //// Test behavior here
        q.enqueue(new TimedEvent.TestTimedEvent(0));
    } // of method

    //==========================================================================

    public static void main(String[] argv) throws Exception {
        runTestAAA();
    } // of method

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2002 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
