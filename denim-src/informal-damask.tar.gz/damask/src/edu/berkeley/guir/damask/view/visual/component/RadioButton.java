package edu.berkeley.guir.damask.view.visual.component;

import java.awt.Color;
import java.awt.geom.Ellipse2D;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.component.SelectOne;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.visual.dialog.PageView;
import edu.berkeley.guir.damask.view.visual.dialog.PageViewContainer;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * A radio button.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  11-12-2003 James Lin
 *                               Created RadioButton.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 11-12-2003
 */
public class RadioButton extends ControlView {

   private static final int CIRCLE_DIAMETER = 15;
   private static final int SOLID_CIRCLE_DIAMETER = 7;
   private static final int GAP = 8; //distance between radio button and caption

   private Label caption;
   private final PPath circleOutline = new PPath();
   private final PPath solidCircle = new PPath();
   private boolean checked = false;

   /**
    * Creates a radio button.
    */
   public RadioButton(final SelectOne.Item selectOneItem) {
      super(selectOneItem, new RunModeEventHandler());
      setResizable(false);
   }

   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      final SelectOne.Item selectOneItem = (SelectOne.Item)getModel();

      // Add the circle outline
      circleOutline.setPathTo(
         new Ellipse2D.Double(0, 0, CIRCLE_DIAMETER, CIRCLE_DIAMETER));
      circleOutline.setPickable(false);
      addChild(circleOutline);

      // Add the caption
      caption = new Label(selectOneItem.getContent());
      caption.setPickable(false);
      addChild(caption);

      // Create filled button, but don't add it
      solidCircle.setPathTo(
         new Ellipse2D.Double(
            (CIRCLE_DIAMETER - SOLID_CIRCLE_DIAMETER) / 2,
            (CIRCLE_DIAMETER - SOLID_CIRCLE_DIAMETER) / 2,
            SOLID_CIRCLE_DIAMETER,
            SOLID_CIRCLE_DIAMETER));
      solidCircle.setPickable(false);
      solidCircle.setPaint(Color.BLACK);
      
      // Set the state of the radio button to match the model
      final PageView pageView = getPageView();
      if (pageView != null) {
         final SelectOne selectOne = (SelectOne)selectOneItem.getParent(); 
         final Dialog pageDialog = ((Page)(pageView.getModel())).getDialog();
         final Dialog controlDialog = selectOneItem.getDialog();
         final int condition;
         if (pageDialog == controlDialog) {
            condition = pageView.getDesignTimeCondition();
         }
         else {
            // Radio button actually represents a template control
            condition = controlDialog.getInitialCondition();
         }
         final Object state =
            selectOne.getStateForCondition(controlDialog, condition);
         setChecked(state == selectOneItem);
      }
   }

   
   /**
    * Returns whether this radio button is checked.
    */
   public Object getState() {
      return Boolean.valueOf(checked);
   }
   
   
   /**
    * Sets whether this radio button is checked. All other radio buttons
    * in this group will be unchecked.
    */
   public void setState(final Object state) {
      final boolean flag = ((Boolean)state).booleanValue();
      final RadioButtonGroup group = (RadioButtonGroup)getParent();
      
      if (flag) {
         group.setState(this);
      }
      else {
         group.setState(null);
      }
   }


   // Overrides abstract method in parent class.
   public Object getEditableContents() {
      return getContent();
   }

   /**
    * Returns the caption of this radio button.
    */
   public Label getContent() {
      return caption;
   }


   /**
    * Sets whether this radio button is checked.
    */
   protected void setChecked(final boolean state) {
      if (checked != state) {
         checked = state;
         if (checked) {
            addChild(solidCircle);
         }
         else {
            removeChild(solidCircle);
         }
      }
   }


   /**
    * Returns a representation of what a button looks like by default.
    */
   public static PNode createTempView() {
      final PNode parentNode = new PNode();

      // Create radio button
      final PPath radioButton =
         new PPath(
            new Ellipse2D.Double(0, 0, CIRCLE_DIAMETER, CIRCLE_DIAMETER));

      // Create caption
      final PPath squiggle = DamaskAppUtils.createSquiggle();
      squiggle.setOffset(CIRCLE_DIAMETER + GAP, 0);

      parentNode.addChild(radioButton);
      parentNode.addChild(squiggle);

      parentNode.setBounds(
         0,
         0,
         CIRCLE_DIAMETER + GAP + squiggle.getWidth(),
         CIRCLE_DIAMETER);

      return parentNode;
   }

   
   /**
    * The event handler for a radio button in Run mode.
    */
   private static class RunModeEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final RadioButton radioButton = (RadioButton)event.getPickedNode();
         radioButton.circleOutline.setPaint(Color.LIGHT_GRAY);
         container.setFocus(radioButton);
      }
      
      public void mouseReleased(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final RadioButton radioButton = (RadioButton)event.getPickedNode();
         
         if (container.getFocus() == radioButton) {
            radioButton.circleOutline.setPaint(DamaskAppUtils.NO_COLOR);

            final SelectOne.Item selectOneItem =
               (SelectOne.Item)radioButton.getModel();

            // Change state of radio button
            final RadioButtonGroup group =
               (RadioButtonGroup)radioButton.getParent();
            container.setControlState(
               (Control)group.getModel(), radioButton.getModel());
            
            // Follow an outgoing connection, if any
            final DeviceType deviceType = radioButton.getDeviceType();

            final NavConnection connection =
               selectOneItem.getOutConnection(
                  radioButton.getDeviceType(),
                  new InvokeEvent(selectOneItem),
                  container.getSelectedPageCondition());
            
            if (connection != null) {
               container.goToPage(
                  connection.getDest(deviceType).getPage(deviceType));
            }
         }
      }
      
      public void mouseEntered(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final RadioButton radioButton = (RadioButton)event.getPickedNode();
         if (container.getFocus() == radioButton) {
            radioButton.circleOutline.setPaint(Color.LIGHT_GRAY);
         }
      }
      
      public void mouseExited(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final RadioButton radioButton = (RadioButton)event.getPickedNode();
         if (container.getFocus() == radioButton) {
            radioButton.circleOutline.setPaint(DamaskAppUtils.NO_COLOR);
         }
      }
   }
}
