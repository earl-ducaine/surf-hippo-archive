package edu.berkeley.guir.damask;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.berkeley.guir.damask.component.*;

/** 
 * A mapping of device types to a list of interaction elements. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2003 James Lin
 *                               Created ComponentGroup.
 *             1.1.0  06-11-2003 James Lin
 *                               Split off DeviceDependentContainer.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-20-2003
 */
public class DeviceDependentContainer {

   private Map/*<DeviceType, List<InteractionElement>>*/ containees;

   //===========================================================================

   public DeviceDependentContainer() {
      containees = new HashMap();
   }

   //===========================================================================

   /**
    * Returns the devices that this component group deals with.
    */
   public Set/*<DeviceType>*/ getDeviceTypes() {
      return Collections.unmodifiableSet(containees.keySet());
   }

   //===========================================================================

   /**
    * Returns the components contained by this component group with the
    * given device, or an empty collection if there aren't any.
    */
   public List getContainees(DeviceType deviceType) {
      if (deviceType == DeviceType.ALL) {
         // Flatten the collection of lists into a single list.
         List containeesToReturn = new ArrayList();
         for (Iterator i = getDeviceTypes().iterator(); i.hasNext();) {
            DeviceType aDeviceType = (DeviceType)i.next();
            containeesToReturn.addAll(getContainees(aDeviceType));
         }

         return containeesToReturn;
      }
      else {
         return DamaskUtils.unmodifiableList((List)containees.get(deviceType));
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the given component to this group for the given device.
    * @param device
    * @param containee
    */
   public void add(DeviceType deviceType, InteractionElement containee) {
      add(deviceType, size(deviceType), containee);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the given component to this group for the given device.
    * @param device
    * @param containee
    */
   public void add(
      DeviceType deviceType,
      int index,
      InteractionElement containee) {
      final Collection devices = deviceType.getSpecificDeviceTypes();

      // If the deviceType is all, then we'll loop through multiple times
      // Otherwise, we'll only be in this loop once
      for (Iterator i = devices.iterator(); i.hasNext();) {
         final DeviceType aDevice = (DeviceType)i.next();

         // Add the containee to the list of containees for the given device.
         List containeesForDevice = (List)containees.get(aDevice);
         if (containeesForDevice == null) {
            containeesForDevice = new ArrayList();
            containees.put(aDevice, containeesForDevice);
         }
         containeesForDevice.add(index, containee);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given component from this group for the given device.
    * 
    * @return whether the given component was removed
    */
   public boolean remove(
      DeviceType deviceType,
      InteractionElement containee) {
      final Collection devices = deviceType.getSpecificDeviceTypes();
      boolean removed = false;

      for (Iterator i = devices.iterator(); i.hasNext();) {
         final DeviceType aDevice = (DeviceType)i.next();
         List containeesForDevice = (List)containees.get(aDevice);
         if (containeesForDevice != null) {
            boolean removedForDevice = containeesForDevice.remove(containee);
            if (removedForDevice) {
               removed = true;
            }
         }
      }
      return removed;
   }

   //===========================================================================

   /**
    * Returns the index of the specified object, or -1 if there is no such
    * index, from the specific device type's perspective.
    */
   public int indexOf(DeviceType deviceType, InteractionElement containee) {
      return ((List)containees.get(deviceType)).indexOf(containee);
   }

   //===========================================================================

   /**
    * Returns the number of items in this group, from the given device type's
    * perspective.
    */
   public int size(DeviceType deviceType) {
      final List list = (List)containees.get(deviceType);
      if (list == null) {
         return 0; 
      }
      else {
         return list.size();
      }
   }

   //===========================================================================
   
   /**
    * Clears the container.
    */
   public void clear() {
      containees.clear();
   }

   //===========================================================================

   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      try {
         DeviceDependentContainer clone =
            (DeviceDependentContainer)super.clone();
         Map origToClone = new HashMap();
         origToClone.put(this, clone);

         Set allChildren = new HashSet();

         // Create a set of all of the containees in this group.
         for (Iterator i = getDeviceTypes().iterator(); i.hasNext();) {
            DeviceType device = (DeviceType)i.next();
            for (Iterator j = getContainees(device).iterator(); j.hasNext();) {
               Component containee = (Component)j.next();
               allChildren.add(containee);
            }
         }

         // Clone each of the containees in this group.
         for (Iterator i = allChildren.iterator(); i.hasNext();) {
            Component containee = (Component)i.next();
            Component containeeClone = (Component)containee.clone();
            origToClone.put(containee, containeeClone);
         }

         // Fix the containees of the clone so that it points to the cloned
         // containees, not the original containees.
         Collection cloneDevices = clone.getDeviceTypes();
         for (Iterator i = cloneDevices.iterator(); i.hasNext();) {
            DeviceType device = (DeviceType)i.next();
            for (Iterator j = clone.getContainees(device).iterator();
               j.hasNext();
               ) {
               Component containee = (Component)j.next();
               clone.add(device, containee);
            }
         }

         return clone;
      }
      catch (CloneNotSupportedException e) {
         throw new Error("Object doesn't support clone - yeah right");
      }
   }

   //===========================================================================

   /**
    * Returns a string representation of this component, including the containees
    * for <em>all</em> devices.
    */
   public String toLongString() {
      final StringBuffer sb = new StringBuffer();

      // For each device, recursively write the containees
      for (Iterator i = getDeviceTypes().iterator(); i.hasNext();) {
         final DeviceType device = (DeviceType)i.next();
         sb.append("* " + device + "\n");
         sb.append(containeesToString(1, device));
      }

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of this component, with the given indent
    * level and including the containees for the given device.
    */
   public String toString(int indentLevel, final DeviceType deviceType) {
      // 1. Make sure we have a concrete device; "all" is not acceptable here.
      deviceType.verifyTypeIsNotAll();

      // 2. Recursively write the containees
      return containeesToString(indentLevel, deviceType);
   }

   //---------------------------------------------------------------------------

//   /**
//    * Returns a string representation of the items in this container (from the
//    * given device's perspective) that are in the given set, with the given
//    * indent level.
//    * 
//    * @param indentLevel the indent level to output the strings at
//    * @param deviceType the type of device whose perspective we are using to
//    * get the containees (the items that this container contains depend on
//    * which device type we are using to look at the container)
//    * @param setMembership a map that maps an item to whether it is a member
//    * of a set
//    */
//   protected String toString(
//      int indentLevel,
//      final DeviceType deviceType,
//      Map setMembership) {
//         
//      // 1. Make sure we have a concrete device; "all" is not acceptable here.
//      assert deviceType != DeviceType.ALL : "Device cannot be ALL";
//
//      // 2. Recursively write the containees
//      return containeesToString(indentLevel, deviceType, setMembership);
//   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of the items in this container (for the
    * given device), with the given indent level.
    */
   private String containeesToString(
      final int indentLevel,
      final DeviceType deviceType) {

      final StringBuffer sb = new StringBuffer();

      for (Iterator i = getContainees(deviceType).iterator(); i.hasNext();) {
         final InteractionElement e = (InteractionElement)i.next();
         sb.append(e.toLongString(indentLevel, deviceType));
         if (i.hasNext()) {
            sb.append("\n");
         }
      }

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of the items in this container (from the
    * given device's perspective) that are in the given set, with the given
    * indent level.
    * 
    * @param indentLevel the indent level to output the strings at
    * @param deviceType the type of device whose perspective we are using to
    * get the containees (the items that this container contains depend on
    * which device type we are using to look at the container)
    * @param setMembership a map that maps an item to whether it is a member
    * of a set
    */
//   private String containeesToString(
//      int indentLevel,
//      final DeviceType deviceType,
//      Map setMembership) {
//
//      final StringBuffer sb = new StringBuffer();
//
//      for (Iterator i = getContainees(deviceType).iterator(); i.hasNext();) {
//         InteractionElement e = (InteractionElement)i.next();
//         if (setMembership.get(e).equals(Boolean.TRUE)) {
//            sb.append(e.toString(indentLevel, deviceType));
//            if (i.hasNext()) {
//               sb.append("\n");
//            }
//         }
//      }
//
//      return sb.toString();
//   }

}
