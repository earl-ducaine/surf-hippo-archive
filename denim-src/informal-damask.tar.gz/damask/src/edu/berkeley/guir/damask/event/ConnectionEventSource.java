package edu.berkeley.guir.damask.event;

import java.awt.Shape;
import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.connection.*;
import edu.berkeley.guir.damask.userevent.DamaskUserEvent;

/** 
 * A source of ConnectionEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-11-2003 James Lin
 *                               Created ConnectionEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-11-2003
 */
public class ConnectionEventSource {
   
   private Vector/*<ConnectionListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified listener to receive events from the connection.
    */
   public synchronized void addConnectionListener(
      final ConnectionListener listener) {
      
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified listener so that it no longer receives
    * events from the connection.
    */
   public synchronized void removeConnectionListener(
      final ConnectionListener listener) {

      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires sourceChanged events to listeners.
    */
   public void fireSourceChanged(
      final Connection connection,
      final DeviceType deviceType,
      final ConnectionSource oldSource,
      final ConnectionSource newSource) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ConnectionEvent event =
         new ConnectionEvent(
            connection,
            ConnectionEvent.SOURCE_CHANGED,
            deviceType,
            oldSource,
            newSource);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final ConnectionListener listener = (ConnectionListener)i.next();
         listener.sourceChanged(event);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Fires destChanged events to listeners.
    */
   public void fireDestChanged(
      final Connection connection,
      final DeviceType deviceType,
      final ConnectionDest oldDest,
      final ConnectionDest newDest) {

      final Vector el;
      synchronized (this) {
         el = (Vector)eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ConnectionEvent event =
         new ConnectionEvent(
            connection,
            ConnectionEvent.DEST_CHANGED,
            deviceType,
            oldDest,
            newDest);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ConnectionListener listener = (ConnectionListener)i.next();

         listener.destChanged(event);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Fires shapeChanged events to listeners.
    */
   public void fireShapeChanged(
      final Connection connection,
      final DeviceType deviceType,
      final Shape oldShape,
      final Shape newShape) {

      final Vector el;
      synchronized (this) {
         el = (Vector)eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ConnectionEvent event =
         new ConnectionEvent(
            connection,
            ConnectionEvent.SHAPE_CHANGED,
            deviceType,
            oldShape,
            newShape);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ConnectionListener listener = (ConnectionListener)i.next();

         listener.shapeChanged(event);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Fires userEventChanged events to listeners.
    */
   public void fireUserEventChanged(
      final Connection connection,
      final DamaskUserEvent oldEvent,
      final DamaskUserEvent newEvent) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ConnectionEvent event =
         new ConnectionEvent(
            connection,
            ConnectionEvent.USER_EVENT_CHANGED,
            DeviceType.ALL,
            oldEvent,
            newEvent);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final ConnectionListener listener = (ConnectionListener)i.next();
         listener.userEventChanged(event);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Fires conditionChanged events to listeners.
    */
   public void fireConditionChanged(
      final Connection connection,
      final int oldCondition,
      final int newCondition) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ConnectionEvent event =
         new ConnectionEvent(
            connection,
            ConnectionEvent.CONDITION_CHANGED,
            DeviceType.ALL,
            new Integer(oldCondition),
            new Integer(newCondition));

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final ConnectionListener listener = (ConnectionListener)i.next();
         listener.conditionChanged(event);
      }
   }
}
