//// See bottom of file for software license
package edu.berkeley.guir.lib.collection;

import java.util.Collection;
import java.util.HashSet;

/**
 * A Map that, for each key, contains a Set of objects.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Jul 31 2002 JIH
 */
public class HashMapSet
    extends HashMapCollection {

    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Empty constructor.
     */
    public HashMapSet() {
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Copy constructor
     */
    public HashMapSet(HashMapSet m) {
        super(m);
    } // of copy constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================





    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    protected Collection getNewCollectionInstance() {
        return (new HashSet());
    } // of method

    //----------------------------------------------------------------

    protected Collection getNewCollectionInstance(Collection c) {
        return (new HashSet(c));
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================





    //==========================================================================
    //===   REGRESSION TESTS   =================================================

    public static HashMapSet getTestInstanceAAA() {
        return (new HashMapSet());
    } // of method

    //----------------------------------------------------------------

    public static HashMapSet getTestInstanceBBB() {
        HashMapSet m = new HashMapSet();

        m.put("A", "Alphabet");
        m.put("A", "Antwerp");
        m.put("A", "Aardvark");
        m.put("B", "Beach");
        m.put("B", "Bust");
        m.put("C", "Cookie");

        return (m);
    } // of method

    //==========================================================================

    /**
     * Print out a few.
     */
    private static void runTestAAA() {
        System.out.println(getTestInstanceAAA());
        System.out.println("----------");
        System.out.println(getTestInstanceBBB());
        System.out.println("----------");
    } // of method

    //----------------------------------------------------------------

    /**
     * Test simple case.
     */
    private static void runTestBBB() {
        HashMapSet m = getTestInstanceBBB();
        System.out.println(m);
        System.out.println("----------");

        System.out.println("Test 1 - add 'D', 'Dog'");
        m.put("D", "Dog");
        System.out.println(m);
        System.out.println("----------");

        System.out.println("Test 2 - remove 'A'");
        m.removeKey("A");
        System.out.println(m);
        System.out.println("----------");

        System.out.println("Test 3 - remove again (should be no effect)");
        m.removeKey("A");
        System.out.println(m);
        System.out.println("----------");

        System.out.println("Test 4 - add 'F', 'Fox'");
        m.put("F", "Fox");
        System.out.println(m);
        System.out.println("----------");

        System.out.println("Test 5 - add again");
        m.put("F", "Fox");
        System.out.println(m);
        System.out.println("----------");

        System.out.println("Test 6 - clone");
        System.out.println(new HashMapSet(m));
        System.out.println("----------");

        System.out.println("Test 7 - clear");
        m.clear();
        System.out.println(m);
        System.out.println("----------");
    } // of method

    //----------------------------------------------------------------

    /**
     * Test clone.
     */
    private static void runTestCCC() {
    } // of method

    //==========================================================================

    public static void main(String[] argv) {
        runTestAAA();
        runTestBBB();
    } // of main

    //===   REGRESSION TESTS   =================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
