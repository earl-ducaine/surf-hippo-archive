package edu.berkeley.guir.denim.components;

import edu.berkeley.guir.denim.toolbox.*;
import edu.berkeley.guir.lib.satin.objects.*;

/**
 * The definition of a text field in a DENIM design. This is a built-in
 * component.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-29-2001  Boxin Li
 *                                Created DenimIntrinsicComponent
 * </PRE>
 *
 *
 * @since   JDK 1.2
 * @version Version 1.0.0  01-29-2001
 */

public class DenimTextField extends DenimIntrinsicComponent{
	
    final static long uniqueID = 25;
    
   /**
    * Creates the DenimTextField component type.
    */
   DenimTextField() {
      super();
      name = "DenimTextField";
      stamp = new RubberStamp("text_field.gif", this);
      
      this.setUniqueID(uniqueID);
   }

   /**
    * Creates an instance of a text field.
    */
   public DenimComponentInstance newInstance() {
      DenimComponentInstance instance = new DenimTextFieldInstance(this);
      instances.add(instance);
      return instance;
   }
}

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
