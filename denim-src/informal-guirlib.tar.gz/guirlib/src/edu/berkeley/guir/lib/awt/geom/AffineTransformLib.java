//// See bottom of source code for software license
package edu.berkeley.guir.lib.awt.geom;

import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

/**
 * Miscellaneous affine transform utilities.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
final public class AffineTransformLib {

   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   private static boolean flagApproxScale = false;

   public static boolean getApproxScale() {
       return (flagApproxScale);
   } // of method

   /**
    * Get a fast and best-guess at scale factors (true), or get 
    * the right answer (false)? By default is right answer (false).
    * 
    * @see #getScaleFactor(AffineTransform)
    */
   public static void setApproxScale(boolean flag) {
       flagApproxScale = flag;
   } // of method

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * No instances allowed.
    */
   private AffineTransformLib() {
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   MISC UTILITIES   ====================================================

   /**
    * Scale, using the specified point as the new center (absolute coords)
    * after scaling.
    *
    * @param scale is the scale factor to zoom in to.
    * @param x     is where we want to be centered (absolute coords).
    * @param y     is where we want to be centered (absolute coords).
    * @param rect  is the bounding box of whatever we are zooming, so we
    *              know where to center at. For SATIN GraphicalObjects,
    *              use getBounds2D(COORD_ABS).
    */
   public static AffineTransform scaleAndCenterAt(double scale, double x, 
                                                  double y, Rectangle2D rect) {

      AffineTransform tx;

      //// These are numbered backwards since you concatenate backwards
      //// with transforms.

      //// 3. Center at (x,y).
      tx = AffineTransform.getTranslateInstance(rect.getWidth()  / 2.0,
                                                rect.getHeight() / 2.0);
      //// 2. Scale.
      tx.concatenate(AffineTransform.getScaleInstance(scale, scale));

      //// 1. Move the origin to the specified point.
      tx.concatenate(AffineTransform.getTranslateInstance(-x, -y));

      return (tx);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Scale, keeping the specified point constant (ie same absolute
    * coordinates) before and after scaling.
    */
   public static AffineTransform scaleAndKeepConstant(double scale, 
                                                      double x, double y) {

      AffineTransform tx;

      //// These are numbered backwards since you concatenate backwards
      //// with transforms.

      //// 3. Move back to where we were.
      tx = AffineTransform.getTranslateInstance(x, y);

      //// 2. Scale.
      tx.concatenate(AffineTransform.getScaleInstance(scale, scale));

      //// 1. Move the origin to the specified point.
      tx.concatenate(AffineTransform.getTranslateInstance(-x, -y));

      return (tx);
   } // of method

   //-----------------------------------------------------------------

   /**
    * @param txStart     is our starting transform, usually identity.
    * @param txFinish    is our goal transform.
    * @param intrp       is a function that can interpolate values for us.
    * @param numFrames   is the number of intermediate steps.
    */
   public static AffineTransform[] interpolate(AffineTransform txStart, 
         AffineTransform txFinish, Interpolation intrp, int numFrames) {

      AffineTransform[] txArray      = new AffineTransform[numFrames];
      double[]          startMatrix  = new double[6];
      double[]          finishMatrix = new double[6];
      double[]          tmpMatrix    = new double[6];

      //// 1. Initialize the first matrix to be the start matrix with diffs.
      txStart.getMatrix(startMatrix);
      txFinish.getMatrix(finishMatrix);

      for (int i = 0; i < numFrames; i++) {
         tmpMatrix[0] = 
               intrp.interpolate(startMatrix[0], finishMatrix[0], i, numFrames);
         tmpMatrix[1] = 
               intrp.interpolate(startMatrix[1], finishMatrix[1], i, numFrames);
         tmpMatrix[2] = 
               intrp.interpolate(startMatrix[2], finishMatrix[2], i, numFrames);
         tmpMatrix[3] = 
               intrp.interpolate(startMatrix[3], finishMatrix[3], i, numFrames);
         tmpMatrix[4] = 
               intrp.interpolate(startMatrix[4], finishMatrix[4], i, numFrames);
         tmpMatrix[5] = 
               intrp.interpolate(startMatrix[5], finishMatrix[5], i, numFrames);
         txArray[i]   = new AffineTransform(tmpMatrix);
      }

/*
      //// 2. Next, make sure the scale is always correct.
      double          idealScale;
      double          curScale;
      double          startScale  = getScaleFactor(txStart);
      double          finishScale = getScaleFactor(txFinish);
      AffineTransform txScale;

      for (int i = 0; i < numFrames; i++) {
         curScale   = getScaleFactor(txArray[i]);
         idealScale = intrp.interpolate(startScale, finishScale, i, numFrames);
         txScale    = scaleAndKeepConstant(idealScale / curScale, 
                      txArray[i].getTranslateX(), txArray[i].getTranslateY());
         txArray[i].concatenate(txScale);
      }
*/

      //// 3. Now we have the absolute interpolation values. However,
      ////    we have to use setTransform() all the time if we use them.
      ////    Instead, we'll calculate relative interpolation values. That is,
      ////    each transform will also undo the previous one, so we can just
      ////    call applyTransform() on each one in order.
      ////
      ////    For example, we want to transform from the left column to right:
      ////       tx0         -->     tx0 txStart.inverse   = ntx0
      ////       tx1         -->     tx1 ntx0.inverse      = ntx1
      ////       tx2         -->     tx2 ntx1.inverse      = ntx2
      ////       tx3         -->     tx3 ntx2.inverse      = ntx3
      try {
         for (int i = numFrames - 1; i >= 1 ; i--) {
            txArray[i].concatenate(txArray[i-1].createInverse());
         }
      }
      catch (Exception e) {
         System.err.println(e);
      }

      //// 5. All right, we're done. Return.
      return (txArray);
   } // of method

   //-----------------------------------------------------------------

   public static AffineTransform[] animateLinearly(AffineTransform txFinish, 
                                                   int numFrames) {
      return (interpolate(new AffineTransform(), txFinish, 
                          new LinearInterpolation(), numFrames));
   } // of method

   //-----------------------------------------------------------------

   public static AffineTransform[] 
   animateSlowInSlowOut(AffineTransform txFinish, int numFrames) {

      return (interpolate(new AffineTransform(), txFinish, 
                          new SlowInSlowOutInterpolation(), numFrames));
   } // of method

   //===   MISC UTILITIES   ====================================================
   //===========================================================================



   //===========================================================================
   //===   TRANSFORM UTILITY METHODS   =========================================

   /**
    * Calculate the AffineTransform that transforms oldRect into newRect.
    *
    * @param  oldRect is the starting Rectangle.
    * @param  newRect is the ending Rectangle.
    * @return the AffineTransform that transforms oldRect into newRect.
    */
   public static AffineTransform resize(Rectangle2D oldRect, 
                                        Rectangle2D newRect) {

      double scaleX = newRect.getWidth() / oldRect.getWidth();
      double scaleY = newRect.getHeight() / oldRect.getHeight();

      AffineTransform txScale;
      AffineTransform txTranslate;
      Rectangle2D     tmpRect;
      
      txScale = AffineTransform.getScaleInstance(scaleX, scaleY);
      tmpRect = GeomLib.transformRectangle(txScale, oldRect);

      txTranslate = AffineTransform.getTranslateInstance(
                       newRect.getX() - tmpRect.getX(),
                       newRect.getY() - tmpRect.getY());

      txTranslate.concatenate(txScale);
      return (txTranslate);
   } // of method

   //-----------------------------------------------------------------


   //-----------------------------------------------------------------

   /**
    * Given a transform, figure out its scaling factor. Works for all cases.
    *
    * @param  tx is the AffineTransform whose scale factor we want.
    * @return the scale factor.
    */
   public final static double getScaleFactor(AffineTransform tx) {
       if (flagApproxScale == true) {
           return (tx.getScaleX());
       }
       else {
           //// 1. Create a line from (0,0) to (0,1).
           Point2D ptAA = new Point2D.Float(0.0f, 0.0f);
           Point2D ptBB = new Point2D.Float(0.0f, 1.0f);

           //// 2. Transform and calculate the distance.
           tx.transform(ptAA, ptAA);
           tx.transform(ptBB, ptBB);

           double x1 = ptAA.getX();
           double y1 = ptAA.getY();
           double x2 = ptBB.getX();
           double y2 = ptBB.getY();

           //// 3. Return the distance between the points.
           return (Math.sqrt((x1-x2)*(x1-x2) + (y2-y1)*(y2-y1)));
       }
   } // of method

   //-----------------------------------------------------------------

   public final static Point2D getTranslateFactor(AffineTransform tx) {
      //// 1. See what the translation is from (0,0) to transformed point.
      Point2D ptAA = new Point2D.Float();
      ptAA.setLocation(0.0, 0.0);

      //// 2. Transform and calculate the distance.
      tx.transform(ptAA, ptAA);
      return (ptAA);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Given a transform, figure out its rotation factor. Only works if the
    * transform does not include any shears. Unfortunately, there doesn't seem
    * to be a SHEAR bit in the AffineTransform, and I don't know if there's an
    * easy way to detect shears. That's what I get for not having taken an
    * advanced graphics course. My advice to anyone reading this is to take the
    * plunge and take an advanced graphics course.
    *
    * @param  tx is the AffineTransform whose rotation factor we want.
    * @return the rotation factor. If it screws up, returns 0.
    */
   public final static double getRotationFactor(AffineTransform tx) {
      //// 0. Get the matrix values.
      double[] matrix = new double[6];
      tx.getMatrix(matrix);

      //// 1.1. Scale down to zoom of 1.
      double scale = getScaleFactor(tx);
      matrix[0] /= scale;
      matrix[1] /= scale;

      //// 1.2. Round off to near 1 if necessary. Common precision error.
      if (matrix[0] > 1) {
         matrix[0] = 1;
      }
      if (matrix[0] < -1) {
         matrix[0] = -1;
      }

      if (matrix[1] > 1) {
         matrix[1] = 1;
      }
      if (matrix[1] < -1) {
         matrix[1] = -1;
      }

      //// 2. Reverse calculate the values.
      ////    tx[0]=cosx  tx[2]=-sinx  tx[4]
      ////    tx[1]=sinx  tx[3]= cosx  tx[5]
      double theta_x1 = Math.acos(matrix[0]);
      double theta_x2 = 2*Math.PI - theta_x1;
      double theta_y1 = Math.asin(matrix[1]);
      double theta_y2 = Math.PI - theta_y1;

      //// 3. Make sure all of the theta_y values are positive.
      if (theta_y1 < 0) {
         theta_y1 += 2*Math.PI;
      }
      if (theta_y2 < 0) {
         theta_y2 += 2*Math.PI;
      }

      //// 4. Check all pairs.
      if (nearEquals(theta_x1, theta_y1) || nearEquals(theta_x1, theta_y2)) {
         return (theta_x1);
      }
      if (nearEquals(theta_x2, theta_y1) || nearEquals(theta_x2, theta_y2)) {
         return (theta_x2);
      }


      // System.out.println(matrix[0] + " " + matrix[2] + " " + matrix[4]);
      // System.out.println(matrix[1] + " " + matrix[3] + " " + matrix[5]);
      // System.out.println("   " + theta_x1);
      // System.out.println("   " + theta_x2);
      // System.out.println("   " + theta_y1);
      // System.out.println("   " + theta_y2);
      // System.out.println();

      return (0);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Can't trust those wascally floating point numbers...
    */
   private static final boolean nearEquals(double aa, double bb) {
      return (Math.abs(aa - bb) < 0.0001);
   } // of method

   //===   TRANSFORM UTILITY METHODS   =========================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) throws Exception {

      Rectangle       r1;
      Rectangle       r2;
      AffineTransform tx;

      r1 = new Rectangle(0, 0, 5, 7);
      r2 = new Rectangle(-3, -4, 12, 7);
      tx = resize(r1, r2);
      System.out.println(r1);
      System.out.println(r2);
      System.out.println(tx);
      System.out.println(GeomLib.transformRectangle(tx, r1));

      System.out.println();
      r1 = new Rectangle(9, 120, 534, 237);
      r2 = new Rectangle(-36, -24, 132, 673);
      tx = resize(r1, r2);
      System.out.println(r1);
      System.out.println(r2);
      System.out.println(tx);
      System.out.println(GeomLib.transformRectangle(tx, r1));

/*
      AffineTransform tx;

      tx = AffineTransform.getRotateInstance(1);
      System.out.println(getRotationFactor(tx));

      tx = AffineTransform.getRotateInstance(2);
      System.out.println(getRotationFactor(tx));

      tx = AffineTransform.getRotateInstance(3);
      System.out.println(getRotationFactor(tx));

      tx = AffineTransform.getRotateInstance(4);
      System.out.println(getRotationFactor(tx));

      tx = AffineTransform.getRotateInstance(5);
      System.out.println(getRotationFactor(tx));

      tx = AffineTransform.getRotateInstance(6);
      System.out.println(getRotationFactor(tx));

      System.out.println("-----");

      tx.concatenate(AffineTransform.getScaleInstance(2, 2));
      System.out.println(getRotationFactor(tx));

      tx.concatenate(AffineTransform.getScaleInstance(3, 3));
      System.out.println(getRotationFactor(tx));

      tx.concatenate(AffineTransform.getTranslateInstance(20, 20));
      System.out.println(getRotationFactor(tx));

      System.out.println("-----");

      tx = AffineTransform.getRotateInstance(1, 10, 10);
      System.out.println(getRotationFactor(tx));

      tx = AffineTransform.getRotateInstance(2, 10, 10);
      System.out.println(getRotationFactor(tx));

      tx = AffineTransform.getRotateInstance(3, 10, 10);
      System.out.println(getRotationFactor(tx));

      tx = AffineTransform.getRotateInstance(4, 10, 10);
      System.out.println(getRotationFactor(tx));

      tx = AffineTransform.getRotateInstance(5, 10, 10);
      System.out.println(getRotationFactor(tx));

      tx = AffineTransform.getRotateInstance(6, 10, 10);
      System.out.println(getRotationFactor(tx));
*/
   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
