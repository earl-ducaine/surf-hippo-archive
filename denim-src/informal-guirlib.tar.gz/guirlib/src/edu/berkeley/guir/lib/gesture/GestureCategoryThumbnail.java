package edu.berkeley.guir.lib.gesture;

import java.awt.*;
import java.util.Observable;
import java.util.Observer;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.*;

/**
 * Condenses a GestureCategory down to a small (thumbnail) display.
 * For now, just chooses the first Gesture from the Category and displays
 * that.
 * Emits a ChangeEvent if the archtype Gesture changes.
 */
public class GestureCategoryThumbnail extends JPanel
implements Observer
{
  protected EventListenerList changeListenerList = new EventListenerList();
  protected ChangeEvent changeEvent = null;
  GestureCategory gestureCategory;
  GestureCategoryFrame gestureCategoryFrame;
  GestureDisplay thumbnail;
  boolean experimentMode = false;
  boolean authorVisible = false;

  public GestureCategoryThumbnail()
  {
    super();
    thumbnail = new GestureDisplay();
    thumbnail.setOffset(10, 10);
    thumbnail.setShowSelected(false);
    setLayout(new BorderLayout());
    setBackground(Color.white);
    add(thumbnail, BorderLayout.CENTER);
  }
  
  public GestureCategoryThumbnail(GestureCategory gc)
  {
    this(gc, false, false);
  }

  public GestureCategoryThumbnail(GestureCategory gc,
				  JScrollPane scrollPane)
  {
    this(gc);
  }
  
  public GestureCategoryThumbnail(GestureCategory gc, boolean experimenting,
				  boolean authorVisible)
  {
    this();
    this.authorVisible = authorVisible;
    thumbnail.setAuthorVisible(authorVisible);
    experimentMode = experimenting;
    setGestureCategory(gc);
  }

  public void setGestureCategory(GestureCategory gc)
  {
    if (gestureCategory != null) {
      gestureCategory.deleteObserver(this);
    }
    gestureCategory = gc;
    if (gestureCategoryFrame != null) {
      gestureCategoryFrame.setGestureCategory(gc);
    }
    if (gc != null) {
      gc.addObserver(this);
    }
    rebuildUI();
  }

  public GestureCategory getGestureCategory()
  {
    return gestureCategory;
  }

  private void rebuildUI()
  {
    String name = gestureCategory.getName();
    if (name == null)
      name = "(unnamed)";
    thumbnail.
      setBorder(BorderFactory.
		createTitledBorder(BorderFactory.createEtchedBorder(),
				   name,
				   TitledBorder.CENTER,
				   TitledBorder.ABOVE_TOP));

    Gesture gesture;
    if (gestureCategory.size() > 0) {
      gesture = gestureCategory.gestureAt(0);
    }
    else {
      gesture = null;
    }
    thumbnail.setGesture(gesture);
    // I'm not sure how much of the following is necessary, but it
    // works and I don't want to take the time to experiment to
    // see what's needed and what isn't
    thumbnail.invalidate();
    thumbnail.setSize(thumbnail.getMinimumSize());
    invalidate();
    Window w = (Window) getTopLevelAncestor();
    if (w != null) {
      w.pack();
    }
    fireStateChange();
  }

  public void paint(Graphics g)
  {
    super.paint(g);
    if (thumbnail.getSelected()) {
      Dimension size = getSize();
      /*
      System.err.println("GCT: mysize = " + size);
      System.err.println("GCT: gesture size = " + thumbnail.getSize());
      */
      g.setColor(Color.red);
      g.drawRect(0, 0, size.width-1, size.height-1);
    }
  }
  
  public void update(Observable gestureCategory, Object arg)
  {
    Gesture gesture = thumbnail.getGesture();

    if ((gesture == null) || (arg == null) ||
	(arg instanceof String) || (arg instanceof GestureCategory))
      rebuildUI();
  }

  public boolean toggleSelected()
  {
    boolean result = thumbnail.toggleSelected();
    repaint();
    return result;
  }

  public void setSelected(boolean value)
  {
    if (value != thumbnail.getSelected())
      repaint();
    thumbnail.setSelected(value);
  }

  /**
   * Create (if necessary) and show the frame corresponding to the
   * category this widget displays.
   */
  public GestureCategoryFrame showCategoryFrame()
  {
    createCategoryFrame();
    gestureCategoryFrame.show();
    return gestureCategoryFrame;
  }

  public GestureCategoryFrame createCategoryFrame()
  {
    if (gestureCategoryFrame == null) {
      gestureCategoryFrame = new GestureCategoryFrame(gestureCategory,
						      experimentMode,
						      authorVisible);
      gestureCategoryFrame.pack();
    }
    return gestureCategoryFrame;
  }

  public GestureCategoryFrame getCategoryFrame()
  {
    return gestureCategoryFrame;
  }

  /**
   * Adds a ChangeListener
   */
  public void addChangeListener(ChangeListener l) {
    changeListenerList.add(ChangeListener.class, l);
  }
  
  /**
   * Removes a ChangeListener
   */
  public void removeChangeListener(ChangeListener l) {
    changeListenerList.remove(ChangeListener.class, l);
  }

  protected void fireStateChange()
  {
    Object[] listeners = changeListenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ChangeListener.class) {
	if (changeEvent == null)
	  changeEvent = new ChangeEvent(this);
	((ChangeListener)listeners[i+1]).stateChanged(changeEvent);
      }
    }
  }

  public void setAuthorVisible(boolean on)
  {
    if (on != authorVisible) {
      authorVisible = on;
      thumbnail.setAuthorVisible(on);
    }
  }
}
