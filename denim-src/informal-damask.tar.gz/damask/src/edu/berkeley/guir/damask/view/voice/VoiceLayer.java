package edu.berkeley.guir.damask.view.voice;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.Trigger;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.connection.ConnectionSource;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.pattern.PatternInstanceView;
import edu.berkeley.guir.damask.view.voice.component.VoiceComponent;
import edu.berkeley.guir.damask.view.voice.component.VoiceTrigger;
import edu.berkeley.guir.damask.view.voice.dialog.Form;
import edu.umd.cs.piccolo.*;

/** 
 * Listens to the model and modifies the scenegraph appropriately. There is
 * one layer per device type.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-14-2004 James Lin
 *                               Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 */
public class VoiceLayer extends DamaskLayer {
   public static final int OTHER_LAYER_ALPHA = 100;
   private static final boolean ENABLED = true;

   // Initialized in initBeforeAddingViews()
   private List/*<Form>*/ forms;
   private List/*<Form>*/ homeForms;

   /**
    * Constructs a new layer that displays a view of the specified document
    * for the specified device type.
    *  
    * @param doc         the document to display
    * @param deviceType  the device type from which perspective to display
    *                     the document
    */
   public VoiceLayer(final DamaskDocument doc, final DeviceType deviceType) {
      this(doc, deviceType, 1.0);
   }

   
   /**
    * Constructs a new layer that displays a view of the specified document
    * for the specified device type.
    * 
    * @param doc             the document to display
    * @param deviceType      the device type from which perspective to display
    *                         the document
    * @param pageTitleScale  the scale at which page titles should be drawn 
    */
   public VoiceLayer(final DamaskDocument doc, final DeviceType deviceType,
         final double pageTitleScale) {
      super(doc, deviceType, pageTitleScale);

      // Listen for cameras being added to or removed from this layer.
      addPropertyChangeListener(PLayer.PROPERTY_CAMERAS, new CamerasHandler());
   }

   
   /**
    * Called before views of elements in the graph are created and added
    * in the constructor.
    */
   protected void initBeforeAddingViews() {
      forms = new ArrayList/*<Form>*/();
      homeForms = new ArrayList/*<PageView>*/();
   }

   
   /**
    * Returns the forms in this layer, including those within the
    * template pane.
    */
   private List/*<Form>*/ getFormsIncludingTemplates() {
      final List/*<Form>*/ allForms = new ArrayList/*<Form>*/();
      allForms.addAll(forms);
      allForms.addAll(getTemplatePane().getViewsOfTemplateDialogs());
      return Collections.unmodifiableList(allForms);
   }


   // @Override
   protected void addViewForElement(final InteractionElement element) {
      if (!ENABLED) {
         return;
      }
      
      final DeviceType deviceType = getDeviceType();
      final TemplatePane templatePane = getTemplatePane();
      if (element instanceof Dialog) {
         final Dialog d = (Dialog)element;
         
         if (!(d instanceof TemplateDialog)) {
            if (d.isEnabled(deviceType)) {

               final Form form = new Form(d);
               views.put(d, form);

               // Add the dialog in such a way that the template pane is always
               // on top
               addChild(indexOfChild(templatePane), form);
               forms.add(form);
            
               form.setContentsSelectable(true);
               trackAddition(form);
            }
         }
      }
      else if (element instanceof Connection) {
         final Connection c = (Connection)element;

         if (c.isVisibleToDeviceType(deviceType)) {
            // We will only handle connections that originate from Triggers.
            final ConnectionSource source = c.getConnectionSource(deviceType);
            if (source instanceof Trigger) {

               // Find the view of the source of the connection.
               final VoiceTrigger voiceTrigger = (VoiceTrigger)getView(source);

               // If the view is null, then it is not visible in this layer,
               // so ignore it. Otherwise...
               if (voiceTrigger != null) {
                  // Set the destination of the response to the destination of the
                  // connection.
                  voiceTrigger.getResponse(
                        voiceTrigger.getForm().getDesignTimeCondition()).
                  setDest(
                     (ResponseDest)getView(c.getConnectionDest(deviceType)));
               }
            }
         }
      }
      else if (element instanceof PatternInstance) {
         final PatternInstance pi = (PatternInstance)element;
         if (pi.isVisibleToDeviceType(deviceType)) {
            final PatternInstanceView piView = new PatternInstanceView(pi);
            addChild(indexOfChild(templatePane), piView);
            views.put(pi, piView);
            trackAddition(piView);
         }
      }
      else {
         assert false : "element added to graph must be dialog, connection, or pattern instance";
      }
   }


   // @Override
   protected void removeViewForElement(InteractionElement element) {
      if (!ENABLED) {
         return;
      }
      
      final DeviceType deviceType = getDeviceType();
      if (element instanceof Dialog) {
         final Dialog d = (Dialog)element;
         if (!(d instanceof TemplateDialog)) {
            if (d.isEnabled(deviceType)) {
               final Form form = (Form)views.get(d);
   
               form.setContentsSelectable(false);
   
               removeChild(form);
               forms.remove(form);
   
               // Make sure any pages that are in the dialog just deleted are not
               // selected in any canvas.
               for (Iterator i = getCamerasReference().iterator(); i.hasNext(); ) {
                  final PCamera camera = (PCamera)i.next();
                  final PComponent component = camera.getComponent();
                  if (component instanceof VoiceCanvas) {
                     final VoiceCanvas canvas = (VoiceCanvas)component;
                     final Form oldSelectedForm = canvas.getSelectedForm();
                     if (oldSelectedForm == form) {
                        canvas.attachHandles(null, camera);
                     }
                  }
               }
               form.dispose();
            }
         }
      }
      else if (element instanceof Connection) {
      }
      else if (element instanceof PatternInstance) {
         final PatternInstance pi = (PatternInstance)element;

         if (pi.isVisibleToDeviceType(deviceType)) {
            final PatternInstanceView piView = (PatternInstanceView)views.get(pi);
            piView.dispose();
            removeChild(piView);
         }
      }
      else {
         assert false : "element added to graph must be dialog, connection, or pattern instance";
      }
   }


   public void adjustComponentByDeviceTypeLayer(final VoiceComponent component) {
   }

   
   /**
    * Places the home icon on the home page.
    */
   // @Override
   public void updateHomePage() {
      final InteractionGraph graph = getDocument().getGraph();
      final DeviceType deviceType = getDeviceType();
      for (Iterator i = homeForms.iterator(); i.hasNext(); ) {
         final PNode homeForm = (PNode)i.next();
         if (homeForm instanceof Form) {
            ((Form)homeForm).setHome(false); 
         }
      }
      
      final Page homePage = graph.getHomePage(deviceType);
      final Dialog homeDialog =
         homePage == null ? null : homePage.getDialog();
      homeForms.clear();
      homeForms = getViews(homeDialog);
      
      for (Iterator i = homeForms.iterator(); i.hasNext(); ) {
         final PNode homeForm = (PNode)i.next();
         if (homeForm instanceof Form) {
            ((Form)homeForm).setHome(true); 
         }
      }
   }



   /**
    * Sets the current device-type layer of this layer. This determines
    * whether elements added to this layer is intended for all device types
    * or only the device type of this layer. 
    */
   protected void internalSetDeviceTypeLayer(final DeviceTypeLayer deviceTypeLayer) {
      super.internalSetDeviceTypeLayer(deviceTypeLayer);
      
      // Make all of the content in the other layer faded out
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode node = (PNode)i.next();
         if (node instanceof Form) {
            ((Form)node).deviceTypeLayerChanged();
         }
      }
      
      for (Iterator i = getTemplatePane().getViewsOfTemplateDialogs().iterator(); i.hasNext();) {
         final InteractionElementView node = (InteractionElementView)i.next();
         if (node instanceof Form) {
            ((Form)node).deviceTypeLayerChanged();
         }
      }
   }
   
   //------------------------------------------------------------------------

   /**
    * Listens to changes to the layer's list of cameras. 
    */
   private class CamerasHandler implements PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent evt) {
         for (Iterator i = getFormsIncludingTemplates().iterator();
            i.hasNext();
            ) {
            final Form form = (Form)i.next();
            form.setContentsSelectable(true);
         }
      }
   }
}
