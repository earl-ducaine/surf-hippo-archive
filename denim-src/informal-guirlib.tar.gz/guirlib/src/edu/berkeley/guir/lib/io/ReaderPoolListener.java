//// See bottom of file for software license
package edu.berkeley.guir.lib.io;

import java.io.PrintWriter;
import java.io.Reader;

/**
 * A callback specifying that a Reader is ready with data.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Aug 11 2002, JH
 */
public interface ReaderPoolListener {

    //==========================================================================
    //===   INNER CLASS   ======================================================

    /**
     * Reads in as much data as possible and prints to screen.
     */
    static class Console implements ReaderPoolListener {
        char[]      chArr     = new char[2048];
        int         charsRead = 0;
        PrintWriter pwtr      = new PrintWriter(System.out);

        /**
         * Synchronized because might be called again before completion.
         */
        public synchronized void onData(Reader rdr) {
            try {
                while (rdr.ready() == true) {
                    charsRead = rdr.read(chArr);
                    pwtr.write(chArr, 0, charsRead);
                    pwtr.flush();
                }
            }
            catch (Exception e) {
                e.printStackTrace(System.err);
            }
        } // of method
    } // of inner class

    //===   INNER CLASS   ======================================================
    //==========================================================================






    //==========================================================================
    //===   CONSTANTS   ========================================================

    public static final ReaderPoolListener CONSOLE = new Console();

    //===   CONSTANTS   ========================================================
    //==========================================================================






    //==========================================================================
    //===   LISTENER METHODS   =================================================

    /**
     * Called when a Reader has data to be read.
     * <P>
     * May need to be synchronized if shared with multiple threads or if it
     * contains an operation that might take a while (ie this method might 
     * be called again before it has completed). So be sure to check that the
     * Reader actually has data via <CODE>rdr.ready()</CODE> before actually
     * doing anything.
     */
    public void onData(Reader rdr);

    //===   LISTENER METHODS   =================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2002 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
