package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.Properties;
import edu.berkeley.guir.lib.gesture.util.Misc;
import javax.swing.text.BadLocationException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.SwingUtilities;
import java.util.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

/** In an attempt to keep MainFrame to a managable size, this part has
    been broken out */
public class NoticeHandler {
  public static final String NOTICE_LIST_PROP = "notice list";
  public static final String NOTICE_DESCENDENTS_PROP = "notice descendents";
  //private static final String NOTICE_ICON_FILENAME = "images/graphics-repository/toolbarButtonGraphics/general/Stop16.gif";
  private static final String NOTICE_ICON_FILENAME = "images/warning.png";
  public static final Icon NOTICE_ICON = new
    ImageIcon(DefaultNotice.class.getResource(NOTICE_ICON_FILENAME));
  static {
    Properties.setPropertyPersistence(NOTICE_LIST_PROP, false);
    Properties.setPropertyPersistence(NOTICE_DESCENDENTS_PROP, false);
  }
  protected GesturePackage gesturePackage;
  protected SummaryLog summaryLog;
  protected PropertyChangeListener propChangeListener =
    new MyPropChangeListener();
    
  public NoticeHandler(SummaryLog log)
  {
    summaryLog = log;
  }

  /** safe to call from any thread */
  public void showNotice(final Notice notice)
  {
    if (SwingUtilities.isEventDispatchThread()) {
      showNoticeImpl(notice);
    }
    else {
      SwingUtilities.invokeLater(new Runnable() {
	public void run() {
	  showNoticeImpl(notice);
	}
      });
    }
  }

  protected void showNoticeImpl(Notice notice)
  {
    int originalLength = summaryLog.length();
    notice.displaySummary(summaryLog);
    /*
    System.out.println("Position of " + notice.getName() + " =\t" +
		       originalLength);
    */
    try {
      notice.setPosition(summaryLog.getDocument().
			 createPosition(originalLength));
    }
    catch (BadLocationException e) {
      System.err.println
	("WARNING: bogus exception (this should never happen): " + e);
    }
  }

  public void registerGesturePackage(GesturePackage pkg)
  {
    if (gesturePackage != null) {
      unregisterGesturePackage();
    }
    gesturePackage = pkg;
    gesturePackage.addPropertyChangeListener(propChangeListener);
  }

  public void unregisterGesturePackage()
  {
    if (gesturePackage != null) {
      gesturePackage.removePropertyChangeListener(propChangeListener);
    }
  }

  /** Add the notice to the notice lists of all Gesture Objects to
      which it applies. */
  public static void addNotice(Notice notice)
  {
    List gestureObjects = notice.getObjectList();
    for (Iterator iter = gestureObjects.iterator(); iter.hasNext();) {
      GestureObject gestureObj = (GestureObject) iter.next();
      addNotice(gestureObj, notice);
    }
  }

  public static void addNotices(Collection notices)
  {
    for (Iterator iter = notices.iterator(); iter.hasNext();) {
      Notice notice = (Notice) iter.next();
      addNotice(notice);
    }
  }
  
  public static void addNotice(GestureObject gestureObj, Notice notice)
  {
    List noticeList = (List) gestureObj.getProperty(NOTICE_LIST_PROP);
    if (noticeList == null) {
      noticeList = new ArrayList();
    }
    noticeList.add(notice);
    gestureObj.setProperty(NOTICE_LIST_PROP, noticeList);
  }

  /** Remove the notice from all its applicable Gesture Objects. */
  public static void removeNotice(Notice notice)
  {
    List gestureObjects = notice.getObjectList();
    for (Iterator iter = gestureObjects.iterator(); iter.hasNext();) {
      GestureObject gestureObj = (GestureObject) iter.next();
      removeNotice(gestureObj, notice);
    }
  }
  
  public static void removeNotice(GestureObject gestureObj, Notice notice)
  {
    List noticeList = (List) gestureObj.getProperty(NOTICE_LIST_PROP);
    // if this is being called, noticeList should not be null, but
    // just to be paranoid...
    if (noticeList != null) {
      noticeList.remove(notice);
      gestureObj.setProperty(NOTICE_LIST_PROP, noticeList);
    }
  }

  /** return set of all notices in gestureObj and its descendents */
  public static Set getNotices(GestureObject gestureObj)
  {
    List noticeList = (List) gestureObj.getProperty(NOTICE_LIST_PROP);
    Set result = (noticeList != null) ? new HashSet(noticeList) :
      new HashSet();
    List noticeDescendents = getNoticeDescendents(gestureObj);
    if (noticeDescendents != null) {
      for (Iterator iter = noticeDescendents.iterator(); iter.hasNext();) {
	GestureObject obj = (GestureObject) iter.next();
	result.addAll((List) obj.getProperty(NOTICE_LIST_PROP));
      }
    }
    return result;
  }

  /** Return a map of notices for gestureObj and its descendents,
      where the key is the notice class and the value is the set of
      all notices of that class. */
  public static Map getNoticeSummary(GestureObject gestureObj)
  {
    List noticeList = (List) gestureObj.getProperty(NOTICE_LIST_PROP);
    /*
    System.out.println("gNS: " + gestureObj + "\t# of notices: " +
		       ((noticeList == null) ? "null" :
			("" + noticeList.size())));
    */
    Map result = new HashMap();
    addNoticesToSummary(result, noticeList);
    List noticeDescendents = getNoticeDescendents(gestureObj);
    if (noticeDescendents != null) {
      for (Iterator iter = noticeDescendents.iterator(); iter.hasNext();) {
	GestureObject obj = (GestureObject) iter.next();
	List nList = (List) obj.getProperty(NOTICE_LIST_PROP);
	//System.out.println("gNS: " + obj + "# of notices: " + nList.size());
	addNoticesToSummary(result, nList);
      }
    }
    return result;
  }

  protected static void addNoticesToSummary(Map map, Collection noticeList)
  {
    if (noticeList != null) {
      //System.out.println("aNTS: # of notices: " + noticeList.size());
      for (Iterator iter = noticeList.iterator(); iter.hasNext();) {
	Notice notice = (Notice) iter.next();
	addNoticeToSummary(map, notice);
      }
      //System.out.println("aNTS: # of map keys: " + map.keySet().size());
    }
  }

  protected static void addNoticeToSummary(Map map, Notice notice)
  {
    Class noticeClass = notice.getClass();
    Set noticeSet;
    if (map.containsKey(noticeClass)) {
      noticeSet = (Set) map.get(noticeClass);
    }
    else {
      noticeSet = new HashSet();
    }
    noticeSet.add(notice);
    map.put(noticeClass, noticeSet);
  }
  
  /** return true if the GestureObject has one or more Notices */
  public static boolean hasNotices(GestureObject gestureObj)
  {
    return Properties.hasNonEmptyCollection(gestureObj, NOTICE_LIST_PROP);
  }

  /** return true if the GestureObject has one or more Notices, or if
      any of its descendents do */
  public static boolean hasNoticesInTree(GestureObject gestureObj)
  {
    return hasNotices(gestureObj) ||
      ((gestureObj instanceof GestureContainer) &&
       Properties.
       hasNonEmptyCollection(gestureObj, NOTICE_DESCENDENTS_PROP));
    // don't really have to check if it's a GestureContainer, but it's
    // probably more efficient to
  }

  public static Set getNoticesOfClass(GestureObject gestureObj,
				      Class noticeClass)
  {
    if (!Notice.class.isAssignableFrom(noticeClass)) {
      throw new IllegalArgumentException("noticeClass must be a Notice");
    }
    Map noticeSummary = getNoticeSummary(gestureObj);
    Set result;
    if (noticeSummary.containsKey(noticeClass)) {
      result = (Set) noticeSummary.get(noticeClass);
    }
    else {
      result = new HashSet();
    }
    return result;
  }
  
  /** return the value of NOTICE_DESCENDENTS_PROP */
  public static List getNoticeDescendents(GestureObject gestureObj)
  {
    return gestureObj.hasProperty(NOTICE_DESCENDENTS_PROP) ?
      (List) gestureObj.getProperty(NOTICE_DESCENDENTS_PROP) : null;
  }
  
  /** Monitor a GesturePackage for changes that involve or affect
      Notices.  There are 4 cases:

      1. A container gets a new child.  Child has its own notice child
         list.  Add all entries on that list to lists of container and
         its ancestors.
      
      2. A gesture object gets its first notice.  Put it on the notice
         child list of all ancestors.
      
      3. A container loses a child.  Child has its own notice child
         list. Remove all entries on that list from lists of container
         and its ancestors.
      
      4. A gesture object loses its last notice. Remove it from the
         notice child list of all its ancestors.
  */
  protected static class MyPropChangeListener
    implements PropertyChangeListener {
    public void propertyChange(PropertyChangeEvent e)
    {
      PropertyChangeEvent originalEvent = Properties.getRootEvent(e);
      String name = originalEvent.getPropertyName();
      Object oldValue = originalEvent.getOldValue();
      Object newValue = originalEvent.getNewValue();
      if (name == NOTICE_LIST_PROP) {
	/*
	System.out.println("notice list changed for " +
			   originalEvent.getSource());
	*/
	List oldList = (List) oldValue;
	List newList = (List) newValue;
	int oldSize = (oldList == null) ? 0 : oldList.size();
	int newSize = (newList == null) ? 0 : newList.size();
	if ((oldSize > 0) && (newSize == 0)) {
	  // last one was removed
	  removeNoticeObjFromAncestors(e, (GestureObject)
				       originalEvent.getSource());
	}
	else if ((newSize > 0) && (oldSize == 0)) {
	  // first one was added
	  addNoticeObjToAncestors((GestureObject)
				  originalEvent.getSource());
	}
      }
      else if (name == GestureContainer.CHILDREN_PROP) {
	GestureContainer container = (GestureContainer)
	  originalEvent.getSource();
	/*
	System.out.println("NH: children changed for " +
			   container.getName());
	*/
	if ((oldValue == null) && (newValue != null)) {
	  // one was added
	  /*
	  System.out.println("\tadded");
	  */
	  GestureObject obj = (GestureObject) newValue;
	  if (hasNotices(obj)) {
	    addNoticeObjToAncestors(obj);
	  }
	}
	else if ((newValue == null) && (oldValue != null)) {
	  // one was removed
	  /*
	  System.out.println("\tremoved");
	  */
	  GestureObject obj = (GestureObject) oldValue;
	  if (hasNotices(obj)) {
	    removeNoticeObjFromAncestors(e, obj);
	    removeNoticeObjsFromAncestors(e, getNoticeDescendents(obj));
	  }
	}
      }
    }

    protected static void addNoticeObjToAncestors(GestureObject gestureObj)
    {
      for (GestureContainer container = gestureObj.getParent();
	   container != null;
	   container = container.getParent()) {
	List noticedObjs;
	if (container.hasProperty(NOTICE_DESCENDENTS_PROP)) {
	  noticedObjs = (List) Misc.
	    cloneCollection((Collection) container.
			    getProperty(NOTICE_DESCENDENTS_PROP));
	}
	else {
	  noticedObjs = new ArrayList();
	}
	if (!noticedObjs.contains(gestureObj)) {
	  noticedObjs.add(gestureObj);
	  /*
	  System.out.println("Adding notice to " + container.getName() +
			     ": " + gestureObj);
	  System.out.println("\t# of noticed descendents: " +
			     noticedObjs.size());
	  */
	  container.setProperty(NOTICE_DESCENDENTS_PROP, noticedObjs);
	}
      }
    }

    /** Walk down the event chain (which are gestureObj's former
        ancestors) and remove gestureObj from their
        NOTICE_DESCENDENTS_PROP list. */
    protected static void
      removeNoticeObjFromAncestors(PropertyChangeEvent e,
				   GestureObject gestureObj)
    {
      for (; (e != null) &&
	     (e.getPropertyName() == GestureContainer.CHILD_CHANGE_PROP);
	   e = (e.getPropertyName() == GestureContainer.CHILD_CHANGE_PROP) ?
	     (PropertyChangeEvent) e.getNewValue() : null) {
	GestureContainer container = (GestureContainer) e.getSource();
	/*
	System.out.println("\tRemoving from " + container.getName() + ":" +
			   gestureObj);
	*/
	List noticedObjs = getNoticeDescendents(container);
	noticedObjs.remove(gestureObj);
	/*
	System.out.println("\t# of noticed descendents: " +
			   noticedObjs.size());
	*/
	container.setProperty(NOTICE_DESCENDENTS_PROP, noticedObjs);
      }
    }

    protected static void
      removeNoticeObjsFromAncestors(PropertyChangeEvent e, List objList)
    {
      if (objList != null) {
	for (Iterator iter = objList.iterator(); iter.hasNext();) {
	  removeNoticeObjFromAncestors(e, (GestureObject) iter.next());
	}
      }
    }
  }
}
