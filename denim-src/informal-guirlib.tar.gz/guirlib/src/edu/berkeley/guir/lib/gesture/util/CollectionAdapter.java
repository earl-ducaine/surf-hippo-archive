package edu.berkeley.guir.lib.gesture.util;

public class CollectionAdapter implements CollectionListener {
  public void elementAdded(CollectionEvent e) {}
  public void elementRemoved(CollectionEvent e) {}
  public void elementChanged(CollectionEvent e) {}
}
