package edu.berkeley.guir.denim.interpreters;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.commands.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import java.awt.geom.*;

/**
 * Selects the tapped GraphicalObject.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-31-1999 JL
 *                    Created class TapInterpreter. Basically copied
 *                    edu.berkeley.guir.lib.satin.interpreter.commands.
 *                    TapSelectInterpreter and added an else clause.
 *             1.0.1  06-27-2000 JH
 *                    Simplified and refactored the code into
 *                    HoldSelectInterpreter in SATIN.
 *
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version Version 1.0.1, 06-27-2000
 */
public class SelectInterpreter
   extends    HoldSelectInterpreter
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 6795162031863799658L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs a tap interpreter.
    */
   public SelectInterpreter() {
      super();
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Constructs a tap interpreter as a copy of the given interpreter.
    */
   public SelectInterpreter(SelectInterpreter intrp) {
      //// 1. Since this interpreter is stateless, we can do this safely.
      this();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Perform initializations common to all constructors.
    */
   private void commonInitializations() {
   } // of method

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   STROKE METHODS   ====================================================

   private double getScaleFactor() {
      return (GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                getAttachedGraphicalObject()));
   } // of method

   //===   STROKE METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   SELECT METHODS   ====================================================

   /**
    * Select the closest graphical object. This is the method called by the
    * Timer, so override this method if you want additional behavior.
    *
    * @param  lastEvent is the last stroke event that occurred.
    * @return true if we selected something, false otherwise.
    */
   protected boolean selectClosestGob(StrokeEvent lastEvent) {
      DenimSheet sheet    = (DenimSheet)getAttachedGraphicalObject().getSheet();
      Point2D    lastAbsPt= lastEvent.getStroke().getEndPoint2D(COORD_ABS);

      //// 1. If the length is too long, it's not a tap.
      TimedStroke stk = lastEvent.getStroke();

      if (!StrokeLib.isTap(stk)) {
         return false;
      }

      isConsumingEvents = true;

      //// 2. Get the select candidates.
      GraphicalObject selgob = sheet.getObjectToSelect(lastAbsPt);

      //// 3. If there is a candidate, then select or deselect.
      boolean wasSelected = false;
      if (selgob != null) {
         wasSelected = manageSelect(selgob,
                                     lastEvent.getMouseEvent().isShiftDown());
         sheet.setCrosshairsVisible(false);
         
         getAttachedGraphicalObject().damage(DAMAGE_NOW);

         //// If an object was selected, allow the user to start moving
         //// it immediately.
         if (wasSelected) {
            NewStrokeEvent newEvt =
               new NewStrokeEvent(lastEvent.getSource(), stk);
            sheet.getMoveSelectedInterpreter().handleNewStroke(newEvt);
            isConsumingEvents = false;
         }
      }
      //// 4. Otherwise, put the crosshairs where the user tapped.
      else {
         cmdsubsys.clearSelected();
         sheet.setCrosshairsLocation(lastAbsPt);
         sheet.setCrosshairsVisible(true);
      }

      //// 5. Return whether we selected something or not.
      return (wasSelected);
   } // of method

   //-----------------------------------------------------------------

   public void handleNewStroke(NewStrokeEvent evt) {
      double curscale;
      curscale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                       getAttachedGraphicalObject().getSheet());

      if (curscale >= INTERPRETER_TRANSITION) {
         setDeep();
      }
      else {
         setShallow();
      }

      super.handleNewStroke(evt);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Selects or unselects the object. Returns whether the object was
    * selected.  Holding down shift key allows selection of multiple objects
    */
   private boolean manageSelect(GraphicalObject selgob, boolean isShiftDown) {

      boolean selected = false;

      if (selgob != null) {
         didToggle = true;

         //// 1.1. If the shift key is held down, then...
         if (isShiftDown) {
            //// 1.1.1. If the object is already selected, unselect it.
            if (cmdsubsys.isSelected(selgob)) {
               cmdsubsys.removeSelected(selgob);
            }
            //// 1.1.2. If the object is not selected, add it to the group
            //// of selected objects.
            else {
               cmdsubsys.addSelected(selgob);
               selected = true;
            }
         }
         //// 1.2. Otherwise, select only that object, and unselect any
         //// other selected objects.
         else {
            cmdsubsys.clearSelected();
            cmdsubsys.addSelected(selgob);
            selected = true;
         }
         selgob.damage(DAMAGE_LATER);
      }
      return selected;
   } // of method


   /**
    * Selects or unselects the object. Returns whether the object was
    * selected.
    */
   protected boolean toggleSelectGraphicalObject(GraphicalObject selgob) {
      boolean selected = false;

      if (selgob != null) {
         if (cmdsubsys.isSelected(selgob)) {
            cmdsubsys.removeSelected(selgob);
         }
         else {
            cmdsubsys.clearSelected();
            cmdsubsys.addSelected(selgob);
            selected = true;
         }
         selgob.damage(DAMAGE_LATER);
      }

      return selected;
   } // of method

   //===   STROKE METHODS ======================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      return (new SelectInterpreter(this));
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
