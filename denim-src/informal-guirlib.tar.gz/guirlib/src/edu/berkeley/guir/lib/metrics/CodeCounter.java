//// See bottom of source code for software license.
package edu.berkeley.guir.lib.metrics;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

/**
 * Runs some simple metrics on your code, like number of methods, number of
 * logical lines of code, etc.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 15 2004
 */
public class CodeCounter {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   public static final String BEGIN_TOKEN      = "{";
   public static final String END_TOKEN        = "}";
   public static final String COMMENT_EOLN     = "//";
   public static final String COMMENT_BEGIN    = "/*";
   public static final String COMMENT_CONTINUE = "*";
   public static final String COMMENT_END      = "*/";
   public static final String STATEMENT_END    = ";";

   //// Method depth says at what level should the BEGIN-END pairs be
   //// counted as methods. Depth 0 indicates a class BEGIN-END pair.
   public static final int    METHOD_DEPTH     = 1;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   String    strFileName;
   int       iLinesOfComments      = 0;     // num of lines of comments
   int       iLinesOfLogicalCode   = 0;     // num of lines of logical code
   int       iLinesOfPhysicalCode  = 0;     // num of lines of physical code
   int       iNumMethods           = 0;     // the number of methods

   boolean   bInsideCommentBlock   = false; // Inside a comment block or not?
   int       iTokenPairCount       = 0;     // num of BEGIN_TOKEN - END_TOKEN

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   UTILITY METHODS   ===================================================

   /**
    * Count the number of occurrences of a character in a String.
    *
    * @param  chSearch is the character to search for.
    * @param  strLine is the String to search through.
    * @return The number of times the character was found in the String.
    */
   public static int 
   countOccurrencesOfCharacter(char chSearch, String strLine) {

      int iNumOccurrences = 0;
      int iStartIndex     = 0;

      iStartIndex = strLine.indexOf(chSearch, 0);

      while (iStartIndex != -1) {
         iNumOccurrences++;
         iStartIndex = strLine.indexOf(chSearch, iStartIndex + 1);
      }

      return(iNumOccurrences);

   } // of countOccurrencesOfCharacter

   //===========================================================================

   /**
    * Count the number of occurrences of a String in a String.
    *
    * @param  strSearch is the String to search for.
    * @param  strLine is the String to search through.
    * @return The number of times the character was found in the String.
    */
   public static int 
   countOccurrencesOfString(String strSearch, String strLine) {

      int iNumOccurrences = 0;
      int iStartIndex     = 0;

      iStartIndex = strLine.indexOf(strSearch, 0);

      while (iStartIndex != -1) {
         iNumOccurrences++;
         iStartIndex = strLine.indexOf(strSearch, iStartIndex + 1);
      }

      return(iNumOccurrences);

   } // of countOccurrencesOfString

   //===========================================================================

   /**
    * Remove all characters from a String starting from the first location
    * of one character to the first location of another character.
    *
    * @param  chFrom is the character to start deleting from.
    * @param  chTo   is the character to end deleting.
    * @param  strLine is the String to remove characters from.
    * @return A String with characters removed, unmodified if the delimiting
    *         characters do not exist in the String.
    */
   public static String 
   removeSubstring(char chFrom, char chTo, String strLine) {
      int iStartIndex;
      int iEndIndex;

      //// Find the start and end indices
      iStartIndex = strLine.indexOf(chFrom);
      iEndIndex   = strLine.indexOf(chFrom, iStartIndex + 1);

      //// Now remove all characters between these indices
      if (iStartIndex == -1 || iEndIndex == -1)
         return(strLine);

      return(strLine.substring(0, iStartIndex) + 
             strLine.substring(iEndIndex + 1));
   }

   //===   UTILITY METHODS   ===================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructor.
    *
    * @param strFileName is the name of the file to open.
    */
   public CodeCounter(String strFileName) {
      FileInputStream   fistream;
      try {
         fistream         = new FileInputStream(strFileName);
         this.strFileName = strFileName;
         countLines(fistream);
      }
      catch (Exception e) {
         System.out.println("File " + strFileName + " not found!");
      }
   } // of constructor

   //----------------------------------------------------------------

   /**
    * Constructor.
    *
    * @param f is the file to open.
    */
   public CodeCounter(File f) {
      FileInputStream   fistream;
      try {
         fistream         = new FileInputStream(f);
         this.strFileName = f.getName();
         countLines(fistream);
      }
      catch (Exception e) {
         System.out.println("File " + f + " not found!");
      }
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



    //==========================================================================
    //===   ACCESSOR METHODS   =================================================

    /**
     * Get the number of lines of comments in the source code.
     *
     * @return The number of lines of comments.
     */
    public int getLinesOfComments() {
       return (iLinesOfComments);
    } // of method

    //==========================================================================

    /**
     * Get the number of lines of logical code in the source code.
     *
     * @return The number of lines of logical code.
     */
    public int getLinesOfLogicalCode() {
       return (iLinesOfLogicalCode);
    } // of method

    //==========================================================================

    /**
     * Get the number of lines of physical code in the source code.
     *
     * @return The number of lines of physical code.
     */
    public int getLinesOfPhysicalCode() {
       return (iLinesOfPhysicalCode);
    } // of method

    //==========================================================================

    /**
     * Get the number of methods in the source code.
     *
     * @return The number of lines of physical code.
     */
    public int getNumMethods() {
       return (iNumMethods);
    } // of method

    //===   ACCESSOR METHODS   =================================================
    //==========================================================================




    //==========================================================================
    //===   PRIVATE UTILITY METHODS   ==========================================

    /**
     * Count the lines of comments, logical code, and physical lines.
     */
    private void countLines(InputStream istream) {

       String            strLine;                         // the line read in
       InputStreamReader istreamRdr = new InputStreamReader(istream);
       BufferedReader    bufRdr     = new BufferedReader(istreamRdr);

       try {
          //// Read until EOF
          while ((strLine = bufRdr.readLine()) != null) {
             //// Skip blank lines here
             strLine = strLine.trim();
             if (! strLine.equals("")) {
                setCommentBlock(strLine);         // see if in block of comments
                checkLineForComments(strLine);    // count comments
                strLine = simplifyLine(strLine);  // remove comments and Strings
                checkMethod(strLine);             // see if method is completed 
                checkLineForLogicalCode(strLine); // count logical line of code
                checkLineForPhysicalCode(strLine);// count physical line of code
             }
          } // of while
       }
       catch (IOException e) {
          System.out.println("Error reading file " + strFileName);
          //// Reset the values so as not to screw up our metrics
          iLinesOfComments      = 0;
          iLinesOfLogicalCode   = 0;
          iLinesOfPhysicalCode  = 0;
          iNumMethods           = 0;
       }
    } // of method

    //----------------------------------------------------------------

    /**
     * See if the entire line is a comment.
     * Does not return true if there is code AND comment on the line.
     *
     * @param  strLine is a line of Java code (trimmed of leading and trailing).
     * @return True if the entire line is a comment, false otherwise.
     */
    private boolean isComment(String strLine) {

       //// if the line starts with // then return true
       if (strLine.startsWith(COMMENT_EOLN) == true)
          return (true);

       //// if we are inside a /* */ comment block then return true
       if (bInsideCommentBlock == true)
          return (true);

       //// if the line starts with a /* then return true
       if (strLine.startsWith(COMMENT_BEGIN) == true)
          return (true);

       return(false);

    } // of method

    //----------------------------------------------------------------

    /**
     * Remove comments and literal Strings in the source line of code.
     *
     * @param  strLine is a line of Java code (trimmed of leading and trailing).
     */
    private String simplifyLine(String strLine) {

       String strReturn = strLine;
       int    iIndex;

       //// Remove literal Strings
       do {
          strLine   = strReturn;
          strReturn = removeSubstring('"', '"', strLine);
       } while (! strLine.equals(strReturn));

       //// See if it contains EOLN comments and remove them
       iIndex = strLine.indexOf(COMMENT_EOLN);
       if (iIndex != -1)
          strReturn = strLine.substring(0, iIndex);

       return(strReturn);

    } // of method

    //----------------------------------------------------------------

    /**
     * Set the status of whether or not we are in a comment block.
     *
     * @param  strLine is a line of Java code (trimmed of leading and trailing).
     */

    private void setCommentBlock(String strLine) {

       //// modifies nonlocal variable bInsideCommentBlock

       //// if the line starts with // then don't do anything
       if (! strLine.startsWith(COMMENT_EOLN)) {
          //// if there was a begin comment block token, and we were not in
          //// a comment block already, then we are now in a comment block
          if (strLine.lastIndexOf(COMMENT_BEGIN) != -1)
             bInsideCommentBlock = true;

          //// if there is an end comment block token, and we were in a comment
          //// block, then we are now out of the comment block
          if ((strLine.lastIndexOf(COMMENT_END) != -1) && 
              (bInsideCommentBlock == true))
             bInsideCommentBlock = false;
       }

    } // of method

    //----------------------------------------------------------------

    /**
     * See if a method has been coded completely in the source.
     *
     * @param  strLine is a line of Java code (trimmed of leading and trailing).
     */
    private void checkMethod(String strLine) {

       int iNumTokensChange = 0;

       // Too many unmatched " + END_TOKEN
       assert iTokenPairCount >= 0; 

       //// if it is not a comment then process it
       if (! isComment(strLine)) {

          //// if it contains a BEGIN_TOKEN then increment iTokenPairCount
          iTokenPairCount += countOccurrencesOfString(BEGIN_TOKEN, strLine);

          //// if it contains a END_TOKEN then decrement iTokenPairCount
          iNumTokensChange = countOccurrencesOfString(END_TOKEN, strLine);

          if (iNumTokensChange > 0) {
             iTokenPairCount -= iNumTokensChange;

             //// if iTokenPairCount is METHOD_DEPTH, then we have completed 
             //// a method. This is because the class also has a BEGIN_END pair
             if (iTokenPairCount == METHOD_DEPTH)
                iNumMethods++;
          }

       }

    } // of method

    //----------------------------------------------------------------

    /**
     * If the line contains a comment then increment the number of
     * lines of comments.
     *
     * @param strLine is a line of Java code (trimmed of leading and trailing).
     */
    private void checkLineForComments(String strLine) {
       //// modifies nonlocal variable iLinesOfComments

       if (isComment(strLine) || strLine.indexOf(COMMENT_EOLN) != -1) {
          //// Skip lines that have no meaningful comments
          if (! strLine.endsWith(COMMENT_CONTINUE) == true)
             iLinesOfComments++;
       }

    } // of method

    //----------------------------------------------------------------

    /**
     * If the line contains a line of logical source code, then increment 
     * the number of lines of comments.
     *
     * @param strLine is a line of Java code (trimmed of leading and trailing).
     */
    private void checkLineForLogicalCode(String strLine) {
       //// modifies nonlocal variable iLinesOfLogicalCode

       if (! isComment(strLine)) {
          if (strLine.indexOf(STATEMENT_END) != -1)
             iLinesOfLogicalCode++;
       }

    } // of method

    //----------------------------------------------------------------

    /**
     * If the line contains a line of physical source code (including comments),
     * then increment the number of lines of comments.
     *
     * @param strLine is a line of Java code (trimmed of leading and trailing).
     */
    private void checkLineForPhysicalCode(String strLine) {
       //// modifies nonlocal variable iLinesOfPhysicalCode

       iLinesOfPhysicalCode++;

    } // of method

    //===   PRIVATE UTILITY METHODS   ==========================================
    //==========================================================================

   


    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {

       return("Source File:            " + strFileName              + "\n" +
              "Lines of Logical Code:  " + getLinesOfLogicalCode()  + "\n" +
              "Number of methods:      " + getNumMethods()          + "\n" +
              "Lines of Comments:      " + getLinesOfComments()     + "\n" +
              "Lines of Physical Code: " + getLinesOfPhysicalCode());

    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   FILE UTILITY   =====================================================

    private static boolean isJavaFile(File f) {
        return (f.getName().endsWith(".java"));
    } // of method

    //----------------------------------------------------------------

    /**
     * @param  fRoot is the directory to start recursing from
     * @return List of String, Java files
     */
    public static List getAllJavaFiles(File fRoot) {
        List listJavaFiles   = new LinkedList(); // List of files
        List listDirectories = new LinkedList(); // List of dirs

        //// 1. Initialize with root.
        listDirectories.add(fRoot);

        //// 2. Dequeue and traverse all directories.
        File fDir;
        while (listDirectories.size() > 0) {
            fDir = (File) listDirectories.remove(0);

            //// 2.1. Get all subdirectories one level below.
            File[] fSubdirs = fDir.listFiles();

            //// 2.2. Get all InfoSpaces one level below.
            for (int i = 0; i < fSubdirs.length; i++) {
                if (isJavaFile(fSubdirs[i])) {
                    listJavaFiles.add(fSubdirs[i]);
                }
                else if (fSubdirs[i].isDirectory()) {
                    listDirectories.add(fSubdirs[i]);
                }
            }
        }

        //// 3. Return.
        return (listJavaFiles);
    } // of method

    //===   FILE UTILITY   =====================================================
    //==========================================================================




    //==========================================================================
    //===   MAIN   =============================================================

    /**
     * @return a List of CodeCounter instances
     */
    private static List handleFile(File f) {
        List   list = new LinkedList();
        List   listJavaFiles;
        File[] fJavaFiles;

        //// 1.1. Skip files that don't exist...
        if (f.exists() == false) {
            System.err.println(f.toString() + " does not exist");
        }
        //// 1.2. ...handle individual files...
        else if (f.isFile()) {
            CodeCounter c = new CodeCounter(f);
            list.add(c);
        }
        //// 1.3. ...handle directories...
        else if (f.isDirectory()) {
           listJavaFiles    = getAllJavaFiles(f);
           fJavaFiles       = (File[]) listJavaFiles.toArray(new File[0]);
           for (int i = 0; i < fJavaFiles.length; i++) {
               list.add(new CodeCounter(fJavaFiles[i]));
           }
        }

        return (list);
    } // of method

    //----------------------------------------------------------------

    /**
     * @param argv is either no-arg, in which case all *.java files in
     *             the current and in contained directories are checked,
     *             or a list of java files or directories.
     */
    public static void main(String[] argv) {
       CodeCounter[] countArr = null;
       List          listCodeCounters;
       int           iSumLinesOfLogicalCode  = 0;
       int           iSumNumMethods          = 0;
       int           iSumLinesOfComments     = 0;
       int           iSumLinesOfPhysicalCode = 0;

       //// 1.1. If no arguments, retrieve all files...
       if (argv.length <= 0) {
           listCodeCounters = handleFile(new File("."));
       }
       //// 1.2. Otherwise handle each argument...
       else {
           listCodeCounters = new LinkedList();
           for (int i = 0; i < argv.length; i++) {
               listCodeCounters.addAll(handleFile(new File(argv[i])));
           }
       }
       countArr = (CodeCounter[]) listCodeCounters.toArray(new CodeCounter[0]);


       //// 2. Calculate and print out individual information
       for (int i = 0; i < countArr.length; i++) {
           System.out.println(countArr[i]);
           System.out.println();
           iSumLinesOfLogicalCode  += countArr[i].getLinesOfLogicalCode();
           iSumNumMethods          += countArr[i].getNumMethods();
           iSumLinesOfComments     += countArr[i].getLinesOfComments();
           iSumLinesOfPhysicalCode += countArr[i].getLinesOfPhysicalCode();
       }


       //// 3. Print out the summary information
       System.out.println
             ("\nSUMMARY INFORMATION"                                + "\n" +
                "#source files:          " + countArr.length         + "\n" + 
                "Lines of Logical Code:  " + iSumLinesOfLogicalCode  + "\n" +
                "Number of methods:      " + iSumNumMethods          + "\n" +
                "Lines of Comments:      " + iSumLinesOfComments     + "\n" +
                "Lines of Physical Code: " + iSumLinesOfPhysicalCode);
       
    } // of main

    //===   MAIN   =============================================================
    //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
