package edu.berkeley.guir.lib.gesture;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.event.EventListenerList;

import edu.berkeley.guir.lib.gesture.util.FlowScrollPanel;

/**
 * Displays the elements (i.e. example Gestures) of a GestureCategory.
 * Emits an ItemEvent when one is (de)selected.
 */
public class GestureCategoryDisplay extends FlowScrollPanel
implements Observer, ItemSelectable
{
  //private String realName;
  private GestureCategory gestureCategory;
  private GestureDisplay selectedGestureDisplay;
  protected EventListenerList itemListenerList = new EventListenerList();
  /*
  JScrollPane scroller = null;
  FlowLayout layout;
  */
  int maxChildHeight = 0;
  boolean authorVisible = false;
  
  public GestureCategoryDisplay()
  {
    this(null, true);
  }

  public GestureCategoryDisplay(GestureCategory gc)
  {
    this(gc, false);
  }
  
  public GestureCategoryDisplay(GestureCategory gc, boolean showAuthor)
  {
    super();
    authorVisible = showAuthor;
    initUI();
    setGestureCategory(gc);
  }

  public void setGestureCategory(GestureCategory gc)
  {
    if (gestureCategory != null) {
      gestureCategory.deleteObserver(this);
    }
    gestureCategory = gc;
    if (gc != null) {
      gc.addObserver(this);
    }
    rebuildUI();
  }

  public GestureCategory getGestureCategory()
  {
    return gestureCategory;
  }
  
  public void update(Observable o, Object arg)
  {
    if (arg != null) {
      if (arg instanceof Gesture) {
	// new gesture entered
	GestureCategory gc = (GestureCategory) o;
	Gesture gesture = (Gesture) arg;

	addGesture(gesture);
      }
      else if (arg instanceof String) {
	// name changed
      }
      else
	rebuildUI();
    }
    else {
      // something more drastic happened
      rebuildUI();
    }
  }

  /**
   * Causes the entire frame to be repacked to make sure that the
   * new GestureDisplay is properly drawn.  This seems wasteful, but
   * nothing else worked.
   */
  public GestureDisplay addGesture(Gesture gesture)
  {
    GestureDisplay gestureDisplay = new GestureDisplay(gesture, 10, 10);
    gestureDisplay.setAuthorVisible(authorVisible);
    gestureDisplay.setBorder(BorderFactory.createEtchedBorder());

    // resize children if necessary
    int newHeight = gestureDisplay.getMinimumSize().height;
    if (newHeight > maxChildHeight) {
      // make all children this new height
      Component[] components = getComponents();
      for (int i = 0; i < components.length; i++) {
	JComponent c = (JComponent) components[i];
	int oldWidth = c.getPreferredSize().width;
	c.setPreferredSize(new Dimension(oldWidth, newHeight));
      }
      maxChildHeight = newHeight;
    }
    else if (newHeight < maxChildHeight) {
      gestureDisplay.
	setPreferredSize(new Dimension(gestureDisplay.
				       getMinimumSize().width,
				       maxChildHeight));
    }
    
    add(gestureDisplay);
    revalidate();
    
    Window w = (Window) getTopLevelAncestor();
    if (w != null) {
      w.pack();
    }

    return gestureDisplay;
  }
  
  // now the UI part

  /**
   * one-time setup when the widget is made
   */
  protected void initUI()
  {
    setMinimumSize(new Dimension(10,10));
    addMouseListener(new MouseHandler());

    ((FlowLayout) getLayout()).setHgap(0);
    /* for debugging
    addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e)
	{
	  if ((e.getModifiers() & e.BUTTON2_MASK) != 0) {
	    Component[] children = getComponents();
	    for (int i = 0; i < children.length; i++) {
	      System.out.println(i + "\t" +
				 debug.toString(children[i].getLocation()));
	    }
	  }
	  else if ((e.getModifiers() & e.BUTTON3_MASK) != 0) {
	    GestureCategoryDisplay.this.rebuildUI();
	    //GestureCategoryDisplay.this.doLayout();
	  }
	}
    });
    */
  }

  static boolean mouse1(MouseEvent e)
  {
    int mods = e.getModifiers();
    return (mods == 0) || ((mods & InputEvent.BUTTON1_MASK) != 0);
  }
  

  /**
   * If the gesturecategory changes, need to change the gestures that
   * are displayed.
   */
  public void rebuildUI()
  {
    // first, clear the old examples
    removeAll();
    maxChildHeight = 0;

    // Make gesture displays for all the gestures and add them
    for (Iterator iter = gestureCategory.iterator(); iter.hasNext();) {
      Gesture gesture = (Gesture) iter.next();
      gestureCategory.add(gesture);
    }
  }
  
  public boolean isOpaque()
  {
    return false;
  }

  /**
   * Returns GestureDisplay associated with current selection (or null
   * if none).
   */
  public GestureDisplay getSelectionDisplay()
  {
    return selectedGestureDisplay;
  }

  /**
   * Returns currently selected Gesture (or null if none).
   */
  public Gesture getSelection()
  {
    return (selectedGestureDisplay == null) ? (null) :
      selectedGestureDisplay.getGesture();
  }

  /**
   * Returns currently selected Gestures (or null if none).
   * For now this will always be an array of 1 Gesture.
   */
  public Object[] getSelectedObjects()
  {
    Gesture selection = getSelection();
    Object[] result = {selection};
    
    if (selection == null)
      result = null;
    
    return result;
  }

  /**
   * This component does tile its children
   */
  public boolean isOptimizedDrawingEnabled()
  {
    return true;
  }

  //
  // Narrowing
  //

  /**
   * Narrows to the specified gestures (which should be a Vector of
   * Gesture).  The reason is for inclusion in the frame title.
   */
  public void narrow(Vector gestures, String reason)
  {
    Component[] components = getComponents();
    for (int i = 0; i < components.length; i++) {
      GestureDisplay gestureDisplay = (GestureDisplay) components[i];
      boolean narrow = gestures.contains(gestureDisplay.getGesture());
      gestureDisplay.setNarrowed(narrow);
    }
    /*
    if (realName == null)
      realName = gestureCategory.getName();
    gestureCategory.setName(realName + reason + " (narrowed)");
    */
  }

  //
  // Mouse event handling
  //
  
  class MouseHandler extends MouseAdapter
  {
    public void mousePressed(MouseEvent e)
    {
      Point p = new Point(e.getPoint());
      
      Component component = getComponentAt(p);
      if ((component != null) && (component instanceof GestureDisplay)) {
	GestureDisplay newSelection = (GestureDisplay) component;
	GestureDisplay oldSelection = selectedGestureDisplay;
	if (newSelection.toggleSelected()) {
	  if (selectedGestureDisplay != null) {
	    selectedGestureDisplay.setSelected(false);
	  }
	  selectedGestureDisplay = newSelection;
	}
	else {
	  selectedGestureDisplay = null;
	}
	// send out change event(s)
	if (oldSelection != null)
	  fireItemChange(ItemEvent.ITEM_STATE_CHANGED,
			 oldSelection.getGesture(), ItemEvent.DESELECTED);
	if (selectedGestureDisplay != null)
	  fireItemChange(ItemEvent.ITEM_STATE_CHANGED,
			 selectedGestureDisplay.getGesture(),
			 ItemEvent.SELECTED);
      }
    }
  }

  //
  // Item Listener routines
  //
  
  public void addItemListener(ItemListener l)
  {
    itemListenerList.add(ItemListener.class, l);
  }

  public void removeItemListener(ItemListener l)
  {
    itemListenerList.remove(ItemListener.class, l);
  }

  protected void fireItemChange(int type, Gesture item, int selectState)
  {
    ItemEvent event = null;
    Object[] listeners = itemListenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ItemListener.class) {
	if (event == null)
	  event = new ItemEvent(this, type, item, selectState);
	((ItemListener)listeners[i+1]).itemStateChanged(event);
      }
    }
  }

  public void setAuthorVisible(boolean on)
  {
    if (authorVisible != on) {
      authorVisible = on;
      Component[] components = getComponents();
      for (int i = 0; i < components.length; i++) {
	GestureDisplay gestureDisplay = (GestureDisplay) components[i];
	gestureDisplay.setAuthorVisible(on);
      }
    }
  }
}
