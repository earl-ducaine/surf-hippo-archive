package edu.berkeley.guir.damask.view;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.*;
import java.util.logging.Logger;
import java.util.prefs.Preferences;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import javax.xml.bind.JAXBException;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.view.DamaskDocument.DamaskCanvasGroup;
import edu.berkeley.guir.damask.view.DamaskDocument.VerboseCommandQueue;
import edu.berkeley.guir.damask.view.appdialogs.FileDialogUtils;
import edu.berkeley.guir.damask.view.appevent.*;
import edu.berkeley.guir.damask.view.appevent.DocumentEvent;
import edu.berkeley.guir.damask.view.appevent.DocumentListener;
import edu.berkeley.guir.damask.view.pattern.PatternBrowser;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.berkeley.guir.lib.satin.command.CommandQueue;
import edu.umd.cs.piccolo.PLayer;

/** 
 * The window that contains the Damask application.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-28-2003 James Lin
 *                               Created DamaskFrame
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-28-2003
 */
public class DamaskFrame extends JFrame {

   private static final String PROPERTY_SLIDER = "slider";
   private static final String PROPERTY_CANVAS = "canvas";
   
   private static final Logger logger =
      Logger.getLogger(DamaskFrame.class.getName());

   // The offset in the x direction that a new window is created from
   // an existing one
   private static final int NEW_WINDOW_OFFSET = 20;
   
   // The position in the Window menu of the first open window.
   // Initialized in the constructor.
   private final int FIRST_OPEN_WINDOW_POS;
   
   private static final SortedSet/*<DamaskFrame>*/ allFrames =
      new TreeSet/*<DamaskFrame>*/(new FrameNameComparator());

   private final DamaskCanvasGroup canvasGroup;
   private DamaskCanvas currentCanvas = null;
   
   private final JTabbedPane tabPane = new JTabbedPane();
   private final Toolbox toolbox = new Toolbox();
   private final DamaskToolbar toolbar = new DamaskToolbar();
   private final Set/*<DamaskCanvas>*/ canvasWithVisibleTemplates =
      new HashSet();

   private final DocumentListener docListener = new DocumentHandler();
   private final WindowHandler winHandler = new WindowHandler();
   private final ChangeListener tabListener = new TabbedPaneListener();
   private final CommandListener commandListener = new CommandHandler();
   
   private final Action newAction = new NewAction();
   private final Action openAction = new OpenAction();
   private final Action saveAction = new SaveAction();
   private final Action undoAction = new UndoAction();
   private final Action redoAction = new RedoAction();
   
   private final JMenuItem fileExportAsVoiceXMLItem;
   
   private final JMenuItem editCutItem;
   private final JMenuItem editCopyItem;
   private final JMenuItem editPasteItem;
   private final JMenuItem editDeleteItem;
   
   private final JCheckBoxMenuItem viewTemplatesItem;
   private final JCheckBoxMenuItem viewRadarItem;
   private final JCheckBoxMenuItem viewPatternItem;
   
   private final JMenu pageMenu;
   private final JMenuItem pageCutItem;
   private final JMenuItem pageCopyItem;
   private final JMenuItem pagePasteItem;
   private final JMenuItem pageDeleteItem;
   private final JMenuItem pageSetHomeItem;
   
   private final JMenu contentMenu;
   private final JRadioButtonMenuItem contentInkItem;
   private final JRadioButtonMenuItem contentTextItem;
   private final JRadioButtonMenuItem contentPictureItem;
   // dummy item so that we can make all of the above 3 unselected
   private final JRadioButtonMenuItem contentMixedItem;
   
   private final JMenuItem contentChangePictureItem;

   private final JMenu runMenu;
   private final JMenuItem runFromHomeItem;
   private final JMenuItem runFromSelectedPageItem;
   
   private final JMenu windowMenu;
   
   private DamaskRadarDialog radarView;
   
   /**
    * Creates a new frame for Damask.
    */
   public DamaskFrame(final DamaskCanvasGroup canvasGroup) {
      this.canvasGroup = canvasGroup;

      // Set the initial size and location of the window.
      final Toolkit toolkit = Toolkit.getDefaultToolkit();
      final Dimension frameSize = toolkit.getScreenSize();
      final Insets insets = toolkit.getScreenInsets(getGraphicsConfiguration());
      frameSize.width -= (insets.left + insets.right);
      frameSize.height -= (insets.top + insets.bottom);
      if (frameSize.width > frameSize.height) {
         frameSize.width *= 0.7;
      }
      else {
         frameSize.height *= 0.7;
      }
      setSize(frameSize);
      setLocation(insets.left, insets.top);

      // Listen for events from ALL open documents.
      for (Iterator i = DamaskApp.getDocuments().iterator(); i.hasNext(); ) {
         final DamaskDocument doc = (DamaskDocument)i.next();
         doc.addDocumentListener(docListener);
      }
      
      final Container content = getContentPane();

      // Create a tabbed pane from this canvas group, one tab per canvas
      for (Iterator i = Damask.getSupportedDeviceTypes().iterator(); i.hasNext();) {
         final DeviceType deviceType = (DeviceType)i.next();
         final JPanel tabPaneContent = new JPanel();
         final DamaskCanvas canvas = canvasGroup.getCanvas(deviceType);
         final DamaskLayer layer = (DamaskLayer)canvas.getLayer(); 

         // Initialize the canvas's zoom level
         canvas.setZoomLevel(DamaskCanvas.STORYBOARD);
			
         tabPaneContent.setLayout(new BorderLayout());

         // Add the layer buttons and the zoom slider to the left
         final JPanel leftBar = new JPanel();
         leftBar.setLayout(new BoxLayout(leftBar, BoxLayout.Y_AXIS));

         {
            final JPanel layerButtonsPanel = new JPanel();
            layerButtonsPanel.setLayout(new GridLayout(0, 1));
            layerButtonsPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
         
            final JLabel layersLabel = new JLabel("Layers:");
            layerButtonsPanel.add(layersLabel);
            
            final ButtonGroup layersButtonGroup = new ButtonGroup();
         
            final JToggleButton allDevicesButton =
               new JRadioButton("All Devices");
            allDevicesButton.setMnemonic('A');
            allDevicesButton.setModel(layer.getAllDevicesButtonModel());
            layersButtonGroup.add(allDevicesButton);
            layerButtonsPanel.add(allDevicesButton);
         
            final JToggleButton thisDeviceButton =
               new JRadioButton("This Device");
            thisDeviceButton.setMnemonic('T');
            thisDeviceButton.setModel(layer.getThisDeviceButtonModel());
            layersButtonGroup.add(thisDeviceButton);
            layerButtonsPanel.add(thisDeviceButton);
            
            if (!Damask.PATTERNS_AND_LAYERS) {
               layersLabel.setVisible(false);
               allDevicesButton.setEnabled(false);
               allDevicesButton.setVisible(false);
               thisDeviceButton.setEnabled(false);
               thisDeviceButton.setVisible(false);
            }
            
            leftBar.add(layerButtonsPanel);
         }

         leftBar.add(new JSeparator());

         {
            final ZoomSlider zoomSlider = new ZoomSlider(canvas.getSliderModel());
            zoomSlider.setMaximumSize(
               new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
            leftBar.add(zoomSlider);
   
            tabPaneContent.add(leftBar, BorderLayout.WEST);

            {
               final JPanel mainPanel = new JPanel();
               mainPanel.setLayout(new BorderLayout());
               // Add buttons for panning
               final JButton topButton = new JButton(DamaskRadarDialog.getRadarIcon("top.gif"));
               final JButton bottomButton = new JButton(DamaskRadarDialog.getRadarIcon("bottom.gif"));
               final JButton leftButton = new JButton(DamaskRadarDialog.getRadarIcon("left.gif"));
               final JButton rightButton = new JButton(DamaskRadarDialog.getRadarIcon("right.gif"));
   
               // Reduce the left and right margins of the left and right buttons.
               leftButton.setMargin(new Insets(0, 3, 0, 3));
               rightButton.setMargin(new Insets(0, 3, 0, 3));
   
               final DamaskCamera camera = (DamaskCamera)canvas.getCamera();
               
               topButton.addMouseListener(
                  new PanButtonMouseHandler(camera, 0, 1));
               bottomButton.addMouseListener(
                  new PanButtonMouseHandler(camera, 0, -1));
               rightButton.addMouseListener(
                  new PanButtonMouseHandler(camera, -1, 0));
               leftButton.addMouseListener(
                  new PanButtonMouseHandler(camera, 1, 0));
   
               mainPanel.add(topButton, BorderLayout.NORTH);
               mainPanel.add(bottomButton, BorderLayout.SOUTH);
               mainPanel.add(rightButton, BorderLayout.EAST);
               mainPanel.add(leftButton, BorderLayout.WEST);
               mainPanel.add(canvas, BorderLayout.CENTER);

               tabPaneContent.add(mainPanel);
            }

            tabPane.addTab(deviceType.toString(), tabPaneContent);
   
            // Used to retrieve the zoom slider later in listenToCurrentCanvas()
            tabPaneContent.putClientProperty(PROPERTY_SLIDER, zoomSlider);
            
            // Used to retrieve the canvas later in listenToCurrentCanvas()
            tabPaneContent.putClientProperty(PROPERTY_CANVAS, canvas);
         }

      }
      content.setLayout(new BorderLayout());
      content.add(tabPane, BorderLayout.CENTER);
      
      addCanvasChangeListener(tabListener);
      
      // Set up the toolbox along the left 
      content.add(toolbox, BorderLayout.WEST);
      
      updateTitleBar();

      // Do not automatically close window when "close window" button is
      // pressed
      setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
      addWindowListener(winHandler);
      addWindowFocusListener(winHandler);
      
      // Set up a glass pane which will intercept and swallow all events.
      // The glass pane will be visible only when the DENIM design is being
      // saved.
      setGlassPane(new EventSwallowerGlassPane());
      
      // Set up the menu bar
      final JMenuBar menuBar = new JMenuBar();
      setJMenuBar(menuBar);
      
      {
         final JMenu fileMenu = new JMenu("File");
         fileMenu.setMnemonic('F');
      
         {
            final JMenuItem fileNewItem = new JMenuItem(newAction);
            fileMenu.add(fileNewItem);
         }
         
         {
            final JMenuItem fileOpenItem = new JMenuItem(openAction);
            fileMenu.add(fileOpenItem);
         }
         
         {
            final JMenuItem fileCloseItem = new JMenuItem(new FileCloseAction());
            fileMenu.add(fileCloseItem);
         }
         
         fileMenu.add(new JSeparator());

         {
            final JMenuItem fileSaveItem = new JMenuItem(saveAction);
            fileMenu.add(fileSaveItem);
         }
         
         {      
            final JMenuItem saveAsItem = new JMenuItem(new SaveAsAction());
            fileMenu.add(saveAsItem);
         }

         fileMenu.add(new JSeparator());

         {
            final JMenuItem fileExportAsImageItem = new JMenuItem(new ExportAsImageAction());
            fileMenu.add(fileExportAsImageItem);
         }

         {
            fileExportAsVoiceXMLItem = new JMenuItem(new ExportAsVoiceXMLAction());
            fileMenu.add(fileExportAsVoiceXMLItem);
         }
         
         // Only add Exit if Damask is not running on a Mac
         if (!DamaskAppUtils.isMac()) {
            fileMenu.add(new JSeparator());

            final JMenuItem editRedoItem = new JMenuItem(new ExitAction());
            fileMenu.add(editRedoItem);
         }
         
         menuBar.add(fileMenu);
      }

      {      
         final JMenu editMenu = new JMenu("Edit");
         editMenu.setMnemonic('E');
      
         final JMenuItem editUndoItem = new JMenuItem(undoAction);
         undoAction.setEnabled(false);
         editMenu.add(editUndoItem);
      
         final JMenuItem editRedoItem = new JMenuItem(redoAction);
         redoAction.setEnabled(false);
         editMenu.add(editRedoItem);

         editMenu.add(new JSeparator());

         // action in updateCurrentCanvas()
         editCutItem = new JMenuItem();
         editMenu.add(editCutItem);

         // action in updateCurrentCanvas()
         editCopyItem = new JMenuItem();
         editMenu.add(editCopyItem);

         // action in updateCurrentCanvas()
         editPasteItem = new JMenuItem();
         editMenu.add(editPasteItem);

         // action in updateCurrentCanvas()
         editDeleteItem = new JMenuItem();
         editMenu.add(editDeleteItem);

         menuBar.add(editMenu);
      }
      
      {      
         final JMenu viewMenu = new JMenu("View");
         viewMenu.setMnemonic('V');

         viewTemplatesItem =
            new JCheckBoxMenuItem(new TemplatePaneAction());
         viewMenu.add(viewTemplatesItem);
         
         viewMenu.add(new JSeparator());
         
         viewRadarItem = new JCheckBoxMenuItem(new ViewRadarAction());
         viewMenu.add(viewRadarItem);
         
         viewPatternItem = new JCheckBoxMenuItem(new ViewPatternAction());
         final PatternBrowser browser = DamaskApp.getPatternBrowserReference();
         if (browser != null) {
            viewPatternItem.setState(browser.isVisible());
         }
         if (Damask.PATTERNS_AND_LAYERS) {
            viewMenu.add(viewPatternItem);
         }
         
         menuBar.add(viewMenu);
      }
      
      {
         pageMenu = new JMenu("Page");
         pageMenu.setMnemonic('P');
      
         // action in updateCurrentCanvas()
         pageCutItem = new JMenuItem();
         pageMenu.add(pageCutItem);

         // action in updateCurrentCanvas()
         pageCopyItem = new JMenuItem();
         pageMenu.add(pageCopyItem);

         // action in updateCurrentCanvas()
         pagePasteItem = new JMenuItem();
         pageMenu.add(pagePasteItem);

         // action in updateCurrentCanvas()
         pageDeleteItem = new JMenuItem();
         pageMenu.add(pageDeleteItem);

         pageMenu.add(new JSeparator());

         // action in updateCurrentCanvas()
         pageSetHomeItem = new JMenuItem();
         pageMenu.add(pageSetHomeItem);

         menuBar.add(pageMenu);
      }

      {
         contentMenu = new JMenu("Content");
         contentMenu.setMnemonic('C');

         {         
            ButtonGroup displayModeGroup = new ButtonGroup();
      
            // action in updateCurrentCanvas()
            contentInkItem = new JRadioButtonMenuItem();
            displayModeGroup.add(contentInkItem);
            contentMenu.add(contentInkItem);

            // action in updateCurrentCanvas()
            contentTextItem = new JRadioButtonMenuItem();
            displayModeGroup.add(contentTextItem);
            contentMenu.add(contentTextItem);

            // action in updateCurrentCanvas()
            contentPictureItem = new JRadioButtonMenuItem();
            displayModeGroup.add(contentPictureItem);
            contentMenu.add(contentPictureItem);

            contentMixedItem = new JRadioButtonMenuItem();
            displayModeGroup.add(contentMixedItem);
            
            // add a listener to this menu
            contentMenu.addMenuListener(new MenuListener() {
               public void menuSelected(MenuEvent e) {
                  final VisualCanvas visualCanvas = (VisualCanvas)currentCanvas;
                  final Collection selectedLabels =
                     visualCanvas.getSelectedLabels();

                  // If there are no selected labels, unselect all of the
                  // display modes in the Content menu.
                  if (selectedLabels.isEmpty()) {
                     contentMixedItem.setSelected(true);
                  }
                  else {
                     // Figure out which display mode in the Content menu to
                     // select.
                     final Content.DisplayMode selectedDisplayMode =
                        visualCanvas.getSelectedLabelsMode();
            
                     // Select the proper display mode in the Content menu,
                     // depending the display mode of the selected labels.
                     if (selectedDisplayMode == Content.INK) {
                        contentInkItem.setSelected(true);
                     }
                     else if (selectedDisplayMode == Content.TEXT) {
                        contentTextItem.setSelected(true);
                     }
                     else if (selectedDisplayMode == Content.IMAGE) {
                        contentPictureItem.setSelected(true);
                     }
                     // If the selected labels do not all share the same
                     // display mode, unselect all of the display modes
                     // in the Content menu.
                     else {
                        contentMixedItem.setSelected(true);
                     }
                  }                  
               }
               
               public void menuCanceled(MenuEvent e) {
               }

               public void menuDeselected(MenuEvent e) {
               }
            });
         }
         
         contentMenu.add(new JSeparator());

         // action in updateCurrentCanvas()
         contentChangePictureItem = new JMenuItem();
         contentMenu.add(contentChangePictureItem);

         menuBar.add(contentMenu);
      }

      {
         runMenu = new JMenu("Run");
         runMenu.setMnemonic('R');
         
         // action in updateCurrentCanvas()
         runFromHomeItem = new JMenuItem();
         runMenu.add(runFromHomeItem);

         // action in updateCurrentCanvas()
         runFromSelectedPageItem = new JMenuItem();
         runMenu.add(runFromSelectedPageItem);

         menuBar.add(runMenu);
      }

      
      {      
         windowMenu = new JMenu("Window");
         windowMenu.setMnemonic('W');
      
         if (!DamaskAppUtils.isMac()) {
            windowMenu.add(new JMenuItem(new NewWindowAction()));
            windowMenu.add(new JMenuItem(new CloseWindowAction()));
         }
         else {
            windowMenu.add(new JMenuItem(new CloseWindowAction()));
            windowMenu.add(new JMenuItem(new NewWindowAction()));
         }
         windowMenu.add(new JSeparator());
         FIRST_OPEN_WINDOW_POS = 3;
         
         updateTitleBar();
      
         menuBar.add(windowMenu);
      }
      
      // Change the state of undo and redo actions to reflect
      // change in command queue
      final VerboseCommandQueue q = canvasGroup.getDocument().getCommandQueue();
      q.addCommandListener(commandListener);
      undoAction.setEnabled(q.canUndo());
      redoAction.setEnabled(q.canRedo());

      // Setup the toolbar. This must happen after setting up the main menus.
      content.add(toolbar, BorderLayout.NORTH);
      
      // Listen for command events from the current canvas,
      // and send keyboard shortcuts and mouse wheel events to
      // the current canvas
      updateCurrentCanvas();
      
      // Keep track of this frame.
      allFrames.add(this);
      updateAllWindowMenus();
      
      // Create a radar view.
      radarView = new DamaskRadarDialog(this);
      
      // Set the initial location of the radar view.
      radarView.setLocation(
         getX() + getWidth() - radarView.getWidth(),
         getY() + getHeight() - radarView.getHeight());
      radarView.setVisible(
         Preferences.userNodeForPackage(DamaskApp.class).getBoolean(
            DamaskApp.PROP_RADAR_VISIBLE,
            true));
      logger.info(this + " created");
   }


   /**
    * Initializes the frame.This should be called right after the constructor.
    */
   public void initialize() {
      toolbar.initialize();
      toolbox.initialize();
   }


   // Overrides method in super.
   public void dispose() {
      logger.info(this + " closed");
      // Remove this frame from allFrames before doing anything else, since
      // allFrames is a SortedSet that depends on comparing the names of the
      // frames, and the names of the frames will change in the code below
      // this.
      allFrames.remove(this);

      // Stop listening for events from ALL open documents.
      for (Iterator i = DamaskApp.getDocuments().iterator(); i.hasNext(); ) {
         final DamaskDocument doc = (DamaskDocument)i.next();
         doc.removeDocumentListener(docListener);
      }
      tabPane.removeChangeListener(tabListener);
      getDocument().removeCanvasGroup(canvasGroup);
      // Update title bars of frames with the same document
      for (Iterator i = getDocument().getWindows().iterator(); i.hasNext(); ) {
         final DamaskFrame frame = (DamaskFrame)i.next();
         frame.updateTitleBar();
      }
      updateAllWindowMenus();
      
      super.dispose();
   }


   /**
    * Returns a set of all of the DamaskFrames that are open.
    */
   public static Set/*<DamaskFrame>*/ getAllDamaskFrames() {
      return Collections.unmodifiableSet(allFrames);
   }
   
   
   /**
    * Returns the canvas group contained in this frame.
    */
   public DamaskCanvasGroup getCanvasGroup() {
      return canvasGroup;
   }
   
   /**
    * Returns the current canvas contained in this frame.
    */
   public DamaskCanvas getCurrentCanvas() {
      // Make sure we're listening to the right canvas.
      final DamaskCanvas realCurrentCanvas =
         (DamaskCanvas)
            ((JComponent)tabPane.getSelectedComponent()).getClientProperty(
            PROPERTY_CANVAS);

      if (realCurrentCanvas != currentCanvas) {
         updateCurrentCanvas();
      }

      return currentCanvas;
   }
   
   /**
    * Makes the specified listener to listen for when the user changes the
    * canvas being displayed.
    */
   public void addCanvasChangeListener(final ChangeListener listener) {
      tabPane.addChangeListener(listener);
   }
   
   /**
    * Makes the specified listener stop listening for when the user changes
    * the canvas being displayed.
    */
   public void removeCanvasChangeListener(final ChangeListener listener) {
      tabPane.removeChangeListener(listener);
   }
   
   /**
    * Refreshes the frame so that it reflects and acts on the current
    * canvas. 
    */
   private void updateCurrentCanvas() {
      // If we're already listening to the actual current canvas, don't do
      // anything.
      final DamaskCanvas realCurrentCanvas =
         (DamaskCanvas)
            ((JComponent)tabPane.getSelectedComponent()).getClientProperty(
            PROPERTY_CANVAS);
      
      if (currentCanvas == realCurrentCanvas) {
         return;
      }
      
      currentCanvas = realCurrentCanvas;

      // Change actions of menu items to reflect current canvas
      editCutItem.setAction(currentCanvas.getCutAction());
      editCopyItem.setAction(currentCanvas.getCopyAction());
      editPasteItem.setAction(currentCanvas.getPasteAction());
      editDeleteItem.setAction(currentCanvas.getDeleteAction());

      runFromHomeItem.setAction(currentCanvas.getRunFromHomeAction());
      runFromSelectedPageItem.setAction(
         currentCanvas.getRunFromSelectedPageAction());

      pageCutItem.setAction(currentCanvas.getCutPageAction());
      pageCopyItem.setAction(currentCanvas.getCopyPageAction());
      pagePasteItem.setAction(currentCanvas.getPastePageAction());
      pageDeleteItem.setAction(currentCanvas.getDeletePageAction());
      pageSetHomeItem.setAction(currentCanvas.getSetHomePageAction());
      
      if (currentCanvas instanceof VisualCanvas) {
         final VisualCanvas visualCanvas = (VisualCanvas)currentCanvas;

         pageMenu.setText("Page");
         pageMenu.setMnemonic(KeyEvent.VK_P);
         
         contentMenu.setVisible(true);
         contentInkItem.setAction(
            visualCanvas.getChangeContentDisplayModeAction(Content.INK));
         contentTextItem.setAction(
            visualCanvas.getChangeContentDisplayModeAction(Content.TEXT));
         contentPictureItem.setAction(
            visualCanvas.getChangeContentDisplayModeAction(Content.IMAGE));
         contentChangePictureItem.setAction(
            visualCanvas.getChangeContentPictureAction());
      }
      else {
         pageMenu.setText("Form");
         pageMenu.setMnemonic(KeyEvent.VK_O);
         
         contentMenu.setVisible(false);
      }
      
      // Change the state of View->Templates
      viewTemplatesItem.setSelected(
         canvasWithVisibleTemplates.contains(currentCanvas));
      
      logger.info(this + ": Current canvas is now " + currentCanvas.getDeviceType());
   }


   /**
    * Returns the document displayed in this frame.
    */
   public DamaskDocument getDocument() {
      return canvasGroup.getDocument();
   }
   
   
   /**
    * Returns how the file name of this frame is represented in the title bar.
    */
   protected String getFileNameInTitleBar() {
      final StringBuffer sb =
         new StringBuffer(getDocument().getDisplayedFileName());

      if (getDocument().getCanvasGroups().size() > 1) {
         int windowNumber = getDocument().getCanvasGroupIndex(canvasGroup);
         sb.append(":");
         sb.append(windowNumber + 1);
      }

      // On Macs, if there are unsaved changes, put a dark red dot in the
      // red close button. 
      if (DamaskAppUtils.isMac()) {
         getRootPane().putClientProperty(
            "windowModified",
            Boolean.valueOf(getDocument().isModified()));
      }
      
      // On other machines, put a * if there are unsaved changes.
      else {
         if (getDocument().isModified()) {
            sb.append("*");
         }
      }

      return sb.toString();
   }

   
   /**
    * Updates the text of the title bar to reflect the document's name,
    * modified status, and window number.
    */
   private void updateTitleBar() {
      final StringBuffer sb = new StringBuffer(getFileNameInTitleBar());
      if (!DamaskAppUtils.isMac()) {
         sb.append(" - Damask");
      }
      final String titleBarString = sb.toString(); 

      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            setTitle(titleBarString);
         }
      });
   }


   
   /**
    * Updates the items in the Window menu to reflect the document's name,
    * modified status, and window number.
    */
   private static void updateAllWindowMenus() {
      // Add the sorted list of the frames' file names to the Window menu.
      // Put a radio button next to *this* frame.  
      for (Iterator i = allFrames.iterator(); i.hasNext(); ) {
         final DamaskFrame frame = (DamaskFrame)i.next();
         
         frame.updateWindowMenu();
      }
   }

   
   /**
    * Updates the items in the Window menu to reflect the document's name,
    * modified status, and window number.
    */
   private void updateWindowMenu() {
      // Add the sorted list of the frames' file names to the Window menu.
      // Put a radio button next to *this* frame.  
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            // Clear the open windows list
            for (int i = windowMenu.getItemCount() - 1;
               i >= FIRST_OPEN_WINDOW_POS;
               i--) {
               
               windowMenu.remove(i);
            }
            
            // Create a new open windows list
            int count = 1;
            for (Iterator i = allFrames.iterator(); i.hasNext(); ) {
               final DamaskFrame frameInMenu = (DamaskFrame)i.next();
               final JMenuItem rbMenuItem =
                  new JRadioButtonMenuItem(
                     new SwitchWindowAction(
                        count,
                        frameInMenu,
                        frameInMenu.getFileNameInTitleBar()));
               
               windowMenu.add(rbMenuItem);
               
               if (frameInMenu == DamaskFrame.this) {
                  rbMenuItem.setSelected(true);
               }
               count++;
            }
         }
      });
   }


   /**
    * Tries to close this frame, prompting if this frame is the only frame
    * to contains the frame's document (other frames may also have this
    * document), and the document isn't saved. 
    * 
    * @return true if the frame is closed 
    */
   public boolean tryClose() {
      // If this is the only frame that contains this document, then
      // we may need to prompt before closing this frame.
      // We assume that a canvas group can only be in one window.
      if (getDocument().getCanvasGroups().size() == 1) {
         return getDocument().tryClose(DamaskFrame.this);
      }
      else {
         setVisible(false);
         dispose();
         return true;
      }
   }
   

   /**
    * Enables or disables the close button.
    */
   public void setCloseButtonEnabled(boolean flag) {
      if (flag) {
         addWindowListener(winHandler);
      }
      else {
         removeWindowListener(winHandler);
      }
   }


   /**
    * Enables or disables the ability for the contents of this window to
    * handle events.
    */
   public void setContentsEnabled(boolean flag) {
      getGlassPane().setVisible(!flag);
   }

   
   // @Override
   public String toString() {
      return DamaskUtils.toShortString(this) + " (" + getFileNameInTitleBar() + ")";
   }

   
   /**
    * Returns the radar view.
    */
   public DamaskRadarDialog getRadarDialog() {
      return radarView;
   }


   /**
    * Called by DamaskRadarDialog when its visibility is changed.
    */
   public void onRadarDialogVisibleChanged(final boolean flag) {
      // Select or deselect the menu item
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            viewRadarItem.setSelected(flag);
         }
      });
   }


   /**
    * Called by PatternBrowser when its visibility is changed.
    */
   public void onPatternBrowserVisibleChanged(final boolean flag) {
      // Select or deselect the menu item
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            viewPatternItem.setState(flag);
         }
      });
   }
   
   
   
   /**
    * Returns the action that creates a new document.
    */
   public Action getNewAction() {
      return newAction;
   }
   
   /**
    * Returns the action that opens a document.
    */
   public Action getOpenAction() {
      return openAction;
   }
   
   /**
    * Returns the action that saves the current document.
    */
   public Action getSaveAction() {
      return saveAction;
   }
   
   /**
    * Returns the action that undoes the previous command.
    */
   public Action getUndoAction() {
      return undoAction;
   }
   
   /**
    * Returns the action that undoes the previous command.
    */
   public Action getRedoAction() {
      return redoAction;
   }

   
//   /**
//    * Sets up the pie menu.
//    */
//   private void setupPieMenu() {
//      PieMenu pieMain      = new PieMenu();
//      PieMenu pieFile      = new PieMenu("File");
//      PieMenu pieEdit      = new PieMenu("Edit");
//      PieMenu pieHelp      = new PieMenu("Help");
//      PieMenu pieTransform = new PieMenu("Rotate /\nZoom");
//
//      //// 1. Pie menu layout.
//      pieMain.add(pieFile);
//         pieFile.add("Open\nImages").addActionListener(new OpenImageListener());
//         pieFile.add("Open\nPoster");
//         pieFile.add("Save\nPoster");
//      pieMain.add(pieHelp);
//         pieHelp.add("About");
//         pieHelp.add("Search");
//         pieHelp.add(pieTransform);
//            pieTransform.add("Zoom\nIn");
//            pieTransform.add("Rotate\nLeft");
//            pieTransform.add("Zoom\nOut");
//            pieTransform.add("Rotate\nRight");
//      pieMain.add("Color").addActionListener(new ColorListener());
//      pieMain.add(pieEdit);
//         pieEdit.add("Undo").addActionListener(new UndoAction());
//         pieEdit.add("Redo").addActionListener(new RedoAction());
//         pieEdit.add("Cut").addActionListener(new CutListener());
//         pieEdit.add("Copy").addActionListener(new CopyListener());
//         pieEdit.add("Paste").addActionListener(new PasteListener());
//         pieEdit.add("Delete").addActionListener(new DeleteListener());
//
//      //// 2. Other pie menu initializations.
//      pieMain.addPieMenuTo(this);
//      pieMain.setLineNorth(true);
//      //pieMain.setAllTapHoldOpen();
//   } // of setupPieMenu


   /**
    * Listens for new actions.
    */
   private class NewAction extends AbstractAction {
      public NewAction() {
         super("New");
         putValue(SHORT_DESCRIPTION, "Creates a new document");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_N));
         putValue(
            ACCELERATOR_KEY,
            KeyStroke.getKeyStroke(
               'N',
               Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("new.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("new.png"));
      }
      
      public void actionPerformed(ActionEvent e) {
         final DamaskFrame newFrame = DamaskApp.createNewDocument();
         newFrame.setBounds(
            getX() + NEW_WINDOW_OFFSET,
            getY(),
            getWidth(),
            getHeight());

         newFrame.radarView.setLocation(
            newFrame.getX() + newFrame.getWidth() - radarView.getWidth(),
            newFrame.getY() + newFrame.getHeight() - radarView.getHeight());
         newFrame.radarView.setVisible(radarView.isVisible());
      }
   }


   /**
    * Listens for open actions.
    */
   private class OpenAction extends AbstractAction {
      public OpenAction() {
         super("Open...");
         putValue(SHORT_DESCRIPTION, "Opens this document");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_O));
         putValue(
            ACCELERATOR_KEY,
            KeyStroke.getKeyStroke(
               'O',
               Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("open.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("open.png"));
      }
      
      public void actionPerformed(ActionEvent e) {
         final File newFile =
            FileDialogUtils.showDamaskOpenDialog(DamaskFrame.this);

         if (newFile != null) {
            // If the file is already open, then switch to that window.
            for (Iterator i = allFrames.iterator(); i.hasNext(); ) {
               final DamaskFrame aFrame = (DamaskFrame)i.next();
               if (newFile.equals(aFrame.getDocument().getFile())) {
                  aFrame.toFront();
                  return;
               }
            }
            
            // Otherwise, open the file in a new window.
            try {
               final DamaskFrame newFrame = DamaskApp.openDocument(newFile);
               
               final boolean emptyDocument = (!getDocument().isModified() &&
                   (getDocument().getFile() == null));

               final int newWindowOffset;
               if (emptyDocument) {
                  newWindowOffset = 0;
               }
               else {
                  newWindowOffset = NEW_WINDOW_OFFSET;
               }
               newFrame.setBounds(
                  getX() + newWindowOffset,
                  getY(),
                  getWidth(),
                  getHeight());
   
               newFrame.radarView.setLocation(
                  newFrame.getX() + newFrame.getWidth() - radarView.getWidth(),
                  newFrame.getY()
                     + newFrame.getHeight()
                     - radarView.getHeight());
               newFrame.radarView.setVisible(radarView.isVisible());
               
               if (emptyDocument) {
                  tryClose();
               }
            }
            catch (JAXBException e1) {
               JOptionPane.showMessageDialog(
                  DamaskFrame.this,
                  "There is a problem opening "
                     + newFile
                     + ".\n\n"
                     + e1.getMessage(),
                  "Damask",
                  JOptionPane.ERROR_MESSAGE);
               DamaskAppExceptionHandler.log(e1);
            }
         }
      }
   }


   /**
    * Listens for close actions.
    */
   private class FileCloseAction extends AbstractAction {
      public FileCloseAction() {
         super("Close");
         putValue(SHORT_DESCRIPTION, "Closes this document");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_C));
         putValue(
            ACCELERATOR_KEY,
            KeyStroke.getKeyStroke(
               'W',
               Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
      }
      
      public void actionPerformed(ActionEvent e) {
         getDocument().tryClose(DamaskFrame.this);
      }
   }


   /**
    * Listens for save actions.
    */
   private class SaveAction extends AbstractAction {
      public SaveAction() {
         super("Save");
         putValue(Action.SHORT_DESCRIPTION, "Saves this document");
         putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_S));
         putValue(
            ACCELERATOR_KEY,
            KeyStroke.getKeyStroke(
               'S',
               Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("save.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("save.png"));
      }
      
      public void actionPerformed(ActionEvent e) {
         getDocument().trySave(DamaskFrame.this);
      }
   }


   /**
    * Listens for save as actions.
    */
   private class SaveAsAction extends AbstractAction {
      public SaveAsAction() {
         super("Save As...");
         putValue(SHORT_DESCRIPTION, "Saves this document with a new name");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_A));
         if (DamaskAppUtils.isMac()) {
            putValue(
               ACCELERATOR_KEY,
               KeyStroke.getKeyStroke(
                  KeyEvent.VK_S,
                  (java.awt.event.InputEvent.SHIFT_MASK
                     | Toolkit.getDefaultToolkit().getMenuShortcutKeyMask())));
         }
      }
      
      public void actionPerformed(ActionEvent e) {
         getDocument().trySaveAs(DamaskFrame.this);
      }
   }


   /**
    * Listens for save as actions.
    */
   private class ExportAsVoiceXMLAction extends AbstractAction {
      public ExportAsVoiceXMLAction() {
         super("Export as VoiceXML...");
         putValue(SHORT_DESCRIPTION, "Exports the voice portion of this document as a VoiceXML document");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_V));
      }
      
      public void actionPerformed(ActionEvent e) {
         getDocument().tryExportAsVoiceXML(DamaskFrame.this);
      }
   }


   /**
    * Listens for save as actions.
    */
   private class ExportAsImageAction extends AbstractAction {
      public ExportAsImageAction() {
         super("Export as Image...");
         putValue(SHORT_DESCRIPTION, "Exports the current tab as an image");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_E));
      }
      
      public void actionPerformed(ActionEvent e) {
         getCurrentCanvas().tryExportAsImage(DamaskFrame.this);
      }
   }


   /**
    * Listens for exit actions.
    */
   private class ExitAction extends AbstractAction {
      public ExitAction() {
         super("Exit");
         putValue(SHORT_DESCRIPTION, "Exits Damask");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_X));
      }
      
      public void actionPerformed(ActionEvent e) {
         DamaskApp.tryExit();
      }
   }


   /**
    * Listens for undo actions.
    */
   private class UndoAction extends AbstractAction {
      public UndoAction() {
         super("Undo");
         putValue(SHORT_DESCRIPTION, "Undoes the last action");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_U));
         putValue(
            ACCELERATOR_KEY,
            KeyStroke.getKeyStroke(
               'Z',
               Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("undo.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("undo.png"));
      }
      
      public void actionPerformed(ActionEvent e) {
         canvasGroup.getDocument().getCommandQueue().undo();
      }
   }


   /**
    * Listens for redo actions.
    */
   private class RedoAction extends AbstractAction {
      public RedoAction() {
         super("Redo");
         putValue(SHORT_DESCRIPTION, "Redoes the last action");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_R));
         putValue(
            ACCELERATOR_KEY,
            KeyStroke.getKeyStroke(
               'Y',
               Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("redo.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("redo.png"));
      }
      
      public void actionPerformed(ActionEvent e) {
         canvasGroup.getDocument().getCommandQueue().redo();
      }
   }


   /**
    * Listens for view radar actions.
    */
   private class ViewRadarAction extends AbstractAction {
      public ViewRadarAction() {
         super("Thumbnail");
         putValue(SHORT_DESCRIPTION, "Displays a thumbnail view of your design");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_H));
      }
      
      public void actionPerformed(ActionEvent e) {
         radarView.setVisible(!radarView.isVisible());
      }
   }

   
   /**
    * Listens for view pattern browser actions.
    */
   private class ViewPatternAction extends AbstractAction {
      public ViewPatternAction() {
         super("Pattern Browser");
         putValue(SHORT_DESCRIPTION, "Displays the pattern browser");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_P));
      }

      public void actionPerformed(ActionEvent e) {
         final Cursor oldCursor = getCursor();
         setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
         
         final PatternBrowser patternBrowser = DamaskApp.getPatternBrowser();
         patternBrowser.setVisible(!patternBrowser.isVisible());
         
         setCursor(oldCursor);
      }
   }
   

   /**
    * Listens for new window actions.
    */
   private class NewWindowAction extends AbstractAction {
      public NewWindowAction() {
         super("New Window");
         putValue(SHORT_DESCRIPTION, "Creates a new window for this document");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_N));
      }
      
      public void actionPerformed(ActionEvent e) {
         final DamaskFrame newFrame =
            new DamaskFrame(getDocument().createCanvasGroup());
         newFrame.initialize();
      
         newFrame.setBounds(
            getX() + NEW_WINDOW_OFFSET,
            getY(),
            getWidth(),
            getHeight());
         newFrame.setVisible(true);

         newFrame.radarView.setLocation(
            newFrame.getX() + newFrame.getWidth() - radarView.getWidth(),
            newFrame.getY() + newFrame.getHeight() - radarView.getHeight());
         newFrame.radarView.setVisible(radarView.isVisible());
         
         updateTitleBar();
      }
   }


   /**
    * Listens for close window actions.
    */
   private class CloseWindowAction extends AbstractAction {
      public CloseWindowAction() {
         super("Close");
         putValue(SHORT_DESCRIPTION, "Closes this window");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_C));
      }
      
      public void actionPerformed(ActionEvent e) {
         tryClose();
      }
   }


   /**
    * Listens for actions to switch to another window.
    */
   private class SwitchWindowAction extends AbstractAction {
      private Window window;
      
      public SwitchWindowAction(
         final int index,
         final Window window,
         final String windowName) {

         if (index < 10) {
            putValue(NAME, Integer.toString(index) + " " + windowName);
         }
         else {
            putValue(NAME, windowName);
         }
         putValue(SHORT_DESCRIPTION, "Switches to this window");
         
         // Set the mnemonic to be the index value, e.g. '1'
         if (index >= 1 && index <= 9) {
            // index + (int)'0' converts index to the proper keycode
            putValue(MNEMONIC_KEY, new Integer(index + (int)'0'));
         }
         
         this.window = window;
      }
      
      public void actionPerformed(ActionEvent e) {
         window.toFront();
         if (e.getSource() instanceof JRadioButtonMenuItem) {
            
            // always show this window as selected
            if (window != DamaskFrame.this) {
               ((JRadioButtonMenuItem)e.getSource()).setSelected(false);
            }
            else {
               ((JRadioButtonMenuItem)e.getSource()).setSelected(true);
            }
         }
      }
   }


   private class TemplatePaneAction extends AbstractAction {
      public TemplatePaneAction() {
         super("Templates");
         putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_T));
      }

      public void actionPerformed(ActionEvent e) {
         final DamaskLayer layer = (DamaskLayer)currentCanvas.getLayer();
         final TemplatePane templatePane = layer.getTemplatePane();

         templatePane.setExpanded(
            currentCanvas.getCamera(),
            !templatePane.isExpanded(),
            true);
            
         if (templatePane.isExpanded()) {
            canvasWithVisibleTemplates.add(currentCanvas);
            templatePane.setVisibleToCamera(currentCanvas.getCamera());
            logger.info(DamaskFrame.this + ": Template pane visible");
         }
         else {
            canvasWithVisibleTemplates.remove(currentCanvas);
            logger.info(DamaskFrame.this + ": Template pane not visible");
         }
      }
   }


   /**
    * Responds to window events.
    */
   private class WindowHandler extends WindowAdapter {
      public void windowClosing(WindowEvent e) {
         tryClose();
      }

      public void windowGainedFocus(WindowEvent e) {
         DamaskApp.setCurrentFrame(DamaskFrame.this);
         
         final DamaskCamera camera = (DamaskCamera)currentCanvas.getCamera();
         final PLayer layer = currentCanvas.getLayer();
         if (layer instanceof DamaskLayer) {
            final TemplatePane templatePane =
               ((DamaskLayer)layer).getTemplatePane();
            templatePane.setVisibleToCamera(camera);
            templatePane.setExpanded(
               camera,
               canvasWithVisibleTemplates.contains(currentCanvas),
               false);
         }
         logger.info(DamaskFrame.this + " gained focus");
      }

      public void windowLostFocus(WindowEvent e) {
         final PLayer layer = currentCanvas.getLayer();
         if (layer instanceof DamaskLayer) {
            ((DamaskLayer)layer).getTemplatePane().setVisibleToCamera(null);
         }
         logger.info(DamaskFrame.this + " lost focus");
      }
   }
   
   
   /**
    * Listens for command events. 
    */
   private class CommandHandler implements CommandListener {
      private void updateActionsEnabledState(final CommandEvent e) {
         final CommandQueue q = e.getCommandQueue();
         undoAction.setEnabled(q.canUndo());
         redoAction.setEnabled(q.canRedo());
         
         // Change the active canvas if this frame has the focus
         if (isFocused()) {
            for (int i = 0, n = tabPane.getComponentCount(); i < n; i++) {
               final DamaskCanvas canvas =
                  (DamaskCanvas)
                     ((JComponent)tabPane.getComponentAt(i)).getClientProperty(
                        PROPERTY_CANVAS);
               if (canvas.getDeviceType() ==
                   ((DamaskCanvas)e.getCanvas()).getDeviceType()) {
                  tabPane.setSelectedIndex(i);
                  return;
               }
            }
         }
      }
      
      // Overrides method in interface.
      public void commandExecuted(CommandEvent e) {
         updateActionsEnabledState(e);
      }

      // Overrides method in interface.
      public void commandUndone(CommandEvent e) {
         updateActionsEnabledState(e);
      }

      // Overrides method in interface.
      public void commandRedone(CommandEvent e) {
         updateActionsEnabledState(e);
      }
   }


   /**
    * Handles change events from the tabbed pane. 
    */
   private class TabbedPaneListener implements ChangeListener {
      public void stateChanged(ChangeEvent e) {
         assert e.getSource()
            == tabPane : "Receiving events from "
               + e.getSource()
               + " instead of "
               + tabPane;
         updateCurrentCanvas();
      }
   }

   
   /**
    * Handles document events.  
    */
   private class DocumentHandler implements DocumentListener {

      public void documentModified(DocumentEvent e) {
         if (e.getDocument() == getDocument()) {
            updateTitleBar();
         }
         updateAllWindowMenus();
      }

      public void documentCleaned(DocumentEvent e) {
         if (e.getDocument() == getDocument()) {
            updateTitleBar();
         }
         updateAllWindowMenus();
      }

      public void documentRenamed(DocumentEvent e) {
         if (e.getDocument() == getDocument()) {
            updateTitleBar();
         }
         updateAllWindowMenus();
      }

      public void documentClosed(DocumentEvent e) {
         e.getDocument().removeDocumentListener(docListener);
      }

      public void documentBusyStarted(DocumentEvent e) {
         if (e.getDocument() == getDocument()) {
            //// Disable the window, so the user can't muck with anything while
            //// saving.
            setCloseButtonEnabled(false);
            setContentsEnabled(false);

            //// Set the cursor to the wait cursor.
            setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
         }
      }

      public void documentBusyStopped(DocumentEvent e) {
         if (e.getDocument() == getDocument()) {
            //// Enable the window.
            setContentsEnabled(true);
            setCloseButtonEnabled(true);
   
            //// Reset the cursor.
            setCursor(Cursor.getDefaultCursor());
         }
      }

      public void canvasGroupAdded(DocumentEvent e) {
      }

      public void canvasGroupRemoved(DocumentEvent e) {
      }
   }


   /**
    * A component that swallows all mouse events.  
    */
   private class EventSwallowerGlassPane extends JComponent {
      public EventSwallowerGlassPane() {
         final MouseInputAdapter emptyAdapter = new MouseInputAdapter() {};
         addMouseListener(emptyAdapter);
         addMouseMotionListener(emptyAdapter);
      }
   }
   
   
   /**
    * A comparator used to sort the names of the frames in the Window menu. 
    */
   private static class FrameNameComparator implements Comparator {
      public int compare(Object o1, Object o2) {
         if (!(o1 instanceof DamaskFrame)) {
            throw new ClassCastException(
               "o1 must be of type DamaskFrame, not "
                  + (o1 == null ? null : o1.getClass()));
         }
         if (!(o2 instanceof DamaskFrame)) {
            throw new ClassCastException(
               "o2 must be of type DamaskFrame, not "
                  + (o2 == null ? null : o2.getClass()));
         }

         final DamaskFrame f1 = (DamaskFrame)o1;
         final DamaskFrame f2 = (DamaskFrame)o2;
         return f1.getFileNameInTitleBar().compareTo(
            f2.getFileNameInTitleBar());
      }
   } 

   /**
    * Handles mouse events for the pan buttons. 
    */
   private class PanButtonMouseHandler implements MouseListener {
      private DamaskCamera camera;
      private double dx;
      private double dy;

      public PanButtonMouseHandler(
         final DamaskCamera camera, final double x, final double y) {
         
         this.camera = camera;
         this.dx = x;
         this.dy = y;
      }

      public void mouseClicked(MouseEvent event) {
      }

      public void mouseEntered(MouseEvent event) {
      }

      public void mouseExited(MouseEvent event) {
      }

      public void mousePressed(MouseEvent event) {
         camera.getPanActivity().setDirection(dx, dy);
         camera.setPanning(true);
      }

      public void mouseReleased(MouseEvent event) {
         camera.setPanning(false);
      }
   }
}
