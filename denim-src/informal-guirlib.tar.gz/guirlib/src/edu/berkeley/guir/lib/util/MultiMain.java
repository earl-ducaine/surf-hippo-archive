//// See bottom of source code for software license.
package edu.berkeley.guir.lib.util;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

/**
 * Class for running the <CODE>main()</CODE> methods
 * of several classes. Useful for running several different classes
 * in the same JVM.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Jan 08 2004 JIH
 */
public class MultiMain {

    //==========================================================================
    //===   INNER CLASS - THREAD RUNNER   ======================================

    static class ThreadRunner extends Thread {
        String[] argv;
        int      start;
        int      end;

        public ThreadRunner(String[] aArgv, int aStart, int aEnd) {
            argv  = aArgv;
            start = aStart;
            end   = aEnd;
        } // of constructor

        public void run() {
            runIndividualMainHelper(argv, start, end);
        } // of method
    } // of inner class

    //===   INNER CLASS - THREAD RUNNER   ======================================
    //==========================================================================



    //==========================================================================
    //===   CLASS VARIABLES   ==================================================

    static boolean flagSynchronous = false;

    //----------------------------------------------------------------

    /**
     * Load sync.
     */
    static protected void setSynchronous() {
        flagSynchronous = true;
    } // of method

    /**
     * Load async.
     */
    static protected void setAsynchronous() {
        flagSynchronous = false;
    } // of method

    //===   CLASS VARIABLES   ==================================================
    //==========================================================================



    //==========================================================================
    //===   CLASS LOADING   ====================================================

    /**
     * Get the main(String[]) method of the specified class.
     */
    public static Method getMain(String strClass) 
        throws ClassNotFoundException, NoSuchMethodException {

        //// 1. Load the desired class.
        Class cl = Class.forName(strClass);

        //// 2. Get the main() method.
        Method methodMain = cl.getMethod("main", new Class[] {
                                                     new String[0].getClass()
                                                 }
                            );

        //// 3. Return.
        return (methodMain);
    } // of method

    //----------------------------------------------------------------

    /**
     * Calculate index from start of one "-ccc" to next "-ccc" or end of argv.
     * @return [0] is start after "-ccc" (inclusive), [1] is end (exclusive).
     *         Negative values means error.
     */
    protected static int[] calcStartEnd(String[] argv, int start) {
        int     startIndex = -1;
        int     endIndex   = -1;
        boolean flagFound  = false;

        //// 1. Go thru the args.
        for (int i = start; i < argv.length; i++) {
            if ("-ccc".equals(argv[i])) {
                //// 1.1. If this is first time we've seen "-ccc",
                ////      save the start index.
                if (flagFound == false) {
                    startIndex = i;
                    flagFound = true;
                }
                //// 1.2. If we've seen "-ccc" before, this is the end index.
                else {
                    endIndex = i;
                    return (new int[] {startIndex, endIndex});
                }
            }
        }

        //// 2.1. If we are at the end and have not found anything, error.
        if (flagFound == false) {
            return (new int[] {-1, -1});
        }
        //// 2.2. Otherwise, endindex is just the length.
        else {
            return (new int[] {startIndex, argv.length});
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * @param start is the start index AFTER "-ccc" (inclusive)
     * @param end   is the end index (exclusive)
     */
    private static void runIndividualMain(String[] argv, 
                                          int argvStart, int argvEnd)
        throws ClassNotFoundException, NoSuchMethodException,
               IllegalAccessException, IllegalArgumentException,
               InvocationTargetException {

        //// 0. Debugging.
        if (false) {
            System.out.println("invoking: ");
            for (int i = argvStart; i < argvEnd; i++) {
                System.out.print(argv[i] + " ");
            }
            System.out.println();
        }

        //// 1. Copy argv subset into another array.
        String[] argvNew = new String[argvEnd - argvStart];
        for (int i = 0; i < argvNew.length; i++) {
            argvNew[i] = argv[argvStart + i];
        }

        //// 2. Get the main method.
        Method main = getMain(argv[argvStart]);

        //// 3. Invoke main.
        main.invoke(null, new Object[] {argvNew});
    } // of method

    //----------------------------------------------------------------

    /**
     * Just catches the exceptions.
     * @param start is the start index AFTER "-ccc" (inclusive)
     * @param end   is the end index (exclusive)
     */
    private static void runIndividualMainHelper(String[] argv, 
                                          int start, int end) {
        //// start + 1 to skip over the "-ccc" argument
        try {
            runIndividualMain(argv, start, end);
        }
        catch (Exception e) {
            StringBuffer strbuf = new StringBuffer();
            for (int i = start + 1; i < end; i++) {
                strbuf.append(argv[i]);
                strbuf.append(" ");
            }
            System.err.println("Failed to run: " + strbuf.toString() + " " +
                               start + " " + end);
            e.printStackTrace();
        }
    } // of method

    //----------------------------------------------------------------

    private static void runMultiMain(String[] argv) {
        int[] indexes;
        int   start = 0;    // start of "-ccc"
        int   end;

        //// 1. Go thru the args and find if "sync".
        for (int i = 0; i < argv.length; i++) {
            if ("-sync".equals(argv[i]) == true) {
                setSynchronous();
            }
        }

        //// 2. Run thru the args.
        while (start >= 0) {
            indexes = calcStartEnd(argv, start);
            start   = indexes[0];
            end     = indexes[1];
            // System.out.println("start: " + start);
            // System.out.println("end:   " + end);

            if (start < 0 || end < 0) {
                break;
            }

            //// Process the args
            //// Check if start + 1 == end, in which case is two
            //// consecutive "-ccc" args
            if (start + 1 != end) {
                if (flagSynchronous == true) {
                    runIndividualMainHelper(argv, start + 1, end);
                }
                else {
                    new ThreadRunner(argv, start + 1, end).start();
                }
            }

            //// Iterate
            start = end;
        }
    } // of method

    //===   CLASS LOADING   ====================================================
    //==========================================================================



    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static void runTestAAA() {
        String[] argv;

        argv = new String[] {
            "-ccc", "edu.berkeley.guir.lib.class1", 
            "-ccc", "edu.berkeley.guir.lib.class2", 
        };
        runMultiMain(argv);
        System.out.println();
        System.out.println();


        argv = new String[] { };
        runMultiMain(argv);
        System.out.println();
        System.out.println();


        argv = new String[] {
            "crap",
            "-ccc", "edu.berkeley.guir.lib.class3", 
            "-ccc", "edu.berkeley.guir.lib.class4", 
        };
        runMultiMain(argv);
        System.out.println();
        System.out.println();


        argv = new String[] {
            "crap,",
            "-ccc", "-ccc", "edu.berkeley.guir.lib.class5", 
        };
        runMultiMain(argv);
        System.out.println();
        System.out.println();

        argv = new String[] {
            "-ccc", "edu.berkeley.guir.lib.class6", "-c", "dog",
            "-ccc", "edu.berkeley.guir.lib.class7", "-m", "dog", "-v", "mouse",
            "-ccc", "edu.berkeley.guir.lib.class8",
        };
        runMultiMain(argv);
        System.out.println();
        System.out.println();
    } // of method

    //----------------------------------------------------------------

    /**
     * Use "-ccc" to specify classes and params. 
     * Use "-sync" to load and run synchronously, default is async.
     * For example:
     * <PRE>
     *    "-ccc class1 arg1 arg2 -ccc com.class2 -m arg3 -d arg4"
     * </PRE>
     * Here, "-ccc" means start of a new class. The "-m" is an argument passed
     * into com.class2 and has no semantic meaning here.
     */
    public static void main(String[] argv) {
        // runTestAAA();
        runMultiMain(argv);
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
