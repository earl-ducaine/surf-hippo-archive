//// See bottom of file for software license
package edu.berkeley.guir.lib.util;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Keeps a pool of Threads available to do work.
 * <P>
 * <H2>API </H2>
 * <UL>
 *    <LI>Call {@link #run(Runnable)} with a Runnable and it will 
 *        execute the job. Jobs are executed in the order they are received.
 * </UL>
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Aug 11 2002
 */
public class ThreadPool {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    private static final int DEFAULT_NUMTHREADS = 5;

    private static final boolean DEBUG = false;

    //===   CONSTANTS   ========================================================
    //==========================================================================





    //==========================================================================
    //===   DEBUG   ============================================================

    private static final void println(String str) {
        if (DEBUG == true) {
            System.out.println(str);
        }
    } // of method

    //===   DEBUG   ============================================================
    //==========================================================================






    //==========================================================================
    //===   THREAD INNER CLASS   ===============================================

    /**
     * A Thread for this ThreadPool.
     */
    class PoolThread extends Thread {
        Runnable job;

        /**
         * Create a Thread with a name.
         */
        public PoolThread(String strName) {
            super(strName);
        } // of constructor

        //------------------------------------------------------------

        /**
         * Tell the Thread to run this job.
         */
        public synchronized void run(Runnable newJob) {
            println(getName() + " starting new job...");
            assert newJob != null;
            job = newJob;
            notify();
        } // of method

        /**
         * Thread should already be running this when start() is called on it.
         */
        public synchronized void run() {
            //// 1. Run forever.
            while (true) {
                //// 2. See if we have a job to run.
                ////    If not, go to sleep.
                if (job == null) {
                    try {
                        println(getName() + " now sleeping...");
                        wait();
                        println(getName() + " awoken...");
                    }
                    catch (InterruptedException e) {
                        continue;
                    }
                }

                //// 3. Run the job.
                try {
                    println(getName() + " running job " + job.toString());
                    job.run();
                    println(getName() + " job completed...");
                }
                catch (Exception e) {
                    e.printStackTrace();
                }

                //// 4. We're done with the job, remove it.
                job = null;

                //// 5.1. If too many threads, then just let the Thread die.
                if (getNumActiveThreads() >= maxNumThreads) {
                    listRunningThreads.remove(this);
                    listAvailableThreads.remove(this);
                    println(getName() + " going away...");
                }
                //// 5.2. Remove ourselves from list of running workers.
                ////      Add ourselves back to the list of available workers.
                else {
                    listRunningThreads.remove(this);
                    listAvailableThreads.add(this);
                    println(getName() + " enqueued back to pool...");
                }
            }
        } // of method
    } // of method

    //===   THREAD INNER CLASS   ===============================================
    //==========================================================================






    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    //// Counter for thread names.
    int counter = 0;

    //// List of Threads.
    List listAvailableThreads = Collections.synchronizedList(new LinkedList());
    List listRunningThreads   = Collections.synchronizedList(new LinkedList());

    //// List of Runnable jobs
    List listRunnable = Collections.synchronizedList(new LinkedList());

    //// Create more Workers on the fly?
    boolean flagExpandable = false;

    //// Max number of threads. Meaningless if flagExpandable == false.
    int maxNumThreads = DEFAULT_NUMTHREADS;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================






    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    public ThreadPool() {
        createNThreads(maxNumThreads);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Create a new ThreadPool with the specified number of Threads
     * initially.
     */
    public ThreadPool(int newNumThreads) {
        maxNumThreads = newNumThreads;
        createNThreads(maxNumThreads);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Create a new ThreadPool with the specified number of Threads
     * initially. Also set whether or not the ThreadPool can add more Threads
     * if it needs to (default is false).
     */
    public ThreadPool(int newNumThreads, boolean newExpandable) {
        maxNumThreads  = newNumThreads;
        flagExpandable = newExpandable;
        createNThreads(maxNumThreads);
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================






    //==========================================================================
    //===   THREAD METHODS   ===================================================

    /**
     * Get the total number of threads we have.
     */
    private int getNumActiveThreads() {
        return (listAvailableThreads.size() + listRunningThreads.size());
    } // of method

    //----------------------------------------------------------------

    /**
     * Create the specified number of Threads.
     */
    private void createNThreads(int val) {
        assert val >= 0;
        for (int i = 0; i < val; i++) {
            createNewThread();
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a new Thread.
     */
    private PoolThread createNewThread() {
        println("creating new thread...");
        PoolThread t = new PoolThread("ThreadPool-Thread" + counter++);
        listAvailableThreads.add(t);
        t.start();
        return (t);
    } // of method

    //----------------------------------------------------------------

    /**
     * Spin-wait until another Thread is available.
     */
    private void waitForNextAvailableThread() {
        println("waiting for next available thread...");
        while (listAvailableThreads.isEmpty() == true) {
            try {
                Thread.yield();
                Thread.sleep(500);
            }
            catch (Exception e) {
                // ignore
            }
        }
        println("done waiting for next available thread...");
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the next Thread. Create one if allowed and if necessary.
     */
    private synchronized PoolThread getNextAvailableThread() {
        println("getting next available thread...");
        //// 1. See if we have any threads available...
        if (listAvailableThreads.isEmpty() == true) {
            //// 1.1. If not, check if we should create any more...
            if (flagExpandable == true) {
                createNewThread();
            }
            //// 1.2. ...else wait for next Thread.
            else {
                waitForNextAvailableThread();
            }
        }

        //// 2. Dequeue first available Thread.
        ////    Add it to the running Threads.
        PoolThread t = (PoolThread) listAvailableThreads.remove(0);
        listRunningThreads.add(t);
        println("returning available thread...");
        return (t);
    } // of method

    //===   THREAD METHODS   ===================================================
    //==========================================================================






    //==========================================================================
    //===   RUN   ==============================================================

    public void run(Runnable job) {
        PoolThread t = getNextAvailableThread();
        t.run(job);
    } // of method

    //===   RUN   ==============================================================
    //==========================================================================






    //==========================================================================
    //===   REGRESSION TESTS   =================================================
/*
    static class PrintJob implements Runnable {
        int val;

        public PrintJob(int newVal) {
            val = newVal;
        } // of method

        public void run() {
            try {
                Thread.sleep(500);
                System.out.println(this.toString());
                Thread.sleep(500);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        } // of method

        public String toString() {
            return ("PrintJob val " + val);
        } // of method
    } // of method

    //==========================================================================

    public static void main(String[] argv) {
        ThreadPool tpool = new ThreadPool(7, true);
        for (int i = 0; i < 13; i++) {
            tpool.run(new PrintJob(i));
        }
    } // of method
*/
    //===   REGRESSION TESTS   =================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
