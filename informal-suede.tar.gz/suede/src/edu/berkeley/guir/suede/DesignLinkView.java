package edu.berkeley.guir.suede;

import java.awt.*;

public class DesignLinkView extends AbstLinkView {
    private   PlayButton     m_playButton   = new PlayButton(false, BALLOON_FG);
    private   RecordButton   m_recordButton = new RecordButton(Color.black, BALLOON_FG);

    public DesignLinkView(SuedeModel model, LinkModel lm, SContentPane pane) {
       super(model, lm, pane);

       m_playButton.setBounds(getWidth() - BUTTON_WIDTH, 0, BUTTON_WIDTH, ARC);
       add(m_playButton);
       m_recordButton.setBounds(getWidth() - 2*BUTTON_WIDTH, 0, BUTTON_WIDTH, ARC);
       add(m_recordButton);

       // catch all of the events at the parent
       m_recordButton.addActionListener(lm);  
       setPlayable(lm.hasAudio());
       //m_playButton.addActionListener(lm);
    }


    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;
        
        // draw the lines in between the record and play buttons
        g2d.setStroke(AbstNodeView.PIXEL_STROKE);
        g2d.drawLine(getWidth() - 2*BUTTON_WIDTH, 0, getWidth() - 2*BUTTON_WIDTH, ARC);
        g2d.drawLine(getWidth() - BUTTON_WIDTH,   0, getWidth() - BUTTON_WIDTH,   ARC);
	}
	
	
	public void setPlayable(boolean b) {
      m_playButton.setPlayable(b);
      if(b) m_playButton.addActionListener(m_linkmodel);
   }

    
    public boolean isPlaying() {
      return !m_playButton.isSelected();
    }
    
    
    public boolean isRecording() {
      return !m_recordButton.isSelected();
    }
    
    public void setStopped() {
      m_recordButton.setSelected(false);
      m_playButton.setSelected(false);
    }
    
    public void setRecording() {
      m_recordButton.setSelected(true);
      m_playButton.setSelected(false);
    }
    
    public void setPlaying() {
      m_recordButton.setSelected(false);
      m_playButton.setSelected(true);
    }
    
    public void setPaused() {
      m_recordButton.setSelected(false);
      m_playButton.setSelected(false);
    }
    
    /*public void clickRecord() {
        System.out.println("we do indeed get here");
      //m_recordButton.doClick();   
    }*/
    
}
