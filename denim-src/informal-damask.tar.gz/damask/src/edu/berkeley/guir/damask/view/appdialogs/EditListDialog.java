package edu.berkeley.guir.damask.view.appdialogs;

import javax.swing.*;
import java.beans.*;
import java.awt.*;
import java.awt.event.*;

/**
 * A dialog box that asks the user to edit the contents of a list.
 *
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-26-2003 James Lin
 *                               Created EditListDialog
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 02-26-2003
 */
public class EditListDialog
   extends JDialog {

   private static final int  DEFAULT_WIDTH  = 420;
   private static final int  DEFAULT_HEIGHT = 200;

   private JTextArea textArea;
   private JOptionPane optionPane;
   private boolean isOK;


   public EditListDialog(String[] listItems) {
      super();
      commonInitializations(listItems);
   }


   public EditListDialog(Frame frame, String[] listItems, int x, int y) {
      super(frame, true);
      commonInitializations(listItems);
      setSizeAndPosition(x, y);
   }


   private void setSizeAndPosition(int x, int y) {
      // Set the size of this window
      int xbox = x - (DEFAULT_WIDTH/2);
      int ybox = y - DEFAULT_HEIGHT;

      // Make sure the window doesn't go off the screen
      if (xbox < 0) {
         xbox = 0;
      }
      if (ybox < 0) {
         ybox = 0;
      }

      Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
      if (xbox + DEFAULT_WIDTH > screenDim.width) {
         xbox -= (xbox + DEFAULT_WIDTH - screenDim.width);
      }

      if (ybox + DEFAULT_HEIGHT > screenDim.height) {
         ybox -= (ybox + DEFAULT_HEIGHT - screenDim.height);
      }

      setBounds(xbox, ybox, DEFAULT_WIDTH, DEFAULT_HEIGHT);
   }


   private void commonInitializations(String[] items) {
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < items.length; i++) {
         sb.append(items[i]);
         sb.append('\n');
      }
      textArea = new JTextArea(sb.toString());

      setTitle("Edit List");
      setResizable(false);

      //// 1. Set up the text box
      textArea.setRows(5);
      textArea.setColumns(4);
      textArea.setLineWrap(false);
      textArea.setWrapStyleWord(false);

      final JScrollPane areaScrollPane = new JScrollPane(textArea);
      areaScrollPane.setVerticalScrollBarPolicy
         (JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
      areaScrollPane.setPreferredSize(new Dimension(250, 70));

      //// 4. Set up the OK/Cancel buttons
      Object[] array = {"Enter the items in the list (one per line):",
                        areaScrollPane};

      optionPane = new JOptionPane(array,
                                   JOptionPane.PLAIN_MESSAGE,
                                   JOptionPane.OK_CANCEL_OPTION,
                                   null,
                                   null,
                                   null);
      setContentPane(optionPane);
      setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

      //// 5. Set up event listeners
      addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent we) {
            //
            // Instead of directly closing the window,
            // we're going to change the JOptionPane's
            // value property.
            //
            optionPane.setValue(new Integer(JOptionPane.CLOSED_OPTION));
         }
      });

      optionPane.addPropertyChangeListener(new PropertyChangeListener() {
         public void propertyChange(PropertyChangeEvent e) {
            //Debug.println("property change: ");
            //Debug.println("  source  : " + e.getSource().getClass());
            //Debug.println("  property: " + e.getPropertyName());
            //Debug.println("    from  : " + e.getOldValue());
            //Debug.println("    to    : " + e.getNewValue());

            String prop = e.getPropertyName();

            if (isVisible()
            && (e.getSource() == optionPane)
            && (prop.equals(JOptionPane.VALUE_PROPERTY) ||
                prop.equals(JOptionPane.INPUT_VALUE_PROPERTY))) {
               Object value = optionPane.getValue();

               if (value == JOptionPane.UNINITIALIZED_VALUE) {
                  //ignore reset
                  return;
               }

               // Reset the JOptionPane's value.
               // If you don't do this, then if the user
               // presses the same button next time, no
               // property change event will be fired.
               optionPane.setValue(JOptionPane.UNINITIALIZED_VALUE);

               if (value instanceof Integer &&
                   ((Integer)value).intValue() == JOptionPane.OK_OPTION) {
                  isOK = true;
                  setVisible(false);
               }
               else { // user closed dialog or clicked cancel
                  isOK = false;
                  setVisible(false);
               }
            }
         }
      });
   } // of method


   /**
    * Returns the items entered by the user into this dialog box.
    */
   public String[] getValues() {
      return textArea.getText().split("\n");
   }


   /**
    * Returns whether the dialog box was closed with OK.
    */
   public boolean wasOKPressed() {
      return isOK;
   }
}

//==============================================================================

/*
Copyright (c) 1999-2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
