package edu.berkeley.guir.damask.event;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;

/** 
 * A source of ElementContainerEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-10-2003 James Lin
 *                               Created InteractionElementContainerSource
 *                    08-13-2003 James Lin
 *                               Renamed to ElementContainerSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-10-2003
 */
public class ElementContainerSource {
   
   private Vector/*<ElementContainerListener>*/
      eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public synchronized void addElementContainerListener(
      final ElementContainerListener listener) {

      if (!eventListeners.contains(listener)) {      
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public synchronized void removeElementContainerListener(
      final ElementContainerListener listener) {

      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns an array of all the action listeners registered on this timer.
    * 
    * @return
    * all of the source's ElementContainerListener or an empty array if no
    * container listeners are currently registered
    */ 
   public ElementContainerListener[] getElementContainerListeners() {
      return (ElementContainerListener[])eventListeners.toArray();
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Fires elementAdded events to listeners.
    */
   public void fireElementAdded(
      final Object source,
      final DeviceType deviceType,
      final int index,
      final InteractionElement e) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ElementContainerEvent event =
         new ElementContainerEvent(
            source,
            ElementContainerEvent.ADDED,
            deviceType,
            index,
            e);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final ElementContainerListener listener =
            (ElementContainerListener)i.next();

         listener.elementAdded(event);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Fires elementRemoved events to listeners.
    */
   public void fireElementRemoved(
      final Object source,
      final DeviceType deviceType,
      final int index,
      final InteractionElement e) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ElementContainerEvent event =
         new ElementContainerEvent(
            source,
            ElementContainerEvent.REMOVED,
            deviceType,
            index,
            e);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final ElementContainerListener listener =
            (ElementContainerListener)i.next();

         listener.elementRemoved(event);
      }
   }

}
