//// See bottom of file for software license
package edu.berkeley.guir.lib.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * A map that is case insensitive when checking
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Dec 01 2002 JIH
 */
public class CaseInsensitiveMap
    extends MapWrapper {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    // (String strLowerCaseKey, String strKey)
    // used for preserving the case of original key names
    Map mapKeys = new HashMap();  

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    /**
     * Creates a new Case insensitive map using a HashMap 
     * as the underlying map.
     */
    public CaseInsensitiveMap() {
        super(new HashMap());
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Wrap around an existing Map and turn it into a case insensitive map.
     * Assumes that the map is empty and things will be added (ie does
     * not reliably work for a Map that already has things)
     * @param map is a new Map instance.
     */
    public CaseInsensitiveMap(Map map) {
        this();
        putAll(map);
    } // of constructor

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================




    //==========================================================================
    //===   DELEGATION METHODS   ===============================================

    public boolean containsKey(Object key) {
        if (key instanceof String) {
            //// 1. Check a lowercase version of the key.
            String strKey = (String) key;
            return (mapKeys.containsKey(strKey.toLowerCase()));
        }
        else {
            return (super.containsKey(key));
        }
    } // of method

    //----------------------------------------------------------------

    public Object put(Object key, Object val) {
        if (key instanceof String) {
            //// 1. Store a lowercase version of the key.
            String strKey = (String) key;
            mapKeys.put(strKey.toLowerCase(), strKey);
        }
        return (super.put(key, val));
    } // of method

    //----------------------------------------------------------------

    //// have to override this, putAll() in HashMap doesn't use put()
    public void putAll(Map t) {
        Iterator it = t.keySet().iterator();
        Object   key;
        Object   val;

        while (it.hasNext()) {
            key = it.next();
            val = t.get(key);
            this.put(key, val);
        }
    } // of method

    //----------------------------------------------------------------

    public Object get(Object key) {
        if (key instanceof String) {
            //// 1. Lookup a lowercase version of the key to get the real one.
            key = mapKeys.get(((String) key).toLowerCase());
        }
        return (super.get(key));
    } // of method

    //----------------------------------------------------------------

    public Object remove(Object key) {
        if (key instanceof String) {
            //// 1. Lookup a lowercase version of the key to get the real one.
            String strKeyAA = (String) key;
            key = mapKeys.remove(strKeyAA.toLowerCase());
        }
        return (super.remove(key));
    } // of method

    //===   DELEGATION METHODS   ===============================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING DEBUGGING   ===============================================

    public String toDebugString() {
        StringBuffer strbuf = new StringBuffer();
        strbuf.append(getWrappedMap().toString());
        strbuf.append("\n");
        strbuf.append(mapKeys.toString());
        return (strbuf.toString());
    } // of method

    //===   TOSTRING DEBUGGING   ===============================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static Map getMapAAA() {
        Map map = new HashMap();
        map.put("HI",  "THERE");
        map.put("AA",  "BB");
        map.put("Ccc", "zzzzz");
        return (map);
    } // of method

    //----------------------------------------------------------------

    private static Map getMapBBB() {
        Map map = new HashMap();
        map.put("DELETE",      "REMOVE");
        map.put("POST",        "ADD");
        map.put("UPDATE",      "UPDATE");
        map.put("GET",         "QUERY");
        map.put("UNSUBSCRIBE", "UNSUBSCRIBE");
        map.put("ADDSPC",      "ADDSPC");
        map.put("REMOVESPC",   "REMOVESPC");
        map.put("SUBSCRIBE",   "SUBSCRIBE");
        map.put("NOTIFY",      "NOTIFY");
        return (map);
    } // of method

    //----------------------------------------------------------------

    private static Map getMapCCC() {
        return (MapLib.invert(getMapBBB()));
    } // of method

    //----------------------------------------------------------------

    private static void runTestAAA() {
        CaseInsensitiveMap map = new CaseInsensitiveMap();

        //// 1. Just add some stuff.
        map.put("CCC", "DDD");
        map.put("eeE", "fff");
        map.put("ggg", "hhH");

        System.out.println(map);
        System.out.println();

        map.putAll(getMapAAA());

        System.out.println(map);
        System.out.println();

        //// 2. Now check whether we contain the keys or not.
        System.out.println(map.get("CCC"));
        System.out.println(map.get("Ccc"));
        System.out.println(map.get("ccc"));

        System.out.println("------");
        System.out.println(map);
        System.out.println(map.mapKeys);
        System.out.println("------");
        System.out.println(map.remove("ccc"));
        System.out.println(map.get("ccc"));
        System.out.println("------");
        System.out.println(map);
        System.out.println(map.mapKeys);
    } // of method

    //----------------------------------------------------------------

    private static void runTestBBB() {
        Map map = new CaseInsensitiveMap(getMapBBB());
        System.out.println(map);
        System.out.println(map.get("POST"));
        System.out.println(map.get("Post"));
        System.out.println(map.get("DELETE"));
        System.out.println(map.get("NOTIFY"));
        System.out.println(map.get("UPDATE"));
    } // of method

    //----------------------------------------------------------------

    private static void runTestCCC() {
        Map map = new CaseInsensitiveMap(getMapCCC());
        System.out.println(map);
        System.out.println(map.get("ADD"));
        System.out.println(map.get("Add"));
        System.out.println(map.get("REMOVE"));
        System.out.println(map.get("Query"));
    } // of method

    //----------------------------------------------------------------

    private static void main(String[] argv) {
        runTestCCC();
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
