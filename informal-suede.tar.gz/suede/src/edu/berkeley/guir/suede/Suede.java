package edu.berkeley.guir.suede;

import javax.swing.*;


/** The main class of the SUEDE project. It instantiates a SuedeModel object.
 *  @version 1.0
 */
public class Suede extends JFrame
{ 
	/**Set showPauseDialog member to true
	 */
  public static boolean showPauseDialog = true;
  /**Set enablePauseElim member to false
   */
  public static boolean enablePauseElim = false;

   /** A main function that instantiate a SuedeModel object.
	*
	* @param args An array of arguments of type String
	*/   
   static public void main(String args[])
   {
		try {
			new SuedeModel( false );
		} catch (Throwable t) {  t.printStackTrace(); System.exit(0);  }
	}

}