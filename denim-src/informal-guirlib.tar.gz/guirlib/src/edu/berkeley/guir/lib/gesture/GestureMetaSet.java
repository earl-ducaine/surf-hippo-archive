package edu.berkeley.guir.lib.gesture;

import java.io.Serializable;
import java.io.IOException;
import java.io.EOFException;
import java.io.Writer;
import java.io.Reader;
import java.text.ParseException;
import java.util.List;
import java.util.Vector;
import edu.berkeley.guir.lib.gesture.util.Misc;
import edu.berkeley.guir.lib.gesture.util.TokenReader;

/** A collection of gesture sets. */
public class GestureMetaSet extends AbstractGestureContainer
implements Serializable, Cloneable {
  protected Vector sets;
  
  public GestureMetaSet()
  {
    super();
    sets = new Vector();
  }

  private static final Class[] CHILD_TYPES = {
    GestureSet.class
  };
  public Class[] getChildTypes()
  {
    return CHILD_TYPES;
  }

  protected List getChildren()
  {
    return sets;
  }

  public Object clone()
  {
    GestureMetaSet result = (GestureMetaSet) super.clone();
    result.sets = (Vector) Misc.deepCopy(sets);
    result.fixParents();
    return result;
  }

  public void write(Writer writer) throws IOException
  {
    writer.write("name\t" + name + "\n");
    if (author != null) {
      writer.write("author\t" + author + "\n");
    }
    for (int i = 0; i < sets.size(); i++) {
      GestureSet set = (GestureSet) sets.get(i);
      writer.write("set\n");
      set.write(writer);
    }
    writer.write("endmetaset\n");
  }

  public static GestureMetaSet read(Reader reader)
    throws IOException, ParseException
  {
    GestureMetaSet result = new GestureMetaSet();
    
    boolean done = false;
    TokenReader r = new TokenReader(reader);
    while (!done) {
      String token;
      try {
	token = r.readToken().intern();
	if (token == "name") {
	  result.name = r.readLine();
	}
	else if (token == "author") {
	  result.author = r.readLine();
	}
	else if (token == "set") {
	  GestureSet gs = GestureSet.read(r);
	  result.add(gs);
	}
	else if (token == "endmetaset") {
	  done = true;
	}
      }
      catch (EOFException e) {
	done = true;
      }
    }
    //System.err.println("Read set '" + result.getName() + "'");
    return result;
  }
}
