package edu.berkeley.guir.damask.view.visual.component;

import java.awt.Color;
import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.component.Trigger;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.event.InteractionElementEvent;
import edu.berkeley.guir.damask.event.InteractionElementListener;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.visual.dialog.PageViewContainer;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;

/** 
 * A hyperlink.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-20-2003 James Lin
 *                               Created Hyperlink.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-20-2003
 */
public class Hyperlink extends ControlView {
   private Label caption; 
   private TriggerHandler triggerHandler = new TriggerHandler();
   
   /**
    * Constructs a hyperlink and associates it with the specified trigger. 
    */
   public Hyperlink(final Trigger trigger) {
      super(trigger, new RunModeEventHandler());
      trigger.addInteractionElementListener(triggerHandler);
   }
   
   
   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      final DeviceType deviceType = getDeviceType();
      final Trigger trigger = (Trigger)getModel();
      
      // Set the contents
      final Content content = trigger.getContent();
      caption = new Label(content);
      caption.setPickable(false); 
      addChild(caption);
      caption.setTransform(content.getTransform(deviceType));
      caption.setBounds(content.getBounds(deviceType));
      
      // Set the contents blue
      getContent().setLabelColor(Color.BLUE);
   }


   /**
    * Returns a representation of what a hyperlink looks like by default.
    */
   public static PNode createTempView() {
      return Label.createTempView();
   }


   // Overrides method in parent class.
   public void dispose() {
      super.dispose();
      final Trigger trigger = (Trigger)getModel();
      trigger.removeInteractionElementListener(triggerHandler);
   }
   
   
   // Overrides abstract method in parent class.
   public Object getEditableContents() {
      return getContent();
   }

   /**
    * Returns the content of the hyperlink.
    */
   public Label getContent() {
      return (Label)getChild(0);
   }


   /**
    * Returns null, since hyperlinks don't have state.
    */
   public Object getState() {
      return null;
   }


   /**
    * Has no effect, since hyperlinks don't have state.
    */
   public void setState(final Object state) {
   }

   
   // @Override
   public void setInRunMode(boolean flag) {
      super.setInRunMode(flag);
      caption.setInRunMode(flag);
   }


   /**
    * The event handler for a hyperlink in Run mode.
    */
   private static class RunModeEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final Hyperlink hyperlink = (Hyperlink)event.getPickedNode();
         hyperlink.setStrokePaint(Color.LIGHT_GRAY);
         container.setFocus(hyperlink);
      }
         
      public void mouseReleased(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final Hyperlink hyperlink = (Hyperlink)event.getPickedNode();
            
         if (container.getFocus() == hyperlink) {
            hyperlink.setStrokePaint(DamaskAppUtils.NO_COLOR);
               
            final DeviceType deviceType = hyperlink.getDeviceType();
            
            final Trigger trigger = (Trigger)hyperlink.getModel();
            final NavConnection connection =
               trigger.getOutConnection(
                  hyperlink.getDeviceType(),
                  new InvokeEvent(trigger),
                  container.getSelectedPageCondition());
            
            if (connection != null) {
               container.goToPage(
                  connection.getDest(deviceType).getPage(deviceType));
            }
         }
         container.setFocus(null);
      }
   }


   /**
    * Handles events from the label's model object. 
    */
   private class TriggerHandler
      implements InteractionElementListener {
      
      public void elementBoundsUpdated(InteractionElementEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            final Rectangle2D newBounds =
               e.getElement().getBounds(e.getDeviceType());
            if ((newBounds.getWidth() == 0)
               && (newBounds.getHeight() == 0)) {
               setBounds(
                  new Rectangle2D.Double(
                     newBounds.getX(),
                     newBounds.getY(),
                     caption.getEmptySize().getWidth(),
                     caption.getEmptySize().getHeight()));
            }
            else {
               setBounds(e.getElement().getBounds(e.getDeviceType()));
            }
         }
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }
}
