package edu.berkeley.guir.lib.awt;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.SwingUtilities;

/**
 * A version of the EventQueue used to record mouse and key
 * events to a file for playback.
 * The file name may be specified; otherwise, a default file name
 * "test_" with a timestamp and a .txt extension will be given.
 *
 *
 * <P>
 * Here is a code example:
 * <CODE>
 *    Toolkit    tk = Toolkit.getDefaultToolkit();
 *    EventQueue q  = tk.getSystemEventQueue();
 *    q.push(new LoggingEventQueue());
 * </CODE>
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 *
 * @author  Lisa Chan (
 *          <A HREF="mailto:lisachan@cory.eecs.berkeley.edu">lisachan@cory.eecs.berkeley.edu</A> )
 * @since   JDK 1.3
 * @version GUIRLib-v1.4-1.1.0, Mar 23 2001
 */

public class LoggingEventQueue
   extends EventQueue {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   private boolean flagDragLeft   = false;
   private boolean flagDragMid    = false;
   private boolean flagDragRight  = false;

   private long lastTime, eventTime, time;
   protected BufferedWriter out;
   protected String filename;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================


   private static String createShortDateTimeString() {
      SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
      return df.format(new Date());
   }

   /**
    * Constructs a file and buffered writer.
    */
   public LoggingEventQueue() throws IOException {
      this("test_" + createShortDateTimeString() + ".txt");
   }

   /**
    * Constructs a file with a specified name and buffered writer.
    */
   public LoggingEventQueue(String filename) throws IOException {
      this.filename = filename;

      lastTime = -1;
      time = 0;

      out = new BufferedWriter(new FileWriter(filename));
   }

   /**
    * Writes mouse and key events to file.
    *
    * Each entry is recorded as follows:
    * delay_time  MOUSEEVENT [mouse_event  screen_coordinates (x,y)-S  relative_coordinates   source_component)
    */
   public void dispatchEvent(AWTEvent evt) {
      try {
         String event = " ";
         boolean writeEvent = false;

         if (evt instanceof MouseEvent) {
            MouseEvent msevt = (MouseEvent) evt;
            Component comp = (Component)msevt.getSource();
            String source = comp.getName();
            String relCoords = "(" + msevt.getX() + "," + msevt.getY() + ")";
            String screenCoords = convertCoords(comp, msevt);

            eventTime = (new Date()).getTime();

            switch (msevt.getID()) {
            case MouseEvent.MOUSE_PRESSED:
               event = "MouseEvent[ MOUSE_PRESSED";
               if (SwingUtilities.isLeftMouseButton(msevt)) {
                  flagDragLeft   = false;
                  event = event + " LT";
               }
               if (SwingUtilities.isMiddleMouseButton(msevt)) {
                  flagDragMid    = false;
                  event = event + " MI";
               }
               if (SwingUtilities.isRightMouseButton(msevt)) {
                  flagDragRight  = false;
                  event = event + " RT";
               }
               writeEvent = true;
               break;

            case MouseEvent.MOUSE_RELEASED:
               event = "MouseEvent[ MOUSE_RELEASED";
               if (SwingUtilities.isLeftMouseButton(msevt)) {
                  flagDragLeft   = false;
                  event = event + " LT";
               }
               if (SwingUtilities.isMiddleMouseButton(msevt)) {
                  flagDragMid    = false;
                  event = event + " MI";
               }
               if (SwingUtilities.isRightMouseButton(msevt)) {
                  flagDragRight  = false;
                  event = event + " RT";
               }
               writeEvent = true;
               break;

            case MouseEvent.MOUSE_DRAGGED:
            case MouseEvent.MOUSE_MOVED:
               event = "MouseEvent[ MOUSE_MOVED";
               if (SwingUtilities.isLeftMouseButton(msevt)) {
                  flagDragLeft   = true;
                  event = event + " LT";
               }
               if (SwingUtilities.isMiddleMouseButton(msevt)) {
                  flagDragMid    = true;
                  event = event + " MI";
               }
               if (SwingUtilities.isRightMouseButton(msevt)) {
                  flagDragRight  = true;
                  event = event + " RT";
               }
               writeEvent = true;
               break;

            default:
               break;
            }

            if (lastTime != -1) {
               time = eventTime - lastTime;
            }
            lastTime = eventTime;

            if (writeEvent) {
               out.write(time + "ms\t\t" + event + "\t\t" +
                         screenCoords + "\t\t" + relCoords + "\t\t" + source + "]\n");
            }
         }// of if MouseEvent

         else if (evt instanceof KeyEvent) {
            KeyEvent kevt = (KeyEvent) evt;

            eventTime = (new Date()).getTime();

            switch (kevt.getID()) {
            case KeyEvent.KEY_PRESSED:
               event = "KeyEvent[ KEY_PRESSED";
               writeEvent = true;
               break;

            case KeyEvent.KEY_RELEASED:
               event = "KeyEvent[ KEY_RELEASED";
               writeEvent = true;
               break;

            default:
               break;
            }

            if (lastTime != -1) {
               time = eventTime - lastTime;
            }
            lastTime = eventTime;

            if (writeEvent) {
               out.write(time + "ms\t\t" + event + "\t\t KeyCode" + kevt.getKeyCode() + "]\n");
            }
         } // of if KeyEvent


      }
      catch (IOException e) {
         System.out.println("ERROR: IOException");
      }

      super.dispatchEvent(evt);
   }// of dispatchEvent


   /**
    * Converts relative coordinates to screen coordinates string.
    */
   private String convertCoords(Component comp, MouseEvent msevt) {
      Point pt = comp.getLocationOnScreen();
      int xCoord = (int)pt.getX() + msevt.getX();
      int yCoord = (int)pt.getY() + msevt.getY();
      return "(" + xCoord + "," + yCoord + ")-S";
   }

   /**
    * Pops this LogginEventQueue from the EventQueue stack.
    */
   public void pop() {
      super.pop();
   }

   /**
    * Closes the current file.
    */
   public void close() {
      try {
         out.flush();
         out.close();
         System.out.println("File "+filename+" closed.");
      }
      catch (IOException e) {
      }
   }

} // of class
   
//==============================================================================

/*
Copyright (c) 2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
