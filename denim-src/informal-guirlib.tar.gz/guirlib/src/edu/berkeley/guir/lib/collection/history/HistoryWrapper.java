//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.history;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * A wrapper for History.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Jan 30 2004
 */
public class HistoryWrapper
    implements History {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    History wrappedHistory;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Wrap around this history.
     */
    public HistoryWrapper(History h) {
        wrappedHistory = h;
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   WRAPPER METHODS   ==================================================

    public void setWrappedHistory(History h) {
        wrappedHistory = h;
    } // of method

    //----------------------------------------------------------------

    public History getWrappedHistory() {
        return (wrappedHistory);
    } // of method

    //===   WRAPPER METHODS   ==================================================
    //==========================================================================




    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    public void addEvent(HistoryEvent evt) {
        wrappedHistory.addEvent(evt);
    } // of method

    //----------------------------------------------------------------

    /**
     * Add all events.
     */
    public void addAllEvents(History history) {
        wrappedHistory.addAllEvents(history);
    } // of method

    public void addAllEvents(Collection col) {
        wrappedHistory.addAllEvents(col);
    } // of method

    public void addAllEvents(Iterator it) {
        wrappedHistory.addAllEvents(it);
    } // of method

    //----------------------------------------------------------------

    /**
     * Remove a specific event.
     */
    public void removeEvent(HistoryEvent evt) {
        wrappedHistory.removeEvent(evt);
    } // of method

    //----------------------------------------------------------------

    /**
     */
    public void removeEvent(int index) {
        wrappedHistory.removeEvent(index);
    } // of method

    //----------------------------------------------------------------

    /**
     * Clear out all events.
     */
    public void clearEvents() {
        wrappedHistory.clearEvents();
    } // of method

    //----------------------------------------------------------------

    /**
     */
    public boolean containsEvent(HistoryEvent evt) {
       return (wrappedHistory.containsEvent(evt));
    } // of method

    //----------------------------------------------------------------

    /**
     */
    public HistoryEvent getEvent(int index) {
        return (wrappedHistory.getEvent(index));
    } // of method

    //----------------------------------------------------------------

    /**
     * @return the number of HistoryEvent objects contained
     */
    public int size() {
        return (wrappedHistory.size());
    } // of method

    //----------------------------------------------------------------

    /**
     * @return an Iterator of HistoryEvent objects
     */
    public Iterator events() {
        return (wrappedHistory.events());
    } // of method

    public Iterator events(boolean flag) {
        return (wrappedHistory.events(flag));
    } // of method

    //----------------------------------------------------------------

    /**
     * Get a copy of the History as a list.
     */
    public List asList() {
        return (wrappedHistory.asList());
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================




    //==========================================================================
    //===   COMMON QUERY METHODS   =============================================

    /**
     * Gets the first entry, which depends on how things are sorted.
     * By default, this returns the oldest.
     */
    public HistoryEvent getFirstEntry() {
        return (wrappedHistory.getFirstEntry());
    } // of method

    //--------------------

    /**
     * Gets the last entry, which depends on how things are sorted.
     * By default, this returns the newest.
     */
    public HistoryEvent getLastEntry() {
        return (wrappedHistory.getLastEntry());
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the first HistoryEvent that matches the specified field.
     * @param flagForward is true if we should go in forward order,
     *                      false if in reverse order.
     */
    public HistoryEvent getByField(boolean flagForward, 
                                   String  strField, 
                                   String  strVal) {

        return (wrappedHistory.getByField(flagForward, strField, strVal));
    } // of method

    //===   COMMON QUERY METHODS   =============================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING METHODS   =================================================

    /**
     * Override this to change how HistoryEvents are displayed.
     */
    public String toString(HistoryEvent evt) {
        return (wrappedHistory.toString(evt));
    } // of method

    //----------------------------------------------------------------

    public String toString() {
       return (wrappedHistory.toString());
    } // of method

    //----------------------------------------------------------------

    public void toWriter(Writer wtr) 
        throws IOException {

        wrappedHistory.toWriter(wtr);
    } // of method

    //===   TOSTRING METHODS   =================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
