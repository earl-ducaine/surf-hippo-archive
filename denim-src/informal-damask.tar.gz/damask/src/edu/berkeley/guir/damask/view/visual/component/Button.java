package edu.berkeley.guir.damask.view.visual.component;

import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.Direction;
import edu.berkeley.guir.damask.component.Trigger;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.event.InteractionElementEvent;
import edu.berkeley.guir.damask.event.InteractionElementListener;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.visual.dialog.PageViewContainer;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * A button.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-20-2003 James Lin
 *                               Created Button.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-20-2003
 */
public class Button extends ControlView {

   private static final int DEFAULT_WIDTH = 80;
   private static final int DEFAULT_HEIGHT = 20;
   private static final int DEFAULT_CORNER_RADIUS = 7;

   private Label caption = null;

   /**
    * Constructs a button and associates it with the specified trigger. 
    */
   public Button(final Trigger trigger) {
      super(trigger, new RunModeEventHandler());
      setStrokePaint(Color.BLACK);
      setStretchedWhenResized(false);
      addClientProperty(
         DamaskAppUtils.PROPERTY_RESIZE_CHILDREN_ANCHOR,
         Direction.CENTER);
      setPaint(DamaskAppUtils.NO_COLOR);
   }
   
   
   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      final DeviceType deviceType = getDeviceType();
      final Trigger trigger = (Trigger)getModel();
      
      // Set the border
      setPathTo(trigger.getBorder(deviceType));
      
      // Set the contents
      caption = new Label(trigger.getContent());
      caption.setPickable(false);
      caption.setMovable(false);
      caption.addClientProperty(
         DamaskAppUtils.PROPERTY_RESIZE_ANCHOR,
         Direction.CENTER);
      addChild(caption);

      getModel().addInteractionElementListener(new TriggerHandler());
   }


   // Overrides abstract method in parent class.
   public Object getEditableContents() {
      return getContent();
   }


   /**
    * Returns the content of this button.
    */
   public Label getContent() {
      return caption;
   }


   /**
    * Returns null, since buttons don't have state.
    */
   public Object getState() {
      return null;
   }


   /**
    * Has no effect, since buttons don't have state.
    */
   public void setState(final Object state) {
   }


   /**
    * Returns a representation of what a button looks like by default.
    */
   public static PNode createTempView() {
      final PPath border =
         new PPath(
            new RoundRectangle2D.Double(
               0, 0,
               DEFAULT_WIDTH, DEFAULT_HEIGHT,
               DEFAULT_CORNER_RADIUS, DEFAULT_CORNER_RADIUS));

      // construct squiggle in button
      final PPath squiggle = DamaskAppUtils.createSquiggle();
      squiggle.setOffset(
         (border.getWidth() - squiggle.getWidth()) / 2,
         (border.getHeight() - squiggle.getHeight()) / 2);

      border.addChild(squiggle);
      
      return border;
   }


   // Overrides method in parent class.
   public void setInRunMode(boolean flag) {
      super.setInRunMode(flag);
   }

   
   /**
    * The event handler for a button in Run mode.
    */
   private static class RunModeEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final Button button = (Button)event.getPickedNode();
         button.getContent().setLabelColor(Color.WHITE);
         button.setPaint(Color.BLACK);
         container.setFocus(button);
      }
      
      public void mouseReleased(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final Button button = (Button)event.getPickedNode();
         
         if (container.getFocus() == button) {
            button.getContent().setLabelColor(Color.BLACK);
            button.setPaint(Color.WHITE);
            
            final DeviceType deviceType = button.getDeviceType();
            
            final Trigger trigger = (Trigger)button.getModel();
            final NavConnection connection =
               trigger.getOutConnection(
                  button.getDeviceType(),
                  new InvokeEvent(trigger),
                  container.getSelectedPageCondition());
            
            if (connection != null) {
               container.goToPage(
                  connection.getDest(deviceType).getPage(deviceType));
            }
         }
      }
      
      public void mouseEntered(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final Button button = (Button)event.getPickedNode();
         if (container.getFocus() == button) {
            button.getContent().setLabelColor(Color.WHITE);
            button.setPaint(Color.BLACK);
         }
      }
      
      public void mouseExited(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final Button button = (Button)event.getPickedNode();
         if (container.getFocus() == button) {
            button.getContent().setLabelColor(Color.BLACK);
            button.setPaint(Color.WHITE);
         }
      }
   }

   /**
    * Handles events from the model object. 
    */
   private class TriggerHandler implements InteractionElementListener {
      public void elementBoundsUpdated(InteractionElementEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            final Rectangle2D newBounds =
               e.getElement().getBounds(e.getDeviceType());
            if ((newBounds.getWidth() == 0)
               && (newBounds.getHeight() == 0)) {
               setBounds(
                  new Rectangle2D.Double(
                     newBounds.getX(),
                     newBounds.getY(),
                     caption.getEmptySize().getWidth(),
                     caption.getEmptySize().getHeight()));
            }
            else {
               setBounds(e.getElement().getBounds(e.getDeviceType()));
            }
         }
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
         // Set the border
         if (e.getDeviceType() == getDeviceType()) {
            setPathTo(((Trigger)getModel()).getBorder(getDeviceType()));
         }
      }
   }
}
