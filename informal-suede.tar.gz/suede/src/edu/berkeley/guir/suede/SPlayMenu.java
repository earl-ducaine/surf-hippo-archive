package edu.berkeley.guir.suede;

import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;
import java.awt.event.*;

// srk: This is the menu for links in analysis mode. It presents a drop down menu 
// of all of the recorded user audio for that link.

public class SPlayMenu extends JComponent {
    private JPopupMenu     m_popup    = new JPopupMenu(); 
    private int            m_numItems = 0;

    public SPlayMenu() {
      addMouseListener(new PopupListener());
    }
    
    
    // whenever we enter analysis mode, we reset the menu list
    // currently, the menu just displays numbers.
    // Eventually this should be the user names
    public void addMenuItem(String s, ActionListener menuListener) {
       m_numItems++;
       JMenuItem menuItem = new JMenuItem(s);
       menuItem.addActionListener(menuListener);
       m_popup.add(menuItem);
    }
    
    public void clearMenuItems() {
      m_popup.removeAll(); 
    }


    public void paintComponent(Graphics g) {  
        Graphics2D g2d = (Graphics2D)g;
        g2d.setColor((m_numItems==0) ? Color.gray : Color.black);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        GeneralPath triangle = new GeneralPath();
        triangle.moveTo(0,                        getWidth()/2 - (int)(getHeight()*0.1f));
        triangle.lineTo((int)(getHeight()*0.28f), getWidth()/2 + (int)(getHeight()*0.35f));
        triangle.lineTo((int)(getHeight()*0.56f), getWidth()/2 - (int)(getHeight()*0.1f));
 
        triangle.closePath();
        g2d.fill(triangle);
    }
    
    
    // This listener pops up the menu when the user clicks on the triangle button on the link
    class PopupListener extends MouseAdapter {
       public void mousePressed(MouseEvent e) {
          if (m_numItems>0) m_popup.show(e.getComponent(),0,0);
       }
    }
}