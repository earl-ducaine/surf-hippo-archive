package edu.berkeley.guir.damask.view.appevent;

import java.util.EventListener;

/** 
 * The listener interface for receiving events indicating that something
 * has occurred within a DamaskRunCanvas.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  12-31-2003 James Lin
 *                               Created RunCanvasListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 12-31-2003
 */
public interface RunCanvasListener extends EventListener {
   
   /**
    * Occurs when a page has been completed loaded.
    */
   void loadCompleted(RunCanvasEvent e);
}
