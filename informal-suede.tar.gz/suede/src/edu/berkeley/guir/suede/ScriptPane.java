package edu.berkeley.guir.suede;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import edu.berkeley.guir.suede.help.*;

/** There is one script pane instance for design mode, and one instance for 
 * analysis mode. A Menu on the top of the window in the design mode including
 * New Window, Open , Save, Save As, Test, New Script, Help
 **/

public class ScriptPane extends javax.swing.JComponent
{
	private static final int     SCRIPT_HT = 65;
	private static final int     MENU_HT   = 20;
	private static final int     BIG_NUMBA = 999999;
	private static final int     SPACING   = 50;
	private static final int     BORDER    = 2;
	private static final Color   MODE_BG   = Color.black;
	private static final Color   MODE_FG   = Color.white;
	private static final Color   MODE_ROLL = Color.darkGray;//HV Oct 1703
	public  static final boolean DESIGN    = true;
	public  static final boolean TRANSC    = false;
	private static final int     SCROLLBAR_HEIGHT = 15;
	    
	private Vector       scripts       = new Vector(); // a set of all the AbstScriptViews
	private int          numScripts    = 0;
	//HV Oct 1703
	//private SMenuBar     menuBar       = new SMenuBar();
	private SMenuBar     menuBar;
	//private STestFrame   testFrame     = null;            
	private SContentPane m_pane;   // a link to the design area     
	private SuedeModel   m_model;  // a link to the main model
	//private JScrollPane  m_scriptArea;
	//private Container  m_scriptBody = new Container();
	  
	public ScriptPane(int width, SContentPane p, boolean isDesignScript) {
	m_pane = p;
	setLayout(new ScrollPaneLayout());
	setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	setBorder(BorderFactory.createEmptyBorder());
	//HV Oct 1703
	menuBar = new SMenuBar(isDesignScript);
	Dimension dim = menuBar.getMaximumSize();
	Dimension maxDim = new Dimension (dim.width, MENU_HT);
	menuBar.setMaximumSize(maxDim);
	add(menuBar);
	
	Dimension testDim = new Dimension (dim.width, getPreferredSize().height);
	//Dimension testDim = new Dimension (dim.width, MENU_HT*4);
	this.setMaximumSize(testDim);
	//HV Jan 1504
	//m_scriptArea = new JScrollPane(m_scriptBody, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
	//								ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
	//add(m_scriptArea);
	setOpaque(true);
	setEnabled(true);
	setVisible(true);
	}
    
	public void addNewScriptActionListener(ActionListener al) {
	menuBar.addNewScriptActionListener(al);
	}

	    
	public void addTestActionListener() {
		menuBar.addTestActionListener();
	}
	 /*****/
		/*public void addHelpActionListener() {
			menuBar.addHelpActionListener();
		}
		/*****/
	public void setModel(SuedeModel model) {
		m_model = model;
		for (int i=0; i<scripts.size(); i++) ((AbstScriptView)scripts.get(i)).setModel(m_model); 
	}
	    
	    
	public int getNumberScripts() {
		return numScripts;
	}

	
	public Dimension getMinimumSize() {
	int minHeight = MENU_HT + 2;
	Enumeration e = scripts.elements();
	System.out.println ("Has elts = " + e.hasMoreElements());
	System.out.println ("NumScript = " + numScripts);
	while ( e.hasMoreElements() ) {
		minHeight += ((JComponent)e.nextElement()).getMinimumSize().height;
	}
	System.out.println ("ScriptPaneMinHeight = " + minHeight);
	return new Dimension( super.getPreferredSize().width, minHeight );
	}

	
	public Dimension getPreferredSize() {
		//System.out.println("4 ScriptPane.getPreferredSize //calls getMin");
	return getMinimumSize();
	}
		    
		    
	public Dimension getMaximumSize() {
		//System.out.println("4 ScriptPane.getMaximumSize //calls getMin");
	return new Dimension(super.getMaximumSize().width, getMinimumSize().height);
	}
	    
	    
   // this adds a new designScript to this pane. This is called once when the design pane is 
   // initialized, and when the user clicks on add script in design mode.
   public DesignScriptView addScript() {
	  DesignScriptView s = new DesignScriptView(numScripts, m_model);        
	  addScript(s);
	  return s;
   }
	    
   public TranscriptView addTranscript( int userID ) {
	  TranscriptView s = new TranscriptView( userID );        
	  addScript(s);
	  return s;
   }
	    
   public void addScript(AbstScriptView s) {
	  scripts.add(s);
	  //s.setAutoscrolls(true);
	  add(s);
	  //HV Jan 1504
	  //m_scriptBody.add(s);
		numScripts++;
	  revalidate();
   }
    
    
	public void addScriptNode(AbstScriptNodeModel scriptNode, int scriptNumber) {
		((AbstScriptView)scripts.get(scriptNumber)).addScriptNode(scriptNode);
	}
    
	public void saveScripts(java.io.PrintWriter pw, String path) {
	for (int i=0; i<scripts.size();i++) {
		((AbstScriptView)scripts.get(i)).saveScript(pw, path);
	}
	}
    
    //HV Oct1703
    public Vector getScripts() {
    	return scripts;
    }
   
   //HV Oct 1703
   //Change the SMenuBar's constructor to make the menu in Analysis mode look better 
	//private class SMenuBar extends javax.swing.JPanel {
	private class SMenuBar extends javax.swing.JMenuBar {
		//private int            buttonRight; // the righthand pixel value of the left set of buttons
		//private JPanel         bp        = new JPanel(); // panel that conatins the d/t/t buttons
                
				/************************Hongvan's Code************************************/
				private RolloverMenu file = new RolloverMenu("File", MODE_BG, MODE_FG, MODE_ROLL);
				private RolloverMenuItem newWindow = new RolloverMenuItem("New Window", MODE_BG, MODE_FG,MODE_ROLL);
				private RolloverMenuItem open = new RolloverMenuItem("Open", MODE_BG, MODE_FG, MODE_ROLL);
				private RolloverMenuItem save = new RolloverMenuItem("Save", MODE_BG, MODE_FG, MODE_ROLL);
				private RolloverMenuItem saveAs = new RolloverMenuItem("Save As...", MODE_BG, MODE_FG, MODE_ROLL);
				/************************End of Hongvan's Code************************************/
                
		/**private RolloverButton open      = new RolloverButton("Open",       MODE_BG, MODE_FG, MODE_ROLL);
		private RolloverButton save      = new RolloverButton("Save",       MODE_BG, MODE_FG, MODE_ROLL);
		private RolloverButton saveAs    = new RolloverButton("Save As...", MODE_BG, MODE_FG, MODE_ROLL);
		*/
				private RolloverButton newScript = new RolloverButton("New Script", MODE_BG, MODE_FG, MODE_ROLL);
		private RolloverButton test      = new RolloverButton("Test",       MODE_BG, MODE_FG, MODE_ROLL);
		/************************Hongvan Code************************************/
				private RolloverMenu help      = new RolloverMenu("Help", MODE_BG, MODE_FG, MODE_ROLL);
				//HV Oct 1703
			private RolloverMenuItem contents = new RolloverMenuItem("Contents", MODE_BG, MODE_FG, MODE_ROLL);
		private RolloverMenuItem about = new RolloverMenuItem("About", MODE_BG, MODE_FG, MODE_ROLL);
				//private JMenuItem contents = new JMenuItem("Contents");
				//private JMenuItem about = new JMenuItem("About");
				/************************End of Hongvan Code*****************************/
                
		private RolloverToggleButton design   = new RolloverToggleButton("Design",   MODE_BG, MODE_FG, MODE_ROLL);
		private RolloverToggleButton analysis = new RolloverToggleButton("Analysis", MODE_BG, MODE_FG, MODE_ROLL);
		//HV Oct1703
		//bg is not used!!!!
		//private ButtonGroup bg = new ButtonGroup();

			
			
		public SMenuBar (boolean isDesignMode) {
			setLayout(null);
			setBorder(BorderFactory.createMatteBorder(0, 0, BORDER, 0, MODE_FG));
			setVisible(true);  setOpaque(true);
			setBackground(MODE_BG);
					    
			design.setSelected(true);
			//HV Oct1703
				  //bg is not used!!!!
			//bg.add(design); bg.add(test); bg.add(analysis);
				            
			int x=0;
			//x = open.setXHeight(x,      MENU_HT);  add(open);
			//x = save.setXHeight(x,      MENU_HT);  add(save);
			//x = saveAs.setXHeight(x,    MENU_HT);  add(saveAs);
			//x = newScript.setXHeight(x, MENU_HT);  
         
						//////////////////Hongvan'scode//////////////////
						/*** The File Menu ***/
						x = file.setXHeight(x, MENU_HT); add(file);
						file.add(newWindow);
						file.add(open);
						file.add(save);
						file.add(saveAs);
						//////////////////////////////////////////////////
                  //HV Oct1703
                  if (isDesignMode){      
					x = newScript.setXHeight(x, MENU_HT);
        
			//buttonRight = x;  
			//test.setXHeight(x, MENU_HT);
					x = test.setXHeight(x, MENU_HT);
                  }        
						//buttonRight = x;
						//////////////////Hongvan's code/////////////////////
						help.setXHeight(x, MENU_HT); add(help);
						help.add(contents);
						help.add(about);
						/////////////////////////////////////////////////////
                        
			design.addActionListener(   new DesignActionListener());
			analysis.addActionListener( new AnalysisActionListener());
			
						//////////////////////Hongvan's code////////////////////
						newWindow.addActionListener( new NewWindowActionListener());
			open.addActionListener(     new OpenActionListener());
			save.addActionListener(     new SaveActionListener());
			saveAs.addActionListener(    new SaveAsActionListener());
                        
                        
						contents.addActionListener( new ContentsActionListener());
						about.addActionListener( new ActionListener() {
							public void actionPerformed(ActionEvent evt) {
								aboutActionPerformed(evt);
							}
						});
						/////////////////////////////////////////////////////
		}
	        
	        
		public void addNewScriptActionListener(ActionListener al) {
			add(newScript);
			newScript.addActionListener(al);
		}


		public void addTestActionListener() {
			add(test);
		test.addActionListener(new TestActionListener());
	}
	    
		/*****/
	   /* public void addHelpActionListener() {
			add(help);
		}*/
	/*****/
       

//	/*
//	 * SMenuBar.getMinimumSize
//	 */
//  	public Dimension getMinimumSize() {
//		return new Dimension(super.getMinimumSize().width,   MENU_HT + BORDER);
//	  }
//	   
//	        
//	/*
//	 * SMenuBar.getPreferredSize
//	 */
//   	public Dimension getPreferredSize() {
//		return new Dimension(super.getPreferredSize().width, MENU_HT*8 + BORDER);
//	}
//	        
//   	
//	/*
//	 * SMenuBar.getMaximumSize
//	 */
//  	public Dimension getMaximumSize() {
//		return new Dimension(super.getMaximumSize().width,   MENU_HT*8 + BORDER);  
//	  }
//
//   	
//	public void setBounds(int x, int y, int w, int h) {
//		super.setBounds(x,y,w,h);
//		bp.setLocation((w - buttonRight)*2/3 + buttonRight - bp.getWidth()/2, 0);
//	}
	
		private class DesignActionListener implements ActionListener {
		 public void actionPerformed (ActionEvent e) {
			   m_model.setAnalysisMode(false);
		 }
	  }
	
	
	  private class TestActionListener implements ActionListener {
		 public void actionPerformed (ActionEvent e) {
			m_model.runTests();
		 }
	  }
    
		private class AnalysisActionListener implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				m_model.setAnalysisMode(true);
			}
		}
    
		// These below access the global card model
        
		private class OpenActionListener implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				m_model.openFile();                
			}
		}
    
		private class SaveActionListener implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				m_model.save(false);                
			}
		}

	private class SaveAsActionListener implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				m_model.save(true);                
			}
	}
	
		//////////////////////Hongvan's code//////////////////////////
		private class ContentsActionListener implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				new Contents().show();
			}
		}
        
		private void aboutActionPerformed (ActionEvent e) {
			   new About().show();        
			}
        
	   private class NewWindowActionListener implements ActionListener {
		   public void actionPerformed (ActionEvent e) {
			   //Create a new blank window in Design Mode
			   //HV Jan 08, 2004
			   SuedeModel newSuede = new SuedeModel(false);
			   Point pt = m_model.getLocation();
			   newSuede.setLocation(pt.x + 50, pt.y + 50);
		   }
	   }
	  /////////////////////////////////////////////////////////////////////
       
		private class TestWindowAdapter extends WindowAdapter {
		  public void windowClosing (java.awt.event.WindowEvent evt) {                          
			m_model.setAnalysisMode(true);
			analysis.setSelected(true);
		  }
		}
	}
}
