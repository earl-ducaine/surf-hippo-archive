//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import edu.berkeley.guir.lib.collection.Queue;
import java.util.HashMap;
import java.util.Iterator;

/**
 * A bidirectional best-first-search for Graph. Not implemented yet.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Feb 04 2000, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.5/1.2.0, Nov 22 2002, JH
 *               Updated for new Graph APIs
 * </PRE>
 *
 * @author  <A HREF="mailto:jasonh@cs.berkeley.edu">Jason Hong</A>
 * @since   1.3RC1
 * @version GUIRLib-v1.5/1.2.0, Nov 22 2002
 */
public class GraphSearchBidirBest
   implements GraphSearch {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   Graph     g;                 // our reference to the graph
   HashMap   table = new HashMap(GraphConst.DEFAULT_NUMBER_NODES);


   //// The list of nodes we have visited, going forward and backward.
   //// It contains the Paths of how to get to that Node (the table key).
   HashMap mapForward  = new HashMap(GraphConst.DEFAULT_NUMBER_NODES);
   HashMap mapBackward = new HashMap(GraphConst.DEFAULT_NUMBER_NODES);

   //// The list of open nodes going forward and backward
   Queue qForward  = new Queue();
   Queue qBackward = new Queue();

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   SEARCH METHODS   ====================================================

   /**
    * Clears out the paths already created while previously searching.
    * This is generally not needed, except when the underlying Graph data
    * changes.
    */
   public void clear() {
      qForward.clear();
      qBackward.clear();
      mapForward.clear();
      mapBackward.clear();
   } // of method

   //-----------------------------------------------------------------
   
   /**
    * Perform a bidirectional Best search on the graph, with the specified 
    * start and target nodes. Bidirectional searches are guaranteed to have the
    * shortest number of hops.
    *
    * @param  g is the Graph we are searching in.
    * @param  strFrom is the name of the starting node.
    * @param  strTo   is the name of the target node.
    * @return Returns the first successful Path found from the start node
    *         to the target node. The Path is empty if no successful Path
    *         is found, or if either the start or target node does not
    *         exist in the Graph.
    */
   public GraphPath search(Graph g, String strFrom, String strTo) {
      GraphPath   p = null;             // the current path
      boolean     flagForward = true;   // Search forward or backwards?
      boolean     flagFound   = false;  // Have we found a path?
      String      strNodeAt;            // name of node where we currently are
      GraphNode   nodeAt;               // the node where we currently are
      String      strNodeNext;          // the name of the next open node
      Iterator    it;                   // list of connected Nodes

      this.g = g;



      //// 0.1. Clear out the previous tables
      mapForward.clear();
      mapBackward.clear();

      //// 0.2. Clear out the previous queues
      qForward.clear();
      qBackward.clear();

      //// 0.3. Setup the return path
      GraphPath pathFinal = new GraphPath();

      throw new RuntimeException("This search not implemented yet");
   } // of method

   //===   SEARCH METHODS   ====================================================
   //===========================================================================

} // of class 

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
