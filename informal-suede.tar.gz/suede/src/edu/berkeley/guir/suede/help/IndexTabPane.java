package edu.berkeley.guir.suede.help;

import javax.swing. *;
import javax.swing.tree.*;
import java.awt.*;
import java.io.File;

class IndexTabPane extends JPanel {
     private JLabel FindLabel;
     private JTextField FindTextField;
     private JTree FileTree;
     private JScrollPane FilePane;
     
     public IndexTabPane () {
         super();
         initComponents();
     }
     
     private void initComponents() {
            FindLabel = new JLabel("Find: ", JLabel.LEFT);
            FindLabel.setPreferredSize(new Dimension(30,30));
            FindTextField = new JTextField();
            FindTextField.setPreferredSize(new Dimension(120, 30));
            JPanel TopPanel = new JPanel();
            TopPanel.setLayout(new FlowLayout());
            TopPanel.add(FindLabel);
            TopPanel.add(FindTextField);
            
            FileTree = new JTree (createTreeModel());
            FilePane = new JScrollPane(FileTree);
            this.setLayout(new BorderLayout());
            this.add(TopPanel, BorderLayout.NORTH);
            this.add(FilePane, BorderLayout.CENTER);
     }
     
     private DefaultTreeModel createTreeModel() {
		File root = new File("M:/");
		FileNode rootNode = new FileNode(root);

		rootNode.explore();
		return new DefaultTreeModel(rootNode);
	}
 }