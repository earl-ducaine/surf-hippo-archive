package edu.berkeley.guir.lib.gesture;

import java.io.*;
import java.util.*;
import edu.berkeley.guir.lib.gesture.util.*;
import java.text.ParseException;

/**
 * Collection of Gestures.  
 */
public class GestureCategory extends AbstractGestureContainer
  implements Serializable, Observer, Cloneable
{
  static int nameCounter = 1;
  static final long serialVersionUID = -1317677446709873144L;
  protected Vector gestures;	// of Gesture
  protected boolean directionInvariant, orientationInvariant, sizeInvariant;
  
  public GestureCategory()
  {
    this(null);
  }

  public GestureCategory(String name)
  {
    this(new Vector(), name);
  }

  public GestureCategory(Vector gestureVector, String name)
  {
    super();
    if (name == null) {
      // invent one
      name = "unnamed" + Integer.toString(nameCounter);
      nameCounter++;
    }
    this.name = name;
    gestures = gestureVector;
  }

  protected List getChildren()
  {
    return gestures;
  }
  
  public void addGesture(Gesture g)
  {
    add(g);
  }

  public Gesture gestureAt(int i)
  {
    return (Gesture) gestures.elementAt(i);
  }

  /** returns -1 if target not in the set */
  public int getGestureIndex(Gesture target)
  {
    return indexOf(target);
  }
  
  public void removeGesture(Gesture g)
  {
    remove(g);
  }

  public void replace(GestureCategory gc)
  {
    Gesture[] oldValue = (gestures == null) ? null :
      (Gesture[]) gestures.toArray();
    if (gc.gestures != null)
      gestures = (Vector) gc.gestures.clone();
    else
      gestures = null;
    if (gc.name != null)
      name = new String(gc.name);
    else
      name = null;
    setChanged();
    notifyObservers(gc);
    if (oldValue != null) {
      fireCollectionEvent(CollectionEvent.ELEMENT_REMOVED, oldValue, 0);
    }
    if (gestures != null) {
      fireCollectionEvent(CollectionEvent.ELEMENT_ADDED,
			  (Gesture[]) gestures.toArray(), 0);
    }
  }
  
  public void update(Observable gesture, Object arg)
  {
    setChanged();
    notifyObservers(gesture);
  }

  public boolean isDot()
  {
    boolean result = true;

    if (gestures.isEmpty()) {
      result = false;
    }
    else {
      for (Iterator iter = iterator();
	   result && iter.hasNext();) {
	Gesture g = (Gesture) iter.next();
	if (g.size() != 1)
	  result = false;
      }
    }

    return result;
  }

  public Object clone()
  {
    GestureCategory gc = (GestureCategory) super.clone();
    gc.gestures = (Vector) Misc.deepCopy(gestures);
    // name can be reused since Strings are immutable
    gc.fixParents();
    return gc;
  }

  // invariant-related functions

  public boolean isSizeInvariant()
  {
    return sizeInvariant;
  }

  public void setSizeInvariance(boolean on)
  {
    sizeInvariant = on;
  }
				
  public boolean isDirectionInvariant()
  {
    return directionInvariant;
  }

  public void setDirectionInvariance(boolean on)
  {
    directionInvariant = on;
  }
				
  public boolean isOrientationInvariant()
  {
    return orientationInvariant;
  }

  public void setOrientationInvariance(boolean on)
  {
    orientationInvariant = on;
  }

  /**
   * Enable or disable all examples
   */
  public void setExamplesEnabled(boolean enabled)
  {
    for (Iterator iter = iterator();
	 iter.hasNext();) {
      Gesture g = (Gesture) iter.next();
      g.setEnabled(enabled);
    }
  }

  private static final Class[] CHILD_TYPES = { Gesture.class };
  public Class[] getChildTypes()
  {
    return CHILD_TYPES;
  }
  
  /**
   * Restore observer status
   */
  private void readObject(ObjectInputStream in)
       throws IOException, ClassNotFoundException
  {
    in.defaultReadObject();
    for (Enumeration en = gestures.elements();
	 en.hasMoreElements(); ) {
      Gesture g = (Gesture) en.nextElement();
      g.addObserver(this);
    }
  }

  public void write(Writer writer) throws IOException
  {
    writer.write("name\t" + name + "\n");
    if (author != null) {
      writer.write("author\t" + author + "\n");
    }
    writer.write("directionInvariant\t" + directionInvariant + "\n");
    writer.write("orientationInvariant\t" + orientationInvariant + "\n");
    writer.write("sizeInvariant\t" + sizeInvariant + "\n");
    writer.write("gestures\t" + gestures.size() + "\n");
    for (int i = 0; i < gestures.size(); i++) {
      Gesture g = gestureAt(i);
      g.write(writer);
    }
    writer.write("endcategory\n");
  }

  public static GestureCategory read(Reader reader) throws IOException,
    ParseException
  {
    return read(new TokenReader(reader));
  }
  
  public static GestureCategory read(TokenReader r) throws IOException,
    ParseException
  {
    GestureCategory result = new GestureCategory();
    
    boolean done = false;
    while (!done) {
      String token;
      try {
	token = r.readToken().intern();
	if (token == "name") {
	  result.name = r.readLine();
	  result.name.trim();
	}
	else if (token == "author") {
	  result.author = r.readLine();
	  result.author.trim();
	}
	else if (token == "directionInvariant") {
	  result.directionInvariant = r.readBoolean();
	}
	else if (token == "orientationInvariant") {
	  result.orientationInvariant = r.readBoolean();
	}
	else if (token == "sizeInvariant") {
	  result.sizeInvariant = r.readBoolean();
	}
	else if (token == "gestures") {
	  try {
	    int numGestures = Integer.parseInt(r.readToken());
	    //System.err.println("Reading " + numGestures + " gestures...");
	    for (int i = 0; i < numGestures; i++) {
	      //System.err.println("Reading #" + i + "...");
	      Gesture gesture = Gesture.read(r);
	      result.addGesture(gesture);
	    }
	  }
	  catch (NumberFormatException e) {
	    throw new IOException("bad argument for categories");
	  }
	}
	else if (token == "endcategory") {
	  done = true;
	}
      }
      catch (EOFException e) {
	done = true;
      }
    }
    //System.err.println("Read category '" + result.getName() + "'");
    return result;
  }

  public String toString()
  {
    return getName();
  }
}
