package edu.berkeley.guir.damask.component;

import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.connection.ConnectionDest;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.damask.view.visual.component.Button;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.umd.cs.piccolo.PNode;


/** 
 * A "trigger" control, which represents a button or hyperlink.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-29-2003 James Lin
 *                               Created Trigger
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 04-29-2003
 */
public class Trigger extends Control {
   
   private static final int CORNER_RADIUS = 10;
   
   //---------------------------------------------------------------------------

   public static class Style {
      private String name;

      private Style(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   public static final Style BUTTON = new Style("button");
   public static final Style HYPERLINK = new Style("hyperlink");
   
   //---------------------------------------------------------------------------

   // Initialize default transform for content inside trigger
   private static final AffineTransform DEFAULT_BUTTON_CONTENT_TRANSFORM;
   static {
      final PNode button = Button.createTempView();
      DEFAULT_BUTTON_CONTENT_TRANSFORM = button.getChild(0).getTransform();
   }

   //---------------------------------------------------------------------------

   private Content content;
   private Map/*<DeviceType, Style>*/ styles =
      new HashMap/*<DeviceType, Style>*/();
   private Map/*<DeviceType, GeneralPath>*/ borders =
      new HashMap/*<DeviceType, GeneralPath>*/();
   private Control prevVoiceControl;
   private ControlVoiceListener prevVoiceControlHandler =
      new PrevControlVoiceHandler();
   private PageRegionHandler pageRegionHandler = new PageRegionHandler();
   private ContentHandler contentHandler = new ContentHandler();

   //===========================================================================

   /**
    * Constructs a trigger with the given piece of content.
    */
   public Trigger(final DeviceType deviceType, final Content content) {
      super(deviceType);
      DamaskUtils.checkValidArgument(
         content.isVisibleToDeviceType(deviceType),
         "content must be visible to " + deviceType);
      this.content = content;

      // Listen to changes in the content, so that this trigger can adjust
      // its borders
      init();
   }

   //---------------------------------------------------------------------------

   /**
    * Constructs a trigger supporting the specified device type, copying
    * properties from the specified trigger.
    */
   public Trigger(final Trigger trigger, final DeviceType deviceType) {
      super(trigger, deviceType);
      
      content = new Content(trigger.getContent(), deviceType);
      styles = new HashMap/*<DeviceType, Style>*/(trigger.styles);
      
      // If the new device type is ALL, then fill in missing styles with
      // trigger's style.
      if ((deviceType == DeviceType.ALL) &&
          (trigger.getDeviceTypesVisibleTo().size() == 1)) {
         final DeviceType triggerDeviceType = trigger.getDeviceType();
         for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
              i.hasNext();) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            if (styles.get(aDeviceType) == null) {
               styles.put(aDeviceType, trigger.getStyle(triggerDeviceType));
            }
         }
      }
      
      borders = new HashMap/*<DeviceType, Style>*/(trigger.borders);

      // Listen to changes in the content, so that this trigger can adjust
      // its borders
      init();
   }

   //---------------------------------------------------------------------------
   
   private void init() {
      // Listen to changes in the content, so that this trigger can adjust
      // its borders
      content.addInteractionElementListener(contentHandler);
      content.addContentEventListener(contentHandler);
      content.addControlVoiceListener(contentHandler);
      
      addVoiceResponseText(0, content.getVoicePromptText());
   }
   
   //===========================================================================
   
   public void dispose() {
      content.removeInteractionElementListener(contentHandler);
      content.removeContentEventListener(contentHandler);
      content.removeControlVoiceListener(contentHandler);
   }
   
   //===========================================================================

   /**
    * Returns the content of this trigger.
    */
   public Content getContent() {
      return content;
   }

   //===========================================================================

   /**
    * Returns how this trigger should be rendered for the specified device
    * type. If no style has ever been explicitly set for the given device
    * type, then the style is HYPERLINK by default. 
    */
   public Style getStyle(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();

      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(deviceType),
         this + " supports " + getDeviceType() + ", not " + deviceType);
      
      final Style style = (Style)styles.get(deviceType);
      if (style == null) {
         return HYPERLINK;
      }
      else {
         return style;
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Sets how this trigger should be rendered for the specified device
    * type. 
    */
   public void setStyle(final DeviceType deviceType, final Style style) {
      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(deviceType),
         this + " supports " + getDeviceType() + ", not " + deviceType);
      
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext(); ) {
         
         final DeviceType aDeviceType = (DeviceType)i.next();
         styles.put(aDeviceType, style);
      }
   }

   //===========================================================================

   /**
    * Returns what the border of this trigger should be if it is rendered
    * as a button for the specified device type, or null if there is no border.
    */
   public GeneralPath getBorder(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();

      return (GeneralPath)borders.get(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets what the border of this trigger should be if it is rendered
    * as a button for the specified device type. 
    */
   public void setBorder(final DeviceType deviceType, final GeneralPath border) {
      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(deviceType),
         this + " supports " + getDeviceType() + ", not " + deviceType);

      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext(); ) {
         
         final DeviceType aDeviceType = (DeviceType)i.next();
         borders.put(aDeviceType, border);
         fireElementBorderUpdated(aDeviceType);
      }
   }

   //---------------------------------------------------------------------------

   public void setBounds(
      final DeviceType deviceType,
      final Rectangle2D newBounds) {

      super.setBounds(deviceType, newBounds);
      
      // TODO We actually want to resize the existing border, not
      // replace it with a round rectangle.
      if (newBounds == null) {
         setBorder(deviceType, null);
      }
      else {
         setBorder(deviceType,
                   new GeneralPath(
                      new RoundRectangle2D.Double(
                         newBounds.getX(),
                         newBounds.getY(),
                         newBounds.getWidth(),
                         newBounds.getHeight(),
                         CORNER_RADIUS,
                         CORNER_RADIUS)));
      }
   }

   //===========================================================================

   private void autoPositionForVisual(final DeviceType aDeviceType) {
      final Rectangle2D fullBounds =
         content.getFullSizeBounds(
            content.getPreferredDisplayMode(aDeviceType));
      
      final Rectangle2D contentBounds =
         new Rectangle2D.Double(fullBounds.getX(),
            fullBounds.getY(),
            fullBounds.getWidth(),
            fullBounds.getHeight());

      content.setBounds(aDeviceType, contentBounds);
      
      if (getStyle(aDeviceType) == BUTTON) {
         content.setTransform(
            aDeviceType,
            DEFAULT_BUTTON_CONTENT_TRANSFORM);
         setBounds(
            aDeviceType,
            new Rectangle2D.Double(
               0, 0,
               contentBounds.getWidth() +
                  2 * DEFAULT_BUTTON_CONTENT_TRANSFORM.getTranslateX(),
               contentBounds.getHeight() +
                  2 * DEFAULT_BUTTON_CONTENT_TRANSFORM.getTranslateY()));
      }
      else {
         setBounds(aDeviceType, contentBounds);
      }
      placeAfterAllControls(aDeviceType);
   }
   
   //---------------------------------------------------------------------------

   // @Override
   protected void autoPositionForDesktop() {
      final Style phoneStyle = (Style)styles.get(DeviceType.SMARTPHONE);
      if (phoneStyle != null) {
         setStyle(DeviceType.DESKTOP, phoneStyle);
      }
      autoPositionForVisual(DeviceType.DESKTOP);
   }

   //---------------------------------------------------------------------------

   // @Override
   protected void autoPositionForSmartphone() {
      final Style desktopStyle = (Style)styles.get(DeviceType.DESKTOP);
      if (desktopStyle != null) {
         setStyle(DeviceType.SMARTPHONE, desktopStyle);
      }
      autoPositionForVisual(DeviceType.SMARTPHONE);
   }

   //---------------------------------------------------------------------------

   // @Override
   protected void autoPositionForVoice() {
   }
   
   //---------------------------------------------------------------------------
   
   protected void setPrevVoiceControl(final Control control) {
      if (prevVoiceControl != null) {
         prevVoiceControl.removeControlVoiceListener(prevVoiceControlHandler);
      }
      prevVoiceControl = control;
      if (prevVoiceControl != null) {
         prevVoiceControl.addControlVoiceListener(prevVoiceControlHandler);
      }
   }

   protected void setupVoiceResponses() {
      for (int i = 0, n = getDialog().getNumConditions(); i < n; i++) {
         final Line2D existingLine = getVoiceResponseLine(i);

         // Find the destination of the trigger. That will be the
         // destination of the response.
         final NavConnection navConnection =
            getOutConnection(DeviceType.VOICE, new InvokeEvent(this), i);
         final ConnectionDest dest;
         if (navConnection != null) {
            dest = navConnection.getDest(DeviceType.VOICE);
         }
         else {
            dest = null;
         }
         
         final Point2D destBoundsCenterInTriggerCoords;
         if (dest != null) {
            final Rectangle2D destBoundsInTriggerCoords =
               globalToLocal(
                  DeviceType.VOICE,
                  dest.localToGlobal(DeviceType.VOICE,
                                     dest.getVoiceResponseDestBounds()));
            destBoundsCenterInTriggerCoords =
               new Point2D.Double(destBoundsInTriggerCoords.getCenterX(),
                                  destBoundsInTriggerCoords.getCenterY());
         }
         else {
            destBoundsCenterInTriggerCoords = null;
         }

         // Find the previous control with a prompt. That will be the source
         // of the response. Also count the number of triggers between this
         // trigger and the control with the prompt.
         Control prevControlWithPrompt;
         int numTriggersBetween = 0;
         {
            final PageRegion voiceRegion = getPageRegion(DeviceType.VOICE);
            prevControlWithPrompt =
               DamaskUtils.getPreviousLowLevelControl(voiceRegion, this);
            Rectangle2D prevPromptBounds = (prevControlWithPrompt == null)
               ? null
               : prevControlWithPrompt.getVoicePromptBounds();
            if (prevControlWithPrompt instanceof Trigger) {
               numTriggersBetween++;
            }
            
            while ((prevPromptBounds == null) && (prevControlWithPrompt != null)) {
               prevControlWithPrompt =
                  DamaskUtils.getPreviousLowLevelControl(
                     voiceRegion, prevControlWithPrompt);
               prevPromptBounds = (prevControlWithPrompt == null) ?
                  null : prevControlWithPrompt.getVoicePromptBounds();
               if (prevControlWithPrompt instanceof Trigger) {
                  numTriggersBetween++;
               }
            }
         }
         
         final Point2D sourceBoundsCenterInTriggerCoords;
         if (prevControlWithPrompt != null) {
            final Rectangle2D sourceBoundsInTriggerCoords =
               globalToLocal(
                  DeviceType.VOICE,
                  prevControlWithPrompt.localToGlobal(
                     DeviceType.VOICE,
                     prevControlWithPrompt.getBounds(DeviceType.VOICE)));
            sourceBoundsCenterInTriggerCoords =
               new Point2D.Double(sourceBoundsInTriggerCoords.getCenterX(),
                                  sourceBoundsInTriggerCoords.getCenterY());
         }
         else {
            sourceBoundsCenterInTriggerCoords = null;
         }
         
         // Set up the response
         final Point2D responseStartPt;
         final Point2D responseEndPt;
         if ((prevControlWithPrompt == null) && (dest == null)) {
            // This trigger must be the only control on this page
            final Rectangle2D balloonBounds =
               content.getBounds(DeviceType.VOICE);
            responseStartPt =
               new Point2D.Double(balloonBounds.getWidth() / 2, 0);
            responseEndPt = new Point2D.Double(balloonBounds.getWidth() / 2,
                                              Response.DEFAULT_LENGTH);
         }
         else {
            if (prevControlWithPrompt == null) {
               if (existingLine == null) {
                  responseStartPt =
                     new Point2D.Double(
                        destBoundsCenterInTriggerCoords.getX() +
                           Response.DEFAULT_LENGTH * numTriggersBetween, 
                        destBoundsCenterInTriggerCoords.getY() -
                           Response.DEFAULT_LENGTH);
               }
               else {
                  responseStartPt = existingLine.getP1();
               }
            }
            else {
               responseStartPt = sourceBoundsCenterInTriggerCoords;
            }
            
            if (dest == null) {
               if (existingLine == null) {
                  responseEndPt =
                     new Point2D.Double(
                        sourceBoundsCenterInTriggerCoords.getX() +
                           Response.DEFAULT_LENGTH * numTriggersBetween, 
                        sourceBoundsCenterInTriggerCoords.getY() +
                           Response.DEFAULT_LENGTH);
               }
               else {
                  responseEndPt = existingLine.getP2();
               }
            }
            else {
               responseEndPt = destBoundsCenterInTriggerCoords;
            }
         }
         
         setVoiceResponseLine(
            i, new Line2D.Double(responseStartPt, responseEndPt));
         setVoiceResponseSource(prevControlWithPrompt);
         setVoiceResponseDest(i, dest);
      }
   }
   
   
   /**
    * Updates the text in the voice response balloon, which is either the
    * content within this trigger, or the text in the voice response balloon
    * of the previous control if there is one.
    */
   protected void updateVoiceResponseText() {
      final PageRegion voiceRegion = getPageRegion(DeviceType.VOICE);
      if (voiceRegion != null) {
         final Control prevControl =
            DamaskUtils.getPreviousLowLevelControl(voiceRegion, this);
         if ((prevControl != null) &&
             !(prevControl instanceof Trigger) &&
             !(prevControl instanceof Content)) {
            setVoiceResponseTextList(prevControl.getVoiceResponseTextList());
         }
         else {
            final List/*<String>*/ newResponseTextList =
               new ArrayList/*<String>*/();
            newResponseTextList.add(content.getVoicePromptText());
            setVoiceResponseTextList(newResponseTextList);
         }
      }
   }

   //---------------------------------------------------------------------------

   // @Override
   public void setPageRegion(DeviceType aDeviceType, PageRegion aRegion) {
      final PageRegion oldRegion = getPageRegion(aDeviceType);
      super.setPageRegion(aDeviceType, aRegion);

      // If the region hasn't changed, then exit
      if (oldRegion == aRegion) {
         return;
      }

      // Initialize voice-specific properties
      if (aDeviceType == DeviceType.VOICE) {
         if (oldRegion != null) {
            oldRegion.removeElementContainerListener(pageRegionHandler);
         }
         if (aRegion != null) {
            aRegion.addElementContainerListener(pageRegionHandler);
         }
      }
   }

   //===========================================================================
   
   public String toString() {
      if (content == null) {
         return super.toString();
      }
      else {
         return super.toString() + " - " + content.contentsToString();
      }
   }

   //===========================================================================

   public Component createCopy(final DeviceType deviceType) {
      return new Trigger(this, deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      final Trigger clone = (Trigger)super.clone();
      clone.contentHandler = clone.new ContentHandler();
      clone.pageRegionHandler = clone.new PageRegionHandler();
      clone.prevVoiceControlHandler = clone.new PrevControlVoiceHandler();
      
      if (content != null) {
         clone.content = (Content)content.clone();
         clone.content.addInteractionElementListener(clone.contentHandler);
         clone.content.addContentEventListener(clone.contentHandler);
         clone.content.addControlVoiceListener(clone.contentHandler);
      }

      clone.styles = new HashMap/*<DeviceType, Style>*/(styles);

      clone.borders = new HashMap/*<DeviceType, Shape>*/();
      for (Iterator i = borders.keySet().iterator(); i.hasNext(); ) {
         final DeviceType deviceType = (DeviceType)i.next();
         clone.borders.put(
            deviceType, ((GeneralPath)borders.get(deviceType)).clone());
      }

      return clone;
   }

   //===========================================================================

   /**
    * Handles events from the content within this trigger. 
    */
   private class ContentHandler
      implements InteractionElementListener, ContentListener, ControlVoiceListener {

      private void reshape(final DeviceType deviceType) {
         final Content content = getContent();
         
         for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
              i.hasNext(); ) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            // If the style is hyperlink, set the bounds of the trigger
            // to match the label            
            if (getStyle(aDeviceType) == HYPERLINK) {
               setBounds(
                  aDeviceType, content.getBoundsInParentCoords(aDeviceType));
            }
         }
      }

      public void elementBoundsUpdated(InteractionElementEvent e) {
         if (e.getElement() == getContent()) {
            reshape(e.getDeviceType());
         }
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
         if (e.getElement() == getContent()) {
            reshape(e.getDeviceType());
         }
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }

      public void preferredDisplayModeChanged(ContentEvent e) {
         if (e.getContent() == getContent()) {
            reshape(e.getDeviceType());
         }
      }

      // @Override
      public void strokeAdded(ContentEvent e) {
         if (e.getContent() == getContent()) {
            reshape(e.getDeviceType());
         }
      }

      // @Override
      public void strokeRemoved(ContentEvent e) {
         if (e.getContent() == getContent()) {
            reshape(e.getDeviceType());
         }
      }

      // @Override
      public void strokesChanged(ContentEvent e) {
         if (e.getContent() == getContent()) {
            reshape(e.getDeviceType());
         }
      }

      // @Override
      public void textChanged(ContentEvent e) {
         if (e.getContent() == getContent()) {
            reshape(e.getDeviceType());
            updateVoiceResponseText();
         }
      }

      // @Override
      public void imageChanged(ContentEvent e) {
         if (e.getContent() == getContent()) {
            reshape(e.getDeviceType());
         }
      }

      // @Override
      public void promptTextChanged(ControlVoiceEvent e) {
         if (e.getControl() == getContent()) {
            reshape(DeviceType.VOICE);
            updateVoiceResponseText();
         }
      }

      // @Override
      public void promptBoundsChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseSourceChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseDestChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseLineChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseTextChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void promptTextIsSyncedWithText(ContentEvent e) {
      }

      // @Override
      public void promptTextIsUnsyncedWithText(ContentEvent e) {
      }
   }
   
   //===========================================================================
   
   private class PrevControlVoiceHandler implements ControlVoiceListener {
      // @Override
      public void promptTextChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void promptBoundsChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseSourceChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseDestChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseLineChanged(ControlVoiceEvent e) {
      }

      // @Override
      public void responseTextChanged(ControlVoiceEvent e) {
         updateVoiceResponseText();
      }
   }

   //===========================================================================

   /**
    * Listens to elements being added and removed from the same page region
    * as this control's. 
    */
   private class PageRegionHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         // If this element was just added, or if the element just added was
         // was added just after this control, then update the voice
         // responses.
         if (e.getElement() == Trigger.this) {
            setupVoiceResponses();
            updateVoiceResponseText();
            setPrevVoiceControl(
               getPageRegion(DeviceType.VOICE).getPreviousControl(Trigger.this));
         }
         else {
            final Control newPrev =
               getPageRegion(DeviceType.VOICE).getPreviousControl(Trigger.this);
            if (e.getElement() == newPrev) {
               setupVoiceResponses();
               updateVoiceResponseText();
               setPrevVoiceControl(newPrev);
            }
         }
      }

      public void elementRemoved(ElementContainerEvent e) {
         // If the element after this control was just removed, then update
         // the voice responses.
         if (e.getElement() == prevVoiceControl) {
            setupVoiceResponses();
            updateVoiceResponseText();
            setPrevVoiceControl(
               getPageRegion(DeviceType.VOICE).getPreviousControl(Trigger.this));
         }
      }
   }   
}
