package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import javax.swing.event.*;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

public class SimpleGestureObjectPanel extends JPanel
  implements GestureObjectDisplay {
  protected PropertyChangeListener propChangeListener =
    new MyPropChangeListener();
  protected EventListenerList listenerList = new EventListenerList();
  protected GesturePointsDisplay pointsDisplay;
  protected double scale = 1.0;

  public SimpleGestureObjectPanel()
  {
    this(null);
  }

  public SimpleGestureObjectPanel(GestureObject object)
  {
    super(new BorderLayout());
    pointsDisplay = new GesturePointsDisplay();
    setDisplayedObject(object);
    pointsDisplay.setOffset(5, 5);
    add(pointsDisplay, BorderLayout.CENTER);
  }

  public void setBackground(Color bg)
  {
    super.setBackground(bg);
    if (pointsDisplay != null) {
      pointsDisplay.setBackground(bg);
    }
  }
  
  public void setDisplayedObject(GestureObject object)
  {
    setGesture((Gesture) object);
  }

  public void setGesture(Gesture g)
  {
    Gesture oldValue = pointsDisplay.getGesture();
    if (oldValue != g) {
      if (oldValue != null) {
	oldValue.removePropertyChangeListener(propChangeListener);
      }
      pointsDisplay.setGesture(g);
      if (g != null) {
	g.addPropertyChangeListener(propChangeListener);
      }
    }
  }
  
  public GestureObject getDisplayedObject()
  {
    return pointsDisplay.getGesture();
  }

  public String getInputGestureTitle()
  {
    return "Draw a replacement example gesture";
  }

  public boolean canAcceptGesture()
  {
    return true;
  }

  public boolean gestureDrawn(Gesture gesture)
  {
    Gesture currentGesture = pointsDisplay.getGesture();
    /*
    System.out.println("GOP.gestureDrawn: setting points for " +
		       toString(currentGesture));
    */
    gesture.normalize();
    currentGesture.setPoints(gesture.getPoints());
    return true;
  }

  public void addActionListener(ActionListener l)
  {
    listenerList.add(ActionListener.class, l);
  }

  public void removeActionListener(ActionListener l)
  {
    listenerList.remove(ActionListener.class, l);
  }

  public boolean isCommandValid(int id)
  {
    return false;
  }

  public void doCommand(int id)
  {
    System.err.println("SimpleGestureObjectPanel handles no commands"
		       + " (was given id " + id + ")");
  }

  private static String toString(GestureObject g)
  {
    return g.toString()
      /*+ ((g instanceof Gesture) ?
	("/" + ((Gesture) g).getPoints().toString()) : "")*/
      ;
  }

  public void setScale(double s)
  {
    scale = s;
    repaint();
  }

  public double getScale()
  {
    return scale;
  }

  public void paint(Graphics g)
  {
    Graphics2D g2d = (Graphics2D) g;
    AffineTransform t = g2d.getTransform();
    g2d.scale(scale, scale);
    super.paint(g);
    g2d.setTransform(t);
  }
  
  public void addMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.add(ChangeListener.class, listener);
  }

  public void removeMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.remove(ChangeListener.class, listener);
  }

  protected class MyPropChangeListener extends EnableListener {
    public MyPropChangeListener()
    {
      super(SimpleGestureObjectPanel.this);
    }
  }
}
