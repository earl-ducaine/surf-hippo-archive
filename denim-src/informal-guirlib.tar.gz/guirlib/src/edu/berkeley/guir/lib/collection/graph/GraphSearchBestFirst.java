//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

/**
 * A best-first-search on Graph. Not implemented yet.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Dec 20 1997, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.5/1.1.0, Nov 22 2002, JH
 *               Updated for new Graph APIs
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.1.4
 * @version GUIRLib-v1.5/1.1.0, Nov 22 2002
 */
public class GraphSearchBestFirst
   implements GraphSearch {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   Graph     g;                 // our reference to the graph

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   SEARCH METHODS   ====================================================

   /**
    * Perform a best-first search on the graph, with the specified start
    * and target nodes.
    *
    * @param  strFrom is the name of the starting node.
    * @param  strTo   is the name of the target node.
    * @return Returns the first successful Path found from the start node
    *         to the target node. The Path is empty if no successful Path
    *         is found, or if either the start or target node does not
    *         exist in the Graph.
    */
   public GraphPath search(Graph g, String strFrom, String strTo) {

      this.g = g;
      GraphPath p = new GraphPath();

      throw new RuntimeException("This search not implemented yet.");
   } // of method

   //===   SEARCH METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
