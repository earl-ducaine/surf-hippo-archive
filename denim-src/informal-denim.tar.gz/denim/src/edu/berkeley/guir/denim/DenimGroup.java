package edu.berkeley.guir.denim;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.HashSet;
import java.util.Set;
import java.util.Iterator;

import edu.berkeley.guir.denim.DenimConstants;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.interpreters.DenimGestureInterpreter;
import edu.berkeley.guir.denim.interpreters.DenimScribbledTextInterpreter;
import edu.berkeley.guir.denim.interpreters.GroupInterpreter;
import edu.berkeley.guir.denim.interpreters.SemanticCircleSelectInterpreter;
import edu.berkeley.guir.lib.awt.geom.Polygon2D;
import edu.berkeley.guir.lib.satin.image.SatinImageLib;
import edu.berkeley.guir.lib.satin.interpreter.DefaultMultiInterpreterImpl;
import edu.berkeley.guir.lib.satin.interpreter.Interpreter;
import edu.berkeley.guir.lib.satin.interpreter.MultiInterpreter;
import edu.berkeley.guir.lib.satin.objects.PatchImpl;
import edu.berkeley.guir.lib.satin.objects.Style;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;
import edu.berkeley.guir.lib.satin.objects.GraphicalObject;

import edu.berkeley.guir.denim.io.*;
import edu.berkeley.guir.lib.satin.graphics.*;

/**
 * A group that can hold arbitrary objects within a DENIM panel.
 * First used to group radio buttons logically.
 * 
 * Also, a DenimGroup can now be used for a second distinct purpose:
 * to merge hyperlink sources into a single larger anchor.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-26-2003 JL
 *                    Created class DenimGroup.
 *             1.0.1  07-07-2003 MR and YL
 *                    Implements DenimHyperlinkContents
 *                    Added
 *                       public GraphicalObject add(GraphicalObject gob, int pos)
 *                       public boolean getShouldGroupContainedAnchors
 *                       public void setHyperlink(boolean flag)
 *                    
 * 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~marcr/">Marc Ringuette</A> (
 *          <A HREF="mailto:marcr@cs.berkeley.edu">marcr@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 1.0.1, 07-07-2003
 */


public class DenimGroup
	extends PatchImpl
	implements DenimRadioButtonInstanceContainer, DenimConstants { //, DenimHyperlinkContents {

   private boolean shouldGroupContainedAnchors=true;
   private Style prevContainedTimedStrokeStyle;
   private Set radioButtons;      // contains the radio buttons in this group

   //-----------------------------------------------------------------

	/**
	 * Constructor for DenimGroup.
	 */
	public DenimGroup() {
		super();
      init();
	}

   //-----------------------------------------------------------------

	/**
	 * Constructor for DenimGroup.
	 * @param stk
	 */
	public DenimGroup(TimedStroke stk) {
		super(stk);
      init();
	}

   //-----------------------------------------------------------------

	/**
	 * Constructor for DenimGroup.
	 * @param s
	 */
	public DenimGroup(Shape s) {
		super(s);
      init();
	}

   //-----------------------------------------------------------------

	/**
	 * Constructor for DenimGroup.
	 * @param r
	 */
	public DenimGroup(Rectangle2D r) {
		super(r);
      init();
	}

   //-----------------------------------------------------------------

	/**
	 * Constructor for DenimGroup.
	 * @param newPoly
	 */
	public DenimGroup(Polygon2D newPoly) {
		super(newPoly);
      init();
	}

   //-----------------------------------------------------------------

	/**
	 * Constructor for DenimGroup.
	 * @param newPoly
	 */
	public DenimGroup(Polygon newPoly) {
		super(newPoly);
      init();
	}

   //-----------------------------------------------------------------

   /**
    * Performs common initializations.
    */
   private void init() {
      Style style = this.getStyle();
      style.setDrawColor(DenimConstants.DEFAULT_GROUP_COLOR);
      style.setFillColor(DenimConstants.DEFAULT_SCRIBBLE_BACKGROUND_COLOR);
      style.setDashArray(DenimConstants.DEFAULT_GROUP_DASH_ARRAY);
      this.setStyle(style);
      
      this.setHasClosedBoundingPoints(true);

      radioButtons = new HashSet();
      
      setupInterpreters();
   }
   
   public Color getPrintFill() {
	   return null;
   }
   
   public Color getPrintDraw() {
	   return DEFAULT_GROUP_COLOR;
   }

   //-----------------------------------------------------------------

   /**
    * Sets up the interpreters for the sketch.
    */
   private void setupInterpreters() {
      
      //// Setup the gesture interpreter.
      Interpreter      intrp;

      MultiInterpreter gestureIm = new DefaultMultiInterpreterImpl();

      intrp = new SemanticCircleSelectInterpreter();
      intrp.setAcceptLeftButton(false);
      gestureIm.add(intrp);

      intrp = new DenimGestureInterpreter();
      intrp.setAcceptLeftButton(false);
      gestureIm.add(intrp);

      this.setGestureInterpreter(gestureIm);

      //// Setup the ink interpreter.
      MultiInterpreter inkIm = new DefaultMultiInterpreterImpl();

      inkIm.add(new DenimScribbledTextInterpreter());
      inkIm.add(new GroupInterpreter());
      inkIm.setAcceptMiddleButton(false);
      inkIm.setAcceptRightButton(false);
      
      this.setInkInterpreter(inkIm);

      this.setAddRightButtonStrokes(false);   // only allowed for sheets
      this.setAddMiddleButtonStrokes(false);  // only allowed for sheets
   } // of method

   //===========================================================================
   //===   RADIO BUTTON CONTAINER METHODS   ====================================

   public boolean addRadioButton(DenimRadioButtonInstance radioButton) {
      return radioButtons.add(radioButton);
   }

   public boolean removeRadioButton(DenimRadioButtonInstance radioButton) {
      return radioButtons.remove(radioButton);
   }

   public Set getRadioButtons() {
      return radioButtons;
   }

   //===   RADIO BUTTON CONTAINER METHODS   ====================================
   //===========================================================================

   //===========================================================================
   //===   LINK ANCHOR CONTAINER METHODS   ====================================


   // overrides 'add' to check if a component is added to
   // the group; if so, turn off shouldGroupContainedAnchors
   public GraphicalObject add(GraphicalObject gob, int pos) {
      if (gob instanceof DenimComponent) {
         this.shouldGroupContainedAnchors=false;
         // bug:  what if it already has an outgoing link?
      }
      if (gob instanceof TimedStroke) {
      	this.prevContainedTimedStrokeStyle=gob.getStyle();
      	// intentional buglet:  only saves one style for all 
      	// contained timedstrokes, for re-coloring on arrow deletion.
      }
      return super.add(gob,pos);
   } // of method
   
   public boolean getShouldGroupContainedAnchors() {
      return shouldGroupContainedAnchors;
   }

   /**
    * check components
    */   
   private void checkComponents() {
       Iterator it = this.getForwardIterator();
       while(it.hasNext())
       {
           GraphicalObject gob = (GraphicalObject)it.next();
           if (gob instanceof DenimComponentInstance) {
             this.shouldGroupContainedAnchors=false;
             return;
           }
       }
       this.shouldGroupContainedAnchors = true;
   }
   
   public void setHyperlink(boolean flag) {

      Iterator it = this.getForwardIterator();
      
      while(it.hasNext()) {
         GraphicalObject child = (GraphicalObject)it.next();
         
         if(child instanceof ScribbledText)
         {
            ((ScribbledText)child).setHyperlink(flag);
         }
         else if(child instanceof TypedText)
         {
            ((TypedText)child).setHyperlink(flag);
         }
         else if(child instanceof TimedStroke)
         {
             if (flag) child.getStyleRef().setDrawColor(DEFAULT_LINK_COLOR);       
             else if (prevContainedTimedStrokeStyle!=null) 
                child.setStyle(prevContainedTimedStrokeStyle);
         }
         else {
         	// don't change its color, I guess...
         }
      }
   }
   
	//-----------------------------------------------------------------
	
    protected void defaultRender(SatinGraphics g)
    {
        this.checkComponents();        
        
        // if print
        if(SatinImageLib.imageConvertingRender||HtmlExport.isExporting())
        {
            renderChildren(g);
        }
        else
        {
            g.fill(getLocalBoundingPoints2DRef());
            //g.draw(getLocalBoundingPoints2DRef());
            Polygon2D p = (Polygon2D)getLocalBoundingPoints2DRef().clone();
            p.transform(g.getTransform());
            try
            {
                g.pushTransform(g.getTransform().createInverse());
            }
            catch(Exception ex)
            {
                g.pushTransform(new AffineTransform());
            }
            g.draw(p);
            g.popTransform();

            renderChildren(g);
        }
    } // of defaultRender
   //===   LINK ANCHOR CONTAINER METHODS   ====================================
   //===========================================================================

   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Returns a deep clone of this group.
    */
   public Object deepClone() {
      return deepClone(new DenimGroup());
   }

   //-----------------------------------------------------------------

   /**
    * Sets the clone parameter to a deep clone of this group,
    * and returns it.
    */
   public Object deepClone(DenimGroup clone) {
      super.deepClone(clone);
      return clone;
   }
   

   //===   CLONE METHODS   =====================================================
   //===========================================================================

}
