//// See bottom of file for software license

package edu.berkeley.guir.lib.satin;


import java.awt.geom.*;
import java.util.*;
import java.awt.*;

/**
 * Render Server to optimize the render of Satin
 *             (1) idle period predication with RenderChecker
 *             (2) render requests buffering and merging 
 *             (3) real-time rendering and conditional rendering
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v2.1-2.0.0, Nov 8 2002, YL
 *               Created class
 *             - SATIN-v2.1-2.0.0, Jun 4 2003, YL
 *               Added latest render time
 * 
 * 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version SATIN-v2.1-2.0.0, Jun 4 2003
 */


public class RenderServer extends Thread
					implements SatinConstants
					 {

      // actual predication time for idle rendering: for simplifing implementation purpose
      // because predication time basically stays around this amount.
      static long optimizedInterval = 1600;

      // check event queue for collision detection
      // adjustable anticipation time
      private static int anticipationTime = 1300;     
      private static final double beta = 0.1;
      private static final double base = (-1)*Math.log(beta);
      private static double alpha = base/anticipationTime;      
      private static final double step = alpha/30;

      // merge effectiveness      
      private static final double mergeEffectiveness = 0.3;
	  
      // thread control variables
      boolean isStop = false;
      boolean isSuspended = false;
      Thread renderThread = null;	  
	  
      Rectangle2D targetRect = null;
      boolean sceneGraphChanged = true;
      boolean realtimeRender = false;
      double flushSpeed = 1;
      long _flushTimeStamp = 0;
	  
      Sheet sheetInstance = null;
      
      /**
       * for serial flush
       */

      private boolean needSerialFlush = false;
      private Vector serialBuffer = new Vector();
      

      //=================================================================
      //===   RENDER QUEUE OF RENDER SYSTEM   ===========================
	
      class RequestQueue extends Vector {
	
         synchronized public void pushARequest(Rectangle2D r)
         {
            this.add(r.clone());
         }
	
         synchronized public Rectangle2D pullARequest()
         {
            if(this.size()>0)
            {
               Rectangle2D r = (Rectangle2D)this.firstElement();
               this.remove(r);
               return r;
            }
            else
               return null;
         }
      }
	
      RequestQueue _queue = new RequestQueue();

      //===   RENDER QUEUE OF RENDER SYSTEM   ===========================
      //=================================================================

	  
      public RenderServer(Sheet instance) {
         sheetInstance = instance;
      }
     
      //--------------------------------------------------------------
      
      /**
       * adjust idle predication time by exponential decay function
       */

      public void adjustIdleAnticipation(boolean isIncrease) {
         
         int flag;
         
         if(isIncrease)
         {
            flag = 1;
         }
         else
         {
            flag = -1;
         }         
         
         double deltaAlpha = flag*step*Math.random();
         alpha += deltaAlpha;
                  
         anticipationTime = (int)(base/alpha);
      }     

      //--------------------------------------------------------------
      
      public void startSerialFlush() {
         this.needSerialFlush = true;
      }
      
      //--------------------------------------------------------------
      
      public void endSerialFlush() {
         this.needSerialFlush = false;
      }
            
      //--------------------------------------------------------------
      
      /**
       * to assure the render request will not be ignored
       */
      
      public void run() {
         
         if(sheetInstance!=null)
         {
            while(!serialBuffer.isEmpty())
            {
               Rectangle repaintRect = (Rectangle)serialBuffer.get(0);
               serialBuffer.remove(0);
               
               if(repaintRect!=null)
               {
                  sceneGraphChanged = true;
               
                  sheetInstance.paintImmediately(
                     (int)repaintRect.getMinX(),(int)repaintRect.getMinY(),
                     (int)repaintRect.getWidth(),(int)repaintRect.getHeight());

                  Toolkit.getDefaultToolkit().sync();

               }
               
               while(sheetInstance.isPaintFinished()==false);
            }
            
            flush(DAMAGE_NOW);
         }
         
      }
     
      //--------------------------------------------------------------
      
      /**
       * evaluate merging effectiveness by area
       */
     
      private boolean evaluateEffectiveness(Rectangle2D src, Rectangle2D added) {
     
         Rectangle2D merge = new Rectangle2D.Double();
         Rectangle2D.union(src, added, merge);
         
         double areaSum = src.getHeight()*src.getWidth()+added.getHeight()*added.getWidth();
         double areaMerge = merge.getWidth()*merge.getHeight();
         
         if(areaSum/areaMerge>=mergeEffectiveness)
         {
            return true;
         }
         else
         {
            return false;
         }
      }
     
      //--------------------------------------------------------------
      
      public void startRealtimeRender() {
         realtimeRender = true;
         this.start();
      }
	  
      //--------------------------------------------------------------	  
	  
      public void setFlushSpeed(double p)
      {
         flushSpeed = p;
      }

      //--------------------------------------------------------------
      	  
      public double getFlushSpeed()
      {
         return flushSpeed;
      }

      //--------------------------------------------------------------
      	  
      public void endRealtimeRender()
      {
         realtimeRender = false;
	  	
         while(_queue.size()>0)
         {
            flush(flushSpeed);		
         }
	  	
      }
	  
      //--------------------------------------------------------------
      
      public boolean isSceneGraphChanged() {
         return sceneGraphChanged;
      }
      
      //--------------------------------------------------------------
	  
      // Generally, you don't need to call this method
      public void setSceneGraphChanged(boolean b) {
         sceneGraphChanged = b;
      }
      
      //--------------------------------------------------------------
      
      /**
       * flush with effectiveness measurement
       */
      
      public void effectiveFlush(int sync)
      {
         Rectangle2D repaintRect = null;
   
         while(_queue.size()>0)
         {
            repaintRect = _queue.pullARequest();
            
            while(_queue.size()>0)
            {
               Rectangle2D r = _queue.pullARequest();
               
               if(this.evaluateEffectiveness(repaintRect, r))
               {
                  Rectangle2D.union(repaintRect, r, repaintRect);
               }
               else
               {
                  // return the render request back to the Queue
                  _queue.pushARequest(r);
                  
                  // conduct a merged rendering
                  sceneGraphChanged = true;
               
                  if(sync == DAMAGE_NOW)
                     sheetInstance.paintImmediately(
                        (int)repaintRect.getMinX(),(int)repaintRect.getMinY(),
                        (int)repaintRect.getWidth(),(int)repaintRect.getHeight());
                  else
                     sheetInstance.repaint(
                        (int)repaintRect.getMinX(),(int)repaintRect.getMinY(),
                        (int)repaintRect.getWidth(),(int)repaintRect.getHeight());
                  break;
               }
            }
         }
   
   
         if(repaintRect!=null)
         {
            sceneGraphChanged = true;
         
            if(sync == DAMAGE_NOW)
               sheetInstance.paintImmediately(
                  (int)repaintRect.getMinX(),(int)repaintRect.getMinY(),
                  (int)repaintRect.getWidth(),(int)repaintRect.getHeight());
            else
               sheetInstance.repaint(
                  (int)repaintRect.getMinX(),(int)repaintRect.getMinY(),
                  (int)repaintRect.getWidth(),(int)repaintRect.getHeight());
         }
      }
      
      
      //--------------------------------------------------------------
      
      
      public long getLatestRenderTimeStamp() {
         return _flushTimeStamp;
      }
      

      //--------------------------------------------------------------
      	
      /**
       * Simplified version of effectiveFlush
       * merge the render requests in the render queue and execut rendering  
       * @param part, the percentage of render requests in the queue
       */

      public void flush(double part)
      {
         if(_queue.size()==0)
            return;
	  		
         int num = (int)(_queue.size()*part);
	    
         if(num==0)
            num = 1;
	    
         Rectangle2D repaintRect = _queue.pullARequest();
         num--;
	    
         Rectangle2D r = null;
	
         if(repaintRect!=null&&num>0)
         {
            r = _queue.pullARequest();
            num--;
         }
	
         while(r!=null&&num>0)
         {
            Rectangle2D.union(repaintRect, r, repaintRect);
            r = _queue.pullARequest();
            num--;
         }
	
         if(repaintRect!=null)
         {
            sceneGraphChanged = true;
	    	
            sheetInstance.repaint(
               (int)repaintRect.getMinX(),(int)repaintRect.getMinY(),
               (int)repaintRect.getWidth(),(int)repaintRect.getHeight());
         }
      }

      //--------------------------------------------------------------
      	
      /**
       * 
       * Simplified version of effectiveFlush: Just merge everything together
       * since most interactions happen locally at a period.
       * 
       * merge the render requests in the render queue and execut rendering  
       */
	
      public void flush(int sync)
      {
         Rectangle2D repaintRect = _queue.pullARequest();
         Rectangle2D r = null;
	
         if(repaintRect!=null)
         {
            r = _queue.pullARequest();
         }
         else
         {
            return;
         }
	
         while(r!=null)
         {
            Rectangle2D.union(repaintRect, r, repaintRect);
            r = _queue.pullARequest();
         }
	
         if(repaintRect!=null)
         {
            sceneGraphChanged = true;
            
            _flushTimeStamp = System.currentTimeMillis();
	    	
            if(sync == DAMAGE_NOW)
               sheetInstance.paintImmediately(
                  (int)repaintRect.getMinX(),(int)repaintRect.getMinY(),
                  (int)repaintRect.getWidth(),(int)repaintRect.getHeight());
            else
               sheetInstance.repaint(
                  (int)repaintRect.getMinX(),(int)repaintRect.getMinY(),
                  (int)repaintRect.getWidth(),(int)repaintRect.getHeight());
         }
      }


      //--------------------------------------------------------------
      
      /**
       * to add a render request to the render queue with a certain render type
       */
	
      public void sendARequest(Rectangle2D repaintRect, int sync)
      {
         if(needSerialFlush)
         {
            if(_queue.isEmpty()==false)
            {
               flush(DAMAGE_LATER);
            }
            
            this.serialBuffer.add(repaintRect.clone());
            
            if(this.isAlive()==false)
            {
               this.start();
            }
         }
         else
         {
            _queue.pushARequest(repaintRect);
            
//            if(this.isAlive()==false&&this.serialBuffer.isEmpty())
//            {
      	  	 
            if(realtimeRender)
            {
               flush(DAMAGE_IDLE);
            } 	
   	  	
            if(sync==DAMAGE_NOW || sync==DAMAGE_LATER)
            {
               flush(sync);
            }
            else if(sync==DAMAGE_IDLE)
            {
   		 	
            }
            else
            {
               throw new RuntimeException("What the heck did you pass damage()?");
            }
               
//            }
         }
      }
      
      public boolean isRenderQueueEmpty() {
    	  return this._queue.isEmpty();
      }

}

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/

