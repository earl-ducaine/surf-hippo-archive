package edu.berkeley.guir.lib.gesture;

import java.lang.System;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.awt.*;

/**
 * For testing the GestureInteractor class
 */
public class GestureInteractorTest extends JPanel
implements KeyListener {

  GestureDisplay gestureDisplay;
  GestureInteractor gi;
  int width, height;
  Frame frame;
  
  public static void main(String args[])
  {
    JFrame frame;

    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    };

    frame = new JFrame("GITest");
    frame.addWindowListener(l);
    GestureInteractorTest me = new GestureInteractorTest(args, frame);
    frame.getContentPane().setLayout(new BorderLayout());
    frame.getContentPane().add(me, BorderLayout.CENTER);

    JMenuBar menuBar = new JMenuBar();
    JMenu menu = new JMenu("File");
    JMenuItem item = new JMenuItem("Quit");
    item.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	System.exit(0);
      }
    });
    menu.add(item);
    menuBar.add(menu);
    
    frame.setJMenuBar(menuBar);
    
    //myPanel p = new myPanel();
    //frame.add("West", p);
    frame.pack();
    frame.setVisible(true);
    me.requestFocus();
  }

  public GestureInteractorTest(String[] args, Frame f)
  {
    super(true);
    width = 200;
    height = 200;
    frame = f;
    addKeyListener(this);

    Box box = new Box(BoxLayout.X_AXIS);
    add(box, BorderLayout.CENTER);

    JPanel panel = new JPanel(new BorderLayout());
    gi = new GestureInteractor();
    gi.setPreferredSize(new Dimension(width, height));
    gi.setBorder(BorderFactory.createEtchedBorder());
    //panel.setPreferredSize(new Dimension(200,200));
    panel.add(gi, BorderLayout.CENTER);
    box.add(panel);

    gestureDisplay = new GestureDisplay();
    gestureDisplay.setPreferredSize(new Dimension(200,200));
    gestureDisplay.
      setBorder(BorderFactory.createTitledBorder(null, "foo",
						 TitledBorder.CENTER,
						 TitledBorder.ABOVE_TOP));
    box.add(gestureDisplay);
    
    gi.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e)
      {
	GestureInteractor interactor = (GestureInteractor) e.getSource();
	// sanity check
	if (interactor != gi) {
	  System.err.println("interactor (" + interactor + ") != gi (" +
			     gi + ")");
	}
	Gesture	g = interactor.getGesture();
	gestureDisplay.setGesture(g);
      }
    });
  }

  private void resize(int delta)
  {
    width += delta;
    height += delta;
    System.err.println("new size is " + width + "x" + height);
    gi.setPreferredSize(new Dimension(width, height));
    gi.invalidate();
  }

  public void keyTyped(KeyEvent e)
  {
    switch (e.getKeyChar()) {
      case ' ':
	resize(10);
	break;
      case '':
      case 'b':
	resize(-10);
	break;
      case 'c':
	gi.setGesture(null);
	break;
      case 'p':
	Window w = (Window) getTopLevelAncestor();
	System.err.println("Packing...");
	w.pack();
	System.err.println("Done packing");
	break;
      default:
	System.err.println("Unknown char '" + e.getKeyChar() + "'");
    }
  }
  
  public void keyPressed(KeyEvent e)
  {
  }
  
  public void keyReleased(KeyEvent e)
  {
  }
}
