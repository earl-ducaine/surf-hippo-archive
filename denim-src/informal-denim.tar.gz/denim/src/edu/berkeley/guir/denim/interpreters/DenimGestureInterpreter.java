//// See bottom of source code for software license

package edu.berkeley.guir.denim.interpreters;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;
import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.recognizer.rubine.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.interpreter.commands.*;
import edu.berkeley.guir.lib.satin.stroke.*;

/**
 * Standard gestures, like cut, copy, paste, delete, and pan.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-16-2000 JL
 *                    Created DenimGestureInterpreter.
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 */
public class DenimGestureInterpreter
   extends StandardGestureInterpreter
   implements DenimConstants {

   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================



   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================


   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public DenimGestureInterpreter() {
      super("denim_all.gsa", Denim.class);
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Denim Gesture Interpreter");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   STROKE INTERPRETER METHODS   ========================================

   /**
    * Change how the interpreter behaves, depending on the zoom level.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject().getSheet();
      double curscale = sheet.getAbsScale();
      if (curscale >= INTERPRETER_TRANSITION) {
         setDeep();
      }
      else {
         setShallow();
      }

      super.handleSingleStroke(evt);
      
      sheet.setModified(true);
   } // of handleSingleStroke

   //===   STROKE INTERPRETER METHODS   ========================================
   //===========================================================================


   //===========================================================================
   //===   HANDLE FEEDBACK   ===================================================


   /**
    * Provides feedback in a non-sticky manner
    * (That is: the feedback stroke is also panned)
    */
   protected void provideFeedback(String gestureName, Point2D location) {
      DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject().getSheet();
      // Setup feedback directly in the sheet
      Classifier currentClassifier = ((RubineRecognizer)intrp.getRecognizer())
             .getClassifier();
      DenimUtils.provideFeedback(currentClassifier, gestureName, sheet, location);
   }

   /**
    * Provides feedback in a sticky manner
    * (That is: the feedback stroke is not panned)
    */
   protected void provideFeedbackSticky(String gestureName, Point2D location) {
      DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject().getSheet();
      // Setup the feedback pointers in the sheet (see sheet.paintComponent)
      Classifier currentClassifier = ((RubineRecognizer)intrp.getRecognizer())
             .getClassifier();
      TimedStroke gestureStroke = DenimUtils.getGestureFeedbackStroke(currentClassifier, gestureName);
      sheet.setFeedbackRefStroke(gestureStroke);
      sheet.setFeedbackRefLocation(location);

      // Set a timer to remove the feedback again
      javax.swing.Timer theTimer = new javax.swing.Timer
         (1000, new FeedbackTimerAction(sheet));
      theTimer.setRepeats(false);
      theTimer.start();
   }

   /**
    * FeedbackTimerAction used by method provideFeedbackSticky
    *
    */
   private static class FeedbackTimerAction
      implements ActionListener {

      public DenimSheet theSheet;

      public FeedbackTimerAction (DenimSheet aSheet) {
         super();
         theSheet = aSheet;
      }

      public void actionPerformed(ActionEvent aEvt) {
         theSheet.setFeedbackRefStroke(null);
         theSheet.damage(DAMAGE_NOW);
      }
   }

   //===   HANDLE FEEDBACK   ===================================================
   //===========================================================================


   //===========================================================================
   //===   HANDLE GESTURE METHODS   ============================================


   protected void handleUndo(TimedStroke stk) {
      // Provide feedback
      provideFeedback("UndoA", stk.getLocation2D(COORD_ABS));

      super.handleUndo(stk);
   }

   protected void handleRedo(TimedStroke stk) {
      // Provide feedback
      provideFeedback("RedoA", stk.getLocation2D(COORD_ABS));

      super.handleRedo(stk);
   }

   /**
    * Cut whatever intersects the stroke.
    * Override this method if you want.
    */
   protected void handleCut(TimedStroke stk) {
      // Provide feedback
      provideFeedback("CutSmallA", stk.getLocation2D(COORD_ABS));

      // Get the things we touch, and cut
      GraphicalObjectCollection gobcol = getGraphicalObjectsTouching(stk, 2);
      cmdqueue.doCommand(new DenimCutCommand(gobcol.getForwardIterator()));
   } // of method

   protected void handleCopy(TimedStroke stk) {
      // Provide feedback
      provideFeedback("Copy", stk.getLocation2D(COORD_ABS));

      // Get the things we touch, and copy
      GraphicalObjectCollection gobcol = getGraphicalObjectsTouching(stk, 2);
      cmdqueue.doCommand(new DenimCopyCommand(gobcol.getForwardIterator()));
   }

   protected void handlePaste(TimedStroke stk) {
      // Provide feedback
      provideFeedback("Paste", stk.getLocation2D(COORD_ABS));

      DenimSheet  sheet = (DenimSheet)getAttachedGraphicalObject().getSheet();
      Rectangle2D rect  = stk.getBounds2D(COORD_ABS);
      Point2D     caretAbsPt = new Point2D.Float(
         (float) (rect.getX() + rect.getWidth()/2),
         (float) (rect.getY() + rect.getHeight()));

      sheet.pasteAt(caretAbsPt);
   } // of handlePaste


   /**
    * Delete whatever is in the center of the stroke (except ourself of course).
    * Override this method if you want.
    */
   protected void handleDelete(TimedStroke stk) {
      provideFeedback("delete", stk.getLocation2D(COORD_ABS));

      GraphicalObjectCollection gobcol = getGraphicalObjectsTouching(stk, 2);
      gobcol.remove(getAttachedGraphicalObject());
      cmdqueue.doCommand(new DenimDeleteCommand(gobcol.getForwardIterator()));
   } // of handleDelete

   protected void handleViewPort(String str, TimedStroke stk) {
      int direction = getViewPortDirection(str);

      switch (direction) {
      case SatinConstants.DIR_LEFT:
         provideFeedbackSticky("ViewPortLeft", stk.getLocation2D(COORD_ABS));
         break;
      case SatinConstants.DIR_RIGHT:
         provideFeedbackSticky("ViewPortRight", stk.getLocation2D(COORD_ABS));
         break;
      case SatinConstants.DIR_UP:
         provideFeedbackSticky("ViewPortUp", stk.getLocation2D(COORD_ABS));
         break;
      case SatinConstants.DIR_DOWN:
         provideFeedbackSticky("ViewPortDown", stk.getLocation2D(COORD_ABS));
         break;
      case SatinConstants.DIR_UP_RIGHT:
         provideFeedbackSticky("ViewPortDiagUpRight", stk.getLocation2D(COORD_ABS));
         break;
      case SatinConstants.DIR_UP_LEFT:
         provideFeedbackSticky("ViewPortDiagUpLeft", stk.getLocation2D(COORD_ABS));
         break;
      case SatinConstants.DIR_DOWN_RIGHT:
         provideFeedbackSticky("ViewPortDiagDownRight", stk.getLocation2D(COORD_ABS));
         break;
      case SatinConstants.DIR_DOWN_LEFT:
         provideFeedbackSticky("ViewPortDiagDownLeft", stk.getLocation2D(COORD_ABS));
         break;
      }

      super.handleViewPort(str, stk);
   } // of method

   //===   HANDLE GESTURE METHODS   ============================================
   //===========================================================================



   //===========================================================================
   //===   GET GOB METHODS   ===================================================

   protected GraphicalObjectCollection
                                    getGraphicalObjectsTouching(TimedStroke stk, double thresh) {

      //// 0. Don't do anything if we're not a group.
      if (! (getAttachedGraphicalObject() instanceof GraphicalObjectGroup)) {
         return (null);
      }

      GraphicalObject           gob        = getAttachedGraphicalObject();
      Shape                     s          = stk.getBoundingPoints2D(COORD_ABS);
      GraphicalObjectGroup      gobgrp     = (GraphicalObjectGroup) gob;
      GraphicalObjectCollection shallowGobs;

      //// 1. First, select shallowly
      shallowGobs = new GraphicalObjectCollectionImpl();
      shallowGobs = gobgrp.getGraphicalObjects(COORD_ABS,
                                               s,
                                               ALL,
                                               SHALLOW,
                                               INTERSECTS,
                                               thresh,
                                               shallowGobs);

      //// 2. Don't cut certain objects, including the attached gob
      ////    and arrows.
      Iterator        myit   = shallowGobs.getForwardIterator();
      LinkedList      list = new LinkedList();
      GraphicalObject mygob;

      // Don't delete arrows and non-selectable GOB's
      while (myit.hasNext()) {
         mygob = (GraphicalObject) myit.next();
         if ((mygob instanceof Arrow) || (!mygob.isSelectable())) {
            list.add(mygob);
         }
      }

      // Don't delete the sheet
      list.add(getAttachedGraphicalObject());

      // Remove them from the cut list
      myit = list.iterator();
      while (myit.hasNext()) {
         mygob = (GraphicalObject) myit.next();
         shallowGobs.remove(mygob);
      }

      //// 3. Now do the shallow / deep check.
      ////    In shallow (zoomed out), we can only cut entire panels
      ////       or strokes that are not in panels.
      ////    In deep (zoomed in), we can only cut strokes and phrases
      ////       that are in panels.

      //// 3.1. If we are searching shallowly, then just return.
      if (flagShallow == true) {
         return shallowGobs;
      }
      //// 3.2. If we are searching deeply, see if the list has
      ////      panels. If so, then find the objects intersecting the
      ////      stroke within each of the panel's sketches
      else {
         Iterator                  it;
         GraphicalObjectCollection deepGobs;

         it       = shallowGobs.getForwardIterator();
         deepGobs = new GraphicalObjectCollectionImpl();

         while (it.hasNext()) {
            Object obj = it.next();
            if (obj instanceof DenimPanel) {
               DenimPanel                panel;
               GraphicalObjectCollection panelGobs;
               Iterator                  pgIt;

               panel     = (DenimPanel) obj;
               panelGobs = new GraphicalObjectCollectionImpl();
               panelGobs = panel.getSketch().getGraphicalObjects(COORD_ABS,
                                                                 s,
                                                                 ALL,
                                                                 SHALLOW,
                                                                 INTERSECTS,
                                                                 thresh,
                                                                 panelGobs);
               pgIt = panelGobs.getForwardIterator();
               while (pgIt.hasNext()) {
                  deepGobs.add((GraphicalObject) pgIt.next());
               }
            }
         }

         return deepGobs;
      }
   } // of method

   //===   GET GOB METHODS   ===================================================
   //===========================================================================


   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (new DenimGestureInterpreter());
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 1999-2001 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
