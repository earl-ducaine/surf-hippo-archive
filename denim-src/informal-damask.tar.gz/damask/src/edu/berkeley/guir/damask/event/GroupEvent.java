package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.damask.dialog.PageRegion;

/** 
 * An event that indicates a change to a component group.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  05-31-2004 James Lin
 *                               Created GroupEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 05-31-2004
 */
public class GroupEvent extends EventObject {
   
   private Type eventType;
   private PageRegion region;
   
   //===========================================================================

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type BOUNDS_UPDATED =
      new Type("component group's bounds updated");
   public static final Type TRANSFORM_UPDATED =
      new Type("component group's transform updated");

   //===========================================================================

   /**
    * Constructs a GroupEvent.
    * 
    * @param source the component group that is affected
    */
   public GroupEvent(
      final ComponentGroup source,
      final Type eventType,
      final PageRegion region) {

      super(source);
      this.eventType = eventType;
      this.region = region;
   }
   
   //===========================================================================

   /**
    * Returns the originator of the event.
    * 
    * @return the Control object that originated the event, or
    * null if the object is not a Control.
    */
   public ComponentGroup getComponentGroup() {
      if (source instanceof ComponentGroup) {
         return (ComponentGroup)source;
      }
      else {
         return null;
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the page region associated with this event.
    */
   public PageRegion getPageRegion() {
      return region;
   }
}
