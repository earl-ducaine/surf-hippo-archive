package edu.berkeley.guir.lib.gesture;

import java.awt.FlowLayout;

import javax.swing.JPanel;

/**
 * A collection of StarPlots, one for each GestureCategory in the
 * GestureSet.
 */
public class GSStarPlot extends JPanel
{
  Classifier classifier;
  double scale = 100;
  double[] featureScales;
  
  public GSStarPlot(Classifier myClassifier)
  {
    classifier = myClassifier;
    buildUI();
  }

  private void buildUI()
  {
    // compute the scale value for each feature
    FeatureVector dummyFV = new FeatureVector();
    int numFeatures = dummyFV.size();
    // these are the min and max of the category mean feature values
    double[] maxValues = new double[numFeatures];
    double[] minValues = new double[numFeatures];
    double[][] meanVals = classifier.meanFeatureValues;
    featureScales = new double[numFeatures];
    for (int featureNum = 0; featureNum < numFeatures; featureNum++) {
      Feature feature = dummyFV.getFeature(featureNum);
      double min = feature.getMinValue();
      double max = feature.getMaxValue();
      boolean finiteMin = min != Double.NEGATIVE_INFINITY;
      boolean finiteMax = max != Double.POSITIVE_INFINITY;
      if (!finiteMin)
	min = Double.POSITIVE_INFINITY;
      if (!finiteMax)
	max = Double.NEGATIVE_INFINITY;
      if (!(finiteMax && finiteMin)) {
	for (int gcIndex = 0; gcIndex < meanVals.length; gcIndex++) {
	  double current = meanVals[gcIndex][featureNum];
	  if (!finiteMin && (current < min))
	    min = current;
	  if (!finiteMax && (current > min))
	    max = current;
	}
      }
      minValues[featureNum] = min;
      maxValues[featureNum] = max;
      featureScales[featureNum] =
	1.0 / (Math.max(Math.abs(min), Math.abs(max)));
      /*
      System.out.println(featureNum + " scale: " +
			 Misc.toString(featureScales[featureNum], 3) +
			 " min: " + Misc.toString(min, 3) +
			 " max: " + Misc.toString(max, 3)
			 );
			 */
    }

    // add widgets
    setLayout(new FlowLayout());
    GestureSet gestureSet = classifier.getGestureSet();
    for (int gcIndex = 0; gcIndex < meanVals.length; gcIndex++) {
      StarPlot starPlot = new StarPlot(meanVals[gcIndex]);
      starPlot.setTitle(((GestureContainer) gestureSet.getChild(gcIndex)).
			getName());
      starPlot.setFeatureScales(featureScales);
      starPlot.setScale(scale);
      starPlot.setWeights(classifier.weights[gcIndex]);
      add(starPlot);
    }
  }
}
