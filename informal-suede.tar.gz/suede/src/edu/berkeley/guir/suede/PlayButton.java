package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;

public class PlayButton extends javax.swing.JToggleButton
{
    private Color playColor;
    private Color pauseColor;

    public PlayButton(boolean isPlayable, Color pause) {
        setPlayable(isPlayable);
        pauseColor = pause;
    }
    
    public void setPlayable(boolean b) {
        if (b) playColor = Color.black;
        else playColor = Color.gray;
        setEnabled(b);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setFocusPainted(false);
        setIcon(new PlayIcon());
        setSelectedIcon(new PauseIcon());  
    }
    

    public void setPauseColor(Color pColor) {
       pauseColor = pColor; 
    }


    public class PlayIcon implements javax.swing.Icon {
        public void paintIcon(Component c, Graphics g, int x, int y) {  
            Graphics2D g2d = (Graphics2D)g;
            g2d.setColor(playColor);
            GeneralPath triangle = new GeneralPath();
            
            triangle.moveTo(getWidth()/2 - (int)(getHeight()*0.17f), (int)(getHeight()*0.21f));
            triangle.lineTo(getWidth()/2 + (int)(getHeight()*0.17f), (int)(getHeight()*0.52f));
            triangle.lineTo(getWidth()/2 - (int)(getHeight()*0.17f), (int)(getHeight()*0.83f));
 
            triangle.closePath();
            g2d.fill(triangle);
        }
        
        public int getIconHeight() {  return HEIGHT;  }

        public int getIconWidth()  {  return WIDTH;   }

    }
    
    public class PauseIcon implements javax.swing.Icon {
        public void paintIcon(Component c, Graphics g, int x, int y) {  
            Graphics2D g2d = (Graphics2D)g;
            g2d.setColor(pauseColor);
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            
            g2d.fill(new Rectangle((int)(getWidth()*0.5f - getHeight()*0.21f + 0.5f), 
                                   (int)(getHeight()*0.32f),
                                   (int)(getHeight()*0.12f + 0.5f), 
                                   (int)(getHeight()*0.49f)));

            g2d.fill(new Rectangle((int)(getWidth()*0.5f + getHeight()*0.04f + 0.5f), 
                                   (int)(getHeight()*0.32f),
                                   (int)(getHeight()*0.12f + 0.5f), 
                                   (int)(getHeight()*0.49f)));
        }
        
        public int getIconHeight() {  return HEIGHT;  }

        public int getIconWidth()  {  return WIDTH;   }

    }
    
}