/*
 * RemoteSocketManager.java
 * Created on November 6, 2001, 3:33 PM
 */

package edu.berkeley.guir.lib.satin.remote;

import java.util.*;
import edu.berkeley.guir.lib.satin.command.*;

/**
 * @author  Scott Klemmer, Katie Everitt
 * @version 1.3
 */
public class InOutMgr extends Thread {
    
   private Vector                m_inEvents      = new Vector();
   private Vector                m_outEvents     = new Vector();
   protected RemoteCommandQueue  m_listener      = null;     
   //private OutpostDOMParser      m_parser         = new OutpostDOMParser(OutpostDOMWriter.getDenimDTD()); //parses XML
   
     
   public InOutMgr(RemoteCommandQueue listener) {
      m_listener = listener;      
   }
    

   /**
   * This thread loops through all of the incoming events and asks them to be handled
   */
   public void run() {
      while (true) {
         if ((!m_inEvents.isEmpty()) && (m_listener!=null)) { //don't pop events off the queue unless someone is listening
               IOEvent event = (IOEvent) m_inEvents.remove(0); // gets the front of the vector
               System.out.println("handling Event");
               handleEvent(event);
         } else try {
               Thread.sleep(25);
         } catch (InterruptedException e) {}
      }
   }
    
    
   /**
   * Add an event to the queue of things to be sent off to the Remote system
   */
   public void postOutgoingEvent(String xml) {
      m_outEvents.add(new IOEvent( xml ));
      System.out.println("(postOutgoingEvent)ADDING event to m_out Vector which is size: "+m_outEvents.size());
   }
 
     
    
   /**
   * The Outgoing socket periodically queries this method to see if there's anything to send.
   * If there is, we return it, and it gets sent off.
   */
   public IOEvent getOutgoingEvent() {
      if ( m_outEvents.isEmpty() ) {
         return null;
      } else {
         int lastIndex = m_outEvents.size()-1;
         System.out.println("REMOVING from vector of size: "+m_outEvents.size());
         return (IOEvent) m_outEvents.remove(lastIndex);
      }
   }


   /**
    * Called by the incoming socket when it receives a new message
    * It adds the corresponding event to the rear of the queue
    * note: Events get pulled off the queue in the run() method above
    */
   public void postIncomingEvent(IOEvent ioEvent) {
      //System.out.println("posting incoming event: " + ioEvent.toString());
      m_inEvents.add(ioEvent);
   }
   
   protected void handleEvent(IOEvent event) { //should this be called handleIncomingEvent??
      m_listener.handleRemoteEvent(event);  // tells to cmdQ which adds to sheet to for speed               
   }
   
   
   /*
   public void notifySocketClosed() {
      m_inEvents.add(new RemoteEvent(RemoteEvent.SOCKET_CLOSED_EVENT, m_inPort));  
   } */  
   
}