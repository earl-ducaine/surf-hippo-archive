package edu.berkeley.guir.damask.component;

import java.util.HashSet;
import java.util.Set;

import edu.berkeley.guir.damask.AbstractInteractionElement;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.dialog.Dialog;

/** 
 * A component of interaction, which represents something that the end-user
 * actually interacts with (as opposed to connections, which represent how
 * components are related to each other).
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2003 James Lin
 *                               Created Component.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-20-2003
 */
public abstract class Component extends AbstractInteractionElement {
   
   private String name = "";
   private ComponentGroup group = null;
   private DeviceType deviceType;

   //===========================================================================
   
   /**
    * Constructs a component.
    * 
    * @param deviceType the device type that this component supports. Can be
    * DeviceType.ALL.
    */
   public Component(final DeviceType deviceType) {
      this.deviceType = deviceType;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Constructs a component by copying properties from the specified
    * component.
    * 
    * @param component the component whose properties will be copied
    * @param deviceType the device type that this component supports. Can be
    * DeviceType.ALL.
    */
   public Component(final Component component, final DeviceType deviceType) {
      super(component);
      this.name = component.getName();
      this.deviceType = deviceType;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Frees up any resources associated with this object.
    */   
   public void dispose() {
      setGroup(null);
   }

   //===========================================================================

   /**
    * Returns the type of device that this component is visible to. May be
    * DeviceType.ALL.
    */
   public DeviceType getDeviceType() {
      return deviceType;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns all of the device types that this element is visible to. 
    */
   public Set/*<DeviceType>*/ getDeviceTypesVisibleTo() {
      return new HashSet(getDeviceType().getSpecificDeviceTypes());
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns whether this element is visible to all device types. 
    */
   public boolean isForAllDeviceTypes() {
      return getDeviceType() == DeviceType.ALL;
   }

   //===========================================================================

   /**
    * Returns the name of this component.
    */
   public String getName() {
      return name;
   }
   
   //---------------------------------------------------------------------------

   /**
    * Sets the name of this component.
    */
   public void setName(String newName) {
      name = newName;
   }
   
   //===========================================================================

   /**
    * Returns the dialog that this component is in.
    */   
   public abstract Dialog getDialog();
   
   //===========================================================================

   /**
    * Returns the group that this component belongs to.
    */
   public ComponentGroup getGroup() {
      return group;
   }
   
   //---------------------------------------------------------------------------

   /**
    * Sets the group that this component belongs to. Called only by
    * ComponentGroup.add() and Component.dispose()
    */
   protected void setGroup(ComponentGroup group) {
      this.group = group;
   }

   //===========================================================================
   
   /**
    * Returns a string representation of this component, with the given indent
    * level for the given device.
    */
   public abstract String toLongString(int indentLevel, DeviceType deviceType);

   //===========================================================================

   /**
    * Creates a copy of this component, whose device type is the specified
    * device type.
    */
   public abstract Component createCopy(final DeviceType deviceType);
   
   //---------------------------------------------------------------------------

   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      Component clone = (Component)super.clone();
      this.group = null;
      return clone;
   }
}
