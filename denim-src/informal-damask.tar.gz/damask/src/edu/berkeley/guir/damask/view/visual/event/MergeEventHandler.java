package edu.berkeley.guir.damask.view.visual.event;

import java.awt.Color;
import java.awt.Paint;
import java.awt.event.InputEvent;
import java.util.*;

import edu.berkeley.guir.damask.command.MergePagesCommand;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.berkeley.guir.damask.view.visual.VisualLayer;
import edu.berkeley.guir.damask.view.visual.dialog.PageView;
import edu.umd.cs.piccolo.event.*;

/** 
 * The event handler that handles splitting pages.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-06-2004 James Lin
 *                               Created InsertComponentHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-06-2004
 */
public class MergeEventHandler extends PBasicInputEventHandler {
   private static final Color HIGHLIGHT_COLOR = new Color(255, 220, 220);
   
   private PageView pageView;

   private Page pageToMergeWithAdjacent;
   private Map/*<PageView, Paint>*/ pageViewsToMerge =
      new HashMap/*<PageView, Paint>*/();
   
   
   /**
    * Constructs a handler which will instantiate a component of the specified
    * type.
    * 
    * @param componentViewType a class which is a descendant of
    * {@link edu.berkeley.guir.damask.view.visual.component.ComponentView}
    */
   public MergeEventHandler() {
      setEventFilter(new PInputEventFilter(InputEvent.BUTTON1_MASK));
   }

   
   // @Override
   public void mouseEntered(final PInputEvent event) {
      final PageView pv =
         (PageView)DamaskAppUtils.getAncestor(
            event.getPickedNode(), PageView.class);
      
      if (pageView != pv) {
         for (Iterator i = pageViewsToMerge.keySet().iterator(); i.hasNext(); ) {
            final PageView aPageView = (PageView)i.next();
            aPageView.getContents().setPaint(
               (Paint)pageViewsToMerge.get(aPageView));
         }
         pageViewsToMerge.clear();
         
         pageView = pv;
         
         if (pageView != null) {
            // If there is a page adjacent to the one that the cursor
            // is in...
            final Page page = (Page)pageView.getModel();
            final Dialog dialog = page.getDialog();
            final List/*<Page>*/ pages = dialog.getPages(page.getDeviceType()); 
            final int pageIndex = pages.indexOf(page);
            
            if (pages.size() > pageIndex + 1) {
               //...then highlight both of them.
               pageToMergeWithAdjacent = page;
               final VisualCanvas canvas = (VisualCanvas)event.getComponent();
               final Page page2 = (Page)pages.get(pageIndex + 1);
               
               final VisualLayer visualLayer = ((VisualLayer) canvas.getLayer());
               
               final Set/*<PageView>*/ pageViewsToHighlight =
                  new HashSet/*<PageView>*/();
               
               pageViewsToHighlight.addAll(visualLayer.getViews(page));
               pageViewsToHighlight.addAll(visualLayer.getViews(page2));
               
               for (Iterator i = pageViewsToHighlight.iterator(); i.hasNext();){
                  final PageView aPageView = (PageView)i.next();
                  pageViewsToMerge.put(
                     aPageView, aPageView.getContents().getPaint());
                  aPageView.getContents().setPaint(HIGHLIGHT_COLOR);
               }
            }
         }
      }
   }

   
   // @Override
   public void mouseReleased(final PInputEvent event) {
      if (pageToMergeWithAdjacent != null) {
         cleanUp();
         final VisualCanvas canvas = (VisualCanvas)event.getComponent();
         canvas.getDocument().getCommandQueue().doCommand(
            canvas,
            new MergePagesCommand(pageToMergeWithAdjacent));
      }
   }
   
   
   /**
    * Clean up anything that the handler left behind before it is disabled.
    */
   public void cleanUp() {
      for (Iterator i = pageViewsToMerge.keySet().iterator(); i.hasNext(); ) {
         final PageView aPageView = (PageView)i.next();
         aPageView.getContents().setPaint(
            (Paint)pageViewsToMerge.get(aPageView));
      }
   }
}
