package edu.berkeley.guir.denim.command;

import java.awt.Rectangle;
import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.interpreters.LabelInterpreter;
import edu.berkeley.guir.denim.interpreters.LabelInterpreter.AddStrokeToLabelCommand;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.command.InsertCommand;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;
import edu.berkeley.guir.lib.satin.objects.GraphicalObject;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollection;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollectionImpl;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectGroup;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectLib;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;
import edu.berkeley.guir.lib.awt.geom.*;

/**
 * Puts graphical objects into a Denim group.
 *
 * <PRE>
 * Revisions:  1.0.0  08-17-2000 JL
 *                    Created class GroupCommand. Originally for grouping
 *                    strokes into a scribble. Not used.
 *             2.0.0  08-17-2002 JL
 *                    Since this class wasn't being used for anything,
 *                    rewrote it for its current purpose
 *             3.0.0  08-07-2004 YL
 *                    competely rebuilt this class
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 3.0.0, 08-07-2004
 */

public class GroupCommand 
   extends UndoableCommand {

   //=======================================================================
   //===   INSTANCE VARIABLES   ============================================

   private GraphicalObjectGroup parent;
   private TimedStroke               boundary;
   
   
/*   private AffineTransform           boundaryTransform;
   private DenimGroup                group;
   
   private GraphicalObjectCollection containedObjects;
   private Map                       containedObjectsToOldLayers;
   private Map                       containedObjectsToOldTransforms;
  */
   // grouping labels
   GraphicalObjectCollection toplevelGobsBeforeGroup = null;
   DenimPanel mergedPanel = null;
   
   // grouping scribbled texts
   GraphicalObjectCollectionImpl scribbledtexts = null;
   ScribbledText mergedText = null;
   DenimGroup group;
   private DenimSketch     sketch = null;
   
   //===   INSTANCE VARIABLES   ============================================
   //=======================================================================
      


   //=======================================================================
   //===   CONSTRUCTORS   ==================================================

   /**
    * Construct the command.
    * 
    * @param parent  the group in which the new Denim group will be created
    * @param stk     the boundary of the group in absolute coordinates. 
    *                 This stroke will be irrevocably changed, so if you want
    *                 to use the stroke somewhere else, pass a clone
    *                 of the stroke instead.
    */
/*   public GroupCommand(GraphicalObjectGroup parent, TimedStroke boundary) {
      super();
      this.parent = parent;
      this.boundary = boundary;

      containedObjects = new GraphicalObjectCollectionImpl();      
      containedObjectsToOldLayers = new WeakHashMap();
      containedObjectsToOldTransforms = new WeakHashMap();

      parent.add(boundary, GraphicalObjectGroup.KEEP_ABS_POS);
      this.boundaryTransform = boundary.getTransform(COORD_REL);
      boundary.delete();

      group = new DenimGroup(boundary);
   } // of constructor
  */
   public GroupCommand(GraphicalObjectGroup p, TimedStroke boundary) {
       super();
       this.parent = p;
       this.boundary = boundary;
    } // of constructor

   //===   CONSTRUCTORS   ==================================================
   //=======================================================================



   //=======================================================================
   //===   NAME ACCESSOR METHODS   =========================================

   public String getPresentationName() {
      return ("create new group");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =========================================
   //=======================================================================



   //=======================================================================
   //===   COMMAND   =======================================================

   /**
    * Notifies the command system that this command can be redone.
    */
   public boolean canRedo() {
      return true;
   } // of method

   //-----------------------------------------------------------------


   public void run() {

      sketch = null;
 
      if(parent instanceof DenimSheet)
      { // grouping labeles
          this.groupLabels();
      }
      else // grouping contents inside a sketch
      {
          Rectangle2D range = boundary.getBounds2D(COORD_ABS);
          Iterator it = parent.getSheet().getReverseIterator();
          while(it.hasNext())
          {
              GraphicalObject gob = (GraphicalObject)it.next();
              Rectangle2D box = gob.getBounds2D(COORD_ABS);
              if(gob instanceof DenimPanel&&box.contains(range.getCenterX(),range.getCenterY()))
              {
                  sketch = ((DenimPanel)gob).getSketch();
                  this.groupContentsOnSketch(sketch);   
                  break;
              }
          }
      }
   }
   
   private void undoGroupLabels() {
       if(mergedPanel!=null)
       {
           mergedPanel.delete();
           parent.getSheet().remove(mergedPanel);
           Iterator it = toplevelGobsBeforeGroup.getForwardIterator();
           while(it.hasNext())
           {
               GraphicalObject obj = (GraphicalObject)it.next();
               parent.getSheet().add(obj);
           }
       }
   }
   
   private void groupLabels() {
       parent.disableDamage();
       toplevelGobsBeforeGroup = new GraphicalObjectCollectionImpl();
       Rectangle2D range = boundary.getBounds2D(COORD_ABS);
       Iterator it = parent.getReverseIterator();
       Rectangle2D bounds = null;
       while(it.hasNext())
       {
           GraphicalObject gob = (GraphicalObject)it.next();
           Rectangle2D box = gob.getBounds2D(COORD_ABS);
           if(range.contains(box.getCenterX(), box.getCenterY()))
           {
               if(gob instanceof DenimPanel&&
                       ((DenimPanel)gob).getLabel().getCaption() instanceof ScribbledText)
               {
                   ScribbledText t = (ScribbledText)((DenimPanel)gob).getLabel().getCaption();
                   toplevelGobsBeforeGroup.addToFront(gob);
                   if(bounds==null)
                   {
                       bounds = t.getBounds2D(COORD_ABS);
                   }
                   else
                   {
                       Rectangle2D.union(t.getBounds2D(COORD_ABS), 
                           bounds,
                           bounds);
                   }
               }
               else if(gob instanceof TimedStroke)
               {
                   toplevelGobsBeforeGroup.addToFront(gob);
                   if(bounds==null)
                   {
                       bounds = gob.getBounds2D(COORD_ABS);
                   }
                   else
                   {
                       Rectangle2D.union(gob.getBounds2D(COORD_ABS), 
                           bounds,
                           bounds);
                   }
               }
           }
       }
       
       if(this.toplevelGobsBeforeGroup.numElements()>1)
       {
/*           GeomLib.transformRectangle(sheet.getInverseTransform(COORD_ABS), bounds, bounds);
           ScribbledText text = new ScribbledText(bounds);
           sheet.addToFront(text); 
  */         
           /**
            * put all strokes into text
            */
           it = toplevelGobsBeforeGroup.getForwardIterator();
           AffineTransform sheetlocal = parent.getInverseTransform(COORD_ABS);
           while(it.hasNext())
           {
               GraphicalObject gob = (GraphicalObject)it.next();
               if(gob instanceof TimedStroke)
               {
                   this.addStroke(sheetlocal, (TimedStroke)gob);
               }
               else if(gob instanceof DenimPanel)
               {
                   ScribbledText t = (ScribbledText)((DenimPanel)gob).getLabel().getCaption();
                   /*ScribbledText text1 = (ScribbledText)t.deepClone();
                   sheet.add(text1, GraphicalObjectGroup.KEEP_REL_POS);
                   AffineTransform trans = t.getTransform(COORD_ABS);
                   trans.preConcatenate(sheet.getInverseTransform(COORD_ABS));
                   text1.applyTransform(trans);
                   text1.moveTo(COORD_ABS, t.getLocation2D(COORD_ABS));
                   while(text1.numElements()>0)
                   {
                       TimedStroke stk = (TimedStroke)text1.get(0);
                       text.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);
                   }               
                   sheet.remove(text1);
                   text1.delete();*/
                   Iterator tt = t.getForwardIterator();
                   while(tt.hasNext())
                   {
                       TimedStroke stk = (TimedStroke)tt.next();
                       this.addStroke(sheetlocal, stk);
                   }
               }
           }
           
           parent.removeAll(toplevelGobsBeforeGroup);
       }
       
       parent.enableDamage();
   }
   
   //private void addStroke(AffineTransform sheetlocal, TimedStroke stk, ScribbledText text) {
   private void addStroke(AffineTransform sheetlocal, TimedStroke stk) {
       Polygon2D poly = stk.getPolygon2D(COORD_ABS);
       poly.transform(sheetlocal);
       TimedStroke s = new TimedStroke(poly);
       s.getStyleRef().setLineWidth
           ((float)(1.0 / DenimUtils.getTrueAbsXform(stk).getScaleX()));
       parent.add(s);
       s.moveTo(COORD_ABS, stk.getLocation2D(COORD_ABS));
       
       //TimedStroke stk = (TimedStroke)s.deepClone();
       //sheet.add(stk);
       
       //text.add((TimedStroke)stk.deepClone(), GraphicalObjectGroup.KEEP_ABS_POS);
       
       if(mergedPanel==null)
       {
           mergedPanel = this.createNewLabel(s).getPanel();
       }
       else
       {
           new LabelInterpreter().new AddStrokeToLabelCommand(mergedPanel.getLabel(), s).run();
       }
   }
   
   
   private DenimLabel createNewLabel(TimedStroke stk) {
       ScribbledText           phrase;
       DenimLabel              label;
       DenimSketch             sketch;
       DenimPanel              panel;
       Rectangle2D             bounds;
       double                  scaleFactor;


       //debug.println("LabelInterpreter: parent = " + parent.getClass() +
       //                   ":" + parent.getUniqueID());

       //phrase      = new Phrase();
       phrase      = new ScribbledText();
       bounds      = stk.getBounds2D(COORD_ABS);
       scaleFactor = GraphicalObjectLib.getScaleFactor(COORD_ABS, parent);

       //// 1. Create phrase.
       ////    Give it a bogus temp location.
       phrase.setBoundingPoints2D(COORD_ABS, new Rectangle(0, 0, 20, 20));
       parent.add(phrase, GraphicalObjectGroup.KEEP_ABS_POS);

       phrase.setBoundingPoints2D(COORD_ABS, bounds);
       phrase.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);

       //// 2. Create label.
       label  = new DenimLabel(phrase);
       bounds = label.getBounds2D(COORD_ABS);
       
       //// 3. Create sketch.
       sketch = new DenimSketch(new Rectangle2D.Double(
                                  bounds.getX(),
                                  bounds.getY() + bounds.getHeight(),
                                  //(int)(DEFAULT_SKETCH_WIDTH  * scaleFactor),
                                  //(int)(DEFAULT_SKETCH_HEIGHT * scaleFactor)));
                                            (int)(DenimSketch.getDefaultSketchWidth()  * scaleFactor),
                                            (int)(DenimSketch.getDefaultSketchHeight() * scaleFactor)));

       //// 4. Create panel.
       panel = new DenimPanel(new Rectangle(0, 0, 1, 1));

       //// throw this into the command queue, so it can be undone
       new InsertCommand(parent, panel,
                                        GraphicalObjectGroup.KEEP_ABS_POS).run();

       panel.setLabel(label);
       panel.setSketch(sketch);

       // HACK: Fix view for sketch, now that it has been added to sheet
       label.initAfterAddLabelToSheet();
       sketch.initAfterAddSketchToSheet();

       //// 5. Adjust the width of the stroke
       stk.getStyleRef().setLineWidth
          ((float)(1.0 / DenimUtils.getTrueAbsXform(stk).getScaleX()));
          
       return label;
    } // of method

  
   /**
    * create a new panel with a given text
    * @param stk
    * @return
    */
   private DenimPanel createNewPanel(ScribbledText phrase) {
       DenimLabel              label;
       DenimSketch             sketch;
       DenimPanel              panel;
       Rectangle2D             bounds;
       double                  scaleFactor;

       scaleFactor = GraphicalObjectLib.getScaleFactor(COORD_ABS, parent);

       //// 2. Create label.
       label  = new DenimLabel(phrase);
       bounds = label.getBounds2D(COORD_ABS);
       
       //// 3. Create sketch.
       sketch = new DenimSketch(new Rectangle2D.Double(
                                  bounds.getX(),
                                  bounds.getY() + bounds.getHeight(),
                                            (int)(DenimSketch.getDefaultSketchWidth()  * scaleFactor),
                                            (int)(DenimSketch.getDefaultSketchHeight() * scaleFactor)));

       //// 4. Create panel.
       panel = new DenimPanel(new Rectangle(0, 0, 1, 1));

       new InsertCommand(parent, panel, GraphicalObjectGroup.KEEP_ABS_POS).run();

       panel.setLabel(label);
       panel.setSketch(sketch);

       // HACK: Fix view for sketch, now that it has been added to sheet
       label.initAfterAddLabelToSheet();
       sketch.initAfterAddSketchToSheet();

       return panel;
    } // of method
   
   private void undoGroupOnSketch(DenimSketch parent) {
       if(group!=null)
       {
            parent.disableDamage();
            while(group.numElements()>0)
            {
                DenimRadioButtonInstance radio = (DenimRadioButtonInstance)group.get(0);
                parent.addToFront(radio, 
                        GraphicalObjectGroup.KEEP_ABS_POS);
                group.remove(radio);
            }
            parent.enableDamage();
            parent.remove(group);
            group.delete();
       }
       else
       {
           parent.disableDamage();
           Iterator it = scribbledtexts.getForwardIterator();
           while(it.hasNext())
           {
               GraphicalObject obj = (GraphicalObject)it.next();
               parent.addToFront(obj);
           }
           parent.remove(mergedText);
           mergedText.delete();
           parent.enableDamage();
           parent.damage(DAMAGE_NOW);
       }
   }
   
   private void groupContentsOnSketch(DenimSketch parent) {

       Iterator it = parent.getForwardIterator();
       scribbledtexts = new GraphicalObjectCollectionImpl();
       GraphicalObjectCollectionImpl radiobtns = new GraphicalObjectCollectionImpl();
       Rectangle2D range = boundary.getBounds2D(COORD_ABS);
       while(it.hasNext())
       {
           GraphicalObject gob = (GraphicalObject)it.next();
           Rectangle2D box = gob.getBounds2D(COORD_ABS);
           if(range.contains(box.getCenterX(), box.getCenterY()))
           {
               if(gob instanceof DenimRadioButtonInstance)
               {
                   radiobtns.addToFront(gob);
               }
               else if(gob instanceof ScribbledText
     //                   ||(gob instanceof DenimHyperlinkInstance
     //                           && ((DenimHyperlinkInstance)gob).getContents() instanceof ScribbledText)
                        ||gob instanceof TimedStroke)
                {
                    scribbledtexts.addToFront(gob);
                }
            }
        }

        // radio button group
        if(radiobtns.numElements()>1)
        {
            scribbledtexts = null;
            
            Rectangle2D bounds = null;
            Iterator mi = radiobtns.getForwardIterator();
            while(mi.hasNext())
            {
                DenimRadioButtonInstance r = (DenimRadioButtonInstance)mi.next();
                if(bounds==null)
                {
                    bounds = (Rectangle2D)r.getBounds2D(COORD_REL).clone();
                }
                else
                {
                    Rectangle2D.union(bounds, r.getBounds2D(COORD_REL), bounds); 
                }
            }
            
            cmdsubsys.clearSelected();
            
            group = new DenimGroup(bounds);
            parent.add(group);
            
            mi = radiobtns.getForwardIterator();
            while(mi.hasNext())
            {
                DenimRadioButtonInstance r = (DenimRadioButtonInstance)mi.next();
                group.add(r, GraphicalObjectGroup.KEEP_ABS_POS);
            }
        }
        else if(scribbledtexts.numElements()>1) // group scribbled text
        {
            parent.disableDamage();
            mergedText = ScribbledText.merge(parent, scribbledtexts);
            parent.removeAll(scribbledtexts);
            parent.enableDamage();
            parent.damage(DAMAGE_NOW);
            
        }

   }
   
   //-----------------------------------------------------------------

   public void redo() {
      run();
   } // of method
      
   //-----------------------------------------------------------------

   public void undo() {
       if(sketch!=null)
       {
           this.undoGroupOnSketch(sketch);
       }
       else
       {
           this.undoGroupLabels();
       }
   } // of method

   //===   COMMAND   =======================================================
   //=======================================================================

} // of class
