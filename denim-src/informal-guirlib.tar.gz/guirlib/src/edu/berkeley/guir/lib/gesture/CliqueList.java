package edu.berkeley.guir.lib.gesture;

import java.util.*;
import java.io.PrintStream;

public class CliqueList
{
  Classifier classifier;

  /** cliqueArray[i] is a Vector of Cliques of size i */
  Vector[] cliqueArray;
  double cliqueDistance;
  int biggestClique = 0;

  public CliqueList(GestureSet gs, double distance)
    throws TrainingException, InterruptedException
  {
    this(new Classifier(gs), distance);
  }
  
  public CliqueList(Classifier c, double distance)
    throws TrainingException, InterruptedException
  {
    if (c == null) {
      throw new NullPointerException("CliqueList must be given a non-null classifier");
    }
    classifier = c;
    cliqueDistance = distance;
    computeCliqueList();
  }

  private void computeCliqueList()
    throws TrainingException, InterruptedException
  {
    classifier.train();

    GestureSet gestureSet = classifier.getGestureSet();
    int numCategories = gestureSet.size();

    cliqueArray = new Vector[numCategories+1];
    for (int i = 1; i < cliqueArray.length; i++) {
      cliqueArray[i] = new Vector();
    }
    
    // make a new clique for each category
    for (Iterator iter = gestureSet.iterator();
	 iter.hasNext();) {
      GestureCategory gc = (GestureCategory) iter.next();
      Clique clique = new Clique();
      clique.add(gc);
      cliqueArray[1].addElement(clique);
    }

    for (int cliqueSize = 1; cliqueSize < numCategories; cliqueSize++) {
      Vector cliqueList = cliqueArray[cliqueSize];
      int numCliques = cliqueList.size();
      for (int cliqueIndex = 0; cliqueIndex < numCliques; cliqueIndex++) {
	Clique clique =
	  (Clique) cliqueList.elementAt(cliqueIndex);
	boolean newCliqueFound = false;
	for (Iterator catIter = gestureSet.iterator();
	     catIter.hasNext();) {
	  GestureCategory gestureCategory =
	    (GestureCategory) catIter.next();
	  if (!clique.contains(gestureCategory) &&
	      isClique(clique, gestureCategory)) {
	    Clique newClique = (Clique) clique.clone();
	    newClique.add(gestureCategory);
	    Vector v = cliqueArray[cliqueSize+1];
	    if (!v.contains(newClique)) {
	      v.addElement(newClique);
	    }
	    newCliqueFound = true;
	  }
	}
	if (newCliqueFound) {
	  biggestClique = cliqueSize+1;
	  cliqueList.removeElementAt(cliqueIndex);
	  cliqueIndex--;
	  numCliques--;
	}
      }
    }
  }

  /** determine if the clique would still be a clique if gestureCategory
   * were added to it. */
  private boolean isClique(Clique clique,
			   GestureCategory gestureCategory)
  {
    boolean closeEnough = true;
    double squaredDist = cliqueDistance * cliqueDistance;
    for (Iterator catIter = clique.iterator();
	 catIter.hasNext() && closeEnough;) {
      GestureCategory gc =
	(GestureCategory) catIter.next();
      double dist = classifier.categoryDistance(gc, gestureCategory);
      /*
      System.err.println(gc.getName() + "\t" + gestureCategory.getName() +
			 "\t" + dist);
			 */
      if (dist > squaredDist)
	closeEnough = false;
    }

    return closeEnough;
  }
  
  public void printCliques(PrintStream out)
  {
    printCliques(out, "");
  }
  
  public void printCliques(PrintStream out, String lineHeader)
  {
    for (int cliqueSize = 1;
	 cliqueSize <= biggestClique;
	 cliqueSize++) {
      Vector cliqueList = cliqueArray[cliqueSize];
      int numCliques = cliqueList.size();
      if (numCliques > 0) {
	out.print(lineHeader + cliqueSize + ": ");
	for (int cliqueIndex = 0; cliqueIndex < numCliques; cliqueIndex++) {
	  Clique clique =
	    (Clique) cliqueList.elementAt(cliqueIndex);
	  out.print("(");
	  for (Iterator catIter = clique.iterator();
	       catIter.hasNext();) {
	    GestureCategory gestureCategory =
	      (GestureCategory) catIter.next();
	    out.print(gestureCategory.getName());
	    if (catIter.hasNext())
	      out.print(", ");
	  }
	  out.print(") ");
	}
	out.println();
      }
    }
  }
}

class Clique extends GestureSet
{
  Clique()
  {
    super();
  }

  public boolean equals(Object obj)
  {
    boolean result;
    if (obj instanceof Clique) {
      Clique clique = (Clique) obj;
      if (clique.size() != size()) {
	result = false;
      }
      else {
	result = true;
	for (Iterator iter = iterator();
	     result && iter.hasNext();) {
	  GestureCategory gestureCategory =
	    (GestureCategory) iter.next();
	  if (clique.getChild(gestureCategory.getName()) == null)
	    result = false;
	}
      }
    }
    else {
      result = false;
    }

    return result;
  }
}
