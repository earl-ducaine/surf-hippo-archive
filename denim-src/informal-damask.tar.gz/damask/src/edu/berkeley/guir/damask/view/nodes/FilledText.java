package edu.berkeley.guir.damask.view.nodes;

import java.awt.*;
import java.awt.Graphics2D;
import java.awt.Paint;

import edu.umd.cs.piccolo.nodes.PText;
import edu.umd.cs.piccolo.util.PPaintContext;

/** 
 * A text node like PText that can also have a background and border color.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  mm-dd-yyyy James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public class FilledText extends PText {

   private static final BasicStroke DEFAULT_STROKE =
      new BasicStroke(1.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
   
   private Paint borderPaint = null;
   private Paint fillPaint = null;
   private Stroke borderStroke = DEFAULT_STROKE; 
   
   /**
    * Constructs a filled text node.
    */
   public FilledText() {
      super();
   }
   
   /**
    * Constructs a filled text node with the given string.
    */
   public FilledText(String aText) {
      super(aText);
   }
   
   
   /**
    * Returns the paint used for the border of this node.
    */
   public Paint getBorderPaint() {
      return borderPaint;
   }
   
   /**
    * Sets the paint used for the border of this node.
    */
   public void setBorderPaint(Paint borderPaint) {
      this.borderPaint = borderPaint;
   }
   
   
   /**
    * Returns the stroke used to paint the border of this node.
    */
   public Stroke getBorderStroke() {
      return borderStroke;
   }
   
   /**
    * Sets the stroke used to paint the border of this node.
    */
   public void setBorderStroke(Stroke borderStroke) {
      this.borderStroke = borderStroke;
   }

   
   /**
    * Returns the paint used to fill the background of this node.
    */
   public Paint getFillPaint() {
      return fillPaint;
   }
   
   /**
    * Sets the paint used to fill the background of this node.
    */
   public void setFillPaint(Paint fillPaint) {
      this.fillPaint = fillPaint;
   }
   
   // @Override
   protected void paint(PPaintContext paintContext) {
      final Graphics2D g2 = paintContext.getGraphics();
      if (fillPaint != null) {
         g2.setPaint(fillPaint);
         g2.fill(getBoundsReference());
      }
      super.paint(paintContext);
      if (borderStroke != null && borderPaint != null) {
         g2.setPaint(borderPaint);
         g2.setStroke(borderStroke);
         g2.draw(getBoundsReference());
      }
   }
}
