//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import java.util.Iterator;

/**
 * A type of View that can contain multiple Views, and decides how each of the
 * Views will be displayed (if any).
 *
 * <P>
 * Some examples could include:
 * <UL>
 *    <LI>Take the first valid view.
 *    <LI>Render all valid views.
 *    <LI>Make the views translucent and overlay them.
 * </UL>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 11 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public interface MultiView 
   extends View {

   //===========================================================================
   //===   MULTI METHODS   =====================================================

   /**
    * Add a view to the MultiView, setting the GraphicalObject the added 
    * View is attached to (via 
    * {@link View#setAttachedGraphicalObject(GraphicalObject)}) to be the same
    * as the one this MultiView is attached to.
    *
    * @param  v is the view to add.
    * @return a reference to v.
    */
   public View add(View v);

   //-----------------------------------------------------------------

   /**
    * Remove a view.
    *
    * @param  v is the view to remove.
    * @return a reference to v.
    */
   public View remove(View v);

   //-----------------------------------------------------------------

   /**
    * Get an iterator over all of the Views.
    *
    * @return an Iterator of View objects.
    */
   public Iterator iterator();

   //-----------------------------------------------------------------

   /**
    * Get the view at the specified index.
    *
    * @param  index is the index in the list to retrieve from.
    * @return the View at the index, or null if it does not exist.
    */
   public View get(int index);

   //-----------------------------------------------------------------

   /**
    * Check if we contain the specified view.
    */
   public boolean contains(View v);

   //-----------------------------------------------------------------

   /**
    * Get the number of views contained.
    */
   public int size();

   //-----------------------------------------------------------------

   /**
    * Clear all of the views.
    */
   public void clear();

   //===   MULTI METHODS   =====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
