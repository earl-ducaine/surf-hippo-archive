package edu.berkeley.guir.damask.view.visual.component;

import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.util.HashSet;
import java.util.Set;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.component.SelectMany;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.visual.dialog.PageViewContainer;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * A check box.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  10-24-2003 James Lin
 *                               Created CheckBox.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 10-24-2003
 */
public class CheckBox extends ControlView {
   
   private static final int BOX_SIDE_LENGTH = 15;
   private static final int GAP = 8;  // distance between check box and caption
   
   private Label caption;
   private final PPath boxOutline = new PPath();
   private final PPath checkMark = new PPath();

   private boolean checked = false;

   /**
    * Creates a check box.
    */
   public CheckBox(final SelectMany.Item selectManyItem) {
      super(selectManyItem, new RunModeEventHandler());
      setResizable(false);
   }
   
   
   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      final SelectMany.Item selectManyItem = (SelectMany.Item)getModel();

      // Add the box outline.
      boxOutline.setPathTo(
         new Rectangle2D.Double(0, 0, BOX_SIDE_LENGTH, BOX_SIDE_LENGTH));
      boxOutline.setPickable(false);
      addChild(boxOutline);

      // Add the caption.
      caption = new Label(selectManyItem.getContent());
      caption.setPickable(false);
      addChild(caption);
      
      // Create the check mark, but don't add it.
      checkMark.moveTo(BOX_SIDE_LENGTH * 0.2f, BOX_SIDE_LENGTH * 0.5f);
      checkMark.lineTo(BOX_SIDE_LENGTH * 0.4f, BOX_SIDE_LENGTH * 0.8f);
      checkMark.lineTo(BOX_SIDE_LENGTH * 0.8f, BOX_SIDE_LENGTH * 0.2f);
      checkMark.setPickable(false);
   }


   /**
    * Returns a representation of what a button looks like by default.
    */
   public static PNode createTempView() {
      final PNode parentNode = new PNode();
      
      // Create check box
      final PPath checkBox =
         new PPath(
            new Rectangle2D.Double(0, 0, BOX_SIDE_LENGTH, BOX_SIDE_LENGTH));

      // Create caption
      final PPath squiggle = DamaskAppUtils.createSquiggle();
      squiggle.setOffset(BOX_SIDE_LENGTH + GAP, 0);
      
      parentNode.addChild(checkBox);
      parentNode.addChild(squiggle);
      
      parentNode.setBounds(
         0,
         0,
         BOX_SIDE_LENGTH + GAP + squiggle.getWidth(),
         BOX_SIDE_LENGTH);

      return parentNode;
   }

   
   /**
    * Returns whether this check box is checked.
    */
   public Object getState() {
      return Boolean.valueOf(checked);
   }
   
   
   /**
    * Sets whether this check box is checked. Also affects the items
    * that are selected in this check box's group.
    */
   public void setState(final Object state) {
      final boolean flag = ((Boolean)state).booleanValue(); 
      if (flag) {
         ((CheckBoxGroup)getParent()).addSelectedCheckBox(this);
      }
      else {
         ((CheckBoxGroup)getParent()).removeSelectedCheckBox(this);
      }
   }


   // Overrides abstract method in parent class.
   public Object getEditableContents() {
      return getContent();
   }

   /**
    * Returns the content of this check box.
    */
   public Label getContent() {
      return caption;
   }
   
   
   /**
    * Returns whether this check box is checked.
    */
   protected boolean isChecked() {
      return checked;
   }
   
   
   /**
    * Sets whether this check box is checked.
    */
   protected void setChecked(final boolean state) {
      if (checked != state) {
         checked = state;
         if (checked) {
            addChild(checkMark);
         }
         else {
            removeChild(checkMark);
         }
      }
   }
   
   
   /**
    * The event handler for a check box in Run mode.
    */
   private static class RunModeEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final CheckBox checkBox = (CheckBox)event.getPickedNode();
         checkBox.boxOutline.setPaint(Color.LIGHT_GRAY);
         container.setFocus(checkBox);
      }
      
      public void mouseReleased(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final CheckBox checkBox = (CheckBox)event.getPickedNode();
         
         if (container.getFocus() == checkBox) {
            checkBox.boxOutline.setPaint(DamaskAppUtils.NO_COLOR);

            final SelectMany.Item selectManyItem =
               (SelectMany.Item)checkBox.getModel();
            
            // Change state of check box
            final CheckBoxGroup group = (CheckBoxGroup)checkBox.getParent();
            final Set/*<SelectMany.Item>*/ selectedItems =
               new HashSet((Set)group.getState());
            if (checkBox.isChecked()) {
               selectedItems.remove(checkBox.getModel());
            }
            else {
               selectedItems.add(checkBox.getModel());
            }
            container.setControlState(
               (Control)group.getModel(), selectedItems);
            
            // Follow an outgoing connection, if any
            final DeviceType deviceType = checkBox.getDeviceType();

            final NavConnection connection =
               selectManyItem.getOutConnection(
                  checkBox.getDeviceType(),
                  new InvokeEvent(selectManyItem),
                  container.getSelectedPageCondition());
            
            if (connection != null) {
               container.goToPage(
                  connection.getDest(deviceType).getPage(deviceType));
            }
         }
         container.setFocus(null);
      }
      
      public void mouseEntered(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final CheckBox checkBox = (CheckBox)event.getPickedNode();
         if (container.getFocus() == checkBox) {
            checkBox.boxOutline.setPaint(Color.LIGHT_GRAY);
         }
      }
      
      public void mouseExited(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         final CheckBox checkBox = (CheckBox)event.getPickedNode();
         if (container.getFocus() == checkBox) {
            checkBox.boxOutline.setPaint(DamaskAppUtils.NO_COLOR);
         }
      }
   }
}
