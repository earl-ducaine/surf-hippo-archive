//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

/**
 * Contains various Graph constants.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Nov 10 1997, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.5/1.2.0, Nov 26 2002, JH
 *               Converted from interface to class
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.3RC1
 * @version GUIRLib-v1.5/1.2.0, Nov 26 2002
 */
public class GraphConst {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   /**
    * This is the default weight that will be assigned if no weight is
    * specified.
    */
   public final static float DEFAULT_WEIGHT = 1;

   //-----------------------------------------------------------------

   /**
    * The default size of the table that contains the nodes. The table itself
    * can dynamically resize itself, but of course it is more efficient
    * this way.
    */
   public final static int   DEFAULT_NUMBER_NODES = 1000;

   //-----------------------------------------------------------------

   /**
    * The default size of the table for each adjacency list (both inlinks
    * and outlinks). Every Node constructed will have a table with this size. 
    * The table itself can dynamically resize itself, but of course it is 
    * more efficient this way.
    */
   public final static int   DEFAULT_NUMBER_EDGES = 10;

   //-----------------------------------------------------------------

   /**
    * The default size of the list for Paths. The Path itself can 
    * dynamically resize itself, but of course it is more efficient this way.
    */
   public final static int   DEFAULT_PATH_SIZE = 20;

   //-----------------------------------------------------------------

   /**
    * The error tolerance we will accept when comparing two floats.
    */
   public final static float ERROR = 0.001f;

   //===   CONSTANTS   =========================================================
   //===========================================================================

} // of interface

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
