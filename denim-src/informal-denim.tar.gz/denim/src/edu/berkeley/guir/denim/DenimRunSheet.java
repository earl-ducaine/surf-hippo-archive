package edu.berkeley.guir.denim;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.swing.SwingUtilities;
import javax.swing.event.MouseInputAdapter;

import edu.berkeley.guir.denim.DenimSheet.Crosshairs;
import edu.berkeley.guir.denim.components.DenimComponentInstance;
import edu.berkeley.guir.denim.components.DenimCustomComponentInstance;
import edu.berkeley.guir.denim.components.DenimHyperlinkInstance;
import edu.berkeley.guir.denim.components.DenimIntrinsicComponent;
import edu.berkeley.guir.denim.event.DenimEvent;
import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.Sheet;
import edu.berkeley.guir.lib.satin.objects.GraphicalObject;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollection;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollectionImpl;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectGroupImpl;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectImpl;
import edu.berkeley.guir.lib.satin.objects.Style;

/**
 * The sheet that is contained within the {@link DenimRunWindow
 * DENIM Run Window}. When a DENIM design is run, the panels are drawn on this
 * sheet.
 *
 * <PRE>
 * Revisions:  1.0.0  08-25-1999  JL
 *                    Created class DenimRunSheet.
 *             2.0.0  02-15-2000  WL
 *                    Added support for a history stack.
 *             2.1.0  03-07-2000  James Lin
 *                                Moved History stack to DenimRunWindow.
 *                                Added Refresh.
 *             2.1.1  July 7, 2003  MR and YL
 *                    Changed renderPanel to make 
 *                    DenimGroup invisible even inside 
 *                    a DenimHyperlinkInstance
 * 
 * </PRE>
 *
 * @see DenimRunWindow
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~marcr/">Marc Ringuette</A> (
 *          <A HREF="mailto:marcr@cs.berkeley.edu">marcr@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 07-07-2003
 *
 */
public class DenimRunSheet
    extends Sheet implements BackgroundImageContainer {

    //===========================================================================
    //===   CONSTANTS   =========================================================

    static final long serialVersionUID = -30255640686438478L;

    public String backgroundName = null;
    public double imageX  = 0;
    public double imageY = 0;
    public double imageW  = 1;
    public double imageH = 1;

    static final float dash1[] = {0.05f};
    static final BasicStroke dashed = new BasicStroke(0.001f,
                                                      BasicStroke.CAP_BUTT,
                                                      BasicStroke.JOIN_MITER,
                                                      10.0f, dash1, 0.0f);

    //===   CONSTANTS   =========================================================
    //===========================================================================



    //===========================================================================
    //===   NONLOCAL VARIABLES   ================================================

    private DenimRunWindow  win;       // the run window that the sheet is in
    private DenimPanel      renderedPanel;
    private DenimPanel curPanel;
    private AffineTransform lastTransform = new AffineTransform();

    private Set             timers = new HashSet();

    private double          panelDisplayWidth;
    private double          panelDisplayHeight;

    private boolean         scenarioMode = false;   // true iff running a scenario
    
    protected HashMap         orig2lst  = new HashMap();

    //===   NONLOCAL VARIABLES   ================================================
    //===========================================================================



    //===========================================================================
    //===   CONSTRUCTORS   ======================================================

    public DenimRunSheet(DenimRunWindow win, DenimPanel startingPanel) {
        this(win, startingPanel, false);
    }

    /**
     * Construct a DenimRunSheet containing the given panel.
     */
    public DenimRunSheet(DenimRunWindow win, DenimPanel startingPanel, boolean scenarioMode) {
        super();

        this.win = win;
        this.scenarioMode = scenarioMode;
        
        DenimSheet origSheet = (DenimSheet)startingPanel.getSheet();
        this.backgroundName = origSheet.backgroundName;
        this.imageX = origSheet.imageX;
        this.imageY = origSheet.imageY;
        this.imageW = origSheet.imageW;
        this.imageH = origSheet.imageH;

        //// 1.
        setLayout(null);
        setBackground(new Color(255, 255, 255));
        setEnabled(false);
        
        DenimRunMouseAdapter adapter = new DenimRunMouseAdapter();
        addMouseListener(adapter);
        addMouseMotionListener(adapter);


        //// 2. Get the width of the panel.
        renderPanel(startingPanel);

        DenimPanel displayedPanel = (DenimPanel)this.get(0);
        panelDisplayWidth =
            displayedPanel.getSketch().getWidth2D(SatinConstants.COORD_ABS);
        panelDisplayHeight =
            displayedPanel.getSketch().getHeight2D(SatinConstants.COORD_ABS) +
            displayedPanel.getLabel().getHeight2D(SatinConstants.COORD_ABS);


    } // of constructor

    //===   CONSTRUCTORS   ======================================================
    //===========================================================================

    //===========================================================================
    //===   INNER CLASSES   =====================================================

    class TimerAction
        implements ActionListener {

        private javax.swing.Timer timer;
        private Arrow arrow;
        private DenimRunSheet runSheet;
        private DenimPanel renderedPanel;

        public TimerAction (javax.swing.Timer timer, DenimRunSheet runSheet, Arrow arrow, DenimPanel renderedPanel) {
            super();
            this.timer = timer;
            this.runSheet = runSheet;
            this.arrow = arrow;
            this.renderedPanel = renderedPanel;
        }
        public void actionPerformed(ActionEvent aEvt) {
            timer.stop();

            // Handle back and forward buttons
            //runSheet.getRunWindow().pushCurrentPanel();
            //runSheet.getRunWindow().clearNextPanels(); //empty the next stack if click on link

            // Fire the event
            DenimComponentInstance inst = (DenimComponentInstance) arrow.getSource();
            inst.handleEvent(new DenimEvent(inst, arrow.getInputEventType()),
                             renderedPanel.getCurrentRunTimeCondition());

        }
    }

    //===   INNER CLASSES   =====================================================
    //===========================================================================

    //===========================================================================
    //===   RUN SHEET METHODS   =================================================

    /*
     * Returns the most nested component instance at the given point in
     * absolute coordinates.
     */
    private DenimComponentInstance findDeepestComponentInstance (Point p) {
        GraphicalObjectCollection gobcol;
        gobcol = getGraphicalObjects(COORD_ABS, p, FIRST, DEEP, CONTAINS, 0.0,
                                     null);
        GraphicalObject deepObject = gobcol.getFirst();

        while (deepObject != null &&
               !(deepObject instanceof DenimComponentInstance)) {
            deepObject = deepObject.getParentGroup();
        }

        return (DenimComponentInstance)deepObject;
    }// of findDeepestComponentInstance

    //-----------------------------------------------------------------

    /**
     * Returns the height of the contents of the sheet.
     */
    public int getVisibleHeight() {
        return (int) panelDisplayHeight + 30;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns the width of the contents of the sheet.
     */
    public int getVisibleWidth() {
        return (int) panelDisplayWidth + 10;
    } // of method

   //-----------------------------------------------------------------

   /**
    * Returns the panel which is currently being displayed by this sheet.
    */
   public DenimPanel getRenderedPanel() {
      return renderedPanel;
   }
   
   public DenimPanel getPanel() {
      return this.curPanel;
   }
   
    //-----------------------------------------------------------------

    /**
     * Returns the run window that contains this sheet.
     */
    private DenimRunWindow getRunWindow() {
        return win;
    } // of method

    //===   RUN SHEET METHODS   =================================================
    //===========================================================================

    //-----------------------------------------------------------------

    private void recursiveDeepClear(GraphicalObjectGroupImpl gog) {

       Iterator it = gog.getForwardIterator();
       GraphicalObjectCollection toDelete = new GraphicalObjectCollectionImpl();

       while(it.hasNext())
       {
          GraphicalObjectImpl go = (GraphicalObjectImpl)it.next();
          
          if(go instanceof GraphicalObjectGroupImpl)
          {
             recursiveDeepClear((GraphicalObjectGroupImpl)go);
          }
          else
          {
             toDelete.add(go);
          }
          
          if(!(go instanceof Crosshairs))
             go.deepClear();
       }
       
       gog.removeAllSilently(toDelete);

    } 
    
    public void reset() {
    	curPanel = null;
    	orig2lst.clear();
    }


    //===========================================================================
    //===   RENDER METHODS   ====================================================

    /**
     * Draw the specified Denim storyboard panel on the Run sheet, and therefore,
     * in the Run window.
     */
    public void renderPanel(DenimPanel panel) {

        Iterator it;

        //// 1. Turn off beserker mode.
        disableDamage();
        
        /**
         * save the last state
         */
        if(this.curPanel!=null)
        {
            renderedPanel.delete();
            orig2lst.put(curPanel, renderedPanel);//.deepClone());
        }

        //// 2. Clear out everything in the sheet.
        //deep clear scenegraph
        try
        {
           recursiveDeepClear(gobs);
        }
        catch(java.util.ConcurrentModificationException e)
        {
           System.out.println(e);
        }
        
        clear();
        
        //// Turn off the grid lines
        DenimSketch.setGridOn(false);
        
        /**
         * if panel was not shown before
         */
        if(orig2lst.get(panel)==null)
        {
    
            //// 3. Clone the panel to display
            renderedPanel = (DenimPanel)(panel.deepClone());
            
            this.curPanel = panel;
    
            //// 4. Add the cloned panel to this sheet, and put it in the upper
            ////    left-hand corner.
            renderedPanel.makeVisibleAtUpperLeftIn(this);
    
            //// 5. If a scenario is being recorded, add the panel to the scenario.
            if (win.isRecording()) {
                win.recordPanel(panel, false);
            }
    
            //// 6. Make the page look "right":
            DenimSketch sketch = renderedPanel.getSketch();
            
            it = sketch.getForwardIterator();
            while (it.hasNext()) {
                Object obj = it.next();
    
                //// Set transparency to default.
                if (obj instanceof DenimSketchContents) {
                    ((DenimSketchContents)obj).setTransparency(
                                             DenimConstants.DEFAULT_TRANSPARENCY);
                }
                
                //// Turn off panel bar within component instance.
                if (obj instanceof DenimCustomComponentInstance) {
                    DenimCustomComponentInstance inst = (DenimCustomComponentInstance)obj;
                    DenimPanel panelTmp = null;
                    Iterator it2 = inst.getForwardIterator();
                    while (it2.hasNext()) {
                        Object obj2 = it2.next();
                        if (obj2 instanceof DenimPanel) {
                            panelTmp = (DenimPanel)obj2;
                        }
                    }
                    if (panelTmp != null) {
                        if (panelTmp.getPanelBar() != null) {
                            panelTmp.getPanelBar().setVisible(false);
                        }
                        panelTmp.getSketch().getStyleRef().setDrawColorRGBA(0, 0, 0, 0);
                    }
                }
    
                //// Make groups invisible.            
                if (obj instanceof DenimGroup) {
                   DenimGroup group = (DenimGroup)obj;
                   Style style = group.getStyle();
                   style.setDrawColor(DenimUtils.NO_COLOR);
                   style.setFillColor(DenimUtils.NO_COLOR);
                   group.setStyle(style);
                }
                
                if(obj instanceof DenimHyperlinkInstance) {
    
                   GraphicalObject content = ((DenimHyperlinkInstance)obj).getContents();
    
                   if(content instanceof DenimGroup) {
    
                      DenimGroup group = (DenimGroup)content;
                      Style style = group.getStyle();
                      style.setDrawColor(DenimUtils.NO_COLOR);
                      style.setFillColor(DenimUtils.NO_COLOR);
                      group.setStyle(style);
                      
                   }
                }
            }
            
            //// 7. Turn off "stack" effect, if necessary
            renderedPanel.setStackEffect(false);
        }
        else
        {
            renderedPanel = (DenimPanel)orig2lst.get(panel);
            this.curPanel = panel;
            this.add(renderedPanel);
        }
        
        //// 8. Disable current timers (that were armed for the previous panel)
        javax.swing.Timer timer;
        it = timers.iterator();
        while (it.hasNext()) {
            timer = (javax.swing.Timer) it.next();
            timer.stop();
        }

        //// 9. Arm any timers that might be in this panel
        Set timerArrows = panel.getTimerArrows();
        it = timerArrows.iterator();
        while (it.hasNext()) {
            Arrow arrow = (Arrow) it.next();
            int delay = DenimIntrinsicComponent.getTimerEventSeconds(arrow.getInputEventType());

            timer = new javax.swing.Timer(delay*1000, null);
            timer.addActionListener(new TimerAction(timer, this, arrow, renderedPanel));
            timer.start();
            timers.add(timer);
        }

        //// 10. Turn on damage again
        enableDamage();
        damage(DAMAGE_NOW);
        //debug.println("renderedPanel after: " + renderedPanel);

        //// 11. Update the window decorations
        win.update();

    } // of method

    //===   RENDER METHODS   ====================================================
    //===========================================================================



    //===========================================================================
    //===   INNER CLASS MOUSE LISTENERs ==========================================

    /**
     * Handles all mouse events inside the run sheet.
     */
    class DenimRunMouseAdapter extends MouseInputAdapter {
        private DenimComponentInstance focus;
        private DenimComponentInstance oldInst;

        //-----------------------------------------------------------------
    
        public void mousePressed(MouseEvent evt) {
            // ignore all mouse clicks when running a scenario
            if (scenarioMode) {
                return;
            }

            DenimComponentInstance inst =
                findDeepestComponentInstance(evt.getPoint());

            if (inst != null) {
                focus = inst;
                if (focus instanceof DenimHyperlinkInstance) {
                    inst.getStyleRef().setDrawColor(Color.black);
                    inst.getStyleRef().setDrawStroke(dashed);
                    DenimRunSheet.this.damage(DAMAGE_NOW);
                }
                focus.mousePressed(evt);
            }
            oldInst = focus; 
        } // of mousePressed

        //-----------------------------------------------------------------
    
        public void mouseReleased(MouseEvent evt) {
            // advance to next panel in scenario sequence
            if (scenarioMode) {
                win.gotoNextPanel();
                return;
            }

            //debug.println("DenimRunSheet: Released");
            //debug.println("this: " + DenimRunSheet.this);

            DenimComponentInstance inst =
                findDeepestComponentInstance(evt.getPoint());

            if (inst != null && inst == focus) {
                focus.mouseReleased(evt);
                // Assuming that clicking on a hyperlink or button is the
                // only way to transition to another panel
                //if (focus instanceof DenimHyperlinkInstance ||
                //    focus instanceof DenimButtonInstance) {
                //    DenimRunSheet rs = (DenimRunSheet)evt.getComponent();
                //    rs.getRunWindow().pushCurrentPanel();
                //    rs.getRunWindow().clearNextPanels(); //empty the next stack if click on link
                //}

                String eventName = null;

                // Check for valid event
                if (SwingUtilities.isLeftMouseButton(evt)) {
                    int getClickCount = evt.getClickCount();
                    if (getClickCount == 1) {
                        eventName = DenimIntrinsicComponent.LEFT_CLICK;
                    }
                    else if (getClickCount == 2) {
                        eventName = DenimIntrinsicComponent.LEFT_2CLICK;
                    }
                }
                else if (SwingUtilities.isRightMouseButton(evt)) {
                    int getClickCount = evt.getClickCount();
                    if (getClickCount == 1) {
                        eventName = DenimIntrinsicComponent.RIGHT_CLICK;
                    }
                    else if (getClickCount == 2) {
                        eventName = DenimIntrinsicComponent.RIGHT_2CLICK;
                    }
                }

                // If valid event, then give event to component instance to handle
                if (eventName != null) {
                    //debug.println("Event from: " + DenimUtils.toShortString(inst));
                    //debug.println("Event type: " + eventName);
                    //debug.println("Run time condition: " + renderedPanel.getCurrentRunTimeCondition());
                    if (inst.getComponentType().hasEvent(eventName)) {
                        //debug.println("component type has event");
                        inst.handleEvent(new DenimEvent(inst, eventName),
                                         renderedPanel.getCurrentRunTimeCondition());
                    }
                    else {
                        //debug.println(eventName + " not supported");
                    }
                }
                else {
                    //debug.println("No event");
                }
                
            }
            else {
                //debug.println("No event source");
            }
            focus = null;

        } // of mouseClicked

        //-----------------------------------------------------------------
    
        public void mouseMoved(MouseEvent evt) {
            
            DenimComponentInstance inst =
                findDeepestComponentInstance(evt.getPoint());
            //DenimRunSheet rs = (DenimRunSheet)evt.getComponent();
            int cond = renderedPanel.getCurrentRunTimeCondition();
            
            if(inst==null)
                return;

            /// 1. handle mouse movement between objects
            if (oldInst != inst) {

                /// 2.1 handle mouse exit from the "old" instance
                if (oldInst != null &&
                    oldInst instanceof DenimComponentInstance &&
                    oldInst.getComponentType() != null &&
                    oldInst.getComponentType().isIntrinsic()) {

                    oldInst.mouseExited(evt);

                    DenimEvent eventAction =
                       new DenimEvent(oldInst,
                                      DenimIntrinsicComponent.MOUSE_EXIT);
                                      
                    if (oldInst.hasAction(eventAction, cond)) {

                        // Handle back and forward buttons
                        //rs.getRunWindow().pushCurrentPanel();
                        //rs.getRunWindow().clearNextPanels();
                        // activate the action
                        oldInst.handleEvent(eventAction, cond);
                    }
                }

                /// 2.2 handle mouse enter to the new instance
                if (inst != null &&
                    inst instanceof DenimComponentInstance &&
                    inst.getComponentType().isIntrinsic() ) {
                     
                    inst.mouseEntered(evt);

                    DenimEvent eventAction = new DenimEvent(
                                          inst,
                                          DenimIntrinsicComponent.MOUSE_ENTER);

                    if (inst.hasAction(eventAction, cond)) {

                        // Handle back and forward buttons
                        //rs.getRunWindow().pushCurrentPanel();
                        //rs.getRunWindow().clearNextPanels();
                        // activate the action
                        inst.handleEvent(eventAction, cond);
                    }
                }
            }

            oldInst = inst;

        } // end of mouseMoved

        //-----------------------------------------------------------------
    
        public void mouseDragged(MouseEvent evt) {
           DenimComponentInstance inst =
              findDeepestComponentInstance(evt.getPoint());

           if (oldInst != null && oldInst == focus && oldInst != inst) {
              oldInst.mouseExited(evt);
           }

           if (inst != null && inst == focus) {
              if (oldInst != inst) {
                 inst.mouseEntered(evt);
              }
              else {
                 inst.mouseDragged(evt);
              }
           }
           oldInst = inst;
        } // end of mouseDragged

    } // of MouseListener

    //===   INNER CLASS MOUSE LISTENER ==========================================
    //===========================================================================

    public String getBackgroundName() {
        return this.backgroundName;
    }
    
    public double getImageX() {
        return this.imageX;
    }
    public double getImageY() {
        return this.imageY;
    }
    
    public double getImageW() {
        return this.imageW;
    }
    
    public double getImageH() {
        return this.imageH;
    }
    
} // of class

//==============================================================================

/*
  Copyright (c) 2000 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
