//// See bottom of file for software license
package edu.berkeley.guir.lib.collection;

import java.util.Date;

/**
 * Do something interesting at a given time.
 * To use this, subclass and implement method <CODE>run()</CODE>.
 * Then, place the TimedEvent into a TimedEventQueue.
 * The event will then execute at (about) the specified time.
 *
 * <P>
 * Can also make the TimedEvents recurring, so that they periodically
 * run and re-enqueue themselves according to a specified delay.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Jan 12 2004 JIH
 */
abstract public class TimedEvent 
    implements Runnable {

    //==========================================================================
    //===   TEST INNER CLASS   =================================================

    //// Used for TestTimedEvent only
    static int nextID = 0;

    /**
     * A TimedEvent for testing purposes.
     */
    public static class TestTimedEvent
        extends TimedEvent {

        int id     = nextID++;

        public TestTimedEvent() {
        } // of method

        /**
         * Set an activation time.
         */
        public TestTimedEvent(long millis) {
            setActivationTime(millis);
        } // of method

        public void run() {
            long curTime = System.currentTimeMillis();
            System.out.println(curTime + " running " + toString());
        } // of method

        public String toString() {
            return ("id: " + id);
        } // of method

    } // of inner class

    //===   TEST INNER CLASS   =================================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    long    activationTime;         // when to activate

    //----------------------------------------------------------------

    int     delay = -1;             // recurring are automatically re-queued
                                    // delay is in millis, added to current time

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * A timed event that will execute immediately.
     */
    public TimedEvent() {
    } // of method

    //----------------------------------------------------------------

    /**
     * A timed event that will execute at the specified time.
     */
    public TimedEvent(long millisAbsoluteTime) {
        setActivationTime(millisAbsoluteTime);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * A timed event that will execute at the specified time.
     */
    public TimedEvent(long millisAbsoluteTime, int delay) {
        setActivationTime(millisAbsoluteTime);
        setRecurring(delay);
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   ACCESSOR / MODIFIER METHODS   ======================================

    /**
     * Set when the event will activate (in millis).
     */
    public void setActivationTime(long millisAbsoluteTime) {
        activationTime = millisAbsoluteTime;
    } // of method

    //----------------------------------------------------------------

    public long getActivationTime() {
        return (activationTime);
    } // of method

    //----------------------------------------------------------------

    /**
     * Set whether this is recurring or not.
     * Recurring events are automatically re-enqueued after being activated.
     *
     * @param aDelayMillis is how long before the TimedEvent should activate 
     *                     again. Set to any negative value to stop recurring.
     */
    public void setRecurring(int aDelayMillis) {
        delay = aDelayMillis;
    } // of method

    //----------------------------------------------------------------

    public boolean isRecurring() {
        return (delay > 0);
    } // of method

    //----------------------------------------------------------------

    /**
     * Update when this event should run again.
     * Only useful if the event is recurring, ignored otherwise.
     */
    public void updateActivationTime() {
        if (isRecurring() == false) {
            return;
        }

        setActivationTime(System.currentTimeMillis() + delay);
    } // of method

    //===   ACCESSOR / MODIFIER METHODS   ======================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        String strClassName = this.getClass().getName();
        int    index        = strClassName.lastIndexOf(".");
        strClassName = strClassName.substring(index + 1);

        return (strClassName + " ActivationTime: " + new Date(activationTime));
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
