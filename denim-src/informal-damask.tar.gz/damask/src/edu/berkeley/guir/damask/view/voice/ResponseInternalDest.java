package edu.berkeley.guir.damask.view.voice;


/**
 * A marker interface that marks a class as a destination of a response, where
 * the destination and the response itself are in the same conversation.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-18-2004 James Lin
 *                               Created ResponseInternalDest.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-18-2004
 */
public interface ResponseInternalDest extends ResponseDest {
}
