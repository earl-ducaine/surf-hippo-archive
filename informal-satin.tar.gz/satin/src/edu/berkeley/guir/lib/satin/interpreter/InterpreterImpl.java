//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter;

import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import java.util.EventObject;

/**
 * The superclass for all of the types of interpreters. Interpreters can do two
 * different things: handle and manipulate new strokes, and manipulate old
 * strokes. Interpreters are attached to GraphicalObjects, currently one 
 * interpreter per GraphicalObject.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 22 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public abstract class InterpreterImpl
   implements Interpreter {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   GraphicalObject        gob;                  // ref to gob that contains us
   String                 strName;              // name of this interpreter
   boolean                flagEnabled = true;   // is this Interpreter enabled?
   BasicStrokeEventFilter filter      = new BasicStrokeEventFilter();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Empty constructor.
    */
   public InterpreterImpl() {
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   public boolean isEnabled() {
      return (flagEnabled);
   } // of isEnabled

   //-----------------------------------------------------------------

   public String getName() {
      return (strName);
   } // of getName

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   public void setEnabled(boolean flag) {
      this.flagEnabled = flag;
   } // of setEnabled

   //-----------------------------------------------------------------

   public String setName(String strName) {
      this.strName = strName;
      return (strName);
   } // of setName

   //-----------------------------------------------------------------

   /**
    * Set the GraphicalObject this Interpreter is attached to.
    *
    * @param gob is the GraphicalObject this Interpreter is to be attached to.
    *            Okay if null temporarily.
    */
   public GraphicalObject setAttachedGraphicalObject(GraphicalObject newGob) {
      gob = newGob;
      return (newGob);
   } // of setAttachedGraphicalObject

   //-----------------------------------------------------------------

   /**
    * Get the GraphicalObject this Interpreter is attached to.
    *
    * @return a GraphicalObject.
    */
   public GraphicalObject getAttachedGraphicalObject() {
      return (gob);
   } // of getGraphicalObjectParent

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   STROKE METHODS   ====================================================

   /**
    * By default, does nothing.
    */
   public void handleNewStroke(NewStrokeEvent evt) {
   } // of handleNewStroke

   //-----------------------------------------------------------------

   /**
    * By default, does nothing.
    */
   public void handleUpdateStroke(UpdateStrokeEvent evt) {
   } // of handleUpdateStroke

   //-----------------------------------------------------------------

   /**
    * By default, does nothing.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
   } // of handleSingleStroke

   //===   STROKE METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   FILTER METHODS   ====================================================

   public boolean isConsumedAccepted() {
      return (filter.isConsumedAccepted());
   } // of isConsumedAccepted

   public boolean isLeftButtonAccepted() {
      return (filter.isLeftButtonAccepted());
   } // of isLeftButtonAccepted

   public boolean isMiddleButtonAccepted() {
      return (filter.isMiddleButtonAccepted());
   } // of isMiddleButtonAccepted

   public boolean isRightButtonAccepted() {
      return (filter.isRightButtonAccepted());
   } // of isRightButtonAccepted

   //-----------------------------------------------------------------

   public void setAcceptConsumed(boolean flag) {
      filter.setAcceptConsumed(flag);
   } // of setAcceptConsumed

   public void setAcceptLeftButton(boolean flag) {
      filter.setAcceptLeftButton(flag);
   } // of setAcceptLeftButton

   public void setAcceptMiddleButton(boolean flag) {
      filter.setAcceptMiddleButton(flag);
   } // of setAcceptMiddleButton

   public void setAcceptRightButton(boolean flag) {
      filter.setAcceptRightButton(flag);
   } // of setAcceptRightButton

   //-----------------------------------------------------------------

   /**
    * This method is called for us when an event is handed to us, 
    * to ensure that we really want to handle the event.
    */
   public boolean isEventAccepted(StrokeEvent evt) {
      return (filter.isEventAccepted(evt));
   } // of isEventAccepted

   /**
    * This method is called for us when an event is handed to us, 
    * to ensure that we really want to handle the event.
    */
   public boolean isEventAccepted(EventObject evt) {
      return (filter.isEventAccepted(evt));
   } // of isEventAccepted

   //===   FILTER METHODS   ====================================================
   //===========================================================================
   


   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 1. Append data.
      strbuf.append("Interpreter Name: " + getName());

      strbuf.append("\nAttached GOb ID:  ");
      if (gob == null) {
         strbuf.append("Not attached");
      }
      else {
         strbuf.append(gob.getUniqueID());
      }
      strbuf.append("\nisEnabled:        " + flagEnabled);
      strbuf.append("\n" + filter.toString());

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Since not overriding clone() can cause many errors with
    * copying-and-pasting, I'm forcing you to do it. So there.
    */
   public abstract Object clone();

   //-----------------------------------------------------------------

   protected InterpreterImpl clone(InterpreterImpl intrp) {
      intrp.gob         = this.gob;
      intrp.strName     = this.strName;
      intrp.flagEnabled = this.flagEnabled;
      intrp.filter      = (BasicStrokeEventFilter) this.filter.clone();

      return (intrp);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
