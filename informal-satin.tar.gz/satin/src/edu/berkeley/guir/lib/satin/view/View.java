//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import java.io.Serializable;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.objects.*;

/**
 * Describes how a GraphicalObject appears on the screen.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 11 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public interface View 
   extends SatinConstants, Cloneable, Serializable {

   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Used to set the GraphicalObject this View is attached to. All
    * views attached will have the specified GOb set to this parameter.
    * This method should be called automatically when the View is added to a
    * GraphicalObject.
    *
    * @param  gob is the GraphicalObject this View is attached to.
    * @return a reference to gob.
    */
   public GraphicalObject setAttachedGraphicalObject(GraphicalObject newGob);

   //-----------------------------------------------------------------

   /**
    * Set the reference for the bounding points for this view.
    * <B>Make sure that the bounds match what you are rendering</B>.
    * Otherwise, you will get some repaint errors, as well as selection errors.
    *
    * @param p is the polygon bounds. Assumes the bounds are already in
    *          local coordinates.
    */
   public void setBoundingPoints2DRef(Polygon2D p);

   //-----------------------------------------------------------------

   /**
    * Set whether this view is visible or not.
    */
   public void setVisible(boolean flag);

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Get the reference for the bounding points for this view.
    *
    * @return the polygon bounds.
    */
   public Polygon2D getBoundingPoints2DRef();

   //-----------------------------------------------------------------

   /**
    * Get the GraphicalObject this View is attached to.
    *
    * @return the GraphicalObject this View is attached to.
    */
   public GraphicalObject getAttachedGraphicalObject();

   //-----------------------------------------------------------------

   /**
    * Check whether this view is visible or not. A view is visible
    * if the visible flag is set (via {@link #setVisible(boolean)})
    * and if the view display value is greater than 0.
    *
    * @return true if the view is visible, false otherwise.
    */
   public boolean isVisible();

   //-----------------------------------------------------------------

   /**
    * Check whether or not this view is valid, ie can and should be displayed. 
    * This can be a combination of any range of parameters. For example, you 
    * could say that this view is valid when:
    * <UL>
    *    <LI>The GraphicalObject's zoom level is within a certain range.
    *    <LI>The GraphicalObject has debugging information turned on.
    * </UL>
    *
    * @return a value between 0.0 and 1.0, with 0.0 meaning do not display,
    *         and 1.0 meaning must display.
    */
   public float getViewDisplayValue();

   //-----------------------------------------------------------------

   /**
    * Get the name of this View.
    *
    * @return Some useful not-too-technical real-world name for this View.
    */
   public String getName();

   //-----------------------------------------------------------------

   /**
    * Set the name of this View.
    *
    * @param  strName is the name of this View.
    * @return a reference to strName.
    */
   public String setName(String strName);

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   RENDERING METHODS   =================================================

   /**
    * Render this view. Use (0,0) as the top-left corner of this view.
    * Any transformations that the attached GraphicalObject has will
    * automatically be applied, so all you have to do is render the view
    * normally.
    */
   public void render(SatinGraphics g);

   //===   RENDERING METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Implementation of the Sorceror's Apprentice algorithm.
    * Needs to be a DEEP clone.
    */
   public Object clone();

   //===   CLONE   =============================================================
   //===========================================================================

} // of class View

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
