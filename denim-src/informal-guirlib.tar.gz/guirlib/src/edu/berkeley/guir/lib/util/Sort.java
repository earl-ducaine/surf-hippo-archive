//// See bottom of source code for software license.
package edu.berkeley.guir.lib.util;

import edu.berkeley.guir.lib.debugging.*;
import java.util.Random;

/**
 * Various sorting algorithms.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 *
 * @deprecated Use java.util.Comparator or java.util.Comparator, and sort 
 *             methods in java.util.Arrays and java.util.Collections instead.
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @author  Khai Truong
 * @version Last modified Aug 31 2000
 */
public class Sort {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   UTILITY METHODS   ===================================================

   /**
    * Swaps two elements in an array.
    *
    * @param    theArray is the array of ints where two elements are swapped.
    * @param    index1 is the position of the first element being swapped.
    * @param    index2 is the position of the second element being swapped.
    */
   private final static void swap( int[] theArray, int index1, int index2 ) {

      int temp = theArray[ index1 ];
      theArray[ index1 ] = theArray[ index2 ];
      theArray[ index2 ] = temp;

   }  // end of swap()

   //===========================================================================

   /**
    * Swaps two elements in an array.
    *
    * @param    theArray is the array of Objects where two elements are swapped.
    * @param    index1 is the position of the first element being swapped.
    * @param    index2 is the position of the second element being swapped.
    */
   private final static void swap( Object[] theArray, int index1, int index2 ) {

      Object temp = theArray[ index1 ];
      theArray[ index1 ] = theArray[ index2 ];
      theArray[ index2 ] = temp;

   }  // end of swap()

   //===   UTILITY METHODS   ===================================================
   //===========================================================================



   //===========================================================================
   //===   BUBBLE SORT   =======================================================

   /**
    * Performs a "bubble" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @return   Returns the time in milliseconds used to perform the sort.
    */
   final public static long bubbleSort( int[] theArray ) {

      boolean flagSwapped = true;   // have we swapped any elements on 
                                    //    the current iteration or not

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      for ( int i = theArray.length - 1; (i >= 0) && flagSwapped; i-- ) {
         for ( int j = 0; j < i; j++ ) {
            flagSwapped = false;
            if ( theArray[ j ] > theArray[j + 1] ) {
               swap(theArray, j, j + 1);
               flagSwapped     = true;
            }
         } 
      }

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of bubbleSort()

   //===========================================================================

   /**
    * Performs a "bubble" sort on theArray passed in.
    *
    * @see      edu.berkeley.guir.lib.util.Comparison
    * @param    theArray is the array of ints to be sorted.
    * @param    compare is a Comparison that allows Objects to be compared.
    * @return   Returns the time in milliseconds used to perform the sort.
    */
   final public static long bubbleSort(Object[] theArray, Comparison compare) {

      boolean flagSwapped = true;   // have we swapped any elements on 
                                    //    the current iteration or not

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      for ( int i = theArray.length - 1; (i >= 0) && flagSwapped; i-- ) {
         for ( int j = 0; j < i; j++ ) {
            flagSwapped = false;
            if ( compare.isGreaterThan(theArray[j], theArray[j + 1]) ) {
               swap(theArray, j, j + 1);
               flagSwapped     = true;
            }
         } 
      }

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of bubbleSort()

   //===========================================================================

   /**
    * Performs a bidirectional "bubble" sort on theArray passed in. Based on
    * the JDK demo code (by Gosling).
    *
    * @param    theArray is the array of ints to be sorted.
    * @return   Returns the time in milliseconds used to perform the sort.
    */
   final public static long bidirBubbleSort( int[] theArray ) {
      int     j;
      int     limit       = theArray.length;
      int     st          = -1;
      boolean flagSwapped = true;       // have we swapped any elements on 
                                        //    the current iteration or not

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      while (st < limit) {
         st++;
         limit--;
         flagSwapped = false;

         //// 2.1. Sort forwards
         for (j = st; j < limit; j++) {
            if (theArray[j] > theArray[j + 1]) {
               swap(theArray, j, j + 1);
               flagSwapped     = true;
            }
         }

         if (!flagSwapped) {
            break;
         }

         //// 2.2. Sort backwards
         for (j = limit - 1; j >= st; j--) {
            if (theArray[j] > theArray[j + 1]) {
               swap(theArray, j, j + 1);
               flagSwapped     = true;
            }
         }

         if (!flagSwapped) {
            break;
         }

      } // of while

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   } // of bidirBubbleSort

   //===========================================================================

   /**
    * Performs a bidirectional "bubble" sort on theArray passed in. Based on
    * the JDK demo code (by Gosling).
    *
    * @param    theArray is the array of ints to be sorted.
    * @param    compare is a Comparison that allows Objects to be compared.
    * @return   Returns the time in milliseconds used to perform the sort.
    */
   final public static long bidirBubbleSort(Object[] theArray, 
                                            Comparison compare ) {
      int     j;
      int     limit       = theArray.length;
      int     st          = -1;
      boolean flagSwapped = true;       // have we swapped any elements on 
                                        //    the current iteration or not

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      while (st < limit) {
         st++;
         limit--;
         flagSwapped = false;

         //// 2.1. Sort forwards
         for (j = st; j < limit; j++) {
            if ( compare.isGreaterThan(theArray[j], theArray[j + 1]) ) {
               swap(theArray, j, j + 1);
               flagSwapped     = true;
            }
         }

         if (!flagSwapped) {
            break;
         }

         //// 2.2. Sort backwards
         for (j = limit - 1; j >= st; j--) {
            if ( compare.isGreaterThan(theArray[j], theArray[j + 1]) ) {
               swap(theArray, j, j + 1);
               flagSwapped     = true;
            }
         }

         if (!flagSwapped) {
            break;
         }

      } // of while

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   } // of bidirBubbleSort

   //===   BUBBLE SORT   =======================================================
   //===========================================================================



   //===========================================================================
   //===   HEAP SORT   =========================================================

   /**
    * Performs a "heap" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @return   Returns the time in milliseconds used to perform the sort.<BR>
    */
   final public static long heapSort( int[] theArray ) {

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      int heapSize = theArray.length;
      for( int i = ( heapSize / 2 ) ; i > 0; i-- )
          siftDown( theArray, i, heapSize );

      do {
         swap( theArray, 0, heapSize - 1 );
         heapSize--;
         siftDown( theArray, 1, heapSize );
      } while ( heapSize > 1 );

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of heapSort()

   //===========================================================================

   /**
    * Converts the inital unordered ints into a <EM>heap</EM>. Maintains 
    * the <EM>heap condition</EM> after each occasion of "removing" a
    * value from the heap.
    *
    * @param    theArray is the array of ints where two elements are swapped.
    * @param    k is the current position of where the heap sort is.
    * @param    heapSize is the size of how many ints left in the _heap_.
    */
   final private static void siftDown( int[] theArray, int k, int heapSize ) {

      boolean done = false;
      int temp = theArray[ k - 1 ];

      while ( (k <= (heapSize/2) ) && ( ! done ) ) {
         int j = 2 * k;

         if ( (j < heapSize) && (theArray[j - 1] < theArray[j]) )
            j++;
         if ( temp >= theArray[j - 1] )
            done = true;
         else {
            theArray[k - 1] = theArray[j - 1];
            k = j;
         }
      }
      theArray[k - 1] = temp;

   }  // end of siftDown()

   //===========================================================================

   /**
    * Performs a "heap" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @param    compare is a Comparison that allows Objects to be compared.
    * @return   Returns the time in milliseconds used to perform the sort.<BR>
    */
   final public static long heapSort( Object[] theArray, Comparison compare ) {

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      int heapSize = theArray.length;
      for( int i = ( heapSize / 2 ) ; i > 0; i-- )
          siftDown( theArray, i, heapSize, compare );

      do {
         swap( theArray, 0, heapSize - 1 );
         heapSize--;
         siftDown( theArray, 1, heapSize, compare );
      } while ( heapSize > 1 );

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of heapSort()

   //===========================================================================

   /**
    * Converts the inital unordered ints into a <EM>heap</EM>. Maintains 
    * the <EM>heap condition</EM> after each occasion of "removing" a
    * value from the heap.
    *
    * @param    theArray is the array of ints where two elements are swapped.
    * @param    k is the current position of where the heap sort is.
    * @param    heapSize is the size of how many ints left in the _heap_.
    * @param    compare is a Comparison that allows Objects to be compared.
    */
   final private static void siftDown( Object[] theArray, int k, int heapSize,
                                        Comparison compare ) {

      boolean done = false;
      Object  temp = theArray[ k - 1 ];

      while ( (k <= ( heapSize / 2) ) && ( ! done ) ) {
         int j = 2 * k;

         if ( (j < heapSize) &&
              compare.isLessThan(theArray[j - 1], theArray[j]) )
            j++;
         if (compare.isGreaterThanOrEqual(temp, theArray[j - 1]))
            done = true;
         else {
            theArray[k - 1] = theArray[j - 1];
            k = j;
         }
      }
      theArray[k - 1] = temp;

   }  // end of siftDown()

   //===   HEAP SORT   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INSERTION SORT   ====================================================

   /**
    * Performs an "insertion" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    *
    * @return   Returns the time in milliseconds used to perform the sort.<BR>
    */
   final public static long insertionSort( int[] theArray ) {

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      if ( theArray.length > 0 )
         for( int i = 1; i < theArray.length; i++ )
            insertLeft( theArray, theArray[i], i - 1 );

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of insertionSort()

   //===========================================================================

   /**
    * Inserts aNumber in its proper place in the left part of an array.
    *
    * @param    theArray is the array of ints where two elements are swapped.
    * @param    aNumber is a number being inserted in the left part of theArray.
    * @param    index is the "before" position of aNumber in theArray.
    */
   final private static void insertLeft( int[] theArray, int aNumber, 
                                         int index ) {

      while( ( index >= 0 ) && ( aNumber < theArray[index] ) ) {
         theArray[index + 1] = theArray[index];
         index--;
      }
      theArray[index + 1] = aNumber;

   }  // end of insertLeft()

   //===========================================================================

   /**
    * Performs an "insertion" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @param    compare is a Comparison that allows Objects to be compared.
    * @return   Returns the time in milliseconds used to perform the sort.<BR>
    */
   final public static long insertionSort( Object[] theArray, 
                                           Comparison compare ) {

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      if ( theArray.length > 0 )
         for( int i = 1; i < theArray.length; i++ )
            insertLeft( theArray, theArray[i], i - 1, compare );

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of insertionSort()

   //===========================================================================

   /**
    * Inserts aNumber in its proper place in the left part of an array.
    *
    * @param    theArray is the array of ints where two elements are swapped.
    * @param    anObj is an Object being inserted in the left part of theArray.
    * @param    index is the "before" position of aNumber in theArray.
    * @param    compare is a Comparison that allows Objects to be compared.
    */
   final private static void insertLeft( Object[] theArray, Object anObj,
                                         int index, Comparison compare ) {

      while( (index >= 0) && compare.isLessThan(anObj, theArray[index]) ) {
         theArray[index + 1] = theArray[index];
         index--;
      }
      theArray[index + 1] = anObj;

   }  // end of insertLeft()

   //===   INSERTION SORT   ====================================================
   //===========================================================================



   //===========================================================================
   //===   MERGE SORT   ========================================================

   /**
    * Performs a "merge" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    *
    * @return   Returns the time in milliseconds used to perform the sort.<BR>
    */
   final public static long mergeSort( int[] theArray ) {

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      if ( theArray.length > 0 )
         mergeSort( theArray, 0, theArray.length - 1 );

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of performMergeSort()

   //===========================================================================

   /**
    * Performs a "merge" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @param    first is the lowest index of the subarray being sorted.
    * @param    last is the highest index of the subarray being sorted.
    */
   final private static void mergeSort( int[] theArray, int first, int last ) {

      if ( first < last ) {
         int middle = ( first + last ) / 2;
         mergeSort( theArray, first, middle );
         mergeSort( theArray, middle+1, last );
         merge( theArray, first, middle, last );
      }

   }  // end of mergeSort()

   //===========================================================================

   /**
    * Merges subarrays into a larger array...where the subarrays are:
    * <OL>
    *   <LI>theArray[first..middle] and
    *   <LI>theArray[middle+1..last]
    * </OL>
    *
    * @param    theArray is the array of ints to be merged.
    * @param    first is the lowest index of the 1st subarray being merged.
    * @param    middle is the break index between the two merging subarrays.
    * @param    high is the highest index of the 2nd subarray being merged.
    */
   final private static void merge( int[] theArray, int first, int middle, 
                                    int last ) {

      int[] tempArray = new int[ theArray.length ];
      int nextLeft    = first;
      int nextRight   = middle + 1;
      int index       = first;

      while( (nextLeft <= middle) && (nextRight <= last) ) {
         if ( theArray[nextLeft] < theArray[nextRight] ) {
            tempArray[index] = theArray[nextLeft];
            nextLeft++;
            index++;
         }
         else {
            tempArray[index] = theArray[nextRight];
            nextRight++;
            index++;
         }
      } // of while

      while( nextLeft <= middle ) {
         tempArray[index] = theArray[nextLeft];
         nextLeft++;
         index++;
      }

      while( nextRight <= last ) {
         tempArray[index] = theArray[nextRight];
         nextRight++;
         index++;
      }

      for( index = first; index <= last; index++ )
         theArray[index] = tempArray[index];

   }  // end of merge()

   //===========================================================================

   /**
    * Performs a "merge" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @param    compare is a Comparison that allows Objects to be compared.
    * @return   Returns the time in milliseconds used to perform the sort.<BR>
    */
   final public static long mergeSort( Object[] theArray, Comparison compare ) {

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      if ( theArray.length > 0 )
         mergeSort( theArray, 0, theArray.length - 1, compare );

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of performMergeSort()

   //===========================================================================

   /**
    * Performs a "merge" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @param    first is the lowest index of the subarray being sorted.
    * @param    last is the highest index of the subarray being sorted.
    * @param    compare is a Comparison that allows Objects to be compared.
    */
   final private static void mergeSort( Object[] theArray, int first, int last,
                                        Comparison compare ) {

      if ( first < last ) {
         int middle = ( first + last ) / 2;
         mergeSort( theArray, first, middle, compare );
         mergeSort( theArray, middle+1, last, compare );
         merge( theArray, first, middle, last, compare );
      }

   }  // end of mergeSort()

   //===========================================================================

   /**
    * Merges subarrays into a larger array...where the subarrays are:
    * <OL>
    *   <LI>theArray[first..middle] and
    *   <LI>theArray[middle+1..last]
    * </OL>
    *
    * @param    theArray is the array of ints to be merged.
    * @param    first is the lowest index of the 1st subarray being merged.
    * @param    middle is the break index between the two merging subarrays.
    * @param    high is the highest index of the 2nd subarray being merged.
    * @param    compare is a Comparison that allows Objects to be compared.
    */
   final private static void merge( Object[] theArray, int first, int middle, 
                                    int last, Comparison compare ) {

      Object[] tempArray = new Object[theArray.length];
      int      nextLeft  = first;
      int      nextRight = middle + 1;
      int      index     = first;

      while( (nextLeft <= middle) && (nextRight <= last) ) {
         if ( compare.isLessThan(theArray[nextLeft], theArray[nextRight]) ) {
            tempArray[index] = theArray[nextLeft];
            nextLeft++;
            index++;
         }
         else {
            tempArray[index] = theArray[nextRight];
            nextRight++;
            index++;
         }
      } // of while

      while( nextLeft <= middle ) {
         tempArray[index] = theArray[nextLeft];
         nextLeft++;
         index++;
      }

      while( nextRight <= last ) {
         tempArray[index] = theArray[nextRight];
         nextRight++;
         index++;
      }

      for( index = first; index <= last; index++ )
         theArray[index] = tempArray[index];

   }  // end of merge()

   //===   MERGE SORT   ========================================================
   //===========================================================================



   //===========================================================================
   //===   QUICK SORT   ========================================================

   /**
    * Performs a "quick" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @return   Returns the time in milliseconds used to perform the sort.
    */
   final public static long quickSort( int[] theArray ) {

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      if ( theArray.length > 0 )
         quickSort( theArray, 0, theArray.length - 1 );

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of quickSort()

   //===========================================================================

   /**
    * Performs a "quick" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @param    low is the lowest index of the subarray being sorted.
    * @param    high is the highest index of the subarray being sorted.
    */
   final private static void quickSort( int[] theArray, int low, int high ) {

      if ( low < high ) {

         //// 1. Partition the array into two parts
         int pivot = theArray[ low ];
         int left  = low;
         int right = high + 1;

         //// 2. Go through the array until the two indices meet
         do {
            //// 2.1. Find the first element smaller than the pivot element
            do {
               left++;
            } while( (left < theArray.length) && (theArray[left] <= pivot) );

            //// 2.2. Find the first element larger than the pivot element
            do {
               right--;
            } while( ( right > 0 ) && ( theArray[right] > pivot ) );

            //// 2.3. Swap the two elements
            if ( left < right ) {
               swap(theArray, left, right);
            }

         } while( left < right );

         swap( theArray, low, right );
         quickSort( theArray, low, right - 1 );
         quickSort( theArray, right + 1, high );
      }

   }  // end of quickSort()

   //===========================================================================

   /**
    * Performs a "quick" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @param    compare is a Comparison that allows Objects to be compared.
    * @return   Returns the time in milliseconds used to perform the sort.
    */
   final public static long quickSort(Object[] theArray, Comparison compare) {

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      if ( theArray.length > 0 )
         quickSort( theArray, 0, theArray.length - 1, compare );

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of quickSort()

   //===========================================================================

   /**
    * Performs a "quick" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @param    low is the lowest index of the subarray being sorted.
    * @param    high is the highest index of the subarray being sorted.
    * @param    compare is a Comparison that allows Objects to be compared.
    */
   final private static void quickSort( Object[] theArray, int low, int high,
                                        Comparison compare) {
      if ( low < high ) {

         //// 1. Partition the array into two parts
         Object pivot = theArray[ low ];
         int    left  = low;
         int    right = high + 1;

         //// 2. Go through the array until the two indices meet
         do {
            //// 2.1. Find the first element smaller than the pivot element
            do {
               left++;
            } while( (left < theArray.length) && 
                      compare.isLessThanOrEqual(theArray[left], pivot));

            //// 2.2. Find the first element larger than the pivot element
            do {
               right--;
            } while( ( right > 0 ) && 
                     compare.isGreaterThan(theArray[right], pivot));
            
            //// 2.3. Swap the two elements
            if ( left < right ) {
               swap(theArray, left, right);
            }

         } while( left < right );

         swap( theArray, low, right );
         quickSort( theArray, low, right - 1, compare );
         quickSort( theArray, right + 1, high, compare );
      }

   }  // end of quickSort()

   //===   QUICK SORT   ========================================================
   //===========================================================================



   //===========================================================================
   //===   SELECTION SORT   ====================================================

   /**
    * Performs a "selection" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    *
    * @return   Returns the time in milliseconds used to perform the sort.<BR>
    */
   final public static long selectionSort( int[] theArray ) {

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      for( int i = 0; i < theArray.length - 1; i++ ) {
         int min = i;

         for( int j = min + 1; j < theArray.length; j++ )
            if ( theArray[ j ] < theArray[ min ] )
               min = j;
         swap( theArray, i, min );
      }

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of selectionSort()

   //===========================================================================

   /**
    * Performs a "selection" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    * @param    compare is a Comparison that allows Objects to be compared.
    * @return   Returns the time in milliseconds used to perform the sort.<BR>
    */
   final public static long selectionSort(Object[] theArray, 
                                          Comparison compare) {

      //// 1. Get the start time
      long t0 = System.currentTimeMillis();

      //// 2. Sort
      for( int i = 0; i < theArray.length - 1; i++ ) {
         int min = i;

         for( int j = min + 1; j < theArray.length; j++ )
            if (compare.isLessThan(theArray[j], theArray[min]))
               min = j;
         swap( theArray, i, min );
      }

      //// 3. Calculate the elapsed time
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of selectionSort()


   //===   SELECTION SORT   ====================================================
   //===========================================================================



   //===========================================================================
   //===   SHELL SORT   ========================================================

   /**
    * Performs a "shell" sort on theArray passed in. Not implemented yet.
    *
    * @param    theArray is the array of ints to be sorted.
    *
    * @return   Returns the time in milliseconds used to perform the sort.<BR>
    */
   final public static long shellSort( int[] theArray ) {

      long t0 = System.currentTimeMillis();
      long t1 = System.currentTimeMillis();
      return( t1 - t0 );

   }  // end of shellSort()

   //===   SHELL SORT   ========================================================
   //===========================================================================



   //===========================================================================
   //===   TREE SORT   =========================================================

   /*
    * Performs a "tree" sort on theArray passed in.
    *
    * @param    theArray is the array of ints to be sorted.
    *
    * @return   Returns the time in milliseconds used to perform the sort.<BR>
    */
/*
   final public static long treeSort( int[] theArray ) {

      long t0 = System.currentTimeMillis();

      if ( theArray.length > 0 ); {
         BinarySearchTree tree = new BinarySearchTree();
         for( int i = 0; i < theArray.length; i++ )
            tree.add( theArray[ i ] );
         tree.inOrderToArray( theArray );
      }

      long t1 = System.currentTimeMillis();
      return( t1 - t0 );
   }  // end of treeSort()
*/

   //===   TREE SORT   =========================================================
   //===========================================================================



   //===========================================================================
   //===   MAIN   ==============================================================

   public static void main(String[] argv) {

      Random rand    = new Random();
      int    arrSize = Integer.parseInt(argv[0]);

      //// 0. Check num of arguments.
      if (argv.length == 0) {
         System.out.println("java util.Sort [size of array]");
	 System.exit(1);
      }

      //// 1. Create an array with random numbers in it.
      int[] origArray = new int[arrSize];
      int[] array     = new int[arrSize];
      for (int i = 0; i < origArray.length; i++) {
         origArray[i] = rand.nextInt();
      }

      //// 2. Perform different sorts comparing the times.
      for (int j = 0; j < 7; j++) {

         //// 3. Copy the array so we have the same array all the time.
         for (int i = 0; i < origArray.length; i++) {
            array[i] = origArray[i];
         }

         //// 4. Do one of the sorts on the copied array.
         switch (j) {

            case 0: System.out.println("SelectionSort on " + array.length);
                    System.out.println("Elapsed (ms): " + selectionSort(array));
                    Debug.println(array);
                    break;
            case 1: System.out.println("BubbleSort on " + array.length);
                    System.out.println("Elapsed (ms): " + bubbleSort(array));
                    Debug.println(array);
                    break;
            case 2: System.out.println("BidirectionalBubbleSort on " + 
                                        array.length);
                    System.out.println("Elapsed (ms): " + 
                                        bidirBubbleSort(array));
                    Debug.println(array);
                    break;
            case 3: System.out.println("InsertionSort on " + array.length);
                    System.out.println("Elapsed (ms): " + insertionSort(array));
                    Debug.println(array);
                    break;
            case 4: System.out.println("MergeSort on " + array.length);
                    System.out.println("Elapsed (ms): " + mergeSort(array));
                    Debug.println(array);
                    break;
            case 5: System.out.println("HeapSort on " + array.length);
                    System.out.println("Elapsed (ms): " + heapSort(array));
                    Debug.println(array);
                    break;
            case 6: System.out.println("QuickSort on " + array.length);
                    System.out.println("Elapsed (ms): " + quickSort(array));
                    Debug.println(array);
                    break;
         }
         System.out.println();
      }


   } // of main

   //===   MAIN   ==============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/

