//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tuple;

import java.util.List;

/**
 * Convenience class for passing around a List of Tuples.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Mar 06 2003, JH
 */
public class TupleList
    extends Tuple {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    public static String TUPLE_TUPLES = "Tuples";

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Create an empty collection of Tuples.
     */
    public TupleList() {
        super(TUPLE_TUPLES);
        setDynamicSize(true);
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a empty collection of Tuples with one element.
     */
    public TupleList(Tuple tAA) {
        this();
        addTuple(tAA);
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a collection of Tuples with two elements.
     */
    public TupleList(Tuple tAA, Tuple tBB) {
        this();
        addTuple(tAA);
        addTuple(tBB);
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a collection of Tuples with three elements.
     */
    public TupleList(Tuple tAA, Tuple tBB, Tuple tCC) {
        this();
        addTuple(tAA);
        addTuple(tBB);
        addTuple(tCC);
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a collection of Tuples from a List of Tuples.
     */
    public TupleList(List listTuples) {
        this();
        addTuples(listTuples);
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================






    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static void runTestYYY() {
        TupleList tList = new TupleList(Tuple.getTestInstanceAAA(),
                                        Tuple.getTestInstanceBBB(),
                                        Tuple.getTestInstanceCCC());
        System.out.println(tList);
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) {
        runTestYYY();
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  tupleation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
