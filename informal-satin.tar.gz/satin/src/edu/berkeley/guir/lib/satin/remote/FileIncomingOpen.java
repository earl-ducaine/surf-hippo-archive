/*
 * FileIncomingOpen.java
 * Created May 2002
 */

package edu.berkeley.guir.lib.satin.remote;

import java.io.*;

/**
 * @author  Katie Everitt, Robert Lee
 * @version 1.4
*/
public class FileIncomingOpen extends Thread {
   private InOutMgr           m_manager      = null;
   private BufferedReader     m_in           = null;   
   private String             m_incomingFile = "";
       
   
   public FileIncomingOpen(InOutMgr manager, String filename) {
      m_manager = manager;      
      m_incomingFile= filename;
   //   start();
   }
   
   private void openFile() {
		try {
		   m_in = new BufferedReader(new FileReader(m_incomingFile));
		} catch (IOException e){
     		e.printStackTrace();
  		}
   }
   
   private void closeFile() {
		try {
         m_in.close();
   	} catch (IOException e){
      	e.printStackTrace();
   	}
   }
   
   public void run() {
      openFile();      
      System.out.println("SaveIncomingDisk: file opened" );  //ftpo    
      try {
         String XMLCommand = m_in.readLine();
//         System.out.println(XMLCommand); // ftpo
         while(XMLCommand!=null){
            //m_q.handleRemoteEvent(XMLCommand);            
            m_manager.handleEvent(new IOEvent(XMLCommand));
            XMLCommand = m_in.readLine();            
         }
      }catch(Exception e){
         e.printStackTrace();   
      }
      closeFile();
   }
}