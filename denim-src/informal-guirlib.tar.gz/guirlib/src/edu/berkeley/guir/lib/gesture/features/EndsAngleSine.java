package edu.berkeley.guir.lib.gesture.features;

import java.lang.Math;
import java.awt.Polygon;
import edu.berkeley.guir.lib.gesture.*;

/**
 * Sine of the angle between the first and last points
 */
public class EndsAngleSine extends Feature {
  public double minValue = -1;
  public double maxValue = 1;
  double rolloff = (4*4);
  double EPSILON = 1e-4;
  
  public EndsAngleSine()
  {
    super();
  }

  public EndsAngleSine(Gesture g)
  {
    super(g);
  }

  protected void computeValue()
  {
    Polygon p = gesture.getPointsRef();

    if (p.npoints < 3) {
      value = 0;
    }
    else {
      double x0 = p.xpoints[0];
      double y0 = p.ypoints[0];
      double xn = p.xpoints[p.npoints-1];
      double yn = p.ypoints[p.npoints-1];

      double hypot = Math.sqrt((xn-x0)*(xn-x0) + (yn-y0)*(yn-y0));
      double factor = hypot * hypot / rolloff;
      if (factor > 1)
	factor = 1;
      factor = (hypot > EPSILON) ? factor/hypot : 0;
      
      value = (yn - y0) * factor;
    }
    valueOk = true;
  }

  public double getMinValue()
  {
    return minValue;
  }
  
  public double getMaxValue()
  {
    return maxValue;
  }

  public String getName()
  {
    return new String("sine of angle between first and last points");
  }

  // could try rotation here if this doesn't work well
  public void scale(double factor)
  {
    gesture.normalize();
    TimedPolygon points = gesture.getPoints();
    double y0 = points.ypoints[0];
    double yn = points.ypoints[points.npoints-1];

    boolean scaley = ((factor-1)*(yn-y0)) > 0;
    double f = (factor>=1) ? factor : (1.0/factor);
    
    for (int i = 0; i < points.npoints; i++) {
      if (scaley) {
	points.ypoints[i] *= f;
      }
      else {
	points.xpoints[i] *= f;
      }
    }

    gesture.setPoints(points);
  }
}
