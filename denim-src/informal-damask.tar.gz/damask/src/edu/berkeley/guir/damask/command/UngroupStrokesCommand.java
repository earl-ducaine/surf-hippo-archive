package edu.berkeley.guir.damask.command;

import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that removes a stroke from a piece of content.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-14-2003 James Lin
 *                               Created RemoveStrokeCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-14-2003
 */
public class UngroupStrokesCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final Content content;
   private Dialog dialog;
   private final Map/*<PageRegion, Integer>*/ contentPositions =
      new HashMap/*<PageRegion, Integer>*/();
   private final Map/*<DeviceType, Integer>*/ scaleX =
      new HashMap/*<DeviceType, Double>*/();
   private final Map/*<DeviceType, Integer>*/ scaleY =
      new HashMap/*<DeviceType, Double>*/();
   private final List/*<Content>*/ newContents = new ArrayList/*<Content>*/();
   
   private final Set/*<PatternInstance>*/ contentPatternInstances =
      new HashSet/*<PatternInstance>*/();

   /**
    * Constructs the command.
    *  
    * @param content the content to remove the stroke from
    * @param stroke the stroke to remove
    */      
   public UngroupStrokesCommand(final Content content) {
      this.content = content;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Ungroup strokes in " + content;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      dialog = content.getDialog();
      
      final Rectangle2D contentFullBounds =
         content.getFullSizeBounds(Content.INK);
      
      // Store the position and scaling factor of the original content,
      // in each page region
      for (Iterator j = content.getDeviceTypesVisibleTo().iterator();
           j.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)j.next();
         final PageRegion aRegion = content.getPageRegion(aDeviceType);
         contentPositions.put(
            aRegion, new Integer(aRegion.getControls().indexOf(content)));
         final Rectangle2D bounds = content.getBounds(aDeviceType);
         scaleX.put(
            aDeviceType,
            new Double(bounds.getWidth() / contentFullBounds.getWidth()));
         scaleY.put(
            aDeviceType,
            new Double(bounds.getHeight() / contentFullBounds.getHeight()));
      }
      
      // Create a new piece of content from each stroke in the original content
      final DeviceType deviceType = content.getDeviceType();
      for (Iterator i = content.getStrokes().iterator(); i.hasNext(); ) {
         final GeneralPath stroke = (GeneralPath)i.next();
         final GeneralPath newStroke = (GeneralPath)stroke.clone();
         final Rectangle2D strokeFullBounds = stroke.getBounds2D();

         // Make the upper left-hand corner of the new stroke (0, 0) in its
         // local coordinate system
         newStroke.transform(
            AffineTransform.getTranslateInstance(
               -strokeFullBounds.getX(), -strokeFullBounds.getY()));
         newStroke.transform(
            AffineTransform.getTranslateInstance(
               -contentFullBounds.getX(), -contentFullBounds.getY()));
         
         final Content newContent = new Content(deviceType, newStroke);
         for (Iterator j = deviceType.getSpecificDeviceTypes().iterator();
              j.hasNext(); ) {
            final DeviceType aDeviceType = (DeviceType)j.next();
            
            // Set the bounds so that the new content is scaled by the same
            // factor as the original content
            final double scaleXForADeviceType =
               ((Double)scaleX.get(aDeviceType)).doubleValue();
            final double scaledRelativeX =
               (strokeFullBounds.getX() - contentFullBounds.getX()) *
               scaleXForADeviceType;
            
            final double scaleYForADeviceType =
               ((Double)scaleY.get(aDeviceType)).doubleValue();
            final double scaledRelativeY =
               (strokeFullBounds.getY() - contentFullBounds.getY()) *
               scaleYForADeviceType;
            
            newContent.setBounds(
               aDeviceType,
               new Rectangle2D.Double(
                  0, 0,
                  strokeFullBounds.getWidth() * scaleXForADeviceType,
                  strokeFullBounds.getHeight() * scaleYForADeviceType));
            
            // Set the transform so that the new content has the same location
            // as the original stroke, keeping in mind that (0, 0) is the
            // upper left-hand corner in the new stroke's local coordinates.
            final Rectangle2D contentBoundsInParentCoords =
               content.getBoundsInParentCoords(aDeviceType);
            
            newContent.setTransform(
               aDeviceType,
               AffineTransform.getTranslateInstance(
                  scaledRelativeX + contentBoundsInParentCoords.getX(),
                  scaledRelativeY + contentBoundsInParentCoords.getY()));
         }
         newContents.add(newContent);
      }
      redo();
   }
   
   // Overrides method in superclass.   
   public void redo() {
      contentPatternInstances.clear();
      contentPatternInstances.addAll(content.getPatternInstanceMemberships());
      
      // Put the new pieces of content in the same positions and page regions
      // as the original content
      for (ListIterator i = newContents.listIterator(newContents.size());
         i.hasPrevious(); ) {
         final Content newContent = (Content)i.previous();
         dialog.addControl(contentPositions, newContent);
         for (Iterator j = contentPatternInstances.iterator(); j.hasNext(); ) {
            final PatternInstance instance = (PatternInstance)j.next();
            instance.add(newContent);
         }
      }
      dialog.removeControl(content);
      for (Iterator j = contentPatternInstances.iterator(); j.hasNext(); ) {
         final PatternInstance instance = (PatternInstance)j.next();
         instance.remove(content);
      }
   }

   // Overrides method in superclass.   
   public void undo() {
      for (Iterator i = newContents.iterator(); i.hasNext();) {
         final Content newContent = (Content) i.next();
         dialog.removeControl(newContent);
         for (Iterator j = contentPatternInstances.iterator(); j.hasNext(); ) {
            final PatternInstance instance = (PatternInstance)j.next();
            instance.remove(newContent);
         }
      }
      dialog.addControl(contentPositions, content);
      for (Iterator j = contentPatternInstances.iterator(); j.hasNext(); ) {
         final PatternInstance instance = (PatternInstance)j.next();
         instance.add(content);
      }
   }
}
