package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.util.List;
import edu.berkeley.guir.lib.gesture.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import javax.swing.border.Border;

public class MisrecognitionNotice extends DefaultNotice {
  private List misrecogGestures;
  private MainFrame mainFrame;
  private ActionListener showExamplesListener = null;
  
  public MisrecognitionNotice(MainFrame mf, List misrecognizedGestures)
  {
    mainFrame = mf;
    misrecogGestures = misrecognizedGestures;
    showExamplesListener = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	ShadowGestureContainer container =
	new ShadowGestureContainer(misrecogGestures);
	container.setName("Misrecognized gestures");
	JScrollPane scrollPane = new JScrollPane();
	GestureContainerPanel panel =
	new MisrecogGestureContainerPanel(container, scrollPane);
	GInternalFrame iFrame = GInternalFrame.
	makeInternalFrame(container, panel, scrollPane);
	mainFrame.getDesktop().showFrame(iFrame);
      }
    };
  }

  public boolean hasExpired()
  {
    // todo: fix this
    return misrecogGestures.size() == 0;
  }

  protected void displayImpl(SummaryLog log)
  {
    //System.out.println("MN: display: " + misrecogGestures.size());
    if (!hasExpired()) {
      log.append("There are " + misrecogGestures.size() + " ");
      log.appendLink("misrecognized gestures",
		     showExamplesListener,
		     "Make a new view for the misrecognized gestures");
      log.append(". This probably indicates either mistakes in entering the gestures, or that the gesture categories are too similar to each other.");
    }
  }

  protected void displaySummaryImpl(SummaryLog log)
  {
    log.appendLink(misrecogGestures.size() + " misrecognized gestures",
		   showExamplesListener,
		   "Make a new view for the misrecognized gestures");
  }
  
  public String getName()
  {
    return "Misrecognized gestures";
  }

  public List getObjectList()
  {
    return misrecogGestures;
  }

  public String getReferenceTag()
  {
    return "Misrecognition";
  }
  
  private HowToPanel howToPanel = null;
  public HowToPanel getHowToPanel()
  {
    if (howToPanel == null) {
      howToPanel = new MisrecognitionExplanationPanel();
    }
    return howToPanel;
  }

  protected static class MisrecogGestureContainerPanel
    extends GestureContainerPanel {
    protected static final Border BORDER =
      BorderFactory.createEtchedBorder();
    public MisrecogGestureContainerPanel(ShadowGestureContainer container,
					 JScrollPane scroller)
    {
      super(container, scroller);
    }

    protected void addGestureObject(GestureObject gestureObj,
				    JScrollPane scrollPane, int index)
    {
      Gesture gesture = (Gesture) gestureObj;
      GestureObjectPanel gesturePanel = (GestureObjectPanel)
	DisplayFactory.create(gestureObj, scrollPane);
      JLabel label = new JLabel(gesture.getParent().getName());
      label.setForeground(Color.green.darker().darker());
      gesturePanel.add(label, BorderLayout.NORTH);
      gesturePanel.setBorder(BORDER);
      this.add(gesturePanel, index);
    }

    public boolean isCommandValid(int id)
    {
      boolean valid;
      switch (id) {
      case PASTE_ACTION:
      case ENABLE_ACTION:
      case DISABLE_ACTION:
	valid = false;
	break;
      default:
	valid = super.isCommandValid(id);
	break;
      }
      return valid;
    }
  }

  public class MisrecognitionExplanationPanel extends HowToPanel {
    SummaryLog log = new SummaryLog(null);
    
    public MisrecognitionExplanationPanel() {
      super();
      buildUI();
    }

    protected void buildUI() {
      add(log, BorderLayout.CENTER);
      setPreferredSize(new Dimension(300, 300));
      log.append("To fix misrecognition problems, first look over the ");
      log.appendLink("examples", showExamplesListener,
		     "Make a new view of the examples");
      log.append(" and see if any of them were drawn the way they were by mistake.  If they were, you should delete them and probably redraw them.\n");
      log.append("If there are no mistaken examples, or if fixing mistaken ones does not help, then it may be that the two gestures are too similar.  You may want to make them more different.");
    }
  }
}
