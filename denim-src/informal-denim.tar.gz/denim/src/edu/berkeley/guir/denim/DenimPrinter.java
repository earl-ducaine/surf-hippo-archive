//// See bottom of source code for software license

package edu.berkeley.guir.denim;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.image.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.objects.*;
import java.awt.*;
import java.awt.print.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Nov 14, 2003 by YL
 * </PRE>
 * 
 * 		 - Rebuilt DenimPrinter class
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

class DenimPrinter extends JDialog implements Printable, DenimConstants, Pageable {
	
   /**
    * Interface elements
    */
	private JButton mRegionButton = null;
	private ButtonGroup mGroup = null;
	private JRadioButton[] mRadioButtons = null;
	
	/**
	 * printing  
	 */
    private static PrinterJob mPrintJob = PrinterJob.getPrinterJob();
    private static PageFormat mPFormat = mPrintJob.defaultPage();
   
    public boolean shouldPrint = false;
   
    private DenimSheet mSheet = null;

	BufferedImage[] mAllBuffer = null;
	BufferedImage[] mSelectedBuffer = null;
	BufferedImage[]   mRegionBuffer = null;
	Rectangle2D mSelectedRegion = null;
	
	Sheet temporarySheet;
	int mPageNumber = 0;
	
	private static final int all = 0;
	private static final int region = 1;
	private static final int selected = 2;
	private int printTask = all;
	 
	/**
	 * A listener that swallows all mouse events.
	 */
	class EmptyListener extends MouseInputAdapter {
	}
	
	/**
	 * A component that swallows all mouse events.
	 */
	class EventSwallowerGlassPane extends JComponent {
		EventSwallowerGlassPane() {
			EmptyListener emptyListener = new EmptyListener();
			this.addMouseListener(emptyListener);
			this.addMouseMotionListener(emptyListener);
		}
	}
   
	/**
	 * added a thread to print images in background
	 * to keep the responsiveness of interface
	 */ 
   
	private class BackgroundPrinting extends Thread {
		public void run() {
			DenimWindow win = (DenimWindow)SwingUtilities.getRoot(mSheet);
			win.setBusy(true);
			printToBuffer();

			try 
			{
				mPrintJob.print();
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
	
			win.setBusy(false);         
		}
	}
   
	/**
	 * I added a thread to convert pages to image in background
	 * to keep the responsiveness of interface
	 */ 
   
	private class BackgroundPreview extends Thread {
		public void run() {
			DenimWindow win = (DenimWindow)SwingUtilities.getRoot(mSheet);
			win.setBusy(true);
			setPrinterDialogEnabled(false);
			preview();
			setPrinterDialogEnabled(true);
			win.setBusy(false);         
		}
	}


	public DenimPrinter(final DenimSheet sheet) {
		
		super((Frame)SwingUtilities.getRoot(sheet), "Print", true);

		temporarySheet = new Sheet();
		
		mSheet = sheet;
		mPrintJob.setPageable(this);
		
		ZoomSlider slider = sheet.getDenimUI().getZoomSlider();
		slider.setAnimateZoom(false);
		slider.setValue(50); // Storyboard value
		slider.setAnimateZoom(true);
		
		this.setGlassPane(new EventSwallowerGlassPane());

		// centering the window
		Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
		this.setBounds((int)(size.getWidth()-430)/2, (int)(size.getHeight()-160)/2, 430, 160);
		this.setResizable(false);
				

		//////////////////////////////////////////////////////////////////////////////////
		// Radio Button Start
		
		JButton printButton = new JButton("Print...");
		JButton previewButton = new JButton("Preview...");
		JButton propButton = new JButton("Page Setup...");
		JButton cancelButton = new JButton("Cancel");

		mRadioButtons = new JRadioButton[3];

 		mGroup = new ButtonGroup();

		mRadioButtons[0] = new JRadioButton("All web pages");
		mRadioButtons[0].setActionCommand("all");
		mRadioButtons[0].setSelected(true);
      
		mRadioButtons[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				mRegionButton.setEnabled(false);
				printTask = all;
			}
		});

		mRadioButtons[1] = new JRadioButton("Selected web pages");
		mRadioButtons[1].setActionCommand("selected");

		mRadioButtons[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				mRegionButton.setEnabled(false);
				printTask = selected;
			}
		});
		
		mRadioButtons[2] = new JRadioButton("Selected region of site");
		mRadioButtons[2].setActionCommand("region");

		mRadioButtons[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				if(((JRadioButton)evt.getSource()).isSelected())
				{
					mRegionButton.setEnabled(true);
					if(DenimPrinter.this.mSelectedRegion==null)
					{
						CanvasChooser topiary = new CanvasChooser(sheet, DenimPrinter.this);
						topiary.setVisible(true);						 
					}
				}
				printTask = region;
			}
		});
		
		mRegionButton = new JButton("Choose a region");
		mRegionButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				CanvasChooser topiary = new CanvasChooser(sheet, DenimPrinter.this);
				topiary.setVisible(true); 	
			}
		});


		mGroup.add(mRadioButtons[0]);
		mGroup.add(mRadioButtons[1]);
		mGroup.add(mRadioButtons[2]);


		// Radio Button End
		//////////////////////////////////////////////////////////////////////////////////


		printButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DenimPrinter.this.setVisible(false);
				shouldPrint = true;
			}
		});
         
		previewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BackgroundPreview previewing = new BackgroundPreview();
				previewing.start();
			}
		});

 
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DenimPrinter.this.setVisible(false);
				shouldPrint = false;
			}
		});

		propButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mPFormat = mPrintJob.pageDialog(mPFormat);
				clearBuffer();
			}
		});

		JPanel radioPanel = new JPanel();
		radioPanel.setLayout(new BoxLayout(radioPanel, BoxLayout.Y_AXIS));
		radioPanel.add(mRadioButtons[0]);
		radioPanel.add(mRadioButtons[2]);
		radioPanel.add(mRadioButtons[1]);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(printButton);
		buttonPanel.add(previewButton);
		buttonPanel.add(propButton);
		buttonPanel.add(cancelButton);

		JPanel center = new JPanel(new FlowLayout(FlowLayout.LEADING));
		center.add(radioPanel);
		center.add(this.mRegionButton);
		center.setBorder(BorderFactory.createEtchedBorder());
		this.mRegionButton.setEnabled(false);
		this.getContentPane().add(center, BorderLayout.CENTER);

		this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
	}

	//------------------------------------------------------------------------------------
	
	/**
	 * preview 
	 */   
	
	private void preview() {
		printToBuffer();
		PreviewDialog view = new PreviewDialog(this);
		view.setVisible(true);
	}
	
	//------------------------------------------------------------------------------------

	/**
	 * print design to buffer
	 */
	private void printToBuffer() {
		DenimWindow win = (DenimWindow)SwingUtilities.getRoot(mSheet);
		win.setBusy(true);
		Iterator iter;
		if (printTask==selected&&mSelectedBuffer==null) {
			iter = cmdsubsys.getSelected();
			// If nothing is selected, print the object under the last
			// cursor position.
			if (!(iter.hasNext())) {
				cmdqueue.doCommand(new SelectShallowCommand(mSheet,
												  cmdsubsys.getAbsoluteLastXLocation(),
												  cmdsubsys.getAbsoluteLastYLocation()));
				iter = cmdsubsys.getSelected();
			}
			initPrintBuffer(iter);
		} 
		else if (printTask==all&&mAllBuffer==null) 
		{
			iter = mSheet.getForwardIterator();
			initPrintBuffer(iter);
		} 
		else if (printTask==region&&this.mRegionBuffer==null) 
		{ 
			this.mRegionBuffer = new BufferedImage[1];
			this.mRegionBuffer[0] = SatinImageLib.toBufferedImage(
								 this.getRenderableSize(),
								 mSheet, mSelectedRegion, false);
			mPageNumber = 1;
		}   	
		
		win.setBusy(false);
	}

	//------------------------------------------------------------------------------------
	
	public BufferedImage[] getPrintBuffer() {
		String selection = mGroup.getSelection().getActionCommand();
		
		if (printTask==selected) {
			return mSelectedBuffer;
		} 
		else if (printTask==all) 
		{
			return mAllBuffer;
		} 
		else
		{
			return mRegionBuffer;
		}
	}
	
	//------------------------------------------------------------------------------------
	
	public void clearBuffer() {
		mAllBuffer=null;
		mSelectedBuffer = null;
		mRegionBuffer = null;
		System.gc();
	}
	//------------------------------------------------------------------------------------
   
	/**
	 * init print buffer
	 */
   
	private void initPrintBuffer(Iterator iter) {
		LinkedList panelList = new LinkedList();   	
		DenimPanel panel;
		Object obj;
		if (printTask==selected)
		{
			mPageNumber = cmdsubsys.getSelectedCollection().numElements();
			if(mAllBuffer!=null) 
			{
				int i = 0;
				mSelectedBuffer = new BufferedImage[mPageNumber];
				while(iter.hasNext()&&i<mSelectedBuffer.length)
				{
					panel = (DenimPanel) iter.next();
					mSelectedBuffer[i] = mAllBuffer[panel.getSheet().indexOf(panel)];
					i++;
				}
				return;
			}
		}
		
		ArrayList list = new ArrayList();
		
		while (iter.hasNext()) {
			obj = iter.next();

			// Step up the parent hierarchy until we reach DenimPanels.
			while (!(obj instanceof DenimPanel) && obj != null) {
				obj = ((GraphicalObject) obj).getParentGroup();
			}

			if (obj instanceof DenimPanel) {
				panel = (DenimPanel) obj;
				if (!panelList.contains(panel)) {
					panelList.add(panel);
					BufferedImage image = toBufferedImage((DenimPanel) obj);
					list.add(image);
				}
			}
		}
		
		BufferedImage[] buf;
		mPageNumber = list.size();
		buf = new BufferedImage[mPageNumber];
		if (printTask==all) 
		{
			mAllBuffer = buf;
		}
		else
		{
			mSelectedBuffer = buf;
		}
		
		Iterator it = list.iterator();
		int c = 0;
		while(it.hasNext())
		{
			buf[c] = (BufferedImage)it.next();
			c++;
		}
		
	}

	//------------------------------------------------------------------------------------

	/** Converts DenimPanels into BufferedImages so that we can print them.
	 */
	private BufferedImage toBufferedImage (DenimPanel panel) {
		//BufferedImage page = SatinImageLib.toImage(panel);
		DenimPanel renderedPanel = (DenimPanel) panel.deepClone();

		renderedPanel.makeVisibleAtUpperLeftIn(temporarySheet);
		renderedPanel.setUniqueID(panel.getUniqueID());
		renderedPanel.setTextBackgroundsTransparent();
		Style style = renderedPanel.getStyle();
		style.setFillColor(Color.white);
		renderedPanel.setStyle(style);
		renderedPanel.getSketch().getStyleRef().setDrawColor(Color.white);
		renderedPanel.getSketch().getStyleRef().setFillColor(Color.white);
		renderedPanel.getLabel().getStyleRef().setDrawColor(Color.white);
		renderedPanel.getLabel().getStyleRef().setFillColor(Color.white);

		BufferedImage img = SatinImageLib.toImage(renderedPanel);
	
		renderedPanel.delete();
		temporarySheet.remove(renderedPanel);
		
		return img;
	}

	//--------------------------------------------------------------------------------------
	
	/** Performs the actual printing of BufferedImage representations of the
	 *  DenimSheets.  A bit of a hack, since we call it once for every page
	 *  in the iterator, but since page numbers don't make much sense here,
	 *  it's adequate.
	 */
	public int print(Graphics g, PageFormat format, int pageIndex)
	{
		if (pageIndex<0||pageIndex>=mPageNumber) {
			return NO_SUCH_PAGE;
		}
      
		Graphics2D g2d = (Graphics2D)g;
		g2d.translate(format.getImageableX(),format.getImageableY());		
		if(printTask==region)
		{
			SatinImageLib.renderRegion(g2d, this.getRenderableSize(),mSheet, mSelectedRegion);
		}
		else if(printTask==all)
		{
			g2d.drawImage(mAllBuffer[pageIndex], new AffineTransform(1f,0f,0f,1f,0,0), null);
		}
		else
		{
			g2d.drawImage(mSelectedBuffer[pageIndex], new AffineTransform(1f,0f,0f,1f,0,0), null);
		}
			
		return Printable.PAGE_EXISTS;
	}
   
	//--------------------------------------------------------------------------------------
   
	public Dimension getRenderableSize() {
		double w = mPFormat.getImageableWidth();//(ideal_w - we);
		double h = mPFormat.getImageableHeight();//(ideal_h - he);
		return new Dimension((int)w, (int)h);
	}

	//-----------------------------------------------------------------

	public void setPrinterDialogEnabled(boolean flag) {
		if(flag)
		{
			this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
		else
		{
			setCursor(new Cursor(Cursor.WAIT_CURSOR));
			this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		}
		getGlassPane().setVisible(!flag);
	}
/*	
	public static void disableDoubleBuffering(Component c) {
	  RepaintManager currentManager = RepaintManager.currentManager(c);
	  currentManager.setDoubleBufferingEnabled(false);
	}

	public static void enableDoubleBuffering(Component c) {
	  RepaintManager currentManager = RepaintManager.currentManager(c);
	  currentManager.setDoubleBufferingEnabled(true);
	}
*/
    public void doPrint() {
		if(DenimPrinter.mPrintJob.printDialog())
		{
			BackgroundPrinting printDaemon = new BackgroundPrinting();
			printDaemon.start();
		}
    }
    
	public int getNumberOfPages() {
		return mPageNumber;
	}

	public PageFormat getPageFormat(int pageIndex) {
		return mPFormat;
	}
	
	public Printable getPrintable(int pageIndex) {
		return this;		 
	}
}


//==============================================================================

/*
Copyright (c) 2003 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User 
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/