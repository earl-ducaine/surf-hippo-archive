//// See bottom of file for software license
package edu.berkeley.guir.lib.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * This Map contains the relative precision values of
 * various fields. This is useful for seeing which field
 * is more precise than another. For example, a person
 * might allow a query on their current city. So by default,
 * this means they also allow the region and country data as well.
 *
 * <P>
 * Each field is associated with an int value, with higher
 * values representing coarser-grained data. For example,
 * 'CountryName' has a value of 120, while 'lat' and 'lon' have
 * values of 20.
 *
 * <P>
 * I used BASIC-like numbering for future extensibility.
 *
 * <P>
 * Sample usage:
 * <PRE>
 *   PrecisionMap map = new PrecisionMap();
 *   map.addValue("CountryName", 120);
 *   map.addValue("CountryCode", 120);
 *   map.addValue("RegionName",  100);
 *   map.addValue("CityName",     80);
 *   map.addValue("ZipCode",      60);
 *   map.addValue("PlaceName",    40);
 *   
 *   System.out.println(map.isCoarserGrained("CountryName", "RegionName"));  //t
 *   System.out.println(map.isCoarserGrained("CountryName", "CountryCode")); //t
 *   System.out.println(map.isCoarserGrained("CityName",    "CountryName")); //f
 *   
 *   System.out.println(map.isFinerGrained("CountryName", "CountryCode"));   //t
 *   System.out.println(map.isFinerGrained("PlaceName",   "CountryName"));   //t
 *   System.out.println(map.isFinerGrained("CityName",    "CountryName"));   //t
 * </PRE>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 13 2004
 */
public class PrecisionMap {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    Map mapPrecisions = new CaseInsensitiveMap(new HashMap());

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    /**
     * Get the field names as a Set.
     */
    public Set asSet() {
        return (mapPrecisions.keySet());
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the field names as a String array.
     */
    public String[] asArray() {
        return (String[]) (asSet().toArray(new String[0]));
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================




    //==========================================================================
    //===   PRECISION METHODS   ================================================

    /**
     * Add a single precision value.
     *
     * @param strFieldName is the arbitrary name of the field.
     * @param val          is an arbitrary int value, higher values are
     *                     coarser-grained
     */
    public void addValue(String strFieldName, int val) {
        mapPrecisions.put(strFieldName, new Integer(val));
    } // of method

    //----------------------------------------------------------------

    /**
     * See if "strAA is less precise or same precision than strBB".
     * For example:
     * <PRE>
     * isCoarserGrained("CountryName", "RegionName");       // true
     * isCoarserGrained("CountryName", "CountryCode");      // same level, true
     * </PRE>
     */
    public boolean isCoarserGrained(String strAA, String strBB) {
        int valAA = getPrecision(strAA);
        int valBB = getPrecision(strBB);
        return (valAA >= valBB);
    } // of method

    /**
     * See if "strAA is more precise or same precision than strBB".
     * @see #isCoarserGrained(String,String)
     */
    public boolean isFinerGrained(String strAA, String strBB) {
        int valAA = getPrecision(strAA);
        int valBB = getPrecision(strBB);
        return (valAA <= valBB);
    } // of method

    //--------------------

    /**
     * Get the relative precision value. This is an arbitrary int
     * value, with higher values meaning less precise / coarser grained.
     */
    public int getPrecision(String str) {
        //// 1. Get the associated Integer value.
        Integer value = (Integer) mapPrecisions.get(str);
        if (value == null) {
            return (Integer.MAX_VALUE);
        }
        else {
            return (value.intValue());
        }
    } // of method

    //===   PRECISION METHODS   ================================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        return (mapPrecisions.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static void runTestAAA() {
        PrecisionMap map = new PrecisionMap();
        map.addValue("CountryName", 120);
        map.addValue("CountryCode", 120);
        map.addValue("RegionName",  100);
        map.addValue("CityName",     80);
        map.addValue("ZipCode",      60);
        map.addValue("PlaceName",    40);

        System.out.println(map.isCoarserGrained("CountryName", "RegionName"));
        System.out.println(map.isCoarserGrained("CountryName", "CountryCode"));
        System.out.println(map.isCoarserGrained("CityName",    "CountryName"));

        System.out.println(map.isFinerGrained("CountryName", "CountryCode"));
        System.out.println(map.isFinerGrained("PlaceName",   "CountryName"));
        System.out.println(map.isFinerGrained("CityName",    "CountryName"));
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestAAA();
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
