/* True/False symbol definitions  12-APR-88 JCW */

#ifndef TRUE
#define TRUE	1
#define FALSE	0
#endif
