//// See bottom of source code for software license.
package edu.berkeley.guir.lib.debugging;

import edu.berkeley.guir.lib.io.IOLib;
import java.io.File;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.zip.ZipFile;

/**
 * Find where a class is being loaded in from.
 * Also check if one class is being shadowed by another.
 *
 * <P>
 * Here is an example of the introspection debugging:
 * <IMG SRC="{@docRoot}/img/debug-introspect.gif">
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Jan 01 2003 JIH
 */
public class FindInClassPath {

    //==========================================================================
    //===   CLASS METHODS   ====================================================

    /**
     * Parse a class name into an array of Strings.
     * For example, "edu.berkeley.guir.lib.debugging.FindInClassPath"
     * becomes {"edu", "berkeley", "guir", "lib", "debugging", 
     * "FindInClassPath.class"}. Adds ".class" to the last part.
     * <P>
     * Useful for traversing directory structure.
     */
    private static String[] parseClassName(String strClassName) {
        StringTokenizer strtok   = new StringTokenizer(strClassName, ".");
        List            listPath = new LinkedList();
        String          token;

        //// 1. Parse out all of the tokens.
        while (strtok.hasMoreTokens()) {
            token = strtok.nextToken();
            if (strtok.hasMoreTokens() == false) {
                token += ".class";
            }
            listPath.add(token);
        }

        //// 2. Return as a String array.
        return ((String[]) listPath.toArray(new String[0]));
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert a class name like
     * "edu.berkeley.guir.lib.debugging.FindInClassPath" to the directory
     * where it should be located, in this case
     * "edu/berkeley/guir/lib/debugging/FindInClassPath.class".
     */
    private static String toClassFileName(String strClassName) {
        String[]     strParsedClassName = parseClassName(strClassName);
        StringBuffer strbuf             = new StringBuffer();
        for (int i = 0; i < strParsedClassName.length; i++) {
            if (i > 0) {
                strbuf.append("/");
            }
            strbuf.append(strParsedClassName[i]);
        }

        return (strbuf.toString());
    } // of method

    //===   CLASS METHODS   ====================================================
    //==========================================================================




    //==========================================================================
    //===   CLASSPATH METHODS   ================================================

    /**
     * Parse the classpath into a List.
     */
    public static List getClassPath() {
        String          strClassPath = System.getProperty("java.class.path");
        List            listPaths    = new LinkedList();
        StringTokenizer strtok       = new StringTokenizer(strClassPath, ";");
        String          strPath;

        //// 1. Parse the classpath.
        while (strtok.hasMoreTokens() == true) {
            strPath = strtok.nextToken();
            listPaths.add(strPath);
        }

        //// 2. Return.
        return (listPaths);
    } // of method

    //----------------------------------------------------------------

    /**
     * Check the current classpath for the specified class.
     */
    public static List checkClassPath(String strClassName) {
        return (checkClassPath(getClassPath(), strClassName));
    } // of method


    /**
     * Check if the specified class is in the specified classpaths.
     *
     * @param listPaths is the parsed Classpath.
     * @param strClassName is the class we want to find.
     * @return a List of classpaths where the class can be found
     */
    private static List checkClassPath(List listPaths, String strClassName) {
        //// 1. Parse the class name.
        String strClassFileName = toClassFileName(strClassName);

        //// 2. Check each class path.
        Iterator it            = listPaths.iterator();
        List     listGoodPaths = new LinkedList();     // paths class was found
        String   strPath;

        //// Debugging
        System.out.println("Searching for " + strClassName + 
                           " in same order as classpath");

        while (it.hasNext()) {
            strPath = (String) it.next();
            if (checkClassPath(strPath, strClassFileName) == true) {
                listGoodPaths.add(strPath);
            }
        }

        //// 3. Return.
        return (listGoodPaths);
    } // of method

    //----------------------------------------------------------------

    /**
     * Check the current classpath for the specified class.
     */
    public static List checkClassPath(Class cl) {
        return (checkClassPath(getClassPath(), cl.getName()));
    } // of method


    /**
     * Check if the specified class is in the specified classpaths.
     *
     * @param listPaths is the parsed ClassPath.
     * @param cl        is the class we want to find.
     * @return a List of classpaths where the class can be found
     */
    private static List checkClassPath(List listPaths, Class cl) {
        return (checkClassPath(getClassPath(), cl.getName()));
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the short class file name. For example, "java.lang.Object"
     * becomes "Object"
     */
    private static String chop(String strClassFileName) {
        int    index                 = strClassFileName.lastIndexOf(".");
        return (strClassFileName.substring(index + 1));
    } // of method

    //----------------------------------------------------------------

    /**
     * See if the specified classname can be found in the specified path.
     * @param strPath is the name of the directory or zip or jar file.
     * @param strClassFileName is the class to lookup, see toClassFileName().
     */
    private static boolean checkClassPath(String strPath, 
                                          String strClassFileName) {
        //// Debugging
        System.out.println("   Searching " + strPath);

        //// 1.1. Handle as a zip or jar file.
        if (strPath.endsWith(".zip") || strPath.endsWith(".jar")) {
            try {
                ZipFile     zipfile = new ZipFile(strPath);
                Enumeration en      = zipfile.entries();

                //// 1.1.1. See if strClassFileName is one of the entries.
                ////        If so, return true.
                while (en.hasMoreElements()) {
                    String str = en.nextElement().toString();
                    if (str.endsWith(strClassFileName)) {
                        System.out.println("      " + str);
                        return (true);
                    }
                }
            }
            catch (Exception e) {
                // error reading zip file, ignore
                e.printStackTrace();
            }
            return (false);

        }
        //// 1.2. Handle as a directory.
        ////      Add the path and the class name together
        else {
            //// 1.2.1. First make sure it ends with the file separator.
            if (strPath.endsWith(File.separator) == false) {
                strPath += File.separator;
            }

            //// 1.2.2. Make the file separators uniform.
            strPath  = strPath.replaceAll("\\\\", "/");
            strPath += strClassFileName;

            //// 1.2.3. See if the file exists. If so, return true.
            File f = new File(strPath);
            if (f.exists() == true) {
                System.out.println("      " + f.toString());
                return (true);
            }

            //// 1.2.5. Otherwise, traverse the entire directory, and
            ////        try to match.
            File[]  files     = IOLib.getAllFiles(new File(strPath));
            boolean flagFound = false;
            for (int i = 0; i < files.length; i++) {
                if (files[i].toString().endsWith(strPath) == true) {
                    System.out.println("      " + files[i].toString());
                    flagFound = true;
                }
            }
            return (flagFound);
        }
    } // of method

    //===   CLASSPATH METHODS   ================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static void printUsage() {
        System.out.println();
        System.out.println("Find where in the classpath a class is being loaded");
        System.out.println("Usage:");
        System.out.println("   java " + FindInClassPath.class.getName() + " [class]");
        System.out.println();
        System.out.println("Example:");
        System.out.println("   java " + FindInClassPath.class.getName() + " java.lang.Object");
        System.out.println("   java " + FindInClassPath.class.getName() + " Object");


    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) {
        //// 1. Check the argument.
        if (argv.length <= 0) {
            printUsage();
            System.exit(0);
        }

        //// 2. Grab the paths.
        List listPaths = checkClassPath(argv[0]);

        //// 3. Print our results.
        System.out.println();
        if (listPaths.size() <= 0) {
            System.out.println(argv[0] + " not found");
        }
        /*
        else {
            System.out.println(argv[0] + " found in: ");

            Iterator it = listPaths.iterator();
            while (it.hasNext()) {
                System.out.println("   " + it.next());
            }
        }
        */

    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class 

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
