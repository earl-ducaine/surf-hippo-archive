//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import java.io.Serializable;

/**
 * A single directed GraphEdge in a graph.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Nov 04 1997, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.5/1.2.0, Nov 26 2002, JH
 *               Updated the API, added parsing
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.1.4
 * @version GUIRLib-v1.5/1.2.0, Nov 26 2002
 */
public class GraphEdge 
   implements Serializable {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   /**
    * A parser for GraphEdges.
    */
   public static final GraphEdgeParser PARSER = 
                                             new GraphEdgeParserDefaultImpl();

   //===   CONSTANTS   =========================================================
   //===========================================================================





   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   GraphNode nodeSrc;        // the source of this GraphEdge
   GraphNode nodeDst;        // the destination of this GraphEdge
   float     weight = 0;     // the weight of this GraphEdge

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructor to create an GraphEdge from a Node to another Node with a
    * weight of GraphConst.DEFAULT_WEIGHT.
    *
    * @param strNodeSrc is the name of the source Node.
    * @param strNodeDst is the name of the destination Node.
    * @see   GraphConst
    */
   public GraphEdge(String strNodeSrc, String strNodeDst) {
      this(new GraphNode(strNodeSrc), new GraphNode(strNodeDst), 
           GraphConst.DEFAULT_WEIGHT);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Constructor to create an GraphEdge from a Node to another Node with the
    * specified weight.
    *
    * @param strNodeSrc is the name of the source Node.
    * @param strNodeDst is the name of the destination Node.
    * @param weight is the weight of the GraphEdge.
    */
   public GraphEdge(String strNodeSrc, String strNodeDst, float weight) {
      this(new GraphNode(strNodeSrc), new GraphNode(strNodeDst), weight);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Constructor to create an GraphEdge from a Node to another Node with a
    * weight of GraphConst.DEFAULT_WEIGHT.
    *
    * @param nodeSrc is the source Node.
    * @param nodeDst is the destination Node.
    * @see   GraphConst
    */
   public GraphEdge(GraphNode nodeSrc, GraphNode nodeDst) {
      this(nodeSrc, nodeDst, GraphConst.DEFAULT_WEIGHT);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Constructor to create an GraphEdge from a Node to another Node with the
    * specified weight.
    *
    * @param nodeSrc is the source Node.
    * @param nodeDst is the destination Node.
    * @param weight is the weight of the GraphEdge.
    */
   public GraphEdge(GraphNode nodeSrc, GraphNode nodeDst, float weight) {
      this.nodeSrc = nodeSrc;
      this.nodeDst = nodeDst;
      this.weight  = weight;
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================





   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Get the source Node of the GraphEdge.
    *
    * @return The source Node of this GraphEdge.
    */
   public GraphNode getSourceNode() {
      return (nodeSrc);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the destination Node of the GraphEdge.
    *
    * @return The destination Node of this GraphEdge.
    */
   public GraphNode getDestNode() {
      return (nodeDst);
   } // of method

   //-----------------------------------------------------------------

   public float getWeight() {
      return(weight);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a hashcode for this GraphEdge.
    *
    * @return Returns an int containing the hashcode for this GraphEdge.
    */
   public int hashCode() {
      String strValue = nodeSrc.toString() + nodeDst.toString();
      return (strValue.hashCode());
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================





   //===========================================================================
   //===   TOSTRING   ==========================================================

   /**
    * Returns the name of the GraphEdge.
    *
    * @return A String containing the name of the GraphEdge.
    */
   public String toString() {
      return(nodeSrc.getName() + ", " + nodeDst.getName() + ", " + weight);
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================





   //===========================================================================
   //===   EQUALS   ============================================================

   /**
    * This method checks if a given object is the "same" as this one.
    * If the two GraphEdges have the same name, then they are considered the
    * same.
    *
    * @param o is the Object to check for equality.
    */
   public boolean equals(Object o) {
      if (o instanceof GraphEdge) {

         //// 1. Check if the two GraphEdges are the same here by checking if 
         ////    the source and destination Nodes are the same, and if
         ////    the weights are within a certain tolerance of each other.
         GraphEdge edgeTemp = (GraphEdge) o;
         if (nodeSrc.equals(edgeTemp.nodeSrc) &&
             nodeDst.equals(edgeTemp.nodeDst) &&
             Math.abs(weight - edgeTemp.weight) < GraphConst.ERROR)
            return (true);
      }

      return(false);
   } // of method

   //===   EQUALS   ============================================================
   //===========================================================================



   
   
   //===========================================================================
   //===   MAIN    =============================================================

   //
   // Used for self-testing purposes.
   //
   public static void main(String[] argv) {
      GraphEdge e1 = new GraphEdge("from", "to");
      GraphEdge e2 = new GraphEdge("alsofrom", "alsoto", 10);
      GraphEdge e3 = new GraphEdge("alsofrom", "alsoto", 10);
      GraphEdge e4 = new GraphEdge("alsofrom", "alsoto", 3.14159f);

      System.out.println(e1);
      System.out.println(e2);
      System.out.println(e3);
      System.out.println(e4);

      System.out.println(e2.equals(e3));
   } // of method

   //===   MAIN    =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
