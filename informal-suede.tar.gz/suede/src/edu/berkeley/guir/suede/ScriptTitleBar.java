/*
 * ScriptTitleBar.java
 *
 * Created on April 3, 2001, 2:56 PM
 */

package edu.berkeley.guir.suede;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ScriptTitleBar extends javax.swing.JPanel {

    
    protected JButton     m_label = null;
    protected JTextField  m_nameField = null;
    protected PlayButton  m_playButton = null;
    protected String      m_scriptName = null;
    protected AbstScriptView m_scriptView = null;
    
    // Used when playing the entire script
    protected int         m_nowPlaying = -1;
  
   
    public ScriptTitleBar( String name, AbstScriptView scriptView ) {
            m_scriptName = name;
            m_scriptView = scriptView;
            
            m_nameField = new JTextField( name, 20 );
            m_nameField.setVisible( false );
            m_nameField.addFocusListener( new FocusListener() {
                public void focusGained( FocusEvent e ) {}
                public void focusLost( FocusEvent e ) {
                    m_scriptName = m_nameField.getText();
                    m_label.setText( m_scriptName );
                    m_nameField.setVisible( false );
                    m_label.setVisible( true );
                }
            } );
            m_nameField.addActionListener( new ActionListener() {
                public void actionPerformed( ActionEvent e ) {
                    m_scriptName = e.getActionCommand();
                    m_label.setText( m_scriptName );
                    m_nameField.setVisible( false );
                    m_label.setVisible( true );
                }
            } );
            
            m_label = new JButton( name );
            m_label.setBorder( BorderFactory.createEmptyBorder() );
            m_label.setFocusPainted( false );
            m_label.addActionListener( new ActionListener() {
                public void actionPerformed( ActionEvent e ) {
                    m_label.setVisible( false );
                    m_nameField.setVisible( true );
                    m_nameField.requestFocus();
                }
            } );
            
            m_playButton = new PlayButton( true, Color.black );
            m_playButton.addActionListener( new ActionListener() {
                public void actionPerformed( ActionEvent e ) {
                    playClicked();
                }
            } );

            setLayout( new FlowLayout( FlowLayout.LEFT, 5, 0 ) );
            add( m_nameField );
            add( m_label );
            add( m_playButton );
    }

    
    public String getName() {
        return m_scriptName;
    }
    
    
           
    // I think theoretically there could be thread conflicts between the following two methods,
    // but I'm not going to worry about it.
    
    protected void playClicked() {
        if ( m_nowPlaying == -1 ) { // If we aren't currently playing audio...
            playNextNode();
        } else { // else pause the audio
            m_scriptView.getNode( m_nowPlaying ).setStopped();
            // set nowPlaying to a high number so playNextNode() will think we're through
            m_nowPlaying = m_scriptView.getNumberNodes();
        }
        
    }
    
    protected void playNextNode() {
        CallbackIF playNext = new CallbackIF() {
            public void callback() {
                playNextNode();
            }
        };
        
        m_nowPlaying++;
        
        if ( m_nowPlaying < m_scriptView.getNumberNodes() ) {
            m_scriptView.getNode( m_nowPlaying ).playAudio( playNext );
        } else {
            m_playButton.setSelected( false );
            m_nowPlaying = -1;
        }
    }
        
    
}
