package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.component.Select;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that removes an item from a select-one or select-many control.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  01-07-2004 James Lin
 *                               Created RemoveItemCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 01-07-2004
 */
public class RemoveItemCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final Select control;
   private final Select.Item item;
   private int index;
   
   /**
    * Constructs the command.
    *  
    * @param control  the control to remove the item to
    * @param item     the item to remove
    */      
   public RemoveItemCommand(final Select control, final Select.Item item) {
      this.control = control;
      this.item = item;
   }


   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Remove " + item + " from " + control;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      index = control.getItems().indexOf(item);
      if (index != -1) {
         control.removeItem(item);
      }
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      if (index != -1) {
         control.addItem(index, item);
      }
   }
}
