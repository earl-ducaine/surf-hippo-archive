package edu.berkeley.guir.damask.command;

import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.dialog.PageRegion;

/** 
 * A command that takes a component that is for all device types, and splits it
 * into several components, one for each device type.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-16-2004 James Lin
 *                               Created SplitComponentIntoDeviceSpecificCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-16-2004
 */
public class SplitComponentIntoDeviceSpecificVersionsCommand
   extends ModifyGraphMacroCommand {

   private final Component component;
   private final DeviceType targetDeviceType;

   /**
    * Constructs the command.
    * 
    * @param component the component to create device-specific versions from
    */
   public SplitComponentIntoDeviceSpecificVersionsCommand(
      final Component component, final DeviceType targetDeviceType) {
      
      this.component = component;
      this.targetDeviceType = targetDeviceType;
      
      if (component instanceof Control) {
         splitControlIntoDeviceSpecificControls((Control)component, targetDeviceType);
      }
      else {
         splitGroupIntoDeviceSpecificGroups((ComponentGroup)component, targetDeviceType);
      }
   }


   private Control splitControlIntoDeviceSpecificControls(
      final Control control, final DeviceType targetDeviceType) {
         
      DamaskUtils.checkValidArgument(control.getDeviceType() == DeviceType.ALL, 
         "Device type of " + control + " must be ALL, not " + control.getDeviceType());
      
      // for each outgoing connection, remove connection
      for (Iterator i = control.getOutConnections().iterator();
         i.hasNext();
         ) {
         final Connection outConnection = (Connection)i.next();
         addCommand(new RemoveConnectionCommand(outConnection, false));
      }
      
      // remove this component and create new components for each device
      final Control newControl = (Control)control.createCopy(targetDeviceType);
      
      final PageRegion targetRegion = control.getPageRegion(targetDeviceType);
      final ComponentGroup targetGroup = control.getGroup();

      if (newControl instanceof Select.Item) {
         final Select.Item newItem = (Select.Item)newControl;
         final Class selectClass;
         if (newItem instanceof SelectOne.Item) {
            selectClass = SelectOne.class;
         }
         else {
            selectClass = SelectMany.class;
         }
         final Select selectToAddTo =
            DamaskUtils.findExistingSelect(
               targetRegion,
               targetGroup,
               newItem.getDeviceType(),
               selectClass,
               Select.FULL);

         if (selectToAddTo == null) {
            final Select newSelect;
            if (newItem instanceof SelectOne.Item) {
               newSelect = new SelectOne(targetDeviceType);
            }
            else {
               newSelect = new SelectMany(targetDeviceType);
            }
            newSelect.addItem(newItem);
            
            addCommand(new AddControlCommand(targetRegion, newSelect));
            if (targetGroup != null) {
               addCommand(new AddComponentToGroupCommand(targetGroup, newControl));
            }
         }
         else {
            addCommand(new AddItemCommand(selectToAddTo, newItem));
         }
      }
      else {
         addCommand(new AddControlCommand(targetRegion, newControl));
         if (targetGroup != null) {
            addCommand(new AddComponentToGroupCommand(targetGroup, newControl));
         }
      }
      
      DamaskUtils.addCommandsForRemovingControlToMacroCommand(this, control);
      
      // for each component
      //    for each old outgoing connection
      //       create new connection, new device type and source
      for (Iterator j = control.getOutConnections().iterator();
         j.hasNext();
         ) {
         final NavConnection connection = (NavConnection)j.next();
         addCommand(
            new AddConnectionCommand(
               targetDeviceType,
               false,
               newControl,
               connection.getUserEvent(),
               connection.getCondition(),
               connection.getConnectionDest(targetDeviceType),
               connection.getShape(targetDeviceType)));
      }
      
      return newControl;
   }


   private ComponentGroup splitGroupIntoDeviceSpecificGroups(
      final ComponentGroup group, final DeviceType targetDeviceType) {

      DamaskUtils.checkValidArgument(group.getDeviceType() == DeviceType.ALL, 
         "Device type of " + group + " must be ALL, not " + group.getDeviceType());
      
      // create one group for each device type
      final ComponentGroup newGroup = (ComponentGroup) group
            .createCopy(targetDeviceType);
      
      final PageRegion targetRegion = (PageRegion) newGroup
            .getPageRegions(targetDeviceType).iterator().next();
      final ComponentGroup targetGroup = group.getGroup();

      addCommand(
         new AddGroupCommand(targetRegion.getPage().getDialog(), newGroup));
      if (targetGroup != null) {
         addCommand(new AddComponentToGroupCommand(targetGroup, newGroup));
      }
      
      // for each component in group:
      for (Iterator i = group.getChildren().iterator(); i.hasNext(); ) {
         final Component child = (Component)i.next();
         final Set/*<Component>*/ childrenToAdd = new HashSet/*<Component>*/();
         // if component is ALL, split component
         if (child.getDeviceType() == DeviceType.ALL) {
            if (child instanceof Control) {
               childrenToAdd.add(
                  splitControlIntoDeviceSpecificControls((Control)child, targetDeviceType));
            }
            else {
               childrenToAdd.add(
                  splitGroupIntoDeviceSpecificGroups((ComponentGroup)child, targetDeviceType));
            }
         }
         else {
            childrenToAdd.add(child);
         }
      
         // add to appropriate new group
         for (Iterator j = childrenToAdd.iterator(); j.hasNext(); ) {
            final Component newChild = (Component)j.next();
            addCommand(new AddComponentToGroupCommand(newGroup, newChild));
         }
      }
      addCommand(new RemoveGroupCommand(group));
      
      return newGroup;
   }


   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Convert device-all " + component + " into " + targetDeviceType;
   }
}
