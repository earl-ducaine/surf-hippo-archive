package edu.berkeley.guir.denim.view;

import java.awt.geom.*;
import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.satin.image.*;

/**
 * Semantic zoom view for {@link DenimLabel labels}.
 *
 * <PRE>
 * Revisions:  1.0.0  08-23-1999 MWN
 *                    Created.
 *             2.0.0  02-02-2000 JH
 *                    Updated to work with new view bounds.
 *                    Made it stick to the sketch correctly.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~newman/">Mark Newman</A> (
 *          <A HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu</A> )
 * @since   JDK 1.3RC1
 * @version Version 2.0.0, 02-02-2000
 */
public class LabelViewWrapper
   extends    StickyZViewWrapper
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -695503430064893760L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   //private DenimSketch sketch;  // the sketch to which this label is attached

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Does nothing, for cloning purposes.
    */
   protected LabelViewWrapper() {
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Construct the view.
    */
   public LabelViewWrapper(View v) {
      super(v);
      setName("LabelViewWrapper");
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR / MODIFIER METHODS   =======================================

   /**
    * Sets the sketch associated with the label with this view to the given
    * sketch.
    */
   /*public void setSketch(DenimSketch sketch) {
      this.sketch = sketch;
   }*/ // of method

   //-----------------------------------------------------------------

   /**
    * Returns the sketch associated with the label with this view.
    */
   /*public DenimSketch getSketch() {
      return sketch;
   }*/ // of method


   //-----------------------------------------------------------------

   /**
    * Called only by DenimLabel.getUnstickyLocalBounds
    */
   public Rectangle2D getUnstickyLocalBounds() {
      return getUnstickyBoundingPoints2DRef().getBounds2D();
   }

   //-----------------------------------------------------------------

   // Used in PhraseInterpreter.AddStrokeToScribbleCommand
   public AffineTransform getStickyTransform() {
      AffineTransform tx = new AffineTransform();
      return getStickyTransform(tx);
   }

   //-----------------------------------------------------------------

   protected AffineTransform getStickyTransform(AffineTransform txTmp) {
      //// 1. Figure out the absolute transform and apply the inverse
      ////    so that we will always be the same, ie Sticky-Z.
      getAttachedGraphicalObject().getTransform(COORD_ABS, txTmp);
/*      
	  if(SatinImageLib.imageConvertingRender)
	  {
	  	try
	  	{
		     txTmp.preConcatenate(
		     	this.getAttachedGraphicalObject().
		     	getSheet().getTransform(COORD_ABS).createInverse());
		     System.out.println(txTmp.getScaleX());
	  	}
	  	catch(Exception ex)
	  	{
	  		ex.printStackTrace();
	  	}
	  }
*/	  
	  double curScale = AffineTransformLib.getScaleFactor(txTmp);
/*	  
	  if(SatinImageLib.imageConvertingRender)
	  {
	      getAttachedGraphicalObject().getTransform(COORD_REL, txTmp);
	      AffineTransform pxTmp = new AffineTransform();
		  getAttachedGraphicalObject().getParentGroup().getTransform(COORD_REL, pxTmp);
		  txTmp.preConcatenate(pxTmp);
		  curScale = AffineTransformLib.getScaleFactor(txTmp);
	  }  
*/	       
      double scale = getDesiredScale() / curScale;
      DenimSketch sketch =
         ((DenimLabel)getAttachedGraphicalObject()).getSketch();

      //// 2. Set the inverse transform to make it sticky.
      txTmp.setToScale(scale, scale);

      //// 3. Translate so that we are stuck right next to the sketch.
      if (sketch != null) {
         Polygon2D       labelBoundingPoints;
         Rectangle2D     labelBounds;
         Rectangle2D     sketchBounds;
         AffineTransform tx = new AffineTransform();

         //// 3.1. Calculate what the sticky view bounds would normally be.
         ////      This gives us bounds in terms of local coords.
         labelBoundingPoints = getUnstickyBoundingPoints2DRef();
         labelBoundingPoints = labelBoundingPoints.transformCopy(txTmp);

         //// 3.2. Transform the sticky view bounds to be the equivalent
         ////      of relative bounds.
         getAttachedGraphicalObject().getTransform(COORD_REL, tx);
         labelBoundingPoints.transform(tx);

         double labelScale = AffineTransformLib.getScaleFactor(tx);

         //// 3.3. Using relative bounds, figure out the gap between
         ////      the label and the sketch.
         labelBounds  = labelBoundingPoints.getBounds2D();
         sketchBounds = sketch.getBounds2D(COORD_REL);

         //// 3.4. Translate by that much.
         ////      If there is a bug, it's likely to be in this equation.
         txTmp.translate(0,
         (sketchBounds.getY() - labelBounds.getY() - labelBounds.getHeight()) /
         (scale * labelScale));
      }

      return (txTmp);

   } // of method

   //===   ACCESSOR / MODIFIER METHODS   =======================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new LabelViewWrapper()));
   } // of clone

   //-----------------------------------------------------------------

   public LabelViewWrapper clone(LabelViewWrapper vw) {
      //// 1. Clone chain.
      super.clone(vw);

      //// 2. Do clone work.
      //vw.sketch = (DenimSketch) this.sketch.deepClone();

      //// 3. Return.
      return (vw);
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
