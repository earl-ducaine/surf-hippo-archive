package edu.berkeley.guir.damask.view.voice.component;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Trigger;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.event.ConnectionSourceEvent;
import edu.berkeley.guir.damask.event.ConnectionSourceListener;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.damask.view.voice.ResponseSource;
import edu.berkeley.guir.damask.view.voice.dialog.Conversation;

/** 
 * A view of a trigger control.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  08-15-2004 James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public class VoiceTrigger extends VoiceControl {
   private final ConnectionSourceHandler connectionSourceHandler =
      new ConnectionSourceHandler(); 

   /**
    * Constructs a view of the specified trigger.
    */
   public VoiceTrigger(final Trigger model) {
      super(model);
      model.addConnectionSourceListener(connectionSourceHandler);
   }

   
   // @Override
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      final Trigger trigger = (Trigger)getModel();
      final Conversation conversation = getConversation();
      final ResponseSource responseSource =
         (ResponseSource)conversation.getPreviousVoiceControlWithPrompt(this);
      
      for (int i = 0, n = ((Dialog)getForm().getModel()).getNumConditions();
           i < n; i++) {
         final NavConnection navConnection =
            trigger.getOutConnection(DeviceType.VOICE, new InvokeEvent(this), i);
         
         setResponse(i, new Response(this, responseSource, navConnection));
      }
   }
   
   
   // @Override
   public void dispose() {
      super.dispose();
      ((Trigger)getModel()).removeConnectionSourceListener(
         connectionSourceHandler);
   }
   
   
   /**
    * Handles events from the model object. 
    */
   private class ConnectionSourceHandler implements ConnectionSourceListener {
      // @Override
      public void outConnectionAdded(ConnectionSourceEvent e) {
         if (e.getSource() == getModel()) {
            final NavConnection connection = (NavConnection)e.getConnection();
            final int condition = connection.getCondition();
            final Response oldResponse = getResponse(condition);
            final ResponseSource responseSource =
               (ResponseSource)getConversation().
                  getPreviousVoiceControlWithPrompt(VoiceTrigger.this);

            setResponse(
               condition,
               new Response(VoiceTrigger.this, responseSource, connection));
            if (oldResponse != null) {
               oldResponse.dispose();
            }
         }
      }

      // @Override
      public void outConnectionRemoved(ConnectionSourceEvent e) {
         if (e.getSource() == getModel()) {
            final NavConnection connection = (NavConnection)e.getConnection();
            final int condition = connection.getCondition();
            final Response oldResponse = getResponse(condition);
            final ResponseSource responseSource =
               (ResponseSource)getConversation().
                  getPreviousVoiceControlWithPrompt(VoiceTrigger.this);
            setResponse(
               condition,
               new Response(VoiceTrigger.this, responseSource, null));
            if (oldResponse != null) {
               oldResponse.dispose();
            }
         }
      }
   }
}
