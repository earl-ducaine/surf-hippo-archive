package edu.berkeley.guir.damask;

import java.util.*;

import javax.swing.JTree;
import javax.swing.tree.*;

import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.damask.pattern.PatternInstanceMember;
import edu.berkeley.guir.lib.collection.Map2D;

/** 
 * Provides a tree-based view of the objects in the model.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-06-2003 James Lin
 *                               Created DamaskStateTree
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.4
 * @version Version 1.0.0, 08-06-2003
 */
public class DamaskStateTree extends JTree {

   private static final String ROOT = "Damask";
   private static final String DIALOGS = "Dialogs";
   private static final String CONNECTIONS = "Connections";
   private static final String PATTERN_INSTANCES = "Pattern Instances";
   private static final String COMPONENT_GROUPS = "Component Groups";

   private final Map2D/*<DeviceType, Object, TreeNode>*/ nodes = new Map2D();

   private final DefaultMutableTreeNode root = new DefaultMutableTreeNode(ROOT);
   
   private final DefaultTreeModel model;

   private final InteractionGraphListener interactionGraphListener =
      new InteractionGraphListener();
   private final DialogListener dialogListener = new DialogListener();
   private final PageListener pageListener = new PageListener();
   private final PageRegionListener pageRegionListener =
      new PageRegionListener();
   private final ControlListener controlListener = new ControlListener();
   private final ConnectionEventListener connectionListener =
      new ConnectionEventListener();
   private final PatternInstanceListener patternInstanceListener =
      new PatternInstanceListener();
   private final SelectListener selectListener =
      new SelectListener();
   private final ComponentGroupListener componentGroupListener =
      new ComponentGroupListener();

   //===========================================================================

   public DamaskStateTree(final InteractionGraph graph) {
      super();
      setShowsRootHandles(true);
      graph.addElementContainerListener(interactionGraphListener);

      model = new StateTreeModel(root);
      setModel(model);

      for (Iterator i = Damask.getSupportedDeviceTypes().iterator(); i.hasNext();) {
         final DeviceType deviceType = (DeviceType)i.next();

         final DefaultMutableTreeNode deviceNode =
            new DefaultMutableTreeNode(deviceType);

         MutableTreeNode treeNode;

         treeNode = new DefaultMutableTreeNode(DIALOGS);
         deviceNode.add(treeNode);
         nodes.put(deviceType, DIALOGS, treeNode);

         treeNode = new DefaultMutableTreeNode(CONNECTIONS);
         deviceNode.add(treeNode);
         nodes.put(deviceType, CONNECTIONS, treeNode);

         treeNode = new DefaultMutableTreeNode(PATTERN_INSTANCES);
         deviceNode.add(treeNode);
         nodes.put(deviceType, PATTERN_INSTANCES, treeNode);

         treeNode = new DefaultMutableTreeNode(COMPONENT_GROUPS);
         deviceNode.add(treeNode);
         nodes.put(deviceType, COMPONENT_GROUPS, treeNode);

         root.add(deviceNode);
      }

      setRootVisible(false);
      expandPath(new TreePath(root));
      
      // Fill in tree with elements already in the graph
      for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
         i.hasNext();
         ) {
         final DeviceType aDeviceType = (DeviceType)i.next();

         for (Iterator j = graph.getDialogs(aDeviceType).iterator();
              j.hasNext(); ) {
            final Dialog d = (Dialog)j.next();
            addDialogToTree(graph, aDeviceType, d);
         }
         for (Iterator j = graph.getConnections(aDeviceType).iterator();
             j.hasNext(); ) {
            final Connection c = (Connection)j.next();
            addConnectionToTree(graph, aDeviceType, c);
         }
         for (Iterator j = graph.getPatternInstances().iterator();
             j.hasNext(); ) {
            final PatternInstance pi = (PatternInstance)j.next();
            addPatternInstanceToTree(graph, aDeviceType, pi);
         }
      }
   }

   //===========================================================================

   private int getAddPosition(
      Collection collection,
      TreeNode parent,
      Object object) {

      if (collection instanceof List) {
         return ((List)collection).indexOf(object);
      }
      else {
         return parent.getChildCount();
      }
   }

   //===========================================================================

   private MutableTreeNode addElementToTree(
      final DeviceType deviceType,
      final MutableTreeNode parent,
      final int position,
      final InteractionElement element) {

      final MutableTreeNode child = new DefaultMutableTreeNode(element);

      nodes.put(deviceType, element, child);

      model.insertNodeInto(child, parent, position);

      return child;
   }

   //===========================================================================

   private void addPageToTree(
      final DeviceType deviceType,
      final MutableTreeNode dialogNode,
      final int position,
      final Page p) {

      final MutableTreeNode pageNode =
         addElementToTree(deviceType, dialogNode, position, p);

      // Listen for the page's events
      p.addInteractionElementListener(pageListener);

      // When a page is added, also add page regions to the page
      for (Iterator i = p.getRegions().iterator(); i.hasNext(); ) {
         final PageRegion region = (PageRegion)i.next();
         
         if (!region.getControls().isEmpty()) {
            // Add node for page region
            addElementToTree(
               deviceType,
               pageNode,
               pageNode.getChildCount(),
               region);
            
            // Add controls that are already in the page region
            for (Iterator j = region.getControls().iterator(); j.hasNext(); ) {
               final Control control = (Control)j.next();
               addControlToTree(region, deviceType, control);
            }
         }

         // Listen for the page region's events                        
         region.addElementContainerListener(pageRegionListener);
         region.addInteractionElementListener(pageRegionListener);
      }
   }

   //===========================================================================

   private MutableTreeNode removeElementFromTree(
      final DeviceType deviceType,
      final InteractionElement element) {

      final MutableTreeNode child =
         (MutableTreeNode)nodes.get(deviceType, element);

      nodes.put(deviceType, element, null);
      if (child != null) {
         model.removeNodeFromParent(child);
      }

      return child;
   }

   //===========================================================================

   private void removePageFromTree(
      final DeviceType deviceType,
      final Page p) {

      // Remove the page's regions from the tree
      for (Iterator i = p.getRegions().iterator(); i.hasNext(); ) {
         final PageRegion region = (PageRegion)i.next();
         
         removeElementFromTree(deviceType, region);
         
         // Stop listening for the page region's events                        
         region.removeElementContainerListener(pageRegionListener);
         region.removeInteractionElementListener(pageRegionListener);
      }

      removeElementFromTree(deviceType, p);
      
      // Stop listening for the page's events
      p.removeInteractionElementListener(pageListener);
   }
   
   //===========================================================================

   /**
    * @param g
    * @param aDeviceType
    * @param d
    */
   private void addDialogToTree(
      final InteractionGraph g,
      final DeviceType aDeviceType,
      final Dialog d) {

      final MutableTreeNode parent =
         (MutableTreeNode)nodes.get(aDeviceType, DIALOGS);
      final int position = getAddPosition(g.getDialogs(), parent, d);

      if (d.isEnabled(aDeviceType)) {
         // Add the dialog to the tree
         final MutableTreeNode child =
            addElementToTree(aDeviceType, parent, position, d);

         // Listen for the dialog's events               
         d.addElementContainerListener(dialogListener);
         d.addInteractionElementListener(dialogListener);

         // Add pages to the dialog's node in the tree
         for (Iterator j = d.getPages(aDeviceType).iterator();
            j.hasNext();
            ) {

            final Page p = (Page)j.next();
            addPageToTree(
               aDeviceType,
               child,
               child.getChildCount(),
               p);
         }
      }
   }

   //===========================================================================

   /**
    * @param g
    * @param aDeviceType
    * @param c
    */
   private void addConnectionToTree(
      final InteractionGraph g,
      final DeviceType aDeviceType,
      final Connection c) {

      final MutableTreeNode parent =
         (MutableTreeNode)nodes.get(aDeviceType, CONNECTIONS);
      final int position = getAddPosition(g.getConnections(), parent, c);

      if (c.isVisibleToDeviceType(aDeviceType)) {
         addElementToTree(aDeviceType, parent, position, c);

         // Listen for the connection's events
         c.addConnectionListener(connectionListener);
         c.addInteractionElementListener(connectionListener);
      }
   }

   //===========================================================================

   /**
    * @param g
    * @param aDeviceType
    * @param pi
    */
   private void addPatternInstanceToTree(
      final InteractionGraph g,
      final DeviceType aDeviceType,
      final PatternInstance pi) {

      final MutableTreeNode parent =
         (MutableTreeNode)nodes.get(aDeviceType, PATTERN_INSTANCES);
      final int position = getAddPosition(g.getPatternInstances(), parent, pi);

      addElementToTree(aDeviceType, parent, position, pi);

      // Listen for the pattern instance's events
      pi.addInteractionElementListener(patternInstanceListener);
      pi.addElementContainerListener(patternInstanceListener);
   }

   //===========================================================================

   /**
    * @param region
    * @param deviceType
    * @param control
    * @param parent
    */
   private void addControlToTree(
      final PageRegion region,
      final DeviceType deviceType,
      final Control control) {

      final MutableTreeNode parent =
         (MutableTreeNode)nodes.get(deviceType, region);

      final int position =
         getAddPosition(region.getControls(), parent, control);

      final MutableTreeNode controlTreeNode =
         addElementToTree(deviceType, parent, position, control);

      // If the control is of type Select, then add its items to the tree
      if (control instanceof Select) {
         final Select select = (Select)control;
         select.addElementContainerListener(selectListener);
         for (Iterator i = select.getItems().iterator(); i.hasNext(); ) {
            final Select.Item item = (Select.Item)i.next();
            addElementToTree(
               deviceType,
               controlTreeNode,
               controlTreeNode.getChildCount(),
               item);
         }
      }
      // Listen for the control's events
      control.addInteractionElementListener(controlListener);
   }

   //===========================================================================

   private final class InteractionGraphListener
      implements ElementContainerListener {
         
      public void elementAdded(ElementContainerEvent e) {
         final Object container = e.getSource();
         final InteractionElement element = e.getElement();

         if (!(container instanceof InteractionGraph)) {
            return;
         }

         final InteractionGraph g = (InteractionGraph)container;

         for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
            i.hasNext();
            ) {
            final DeviceType aDeviceType = (DeviceType)i.next();

            if (element instanceof Dialog) {
               addDialogToTree(g, aDeviceType, (Dialog)element);
            }
            else if (element instanceof Connection) {
               addConnectionToTree(g, aDeviceType, (Connection)element);
            }
            else if (element instanceof PatternInstance) {
               addPatternInstanceToTree(g, aDeviceType, (PatternInstance)element);
            }
            else {
               assert false : "element added to graph must be dialog, connection, or pattern instance";
            }
         }
      }

      //------------------------------------------------------------------------

      public void elementRemoved(ElementContainerEvent e) {
         final Object container = e.getSource();
         final InteractionElement element = e.getElement();

         if (!(container instanceof InteractionGraph)) {
            return;
         }

         for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
            i.hasNext();
            ) {
               
            final DeviceType aDeviceType = (DeviceType)i.next();

            if (element instanceof Dialog) {
               final Dialog d = (Dialog)element;
               
               // Remove pages from the dialog's node in the tree
               // TODO do I need to do this? Won't the model fire
               // page remove events anyway?
               for (Iterator j = d.getPages(aDeviceType).iterator();
                  j.hasNext();
                  ) {

                  final Page p = (Page)j.next();
                  removePageFromTree(aDeviceType, p);
               }
               
               d.removeElementContainerListener(dialogListener);
               d.removeInteractionElementListener(dialogListener);

               removeElementFromTree(aDeviceType, d);               
            }
            else if (element instanceof Connection) {
               final Connection c = (Connection)element;

               removeElementFromTree(aDeviceType, c);

               // Listen for the connection's events
               c.removeConnectionListener(connectionListener);
               c.removeInteractionElementListener(connectionListener);
            }
            else if (element instanceof PatternInstance) {
               final PatternInstance pi = (PatternInstance)element;

               removeElementFromTree(aDeviceType, pi);

               // Listen for the pattern instance's events
               pi.removeInteractionElementListener(patternInstanceListener);
               pi.removeElementContainerListener(patternInstanceListener);
            }
            else {
               assert false : "element added to graph must be dialog, connection, or pattern instance";
            }
         }
      }
   }

   //===========================================================================

   private final class DialogListener
      implements
         ElementContainerListener,
         InteractionElementListener {

      public void elementAdded(ElementContainerEvent e) {
         final Object container = e.getSource();
         final DeviceType deviceType = e.getDeviceType();

         if (!(container instanceof Dialog)) {
            return;
         }
         final Dialog dialog = (Dialog)container;
         
         if (e.getElement() instanceof Page) {
            final Page page = (Page)e.getElement();

            final MutableTreeNode parent =
               (MutableTreeNode)nodes.get(deviceType, dialog);
            final int position =
               getAddPosition(dialog.getPages(deviceType), parent, page);

            addPageToTree(deviceType, parent, position, page);
         }
         else {
            // Add component group
         }
      }

      //------------------------------------------------------------------------

      public void elementRemoved(ElementContainerEvent e) {
         final Object container = e.getSource();
         final DeviceType deviceType = e.getDeviceType();

         if (!(container instanceof Dialog)) {
            return;
         }
         
         if (e.getElement() instanceof Page) {
            final Page page = (Page)e.getElement();

            removePageFromTree(deviceType, page);
         }
      }

      //------------------------------------------------------------------------

      public void elementBoundsUpdated(InteractionElementEvent e) {
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }

   }

   //===========================================================================

   private final class PageListener implements InteractionElementListener {

      public void elementBoundsUpdated(InteractionElementEvent e) {
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }

   //===========================================================================

   private final class PageRegionListener
      implements ElementContainerListener, InteractionElementListener {

      public void elementAdded(ElementContainerEvent e) {
         final Object container = e.getSource();
         final DeviceType deviceType = e.getDeviceType();

         if (!(container instanceof PageRegion)) {
            return;
         }

         final PageRegion region = (PageRegion)container;

         MutableTreeNode parent =
            (MutableTreeNode)nodes.get(deviceType, region);

         // If the page region hasn't been added to the tree yet, add it
         if (parent == null) {
            final MutableTreeNode pageNode =
               (MutableTreeNode)nodes.get(deviceType, region.getPage());

            // Figure out the right position to add the new region
            final List regionNames = Direction.getValues();
            final int regionNameIndex = regionNames.indexOf(region.getName());
            
            int regionNodeIndex = pageNode.getChildCount();
            for (int i = 0, n = pageNode.getChildCount(); i < n; i++) {
               final PageRegion aRegion =
                  (PageRegion) ((DefaultMutableTreeNode)pageNode.getChildAt(i))
                     .getUserObject();
                     
               final int aNameIndex = regionNames.indexOf(aRegion.getName());
               if (aNameIndex > regionNameIndex) {
                  regionNodeIndex = i;
               }
            }
                  
            parent =
               addElementToTree(deviceType, pageNode, regionNodeIndex, region);
         }
            
         final Control control = (Control)e.getElement();
         addControlToTree(region, deviceType, control);
      }

      //------------------------------------------------------------------------

      public void elementRemoved(ElementContainerEvent e) {
         final Object container = e.getSource();
         final DeviceType deviceType = e.getDeviceType();

         if (!(container instanceof PageRegion)) {
            return;
         }

         final Control control = (Control)e.getElement();

         // Stop listening for the control's events
         control.removeInteractionElementListener(controlListener);

         removeElementFromTree(deviceType, control);
      }

      //------------------------------------------------------------------------

      public void elementBoundsUpdated(InteractionElementEvent e) {
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }

   }

   //===========================================================================

   private final class ControlListener implements InteractionElementListener {

      public void elementBoundsUpdated(InteractionElementEvent e) {
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }

   //===========================================================================

   private final class ConnectionEventListener
      implements InteractionElementListener, ConnectionListener {

      public void elementBoundsUpdated(InteractionElementEvent e) {
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }

      public void sourceChanged(ConnectionEvent e) {
      }

      public void destChanged(ConnectionEvent e) {
      }

      public void shapeChanged(ConnectionEvent e) {
      }

      public void userEventChanged(ConnectionEvent e) {
      }

      public void conditionChanged(ConnectionEvent e) {
      }
   }

   //===========================================================================

   private final class PatternInstanceListener
      implements ElementContainerListener, InteractionElementListener {

      public void elementAdded(ElementContainerEvent e) {
         final Object container = e.getSource();
         final DeviceType deviceType = e.getDeviceType();

         if (!(container instanceof PatternInstance)) {
            return;
         }

         final PatternInstance pi = (PatternInstance)container;
         final PatternInstanceMember element =
            (PatternInstanceMember)e.getElement();

         final MutableTreeNode parent =
            (MutableTreeNode)nodes.get(deviceType, container);

         final int position =
            getAddPosition(pi.getMembers(), parent, element);

         addElementToTree(deviceType, parent, position, element);
      }

      //------------------------------------------------------------------------

      public void elementRemoved(ElementContainerEvent e) {
         final Object container = e.getSource();
         final DeviceType deviceType = e.getDeviceType();

         if (!(container instanceof PatternInstance)) {
            return;
         }

         final PatternInstanceMember element =
            (PatternInstanceMember)e.getElement();

         removeElementFromTree(deviceType, element);
      }

      //------------------------------------------------------------------------

      public void elementBoundsUpdated(InteractionElementEvent e) {
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }

   //===========================================================================

   private final class SelectListener implements ElementContainerListener {

      public void elementAdded(ElementContainerEvent e) {
         final Object container = e.getSource();
         final DeviceType deviceType = e.getDeviceType();

         if (!(container instanceof Select)) {
            return;
         }

         final Select select = (Select)container;
         final Select.Item element =
            (Select.Item)e.getElement();

         for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
            i.hasNext();
            ) {
            
            final DeviceType aDeviceType = (DeviceType)i.next();
            
            final MutableTreeNode parent =
               (MutableTreeNode)nodes.get(aDeviceType, select);
               
            if (parent != null) {
               final int position =
                  getAddPosition(select.getItems(), parent, element);

               addElementToTree(aDeviceType, parent, position, element);
            }
         }
         
      }

      //------------------------------------------------------------------------

      public void elementRemoved(ElementContainerEvent e) {
         final Object container = e.getSource();
         final DeviceType deviceType = e.getDeviceType();

         if (!(container instanceof Select)) {
            return;
         }

         final Select.Item element =
            (Select.Item)e.getElement();

         removeElementFromTree(deviceType, element);
      }
   }

   //===========================================================================

   private final class ComponentGroupListener
      implements ElementContainerListener {

      public void elementAdded(ElementContainerEvent e) {
         final Object container = e.getSource();
         final DeviceType deviceType = e.getDeviceType();
         final InteractionElement element = e.getElement();

         if (!(container instanceof ComponentGroup)) {
            return;
         }

         final ComponentGroup g = (ComponentGroup)container;

         MutableTreeNode parent = (MutableTreeNode)nodes.get(deviceType, g);
         if (parent == null) {
            parent = new DefaultMutableTreeNode(element.toString());
            nodes.put(deviceType, g, parent);

            final MutableTreeNode groupNode =
               (MutableTreeNode)nodes.get(deviceType, COMPONENT_GROUPS);

            groupNode.insert(parent, groupNode.getChildCount());
         }

         int position =
            getAddPosition(g.getChildren(deviceType), parent, element);

         addElementToTree(deviceType, parent, position, element);
      }

      //------------------------------------------------------------------------

      public void elementRemoved(ElementContainerEvent e) {
         final Object container = e.getSource();
         final DeviceType deviceType = e.getDeviceType();
         final InteractionElement element = e.getElement();

         if (!(container instanceof ComponentGroup)) {
            return;
         }

         removeElementFromTree(deviceType, element);
      }

   }

   //===========================================================================

   private final class StateTreeModel extends DefaultTreeModel {
      public StateTreeModel(TreeNode root) {
         super(root);
      }

//      public boolean isLeaf(Object node) {
//         return node instanceof Control;
//      }
   }
}
