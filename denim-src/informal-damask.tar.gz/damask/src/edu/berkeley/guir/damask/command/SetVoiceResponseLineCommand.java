package edu.berkeley.guir.damask.command;

import java.awt.geom.Line2D;

import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that changes the bounds of an interaction element.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-09-2003 James Lin
 *                               Created UpdateBoundsCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-09-2003
 */
public class SetVoiceResponseLineCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final Control control;
   private final int condition;
   private final Line2D newLine;
   private final Line2D oldLine;

   /**
    * Constructs the command.
    * 
    * @param element the element whose bounds is to be updated
    * @param newBounds the new bounds of the element
    */
   public SetVoiceResponseLineCommand(
      final Control control,
      final int condition,
      final Line2D newLine) {
         
      this.control = control;
      this.condition = condition;
      this.newLine = newLine;
      oldLine = control.getVoiceResponseLine(condition);
   }


   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Set response line of " + control + " for condition " + condition +
         ": " + oldLine + "->" + newLine;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      control.setVoiceResponseLine(condition, newLine);
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      control.setVoiceResponseLine(condition, oldLine);
   }
}
