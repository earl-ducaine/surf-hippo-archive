package edu.berkeley.guir.damask.view.visual;

import java.awt.Color;
import java.awt.Paint;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.*;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.DamaskLayer.DeviceTypeLayer;
import edu.berkeley.guir.damask.view.visual.component.*;
import edu.berkeley.guir.damask.view.visual.dialog.PageView;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.awt.geom.Polygon2D;
import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolo.util.PPaintContext;


/** 
 * An arrow.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-19-2003 James Lin
 *                               Created Arrow.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 11-19-2003
 */
public class Arrow extends InteractionElementView {
   private static final Paint ORG_COLOR = Color.GRAY;
   private static final Paint NAV_COLOR = new Color(0, 153, 255);

   private final Map/*<PCamera, Boolean>*/ visible = new HashMap();
   
   private final ConnectionHandler connectionHandler = new ConnectionHandler();
   private final EndpointViewHandler endpointViewHandler =
      new EndpointViewHandler();
   private final ControlHandler controlHandler = new ControlHandler();
   private final PageRegionViewHandler pageRegionViewHandler =
      new PageRegionViewHandler();
   private final CameraHandler cameraHandler = new CameraHandler();
   
   private InteractionElementView sourceView;
   private PageView sourcePageView;

   private InteractionElementView destView;
   private PageView destPageView;

   public Arrow(final Connection connection) {
      super(connection);
      
      if (connection instanceof OrgConnection) {
         setStrokePaint(ORG_COLOR);
      }
      else {
         setStrokePaint(NAV_COLOR);
      }

      // Listen for the connection's events
      connection.addConnectionListener(connectionHandler);
      connection.addInteractionElementListener(connectionHandler);
   }


   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();

      // Listen for events from the view objects of the endpoints. This allows
      // for updating the arrow's shape as the user drags the endponts around.
      updateSourceView();
      updateDestView();

      updateShape();
      deviceTypeLayerChanged();
   }

   
   /**
    * Frees up any resources associated with this object. This should be called
    * <i>before</i> removing the arrow from its parent.
    */
   // Overrides method in parent class.
   public void dispose() {
      super.dispose();

      final Connection connection = (Connection)getModel();
      connection.removeConnectionListener(connectionHandler);
      connection.removeInteractionElementListener(connectionHandler);

      stopListeningToSourceView();
      stopListeningToDestView();
   }


   // Overrides method in parent class.
   public DeviceType getDeviceType() {
      final DamaskLayer layer = getLayer();
      if (layer != null) {
         return layer.getDeviceType();
      }
      else {
         return null;
      }
   }

   
   /**
    * Returns the view of the source of this arrow.
    */
   public InteractionElementView getSourceView() {
      return sourceView;
   }


   /**
    * Returns the view of the destination of this arrow.
    */
   public InteractionElementView getDestView() {
      return destView;
   }


   // Overrides method in parent class.
   protected void paint(PPaintContext paintContext) {
      // HACK so that voice empty responses do not show up in other
      // device types
      final ConnectionSource source = (sourceView == null) ? null : (ConnectionSource)sourceView.getModel();
      final ConnectionDest dest = (destView == null) ? null : (ConnectionDest)destView.getModel();
      
      boolean dontShow = false;
      if (source instanceof Trigger) {
         final Label label;
         if (sourceView instanceof Hyperlink) {
            label = ((Hyperlink)sourceView).getContent();
         }
         else {
            label = ((Button)sourceView).getContent();
         }
         dontShow |=
            label.isEmpty() && label.getDisplayMode() == Content.TEXT;
      }
      
      dontShow |= 
         source.getPage(getDeviceType()) == dest.getPage(getDeviceType());
         
      if (!dontShow) {
         super.paint(paintContext);
         DamaskAppUtils.drawArrowheads(this, paintContext);     
      }
   }


   /**
    * Updates the shape of the arrow based on the model.
    */
   protected void updateShape() {
      final Connection model = (Connection)getModel();
      
      setVisible(true);
      
      //HACK Make it work for arrows from template pane. This hack is
      // necessary because the model does not store the transform of the
      // template pane, making the global bounds of the source page in the
      // model incorrect.
      final GeneralPath newShape = model.getShape(getDeviceType()); 
      final Polygon2D newPoly =
         GeomLib.pathIteratorToPolygon2D(newShape.getPathIterator(null));
      
      if (((ConnectionSource)sourceView.getModel()).getDialog()
            instanceof TemplateDialog) {
         final PBounds sourceGlobalBds = sourceView.getBounds();
         sourceView.localToGlobal(sourceGlobalBds);
         
         setPathTo(new Line2D.Double(
                      sourceGlobalBds.getCenterX(),
                      sourceGlobalBds.getCenterY(),
                      newPoly.xpoints[newPoly.npoints - 1],
                      newPoly.ypoints[newPoly.npoints - 1]));
      }
      else {
         setPathTo(newShape);
      }
      setTransform(model.getTransform(getDeviceType()));
   }

   
   /**
    * Stops listening to the old source, and starts listening to the new
    * source.
    */
   protected void updateSourceView() {
      final DeviceType deviceType = getDeviceType();
      stopListeningToSourceView();

      final DamaskLayer layer = getLayer();
      
      final ConnectionSource newSource =
         ((Connection)getModel()).getConnectionSource(deviceType);
      
      if (newSource != null) {
         final List/*<InteractionElementView>*/ possibleViews =
            getLayer().getViews(newSource);
         sourceView = null;
         
         // The view must be either a ControlView or a PageView. There can only
         // be one PageView per page in a layer, but there could be multiple
         // ControlViews (e.g., a view of a template control). Therefore,
         // look for a ControlView whose parent matches its model's parent.
         for (Iterator i = possibleViews.iterator(); i.hasNext(); ) {
            final InteractionElementView possibleView =
               (InteractionElementView)i.next();

            if (possibleView instanceof PageView) {
               assert possibleViews.size() == 1;
               sourceView = possibleView;
               break;
            }
            else {
               final ControlView possibleControlView = (ControlView)possibleView;
               
               if (possibleControlView.getPageView().getModel()
                  == newSource.getPage(deviceType)) {
                  sourceView = possibleView;
                  break;
               }
            }
         }
         
         sourceView.addPropertyChangeListener(endpointViewHandler);

         if (newSource instanceof Control) {
            ((Control)newSource).addControlListener(controlHandler);
         }
         
         final Page newSourcePage = newSource.getPage(deviceType);
         if (newSourcePage != null && newSourcePage != newSource) {
            sourcePageView = (PageView)layer.getView(newSourcePage);
            sourcePageView.addPropertyChangeListener(endpointViewHandler);
         }
         else {
            sourcePageView = null;
         }
         
         if (newSourcePage != null && newSourcePage.isTemplate()) {
            for (Iterator i = layer.getCamerasReference().iterator();
               i.hasNext(); ) {

               final PCamera camera = (PCamera)i.next();
               camera.addPropertyChangeListener(
                  PNode.PROPERTY_BOUNDS,
                  cameraHandler);
               camera.addPropertyChangeListener(
                  PCamera.PROPERTY_VIEW_TRANSFORM,
                  cameraHandler);
            }
         }
      }
   }

   
   /**
    * Stops listening to the view of the source of this arrow.
    */
   private void stopListeningToSourceView() {
      if (sourceView != null) {
         final DamaskLayer layer = getLayer();
         sourceView.removePropertyChangeListener(endpointViewHandler);

         final InteractionElement source = sourceView.getModel();
         if (source instanceof Control) {
            ((Control)source).removeControlListener(controlHandler);
         }

         if (sourcePageView != null) {
            sourcePageView.removePropertyChangeListener(endpointViewHandler);
            
            if (((Page)sourcePageView.getModel()).isTemplate()) {
               for (Iterator i = layer.getCamerasReference().iterator();
                  i.hasNext(); ) {

                  final PCamera camera = (PCamera)i.next();
                  camera.removePropertyChangeListener(
                     PNode.PROPERTY_BOUNDS,
                     cameraHandler);
                  camera.removePropertyChangeListener(
                     PCamera.PROPERTY_VIEW_TRANSFORM,
                     cameraHandler);
               }
            }
         }
      }
   }


   /**
    * Stops listening to the old destination, and starts listening to the
    * new destination.
    */
   protected void updateDestView() {
      final DeviceType deviceType = getDeviceType();

      stopListeningToDestView();

      final ConnectionDest newDest =
         ((Connection)getModel()).getConnectionDest(deviceType);
      
      if (newDest != null) {
         destView = getLayer().getView(newDest); 
         destView.addPropertyChangeListener(endpointViewHandler);

         if (newDest instanceof Control) {
            ((Control)newDest).addControlListener(controlHandler);
         }
         

         final Page newDestPage = newDest.getPage(deviceType);
         if (newDestPage != null && newDestPage != newDest) {
            destPageView = (PageView)getLayer().getView(newDestPage); 
            destPageView.addPropertyChangeListener(endpointViewHandler);
         }
      }
   }


   /**
    * Stops listening to the view of the destination of this arrow.
    */
   private void stopListeningToDestView() {
      if (destView != null) {
         destView.removePropertyChangeListener(endpointViewHandler);
         
         final InteractionElement dest = destView.getModel();
         if (dest instanceof Control) {
            ((Control)dest).removeControlListener(controlHandler);
         }
         
         if (destPageView != null) {
            destPageView.removePropertyChangeListener(endpointViewHandler);
         }
      }
   }


   /**
    * Realign the arrow to match the source and destination's new locations.
    */
   public void reanchor() {
      final Connection connection = (Connection)getModel();
      final DeviceType deviceType = getDeviceType();
         
      final InteractionElementView sourceView = getSourceView();
      final InteractionElementView destView = getDestView();

      if ((sourceView == null) || (destView == null)) {
         setVisible(false);
         return;         
      }
      setVisible(true);
         
      final PBounds sourceGlobalBds = sourceView.getBounds();
      sourceView.localToGlobal(sourceGlobalBds);

      double fracX = connection.getSourceXAsWidthFraction(deviceType);
      //HACK Make it work for arrows from template pane. This hack is
      // necessary because the model does not store the transform of the
      // template pane, making the global bounds of the source page in the
      // model incorrect.
      if (fracX < 0 || fracX > 1) {
         fracX = 0.5;
      }
      final double startPointX =
         fracX * sourceGlobalBds.getWidth() + sourceGlobalBds.getX();
      double fracY = connection.getSourceYAsHeightFraction(deviceType);
      //HACK Make it work for arrows from template pane. This hack is
      // necessary because the model does not store the transform of the
      // template pane, making the global bounds of the source page in the
      // model incorrect.
      if (fracY < 0 || fracY > 1) {
         fracY = 0.5;
      }
      final double startPointY =
         fracY * sourceGlobalBds.getHeight() + sourceGlobalBds.getY();

      final PBounds destGlobalBds = destView.getBounds();
      destView.localToGlobal(destGlobalBds);
         
      final double endPointX =
         connection.getDestXAsWidthFraction(deviceType)
            * destGlobalBds.getWidth()
            + destGlobalBds.getX();
         
      final double endPointY =
         connection.getDestYAsHeightFraction(deviceType)
            * destGlobalBds.getHeight()
            + destGlobalBds.getY();
         
      setPathTo(
         new Line2D.Double(
            startPointX, startPointY, endPointX, endPointY));
   }


   /**
    * Returns whether this arrow is visible to the specified camera.
    */
   public boolean isVisibleToCamera(final PCamera camera) {
      final Boolean result = (Boolean)visible.get(camera);
      if (result == null) {
         return true;
      }
      else {
         return result.booleanValue();
      }
   }

   /**
    * Sets whether this arrow is visible to the specified camera.
    */
   public void setVisibleToCamera(final PCamera camera, final boolean isVisible) {
      visible.put(camera, Boolean.valueOf(isVisible));
   }

   // Overrides method in parent class.   
   public void fullPaint(PPaintContext paintContext) {
      if (isVisibleToCamera(paintContext.getCamera())) {
         super.fullPaint(paintContext);
      }
   }

   
   /**
    * Adjusts the transparency of this arrow, depending on
    * what its device type is and what the current device-type layer is. 
    */
   public void deviceTypeLayerChanged() {
      final Connection connection = (Connection)getModel();
      final DeviceTypeLayer deviceTypeLayer = getLayer().getDeviceTypeLayer();
      
      if ((connection.isForAllDeviceTypes()
         && (deviceTypeLayer == DeviceTypeLayer.ALL))

         || (!connection.isForAllDeviceTypes()
            && connection.isVisibleToDeviceType(getDeviceType())
            && (deviceTypeLayer == DeviceTypeLayer.DEVICE))) {

         DamaskAppUtils.setInternalColorAlpha(
            this, DamaskLayer.THIS_LAYER_ALPHA);
      }
      else {
         DamaskAppUtils.setInternalColorAlpha(
            this, DamaskLayer.OTHER_LAYER_ALPHA);
      }
   }


   /**
    * Handles events from the arrow's model object. 
    */
   private class ConnectionHandler
      implements InteractionElementListener, ConnectionListener {
         
      public void elementBoundsUpdated(InteractionElementEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            updateShape();
         }
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            updateShape();
         }
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }

      public void sourceChanged(ConnectionEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            updateSourceView();
            updateShape();
         }
      }

      public void destChanged(ConnectionEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            updateDestView();
            updateShape();
         }
      }

      public void shapeChanged(ConnectionEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            updateShape();
         }
      }

      public void userEventChanged(ConnectionEvent e) {
      }

      public void conditionChanged(ConnectionEvent e) {
      }
   }


   /**
    * Handles events from the view objects of the arrow's endpoints. 
    */
   private class EndpointViewHandler implements PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent evt) {
         if (evt.getPropertyName().equals(PNode.PROPERTY_BOUNDS)
            || evt.getPropertyName().equals(PNode.PROPERTY_TRANSFORM)) {
            reanchor();
         }
         else if (evt.getPropertyName().equals(PNode.PROPERTY_PARENT)) {
            reanchor();
         }
      }
   }


   /**
    * Handles events from the view objects of the arrow's endpoints. 
    */
   private class CameraHandler implements PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent evt) {
         reanchor();
      }
   }
   
   
   /**
    * Handles events from the source and destination of the arrow's model if
    * they are controls.
    */ 
   private class ControlHandler implements ControlListener {
      // @Override
      public void controlStateChanged(ControlEvent e) {
      }

      // @Override
      public void controlSignificanceChanged(ControlEvent e) {
      }

      // @Override
      public void pageRegionChanged(ControlEvent e) {
         final DeviceType deviceType = getDeviceType();
         if (e.getDeviceType() == deviceType) {
            final Connection connection = (Connection)getModel();
            final Control control = e.getControl();
            final PageRegion pageRegion = control.getPageRegion(deviceType);
            if (control == connection.getConnectionSource(deviceType)) {
               if (pageRegion == null) {
                  stopListeningToSourceView();
               }
               else {
                  getLayer().getView(pageRegion).addPropertyChangeListener(
                     PNode.PROPERTY_CHILDREN, pageRegionViewHandler);
               }
            }
            else if (control == connection.getConnectionDest(deviceType)) {
               if (pageRegion == null) {
                  stopListeningToDestView();
               }
               else {
                  getLayer().getView(pageRegion).addPropertyChangeListener(
                     PNode.PROPERTY_CHILDREN,
                     pageRegionViewHandler);
               }
            }
         }
      }
   }
   

   /**
    * Handles events from a page region view.
    */ 
   private class PageRegionViewHandler implements PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent e) {
         ((PNode)e.getSource()).removePropertyChangeListener(
            PNode.PROPERTY_CHILDREN, pageRegionViewHandler);
         updateSourceView();
         updateDestView();
      }
   }
}
