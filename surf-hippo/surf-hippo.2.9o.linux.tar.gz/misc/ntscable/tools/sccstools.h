	/*-------------------------------------------------------------
	|			
	|	MODULE:   %W%
	|				
	|	MACHINE:  UNIX                 
	|					
	|	STARTED:  10-OCT-90  BY:  J.C. Wathey 
	|			
	|	REVISED:  %G%   BY:  JCW
	|				
	|	STATUS:      incomplete or untested		
	|                    compiles; partly tested	
	|                 -> runs; revisions in progress
	|                    runs; stable version
	|					
	|       CONTAINS: macros, definitions and declarations for
	|		  sccs  tools
	|                                     
	-------------------------------------------------------------*/

char  * sccs_what(),
      * latest_sccs_version();
