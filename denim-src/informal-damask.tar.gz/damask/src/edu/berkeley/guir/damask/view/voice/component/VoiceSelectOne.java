package edu.berkeley.guir.damask.view.voice.component;

import edu.berkeley.guir.damask.component.SelectOne;
import edu.berkeley.guir.damask.view.voice.ResponseInternalDest;
import edu.berkeley.guir.damask.view.voice.ResponseSource;
import edu.berkeley.guir.damask.view.voice.dialog.Conversation;

/** 
 * A view of a select-one control.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  08-15-2004 James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public class VoiceSelectOne extends VoiceControl {

   /**
    * Constructs a view of the specified select-one control.
    */
   public VoiceSelectOne(final SelectOne model) {
      super(model);
   }

   
   // @Override
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      final Conversation conversation = getConversation();
      
      setResponse(
         0,
         new Response(
            this,
            (ResponseSource)conversation.getPreviousVoiceControlWithPrompt(this),
            (ResponseInternalDest)
               conversation.getNextVoiceControlWithPrompt(this)));
   }
}
