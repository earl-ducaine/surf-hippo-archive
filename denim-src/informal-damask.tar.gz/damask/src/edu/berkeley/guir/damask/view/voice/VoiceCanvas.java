package edu.berkeley.guir.damask.view.voice;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.geom.Point2D;
import java.util.*;
import java.util.List;
import java.util.logging.Logger;

import javax.swing.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.Direction;
import edu.berkeley.guir.damask.command.RemoveDialogCommand;
import edu.berkeley.guir.damask.command.SetHomePageCommand;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.DamaskDocument.DamaskCanvasGroup;
import edu.berkeley.guir.damask.view.appevent.CanvasEvent;
import edu.berkeley.guir.damask.view.appevent.CanvasListener;
import edu.berkeley.guir.damask.view.event.EraserEventHandler;
import edu.berkeley.guir.damask.view.event.StyledTextEventHandler;
import edu.berkeley.guir.damask.view.nodes.DamaskWindowTitle;
import edu.berkeley.guir.damask.view.nodes.NonResizableHandle;
import edu.berkeley.guir.damask.view.visual.component.Label;
import edu.berkeley.guir.damask.view.voice.component.*;
import edu.berkeley.guir.damask.view.voice.dialog.Form;
import edu.berkeley.guir.damask.view.voice.event.*;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PInputEventListener;
import edu.umd.cs.piccolox.handles.PBoundsHandle;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * The canvas in which the designer creates his or her speech design.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-14-2004 James Lin
 *                               Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 07-14-2004
 */
public class VoiceCanvas extends DamaskCanvas {

   // Logger
   private static final Logger logger =
      Logger.getLogger(DamaskCanvas.class.getName());

   // Constants for mode names
   public static final String DRAW_MODE = "Draw";
   public static final String ERASER_MODE = "Eraser";
   
   // Piccolo event mode and handlers
   private final VoiceTextHandler formTitleHandler = new VoiceTextHandler();
   private PInputEventListener appModeHandler = null;
   private StyledTextEventHandler activeTextHandler = null;
   
   // Actions for menu items
   private final Action cutFormAction = new CutFormAction();
   private final Action copyFormAction = new CopyFormAction();
   private final Action pasteFormAction = new PasteFormAction();
   private final Action deleteFormAction = new DeleteFormAction();
   private final Action setHomeFormAction = new SetHomeFormAction();
   private final Action runFromHomeAction = new RunFromHomeAction();
   private final Action runFromSelectedPageAction =
      new RunFromSelectedPageAction();

   // Pop up menus
   private final JPopupMenu formPopupMenu = new JPopupMenu();

   /**
    * Creates the canvas.
    * 
    * @param group the canvas group this canvas belongs to
    * @param deviceType the device type from which perspective to display
    * the document
    */
   public VoiceCanvas(
      final DamaskCanvasGroup group,
      final DeviceType deviceType) {
         
      this(group, deviceType, 1.0);
   }
      
   /**
    * Creates the canvas.
    * 
    * @param group the canvas group this canvas belongs to
    * @param deviceType the device type from which perspective to display
    * the document
    * @param pageTitleScale the scale at which page titles should be drawn 
    */
   public VoiceCanvas(
      final DamaskCanvasGroup group,
      final DeviceType deviceType,
      final double pageTitleScale) {
      
      super(group, deviceType, pageTitleScale);


      // Listen to changes in my own selection
      addCanvasListener(new SelectionChangeHandler());
      
      final Cursor eraserCursor =
         DamaskAppUtils.createCursor(
            "eraser.gif",
            new Point(0, 0),
            ERASER_MODE);

      final PInputEventListener eraserHandler = new EraserEventHandler();
      
      addMode(
         new VoiceMode(
            ERASER_MODE,
            null,
            null,
            eraserHandler,
            eraserHandler,
            eraserHandler,
            
            null,
            null,
            eraserCursor,
            eraserCursor,
            eraserCursor));
      
      addMode(
         new VoiceMode(
            DRAW_MODE,
            new InsertFormHandler(),
            new InsertPromptHandler(),
            new DragFromPromptHandler(),
            new ResponseTextHandler(),
            new DragResponseHotSpotHandler(),
            
            DamaskAppUtils.createCursor(
               "page.gif",
               new Point(0, 0),
               "Page"),
            Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR),
            Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR),
            Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR),
            Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR)));
      
      // Initialize pop up menus
      runFromHomeAction.setEnabled(
         !getDocument().getGraph().getDialogs(getDeviceType()).isEmpty());
      runFromSelectedPageAction.setEnabled(false);
      
      {
         formPopupMenu.add(new JMenuItem(cutFormAction));
         formPopupMenu.add(new JMenuItem(copyFormAction));
         formPopupMenu.add(new JMenuItem(getPasteAction()));
         formPopupMenu.add(new JMenuItem(deleteFormAction));
         formPopupMenu.add(new JSeparator());
         formPopupMenu.add(new JMenuItem(setHomeFormAction));
         formPopupMenu.add(new JSeparator());
         final JMenuItem runFromThisPageItem =
            new JMenuItem(getRunFromSelectedPageAction());
         runFromThisPageItem.setText("Run From This Form");
         runFromThisPageItem.setMnemonic(KeyEvent.VK_R);
         formPopupMenu.add(runFromThisPageItem);
      }
   }


   // @Override
   public DamaskAppMode getSelectionAppMode() {
      return new VoiceMode(
         SELECTION_MODE,
         getSelectionEventHandler(),
         getSelectionEventHandler(),
         getSelectionEventHandler(),
         new DragResponseTextHandler(),
         new DragResponseHotSpotHandler(),
         
         null,
         null,
         Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR),
         Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR),
         Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
   }

   
   /**
    * Enables or disables the current mode's event handler. If the event
    * handler is being enabled, then the current handler is chosen depending
    * on whether the mouse cursor is currently over a page, a control, or
    * the background. 
    */
   protected void setModeEventHandlerEnabled(final boolean flag) {
      final PNode insideNode = getInsideNode();
      
      final DamaskAppMode appMode = getMode();
      if (!(appMode instanceof VoiceMode)) {
         super.setModeEventHandlerEnabled(flag);
         return;
      }
      
      final VoiceMode voiceMode = (VoiceMode)appMode;
      if (flag) {
         Cursor cursorToUse;
         if ((insideNode instanceof Form.Contents)
            || (insideNode instanceof DamaskWindowTitle)
            || (insideNode instanceof VoiceControl)) {
            appModeHandler = voiceMode.getFormHandler();
            cursorToUse = voiceMode.getFormCursor();
         }
         else if (insideNode instanceof Prompt) {
            appModeHandler = voiceMode.getPromptHandler();
            cursorToUse = voiceMode.getPromptCursor();
         }
         else if (insideNode instanceof Response.TextGroup) {
            appModeHandler = voiceMode.getResponseTextHandler();
            cursorToUse = voiceMode.getResponseTextCursor();
         }
         else if (insideNode instanceof Response.HotSpot) {
            appModeHandler = voiceMode.getResponseHotSpotHandler();
            cursorToUse = voiceMode.getResponseHotSpotCursor();
         }
         else if (insideNode instanceof Label) {  // form title
            final Label componentView = (Label)insideNode;
            
            cursorToUse = null;
            
            if (appMode.getName() == DRAW_MODE) {
               if (componentView.getParent() instanceof DamaskWindowTitle) {
                  final Object contents = componentView.getEditableContents();
                  if (((Label)contents).getDisplayMode() == Content.TEXT) {
                     appModeHandler = formTitleHandler;
                     cursorToUse =
                        Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR);
                  }
               }
            }
         }
         else if (insideNode instanceof Response) {
            cursorToUse = voiceMode.getFormCursor();
         }
         else if (insideNode == null) {
            appModeHandler = voiceMode.getDefaultHandler();
            if ((insideNode instanceof PBoundsHandle)
               && !(insideNode instanceof NonResizableHandle)) {
               final PBoundsHandle handle = ((PBoundsHandle)insideNode);
               cursorToUse =
                  handle.getCursorFor(
                     ((PBoundsLocator)handle.getLocator()).getSide());
            }
            else {
               cursorToUse = appMode.getDefaultCursor();
            }
         }
         else {
            appModeHandler = null;
            cursorToUse = null;
         }

         if (appModeHandler != null) {
            addInputEventListener(appModeHandler);
         }
         setCursor(cursorToUse);
      }
      else {
         if (appModeHandler != null) {
            removeInputEventListener(appModeHandler);
         }
         setCursor(null);
      }
   }

   
   /**
    * Sets the text handler which is actively handling text from the user.
    */
   public void setActiveTextHandler(final StyledTextEventHandler handler) {
      stopTextEditing();
      activeTextHandler = handler;
   }


   /**
    * Stops any text editing in progress.
    */
   public void stopTextEditing() {
      if (activeTextHandler != null) {
         activeTextHandler.stopEditing();
         activeTextHandler = null;
      }
   }
   

   // @Override
   public PageRegion getPasteTargetPageRegion() {
      final Form form = getSelectedForm();
      if (form == null) {
         return null;
      }
      else {
         // Always put the new content on a new "page"
         final Page lastPage =
            ((Dialog)form.getModel()).getLastPage(getDeviceType()); 
         final Page pageForPastedContent;
         if (lastPage.getRegion(Direction.CENTER).getControls().isEmpty()) {
            pageForPastedContent = lastPage;
         }
         else {
            pageForPastedContent = lastPage.split(Collections.EMPTY_LIST);
         }
         return pageForPastedContent.getRegion(Direction.CENTER);
      }
   }


   /**
    * Returns the form that the user is interacting with.
    */
   public Form getSelectedForm() {
      return (Form)getCurrentWindow();
   }


   // @Override
   public Page getSelectedPage() {
      final Form form = getSelectedForm();
      if (form == null) {
         return null;
      }
      else {
         return ((Dialog)form.getModel()).getFirstPage(getDeviceType());
      }
   }
   
   // @Override
   protected Page getDropTarget(final Point2D layerDropPt) {
      //TODO complete getDropTarget
      return null;
   }

   
   /**
    * Returns the proper pop-up context menu, depending on what objects
    * are currently selected.
    */
   public JPopupMenu getPopupMenu(
      final PNode pickedNode,
      final boolean isPickedNodeSelectable) {

      if (!isPickedNodeSelectable) {
         if ((pickedNode instanceof Form.Contents) ||
             (pickedNode instanceof DamaskWindowTitle)) {
            return formPopupMenu;
         }
         else {
            return super.getPopupMenu(pickedNode, isPickedNodeSelectable);
         }
      }
      else {
         return super.getPopupMenu(pickedNode, isPickedNodeSelectable);
      }
   }
   
   /**
    * Returns the action that copies the selected page into the clipboard.
    */
   public Action getCopyPageAction() {
      return copyFormAction;
   }

   /**
    * Returns the action that cuts the selected page into the clipboard.
    */
   public Action getCutPageAction() {
      return cutFormAction;
   }

   /**
    * Returns the action that deletes the selected page.
    */
   public Action getDeletePageAction() {
      return deleteFormAction;
   }

   /**
    * Returns the action that pastes the contents of the clipboard if the
    * contents contain a page.
    */
   public Action getPastePageAction() {
      return pasteFormAction;
   }

   /**
    * Returns the action that sets the home page to the selected page.
    */
   public Action getSetHomePageAction() {
      return setHomeFormAction;
   }

   /**
    * Returns the action that runs the design from the home page.
    */
   //@Override
   public Action getRunFromHomeAction() {
      return runFromHomeAction;
   }

   /**
    * Returns the action that runs the design from the selected page.
    */
   //@Override
   public Action getRunFromSelectedPageAction() {
      return runFromSelectedPageAction;
   }

   
   /**
    * Listens for cut form actions.
    */
   private class CutFormAction extends AbstractAction {
      public CutFormAction() {
         super("Cut Form");
         putValue(SHORT_DESCRIPTION, "Cuts the selected form into the clipboard");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_T));
      }
      
      public void actionPerformed(ActionEvent e) {
         getCopyPageAction().actionPerformed(e);
         getDeletePageAction().actionPerformed(e);
      }
   }


   /**
    * Listens for copy form actions.
    */
   private class CopyFormAction extends AbstractAction {
      public CopyFormAction() {
         super("Copy Form");
         putValue(SHORT_DESCRIPTION, "Copies the selected form into the clipboard");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_C));
      }
      
      public void actionPerformed(ActionEvent e) {
         logger.info("Begin copy form");
         final List/*<Form>*/ selectedFormList =
            new ArrayList/*<Form>*/();
         selectedFormList.add(getSelectedForm());
         setObjectsToCopy(selectedFormList);
         final TransferHandler handler = getTransferHandler();
         handler.exportToClipboard(
            VoiceCanvas.this,
            Toolkit.getDefaultToolkit().getSystemClipboard(),
            TransferHandler.COPY);
         getPasteAction().setEnabled(true);
         logger.info("End copy form");
      }
   }


   /**
    * Listens for paste form actions.
    */
   private class PasteFormAction extends AbstractAction {
      public PasteFormAction() {
         super("Paste Form");
         putValue(SHORT_DESCRIPTION, "Pastes the contents of the clipboard");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_P));
      }
      
      public void actionPerformed(ActionEvent e) {
         logger.info("Begin paste form");
         final Clipboard clipboard =
            Toolkit.getDefaultToolkit().getSystemClipboard();
         final Transferable clipData = clipboard.getContents(this);
         if (clipData != null) {
            final TransferHandler handler =
               getTransferHandler();
            if (handler
               .canImport(VoiceCanvas.this, clipData.getTransferDataFlavors())) {
               handler.importData(VoiceCanvas.this, clipData);
            }
         }
         logger.info("End paste form");
      }
   }


   /**
    * Listens for delete form actions.
    */
   private class DeleteFormAction extends AbstractAction {
      public DeleteFormAction() {
         super("Delete Form");
         putValue(SHORT_DESCRIPTION, "Deletes the selected form");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_D));
      }
      
      public void actionPerformed(ActionEvent e) {
         getDocument().getCommandQueue().doCommand(VoiceCanvas.this,
            new RemoveDialogCommand(
               ((Dialog)getSelectedForm().getModel())));
      }
   }


   /**
    * Listens for set home form actions.
    */
   private class SetHomeFormAction extends AbstractAction {
      public SetHomeFormAction() {
         super("Set as Home Form");
         putValue(SHORT_DESCRIPTION, "Sets the selected form as the home form");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_H));
      }
      
      public void actionPerformed(ActionEvent e) {
         final DamaskLayer layer = (DamaskLayer)getLayer();
         getDocument().getCommandQueue().doCommand(VoiceCanvas.this,
            new SetHomePageCommand(
               layer.getDocument().getGraph(),
               layer.getDeviceType(),
               getSelectedPage()));
         // Since the selected page is now the home page, we can
         // disable this command
         setEnabled(false);
      }
   }


   /**
    * Listens for run actions.
    */
   private class RunFromHomeAction extends AbstractAction {
      public RunFromHomeAction() {
         super("Run from Home Form");
         putValue(SHORT_DESCRIPTION, "Runs this document");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_H));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("run_from_home.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("run_from_home.png"));
      }

      public void actionPerformed(ActionEvent e) {
         final DamaskLayer layer = (DamaskLayer)getLayer();
         final DamaskDocument document = layer.getDocument();
         final DeviceType deviceType = layer.getDeviceType();
         final Page homePage = document.getGraph().getHomePage(deviceType);

         final VoicePreview voicePreview =
            new VoicePreview(
               VoiceCanvas.this,
               document.getDisplayedFileName(),
               homePage.getDialog());
         voicePreview.go();
      }
   }

   
   /**
    * Listens for run from selected form actions.
    */
   private class RunFromSelectedPageAction extends AbstractAction {
      public RunFromSelectedPageAction() {
         super("Run from Selected Form");
         putValue(SHORT_DESCRIPTION, "Runs this document from the selected form");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_S));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("run.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("run.png"));
      }

      public void actionPerformed(ActionEvent e) {
         final DamaskLayer layer = (DamaskLayer)getLayer();
         final DamaskDocument document = layer.getDocument();
         final Page selectedPage = getSelectedPage();
         final VoicePreview voicePreview =
            new VoicePreview(
               VoiceCanvas.this,
               document.getDisplayedFileName(),
               selectedPage.getDialog());
         voicePreview.go();
      }
   }

   
   // Selection change methods ------------------------------------------

   /**
    * Handles changes what objects are selected on this canvas.
    */
   private class SelectionChangeHandler implements CanvasListener {
      public void selectionChanged(CanvasEvent e) {
      }

      public void selectedPageChanged(CanvasEvent e) {
         assert e.getCanvas() == VoiceCanvas.this :
            "should be receiving events from " +
            VoiceCanvas.this + ", not " + e.getCanvas();

         final boolean hasSelectedPage = (getSelectedForm() != null);
//         if (hasSelectedPage) {
//            final boolean isSelectedPageHome =
//               (getDocument().getGraph().getHomePage(getDeviceType())
//                  == getSelectedForm().getModel());
//            setHomePageAction.setEnabled(!isSelectedPageHome);
//         }
//         else {
//            setHomePageAction.setEnabled(false);
//         }

         getRunFromSelectedPageAction().setEnabled(hasSelectedPage);
      }
   }   
}
