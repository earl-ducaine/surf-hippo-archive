//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Like a WeakHashMap, except that it's a set.
 * <P>
 * I've found this class to be useful when implementing circularly-referenced
 * objects. The reason is that you want to be able to notify a bunch of 
 * objects, which means you need to have a reference to the objects. However, 
 * you don't want the notified objects to hang around if you are the only 
 * object to have a reference to them. Hence a weak reference, or more 
 * specifically, a set of weak references.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Apr 09 2002 JIH
 */
public class WeakHashSet
   extends    AbstractSet
   implements Set, Cloneable, java.io.Serializable {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   Map map = new WeakHashMap();

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================




   //===========================================================================
   //===   SET METHODS   =======================================================

   public boolean add(Object obj) {
      return (map.put(obj, Boolean.TRUE) == null);
   } // of method

   //------------------------------------------------------------------

   public boolean remove(Object obj) {
      return (map.remove(obj) == Boolean.TRUE);
   } // of method

   //------------------------------------------------------------------

   public void clear() {
      map.clear();
   } // of method

   //------------------------------------------------------------------

   public boolean isEmpty() {
      return (map.isEmpty());
   } // of method

   //------------------------------------------------------------------

   public int size() {
      return (map.size());
   } // of method

   //------------------------------------------------------------------

   public boolean contains(Object obj) {
      return (map.containsKey(obj));
   } // of method

   //------------------------------------------------------------------

   public Iterator iterator() {
      return (map.keySet().iterator());
   } // of method

   //===   SET METHODS   =======================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Make a shallow clone.
    */
   public Object clone() {
      try {
         WeakHashSet s = (WeakHashSet) super.clone();
         s.map         = new WeakHashMap();

         Iterator it = map.keySet().iterator();
         while (it.hasNext()) {
            s.add(it.next());
         }

         return (s);
      }
      catch (CloneNotSupportedException e) {
         //// Oops, you're in trouble
         throw new InternalError();
      }
   } // of method

   //===   CLONE METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   SERIALIZATION METHODS   =============================================

   /**
    * Modified from HashSet.java.
    */
   private synchronized void writeObject(java.io.ObjectOutputStream s)
      throws java.io.IOException {

      // Write out any hidden serialization magic
      s.defaultWriteObject();

      // Write out size
      s.writeInt(map.size());

      // Write out all elements in the proper order.
      for (Iterator i=map.keySet().iterator(); i.hasNext(); ) {
         s.writeObject(i.next());
      }
   } // of method

   //------------------------------------------------------------------

   /**
    * Modified from HashSet.java.
    */
   private synchronized void readObject(java.io.ObjectInputStream s)
      throws java.io.IOException, ClassNotFoundException {
      // Read in any hidden serialization magic
      s.defaultReadObject();

      // Read in HashMap capacity and load factor and create backing HashMap
      map = new WeakHashMap();

      // Read in size
      int size = s.readInt();

      // Read in all elements in the proper order.
      for (int i=0; i<size; i++) {
         Object e = s.readObject();
         map.put(e, Boolean.TRUE);
      }
   } // of method

   //===   SERIALIZATION METHODS   =============================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
