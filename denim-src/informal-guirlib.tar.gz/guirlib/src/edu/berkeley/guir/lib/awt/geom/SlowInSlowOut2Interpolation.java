//// See bottom of source code for software license
package edu.berkeley.guir.lib.awt.geom;

/**
 * Testing new slow-in-slow-out functions, from subArctic and artkit.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
public class SlowInSlowOut2Interpolation 
   extends Interpolation {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   double bounds;
   double percentTimeAtBounds;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public SlowInSlowOut2Interpolation() {
      this(0.2, 0.4);
   } // of default constructor

   //===========================================================================

   /**
    *
    * @param bounds represents two values: the percent of slow-in frames 
    *               (bounds), and the percent of slow-out frames (1 - bounds).
    *               Thus, the number of normal frames is (1 - 2*bounds), and
    *               the value of bounds must be &lt;= 0.5.
    * @param val    represents the percent of physical time spent during
    *               the slow-in and slow-out frames. This value must also
    *               be &lt;= 0.5.
    */
   public SlowInSlowOut2Interpolation(double bounds, double val) {
      if (bounds < 0.0 || bounds > 0.5) {
         throw new IllegalArgumentException("Value for bounds outside range");
      }
      if (val < 0.0 || val > 0.5) {
         throw new IllegalArgumentException("Bounds value outside range");
      }

      this.bounds              = bounds;
      this.percentTimeAtBounds = val;

   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   INTERPOLATION   =====================================================

   public double 
   interpolate(double startValue, double endValue, int current, int total) {

      //// 0. Bounds checking.
      if (current >= total) {
         return (endValue);
      }
      if (current < 0) {
         return (startValue);
      }

      //// 1. Calculate the transition value.
      double t  = (double) current / (double) total;
      double ds;
      double dv = endValue - startValue;

      //// 1.1. Calculate slow-out value...
      if (t < bounds) {
         ds = t * percentTimeAtBounds / bounds;
      }
      //// 1.2. Calculate slow-in value...
      else if (t > 1.0 - bounds) {
         ds = (1.0 - percentTimeAtBounds) +
              (t - (1 - bounds)) * percentTimeAtBounds / bounds;
      }
      //// 1.3. Otherwise calculate normal value...
      else {
         ds = percentTimeAtBounds + 
              (t - bounds) * (1 - 2*percentTimeAtBounds) / (1 - 2*bounds);
      }

      return (startValue + ds*dv);
   } // of interpolate

   //===   INTERPOLATION   =====================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) {
      Interpolation interp = new SlowInSlowOut2Interpolation();
      System.out.println(interp.interpolate(0, 1, 0, 10));
      System.out.println(interp.interpolate(0, 1, 1, 10));
      System.out.println(interp.interpolate(0, 1, 2, 10));
      System.out.println(interp.interpolate(0, 1, 3, 10));
      System.out.println(interp.interpolate(0, 1, 4, 10));
      System.out.println(interp.interpolate(0, 1, 5, 10));
      System.out.println(interp.interpolate(0, 1, 6, 10));
      System.out.println(interp.interpolate(0, 1, 7, 10));
      System.out.println(interp.interpolate(0, 1, 8, 10));
      System.out.println(interp.interpolate(0, 1, 9, 10));

      System.out.println();
      System.out.println(interp.interpolate(0, 1, 0,  20));
      System.out.println(interp.interpolate(0, 1, 1,  20));
      System.out.println(interp.interpolate(0, 1, 2,  20));
      System.out.println(interp.interpolate(0, 1, 3,  20));
      System.out.println(interp.interpolate(0, 1, 4,  20));
      System.out.println(interp.interpolate(0, 1, 5,  20));
      System.out.println(interp.interpolate(0, 1, 6,  20));
      System.out.println(interp.interpolate(0, 1, 7,  20));
      System.out.println(interp.interpolate(0, 1, 8,  20));
      System.out.println(interp.interpolate(0, 1, 9,  20));
      System.out.println(interp.interpolate(0, 1, 10, 20));
      System.out.println(interp.interpolate(0, 1, 11, 20));
      System.out.println(interp.interpolate(0, 1, 12, 20));
      System.out.println(interp.interpolate(0, 1, 13, 20));
      System.out.println(interp.interpolate(0, 1, 14, 20));
      System.out.println(interp.interpolate(0, 1, 15, 20));
      System.out.println(interp.interpolate(0, 1, 16, 20));
      System.out.println(interp.interpolate(0, 1, 17, 20));
      System.out.println(interp.interpolate(0, 1, 18, 20));
      System.out.println(interp.interpolate(0, 1, 19, 20));
      System.out.println(interp.interpolate(0, 1, 20, 20));
   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
