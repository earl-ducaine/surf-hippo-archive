/*
 * RemoteIncomingSocket.java
 * Created on November 6, 2001, 3:33 PM
 */

package edu.berkeley.guir.lib.satin.remote;

import java.io.*;
import java.net.*;

/**
 * @author  Scott Klemmer, Katie Everitt
 * @version 1.3
*/
public class RemoteIncomingSocket extends Thread {
   private RemoteSocketMgr m_manager      = null;
       
   private int             m_port         = -1;
   private ServerSocket    m_inSocket     = null;
   private Socket          m_inConnection = null;
   private BufferedReader  m_in           = null;
   private PrintWriter     m_inEcho       = null;   
       
       
   /** Creates new GRemoteIncomingSocket */
   public RemoteIncomingSocket(RemoteSocketMgr manager,int port_num) {
      m_manager = manager;
      m_port = port_num;
      start();
   }


   private void establishConnection() {
      try {
         System.out.println("RemoteIncomingSocket: waiting for connection");
         System.out.println("RemoteINSocket: Waiting on " + m_port);
         m_inConnection = m_inSocket.accept();
         System.out.println("RemoteIncomingSocket: Connection Established.");
      } catch (IOException e) {
         System.out.println("GRemoteIncomingSocket: Connection Failed.");
      }

      try {
         m_in = new BufferedReader(new InputStreamReader(m_inConnection.getInputStream()));
      } catch (IOException e) {
         System.out.println("GRemoteIncomingSocket: Failed to create InputStream (Response Echo).");
      }

      try{
         m_inEcho = new PrintWriter(m_inConnection.getOutputStream(), true);
      } catch (UnknownHostException e) {
         System.out.println("RemoteIncomingSocket: Unknown host - localhost");
      } catch (IOException e) {
         System.out.println("RemoteIncomingSocket: Failed to create OutputStream.");
      }
           
   }
    
   public void run() {
      try {
         m_inSocket = new ServerSocket(m_port);
      } catch (IOException e) {
         System.out.println("Failed to Create IncomingSocket");
         System.exit(-1);
      }

      while (true) {
         if (m_inConnection == null) {
            //if we haven't made a connection
               establishConnection();
         } else {
            // we have a connection already
            try {
					System.out.println("Incoming: blocking until data...");
               //m_in will block until data is available
               String s = m_in.readLine();
               if (s != null) {
                  IOEvent rEvent = new IOEvent(s, m_port);
                  System.out.println("RemoteIncomingSocket: Received incoming event " + rEvent.toString() + "...");
                  m_manager.postIncomingEvent(rEvent);
                  m_inEcho.println("<THANKS>");
               } else {
                  try { Thread.sleep(100); } catch (InterruptedException e) { }
               }
            } catch (IOException e) {
               System.out.println("RemoteIncomingSocket: Connection lost...\n");
               try {
                  //m_manager.notifySocketClosed();
                  m_inConnection.close();
                  m_inConnection = null;
               } catch (IOException e2) {
               }
            }
         }   
      }
   }
}