/*
 * Copyright (C) 2003 by the Regents of the University of California.
 *  
 * Copyright (C) 2002-2003 by University of Maryland, College Park, MD 20742 
 * All rights reserved. 
 * 
 * This code is based on code in Piccolo.
 * 
 * Piccolo was written at the Human-Computer Interaction Laboratory 
 * www.cs.umd.edu/hcil by Jesse Grosjean under the supervision of Ben Bederson. 
 * The Piccolo website is www.cs.umd.edu/hcil/piccolo 
 */
package edu.berkeley.guir.damask.view.event;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.border.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.*;

import edu.berkeley.guir.damask.view.DamaskCanvas;
import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolox.nodes.PStyledText;

/**
 * Provides standard interaction for editing
 * {@see edu.umd.cs.piccolox.nodes.PStyledText}. This class
 * is the same as {@see edu.umd.cs.piccolox.event.PStyledTextEventHandler},
 * except that the constructor does not take a canvas parameter.
 * 
 * @author Lance Good
 * @author James Lin
 */
public class StyledTextEventHandler extends PBasicInputEventHandler {

   protected PCanvas canvas;
   protected JTextComponent editor;
   protected DocumentListener docListener;
   protected PStyledText editedText;

   /**
    * Basic constructor for PStyledTextEventHandler
    */
   public StyledTextEventHandler() {
      super();
      this.editor = createDefaultEditor();
   }

   /**
    * Constructor for PStyledTextEventHandler that allows an editor to be specified
    */
   public StyledTextEventHandler(JTextComponent editor) {
      super();
      this.editor = editor;
   }

   /**
    * Returns the text component being used as an editor for styled text.
    */
   public JTextComponent getEditor() {
      return editor;
   }

   protected void initEditor() {
      canvas.setLayout(null);
      canvas.add(editor);
      editor.setVisible(false);
      
      docListener = createDocumentListener();
   }

   protected JTextComponent createDefaultEditor() {
      JTextPane tComp = new JTextPane() {

         /**
          * Set some rendering hints - if we don't then the rendering can be inconsistent.  Also,
          * Swing doesn't work correctly with fractional metrics.
          */
         public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D)g;
            
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g2.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_OFF);            
            
            super.paint(g);
         }
         
         /**
          * If the standard scroll rect to visible is on, then you can get weird behaviors if the
          * canvas is put in a scrollpane.
          */
         public void scrollRectToVisible() {
         }
      }; 
      tComp.setBorder(new CompoundBorder(new LineBorder(Color.black),new EmptyBorder(3,3,3,3)));
      return tComp;
   }

   protected DocumentListener createDocumentListener() {
      return new DocumentListener() {
         public void removeUpdate(DocumentEvent e) {
            reshapeEditorLater();
         }  
         
         public void insertUpdate(DocumentEvent e) {
            reshapeEditorLater();
         }
         
         public void changedUpdate(DocumentEvent e) {
            reshapeEditorLater();
         }        
      };    
   }

   public PStyledText createText() {
      final PStyledText newText = new PStyledText();
      
      final Document doc = editor.getUI().getEditorKit(editor).createDefaultDocument();
      if (doc instanceof StyledDocument) {
         final AttributeSet rootAttributes = doc.getDefaultRootElement().getAttributes();
         if (!rootAttributes.isDefined(StyleConstants.FontFamily)
            || !rootAttributes.isDefined(StyleConstants.FontSize)) {

            final Font eFont = editor.getFont();
            final MutableAttributeSet as = new SimpleAttributeSet();
            StyleConstants.setFontFamily(as, eFont.getFamily());
            StyleConstants.setFontSize(as, eFont.getSize());

            ((StyledDocument) doc).setParagraphAttributes(0, doc.getLength(), as, false);
         }
      }
      newText.setDocument(doc);
      
      return newText;
   }

   public PStyledText createText(final int fontSize) {
      final PStyledText newText = new PStyledText();
      
      final Document doc = editor.getUI().getEditorKit(editor).createDefaultDocument();
      if (doc instanceof StyledDocument) {
         final AttributeSet rootAttributes = doc.getDefaultRootElement().getAttributes();
         if (!rootAttributes.isDefined(StyleConstants.FontFamily)
            || !rootAttributes.isDefined(StyleConstants.FontSize)) {

            final Font eFont = editor.getFont();
            final MutableAttributeSet as = new SimpleAttributeSet();
            StyleConstants.setFontFamily(as, eFont.getFamily());
            StyleConstants.setFontSize(as, fontSize);

            ((StyledDocument) doc).setParagraphAttributes(0, doc.getLength(), as, false);
         }
      }
      newText.setDocument(doc);
      
      return newText;
   }

   public void mousePressed(PInputEvent inputEvent) {
      PNode pickedNode = inputEvent.getPickedNode();
            
      stopEditing();
      
      if (pickedNode instanceof PStyledText) {
         startEditing(inputEvent,(PStyledText)pickedNode);
      }
      else if (pickedNode instanceof PCamera) {
         PStyledText newText = createText();
         Insets pInsets = newText.getInsets();
         ((PCanvas)inputEvent.getComponent()).getLayer().addChild(newText);
         newText.translate(inputEvent.getPosition().getX()-pInsets.left,inputEvent.getPosition().getY()-pInsets.top);
         startEditing(inputEvent, newText);
      }
   }  
   
   public void startEditing(PInputEvent event, PStyledText text) {
      canvas = (PCanvas)event.getComponent(); 
      if (canvas instanceof DamaskCanvas) {
         ((DamaskCanvas)canvas).setTextEditing(true);
      }
      
      initEditor();
      
      // Get the node's top right hand corner
      Insets pInsets = text.getInsets();
      Point2D nodePt = new Point2D.Double(text.getX()+pInsets.left,text.getY()+pInsets.top);
      text.localToGlobal(nodePt);
      event.getTopCamera().viewToLocal(nodePt);

      // Update the editor to edit the specified node
      editor.setDocument(text.getDocument());
      editor.setVisible(true);

      Insets bInsets = editor.getBorder().getBorderInsets(editor);
      editor.setLocation((int)nodePt.getX()-bInsets.left,(int)nodePt.getY()-bInsets.top);
      reshapeEditorLater();

      dispatchEventToEditor(event);
      canvas.repaint();

      text.setEditing(true);
      text.getDocument().addDocumentListener(docListener);
      editedText = text;               
   }
   
   public void stopEditing() {
      if (canvas instanceof DamaskCanvas) {
         ((DamaskCanvas)canvas).setTextEditing(false);
      }
      if (editedText != null) {
         editedText.getDocument().removeDocumentListener(docListener);
         editedText.setEditing(false);

         if (editedText.getDocument().getLength() == 0) {
            editedText.removeFromParent();      
         }
         else {
            editedText.syncWithDocument();
         }

         editor.setVisible(false);
         canvas.repaint();
      
         editedText = null;
      }
   }

   public void dispatchEventToEditor(final PInputEvent e) {
      // We have to nest the mouse press in two invoke laters so that it is 
      // fired so that the component has been completely validated at the new size
      // and the mouse event has the correct offset
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            SwingUtilities.invokeLater(new Runnable() {
               public void run() {  
                  MouseEvent me =
                     new MouseEvent(
                        editor,
                        MouseEvent.MOUSE_PRESSED,
                        e.getWhen(),
                        e.getModifiers(),
                        (int) (e.getCanvasPosition().getX() - editor.getX()),
                        (int) (e.getCanvasPosition().getY() - editor.getY()),
                        1,
                        false);
                  editor.dispatchEvent(me);
               }
            });
         }
      });
   }

   
   public void reshapeEditor() {
      if (editedText != null) {
         // Update the size to fit the new document - note that it is a 2 stage process
         Dimension prefSize = editor.getPreferredSize();
   
         Insets pInsets = editedText.getInsets();
         Insets jInsets = editor.getInsets();
         
         int width = (editedText.getConstrainWidthToTextWidth()) ? (int)prefSize.getWidth() : (int)(editedText.getWidth()-pInsets.left-pInsets.right+jInsets.left+jInsets.right+3.0);
         prefSize.setSize(width,prefSize.getHeight());
         editor.setSize(prefSize);

         prefSize = editor.getPreferredSize();
         int height = (editedText.getConstrainHeightToTextHeight()) ? (int)prefSize.getHeight() : (int)(editedText.getHeight()-pInsets.top-pInsets.bottom+jInsets.top+jInsets.bottom+3.0);         
         prefSize.setSize(width,height);     
         editor.setSize(prefSize);
      }
   }

   /**
    * Sometimes we need to invoke this later because the document events seem to get fired
    * before the text is actually incorporated into the document
    */
   protected void reshapeEditorLater() {
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            reshapeEditor();
         }
      });         
   }
   
}
