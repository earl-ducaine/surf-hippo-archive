//// See bottom of source code for software license.
package edu.berkeley.guir.lib.io;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Holds a buffer of bytes that can be resized, compacted, inserted into,
 * removed, sliced, and diced. Useful for networking, file access, and other
 * systems-level operations. As my friend Chris Long astutely pointed out, 
 * this is the class to use when interfacing with C.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Mar 11 2004, JIH
 */
public class DataBuffer {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    private static final int DEFAULT_SIZE = 8192;

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    byte[] databuf;              // holds the data
    int    datalen;              // how much of the data is good data

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Create a new, empty 8K DataBuffer.
     */
    public DataBuffer() {
        this(DEFAULT_SIZE);
    } // of default constructor

    //-----------------------------------------------------------------

    /**
     * Create a new, empty DataBuffer with the specified buffer size.
     *
     * @param len is the length of the DataBuffer to create.
     */
    public DataBuffer(int len) {
        if (len <= 0) {
           throw new IllegalArgumentException(
                             "buffer size " + len + " should be positive");
        }
        databuf = new byte[len];
        datalen = 0;
    } // of constructor

    //-----------------------------------------------------------------

    /**
     * Create a DataBuffer using the specified buffer.
     *
     * @param buf is the array to use in this DataBuffer.
     */
    public DataBuffer(byte[] buf) {
        this(buf, buf.length);
    } // of constructor

    //-----------------------------------------------------------------

    /**
     * Create a DataBuffer using the specified buffer and the specified length.
     *
     * @param buf is the array to use in this DataBuffer.
     * @param len is the length of the bytes to use from the buffer.
     *        Ensure that len is less than or equal to buf.length.
     */
    public DataBuffer(byte[] buf, int len) {
        if (len <= 0) {
            throw new IllegalArgumentException(
                             "buffer size " + len + " should be positive");
        }
        databuf = buf;
        datalen = len;
    } // of constructor

    //-----------------------------------------------------------------

    /**
     * Create a new DataBuffer containing this String.
     *
     * @param str is the String to copy into the DataBuffer.
     */
    public DataBuffer(String str) {
        this(str.getBytes());
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Slurp in all into the DataBuffer.
     *
     * @param istream  is the InputStream to slurp data from
     * @param totallen is the #bytes we are expecting to read
     */
    public DataBuffer(InputStream istream, int totallen) 
        throws IOException {

        readAll(istream, totallen);
    } // of method

    //----------------------------------------------------------------

    /**
     * Slurp in all into the DataBuffer.
     *
     * @param istream is the InputStream to slurp data from
     */
    public DataBuffer(InputStream istream) 
        throws IOException {

        readAll(istream);
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   I/O METHODS   ======================================================

    public void readAll(InputStream istream)
        throws IOException {

        byte[] buf = new byte[DEFAULT_SIZE];
        int    len;                       // current length read

        while ((len = istream.read(buf, 0, buf.length)) > 0) {
            append(buf);
        }
    } // of method

    //--------------------

    public void readAll(InputStream istream, int totallen) 
        throws IOException {

        byte[] buf    = new byte[totallen];
        int    len;                       // current length read
        int    runlen = 0;

        while ((len = istream.read(buf, 0, buf.length)) > 0) {
            runlen += len;
            append(buf);
            if (runlen >= totallen) {
                return;
            }
        }
    } // of method

    //----------------------------------------------------------------

    public void writeAll(OutputStream ostream) 
        throws IOException {

        ostream.write(databuf, 0, datalen);
    } // of method

    //===   I/O METHODS   ======================================================
    //==========================================================================




    //==========================================================================
    //===   FILE METHODS   =====================================================

    /**
     * Save the buffer as a file, overwriting the file if necessary.
     *
     * @param  strFileName is the name of the file to save the buffer to.
     * @throws IOException on an I/O error, most likely a file write error.
     */
    public void writeToFile(String strFileName) 
        throws IOException {

        saveToFile(strFileName, false);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Append the buffer to the specified file, creating the file if it does not
     * exist.
     *
     * @param strFileName is the name of the file to append to.
     * @throws IOException on an I/O error, most likely a file write error.
     */
    public void appendToFile(String strFileName) 
        throws IOException {

        saveToFile(strFileName, true);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Actually does the work of writing the data to file.
     *
     * @param  strFileName is the name of the file to write to.
     * @param  flagAppend  specifies whether or not to append or overwrite.
     * @throws IOException on an I/O error, most likely a file write error.
     */
    private void saveToFile(String strFileName, boolean flagAppend) 
        throws IOException {

        FileOutputStream     fostream;
        BufferedOutputStream bostream;

        fostream = new FileOutputStream(strFileName, flagAppend);
        bostream = new BufferedOutputStream(fostream);

        bostream.write(databuf, 0, datalen);
        bostream.flush();
        bostream.close();
    } // of method

    //-----------------------------------------------------------------

    /**
     * Restore the buffer with data from the specified file. Overwrites what is
     * currently in the buffer. Can only read the first Integer.MAX_VALUE bytes 
     * from a file.
     *
     * @param  strFileName is the file to read from.
     * @throws IOException on an I/O error, most likely either file does not
     *         exist or there is a file read error.
     */
    public void readFromFile(String strFileName) 
       throws IOException, FileNotFoundException {

       FileInputStream fistream;
       File            file       = new File(strFileName);
       long            fileLength = file.length();
       int             length;

       //// 1. Ensure we do not exceed the max value for ints.
       if (fileLength > Integer.MAX_VALUE) {
          length = Integer.MAX_VALUE;
       }
       else {
          length = (int) fileLength;
       }

       //// 2. Ensure we have enough space in the buffer.
       resize(length);

       //// 3. Read in the data.
       fistream = new FileInputStream(strFileName);
       datalen  = length;
       fistream.read(databuf, 0, length);
       fistream.close();
    } // of method

    //===   FILE METHODS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   ACCESSOR METHODS   =================================================

    /**
     * Get a reference to the data buffer containing the data. You must 
     * ensure that the length of the data is correct if any changes are made!
     *
     * @return a reference to the only copy of the data.
     */
    public byte[] getBytes() {
       return (databuf);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Get the length of the data.
     *
     * @return the length of the data.
     */
    public int getLength() {
       return (datalen);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Find the index of the specified buffer.
     *
     * @param str is the String to search for.
     */
    public int indexOf(String str) {
       return (indexOf(0, str.getBytes(), 0, str.length()));
    } // of method

    //--------------------

    /**
     * Find the index of the specified buffer.
     *
     * @param str is the String to search for.
     * @param start is the start position in this databuffer to search from.
     */
    public int indexOf(int start, String str) {
       return (indexOf(start, str.getBytes(), 0, str.length()));
    } // of method

    //--------------------

    /**
     * Find the index of the specified buffer.
     *
     * @param start is the start position in this databuffer to search from.
     * @param str is the String to search for.
     * @param offset is where in searchbuf to start searching from.
     * @param len is the number of bytes to search through in searchbuf.
     */
    public int indexOf(int start, String str, int offset, int len) {
       return (indexOf(start, str.getBytes(), offset, len));
    } // of method

    //-----------------------------------------------------------------

    /**
     * Find the index of the specified buffer.
     *
     * @param searchbuf is the bytes to search for.
     */
    public int index(DataBuffer searchbuf) {
       return (indexOf(0, searchbuf.getBytes(), 0, searchbuf.getLength()));
    } // of method

    //--------------------

    /**
     * Find the index of the specified buffer.
     *
     * @param start is the start position in this databuffer to search from.
     * @param searchbuf is the bytes to search for.
     * @param offset is where in searchbuf to start searching from.
     * @param len is the number of bytes to search through in searchbuf.
     */
    public int index(int start, DataBuffer searchbuf, int offset, int len) {
       return (indexOf(start, searchbuf.getBytes(), offset, len));
    } // of method

    //-----------------------------------------------------------------

    /**
     * Find the index of the specified buffer.
     *
     * @param searchbuf is the bytes to search for.
     */
    public int indexOf(byte[] searchbuf) {
       return (indexOf(0, searchbuf, 0, searchbuf.length));
    } // of method

    //--------------------

    /**
     * Find the index of the specified buffer. Currently a brute-force search,
     * should switch to Boyer-Moore or something similar one day.
     *
     * @param start is the start position in this databuffer to search from.
     * @param searchbuf is the bytes to search for.
     * @param offset is where in searchbuf to start searching from.
     * @param len is the number of bytes to search through in searchbuf.
     */
    public int indexOf(int start, byte[] searchbuf, int offset, int len) {
       int i = start;
       int j = offset;

       while (i < this.getLength()) {
          if (databuf[i] == searchbuf[j]) {
             j++;
          }
          else {
             j = offset;
          }

          i++;
          if (j >= len) {
             return (i - j);
          }
       }

       return (-1);
    } // of method

    //--------------------

    /**
     * Find the index of the first instance of the specified character.
     *
     * @param start is the start position in this databuffer to search from.
     * @param ch is the char to search for.
     */
    public int indexOf(int start, char ch) {
       for (int i = start; i < this.getLength(); i++) {
          if (databuf[i] == (byte) ch) {
             return(i);
          }
       }
       return (-1);
    } // of method

    //--------------------

    /**
     * Find the index of the first instance of the specified character.
     *
     * @param ch is the char to search for.
     */
    public int indexOf(char ch) {
       return(indexOf(0, ch));
    } // of method

    //-----------------------------------------------------------------

    /**
     * Retrieve the byte at the specified position.
     *
     * @param index is the location to retrieve.
     */
    public final byte at(int index) {
       if (index >= datalen) {
          throw new ArrayIndexOutOfBoundsException();
       }
       return(databuf[index]);
    } // of method

    //===   ACCESSOR METHODS   =================================================
    //==========================================================================




    //==========================================================================
    //===   MODIFIER METHODS   =================================================

    /**
     * Find any String in strFindArray and replace it with strReplace.
     * Note that this does not work entirely correctly if a substring of
     * strReplace is in strFindArray. This is an O(N^2) operation.
     *
     */
    public void replace(String[] strFindArray, String strReplace) {
       for (int i = 0; i < strFindArray.length; i++) {
          replace(strFindArray[i], strReplace);
       }
    } // of method

    //--------------------

    /**
     * Find all instances of a String, and replace these instances with another
     * String. This is an O(N) operation.
     *
     * @param strFind    is the String to find.
     * @param strReplace is the String to replace strFind with.
     */
    public void replace(String strFind, String strReplace) {
       int index;

       index = indexOf(0, strFind);
       while (index >= 0) {
          index = replaceHelper(index, strFind, strReplace);
       }
    } // of method

    //--------------------

    /**
     * Find the first instance of a String and replace it with another String.
     *
     * @param startpos   is where to start searching from.
     * @param strFind    is the String to find.
     * @param strReplace is the String to replace strFind with.
     */
    private int replaceHelper(int startpos, String strFind, String strReplace) {
       int index;
       
       //// 1. Find where the next instance of the String to find is.
       index = indexOf(startpos, strFind);

       //// 2. If we found it, replace it.
       if (index >= 0) {

          //// 2.1. If the two Strings are not the same length, then will have
          ////      to do some resizing.
          if (strFind.length() != strReplace.length()) {
             insert(index, strReplace);
             remove(index + strReplace.length(), strFind.length());
          }
          //// 2.2. If the two Strings are the same length, then we won't have
          ////      to do any resizing. Just overwrite the String in place.
          else {
             for (int i = 0; i < strReplace.length(); i++) {
                databuf[index + i] = (byte) strReplace.charAt(i);
             }
          }
       }
       return (index);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Clear out the data in the buffer by setting the length to 0. 
     * Use method fill() to put bogus values in the buffer.
     */
    public void clear() {
       datalen = 0;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Fill the entire buffer with byte value 0.
     */
    public void fill() {
       fill((byte) 0);
    } // of method

    //--------------------

    /**
     * Fill the entire buffer with the specified byte value. This can be
     * useful when debugging, as you can insert a value that is obviously wrong.
     *
     * @param bb is the byte to put in the buffer.
     */
    public void fill(byte bb) {
       for (int i = 0; i < databuf.length; i++) {
          databuf[i] = bb;
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Resize the data buffer size.
     *
     * @param size is the new size to change the buffer to. If it is smaller
     *        than the current length of the data, then it will default to the 
     *        current length of the data.
     */
    public void resize(int size) {
       int newsize;

       //// 1. Ensure that the size of the buffer is at least the size of the
       ////    data we currently hold.
       newsize = databuf.length;
       while (newsize < size) {
          newsize *= 2;
       }

       //// 2. Copy the bytes over.
       byte[] newbuf = new byte[newsize];
       System.arraycopy(databuf, 0, newbuf, 0, datalen);
       databuf = newbuf;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Compact the data buffer to the current size of the data.
     */
    public void compact() {
       resize(0);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Append the specified buffer to the end.
     *
     * @param insertbuf is the buffer to insert.
     */
    public void append(byte[] insertbuf) {
       insert(datalen, insertbuf);
    } // of method

    //--------------------

    /**
     * Append the specified buffer to the end.
     *
     * @param insertbuf is the buffer to insert.
     * @param off is the offset in insertbuf to copy from.
     * @param len is the amount to insert from insertbuf.
     */
    public void append(byte[] insertbuf, int off, int len) {
       insert(datalen, insertbuf, off, len);
    } // of method

    //--------------------

    /**
     * Append a DataBuffer to this current DataBuffer.
     *
     * @param buf is the DataBuffer to append.
     */
    public void append(DataBuffer buf) {
       insert(datalen, buf.getBytes(), 0, buf.getLength());
    } // of method

    //--------------------

    /**
     * Append a single byte to this current DataBuffer.
     *
     * @param bb is the byte to append.
     */
    public void append(byte bb) {
       byte[] buf = new byte[1];
       buf[0] = bb;
       append(buf);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Insert len number of spaces (with value 0) at position pos. This is a
     * slow operation.
     *
     * @param pos is the position to insert spaces at.
     * @param len is the number of spaces to insert.
     */
    public void insert(int pos, int len) {
       //// 1. Ensure we have enough space.
       byte[] newbuf;
       if (datalen + len > databuf.length) {
          newbuf = new byte[datalen + len];
       }
       else {
          newbuf = new byte[databuf.length];
       }

       //// 2. Copy and shift things over.
       System.arraycopy(databuf, 0, newbuf, 0, pos);
       System.arraycopy(databuf, pos, newbuf, pos + len, datalen - pos);

       databuf = newbuf;
       datalen += len;
    } // of method

    //--------------------

    /**
     * Insert the specified buffer at the specified position.
     * This is a slow operation.
     *
     * @param pos is the position to start inserting at.
     * @param insertbuf is the buffer to insert.
     * @param off is the offset in insertbuf to copy from.
     * @param len is the amount to insert from insertbuf.
     */
    public void insert(int pos, byte[] insertbuf, int off, int len) {

       //// 1. Insert some space in.
       insert(pos, len);

       //// 2. Copy the bytes over.
       System.arraycopy(insertbuf, off, databuf, pos, len);
    } // of method

    //--------------------

    /**
     * Insert the specified String at the specified position.
     * This is a slow operation.
     *
     * @param pos is the position to start inserting at.
     * @param str is the String to insert.
     */
    public void insert(int pos, String str) {
       insert(pos, str.getBytes(), 0, str.length());
    } // of method

    //--------------------

    /**
     * Insert the entire buffer insertbuf at the specified position.
     * This is a slow operation.
     *
     * @param pos is the position to start inserting at.
     * @param insertbuf is the buffer to insert.
     */
    public void insert(int pos, byte[] insertbuf) {
       insert(pos, insertbuf, 0, insertbuf.length);
    } // of insert

    //--------------------

    /**
     * Insert the entire DataBuffer buf at the specified position.
     * This is a slow operation.
     *
     * @param pos is the position to start inserting at.
     * @param buf is the buffer to insert.
     */
    public void insert(int pos, DataBuffer buf) {
       insert(pos, buf.getBytes(), 0, buf.getLength());
    } // of method

    //--------------------

    /**
     * Insert the specified buffer at the specified position.
     * This is a slow operation.
     *
     * @param pos is the position to start inserting at.
     * @param buf is the DataBuffer to insert.
     * @param off is the offset in insertbuf to copy from.
     * @param len is the amount to insert from insertbuf.
     */
    public void insert(int pos, DataBuffer buf, int off, int len) {
       insert(pos, buf.getBytes(), off, len);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Remove len number of bytes at position pos. This is a slow operation.
     *
     * @param pos is the position to start removing from (starting with 0, 
     *        inclusive).
     * @param len is the length of data to remove.
     */
    public void remove(int pos, int len) {
       System.arraycopy(databuf, pos + len, databuf, pos,
             databuf.length - pos - len);

       datalen -= len;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Set the bytes contained in this DataBuffer.
     *
     * @param buf is the data buffer.
     * @param len is the length of the data. Must be a nonnegative value.
     */
    public void setBytes(byte[] buf, int len) {
       databuf = buf;
       setLength(len);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Copy the bytes in the specified buffer over to this DataBuffer.
     *
     * @param buf is the data buffer.
     * @param len is the length of the data. Must be a nonnegative value.
     */
    public void copyBytes(byte[] buf, int len) {
       System.arraycopy(buf, 0, databuf, 0, len);
       setLength(len);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Set the length of the data.
     *
     * @param len is the length of the data. Must be a nonnegative value.
     */
    public void setLength(int len) {
       datalen = len;
    } // of method

    //===   MODIFIER METHODS   =================================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    /**
     * Convert the data to a String printable format.
     */
    public String toString() {
       return (new String(databuf, 0, datalen));
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   MAIN   =============================================================
 /*
    public static void main(String[] argv) 
       throws Exception {

       DataBuffer buf = new DataBuffer();
       byte[]     bytes = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};

       byte[]     morebytes = {'h', 'i', 'j', 'k', 'l', 'm', 'n'};

       buf.append(bytes);
       System.out.println("|" + buf + "|");

       buf.append(buf);
       System.out.println("|" + buf + "|");

       buf.insert(3, "mystr");
       System.out.println("|" + buf + "|");

       buf.insert(0, "mystr");
       System.out.println("|" + buf + "|");

       buf.clear();
       buf.insert(0, "hi");

       buf.replace("hi", "supercalifragilistic");
       System.out.println("|" + buf + "|");

       buf.replace("c", "k");
       System.out.println("|" + buf + "|");

       String[] strArray = new String[2];
       strArray[0] = "super";
       strArray[1] = "frag";

       buf.replace(strArray, "new");
       System.out.println("|" + buf + "|");




       buf.writeToFile("myfile1.dat");
       buf.appendToFile("myfile1.dat");

       buf.appendToFile("myfile2.dat");
       buf.writeToFile("myfile2.dat");

       buf.clear();
       buf.readFromFile("myfile1.dat");
       System.out.println("|" + buf + "|");

       buf.clear();
       buf.readFromFile("myfile2.dat");
       System.out.println("|" + buf + "|");

       buf.setBytes(bytes, bytes.length);
       buf.insert(0, morebytes);
       System.out.println("|" + buf + "|");



       System.out.println(buf.datalen);
       buf.insert(14, morebytes);
       System.out.println("|" + buf + "|");

       System.out.println(buf);
       buf.setBytes(bytes, bytes.length);
       buf.insert(2, 2);
       System.out.println(buf);  // should be "ab  cdefg"

       buf.remove(2, 2);
       System.out.println(buf);  // should be "abcdefg"

       buf.remove(0, 0);
       System.out.println(buf);  // should be "abcdefg"

       buf.remove(6, 0);
       System.out.println(buf);  // should be "abcdefg"

       buf.insert(0, 0);
       System.out.println(buf);  // should be "abcdefg"

       buf.insert(6, 0);
       System.out.println(buf);  // should be "abcdefg"

       buf.insert(0, 2);
       System.out.println(buf);  // should be "  abcdefg"

       buf.insert(6, 2);
       System.out.println(buf);  // should be "  abcd  efg"

       buf.remove(0, 2);
       buf.remove(6, 2);
       System.out.println(buf);  // should be "abcd  g"

       buf.insert(7, 2);
       System.out.println("|" + buf + "|");

    } // of main
 */

    //===   MAIN   =============================================================
    //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
