//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tuple.filter;

import edu.berkeley.guir.lib.collection.tuple.Tuple;
import edu.berkeley.guir.lib.util.filter.Filter;

/**
 * Accept Tuples that have the specified tuple type (ie the main XML tag).
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 20 2003, JH
 */
public class TupleFilterByType
    extends TupleFilterBaseImpl {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    String strTupleTypePattern;  // pattern for tuple type tag

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * See if the TupleType exists.
     */
    public TupleFilterByType(String newTupleTypePattern) {
        strTupleTypePattern = newTupleTypePattern;
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   ACCESSOR METHODS   =================================================

    public String getTupleTypePattern() {
        return (strTupleTypePattern);
    } // of method

    //===   ACCESSOR METHODS   =================================================
    //==========================================================================




    //==========================================================================
    //===   FILTER METHODS   ===================================================

    public boolean isAccepted(Object obj) {
        try {
            Tuple t = (Tuple) obj;

            //// 1. Get the xpath value.
            String strVal = t.getTupleType();

            //// 2.1. If the value does not exist, then fail.
            if (strVal == null) {
                return (false);
            }
            //// 2.2. Otherwise, see if it matches the specified pattern.
            else {
                return (strVal.matches(strTupleTypePattern));
            }
        }
        catch (Exception e) {
            // fail
            e.printStackTrace();
            return (false);
        }
    } // of method

    //===   FILTER METHODS   ===================================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        StringBuffer strbuf = new StringBuffer();
        strbuf.append("TupleFilterByType: [pattern: ");
        strbuf.append(getTupleTypePattern());
        strbuf.append("]");
        return (strbuf.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================





    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static void testAAA(Filter f, Tuple t) {
        System.out.println("------------------");
        System.out.println(f);
        System.out.println(t);
        System.out.println("accept: " + f.isAccepted(t));
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) {
        Filter f;
        
        f = new TupleFilterByType("ContextTuple");
        testAAA(f, Tuple.getTestInstanceAAA());
        testAAA(f, Tuple.getTestInstanceBBB());
        testAAA(f, Tuple.getTestInstanceCCC());

        f = new TupleFilterByType("person");
        testAAA(f, Tuple.getTestInstanceAAA());
        testAAA(f, Tuple.getTestInstanceBBB());
        testAAA(f, Tuple.getTestInstanceCCC());

    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
