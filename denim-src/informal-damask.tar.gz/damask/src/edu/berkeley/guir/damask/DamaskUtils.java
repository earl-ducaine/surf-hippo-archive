package edu.berkeley.guir.damask;

import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.satin.command.MacroCommand;

/** 
 * A collection of useful utilities.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-25-2003 James Lin
 *                               Created DamaskUtils
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 04-25-2003
 */
public final class DamaskUtils {
   
   public static int INDENT_SPACES = 3;
   
   //===========================================================================
   
   // Make this class uninstantiable.
   private DamaskUtils() {
   }
   
   //===========================================================================
   
   /**
    * Returns an unmodifiable version of the given collection, or an
    * unmodifiable empty collection if the parameter is null.  
    */
   public static Collection unmodifiableCollection(Collection collection) {
      if (collection != null) {
         return Collections.unmodifiableCollection(collection); 
      }
      else {
         return Collections.EMPTY_LIST; 
      }
   }
   
   //===========================================================================
   
   /**
    * Returns an unmodifiable version of the given list, or an
    * unmodifiable empty list if the parameter is null.  
    */
   public static List unmodifiableList(final List list) {
      if (list != null) {
         return Collections.unmodifiableList(list); 
      }
      else {
         return Collections.EMPTY_LIST; 
      }
   }

   //===========================================================================
   
   private static void appendTwoDigit(final StringBuffer sb, final int x) {
      if (x < 10) {
         sb.append('0');
      }
      sb.append(x);
   }

   //===========================================================================

   // Append the time and date in ISO 8601 format
   public static String dateToISO(long millis) {
      final StringBuffer sb = new StringBuffer();
      final Calendar calendar = Calendar.getInstance();
      calendar.setTimeInMillis(millis);

      sb.append(calendar.get(Calendar.YEAR));
      sb.append('-');
      appendTwoDigit(sb, calendar.get(Calendar.MONTH) + 1);
      sb.append('-');
      appendTwoDigit(sb, calendar.get(Calendar.DAY_OF_MONTH));
      sb.append('T');
      appendTwoDigit(sb, calendar.get(Calendar.HOUR_OF_DAY));
      sb.append(':');
      appendTwoDigit(sb, calendar.get(Calendar.MINUTE));
      sb.append(':');
      appendTwoDigit(sb, calendar.get(Calendar.SECOND));
      
      return sb.toString();
   }

   //===========================================================================
   
   /**
    * Returns the value stored in the specified map with the specified key.
    * If the map does not have that key, then this method takes the
    * stores the key with the specified default value in the map, and returns
    * the value. 
    */
   public static Object defaultGet(final Map map, final Object key, final Object defaultValue) {
      final Object value;
      if (map.containsKey(key)) {
         value = map.get(key);
      }
      else {
         map.put(key, defaultValue);
         value = defaultValue;
      }
      return value;
   }

   //===========================================================================
   
   /**
    * Throws an IllegalArgumentException if the specified condition is false.  
    */
   public static void checkValidArgument(boolean cond, String message) {
      if (!cond) {
         throw new IllegalArgumentException(message);
      }
   }

   //===========================================================================
   
   /**
    * Returns the deepest group within the specified group whose
    * (device-specific) bounds contain the specified rectangle.
    */
   private static ComponentGroup getDeepestGroupAt(
      final ComponentGroup possibleGroup,
      final PageRegion region,
      final Rectangle2D boundsInGroupCoords)
   throws NoninvertibleTransformException {

      ComponentGroup result = null;

      // If this group contains the rectangle...
      if (possibleGroup
         .getBoundsInPageRegion(region)
         .contains(boundsInGroupCoords)) {

         result = possibleGroup;
         ComponentGroup nestedGroupResult = null;
         
         // Check if the rectangle is in a group within this group
         for (Iterator j =
            possibleGroup.getChildren(region.getDeviceType()).iterator();
            j.hasNext();
            ) {
            
            final Component child = (Component)j.next();
            if (child instanceof ComponentGroup) {
               final ComponentGroup nestedGroup = (ComponentGroup)child;
               final Rectangle2D boundsInNestedGroupCoords =
                  GeomLib.transformRectangle(
                     nestedGroup.getTransformInPageRegion(region).createInverse(),
                     boundsInGroupCoords);
            
               nestedGroupResult =
                  getDeepestGroupAt(
                     nestedGroup,
                     region,
                     boundsInNestedGroupCoords);

               // If a nested group does contain the rectangle, return it               
               if (nestedGroupResult != null) {
                  result = nestedGroupResult;
                  break;
               }
            }
         }
      }
      return result;
   }
   
   //---------------------------------------------------------------------------

   /**
    * Returns the deepest group within the specified page region whose
    * bounds contain the specified rectangle.
    */
   public static ComponentGroup getDeepestGroupAt(
      final PageRegion region,
      final AffineTransform transform,
      final Rectangle2D bounds,
      final boolean forAllDeviceTypes) {

      try {
         final Rectangle2D boundsInRegionCoords =
            GeomLib.transformRectangle(transform, bounds);
         ComponentGroup group = null;

         for (Iterator i = region.getPage().getDialog().getGroups().iterator();
            i.hasNext();
            ) {

            final ComponentGroup possibleGroup = (ComponentGroup)i.next();

            if (possibleGroup.isForAllDeviceTypes() == forAllDeviceTypes) {

               final AffineTransform possibleGroupTransformInRegion =
                  possibleGroup.getTransformInPageRegion(region);

               if (possibleGroupTransformInRegion != null) {
                  final Rectangle2D boundsInGroupCoords =
                     GeomLib.transformRectangle(
                        possibleGroupTransformInRegion.createInverse(),
                        boundsInRegionCoords);

                  final ComponentGroup result =
                     getDeepestGroupAt(
                        possibleGroup,
                        region,
                        boundsInGroupCoords);

                  if (result != null) {
                     group = result;
                     break;
                  }
               }
            }
         }
         return group;
      }
      catch (NoninvertibleTransformException e) {
         // This should never happen.
         DamaskAppExceptionHandler.log(e);
         return null;
      }
   }
      
   //===========================================================================

   /**
    * Returns an existing control whose type is <code>selectClass</code>,
    * the specified subclass of Select, within either <code>group</code> or
    * <code>region</code> if <code>group</code> is null.
    * 
    * @param region the page region to search if <code>group</code> is null
    * @param group the component group to search
    * @param selectClass the subclass of Select to search for
    */
   public static Select findExistingSelect(
      final PageRegion region,
      final ComponentGroup group,
      final DeviceType itemDeviceType,
      final Class selectClass,
      final Select.Style selectStyle) {

      Select selectToAddTo = null;
      for (Iterator i = region.getControls().iterator(); i.hasNext(); ) {
         final Control control = (Control)i.next();
         if (selectClass.isInstance(control)) {
            final Select select = (Select)control;
            if ((select.getDeviceType() == itemDeviceType)
               && (select.getGroup() == group)
               && (select.getStyle(region.getDeviceType()) == selectStyle)) {

               selectToAddTo = select;
               break;
            }
         }
      }
      
      return selectToAddTo;
   }
   
   //===========================================================================

   /**
    * Splits the voice page that the specified control is in.
    * 
    * @return an array of Pages. The page at index 0 is the original page,
    * and the page at index 1 is the page that was split away.
    */
   public static Page[] splitVoicePageAfterTrigger(final Trigger control) {
      final PageRegion voicePageRegion =
         control.getPageRegion(DeviceType.VOICE); 

      final Page voicePageWithTrigger = voicePageRegion.getPage(); 
      
      final List/*<Control>*/ voiceControls =
         voicePageRegion.getControls();
      
      final List/*<Control>*/ voiceNonTriggersAfterTrigger =
         new ArrayList/*<Control>*/();
      
      for (Iterator i =
           voiceControls.listIterator(voiceControls.indexOf(control) + 1);
           i.hasNext(); ) {
         final Control subsequentVoiceControl = (Control)i.next();
         if (!(subsequentVoiceControl instanceof Trigger)) {
            voiceNonTriggersAfterTrigger.add(subsequentVoiceControl);
         }
      }
      
      // If there are no non-triggers after the new trigger, then
      // split an empty page from voicePageRegion's page only if
      // voicePageRegion's page is the last page in the dialog.
      final List/*<Page>*/ voicePages =
         voicePageWithTrigger.getDialog().getPages(DeviceType.VOICE);
      
      final Page splitVoicePage;
      
      if (!voiceNonTriggersAfterTrigger.isEmpty() ||
          (voicePages.indexOf(voicePageWithTrigger) ==
             voicePages.size() - 1)) {
         splitVoicePage =
            voicePageWithTrigger.split(voiceNonTriggersAfterTrigger);
      }
      else {
         splitVoicePage = null;
      }
      
      return new Page[] {voicePageWithTrigger, splitVoicePage};
   }

   //===========================================================================
   
   public static PageRegion getCorrespondingRegion(final PageRegion region,
         final Control control,
         final DeviceType deviceType) {

      deviceType.verifyTypeIsNotAll();
      
      final PageRegion controlRegion;
      if (control == null) {
         controlRegion = null;
      }
      else {
         controlRegion = control.getPageRegion(deviceType);
      }
      
      final PageRegion correspondingRegion;
      if (controlRegion == null) {
         final Page correspondingPage =
            region.getPage().getDialog().getLastPage(deviceType);
         if (deviceType == DeviceType.VOICE) {
            correspondingRegion = correspondingPage.getRegion(Direction.CENTER);
         }
         else {
            correspondingRegion = correspondingPage.getRegion(region.getName());
         }
      }
      else {
         correspondingRegion = controlRegion;
      }
      
      return correspondingRegion;
   }

   //---------------------------------------------------------------------------
   
   /**
    * A cluster node used in hierachical clustering of controls within
    * a page region, to determine which controls are near which.
    */
   private static class Cluster {
      public final Rectangle2D rect;
      public final Cluster left;
      public final Cluster right;
      public final Control control;

      public Cluster(final Cluster left, final Cluster right) {
         this.left = left;
         this.right = right;
         rect = left.rect.createUnion(right.rect);
         control = null;
      }
      
      public Cluster(final Control control, final DeviceType deviceType) {
         this.control = control;
         rect = control.getBoundsInParentCoords(deviceType);
         left = null;
         right = null;
      }
      
      public Cluster(final Rectangle2D rect) {
         this.rect = rect;
         control = null;
         left = null;
         right = null;
      }
      
      public String toString() {
         if (control != null) {
            return "[" + control + "]";
         }
         if (left == null && right == null) {
            return "[X]";
         }
         final String leftStr = (left == null) ? "" : left.toString(); 
         final String rightStr = (right == null) ? "" : right.toString();
         return "[" + leftStr + ", " + rightStr + "]";
      }
   }
   
   
   /**
    * Takes a tree of cluster nodes rooted at the specified node, and adds the
    * controls which are in the leaves of the tree to the specified list.
    */
   private static void flattenClusterTree(final Cluster cluster,
                                          final List/*<Control>*/ controls) {
      if (cluster == null) {
         return;
      }
      if (cluster.left == null && cluster.right == null) {
         controls.add(cluster.control);
      }
      flattenClusterTree(cluster.left, controls);
      flattenClusterTree(cluster.right, controls);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns a list of controls in the specified page region where the
    * controls are listed in the order that they are actually laid out.
    * 
    * @param region the region whose controls to return
    * @param controlDeviceType the device type of the controls to return. If
    *         null, then the returned controls' device types can be anything.
    */
   public static List/*<Control>*/ getControlsInPositionOrder(
      final PageRegion region,
      final DeviceType controlDeviceType) {
      
      // 1  Set up a cluster for each control...
      final Set/*<Cluster>*/ activeClusters = new HashSet/*<Cluster>*/();
      for (Iterator i = region.getControls().iterator(); i.hasNext(); ) {
         final Control control = (Control)i.next();
         if ((controlDeviceType == null) ||
             control.getDeviceType().equals(controlDeviceType)) {
            // HACK if test should never fail, but sometimes does
            if (control.getBoundsInParentCoords(region.getDeviceType()) != null) {
               activeClusters.add(new Cluster(control, region.getDeviceType()));
            }
         }
      }
      
      if (activeClusters.isEmpty()) {
         return Collections.EMPTY_LIST;
      }
      
      // 2  Do a hierarchical clustering of the controls, to figure out which
      //    controls are near which.
      doHierarchicalClustering(activeClusters);
      
      // 3  Take the hierarchy of clusters and flatten it.
      final List/*<Control>*/ controls = new ArrayList/*<Control>*/();
      flattenClusterTree((Cluster)activeClusters.iterator().next(), controls);
      
      return controls;
   }
   
   /**
    * Finds the control that is "before" the specified rectangular region,
    * or null if there isn't any.
    */
   public static Control getControlBefore(
      final DeviceType pageDeviceType,
      final Iterator controlsIterator,
      final DeviceType newControlDeviceType,
      final AffineTransform newControlTransform,
      final Rectangle2D newControlBounds) {

      if (!controlsIterator.hasNext()) {
         return null;
      }

      // 1  Set up a cluster for each control...
      final Set/*<Cluster>*/ activeClusters = new HashSet/*<Cluster>*/();
      while (controlsIterator.hasNext()) {
         final Control control = (Control)controlsIterator.next();
         if (control.getDeviceType().equals(newControlDeviceType)) {
            activeClusters.add(new Cluster(control, pageDeviceType));
         }
      }
      
      //      ...including the new control
      activeClusters.add(
         new Cluster(
            GeomLib.transformRectangle(newControlTransform, newControlBounds)));
      
      // 2  Do a hierarchical clustering of the controls, to figure out which
      //    controls are near which.
      doHierarchicalClustering(activeClusters);
      
      // 3  Take the hierarchy of clusters and flatten it.
      final List/*<Control>*/ controls = new ArrayList/*<Control>*/();
      flattenClusterTree((Cluster)activeClusters.iterator().next(), controls);

      // 4  Find the control before "null", which represents the new control.
      final int newControlIndex = controls.indexOf(null);
      if (newControlIndex == 0) {
         return null;
      }
      else {
         return (Control)controls.get(newControlIndex - 1);
      }
   }

   /**
    * @param activeClusters
    */
   private static void doHierarchicalClustering(
      final Set/*<Cluster>*/ activeClusters) {
      
      // 1.2  Until there is only one cluster left...
      while (activeClusters.size() > 1) {
         // 1.2.1  Figure out the distances between every pair of clusters
         double shortestDistance = Double.POSITIVE_INFINITY;
         double thetaForShortestDistance = Double.POSITIVE_INFINITY;
         Cluster nearestCluster1 = null;
         Cluster nearestCluster2 = null;
         for (Iterator i = activeClusters.iterator(); i.hasNext(); ) {
            final Cluster c1 = (Cluster)i.next();
            for (Iterator j = activeClusters.iterator(); j.hasNext(); ) {
               final Cluster c2 = (Cluster)j.next();
               if (c1 == c2) {
                  continue;
               }
               final double x = c2.rect.getX() - c1.rect.getX();
               final double y = c2.rect.getCenterY() - c1.rect.getCenterY();
               
               final double r = Math.sqrt(x*x + y*y);
               
               if (r < shortestDistance) {
                  shortestDistance = r;
                  thetaForShortestDistance = Math.atan2(y, x);
                  nearestCluster1 = c1;
                  nearestCluster2 = c2;
               }
            }
         }

         // 1.2.2  Take the clusters with the shortest distance, and cluster
         //        them together
         activeClusters.remove(nearestCluster1);
         activeClusters.remove(nearestCluster2);

         // 1.2.2.1  If nearestCluster2 is in one of the following positions
         //          relative to nearestCluster1:
         //                                  nearestCluster2
         //              nearestCluster1     nearestCluster2
         //              nearestCluster2     nearestCluster2
         //
         //          then nearestCluster2 is considered to be after
         //          nearestCluster1. Otherwise, it is before.
         if ((-3.0/8) * Math.PI <= thetaForShortestDistance
               && thetaForShortestDistance <= (5.0/8) * Math.PI) {
            activeClusters.add(new Cluster(nearestCluster1, nearestCluster2));
         }
         else {
            activeClusters.add(new Cluster(nearestCluster2, nearestCluster1));
         }
      }
   }

   //===========================================================================

   /**
    * Adds, to the specified macro command, a command which adds the
    * specified component to the specified region.
    * 
    * @param cmd the command to add to
    * @param component the component to add
    * @param region the page region to add to
    */
   public static void addCommandsForAddingComponentToMacroCommand(
      final MacroCommand cmd,
      final Component newComponent,
      final PageRegion region) {

      addCommandsForAddingComponentToMacroCommand(cmd,
                                            newComponent,
                                            region,
                                            null,
                                            true,
                                            true);
   }
      

   /**
    * Adds, to the specified macro command, a command which adds the
    * specified component to the specified region.
    * 
    * @param cmd the command to add to
    * @param component the component to add
    * @param region the page region to add to
    */
   public static void addCommandsForAddingComponentToMacroCommand(
      final MacroCommand cmd,
      final Component newComponent,
      final PageRegion region,
      final ComponentGroup group,
      final boolean autoFindGroup,
      final boolean autoCreateVoiceContent) {
      
      final DamaskUtils.NewComponentInfo newComponentInfo =
         DamaskUtils.inferBoundsAndTransform(
            newComponent, region, group, autoFindGroup);
      
      final Component actualNewComponent = newComponentInfo.getNewComponent();
      final Content newContentAboveNewComponent =
         newComponentInfo.getNewContentAboveNewComponent();
      final Trigger newTriggerBelowNewComponent =
         newComponentInfo.getNewTriggerBelowNewComponent();
      final Trigger placeholderToRemove =
         newComponentInfo.getPlaceholderToRemove();
      Control controlBefore = newComponentInfo.getControlBefore();
      final ComponentGroup groupForNewComponents =
         newComponentInfo.getComponentGroup();

      if (actualNewComponent.isVisibleToDeviceType(DeviceType.VOICE)) {
         final PageRegion voiceRegion;
         if (controlBefore == null) {
            voiceRegion =
               region.getPage().getDialog().getPageRegionToAddTo(
                  region, true, DeviceType.VOICE);
         }
         else {
            voiceRegion =
               region.getPage().getDialog().getPageRegionToAddTo(
                  controlBefore, DeviceType.VOICE);
         }
         
         if (newContentAboveNewComponent != null && autoCreateVoiceContent) {
            addCommandsForAddingOneComponentToMacroCommand(
               cmd,
               voiceRegion,
               newComponentInfo,
               newContentAboveNewComponent,
               controlBefore instanceof Select.Item ?
                  ((Select.Item)controlBefore).getParent() :
                     controlBefore,
               groupForNewComponents);
            controlBefore = newContentAboveNewComponent;
         }
         
         if (placeholderToRemove != null) {
            cmd.addCommand(new RemoveControlCommand(placeholderToRemove));
         }
      }
      
      addCommandsForAddingOneComponentToMacroCommand(
         cmd,
         region,
         newComponentInfo,
         actualNewComponent,
         controlBefore,
         groupForNewComponents);
      
      if (actualNewComponent.isVisibleToDeviceType(DeviceType.VOICE)) {
         if (newTriggerBelowNewComponent != null) {
            cmd.addCommand(
               new AddControlCommand(
                  (Control)actualNewComponent,
                  newTriggerBelowNewComponent));
         }
      }
   }   
   
   
   private static void addCommandsForAddingOneComponentToMacroCommand(
      final MacroCommand cmd,
      final PageRegion region,
      final DamaskUtils.NewComponentInfo newComponentInfo,
      final Component actualNewComponent,
      final Control controlBefore,
      final ComponentGroup groupForNewComponents) {
      
      if (actualNewComponent instanceof Select.Item) {
         final Select selectToAddTo = newComponentInfo.getSelectToAddTo();
         cmd.addCommand(new AddItemCommand(selectToAddTo,
                                           selectToAddTo.getItems()
                                                        .indexOf(controlBefore) + 1,
                                           (Select.Item)actualNewComponent));
      }
      else if (actualNewComponent instanceof Control) {
         if (controlBefore == null) {
            cmd.addCommand(new AddControlCommand(region,
                                                 (Control) actualNewComponent));
            
            if (actualNewComponent.isVisibleToDeviceType(DeviceType.VOICE)) {
               final Collection newPageComponents =
                  new ArrayList();
               newPageComponents.add(actualNewComponent);
               final PageRegion voiceRegion =
                  region.getPage().getDialog().getPageRegionToAddTo(
                     region, true, DeviceType.VOICE);
               if (shouldSplitVoiceRegion(voiceRegion, actualNewComponent)) {
                  cmd.addCommand(
                     new SplitPageCommand(
                        voiceRegion.getPage(), newPageComponents, 0));
               }
            }
         }
         else {
            cmd.addCommand(new AddControlCommand(controlBefore,
                                                 (Control) actualNewComponent));
            cmd.addCommand(
               new ChangePageRegionCommand(
                  (Control)actualNewComponent, region.getDeviceType(), region));
            
            if (actualNewComponent.isVisibleToDeviceType(DeviceType.VOICE)) {
               final Collection newPageComponents =
                  new ArrayList();
               newPageComponents.add(actualNewComponent);
               final PageRegion voiceRegion =
                  controlBefore.getDialog().getPageRegionToAddTo(
                     controlBefore, DeviceType.VOICE);
               if (shouldSplitVoiceRegion(voiceRegion, actualNewComponent)) {
                  cmd.addCommand(
                     new SplitPageCommand(
                        voiceRegion.getPage(), newPageComponents, 0));
               }
            }
         }
      }
      else {
         cmd.addCommand(
            new AddGroupCommand(
               region.getPage().getDialog(),
               (ComponentGroup)actualNewComponent));
      }

      if (groupForNewComponents != null) {
         cmd.addCommand(
            new AddComponentToGroupCommand(
               groupForNewComponents, actualNewComponent));
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * @param voiceRegion
    * @return
    */
   private static boolean shouldSplitVoiceRegion(
      final PageRegion voiceRegion, final Component newComponent) {

      boolean shouldSplit = false;
      if (newComponent instanceof SelectMany) {
         shouldSplit = false;
         for (Iterator i = voiceRegion.getControls().iterator(); i.hasNext(); ) {
            final Control voiceControl = (Control)i.next();
            if (!(voiceControl instanceof Trigger)) {
               shouldSplit = true;
               break;
            }
         }
      }
      else if (newComponent instanceof Content) {
         shouldSplit = false;
         for (Iterator i = voiceRegion.getControls().iterator(); i.hasNext(); ) {
            final Control voiceControl = (Control)i.next();
            if ((voiceControl instanceof Content) || (voiceControl instanceof SelectMany)) {
               shouldSplit = true;
               break;
            }
         }
      }
      else if (newComponent instanceof SelectOne || newComponent instanceof TextInput) {
         shouldSplit = false;
         for (Iterator i = voiceRegion.getControls().iterator(); i.hasNext(); ) {
            final Control voiceControl = (Control)i.next();
            if (!((voiceControl instanceof Content) || (voiceControl instanceof Trigger))) {
               shouldSplit = true;
               break;
            }
         }
      }
      return shouldSplit;
   }

   /**
    * Adds, to the specified macro command, a command which removes the
    * specified control.
    * 
    * @param cmd the command to add to
    * @param control the control to remove
    */
   public static void addCommandsForRemovingControlToMacroCommand(
      final MacroCommand cmd,
      final Control control) {
   
      if (control instanceof Select.Item) {
         final Select.Item selectItem = (Select.Item)control;
         final Select select = selectItem.getParent();
         cmd.addCommand(new RemoveItemCommand(select, selectItem));
         if (select.getItems().size() == 1) {
            cmd.addCommand(new RemoveControlCommand(select));
         }
      }
      else {
         cmd.addCommand(new RemoveControlCommand(control));
      }
   }
   
   //===========================================================================
   
   private static class NewComponentInfo {
      private final Content newContentAboveNewComponent;
      private final Component newComponent;
      private final Trigger newTriggerBelowNewComponent;
      private final Trigger placeholderToRemove;
      private final Select select;
      private final Control controlBefore;
      private final ComponentGroup group;
      
      public NewComponentInfo(final Component newComponent,
            final Content newContentAboveNewComponent,
            final Trigger newTriggerBelowNewComponent,
            final Trigger placeholderToRemove,
            final Select selectToAddTo, final Control controlBefore,
            final ComponentGroup group) {
         this.newComponent = newComponent;
         this.newContentAboveNewComponent = newContentAboveNewComponent;
         this.newTriggerBelowNewComponent = newTriggerBelowNewComponent;
         this.placeholderToRemove = placeholderToRemove;
         this.select = selectToAddTo;
         this.controlBefore = controlBefore;
         this.group = group;
      }
      
      public Component getNewComponent() {
         return newComponent;
      }
      
      public Content getNewContentAboveNewComponent() {
         return newContentAboveNewComponent;
      }
      
      public Trigger getNewTriggerBelowNewComponent() {
         return newTriggerBelowNewComponent;
      }
      
      public Trigger getPlaceholderToRemove() {
         return placeholderToRemove;
      }
      
      public Control getControlBefore() {
         return controlBefore;
      }
      
      public Select getSelectToAddTo() {
         return select;
      }
      
      public ComponentGroup getComponentGroup() {
         return group;
      }
   }
   
   //---------------------------------------------------------------------------

   /**
    * Sets the bounds and transform for the specified component, for device
    * types other than the specified page region's device type. Also figures
    * out the component group that the specified component should be in, and
    * what control is before the specified component.
    */
   private static NewComponentInfo inferBoundsAndTransform(
      final Component component,
      final PageRegion region,
      ComponentGroup group,
      final boolean autoFindGroup) {

      final DeviceType deviceType = component.getDeviceType();
      final DeviceType regionDeviceType = region.getDeviceType();
      final AffineTransform transform = getTransform(component, region);
      final Rectangle2D bounds = getBounds(component, region);

      if (autoFindGroup) {
         group = DamaskUtils.getDeepestGroupAt(region,
                                               transform,
                                               bounds,
                                               deviceType == DeviceType.ALL);
      }
      
      Component newComponent = component;
      Control controlBefore = null;
      Select selectToAddTo = null;
      
      if (component instanceof Select.Item) {
         final Select.Item item = (Select.Item)component;
         final Class selectClass;
         if (item instanceof SelectOne.Item) {
            selectClass = SelectOne.class;
         }
         else {
            selectClass = SelectMany.class;
         }
         selectToAddTo =
            DamaskUtils.findExistingSelect(
               region,
               group,
               item.getDeviceType(),
               selectClass,
               Select.FULL);

         // If there is an appropriate existing select control to add to the
         // item to, then add it.
         if (selectToAddTo != null) {
            for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
                 i.hasNext();) {
               final DeviceType aDeviceType = (DeviceType) i.next();
               if (aDeviceType != regionDeviceType) {
                  item.setContentInsets(
                     aDeviceType,
                     item.getDefaultInsets(
                        aDeviceType,
                        selectToAddTo.getStyle(aDeviceType)));
               }
            }

            controlBefore =
               selectToAddTo.getItemBefore(
                  regionDeviceType,
                  item.getDeviceType(),
                  item.getTransform(regionDeviceType),
                  item.getBounds(regionDeviceType));
            
            group = null;
         }
         
         // Otherwise, create a new select control and add the item to it.
         else {
            if (item instanceof SelectOne.Item) {
               newComponent = new SelectOne(deviceType);
            }
            else {
               newComponent = new SelectMany(deviceType);
            }
            final Select newSelect = ((Select)newComponent);
            for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
                 i.hasNext(); ) {
               final DeviceType aDeviceType = (DeviceType)i.next();
               if (aDeviceType != regionDeviceType) {
                  item.setContentInsets(aDeviceType,
                                        item.getDefaultInsets(
                                           aDeviceType,
                                           newSelect.getStyle(aDeviceType)));
               }
            }
            newSelect.addItem(item);
         }
      }

      if ((controlBefore == null) && (selectToAddTo == null) && (bounds != null)) {
         if (group != null) {
            controlBefore =
               getControlBefore(
                  regionDeviceType,
                  group.getChildren(regionDeviceType).iterator(),
                  deviceType,
                  transform,
                  bounds);
         }
         else {
            controlBefore = region.getPage().getDialog().getControlBefore(
               region,
               deviceType,
               transform,
               bounds);
         }
      }
   

      // Special handling for the Voice case:
      boolean putVoiceTriggerBelowNewControl = false;
      boolean putVoiceContentAboveNewControl = false;
      Content newVoiceContent = null;
      Control controlAfter = null;
      Trigger placeholderToRemove = null;
      
      if ((newComponent instanceof Control) &&
          (newComponent.isVisibleToDeviceType(DeviceType.VOICE))) {
//         
//         // There are certain instances where a Content needs to be inserted,
//         // so that in the Voice view, responses always start and end at prompts,
//         // not other responses.
//         if (controlBefore == null) {
//            if (region.getName() == Direction.CENTER) {
//               final Page page = region.getPage();
//               final Dialog dialog = page.getDialog(); 
//               for (Iterator i =
//                    dialog.getPages(DeviceType.VOICE).iterator();
//                    i.hasNext(); ) {
//                  final Page aPage = (Page)i.next();
//                  final List/*<Control>*/ controls =
//                     aPage.getRegion(Direction.CENTER).getControls();
//                  if (!controls.isEmpty()) {
//                     controlAfter = (Control)controls.get(0);
//                     break;
//                  }
//               }
//            }
//            else {
//               final Page page = region.getPage();
//               final Dialog dialog = page.getDialog();
//               final Page voicePage = dialog.getFirstPage(DeviceType.VOICE);
//               final List/*<Control>*/ controls =
//                  voicePage.getRegion(region.getName()).getControls();
//               if (controls.isEmpty()) {
//                  controlAfter = null;
//               }
//               else {
//                  controlAfter = (Control)controls.get(0);
//               }
//            }
//         }
//         else {
//            final List/*<Control>*/ voiceControls =
//               controlBefore.getPageRegion(DeviceType.VOICE).getControls();
//            final int controlBeforeIndex = voiceControls.indexOf(controlBefore);
//            if (controlBeforeIndex == voiceControls.size() - 1) {
//               controlAfter = null;
//            }
//            else {
//               controlAfter = (Control)voiceControls.get(controlBeforeIndex + 1);
//            }
//         }
//         
//         putVoiceTriggerBelowNewControl =
//            !(newComponent instanceof Content) &&
//            !(newComponent instanceof Trigger) &&
//            !(controlAfter instanceof Trigger);
//
//         putVoiceContentAboveNewControl =
//            (((newComponent instanceof TextInput) ||
//              (newComponent instanceof SelectOne)) &&
//             !(controlBefore instanceof Content));
//
//         putVoiceContentAboveNewControl |=
//            ((newComponent instanceof Trigger) && (controlBefore == null));
//
//         
//         if (putVoiceTriggerBelowNewControl || putVoiceContentAboveNewControl) {
//            newVoiceContent = new Content(DeviceType.VOICE, Response.NULL_DISPLAY_STRING);
//         }

         // Find the control after controlBefore in the voice region
         final PageRegion voiceRegion = getCorrespondingRegion(
            region,
            controlBefore,
            DeviceType.VOICE);
         
         Control voiceControlAfter = null;
         if (!voiceRegion.getControls().isEmpty()) {
            if (!shouldSplitVoiceRegion(voiceRegion, newComponent)) {
               if (controlBefore == null) {
                  voiceControlAfter = (Control)voiceRegion.getControls().get(0);
               }
               else {
                  voiceControlAfter = 
                     DamaskUtils.getNextLowLevelControl(
                        voiceRegion, controlBefore);
               }
               
               // If a Trigger is inserted above a voice trigger placeholder, then
               // remove the placeholder
               if ((voiceControlAfter instanceof Trigger) &&
                   (newComponent instanceof Trigger)) {
                  placeholderToRemove = (Trigger)voiceControlAfter; 
               }
            }
         }
         
         putVoiceTriggerBelowNewControl =
            !(newComponent instanceof Content) &&
            !(newComponent instanceof Trigger) &&
            !(voiceControlAfter instanceof Trigger);

      }
      
      Content newContentAboveNewControl = null;
      Trigger newTriggerBelowNewControl = null;

      newVoiceContent = new Content(DeviceType.VOICE, Response.NULL_DISPLAY_STRING);
      
      if (putVoiceTriggerBelowNewControl) {
         newTriggerBelowNewControl = new Trigger(DeviceType.VOICE, newVoiceContent);
      }
      if (putVoiceContentAboveNewControl) {
         newContentAboveNewControl = newVoiceContent;
      }
      
      return new NewComponentInfo(
         newComponent, newContentAboveNewControl, newTriggerBelowNewControl,
         placeholderToRemove, selectToAddTo, controlBefore, group);
   }

   //---------------------------------------------------------------------------
   
//   /**
//    * Adjusts the width and height of the specified item to reflect 
//    * the insets for the specified device type.
//    */
//   private static void adjustItemBounds(
//      final Select.Item item,
//      final DeviceType deviceType,
//      final DeviceType regionDeviceType) {
//      
//      // Adjust the width and height of the item to reflect the insets.
//      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
//           i.hasNext(); ) {
//         final DeviceType aDeviceType = (DeviceType)i.next();
//         if (aDeviceType != regionDeviceType) {
//            final Insets2D userSpecInsets =
//               item.getContentInsets(regionDeviceType);
//            final Insets2D newInsets =
//               item.getContentInsets(aDeviceType);
//            
//            final Rectangle2D userSpecItemBounds =
//               item.getBounds(regionDeviceType);
//            
//            item.getContent()
//                .setBounds(aDeviceType,
//                           item.getContent().getBounds(regionDeviceType));
//    
//            final AffineTransform userSpecItemContentTransform =
//               item.getContent().getTransform(regionDeviceType);
//            
//            userSpecItemContentTransform.preConcatenate(
//               AffineTransform.getTranslateInstance(
//                  newInsets.getLeft() - userSpecInsets.getLeft(),
//                  newInsets.getTop() - userSpecInsets.getTop()));
//            
//            item.getContent()
//                .setTransform(aDeviceType, userSpecItemContentTransform);
//    
//            item.setBounds(
//               aDeviceType,
//               new Rectangle2D.Double(
//                  userSpecItemBounds.getX(),
//                  userSpecItemBounds.getY(),
//                  userSpecItemBounds.getWidth() -
//                     (userSpecInsets.getLeft() - newInsets.getLeft()) -
//                     (userSpecInsets.getRight() - newInsets.getRight()),
//                  userSpecItemBounds.getHeight() -
//                     (userSpecInsets.getTop() - newInsets.getTop()) -
//                     (userSpecInsets.getBottom() - newInsets.getBottom())));
//         }
//      }
//   }

   /**
    * Returns the bounds of the specified component.
    */
   private static Rectangle2D getBounds(
      final Component component,
      final PageRegion region) {

      final DeviceType deviceType = region.getDeviceType();
      if (component instanceof Control) {
         return ((Control)component).getBounds(deviceType);
      }
      else {
         return ((ComponentGroup)component).getBoundsInPageRegion(region);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the transform of the specified component.
    */
   private static AffineTransform getTransform(
      final Component component,
      final PageRegion region) {

      final DeviceType deviceType = region.getDeviceType();
      if (component instanceof Control) {
         return ((Control)component).getTransform(deviceType);
      }
      else {
         return ((ComponentGroup)component).getTransformInPageRegion(region);
      }
   }

   //---------------------------------------------------------------------------
   
//   private static final int VERTICAL_GAP_BETWEEN_CONTROLS = 2;
//   private static final int HORIZONTAL_GAP_BETWEEN_CONTROLS = 6;
//   
//   //---------------------------------------------------------------------------
//
//   private static void repositionNewControl(
//      final PageRegion userSpecRegion,
//      final Control controlBefore,
//      final Control control) {
//   
//      final DeviceType userSpecDeviceType = userSpecRegion.getDeviceType();
//
//      final Rectangle2D userSpecBounds = control.getBounds(userSpecDeviceType);
//      final AffineTransform userSpecTransform =
//         control.getTransform(userSpecDeviceType);
//      
//      // For device types where the new control is not being manually
//      // added by the designer...
//      for (Iterator i = control.getDeviceTypesVisibleTo().iterator();
//         i.hasNext(); ) {
//      
//         final DeviceType aDeviceType = (DeviceType)i.next();
//         final PageRegion aRegion = getCorrespondingRegion(userSpecRegion,
//                                                           controlBefore,
//                                                           aDeviceType);
//         
//         // If the component already has bounds for this device type, then
//         // they do not need to be changed
//         if (control.getBounds(aDeviceType) != null) {
//            continue;
//         }
//         
//         // If the component is a select control, then adjust the width and
//         // height of each item to reflect the insets.
//         if (control instanceof Select) {
//            final Select select = (Select)control;
//            for (Iterator j = select.getItems().iterator(); j.hasNext(); ) {
//               final Select.Item item = (Select.Item)j.next();
//               final Insets2D userSpecInsets =
//                  item.getContentInsets(userSpecDeviceType);
//               final Insets2D newInsets =
//                  item.getContentInsets(aDeviceType);
//               
//               final Rectangle2D userSpecItemBounds =
//                  item.getBounds(userSpecDeviceType);
//               
//               item.getContent()
//                   .setBounds(aDeviceType,
//                              item.getContent().getBounds(userSpecDeviceType));
//
//               final AffineTransform userSpecItemContentTransform =
//                  item.getContent().getTransform(userSpecDeviceType);
//               
//               userSpecItemContentTransform.preConcatenate(
//                  AffineTransform.getTranslateInstance(
//                     newInsets.getLeft() - userSpecInsets.getLeft(),
//                     newInsets.getTop() - userSpecInsets.getTop()));
//               
//               item.getContent()
//                   .setTransform(aDeviceType, userSpecItemContentTransform);
//
//               item.setBounds(
//                  aDeviceType,
//                  new Rectangle2D.Double(
//                     userSpecItemBounds.getX(),
//                     userSpecItemBounds.getY(),
//                     userSpecItemBounds.getWidth() -
//                        (userSpecInsets.getLeft() - newInsets.getLeft()) -
//                        (userSpecInsets.getRight() - newInsets.getRight()),
//                     userSpecItemBounds.getHeight() -
//                        (userSpecInsets.getTop() - newInsets.getTop()) -
//                        (userSpecInsets.getBottom() - newInsets.getBottom())));
//            }
//         }
//         else {
//            final Content content = control.getContent(); 
//            if (content != null) {
//               content.setBounds(aDeviceType,
//                                 content.getBounds(userSpecDeviceType));
//               content.setTransform(aDeviceType,
//                                    content.getTransform(userSpecDeviceType));
//            }
//         }
//         
//         
//         // Desktop -> Smartphone
//         // Voice -> Desktop
//         if (((userSpecDeviceType == DeviceType.DESKTOP)
//              && (aDeviceType == DeviceType.SMARTPHONE)) ||
//              // Voice -> Smartphone
//             ((userSpecDeviceType == DeviceType.VOICE)
//              && (aDeviceType != DeviceType.VOICE)) ||
//              // Desktop -> Voice
//              // Smartphone -> Voice
//              ((userSpecDeviceType != DeviceType.VOICE)
//              && (aDeviceType == DeviceType.VOICE))) {
//
//            // Initially make the bounds for this device type the same as for
//            // userSpecRegion.
//            Rectangle2D componentNewBounds;
//            
//            componentNewBounds = (Rectangle2D)userSpecBounds.clone();
//           
//            // Shrink the new control to fit the device type's characteristics,
//            // if necessary.
//            if ((control instanceof Content)
//               && (componentNewBounds.getHeight()
//                  > aDeviceType.getPreferredContentHeight())) {
//
//               final double frac =
//                  aDeviceType.getPreferredContentHeight()
//                     / componentNewBounds.getHeight();
//
//               componentNewBounds =
//                  new Rectangle2D.Double(
//                     componentNewBounds.getX(),
//                     componentNewBounds.getY(),
//                     componentNewBounds.getWidth() * frac,
//                     componentNewBounds.getHeight() * frac);
//            }
//            
//            // If the new control is a select item, then adjust the width and
//            // height to conform to the new insets, if necessary.
//            else if (control instanceof Select.Item) {
//               final Select.Item item = (Select.Item)control;
//
//               final Insets2D userSpecInsets =
//                  item.getContentInsets(userSpecDeviceType);
//
//               final Insets2D newInsets = item.getContentInsets(aDeviceType);
//               
//               componentNewBounds =
//                  new Rectangle2D.Double(
//                     componentNewBounds.getX(),
//                     componentNewBounds.getY(),
//                     componentNewBounds.getWidth()
//                        - (userSpecInsets.getLeft() - newInsets.getLeft())
//                        - (userSpecInsets.getRight() - newInsets.getRight()),
//                     componentNewBounds.getHeight()
//                        - (userSpecInsets.getTop() - newInsets.getTop())
//                        - (userSpecInsets.getBottom() - newInsets.getBottom()));
//
//               final AffineTransform userSpecItemContentTransform =
//                  item.getContent().getTransform(userSpecDeviceType);
//               
//               userSpecItemContentTransform.preConcatenate(
//                  AffineTransform.getTranslateInstance(
//                     newInsets.getLeft() - userSpecInsets.getLeft(),
//                     newInsets.getTop() - userSpecInsets.getTop()));
//               
//               item.getContent()
//                   .setTransform(aDeviceType, userSpecItemContentTransform);
//            }
//            
//            // Set the bounds for this device type.
//            if (control.getBounds(aDeviceType) == null) {
//               control.setBounds(aDeviceType, componentNewBounds);
//            }
//            
//            if (controlBefore == null) {
//               // Simply position in the upper left-hand corner.
//               control.setTransform(aDeviceType, new AffineTransform());
//            }
//            else {
//               // Position the new control underneath or to the right of
//               // controlBefore, depending on the orientation of the page
//               // region.
//               final Rectangle2D controlBeforeBounds =
//                  controlBefore.getBoundsInParentCoords(aDeviceType);
//
//               // If the control being inserted is a FULL-style select control,
//               // then place each item separately.
//               if ((control instanceof Select)
//                     && (((Select) control).getStyle(aDeviceType) == Select.FULL)) {
//                  
//                  final double beforeX = controlBeforeBounds.getX();
//                  final double beforeY = controlBeforeBounds.getY();
//                  double newX = controlBeforeBounds.getMaxX() +
//                                HORIZONTAL_GAP_BETWEEN_CONTROLS;
//                  double newY = controlBeforeBounds.getMaxY() +
//                                VERTICAL_GAP_BETWEEN_CONTROLS;
//
//                  for (Iterator j = ((Select) control).getItems().iterator(); 
//                       j.hasNext();) {
//                     final Select.Item item = (Select.Item)j.next();
//                     final Rectangle2D itemBounds = item.getBounds(userSpecDeviceType); 
//                     item.setBounds(aDeviceType, itemBounds);
//                     
//                     final AffineTransform itemNewTransform;
//                     
//                     if (aRegion.getOrientation() == Orientation.VERTICAL) {
//                        itemNewTransform = AffineTransform.getTranslateInstance(
//                           beforeX - itemBounds.getX(),
//                           newY - itemBounds.getY());
//                        newY += itemBounds.getHeight() +
//                                VERTICAL_GAP_BETWEEN_CONTROLS;
//                     }
//                     else {
//                        itemNewTransform = AffineTransform.getTranslateInstance(
//                           newX - itemBounds.getX(),
//                           beforeY - itemBounds.getY());
//                        newX += itemBounds.getWidth() +
//                                HORIZONTAL_GAP_BETWEEN_CONTROLS;
//                     }
//                     item.setTransform(aDeviceType, itemNewTransform);
//                  }
//               }
//               else {
//                  final AffineTransform controlNewTransform =
//                     AffineTransform.getTranslateInstance(
//                        controlBeforeBounds.getX(), controlBeforeBounds.getY());
//                  
//                  controlNewTransform.preConcatenate(
//                     AffineTransform.getTranslateInstance(
//                        -componentNewBounds.getX(),
//                        -componentNewBounds.getY()));
//            
//                  if (aRegion.getOrientation() == Orientation.VERTICAL) {
//                     controlNewTransform.preConcatenate(
//                        AffineTransform.getTranslateInstance(
//                           0,
//                           controlBeforeBounds.getHeight()
//                              + VERTICAL_GAP_BETWEEN_CONTROLS));
//                  }
//                  else {
//                     controlNewTransform.preConcatenate(
//                        AffineTransform.getTranslateInstance(
//                           controlBeforeBounds.getWidth()
//                              + HORIZONTAL_GAP_BETWEEN_CONTROLS,
//                           0));
//                  }
//                  control.setTransform(aDeviceType, controlNewTransform);
//               }
//            }
//         }
//
//         // Smartphone -> Desktop
//         else {
//            control.setBounds(
//               aDeviceType, control.getBounds(userSpecDeviceType));
//               
//            // Place the control in the same place relative to the dimensions
//            // of the desktop page region.
//            final double fracX =
//               userSpecTransform.getTranslateX()
//                  / userSpecRegion.getBounds().getWidth();
//            final double fracY =
//               userSpecTransform.getTranslateY()
//                  / userSpecRegion.getBounds().getHeight();
//
//            control.setTransform(
//               aDeviceType,
//               new AffineTransform(
//                  userSpecTransform.getScaleX(), userSpecTransform.getShearY(),
//                  userSpecTransform.getShearX(), userSpecTransform.getScaleY(),
//                  fracX * aRegion.getBounds().getWidth(),
//                  fracY * aRegion.getBounds().getHeight()));
//         }
//      }
//   }
//
//   
//   private static void repositionNewGroup(
//      final PageRegion userSpecRegion,
//      final Control controlBefore,
//      final ComponentGroup group) {
//
//      final Map/*<PageRegion, Rectangle2D>*/ newBoundsForRegion =
//         new HashMap/*<PageRegion, Rectangle2D>*/();
//      
//      // For device types where the new group is not being manually
//      // added by the designer...
//      for (Iterator i = group.getDeviceTypesVisibleTo().iterator();
//         i.hasNext(); ) {
//      
//         final DeviceType aDeviceType = (DeviceType)i.next();
//
//         // If the group already has bounds for this device type, then
//         // they do not need to be changed
//         if (!group.getPageRegions(aDeviceType).isEmpty()) {
//            continue;
//         }
//         
//         // If there are no children for this device type, then simply
//         // set the bounds to be the default size
//         final Set children = group.getChildren(aDeviceType);
//         if (children.isEmpty()) {
//            final PageRegion aRegion = getCorrespondingRegion(userSpecRegion,
//                                                               controlBefore,
//                                                               aDeviceType);
//            final double groupX;
//            final double groupY;
//            
//            
//            if (controlBefore == null) {
//               groupX = 0;
//               groupY = 0;
//            }
//            else {
//               final Rectangle2D controlBeforeBounds =
//                  controlBefore.getBoundsInParentCoords(aDeviceType);
//               groupX = controlBeforeBounds.getX();
//               groupY = controlBeforeBounds.getY();
//            }
//            newBoundsForRegion.put(
//               aRegion,
//               new Rectangle2D.Double(groupX, groupY,
//                                      aDeviceType.getGroupDefaultWidth(),
//                                      aDeviceType.getGroupDefaultHeight()));
//         }
//         else {
//            // Otherwise, make the bounds the union of the bounds of the
//            // contained components
//            for (Iterator j = children.iterator(); j.hasNext(); ) {
//               final Component child = (Component)j.next();
//               if (child instanceof Control) {
//                  final Control childControl = (Control)child;
//                  final Rectangle2D childControlBounds =
//                     childControl.getBoundsInParentCoords(aDeviceType);
//                  final PageRegion regionForChild =
//                     childControl.getPageRegion(aDeviceType); 
//                  Rectangle2D bounds =
//                     (Rectangle2D)newBoundsForRegion.get(regionForChild);
//                  if (bounds == null) {
//                     bounds = childControlBounds;
//                  }
//                  else {
//                     Rectangle2D.union(bounds, childControlBounds, bounds);
//                  }
//                  newBoundsForRegion.put(regionForChild, bounds);
//               }
//               else {
//                  final ComponentGroup childGroup = (ComponentGroup)child;
//                  for (Iterator k = childGroup
//                        .getPageRegions(aDeviceType).iterator(); k.hasNext();) {
//                     final PageRegion regionForChild = (PageRegion)k.next();
//                     final Rectangle2D childGroupBounds =
//                        GeomLib.transformRectangle(
//                           childGroup.getTransformInPageRegion(regionForChild),
//                           childGroup.getBoundsInPageRegion(regionForChild));
//                     Rectangle2D bounds =
//                        (Rectangle2D)newBoundsForRegion.get(regionForChild);
//                     if (bounds == null) {
//                        bounds = childGroupBounds;
//                     }
//                     else {
//                        Rectangle2D.union(bounds, childGroupBounds, bounds);
//                     }
//                     newBoundsForRegion.put(regionForChild, bounds);
//                  }
//               }
//            }
//         }
//      }
//            
//      for (Iterator i = newBoundsForRegion.keySet().iterator(); i.hasNext();) {
//         final PageRegion region = (PageRegion)i.next();
//         group.setBoundsInPageRegion(
//            region, (Rectangle2D) newBoundsForRegion.get(region));
//         group.setTransformInPageRegion(region, new AffineTransform());
//      }
//   }
//   
//   /**
//    * Moves <code>component</code> below <code>controlBefore</code> for all
//    * of <code>component</code>'s device types except in
//    * <code>userSpecRegion</code> 's.
//    */   
//   public static void repositionNewComponent(
//      final PageRegion userSpecRegion,
//      final Control controlBefore,
//      final Component component) {
//      
//      if (component instanceof Control) {
//         repositionNewControl(userSpecRegion, controlBefore, (Control)component);
//      }
//      else {
//         repositionNewGroup(userSpecRegion, controlBefore, (ComponentGroup)component);
//      }
//   }
   
   /**
    * Moves controls in the specified region below the specified control
    * down by the specified height.
    */
   private static void addCommandsForMovingOverlappingComponentsToMacroCommand(
         final MacroCommand cmd,
         final PageRegion region,
         final Rectangle2D newControlBounds,
         final double dx,
         final double dy) {

      final DeviceType deviceType = region.getDeviceType();
      final List/*<Control>*/ controls = region.getControls();
      
      for (Iterator i = controls.iterator(); i.hasNext(); ) {
         final Control control = (Control)i.next();
         final Rectangle2D controlBounds =
            control.getBoundsInParentCoords(deviceType);
         
         boolean shouldMove = false;
         if (dx < 0) {
            shouldMove |= (controlBounds.getX() <= newControlBounds.getX());
         }
         else if (dx > 0) {
            shouldMove |= (controlBounds.getX() >= newControlBounds.getX());
         }
         if (dy < 0) {
            shouldMove |= (controlBounds.getY() <= newControlBounds.getY());
         }
         else if (dy > 0) {
            shouldMove |= (controlBounds.getY() >= newControlBounds.getY());
         }
         
         if (shouldMove) {
            if ((control instanceof Select)
                  && (((Select) control).getStyle(deviceType) == Select.FULL)) {
               for (Iterator j = ((Select) control).getItems().iterator(); 
                    j.hasNext();) {
                  final Select.Item item = (Select.Item) j.next();
                  final AffineTransform transform =
                     item.getTransform(deviceType);
                  transform.preConcatenate(
                     AffineTransform.getTranslateInstance(dx, dy));
                  cmd.addCommand(new SetTransformCommand(item, deviceType,
                        transform));
               }
            }
            else {
               final AffineTransform transform = control
                     .getTransform(deviceType);
               transform.preConcatenate(AffineTransform
                     .getTranslateInstance(dx, dy));
               cmd.addCommand(new SetTransformCommand(control, deviceType,
                     transform));
            }
         }
      }
   }

   //===========================================================================
   
   /**
    * Returns the following:
    * 
    * <ul>
    * <li>If the previous voice control is a select-many control, then returns
    * the last item in that control
    * <li>If the specified control is a select-many item, then returns the
    * previous item in the select-many control  
    * <li>If the specified control is the first item in a select-many control,
    * then returns the control before the select-many control (which may
    * be another select-many item)
    * <li>Otherwise, returns the previous control
    * </ul>
    */
   public static Control getPreviousLowLevelControl(
      final PageRegion region, final Control control) {

      if (control instanceof Select.Item) {
         final Select.Item item = (Select.Item)control;
         final Select select = item.getParent();
         
         final int index = select.getItems().indexOf(item); 
         if ((index > 0) &&
             (select.getStyle(region.getDeviceType()) == Select.FULL)) {
            return (Select.Item)select.getItems().get(index - 1); 
         }
         else {
            return getPreviousLowLevelControl(region, item.getParent());
         }
      }
      else {
         final Control controlBefore = region.getPreviousControl(control);
         
         if ((controlBefore instanceof Select) &&
             (((Select)controlBefore).getStyle(region.getDeviceType()) ==
              Select.FULL)) {
            final List/*<Select.Item>*/ items =
               ((Select)controlBefore).getItems();
            if (items.isEmpty()) {
               return getPreviousLowLevelControl(region, controlBefore);
            }
            else {
               return (Select.Item)items.get(items.size() - 1);
            }
         }
         else {
            return controlBefore;
         }
      }
   }


   /**
    * Returns the following:
    * 
    * <ul>
    * <li>If the next voice control is a select-many control, then returns
    * the first item in that control
    * <li>If the specified control is a select-many item, then returns the
    * next item in the select-many control  
    * <li>If the specified control is the last item in a select-many control,
    * then returns the control after the select-many control (which may
    * be another select-many item)
    * <li>Otherwise, returns the next control
    * </ul>
    */
   public static Control getNextLowLevelControl(
      final PageRegion region, final Control control) {

      if (control instanceof Select.Item) {
         final Select.Item item = (Select.Item)control;
         final Select select = item.getParent();
         final List/*<Select.Item>*/ items = select.getItems();
         
         final int index = items.indexOf(item); 
         if ((index < items.size() - 1) &&
             (select.getStyle(region.getDeviceType()) == Select.FULL)) {
            return (Select.Item)select.getItems().get(index + 1); 
         }
         else {
            return getNextLowLevelControl(region, item.getParent());
         }
      }
      else {
         final Control controlAfter = region.getNextControl(control);
         
         if ((controlAfter instanceof Select) &&
             (((Select)controlAfter).getStyle(region.getDeviceType()) ==
              Select.FULL)) {
            final List/*<Select.Item>*/ items =
               ((Select)controlAfter).getItems();
            if (items.size() == 0) {
               return controlAfter;
            }
            else {
               return (Select.Item)items.get(items.size() - 1);
            }
         }
         else {
            return controlAfter;
         }
      }
   }

   
   /**
    * Returns the previous prompt from the specified control. 
    */
   public static Control getPreviousControlWithPrompt(
      final PageRegion region, final Control control) {
      
      Control prevControl = getPreviousLowLevelControl(region, control);
      
      Rectangle2D prevPromptBounds = (prevControl == null) ?
                                     null :
                                     prevControl.getVoicePromptBounds();
      
      while ((prevPromptBounds == null) && (prevControl != null)) {
         prevControl = getPreviousLowLevelControl(region, prevControl);
         prevPromptBounds = (prevControl == null) ?
                            null :
                            prevControl.getVoicePromptBounds();
      }
      return prevControl;
   }
   
   /**
    * Returns the next prompt from the specified control. 
    */
   public static Control getNextControlWithPrompt(
      final PageRegion region, final Control control) {
      
      Control nextControl = getNextLowLevelControl(region, control);
      
      Rectangle2D nextPromptBounds = nextControl == null ?
                          null :
                          nextControl.getVoicePromptBounds();
      
      while ((nextPromptBounds == null) && (nextControl != null)) {
         nextControl = getNextLowLevelControl(region, nextControl);
         nextPromptBounds = nextControl == null ?
            null :
            nextControl.getVoicePromptBounds();
      }
      return nextControl;
   }

   public static String toShortString(final Object o) {
      if (o == null) {
         return "null";
      }
      String s = o.getClass().getName() + "@" +
         Integer.toHexString(o.hashCode());
      return s.replaceAll(".*\\.", "");      
   }
}
