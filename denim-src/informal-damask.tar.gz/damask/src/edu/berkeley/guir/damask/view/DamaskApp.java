package edu.berkeley.guir.damask.view;

import java.awt.EventQueue;
import java.awt.Frame;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.*;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import javax.swing.UIManager;
import javax.xml.bind.JAXBException;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.InteractionGraph;
import edu.berkeley.guir.damask.view.appevent.*;
import edu.berkeley.guir.damask.view.pattern.PatternBrowser;

/** 
 * The Damask application.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-28-2003 James Lin
 *                               Created DamaskApp.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-28-2003
 */
public class DamaskApp {
   private static final List/*<DamaskDocument>*/ documents =
      new ArrayList();
      
   private static final DamaskApp instance = new DamaskApp();
   // used solely for source of event
      
   private static int numNewDocs = 0;
   private static final DocumentListener docListener = new DocumentHandler();
   private static final AppEventSource appEventSource = new AppEventSource();
   private static DamaskFrame currentFrame = null;

   private static final String INITIAL_COLLECTION_ID = "DesignOfSites";
   private static final String INITIAL_PATTERN_ID = "PersonalECommerce";
   private static PatternBrowser patternBrowser = null;
   
   protected static final String PROP_WINDOW_X = "Window x";
   protected static final String PROP_WINDOW_Y = "Window y";
   protected static final String PROP_WINDOW_WIDTH = "Window width";
   protected static final String PROP_WINDOW_HEIGHT = "Window height";

   protected static final String PROP_RADAR_X = "Radar x";
   protected static final String PROP_RADAR_Y = "Radar y";
   protected static final String PROP_RADAR_WIDTH = "Radar width";
   protected static final String PROP_RADAR_HEIGHT = "Radar height";
   protected static final String PROP_RADAR_ZOOM = "Radar zoom";
   protected static final String PROP_RADAR_VISIBLE = "Radar view visible";
   
   private static final Logger logger =
      Logger.getLogger(DamaskApp.class.getName());

   private static Handler logHandler;
   
   static {
      // Use platform's look and feel
      try {
          UIManager.setLookAndFeel(
              UIManager.getSystemLookAndFeelClassName());
      }
      catch (Exception e) {
         // Ignore -- the standard look and feel is good enough
      }

      // Make all loggers write to a file
      try {
         String dateStr =
            DamaskUtils.dateToISO(System.currentTimeMillis()).replace(':', '-');

         logHandler =
            new FileHandler(DamaskAppUtils.getUserDirectory().getPath() +
                            "/damask-" + dateStr + ".log");
         Logger.getLogger("").addHandler(logHandler);
      }
      catch (SecurityException e) {
         // Ignore
      }
      catch (IOException e) {
         // Ignore
      }
   }

   
   /**
    * A helper class for displaying a frame. An instance of this class should
    * be invoked by AWT's {@link java.awt.EventQueue}. 
    */
   private static class FrameDisplayer implements Runnable {
      final Frame frame;
      public FrameDisplayer(Frame frame) {
         this.frame = frame;
      }
      public void run() {
         frame.show();
      }
   }
   
   /**
    * Runs Damask.
    */
   public static void main(final String[] args) {
      logger.info("Damask started");
      
      // Disable DirectX, since it seems to be crashing my machine.
      System.setProperty("sun.java2d.noddraw", "true");

      // Force the menu bar to be at the top of the screen on Macs.
      System.setProperty("apple.laf.useScreenMenuBar", "true");

      // Install custom handler for uncaught exceptions, so that we can log
      // them
      System.setProperty("sun.awt.exception.handler",
         DamaskAppExceptionHandler.class.getName());
      
      final DamaskFrame firstFrame = createNewDocument();
      
      // Set the size and location to what is stored in preferences, if
      // available
      final Preferences prefs = Preferences.userNodeForPackage(DamaskApp.class);

      final int newX = prefs.getInt(PROP_WINDOW_X, firstFrame.getX());
      final int newY = prefs.getInt(PROP_WINDOW_Y, firstFrame.getY());
      final int newWidth =
         prefs.getInt(PROP_WINDOW_WIDTH, firstFrame.getWidth());
      final int newHeight =
         prefs.getInt(PROP_WINDOW_HEIGHT, firstFrame.getHeight());
      firstFrame.setLocation(newX, newY);
      firstFrame.setSize(newWidth, newHeight);
      firstFrame.validate();
      
      setCurrentFrame(firstFrame);

      final DamaskRadarDialog radarDialog = firstFrame.getRadarDialog();
      final int newRadarX = prefs.getInt(PROP_RADAR_X, radarDialog.getX());
      final int newRadarY = prefs.getInt(PROP_RADAR_Y, radarDialog.getY());
      final int newRadarWidth =
         prefs.getInt(PROP_RADAR_WIDTH, radarDialog.getWidth());
      final int newRadarHeight =
         prefs.getInt(PROP_RADAR_HEIGHT, radarDialog.getHeight());
      radarDialog.setLocation(newRadarX, newRadarY);
      radarDialog.setSize(newRadarWidth, newRadarHeight);
      radarDialog.validate();
   }

   
   /**
    * Creates a new window containing an empty document.
    */
   public static DamaskFrame createNewDocument() {
      numNewDocs++;
      return createDocument(
         new DamaskDocument(new InteractionGraph(), numNewDocs));
   }

   
   /**
    * Creates a new window containing an empty document.
    */
   public static DamaskFrame openDocument(final File f) throws JAXBException {
      return createDocument(new DamaskDocument(f));
   }

   
   /**
    * Creates a new window containing a document that views the specified graph.
    */
   protected static DamaskFrame createDocument(final DamaskDocument doc) {
//      final javax.swing.JFrame stateFrame =
//         new javax.swing.JFrame("Damask Model");
//      stateFrame.getContentPane().add(
//         new javax.swing.JScrollPane(
//            new edu.berkeley.guir.damask.DamaskStateTree(doc.getGraph())));
//      stateFrame.pack();
//      stateFrame.show();
      documents.add(doc);
      doc.addDocumentListener(docListener);
      
      final DamaskFrame frame = new DamaskFrame(doc.createCanvasGroup());
      frame.initialize();
      
      // Display the frame on AWT's event queue.
      final Runnable runner = new FrameDisplayer(frame);
      EventQueue.invokeLater(runner);
      
      return frame;
   }
   

   /**
    * Tries exiting Damask, first prompting the user to save any
    * unsaved documents.
    */
   public static void tryExit() {
      // Copy the list of documents, to avoid concurrent modification
      // exceptions while closing
      final List docs = new ArrayList(documents);
      for (Iterator it = docs.iterator(); it.hasNext();) {
         final DamaskDocument doc = (DamaskDocument)it.next();
         
         if (!doc.tryClose(null)) {
            break;
         }
      }
   }
   
   
   /**
    * Exits Damask.
    */
   private static void exit() {
      logger.info("Damask exited");
      logHandler.close();
      System.exit(0);
   }


   /**
    * Returns a list of open documents.
    */
   public static List/*<DamaskDocument>*/ getDocuments() {
      return Collections.unmodifiableList(documents);
   }

   /**
    * Saves the location and size of the given DamaskFrame to user's
    * preferences.
    */
   private static void saveFrameInfo(final DamaskFrame frame) {
      final Preferences prefs = Preferences.userNodeForPackage(DamaskApp.class);
       
      prefs.putInt(PROP_WINDOW_X, frame.getX());
      prefs.putInt(PROP_WINDOW_Y, frame.getY());
      prefs.putInt(PROP_WINDOW_WIDTH, frame.getWidth());
      prefs.putInt(PROP_WINDOW_HEIGHT, frame.getHeight());
      
      final DamaskRadarDialog radarDialog = frame.getRadarDialog();
      prefs.putInt(PROP_RADAR_X, radarDialog.getX());
      prefs.putInt(PROP_RADAR_Y, radarDialog.getY());
      prefs.putInt(PROP_RADAR_WIDTH, radarDialog.getWidth());
      prefs.putInt(PROP_RADAR_HEIGHT, radarDialog.getHeight());
      prefs.putBoolean(PROP_RADAR_VISIBLE, radarDialog.isVisible());
      
      try {
         prefs.sync();
      }
      catch (BackingStoreException e) {
         // Ignore, but log it
         DamaskAppExceptionHandler.log(e);
      }
   }

   /**
    * Adds the specified listener to receive global app events.
    */
   public static void addAppListener(final AppListener listener) {
      appEventSource.addAppListener(listener);
   }

   /**
    * Removes the specified listener so that it no longer receives
    * global app events.
    */
   public static void removeAppListener(final AppListener listener) {
      appEventSource.removeAppListener(listener);
   }
   
   /**
    * Fires currentFrameChanged events to listeners.
    */
   public static void fireCurrentFrameChanged() {
      appEventSource.fireCurrentFrameChanged(instance);
   }

   /**
    * Returns the frame with the focus.
    */
   public static DamaskFrame getCurrentFrame() {
      return currentFrame;
   }

   /**
    * Sets the frame with the focus.
    */
   protected static void setCurrentFrame(final DamaskFrame currentFrame) {
      DamaskApp.currentFrame = currentFrame;
      fireCurrentFrameChanged();
   }
   
   /**
    * Returns the pattern browser.
    */
   public static PatternBrowser getPatternBrowser() {
      if (patternBrowser == null) {
         //TODO pattern browser should remember what was the last pattern viewed
         patternBrowser = new PatternBrowser(INITIAL_COLLECTION_ID, INITIAL_PATTERN_ID);
         patternBrowser.setVisible(false);
      }
      return patternBrowser;
   }
   
   /**
    * Returns the reference to the pattern browser, which may be null if
    * the designer hasn't opened it yet.
    */
   static PatternBrowser getPatternBrowserReference() {
      return patternBrowser;
   }
   
   /**
    * Handles document events.  
    */
   private static class DocumentHandler implements DocumentListener {

      public void documentModified(DocumentEvent e) {
      }

      public void documentCleaned(DocumentEvent e) {
      }

      public void documentRenamed(DocumentEvent e) {
      }

      public void documentClosed(DocumentEvent e) {
         // Close all of the frames associated with this document.
         final DamaskDocument doc = e.getDocument();
         final Collection framesForDoc = doc.getWindows();
      
         documents.remove(doc);
         doc.removeDocumentListener(docListener);
      
         for (Iterator i = framesForDoc.iterator(); i.hasNext(); ) {
            final DamaskFrame frame = (DamaskFrame)i.next();
         
            if (documents.isEmpty()) {
               // Since the last window was closed, save its location
               // and size to user's prefs.
               saveFrameInfo(frame);
            }
      
            frame.setVisible(false);
            frame.dispose();
         }
      
         doc.getGraph().dispose();
         
         if (documents.isEmpty()) {
            exit();
         }
      }

      public void documentBusyStarted(DocumentEvent e) {
      }

      public void documentBusyStopped(DocumentEvent e) {
      }

      public void canvasGroupAdded(DocumentEvent e) {
      }

      public void canvasGroupRemoved(DocumentEvent e) {
      }
   }
}
