package edu.berkeley.guir.lib.util;

/**
 * Utility methods for manipulating Booleans.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0-1.0.0, Jan 01 2004, JL
 *               Created class
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version GUIRLib-v1.5/1.0.0, Jan 01 2004 JL
 */
public final class BooleanLib {
   
   /**
    * Prevents instantiation.
    */
   private BooleanLib() {
   }
   
   
   /**
    * Returns the inverse of the given Boolean object.
    */
   public static Boolean invert(final Boolean booleanObj) {
      return Boolean.valueOf(!(booleanObj.booleanValue()));
   }
}
