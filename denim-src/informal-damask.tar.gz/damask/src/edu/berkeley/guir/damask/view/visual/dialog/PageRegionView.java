package edu.berkeley.guir.damask.view.visual.dialog;

import java.awt.*;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.List;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.pattern.PatternInstanceView;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.berkeley.guir.damask.view.visual.VisualLayer;
import edu.berkeley.guir.damask.view.visual.component.*;
import edu.berkeley.guir.damask.view.visual.component.Button;
import edu.berkeley.guir.damask.view.visual.component.Label;
import edu.berkeley.guir.damask.view.visual.component.Panel;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.util.PPaintContext;
import edu.umd.cs.piccolo.util.PPickPath;

/** 
 * A view of a page region.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-18-2003 James Lin
 *                               Created PageRegionView.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-18-2003
 */
public class PageRegionView
   extends InteractionElementView
   implements PageViewPart {

   public static final Paint BORDER_COLOR = new Color(215, 215, 215);
   public static final Paint SELECTED_BORDER_COLOR = new Color(0, 153, 0);
   public static final Color GRID_COLOR = new Color(0, 255, 255, 30);

   private static final Stroke TEMPLATE_CONTROLS_STROKE =
      new BasicStroke(
         1,
         BasicStroke.CAP_BUTT,
         BasicStroke.JOIN_MITER,
         1,
         new float[] { 4, 3 },
         0);

   private int inset;
   private final boolean grayOutTemplateElements;
   private boolean inRunMode = false;

   private final ElementContainerListener handler = new PageRegionHandler();
   private final ElementContainerListener templateHandler =
      new TemplatePageRegionHandler();
   private final InteractionElementListener elementHandler =
      new ElementHandler();
   private final ElementContainerListener dialogHandler = new DialogHandler();

   private final Map/*<Component, ComponentView>*/ views = new HashMap();
   private final Map/*<Page, List<ControlView>>*/ viewsFromTemplate =
      new HashMap();
   private WeakReference/*<Label>*/ mostRecentlyAddedLabel = null;
   
   // The children are in the following order:
   // template controls, panels, normal controls 
   private int firstNormalChildIndex = 0;
   private int firstGroupIndex = 0;
   
   public PageRegionView(
      final PageRegion region,
      final boolean grayOutTemplateElements) {

      super(region);

      setStrokePaint(BORDER_COLOR);

      // Paint the regions transparent so that they are pickable
      setPaint(DamaskAppUtils.NO_COLOR);

      this.grayOutTemplateElements = grayOutTemplateElements;
      
      // Listen to events from model objects
      region.addElementContainerListener(handler);
      region.addInteractionElementListener(elementHandler);
      region.getPage().getDialog().addElementContainerListener(dialogHandler);

      inset = region.getInset();

      // Bounds are set in PageViewContents.layoutChildren()

      addInputEventListener(new BasicInputEventHandler());
   }

   
   // Overrides method in ancestor class.
   protected void initAfterAddToParent() {
      setInRunMode(((PageViewContents)getParent()).isInRunMode());
      
      // Add controls
      final PageRegion region = (PageRegion) getModel();

      for (Iterator i = region.getControls().iterator(); i.hasNext();) {
         final Control control = (Control) i.next();
         addViewForNormalControl(control);
      }
      
      // Add groups
      for (Iterator i = region.getPage().getDialog().getGroups().iterator();
         i.hasNext();
         ) {

         final ComponentGroup group = (ComponentGroup)i.next();
         if (group.getTransformInPageRegion(region) != null) {
            addViewForGroup(group);
         }
      }

      // Add template
      for (Iterator i = region.getPage().getTemplates().iterator();
         i.hasNext();
         ) {
            
         final Page template = (Page)i.next();
         addTemplate(template);
      }
   }


   // Overrides method in parent class.
   public void dispose() {
      super.dispose();

      final PageRegion region = (PageRegion)getModel();
      region.removeElementContainerListener(handler);
      region.removeInteractionElementListener(elementHandler);
      region.getPage().getDialog().removeElementContainerListener(dialogHandler);
   }


   /**
    * Returns the contents of the page that this region is in.
    */   
   public PageViewContents getContents() {
      return (PageViewContents)getParent();
   }


   // @Override
   public PageView getPageView() {
      final PageViewContents contents = getContents();
      if (contents == null) {
         return null;
      }
      else {
         return contents.getPageView();
      }
   }


   // @Override
   public DialogView getDialogView() {
      final PageView pageView = getPageView();
      if (pageView == null) {
         return null;
      }
      else {
         final PNode parent = pageView.getParent();
         if (parent instanceof DialogView) {
            return (DialogView)parent;
         }
         else {
            return null;
         }
      }
   }
   
   
   /**
    * Returns the device type that this page region view handles.
    */
   public DeviceType getDeviceType() {
      return ((PageRegion)getModel()).getDeviceType();
   }


   /**
    * Returns the label most recently added to this page region, or
    * null if that label has been erased.
    */   
   public Label getMostRecentlyAddedLabel() {
      return (Label)mostRecentlyAddedLabel.get();
   }


   /**
    * Adds the proper view for the specified element.
    */
   private ControlView addViewForNormalControl(final Control control) {
      return (ControlView)addViewForComponent(getChildrenCount(), control);
   }
	
	   
   /**
    * Adds the proper view for the specified element.
    */
   private ControlView addViewForNormalControl(
      final int index,
      final Control control) {
      
      return (ControlView)addViewForComponent(
         index + firstNormalChildIndex,
         control);
   }
   
      
   /**
    * Adds the proper view for the specified template element.
    */
   private ControlView addViewForTemplateControl(
      final Page template,
      final Control control) {

      return addViewForTemplateControl(template, firstGroupIndex, control);
   }
   
      
   /**
    * Adds the proper view for the specified template element.
    */
   private ControlView addViewForTemplateControl(
      final Page template,
      final int index,
      final Control control) {

      final ControlView result =
         (ControlView)addViewForComponent(index, control);
      firstNormalChildIndex++;
      firstGroupIndex++;
      
      ((List)viewsFromTemplate.get(template)).add(result);
      
      if (grayOutTemplateElements) {
         DamaskAppUtils.setInternalStroke(result, TEMPLATE_CONTROLS_STROKE);
      }
      if (!result.isInRunMode()) {
         result.setSelectable(false);
         result.setPickable(false);
      }
      
      return result;
   }
   
      
   /**
    * Adds the proper view for the specified component group.
    */
   private Panel addViewForGroup(final ComponentGroup group) {
      return addViewForGroup(firstNormalChildIndex - firstGroupIndex, group);
   }
   
      
   /**
    * Adds the proper view for the specified template element.
    */
   private Panel addViewForGroup(
      final int index,
      final ComponentGroup group) {

      final Panel result =
         (Panel)addViewForComponent(index + firstGroupIndex, group);
      firstNormalChildIndex++;
      return result;
   }
   
      
   /**
    * Adds the proper view for the specified element at the specified index.
    */
   private ComponentView addViewForComponent(
      final int index,
      final Component component) {

      final ComponentView componentView;

      if (component instanceof Content) {
         componentView = new Label((Content)component);
         mostRecentlyAddedLabel = new WeakReference((Label)componentView);
      }
      else if (component instanceof Trigger) {
         final Trigger trigger = (Trigger)component;
         if (trigger.getStyle(getDeviceType()) == Trigger.BUTTON) {
            componentView = new Button((Trigger)component);
         }
         else {
            componentView = new Hyperlink((Trigger)component);
         }
      }
      else if (component instanceof TextInput) {
         componentView = new TextBox((TextInput)component);
      }
      else if (component instanceof SelectMany) {
         componentView = new CheckBoxGroup((SelectMany)component);
      }
      else if (component instanceof SelectOne) {
         final SelectOne selectOne = (SelectOne)component;
         if (selectOne.getStyle(getDeviceType()) == SelectOne.FULL) {
            componentView = new RadioButtonGroup((SelectOne)component);
         }
         else if (selectOne.getStyle(getDeviceType()) == SelectOne.COMPACT) {
            componentView = new ListBox((SelectOne)component);
         }
         else {
            assert selectOne.getStyle(getDeviceType()) == SelectOne.MINIMAL; 
            componentView = new ComboBox((SelectOne)component);
         }
      }
      else if (component instanceof ComponentGroup) {
         componentView = new Panel((ComponentGroup)component);
      }
      else {
         componentView = null;
         assert false : "element of type "
            + component.getClass()
            + " cannot be added to a page region";
      }
      addChild(index, componentView);
      componentView.setInRunMode(isInRunMode());
      
      if (componentView instanceof ControlView) {
         final ControlView controlView = (ControlView)componentView;
         final Control control = (Control)component;
         
         final Dialog dialogOfControl = control.getDialog();
         final int conditionForState;

         // If the control is a template control, then set the state
         // of the control to the template dialog's initial condition.
         if (dialogOfControl != ((Page) getPageView().getModel()).getDialog()) {
            conditionForState = dialogOfControl.getInitialCondition();
         }
         else {
            // Change the state of the component. If the page region view is in run
            // mode, then use the state for condition 0; otherwise, use the
            // state for the current design time condition.
            if (isInRunMode()) {
               conditionForState = 0;
            }
            else {
               conditionForState = getPageView().getDesignTimeCondition();
            }
         }
         
         // Otherwise, set the state of the control to that in
         // conditionForState.
         controlView.setState(
            (control.getStateForCondition(dialogOfControl, conditionForState)));
      }
      views.put(component, componentView);

      final VisualLayer layer =
         (VisualLayer)DamaskAppUtils.getAncestor(this, VisualLayer.class);

      if (layer != null) {

         // Make check boxes and radio buttons selectable in the Design windows.
         if ((componentView instanceof CheckBoxGroup)
            || (componentView instanceof RadioButtonGroup)) {
   
            layer.addSelectableParent(componentView);
         }
      
         // Fade the control if its device type doesn't match the current
         // device-type layer.
         componentView.deviceTypeLayerChanged();
         
         layer.trackAddition(componentView);
         
         // Add the view to any views of pattern instances it is a member of
         if (component instanceof Control) {
            for (Iterator i =
                  ((Control)component).getPatternInstanceMemberships().iterator();
                  i.hasNext(); ) {
               final PatternInstance instance = (PatternInstance)i.next();
               final PatternInstanceView instanceView =
                 (PatternInstanceView)layer.getView(instance);
               if (instanceView != null) {
                  instanceView.addMemberView(componentView);
               }
            }
         }
      }
      return componentView;
   }


   /**
    * Removes the proper view for the specified template element.
    */
   private void removeViewForTemplateControl(
      final Page template,
      final Control control) {

      final ControlView removedView =
         (ControlView)removeViewForComponent(control);
      ((List)viewsFromTemplate.get(template)).remove(removedView);
      firstNormalChildIndex--;
      firstGroupIndex--;
   }


   /**
    * Removes the proper view for the specified component group.
    */
   private void removeViewForGroup(final ComponentGroup group) {
      removeViewForComponent(group);
      firstNormalChildIndex--;
   }


   /**
    * Removes the proper view for the specified element.
    * 
    * @return the view that was removed
    */
   private ComponentView removeViewForComponent(final Component component) {
      final ComponentView componentView = (ComponentView)views.get(component);

      componentView.removeFromParent();
      views.remove(component);
      componentView.dispose();

      final DamaskLayer layer =
         (DamaskLayer)DamaskAppUtils.getAncestor(this, DamaskLayer.class);

      if (layer != null) {
         // Remove check box group or radio button group from list of
         // selectable parents
         if ((componentView instanceof CheckBoxGroup)
            || (componentView instanceof RadioButtonGroup)
            || (componentView instanceof Button)) {
   
            layer.removeSelectableParent(componentView);
         }
            
         // Remove the view from any views of pattern instances it is a member of
         if (component instanceof Control) {
            for (Iterator i =
                 ((Control)component).getPatternInstanceMemberships().iterator();
                 i.hasNext(); ) {
               final PatternInstance instance = (PatternInstance)i.next();
               final PatternInstanceView instanceView =
                  (PatternInstanceView)layer.getView(instance);
               if (instanceView != null) {
                  instanceView.removeMemberView(componentView);
               }
            }
         }
      }
      
      return componentView;
   }

   
   /**
    * Adds the objects from the page's template. 
    */
   protected void addTemplate(final Page newTemplate) {
      // Add the new template's elements (if the template isn't null).
      if (newTemplate != null) {
         if (viewsFromTemplate.get(newTemplate) == null) {
            viewsFromTemplate.put(newTemplate, new ArrayList());
         }

         final PageRegion region = (PageRegion)getModel();

         final PageRegion templateRegion =
            newTemplate.getRegion(region.getName());

         for (Iterator i = templateRegion.getControls().iterator();
            i.hasNext();
            ) {
      
            final Control control = (Control)i.next();
            final ControlView controlView =
               addViewForTemplateControl(newTemplate, control);
            controlView.setSelectable(false);
            if (grayOutTemplateElements) {
               DamaskAppUtils.setInternalStroke(
                  controlView,
                  TEMPLATE_CONTROLS_STROKE);
            }
         }
      
         // Listen to the template for changes
         templateRegion.addElementContainerListener(templateHandler);
      }
   }


   /**
    * Removes the objects from the page's template. 
    */
   protected void removeTemplate(final Page oldTemplate) {
      // Remove the old template's elements.
      if (oldTemplate != null) {
         final PageRegion region = (PageRegion)getModel();

         final PageRegion templateRegion =
            oldTemplate.getRegion(region.getName());

         final List/*<ControlView>*/ templateControlViews =
            (List)viewsFromTemplate.get(oldTemplate);

         for (Iterator i = templateControlViews.iterator(); i.hasNext(); ) {
            final ControlView controlView = (ControlView)i.next();
            removeChild(controlView);
            firstNormalChildIndex--;
            firstGroupIndex--;
         }
         templateControlViews.clear();
      
         // Stop listening to the template for changes
         templateRegion.removeElementContainerListener(templateHandler);
      }
   }


   /**
    * Returns whether this page view is in Run mode.
    */
   public boolean isInRunMode() {
      return inRunMode;
   }

   /**
    * Sets whether this page view is in Run mode, when the controls behave
    * as if the user is interacting with them.
    */
   public void setInRunMode(boolean flag) {
      inRunMode = flag;
      for (Iterator j = getChildrenIterator(); j.hasNext();) {
         final Object child = j.next();
         if (child instanceof ComponentView) {
            ((ComponentView)child).setInRunMode(flag);
         }
      }
   }


   /**
    * Returns the inset of this page region view.
    */
   public int getInset() {
      return inset;
   }
   
   /**
    * Sets the inset of this page region view. Used only internally and by
    * PageViewContents during resizing.
    */
   public void setInset(final int inset) {
      this.inset = inset;
   }

   //=========================================================================
   // The code below mimics functionality in edu.umd.cs.piccolox.nodes.PClip.

   protected void paint(PPaintContext paintContext) {
      if (!isInRunMode()) {
         if (paintContext.getScale()
            >= DamaskCanvas.scaleFactor(DamaskCanvas.BETWEEN_STORYBOARD_PAGE)
               - 0.02) {   // 0.02 is an arbitrary fudge factor
            final Graphics2D g2 = paintContext.getGraphics();
            final Paint oldPaint = g2.getPaint();
            final DeviceType deviceType = getDeviceType();
            g2.setPaint(GRID_COLOR);

            if (deviceType.getGridWidth() > 0) {
               for (int x = 0; x <= getWidth(); x += deviceType.getGridWidth()) {
                  g2.drawLine(x, 0, x, (int)getHeight());
               }
            }
            
            if (deviceType.getGridHeight() > 0) {
               for (int y = 0; y <= getHeight(); y += deviceType.getGridHeight()) {
                  g2.drawLine(0, y, (int)getWidth(), y);
               }
            }
            g2.setPaint(oldPaint);
         }
      }
      clipPaint(paintContext);
   }

   protected void paintAfterChildren(PPaintContext paintContext) {
      clipPaintAfterChildren(paintContext);
   }

   public boolean fullPick(PPickPath pickPath) {
      return clipFullPick(pickPath);
   }

   // The code above mimics functionality in edu.umd.cs.piccolox.nodes.PClip.
   //=========================================================================

   /** 
    * Handles element container events from the page region model.
    */
   private class PageRegionHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         addViewForNormalControl(e.getIndex(), (Control)e.getElement());
      }

      public void elementRemoved(ElementContainerEvent e) {
         removeViewForComponent((Control)e.getElement());
      }
   }

   /** 
    * Handles element container events from the model of the template page.
    */
   private class TemplatePageRegionHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         addViewForTemplateControl(
            ((PageRegion)e.getSource()).getPage(),
            e.getIndex(),
            (Control)e.getElement());
      }

      public void elementRemoved(ElementContainerEvent e) {
         removeViewForTemplateControl(
            ((PageRegion)e.getSource()).getPage(),
            (Control)e.getElement());
      }
   }


   /**
    * Handles events from the dialog associated with the model of this
    * object.
    */
   private class DialogHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         if (e.getElement() instanceof ComponentGroup) {
            final ComponentGroup group = (ComponentGroup)e.getElement();
            if (group.getDeviceTypesVisibleTo().contains(getDeviceType())) {
               if (group.getTransformInPageRegion((PageRegion)getModel()) != null) {
                  addViewForGroup(group);
               }
            }
         }
      }

      public void elementRemoved(ElementContainerEvent e) {
         if (e.getElement() instanceof ComponentGroup) {
            final ComponentGroup group = (ComponentGroup)e.getElement();
            if (group.getDeviceTypesVisibleTo().contains(getDeviceType())) {
               if (group.getTransformInPageRegion((PageRegion)getModel()) != null) {
                  removeViewForGroup(group);
               }
            }
         }
      }
   }


   /**
    * Handles events from the model object. 
    */
   private class ElementHandler implements InteractionElementListener {
      public void elementBoundsUpdated(InteractionElementEvent e) {
         setInset(((PageRegion)getModel()).getInset());
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
         setInset(((PageRegion)getModel()).getInset());
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }


   /**
    * Listens to mouse and key events in the canvas's main camera.
    */
   private class BasicInputEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         if (event.getComponent() instanceof VisualCanvas) {
            final VisualCanvas canvas = (VisualCanvas)event.getComponent();
            if (!canvas.isWindowBoundsChanging()) {
               canvas.setSelectedPageRegionView(PageRegionView.this);
               updateHandles(event);
            }
         }
      }
      
      private void updateHandles(PInputEvent event) {
         if (event.getComponent() instanceof VisualCanvas) {
            ((VisualCanvas)event.getComponent()).attachHandles(
               getPageView(),
               event.getCamera());
         }
      }
   }
}
