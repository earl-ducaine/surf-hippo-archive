package edu.berkeley.guir.lib.gesture.util;

import java.lang.System;
import java.lang.ClassCastException;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.JComponent;
import java.awt.Component;

/**
 * Adds hysteresis to a Component.  That is, when the user resizes the
 * Component, that becomes its preferredSize, so subsequent pack()
 * operations will not change its size (although it can still be
 * resized manually or with setSize() and its preferredSize can be
 * changed with setPreferredSize()).
 */
public class HystericResizer extends ComponentAdapter
{
  public HystericResizer()
  {
  }
  
  public void componentResized(ComponentEvent e)
  {
    Component component = e.getComponent();
    JComponent jc;
    try {
      jc = (JComponent) component;
    }
    catch (ClassCastException exception) {
      System.err.println("Can only use HystericReziser with a JComponent." +
		" Details: " + exception);
      return;
    }
    jc.setPreferredSize(jc.getSize());
  }
}
