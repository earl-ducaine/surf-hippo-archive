package edu.berkeley.guir.damask.view.visual.event;

import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.text.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.appdialogs.EditListDialog;
import edu.berkeley.guir.damask.view.event.StyledTextEventHandler;
import edu.berkeley.guir.damask.view.visual.component.*;
import edu.berkeley.guir.damask.view.visual.component.ComponentView;
import edu.berkeley.guir.damask.view.visual.component.Label;
import edu.berkeley.guir.damask.view.visual.dialog.PageRegionView;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolox.nodes.PStyledText;

/**
 * The event handler for entering text.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-15-2004 James Lin
 *                               Changed TextHandler from a static inner class
 *                               of DamaskCanvas to its own top-level class 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-15-2004
 */
public class TextHandler extends StyledTextEventHandler {
   private Label label = null;
   private final Color LABEL_EDIT_COLOR = Color.LIGHT_GRAY;
   private Content.DisplayMode labelOrigDispMode = null;
   private PageRegionView regionView = null;
   private final PStyledText styledText = createText();
      
   public TextHandler() {
      super();
      init();
   }

   public TextHandler(JTextComponent editor) {
      super(editor);
      init();
   }

   private void init() {
      DamaskAppUtils.setFont(styledText, DamaskAppUtils.getDefaultFont());
   }
   
   public void mousePressed(PInputEvent event) {
      final PNode pickedNode = event.getPickedNode();

      if ((label != null) || (editedText != null)) {
         stopEditing();
      }
      
      DamaskAppUtils.setText(styledText, "");
      DamaskAppUtils.setFont(styledText, DamaskAppUtils.getDefaultFont());
      
      if (pickedNode instanceof PageRegionView) {
         // Potentially create a new text label
         regionView = (PageRegionView)pickedNode;

         final Insets pInsets = styledText.getInsets();
         pickedNode.addChild(styledText); // will be removed in stopEditing()

         final Point2D position = event.getPosition();
         pickedNode.globalToLocal(position);

         styledText.setOffset(
            position.getX() - pInsets.left,
            position.getY() - pInsets.top);
            
         startEditing(event, styledText);
      }
      else if (pickedNode instanceof ComponentView) {
         // Potentially edit an existing component
         final ComponentView componentView = (ComponentView)pickedNode;
         final Object contents = componentView.getEditableContents();
         if (contents instanceof Label) {
            label = (Label)contents;
            final DamaskLayer layer = label.getLayer();
            
            if (((Content)label.getModel()).getDeviceType() != layer.getDeviceTypeForNewElement()) {
               if (!DamaskAppUtils.askToChangeLayers(layer,
                  (JComponent)event.getComponent())) {
                  label = null;
                  return;
               }
            }
            
            labelOrigDispMode = label.getDisplayMode();
            label.setLabelColor(LABEL_EDIT_COLOR);
            final Content content = ((Content)label.getModel());
            
            DamaskAppUtils.setText(styledText, label.getText().getText());
            DamaskAppUtils.setFontSize(
               styledText, content.getTextSize(label.getDeviceType()));
         
            final Insets pInsets = styledText.getInsets();

            label.setVisible(false);
            
            layer.addChild(styledText);
            // will be removed in stopEditing()

            final PBounds labelGlobalBounds = label.getBounds();
            label.localToGlobal(labelGlobalBounds);
               
            final Point2D position = labelGlobalBounds.getOrigin();

            styledText.setOffset(
               position.getX() - pInsets.left,
               position.getY() - pInsets.top);
            
            startEditing(event, styledText);

         }
         else if (contents instanceof List/*<Label>*/) {
            editContentList(
               event,
               (ControlView)componentView,
               (List)contents);
         }
      }
   }


   /**
    * Prompts the user to change the items in the selected control.
    */
   private void editContentList(
      final PInputEvent event,
      final ControlView controlView,
      final List contentList) {
         
      final Select select = (Select)controlView.getModel();
      final String[] items = new String[contentList.size()];
      for (int i = 0, n = items.length; i < n; i++) {
         items[i] =
            ((Content) ((Label)contentList.get(i)).getModel()).getText();
      }
         
      final DamaskCanvas canvas = (DamaskCanvas)event.getComponent();

      final Window parentWin = (Window)SwingUtilities.getRoot(canvas);
         
      // Note that we have to translate the point according
      // to the default window
      final Point2D pt = event.getCanvasPosition();
      int x = (int)pt.getX() + canvas.getX();
      int y = (int)pt.getY() + canvas.getY();
         
      final EditListDialog dlg;
      if (parentWin instanceof Frame) {
         dlg = new EditListDialog((Frame)parentWin, items, x, y);
      }
      else {
         dlg = new EditListDialog(items);
      }
         
      dlg.setVisible(true);
      if (dlg.wasOKPressed()) {
         final String[] newItems = dlg.getValues();
         final MacroCommand command = new ModifyGraphMacroCommand();
            
         DamaskAppUtils.addCommandsToModifySelectItemsToMacroCommand(
            select, canvas, newItems, command, false);
         
         canvas.getDocument().getCommandQueue().doCommand(canvas, command);
      }
   }

   public void stopEditing() {
      if (canvas instanceof DamaskCanvas) {
         ((DamaskCanvas)canvas).setTextEditing(false);
      }
      
      if (editedText != null) {
         final DamaskCanvas damaskCanvas = (DamaskCanvas)canvas;
         final Document editedDoc = editedText.getDocument(); 
         editedDoc.removeDocumentListener(docListener);
         editedText.setEditing(false);
         editedText.syncWithDocument();

         editedText.removeFromParent();
         
         // If the document is empty...
         if (editedText.getDocument().getLength() == 0) {
            if (label != null) {
               label.setDisplayMode(labelOrigDispMode);
               label.setVisible(true);
            }
         }
         else {
            // If label isn't null, then edit the label's content
            if (label != null) {
               label.setDisplayMode(labelOrigDispMode);
               label.setVisible(true);

               try {
                  final Content content = (Content)label.getModel();
                  final MacroCommand command = new ModifyGraphMacroCommand();
                  command.addCommand(
                     new EditContentCommand(
                        content,
                        editedDoc.getText(0, editedDoc.getLength())));

                  for (Iterator i =
                     content.getDeviceTypesVisibleTo().iterator();
                     i.hasNext();
                     ) {
                     final DeviceType aDeviceType = (DeviceType)i.next();
                     command.addCommand(
                        new SetContentDisplayModeCommand(
                           content,
                           aDeviceType,
                           Content.TEXT));
                  }

                  // If the label's parent has a RESIZE_CHILDREN_ANCHOR
                  // property equal to CENTER, then recenter the label
                  if (label.getParent()
                     .getClientProperty(
                        DamaskAppUtils.PROPERTY_RESIZE_CHILDREN_ANCHOR)
                     == Direction.CENTER) {

                     for (Iterator i =
                        content.getDeviceTypesVisibleTo().iterator();
                        i.hasNext();
                        ) {
                        final DeviceType aDeviceType = (DeviceType)i.next();

                        final Rectangle2D contentOldLocalBounds =
                           content.getBounds(aDeviceType);

                        final AffineTransform contentOldTransform =
                           content.getTransform(aDeviceType);

                        final Rectangle2D contentOldBounds =
                           GeomLib.transformRectangle(
                              contentOldTransform,
                              contentOldLocalBounds);

                        final Rectangle2D contentNewBoundsSortOf =
                        GeomLib.transformRectangle(
                           contentOldTransform,
                           new Rectangle2D.Double(
                              contentOldLocalBounds.getX(),
                              contentOldLocalBounds.getY(),
                              editedText.getWidth(),
                              editedText.getHeight()));
                              
                        final AffineTransform contentNewTransform =
                           AffineTransform.getTranslateInstance(
                              (contentOldBounds.getWidth()
                                 - contentNewBoundsSortOf.getWidth())
                                 / 2,
                              (contentOldBounds.getHeight()
                                 - contentNewBoundsSortOf.getHeight())
                                 / 2);
                        contentNewTransform.concatenate(contentOldTransform);
                              
                        command.addCommand(
                           new SetTransformCommand(
                              content,
                              aDeviceType,
                              contentNewTransform));
                     }
                  }
                  
                  damaskCanvas.getDocument().getCommandQueue().doCommand(
                     damaskCanvas, command);
               }
               catch (BadLocationException e) {
                  // should never happen
                  DamaskAppExceptionHandler.log(e);
               }
            }
            // Else, create new content
            else {
               final Rectangle2D bounds = editedText.getBounds();
               final AffineTransform transform = editedText.getTransform();
            
//               editedText.removeFromParent();
            
               try {
                  final PageRegion region = (PageRegion)regionView.getModel();
                  final DamaskLayer layer =
                     ((DamaskLayer)damaskCanvas.getLayer());
                  final DeviceType deviceTypeForText =
                     layer.getDeviceTypeForNewElement();
                  final Content content = new Content(deviceTypeForText,
                        editedDoc.getText(0, editedDoc.getLength()));
                  content.setTransform(region.getDeviceType(), transform);
                  //HACK There should really be a bit within Control to
                  // indicate whether the bounds and transform for a particular
                  // device type has been initialized, instead of seeing if the
                  // bounds are null.
                  if (content.isVisibleToDeviceType(DeviceType.VOICE)) {
                     content.setTransform(DeviceType.VOICE, transform);
                  }
                  content.setBounds(region.getDeviceType(), bounds);
                  

                  final MacroCommand cmd = new ModifyGraphMacroCommand();
                  DamaskUtils.addCommandsForAddingComponentToMacroCommand(cmd,
                                                                    content,
                                                                    region);
                  damaskCanvas.getDocument().getCommandQueue().doCommand(
                     damaskCanvas, cmd);
               }
               catch (BadLocationException e) {
                  // should never happen
                  DamaskAppExceptionHandler.log(e);
               }
            }
         }

         editor.setVisible(false);
         canvas.repaint();

         editedText = null;
         label = null;
      }
   }

   protected JTextComponent createDefaultEditor() {
      final JTextComponent tComp = super.createDefaultEditor();
      tComp.setBorder(new EmptyBorder(0, 0, 0, 0));
      return tComp;
   }
}
