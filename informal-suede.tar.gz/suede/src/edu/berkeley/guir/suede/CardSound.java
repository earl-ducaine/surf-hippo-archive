package edu.berkeley.guir.suede;

/*
 * class CardSound
 * 
 * shound handle all audio operations separate from a graphical representation!
 *
 *  usage:
 *    To Record Audio --
 *        recordAudio(boolean isLink, double systemNodeDuration)
 *        stopRecordingAudio()  
 *      Can pause and resume in this as desired
 *      
 *    To Play Audio --
 *        playAudio() 
 *        stopPlayingAudio()
 *      Can pause and resume in this as desired  
 *
 *  aks, 04/27/00
 *  revised by lisa chan, 08/15/01
 */

import java.io.*;
import javax.sound.sampled.*;


public class CardSound {
    private static final boolean DEBUG          = false;
    private static final int     bufSize        = 16384;
    private static final int     MODEPLAYING    = 0;
    private static final int     MODENOTPLAYING = 1;
    private static final int     MODESTOPPED    = 2;
    public  static final int     NO_AUDIO       = -1;
  
    public  String   fileName = "untitled";
    private Sample   sample   = new Sample();  // PAUSE ELIM CODE
    private Capture  capture  = new Capture();
    private Playback playback = new Playback();
    private int      m_mode   = MODENOTPLAYING;
    private double   seconds; //duration is the length of the stream, seconds is the current position
    private File     file;
    private EndPlayCallbackIF   m_playcall         = null;
    private EndRecordCallbackIF m_recordcall       = null;
    private AudioInputStream    m_audioInputStream = null;
   
    private final FormatCtrls   formatCtrl         = new FormatCtrls();
  
    private boolean isLink = false; //determines whether or not to remove the pause; remove only if it is a link
    private double  pauseDuration = 0; //the amount of pause time that was eliminated
    private double  systNodeDuration = 0; //for barge-ins, need to know length of preceding system node so that we do not
                                         //calculate it into the pause duration
    private boolean stopCapture = false;  // thread management
    private boolean stopPlayback = false; // thread management
    private static boolean pinned = false; 
  
    public static int silenceArea = 0;

    private boolean PAUSE = false;
  
    public CardSound() {
    }  
  
    public CardSound(EndPlayCallbackIF playcall, EndRecordCallbackIF recordcall) {
	m_playcall = playcall;
	m_recordcall = recordcall;
    }  
  
    public boolean isStopped() {
	return (m_mode == MODESTOPPED);
    }
  
    public synchronized boolean isAvailable() {
	return (m_audioInputStream !=null);
    }

    public synchronized boolean playbackLineIsValid() {
	if (playback==null) 
	    return false;
	return playback.isLineValid();
    }
  
    public synchronized boolean playbackLineIsOpen() {
	if (playback==null) 
	    return false;
	return playback.isLineOpen();
    }
  
    public synchronized boolean captureLineIsValid() {
	if (capture==null) 
	    return false;
	return capture.isLineValid();
    }
  
    public synchronized boolean captureLineIsActive() {
	if (capture==null) 
	    return false;
	return capture.isLineActive();
    }
  
    public long getPlayMilliseconds() {
	return playback.getMilliseconds();
    }
  
    public long getCaptMilliseconds() {
	return capture.getMilliseconds();
    }
  
    public synchronized void setPlayCallback(EndPlayCallbackIF playcall) {
	m_playcall = playcall;
    }
  
    private synchronized void setRecordCallback(EndRecordCallbackIF recordcall) {
	m_recordcall = recordcall;
    }

    public synchronized double getDuration() {
	if (m_audioInputStream != null)
	    return ((double)m_audioInputStream.getFrameLength()) / m_audioInputStream.getFormat().getFrameRate();
	return NO_AUDIO;
    }
  
    public void setPauseDuration(double pause) {
	pauseDuration = pause;
    }
  
    public double getPauseDuration() {
	return pauseDuration;
    }

    public void setToBeginning() {
	setSeconds(0);
    }
  
    private void setSeconds(double d) {
	seconds = d;
    }
  
  
    public double getSeconds() {
	return seconds;
    }
  
    public synchronized AudioInputStream getAudio() {
	return m_audioInputStream;
    }
  
  
    public synchronized boolean setAudio(AudioInputStream ais) {
	m_audioInputStream = ais;
	return true;
    }  


    private void playDone() {
	// for some reason, this is the right sequencing.
	if (m_mode != MODESTOPPED) 
	    m_mode = MODENOTPLAYING;    
    
	if (m_playcall != null) 
	    m_playcall.callmeWhenDonePlaying(/*this*/);
    }
  
  
    private void recordDone() {
	if (m_recordcall != null) 
	    m_recordcall.callmeWhenDoneRecording();
    }
  
    public synchronized void sampleSilence() {
	sample.start();
    } //PAUSE ELIM CODE

    public synchronized boolean playAudio() {
	m_mode = MODEPLAYING;    
	if (isAvailable()) {
	    playback.start();
	    return true;
	} else {
	    stopPlayingAudio();
	    //System.out.println("playAudio error: There is no audio to play");
	    return false;
	}
    }
  
    public synchronized void stopPlayingAudio() {
	m_mode = MODESTOPPED; 
	//playback.stop();
	stopPlayback = true;
    }

    /*public void recordAudio(boolean isLink, double systNodeDuration, boolean pauseElim) {
	PAUSE = pauseElim;
	recordAudio (isLink, systNodeDuration);
	}*/

    public void recordAudio(boolean isLink, double systNodeDuration) {
	this.isLink = isLink;
	this.systNodeDuration = systNodeDuration;
	capture.start();
    }
    
    public synchronized void stopRecordingAudio() {
	m_mode = MODESTOPPED; 
	stopCapture = true; //do not use deprecated capture.stop()!!!
    }
  
    /**
     * Combines the bytes into samples based on the audio format.
     */
    private int[] extractSamples(byte[] capturedBytes, AudioFormat format) {
	int frameSize = format.getFrameSize();
	int[] samples = new int[capturedBytes.length/frameSize];
	
	int sample = 0;
	for (int i = 0, s = 0; i < capturedBytes.length; i+=frameSize, s++) {
	    if (format.getSampleSizeInBits() == 16) {
		int MSB = (int) capturedBytes[i];
		int LSB = (int) capturedBytes[i+1];
		
		//each sample is taken from only one channel (for stereo)--I assume that that sample is
		//a fair representation of the entire frame sample
		if (format.isBigEndian()) {
		    sample = MSB << 8 | (255 & LSB);
		}
		else {
		    sample = LSB << 8 | (255 & MSB);
		} 
	    }
	    else {
		sample = capturedBytes[i]; //takes only one channel for stereo format
	    }
	    samples[s] = sample;
	}
	
	return samples;		 
    }  //PAUSE ELIM CODE
  
    /**
     * Removes the beginning pause in an entire sample by integrating across quarter second
     * intervals and comparing this area against the area of a quarter-second "silent" sample.
     * If it is 2x greater than the silence area, then we can consider this "voice" and eliminate
     * the preceding captured audio.
     */
    private byte[] eliminatePause(byte[] capturedBytes, AudioFormat format) {
      //int intervalSize = (int)format.getSampleRate()/2; // evaluate in quarter second intervals
      //int incrementSize = (int)format.getSampleRate()/4; // increment in eighth second intervals to try to calculat
      int intervalSize = (int)format.getSampleRate()/4; // evaluate in quarter second intervals
      int incrementSize = (int)format.getSampleRate()/8; // increment in eighth second intervals to try to calculate optimal threshold point
      int frameSize = format.getFrameSize();
		
      int[] samples = extractSamples(capturedBytes, format); //the samples of the captured bytes
      int start = 0;
	
      for (int i = 0; i < samples.length;) {
	  int sampleArea = 0;
	  int j = i;
	  int endSamples = i+intervalSize;
	  if (endSamples > samples.length) {
	      endSamples = samples.length;
	  }
	  for (; j < endSamples; j++) {
	      sampleArea += Math.abs(samples[j]);
	  }
	  if (sampleArea > silenceArea*5) {
	      
	      start = i;
	      start -= incrementSize; //to try to ensure we do not cut off voice
	      if (start < 0) {
		  start = 0;
	      }
	      break;
	  }
	  i += incrementSize;
	  
      }  //PAUSE ELIM CODE
      
      /* NOTE: May want to remove end pause as well but will need to be more generous with the
	 intervals to make sure it really is the end and not just a pause in the response. */
      
      start = start*frameSize; //to index into the byte array
	
      byte[] cleanedBytes = new byte[capturedBytes.length - start];
      for (int j = 0; j < cleanedBytes.length; j++, start++) {
	  cleanedBytes[j] = capturedBytes[start];
      }
      return cleanedBytes;
	
    } //PAUSE ELIM CODE

  
    /**
     * For testing purposes....
     * Print the samples above a certain threshold
     */
    private void printSamples(int[] samples) {
	int voiceMax = -Integer.MAX_VALUE;
	int s = 0; 
	int index = 0;
	
	System.out.println("SAMPLE LENGTH: " + samples.length);
	
	int one = 11024; // quarter of a second (44k hz)
	int two = 5512; // eight of a second
	
	int thresholdArea = silenceArea*5;
	System.out.println("THRESHOLD AREA " + thresholdArea);
	
	for (int i = 0; i < samples.length;) {
	    int sampleArea = 0;
	    int j = i;
	    int endSamples = i+one;
	    if (endSamples > samples.length) {
		endSamples = samples.length;
	    }
	    for (; j < endSamples; j++) {
		sampleArea += Math.abs(samples[j]);
	    }
	    int jend = j-1;
	    System.out.println("\ttotal sample area: " + sampleArea + "; " + i + " to " + jend);
	    i += two;
	}
    } //PAUSE ELIM CODE
    
  
    private void resetAudio() {
	stopPlayback = false; //allow lines to playback or capture
	stopCapture = false;
	try {
	    if (m_audioInputStream != null && 
		m_audioInputStream.markSupported()) {
		m_audioInputStream.reset();
	    }
	} 
	catch (Exception e) {
	    e.printStackTrace();
	    System.out.println("Unable to reset the stream\n" + e);
	    stopPlayback = true;
	    stopCapture = true;
	}
    }

  
    public void createAudioInputStream(File file, boolean updateComponents) {
	if (file != null && file.isFile()) {
	    try {
		this.file = file;
            
		AudioInputStream ais2, ais;
		ais2 = AudioSystem.getAudioInputStream(file);
                
		int frameSizeInBytes = ais2.getFormat().getFrameSize();
		int frameLength = (int) ais2.getFrameLength();
		byte[] audioBytes = new byte[frameLength * frameSizeInBytes];
		int numberread = ais2.read(audioBytes, 0, frameLength * frameSizeInBytes);
		// make a copy of it
		ByteArrayInputStream bais = new ByteArrayInputStream(audioBytes);
		ais = new AudioInputStream(bais, ais2.getFormat(), audioBytes.length / frameSizeInBytes);     
            
		setAudio(ais);
           
		fileName = file.getName();
           
		long milliseconds = (long)((m_audioInputStream.getFrameLength() * 1000) / m_audioInputStream.getFormat().getFrameRate());
           
		if (updateComponents) {
		    formatCtrl.setFormat(m_audioInputStream.getFormat());
		}
            
		resetAudio();
            

	    } catch (Exception ex) {
		reportStatus(ex.toString());
		ex.printStackTrace();
	    }
	} 
	else {
	    reportStatus("Audio file required.");
	}
    }
   
   
    public void saveToFile(String name, AudioFileFormat.Type fileType) {
	if (m_audioInputStream == null) {
	    reportStatus("No loaded audio to save");
	    return;
	} 
      
	//$REVIEW: commented out but unsure of what it's original purpose was
	/*else if (file != null) {
	  createAudioInputStream(file, false);
	  }*/
      
	resetAudio();

	File file = new File(fileName = name);
	try {
	    if (AudioSystem.write(m_audioInputStream, fileType, file) == -1) {
		throw new IOException("Problems writing to file");
	    }
               
	    resetAudio();
         
         
	} catch (Exception ex) { 
	    reportStatus(ex.toString()); 
	    ex.printStackTrace();
	}
      
	//samplingGraph.repaint();
	  
    }
   
   
    private void reportStatus(String msg) {
	System.out.println(msg);
    }
   
    /**
     * Takes only a sample recording and records the maximum amplitude of silence.
     */
    private class Sample extends AbstAudioHandler {
		
	public void run() {
	    setToBeginning();
	    
	    AudioFormat format = formatCtrl.getFormat();
	    DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            
	    if (!AudioSystem.isLineSupported(info)) {
		shutDown("Line matching " + info + " not supported.");
		return;
	    }
	    
	    // get and open the target data line for capture.
	    try {
		line = (TargetDataLine) AudioSystem.getLine(info);
				//System.out.println("Sample open..."); //RMV
		((TargetDataLine)line).open(format, line.getBufferSize());
	    } 
	    catch (LineUnavailableException ex) {
		shutDown("Unable to open the line: " + ex);
		return;
	    } 
	    catch (SecurityException ex) {
		shutDown(ex.toString());
		return;
	    } 
	    catch (Exception ex) {
		shutDown(ex.toString());
		return;
	    }
	    
	    ByteArrayOutputStream out = new ByteArrayOutputStream();
	    
	    int frameSizeInBytes = format.getFrameSize();
	    int bufferLengthInFrames = line.getBufferSize() / 8;
	    int bufferLengthInBytes = (bufferLengthInFrames * frameSizeInBytes);
	    byte[] data = new byte[bufferLengthInBytes]; //this is a sample of 1/4 of second
	    
	    int numBytesRead;
	    
	    line.start();
            
	    if((numBytesRead = ((TargetDataLine)line).read(data, 0, bufferLengthInBytes)) != -1)
		out.write(data, 0, numBytesRead);
	    
	    // stop and close the line; also stop sampling.
	    line.stop();
	    sample.stop();
	    
	    // The following line is necessary! Without a lengthy stall between stop and close, e.g. a printout, 
	    // the audio recording features get screwed up. This is due to a problem in Java Media.
	    System.out.println("End of sampling.");
	    
	    //System.out.println("Sample close..."); //RMV
	    line.close();
	    line = null;
            
				// stop and close the output stream
	    try {
		out.flush();
		out.close();
	    } catch (IOException ex) {
		ex.printStackTrace();
	    }
	    
	    int[] samples = extractSamples(out.toByteArray(), format);
	    
	    int totalSample = 0;
	    for (int i = 0; i < samples.length; i++) {
		totalSample += Math.abs(samples[i]); 
	    }
	    silenceArea = totalSample;
	    int avg = totalSample/samples.length;
	    
	    int thresh = silenceArea*5;
	    /*System.out.println("CALIBRATION RESULTS");
	    System.out.println("Total silence area is: " + silenceArea + ", threshold is: " + thresh);
	    System.out.println("Average per sample is: " + avg);*/
	}
	
    } //PAUSE ELIM CODE
    
    /** 
     * * Reads audio data from the input channel and writes to the output stream
     * */
    private class Capture extends AbstAudioHandler {

	public void run() {
	    setToBeginning();
	    resetAudio(); 
	    // define the required attributes for our line, 
	    // and make sure a compatible line is supported.
	    AudioFormat format = formatCtrl.getFormat();
		 
	    ByteArrayOutputStream out = new ByteArrayOutputStream();
	    float frameRate = format.getFrameRate();
 	    int frameSizeInBytes = format.getFrameSize();
         
	    DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
             
	    if (!AudioSystem.isLineSupported(info)) {
		shutDown("Line matching " + info + " not supported.");
		return;
	    }

	    // get and open the target data line for capture.
	    try {
		line = (TargetDataLine) AudioSystem.getLine(info);
		//System.out.println("Capture open..."); //RMV
		while (true) {
		    if (!pinned) {
			pinned = true;
			((TargetDataLine)line).open(format, line.getBufferSize());
			break;
		    }
		    else {
			Thread.sleep(500);
		    }
		}
	    }
	    catch (LineUnavailableException ex) {
		shutDown("Unable to open the line: " + ex);
		return;
	    } 
	    catch (SecurityException ex) {
		ex.printStackTrace();
		shutDown(ex.toString());
		return;
	    } 
	    catch (Exception ex) {
		ex.printStackTrace();
		shutDown(ex.toString());
		return;
	    }
		 
	    int bufferLengthInFrames = line.getBufferSize() / 8;
	    int bufferLengthInBytes = bufferLengthInFrames * frameSizeInBytes;
	    byte[] data = new byte[bufferLengthInBytes];
         
	    int numBytesRead;
             
	    line.start();
	               
	    while (thread != null && !stopCapture) {
		setSeconds(getCaptMilliseconds() / 1000.0);
                
		if((numBytesRead = ((TargetDataLine)line).read(data, 0, bufferLengthInBytes)) == -1)
		    break;

		out.write(data, 0, numBytesRead);
	    }

	    // we reached the end of the stream.  stop and close the line.
	    line.stop();
            
	    stopCapture = false;


	    // The following line is necessary! Without a lengthy stall between stop and close, e.g. a printout, 
	    // the audio recording features get screwed up. This is due to a problem in Java Media.
	    System.out.println("stop recording.");
		
	    line.flush();
	    line.close();
	    line = null;
	    pinned = false;
	    //System.out.println("Capture close..." + pinned); //RMV
	 
		 
	    // stop and close the output stream
	    try {
		out.flush();
		out.close();
	    } catch (IOException ex) {
		ex.printStackTrace();
	    }
	 
	    // load bytes into the audio input stream for playback
	 
	    byte[] audioBytes = out.toByteArray();
	    int audioLengthInFrames = audioBytes.length/frameSizeInBytes;
	 
	    double fullDuration = audioLengthInFrames/frameRate;
	    double newDuration = fullDuration; 
         
	    //if this is a link and we want to eliminate the pause, take out the pause in the byte array
	    if (isLink && Suede.enablePauseElim) { 
		//printSamples(extractSamples(audioBytes, format));
		audioBytes = eliminatePause(audioBytes, format);
		audioLengthInFrames = audioBytes.length/frameSizeInBytes;
		newDuration = audioLengthInFrames/frameRate;
	    } //PAUSE ELIM CODE
	    
	    ByteArrayInputStream bais = new ByteArrayInputStream(audioBytes);
	    setAudio(new AudioInputStream(bais, format, audioBytes.length / frameSizeInBytes));
	    resetAudio();
	 
	    //save the duration of the pause for analysis
	    setPauseDuration(fullDuration - newDuration - systNodeDuration); //PAUSE ELIM CODE
	   
	 
	    recordDone();
	    setToBeginning();
	}
    } // End class Capture

    
    /**
     * Write data to the OutputChannel.
     */
    private class Playback extends AbstAudioHandler {

	public void run() {
	    setToBeginning();
		  
	    // make sure we have something to play
	    if (!isAvailable()) {
		shutDown("No loaded audio to play back");
		return;
	    }
	    resetAudio();
          
        
	    // get an AudioInputStream of the desired format for playback
         
	    AudioFormat format = m_audioInputStream.getFormat();
	    AudioInputStream playbackInputStream = AudioSystem.getAudioInputStream(format, m_audioInputStream);
			
	    if (playbackInputStream == null) {
		shutDown("Unable to convert stream of format " + m_audioInputStream + " to format " + format);
		return;
	    }

	    // define the required attributes for our line, 
	    // and make sure a compatible line is supported.

          
	    DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
	    if (!AudioSystem.isLineSupported(info)) {
		shutDown("Line matching " + info + " not supported.");
		return;
	    }

	    synchronized (this) {
             
		// get and open the source data line for playback.
		try {
		    line = (SourceDataLine) AudioSystem.getLine(info);
				
		    ((SourceDataLine)line).open(format, bufSize);
		} catch (LineUnavailableException ex) {
		    shutDown("Unable to open the line: " + ex);
		    return;
		}
			 
		// play back the captured audio data
		int frameSizeInBytes = format.getFrameSize();
		int bufferLengthInFrames = line.getBufferSize() / 8;
		int bufferLengthInBytes = bufferLengthInFrames * frameSizeInBytes;
			
		byte[] data = new byte[bufferLengthInBytes];
		int numBytesRead = 0;

		// start the source data line
		line.start();
          
		while (thread != null && !stopPlayback) {
		    setSeconds(getPlayMilliseconds() / 1000.0);
               
		    try {
			if ((numBytesRead = playbackInputStream.read(data)) == -1) {
			    break;
			}
			int numBytesRemaining = numBytesRead;
                   
                   
			while (numBytesRemaining > 0 ) {
			    numBytesRemaining -= ((SourceDataLine)line).write(data, 0, numBytesRemaining);
			}
			   
		    } catch (Exception e) {
			shutDown("Error during playback: " + e);
			break;
		    }
		}
              
               
		// we reached the end of the stream.  let the data play out, then
		// stop and close the line.
		if (thread != null) {
		    line.drain();
		}

		if (line != null) {
		    line.stop();
		    //System.out.println("Play close..."); //RMV
		    line.close();
		}
		stopPlayback = false;
               
		line = null;
		shutDown(null);
          
	    } // end synchronized
            
	    playDone();
	    setToBeginning();
	}
    } // End class Playback
    
    
}
