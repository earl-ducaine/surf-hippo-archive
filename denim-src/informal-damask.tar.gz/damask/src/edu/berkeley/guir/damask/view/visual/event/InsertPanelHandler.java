package edu.berkeley.guir.damask.view.visual.event;

import java.awt.geom.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.visual.component.Panel;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PInputEvent;

/** 
 * The event handler that handles inserting panels into pages.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  05-31-2003 James Lin
 *                               Created InsertPanelHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 05-31-2003
 */
public class InsertPanelHandler extends InsertComponentHandler {
   private Point2D startPoint = null;

   /**
    * Constructs a new text box handler. 
    */
   public InsertPanelHandler() {
      super(Panel.class);
   }


   // Overrides method in parent class.
   protected void updateComponentView(PInputEvent e, PNode controlView) {
      final Point2D currentPoint = e.getPosition();

      controlView.setOffset(
         Math.min(currentPoint.getX(), startPoint.getX()),
         Math.min(currentPoint.getY(), startPoint.getY()));
      controlView.setBounds(
         0,
         0,
         Math.abs(currentPoint.getX() - startPoint.getX()),
         Math.abs(currentPoint.getY() - startPoint.getY()));
   }


   // Overrides method in parent class.
   public void startDrag(PInputEvent e) {
      startPoint = e.getPosition();
      super.startDrag(e);
   }


   // Overrides method in parent class.
   protected Component createNewComponent(
      final DeviceType deviceType,
      final PageRegion region,
      final AffineTransform transform,
      final Rectangle2D bounds) {
      
      final ComponentGroup group = new ComponentGroup(deviceType);
   
      group.setTransformInPageRegion(region, transform);
      group.setBoundsInPageRegion(region, bounds);
      
      return group;
   }
}
