package edu.berkeley.guir.suede;

import javax.swing.*;
import java.awt.event.*;
import org.w3c.dom.*;
import org.xml.sax.*;

// the script model is the model for all of the scripts in the script area.
// there should be one instantiation of this class for the suede app

public class ScriptModel {
   private static final boolean DEBUG = false;
   private static final String  m_smallcardprefix = "cs";
   
    private ScriptPane m_scriptAreaView; //the set of all the scripts in design mode
    private ScriptPane m_transcriptAreaView; // the set of all transcripts in analysis mode
    private JSplitPane m_parent; // a link to the content pane, containing both the script view and the design area
    private int        m_smallcardoffsetnum = 0;
    private SuedeModel m_model; // Needed during loading: Transcript needs to communicate usage numbers to model.

    
    public ScriptModel(int width, SContentPane designArea ) {
       m_scriptAreaView     = new ScriptPane(width, designArea, ScriptPane.DESIGN);
       m_scriptAreaView.addScript();
       m_scriptAreaView.addNewScriptActionListener(new ScriptActionListener());
	   m_scriptAreaView.addTestActionListener();
       m_transcriptAreaView = new ScriptPane(width, designArea, ScriptPane.TRANSC);
    }


    public ScriptPane getScriptAreaView() {
        return m_scriptAreaView;   
    }
    
    //HV Oct1703
    public ScriptPane getTranscriptAreaView() {
    	return m_transcriptAreaView;
    }
    
    public int getNumberScripts( boolean isTranscript ) {
        if ( isTranscript )
            return m_transcriptAreaView.getNumberScripts();
        
        return m_scriptAreaView.getNumberScripts();
    }
    
    
    public void setAppModel(SuedeModel model) {
        m_scriptAreaView.setModel(model);
        m_transcriptAreaView.setModel(model);
        m_model = model;
    }
    
    public void setParentView(JSplitPane p) {
        m_parent = p;
    }
    
    
    // this pair of methods switches the script area between displaying
    // the wizard recorded scripts (design view) and the user recorded transcripts (analysis view)
    
    public void setAnalysisMode() {
        //System.out.println("ScriptModel: set analysis view");
        m_parent.remove(m_scriptAreaView);
        m_parent.setTopComponent(m_transcriptAreaView);
    }

    public void setDesignMode() {
        //System.out.println("ScriptModel: set design view");   
        m_parent.remove(m_transcriptAreaView);
        m_parent.setTopComponent(m_scriptAreaView);
    }
    
    
    public void addDesignScriptNode(DesignScriptNodeModel sc, int scriptnum) {
      if (scriptnum==m_scriptAreaView.getNumberScripts()) m_scriptAreaView.addScript();
      
       m_scriptAreaView.addScriptNode(sc, scriptnum);
    }
    
    
   /*
      * adds a script card to the script area
      * 
      * @param java.awt.Point evtPoint
      */
   public DesignScriptNodeModel addDesignScriptNode(boolean cardtype, int scriptNum) {
      DesignScriptNodeModel nodeModel = new DesignScriptNodeModel(nextSmallCardName(), cardtype);
      nodeModel.setScriptNumber(scriptNum);
      addDesignScriptNode(nodeModel, scriptNum);
      return nodeModel;
   }
  

   public void addTranscriptNode(TranscriptNodeModel sc, int scriptnum) {
      if (scriptnum==m_transcriptAreaView.getNumberScripts()) m_transcriptAreaView.addTranscript( scriptnum );
      
      m_transcriptAreaView.addScriptNode(sc, scriptnum);
   }
    
    
   public TranscriptNodeModel addTranscriptNode(boolean cardtype, int scriptNum) {
      //System.out.println("Adding transcript nodes from a file not yet supported");
      return null;
   }
  

    public void addTranscript(TranscriptView tView) {
       m_transcriptAreaView.addScript(tView);
       // Change split pane size now that there's another transcript
       m_parent.resetToPreferredSizes();
    }
    
    
    public void loadScripts(NodeList nlist) throws SAXException {
      for (int j = 0; j < nlist.getLength(); j++) {
          // if we hit a cardsmall, parse its child XML
          // FIXME: we don't do enough error checking in this 4/26/00 aks  
          if (nlist.item(j).getNodeName().equals("cardsmall")) {
                   
            DesignScriptNodeModel nscard = new DesignScriptNodeModel(nextSmallCardName(), true);
           
         
            m_smallcardoffsetnum = m_smallcardoffsetnum - 1;
            // bug?  the label for this card will get incremented and assigned automatically,
            // and then it will get rewritten when read-in.  it's already in the list of cardModel
            fillScriptCard(nlist.item(j).getChildNodes(), nscard);
                  
            addDesignScriptNode(nscard, nscard.getScriptNumber());
         } //else System.out.println("loadScripts: parsing error on "+nlist.item(j).getNodeName());
       }
    }


    public void loadTranscripts(NodeList nlist) throws SAXException { 
      TranscriptNodeModel prevUserNode = null, prevPromptNode = null;
      int prevScriptNum = -1;
        
      for (int j = 0; j < nlist.getLength(); j++) {
          // if we hit a cardsmall, parse its child XML
          // FIXME: we don't do enough error checking in this 4/26/00 aks  
          if (nlist.item(j).getNodeName().equals("cardsmall")) {
                   
             TranscriptNodeModel nscard = new TranscriptNodeModel( nextSmallCardName(), 0 );
                   
             m_smallcardoffsetnum = m_smallcardoffsetnum - 1;
             // bug?  the label for this card will get incremented and assigned automatically,
             // and then it will get rewritten when read-in.  it's already in the list of cardModel
             fillScriptCard(nlist.item(j).getChildNodes(), nscard);
                  
             addTranscriptNode(nscard, nscard.getScriptNumber());
             
             if ( prevScriptNum != nscard.getScriptNumber() ) {
                 prevPromptNode = null;
                 prevUserNode = null;
                 prevScriptNum = nscard.getScriptNumber();
             }
             
             if ( nscard.getCardType() == AbstScriptNodeModel.SYSTEM ) {
                 if ( prevPromptNode != null ) {
                    m_model.updateTranscriptWithLink( prevPromptNode.getLabel(), nscard.getLabel(),
                                                    prevScriptNum, prevUserNode );
                 }
                 prevPromptNode = nscard;
             } else {
                 prevUserNode = nscard;
             }
                 
             
             // Add the usage numbers to the graph
   //          if ( nscard.getCardType() == AbstScriptNodeModel.USER )
     //            m_model.updateTranscriptWithLink( nscard.getLabel(), nscard.getScriptNumber(), nscard );
          } //else System.out.println("loadTranscripts: parsing error on "+nlist.item(j).getNodeName());
       }
       
    }
    
    
    /*
     * makes up a name for each card, right now differentiates card
     * numbers based on adding the card number to the string representing the card.
     */
    public String nextSmallCardName() {
       m_smallcardoffsetnum = m_smallcardoffsetnum + 1;
       return m_smallcardprefix + m_smallcardoffsetnum;
    }
  
  
  /*
   * parses an XML NodeList and enters the right information into
   * an recently created ScriptNodeModel.
   *    NodeList - read in from the saved out model file
   *    ScriptNodeModel - created before this function is called
   *
   * @param NodeList nlist, ScriptNodeModel ncard
   */
  public void fillScriptCard (NodeList nlist, AbstScriptNodeModel ncard)
    throws SAXException
    {
      String tag, value = "";
      for (int j = 0; j < nlist.getLength(); j++) {
        tag = nlist.item(j).getNodeName();
        if (DEBUG) {
          System.out.print("<");
          System.out.print(nlist.item(j).getNodeName());
          System.out.print(">=");      
          System.out.print("" + nlist.item(j).getNodeType());
          System.out.print(":");
        }
        
        if (nlist.item(j).getNodeType() == 1) {
          
          if (nlist.item(j).getChildNodes().item(0) == null) {
            value = "";
           System.out.print( value );
          } else {
            value = nlist.item(j).getChildNodes().item(0).getNodeValue();            
            if (DEBUG) { System.out.print(nlist.item(j).getChildNodes().item(0).getNodeValue());  }
          }
          
          
        } else if (nlist.item(j).getNodeType() == 3) {
          if (DEBUG) { System.out.print(nlist.item(j).getNodeValue()); }
          value = "";
        }
        
        // check if there is something in the value field
        if (value.length() > 0) {
          // go through the cases for the tags, value pairs
          try {
              if (tag.equals("label")) {
                
                ncard.setLabel(value);                
                // HACK: update the offset to be the value of this, so we know we are always higher than this in new labels
                try {
                  int tmp = Integer.parseInt(value.substring(m_smallcardprefix.length()));
                  if (tmp > m_smallcardoffsetnum) {
                    m_smallcardoffsetnum = tmp;
                  } else {  // if we are too low, we better increment the label for this card so we don't get screwed with repeated labels
                    m_smallcardoffsetnum = m_smallcardoffsetnum + 1;
                    ncard.setLabel(m_smallcardprefix + m_smallcardoffsetnum);
                  }
                } catch (Exception ex) {
                    // What if I just don't report the exception?
                  //ex.printStackTrace();
                }  
                
                
                
              } /*else if (tag.equals("ux")) {
                ncard.setLocation(Integer.parseInt(value), ncard.getLocation().y);
              } else if (tag.equals("uy")) {
                ncard.setLocation(ncard.getLocation().x, Integer.parseInt(value));
              } */ else if (tag.equals("caption")) {
                ncard.setCaption(value);
              } else if (tag.equals("scripttype")) {

                if (value.compareTo("true") == 0) {
                  if (DEBUG) { System.out.println(" setting script card true ... "); };
                  ncard.setCardType(true);    
                } else {
                  if (DEBUG) { System.out.println(" setting script card false ... "); } ;
                   ncard.setCardType(false);    
                }
                
              } else if (tag.equals("scriptnumber")) {
                ncard.setScriptNumber(Integer.parseInt(value));    
              } else if (tag.equals("filename")) {
                ncard.fillAudio(m_model.getDataPath() + value);  // reads the audio from the specified filename
              }
            } catch (Exception ex) {
              ex.printStackTrace(System.out);
            }
        }        
        
        if (DEBUG) { System.out.print("\n");  }
      }
    }
    
 
    // this saves all of the design scripts and all of the transcripts
    public void saveScriptModel(java.io.PrintWriter pw, String path) {

       // this saves all of the design scripts
       pw.println("<scripts>");
       m_scriptAreaView.saveScripts(pw, path);
       pw.println("</scripts>");


       // this saves all of the transcripts
       pw.println("<transcripts>");
       m_transcriptAreaView.saveScripts(pw, path);
       pw.println("</transcripts>");
    }



    // this inner class listens for the user to click the "new script" button
    // only the script area listens for this, because it isn't possible for a designer to add more transcripts
    private class ScriptActionListener implements ActionListener {
       public void actionPerformed (ActionEvent e) {
          m_scriptAreaView.addScript();
          m_parent.resetToPreferredSizes();
       }
    }
    
}