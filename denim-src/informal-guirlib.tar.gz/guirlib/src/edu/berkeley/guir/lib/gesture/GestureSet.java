package edu.berkeley.guir.lib.gesture;

import java.io.*;
import java.util.*;
import java.io.PrintStream;
import edu.berkeley.guir.lib.gesture.util.*;
import java.text.ParseException;

/**
 * Collection of GestureObjects (typically GestureGroups or
 * GestureCategorys).
 *
 */
public class GestureSet extends AbstractGestureContainer
implements Serializable, Cloneable {
  protected String keywords;
  /** of GestureObject (typically GestureGroup or GestureCategory) */
  protected Vector members;
  
  public GestureSet()
  {
    this(null);
  }

  /** collection must contain valid children (see getChildTypes()) */
  public GestureSet(Collection children)
  {
    super();
    members = new Vector();
    if (children != null) {
      members.addAll(children);
    }
  }
  
  protected List getChildren()
  {
    return members;
  }
  
  public void setKeywords(String kw)
  {
    keywords = kw;
  }

  public String getKeywords()
  {
    return keywords;
  }

  /** accumulate all the categories from container in list */
  protected void addCategories(List list, GestureContainer container)
  {
    for (Iterator iter = container.iterator(); iter.hasNext();) {
      Object childObj = iter.next();
      Class type = childObj.getClass();
      if (GestureCategory.class.isAssignableFrom(type)) {
	list.add(childObj);
      }
      else if (GestureContainer.class.isAssignableFrom(type)) {
	addCategories(list, (GestureContainer) childObj);
      }
    }
  }
  
  /** Return all the categories in this set */
  public List getCategories()
  {
    List result = new ArrayList();
    addCategories(result, this);
    return result;
  }

  /** Return the category with the given name */
  public GestureCategory getCategory(String name) {
    if (name == null) {
      return null;
    }
    List categories = getCategories();
    Iterator it = categories.iterator();
    GestureCategory category = null;
    name = name.trim();
    while (it.hasNext()) {
      category = (GestureCategory)it.next();
      if (name.equals(category.getName().trim())) {
	return category;
      }
    }
    return null;
  }

  /** return all categories in this set that are enabled */
  public List getEnabledCategories()
  {
    return (List) Misc.accept(getCategories(), new Misc.Acceptor() {
      public boolean accept(Object obj) {
	GestureObject g = (GestureObject) obj;
	return g.isEnabled();
      }
    });
  }
  
  /**
   * Return Enumeration of elements that should be trained on.
   * (For now, same as elements().)
   */
  private static final Class[] CHILD_TYPES = {
    GestureGroup.class, GestureCategory.class
  };
  /** Valid types are GestureGroup and GestureCategory */
  public Class[] getChildTypes()
  {
    return CHILD_TYPES;
  }
  
  public void update(Observable gestureCategory, Object arg)
  {
    setChanged();
    notifyObservers(gestureCategory);
  }

  /**
   * Restore observer status
   */
  private void readObject(ObjectInputStream in)
       throws IOException, ClassNotFoundException
  {
    in.defaultReadObject();
    // add collection listeners?
    /*
    for (Enumeration enum = members.elements();
	 enum.hasMoreElements(); ) {
      GestureCategory gc = (GestureCategory) enum.nextElement();
      gc.addCollectionListener(listener);
    }
    */
  }

  public void write(Writer writer) throws IOException
  {
    writer.write("name\t" + name + "\n");
    if (keywords != null) {
      writer.write("keywords\t" + keywords + "\n");
    }
    if (author != null) {
      writer.write("author\t" + author + "\n");
    }
    for (int i = 0; i < members.size(); i++) {
      GestureContainer container = (GestureContainer) members.get(i);
      if (container instanceof GestureGroup) {
	writer.write("group\n");
	((GestureGroup) container).write(writer);
      }
      else if (container instanceof GestureCategory) {
	writer.write("category\n");
	((GestureCategory) container).write(writer);
      }
    }
    writer.write("endset\n");
  }

  public static GestureSet read(Reader reader) throws IOException,
    ParseException
  {
    GestureSet result = new GestureSet();
    
    boolean done = false;
    TokenReader r = new TokenReader(reader);
    while (!done) {
      String token;
      try {
	token = r.readToken().intern();
	//System.out.println("GestureSet    \ttoken: " + token);
	if (token == "name") {
	  result.name = r.readLine();
	}
	else if (token == "keywords") {
	  result.keywords = r.readLine();
	}
	else if (token == "author") {
	  result.author = r.readLine();
	}
	else if (token == "categories") {
	  // for old format, where a set only contained categories
	  try {
	    int numMembers = Integer.parseInt(r.readToken());
	    for (int i = 0; i < numMembers; i++) {
	      GestureCategory gc = GestureCategory.read(r);
	      result.add(gc);
	    }
	  }
	  catch (NumberFormatException e) {
	    throw new IOException("bad argument for categories");
	  }
	}
	else if (token == "category") {
	  GestureCategory gc = GestureCategory.read(r);
	  result.add(gc);
	}
	else if (token == "group") {
	  GestureGroup gg = GestureGroup.read(r);
	  result.add(gg);
	}
	else if (token == "endset") {
	  done = true;
	}
      }
      catch (EOFException e) {
	done = true;
      }
    }
    //System.err.println("Read set '" + result.getName() + "'");
    return result;
  }
  
  public Object clone()
  {
    GestureSet gs = (GestureSet) super.clone();
    // name, keywords, and author can be reused since Strings are
    // immutable
    gs.members = (Vector) Misc.deepCopy(members);
    gs.fixParents();
    return gs;
  }

  // debugging

  /**
   * For debugging.  Print out names of all members and their sizes.
   */
  public void dumpNames(PrintStream out)
  {
    /* todo: fix to use iterator
    Enumeration enum = elements();
    while (enum.hasMoreElements()) {
      GestureObject gestureObj =
	(GestureObject) enum.nextElement();
      out.println((gestureObj instanceof GestureContainer) ?
		  ((GestureContainer) gestureObj).getName() : "example");
    }
    */
  }

  public String toString()
  {
    return getName();
  }
}
