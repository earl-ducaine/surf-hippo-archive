package edu.berkeley.guir.lib.gesture;

import java.util.*;

/**
 * Keeps a cache of features for GestureObject.  Known issues:
 * * Only supports Gesture.
 * * Once a Gesture is added, it will never be garbage collected.
 *   FeatureFactory could use a WeakHashMap instead of a HashMap, but
 *   that wouldn't help since each value (Feature) has a strong reference
 *   to its Gesture.
 */
public class FeatureFactory {
  /** key is a GestureObject.  Value is a HashMap whose key is a
      Class and value is a Feature. */
  private static HashMap featureTable = new HashMap();
  private static boolean flagCaching = true;
  
  private FeatureFactory()
  {
  }

  protected static void checkFeatureClass(Class c)
  {
    if (!Feature.class.isAssignableFrom(c)) {
      throw new IllegalArgumentException("featureClass must be a Feature");
    }
  }

  public static Feature getFeature(Class featureClass,
				   GestureObject gestureObj)
  {
    checkFeatureClass(featureClass);
    Feature result = null;
    if (gestureObj instanceof Gesture) {
      if (isCaching()) {
	result = createFeature(featureClass, gestureObj);
      }
      else {
        HashMap features = getFeatures((Gesture) gestureObj);
        if (features == null) {
	  features = new HashMap();
	  featureTable.put(gestureObj, features);
        }
        result = getFeature(features, featureClass);
        if (result == null) {
	  result = createFeature(featureClass, gestureObj);
	  features.put(featureClass, result);
        }
      }
    }
    else {
      System.err.println("Warning: FeatureFactory.getFeature: Features for non-Gestures are not supported (yet)");
    }
    return result;
  }

  public static double getFeatureValue(Class featureClass,
				       GestureObject gestureObj)
  {
    checkFeatureClass(featureClass);
    double result;
    if (gestureObj instanceof Gesture) {
      Feature f = getFeature(featureClass, gestureObj);
      result = f.getValue();
    }
    else if (gestureObj instanceof GestureContainer) {
      GestureContainer container = (GestureContainer) gestureObj;
      result = 0;
      int count = 0;
      for (Iterator iter = container.iterator(); iter.hasNext(); count++) {
	GestureObject child = (GestureObject) iter.next();
	result += getFeatureValue(featureClass, child);
      }
      result /= count;
    }
    else {
      System.err.println("Warning: FeatureFactory.getFeatureValue: Only Gesture and GestureContainer are supported");
      result = 0;
    }
    return result;
  }
  
  protected static Feature createFeature(Class featureClass,
					 GestureObject gestureObj)
  {
    if (!Feature.class.isAssignableFrom(featureClass)) {
      throw new IllegalArgumentException("featureClass must be a Feature");
    }
    Feature feature = null;
    try {
      feature = (Feature) featureClass.newInstance();
      if (gestureObj != null) {
	if (gestureObj instanceof Gesture) {
	  feature.setGesture((Gesture) gestureObj);
	}
	else {
	  System.err.println("Warning: FeatureFactory.getFeature: Features for non-Gestures are not supported (yet)");
	}
      }
    }
    catch (InstantiationException e) {
      System.err.println("Warning: could not instantiate feature of class '"
			 + featureClass.getName() + "':" + e);
    }
    catch (IllegalAccessException e) {
      System.err.println("Warning: could not access class '"
			 + featureClass.getName() + "':" + e);
    }

    return feature;
  }

  protected static Feature getFeature(HashMap table, Class featureClass)
  {
    Feature result;
    if (table.containsKey(featureClass)) {
      result = (Feature) table.get(featureClass);
    }
    else {
      result = null;
    }
    return result;
  }
  
  protected static HashMap getFeatures(Gesture gesture)
  {
    HashMap result;
    if (featureTable.containsKey(gesture)) {
      result = (HashMap) featureTable.get(gesture);
    }
    else {
      result = null;
    }
    return result;
  }
  
  public static double[] getValues(Class[] featureClasses,
				   GestureObject gestureObj)
  {
    double[] result = new double[featureClasses.length];
    for (int i = 0; i < featureClasses.length; i++) {
      result[i] = getFeatureValue(featureClasses[i], gestureObj);
    }
    return result;
  }

  public static String getFeatureName(Class featureClass)
  {
    Feature f = createFeature(featureClass, null);
    return (f == null) ? null : f.getName();
  }
  
  /**
   * Sets whether to cache the features for a gesture, or create one
   * every time one is requested.
   */
  public static void setCaching(boolean flag)
  {
    flagCaching = flag;
  }
  
  /**
   * Gets whether features for a gesture are cached.
   */
  public static boolean isCaching()
  {
    return flagCaching;
  }
  
  /**
   * Clears the cache of features
   */
  public static void clearCache()
  {
    featureTable.clear();
  }
}
