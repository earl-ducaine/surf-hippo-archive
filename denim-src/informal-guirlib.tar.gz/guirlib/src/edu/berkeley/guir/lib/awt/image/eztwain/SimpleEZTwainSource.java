package edu.berkeley.guir.lib.awt.image.eztwain;

import edu.berkeley.guir.lib.awt.image.*;
import java.awt.Component;
import java.awt.image.*;
import java.util.*;

/**
 * <PRE>
 * Revisions:  - GUIRLib-v1.0-1.0.0, Jan 21 2000, FL
 *               Created class
 *             - GUIRLib-v1.4-1.0.0, Aug 31 2000, JH
 *               Touched for GUIRLib release
 *             - Commented out the reference to the DrawingInfo class, to eliminate
 *               compile errors pending our finding a replacement.  See below.  --MarcR
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~fli/">Francis Li</A> (
 *          <A HREF="mailto:fli@cs.berkeley.edu">fli@cs.berkeley.edu</A>)
 * @since   JDK 1.3
 * @version GUIRLib-v1.4-1.0.0, Aug 31 2000
 */
public class SimpleEZTwainSource implements SimpleTwainSource, Runnable
{
   protected Vector vecConsumers = new Vector ();
   protected EZTwainWrapper eztWrapper = new EZTwainWrapper ();
   protected boolean boolMulti = false;
   protected Thread threadMulti = null;
   
   protected int hwnd;
   
   // Flag for multiple image transfers- shows that at least one image has been
   // transferred.
   protected boolean boolTransferred = false;
   
   /** Creates new SimpleEZTwainSource */
   public SimpleEZTwainSource () 
   {
      hwnd = 0;
   }

   public void setParent (Component parent)
   {
      if (null == parent)
      {
         hwnd = 0;
         return;
      }

	  assert false;  
	  /* Note:  the DrawingSurface class is believed to be outdated, and
	   * a replacement needs to be found.
      DrawingSurfaceInfo info = (DrawingSurfaceInfo) ((DrawingSurface) parent.getPeer ()).getDrawingSurfaceInfo ();
      info.lock ();
      hwnd = ((WDrawingSurfaceInfo) info).getHWnd ();
      info.unlock ();      
	   */
   }
   
   public void selectSource()
   {     
      eztWrapper.selectImageSource (hwnd);
   }
   
   public void addConsumer(ImageConsumer ic) 
   {
      if (false == vecConsumers.contains (ic))
         vecConsumers.add (ic);
   }

   public void removeConsumer(ImageConsumer ic) 
   {
      vecConsumers.remove (ic);
   }
  
   public boolean isConsumer(ImageConsumer ic) 
   {
      return vecConsumers.contains (ic);
   }
  
   public void requestTopDownLeftRightResend(ImageConsumer ic) 
   {
   }

   public void setMultiTransfer (boolean boolSet) 
   {
      boolMulti = boolSet;
      if (true == boolMulti)
         eztWrapper.setMultiTransfer (1);
      else
         eztWrapper.setMultiTransfer (0);
   }
   
   public boolean getMultiTransfer () 
   {
      return boolMulti;
   }

   public void startProduction (ImageConsumer ic)
   {     
      addConsumer (ic);
      
      // Just have one thread for simplicity
      if ((null == threadMulti) || (false == threadMulti.isAlive ()))
      {
         threadMulti = new Thread (this);
         threadMulti.start ();
      }
   }

   public void run () 
   {
      // A flag to indicate that at least one image has been transferred.
      boolean boolTransferred = false;
      ImageConsumer ic;
      
      do
      {
         int handle = eztWrapper.acquireNative (hwnd, EZTwainWrapper.TWAIN_ANYTYPE);
         if (0 == handle)
         {
            // loop over all consumers
            Vector v = (Vector) vecConsumers.clone();
            Iterator i = v.iterator ();

            while (i.hasNext ())
            {
               ic = (ImageConsumer) i.next ();
               if ((false == boolMulti) || (true == boolTransferred))
                  ic.imageComplete (ImageConsumer.STATICIMAGEDONE);
               else
                  ic.imageComplete(ImageConsumer.IMAGEABORTED);
            }

            if (true == boolMulti)
            {
               eztWrapper.closeSource ();
               eztWrapper.closeSourceManager (hwnd);
               eztWrapper.unloadSourceManager ();
               boolTransferred = false;
            }

            return;
         }

         int x = eztWrapper.dibWidth (handle);
         int y = eztWrapper.dibHeight (handle);
         byte[] buf = new byte[3*x];
         int[] imagedata = new int[x*y];
         Hashtable ht = new Hashtable();
         ColorModel cm = new DirectColorModel(32, 0x000000FF, 0x0000FF00, 0x00FF0000, 0xFF000000);

         for (int i = 0; i < y; i++)
         {
            eztWrapper.dibReadRowRGB (handle, i, buf);
            for (int j = 0; j < x; j++)
            {
               int r = buf[3*j];
               r = (r < 0) ? (r + 256) : r;
               int g = buf[3*j + 1];
               g = (g < 0) ? (g + 256) : g;
               g <<= 8;
               int b = buf[3*j + 2];
               b = (b < 0) ? (b + 256) : b;
               b <<= 16;

               imagedata[i*x + j] = r | g | b | 0xFF000000;
            }
         }
         eztWrapper.freeNative (handle);

         // loop over all consumers
         Vector v = (Vector) vecConsumers.clone();
         Iterator i = v.iterator ();

         while (i.hasNext ())
         {
            ic = (ImageConsumer) i.next ();

            ic.setColorModel (cm);
            ic.setDimensions (x, y);
            ic.setProperties (ht);
            ic.setHints (ImageConsumer.RANDOMPIXELORDER);
            ic.setPixels (0, 0, x, y, cm, imagedata, 0, x);
            if (true == boolMulti)
            {
               ic.imageComplete (ImageConsumer.SINGLEFRAMEDONE);
               boolTransferred = true;
            }
            else
               ic.imageComplete (ImageConsumer.STATICIMAGEDONE);
         }
      }
      while (true == boolMulti);
   }
   
   public static void main (String[] strArgs)
   {
      SimpleEZTwainSource source = new SimpleEZTwainSource ();
      
      //source.selectSource ();
      source.setMultiTransfer (true);
      source.show ();      
   }
   
   public void show ()
   {
      TestFrame test = new TestFrame (this);
   }

   public class TestFrame extends java.awt.Frame
   {      
      protected ImageProducer ip;     
      protected java.awt.Image img;
      protected Vector vecImages = new Vector ();
      protected FrameGrabber fg = new FrameGrabber ();
      
      TestFrame (ImageProducer ip)
      {
         this.show ();
         this.ip = ip;
         
         ip.startProduction (fg);
/*         img = createImage (ip);
         
         BufferedImage bimg = (BufferedImage) createImage (240, 180);
         java.awt.Graphics g = bimg.getGraphics ();
         g.drawImage (img, 0, 0, this);*/
      }
      
      public void paint (java.awt.Graphics g)
      {
         //g.drawImage (img, 0, 25, this);         
         int y = 25;         
         Iterator i = fg.getImages ().iterator (); //vecImages.iterator ();
         while (i.hasNext ())
         {
            System.out.println (y);
            java.awt.Image bimg = (java.awt.Image) i.next ();
            g.drawImage (bimg, 0, y, this);
            y += bimg.getHeight (this);            
         }       
      }
/*
      public boolean imageUpdate (java.awt.Image img, int infoflags, int x, int y, int width, int height) 
      {  
         if (ImageObserver.ABORT == (infoflags & ImageObserver.ABORT))
         {
            return false;
         }
         else if (ImageObserver.ALLBITS == (infoflags & ImageObserver.ALLBITS))
         {
            return false;
         }  
         else if (ImageObserver.FRAMEBITS == (infoflags & ImageObserver.FRAMEBITS))
         {
            BufferedImage bimg = (BufferedImage) createImage (240, 180);
            java.awt.Graphics g = bimg.getGraphics ();
            g.drawImage (img, 0, 0, this);

            vecImages.add (bimg);
            
            return true;
         }
         
         return true;
      }*/
   }
}

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/




