//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.stroke;

import java.awt.geom.*;
import java.io.*;
import java.util.*;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.noise.*;
import edu.berkeley.guir.lib.satin.*;

/**
 * Utilities for manipulating strokes, including:
 * <UL>
 *    <LI>Straightening strokes into lines that go up, down, left, or right
 *        only
 *    <LI>Merging two strokes together
 *    <LI>Splitting two strokes apart
 *    <LI>Calculating temporal and spatial distances between two strokes.
 * </UL>
 * See {@link Polygon2D#simplify()} for how to simplify a polyline.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 02 1999, JH
 *               Created class
 *             - SATIN-v1.0-1.0.0, Jul 22 2000, JH
 *               Moved the temporal and spatial distance methods
 *               from PhraseInterpreter to here.
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.1.0, Oct 07 2000, JH
 *               Added computeApproxDirectionVector()
 *             - SATIN-v2.2-1.1.1, Nov 20 2000, JH
 *               Fixed computeTemporalDistance() to return temporalDistance
 *               instead of maxTemporalDistance
 *             - SATIN-v2.2-1.2.0, Mar 16 2001, JL
 *               Added straighten()
 *             - SATIN-v2.2/1.3.0, Apr 11 2002, JH
 *               Added Quill output code.
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.2.0, Mar 16 2001
 */
public class StrokeLib 
   implements SatinConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================




   //===========================================================================
   //===   RUBINE FEATURE EXTRACTION METHODS   =================================

   //// All relative coordinates


   //-----------------------------------------------------------------

   public static double calculateAnglePerDistance(TimedStroke stk) {
       double    totalAngle  = calculateTotalAngle(stk);
       double    totalLength = calculateTotalLength(stk);

       return (totalAngle / totalLength);
   } // of method

   //-----------------------------------------------------------------

   public static double calculateAspect(TimedStroke stk) {
       Rectangle2D bds      = stk.getBounds2D(COORD_REL);
       double      bdsTheta = Math.atan2(bds.getHeight(), bds.getWidth());

       return (Math.abs(bdsTheta - 45.0 / 180.0 * Math.PI));
   } // of method

   //-----------------------------------------------------------------

   public static double calculateBoundsAngle(TimedStroke stk) {
       Rectangle2D bds = stk.getBounds2D(COORD_REL);
       return (Math.atan2(bds.getHeight(), bds.getWidth()));
   } // of method

   //-----------------------------------------------------------------

   public static double calculateBoundsSize(TimedStroke stk) {
       Rectangle2D bds = stk.getBounds2D(COORD_REL);
       return (Math.sqrt(bds.getHeight()*bds.getHeight() + 
                         bds.getWidth()*bds.getWidth() ));
   } // of method

   //-----------------------------------------------------------------

   public static double calculateCurviness1(TimedStroke stk) {
      Polygon2D points = stk.getPolygon2D(COORD_REL);
      double    value  = 0;

      double lowerThreshold        = 5;
      double upperThreshold        = 20;
      double lowerThresholdRadians = lowerThreshold / 180 * Math.PI;
      double upperThresholdRadians = upperThreshold / 180 * Math.PI;

      for (int i = 2; i < points.npoints; i++) {
          double dx       = points.xpoints[i] - points.xpoints[i-1];
          double dy       = points.ypoints[i] - points.ypoints[i-1];
          double dx2      = points.xpoints[i-1] - points.xpoints[i-2];
          double dy2      = points.ypoints[i-1] - points.ypoints[i-2];

          double theta    = Math.atan2(dx*dy2 - dx2*dy, dx*dx2 + dy*dy2);
          double absTheta = Math.abs(theta);

          if ((absTheta > lowerThresholdRadians) &&
              (absTheta < upperThresholdRadians))
            value += theta;
      }
      return (Math.abs(value));
   } // of method

   //-----------------------------------------------------------------

   public static double calculateCurviness2(TimedStroke stk) {
      Polygon2D points    = stk.getPolygon2D(COORD_REL);
      double    threshold = 19;
      double    value     = 0;

      double thresholdRadians = threshold / 180 * Math.PI;
      for (int i = 2; i < points.npoints; i++) {
          double dx    = points.xpoints[i] - points.xpoints[i-1];
          double dy    = points.ypoints[i] - points.ypoints[i-1];
          double dx2   = points.xpoints[i-1] - points.xpoints[i-2];
          double dy2   = points.ypoints[i-1] - points.ypoints[i-2];
          double theta = Math.atan2(dx*dy2 - dx2*dy, dx*dx2 + dy*dy2);

          if (Math.abs(theta) < thresholdRadians)
              value += theta;
      }
      return (Math.abs(value));
   } // of method

   //-----------------------------------------------------------------

   public static double calculateDensity1(TimedStroke stk) {
       double totalLength = calculateTotalLength(stk);
       double endsDist    = calculateEndsDistance(stk);

       if (endsDist != 0) {
           return (totalLength / endsDist);
       }
       else {
           return (0);
       }
   } // of method

   //-----------------------------------------------------------------

   public static double calculateDensity2(TimedStroke stk) {
       double totalLength = calculateTotalLength(stk);
       double boundsSize  = calculateBoundsSize(stk);

       return (totalLength / boundsSize);
   } // of method

   //-----------------------------------------------------------------

   public static double calculateEndsAngleCosine(TimedStroke stk) {
      Polygon2D p       = stk.getPolygon2D(COORD_REL);
      double    value   = 0;
      double    rolloff = (4*4);
      double    EPSILON = 1e-4;

      if (p.npoints < 3) {
          value = 0;
      }
      else {
          double x0     = p.xpoints[0];
          double y0     = p.ypoints[0];
          double xn     = p.xpoints[p.npoints-1];
          double yn     = p.ypoints[p.npoints-1];
          double hypot  = Math.sqrt((xn-x0)*(xn-x0) + (yn-y0)*(yn-y0));
          double factor = hypot * hypot / rolloff;
          if (factor > 1) {
              factor = 1;
          }
          factor = (hypot > EPSILON) ? factor/hypot : 0;
          value = (xn - x0) * factor;
      }
      return (value);
   } // of method

   //-----------------------------------------------------------------

   public static double calculateEndsAngleSine(TimedStroke stk) {
      Polygon2D p       = stk.getPolygon2D(COORD_REL);
      double    value   = 0;
      double    rolloff = (4*4);
      double    EPSILON = 1e-4;

      if (p.npoints < 3) {
          value = 0;
      }
      else {
          double x0     = p.xpoints[0];
          double y0     = p.ypoints[0];
          double xn     = p.xpoints[p.npoints-1];
          double yn     = p.ypoints[p.npoints-1];
          double hypot  = Math.sqrt((xn-x0)*(xn-x0) + (yn-y0)*(yn-y0));
          double factor = hypot * hypot / rolloff;
          if (factor > 1) {
              factor = 1;
          }
          factor = (hypot > EPSILON) ? factor/hypot : 0;
          value = (yn - y0) * factor;
      }
      return (value);
   } // of method

   //-----------------------------------------------------------------

   public static double calculateEndsDistance(TimedStroke stk) {
      Polygon2D points = stk.getPolygon2D(COORD_REL);

      if (points.npoints > 0) {
          double dx = points.xpoints[points.npoints-1] - points.xpoints[0];
          double dy = points.ypoints[points.npoints-1] - points.ypoints[0];
          return (Math.sqrt(dx*dx + dy*dy));
      }
      else {
          return (0);
      }
   } // of method

   //-----------------------------------------------------------------

   public static double calculateInitAngleCosine(TimedStroke stk) {
      Polygon2D p     = stk.getPolygon2D(COORD_REL);
      double    value = 0;

      if (p.npoints < 3) {
          value = 0;
      }
      else {
          double x0 = p.xpoints[0];
          double y0 = p.ypoints[0];
          double x2 = p.xpoints[2];
          double y2 = p.ypoints[2];
          double hypot = Math.sqrt((x2-x0)*(x2-x0) + (y2-y0)*(y2-y0));
          value = (hypot == 0) ? 0 : (x2 - x0) / hypot;
      }
      return (value);
   } // of method

   //-----------------------------------------------------------------

   public static double calculateInitAngleSine(TimedStroke stk) {
      Polygon2D p     = stk.getPolygon2D(COORD_REL);
      double    value = 0;

      if (p.npoints < 3) {
          value = 0;
      }
      else {
          double x0 = p.xpoints[0];
          double y0 = p.ypoints[0];
          double x2 = p.xpoints[2];
          double y2 = p.ypoints[2];
          double hypot = Math.sqrt((x2-x0)*(x2-x0) + (y2-y0)*(y2-y0));
          value = (hypot == 0) ? 0 : (y2 - y0) / hypot;
      }
      return (value);
   } // of method

   //-----------------------------------------------------------------

   public static double calculateLogArea(TimedStroke stk) {
       Rectangle2D bds          = stk.getBounds2D(COORD_REL);
       double      boundsLength = Math.sqrt((bds.getWidth()*bds.getWidth()) +
                                            (bds.getHeight()*bds.getHeight()));
       return (2 * Math.log(boundsLength));
   } // of method

   //-----------------------------------------------------------------

   public static double calculateLogAspect(TimedStroke stk) {
       double RADIANS45  = 45.0 / 180.0 * Math.PI;
       double ONE_DEGREE =  1.0 / 180.0 * Math.PI;

       Rectangle2D bds         = stk.getBounds2D(COORD_REL);
       double      boundsAngle = Math.atan2(bds.getHeight(), bds.getWidth());
       double      aspect      = Math.abs(boundsAngle - RADIANS45);
       double      value       = Math.log((aspect != 0) ? aspect : ONE_DEGREE);

       return (value);
   } // of method

   //-----------------------------------------------------------------

   public static double calculateSharpness(TimedStroke stk) {
       Polygon2D points = stk.getPolygon2D(COORD_REL);
       double  value  = 0;
       for (int i = 2; i < points.npoints; i++) {
           double dx    = points.xpoints[i]   - points.xpoints[i-1];
           double dy    = points.ypoints[i]   - points.ypoints[i-1];
           double dx2   = points.xpoints[i-1] - points.xpoints[i-2];
           double dy2   = points.ypoints[i-1] - points.ypoints[i-2];
           double theta = Math.atan2(dx*dy2 - dx2*dy, dx*dx2 + dy*dy2);
           value += theta*theta;
       }
       return (value);
   } // of method

   //-----------------------------------------------------------------

   public static double calculateTotalAbsAngle(TimedStroke stk) {
       Polygon2D points = stk.getPolygon2D(COORD_REL);
       double    value  = 0;

       for (int i = 2; i < points.npoints; i++) {
           double dx    = points.xpoints[i]   - points.xpoints[i-1];
           double dy    = points.ypoints[i]   - points.ypoints[i-1];
           double dx2   = points.xpoints[i-1] - points.xpoints[i-2];
           double dy2   = points.ypoints[i-1] - points.ypoints[i-2];
           double theta = Math.atan2(dx*dy2 - dx2*dy, dx*dx2 + dy*dy2);
           value += Math.abs(theta);
       }
       return (value);
   } // of method

   //-----------------------------------------------------------------

   public static double calculateTotalAngle(TimedStroke stk) {
       Polygon2D points = stk.getPolygon2D(COORD_REL);
       double    value  = 0;

       for (int i = 2; i < points.npoints; i++) {
           double dx    = points.xpoints[i]   - points.xpoints[i-1];
           double dy    = points.ypoints[i]   - points.ypoints[i-1];
           double dx2   = points.xpoints[i-1] - points.xpoints[i-2];
           double dy2   = points.ypoints[i-1] - points.ypoints[i-2];
           double theta = Math.atan2(dx*dy2 - dx2*dy, dx*dx2 + dy*dy2);
           value += theta;
       }
       return (value);

   } // of method

   //-----------------------------------------------------------------

   public static double calculateTotalLength(TimedStroke stk) {
       Polygon2D points = stk.getPolygon2D(COORD_REL);
       double    value  = 0;

       for (int i = 1; i < points.npoints; i++) {
           double dx = points.xpoints[i] - points.xpoints[i-1];
           double dy = points.ypoints[i] - points.ypoints[i-1];
           double magsq = dx*dx + dy*dy;
           value += Math.sqrt(magsq);
       }
       return (value);
   } // of method

   //===   RUBINE FEATURE EXTRACTION METHODS   =================================
   //===========================================================================





   //===========================================================================
   //===   STROKE CUMULATIVE METHODS   =========================================

   /**
    * Return an array that contains the cumulative length of the polygon.
    * For example, index[0] is 0.0, index[1] is the length from point 0 to 1,
    * index[2] is length from point 0 to 2, etc.
    */
   public static float[] getCumulativeLengths(Polygon2D poly) {
      float[] lengths = new float[poly.npoints];

      if (poly.npoints == 0) {
         return (lengths);
      }

      lengths[0] = 0;
      for (int i = 1; i < poly.npoints; i++) {
         lengths[i] = lengths[i - 1] + 
                      GeomLib.distance(
                                  poly.xpoints[i],     poly.ypoints[i],
                                  poly.xpoints[i - 1], poly.ypoints[i - 1]);
      }

      return (lengths);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Return an array that contains the cumulative X values of the polygon.
    * For example, given polygon {(2, 3), (6, 7), (9, 10)}, the array returned
    * would be {2, 8, 17} (2, 2+6, 2+6+9).
    */
   public static float[] getCumulativeXValues(Polygon2D poly) {
      float[] xvals = new float[poly.npoints];

      xvals[0] = poly.xpoints[0];
      for (int i = 1; i < poly.npoints; i++) {
         xvals[i] = xvals[i - 1] + poly.xpoints[i];
      }

      return (xvals);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Return an array that contains the cumulative X values of the polygon.
    * For example, given polygon {(2, 3), (6, 7), (9, 10)}, the array returned
    * would be {3, 10, 20} (3, 3+7, 3+7+10).
    */
   public static float[] getCumulativeYValues(Polygon2D poly) {
      float[] yvals = new float[poly.npoints];

      yvals[0] = poly.ypoints[0];
      for (int i = 1; i < poly.npoints; i++) {
         yvals[i] = yvals[i - 1] + poly.ypoints[i];
      }

      return (yvals);
   } // of method

   //===   STROKE CUMULATIVE METHODS   =========================================
   //===========================================================================
   



   //===========================================================================
   //===   STROKE VELOCITY METHODS   ===========================================

   /**
    * Given a stroke, approximate the direction that the 
    * last few endpoints are going in.
    *
    * @param  cdsys is the coordinate system to use.
    * @param  stk is the stroke whose approximate direction we want.
    * @return a Point2D representing direction and magnitude.
    */
   public static Point2D computeApproxDirection(int cdsys, 
                                                TimedStroke stk) {
      int       len     = stk.getNumPoints();
      int       startpt = Math.max(0, len - 15);    // 15 is my best guess
      Polygon2D points  = stk.getPolygon2D(cdsys);
      Point2D   ptA     = new Point2D.Float();
      Point2D   ptB     = new Point2D.Float();
      Point2D   ptDel   = new Point2D.Float();

      //// 1. Calculate the general direction we are going by
      ////    looking at the last few points.
      for (int i = startpt; i < len; i++) {
         ptA.setLocation(points.xpoints[i], points.ypoints[i]);
         for (int j = i + 1; j < len; j++) {
            ptB.setLocation(points.xpoints[j], points.ypoints[j]);
            ptDel.setLocation(ptDel.getX() + (ptB.getX() - ptA.getX()),
                              ptDel.getY() + (ptB.getY() - ptA.getY()));
         }
      }

      //// 2. Normalize the distance to be 1.0.
      double dist = Math.sqrt(ptDel.getX()*ptDel.getX() +
                             ptDel.getY()*ptDel.getY());
      ptDel.setLocation(ptDel.getX() / dist, ptDel.getY() / dist);


      return (ptDel);
   } // of method

   //===   STROKE VELOCITY METHODS   ===========================================
   //===========================================================================




   //===========================================================================
   //===   DISTANCE METHODS   ==================================================

   /**
    * Calculates the Euclidean distance between the endpoints of the given
    * stroke in the given coordinate system.
    * 
    * @param  cdsys is the coordinate system to use.
    * @param  stk is the stroke endpoint distance we want.
    * 
    * @return a double representing the distance.
    */
   public static double computeEndpointDistance(int cdsys, 
                                                TimedStroke stk) {
      Point2D startPt = stk.getStartPoint2D(cdsys);
      Point2D endPt = stk.getEndPoint2D(cdsys);
      
      return GeomLib.distance(startPt, endPt);
   } // of method

   //-----------------------------------------------------------------
   
   /**
    * Calls the other computeSpatialDistance() method using unbiased
    * distances (ie weights of 1).
    */
   public static double computeSpatialDistance(TimedStroke stk1, 
                                               TimedStroke stk2) {
      return (computeSpatialDistance(1.0, 1.0, stk1, stk2));
   } // of method



   /**
    * Compute the spatial distance between two strokes. The spatial distance 
    * between two strokes is the weighted sum of the minimum x-distance and 
    * the minimum y-distance between two strokes.
    * <P>
    * Method uses a version of the algorithm proposed by 
    * Chiu and Wilcox in Chiu, P. and Wilcox, L. "A Dynamic Grouping 
    * Technique for Ink and Audio Notes," Proceedings of UIST 98, San 
    * Francisco, CA, November 1-4, 1998, pp. 195-202.
    *
    * @param relImportanceX is the weight on the x-distance.
    * @param relImportanceY is the weight on the y-distance.
    * @param stk1           is a stroke.
    * @param stk2           is a stroke.
    */
   public static double computeSpatialDistance(double relImportanceX, 
                                               double relImportanceY, 
                                               TimedStroke stk1, 
                                               TimedStroke stk2) {
      //// 1. Compute spatial distance.
      double      dx, dy, spatialDistance;
      Rectangle2D boundsStk1 = stk1.getBounds2D(COORD_ABS);
      Rectangle2D boundsStk2 = stk2.getBounds2D(COORD_ABS);
                
      //// 1.1. If the strokes intersect, the spatial distance is zero
      if (stk1.shapeIntersects(stk2)) {
         spatialDistance = 0;
      } 
      else {
         //// 1.2.1. Compute x distance. 
         ////        It's the distance from the rightmost point of the 
         ////        leftmost stroke to the leftmost point of the 
         ////        rightmost stroke. It's zero if the strokes
         ////        overlap horizontally.
         if (boundsStk2.getX() > boundsStk1.getX()) {
          dx = boundsStk2.getX() - (boundsStk1.getX() + boundsStk1.getWidth());
         } 
         else { 
          dx = boundsStk1.getX() - (boundsStk2.getX() + boundsStk2.getWidth());
         }
         if (dx < 0) {
            dx = 0;
         }

         //// 1.2.2. Compute y distance. 
         ////        It's the distance from the lowest point of the 
         ////        topmost stroke to the highest point of the 
         ////        lowermost stroke. It's zero if the strokes
         ////        overlap vertically.
         if (boundsStk2.getY() > boundsStk1.getY()) {
          dy = boundsStk2.getY() - (boundsStk1.getY() + boundsStk1.getHeight());
         } 
         else { 
          dy = boundsStk1.getY() - (boundsStk2.getY() + boundsStk2.getHeight());
         }
         if (dy < 0) {
            dy = 0;
         }

         //// 1.2.3. Compute spatial distance assiging relative weights 
         ////        to x & y distances
         spatialDistance = relImportanceX*dx + relImportanceY*dy;
      }

      return (spatialDistance);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Compute the distance between two strokes in terms of time. Use a maximum
    * time value of 100,000.
    */
   public static double computeTemporalDistance(TimedStroke stk1, 
                                                TimedStroke stk2) {
      return (computeTemporalDistance(stk1, stk2, 100000.0));
   } // of method



   /**
    * Compute the distance between two strokes in terms of time. 
    * <P>
    * Method uses a version of the algorithm proposed by 
    * Chiu and Wilcox in Chiu, P. and Wilcox, L. "A Dynamic Grouping 
    * Technique for Ink and Audio Notes," Proceedings of UIST 98, San 
    * Francisco, CA, November 1-4, 1998, pp. 195-202.
    */
   public static double computeTemporalDistance(TimedStroke stk1, 
                                                TimedStroke stk2,
                                                double maxTimeDistance) {
      double temporalDistance = 0.0;

      //// 1. Figure out time distance.
      if (stk1.getEndTime() < stk2.getStartTime()) {
         temporalDistance = stk2.getStartTime() - stk1.getEndTime();
      }
      else {
         temporalDistance = stk1.getStartTime() - stk2.getEndTime();
      }

      //// 2. Calculate max on time distance.
      if (temporalDistance > maxTimeDistance) {
         temporalDistance = maxTimeDistance;
      }

      return (temporalDistance);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Compute the distance between two strokes in some "stroke-space".
    * Weight temporal distances and spatial distances equally (ie 1).
    */
   public static double computeDistance(TimedStroke stk1, TimedStroke stk2) {
      return (computeDistance(1.0, 1.0, stk1, stk2));
   } // of method



   /**
    * Compute how far two strokes are in "handwriting space". Lower values mean
    * these two strokes should be aggregated together. Only takes spatial
    * distance into account, ignores temporal.
    */
   public static double computeHandwritingDistance(TimedStroke stk1,
                                                   TimedStroke stk2) {
      return (5.0 * computeSpatialDistance(1.0, 4.0, stk1, stk2));
   } // of method



   /**
    * Compute the distance between two strokes in some "stroke-space".
    * <P>
    * Method uses a version of the algorithm proposed by 
    * Chiu and Wilcox in Chiu, P. and Wilcox, L. "A Dynamic Grouping 
    * Technique for Ink and Audio Notes," Proceedings of UIST 98, San 
    * Francisco, CA, November 1-4, 1998, pp. 195-202.
    */
   public static double computeDistance(double relImportanceSpace, 
                                        double relImportanceTime, 
                                        TimedStroke stk1, 
                                        TimedStroke stk2) {

      return (relImportanceTime  * computeTemporalDistance(stk1, stk2) +
              relImportanceSpace * computeSpatialDistance(stk1, stk2));
   } // of method

   //===   DISTANCE METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   NOISE METHODS   =====================================================

   /**
    * Create a reasonably noisy straight-line TimedStroke.
    *
    * <P>
    * "Values of 0.3 for Freq, 0.05 for Amp, 10 for Steps produces surprisingly
    * informal appearance, with reasonable performance cost. Note that each new
    * component should be given a unique value for T (e.g. increase T by a
    * large non-integral number every time a new object is created)."
    *
    * <P>
    * So, from my hacking, here's what I can tell:
    * <UL>
    *    <LI>Values of <CODE>t</CODE> and <CODE>freq</CODE> don't really matter
    *        that much
    *    <LI><CODE>amp</CODE> and <CODE>steps</CODE> are the key variables.
    *    <LI><CODE>amp</CODE> represents the number of pixels to offset.
    *        Reasonable values are between 1 and 10.
    *    <LI><CODE>steps</CODE> is the number of points in the stroke.
    *        Reasonable values depend on the overall length of the stroke,
    *        but I've found that between 10 and 20 is often good enough.
    * </UL>
    *
    * <P>
    * Uses Perlin noise algorithm in "Creating Informal Looking Interfaces" 
    * by Jonathan Meyer and Michael Crumpton, at:
    * http://www.cat.nyu.edu/meyer/projects/etchapad/lines.html
    *
    * @param t     determines what part of the noise curve is sampled for 
    *              that object. 
    * @param freq  determines the rate of sampling
    * @param amp   indicates the level
    * @param steps indicates how many samples to introduce per line segment
    */
   public static TimedStroke getNoisyStroke(float x1,  float y1, 
                                            float x2,  float y2, 
                                            float t,   float freq, 
                                            float amp, int   steps) {
       TimedStroke stk = new TimedStroke();

       float step    = 1.0f / steps;
       //float linelen = (float) (Math.sqrt( (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) ));
       float xmag    = amp; 
       float ymag    = amp; 
       float n;
       float xx;
       float yy;

       stk.addPoint(x1, y1);

       // System.out.println("xmag: " + xmag);
       // System.out.println("ymag: " + ymag);
       for (float a = step; a < 1; a += step) {
           n = (float) NoiseLib.noise1(t);
           t += freq;

           xx = x1 + a*(x2 - x1) + n * xmag;
           yy = y1 + a*(y2 - y1) + n * ymag;
           // System.out.println("a: " + a + "n: " + n + 
           //                    "\txx: " + xx + "\tyy: " + yy);

           stk.addPoint(xx, yy);
       }
       stk.addPoint(x2, y2);

       // System.out.println(stk.getBoundingPoints2D(COORD_LOCAL));

       return (stk);
   } // of method

   //-----------------------------------------------------------------

   /**
    * @return Return how many points were added.
    */
   private static int interpolate(
                 float[] srcxpts, float[] srcypts, int srci, int srcj,
                 float[] dstxpts, float[] dstypts, int dsti, float maxlen) {

       //// 1. Figure out the distance.
       double dist = Point2D.distance(srcxpts[srci],   srcypts[srci],
                                      srcxpts[srci+1], srcypts[srci+1]);

       //// 2. If it is a split value, then split into the
       ////    right number of substrokes.
       if (dist >= maxlen) {
           int split = (int) (dist / maxlen);

           float newx;
           float newy;
           for (int j = 0; j < split; j++) {
               newx = srcxpts[srci] + 
                             ((float)j/split)*(srcxpts[srcj] - srcxpts[srci]);

               newy = srcypts[srci] + 
                             ((float)j/split)*(srcypts[srcj] - srcypts[srci]);

               dstxpts[dsti] = newx;
               dstypts[dsti] = newy;
               dsti++;
           }

           return (split);
       }
       //// 3. Otherwise, just copy the point value over.
       else {
           dstxpts[dsti] = srcxpts[srci];
           dstypts[dsti] = srcypts[srci];
           dsti++;

           return (1);
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add noise to a stroke. 
    *
    * @see #getNoisyStroke(float,float,float,float,float,float,float,int)
    * @param t      determines what part of the noise curve is sampled for 
    *               that object. 
    * @param freq   determines the rate of sampling
    * @param amp    indicates the level
    * @param maxlen is the maximum length of a substroke. Substrokes that
    *               are too long will be split.
    * @return a new TimedStroke.
    */
   public static TimedStroke noisify(TimedStroke stk, float t, 
                                     float freq, float amp, float maxlen) {
       Polygon2D poly      = stk.getBoundingPoints2D(COORD_LOCAL);
       float[]   xpts      = poly.xpoints;
       float[]   ypts      = poly.ypoints;
       int       len       = poly.npoints;
       int       numsplits = 0;             // number of strokes to split

       //// 0. Ignore short strokes.
       if (stk.getNumPoints() <= 1) {
           return new TimedStroke(stk);
       }

       //// 1. Split strokes that are too long
       //// 1.1. First count how many long strokes there are
       double dist;
       for (int i = 0; i < len - 1; i++) {
           dist = Point2D.distance(xpts[i], ypts[i], xpts[i+1], ypts[i+1]);
           if (dist >= maxlen) {
               //// Subtract 1 because we want to count the number of
               //// new vertex points, and there is already one for the
               //// current point.
               numsplits += (int) (dist / maxlen) - 1;
           }
       }


       //// 1.2. Handle the closed polygon condition.
       if (poly.isClosed()) {
           dist = Point2D.distance(xpts[len-1], ypts[len-1], xpts[0], ypts[0]);
           if (dist >= maxlen) {
               //// Not subtracting 1 is *not* a bug here, because
               //// there aren't any points allocated for closed polygons.
               numsplits += (int) (dist / maxlen);
           }
       }


       //// 1.3. If there are any splits, then split into substrokes.
       if (numsplits > 0) {

           //// 1.3.1. First, create a new array of points.
           float[] newxpts = new float[len + numsplits];
           float[] newypts = new float[len + numsplits];
           int     newi    = 0;


           //// 1.3.2. Find the split values again.
           for (int i = 0; i < len - 1; i++) {
               newi += interpolate(xpts,ypts,i,i+1,newxpts,newypts,newi,maxlen);
           }


           //// 1.3.5. Handle the closed polygon condition.
           if (poly.isClosed() && len >= 2) {
               newi += interpolate(xpts, ypts, len-1, 0,
                                   newxpts, newypts, newi, maxlen);
           }

           //// DEBUGGING
           // System.out.println("");
           // for (int i = 0; i < len; i++) {
           //     System.out.println("" + xpts[i] + " " + ypts[i]);
           // }

           //// Set the array to be the split substrokes array.
           xpts = newxpts;
           ypts = newypts;
           len  = xpts.length;
       }

       //// DEBUGGING
       // System.out.println("");
       // for (int i = 0; i < len; i++) {
       //     System.out.println("" + xpts[i] + " " + ypts[i]);
       // }

       //// 2. Add noise to the points.
       float n;

       for (int i = 0; i < len; i++) {
           n        = (float) NoiseLib.noise1(t);
           t       += freq;
           xpts[i] += n*amp;
           ypts[i] += n*amp;
       }

       //// 3. Return.
       TimedStroke newstk;
       poly   = new Polygon2D(xpts, ypts, len);
       newstk = new TimedStroke(poly);
       newstk.setHasClosedBoundingPoints(stk.hasClosedBoundingPoints());

       return (newstk);
   } // of method

   //===   NOISE METHODS   =====================================================
   //===========================================================================




   //===========================================================================
   //===   STROKE OUTPUT METHODS   =============================================

   /**
    * Convert a TimedStroke into a Quill Gesture. Useful for saving out
    * to file in Quill's output format.
    *
    * <P>
    * A {@link GesturePackage} contains a:
    * <UL>
    *    <LI>"training" {@link GestureSet}
    *    <LI>"test"     {@link GestureSet}
    * </UL>
    *
    * A {@link GestureSet} contains:
    * <UL>
    *    <LI>multiple {@link GestureCategory} instances
    * </UL>
    *
    * A {@link GestureCategory} contains:
    * <UL>
    *    <LI>multiple {@link Gesture} instances
    * </UL>
    *
    * <P>
    * Here is some code to write out Quill output.
    *
    * <PRE>
    *  //// 1. Prepare all of the strokes to output.
    *  TimedStroke     stkAA  = getTestInstanceStrokeAA();
    *  TimedStroke     stkBB  = getTestInstanceStrokeBB();
    *  TimedStroke     stkCC  = getTestInstanceStrokeCC();
    *  TimedStroke     stkDD  = getTestInstanceStrokeDD();
    *
    *  //// 2. Convert the strokes to Quill gestures.
    *  Gesture         gAA    = convertStrokeToQuillGesture(stkAA);
    *  Gesture         gBB    = convertStrokeToQuillGesture(stkBB);
    *  Gesture         gCC    = convertStrokeToQuillGesture(stkCC);
    *  Gesture         gDD    = convertStrokeToQuillGesture(stkDD);
    *
    *  //// 3. Create the Gesture Categories, and put the right
    *  ////    Gestures into the right Gesture Categories.
    *  GestureCategory gCatAA = new GestureCategory();
    *  GestureCategory gCatBB = new GestureCategory();
    *  GestureCategory gCatCC = new GestureCategory();
    *
    *  gCatAA.addGesture(gAA);
    *  gCatBB.addGesture(gBB);
    *  gCatCC.addGesture(gCC);
    *  gCatCC.addGesture(gDD);
    *
    *  //// 3.1. Set up a List of all of the categories.
    *  LinkedList listCategories = new LinkedList();
    *  listCategories.add(gCatAA);
    *  listCategories.add(gCatBB);
    *  listCategories.add(gCatCC);
    *
    *  //// 4. Prepare the training set. There are no test cases
    *  ////    here, so we can just go on and prepare the package.
    *  GestureSet     gTrainingSet = new GestureSet(listCategories);
    *  GesturePackage gPack        = new GesturePackage(gTrainingSet);
    *
    *  //// 5. Write out to file.
    *  FileWriter fwtr = new FileWriter("out.gsa");
    *  gPack.write(fwtr);
    *  fwtr.close();
    * </PRE>
    */
   public static Gesture convertStrokeToQuillGesture(TimedStroke stk) {
       TimedPolygon2D polyOrig   = stk.getPolygon2D(COORD_LOCAL);
       TimedPolygon   polyNew;
       int            len        = polyOrig.npoints;
       int[]          newXpoints = new int[len];
       int[]          newYpoints = new int[len];
       long[]         newTimes   = new long[len];

       //// 1. Create new arrays of points and convert the polygons.
       for (int i = 0; i < len; i++) {
           newXpoints[i] = (int) polyOrig.xpoints[i];
           newYpoints[i] = (int) polyOrig.ypoints[i];
           newTimes[i]   = polyOrig.times[i];
       }
       polyNew = new TimedPolygon(newXpoints, newYpoints, newTimes, len);

       //// 2. Create a new Gesture.
       Gesture gNew = new Gesture();
       gNew.setPoints(polyNew);

       return (gNew);
   } // of method

   //===   STROKE OUTPUT METHODS   =============================================
   //===========================================================================




   //===========================================================================
   //===   LINEARIZE STROKE METHODS   ==========================================

   private static final short DOWN  = 0;
   private static final short UP    = 1;
   private static final short LEFT  = 2;
   private static final short RIGHT = 3;

   //-----------------------------------------------------------------

   /**
    * Figure out the general direction we are going from point1 to point2.
    *
    * @return DOWN, UP, LEFT, or RIGHT.
    */
   private static short calcGeneralDirection(float x1, float y1, 
                                             float x2, float y2) {
      float dx = x2 - x1;
      float dy = y2 - y1;

      if (Math.abs(dx) >= Math.abs(dy)) {
         if (dx >= 0) {
            return (RIGHT);
         }
         else {
            return (LEFT);
         }
      }
      else {
         if (dy >= 0) {
            return (DOWN);
         }
         else {
            return (UP);
         }
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Turn part of a polygon into a straight line that goes UP, DOWN, LEFT, or
    * RIGHT.
    * <P>
    * for (int i = start; i < end; i++)
    *
    * @param direction is UP, DOWN, LEFT, or RIGHT.
    */
   private static Line2D 
   linearize(Polygon2D poly, int start, int end, short direction) {

      float minY = poly.ypoints[start];   // min Y found
      float maxY = poly.ypoints[start];   // max Y found
      float sumY = 0;                     // sum Y calculated
      float avgY = 0;                     // avg Y calculated

      float minX = poly.xpoints[start];   // min X found
      float maxX = poly.xpoints[start];   // max X found
      float sumX = 0;                     // sum X calculated
      float avgX = 0;                     // avg X calculated

      //// 1. Calculate the values above.
      for (int i = start; i < end; i++) {
         sumX += poly.xpoints[i];
         sumY += poly.ypoints[i];

         if (poly.ypoints[i] < minY) {
            minY = poly.ypoints[i];
         }
         else if (poly.ypoints[i] > maxY) {
            maxY = poly.ypoints[i];
         }

         if (poly.xpoints[i] < minX) {
            minX = poly.xpoints[i];
         }
         else if (poly.xpoints[i] > maxX) {
            maxX = poly.xpoints[i];
         }

      }

      //// 2. Calculate the averages.
      avgX = sumX / (end - start);
      avgY = sumY / (end - start);

      //// 3. Return a line based on the direction we are going.
      Line2D line = new Line2D.Float();
      switch (direction) {
         case UP:
            line.setLine(avgX, maxY, avgX, minY);
            break;
         case DOWN:
            line.setLine(avgX, minY, avgX, maxY);
            break;
         case LEFT:
            line.setLine(maxX, avgY, minX, avgY);
            break;
         case RIGHT:
            line.setLine(minX, avgY, maxX, avgY);
            break;
         default:
            // direction parameter must be UP, DOWN, LEFT, or RIGHT
            assert false; 
      }

      return (line);
   } // of 

   //-----------------------------------------------------------------

   /**
    * Convert a list of lines into a stroke.
    * The lines are "near" each other, and either go UP, DOWN, LEFT, or RIGHT.
    * <P>
    * This algorithm can be improved, since there are slight offsets
    * between lines, but we just throw those away, cascading the offset 
    * errors.
    */
   private static TimedStroke linesToStroke_1(LinkedList listLines) {
      TimedStroke linearStk = new TimedStroke(); Iterator    it =
      listLines.iterator(); Line2D      line; float       lastx, lasty;
      float       x1, y1, x2, y2;

      lastx = 0;
      lasty = 0;
      while (it.hasNext()) {
         line = (Line2D) it.next();
         x1   = (float) line.getX1();
         y1   = (float) line.getY1();
         x2   = (float) line.getX2();
         y2   = (float) line.getY2();

         if (linearStk.getNumPoints() <= 0) {
            linearStk.addPoint(x1, y1);
            linearStk.addPoint(x2, y2);
         }
         else {
            //// Goes up-down
            if (Math.abs(x1 - x2) < FLOATING_PT_TOLERANCE) {
               x2 = lastx;
               linearStk.addPoint(x2, y2);
            }
            //// Goes left-right
            else {
               y2 = lasty;
               linearStk.addPoint(x2, y2);
            }
         }

         lastx = x2;
         lasty = y2;
      }

      return (linearStk);
   } // of method

   //-----------------------------------------------------------------

   /**
    * A mini-filter for beginning and end points to determine the general
    * direction we are going. Biased towards later values (ie new directions
    * you are heading towards).
    * <P>
    * It's probably a good idea to use an odd-sized window, so that there won't
    * be any strange ties. In other words, start and end should either be both
    * even or both odd (e.g. start:0 end:4 looks at a window of 3 values).
    */
   private static short 
   calcGeneralDirection(short[] directions, int start, int end) {
      int[] dircounts = new int[4];

      //// Count the number of times each direction appears.
      for (int i = start; i < end; i++) {
         dircounts[directions[i]]++;
      }

      //// Now find the index of the max.
      short index = 0;
      int   max   = 0;
      for (short i = 0; i < dircounts.length; i++) {
         if (dircounts[i] >= max) {
            index = i;
            max   = dircounts[i];
         }
      }

      return (index);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Filter out abnormal values. Right now just filters the start and end
    * values. It's conceivable that you may want to filter out the middle
    * values too, but it seems to work okay as is.
    */
   private static void filterDirections(short[] directions) {
      int len = directions.length;

      if (len > 4) {
         //// 1.1. Set the beginning.
         directions[0] = calcGeneralDirection(directions, 0, 4);

         //// 1.2. Set the end.
         directions[len-1] = calcGeneralDirection(directions, len - 4, len);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Given a stroke, straighten it out. In other words, make a hand-drawn
    * stroke go up, down, left, or right only, with 90 degree transitions. 
    */
   public static TimedStroke linearize(TimedStroke stk) {
      TimedStroke linearStk  = null;
      Polygon2D   poly       = stk.getBoundingPoints2D(COORD_LOCAL);

      //// 0. Value at index i is direction from point i to point i+1
      short[]     directions = new short[poly.npoints - 1];

      //// 1. Figure out the general direction the stroke is going.
      for (int i = 0; i < poly.npoints - 1; i++) {
         directions[i] = calcGeneralDirection(
                              poly.xpoints[i],     poly.ypoints[i],
                              poly.xpoints[i + 1], poly.ypoints[i + 1]);
      }

      //// 2. Filter out noise in the directions.
      filterDirections(directions);

      //// 3. Change the directions into points.
      LinkedList listLines = new LinkedList();
      short      curdir    = directions[0];
      int        start     = 0;

      //// 3.1. Get the points.
      for (int i = 1; i < directions.length; i++) {
         if (curdir == directions[i]) {
            continue;
         }
         else {
            Line2D line = linearize(poly, start, i, curdir);
            listLines.add(line);
            curdir = directions[i];
            start  = i;
         }
      }

      //// 3.2. Get the last points since we last changed directions.
      if (start < poly.npoints) {
         Line2D line = linearize(poly, start, poly.npoints, curdir);
         listLines.add(line);
      }

      //// 4. Convert the lines into a stroke.
      linearStk = linesToStroke_1(listLines);

      //// 5. Set the linearized stroke's transform to be the same as original.
      linearStk.setTransform(stk.getTransform(COORD_REL));
      linearStk.setStyle(stk.getStyle());

      return (linearStk);
   } // of method

   //-----------------------------------------------------------------
   
   /**
    * Turns the given stroke into a straight line between the stroke's
    * endpoints.
    */
   public static void straighten(TimedStroke stk) {
      int numPoints = stk.getNumPoints();
      if (numPoints > 2) {
         float firstX = stk.poly.xpoints[0];
         float firstY = stk.poly.ypoints[0];
         long  firstTime = stk.poly.times[0];
         float lastX = stk.poly.xpoints[numPoints - 1];
         float lastY = stk.poly.ypoints[numPoints - 1];
         long  lastTime = stk.poly.times[numPoints - 1];
            
         stk.clearPoints();
         stk.addPoint(firstX, firstY, firstTime);
         stk.addPoint(lastX, lastY, lastTime);
      }
   }
   
   //===   LINEARIZE STROKE METHODS   ==========================================
   //===========================================================================




   //===========================================================================
   //===   MERGE STROKE METHODS   ==============================================

   /**
    * This method modifies the cumulative length array to get rid of the
    * center values. Only the first perc and last perc values remain.
    */
   private static void hideCenterLengths(float[] cumlengths, float perc) {
      if (cumlengths.length <= 0) {
         return;
      }

      float len         = cumlengths[cumlengths.length - 1];
      float startThresh = perc * len;
      float endThresh   = len - startThresh;

      for (int i = 0; i < cumlengths.length; i++) {
         if (cumlengths[i] < startThresh || cumlengths[i] > endThresh) {
            continue;
         }
         else {
            cumlengths[i] = -1;
         }
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Do our best to merge two strokes together into a new one.
    * Unfortunately loses time information.
    */
   public static TimedStroke mergeStrokes(TimedStroke stkAA, 
                                          TimedStroke stkBB) {
      //// 1. Get the bounding points.
      Polygon2D pAA = stkAA.getBoundingPoints2D(COORD_ABS);
      Polygon2D pBB = stkBB.getBoundingPoints2D(COORD_ABS);

      //// 2. Get the cumulative lengths of the polygons.
      float[] lenAA = getCumulativeLengths(pAA);
      float[] lenBB = getCumulativeLengths(pBB);

      //// 2.1. The 0.333 means to look only at the first third and the
      ////      last third of the stroke. To make it look at, say, the first
      ////      fifth, then use 0.2.
      hideCenterLengths(lenAA, 0.333f);
      hideCenterLengths(lenBB, 0.333f);

      //// 3. Calculate the distances between each of the points in AA to BB.
      ////    Store the corresponding index too.
      float[] mindists = new float[pAA.npoints];  // min dist for pAA
      int[]   indices  = new int[pAA.npoints];    // index of point in pBB
      double  mindist;                            // min dist for iteration
      int     index;                              // min dist index for iter
      double  dist;                               // tmp storage

      for (int i = 0; i < pAA.npoints; i++) {
         //// 3.1. Check if the point is too far away from the edge of a
         ////      stroke. If so, then continue.
         if (lenAA[i] < 0) {
            continue;
         }

         //// 3.2. Otherwise, calculate the min distance from pAA[i] to pBB.
         mindist  = Double.MAX_VALUE;
         index    = -1;
         for (int j = 0; j < pBB.npoints; j++) {
            if (lenBB[j] < 0) {
               continue;
            }
            dist = GeomLib.distance(pAA.xpoints[i], pAA.ypoints[i], 
                                    pBB.xpoints[j], pBB.ypoints[j]);
            if (dist < mindist) {
               mindist = (float) dist;
               index   = j;
            }
         }

         //// 3.3. Store the min dist and index.
         if (index >= 0) {
            mindists[i] = (float) mindist;
            indices[i]  = index;
         }
      }

      //// 4. Find the absolute min on both sides.
      int   indexAAFront = 0;
      int   indexBBFront = 0;
      float mindistFront = Float.MAX_VALUE;
      for (int i = 0; i < pAA.npoints; i++) {
         if (lenAA[i] < 0) {
            break;
         }
         if (mindists[i] < mindistFront) {
            mindistFront = mindists[i];
            indexAAFront = i;
            indexBBFront = indices[i];
         }
      }

      int   indexAABack = pAA.npoints - 1;
      int   indexBBBack = pBB.npoints - 1;
      float mindistBack = Float.MAX_VALUE;
      for (int i = pAA.npoints - 1; i >= 0; i--) {
         if (lenAA[i] < 0) {
            break;
         }
         if (mindists[i] < mindistBack) {
            mindistBack = mindists[i];
            indexAABack = i;
            indexBBBack = indices[i];
         }
      }

      //// 5.1. If both ends are too far apart, ignore.
      if (mindistFront > 2*DEFAULT_SELECT_THRESHOLD &&
          mindistBack  > 2*DEFAULT_SELECT_THRESHOLD) {
         return (null);
      }

      //// 5.2. Check if the front end of AA is connected to anything in BB.
      boolean flagFrontConnected = true;
      if (mindistFront > 2*DEFAULT_SELECT_THRESHOLD) {
         flagFrontConnected = false;
         indexAAFront = 0;
      }

      //// 5.3. Check if the tail end of AA is connected to anything in BB.
      boolean flagBackConnected = true;
      if (mindistBack  > 2*DEFAULT_SELECT_THRESHOLD) {
         flagBackConnected = false;
         indexAABack  = pAA.npoints - 1;
      }

      //// 6. Now try to merge the strokes together.
      ////    This part of the code is more complex than I would like, but I
      ////    don't know of any way of simplifying it.
      ////
      ////    If both ends are connected, then go from 
      ////        indexAAFront to indexAABack to indexBBBack to indexBBFront
      ////    If front end of AA is connected, then go from
      ////        indexAABack (npoints - 1) to indexAAFront to indexBBFront to
      ////        majority
      ////    If back end of AA is connected, then go from
      ////        indexAAFront (0) to indexAABack to indexBBBack to majority
      TimedStroke stk = new TimedStroke();

      //// 6.1. If both ends of AA are connected to something in BB...
      if (flagFrontConnected && flagBackConnected) {
         for (int i = indexAAFront; i < indexAABack; i++) {
            stk.addPoint(pAA.xpoints[i], pAA.ypoints[i]);
         }
         if (indexBBFront < indexBBBack) {
            for (int i = indexBBBack; i >= indexBBFront ; i--) {
               stk.addPoint(pBB.xpoints[i], pBB.ypoints[i]);
            }
         }
         else {
            for (int i = indexBBBack; i < indexBBFront; i++) {
               stk.addPoint(pBB.xpoints[i], pBB.ypoints[i]);
            }
         }
      }
      //// 6.2. ...else if only the front end of AA is connected to BB...
      else if (flagFrontConnected == true) {
         for (int i = indexAABack; i >= indexAAFront; i--) {
            stk.addPoint(pAA.xpoints[i], pAA.ypoints[i]);
         }

         //// 6.2.1. Go in the direction of the longer substroke.
         if (lenBB[indexBBFront] <
             lenBB[pBB.npoints - 1] - lenBB[indexBBFront]) {
            for (int i = indexBBFront; i < pBB.npoints; i++) {
               stk.addPoint(pBB.xpoints[i], pBB.ypoints[i]);
            }
         }
         else {
            for (int i = indexBBFront; i >= 0; i--) {
               stk.addPoint(pBB.xpoints[i], pBB.ypoints[i]);
            }
         }
      }
      //// 6.3. ...else if only the back end of AA is connected to BB...
      else if (flagBackConnected == true) {
         for (int i = indexAAFront; i < indexAABack; i++) {
            stk.addPoint(pAA.xpoints[i], pAA.ypoints[i]);
         }

         //// 6.3.1. Go in the direction of the longer substroke.
         if (lenBB[indexBBBack] < 
             lenBB[pBB.npoints - 1] - lenBB[indexBBBack]) {
            for (int i = indexBBBack; i < pBB.npoints; i++) {
               stk.addPoint(pBB.xpoints[i], pBB.ypoints[i]);
            }
         }
         else {
            for (int i = indexBBBack; i >= 0; i--) {
               stk.addPoint(pBB.xpoints[i], pBB.ypoints[i]);
            }
         }
      }
      //// 6.4. ...else no connection at all.
      else {
         return (null);
      }

      return (stk);
   } // of method

   //===   MERGE STROKE METHODS   ==============================================
   //===========================================================================




   //===========================================================================
   //===   SPLIT STROKE METHODS   ==============================================

   /**
    * Given a stroke and a box, return an iterator to a list of strokes that
    * results from erasing the region in the box, possibly cutting
    * the given stroke into several smaller strokes.
    *
    * @param stk  is the stroke to cut.
    * @param rect is the Rectangle in absolute coordinates.
    */
   public static java.util.List splitStroke(TimedStroke stk, Rectangle2D rect) {
      Polygon2D      p    = stk.getBoundingPoints2D(COORD_ABS); // stk bds
      Line2D         pSeg = new Line2D.Double();                // lines in stk

      LinkedList     list   = new LinkedList();    // list of new stks
      TimedStroke    newstk = null;                // stk to add

      java.util.List ptlist;       // list of points in pSeg intersecting rect 
      Iterator       it;           // iterator over ptlist
      Point2D        p1;           // first point in ptlist  (has at most 2)
      Point2D        p2;           // second point in ptlist (has at most 2)

      //// 1. Go through each point in the stroke.
      for (int i = 0; i < p.npoints - 1; i++) {

         //// 1.1. Create a line segment from each adjacent pair of points.
         double x1 = p.xpoints[i];
         double y1 = p.ypoints[i];
         double x2 = p.xpoints[i + 1];
         double y2 = p.ypoints[i + 1];
         pSeg.setLine(x1, y1, x2, y2);

         //// 1.2. If the line segment intersects the rectangle...
         if (pSeg.intersects(rect)) {
            ptlist = GeomLib.calcIntersectPoints(pSeg, rect);
            it   = ptlist.iterator();
            p1   = null;
            p2   = null;
            if (it.hasNext()) {
               p1 = (Point2D) it.next();
            }
            if (it.hasNext()) {
               p2 = (Point2D) it.next();
            }

            //// 1.2.1. Case 1 - Start point out, end point in rectangle
            if (!rect.contains(x1, y1) && rect.contains(x2, y2)) {
               if (newstk == null) {
                  newstk = new TimedStroke();
                  list.add(newstk);
               }
               newstk.addPoint(x1, y1);
               newstk.addPoint(p1);
               newstk = null;
            }
            //// 1.2.2. Case 2 - Start point in, end point out rectangle
            else if (rect.contains(x1, y1) && !rect.contains(x2, y2)) {
               if (newstk == null) {
                  newstk = new TimedStroke();
                  list.add(newstk);
               }
               newstk.addPoint(p1);
               newstk.addPoint(x2, y2);
            }
            //// 1.2.3. Case 3 - Both points out rectangle.
            else if (!rect.contains(x1, y1) && !rect.contains(x2, y2)) {
               if (newstk== null) {
                  newstk = new TimedStroke();
                  list.add(newstk);
               }
               newstk.addPoint(x1, y1);

               //// Make sure p1 is the closer one.
               if (p2 != null) {
                  if (GeomLib.distance(x1, y1, p1.getX(), p1.getY()) >
                      GeomLib.distance(x1, y1, p2.getX(), p2.getY())) {
                     Point2D ptmp = p1;
                     p1 = p2;
                     p2 = ptmp;
                  }
               }
               newstk.addPoint(p1);

               newstk = new TimedStroke();
               list.add(newstk);
               if (p2 != null) {
                  newstk.addPoint(p2);
               }
               newstk.addPoint(x2, y2);
            }
            //// 1.2.4. Case 4 - Both points in rectangle.
            else {
               //// ignore - do nothing and just continue
            }
         }
         //// 1.3. ...otherwise the line segment does not intersect...
         else {
            if (newstk == null) {
               newstk = new TimedStroke();
               list.add(newstk);
            }
            newstk.addPoint(x1, y1);
         }
      } // of for

      //// 1.4. Don't forget the last point.
      if (newstk != null) {
         newstk.addPoint(p.xpoints[p.npoints - 1], p.ypoints[p.npoints - 1]);
      }

      return (list);
   } // of splitStroke

   //===   SPLIT STROKE METHODS   ==============================================
   //===========================================================================




   /**
    * Returns whether the given stroke represents a tap.
    */
   public static boolean isTap(TimedStroke stk) {
      Rectangle2D absBds;
      if (stk.getParentGroup() == null) {
         absBds = stk.getBounds2D(COORD_LOCAL);
      }
      else {
         absBds = stk.getBounds2D(COORD_ABS);
      }
      
      return (absBds.getWidth() <= MAX_TAP_WIDTH &&
              absBds.getHeight() <= MAX_TAP_HEIGHT);
   }


   



   //===========================================================================
   //===   REGRESSION TEST METHODS   ===========================================

   /**
    * Get a sample stroke for testing purposes.
    */
   public static TimedStroke getTestInstanceStrokeAA() {
      TimedStroke stk = new TimedStroke();
      stk.addPoint(0,55);
      stk.addPoint(11,40);
      stk.addPoint(20,25);
      stk.addPoint(24,18);
      stk.addPoint(28,9);
      stk.addPoint(29,4);
      stk.addPoint(29,7);
      stk.addPoint(30,12);
      stk.addPoint(32,19);
      stk.addPoint(34,31);
      stk.addPoint(38,44);
      stk.addPoint(43,57);
      stk.addPoint(48,65);
      stk.addPoint(51,68);
      stk.addPoint(53,69);
      stk.addPoint(54,68);
      stk.addPoint(56,64);
      stk.addPoint(58,58);
      stk.addPoint(60,47);
      stk.addPoint(63,14);
      stk.addPoint(64,11);
      stk.addPoint(65,15);
      stk.addPoint(66,22);
      stk.addPoint(68,32);
      stk.addPoint(71,43);
      stk.addPoint(73,53);
      stk.addPoint(76,59);
      stk.addPoint(78,62);
      stk.addPoint(79,61);
      stk.addPoint(80,58);
      stk.addPoint(82,54);
      stk.addPoint(83,46);
      stk.addPoint(88,17);
      stk.addPoint(89,5);
      stk.addPoint(90,0);
      stk.addPoint(92,3);
      stk.addPoint(93,8);
      stk.addPoint(96,16);
      stk.addPoint(98,26);
      stk.addPoint(103,36);
      stk.addPoint(107,45);
      stk.addPoint(113,53);
      stk.addPoint(115,54);
      return (stk);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a sample stroke for testing purposes.
    */
   public static TimedStroke getTestInstanceStrokeBB() {
      TimedStroke stk = new TimedStroke();
      stk.addPoint(4       ,       12);
      stk.addPoint(5       ,       40);
      stk.addPoint(3       ,       68);
      stk.addPoint(1       ,       88);
      stk.addPoint(1       ,       104);
      stk.addPoint(2       ,       115);
      stk.addPoint(6       ,       117);
      stk.addPoint(25      ,       114);
      stk.addPoint(56      ,       106);
      stk.addPoint(77      ,       101);
      stk.addPoint(96      ,       99);
      stk.addPoint(109     ,       99);
      stk.addPoint(111     ,       89);
      stk.addPoint(109     ,       67);
      stk.addPoint(114     ,       43);
      stk.addPoint(117     ,       26);
      stk.addPoint(118     ,       16);
      stk.addPoint(115     ,       6);
      stk.addPoint(108     ,       1);
      stk.addPoint(99      ,       0);
      stk.addPoint(67      ,       4);
      stk.addPoint(34      ,       11);
      stk.addPoint(13      ,       17);
      stk.addPoint(3       ,       20);
      stk.addPoint(0       ,       23);
      return (stk);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a sample stroke for testing purposes.
    */
   public static TimedStroke getTestInstanceStrokeCC() {
      TimedStroke stk = new TimedStroke();
      stk.addPoint(0       ,       0);
      stk.addPoint(4       ,       13);
      stk.addPoint(6       ,       26);
      stk.addPoint(9       ,       39);
      stk.addPoint(14      ,       48);
      stk.addPoint(18      ,       50);
      stk.addPoint(24      ,       45);
      stk.addPoint(34      ,       34);
      stk.addPoint(40      ,       22);
      stk.addPoint(44      ,       14);
      stk.addPoint(46      ,       10);
      stk.addPoint(46      ,       13);
      stk.addPoint(47      ,       18);
      stk.addPoint(48      ,       26);
      stk.addPoint(49      ,       33);
      stk.addPoint(50      ,       41);
      stk.addPoint(51      ,       46);
      stk.addPoint(52      ,       48);
      stk.addPoint(54      ,       47);
      stk.addPoint(57      ,       42);
      stk.addPoint(62      ,       34);
      stk.addPoint(68      ,       24);
      stk.addPoint(76      ,       11);
      stk.addPoint(76      ,       14);
      stk.addPoint(76      ,       23);
      stk.addPoint(76      ,       31);
      stk.addPoint(79      ,       46);
      stk.addPoint(81      ,       46);
      stk.addPoint(83      ,       42);
      stk.addPoint(88      ,       34);
      stk.addPoint(93      ,       25);
      stk.addPoint(98      ,       17);
      stk.addPoint(101     ,       10);
      stk.addPoint(104     ,       3);
      stk.addPoint(104     ,       5);
      stk.addPoint(104     ,       9);
      stk.addPoint(104     ,       17);
      stk.addPoint(105     ,       26);
      stk.addPoint(106     ,       34);
      stk.addPoint(108     ,       40);
      stk.addPoint(110     ,       44);
      stk.addPoint(112     ,       47);
      stk.addPoint(113     ,       46);
      return (stk);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a sample stroke for testing purposes.
    */
   public static TimedStroke getTestInstanceStrokeDD() {
      TimedStroke stk = new TimedStroke();
      stk.addPoint(0       ,       0);
      stk.addPoint(0       ,       10);
      stk.addPoint(10      ,       10);
      stk.addPoint(10      ,       0);
      return (stk);
   } // of method

   //===   REGRESSION TEST METHODS   ===========================================
   //===========================================================================




   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) throws Exception {
       //// 1. Prepare all of the strokes to output.
       TimedStroke     stkAA  = getTestInstanceStrokeAA();
       TimedStroke     stkBB  = getTestInstanceStrokeBB();
       TimedStroke     stkCC  = getTestInstanceStrokeCC();
       TimedStroke     stkDD  = getTestInstanceStrokeDD();

       //// 2. Convert the strokes to Quill gestures.
       Gesture         gAA    = convertStrokeToQuillGesture(stkAA);
       Gesture         gBB    = convertStrokeToQuillGesture(stkBB);
       Gesture         gCC    = convertStrokeToQuillGesture(stkCC);
       Gesture         gDD    = convertStrokeToQuillGesture(stkDD);

       //// 3. Create the Gesture Categories, and put the right
       ////    Gestures into the right Gesture Categories.
       GestureCategory gCatAA = new GestureCategory();
       GestureCategory gCatBB = new GestureCategory();
       GestureCategory gCatCC = new GestureCategory();

       gCatAA.addGesture(gAA);
       gCatBB.addGesture(gBB);
       gCatCC.addGesture(gCC);
       gCatCC.addGesture(gDD);

       //// 3.1. Set up a List of all of the categories.
       LinkedList listCategories = new LinkedList();
       listCategories.add(gCatAA);
       listCategories.add(gCatBB);
       listCategories.add(gCatCC);

       //// 4. Prepare the training set. There are no test cases
       ////    here, so we can just go on and prepare the package.
       GestureSet     gTrainingSet = new GestureSet(listCategories);
       GesturePackage gPack        = new GesturePackage(gTrainingSet);

       //// 5. Write out to file.
       FileWriter fwtr = new FileWriter("out.gsa");
       gPack.write(fwtr);
       fwtr.close();
   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of Class StrokeLib

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/

