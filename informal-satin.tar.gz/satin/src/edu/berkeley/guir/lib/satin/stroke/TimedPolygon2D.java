//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.stroke;

import java.awt.*;
import java.io.Serializable;
import edu.berkeley.guir.lib.awt.geom.*;

/**
 * A polygon that also has timing information. 
 *
 * <P>
 * This implementation is not yet optimized for space. The difficulty lies
 * in the design decision made by Javasoft to make the arrays in Polygon
 * directly accessible, which can improve performance but make other
 * optimizations much more difficult since there is no abstraction.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Oct 06 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~allanl/">Chris Long</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">allanl@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class TimedPolygon2D
   extends    Polygon2D
   implements Serializable,
              Cloneable {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -4348203203982309698L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTANTS   =========================================================

   /**
    * Default length of the times array.
    */
   private static final int DEFAULT_ARRAY_LEN = 20;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   // in the tradition of Polygon, make this public
   public long[] times = new long[DEFAULT_ARRAY_LEN];

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public TimedPolygon2D() {
      super();
   } // of constructor

   //-----------------------------------------------------------------

   public TimedPolygon2D(int[] x, int[] y, int numPoints) {
      this(x, y, System.currentTimeMillis(), numPoints);
   } // of constructor
  
   //-----------------------------------------------------------------

   public TimedPolygon2D(int[] x, int[] y, long time, int numPoints) {
      super(x, y, numPoints);
      times = new long[numPoints];
      for (int i = 0; i < numPoints; i++) {
         times[i] = time;
      }
   } // of constructor
  
   //-----------------------------------------------------------------

   public TimedPolygon2D(int[] x, int[] y, long[] t, int numPoints) {
      super(x, y, numPoints);
      times = new long[t.length];
      System.arraycopy(t, 0, times, 0, npoints);        
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Clone the polygon, with all the times set to the current time.
    */
   public TimedPolygon2D(Polygon p) {
      this(p.xpoints, p.ypoints, p.npoints);
   } // of constructor
  
   //-----------------------------------------------------------------

   /**
    * Create a polygon with the specified times.
    */
   public TimedPolygon2D(Polygon p, long[] t) {
      this(p.xpoints, p.ypoints, t, p.npoints);
   } // of constructor

   //-----------------------------------------------------------------

   public TimedPolygon2D(float[] x, float[] y, int numPoints) {
      this(x, y, System.currentTimeMillis(), numPoints);
   } // of constructor
  
   //-----------------------------------------------------------------

   public TimedPolygon2D(float[] x, float[] y, long time, int numPoints) {
      super(x, y, numPoints);
      times = new long[numPoints];
      for (int i = 0; i < numPoints; i++) {
         times[i] = time;
      }
   } // of constructor
  
   //-----------------------------------------------------------------

   public TimedPolygon2D(float[] x, float[] y, long[] t, int numPoints) {
      super(x, y, numPoints);
      times = new long[t.length];
      System.arraycopy(t, 0, times, 0, npoints);        
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Clone the polygon, with all the times set to the current time.
    */
   public TimedPolygon2D(Polygon2D p) {
      this(p.xpoints, p.ypoints, p.npoints);
   } // of constructor
  
   //-----------------------------------------------------------------

   /**
    * Create a polygon with the specified times.
    */
   public TimedPolygon2D(Polygon2D p, long[] t) {
      this(p.xpoints, p.ypoints, t, p.npoints);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Clone the specified polygon.
    */
   public TimedPolygon2D(TimedPolygon2D p) {
      this(p.xpoints, p.ypoints, p.times, p.npoints);
   } // of constructor
  
   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Get the start time of this polygon.
    *
    * @return the start time of this polygon. This value is junk unless there
    *         is at least one point in the polygon.
    */
   public long getStartTime() {
      return(times[0]);
   } // of getStartTime

   //-----------------------------------------------------------------

   /**
    * Get the end time of this polygon.
    *
    * @return the end time of this polygon. This value is junk unless there
    *         is at least one point in the polygon.
    */
   public long getEndTime() {
      return(times[npoints - 1]);
   } // of getEndTime

   //-----------------------------------------------------------------

   /**
    * Fixes a bug in Polygon.
    */
   public Rectangle getBounds() {
      if (npoints > 0) {
         return (super.getBounds());
      }
      else {
         return (new Rectangle());
      }
   } // of getBounds

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   public void setToShape(TimedPolygon2D poly) {
      super.setToShape(poly);
      times = new long[poly.npoints];
      System.arraycopy(poly.times, 0, times, 0, npoints);        
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a point, with the time determined by the system clock.
    *
    * @param x is the x-coordinate of the point to add.
    * @param y is the y-coordinate of the point to add.
    */
   public void addPoint(double x, double y) {
      addPoint(x, y, System.currentTimeMillis());
   } // of addPoint

   //-----------------------------------------------------------------

   /**
    * Add a point with the specified time.
    *
    * @param x is the x-coordinate of the point to add.
    * @param y is the y-coordinate of the point to add.
    * @param t is the time for this point.
    */
   public void addPoint(double x, double y, long t) {
      super.addPoint(x, y);

      //// 1. Resize the times array if we have to.
      if (times != null) {
         if (npoints >= times.length) {
            long[] temp = new long[times.length * 2];
            System.arraycopy(times, 0, temp, 0, times.length);
            times = temp;
         }
         times[npoints-1] = t;
      }
   } // of addPoint

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      StringBuffer strbuf = new StringBuffer();

      strbuf.append("[");
      for (int i = 0; i < npoints; i++) {
         strbuf.append("(" + xpoints[i] + "," + 
                             ypoints[i] + "," + 
                             times[i] + ")");
      }
      strbuf.append("]");

      return (strbuf.toString());
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      TimedPolygon2D ret = new TimedPolygon2D();
      clone(ret);
      return (ret);
   } // of clone

   //-----------------------------------------------------------------

   public Object clone(TimedPolygon2D p) {
      super.clone(p);
      p.times = new long[this.times.length];
      System.arraycopy(this.times, 0, p.times, 0, this.times.length);
      return (p);
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   MAIN   ==============================================================

   /**
    * This code demonstrates a bug with polygon
    */
/*
   public static void main(String[] argv) {
      Polygon2D t = new Polygon2D();
      System.out.println(t.getBounds());
      t.addPoint(196, 496);
      System.out.println(t.getBounds());
      t.addPoint(200, 500);
      System.out.println(t.getBounds());
      t.addPoint(190, 190);
      System.out.println(t.getBounds());
      System.out.println();

      Polygon2D t2 = new Polygon2D();
      t2.addPoint(196, 496);
      t2.addPoint(200, 500);
      t2.addPoint(190, 190);
      System.out.println(t2.getBounds());
      System.out.println();

      t = new TimedPolygon2D();
      System.out.println(t.getBounds());
      t.addPoint(196, 496);
      System.out.println(t.getBounds());
      t.addPoint(200, 500);
      System.out.println(t.getBounds());
      t.addPoint(190, 190);
      System.out.println(t.getBounds());
      System.out.println();

      t2 = new TimedPolygon2D();
      t2.addPoint(196, 496);
      t2.addPoint(200, 500);
      t2.addPoint(190, 190);
      System.out.println(t2.getBounds());
   } // of main
*/
   //===   MAIN   ==============================================================
   //===========================================================================

} // of class 

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
