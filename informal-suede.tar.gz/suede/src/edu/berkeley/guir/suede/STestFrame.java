 package edu.berkeley.guir.suede;/**/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.text.html.*;
import java.net.*;
import java.util.Vector;

// This is the window that testing occurs in
// It contains a menu bar, a transcript area, control buttons, and an html pane

public class STestFrame extends javax.swing.JFrame {
  
    private static final int    SCRIPT_HEIGHT = 65;
    private static final int    MENU_HEIGHT   = 20;
    private static final int    SPACING       = 50;
    private static final int    BORDER        = 2;
    private static final Color  MODE_BG       = Color.white;
    private static final Color  MODE_FG       = Color.black;
    private static final Color  MODE_ROLL     = Color.red;
    private static final int    STARTED       = 0;
    private static final int    STOPPED       = 1;
    private static final int    RECORDING     = 2;
    private static final int    PLAYING       = 3;
    private static final int    BARGING       = 4;
    private static final int    TIMEOUT       = 5;
    private static String TEST_TITLE    = "SUEDE Test - ";
    
    //HV Dec1803
    private static final int NOT_HEARD = 6;
    private static final int NOT_LEGAL = 7;
    
    private int             m_mode            = STOPPED; //this will always be STARTED or STOPPED
    private int             m_playmode        = STOPPED; //This will be either STOPPED, PLAYING, or RECORDING
    private TranscriptView  m_transcript;
    private String          m_currentcardname = "";
    private String          m_startcardname   = "";
    private String          m_startfilename   = "";
    private String          m_suede_filename  = "";
    private SMenuBar        m_menuBar         = new SMenuBar();  
    private SControlPanel   m_controlPanel    = new SControlPanel();
    private String          m_clickedurl      = "";
    private JEditorPane     m_pane            = null;
    private PlayCallback    m_playcallback    = new PlayCallback();
    private RecordCallback  m_reccallback     = new RecordCallback();
    //private CardSound       m_curUserAudio    = null;  // This variable is for recording the user's current audio input. When the wizard clicks on a link, this audio will be dumped into the link.
    private int             m_userID;
    private String          m_userName        = "User " + m_userID;
    private JEditorPane     editPane          = new JEditorPane();
    private TranscriptNodeModel m_curSystNode = null;  // this keeps around stuff we need to alternate playing and saving audio
    private TranscriptNodeModel m_curUserNode = null;
    private SuedeModel      m_model;   
    private Container       m_contentPane;
    private Frame	    m_testFrame;
    private Calibrator      m_calibrator; 
       
    //private boolean PAUSE = false;
    
    public STestFrame (String startfilename, String suede_filename, SuedeModel model, int startingID /*, boolean PAUSE*/) {
	//this.PAUSE = PAUSE;
        m_testFrame = this;
	m_userID = startingID;
        m_transcript = new TranscriptView( m_userID );
	m_calibrator = new Calibrator(m_testFrame);  //PAUSE ELIM CODE
	        
	//TEST_TITLE = TEST_TITLE +  suede_filename + ": "; //sets the title to include the name of that analysis
	m_suede_filename = suede_filename + ": ";
	updateUserName("User " + m_userID); //the default first user is "User 0"
        m_menuBar.setUserName(m_userName); //tell the menu bar about the user name we just set
        setSize(700, 700);
        setBackground(Color.white);
        
        m_model = model;
        
        m_contentPane = getContentPane();
        getContentPane().setBackground(new java.awt.Color(24,40,105));
        
	/* scrollPane = new STopScrollPane(m_transcript, 
                                        ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER,
                                        ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
 
        scrollPane.setBorder(BorderFactory.createMatteBorder(0, 0, 4, 0, Color.black));
        scrollPane.setBackground(new java.awt.Color(24,40,105));
        */
        editPane.setBorder(BorderFactory.createMatteBorder(0, 40, 40, 0, Color.white));
        editPane.setEditable(false); 
        editPane.addHyperlinkListener(new Hyperactive());
        
        JScrollPane htmlScrollPane = new JScrollPane(editPane, 
                                                     ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                                                     ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        editPane.setAutoscrolls(true);
        try {            
            //System.out.println("Checking out ... ");      
            startfilename = "file:///" + startfilename.replace('\\', '/');     
            m_startfilename = startfilename;
            editPane.setPage(new URL(startfilename));
            //System.out.println(startfilename);   
            m_currentcardname = parseStringToCardLabel(startfilename);
            m_startcardname   = m_currentcardname;
            //System.out.println("Looking up ... " + m_currentcardname);            
        } catch (Exception e) {
            //e.printStackTrace();
            System.out.println("Problem loading!");
        }
            
        getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        getContentPane().add(m_menuBar);
        //getContentPane().add(scrollPane);                
        getContentPane().add(m_transcript);
        getContentPane().add(m_controlPanel);
        //getContentPane().add(editPane);
        getContentPane().add(htmlScrollPane);

        showTheNextCard(); //places the first system card and response down
        
        addWindowListener (new java.awt.event.WindowAdapter () {
          public void windowClosing (java.awt.event.WindowEvent evt) {                          
              if (getPlayMode() == STOPPED) {
                  //hide();                 
              }
              
              if (getPlayMode() == RECORDING) {                
                System.out.println("remember to stop first!!!!");
                //m_curUserAudio.stopRecordingAudio(new closeCallback()); 
                m_curUserNode.stopRecordingAudio(); 
                //m_playmode = STOPPED;
              }
          } 
        }
         );
    }
    

    private void updateUserName(String userName) {
        m_userName = userName;
        setTitle(TEST_TITLE + m_suede_filename + m_userName);
    }
	
    
    public TranscriptView getScript() {
        //System.out.println("^^STestFrame: getScript");
        return m_transcript;   
    }
    
    public Calibrator getCalibrator() {
	return m_calibrator;
    } // PAUSE ELIM CODE
    
    public int getPlayMode() {
        if ( ! m_curSystNode.isStopped() ) {
            if ( ! m_curUserNode.isStopped() ) {
                // This shouldn't happen...both system and user nodes claim to be running
                // But for some reason we are in this state when playing...
                // So I don't know why it works, but it seems to.
                // CardSound states are messed up, there are three of them, which I don't understand.
                //System.out.println( "STestFrame.getPlayMode() is confused." );
                return PLAYING;
            } else {
                return PLAYING;
            }
        } else if ( ! m_curUserNode.isStopped() ) {
            return RECORDING;
        } 
        
        return STOPPED;
    }
 

    private class closeCallback implements CallbackIF {
        public void callback() {
            //System.out.println("^^STestFrame: closeCallback");
            hide();
        }
    }
    
    
    public void bargeIn() {      
        //System.out.println("^^STestFrame: bargeIn");
        if (getPlayMode() == PLAYING) {
	    // m_curSystNode.clickPlay(); 
	    m_curSystNode.setStopped();
	    m_curSystNode.isBarged = true; //PAUSE ELIM CODE
	}
    }
    
    
    public void timeOut() {
      //System.out.println("^^STestFrame: timeOut");
      if (getPlayMode() == RECORDING) {
        //m_curUserAudio.setCallback(new TimeoutCallback());;             
        m_curUserNode.setTimeOut();
        m_curUserNode.stopRecordingAudio();
        showTheNextCard();
      } else {
        //System.out.println("not recording: " + getPlayMode() + " " + m_currentcardname);
      }
    }
    
    

    public void didnotSay() {
      if (getPlayMode() == RECORDING) {
        m_curUserNode.setDidNotSay();
        m_curUserNode.stopRecordingAudio();
        //HV Dec1803
        URL u = Suede.class.getResource("audio/sorryididnthearyou.wav");
        String fn = u.getFile();
        //kill %20 that occur on some machines
        int n = fn.indexOf("%20");
        while(n > -1){
        	fn = fn.substring(0,n) + " " + fn.substring(n+3);
        	n = fn.indexOf("%20");
        }
        
		//showTheNextCardSubstituted(Suede.class.getResource("audio/sorryididnthearyou.wav").getFile());
		showTheNextCardSubstituted(NOT_HEARD, fn);
      } else {
        //System.out.println("not didnotsay: " + getPlayMode() + " " + m_currentcardname);
      }

    }

    public void saidWrong() {
      if (getPlayMode() == RECORDING) {
        m_curUserNode.setSaidWrong();
        m_curUserNode.stopRecordingAudio();
        
        //HV Dec1803
        URL u = Suede.class.getResource("audio/sorryyoucantsaythat.wav");
        String fn = u.getFile();
        //kill %20 that occur on some machines
        int n = fn.indexOf("%20");
        while(n > -1) {
        	fn = fn.substring(0,n) + " " + fn.substring(n+3);
        	n = fn.indexOf("%20");
        }    
		//showTheNextCardSubstituted(Suede.class.getResource("audio/sorryyoucantsaythat.wav").getFile());
		showTheNextCardSubstituted(NOT_LEGAL, fn);
      } else {
        //System.out.println("not saidwrong: " + getPlayMode() + " " + m_currentcardname);
      }

    }



    /*
     * adds the transcript to the design area
     */
    public void copyTranscriptToAnalysis() {
      //System.out.println("^^STestFrame: copyTranscriptToAnalysis");
      m_model.getScriptModel().addTranscript(m_transcript);
    }
    

    
    
    private void stopRecordingTheAudio() {            
        //System.out.println("^^STestFrame: stopRecordingtheaudio");
            // stop recording and unhook the last transcript card!!
            if (getPlayMode() != BARGING) {
              m_curUserNode.stopRecordingAudio();
              m_reccallback.callback();
              //m_curSystNode.setCallback(null);                                    
            }
            //after recording, we switch to play mode
            //m_playmode = PLAYING;
    }
    
    
    /*
     * pulls out the url from an href attributes string
     */
    public String parseURLString(String start) {
      //System.out.println("^^STestFrame: parse url string");
      if (start.indexOf('=') == -1) {
        //System.out.println("That's not a good random URL");
        return start;
      } else {
        return start.substring(start.indexOf('=')+1);
      }
   }
    
    /*
     * passes back the next string, might be randomized, might not!
     */
    public String randomError( HTMLDocument doc, String nextURLString ) {
      String result = nextURLString;
      int errval = m_menuBar.getErrorRate();  // percentage of error
      Vector urls = new Vector();
      HTMLDocument.Iterator urliterator;

      // error warning should always be clear
      
      if (Math.random() * 100 < errval) {        
        
        urliterator = doc.getIterator(HTML.Tag.A);
        while (urliterator.isValid()) {
          //System.out.println(urliterator.getAttributes().toString());
          if (nextURLString.indexOf(urliterator.getAttributes().toString()) == -1) {  // add to the array the element that is not the next one clicked
            urls.addElement(parseURLString(urliterator.getAttributes().toString()));          
          }
          urliterator.next();
        }
        
        if (urls.size() > 1) {  // want at least two to chose from.
          m_menuBar.setErrorWarning(true);
          // pull out a random one from the list
          String nextone = (String) urls.elementAt((int)(urls.size() * Math.random()));
          //System.out.println("next one: " + nextone);      
          result = nextURLString.substring(0, nextURLString.lastIndexOf('/')+1) + nextone;
        } else {
          result = nextURLString;
        }
        
      } else {
        result = nextURLString;
      }
      
      return result;
    }
    
    
    /*************************************************************************  
     *************************************************************************  
                              HyperlinkListener
     *************************************************************************
     *************************************************************************/
    private class Hyperactive implements HyperlinkListener {
 
         public void hyperlinkUpdate(HyperlinkEvent e) {
             if (m_mode == STARTED) {
    	          if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                   m_menuBar.setErrorWarning(false);   
 		             JEditorPane pane = (JEditorPane) e.getSource();
 		             if (e instanceof HTMLFrameHyperlinkEvent) {
 		              /*HTMLFrameHyperlinkEvent  evt = (HTMLFrameHyperlinkEvent)e;
 		              HTMLDocument doc = (HTMLDocument)pane.getDocument();
 		              doc.processHTMLFrameHyperlinkEvent(evt);*/
 		          } else {
 		              try {                              
                          //bargeIn(); //$REVIEW-should this be commented or not? does it help in testing?
                          m_clickedurl = randomError((HTMLDocument)pane.getDocument(), e.getURL().toString());                              
                          m_pane = pane;
                          //m_e = e;
                          stopRecordingTheAudio();
                          // we get a callback at the end of this!!                  
 		              } catch (Exception ex) {
                          System.out.println("problema******");
     			          //t.printStackTrace();
 		              }
 		          }
 	          }
                  
            }  // end if  m_mode
 	     } // end method update              

    } //end class Hyperactive
    
    
    // srk: this is my attempt at new code that uses transcript elements in the transcript area
    // does each invocation of this method should add one system prompt and one user response?
    private void showTheNextCard() {          
       m_curSystNode = new TranscriptNodeModel(/*m_model.nextSmallCardName()*/ m_currentcardname, 
                                               m_model.lookupSingleNodeModel(m_currentcardname), m_userID);            
	   showTheNextLink();
    }

    // a substituted filename must be available
   /* private void showTheNextCardSubstituted(String filename) {          
       m_curSystNode = new TranscriptNodeModel("system audio", filename, m_userID );
	   showTheNextLink();
    }*/

	//HV Dec1803
	private void showTheNextCardSubstituted(int situation, String filename) {
		if (situation == NOT_HEARD)          
		   m_curSystNode = new TranscriptNodeModel("not heard system audio", filename, m_userID );
		else if (situation == NOT_LEGAL)
			m_curSystNode = new TranscriptNodeModel("not legal system audio", filename, m_userID );
		showTheNextLink();
	}
	
    private void showTheNextLink() {
       m_transcript.addScriptNode(m_curSystNode);
       // show the next link so we know when we start recording
                                                // Give each user node a unique label so audio will load.
       m_curUserNode = new TranscriptNodeModel( ( "ct" + m_currentcardname ) + m_userID, m_userID );
       // srk: I still need to tell the scriptmodel 'bout the cardsound 
       m_transcript.addScriptNode(m_curUserNode);
       // start playing the current audio
       if ( m_mode == STARTED ) {
		    
            m_curSystNode.playAudio(m_playcallback);
		
            //$REVIEW: start recording the next response
	    if (Suede.enablePauseElim) {
		m_curUserNode.recordAudio(true, m_curSystNode.getDuration()/*, PAUSE*/); //PAUSE_ELIM
	    }
       }
    }
    
    private String parseStringToCardLabel(String s) {
      //System.out.println("^^STestFrame: parse string to card label");
      int lastslash = s.lastIndexOf("/");
      s = s.substring(lastslash+1);
      int firstnumber = s.indexOf("#");
      if (firstnumber != -1) {
        s = s.substring(firstnumber+1);      
      }
      
      int firstdash = s.indexOf("_");
      if (firstdash != -1) {  // happens at timeout when we use a parsed string already!
        s = s.substring(0, firstdash);      
      }
      
      return s;
    }
    
    
    private String parseSLinkStringToURL (String s) {
      //System.out.println("^^STestFrame: parse slink string to url");
      int lastslash = s.lastIndexOf("/");      
      int firstdash = s.indexOf("#");     
      // get rid of the bad stuff in the middle
      s = s.substring(0, lastslash+1) + s.substring(firstdash+1);      
      return s;
    }
    
    
    private String parseStringToSLinkLabel(String s) {
       //System.out.println("^^STestFrame: parse string to slink label");
       int lastslash = s.lastIndexOf("/");
       s = s.substring(lastslash+1);
       int firstdash = s.indexOf("#");
       s = s.substring(0, firstdash);      
       return s;
    }
    
    
    private class TimeoutCallback implements CallbackIF {      
       public void callback() {
          //System.out.println("Getting the TimeoutCallback ...");
          m_curUserNode.setTimeOut();
          showTheNextCard();
       }
    }

    
    
    /*
     * PlayCallback
     */
    private class PlayCallback implements CallbackIF {
          /*
           * From callbackIF
           */
          public void callback() {   
	      //System.out.println("PlayCallback..");
	      if (!Suede.enablePauseElim) {
		  m_curUserNode.recordAudio(true, m_curSystNode.getDuration()/*, PAUSE*/);
	      }
	      else {
		  // DO NOTHING. For pause elimination, recording is already in progress.
	      }
          }
    }    
    
    /*
     * RecordCallback
     */
   private class RecordCallback implements CallbackIF {
      /*
       * From callbackIF
       */
      public void callback() {
        // System.out.println("RecordCallback..");
            String s = m_clickedurl;
            //System.out.println("clicked on url: "+s);                              
            try {
               String nextcardname = parseStringToCardLabel(s);            
               if (s.indexOf('#') != -1) {
                  String link = parseStringToSLinkLabel(s);
                  //System.out.println("Looking up link ... " + link);    
                  m_model.updateTranscriptWithLink(link, m_userID, m_curUserNode);
                  m_pane.setPage(parseSLinkStringToURL(m_clickedurl));
                  m_curUserNode.setCaption((m_model.lookupLinkModel(link)).getCaption());
               } else {                                                                
                  s = parseStringToCardLabel(s);                              
                  //System.out.println("Looking up link ... " + m_currentcardname + " , " + s);    
                  m_model.updateTranscriptWithLink(m_currentcardname, s,
                                                   m_userID, m_curUserNode);                    
                  m_pane.setPage(m_clickedurl); 
               }
               m_currentcardname = nextcardname;                 
               
                showTheNextCard();  // this sets the mode to playing....
            } catch (Exception e) {
               System.out.println("problema en STestFrame.recordCallback");
               //e.printStackTrace();
            }
         }
   }

    
     private class SControlPanel extends javax.swing.JPanel {
        private int m_buttonHeight = 0;
        
        public SControlPanel() {
            //System.out.println("^^STestFrame: s control panel");
            setBackground(Color.white);
            setLayout(null);
            setVisible(true);  setOpaque(true);
            setBorder(BorderFactory.createMatteBorder(0, 0, 4, 0, Color.black));
    	    
            JButton bargeButton = new SControlButton("Barge in", 
                       new ImageIcon(Toolkit.getDefaultToolkit().createImage(Suede.class.getResource("images/barge.gif"))));

            JButton timeoutButton = new SControlButton("Time out",
                       new ImageIcon(Toolkit.getDefaultToolkit().createImage(Suede.class.getResource("images/timeout.gif"))));
	    JButton didnotsayButton = new SControlButton("Not heard", 
                       new ImageIcon(Toolkit.getDefaultToolkit().createImage(Suede.class.getResource("images/timeout.gif"))));
	    JButton saidwrongButton = new SControlButton("Not legal", 
                       new ImageIcon(Toolkit.getDefaultToolkit().createImage(Suede.class.getResource("images/barge.gif"))));

            timeoutButton.setSize(timeoutButton.getPreferredSize());
            bargeButton.setSize(bargeButton.getPreferredSize());
	    didnotsayButton.setSize(didnotsayButton.getPreferredSize());
	    saidwrongButton.setSize(saidwrongButton.getPreferredSize());

            bargeButton.setLocation(30,7);
            timeoutButton.setLocation(bargeButton.getX() + bargeButton.getWidth() + 15,7);
	    didnotsayButton.setLocation(timeoutButton.getX() + timeoutButton.getWidth() + 15, 7);
	    saidwrongButton.setLocation(didnotsayButton.getX() + didnotsayButton.getWidth() + 15, 7);


            bargeButton.addActionListener(new BargeActionListener());
            timeoutButton.addActionListener(new TimeoutActionListener());
            didnotsayButton.addActionListener(new DidnotsayActionListener());
	    saidwrongButton.addActionListener(new SaidwrongActionListener());

            add(bargeButton);
            add(timeoutButton);
	    add(didnotsayButton);
	    add(saidwrongButton);
            
            m_buttonHeight = timeoutButton.getHeight();
        }


        private class SControlButton extends JButton {
            public SControlButton(String str, ImageIcon icon) {
                super(str, icon);
                //System.out.println("^^STestFrame: s control button");
                setOpaque(false);
                setBorderPainted(false);
                setFocusPainted(false);
                
                setHorizontalAlignment(SwingConstants.CENTER);
                setVerticalAlignment(SwingConstants.CENTER);
                
                setHorizontalTextPosition(AbstractButton.CENTER);
                setVerticalTextPosition(SwingConstants.BOTTOM);
            }
        }
        
        
        private class TimeoutActionListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {              
            //System.out.println("^^STestFrame: time out");
               timeOut();
            }
        }


        private class BargeActionListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {               
               //System.out.println("^^STestFrame: barge in");
               bargeIn();
            }
        }

        private  class DidnotsayActionListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {               
                didnotSay();
            }
        }


        private  class SaidwrongActionListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {               
                saidWrong();
            }
        }



        public Dimension getMinimumSize() {
            return new Dimension(super.getMinimumSize().width,   m_buttonHeight + 10);  }
        
        public Dimension getPreferredSize() {
            return new Dimension(super.getPreferredSize().width, m_buttonHeight + 10);  }
        
        public Dimension getMaximumSize() {
            return new Dimension(super.getMaximumSize().width,   m_buttonHeight + 10);  }
            
    
    }
    
    
    // the menu bar is the horizontal black bar with controls and feedback at the top of the screen
    private class SMenuBar extends javax.swing.JPanel {
        private static final int SPACE = 16;
      
        private JPanel     bp = new JPanel(); // panel that conatins the d/t/a buttons
        private int        buttonRight; // the righthand end of the left set of buttons
        private JTextField errorField;
        private JTextField userField;
        private JLabel     errornotification;
        
        
        public SMenuBar () {
            setLayout(null);
            setBorder(BorderFactory.createMatteBorder(0, 0, BORDER, 0, Color.white));
            setVisible(true);  setOpaque(true);
            setBackground(Color.black);

            // the four wizard control buttons
            // Save and new user aren't really needed. Lets try with just start/stop.
            RolloverButton btnstart          = new RolloverButton("Begin Test",        Color.black, Color.white, Color.darkGray);
            RolloverButton btnstop           = new RolloverButton("End Test",        Color.black, Color.white, Color.darkGray);
			      
            
            // the wizard control for setting error rate
            JLabel errorlabel = new JLabel(" % Errors");  
            errorlabel.setForeground(Color.white);
            errorField = new JTextField("0"); 

            // the wizard control for setting user name
            JLabel userLabel  = new JLabel("User ID:");
            userLabel.setForeground(Color.white);
            //System.out.println("*******"+m_userName);
            userField = new JTextField(m_userName);             
            userField.addActionListener(new TextChangedListener());
            
            errornotification = new JLabel("RANDOM ERROR HAS OCCURRED!");  
            errornotification.setHorizontalAlignment(SwingConstants.CENTER);
            errornotification.setOpaque(true);
            errornotification.setVisible(true);
            errornotification.setBackground(Color.red);
            errornotification.setForeground(Color.white);
            
            ButtonGroup bg = new ButtonGroup();

            // this block of code iteratively lays out all of the components along the x-axis
            int x=0;
 
            x = btnstart.setXHeight(x,      MENU_HEIGHT);  add(btnstart);            
            x = btnstop.setXHeight(x,      MENU_HEIGHT);  add(btnstop);
		      
            
            x = setXHeight(errorlabel, x, MENU_HEIGHT);  add(errorlabel);
            x = setXHeight(errorField, x, MENU_HEIGHT);  add(errorField);
            x = setXHeight(userLabel,  x + 13, MENU_HEIGHT);  add(userLabel);
            x = setXHeight(userField,  x - 5, MENU_HEIGHT);  add(userField);
            x = setXHeight(errornotification, x + 10,  MENU_HEIGHT);  add(errornotification);
            errornotification.setVisible(false);
            
        
            btnstart.addActionListener(new btnstartActionListener());
            btnstop.addActionListener(new btnstopActionListener());
		    
        }      
        

        public Dimension getMinimumSize() {
            return new Dimension(super.getMinimumSize().width,   MENU_HEIGHT + BORDER);  }
        
        public Dimension getPreferredSize() {
            return new Dimension(super.getPreferredSize().width, MENU_HEIGHT + BORDER);  }
        
        public Dimension getMaximumSize() {
            return new Dimension(super.getMaximumSize().width,   MENU_HEIGHT + BORDER);  }
            
        public void setBounds(int x, int y, int w, int h) {
            super.setBounds(x,y,w,h);
            bp.setLocation((w - buttonRight)*2/3 + buttonRight - bp.getWidth()/2, 0);
        }
 
 
        // This method sets the bounds of the component to be       
        public int setXHeight(JComponent widget, int x, int h) {
          widget.setBounds(x,0,getIdealWidth(widget), h);
          return x+getIdealWidth(widget);
        }
                
        public int getIdealWidth(JComponent widget) { return widget.getPreferredSize().width + SPACE;   }
        
        public void setErrorWarning(boolean state) {
          errornotification.setVisible(state);
          repaint();          
        }        
        
        public int getErrorRate() {
          int result = 0;
          try {
            result = Integer.parseInt(errorField.getText());
            if (result < 0) {
                result = 0;
              } else if (result > 100) {
                result = 100;
              }
          } catch (Exception e) {
            System.out.println("invalid error parameter!");            
          }
          errorField.setText(""+result);
          return result;
        }
    
        
        // if the wizard changes the user id, the system gets the new one
        public String getUserName() {
          return userField.getText();
        }
    
    
        // the system sets the ID when the wizard starts a new user
        public void setUserName(String id) {
            userField.setText(id);
            userField.setSize(userField.getPreferredSize().width + 9, userField.getHeight());
        }


        // this class updates the system's record of the user id when the wizard changes it
        private class TextChangedListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                //System.out.println("user ID changed");
                updateUserName(getUserName());
                userField.setSize(userField.getPreferredSize().width + 9, userField.getHeight());
            }
        }
        
        
         
        
        private class btnstartActionListener implements ActionListener {
            public void actionPerformed (ActionEvent e) {
                m_mode = STARTED;
                m_curSystNode.playAudio(m_playcallback);

		if (Suede.enablePauseElim) {
		    m_curUserNode.recordAudio(true, m_curSystNode.getDuration()); //PAUSE ELIM CODE
		}
            }
        }
		
		
        // Stop now does the work of save and new user as well.
        private class btnstopActionListener implements ActionListener {
            public void actionPerformed (ActionEvent e) {
                // Stop the last node
                m_curUserNode.stopRecordingAudio();
                m_curSystNode.setCallback(null);                        
                m_mode = STOPPED;
                //m_playmode = STOPPED;
				
		//update user responses to analysis
		while ((m_model.scriptNodes).size() != 0) {
		    LinkModel lm = (LinkModel)m_model.sourceNodes.remove(0);
		    TranscriptNodeModel tm = (TranscriptNodeModel)m_model.scriptNodes.remove(0);
		    lm.addUserResponse(tm);
		}
                
                // Save transcript. (Have to remove first to avoid putting AWT components in two places at once.
                m_contentPane.remove( m_transcript );
                copyTranscriptToAnalysis();
                
                // Go to next user
                m_userID++;
                updateUserName("User " + m_userID);
                setUserName(m_userName);
                m_currentcardname = m_startcardname;
                try {
                    editPane.setPage(new URL(m_startfilename));
                }
                catch (Exception exp) {
                        System.out.println("can't set new start page!");
                        //exp.printStackTrace();
                }
  
                // Create new transcript and scroll pane and add them
                
                m_transcript = new TranscriptView( m_userID ); 
 
                m_contentPane.add( m_transcript, 1 );
                
                showTheNextCard();
                
                m_contentPane.validate(); 
                m_contentPane.repaint();
                
 
            }
        }
    
        

      
      private class STopScrollPane extends JScrollPane {
        public static final int HSB_HEIGHT = 15;
        
         public STopScrollPane (Component view, int vsbPolicy, int hsbPolicy) {
           super(view, vsbPolicy, hsbPolicy);
        }
        
          public Dimension getMaximumSize() {
            return new Dimension (super.getMaximumSize().width, HSB_HEIGHT);
          }
      }
    }
}
