package edu.berkeley.guir.damask.view;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.datatransfer.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.JComponent;
import javax.swing.TransferHandler;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.command.AddDialogCommand;
import edu.berkeley.guir.damask.command.ModifyGraphMacroCommand;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.view.visual.component.*;
import edu.berkeley.guir.damask.view.visual.dialog.PageView;
import edu.berkeley.guir.damask.view.voice.component.*;
import edu.berkeley.guir.damask.view.voice.dialog.Conversation;
import edu.berkeley.guir.damask.view.voice.dialog.Form;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.util.PPaintContext;

/** 
 * A Transferable which implements the capability required to transfer 
 * DamaskObjects to and from the clipboard. This Transferable properly
 * supports its own custom data flavor <code>DAMASK_OBJECTS_FLAVOR</code>,
 * {@link java.awt.datatransfer.DataFlavor#imageFlavor}, and
 * {@link java.awt.datatransfer.DataFlavor#stringFlavor}.
 * No other DataFlavors are supported.
 *  
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-19-2004 James Lin
 *                               Created DamaskObjectSelection.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-19-2004
 */
public class DamaskObjectSelection
   extends TransferHandler
   implements Transferable {

   private static final int PASTE_OFFSET = 20;

   private static final Logger logger =
      Logger.getLogger(DamaskObjectSelection.class.getName());
   
   // Stores clones of elements and the parents of the original elements
   private final Map/*<InteractionElement, Object>*/
      copiedObjectsToOrigParents =
      new LinkedHashMap/*<InteractionElement, Object>*/();

   // Stores a clone of the views of the original elements
   private PNode copiedObjectsPureCopy = null;
   
   // Stores the text of the original elements (if they consist of one label)
   private String copiedText = "";

   public static final DataFlavor DAMASK_OBJECTS_FLAVOR =
      new DataFlavor(
         DataFlavor.javaJVMLocalObjectMimeType + ";class=java.util.Map",
         "Collection of Damask objects");

   private static final DataFlavor flavors[] =
      {DAMASK_OBJECTS_FLAVOR, DataFlavor.imageFlavor, DataFlavor.stringFlavor};

   // Overrides method in TransferHandler.
   public int getSourceActions(final JComponent comp) {
      if (comp instanceof DamaskCanvas) {
         return TransferHandler.COPY_OR_MOVE;
      }
      else {
         return TransferHandler.NONE;
      }
   }

   // Overrides method in TransferHandler.
   public boolean canImport(
      final JComponent comp,
      final DataFlavor compFlavors[]) {

      if (comp instanceof DamaskCanvas) {
         for (int i = 0, n = compFlavors.length; i < n; i++) {
            if (isDataFlavorSupported(compFlavors[i])) {
               return true;
            }
         }
      }
      return false;
   }

   // Overrides method in TransferHandler.
   // This method is used in Cut and Copy.
   public Transferable createTransferable(final JComponent comp) {
      if (!(comp instanceof DamaskCanvas)) {
         return null;
      }

      copiedObjectsToOrigParents.clear();
         
      // Store the selected nodes in the canvas
      final DamaskCanvas canvas = (DamaskCanvas)comp;
      final Collection/*<PNode>*/ selectedObjects = canvas.getObjectsToCopy();
      
      final Map/*<Control, Control>*/ controlClones =
         new HashMap/*<Control, Control>*/();
      
      // Any voice controls that are selected need to be copied in the order
      // that they appear within their page region (so that voice controls are
      // copied in the proper order). So first, scan the controls
      // and store their page regions.
      final Set/*<PageRegion>*/ voiceControlRegions =
         new HashSet/*<PageRegion>*/();
      final Set/*<Control>*/ voiceControls = new HashSet/*<PageRegion>*/();
      
      
      for (Iterator i = selectedObjects.iterator(); i.hasNext(); ) {
         final Object selectedView = i.next();

         // Clone the objects that are currently selected. If a page is
         // selected, clone its dialog.
         if (selectedView instanceof PageView) {
            final Dialog selectedDialog =
               ((Page) ((PageView)selectedView).getModel()).getDialog();
            copiedObjectsToOrigParents.put(
               selectedDialog.clone(),
               selectedDialog.getInteractionGraph());
         }
         else if (selectedView instanceof Form) {
            final Form form = (Form)selectedView;
            final Dialog selectedDialog = (Dialog)form.getModel();
            copiedObjectsToOrigParents.put(
               selectedDialog.clone(),
               selectedDialog.getInteractionGraph());
            
            // Copy connections originate from this form
//            for (Iterator j =
//                 selectedDialog.getPages(DeviceType.VOICE).iterator();
//                 j.hasNext(); ) {
//               final Page page = (Page)j.next();
//               for (Iterator k = page.getRegions().iterator(); k.hasNext(); ) {
//                  final PageRegion region = (PageRegion)k.next();
//                  for (Iterator m = region.getControls().iterator();
//                       m.hasNext(); ) {
//                     final Control control = (Control)m.next();
//                     for (Iterator n = control.getOutConnections().iterator();
//                          n.hasNext(); ) {
//                        final Connection connection = (Connection)n.next();
//                        if (connection.isVisibleToDeviceType(DeviceType.VOICE)){
//                           copiedObjectsToOrigParents.put(
//                              connection.clone(),
//                              connection.getInteractionGraph());
//                        }
//                     }
//                  }
//               }
//            }
         }
         else if ((selectedView instanceof ControlView) ||
                  (selectedView instanceof Prompt) ||
                  (selectedView instanceof Response.TextGroup)) {
            final Control selectedControl;
            if (selectedView instanceof ControlView) {
               selectedControl =
                  (Control) ((ControlView)selectedView).getModel();
            }
            else if (selectedView instanceof Prompt) {
               selectedControl =
                  (Control) ((Prompt)selectedView).getModel();
            }
            else {
               selectedControl =
                 (Control)
                    ((Response.TextGroup)selectedView).getResponse().getModel();
            }
            
            if (selectedControl.isVisibleToDeviceType(DeviceType.VOICE)) {
               voiceControls.add(selectedControl);
               voiceControlRegions.add(selectedControl.getPageRegion(DeviceType.VOICE));
            }
            else {
               final Control selectedControlClone =
                  (Control)selectedControl.clone();
               copiedObjectsToOrigParents.put(
                  selectedControlClone,
                  selectedControl.getPageRegion(canvas.getDeviceType()));
               controlClones.put(selectedControl, selectedControlClone);
            }
         }
      }
      
      // Now, copy the selected voice controls in the order they appear
      // within their page regions.
      for (Iterator i = voiceControlRegions.iterator(); i.hasNext(); ) {
         final PageRegion region = (PageRegion)i.next();
         for (Iterator j = region.getControls().iterator(); j.hasNext(); ) {
            final Control control = (Control)j.next();
            if (voiceControls.contains(control)) {
               final Control selectedControlClone =
                  (Control)control.clone();
               copiedObjectsToOrigParents.put(
                  selectedControlClone,
                  control.getPageRegion(canvas.getDeviceType()));
               controlClones.put(control, selectedControlClone);
            }
         }
      }
      
      // Clone the component groups, which needs to happen after cloning
      // controls
//      for (Iterator i = selectedObjects.iterator(); i.hasNext(); ) {
//         final Object selectedView = i.next();
//
//         if (selectedView instanceof Panel) {
//            final ComponentGroup selectedGroup =
//               (ComponentGroup) ((Panel)selectedView).getModel();
//            copiedObjectsToOrigParents.put(
//               selectedGroup.clone(controlClones),
//               (ComponentGroup) ((Panel)selectedView)
//                  .getPageRegionView()
//                  .getModel());
//         }
//      }

      
      // Create a node whose bounds will just be big enough to hold the
      // selected objects. This will be used to generate an image for
      // the clipboard.
      copiedObjectsPureCopy = new PNode();
      for (Iterator i = selectedObjects.iterator(); i.hasNext(); ) {
         final PNode node = (PNode)i.next();
         final PNode nodeCopy = DamaskAppUtils.getPureCopy(node);
         nodeCopy.setTransform(node.getLocalToGlobalTransform(null));
         copiedObjectsPureCopy.addChild(nodeCopy);
      }
      
      // If the selected objects consist of one label, then store its
      // text for the clipboard.
      if (selectedObjects.size() == 1) {
         final Object selectedObject = selectedObjects.iterator().next();
         if (selectedObject instanceof Label) {
            copiedText =
               ((Content)((Label)selectedObject).getModel()).getText();
         }
      }
      return this;
   }
   
   
   // Overrides method in TransferHandler.
   // This method is used in Paste.
   public boolean importData(final JComponent comp, final Transferable t) {
      boolean result = false;
      try {
         if (comp instanceof DamaskCanvas) {
            final DamaskCanvas canvas = (DamaskCanvas)comp;
            final DeviceType canvasDeviceType = canvas.getDeviceType();
            
            // If there isn't a selected page region, paste into the home page.
            final PageRegion targetRegion = canvas.getPasteTargetPageRegion();

            final DeviceType deviceTypeForNewElement =
               ((DamaskLayer)canvas.getLayer()).getDeviceTypeForNewElement();

            // If the transferable is a set of Damask objects, paste them
            if (t.isDataFlavorSupported(DAMASK_OBJECTS_FLAVOR)) {
               final MacroCommand cmd = new ModifyGraphMacroCommand();

               final DamaskObjectSelection clipboardData =
                  ((DamaskObjectSelection)t
                     .getTransferData(DAMASK_OBJECTS_FLAVOR));
               final Collection newObjects = clipboardData.getCopiedObjects();

               // If a panel is selected, we will paste the objects in the
               // upper left-hand corner of the panel. Otherwise, we will paste
               // in the upper left-hand corner of the page region.
               final Panel targetPanel =
                  DamaskAppUtils.findRootPanel(canvas.getSelectedObjects());
               final ComponentGroup targetGroup;
               if (targetPanel == null) {
                  targetGroup = null;
               }
               else {
                  targetGroup = (ComponentGroup)targetPanel.getModel();
               }
               
               // Keep track of controls whose bounds are not defined for
               // device type of the page region in which they will be pasted,
               // because they will all be pasted in the same location.
               // We will move them out of each other's way later.
               final List/*<Control>*/ controlsWithNoBounds =
                  new ArrayList/*<Control>*/();
               
               // Now, paste the objects.               
               for (Iterator i = newObjects.iterator(); i.hasNext(); ) {
                  final InteractionElement element =
                     (InteractionElement)i.next();
                  System.out.println(element);
                  
                  if (element instanceof Dialog) {
                     final Dialog newDialog =
                        new Dialog((Dialog)element, deviceTypeForNewElement);

                     final InteractionGraph parent =
                        (InteractionGraph)clipboardData.getParent(element);
                     
                     cmd.addCommand(new AddDialogCommand(parent, newDialog));
                  }
                  else if (element instanceof Control) {
                     final Control control = (Control) element;
                     final Control newControl =
                        (Control) control.createCopy(deviceTypeForNewElement);

                     if (newControl.getBounds(canvasDeviceType) == null) {
                        controlsWithNoBounds.add(newControl);
                     }
                     
                     DamaskUtils.addCommandsForAddingComponentToMacroCommand(
                        cmd,
                        newControl,
                        targetRegion,
                        targetGroup,
                        false,
                        false);
                     
                     // If the original element that was copied is still
                     // in the same place, offset the pasted element
                     // so it doesn't overlap
                     final Control origControl = 
                        (Control)control.getCloneSourceIfAlive();
                     if (origControl != null) {
                        if (origControl.getPageRegion(canvasDeviceType) ==
                           targetRegion) {

                           final Point2D origControlLocation =
                              origControl.getTransform(canvasDeviceType).
                                 transform(
                                    origControl.getLocation(canvasDeviceType),
                                    null);
                           
                           final AffineTransform newControlTransform =
                              newControl.getTransform(canvasDeviceType);

                           final Point2D newControlLocation =
                              newControlTransform.transform(
                                 newControl.getLocation(canvasDeviceType),
                                 null);
                           
                           if (origControlLocation.equals(newControlLocation)) {
                              newControlTransform
                                 .preConcatenate(AffineTransform
                                    .getTranslateInstance(PASTE_OFFSET,
                                                          PASTE_OFFSET));
                              newControl.setTransform(canvasDeviceType,
                                                      newControlTransform);
                           }
                        }
                     }
                  }
                  else {
                     System.out.println(
                        "Pasting " + element + " not supported");
                  }
               }
               if (!cmd.isEmpty()) {
                  canvas.getDocument().getCommandQueue().doCommand(canvas, cmd);
                  result = true;
                  
                  // Move the controls that are on top of each other out of
                  // the way
                  double newControlY = 0;
                  for (Iterator j = controlsWithNoBounds.iterator();
                       j.hasNext(); ) {
                     final Control controlWithNoBounds = (Control)j.next();
                     
                     // We know the transform is identity (since the control
                     // didn't have bounds), so just apply a translate
                     // transform.
                     controlWithNoBounds.setTransform(
                        canvasDeviceType,
                        AffineTransform.getTranslateInstance(0, newControlY));
                     newControlY +=
                        controlWithNoBounds.getBounds(canvasDeviceType).getHeight();
                  }
               }
            }
            
            // If the transferable is an image, create an instance of Content
            // to hold the image and paste it
            else if (t.isDataFlavorSupported(DataFlavor.imageFlavor)) {
               final BufferedImage newImage =
                  (BufferedImage)t.getTransferData(DataFlavor.imageFlavor);
               final Content newContent =
                  new Content(deviceTypeForNewElement, newImage);
               newContent.setBounds(
                  DeviceType.ALL,
                  new Rectangle2D.Double(0,
                     0, newImage.getWidth(), newImage.getHeight()));
               
               final MacroCommand cmd = new ModifyGraphMacroCommand();
               DamaskUtils.addCommandsForAddingComponentToMacroCommand(cmd,
                                                                 newContent,
                                                                 targetRegion);
               canvas.getDocument().getCommandQueue().doCommand(canvas, cmd);
               result = true;
            }
            
            // If the transferable is text, create an instance of Content
            // to hold the image and paste it
            else if (t.isDataFlavorSupported(DataFlavor.stringFlavor)) {
               final String newText =
                  (String)t.getTransferData(DataFlavor.stringFlavor);
               final Content newContent =
                  new Content(deviceTypeForNewElement, newText);
               
               final MacroCommand cmd = new ModifyGraphMacroCommand();
               DamaskUtils.addCommandsForAddingComponentToMacroCommand(cmd,
                                                                 newContent,
                                                                 targetRegion);
               canvas.getDocument().getCommandQueue().doCommand(canvas, cmd);
               result = true;
            }
            
            canvas.getSelectionEventHandler().unselectAll(canvas);
         }
      }
      catch (UnsupportedFlavorException ignored) {
         logger.info("Cannot paste");
         DamaskAppExceptionHandler.log(ignored);
      }
      catch (IOException ignored) {
         logger.info("Cannot paste");
         DamaskAppExceptionHandler.log(ignored);
      }
      return result;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the objects copied into the clipboard.
    */
   public Collection getCopiedObjects() {
      return copiedObjectsToOrigParents.keySet();
   }
   
   
   /**
    * Returns the parent of the specified element.
    */
   public Object getParent(final InteractionElement element) {
      return copiedObjectsToOrigParents.get(element);
   }

   //---------------------------------------------------------------------------

   // Overrides method in Transferable.
   // This method is used in Paste.
   public Object getTransferData(final DataFlavor flavor)
      throws UnsupportedFlavorException {

      if (DAMASK_OBJECTS_FLAVOR.match(flavor)) {
         return this;
      }
      else if (DataFlavor.imageFlavor.match(flavor)) {
         // Paint the selected objects into an image.
         
         if (copiedObjectsPureCopy == null) {
            return null;
         }
         
         // Create an image of the right size.
         final Rectangle2D imageBounds =
            copiedObjectsPureCopy.getFullBounds();
         final int imageWidth = (int)imageBounds.getWidth();
         final int imageHeight = (int)imageBounds.getHeight();
         final BufferedImage selectedViewsImage =
            new BufferedImage(
               imageWidth,
               imageHeight,
               BufferedImage.TYPE_INT_ARGB);
         
         // Give the image a white background.
         final Graphics2D g = selectedViewsImage.createGraphics();
         g.setColor(Color.WHITE);
         g.fillRect(0, 0, imageWidth, imageHeight);
         
         // Make sure the selected objects are painted in the upper left-hand
         // corner of the image.
         final AffineTransform origTransform =
            copiedObjectsPureCopy.getTransform();
         copiedObjectsPureCopy.setTransform(
            AffineTransform.getTranslateInstance(
               -imageBounds.getX(),
               -imageBounds.getY()));
         
         // Paint the selected objects into the image.      
         final PPaintContext paintContext = new PPaintContext(g);
         copiedObjectsPureCopy.fullPaint(paintContext);

         // Clean up.         
         copiedObjectsPureCopy.setTransform(origTransform);
         g.dispose();

         return selectedViewsImage;
      }
      else if (DataFlavor.stringFlavor.match(flavor)) {
         return copiedText;
      }
      else {
         throw new UnsupportedFlavorException(flavor);
      }
   }

   // Overrides method in Transferable.
   public DataFlavor[] getTransferDataFlavors() {
      return flavors;
   }

   // Overrides method in Transferable.
   public boolean isDataFlavorSupported(DataFlavor flavor) {
      for (int i = 0, n = flavors.length; i < n; i++) {
         if (flavors[i].match(flavor)) {
            return true;
         }
      }
      return false;
   }
}