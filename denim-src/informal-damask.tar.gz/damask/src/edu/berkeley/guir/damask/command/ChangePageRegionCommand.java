package edu.berkeley.guir.damask.command;

import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that changes the page region of a component.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-09-2003 James Lin
 *                               Created UpdateBoundsCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-09-2003
 */
public class ChangePageRegionCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final Component component;
   private DeviceType deviceType;
   private PageRegion oldRegion;
   private final PageRegion newRegion;
   private final Rectangle2D groupBounds;

   /**
    * Constructs the command.
    * 
    * @param element the element whose bounds is to be updated
    * @param newBounds the new bounds of the element
    */
   public ChangePageRegionCommand(
      final Component component,
      final PageRegion oldRegion,
      final PageRegion newRegion) {

      this.component = component;
      this.oldRegion = oldRegion;
      this.deviceType = null;
      this.newRegion = newRegion;
      
      if (component instanceof ComponentGroup) {
         groupBounds =
            ((ComponentGroup)component).getBoundsInPageRegion(oldRegion);
      }
      else {
         groupBounds = null;
      }
   }

   /**
    * Constructs the command.
    * 
    * @param element the element whose bounds is to be updated
    * @param newBounds the new bounds of the element
    */
   public ChangePageRegionCommand(
      final Control control,
      final DeviceType deviceType,
      final PageRegion newRegion) {

      this.component = control;
      this.deviceType = deviceType;
      this.oldRegion = null;
      this.newRegion = newRegion;
      
      groupBounds = null;
   }


   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Changing page region of " + component + ": "
         + oldRegion + "->" + newRegion;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      if (oldRegion == null) {
         oldRegion = ((Control)component).getPageRegion(deviceType);
      }
      
      if (oldRegion == newRegion) {
         return;
      }
      
      if (component instanceof ComponentGroup) {
         ((ComponentGroup)component).setBoundsInPageRegion(oldRegion, null);
         ((ComponentGroup)component).setBoundsInPageRegion(newRegion, groupBounds);
      }
      else {
         oldRegion.getPage().getDialog().changeControlPageRegion(
            (Control)component, newRegion);
      }
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      if (oldRegion == newRegion) {
         return;
      }
      
      if (component instanceof ComponentGroup) {
         ((ComponentGroup)component).setBoundsInPageRegion(newRegion, null);
         ((ComponentGroup)component).setBoundsInPageRegion(oldRegion, groupBounds);
      }
      else {
         oldRegion.getPage().getDialog().changeControlPageRegion(
            (Control)component, oldRegion);
      }
   }
}
