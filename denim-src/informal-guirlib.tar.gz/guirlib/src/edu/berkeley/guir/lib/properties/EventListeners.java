package edu.berkeley.guir.lib.properties;

import java.beans.*;
import java.util.*;
import edu.berkeley.guir.lib.collection.*;

/**
 * Generic class for handling JavaBeans PropertyChangeListeners and
 * VetoableChangeListeners. Intended to be used within a class that
 * sends out these kinds of events.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0-1.0.0, Jun 02 2000, JH
 *               Created class
 *             - GUIRLib-v1.5/1.0.0, Apr 09 2002, JIH
 *               Updated for JDK1.4 with assertions, general cleanup
 *               and removal of cruftiness.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>
 *          )
 * @since   JDK 1.3
 * @version GUIRLib-v1.5/1.0.0, Apr 09 2002 JIH
 */
class EventListeners 
   implements PropertyConstants {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   //// (String, property name) -> (WeakHashSet, set of PropertyChangeListeners)
   HashMap    mapPropertyChangeListeners  = new HashMap();
   LinkedList listPropertyChangeListeners = new LinkedList();

   //-----------------------------------------------------------------

   //// (String, property name) -> (WeakHashSet, set of VetoableChangeListeners)
   HashMap    mapVetoableChangeListeners  = new HashMap();
   LinkedList listVetoableChangeListeners = new LinkedList();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   INTERNAL PROPERTY LISTENER METHODS   ================================

   /**
    * Add a listener.
    */
   private void addListener(List list, EventListener l) {
      //// 1. Add to list.
      list.add(l);
   } // of method


   /**
    * Add a listener on a specific property.
    *
    * @param map is either mapPropertyChangeListeners or
    *            mapVetoableChangeListeners.
    * @param str is the property.
    * @param l   is the EventListener to add.
    */
   public void addListener(Map map, String str, EventListener l) {
      //// 0.1. Lazily instantiate the set if it does not exist.
      Set setListeners = (Set) map.get(str);

      if (setListeners == null) {
         setListeners = new WeakHashSet();
         map.put(str, setListeners);
      }

      //// 1. Add the listener to the set.
      setListeners.add(l);
   } // of method


   /**
    * Remove a listener on all bound properties.
    */
   public void removeListener(List list, Map map, EventListener l) {
      list.remove(l);

      //// 2. Remove from all known bound properties.
      Iterator it = map.keySet().iterator();
      String   key;
      Set      setListeners;

      while (it.hasNext()) {
         key          = (String) it.next();
         setListeners = (Set) map.get(key);
         setListeners.remove(l);
      }
   } // of method


   /**
    * Remove a listener on a bound property.
    */
   public void removeListener(Map map, String str, EventListener l) {
      //// 0.1. See if the set exists. If not exit out.
      Set setListeners = (Set) map.get(str);
      if (setListeners == null) {
         return;
      }

      //// 1. Remove the property.
      setListeners.remove(l);
   } // of method

   //===   INTERNAL PROPERTY LISTENER METHODS   ================================
   //===========================================================================




   //===========================================================================
   //===   PROPERTY LISTENER METHODS   =========================================

   /**
    * Add a listener on all bound properties.
    * Why Javasoft didn't call it addBoundPropertiesListener() is beyond me...
    */
   public void addPropertyChangeListener(PropertyChangeListener l) {
      listPropertyChangeListeners = new LinkedList();
      addListener(listPropertyChangeListeners, l);
   } // of method


   /**
    * Add a listener on a specific bound property.
    *
    * @param str is the property.
    */
   public void addPropertyChangeListener(String str, PropertyChangeListener l) {
      addListener(mapPropertyChangeListeners, str, l);
   } // of method


   /**
    * Remove a listener on all bound properties.
    */
   public void removePropertyChangeListener(PropertyChangeListener l) {
      removeListener(listPropertyChangeListeners,mapPropertyChangeListeners,l);
   } // of method


   /**
    * Remove a listener on a bound property.
    */
   public void 
   removePropertyChangeListener(String str, PropertyChangeListener l) {
      removeListener(mapPropertyChangeListeners, str, l);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a listener on a constrained property.
    * Why Javasoft didn't call it addConstrainedPropertiesListener() is 
    * beyond me...
    */
   public void 
   addVetoableChangeListener(VetoableChangeListener l) {
      addListener(listVetoableChangeListeners, l);
   } // of method

   /**
    * Add a listener on a constrained property.
    */
   public void 
   addVetoableChangeListener(String str, VetoableChangeListener l) {
      addListener(mapVetoableChangeListeners, str, l);
   } // of method

   /**
    * Remove a listener on a constrained property.
    */
   public void 
   removeVetoableChangeListener(VetoableChangeListener l) {
      removeListener(listVetoableChangeListeners,mapVetoableChangeListeners,l);
   } // of method

   /**
    * Remove a listener on a constrained property.
    */
   public void 
   removeVetoableChangeListener(String str, VetoableChangeListener l) {
      removeListener(mapVetoableChangeListeners, str, l);
   } // of method

   //===   PROPERTY LISTENER METHODS   =========================================
   //===========================================================================




   //===========================================================================
   //===   PROPERTY FIRE METHODS   =============================================

   public void firePropertyChange(PropertyChangeEvent evt) {
      Iterator               it;
      PropertyChangeListener lstnr;
      Set                    setListeners;

      //// 1. Iterate over specific listener.
      it = listPropertyChangeListeners.iterator();
      while (it.hasNext()) {
         lstnr = (PropertyChangeListener) it.next();
         lstnr.propertyChange(evt);
      }

      //// 2. Iterate over global listeners.
      setListeners = (Set)mapPropertyChangeListeners.get(evt.getPropertyName());
      if (setListeners != null) {
         it = setListeners.iterator();
         while (it.hasNext()) {
            lstnr = (PropertyChangeListener) it.next();
            lstnr.propertyChange(evt);
         }
      }
   } // of method

   public void 
   firePropertyChange(Object src, String str, boolean oldVal, boolean newVal) {
      firePropertyChange(src, str, new Boolean(oldVal), new Boolean(newVal));
   } // of method

   public void 
   firePropertyChange(Object src, String str, int oldVal, int newVal) {
      firePropertyChange(src, str, new Integer(oldVal), new Integer(newVal));
   } // of method

   public void 
   firePropertyChange(Object src, String str, Object oldVal, Object newVal) {
      firePropertyChange(new PropertyChangeEvent(src, str, oldVal, newVal));
   } // of method

   //-----------------------------------------------------------------

   public void fireVetoableChange(PropertyChangeEvent evt) 
      throws PropertyVetoException {

      Iterator               it;
      VetoableChangeListener lstnr;
      Set                    setListeners;

      //// 1. Iterate over specific listener.
      it = listVetoableChangeListeners.iterator();
      while (it.hasNext()) {
         lstnr = (VetoableChangeListener) it.next();
         lstnr.vetoableChange(evt);
      }

      //// 2. Iterate over global listeners.
      setListeners = (Set)mapVetoableChangeListeners.get(evt.getPropertyName());
      if (setListeners != null) {
         it = setListeners.iterator();
         while (it.hasNext()) {
            lstnr = (VetoableChangeListener) it.next();
            lstnr.vetoableChange(evt);
         }
      }
   } // of method


   public void fireVetoableChange(Object src, String str, 
                                  boolean oldVal, boolean newVal)
      throws PropertyVetoException {

      fireVetoableChange(src, str, new Boolean(oldVal), new Boolean(newVal));
   } // of method


   public void fireVetoableChange(Object src, String str, 
                                  int oldVal, int newVal) 
      throws PropertyVetoException {

      fireVetoableChange(src, str, new Integer(oldVal), new Integer(newVal));
   } // of method


   public void fireVetoableChange(Object src, String str, 
                                  Object oldVal, Object newVal) 
      throws PropertyVetoException {

      fireVetoableChange(new PropertyChangeEvent(src, str, oldVal, newVal));
   } // of method

   //===   PROPERTY FIRE METHODS   =============================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
