package edu.berkeley.guir.denim.toolbox;

import edu.berkeley.guir.denim.DenimConstants;
import edu.berkeley.guir.denim.DenimSketch;
import java.awt.*;


/**
 * A grouping pencil, which allows designers to group objects within a 
 * Denim sketch.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-16-2002 James Lin
 *                               Created AnnotationPen
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 08-16-2002
 */
public class GroupingPencil
   extends Tool
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //static final long serialVersionUID = -7987898834268005604L;

   //===   CONSTANTS   =========================================================
   //===========================================================================


    Color gestureColor = new Color(100,100,253);
    float gestureWidth = 3;
    Color oldColor = Color.black;
    float oldWidth = 1;
   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates a group pencil tool to be placed in the toolbox.
    */
   public GroupingPencil() {
      super("pen.gif",
            new Point(0, 15),
            new Point(5, 31),
            new Point(5, 31),
            "Grouping Pencil");
            this.setToolTipText("Groups objects within canvas");  
           
          }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================


   //===========================================================================
   //===   PEN METHODS   =======================================================

   public void firstAddedToContainer() {
      super.firstAddedToContainer();
      // Enable the sketches' group interpreter.
      //
      // This assumes that for the group interpreter, calling setEnabled()
      // will enable or disable group interpreters for each sketch.
      enabledInterpreters.add(DenimSketch.getPrototypeGroupInterpreter());
   }

   //-----------------------------------------------------------------

   /**
    * Grabs the tool and disables inking the sheet.
    */
   public void grab() {
      super.grab();
      getDenimUI().getSheet().setAddLeftButtonStrokes(false);
      oldColor = getDenimUI().getSheet().getIIFInterpreter().getInkColor();
      oldWidth = (float)getDenimUI().getSheet().getIIFInterpreter().getInkWidth();
      getDenimUI().getSheet().getIIFInterpreter().setInkColor(gestureColor);
      getDenimUI().getSheet().getIIFInterpreter().setInkWidth(gestureWidth);
   }
   
   public void drop(Container c, Point p) {
       getDenimUI().getSheet().getIIFInterpreter().setInkColor(oldColor);
       getDenimUI().getSheet().getIIFInterpreter().setInkWidth(oldWidth);
       super.drop(c, p);
   }

   //===   PEN METHODS   =======================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
