//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.watch.*;
import java.awt.geom.*;
import java.io.Serializable;
import java.util.*;

/**
 * A Graphical Object collection that implements the Watcher interface,
 * listening for changes to the Graphical Objects contained.
 *
 * <P>
 * A Graphical Object Collection simply contains a collection of Graphical
 * Objects. It does not modify the Graphical Objects in any way.
 * 
 * <P>
 * If you're familiar with Collections in Java, you're probably wondering why
 * this doesn't implement the collection interface correctly. Well,
 * unfortunately, Java has some naming conflicts with methods, like size().
 * If the naming conflicts ever get resolved, then we'll straighten out the
 * names here too.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Oct 09 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public interface GraphicalObjectCollection
   extends SatinConstants, Watcher, Cloneable, Serializable {

   //===========================================================================
   //===   COLLECTION METHODS   ================================================

   /**
    * Same as addToFront.
    *
    * @param  gob is the GraphicalObject to add.
    * @return a reference to the GraphicalObject added.
    */
   public GraphicalObject add(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Add a GraphicalObject to the front of the list.
    *
    * @param  gob is the Graphical Object to add.
    * @return a reference to the GraphicalObject added.
    */
   public GraphicalObject addToFront(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Add a GraphicalObject to the back of the list.
    *
    * @param  gob is the Graphical Object to add.
    * @return a reference to the GraphicalObject added.
    */
   public GraphicalObject addToBack(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Add a Graphical Object to the specified location.
    *
    * @param index is the location to add to (zero-based). It is up to the
    *        programmer to ensure that this is a valid value.
    * @param gob   is the Graphical Object to add.
    */
   public GraphicalObject add(int index, GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Clear out all Graphical Objects in this collection.
    */
   public void clear();

   //-----------------------------------------------------------------

   /**
    * See if this Graphical Object Collection contains the specified Graphical
    * Object. Please note that this is NOT the same as calling 
    * {@link GraphicalObject#shapeContains(GraphicalObject)}.
    *
    * @return true if it contains the specified Graphical Object, false
    *         otherwise.
    */
   public boolean contains(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Get the Graphical Object at the specified index.
    *
    * @param  index is the location to look at (zero-based). It is up to the
    *         programmer to ensure that this is a valid value.
    * @return the Graphical Object at the specified index.
    */
   public GraphicalObject get(int index);

   //-----------------------------------------------------------------

   /**
    * Get the first Graphical Object.
    *
    * @return null if nothing is there.
    */
   public GraphicalObject getFirst();

   //-----------------------------------------------------------------

   /**
    * Get the last Graphical Object.
    *
    * @return null if nothing is there.
    */
   public GraphicalObject getLast();

   //-----------------------------------------------------------------

   /**
    * Retrieve the GraphicalObject with the specified unique ID.
    *
    * @param  id is the unique ID of the GraphicalObject to retrieve.
    * @return the GraphicalObject with that ID, or null if it isn't here.
    */
   public GraphicalObject getID(long id);

   //-----------------------------------------------------------------

   /**
    * Get the union of the bounds of the GraphicalObjects contained in
    * this collection. 
    *
    * Asking for local bounds is useless.<BR>
    * Asking for relative bounds is useful only if all of the GraphicalObjects 
    * have the same parent.<BR>
    * Asking for absolute bounds will always work.
    *
    * @param  cdsys is the coordinate system to use.
    * @return Rectangle representing the union of bounds.
    */
   public Rectangle2D getCollectionBounds2D(int cdsys);

   //-----------------------------------------------------------------

   /**
    * Get the bounds, put them in the specified Rectangle.
    */
   public Rectangle2D getCollectionBounds2D(int cdsys, Rectangle2D rect);

   //-----------------------------------------------------------------

   /**
    * Find the index of the specified Graphical Object.
    *
    * @param  gob is the Graphical Object to look for.
    * @return the index of the Graphical Object in this collection (zero-based)
    *         or -1 if it is not here.
    */
   public int indexOf(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Is this collection empty?
    *
    * @return true if empty, false otherwise.
    */
   public boolean isEmpty();

   //-----------------------------------------------------------------

   /**
    * Get the number of elements contained in this collection.
    * <P>
    * I realize that this should have been called size(), but there already
    * exists a deprecated method in Component named size().
    *
    * @return the number of elements contained.
    */
   public int numElements();

   //-----------------------------------------------------------------

   /**
    * Remove a Graphical Object from this collection.
    *
    * @param gob is the Graphical Object ot remove.
    */
   public GraphicalObject remove(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Get an iterator that goes forward thru the collection.
    *
    * @return an Iterator.
    */
   public Iterator getForwardIterator();

   //-----------------------------------------------------------------

   /**
    * Get an iterator that goes backwards thru the collection.
    *
    * @return an Iterator.
    */
   public Iterator getReverseIterator();

   //-----------------------------------------------------------------

   /**
    * Sort the list given the specified comparator.
    * One useful one is the {@link LayerComparator}, which sorts by layers.
    */
   public void sort(Comparator c);

   //===   COLLECTION METHODS   ================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Clone shallowly, one level only.
    */
   public Object clone();

   //-----------------------------------------------------------------

   /**
    * Clone deeply, recursing if necessary.
    */
   public Object deepClone();

   //===   CLONE METHODS   =====================================================
   //===========================================================================

} // of class GraphicalObjectCollection

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
