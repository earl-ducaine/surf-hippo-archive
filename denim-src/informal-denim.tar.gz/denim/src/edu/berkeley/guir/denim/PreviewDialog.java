//// See bottom of source code for software license

package edu.berkeley.guir.denim;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import javax.swing.plaf.*;

/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Oct 23, 2003 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class PreviewDialog extends JDialog {

	static Dimension mPaperSize = null;
	
	DenimPrinter mPrinter;
	BufferedImage[] mImages;
	JTextField mPage;
	JScrollPane mScroll;
	
	/**
	 * A listener that swallows all mouse events.
	 */
	class EmptyListener extends MouseInputAdapter {
	}
	
	/**
	 * A component that swallows all mouse events.
	 */
	class EventSwallowerGlassPane extends JComponent {
		EventSwallowerGlassPane() {
			EmptyListener emptyListener = new EmptyListener();
			this.addMouseListener(emptyListener);
			this.addMouseMotionListener(emptyListener);
		}
	}

	/**
	 * a print page
	 */	
	public class PreviewPage extends JPanel {

		int imageIndex = -1;
		
		double mScale = 1;
				
		public PreviewPage(int index) {
			imageIndex = index;
			this.setBackground(Color.white);
			this.setBorder(BorderUIResource.getBlackLineBorderUIResource());
			this.setPreferredSize(mPaperSize);
			
			double sx = (double)mPaperSize.getWidth()/(double)mImages[imageIndex].getWidth();
			double sy = (double)mPaperSize.getHeight()/(double)mImages[imageIndex].getHeight();
			
			mScale = sx>sy? sy:sx;
		}
		
		public void paintComponent(Graphics xg) {
			super.paintComponent(xg);

			Graphics2D g2d = (Graphics2D)xg;
			g2d.setColor(Color.white);
			g2d.fillRect(0,0,this.getWidth(), this.getHeight());
			
		   g2d.drawImage(mImages[imageIndex], 0, 0, 
		   		(int)(mImages[imageIndex].getWidth()*mScale), 
				(int)(mImages[imageIndex].getHeight()*mScale), 0, 0, 
				mImages[imageIndex].getWidth(), 
				mImages[imageIndex].getHeight(), this); 
		}

	}

	public PreviewDialog(DenimPrinter printer) {//, BufferedImage[] image) {
		super(printer,"Print Preview", true);
		
		mImages = printer.getPrintBuffer();
		this.setGlassPane(new EventSwallowerGlassPane());
		
		mPaperSize = printer.getRenderableSize();
		
		mPrinter = printer;
		//mImages = image;
		
		this.setBounds(0,0, (int)mPaperSize.getWidth()+36, (int)mPaperSize.getHeight()+60);
		int x = (int)((this.getToolkit().getScreenSize().getWidth()-this.getBounds().getWidth())/2);
		int y = (int)((this.getToolkit().getScreenSize().getHeight()-this.getBounds().getHeight())/2);
		this.setBounds(x,y, (int)mPaperSize.getWidth()+36, (int)mPaperSize.getHeight()+60);
		
		this.setResizable(false);

		JPanel container = new JPanel();
		BoxLayout layout = new BoxLayout(container, BoxLayout.Y_AXIS);
		container.setLayout(layout);
		mScroll = new JScrollPane(container);
		
		for(int i=0; i<mImages.length; i++)
		{
			container.add(new PreviewPage(i));
		}
		
		container.revalidate();

		this.getContentPane().add(mScroll, BorderLayout.CENTER);
		
		JPanel buttons = new JPanel();
		this.getContentPane().add(buttons, BorderLayout.NORTH);

		JButton print = new JButton("Print...");
		buttons.add(print);
		
		print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				PreviewDialog.this.setVisible(false);
				mPrinter.setVisible(false);
				//mPrinter.printFromOutSide();
				mPrinter.shouldPrint = true;
			}
		});

		JButton ok = new JButton("Close");
		buttons.add(ok);
		
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				PreviewDialog.this.setVisible(false);
			}
		});
		
	
		buttons.add(new JLabel("   Page "));
		mPage = new JTextField("1");
		mPage.setPreferredSize(new Dimension(30,23));
		buttons.add(mPage);
		mPage.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent evt) {
				try
				{
					int index = Integer.parseInt(mPage.getText());
					int value = (int)((index-1)*(double)mScroll.getVerticalScrollBar().getMaximum()/(double)mImages.length);
					mScroll.getVerticalScrollBar().setValue(value);
				}
				catch(Exception ex)
				{
					
				}
			}
		});

		
		buttons.add(new JLabel("/"+ mImages.length));
		
		mScroll.getVerticalScrollBar().addAdjustmentListener(new AdjustmentListener() {
			public void adjustmentValueChanged(AdjustmentEvent e) {
				int index = (int)(e.getAdjustable().getValue()*
						(double)mImages.length/(double)e.getAdjustable().getMaximum())+1;
				mPage.setText(Integer.toString(index));						 
			}
		});
	}
	
	public void setPrinterDialogEnabled(boolean flag) {
		if(flag)
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		else
			setCursor(new Cursor(Cursor.WAIT_CURSOR));
		getGlassPane().setVisible(!flag);
	}
}


//==============================================================================

/*
Copyright (c) 2003 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User 
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/