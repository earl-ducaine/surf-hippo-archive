//// See bottom of file for software license
package edu.berkeley.guir.lib.util;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * A pool of Pollable objects.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Aug 11 2002
 */
public class PollingPool {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    public static final int DEFAULT_SLEEPTIME = 500;

    //----------------------------------------------------------------

    private static final boolean DEBUG = false;

    //===   CONSTANTS   ========================================================
    //==========================================================================






    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    Set    setPollable   = new HashSet();      // set of Pollables we monitor

    //----------------------------------------------------------------

    Thread     t;                                  // our internal thread
    int        sleepTime     = DEFAULT_SLEEPTIME;  // sleep for set time...
    Random     rand          = new Random();       // ...plus a random time
    ThreadPool tpool         = null;

    //----------------------------------------------------------------

    List listPollableTmp = new LinkedList();   // dummy iterator collection

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================






    //==========================================================================
    //===   DEBUG   ============================================================

    private static final void println(String str) {
        if (DEBUG == true) {
            System.out.println(str);
        }
    } // of method

    //===   DEBUG   ============================================================
    //==========================================================================






    //==========================================================================
    //===   INNER CLASSES   ====================================================

    /**
     * Single job that polls everything. Only one instance of this.
     */
    class PollJob implements Runnable {
        public void run() {
            //// 1. Poll forever. Wait arbitrary and random 
            ////    amount of time before next poll.
            while (true) {
                try {
                    println("polling...");
                    poll();
                    Thread.yield();
                    println("sleeping...");
                    Thread.sleep(sleepTime + Math.abs(rand.nextInt())%1000 );
                }
                catch (Exception e) {
                    e.printStackTrace(System.err);
                }
            }
        } // of method
    } // of inner class

    //==========================================================================

    /**
     * Do the callback on a Pollable object, in case their onReady() method 
     * is expected to block or take a long time.
     */
    class ReadyCallbackJob implements Runnable {
        Pollable p;

        public ReadyCallbackJob(Pollable newP) {
            assert newP != null;
            p = newP;
        } // of method

        public void run() {
            p.onReady();
        } // of method
    } // of inner class

    //===   INNER CLASSES   ====================================================
    //==========================================================================






    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    public PollingPool() {
        t = new Thread(new PollJob());
        t.start();
    } // of constructor

    //----------------------------------------------------------------

    public PollingPool(ThreadPool newTpool) {
        setThreadPool(newTpool);
        t = new Thread(new PollJob());
        t.start();
    } // of constructor

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================






    //==========================================================================
    //===   ACCESSOR / MODIFIER METHODS   ======================================

    public void setSleepTime(int newSleepTime) {
        assert newSleepTime > 0;
        sleepTime = newSleepTime;
    } // of method

    //----------------------------------------------------------------

    public void setThreadPool(ThreadPool newTpool) {
        assert newTpool != null;
        tpool = newTpool;
    } // of method

    //===   ACCESSOR / MODIFIER METHODS   ======================================
    //==========================================================================






    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    public void add(Pollable p) {
        setPollable.add(p);
    } // of method

    //----------------------------------------------------------------

    public void remove(Pollable p) {
        setPollable.remove(p);
    } // of method

    //----------------------------------------------------------------

    public void clear() {
        setPollable.clear();
    } // of method

    //----------------------------------------------------------------

    public Iterator iterator() {
        return (setPollable.iterator());
    } // of method

    //----------------------------------------------------------------

    public Set getPollables() {
        return (new HashSet(setPollable));
    } // of method

    //----------------------------------------------------------------

    private void fireEvent(Pollable p) {
        //// 1.1. Do the callback on our own thread.
        if (tpool == null) {
            p.onReady();
        }
        //// 1.2. Do the callback on a separate thread.
        else {
            tpool.run( new ReadyCallbackJob(p) );
        }
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================






    //==========================================================================
    //===   IO METHODS   =======================================================

    private synchronized void poll() {
        //// 1. Use a temp to avoid potential ConcurrentModification errors
        listPollableTmp.clear();
        listPollableTmp.addAll(setPollable);

        //// 2. 
        Iterator it = listPollableTmp.iterator();
        Pollable p;

        while (it.hasNext()) {
            p = (Pollable) it.next();
            try {
                if (p.isReady() == true) {
                    fireEvent(p);
                }
            }
            catch (Exception e) {
                e.printStackTrace(System.err);
            }
        }
    } // of method

    //===   IO METHODS   =======================================================
    //==========================================================================






    //==========================================================================
    //===   REGRESSION TESTS   =================================================
/*
    static class PrintJob implements Pollable {
        int val;

        public PrintJob(int newVal) {
            val = newVal;
        } // of method

        public boolean isReady() {
            return (true);
        } // of method

        public void onReady() {
            try {
                Thread.sleep(1000);
            }
            catch (Exception e) {
            }
            System.out.println("callback on " + val);
        } // of method
    } // of inner class

    //==========================================================================

    public static void main(String[] argv) throws Exception {
        PollingPool p = new PollingPool(new ThreadPool());

        Thread.sleep(1000);

        p.add(new PrintJob(0));
        Thread.sleep(1000);
        p.add(new PrintJob(1));
        p.add(new PrintJob(2));
        p.add(new PrintJob(3));
        Thread.sleep(2000);
        p.add(new PrintJob(4));
        p.add(new PrintJob(5));
        p.add(new PrintJob(6));
        p.add(new PrintJob(7));
        p.add(new PrintJob(8));
        p.add(new PrintJob(9));
    } // of main
*/
    //===   REGRESSION TESTS   =================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
