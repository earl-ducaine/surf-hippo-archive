//// See bottom of source code for software license
package edu.berkeley.guir.lib.awt.geom;

import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;

/**
 * Abstracts a PathIterator into a line iterator. Get lines instead of points.
 * Also uses the standard collection method names, like next() and hasNext(),
 * instead of the ones in PathIterator.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
public class ShapeLineIterator {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   PathIterator it;
   float[]      ptsArray = new float[6];
   double       lastX;
   double       lastY;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Construct a line iterator from the specified path iterator.
    * Warning: assumes that the path iterator iterates over straight lines.
    * It does not do any error checking.
    */
   public ShapeLineIterator(PathIterator it) {
      this.it = it;
      if (!it.isDone()) {
         it.currentSegment(ptsArray);
         it.next();
         lastX = ptsArray[0];
         lastY = ptsArray[1];
      }
   } // of constructor

   //===========================================================================

   /**
    * Construct a line iterator from the bounding points of the specified
    * shape. Assumes that the shape is constructed of straight lines.
    */
   public ShapeLineIterator(Shape s) {
      this(s, new AffineTransform());
   } // of constructor

   //===========================================================================

   /**
    * Construct a line iterator from the bounding points of the specified
    * shape, applying the transform to the bounding points.
    */
   public ShapeLineIterator(Shape s, AffineTransform tx) {
      this(s.getPathIterator(tx));
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ITERATOR METHODS   ==================================================

   public boolean isDone() {
      return (it.isDone());
   } // of isDone

   //===========================================================================

   public boolean hasNext() {
      return (!it.isDone());
   } // of hasNext

   //===========================================================================

   /**
    * Get the next line.
    *
    * @return the next line.
    */
   public Line2D next() {
      return (next(new Line2D.Double()));
   } // of next

   //===========================================================================

   /**
    * Get the next line, using the specified line as storage.
    *
    * @param  line is used to store the next line, previous data will 
    *              be overwritten.
    * @return a reference to the specified line.
    */
   public Line2D next(Line2D line) {
      if (it.isDone()) {
         throw new RuntimeException("You need to check if this ShapeLineIterator has more lines or not through hasNext()");
      }
      it.currentSegment(ptsArray);
      it.next();
      line.setLine(lastX, lastY, ptsArray[0], ptsArray[1]);
      lastX = ptsArray[0];
      lastY = ptsArray[1];
      return(line);
   } // of next

   //===   ITERATOR METHODS   ==================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
