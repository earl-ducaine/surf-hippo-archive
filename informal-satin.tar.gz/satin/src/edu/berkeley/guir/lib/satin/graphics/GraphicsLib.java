//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.graphics;

import java.awt.*;
import java.util.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.util.StringLib;

/**
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jul 22 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
final public class GraphicsLib 
   implements GraphicsConstants {

   //===========================================================================
   //===   CLASS VARIABLES   ===================================================


   //===   CLASS VARIABLES   ===================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * No instances allowed.
    */
   private GraphicsLib() {
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   GRAPHICS POSITION METHODS   =========================================

   /**
    * Shift an object to have new coordinates. For example, most objects are
    * drawn using the specified (x,y) coordinates as the top-left corner. Let's
    * say you want to use the specified (x,y) coordinates as the center. This
    * method does this transformation, returning an (x,y) coordinate that says
    * where you should draw.
    *
    * <P>
    * Suppose you have a Rectangle, and you want to draw it such that
    * it is centered at (0,0). Just call 
    * calculateNewPosition(rect, GraphicsLib.CENTER) to figure out where
    * the top-left corner of the Rectangle should be drawn. Pretty neat, eh?
    *
    * @param  shape is some shape to draw. 
    * @param  pos   specifies where to shift the drawing to (CENTER, 
    *               TOP_LEFT, etc).
    * @return a Point containing where to draw the object's top-left corner.
    */
   public static Point calculateNewPosition(Shape shape, int pos) {

      Point     pt;
      Rectangle rect = shape.getBounds();
      int       x    = rect.x;
      int       y    = rect.y;
      int       w    = rect.width;
      int       h    = rect.height;

      switch (pos) {
         case TOP_LEFT    : pt = new Point(x,       y);       break;
         case TOP         : pt = new Point(x - w/2, y);       break;
         case TOP_RIGHT   : pt = new Point(x - w,   y);       break;
         case LEFT        : pt = new Point(x,       y - h/2); break;
         case CENTER      : pt = new Point(x - w/2, y - h/2); break;
         case RIGHT       : pt = new Point(x - w,   y - h/2); break;
         case BOTTOM_LEFT : pt = new Point(x,       y - h);   break;
         case BOTTOM      : pt = new Point(x - w/2, y - h);   break;
         case BOTTOM_RIGHT: pt = new Point(x - w,   y - h);   break;
         default:
            throw new IllegalArgumentException("Unknown position value " + pos);
      }

      return (pt);

   }  // of calculateNewPosition

   //-----------------------------------------------------------------

   /**
    * Calculate how much a Shape should be translated along x- and y- such
    * that the specified position of the Shape will be at the specified (x,y)
    * coordinate.
    * <P>
    * For example, say you already have a circle, and want to draw this
    * circle with (0,0) as its center. Just call
    * calculateTranslation(circle, 0, 0, CENTER) to figure out how much
    * the shape should be translated. 
    *
    * @param  shape is the Shape to determine how much to move. Make sure
    *               that the coordinates of shape are in the same coordinate
    *               system as x and y below.
    * @param  x     is the x-coordinate to move it to.
    * @param  y     is the y-coordinate to move it to.
    * @param  pos   is the position that x and y represent (e.g. CENTER,
    *               TOP_LEFT, etc).
    * @return a Point containing the amount to translate along x and y.
    */
   public static Point 
   calculateTranslation(Shape shape, int x, int y, int pos) {
      Point     newLoc    = calculateNewPosition(shape, pos);
      Rectangle oldBounds = shape.getBounds();

      return (new Point(newLoc.x - oldBounds.x, newLoc.y - oldBounds.y));
   } // of calculateTranslation

   //===   GRAPHICS POSITION METHODS   =========================================
   //===========================================================================



   //===========================================================================
   //===   STRING GRAPHICS METHODS   ===========================================

   /**
    * Using the specified font, calculate the width (in pixels) of 
    * the specified String.
    *
    * @see    #calculateTotalWidth(java.lang.String, java.awt.FontMetrics)
    * @param  str  is the String whose max width in pixels we want.
    * @param  font is the font to use for this String.
    * @return the height (in pixels) of this String.
    */
   public static int calculateTotalWidth(String str, Font font) {
      Toolkit tk = Toolkit.getDefaultToolkit();
      FontMetrics fmetric = tk.getFontMetrics(font);
      return (calculateTotalWidth(str, fmetric));
   } // of calculateTotalWidth

   //-----------------------------------------------------------------

   /**
    * Using the specified font metric, calculate the max width of this String
    * in pixels, that is the longest width among each of the rows of
    * this String.
    *
    * @param  str     is the String whose max width in pixels we want.
    * @param  fmetric is the FontMetrics to use for calculation.
    * @return the width (in pixels) of the longest row of this String.
    */
   public static int calculateTotalWidth(String str, FontMetrics fmetric) {
      String          strTmp;
      StringTokenizer strtok;
      int             width    = 0;
      int             widthTmp = 0;

      strtok = new StringTokenizer(str);
      while (strtok.hasMoreTokens()) {
         strTmp   = strtok.nextToken();
         widthTmp = fmetric.stringWidth(strTmp);
         if (widthTmp > width) {
            width = widthTmp;
         }
      }
      return (width);
   } // of calculateTotalWidth

   //-----------------------------------------------------------------

   /**
    * Using the specified font, calculate the height (in pixels) of 
    * the specified String.
    *
    * @see    #calculateTotalHeight(java.lang.String, java.awt.FontMetrics)
    * @param  str  is the String whose max width in pixels we want.
    * @param  font is the font to use for this String.
    * @return the height (in pixels) of this String.
    */
   public static int calculateTotalHeight(String str, Font font) {
      Toolkit tk = Toolkit.getDefaultToolkit();
      FontMetrics fmetric = tk.getFontMetrics(font);
      return (calculateTotalHeight(str, fmetric));
   } // of calculateTotalWidth

   //-----------------------------------------------------------------

   /**
    * First, calculate how many rows there are. Then, using the current font
    * metric, calculate the total height of this String in pixels.
    *
    * @param  str     is the String whose max width in pixels we want.
    * @param  fmetric is the FontMetrics to use for calculation.
    * @return the height (in pixels) of this String.
    */
   public static int calculateTotalHeight(String str, FontMetrics fmetric) {
      return (fmetric.getHeight() * StringLib.getNumRows(str));
   } // of calculateTotalHeight

   //-----------------------------------------------------------------

   /**
    * Calculate the bounding box for this String. Uses the current font metrics
    * for this graphics object.
    *
    * @see    #calculateBoundingBox(String, FontMetrics, int, int, int)
    * @param  str is the String whose bounding box we want.
    * @param  f   is the Font to use.
    * @param  x   is the left side of the bounding box.
    * @param  y   is the top side of the bounding box (NOT bottom).
    * @param  pos specifies what (x,y) are relative to the bounding box
    *             (e.g. the CENTER, TOP_LEFT, etc).
    * @return the bounding box.
    */
   public static Rectangle 
   calculateBoundingBox(String str, Font f, int x, int y, int pos) {
      Toolkit tk = Toolkit.getDefaultToolkit();
      FontMetrics fmetric = tk.getFontMetrics(f);
      return (calculateBoundingBox(str, fmetric, x, y, pos));
   } // of calculateBoundingBox

   //-----------------------------------------------------------------

   /**
    * Calculate the bounding box for this String. Uses the current font metrics
    * for this graphics object. Since Strings do not inherently have 
    * coordinates, use the specified (x,y) position as the top-left.
    *
    * @param  str     is the String whose bounding box we want.
    * @param  fmetric is the FontMetric to use.
    * @param  x       is the left side of the bounding box.
    * @param  y       is the top side of the bounding box (NOT bottom).
    * @param  pos specifies what (x,y) are relative to the bounding box
    *             (e.g. the CENTER, TOP_LEFT, etc).
    * @return the bounding box.
    */
   public static Rectangle calculateBoundingBox(String str, 
         FontMetrics fmetric, int x, int y, int pos) {

      //// 1. Calculate the height and width.
      Rectangle   rect        = new Rectangle();
      int         totalWidth  = calculateTotalWidth(str, fmetric);
      int         totalHeight = calculateTotalHeight(str, fmetric);

      rect.x      = x;
      rect.y      = y;
      rect.width  = totalWidth;
      rect.height = totalHeight;

      //// 2. Okay, now shift the position.
      Point pt = GraphicsLib.calculateNewPosition(rect, pos);
      rect.x   = pt.x;
      rect.y   = pt.y;

      return (rect);
   } // of calculateBoundingBox

   //===   STRING GRAPHICS METHODS   ===========================================
   //===========================================================================



   //===========================================================================
   //===   COLOR METHODS   =====================================================

   /**
    * Set the transparency for drawing.
    *
    * @param aa is the transparency value, from 0 to 1, 0 being transparent and
    *           1 being solid.
    */
   public static final Color makeTransparent(Color c, float aa) {
      //// 1. Exception case.
      if (aa >= 1) {
         return (c);
      }

      return (makeTransparent(c, (int) (255*aa)));
   } // of makeTransparent

   //-----------------------------------------------------------------

   /**
    * Set the transparency for draw.
    *
    * @param aa is the transparency value (0-255). Sets to 0 if less than
    *           0, or to 255 if greater than 255.
    */
   public static final Color makeTransparent(Color c, int aa) {
      //// 1. Exception cases.
      if (aa > 255) {
         aa = 255;
      }
      else if (aa < 0) {
         aa = 0;
      }

      //// 2. Make the color transparent.
      int rgb = c.getRGB();
      rgb = (aa << 24) + rgb;

      //// 3. Create a new color.
      return (new Color(rgb, true));
   } // of makeTransparent

   //===   COLOR METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static void main(String[] argv) {

      System.out.println(GraphicsLib.makeTransparent(Color.red, 200).getAlpha());
      System.out.println(GraphicsLib.makeTransparent(Color.red, 200).getRed());
      System.out.println(GraphicsLib.makeTransparent(Color.red, 200).getGreen());
      System.out.println(GraphicsLib.makeTransparent(Color.red, 200).getBlue());


   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
