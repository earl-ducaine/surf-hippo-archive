//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tuple;

import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.LinkedList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/**
 * Standard parser for parsing Tuples from streams.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Nov 21 2002, JH
 */
public class TupleParserDefaultImpl 
    implements TupleParser {

    //==========================================================================
    //===   SAX DEFAULT HANDLER INNER CLASS   ==================================

    /**
     * Parses into a tree of Tuples.
     */
    private class TupleHandler
        extends DefaultHandler {

        Tuple rootTuple;
        Tuple currentTuple;
        List  listTuples = new LinkedList();  // stack of tuples


        /**
         * Push a Tuple on to the stack of Tuples.
         * Also set the root if this is the first Tuple we have seen.
         */
        public void push(Tuple t) {
            if (listTuples.size() <= 0) {
                rootTuple = t;
            }
            listTuples.add(t);
        } // of method


        /**
         * Pop a tuple from the stack.
         */
        public void pop() {
            listTuples.remove(listTuples.size() - 1);
        } // of method


        /**
         * Get the current Tuple.
         */
        public Tuple poke() {
            if (listTuples.size() <= 0) {
                return (null);
            }
            return ((Tuple) listTuples.get(listTuples.size() - 1));
        } // of method


        /**
         * Get the root Tuple.
         */
        public Tuple getRoot() {
            return (rootTuple);
        } // of method


        /**
         * Start of a new XML tag.
         */
        public void startElement(String uri, String localName, 
                                 String elementName, Attributes attr) 
            throws SAXException {

            //// 1. Just to keep the state right.
            super.startElement(uri, localName, elementName, attr);

            //// 2. Create a new tuple. Add the attributes too.
            currentTuple = createNewTuple(elementName);
            for (int i = 0; i < attr.getLength(); i++) {
                currentTuple.setAttribute(attr.getQName(i), attr.getValue(i));
            }

            //// 3. Add the tuple to the previous one.
            Tuple t = poke();
            if (t != null) {
                t.addTuple(currentTuple);
            }

            //// 4. Add the tuple to the stack.
            push(currentTuple);
        } // of method


        /**
         * End of an XML tag.
         */
        public void endElement(String uri, String localName, 
                               String elementName)
            throws SAXException {

            //// 1. Just to keep the state right.
            super.endElement(uri, localName, elementName);

            //// 2. Pop the stack of tuples.
            pop();
        } // of method

    } // of class

    //===   SAX DEFAULT HANDLER INNER CLASS   ==================================
    //==========================================================================





    //==========================================================================
    //===   FACTORY METHODS   ==================================================

    /**
     * Factory method. Override this to return a specific type of Tuple.
     */
    protected Tuple createNewTuple() {
        return (new Tuple());
    } // of method


    /**
     * Factory method. Override this to return a specific type of Tuple.
     */
    protected Tuple createNewTuple(String strElementName) {
        return (new Tuple(strElementName));
    } // of method

    //===   FACTORY METHODS   ==================================================
    //==========================================================================





    //==========================================================================
    //===   SAX DEFAULT HANDLER INNER CLASS   ==================================

    /**
     * Parse an XML String into a Tuple.
     */
    public Tuple parse(String str) 
        throws TupleParserException {

        return ( parse(new InputSource(new StringReader(str))) );
    } // of method

    //----------------------------------------------------------------

    /**
     * Parse an InputStream into a Tuple.
     * Closes stream when done.
     */
    public Tuple parse(InputStream istream)
        throws TupleParserException {

        Tuple t = parse(new InputSource(istream));
        try {
            istream.close();
        }
        catch (Exception e) {
            // ignore
        }
        return (t);
    } // of method

    //----------------------------------------------------------------

    /**
     * Parse a Reader into a Tuple.
     * Closes stream when done.
     */
    public Tuple parse(Reader rdr)
        throws TupleParserException {

        Tuple t = parse(new InputSource(rdr));
        try {
            rdr.close();
        }
        catch (Exception e) {
            // ignore
        }
        return (t);
    } // of method

    //----------------------------------------------------------------

    /**
     * Parse an InputSource into a Tuple.
     */
    public Tuple parse(InputSource isrc) 
        throws TupleParserException {

        SAXParserFactory factory  = null;
        SAXParser        parser;
        TupleHandler     handler;

        //// 1. Try parsing.
        try {
            factory = SAXParserFactory.newInstance();
            parser  = factory.newSAXParser();
            handler = new TupleHandler();
            parser.parse(isrc, handler);
        }
        catch (Exception e) {
            //// You are seriously screwed here...
            // e.printStackTrace();
            throw new TupleParserException(e);
        }

        //// 2. Return.
        return (handler.getRoot());
    } // of method

    //===   PARSING   ==========================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
