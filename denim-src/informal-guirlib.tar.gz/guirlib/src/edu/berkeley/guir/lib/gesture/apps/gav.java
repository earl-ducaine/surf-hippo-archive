package edu.berkeley.guir.lib.gesture.apps;

/*
 * computes variance of change in gesture angle
 */

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.Misc;
import java.io.File;
import java.io.PrintStream;
import java.awt.Polygon;
import java.util.Iterator;

public class gav {
  public final int SIGFIGS = 10;
  
  class angleVariance extends Feature {
    public final double minValue = 0;
    public final double maxValue = Double.POSITIVE_INFINITY;

    public angleVariance(Gesture g)
    {
      super(g);
    }
    
    public String getName()
    {
      return "angle variance";
    }
    
    public double getMinValue()
    {
      return minValue;
    }
    
    public double getMaxValue()
    {
      return maxValue;
    }

    protected void computeValue()
    {
      double totalAngle = 0;
      Polygon points = gesture.getPoints();
      double[] angles = new double[points.npoints];
      
      for (int i = 2; i < points.npoints; i++) {
	double dx = points.xpoints[i] - points.xpoints[i-1];
	double dy = points.ypoints[i] - points.ypoints[i-1];
	double dx2 = points.xpoints[i-1] - points.xpoints[i-2];
	double dy2 = points.ypoints[i-1] - points.ypoints[i-2];
	angles[i] = Math.atan2(dx*dy2 - dx2*dy, dx*dx2 + dy*dy2);
	totalAngle += angles[i];
      }
      double meanAngle = totalAngle / points.npoints;
      double ssqr = 0;
      for (int i = 2; i < points.npoints; i++) {
	double delta = angles[i] - meanAngle;
	ssqr += delta * delta;
      }
      ssqr = ssqr / (points.npoints-2);
      value = ssqr;
      valueOk = true;
    }

    public void scale(double factor)
    {
      // todo
    }
  }

  public static void main(String[] argv)
  {
    if (argv.length != 1) {
      System.err.println("gav: usage: java gav gesturesetfile");
      System.exit(-1);
    }

    GestureSetFrame frame =
      new GestureSetFrame("gav", false);
    /*
    // Guess that the current user is the author
    frame.setAuthor(System.getProperty("user.name"));
    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    };
    frame.addWindowListener(l);
    */

    frame.openFile(new File(argv[0]));

    GestureSet gs = frame.getGestureSetDisplay().getGestureSet();
    gav dummy = new gav();
    dummy.printVariances(System.out, gs);
    System.exit(0);
  }

  void printVariances(PrintStream out, GestureSet gs)
  {
    for (Iterator it = gs.getCategories().iterator(); it.hasNext();) {
      GestureCategory gc = (GestureCategory)it.next();
      Gesture g = gc.gestureAt(0);
      angleVariance av = new angleVariance(g);

      out.println(gc.getName() + "\t" + Misc.toString(av.getValue(), SIGFIGS));
    }
  }
}
