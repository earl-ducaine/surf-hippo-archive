package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.dialogs.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.objects.*;
import java.util.*;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

/**
 * Inserts or edits typed text in a Denim design.
 *
 * <PRE>
 * Revisions:  1.0.0  03-03-2000 Will Lee (maintained by James Lin)
 *                    Created class TextInterpreter.
 *             2.0.0  10-19-2000 JL
 *                    Renamed to TypedTextInterpreter.
 *             3.0.0  10-25-2001 JL
 *                    Separated this functionality from TypedTextInterpreter
 *                    so that it could be accessed by DenimPieMenu.
 *             4.0.0  01-15-2003 YL
 *                    Fixed the bug of empty label by trimming the leading
 *                    "return"
 *             4.1.0  02-04-2003 YL 
 *                    Fixed the refreshing bug of inserting text in a page by
 *                    pie menu
 *                    Supported current font, for label, the default font is
 *                    Title. For others, it will keep the last font selected.
 *             4.2.0  02-26-2003 JL
 *                    Added support for list-style widgets
 *                    Removed font handling code from TypedTextHandler and
 *                    consolidated it into TextInsertDialog
 *             4.2.1  08-03-2004 YL
 *                    Added feedback for text or scribbledText while editing
 *                    Changed the search alogrithm for the target object to make changing built-in component captions easier 
 * 
 *
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2.2
 * @version Version 4.2.0, 08-03-2004
 */
public class TypedTextHandler implements DenimConstants
{

	//===========================================================================
	//===   CONSTANTS   =========================================================

	//===   CONSTANTS   =========================================================
	//===========================================================================

	//===========================================================================
	//===   INSTANCE VARIABLES   ================================================

	private Point2D absPt;
	private GraphicalObject objectHit;
	private ActionType action;

	//public static int currentFont = 1;

	//===   INSTANCE VARIABLES   ================================================
	//===========================================================================

	//===========================================================================
	//===   NESTED CLASSES   ====================================================

	protected class UserInputResult
	{
		public JTextArea textArea;
		public String text;
		public boolean isOK;

		public UserInputResult(TextInsertDialog dlg)
		{

			this.textArea = dlg.getValidatedTextArea();
			this.text = dlg.getValidatedText();
			this.isOK = dlg.isOK();

		}
	}

	//=======================================================================

	public interface ActionType
	{
		public void run(Point2D pt, GraphicalObject gob);
	}

	//-----------------------------------------------------------------

	public class TextPanelCreator implements ActionType
	{
		public void run(Point2D pt, GraphicalObject gob)
		{
			GraphicalObjectGroup parent = (GraphicalObjectGroup) gob;
			UserInputResult result =
				getInputFromUser(
					pt,
					parent,
					null,
					"Insert Page",
					"Text for Page's Label:");
			JTextArea ta = result.textArea;

			//// 3.1.1. Create a new label and panel if the text isn't empty
			if (result.isOK && result.text != null)
			{
				Debug.println("Creating label on parent: ");
				Debug.println(
					"TypedTextInterpreter: parent = "
						+ DenimUtils.toShortString(parent));

				parent.disableDamage();

				//// 1. Create a Denim text
				TypedText denimText = new TypedText(ta);
				Rectangle2D textBounds =
					getTypedTextBoundsAtPoint(pt, denimText);
				Rectangle2D bounds;

				denimText.setBoundingPoints2D(COORD_ABS, textBounds);
				parent.add(denimText, GraphicalObjectGroup.KEEP_ABS_POS);

				//// 2. Create label
				DenimLabel label = new DenimLabel(denimText);
				bounds = label.getBounds2D(COORD_ABS);
				Debug.println("label bounds = " + bounds.toString());
				label.setBoundingPoints2D(COORD_ABS, textBounds);

				//// 3. Create sketch.
				double scaleFactor =
					GraphicalObjectLib.getScaleFactor(COORD_ABS, parent);
				DenimSketch sketch =
					new DenimSketch(
						new Rectangle2D
						.Double(
							bounds.getX(),
							bounds.getY() + bounds.getHeight(),
					//(int)(DEFAULT_SKETCH_WIDTH  * scaleFactor),
		//(int)(DEFAULT_SKETCH_HEIGHT * scaleFactor)));
	(int) (DenimSketch.getDefaultSketchWidth() * scaleFactor),
		(int) (DenimSketch.getDefaultSketchHeight() * scaleFactor)));

				//// 4. Create panel.
				DenimPanel panel = new DenimPanel(new Rectangle(0, 0, 1, 1));

				Debug.println(
					"Adding "
						+ DenimUtils.toShortString(panel)
						+ " to "
						+ DenimUtils.toShortString(parent));

				//// throw this into the command queue, so it can be undone
				MacroCommand cmd = new MacroCommand();
				cmd.addCommand(
					new InsertCommand(
						parent,
						panel,
						GraphicalObjectGroup.KEEP_ABS_POS));
				cmd.addCommand(
					new SetSheetModifiedCommand(
						(DenimSheet) parent.getSheet(),
						true));
				cmdqueue.doCommand(cmd);

				Debug.println(
					"Done. parent is " + panel.getParentGroup().getClass());
				Debug.println("Kids (" + parent.numElements() + "): ");
				for (int i = 0; i < parent.numElements(); i++)
				{
					Debug.println(
						"  " + i + ": " + DenimUtils.toShortString(parent));
				}

				panel.setLabel(label);
				panel.setSketch(sketch);

				// HACK: Fix view for sketch, now that it has been added to sheet
				label.initAfterAddLabelToSheet();
				sketch.initAfterAddSketchToSheet();

				parent.enableDamage();
				parent.damage(DAMAGE_NOW);
			}
			else
			{
				Debug.println("User hit cancel");
			}
		}
	}

	//-----------------------------------------------------------------

	public class TextCreator implements ActionType
	{
		public void run(Point2D pt, GraphicalObject gob)
		{
			DenimSketch sketch = (DenimSketch) gob;
			UserInputResult result =
				getInputFromUser(
					pt,
					sketch,
					null,
					"Insert Text",
					"Text to Insert:");
			JTextArea ta = result.textArea;
			if (result.isOK && result.text != null)
			{

				DenimSheet sheet = (DenimSheet) sketch.getSheet();

				//Debug.println("Creating phrase on parent: ");
				//Debug.println("parent = " + sketch.getClass() +
				//              ":" + sketch.getUniqueID());

				TypedText newTxt = new TypedText(ta);
				//Debug.println("before: " + DenimUtils.toMedString(newTxt));
				newTxt.applyTransform(
					DenimUtils.getScaleTransformAt(
						newTxt,
						sheet.getAbsScale(),
						sketch));
				//Debug.println("after: " + DenimUtils.toMedString(newTxt));
				Rectangle2D textAbsBds = getTypedTextBoundsAtPoint(pt, newTxt);

				//// throw this into the command queue, so it can be undone
				Command cmd =
					getCreateTypedTextCommand(
						newTxt,
						sketch,
						textAbsBds.getX(),
						textAbsBds.getY());
				cmdqueue.doCommand(cmd);
                
				//Debug.println("way after: " + DenimUtils.toMedString(newTxt));

				gob.damage(DAMAGE_LATER);
			}
		}
	}

	public class ListEditor implements ActionType
	{
		public void run(Point2D pt, GraphicalObject gob)
		{
			DenimListComponent list = (DenimListComponent) gob;
			TextArea area = getListFromUser(pt, list);
			if (area != null)
			{
				cmdqueue.doCommand(new EditListCommand(list, area));
			}
		}
	}

	//-----------------------------------------------------------------

	public class TextEditor implements ActionType
	{
		public void run(Point2D pt, GraphicalObject gob)
		{
			TypedText dts = (TypedText) gob;
			GraphicalObjectGroup parent = dts.getParentGroup();
			GraphicalObjectGroup grandparent = null;
			if (parent != null)
			{
				grandparent = parent.getParentGroup();
			}

			//// If we are modifying a list, then do something
			//// completely different.
			if (grandparent instanceof DenimListComponent)
			{
				DenimListComponent list = (DenimListComponent) grandparent;
				TextArea area = getListFromUser(pt, list);
				if (area != null)
				{
					cmdqueue.doCommand(new EditListCommand(list, area));
				}
				return;
			}

			UserInputResult result =
				getInputFromUser(
					pt,
					dts,
					dts.getTextArea(),
					"Edit Text",
					"Text to Edit:");
			JTextArea ta = result.textArea;

			// If the user didn't hit cancel...
			if (result.isOK)
			{

				TypedText newTxt = new TypedText(ta);

				// If the text is empty, delete the text
				if (result.text == null)
				{
					cmdqueue.doCommand(new DenimDeleteCommand(dts));
				}
				// Otherwise, change it
				else if (parent instanceof CaptionedGraphicalObject)
				{
					cmdqueue.doCommand(
						new ChangeCaptionCommand(
							(CaptionedGraphicalObject) parent,
							newTxt));
				}
				else if (grandparent instanceof CaptionedGraphicalObject)
				{
					cmdqueue.doCommand(
						new ChangeCaptionCommand(
							(CaptionedGraphicalObject) grandparent,
							newTxt));
				}
				else if (grandparent instanceof DenimComboBoxInstance)
				{
					//cmdqueue.doCommand
					//   (new ChangeCaptionCommand(
					//      (CaptionedGraphicalObject)parent.getParentGroup(), newTxt));
				}
				else if (parent instanceof DenimHyperlinkInstance)
				{
					Debug.println("parent is link");
					double sheetScale =
						((DenimSheet) parent.getSheet()).getAbsScale();
					newTxt.applyTransform(
						DenimUtils.getScaleTransformAt(
							newTxt,
							sheetScale,
							parent));
					cmdqueue.doCommand(
						new ChangeHyperlinkContentsCommand(
							(DenimHyperlinkInstance) parent,
							newTxt));
				}
				else
				{
					cmdqueue.doCommand(new EditTextCommand(dts, ta));
				}
			}
		}
	}

	//-----------------------------------------------------------------

	public class ScribbleConverter implements ActionType
	{
		public void run(Point2D pt, GraphicalObject gob)
		{
			ScribbledText scribble = (ScribbledText) gob;
			GraphicalObjectGroup parent = scribble.getParentGroup();
			GraphicalObjectGroup grandparent = null;
			if (parent != null)
			{
				grandparent = parent.getParentGroup();
			}

			//// If we are modifying a list, then do something
			//// completely different.
			if (grandparent instanceof DenimListComponent)
			{
				DenimListComponent list = (DenimListComponent) grandparent;
				TextArea area = getListFromUser(pt, list);
				if (area != null)
				{
					cmdqueue.doCommand(new EditListCommand(list, area));
				}
				return;
			}

			//// For everything else, edit the text.
			UserInputResult result =
				getInputFromUser(
					pt,
					scribble,
					null,
					"Convert to Text",
					"Text to Insert:");
			JTextArea jta = result.textArea;

			if (result.isOK && result.text != null)
			{
				TypedText newTxt = new TypedText(jta);

				//// 3.4.1. Convert the scribble into text if the text isn't empty
				if (parent instanceof CaptionedGraphicalObject)
				{
					cmdqueue.doCommand(
						new ChangeCaptionCommand(
							(CaptionedGraphicalObject) parent,
							newTxt));
					parent.getParentGroup().damage(DAMAGE_NOW);
				}
				else if (grandparent instanceof CaptionedGraphicalObject)
				{
					cmdqueue.doCommand(
						new ChangeCaptionCommand(
							(CaptionedGraphicalObject) grandparent,
							newTxt));
					parent.getParentGroup().damage(DAMAGE_NOW);
				}
				else if (parent instanceof DenimHyperlinkInstance)
				{
					double sheetScale =
						((DenimSheet) parent.getSheet()).getAbsScale();

					newTxt.applyTransform(
						DenimUtils.getScaleTransformAt(
							newTxt,
							sheetScale,
							parent));
					cmdqueue.doCommand(
						new ChangeHyperlinkContentsCommand(
							(DenimHyperlinkInstance) parent,
							newTxt));
					parent.damage(DAMAGE_NOW);
				}
				else if (parent instanceof DenimSketch)
				{
					DenimSketch sketch = (DenimSketch) parent;
					double sheetScale =
						((DenimSheet) parent.getSheet()).getAbsScale();

					Rectangle2D objAbsBds = scribble.getBounds2D(COORD_ABS);
					newTxt.applyTransform(
						DenimUtils.getScaleTransformAt(
							newTxt,
							sheetScale,
							sketch));
					MacroCommand cmd =
						getCreateTypedTextCommand(
							newTxt,
							sketch,
							objAbsBds.getX(),
							objAbsBds.getY());
					cmd.addCommand(new DenimDeleteCommand(scribble));
					cmdqueue.doCommand(cmd);

					parent.damage(DAMAGE_LATER);
				}
			}
		}
	}

	//===   NESTED CLASSES   ====================================================
	//===========================================================================

	//===========================================================================
	//===   CONSTRUCTOR   =======================================================

	/**
	 * Constructs a handler to handle editing or inserting text at the
	 * given absolute point.
	 */
	public TypedTextHandler(Point2D absPt, Sheet sheet)
	{
		this.absPt = absPt;
		objectHit = getDeepestGobAt(absPt, sheet);

		Debug.println("Hit: " + DenimUtils.toShortString(objectHit));

		//// 3. After we get the object Hit, we have to decide what we're
		////    going to do see if we hit the sheet:

		//// 3.1. If we hit the sheet, create a new panel
		if (objectHit == null)
		{
			action = new TextPanelCreator();
			objectHit = sheet;
		}
		//// 3.2. If we hit a sketch, create new typed text
		else if (objectHit instanceof DenimSketch)
		{
			action = new TextCreator();
		}
		//// 3.3. If we hit some text, edit it
		else if (objectHit instanceof TypedText)
		{
			action = new TextEditor();
		}
		//// 3.4. If we hit a scribble, convert it to text
		else if (objectHit instanceof ScribbledText)
		{
			action = new ScribbleConverter();
		}
		//// 3.5. Who knows what we hit, so walk up the scenegraph until
		////      we find either a sketch or a sheet.
		else
		{
			GraphicalObject gob = objectHit;
			while (gob != null)
			{
				if (gob instanceof Sheet)
				{
					action = new TextPanelCreator();
					objectHit = gob;
					break;
				}
				else if (gob instanceof DenimSketch)
				{
					action = new TextCreator();
					objectHit = gob;
					break;
				}
				else if (gob instanceof CaptionedGraphicalObject)
				{ // deep search for caption
					DenimText caption =
						((CaptionedGraphicalObject) gob).getCaption();
					if (caption instanceof TypedText)
					{
						action = new TextEditor();
					}
					else if (caption instanceof ScribbledText)
					{
						action = new ScribbleConverter();
					}
					objectHit = caption;
					break;
				}
				else if (gob instanceof DenimListComponent)
				{
					objectHit = gob;
					action = new ListEditor();
					break;
				}
				else
				{
					gob = gob.getParentGroup();
				}
			}
		}
	}

	//===   CONSTRUCTOR   =======================================================
	//===========================================================================

	//===========================================================================
	//===   HELPER METHODS   ====================================================

	/**
	 * Returns the closest graphical object hit by the point
	 *
	 * @param pt    the point in absolute coordinates that you want to
	 *              get the object from
	 * @param sheet the denim sheet that the hit is on
	 */
	private GraphicalObject getDeepestGobAt(Point2D pt, Sheet sheet)
	{
		GraphicalObject gobHit = null;
		GraphicalObjectCollection gobcol = new GraphicalObjectCollectionImpl();

		//// 1. Get all deep graphical objects near the point within 0 points.
		sheet.getGraphicalObjects(COORD_ABS, pt, ALL, DEEP, NEAR, 1, gobcol);

		//// 2. Get the object that _strictly_ contains the point.
		Iterator it = gobcol.getReverseIterator();//.getForwardIterator();
		GraphicalObject gob = null;
		float gobDist = Float.MAX_VALUE;
		float dist;

		while (it.hasNext())
		{
			gob = (GraphicalObject) it.next();
			Debug.println("inspecting " + DenimUtils.toShortString(gob));
			if (gob.isVisible())
			{
				if (gob instanceof DenimSketch
					&& !((DenimSketch) gob).isSketchVisible())
				{
					continue;
				}
				dist = gob.minDistance(COORD_ABS, pt);
				if (dist < gobDist)
				{
					gobDist = dist;
					gobHit = gob;
				}
			}
		}
		if (gobHit != null)
		{
			if (gobHit.getParentGroup() instanceof TypedText)
			{
				return gobHit.getParentGroup();
			}
			else if (gobHit instanceof DenimLabel)
			{
				return ((DenimLabel) gobHit).getPhrase();
			}
		}
		return gobHit;
	} // of method

	//-----------------------------------------------------------------

	private MacroCommand getCreateTypedTextCommand(
		TypedText txt,
		GraphicalObjectGroup parent,
		double absX,
		double absY)
	{

		Point2D relPt =
			GraphicalObjectLib.absoluteToLocal(
				parent,
				new Point2D.Double(absX, absY));

		MacroCommand cmd = new MacroCommand();
		cmd.addCommand(
			new InsertCommand(parent, txt, GraphicalObjectGroup.KEEP_REL_POS));
		cmd.addCommand(new SetLocationCommand(txt, relPt.getX(), relPt.getY()));
		cmd.addCommand(
			new SetSheetModifiedCommand((DenimSheet) parent.getSheet(), true));
		return cmd;
	}

	//-----------------------------------------------------------------

	/**
	 * Given a point and a piece of text, returns the absolute bounds that
	 * the text should be have.
	 */
	private Rectangle2D getTypedTextBoundsAtPoint(Point2D pt, TypedText text)
	{
		Rectangle2D textBounds = text.getBounds2D(COORD_ABS);
		Debug.println("orig textBounds = " + textBounds.toString());

		Rectangle2D rtnBound =
			new Rectangle2D.Double(
				pt.getX(),
				pt.getY() - textBounds.getHeight(),
				textBounds.getWidth(),
				textBounds.getHeight());
		Debug.println("new textBounds = " + rtnBound.toString());
		return rtnBound;
	}

	//-----------------------------------------------------------------

	/**
	 * Pops up a dialog box and returns a JTextArea that contains the user's
	 * inputted text.
	 */
	private UserInputResult getInputFromUser(
		Point2D pt,
		GraphicalObject obj,
		JTextArea ta,
		String dialogTitle,
		String dialogLabel)
	{
		DenimSheet sheet = (DenimSheet) obj.getSheet();
		Window parentWin = (Window) SwingUtilities.getRoot(sheet);

		// Note that we have to translate the point according
		// to the default window
		int x = (int) pt.getX() + parentWin.getX();
		int y = (int) pt.getY() + parentWin.getY();
		Debug.println("new coordinate for point = " + x + ", " + y);

		TextInsertDialog textDialog;

		if (!(obj instanceof DenimSketch))
		{
			textDialog =
				new TextInsertDialog(
					(Frame) parentWin,
					ta,
					x,
					y,
					dialogTitle,
					dialogLabel);
			// for title font
		}
		else
		{
			textDialog =
				new TextInsertDialog(
					(Frame) parentWin,
					ta,
					x,
					y,
					dialogTitle,
					dialogLabel);
		}

		textDialog.setVisible(true);

		return new UserInputResult(textDialog);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Pops up a dialog box and returns an array of strings that contains 
	 * the user's inputed text, or null if the user clicked Cancel.
	 */
	private TextArea getListFromUser(Point2D pt, DenimListComponent comboBox)
	{
		Sheet sheet = ((GraphicalObject) comboBox).getSheet();
		Window parentWin = (Window) SwingUtilities.getRoot(sheet);

		// Note that we have to translate the point according
		// to the default window
		int x = (int) pt.getX() + parentWin.getX();
		int y = (int) pt.getY() + parentWin.getY();

		//EditListDialog dlg;
        TextInsertDialog dlg;
		/*if (parentWin instanceof Frame)
		{
			dlg =
				new EditListDialog(
					(Frame) parentWin,
					comboBox.getItemsAsText(),
					x,
					y);
		}
		else
		{
			dlg = new EditListDialog(comboBox.getItemsAsText());
		}
*/
        if (parentWin instanceof Frame)
        {
            dlg = new TextInsertDialog((Frame) parentWin, comboBox.getItemsAsText(), x, y, 
                    comboBox.getColor(), comboBox.getFont(),  "Edit List", "Edit List");
        }
        else
        {
            dlg = new TextInsertDialog(null, comboBox.getItemsAsText(), x, y, 
                    comboBox.getColor(), comboBox.getFont(),  "Edit List", "Edit List");
        }
        
		dlg.setVisible(true);
        /*
		if (dlg.wasOKPressed())
		{
			return dlg.getValues();
		}
		else
		{
			return null;
		}*/
        
        if(dlg.isOK())
        {    
            TextArea a = new TextArea();
            a.setText(dlg.getTextArea().getText());
            a.setFont(dlg.getTextArea().getFont());
            return a;
        }
        else
        {    
            return null;
        }
        
	} // of method

	//===   HELPER METHODS   ====================================================
	//===========================================================================

	//===========================================================================
	//===   TEXT INSERT METHODS   ===============================================

	/**
	 * Returns the action that will either edit or insert the text.
	 */
	public ActionType getAction()
	{
		return action;
	}

    //-----------------------------------------------------------------
    
    private DenimComponentInstance getComponentParent(GraphicalObject gob) {
        if(gob instanceof DenimComponentInstance)
        {
            return (DenimComponentInstance)gob;
        }
        else if(gob.getParentGroup()!=null)
        {
            return getComponentParent(gob.getParentGroup());
        }
        else
        {
            return null;
        }
    }
    //-----------------------------------------------------------------
	/**
	 * Does the currently selected action.
	 */
	public void run()
	{
        PatchImpl focus = null;
        boolean oldDraw = false;
        Color oldBounds = null;
        
        if(objectHit!=null)
        {
            if(!(objectHit instanceof Sheet || 
                    objectHit instanceof DenimSketch))
            {
                focus = this.getComponentParent(objectHit);
                if(focus ==null && objectHit instanceof PatchImpl)
                {
                    focus = (PatchImpl)objectHit;
                }
                
                oldDraw = focus.shouldDrawPatch();
                oldBounds = focus.getStyleRef().getDrawColor();
                focus.disableDamage();
                focus.setDrawPatch(true);
                if(focus instanceof DenimComponentInstance)
                    focus.getStyleRef().setDrawStroke(new BasicStroke(5));
                else
                    focus.getStyleRef().setDrawStroke(new BasicStroke(3));
                focus.getStyleRef().setDrawColor(new Color(100,100,255));
                focus.enableDamage();
                if(focus.getParentGroup()!=null)
                    focus.getParentGroup().damage(DAMAGE_NOW);
            }
        }
        
        /*
        GraphicalObject gob = this.getComponentParent(objectHit);
        if(gob!=null&&gob instanceof DenimIntrinsicComponentInstance)
        {
            ReplaceToolbar bar = new ReplaceToolbar(
                    (JFrame) SwingUtilities.getRoot(gob.getSheet()), 
                    (DenimIntrinsicComponentInstance)gob);
            bar.setVisible(true);
        }
        else
        {
            getAction().run(absPt, objectHit);
        }
*/
        getAction().run(absPt, objectHit);
        
        if(focus!=null)
        {
            focus.disableDamage();
            focus.setDrawPatch(oldDraw);
            focus.getStyleRef().setDrawColor(oldBounds);
            focus.enableDamage();
            if(focus.getParentGroup()!=null)
                focus.getParentGroup().damage(DAMAGE_IDLE);
        }
        
        if (objectHit != null && objectHit.getSheet() != null)
        {
            objectHit.getSheet().flushRenderRequests();
        }
            
        
/*		if (objectHit != null && objectHit.getSheet() != null)
        {
            objectHit.getSheet().bufferUpcomingRender(1000);
            
            GraphicalObject gob = objectHit;
            while(!(gob instanceof DenimSketch || gob instanceof DenimPanel
                || gob instanceof DenimSheet))
            {
                gob = gob.getParentGroup();
            }
            
            
            gob.damage(DAMAGE_IDLE);
            objectHit.getSheet().damage(DAMAGE_NOW);
			objectHit.getSheet().flushRenderRequests();
        }*/
	}

	//===   TEXT INSERT METHODS   ===============================================
	//===========================================================================
}

//==============================================================================

/*
Copyright (c) 2000-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
