package edu.berkeley.guir.damask.view.visual;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.pattern.PatternInstanceView;
import edu.berkeley.guir.damask.view.visual.component.ControlView;
import edu.berkeley.guir.damask.view.visual.dialog.DialogView;
import edu.berkeley.guir.damask.view.visual.dialog.PageView;
import edu.umd.cs.piccolo.*;

/** 
 * Listens to the model and modifies the scenegraph appropriately. There is
 * one layer per device type.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-09-2003 James Lin
 *                               Created LayerDirector.
 *                    11-19-2003 James Lin
 *                               Renamed to DamaskLayer, made a child class
 *                               of PLayer.
 *                    07-14-2004 James Lin
 *                               Split VisualLayer from DamaskLayer.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 07-14-2004
 */
public class VisualLayer extends DamaskLayer {

   // Initialized in initBeforeAddingViews()
   private List/*<DialogView>*/ dialogs;
   private PageView homePageView; 
   private List/*<PageView>*/ homePageViews;

   /**
    * Constructs a new layer that displays a view of the specified document
    * for the specified device type.
    *  
    * @param doc         the document to display
    * @param deviceType  the device type from which perspective to display
    *                     the document
    */
   public VisualLayer(DamaskDocument doc, DeviceType deviceType) {
      this(doc, deviceType, 1.0);
   }

   
   /**
    * Constructs a new layer that displays a view of the specified document
    * for the specified device type.
    * 
    * @param doc             the document to display
    * @param deviceType      the device type from which perspective to display
    *                         the document
    * @param pageTitleScale  the scale at which page titles should be drawn 
    */
   public VisualLayer(DamaskDocument doc, DeviceType deviceType,
         double pageTitleScale) {
      super(doc, deviceType, pageTitleScale);

      // Listen for cameras being added to or removed from this layer.
      addPropertyChangeListener(PLayer.PROPERTY_CAMERAS, new CamerasHandler());
   }

   
   /**
    * Called before views of elements in the graph are created and added
    * in the constructor.
    */
   protected void initBeforeAddingViews() {
      dialogs = new ArrayList/*<DialogView>*/();
      homePageView = null; 
      homePageViews = new ArrayList/*<PageView>*/();
   }


   /**
    * Sets the current device-type layer of this layer. This determines
    * whether elements added to this layer is intended for all device types
    * or only the device type of this layer. 
    */
   protected void internalSetDeviceTypeLayer(final DeviceTypeLayer deviceTypeLayer) {
      super.internalSetDeviceTypeLayer(deviceTypeLayer);
      
      // Make all of the content in the other layer faded out
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode node = (PNode)i.next();
         if (node instanceof Arrow) {
            ((Arrow)node).deviceTypeLayerChanged();
         }
         else if (node instanceof DialogView) {
            ((DialogView)node).deviceTypeLayerChanged();
         }
      }
      
      for (Iterator i = getTemplatePane().getViewsOfTemplateDialogs().iterator(); i.hasNext();) {
         final InteractionElementView node = (InteractionElementView)i.next();
         if (node instanceof DialogView) {
            ((DialogView)node).deviceTypeLayerChanged();
         }
      }
   }


   /**
    * Returns the dialog views in this layer.
    */
   public List/* <DialogView> */getDialogViews() {
      return Collections.unmodifiableList(dialogs);
   }

   /**
    * Returns the dialog views in this layer, including those within the
    * template pane.
    */
   public List/*<DialogView>*/ getDialogViewsIncludingTemplates() {
      final List/*<DialogView>*/ allDialogs = new ArrayList/*<DialogView>*/();
      allDialogs.addAll(dialogs);
      allDialogs.addAll(getTemplatePane().getViewsOfTemplateDialogs());
      return Collections.unmodifiableList(allDialogs);
   }

   /**
    * Returns a view of the home page in this layer.
    */
   public PageView getHomePageView() {
      return homePageView;
   }

   /**
    * Returns the views of the home page in this layer.
    */
   public List/*<PageView>*/ getHomePageViews() {
      return Collections.unmodifiableList(homePageViews);
   }


   /**
    * Adds the proper view for the specified element.
    */
   protected void addViewForElement(final InteractionElement element) {
      final DeviceType deviceType = getDeviceType();
      final TemplatePane templatePane = getTemplatePane();
      if (element instanceof Dialog) {
         final Dialog d = (Dialog)element;
         
         if (!(d instanceof TemplateDialog)) {
            if (d.isEnabled(deviceType)) {

               //TODO look up how to have a node's bounds automatically equal to its children's bounds
               final DialogView dView = new DialogView(d);
               views.put(d, dView);

               // Add the dialog in such a way that the template pane is always
               // on top
               addChild(indexOfChild(templatePane), dView);
               dialogs.add(dView);
            
               dView.setContentsSelectable(true);
               trackAddition(dView);
            }
         }
      }
      else if (element instanceof Connection) {
         final Connection c = (Connection)element;

         if (c.isVisibleToDeviceType(deviceType)) {
            // Create arrow.
            final Arrow arrow = new Arrow(c);

            // Add the arrow in such a way that the template pane is always on
            // top, except for arrows that originate from the template pane
            final Page sourcePage =
               c.getConnectionSource(deviceType).getPage(deviceType);
            if (sourcePage.isTemplate()) {
               addChild(arrow);
            }
            else {
               addChild(indexOfChild(templatePane), arrow);
            }
            // Make the arrow invisible if it originates from the
            // template pane and the pane is not visible
            if (c.getConnectionSource(deviceType).getDialog() instanceof
                TemplateDialog) {
               for (int i = 0, n = getCameraCount(); i < n; i++) {
                  final PCamera aCamera = getCamera(i);
                  arrow.setVisibleToCamera(
                     aCamera, templatePane.isVisibleToCamera(aCamera));
               }
            }
            
            views.put(c, arrow);
            trackAddition(arrow);
            
            // Add the arrow to views of any of its pattern instances
            for (Iterator i = c.getPatternInstanceMemberships().iterator();
                 i.hasNext(); ) {
               final PatternInstance instance = (PatternInstance)i.next();
               final PatternInstanceView instanceView =
                  (PatternInstanceView)views.get(instance);
               if (instanceView != null) {
                  instanceView.addMemberView(arrow);
               }
            }
         }
      }
      else if (element instanceof PatternInstance) {
         final PatternInstance pi = (PatternInstance)element;
         if (pi.isVisibleToDeviceType(deviceType)) {
            final PatternInstanceView piView = new PatternInstanceView(pi);
            addChild(indexOfChild(templatePane), piView);
            views.put(pi, piView);
            trackAddition(piView);
         }
      }
      else {
         assert false : "element added to graph must be dialog, connection, or pattern instance";
      }
   }

   /**
    * Removes the proper view for the specified element.
    */
   protected void removeViewForElement(final InteractionElement element) {
      final DeviceType deviceType = getDeviceType();
      if (element instanceof Dialog) {
         final Dialog d = (Dialog)element;
         if (!(d instanceof TemplateDialog)) {
            if (d.isEnabled(deviceType)) {
               final DialogView dView = (DialogView)views.get(d);
   
               dView.setContentsSelectable(false);
   
               removeChild(dView);
               dialogs.remove(dView);
   
               // Make sure any pages that are in the dialog just deleted are not
               // selected in any canvas.
               for (Iterator i = getCamerasReference().iterator(); i.hasNext(); ) {
                  final PCamera camera = (PCamera)i.next();
                  final PComponent component = camera.getComponent();
                  if (component instanceof VisualCanvas) {
                     final VisualCanvas canvas = (VisualCanvas)component;
                     final PageView oldSelectedPageView =
                        canvas.getSelectedPageView();
                     if ((oldSelectedPageView != null)
                        && (oldSelectedPageView.getParent() == dView)) {
                        canvas.attachHandles(null, camera);
                     }
                  }
               }
               dView.dispose();
            }
         }
      }
      else if (element instanceof Connection) {
         final Connection c = (Connection)element;

         if (c.isVisibleToDeviceType(deviceType)) {
            final Arrow arrow = (Arrow)views.get(c);
            
            // Remove the arrow from any of its pattern instance views
            for (Iterator i = c.getPatternInstanceMemberships().iterator();
                 i.hasNext(); ) {
               final PatternInstance instance = (PatternInstance)i.next();
               final PatternInstanceView instanceView =
                  (PatternInstanceView)views.get(instance);
               if (instanceView != null) {
                  instanceView.removeMemberView(arrow);
               }
            }
            
            arrow.dispose();
            removeChild(arrow);
         }
      }
      else if (element instanceof PatternInstance) {
         final PatternInstance pi = (PatternInstance)element;

         if (pi.isVisibleToDeviceType(deviceType)) {
            final PatternInstanceView piView = (PatternInstanceView)views.get(pi);
            piView.dispose();
            removeChild(piView);
         }
      }
      else {
         assert false : "element added to graph must be dialog, connection, or pattern instance";
      }
   }
   
   
   /**
    * Places the home icon on the home page.
    */
   // @Override
   public void updateHomePage() {
      final InteractionGraph graph = getDocument().getGraph();
      final DeviceType deviceType = getDeviceType();
      for (Iterator i = homePageViews.iterator(); i.hasNext(); ) {
         final PNode homePageView = (PNode)i.next();
         if (homePageView instanceof PageView) {
            ((PageView)homePageView).setHome(false); 
         }
      }
      
      homePageView = (PageView)getView(graph.getHomePage(deviceType)); 
      homePageViews.clear();
      homePageViews = getViews(graph.getHomePage(deviceType));
      
      for (Iterator i = homePageViews.iterator(); i.hasNext(); ) {
         final PNode homePageView = (PNode)i.next();
         if (homePageView instanceof PageView) {
            ((PageView)homePageView).setHome(true); 
         }
      }
   }

   
   //why nullpointer sometimes? connection problems
   public void updateArrows(DialogView diagview) {
      final TemplatePane templatePane = getTemplatePane();
      LinkedList arrwList = new LinkedList();
      LinkedList tparrwList = new LinkedList();
      LinkedList tpdvList = new LinkedList();
      Iterator tpiter = templatePane.getChildrenIterator();
      while (tpiter.hasNext()) {
         tpdvList.add(tpiter.next());
      }
      Iterator iter = this.getChildrenIterator();
      while (iter.hasNext()) {
         Object obj = iter.next();
         if (obj instanceof Arrow) {
            Arrow arrw = (Arrow)obj;
            Object srcObj = arrw.getSourceView();
            Object destObj = arrw.getDestView();
            if (srcObj instanceof PageView) {
               if (((PageView)srcObj).getParent() == diagview) {
                  arrwList.add(arrw);
               }
               Iterator tpdviter = tpdvList.iterator();
               while (tpdviter.hasNext()) {
                  if (((PageView)srcObj).getParent()
                     == (DialogView)tpdviter.next()) {
                     tparrwList.add(arrw);
                  }
               }
            }
            if (destObj instanceof PageView) {
               if (((PageView)destObj).getParent() == diagview) {
                  arrwList.add(arrw);
               }
               Iterator tpdviter = tpdvList.iterator();
               while (tpdviter.hasNext()) {
                  if (((PageView)destObj).getParent()
                     == (DialogView)tpdviter.next()) {
                     tparrwList.add(arrw);
                  }
               }
            }
            if (srcObj instanceof ControlView) {
               ControlView cntrlview = (ControlView)srcObj;
               if (cntrlview.getParent().getParent().getParent().getParent()
                  == diagview) {
                  arrwList.add(arrw);
               }
               Iterator tpdviter = tpdvList.iterator();
               while (tpdviter.hasNext()) {
                  if (cntrlview.getParent().getParent().getParent().getParent()
                     == (DialogView)tpdviter.next()) {
                     tparrwList.add(arrw);
                  }
               }
            }
         }
      }
      Iterator arrwiter = arrwList.iterator();
      while (arrwiter.hasNext()) {
         ((Arrow)arrwiter.next()).moveToFront();
      }
      templatePane.moveToFront();
      Iterator tparrwiter = tparrwList.iterator();
      while (tparrwiter.hasNext()) {
         ((Arrow)tparrwiter.next()).moveToFront();
      }
   }
   
   //------------------------------------------------------------------------

   /**
    * Listens to changes to the layer's list of cameras. 
    */
   private class CamerasHandler implements PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent evt) {
         for (Iterator i = getDialogViewsIncludingTemplates().iterator();
            i.hasNext();
            ) {
            final DialogView dialogView = (DialogView)i.next();
            dialogView.setContentsSelectable(true);
         }
      }
   }
}
