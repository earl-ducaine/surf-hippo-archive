package edu.berkeley.guir.lib.gesture;

import java.awt.*;
import java.util.BitSet;

import javax.swing.*;

import edu.berkeley.guir.lib.gesture.util.Misc;

/**
 * the part of FeaturePointGraph that graphs a single feature
 */
public class FPGraphFeature extends JPanel
{
  public static final Color[] colorArray = {
    Color.red, Color.blue, Color.magenta, Color.orange,
    Color.green, Color.pink, Color.cyan
  };
  Classifier classifier;
  int featureNumber;
  boolean weightsOn = false;
  /** indexed by [categoryNum][exampleNum].  If weights are on, these
    are the weighted values. */
  double featureValues[][];
  double maxValue;
  double minValue;
  BitSet categoryMask;
  JLabel minLabel, maxLabel;
  PlotColumn[] plotColumns;
  
  /** c must be non-null, else an IllegalArgumentException is thrown */
  public FPGraphFeature(Classifier c, int featureNum)
  {
    this(c, featureNum, Misc.not(new BitSet(c.getGestureSet().size())));
  }

  /** c must be non-null, else an IllegalArgumentException is thrown */
  public FPGraphFeature(Classifier c, int featureNum, BitSet catMask)
  {
    if (c == null)
      throw new IllegalArgumentException("Classifier c must be non-null");
    
    classifier = c;
    featureNumber = featureNum;
    categoryMask = catMask;
    featureValues = new double[1][];

    initUI();
  }

  /** Build the interface by adding a column for each category */
  private void initUI()
  {
    GridBagLayout gb = new GridBagLayout();
    JPanel dataPanel = new JPanel(gb);
    
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.fill = GridBagConstraints.VERTICAL;
    constraints.weighty = 1.0;
    
    GestureSet gestureSet = classifier.getGestureSet();
    int numCategories = gestureSet.size();
    plotColumns = new PlotColumn[numCategories];
    for (int catNum = 0; catNum < numCategories; catNum++) {
      plotColumns[catNum] = new PlotColumn();
      plotColumns[catNum].setBackground(Color.white);
      plotColumns[catNum].
	setForeground(colorArray[catNum % colorArray.length]);
      dataPanel.add(plotColumns[catNum], constraints);
    }

    setLayout(new BorderLayout());
    setBackground(Color.white);
    add(dataPanel, BorderLayout.CENTER);
    minLabel = new JLabel();
    maxLabel = new JLabel();
    minLabel.setBackground(Color.white);
    maxLabel.setBackground(Color.white);
    minLabel.setHorizontalAlignment(SwingConstants.CENTER);
    maxLabel.setHorizontalAlignment(SwingConstants.CENTER);
    add(minLabel, BorderLayout.SOUTH);
    add(maxLabel, BorderLayout.NORTH);

    rebuildUI();
  }

  private void computeFeatureValues()
  {
    GestureSet gestureSet = classifier.getGestureSet();
    int numCategories = gestureSet.size();
    if (featureValues.length < numCategories)
      featureValues = new double[numCategories][];
    
    minValue = Double.POSITIVE_INFINITY;
    maxValue = Double.NEGATIVE_INFINITY;
    for (int catNum = 0; catNum < numCategories; catNum++) {
      GestureCategory gc = (GestureCategory) gestureSet.getChild(catNum);
      int numExamples = gc.size();
      if ((featureValues[catNum] == null) ||
	  (featureValues[catNum].length < numExamples))
	featureValues[catNum] = new double[numExamples];
      double weight = 1.0;
      if (weightsOn) {
	weight = classifier.weights[catNum][featureNumber+1];
      }
      for (int exampleNum = 0; exampleNum < numExamples; exampleNum++) {
	Gesture gesture = gc.gestureAt(exampleNum);
	Feature f = FeatureVector.singleFeature(gesture, featureNumber);
	double value = f.getValue();
	if (weightsOn)
	  value *= weight;
	featureValues[catNum][exampleNum] = value;
	if (value < minValue)
	  minValue = value;
	if (value > maxValue)
	  maxValue = value;
      }
    }
  }

  private void rebuildUI()
  {
    computeFeatureValues();

    for (int catNum = 0; catNum < classifier.getGestureSet().size();
	 catNum++) {
      plotColumns[catNum].setVisible(categoryMask.get(catNum));
      plotColumns[catNum].setData(featureValues[catNum],
				  minValue, maxValue);
    }
    minLabel.setText(Misc.toString(minValue, 3));
    maxLabel.setText(Misc.toString(maxValue, 3));
    
    invalidate();
    Window w = (Window) getTopLevelAncestor();
    if (w != null)
      w.pack();
  }

  public void setCategoryMask(BitSet catMask)
  {
    if (!catMask.equals(categoryMask)) {
      categoryMask = (BitSet) catMask.clone();
      rebuildUI();
    }
  }

  public void weightsOn(boolean on)
  {
    if (weightsOn != on) {
      weightsOn = on;
      rebuildUI();
    }
  }
}
