//// See bottom of source code for software license

package edu.berkeley.guir.denim.interpreters;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.*;
import java.util.List;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.command.DenimPhantomMoveCommand;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.awt.geom.Polygon2D;
import edu.berkeley.guir.lib.satin.command.PhantomMoveCommand;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.InterpreterImpl;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

/**
 * By default accepts left button only.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 02 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             1.0.0  02-26-2003 JL
 *                    Split into SATIN class and DENIM-specific class
 *             1.1.0  03-03-2003 JL
 *                    Merged Yang's performance-related changes in
 *                    DenimSheet.SemanticMoveSelectedInterpreter into this
 *                    class
 *             1.1.1  03-11-2003 YL
 *                    Add simulateStart to enable new selection for immediate dragging after selection
 *                    Enabled all objects in DENIM with speedup dragging 
 *             1.1.1  03-26-2003 YL
 *                    Added hollow feedback of strokes for dragging
 *             1.1.1  04-02-2003 YL
 *                    Supported speedup dragging in auto-pan
 *             1.1.1  06-11-2003 YL
 *                    disabled moving of an Arrow by itself
 * 
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2.2
 * @version 1.0.0, 06-11-2003
 */

public class DenimMoveSelectedInterpreter extends InterpreterImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private boolean isOverSelected; // true if the user started dragging

   // over a selected object
   private double lastX; // last absolute x-coordinate
   private double lastY; // last absolute y-coordinate

   private GraphicalObjectCollection movingObjects; // objects to move
   private GraphicalObjectGroup oldParent; // initial parent of

   // objects to move
   private Point2D[] oldRelLocs;
   private Point2D[] newRelLocs;
   private AffineTransform[] oldTransforms;
   private AffineTransform[] newTransforms;

   private double totalDx = 0;
   private double totalDy = 0;

	private double ptotalDx = 0;
	private double ptotalDy = 0;
	      
   private DenimSheet sheet = null;

   /**
    * for speedup draggging
    */
   
   //1. for DenimPanel
   private List currentFrames = new ArrayList();
   private List internalNavs = new ArrayList();
   private List internalOrgs = new ArrayList();
   
   private List internalArrows = new ArrayList();

   //2. for strokes
   private Vector selectedStrokes = new Vector();

   // for synchronized purpose: using vector
   private Vector objectsInsideSketch = new Vector();
   
   //4. for drag-hold selection
   private Polygon2D loopGesture = null;   

   // for auto-pan problems   
   private AffineTransform startSheetTransform = new AffineTransform();
   private AffineTransform lastSheetTransform = new AffineTransform();
	/*
	private ArrayList mPhantoms = null;
	private BufferedImage mPhantomBackground = null;
	
	private SpeedupInitializer mSpeeduper = null;
	private boolean mSpeedupFinished = false;
	private boolean mOldSpeedupFinished = false;
		
	class SpeedupInitializer extends Thread {
		
		public SpeedupInitializer() {
			mOldSpeedupFinished = false;
			mSpeedupFinished = false;
		}
		
		public void run() {
			initializeSpeedupDragging();
			mSpeedupFinished = true;
		}
	}
*/
   //3. for objecs inside a sketch (except strokes)
   
   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================

   private class ObjectInsideSketch {

      public BufferedImage patchObject = null;
      public Line2D patchArrow = null;
      public Arrow patchOutArrow = null;
      public Rectangle2D patchPos = null;

      //-----------------------------------------------------------------
      
      /**
       * get image and hyperlink of those objects inside DenimPanel except stroke
       */
      
      public ObjectInsideSketch(PatchImpl obj) {

         sheet.setRenderToScreen(false);
         patchPos = obj.getBounds2D(COORD_ABS);
         patchObject =
            (BufferedImage)sheet.createImage(
               (int)patchPos.getWidth(),
               (int)patchPos.getHeight());
         cmdsubsys.removeSelected(obj);

         if (obj instanceof DenimComponentInstance
            && !((DenimComponentInstance)obj).getOutgoingArrows().isEmpty()) {
            Arrow ar = 
               (Arrow) ((DenimComponentInstance)obj)
                  .getOutgoingArrows()
                  .toArray()[0];
            
            if(!ar.isGlobal())
            {
                patchOutArrow = ar;
                Polygon2D skel = patchOutArrow.getPolygon2D(COORD_ABS);
                patchArrow =
                   new Line2D.Double(
                      skel.xpoints[0],
                      skel.ypoints[0],
                      skel.xpoints[skel.npoints - 1],
                      skel.ypoints[skel.npoints - 1]);
                patchOutArrow.setVisible(false);
                patchOutArrow.damage(DAMAGE_IDLE);
            }
         }

         obj.cacheImageTo(patchObject);
         obj.damage(DAMAGE_NOW);
         obj.cacheImageTo(null);

      }
      
      //-----------------------------------------------------------------

      public void draw(Graphics2D bg, double autopanx, double autopany) {

         if (patchObject != null) {
            bg.setTransform(
               AffineTransform.getTranslateInstance(totalDx, totalDy));
            bg.drawImage(
               patchObject,
               (int)patchPos.getMinX(),
               (int)patchPos.getMinY(),
               sheet);
            bg.setColor(Color.blue);
            DenimMoveSelectedInterpreter.this.renderSelected(bg, patchPos);

            if (patchArrow != null) {

               bg.setTransform(AffineTransform.getTranslateInstance(0, 0));
               Line2D line =
                  new Line2D.Double(
                     patchArrow.getP1().getX() + totalDx,
                     patchArrow.getP1().getY() + totalDy,
                     patchArrow.getP2().getX() + autopanx,
                     patchArrow.getP2().getY() + autopany);

               bg.setColor(DenimConstants.DEFAULT_NAV_ARROW_COLOR);
               bg.draw(line);
               DenimPanel.drawArrowheads(line, bg);
            }
         }
      }

      public void dragEnd() {

         if (patchOutArrow != null) {
            patchOutArrow.setVisible(true);
         }

         patchObject = null;
         patchArrow = null;
         patchOutArrow = null;
         patchPos = null;

      }
   }

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public DenimMoveSelectedInterpreter() {
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Move Selected Item Interpreter");
      setAcceptMiddleButton(false);
      setAcceptRightButton(false);
      movingObjects = new GraphicalObjectCollectionImpl();
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   //-----------------------------------------------------------------
   
   public void setLoopGesture(Polygon2D lg) {
      loopGesture = lg;
   }
   
   
   private void clear() {
      oldParent = null;
      movingObjects.clear();
      currentFrames.clear();
      internalNavs.clear();
      internalOrgs.clear();
      selectedStrokes.clear();
      objectsInsideSketch.clear();
   }
   
   
   //-----------------------------------------------------------------     

   /**
    * move the internal arrows when dragging multi-selection objects.
    */
   private void moveArrowsBetweenSelectedObjects(Graphics2D bg, double dx, double dy) {
      bg.setColor(DenimConstants.DEFAULT_NAV_ARROW_COLOR);

      for (Iterator i = internalNavs.iterator(); i.hasNext(); ) {
         Line2D line = (Line2D) i.next();
         line.setLine(
            line.getP1().getX() + dx,
            line.getP1().getY() + dy,
            line.getP2().getX() + dx,
            line.getP2().getY() + dy);
         bg.draw(line);
         DenimPanel.drawArrowheads(line, bg);
      }

      bg.setColor(DenimConstants.DEFAULT_ORG_ARROW_COLOR);

      for (Iterator i = internalOrgs.iterator(); i.hasNext(); ) {
         Line2D line = (Line2D) i.next();
         line.setLine(
            line.getP1().getX() + dx,
            line.getP1().getY() + dy,
            line.getP2().getX() + dx,
            line.getP2().getY() + dy);
         bg.draw(line);
         DenimPanel.drawArrowheads(line, bg);
      }
   }

  //-----------------------------------------------------------------


   // copied from SATIN
 
  private void renderSelected(Graphics2D g, Rectangle2D rect) {
         //// 1. Get the size of the handle.
      int size = 6;

      //// 2. Calculate the location of the handles.
      int x = (int) rect.getX();
      int y = (int) rect.getY();
      int w = (int) rect.getWidth();
      int h = (int) rect.getHeight();

      int x1 = x;               // top-left
      int y1 = y;
      int x2 = x + w/2;         // top-mid
      int y2 = y;
      int x3 = x + w;           // top-right
      int y3 = y;
      int x4 = x + w;           // mid-right
      int y4 = y + h/2;
      int x5 = x + w;           // bottom-right
      int y5 = y + h;
      int x6 = x + w/2;         // bottom-mid
      int y6 = y + h;
      int x7 = x;               // bottom-left
      int y7 = y + h;
      int x8 = x;               // mid-left
      int y8 = y + h/2;

      //// 3. Paint the handles.
      g.fillRect(x1 - size/2, y1 - size/2, size, size);
      g.fillRect(x2 - size/2, y2 - size/2, size, size);
      g.fillRect(x3 - size/2, y3 - size/2, size, size);
      g.fillRect(x4 - size/2, y4 - size/2, size, size);
      g.fillRect(x5 - size/2, y5 - size/2, size, size);
      g.fillRect(x6 - size/2, y6 - size/2, size, size);
      g.fillRect(x7 - size/2, y7 - size/2, size, size);
      g.fillRect(x8 - size/2, y8 - size/2, size, size);
   } // of method
      
   
   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================
   
   public void handleNewStroke(NewStrokeEvent evt) {

      if (sheet == null) {
         sheet = (DenimSheet)this.getAttachedGraphicalObject().getSheet();
      }

      sheet.setPieMenuVisible(false);

      TimedStroke stk = evt.getStroke();
      GraphicalObject attached = getAttachedGraphicalObject();

      if (attached instanceof GraphicalObjectGroup) {
         Point2D ptPress = stk.getStartPoint2D(COORD_ABS);

         GraphicalObject gobTmp = null;

         //// 1. See if we are over a selected GraphicalObject.
         isOverSelected = false;

         for (Iterator selIter = cmdsubsys.getSelected(); selIter.hasNext();) {
            GraphicalObject gob = (GraphicalObject)selIter.next();
            if (gob.shapeContains(COORD_ABS, ptPress)) {
               gobTmp = gob;
               
               isOverSelected = true;
               break;
            }
         }

         //// 1.1. If the item is selected...
         if (isOverSelected) {

            movingObjects.clear();
      
            totalDx = 0;
            totalDy = 0;

            //// 1.1.1. If the stroke starts within a sketch, and the current
            //// zoom level is lower than sitemap level, then assume the user
            //// is trying to draw something instead of moving the sketch
            GraphicalObjectCollection selObjs =
               cmdsubsys.getSelectedCollection();

            if (sheet.getAbsScale() > DenimConstants.SITEMAP_SCALE_FACTOR) {
               for (Iterator its = selObjs.getForwardIterator();
                  its.hasNext();
                  ) {

                  GraphicalObject gob = (GraphicalObject)its.next();

                  if (gob instanceof DenimPanel) {
                     DenimSketch sketch = ((DenimPanel) gob).getSketch();

                     if (sketch
                        .getBounds2D(COORD_ABS)
                        .contains(
                           evt.getStroke().getBounds2D(COORD_ABS).getCenterX(),
                           evt
                              .getStroke()
                              .getBounds2D(COORD_ABS)
                              .getCenterY())) {
                        evt.setConsumed(false);
                        isOverSelected = false;
                        gobTmp = null;
                        return;
                     }
                  }
               }
            }

            evt.setConsumed();
            evt.setShouldRender(false);

            //// 1.1.2. Store the location of the original mouse click.
            lastX = ptPress.getX();
            lastY = ptPress.getY();

            //// 1.1.3. Keep track of only the selected objects that have
            ////        the same parent as the object being directly dragged.
            this.oldParent = gobTmp.getParentGroup();

            for (Iterator it = selObjs.getForwardIterator(); it.hasNext();) {
               GraphicalObject gob = (GraphicalObject) it.next();
               if (gob.getParentGroup() == oldParent) {
                  
                  // Arrow should not be moved alone
                  if(!(gob instanceof Arrow))
                     movingObjects.add(gob);
               }
            }

            //// 1.1.4. Store the original relative locations of the
            ////        objects to be moved.
            oldRelLocs = new Point2D[movingObjects.numElements()];
            oldTransforms = new AffineTransform[movingObjects.numElements()];
            int i = 0;
            for (Iterator it = movingObjects.getForwardIterator();
               it.hasNext();
               ) {
               GraphicalObject gob = (GraphicalObject) it.next();
               oldRelLocs[i] = gob.getLocation2D(COORD_REL);
               oldTransforms[i] = gob.getTransform(COORD_REL);
               i++;
            }

            //// 1.1.5. Set up the low-level display code that will
            ////        handle the display of dragging
            
            initializeSpeedupDragging();
            
/*				mPhantoms = this.getPhantom();
				            
            this.mSpeeduper = new SpeedupInitializer();
            this.mSpeeduper.start();
*/
         }
      }
   } // of handleNewStroke

	//-----------------------------------------------------------------
/*	
	private ArrayList getPhantom() {
		
		// Consistence Check for background image
		if (mPhantomBackground == null
			|| mPhantomBackground.getWidth() != sheet.getWidth()
			|| mPhantomBackground.getHeight() != sheet.getHeight()) {
				
				mPhantomBackground = (BufferedImage)sheet.createImage(
												sheet.getWidth(),
												sheet.getHeight());
		}
		
		ArrayList polys = new ArrayList();
		Iterator it = movingObjects.getForwardIterator();
		while(it.hasNext())
		{
			GraphicalObject obj = (GraphicalObject)it.next();
			if(obj instanceof ObjectPhantom)
			{
				polys.add(((ObjectPhantom)obj).getPhantom());
			}
		}
		
		ptotalDx = 0;
		ptotalDx = 0;
		
		return polys;
	}
	*/	
   //-----------------------------------------------------------------
   
   private void initializeSpeedupDragging() {

      // Consistence Check for background image
      if (sheet.getBackgroundImage() == null
         || sheet.getBackgroundImage().getWidth() != sheet.getWidth()
         || sheet.getBackgroundImage().getHeight() != sheet.getHeight()) {
         sheet.setBackgroundImage(
            (BufferedImage)sheet.createImage(
               sheet.getWidth(),
               sheet.getHeight()));
      }

      // Clear up
      startSheetTransform = (AffineTransform)sheet.getTransform(COORD_ABS).clone();
      lastSheetTransform = (AffineTransform)sheet.getTransform(COORD_ABS).clone();
      
      currentFrames.clear();
      selectedStrokes.clear();
      internalNavs.clear();
      internalOrgs.clear();
      objectsInsideSketch.clear();
      
      // convert collection to vector to avoid CoModificationException of
      // multiple threads
      Vector objs = new Vector();         
      for (Iterator i = movingObjects.getForwardIterator(); i.hasNext(); ) {
         objs.add(i.next());
      }

      try {
         for (Iterator i = objs.iterator(); i.hasNext(); ) {
            GraphicalObject gob = (GraphicalObject)i.next();

            if (gob instanceof DenimPanel) {
               // For DENIM Panel speeding up dragging
               currentFrames.add(
                  ((DenimPanel)gob).initFrameForMultiSelection(
                     movingObjects,
                     internalNavs,
                     internalOrgs,
                     internalArrows));
               ((DenimPanel)gob).setHyperLinkVisible(false);
               gob.setVisible(false);
            }
            else if (gob instanceof TimedStroke) {
               // For TimedStroke speeding up dragging
               selectedStrokes.add(((TimedStroke)gob).getPolygon2D(COORD_ABS));
               gob.setVisible(false);

               //               TimedCurvyStroke tcs = new TimedCurvyStroke(((TimedStroke)gob).getPolygon2D(COORD_ABS));
               //               selectedStrokes.add(tcs);
            }
            else if (
               gob instanceof DenimComponentInstance
                  || gob instanceof ScribbledText
                  || gob instanceof TypedText
                  || gob instanceof DenimGroup
                  || gob instanceof DenimImage) {
               // Patch Object speeding up
               objectsInsideSketch.add(new ObjectInsideSketch((PatchImpl)gob));
               gob.setVisible(false);
            }
            else {
               System.out.println("not supported by speeding up dragging");
               System.out.println(gob.toString());
            }
         }
      }
      catch (java.util.ConcurrentModificationException e) {
         System.out.println("ConcurrentModificationException in NewStroke");
      }

      sheet.setRenderToScreen(false);

      // Refresh buffered image but not render to screen
      if (!currentFrames.isEmpty() || selectedStrokes.size() > 0) {
         sheet.damage(DAMAGE_NOW);
      }

   }

   //-----------------------------------------------------------------     
      
   /**
    * simulate start of a drag
    */      
   
   public void simulateStart(Point2D ptPress, GraphicalObject obj) {
      
      sheet.setPieMenuVisible(false);
      
      GraphicalObject attached = getAttachedGraphicalObject();

      if (attached instanceof GraphicalObjectGroup) {
         movingObjects.clear();
         totalDx = 0;
         totalDy = 0;

         isOverSelected = true;
         GraphicalObject gobTmp = obj;
         
         //// 1.1. If the item is selected...
         if (isOverSelected) {

            GraphicalObjectCollection selObjs =
               cmdsubsys.getSelectedCollection();

            //// 1.1.2. Store the location of the original mouse click.
            lastX = ptPress.getX();
            lastY = ptPress.getY();

            //// 1.1.3. Keep track of only the selected objects that have
            ////        the same parent as the object being directly dragged.
            this.oldParent = gobTmp.getParentGroup();

            for (Iterator it = selObjs.getForwardIterator(); it.hasNext();) {
               GraphicalObject gob = (GraphicalObject) it.next();
               if (gob.getParentGroup() == oldParent) {

                  // Arrow should not be moved alone
                  if(!(gob instanceof Arrow))
                     movingObjects.add(gob);
               }
            }

            //// 1.1.4. Store the original relative locations of the
            ////        objects to be moved.
            oldRelLocs = new Point2D[movingObjects.numElements()];
            oldTransforms = new AffineTransform[movingObjects.numElements()];
            int i = 0;
            for (Iterator it = movingObjects.getForwardIterator();
               it.hasNext();
               ) {
               
               GraphicalObject gob = (GraphicalObject) it.next();
               oldRelLocs[i] = gob.getLocation2D(COORD_REL);
               oldTransforms[i] = gob.getTransform(COORD_REL);
               i++;
            }
            
            initializeSpeedupDragging();
/*				mPhantoms = this.getPhantom();
				
				this.mSpeeduper = new SpeedupInitializer();
				this.mSpeeduper.start();*/
         }     
               
      }
   }

   //-----------------------------------------------------------------

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
   	
      //// 1. Move the selected objects.
      if (isOverSelected) {

         TimedStroke stk = evt.getStroke();
         Point2D pt = stk.getEndPoint2D(COORD_ABS);

         double dx = pt.getX() - lastX;
         double dy = pt.getY() - lastY;
         
         AffineTransform currentTr = sheet.getTransform(COORD_ABS);

         double autoPanDeltaX =
            currentTr.getTranslateX() - this.lastSheetTransform.getTranslateX();
         double autoPanDeltaY =
            currentTr.getTranslateY() - this.lastSheetTransform.getTranslateY();
         
         this.lastSheetTransform = (AffineTransform)currentTr.clone();
         
         if (dx != 0 || dy != 0) {

            Graphics2D g2d = (Graphics2D)sheet.getSheet().getGraphics();
            
/*            if(mOldSpeedupFinished==false&&mSpeedupFinished==true)
            {
            	dx = ptotalDx+dx;
            	dy = ptotalDy+dy;
            }

				// if the speedup initilizatio is not completed, just use phantom
				if(mSpeedupFinished==false)
				{
					ptotalDx += dx;
					ptotalDy += dy;
					
					Graphics2D bg = this.mPhantomBackground.createGraphics();
					bg.setRenderingHint(
						RenderingHints.KEY_ANTIALIASING,
						RenderingHints.VALUE_ANTIALIAS_ON);
					bg.drawImage(sheet.getBufferedImage(), 0, 0, sheet);
					bg.translate(ptotalDx, ptotalDy);
					Iterator it = this.mPhantoms.iterator();
					while(it.hasNext())
					{
						Polygon2D poly = (Polygon2D)it.next();
						bg.draw(poly);
					}
					bg.dispose();
					g2d.drawImage(this.mPhantomBackground, 0, 0, sheet);
					mOldSpeedupFinished = false;
				}
				else
				{
				*/
					totalDx += dx;
					totalDy += dy;
					
	            Graphics2D bg = sheet.getBackgroundImage().createGraphics();
	            bg.setRenderingHint(
	               RenderingHints.KEY_ANTIALIASING,
	               RenderingHints.VALUE_ANTIALIAS_ON);
	
	            bg.drawImage(sheet.getBufferedImage(), 0, 0, sheet);
	
	            if (!currentFrames.isEmpty()) {
	               for (Iterator i = currentFrames.iterator(); i.hasNext();) {
	                  ((DenimPanel)i
	                     .next())
	                     .moveFrameForMultiSelection(
	                        bg,
	                        dx,
	                        dy,
	                        autoPanDeltaX,
	                        autoPanDeltaY);
	               }
	
	               moveArrowsBetweenSelectedObjects(bg, dx, dy);
	            }
	
	            if (!selectedStrokes.isEmpty()) {
	
	               bg.setTransform(
	                  AffineTransform.getTranslateInstance(totalDx, totalDy));
	
	               for (Iterator i = selectedStrokes.iterator(); i.hasNext(); ) {
	                  Polygon2D poly = (Polygon2D)i.next();
	                   
	                  bg.setColor(Color.red);
	                  bg.setStroke(new BasicStroke(6));
	                  bg.draw(poly);
	
	                  bg.setStroke(new BasicStroke(2));
	                  bg.setColor(Color.white);
	                  bg.draw(poly);
	
	                  //                  ((TimedCurvyStroke)selectedStrokes.get(i)).render(new SatinGraphics(bg));
	               }
	            }
	
	            for (Iterator i = objectsInsideSketch.iterator(); i.hasNext(); ) {
	               ObjectInsideSketch obj = (ObjectInsideSketch)i.next();
	
	               double autoPanTotalX =
	                  currentTr.getTranslateX()
	                     - this.startSheetTransform.getTranslateX();
	               double autoPanTotalY =
	                  currentTr.getTranslateY()
	                     - this.startSheetTransform.getTranslateY();
	
	               obj.draw(bg, autoPanTotalX, autoPanTotalY);
	            }
	
	            if (loopGesture != null) {
	               bg.setColor(new Color(0, 0, 255, 66));
	               bg.setStroke(new BasicStroke(6));
	               AffineTransform tr =
	                  AffineTransform.getTranslateInstance(totalDx, totalDy);
	               bg.setTransform(tr);
	               bg.draw(loopGesture);
	            }
	
	            bg.dispose();
	            g2d.drawImage(sheet.getBackgroundImage(), 0, 0, sheet);
	            
					//mOldSpeedupFinished = true;
				}
         //}
         
			lastX = pt.getX();
			lastY = pt.getY();

         evt.setConsumed();
         evt.setShouldRender(false);
      }
   } // of handleUpdateStroke


   //-----------------------------------------------------------------

   public void handleSingleStroke(SingleStrokeEvent evt) {
      //// 1. Set event as consumed, since we already used it.
      if (isOverSelected) {
         
         AffineTransform currentTr = sheet.getTransform(COORD_ABS);
         double autoscrollDetlaX =
            currentTr.getTranslateX() - startSheetTransform.getTranslateX();
         double autoscrollDetlaY =
            currentTr.getTranslateY() - startSheetTransform.getTranslateY();
         
         totalDx -= autoscrollDetlaX;
         totalDy -= autoscrollDetlaY;
         
         evt.setConsumed();
         evt.setShouldRender(false);
         
         sheet.bufferUpcomingRender(1000);              

         // code for speedup dragging
         
         loopGesture = null;

         for (Iterator i = currentFrames.iterator(); i.hasNext(); ) {               
            ((DenimPanel)i.next()).disposeObjectFrame();
         }
  
         currentFrames.clear();
         selectedStrokes.clear();
  
         try {
            for (Iterator i = movingObjects.getReverseIterator(); i.hasNext(); ) {
               GraphicalObject obj = (GraphicalObject)i.next();
               
               if(obj.getParentGroup() instanceof GraphicalObjectImpl)
                   ((GraphicalObjectImpl)obj.getParentGroup()).getRenderCache().setCacheInvalide();

               obj.moveBy(COORD_ABS, totalDx, totalDy);
               
               obj.setVisible(true);
               cmdsubsys.addSelected(obj);

               if (obj instanceof DenimPanel) {
                  ((DenimPanel)obj).setHyperLinkVisible(true);
                  ((DenimPanel)obj).releaseResource();
               }
            }

            for (Iterator i = internalArrows.iterator(); i.hasNext(); ) {
               cmdsubsys.addSelected((Arrow)i.next());
            }

            for (Iterator i = objectsInsideSketch.iterator(); i.hasNext(); ) {
               ((ObjectInsideSketch)i.next()).dragEnd();
            }
         }
         catch (ConcurrentModificationException ex) {
            for (Iterator i = movingObjects.getReverseIterator(); i.hasNext(); ) {
               GraphicalObject obj = (GraphicalObject)i.next();
               obj.setVisible(true);

               if (obj instanceof DenimPanel)
                  ((DenimPanel)obj).setHyperLinkVisible(true);
            }

            for (Iterator i = objectsInsideSketch.iterator(); i.hasNext(); ) {
               ((ObjectInsideSketch)i.next()).dragEnd();
            }
         }


         //// 2. Check if the objects actually moved. (Checking one is
         ////    enough.)
         if (movingObjects.isEmpty()==false&&
                 !movingObjects
                    .get(0)
                    .getLocation2D(COORD_REL)
                    .equals(oldTransforms[0])) {
   
            //// 2.1. Figure out the new parent of the moved objects.
            GraphicalObjectGroup newParent;
   
            ////      If the old parent was a sketch or a group, then the
            ////      new parent can be a sketch or a group.
            if ((this.oldParent instanceof DenimSketch)
               || (this.oldParent instanceof DenimGroup)) {
               TimedStroke stk = evt.getStroke();
               Rectangle2D box = movingObjects.getCollectionBounds2D(COORD_ABS);
               Point2D pt = //stk.getEndPoint2D(COORD_ABS);
                   new Point2D.Double(
                           box.getCenterX(),
                           box.getCenterY()); 
   
               
               DenimPanel panel = DenimUtils.findPanel(sheet, pt);
               
               if (panel != null) {
               /*   DenimGroup group =
                     DenimUtils.findDeepestNestedDenimGroup(panel.getSketch(), pt);
                  if (group == null) {
                     newParent = panel.getSketch();
                  }
                  else {
                     newParent = group;
                     // Make sure the group isn't one of the selected objects
                     for (Iterator it = movingObjects.getForwardIterator(); it.hasNext(); ) {
                        GraphicalObject gob = (GraphicalObject) it.next();
                        if (gob == group) {
                           newParent = group.getParentGroup();
                           break;
                        }
                     }
                  }
                  */
                   newParent = panel.getSketch();
               }
               else {
                  newParent = sheet;
               }
            }
            else {
               newParent = oldParent;
            }
   
            //// 2.2. If the parent is now different, change the parent
            ////      of the objects (but leave them in the same location).
            if (oldParent != newParent) {
               for (Iterator it = movingObjects.getForwardIterator(); it.hasNext(); ) {
                  GraphicalObject gob = (GraphicalObject) it.next();
                  newParent.add(gob, GraphicalObjectGroup.KEEP_ABS_POS);
               }
            }
   
            //// 2.3. Store the new relative locations of the
            ////      selected objects.
            int i = 0;
            newRelLocs = new Point2D[movingObjects.numElements()];
            newTransforms = new AffineTransform[movingObjects.numElements()];
            for (Iterator it = movingObjects.getForwardIterator(); it.hasNext(); ) {
               GraphicalObject gob = (GraphicalObject) it.next();
               newRelLocs[i] = gob.getLocation2D(COORD_REL);
               newTransforms[i] = gob.getTransform(COORD_REL);
               i++;
            }
   
            //// 2.4. Put a "phantom" command in the command
            ////      queue, which won't actually move the selected objects
            ////      but will allow the user to undo and redo the move
            ////      just executed.
            if (oldParent == newParent) {
               cmdqueue.doCommand(
                  new PhantomMoveCommand(
                     cmdsubsys.getSelected(),
                     oldRelLocs,
                     newRelLocs));
            }
            else {
               cmdqueue.doCommand(
                  new DenimPhantomMoveCommand(
                     cmdsubsys.getSelected(),
                     oldParent,
                     oldTransforms,
                     newParent,
                     newTransforms));
            }
         }
         

         sheet.setRenderToScreen(true);
         getAttachedGraphicalObject().damage(DAMAGE_LATER);
         sheet.flushRenderRequests();

         //release the references for memory optimizations         
         clear();
         
         sheet.setModified(true);
                
      }
   } // of handleSingleStroke

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================

   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (new DenimMoveSelectedInterpreter());
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
