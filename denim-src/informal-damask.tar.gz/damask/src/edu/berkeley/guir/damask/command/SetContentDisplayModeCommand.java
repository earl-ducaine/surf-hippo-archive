package edu.berkeley.guir.damask.command;

import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that sets the preferred display mode for content.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  01-07-2004 James Lin
 *                               Created SetContentDisplayModeCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 01-07-2004
 */
public class SetContentDisplayModeCommand extends UndoableCommand
implements ModifyGraphCommand {

   private final Content content;
   private final DeviceType deviceType;
   private final Map/*<DeviceType, Content.DisplayMode>*/ oldDisplayModes =
      new HashMap/*<DeviceType, Content.DisplayMode>*/();
   private final Content.DisplayMode newDisplayMode;
   
   /**
    * Constructs the command.
    *  
    * @param content      the content to edit
    * @param deviceType   the device type for which the display mode
    *                      will be changed
    * @param displayMode  the new display mode of the content
    */      
   public SetContentDisplayModeCommand(
      final Content content,
      final DeviceType deviceType,
      final Content.DisplayMode displayMode) {

      this.content = content;
      this.deviceType = deviceType;
      newDisplayMode = displayMode;
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext();
         ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         oldDisplayModes.put(
            aDeviceType,
            content.getPreferredDisplayMode(aDeviceType));
      }
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Set display mode of " + content +
         " for " + deviceType + " to " + newDisplayMode;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      content.setPreferredDisplayMode(deviceType, newDisplayMode);
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext();
         ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         content.setPreferredDisplayMode(
            aDeviceType,
            (Content.DisplayMode)oldDisplayModes.get(aDeviceType));
      }
   }
}
