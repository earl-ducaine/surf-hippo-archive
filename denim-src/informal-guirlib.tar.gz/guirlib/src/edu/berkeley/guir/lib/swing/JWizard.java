//// See bottom of file for software license
package edu.berkeley.guir.lib.swing;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/**
 * An implementation of a Wizard process funnel.
 * To use, create JWizardPanels, each of which represent a single 
 * step in the wizard. Add the JWizardPanels to the JWizard (via 
 * {@link #addPanel(JWizardPanel)}).
 * <P>
 * Here's an example of how to use this JWizard.
 * <CODE>
 *  // First panel of the Wizard
 *  static class MainPanel extends JWizardPanel {
 *      JRadioButton optionA;
 *      JRadioButton optionB;
 *
 *      public MainPanel() {
 *          //// 1. "Main" is the name of this panel.
 *          ////    Have to name it, to know what state to transition from / to
 *          super("Main");
 *          setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
 *
 *          //// 2. Setup the GUI model. Arbitrary code here.
 *          ButtonGroup grp = new ButtonGroup();
 *          optionA = new JRadioButton("A");
 *          optionB = new JRadioButton("B");
 *          optionA.addItemListener(new MyItemListener());
 *          optionB.addItemListener(new MyItemListener());
 *          grp.add(optionA);
 *          grp.add(optionB);
 *
 *          //// 3. Setup the GUI display. Arbitrary code here.
 *          add(new JLabel("Choose an option:"));
 *          add(optionA);
 *          add(optionB);
 *
 *          //// 4. Set the next to be disabled by default.
 *          ////    Wait until something has been selected.
 *          setNextEnabled(false);
 *      } // of contructor
 *
 *      // Get what state we should move to when "Next" is selected
 *      public String getNextState() {
 *          if (optionA.isSelected() == true) {
 *              return ("A");
 *          }
 *          if (optionB.isSelected() == true) {
 *              return ("B");
 *          }
 *          return (null);
 *      } // of method
 *
 *      // Listen to changes in the state of the wizard and then enable
 *      // the "Next" button. Not a compelling example here, but you should
 *      // be able to see how you can check the current state of the wizard
 *      // and make sure that it's in a good state before allowing the 
 *      // end-user to go to the next state
 *      class MyItemListener implements ItemListener {
 *          public void itemStateChanged(ItemEvent evt) {
 *              setNextEnabled(true);
 *          } // of method
 *      } // of inner inner class
 *  } // of inner class
 *
 *
 *  // Panel displayed if option A is selected
 *  static class OptionAPanel extends JWizardPanel {
 *      public OptionAPanel() {
 *          super("A");
 *          add(new JLabel("OptionA panel"));
 *      } // of constructor
 *
 *      // Signify that this is a finished state
 *      public String getNextState() {
 *          return (JWizardPanel.FINISHED);
 *      } // of method
 *
 *      // Where to go back to
 *      public String getBackState() {
 *          return ("Main");
 *      } // of method
 *  } // of inner class
 *
 *
 *  // Panel displayed if option B is selected
 *  static class OptionBPanel extends JWizardPanel {
 *      public OptionBPanel() {
 *          super("B");
 *          add(new JLabel("OptionB panel"));
 *      } // of constructor
 *
 *      // Signify that this is a finished state
 *      public String getNextState() {
 *          return (JWizardPanel.FINISHED);
 *      } // of method
 *
 *      // Where to go back to
 *      public String getBackState() {
 *          return ("Main");
 *      } // of method
 *  } // of inner class
 *
 *
 *  // Listens to messages from the wizard
 *  // Not a compelling example, but you should be able to see how to 
 *  // tailor a response from the Wizard upon completion or cancellation.
 *  static public class Listener implements JWizardListener {
 *      public void onFinish() {
 *          System.out.println("Wizard finished");
 *      } // of method
 *
 *      public void onCancel() {
 *          System.out.println("Wizard cancelled");
 *      } // of method
 *  } // of inner class
 *
 *
 *  // Run the wizard
 *  public static void main(String[] argv) {
 *      JWizard wiz;
 *
 *      //// 1. Setup the Wizard GUI.
 *      wiz = new JWizard();
 *      wiz.addPanel(new MainPanel());
 *      wiz.addPanel(new OptionAPanel());
 *      wiz.addPanel(new OptionBPanel());
 *
 *      //// 2. Add a listener.
 *      wiz.addListener(new Listener());
 *
 *      //// 3. Display the wizard and go.
 *      wiz.setVisible(true);
 *  } // of main
 * </CODE>
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified July 10 2003, JH
 */
public class JWizard
    extends JFrame {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    //// Needed to switch the Wizard screen
    CardLayout layout;

    //// (JWizardPanel panel, WizardActionPanel)
    //// Given a wizard panel, stores the corresponding "next" / "back" panel
    Map        mapPanelAction = new HashMap();

    //// List of JWizardListener instances.
    List       listListeners  = new LinkedList();

    //// Is this the first panel added? If so, disable back button.
    boolean    flagFirstPanel = true;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Create a no-title wizard frame.
     */
    public JWizard() {
        super();
        commonInit();
    } // of method

    //----------------------------------------------------------------

    /**
     * Create a wizard frame with specified title.
     */
    public JWizard(String strTitle) {
        super(strTitle);
        commonInit();
    } // of method

    //----------------------------------------------------------------

    /**
     * Initializations common to all constructors.
     */
    private void commonInit() {
        setSize(400, 200);
        layout = new CardLayout();
        getContentPane().setLayout(layout);

        //// For debugging
        // addListener(JWizardListener.CONSOLE);
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   WIZARD METHODS   ===================================================

    /**
     * Add a wizard panel. First panel added is the 
     * first to be shown, by default. Also disables back button
     * on first panel added by default.
     */
    public void addPanel(JWizardPanel pwiz) {
        //// 1. Create an empty JPanel to encapsulate everything.
        JPanel p = new JPanel();
        p.setLayout(new BorderLayout());

        //// 2. Add the wizard panel.
        p.add(pwiz, BorderLayout.CENTER);
        p.add(new JLabel("   "), BorderLayout.NORTH);
        p.add(new JLabel("   "), BorderLayout.WEST);

        //// 3. Add the buttons.
        WizardActionPanel pAction = new WizardActionPanel(pwiz);
        mapPanelAction.put(pwiz, pAction);

        //// 4.
        pwiz.setWizard(this);

        //// 5. Add listeners to the back, next, and cancel buttons.
        pAction.getBackButton().addActionListener(new BackActionListener(pwiz));
        pAction.getNextButton().addActionListener(new NextActionListener(pwiz));
        pAction.getCancelButton().addActionListener(new CancelActionListener());
        p.add(pAction, BorderLayout.SOUTH);

        //// 6. Add the whole panel we just created to this wizard.
        getContentPane().add(p, pwiz.getStateName());

        //// 7. Disable back button if first panel added, ie start panel.
        if (flagFirstPanel == true) {
            flagFirstPanel = false;
            pwiz.setBackEnabled(false);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Update the status of the back / next buttons for this wizard.
     * Called automatically by JWizardPanel when the next / back 
     * enable / disable state is changed. For internal use only.
     * (Ok, so this really should be an inner class and all, but I didn't
     * want to create an extra class just for a single method like this)
     * @see JWizardPanel#setNextEnabled(boolean)
     * @see JWizardPanel#setBackEnabled(boolean)
     */
    public void onUpdate(JWizardPanel pwiz) {
        WizardActionPanel pAction;

        //// 1. Retrieve the action panel.
        pAction = (WizardActionPanel) mapPanelAction.get(pwiz);

        //// 2. Update the buttons.
        pAction.getBackButton().setEnabled(pwiz.isBackEnabled());
        pAction.getNextButton().setEnabled(pwiz.isNextEnabled());
    } // of method

    //----------------------------------------------------------------

    /**
     * Add a listener to this Wizard.
     */
    public void addListener(JWizardListener lstnr) {
        listListeners.add(lstnr);
    } // of method

    /**
     * Remove a listener from this Wizard.
     */
    public void removeListener(JWizardListener lstnr) {
        listListeners.remove(lstnr);
    } // of method

    /**
     * Clear out all listeners on this Wizard.
     */
    public void clearListeners() {
        listListeners.clear();
    } // of method

    /**
     * Notify all listeners that the Wizard has finished.
     */
    protected void fireOnFinish() {
        Iterator        it = listListeners.iterator();
        JWizardListener l;
        while (it.hasNext()) {
            l = (JWizardListener) it.next();
            l.onFinish();
        }
    } // of method

    /**
     * Notify all listeners that the Wizard has been cancelled.
     */
    protected void fireOnCancel() {
        Iterator        it = listListeners.iterator();
        JWizardListener l;
        while (it.hasNext()) {
            l = (JWizardListener) it.next();
            l.onCancel();
        }
    } // of method

    //===   WIZARD METHODS   ===================================================
    //==========================================================================




    //==========================================================================
    //===   GUI SETUP   ========================================================

    /**
     * Listens for "next" button presses.
     */
    class NextActionListener implements ActionListener {
        JWizardPanel p;

        public NextActionListener(JWizardPanel newp) {
            p = newp;
        } // of method

        public void actionPerformed(ActionEvent evt) {
            //// 1.1. If we are finished...
            if (JWizardPanel.FINISHED.equalsIgnoreCase(p.getNextState())) {
                JWizard.this.dispose();
                fireOnFinish();
            }
            //// 1.2. Otherwise...
            else {
                layout.show(JWizard.this.getContentPane(), p.getNextState());
            }
        } // of method
    } // of inner class


    /**
     * Listens for "back" button presses.
     */
    class BackActionListener implements ActionListener {
        JWizardPanel p;

        public BackActionListener(JWizardPanel newp) {
            p = newp;
        } // of method

        public void actionPerformed(ActionEvent evt) {
            layout.show(JWizard.this.getContentPane(), p.getBackState());
        } // of method
    } // of inner class


    /**
     * Closes the wizard window.
     */
    class CancelActionListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
            JWizard.this.dispose();
            fireOnCancel();
        } // of method
    } // of inner class

    //----------------------------------------------------------------

    /**
     * A panel that has back, next, and cancel on it.
     */
    class WizardActionPanel extends JPanel {
        JWizardPanel         wiz;
        JButton              buttonBack;
        JButton              buttonNext;
        JButton              buttonCancel;

        public WizardActionPanel(JWizardPanel newWiz) {
            //// 1. Save the reference to the wizard panel we control.
            setLayout(new FlowLayout(FlowLayout.RIGHT));
            wiz = newWiz;

            //// 2. Setup the back button.
            buttonBack = new JButton("< Back");
            if (newWiz.isBackEnabled() == false) {
                buttonBack.setEnabled(false);
            }

            //// 3. Setup the next button.
            if (JWizardPanel.FINISHED.equalsIgnoreCase(newWiz.getNextState())) {
                buttonNext = new JButton("Finished");
            }
            else {
                buttonNext = new JButton("Next >");
            }

            if (newWiz.isNextEnabled() == false) {
                buttonNext.setEnabled(false);
            }

            //// 4. Setup the cancel button.
            buttonCancel = new JButton("Cancel");

            //// 5. Setup UI.
            add(new JLabel("                  "));
            add(buttonBack);
            add(buttonNext);
            add(new JLabel("   "));
            add(buttonCancel);
        } // of constructor

        //------------------------------------------------------------

        /**
         * Get the back button. Useful for adding listeners.
         */
        public JButton getBackButton() {
            return (buttonBack);
        } // of method

        /**
         * Get the next button. Useful for adding listeners.
         */
        public JButton getNextButton() {
            return (buttonNext);
        } // of method

        /**
         * Get the cancel button. Useful for adding listeners.
         */
        public JButton getCancelButton() {
            return (buttonCancel);
        } // of method
    } // of inner class

    //===   GUI SETUP   ========================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    // First panel of the Wizard
    static class MainPanel extends JWizardPanel {
        JRadioButton optionA;
        JRadioButton optionB;

        public MainPanel() {
            //// 1. "Main" is the name of this panel.
            ////    Have to name it, to know what state to transition from / to
            super("Main");
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

            //// 2. Setup the GUI model. Arbitrary code here.
            ButtonGroup grp = new ButtonGroup();
            optionA = new JRadioButton("A");
            optionB = new JRadioButton("B");
            optionA.addItemListener(new MyItemListener());
            optionB.addItemListener(new MyItemListener());
            grp.add(optionA);
            grp.add(optionB);

            //// 3. Setup the GUI display. Arbitrary code here.
            add(new JLabel("Choose an option:"));
            add(optionA);
            add(optionB);

            //// 4. Set the next to be disabled by default.
            ////    Wait until something has been selected.
            setNextEnabled(false);
        } // of contructor

        // Get what state we should move to when "Next" is selected
        public String getNextState() {
            if (optionA.isSelected() == true) {
                return ("A");
            }
            if (optionB.isSelected() == true) {
                return ("B");
            }
            return (null);
        } // of method

        // Listen to changes in the state of the wizard and then enable
        // the "Next" button. Not a compelling example here, but you should
        // be able to see how you can check the current state of the wizard
        // and make sure that it's in a good state before allowing the 
        // end-user to go to the next state
        class MyItemListener implements ItemListener {
            public void itemStateChanged(ItemEvent evt) {
                setNextEnabled(true);
            } // of method
        } // of inner inner class
    } // of inner class


    // Panel displayed if option A is selected
    static class OptionAPanel extends JWizardPanel {
        public OptionAPanel() {
            super("A");
            add(new JLabel("OptionA panel"));
        } // of constructor

        // Signify that this is a finished state
        public String getNextState() {
            return (JWizardPanel.FINISHED);
        } // of method

        // Where to go back to
        public String getBackState() {
            return ("Main");
        } // of method
    } // of inner class


    // Panel displayed if option B is selected
    static class OptionBPanel extends JWizardPanel {
        public OptionBPanel() {
            super("B");
            add(new JLabel("OptionB panel"));
        } // of constructor

        // Signify that this is a finished state
        public String getNextState() {
            return (JWizardPanel.FINISHED);
        } // of method

        // Where to go back to
        public String getBackState() {
            return ("Main");
        } // of method
    } // of inner class


    // Listens to messages from the wizard
    // Not a compelling example, but you should be able to see how to 
    // tailor a response from the Wizard upon completion or cancellation.
    static public class Listener implements JWizardListener {
        public void onFinish() {
            System.out.println("Wizard finished");
        } // of method

        public void onCancel() {
            System.out.println("Wizard cancelled");
        } // of method
    } // of inner class


    // Run the wizard
    public static void main(String[] argv) {
        JWizard wiz;

        //// 1. Setup the Wizard GUI.
        wiz = new JWizard();
        wiz.addPanel(new MainPanel());
        wiz.addPanel(new OptionAPanel());
        wiz.addPanel(new OptionBPanel());

        //// 2. Add a listener.
        wiz.addListener(new Listener());

        //// 3. Display the wizard and go.
        wiz.setVisible(true);
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
