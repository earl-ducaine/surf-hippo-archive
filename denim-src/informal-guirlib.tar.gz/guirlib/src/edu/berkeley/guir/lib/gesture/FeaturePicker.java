package edu.berkeley.guir.lib.gesture;

import java.awt.BorderLayout;
import java.awt.ItemSelectable;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.EventListenerList;

/**
 * Emits ItemEvents when a feature is selected or deselected.  The
 * item field is an Integer that indicates which feature was
 * (de)selected.
 */
public class FeaturePicker extends JFrame implements ItemSelectable
{
  static FeatureVector fv = new FeatureVector();
  JCheckBox checkBoxes[];
  protected EventListenerList itemListenerList = new EventListenerList();
  int numSelected;
  
  public FeaturePicker()
  {
    super();
    buildUI();
  }

  public FeaturePicker(String name)
  {
    super(name);
    buildUI();
  }

  void buildUI()
  {
    int numRows = fv.size();
    checkBoxes = new JCheckBox[numRows];

    Box contents = Box.createVerticalBox();

    for (int i = 0; i < numRows; i++) {
      checkBoxes[i] = new JCheckBox(Integer.toString(i) + " " +
				    fv.getFeature(i).getName());

      checkBoxes[i].addItemListener(new CheckBoxListener(i));
      checkBoxes[i].setSelected(true);
      contents.add(checkBoxes[i]);
    }
    numSelected = numRows;
    getContentPane().setLayout(new BorderLayout());

    JScrollPane scrollPane = new JScrollPane(contents);
    getContentPane().add(scrollPane, BorderLayout.CENTER);

    JButton b = new JButton("Close");
    ActionListener l = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	dispose();
      }
    };
    b.addActionListener(l);
    getContentPane().add(b, BorderLayout.SOUTH);
  }

  public void setFeatureSelected(int featureNum, boolean on)
  {
    checkBoxes[featureNum].setSelected(on);
  }

  public boolean isFeatureSelected(int featureNum)
  {
    return checkBoxes[featureNum].isSelected();
  }

  public int getNumSelected()
  {
    return numSelected;
  }
  
  public class CheckBoxListener implements ItemListener
  {
    int cbNum;

    CheckBoxListener(int n)
    {
      cbNum = n;
    }
    
    public void itemStateChanged(ItemEvent e)
    {
      if (e.getStateChange() == ItemEvent.SELECTED)
	numSelected++;
      else
	numSelected--;
      fireItemChange(ItemEvent.ITEM_STATE_CHANGED, cbNum,
		     e.getStateChange());
    }
  }
  
  public void addItemListener(ItemListener l)
  {
    itemListenerList.add(ItemListener.class, l);
  }

  public void removeItemListener(ItemListener l)
  {
    itemListenerList.remove(ItemListener.class, l);
  }

  protected void fireItemChange(int type, int featureNum, int selectState)
  {
    ItemEvent event = null;
    Object[] listeners = itemListenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ItemListener.class) {
	if (event == null)
	  event = new ItemEvent(this, type, new Integer(featureNum),
				selectState);
	((ItemListener)listeners[i+1]).itemStateChanged(event);
      }
    }
  }

  /**
   * Returns an array of Integers, the indices of the selected features
   */
  public Object[] getSelectedObjects()
  {
    Object result[] = new Object[numSelected];
    int ri = 0;
    for (int i = 0; i < checkBoxes.length; i++) {
      if (checkBoxes[i].isSelected())
	result[ri++] = new Integer(i);
    }
    return result;
  }
  
  public static void main(String args[])
  {
    FeaturePicker fp = new FeaturePicker("FeaturePicker test");

    WindowListener l = new WindowAdapter() {
      public void windowClosed(WindowEvent e) {System.exit(0);}
      public void windowClosing(WindowEvent e) {System.exit(0);}
    };
    fp.addWindowListener(l);

    fp.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e)
      {
	Object o[] = e.getItemSelectable().getSelectedObjects();
	System.out.print("Current selection:");
	for (int i = 0; i < o.length; i++)
	  System.out.print(" " + o[i]);
	System.out.println();
      }
    });

    fp.pack();
    //fp.setSize(new Dimension(500, 500));
    fp.show();
  }
}
