package edu.berkeley.guir.denim;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.*;
import java.awt.image.*;

/**
 * The user interface of the entire Denim application. See the
 * <a href="http://guir.berkeley.edu/projects/denim/">Denim</a> project page
 * for details.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-08-2001 Shengdong Zhao <sszhao@sims.berkeley.edu>
 *                               Created RadarViewPanel.java
 *                    05-24-2002 Liane Beckman
 *                               Redid the transforms
 *                    06-03-2002 James Lin
 *                               Separated the transform calculation into its
 *                               own method
 * 					  12-16-2002 Yang Li
 * 								 Employed buffered image of Sheet to render RadarView to improve the performance
 *                               
 * </PRE>
 *
 * @author  Shengdong Zhao
 * @author  Liane Beckman
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 1.1.0, 12-16-2002
 */
public class RadarViewPanel extends JPanel {
   
   //===========================================================================
   //===   CONSTANTS  ==========================================================
   
   public static final int INITIAL_WIDTH  = 200;
   public static final int INITIAL_HEIGHT = 200;
   
   private BufferedImage pictureOfSceneGraph = null;
   
   public static final double SHRINK_FACTOR = 2.0;
   
   // 3 pixel wide stroke for drawing the crosshair
   private static final Stroke CROSSHAIR_STROKE = new BasicStroke(3);

   //===   CONSTANTS  ==========================================================
   //===========================================================================
   



   
   //===========================================================================
   //===   INSTANCE VARIABLES ==================================================
   
   private DenimSheet sheet;
   private Point2D cursorLocation = null;
   private static boolean isRendering = false;
   
   private Rectangle2D radarArea = null;
   private BufferedImage radarImage = null;

   //===   INSTANCE VARIABLES ==================================================
   //===========================================================================






   //===========================================================================
   //===   INNER CLASS MOUSE LISTENERS   =======================================

   /**
    * Listens to mouse events on the <i>sheet</i>, not the radar view itself.
    */   
   class SheetMouseListener implements MouseListener,
                                       MouseMotionListener {
                              
      private float     oldX = 0;   // for the cursor
      private float     oldY = 0;
      private float     newX = 0;
      private float     newY = 0;

      private Point2D   startPt;    // for dragging
      private Point2D   endPt;


      public void mouseClicked(MouseEvent evt) {}

      public void mouseEntered(MouseEvent evt) {
         drawCursor(evt);
         RadarViewPanel.this.repaint();
      }

      public void mouseExited(MouseEvent evt) {
         cursorLocation = null;
         RadarViewPanel.this.repaint();
      }
                              
      public void mouseDragged(MouseEvent evt) {
          drawCursor(evt);
      } // of method

      public void mouseMoved(MouseEvent evt) {
          drawCursor(evt);
      } // of method

      public void mousePressed(MouseEvent evt) {
          startPt = sheetToRadarCoordinates(evt.getPoint());
      } // of method

      public void mouseReleased(MouseEvent evt) {
          endPt = sheetToRadarCoordinates(evt.getPoint());

          Rectangle2D rect = GeomLib.makeRectangle(startPt, endPt, 9); 
          RadarViewPanel.this.repaint((int) rect.getX(),
                                      (int) rect.getY(),
                                      (int) rect.getWidth(),
                                      (int) rect.getHeight());
      } // of method
 

      private void drawCursor(MouseEvent evt) {
          cursorLocation = sheetToRadarCoordinates(evt.getPoint());

          //// 2. Get the old coordinates and the new coordinates,
          ////    make a minimal rectangle for repainting.
          oldX = newX;
          oldY = newY;
          newX = (float) cursorLocation.getX();
          newY = (float) cursorLocation.getY();

          //// 3. Repaint. 9 is offset from center of crosshairs.
          Rectangle2D rect = GeomLib.makeRectangle(oldX, oldY, newX, newY, 9); 
          RadarViewPanel.this.repaint((int) rect.getX(),
                                      (int) rect.getY(),
                                      (int) rect.getWidth(),
                                      (int) rect.getHeight());
      }
   } // of inner class

   //===   INNER CLASS MOUSE LISTENERS   =======================================
   //===========================================================================
   


   
   
   //===========================================================================
   //===   CONSTRUCTORS   ======================================================
   
   public RadarViewPanel(DenimSheet sh) {
      this.sheet = sh;
      SheetMouseListener mL = new SheetMouseListener();
      sheet.addMouseListener(mL);
      sheet.addMouseMotionListener(mL);
      
      this.addMouseMotionListener(new MouseMotionAdapter() {
          
          /*public void mouseMoved(MouseEvent evt) {
              slideWindow(evt, false);
          }*/
          
          public void mouseDragged(MouseEvent evt) {
              slideWindow(evt, true);
          }
      });

      this.addMouseListener(new MouseAdapter() {
          
          public void mousePressed(MouseEvent evt) {
              slideWindow(evt, true);
          }
          
      	  public void mouseReleased(MouseEvent evt) {

			Rectangle2D rect = RadarViewPanel.this.getBounds();
			
			double deltax = rect.getCenterX() - evt.getX();
			double deltay = rect.getCenterY() - evt.getY();
						
			double scaleX =
			   (getWidth() / SHRINK_FACTOR) /
			   (double)getSheet().getWidth();
			double scaleY =
			   (getHeight() / SHRINK_FACTOR) /
			   (double)getSheet().getHeight();
			   
			double scale = Math.min(scaleX, scaleY);
			
			AffineTransform tx = new AffineTransform();
			tx.translate(deltax/scale, deltay/scale);
			//sheet.applyTransform(tx);
			
			AffineTransform[] txArray;
			txArray = AffineTransformLib.animateSlowInSlowOut(tx, 8);
			
        	sheet.setSheetPanning(true);
        	GraphicalObjectLib.animate(sheet, txArray);	
        	sheet.setSheetPanning(false);
            sheet.damage(SatinConstants.DAMAGE_NOW);
      	 }
      });
   }
      
   //===   CONSTRUCTORS   ======================================================
   //===========================================================================





   //===========================================================================
   //===   METHODS   ===========================================================

   /**
    * Returns the sheet that is associated with this radar view.
    */
   public DenimSheet getSheet() {
      return sheet;
   }

   //-----------------------------------------------------------------

   /**
    * Convert a point from the Sheet's coordinates to the inner box of
    * the Radar's coordinates.
    *
    * For example, this method is used to display the mouse cursor 
    * so it appears in the right place within the tiny box.
    *
    * @param ptSheet is transformed in place.
    */
   private Point2D sheetToRadarCoordinates(Point2D ptSheet) {
       //// 1. Get the location of the mouse cursor
       ////    and change it to this radar view's coordinate system.
       Point2D ptRadar = ptSheet;
       sheet.getInverseTransform(SatinConstants.COORD_ABS).transform(
               ptSheet, ptRadar);

       getTransform().transform(ptRadar, ptRadar);
       return (ptRadar);
   } // of method
   
   private void slideWindow(MouseEvent evt, boolean pressed) {
       
       if(radarImage==null)
           return;

       Rectangle2D r = new Rectangle2D.Double(
               evt.getX()-radarArea.getWidth()/2, 
               evt.getY()-radarArea.getHeight()/2,
               radarArea.getWidth(), 
               radarArea.getHeight());
      
       Graphics2D g2d = (Graphics2D)radarImage.createGraphics();
       
       g2d.drawImage(pictureOfSceneGraph, 0, 0, RadarViewPanel.this);

       // draw current area
       if(pressed)
           g2d.setColor(new Color(160,130,130));
       else
           g2d.setColor(Color.red);
       g2d.draw(radarArea);
       
       // draw selecting area
       g2d.setStroke(new BasicStroke(3));
       g2d.setColor(new Color(120,180,100));
       g2d.draw(r);
       
       g2d.dispose();
       RadarViewPanel.this.getGraphics().drawImage(radarImage, 0, 0, RadarViewPanel.this);
   }

   //-----------------------------------------------------------------
   
   static public boolean isRadarViewRendering() {
      return RadarViewPanel.isRendering;
   }
   
   //-----------------------------------------------------------------

   /**
    * @param rect is in the original sheet's coordinate system.
    *             Value null means repaint everything.
    *             If the rect area is beyond a threshold, then repaint all.
    */
   public void damageRadar(Rectangle2D rect) {
       //// 1. Check if we should repaint everything.
       if (rect == null) {
           repaint();
           return;
       }

       //// 2. Otherwise, transform rect and repaint just that area.
       Point2D ptAA = new Point2D.Double(rect.getX(), 
                                         rect.getY());
       Point2D ptBB = new Point2D.Double(rect.getX() + rect.getWidth(), 
                                         rect.getY() + rect.getHeight());

       ptAA = sheetToRadarCoordinates(ptAA);
       ptBB = sheetToRadarCoordinates(ptBB);

       repaint((int) ptAA.getX(),
               (int) ptAA.getY(),
               (int) (ptBB.getX() - ptAA.getX()),
               (int) (ptBB.getY() - ptAA.getY())  );

   } // of method

   //-----------------------------------------------------------------

   private AffineTransform getTransform() {
      // Find the bounds of the sheet displayed in the main view in local
      // coordinates.
      Rectangle2D sheetMainSheetBds =
         sheet.getBounds2D(SatinConstants.COORD_LOCAL);

      // Find the width and height of the radarViewPanel in pixel coordinates.
      int radarPixelWidth = getWidth(), radarPixelHeight = getHeight();

      // Get the transform between the sheet and the "main" camera.
      AffineTransform tx = sheet.getTransform(SatinConstants.COORD_ABS);

	  // Bail out if the RadarViewPanel is hidden.  Why is this being called then?
	  if (radarPixelWidth==0 && radarPixelHeight==0) {
	  	return tx;
	  }
	  
      // Shrink the sheet viewed in the radar view so that:
      // * You can see at least SHRINK_FACTOR times as much of the sheet
      //   in the radar view in either dimension
      // * It will fit within the radar view window.
      double scaleX =
         (this.getWidth() / SHRINK_FACTOR) /
         (double)this.getSheet().getWidth();
      double scaleY =
         (this.getHeight() / SHRINK_FACTOR) /
         (double)this.getSheet().getHeight();
      double scale = Math.min(scaleX, scaleY);
      
      tx.preConcatenate(AffineTransform.getScaleInstance(scale, scale));

      // Find the local sheet coordinates corresponding to the upper left
      // and lower right-hand corners of the radar view.
      Point2D radarLowerRightPixel =
          new Point2D.Double(radarPixelWidth, radarPixelHeight);
      Point2D radarUpperLeftPixel = new Point2D.Double(0, 0);
      Point2D radarLowerRightSheet = null;
      Point2D radarUpperLeftSheet = null;

      try {
         radarLowerRightSheet = tx.inverseTransform(radarLowerRightPixel,
                                                    radarLowerRightSheet);
         radarUpperLeftSheet = tx.inverseTransform(radarUpperLeftPixel,
                                                   radarUpperLeftSheet);
                                                   
         // Translate the sheet in the radar to the center (simple geometry):
         //   find sheet coordinates of the middle of the radar then subtract 
         //   off half of the sheet's width or height.
         AffineTransform trans =
            AffineTransform.getTranslateInstance(
               (radarLowerRightSheet.getX() - radarUpperLeftSheet.getX()) / 2 -
                  sheetMainSheetBds.getWidth() / 2,
               (radarLowerRightSheet.getY() - radarUpperLeftSheet.getY()) / 2 -
                  sheetMainSheetBds.getHeight() / 2);
         //System.out.println("trans: " + DenimUtils.toShortString(trans));
   
         tx.concatenate(trans);
      } catch (NoninvertibleTransformException e) {
         assert false: "transform of RadarViewPanel is not invertible";
      }
      
      return tx;
   }
   

   //-----------------------------------------------------------------

   /**
    * Paints the contents of the radar view.
    */
   public void paintComponent(Graphics g){

      if(pictureOfSceneGraph==null||
      		pictureOfSceneGraph.getWidth()!=this.getWidth()||
      		pictureOfSceneGraph.getHeight()!=this.getHeight())
      {
      	  pictureOfSceneGraph = (BufferedImage)this.createImage(this.getWidth(),this.getHeight());
          radarImage = (BufferedImage)this.createImage(this.getWidth(),this.getHeight());
   	  	  sheet.setShouldUpdateRadarView(true);
      }
      
	  SatinGraphics graphics = new SatinGraphics();
	  
      if(sheet.shouldUpdateRadarView())
      {
		  Graphics2D bufferGraphics = pictureOfSceneGraph.createGraphics();
		 
        bufferGraphics.setClip(new Rectangle2D.Double(0, 0, this.getWidth(), this.getHeight()));//g.getClip());
		  
		  graphics.setGraphics((Graphics2D) bufferGraphics);
		
		  //// 1. Clear out the background.
		  graphics.setBackground(this.sheet.getBackground());
		  graphics.clearRect(0, 0, getWidth(), getHeight());
		
		  //// 2. Set hints for fastest rendering.
		  graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
		                      RenderingHints.VALUE_ANTIALIAS_OFF);
		  graphics.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
		                      RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
		  graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
		                      RenderingHints.VALUE_ANTIALIAS_OFF);
		  graphics.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,
		                      RenderingHints.VALUE_COLOR_RENDER_SPEED);
		  graphics.setRenderingHint(RenderingHints.KEY_DITHERING,
		                      RenderingHints.VALUE_DITHER_DISABLE);
		  graphics.setRenderingHint(RenderingHints.KEY_RENDERING,
		                      RenderingHints.VALUE_RENDER_SPEED);
		  graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
		                      RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		  graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
		                      RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
		  graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
		                      RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
		
		  // draw radarview by buffered image of sheet                          
		/*      if(sheet.getBufferedImage()!=null)
		      {
			      graphics.drawImage(sheet.getBufferedImage(), 0, 0, this.getWidth(), this.getHeight(), Color.white, this);
		      }
		*/            
         
         AffineTransform tx = getTransform();
         graphics.pushTransform(tx);      
	      
	      // Draw the sheet itself.
      
         sheet.setShouldUpdateRadarView(false);
   	  	
         RadarViewPanel.isRendering = true;
         sheet.render(graphics);
         RadarViewPanel.isRendering = false;

         bufferGraphics.dispose();
         
         //clear up sheet
         sheet.repaint();
      }
   	  
      g.drawImage(pictureOfSceneGraph, 0, 0, this);
   	  
      drawAreaIcon(g);

   }
   
   private void drawAreaIcon(Graphics g) {

	  SatinGraphics graphics = new SatinGraphics();
 	  graphics.setGraphics((Graphics2D)g);

	  AffineTransform tx = getTransform();
	  graphics.pushTransform(tx);      

	  //// 2. Set hints for fastest rendering.
	  graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
	                      RenderingHints.VALUE_ANTIALIAS_OFF);
	  graphics.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
	                      RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
	  graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
	                      RenderingHints.VALUE_ANTIALIAS_OFF);
	  graphics.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,
	                      RenderingHints.VALUE_COLOR_RENDER_SPEED);
	  graphics.setRenderingHint(RenderingHints.KEY_DITHERING,
	                      RenderingHints.VALUE_DITHER_DISABLE);
	  graphics.setRenderingHint(RenderingHints.KEY_RENDERING,
	                      RenderingHints.VALUE_RENDER_SPEED);
	  graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
	                      RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
	  graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
	                      RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
	  graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
	                      RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);

  	  // Draw a red rectangle indicating the part of the sheet visible
      // in the main window.
      graphics.setColor(Color.red);
      Rectangle2D sheetMainSheetBds =
         sheet.getBounds2D(SatinConstants.COORD_LOCAL);
      graphics.draw(sheetMainSheetBds);
      radarArea = GeomLib.transformRectangle(graphics.getTransform(), sheetMainSheetBds);
      graphics.popTransform();
      
      // Draw crosshairs representing the location of the cursor in the 
      // main window
      if (cursorLocation != null) {
         int cursorX = (int)cursorLocation.getX();
         int cursorY = (int)cursorLocation.getY();
         
         graphics.setStroke(CROSSHAIR_STROKE);
         graphics.drawLine(cursorX - 2, cursorY, cursorX - 6, cursorY);
         graphics.drawLine(cursorX + 2, cursorY, cursorX + 6, cursorY);
         graphics.drawLine(cursorX, cursorY + 2, cursorX, cursorY + 6);
         graphics.drawLine(cursorX, cursorY - 2, cursorX, cursorY - 6);
      }
	  
   }
   
   //===   METHODS   ===========================================================
   //===========================================================================
   
} // class RadarViewPanel

//==============================================================================

/*
Copyright (c) 2001-02 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
