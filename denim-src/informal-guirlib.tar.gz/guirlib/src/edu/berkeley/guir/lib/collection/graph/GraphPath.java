//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * An object representing a GraphPath in a Graph.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Nov 04 1997, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.5/1.2.0, Nov 26 2002, JH
 *               Updated code for new Graph APIs
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.3RC1
 * @version GUIRLib-v1.5/1.2.0, Nov 22 2002
 */
public class GraphPath 
   implements Serializable, Cloneable {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //// Place holder for the default weight.
   private final static Float DEFAULT_WEIGHT_OBJECT = 
                                         new Float(GraphConst.DEFAULT_WEIGHT);

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   //// list of Nodes to take
   LinkedList listNodes = new LinkedList();

   //// list of the weights
   LinkedList listWeights = new LinkedList();

   //// temporary table used in isCycle() method only
   HashMap mapNodesTemp = new HashMap();

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create a new empty Path.
    */
   public GraphPath() {
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================





   //===========================================================================
   //===   ITERATOR INNER CLASSES   ============================================

   /**
    * Go through the list backwards.
    */
   class ReverseIterator implements Iterator {

      List list;
      int  index;

      //--------------------------------------------------------------

      public ReverseIterator(List list) {
         this.list  = list;
         this.index = list.size() - 1;
      } // of constructor

      //--------------------------------------------------------------

      public boolean hasNext() {
         return (index >= 0);
      } // of hasNext

      //--------------------------------------------------------------

      public Object next() {
         return (list.get(index--));
      } // of next

      //--------------------------------------------------------------

      public void remove() {
         list.remove(index);
      } // of remove

      //--------------------------------------------------------------

   } // of inner class

   //===   ITERATOR INNER CLASSES   ============================================
   //===========================================================================





   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /** 
    * Return the list of Nodes.
    *
    * @return an Iterator that contains the GraphNodes in this GraphPath.
    */
   public Iterator getNodes() {
      return (listNodes.iterator());
   } // of method

   //-----------------------------------------------------------------

   /** 
    * Return the list of Nodes in reverse order.
    *
    * @return an Iterator that contains the GraphNodes in this GraphPath
    *         in reverse order.
    */
   public Iterator getNodesReversed() {
      return (new ReverseIterator(listNodes));
   } // of method

   //-----------------------------------------------------------------

   /** 
    * Return the list of weights.
    *
    * @return an Iterator that contains Floats, which represent the
    * weights.
    */
   public Iterator getWeights() {
      return (listWeights.iterator());
   } // of method

   //-----------------------------------------------------------------

   /** 
    * Return the list of weights.
    *
    * @return an Iterator that contains Floats, which represent the
    * weights.
    */
   public Iterator getWeightsReversed() {
      return (new ReverseIterator(listWeights));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Sum the weight in the Path.
    *
    * @return the weight of the Path.
    */
   public float totalWeight() {
      float dSumWeight = 0;
      Float floatWeight;

      for (Iterator it = getWeights(); it.hasNext(); ) {
         floatWeight = (Float) it.next();
         dSumWeight  += floatWeight.floatValue();
      }

      return (dSumWeight);
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if there is a cycle in the Path.
    *
    * @return true if there is a cycle, false otherwise.
    */
   public boolean isCycle() {
      Object node;            // a temporary handle to an element in the list

      //// 1. Clear out all the elements in the temporary table
      mapNodesTemp.clear();

      //// 2. Run through the list of Nodes in our path and see if there 
      ////    are any duplicates
      for (Iterator it = getNodes(); it.hasNext(); ) {
         node = it.next();
         if (mapNodesTemp.get(node) != null)
            return (true);
         else
            mapNodesTemp.put(node, Boolean.TRUE);
      }

      return (false);
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if the specified GraphNode is contained in this Adjacency List.
    *
    * @param node is the GraphNode to check if for in this Adjacency List.
    */
   public boolean contains(GraphNode node) {
      return ( contains(node.getName()) );
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if the specified GraphNode is contained in this Adjacency List.
    *
    * @param strNodeName is the Node to check if for in this Adjacency List.
    */
   public boolean contains(String strNodeName) {
      for (Iterator it = getNodes(); it.hasNext(); ) {
         GraphNode node = (GraphNode) it.next();
         if (strNodeName.equals(node.getName())) {
            return (true);
         }
      }

      return (false);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the last GraphNode added to this Path.
    *
    * @return the name of the last Node, or null if there are no Nodes.
    */
   public GraphNode getLastNode() {
      int size = listNodes.size();
      if (size == 0) {
         return (null);
      }
      else {
         return ((GraphNode) listNodes.getLast());
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the length of the path.
    *
    * @return the length of the path, nonnegative.
    */
   public int length() {
      return (listNodes.size());
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================





   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Add a GraphNode to the end of the Path.
    * The weight is defaulted to GraphConst.DEFAULT_WEIGHT.
    *
    * <P>
    * Currently no runtime checks are done to ensure that this edge is valid or
    * even connects correctly in the Path. 
    *
    * @see   GraphConst
    * @param node is the GraphNode to add to the end of the Path.
    */
   public void addNode(GraphNode node) {
      addNode(node, DEFAULT_WEIGHT_OBJECT);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a GraphNode to the end of the Path.
    *
    * <P>
    * Currently no runtime checks are done to ensure that this edge is valid or
    * even connects correctly in the Path. 
    *
    * @param node is the GraphNode to add to the end of the Path.
    * @param weight is the weight of the edge taken. Note that the weight
    *        is meaningless if it is the first node in a Path, and will
    *        thus be ignored.
    */
   public void addNode(GraphNode node, float weight) {
      addNode(node, new Float(weight));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a GraphNode to the end of the Path.
    * The weight is defaulted to GraphConst.DEFAULT_WEIGHT.
    *
    * <P>
    * Currently no runtime checks are done to ensure that this edge is valid or
    * even connects correctly in the Path. 
    *
    * @see   GraphConst
    * @param node is the GraphNode to add to the end of the Path.
    * @param fWeight is the weight of the edge taken.
    */
/*
   public void addNode(String strNodeName, float weight) {

      addNode(strNodeName, new Float(weight));

   } // of addNode
*/
   //-----------------------------------------------------------------

   /**
    * Remove the last GraphNode added from the Path.
    */
   public void removeLastNode() {
      int index;

      // "Number of nodes (" + listNodes.size() + ") and 
      // number of weights (" + listWeights.size() + ") does not match");
      // assert ((listNodes.size() - 1) == listWeights.size() || 
      //          listNodes.size() == 0);

      //// 1. Remove the last GraphNode added
      index = listNodes.size() - 1;
      if (index >= 0) {
         listNodes.removeLast();

         //// 2. The number of weights we have is always one less than
         ////    the number of Nodes
         if (index >= 1) {
            listWeights.removeLast();
         }
      }
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   PRIVATE METHODS   ===================================================

   /**
    * Add a GraphNode to the end of the GraphPath.
    *
    * @see   GraphConst
    * @param node is the GraphNode to add to the end of the Path.
    */
   public void addNode(GraphNode node, Float weight) {
      // node is a null reference
      // assert node != null; 
      // weight is a null reference
      // assert node != null; 

      //// 1. Check if there are already elements in the Path. It is
      ////    meaningless to add in a weight with only one node.
      if (listNodes.size() > 0) {
         listWeights.add(weight);
      }

      //// 2. Add in the GraphNode itself to the Path.
      listNodes.add(node);
   } // of method

   //===   PRIVATE METHODS   ===================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   /*
    * Convert this object into some form of String.
    *
    * @return a String containing information about this object.
    */
   public String toString() {
      Iterator     itWeights    = getWeights();
      Iterator     itNodes      = getNodes();
      StringBuffer strbufReturn = new StringBuffer("[");
      GraphNode    node;

      try {
         while (itNodes.hasNext()) {
            node = (GraphNode) itNodes.next();
            strbufReturn.append("\n");
            strbufReturn.append("  " + node.getName());
            strbufReturn.append(" (" + itWeights.next() + ") ->");
         }
      }
      catch (NoSuchElementException e) {
         //// Yes, this is a hack, but a fairly effective one.
         //// This part of the code will always be reached since there
         //// is one less element in enumWeights than in enumNodes.
         //// Since this code won't often be used, it isn't that much of
         //// a performance issue. Also, it is much cleaner to write than
         //// having to do the various if-then checks.
         strbufReturn.append("\n");
      }
      catch (Exception e) {
         return("[exception]");
      }

      strbufReturn.append("]");

      return (strbufReturn.toString());
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Shallowly clones this Path.
    *
    * @return a GraphPath object that has the same values 
    *         as this GraphPath instance.
    */
   public Object clone() {
      GraphPath cloned = new GraphPath();   // the cloned Path

      //// 1. Copy the GraphPath list
      cloned.listNodes = new LinkedList(this.listNodes);

      //// 2. Copy the weights list
      cloned.listWeights = new LinkedList(this.listWeights);

      return(cloned);      
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   EQUALS   ============================================================

   /*
    * This method checks if a given object is the "same" as this one.
    *
    * @param obj is the Object to check for equality.
    */
   public boolean equals(Object obj) {
      if (obj instanceof GraphPath) {
         GraphPath temp = (GraphPath) obj;

         int len;
         try {
            //// 1. See if the GraphNode lists match.
            len = listNodes.size();
            for (int i = 0; i < len; i++) {
               if (!listNodes.get(i).equals(temp.listNodes.get(i))) {
                  return (false);
               }
            }

            //// 2. See if the Weight lists match.
            len = listWeights.size();
            for (int i = 0; i < len; i++) {
               if (!listWeights.get(i).equals(temp.listWeights.get(i))) {
                  return (false);
               }
            }
         }
         catch (Exception e) {
            //// different sized lengths?
            return (false);
         }

         return (true);
      }

      return(false);
   } // of method

   //===   EQUALS   ============================================================
   //===========================================================================

   
   
   //===========================================================================
   //===   MAIN    =============================================================

/*
   //
   // This is a concept known as self-testing objects.
   // The object contains methods for testing that it is correct.
   //
   // The code below is simply testing the functionality of this object.
   //
   public static void main(String[] argv) {

      GraphPath p = new Path();



      Node n1 = new Node("http://www.sims.berkeley.edu/");
      Node n2 = new Node("http://www.sims.berkeley.edu/people/faculty.html");
      Node n3 = new Node("http://www.sims.berkeley.edu/~hearst/");

      p.addNode(n1);
      p.addNode(n2);
      p.addNode(n3);

      //// Test the cloning procedures
      GraphPath p2 = (Path) p.clone();
      System.out.println(p);
      System.out.println(p2);
      System.out.println();

      System.out.println(p2.equals(p));
      System.out.println();

      p.addNode(new Node("a"));
      p.addNode(new Node("b"), 1);
      System.out.println(p);
      System.out.println(p2);



      //// Test the GraphPath routines
      p = new Path();
      p.addNode(new Node("a"));
      p.addNode(new Node("b"), 1);
      p.addNode("c", 2);
      p.addNode("d", 3);
      p.addNode("e", 4);
      p.addNode("f", 5);
      System.out.println(p);
      System.out.println(p.totalWeight());
      System.out.println(p.isCycle());

      p.addNode(new Node("b"), 1);
      System.out.println(p);
      System.out.println(p.totalWeight());
      System.out.println(p.isCycle());

      p.removeLastNode();
      System.out.println(p);
      System.out.println(p.totalWeight());
      System.out.println(p.isCycle());

      p.removeLastNode();
      System.out.println(p);
      System.out.println(p.totalWeight());
      System.out.println(p.isCycle());

      p.removeLastNode();
      p.removeLastNode();
      p.removeLastNode();
      p.removeLastNode();
      System.out.println(p);
      System.out.println(p.totalWeight());
      System.out.println(p.isCycle());

      p.removeLastNode();
      System.out.println(p);
      System.out.println(p.totalWeight());
      System.out.println(p.isCycle());

   } // of main
*/

   //===   MAIN    =============================================================
   //===========================================================================

} // of Class Path


/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
