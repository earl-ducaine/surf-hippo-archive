package edu.berkeley.guir.denim.components;

import edu.berkeley.guir.denim.toolbox.RubberStamp;
//import edu.berkeley.guir.lib.debugging.Debug;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollection;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

/**
 * @author shen
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class DenimListBox extends DenimIntrinsicComponent {

    final static long uniqueID = 26;
    
   //===========================================================================
   //===   CONSTANTS   =========================================================

//   static final long serialVersionUID = -8627577626259770128L;
//   private static final Debug debug = new Debug(Debug.ON);

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create a Denim list box.
    */
   DenimListBox() {
      super();

      name = "List Box";
      stamp = new RubberStamp("list_box.gif", this);
      
      this.setUniqueID(uniqueID);
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   COMPONENT METHODS   =================================================

   /**
    * Create a new instance of a list box, for use in a Denim storyboard.
    */
   public DenimComponentInstance newInstance(TimedStroke border,
                                             GraphicalObjectCollection items) {
      DenimComponentInstance instance = 
         new DenimListBoxInstance(this, border, items);
      instances.add(instance);
      return instance;
   }

   //-----------------------------------------------------------------

   /**
    * Create a new instance of a list box, for use in a Denim storyboard.
    */
   public DenimComponentInstance newInstance() {
      DenimComponentInstance instance = new DenimListBoxInstance(this);
      instances.add(instance);
      return instance;
   }


   //-----------------------------------------------------------------

   /**
    * Create a new instance of a list box.
    */
   public DenimComponentInstance newInstance(TimedStroke border,
                                             boolean createdByStamp,
                                             GraphicalObjectCollection items,
                                             int selectedIndex) {
      DenimComponentInstance instance =
         new DenimListBoxInstance(this, border, createdByStamp,
                                  items, selectedIndex);
      instances.add(instance);
      return instance;
   }

   //===   COMPONENT METHODS   =================================================
   //===========================================================================

} // of class
