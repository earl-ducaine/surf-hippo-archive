package edu.berkeley.guir.damask.view.nodes;

import java.awt.Color;
import java.awt.geom.Point2D;
import java.util.*;

import javax.swing.SwingConstants;

import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * A border that resizes the node that it is attached to.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-29-2003 James Lin
 *                               Created SizingBorder.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-29-2003
 */
public class SizingBorder extends BoundsHandle {
   
   public static final int CORNER_SIZE = 20;
   public static final int BORDER_SIZE = 5;
   public static final Color BORDER_COLOR = Color.LIGHT_GRAY;


   /**
    * Creates a sizing border with the specified locator.
    */
   public SizingBorder(PBoundsLocator aLocator) {
      super(aLocator);
      setPaint(BORDER_COLOR);
      setStrokePaint(Color.BLACK);
      relocateHandle();
   }


   /**
    * Adds sizing borders to the given node.
    */
   public static void addSizingBordersTo(PNode aNode) {
      aNode.addChild(new SizingBorder(PBoundsLocator.createEastLocator(aNode))); 
      aNode.addChild(new SizingBorder(PBoundsLocator.createWestLocator(aNode))); 
      aNode.addChild(new SizingBorder(PBoundsLocator.createNorthLocator(aNode))); 
      aNode.addChild(new SizingBorder(PBoundsLocator.createSouthLocator(aNode)));
      aNode.addChild(new SizingBorder(PBoundsLocator.createNorthEastLocator(aNode))); 
      aNode.addChild(new SizingBorder(PBoundsLocator.createNorthWestLocator(aNode))); 
      aNode.addChild(new SizingBorder(PBoundsLocator.createSouthEastLocator(aNode))); 
      aNode.addChild(new SizingBorder(PBoundsLocator.createSouthWestLocator(aNode)));    
   }


   /**
    * Removes sizing borders from the given node.
    */
   public static void removeSizingBordersFrom(PNode aNode) {
      final List handles = new ArrayList();

      for (Iterator i = aNode.getChildrenIterator(); i.hasNext(); ) {
         final PNode each = (PNode)i.next();
         if (each instanceof SizingBorder) {
            handles.add(each);
         }
      }
      aNode.removeChildren(handles);      
   }

   /**
    * Resizes this border to the right width and height, depending on the
    * attached node's width and height.
    * 
    * @param nodeWidth    the rendered width of this border's node
    * @param nodeHeight   the rendered height of this border's node
    * @param cornerWidth  the rendered width of a corner element of this node
    * @param cornerHeight the rendered height of a corner element of this node
    * @param borderSize   the width of the border element itself
    */
   protected void resizeHandle(
      double nodeWidth,
      double nodeHeight,
      float cornerWidth,
      float cornerHeight,
      float borderSize) {
      
      switch (((PBoundsLocator)getLocator()).getSide()) {
         case SwingConstants.NORTH_WEST :
            setPathToPolyline(
               new float[] { 0, cornerWidth, cornerWidth, borderSize, borderSize,   0,           0 },
               new float[] { 0, 0,           borderSize,  borderSize, cornerHeight, cornerHeight, 0 });
            break;
         case SwingConstants.NORTH_EAST :
            setPathToPolyline(
               new float[] { 0, cornerWidth, cornerWidth,  cornerWidth - borderSize, cornerWidth - borderSize, 0,          0 },
               new float[] { 0, 0,           cornerHeight, cornerHeight,             borderSize,               borderSize, 0 });
            break;
         case SwingConstants.SOUTH_WEST :
            setPathToPolyline(
               new float[] { 0, borderSize, borderSize,                cornerWidth,               cornerWidth,  0,            0 },
               new float[] { 0, 0,          cornerHeight - borderSize, cornerHeight - borderSize, cornerHeight, cornerHeight, 0 });
            break;
         case SwingConstants.SOUTH_EAST :
            setPathToPolyline(
               new float[] { 0,            0,                         cornerWidth - borderSize,  cornerWidth - borderSize, cornerWidth, cornerWidth, 0 },
               new float[] { cornerHeight, cornerHeight - borderSize, cornerHeight - borderSize, 0                       , 0,           cornerHeight, cornerHeight });
            break;

         case SwingConstants.WEST :
         case SwingConstants.EAST :
            setPathToRectangle(
               0,
               0,
               (float)borderSize,
               (float)(nodeHeight - cornerWidth + 3));
            break;

         case SwingConstants.NORTH :
         case SwingConstants.SOUTH :
            setPathToRectangle(
               0,
               0,
               (float)(nodeWidth - cornerHeight + 3),
               (float)borderSize);
      }
   }
   

   /**
    * Returns the pixel width of the node that this border is attached to,
    * as rendered by the border's constraint camera. 
    */
   protected double getNodeRenderedWidth() {
      return ((PBoundsLocator)getLocator()).getNode().getWidth();
   }


   /**
    * Returns the pixel height of the node that this border is attached to,
    * as rendered by the border's constraint camera. 
    */
   protected double getNodeRenderedHeight() {
      return ((PBoundsLocator)getLocator()).getNode().getHeight();
   }


   // Overrides method in superclass.
   public void relocateHandle() {
      double nodeWidth = getNodeRenderedWidth();
      double nodeHeight = getNodeRenderedHeight();
      float cornerWidth = CORNER_SIZE;
      float cornerHeight = CORNER_SIZE;
      
      if (CORNER_SIZE*2 > nodeWidth + BORDER_SIZE*2) {
         cornerWidth = ((float)nodeWidth + BORDER_SIZE*2) / 2;
         nodeWidth = 0;
      }
      
      if (CORNER_SIZE*2 > nodeHeight + BORDER_SIZE*2) {
         cornerHeight = ((float)nodeHeight + BORDER_SIZE*2) / 2;
         nodeHeight = 0;
      }
      
      resizeHandle(
         nodeWidth,
         nodeHeight,
         cornerWidth,
         cornerHeight,
         BORDER_SIZE);
      
      final PBoundsLocator locator = (PBoundsLocator)getLocator();
      
      final PBounds b = getBoundsReference();
      final double width = b.getWidth();
      final double height = b.getHeight();
      final Point2D aPoint = locator.locatePoint(null);
      
      final PNode located = locator.getNode();
      final PNode parent = getParent();
      
      located.localToGlobal(aPoint);
      globalToLocal(aPoint);
      
      if (parent != located && parent instanceof PCamera) {
         ((PCamera)parent).viewToLocal(aPoint);
      }
      
      final double newCenterX = aPoint.getX();
      final double newCenterY = aPoint.getY();

      if (newCenterX != b.getCenterX() || newCenterY != b.getCenterY()) {
         switch (locator.getSide()) {
            case SwingConstants.NORTH_WEST :
               setBounds(
                  newCenterX - BORDER_SIZE,
                  newCenterY - BORDER_SIZE,
                  width,
                  height);
               break;
            case SwingConstants.NORTH_EAST :
               setBounds(
                  newCenterX - cornerWidth + BORDER_SIZE - 1,
                  newCenterY - BORDER_SIZE,
                  width,
                  height);
               break;
            case SwingConstants.SOUTH_WEST :
               setBounds(
                  newCenterX - BORDER_SIZE,
                  newCenterY - cornerHeight + BORDER_SIZE - 1,
                  width,
                  height);
               break;
            case SwingConstants.SOUTH_EAST :
               setBounds(
                  newCenterX - cornerWidth + BORDER_SIZE - 1,
                  newCenterY - cornerHeight + BORDER_SIZE - 1,
                  width,
                  height);
               break;

            case SwingConstants.NORTH :
               setBounds(
                  newCenterX - width/2,
                  newCenterY - BORDER_SIZE,
                  width,
                  height);
               break;

            case SwingConstants.SOUTH :
               setBounds(
                  newCenterX - width/2,
                  newCenterY - 1,
                  width,
                  height);
               break;

            case SwingConstants.WEST :
               setBounds(
                  newCenterX - BORDER_SIZE,
                  newCenterY - height/2,
                  width,
                  height);
               break;

            case SwingConstants.EAST :
               setBounds(
                  newCenterX - 1,
                  newCenterY - height/2,
                  width,
                  height);
               break;
         }
      }
   }
}
