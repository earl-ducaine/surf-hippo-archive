//// See bottom of file for software license
package edu.berkeley.guir.lib.util;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Time utility methods.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 14 2004 JH
 */
public class TimeLib {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * Number of milliseconds in a minute.
     */
    public static final long MILLIS_MINUTE  = 60*1000L;

    /**
     * Number of milliseconds in an hour.
     */
    public static final long MILLIS_HOUR    = 60*MILLIS_MINUTE;

    /**
     * Number of milliseconds in a day.
     */
    public static final long MILLIS_DAY     = 24*MILLIS_HOUR;

    /**
     * Number of milliseconds in a week.
     */
    public static final long MILLIS_WEEK    =  7*MILLIS_DAY;

    /**
     * Number of milliseconds in a month (approximate, since
     * length of months vary).
     */
    public static final long MILLIS_MONTH   =  4*MILLIS_WEEK;

    //----------------------------------------------------------------

    /**
     * Number of seconds in a minute.
     */
    public static final long SECONDS_MINUTE = MILLIS_MINUTE / 1000;

    /**
     * Number of seconds in an hour.
     */
    public static final long SECONDS_HOUR   = MILLIS_HOUR   / 1000;

    /**
     * Number of seconds in a day.
     */
    public static final long SECONDS_DAY    = MILLIS_DAY    / 1000;

    /**
     * Number of seconds in a week.
     */
    public static final long SECONDS_WEEK   = MILLIS_WEEK   / 1000;

    /**
     * Number of seconds in a month.
     */
    public static final long SECONDS_MONTH  = MILLIS_MONTH  / 1000;

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * No instances allowed.
     */
    private TimeLib() {
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY - TIME PREDICATES   ========================================

    /**
     * See if the current time is between the two times.
     * @throws IllegalArgumentException on parsing failure.
     */
    public static boolean isBetween(String strStartTime, String strEndTime) {
        return (isBetween(new Date(), strStartTime, strEndTime));
    } // of method

    //----------------------------------------------------------------

    /**
     * @param strStartTime is something like "5:30AM" or "6PM"
     * @param strEndTime   is the same as above. Should be after strStartTime.
     * @throws IllegalArgumentException on parsing failure.
     */
    public static boolean isBetween(Date   d, 
                                    String strStartTime, 
                                    String strEndTime) {

        Calendar calendar           = new GregorianCalendar();
        int      hours;
        int      minutes;
        int      curTimeInMinutes;
        int      startTimeInMinutes = timeToMinuteOfDay(strStartTime);
        int      endTimeInMinutes   = timeToMinuteOfDay(strEndTime);

        //// 1. Get the specified Date in terms of minutes.
        calendar.setTime(d);
        hours            = calendar.get(Calendar.HOUR_OF_DAY);
        minutes          = calendar.get(Calendar.MINUTE);
        curTimeInMinutes = 60*hours + minutes;

        //// 2. Error checking.
        if (startTimeInMinutes > endTimeInMinutes) {
            throw new IllegalArgumentException("start time " + strStartTime + 
                                               " after end time " + strEndTime);
        }

        //// 3. Check if the specified Date is in between the two times.
        if (startTimeInMinutes < curTimeInMinutes &&
            curTimeInMinutes   < endTimeInMinutes) {
            return (true);
        }
        return (false);
    } // of method

    //===   UTILITY - TIME PREDICATES   ========================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY - TIME CONVERSION METHODS   ================================

    /**
     * Convert a time like "5:30AM" to the minute of the day it is,
     * in this case 5*60 + 30.
     * @param strTime is something like "5:30AM", "6PM", "12:59AM", 
     *                "12noon", "12midnight", "1400", or "12:01AM"
     * @throws IllegalArgumentException on parsing failure.
     */
    public static int timeToMinuteOfDay(String strTime) {
        int    offset     = 0;
        String strHours   = "";
        int    hours      = 0;
        String strMinutes = "";
        int    minutes    = 0;

        //// 1.1. Handle "noon" and "midnight"
        if (strTime.equals("12noon") || strTime.equals("12Noon")) {
            return (12*60);
        }
        else if (strTime.equals("12midnight") || strTime.equals("12Midnight")) {
            return (0);
        }

        //// 1.2. Handle AM / PM.
        if (strTime.endsWith("AM") == true) {
            offset = 0;
        }
        else if (strTime.endsWith("PM") == true) {
            offset = 12*60;
        }
        else {
            int    len = strTime.length();
            String strFront;
            String strEnd;

            if (len == 3) {
                strFront = strTime.substring(0, 1);
                strEnd   = strTime.substring(1);
                return (timeToMinuteOfDay(strFront + ":" + strEnd + "AM"));
            }
            else if (len == 4) {
                strFront = strTime.substring(0, 2);
                strEnd   = strTime.substring(2);
                return (timeToMinuteOfDay(strFront + ":" + strEnd + "AM"));
            }
            else {
                throw new IllegalArgumentException("Can't parse: " + strTime);
            }
        }

        //// 1.3. Clip off "AM" or "PM"
        strTime = strTime.substring(0, strTime.length() - 2);


        //// 2. Split the string into hour and minutes.
        int indexColon = strTime.indexOf(":");
        if (indexColon > 0) {
            strHours   = strTime.substring(0, indexColon);
            strMinutes = strTime.substring(indexColon + 1);
        }
        else {
            strHours   = strTime;
            strMinutes = "0";
        }


        //// 3. Parse the hour and minutes.
        try {
            hours   = Integer.parseInt(strHours);
            minutes = Integer.parseInt(strMinutes);

            //// 3.1. Make sure that the parsed values are valid.
            if (hours < 0 || minutes < 0) {
                throw new IllegalArgumentException("Can't parse: " + strTime);
            }

            if (minutes >= 60) {
                throw new IllegalArgumentException("Too many minutes: " +  
                                                                    strTime);
            }

            //// 3.2. Special case for midnight and noon.
            if (hours == 12) {
                hours = 0;
            }
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Can't parse: " + strTime);
        }

        //// 4. Return.
        return (offset + 60*hours + minutes);
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert something like "1 hour" or "2 days" into milliseconds.
     * For example:
     * <UL>
     *    <LI>"1 second"  is converted into              60*1000 milliseconds
     *    <LI>"2 seconds" is converted into            2*60*1000 milliseconds
     *    <LI>"1 minute"  is converted into         60*1000*1000 milliseconds
     *    <LI>"1 hour"    is converted into      60*60*1000*1000 milliseconds
     *    <LI>"1 day"     is converted into   24*60*60*1000*1000 milliseconds
     *    <LI>"2 days"    is converted into 2*24*60*60*1000*1000 milliseconds
     * </UL>
     * @return time in milliseconds
     * @throws IllegalArgumentException if could not parse.
     */
    public static long timespanToMillis(String strTimespan) {
        int    index = strTimespan.indexOf(" ");
        int    num;
        String strNum;
        String strTime;
        long   factor;

        //// 1. Quick error check.
        if (index < 0) {
            throw new IllegalArgumentException("No time unit? " + strTimespan);
        }

        //// 2. Extract the numeric value and time factor.
        strNum  = strTimespan.substring(0, index);
        strTime = strTimespan.substring(index + 1);

        //// 3. Figure out the numeric value.
        try {
            num = Integer.parseInt(strNum);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Not a number or out of range? " 
                                               + strNum);
        }

        //// 3. Calculate the time factor, ex. day or hour
        if (strTime.startsWith("month") == true) {
            factor = MILLIS_MONTH;
        }
        else if (strTime.startsWith("week") == true) {
            factor = MILLIS_WEEK;
        }
        else if (strTime.startsWith("day") == true) {
            factor = MILLIS_DAY;
        }
        else if (strTime.startsWith("hour") == true) {
            factor = MILLIS_HOUR;
        }
        else if (strTime.startsWith("minute") == true) {
            factor = MILLIS_MINUTE;
        }
        else if (strTime.startsWith("second") == true) {
            factor = 1000;
        }
        else {
            throw new IllegalArgumentException("Unknown time unit: " +
                                                   strTimespan);
        }

        //// 4. Calculate the time.
        return (num*factor);
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert from seconds to other units.
     * For example;
     * <UL>
     *    <LI>"86400 seconds" becomes "1 day"
     *    <LI>"86401 seconds" remains "86401 seconds"
     *    <LI>"120" seconds"  becomes "2 minutes"
     *    <LI>"121 seconds"   remains "121 seconds"
     * </UL>
     */
    public static String timespanToString(long seconds) {
        long   val;
        String strUnit;

        // System.out.println("** " + seconds);
        // System.out.println("AA " + (seconds % SECONDS_MONTH));
        // System.out.println("BB " + (seconds % SECONDS_WEEK));
        // System.out.println("CC " + (seconds % SECONDS_DAY));
        // System.out.println("DD " + (seconds % SECONDS_HOUR));
        // System.out.println("EE " + (seconds % SECONDS_MINUTE));

        //// 1. Figure out time and units.
        if (seconds % SECONDS_MONTH == 0) {
            val     = seconds / SECONDS_MONTH;
            strUnit = "month";
        }
        else if (seconds % SECONDS_WEEK == 0) {
            val     = seconds / SECONDS_WEEK;
            strUnit = "week";
        }
        else if (seconds % SECONDS_DAY == 0) {
            val     = seconds / SECONDS_DAY;
            strUnit = "day";
        }
        else if (seconds % SECONDS_HOUR == 0) {
            val     = seconds / SECONDS_HOUR;
            strUnit = "hour";
        }
        else if (seconds % SECONDS_MINUTE == 0) {
            val     = seconds / SECONDS_MINUTE;
            strUnit = "minute";
        }
        else {
            val     = seconds;
            strUnit = "second";
        }

        //// 2. Plural or singular?
        if (val == 1) {
            return ("1 " + strUnit);
        }
        else {
            return (val + " " + strUnit + "s");
        }
    } // of method

    //===   UTILITY - TIME CONVERSION METHODS   ================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY - TIME COMPARISON METHODS   ================================

    /**
     * @param d       is a date to compare.
     * @param strTime is a String describing a predicate, for example
     *                "less than 1 day old" or "less than 2 days old" or
     *                "more than 1 week"
     * @see edu.berkeley.guir.lib.util.condition.RelativeDateCondition
     */
    public static boolean compare(Date d, String strTime) {
        //// 1. Clip out the " old" portion.
        if (strTime.endsWith(" old")) {
            strTime = strTime.substring(0, strTime.length() - 4);
        }

        //// 2.1. Figure out "more than " or "less than "
        boolean flagMoreThan = false;
        if (strTime.startsWith("more than ") == true) {
            flagMoreThan = true;
        }
        else if (strTime.startsWith("less than ") == true) {
            flagMoreThan = false;
        }
        else {
            throw new IllegalArgumentException("must begin with 'more than'" + 
                                               " or 'less than': " + strTime);
        }

        //// 2.2. Clip out "more than " or "less than ".
        strTime = strTime.substring(10);

        //// 3. Get the baseline comparison time.
        long deltaTime   = timespanToMillis(strTime);
        long baseTime    = System.currentTimeMillis() - deltaTime;
        long compareTime = d.getTime();

        //// 4. Do the comparison.
        if (flagMoreThan == true) {
            return (compareTime <= baseTime);
        }
        else {
            return (compareTime >= baseTime);
        }
    } // of method

    //===   UTILITY - TIME COMPARISON METHODS   ================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY - CALENDAR METHODS   =======================================

    /**
     * Adds 24 hours from right now.
     * @return time in millis.
     */
    public static long calculateNextDay() {
        return (calculateNextDay(System.currentTimeMillis()));
    } // of method


    /**
     * Adds 24 hours to the specified time.
     * @return time in millis.
     */
    public static long calculateNextDay(long millis) {
        Calendar calendar    = new GregorianCalendar();
        calendar.setTimeInMillis(millis);
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        return (calendar.getTimeInMillis());
    } // of method

    //----------------------------------------------------------------

    /**
     * Figure out when the next midnight is starting from right now.
     * @return time in millis.
     */
    public static long calculateNextMidnight() {
        return (calculateNextMidnight(System.currentTimeMillis()));
    } // of method


    /**
     * Figure out when the next midnight is starting from the specified time.
     * @return time in millis.
     */
    public static long calculateNextMidnight(long millis) {
        Calendar calendar    = new GregorianCalendar();

        calendar.setTimeInMillis(millis);
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        calendar.set(Calendar.HOUR,         0);
        calendar.set(Calendar.MINUTE,       0);
        return (calendar.getTimeInMillis());
    } // of method

    //----------------------------------------------------------------

    /**
     * Figure out when the next Sunday midnight is starting from right now.
     * @return time in millis.
     */
    public static long calculateNextSundayMidnight() {
        return (calculateNextSundayMidnight(System.currentTimeMillis()));
    } // of method


    /**
     * Calculate the next Sunday midnight time from the specified time.
     * @return time in millis.
     */
    public static long calculateNextSundayMidnight(long millis) {
        Calendar calendar    = new GregorianCalendar();

        calendar.setTimeInMillis(millis);

        for (int i = 0; i < 7; i++) {
            int val = calendar.get(Calendar.DAY_OF_WEEK);
            if (val == Calendar.SUNDAY) {
                break;
            }
            calendar.add(Calendar.DAY_OF_YEAR, 1);
        }

        calendar.set(Calendar.HOUR,   0);
        calendar.set(Calendar.MINUTE, 0);

        return (calendar.getTimeInMillis());
    } // of method

    //----------------------------------------------------------------

    /**
     * @return time in millis.
     */
    public static long calculateNextFirstOfMonthMidnight() {
        return (calculateNextFirstOfMonthMidnight(System.currentTimeMillis()));
    } // of method


    /**
     * Calculate the next midnight that falls on first of a month.
     * @return time in millis.
     */
    public static long calculateNextFirstOfMonthMidnight(long millis) {
        Calendar calendar    = new GregorianCalendar();

        calendar.setTimeInMillis(millis);

        calendar.add(Calendar.MONTH, 1);
        for (int i = 0; i < 31; i++) {
            int val = calendar.get(Calendar.DATE);
            if (val <= 1) {
                break;
            }
            calendar.roll(Calendar.DATE, false);
        }

        calendar.set(Calendar.HOUR,   0);
        calendar.set(Calendar.MINUTE, 0);

        return (calendar.getTimeInMillis());
    } // of method

    //===   UTILITY - CALENDAR METHODS   =======================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static void runTestAAA() {
        System.out.println("HOUR " + MILLIS_HOUR);
        System.out.println("DAY  " + MILLIS_DAY);
        System.out.println("----------");
        System.out.println(MILLIS_HOUR);
        System.out.println(timespanToMillis("1 hour"));

        System.out.println("----------");
        System.out.println(2*MILLIS_HOUR);
        System.out.println(timespanToMillis("2 hours"));

        System.out.println("----------");
        System.out.println(1*MILLIS_DAY);
        System.out.println(timespanToMillis("1 day"));

        System.out.println("----------");
        System.out.println(2*MILLIS_DAY);
        System.out.println(timespanToMillis("2 days"));

        System.out.println("----------");
        System.out.println(30*MILLIS_DAY);
        System.out.println(timespanToMillis("30 days"));
    } // of method

    //--------------------

    private static void testTimeToMinuteOfDay(String str) {
        try {
            System.out.print(str + "\t- ");
            System.out.println(timeToMinuteOfDay(str));
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    } // of method


    //// Make sure that converting to minutes works correctly
    private static void runTestBBB() {
        testTimeToMinuteOfDay("12:00AM");
        testTimeToMinuteOfDay("12:01AM");
        testTimeToMinuteOfDay("12:59AM");
        testTimeToMinuteOfDay("1AM");
        testTimeToMinuteOfDay("1:00AM");
        testTimeToMinuteOfDay("2AM");
        testTimeToMinuteOfDay("2:30AM");
        testTimeToMinuteOfDay("5AM");
        testTimeToMinuteOfDay("9AM");
        testTimeToMinuteOfDay("9:59AM");
        testTimeToMinuteOfDay("10AM");
        testTimeToMinuteOfDay("10:00AM");
        testTimeToMinuteOfDay("11:00AM");
        testTimeToMinuteOfDay("11:59AM");
        testTimeToMinuteOfDay("12PM");
        testTimeToMinuteOfDay("12:00PM");
        testTimeToMinuteOfDay("12:59PM");
        testTimeToMinuteOfDay("1PM");
        testTimeToMinuteOfDay("9PM");
        testTimeToMinuteOfDay("9:59PM");
        testTimeToMinuteOfDay("10PM");
        testTimeToMinuteOfDay("10:00PM");
        testTimeToMinuteOfDay("11:59PM");
        testTimeToMinuteOfDay("12midnight");
        testTimeToMinuteOfDay("12noon");
        testTimeToMinuteOfDay("1400");
        testTimeToMinuteOfDay("0500");
    } // of method

    //--------------------

    //// See if the current time is *between* the specified times.
    private static void runTestCCC() {
        System.out.println(isBetween("5AM", "9PM"));
        System.out.println(isBetween("8PM", "9PM"));
        System.out.println(isBetween("9PM", "10PM"));
        System.out.println(isBetween("9PM", "10AM"));
    } // of method

    //--------------------

    //// Test the time conversion
    private static void runTestDDD() {
        System.out.println("" + MILLIS_MONTH);
        System.out.println("" + MILLIS_WEEK);
        System.out.println("" + MILLIS_DAY);
        System.out.println("" + MILLIS_HOUR);
        System.out.println("" + MILLIS_MINUTE);

        System.out.println(timespanToString(86400));          // 1 day
        System.out.println(timespanToString(86401));          // 86401 seconds
        System.out.println(timespanToString(3600));           // 1 hour
        System.out.println(timespanToString(7200));           // 2 hours
        System.out.println(timespanToString(SECONDS_WEEK));   // 1 week
        System.out.println(timespanToString(2*SECONDS_WEEK)); // 2 weeks
    } // of method

    //--------------------

    //// Test relative time comparison
    private static void runTestEEE() {
        System.out.println(compare(new Date(), "less than 1 hour old"));
        System.out.println(compare(new Date(), "more than 2 hours"));
    } // of method

    //--------------------

    private static void runTestFFF() {
        Date dAA = new Date( 1072573550593L ); // Dec 27 2003
        Date dBB = new Date( 1072573550593L + 4*24*3600*1000L); // Dec 27 2003
        System.out.println(dAA);
        System.out.println(dBB);

        System.out.println();
        System.out.println("Next Day");
        System.out.println(new Date(TimeLib.calculateNextDay()));
        System.out.println(new Date(TimeLib.calculateNextDay(dAA.getTime())));
        System.out.println(new Date(TimeLib.calculateNextDay(dBB.getTime())));

        System.out.println();
        System.out.println("Midnight");
        System.out.println(new Date(TimeLib.calculateNextMidnight()));
        System.out.println(new Date(TimeLib.calculateNextMidnight(dAA.getTime())));
        System.out.println(new Date(TimeLib.calculateNextMidnight(dBB.getTime())));

        System.out.println();
        System.out.println("Next Sunday Midnight");
        System.out.println(new Date(TimeLib.calculateNextSundayMidnight()));
        System.out.println(new Date(TimeLib.calculateNextSundayMidnight(dAA.getTime())));
        System.out.println(new Date(TimeLib.calculateNextSundayMidnight(dBB.getTime())));

        System.out.println();
        System.out.println("Next First of Month Midnight");
        System.out.println(new Date(TimeLib.calculateNextFirstOfMonthMidnight()));
        System.out.println(new Date(TimeLib.calculateNextFirstOfMonthMidnight(dAA.getTime())));
        System.out.println(new Date(TimeLib.calculateNextFirstOfMonthMidnight(dBB.getTime())));
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) {
        runTestBBB();
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
