package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JButton;

/** Manages the display of How To information. */
public class HowToManager {
  protected static final String HOW_TO_FRAME_PROP = "HOW_TO_FRAME";
  protected static HowToManager defaultManager = new HowToManager();
  protected JButton closeButton;
  
  protected HowToManager() {}

  public static HowToManager getManager()
  {
    return defaultManager;
  }
  
  public void showHowTo(MainFrame mainFrame, Notice notice)
  {
    JFrame frame = (JFrame) mainFrame.getRootPane().
      getClientProperty(HOW_TO_FRAME_PROP);
    if (frame == null) {
      frame = createFrame(mainFrame, notice);
      mainFrame.getRootPane().
	putClientProperty(HOW_TO_FRAME_PROP, frame);
    }
    setNotice(mainFrame, frame, notice);
    frame.pack();
    frame.setVisible(true);
    frame.toFront();
  }

  protected JFrame createFrame(MainFrame mainFrame, Notice notice)
  {
    HowToPanel htPanel = notice.getHowToPanel();
    htPanel.setMainFrame(mainFrame);
    final JFrame frame = new JFrame();
    Container contents = frame.getContentPane();
    contents.setLayout(new BorderLayout());
    closeButton = new JButton("Close");
    closeButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	frame.setVisible(false);
      }
    });
    return frame;
  }

  protected void setNotice(MainFrame mainFrame, JFrame frame, Notice notice)
  {
    String title = mainFrame.
      getGesturePackage().getName() + " - " +
      "How To - " + notice.getName() + " - quill";
    frame.setTitle(title);
    Container contents = frame.getContentPane();
    HowToPanel htPanel = notice.getHowToPanel();
    /*
    System.out.println("htPanel: " + htPanel + "\t" +
		       htPanel.getComponentCount());
    */
    contents.removeAll();
    contents.add(closeButton, BorderLayout.SOUTH);
    contents.add(htPanel, BorderLayout.CENTER);
  }
}
