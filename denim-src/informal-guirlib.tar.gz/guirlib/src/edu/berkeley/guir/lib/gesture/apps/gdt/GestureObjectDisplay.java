package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.GestureObject;
import edu.berkeley.guir.lib.gesture.Gesture;
import java.awt.event.ActionListener; 
import java.awt.Color;

public interface GestureObjectDisplay
  extends Commander, GestureAcceptor {
  Color ENABLED_BACKGROUND = Color.lightGray;
  Color DISABLED_BACKGROUND = Color.gray;
  
  GestureObject getDisplayedObject();
  /** A string indicating what to do tell the user about inputing new
      gestures, such as, "Draw a new example." */
  String getInputGestureTitle();
  /** Called when a new gesture is drawn.  Should recognize the
      gesture, or add it to the set.  Returns true if the input area
      should be cleared. */
  boolean gestureDrawn(Gesture gesture);
  void setScale(double scale);
  double getScale();

  /** An ActionEvent is fired when the gesture is activated.
      (Double-click, usually, which usually means to open it) */
  void addActionListener(ActionListener l);
  void removeActionListener(ActionListener l);
}
