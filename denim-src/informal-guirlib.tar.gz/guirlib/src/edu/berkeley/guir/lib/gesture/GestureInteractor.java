package edu.berkeley.guir.lib.gesture;

import java.awt.Color;
import java.awt.Insets;
import java.awt.event.*;

import javax.swing.event.*;

/**
 * Extends GestureDisplay to allow gesture to be entered with the mouse
 * (or tablet).  Emits a ChangeEvent when the Gesture changes.  For
 * performance reasons, this ChangEvent is emitted only when the Gesture
 * is finished (i.e., on mouse up) not while it's being drawn (i.e,
 * on mouse motion).
 */
public class GestureInteractor extends GesturePointsDisplay
  implements MouseListener, MouseMotionListener
{
  protected EventListenerList changeListenerList = new EventListenerList();
  protected ChangeEvent changeEvent = null;
  private boolean enabled = false;
  
  public GestureInteractor()
  {
    super();
    initUI();
  }

  public GestureInteractor(Gesture g)
  {
    super(g);
    initUI();
  }

  private void initUI()
  {
    setEnabled(true);
  }

  public void setEnabled(boolean on)
  {
    if (enabled != on) {
      if (on) {
	addMouseListener(this);
	addMouseMotionListener(this);
	setBackground(Color.white);
	setForeground(Color.black);
      }
      else {
	removeMouseListener(this);
	removeMouseMotionListener(this);
	setBackground(Color.lightGray);
	setForeground(Color.black);
      }
      enabled = on;
    }
  }

  public boolean getEnabled()
  {
    return enabled;
  }
  
  /**
   * This works around a bug in AWT that causes the modifiers to sometimes
   * be 0, not BUTTON1_MASK, when mouse button 1 is pressed.
   */
  boolean mouse1only(MouseEvent e)
  {
    int mods = e.getModifiers();
    return (mods == 0) || (mods == InputEvent.BUTTON1_MASK);
  }
  
  public void mousePressed(MouseEvent e)
  {
    //System.err.println("pressed: " + e.getModifiers());
    if (mouse1only(e))
      drag_start(e, null);
  }

  public void mouseReleased(MouseEvent e)
  {
    //System.err.println("released: " + e.getModifiers());
    if (mouse1only(e))
      drag_end(e, null);
  }
  
  public void mouseClicked(MouseEvent e)
  {
  }

  public void mouseMoved(MouseEvent e)
  {
  }
  
  public void mouseDragged(MouseEvent e)
  {
    if (mouse1only(e))
      drag_feedback(e, null);
  }

  public void mouseEntered(MouseEvent e)
  {
  }

  public void mouseExited(MouseEvent e)
  {
  }
    
  /** This is a holdover from subArctic, which I'm keeping in case I
   *  ever want to extend the event model to be more like it was
   */
  public boolean drag_start(MouseEvent evt,
			    Object user_info)
  {
    //System.err.println("start");
    Gesture g = getGesture();
    
    if (g == null) {
      setGesture(new Gesture());
      g = getGesture();
    }
    g.clearPoints();

    drag_feedback(evt, user_info);
    
    return true;
  }

  /** This is a holdover from subArctic, which I'm keeping in case I
   *  ever want to extend the event model to be more like it was
   */
  public boolean drag_feedback(MouseEvent evt,
			       Object user_info)
  {
    Insets insets = getInsets();
    int x, y;
    x = evt.getX() - insets.left;
    y = evt.getY() - insets.top;
    getGesture().addPoint(x, y);
    
    return true;
  }

  /** This is a holdover from subArctic, which I'm keeping in case I
   *  ever want to extend the event model to be more like it was
   */
  public boolean drag_end(MouseEvent evt,
			  Object user_info)
  {
    /*
    System.out.println("GI:end");
    getGesture().printTiming(System.out);
    */
    // notify listeners of change, if any
    fireStateChange();
    
    return true;
  }

  /**
   * Adds a ChangeListener
   */
  public void addChangeListener(ChangeListener l) {
    changeListenerList.add(ChangeListener.class, l);
  }
  
  /**
   * Removes a ChangeListener
   */
  public void removeChangeListener(ChangeListener l) {
    changeListenerList.remove(ChangeListener.class, l);
  }

  protected void fireStateChange()
  {
    Object[] listeners = changeListenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ChangeListener.class) {
	if (changeEvent == null)
	  changeEvent = new ChangeEvent(this);
	((ChangeListener)listeners[i+1]).stateChanged(changeEvent);
      }
    }
  }
}
