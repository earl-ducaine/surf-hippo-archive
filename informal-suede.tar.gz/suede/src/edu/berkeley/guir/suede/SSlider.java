package edu.berkeley.guir.suede;

import java.awt.*;

public class SSlider extends javax.swing.JComponent
{
    private static final int INSET  = 7;
    private static final int TIME_H = 3;
    private static final int TIME_W = 15;
    
    private static final Color NO_AUDIO = new Color(102, 102, 102);
    private static final Color INACTIVE = Color.black;
    
    private double  m_percent     = 0;
    private String  m_timeString  = "";
    private boolean m_isRecording = false;
    private Color   m_curColor    = NO_AUDIO;
    private Color   m_activeColor;
    private double  m_totalTime   = 0;

    
    public SSlider(Color active) {
        m_activeColor = active;
        setOpaque(false);
        setEnabled(false);
    }

    
    public void setActiveColor(Color active) {
       m_activeColor = active;
    }
    

    public void setTotalTime(double seconds) { 
       if(seconds>0.0) {
          m_totalTime = seconds;
          java.text.DecimalFormat format1= new java.text.DecimalFormat("00.0");
          m_timeString = format1.format(seconds);
          repaint();
       }
    }
    
    
    public void setCurTime(double time) {
       if (time>m_totalTime) setTotalTime(time);
       
       if (m_isRecording) {
         m_percent = (time%3.0)/3.0; 
       } else {
         if (m_totalTime>0) m_percent = time/m_totalTime;  
       }
       
       repaint();
    }
    

    public void setRecording() {
       m_totalTime = 0.0;
       m_curColor = m_activeColor;
       m_isRecording = true;
       repaint();
    }
    
    
    public void setPlaying() {
       m_curColor = m_activeColor;
       repaint();
    }


    public void setStopped() {
       m_curColor = INACTIVE;
       m_percent = 0;
       m_isRecording = false;
       repaint();
    }
    

    public void paint(Graphics g) {
        //1. set up the params: axis aligned lines should not be antialiased.
        Graphics2D g2d = (Graphics2D)g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g2d.setStroke(AbstNodeView.STROKE);
     
        //2. draw the horizontal background line
        g.setColor(m_curColor);
        int end = getWidth() - INSET;
        g.drawLine(INSET, getHeight()/2, end, getHeight()/2);

        //3. draw the vertical marker line
        g.setColor((m_isRecording) ? m_activeColor : INACTIVE);
        int xVal = (int)(m_percent * (end - INSET) + INSET);
        g.drawLine(xVal, INSET, xVal, getHeight() - INSET); //the vertical marker line
        
        //4. display the total time in the bottom right
        g.setColor((m_totalTime>0) ? m_activeColor : NO_AUDIO);
        String time;
        if ((m_timeString!="")) {
            g.setFont(g.getFont().deriveFont(Font.BOLD, 9));
            time = m_timeString;
        } else {
            g.setFont(g.getFont().deriveFont(Font.BOLD, 10));
            time = "--. -";
        }

        g2d.drawString(time, getWidth() - INSET - TIME_W, getHeight() - TIME_H);
    }
}