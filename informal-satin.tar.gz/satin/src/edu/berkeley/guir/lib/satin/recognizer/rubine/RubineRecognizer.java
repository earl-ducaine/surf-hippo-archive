//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.recognizer.rubine;

import edu.berkeley.guir.lib.collection.*;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.recognizer.*;
import java.io.*;
import java.text.ParseException;
import java.util.*;

/**
 * A wrapper for Rubine's Recognizer. This wrapper looks at the absolute
 * bounding points of TimedStrokes, classifying on what the user sees as
 * opposed to the underlying stroke data.
 *
 * <PRE>
 * Revisions:  1.0.0  06-16-1999 JH
 *                    Created class RubineRecognizer
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 06-16-1999
 */
public class RubineRecognizer
   implements SingleStrokeRecognizer {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private RubineClassifier classifier;       //// the Rubine's classifier

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTOR   =======================================================

   /**
    * Create a Rubine Recognizer with an empty data set. Everything gets
    * recognized as "tap".
    */
   public RubineRecognizer() {
   } // of default constructor

   //===========================================================================

   /**
    * Create a Rubine Recognizer.
    *
    * @param     rdr is a Reader reading the classification file.
    * @exception IOException on a read error.
    * @exception ParseException on a bad data file.
    * @exception TrainingException on a problem with the classifier.
    */
   public RubineRecognizer(Reader rdr) 
      throws IOException, ParseException, TrainingException {

      //// 1. Create an empty GestureSet.
      GestureSet gset = new GestureSet();

      //// 2. Initialize the data files.
      gset       = GestureSet.read(rdr);
      classifier = new RubineClassifier(gset);
      try {
         classifier.train();
      }
      catch (InterruptedException e) {
         // ignore
      }
   } // of constructor

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================


   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   public RubineClassifier getClassifier() {
      return (classifier);
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   CLASSIFICATION   ====================================================

   public Classification classify(TimedStroke stk) {
      Classification c      = new Classification();

      //// 0. Exception case.
      if (classifier == null) {
         c.put("tap", 1.0);
         return (c);
      }

      //// 1. Get the timed polygon within the Timed Stroke.
      ////    Get absolute in order to be scale-invariant. Otherwise, 
      ////    Rubine's fails, since it can't handle different sizes.
      TimedPolygon2D  polyOld = stk.getPolygon2D(COORD_ABS);
      int[]           xpts    = new int[polyOld.npoints];
      int[]           ypts    = new int[polyOld.npoints];

      for (int i = 0; i < polyOld.npoints; i++) {
         xpts[i] = (int) polyOld.xpoints[i];
         ypts[i] = (int) polyOld.ypoints[i];
      }

      TimedPolygon    polyNew = new TimedPolygon(xpts,
                                                 ypts,
                                                 polyOld.times,
                                                 polyOld.npoints);

      //// 2. Create a temporary Gesture to wrap around the TimedPolygon.
      Gesture gesture = new Gesture();
      gesture.setPoints(polyNew);

      //// 3. Classify the Feature Vector.
      SortedValueNumMap map;
      try {
         map = classifier.classify_satin(gesture);
      }
      catch (Exception e) {
         map = new SortedValueNumMap();
         map.put("Exception error", 1.0);
      }
      gesture = null;

      //// 5.   Convert the result into standard Satin classification results.
      //// 5.1. If there are no items, then return an empty classification.
      if (map.size() <= 0) {
         return (c);
      }

      //// 5.2. Otherwise, scale the Mahalonbis distances by the max val.
      double   maxVal = ((Number) map.getLargestValue()).doubleValue();
      Set      keys   = map.keySet();
      Iterator it     = keys.iterator();
      Object   key;
      double   val;

      while (it.hasNext()) {
         key = it.next();

         //// 5.2.1. If we only have one value, then scale it to 100% 
         ////        no matter what.
         if (keys.size() == 1) {
            val = 1.0;
         }
         //// 5.2.2. Otherwise, scale it so that the largest value is 0%.
         else {
            val = ((Number) map.get(key)).doubleValue();
            val = (maxVal - val) / maxVal;
         }
         c.put(key, val);
      }
      
      return (c);

   } // of classify

   //===   CLASSIFICATION   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/


