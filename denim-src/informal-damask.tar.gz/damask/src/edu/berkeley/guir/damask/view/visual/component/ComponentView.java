package edu.berkeley.guir.damask.view.visual.component;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.nodes.DamaskWindow;
import edu.berkeley.guir.damask.view.nodes.DamaskWindowTitle;
import edu.berkeley.guir.damask.view.visual.dialog.*;
import edu.umd.cs.piccolo.PNode;

/** 
 * A view of a Damask component. All subclasses of ComponentView should implement
 * a static method called createTempView() that returns a PNode.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-19-2003 James Lin
 *                               Created ControlView.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-19-2003
 */
public abstract class ComponentView extends InteractionElementView {

   /**
    * Initializes a view of the specified component.
    */
   public ComponentView(final Component component) {
      super(component);
   }
   
   /**
    * Initializes a view of the specified component.
    * 
    * @param component the component for which this view is created
    * @param useDefaultElementListener true if this instance should add
    * an InteractionElementListener that automatically adjusts the bounds
    * and transform of the view by listening to changes in the model
    */
   public ComponentView(
      final Component component,
      final boolean useDefaultElementListener) {

      super(component, useDefaultElementListener);
   }
   
   // Overrides method in parent class.
   public void dispose() {
      super.dispose();
   }
   
   /**
    * Returns the region view that this component view is in.
    */
   public PageRegionView getPageRegionView() {
      return (PageRegionView)DamaskAppUtils.getAncestor(
         this,
         PageRegionView.class);
   }
   
   
   /**
    * Returns the view of the page contents that this component view is in.
    */
   public PageViewContents getPageViewContents() {
      final PageRegionView regionView = getPageRegionView();
      if (regionView == null) {
         return null;
      }
      else {
         return regionView.getContents();      
      }
   }
   
   
   /**
    * Returns the view of the page that this component view is in.
    */
   public PageView getPageView() {
      // We'll try two ways to get the answer.
      PageView result =
         (PageView)DamaskAppUtils.getAncestor(this, PageView.class);
      if (result == null) {
         final PageViewContents pageViewContents = getPageViewContents();
         if (pageViewContents == null) {
            result = null;
         }
         else {
            result = pageViewContents.getPageView();      
         }
      }
      return result;
   }
   
   
   /**
    * Returns the view of the dialog that this component view is in.
    */
   public DialogView getDialogView() {
      final PageView pageView = getPageView();
      if (pageView == null) {
         return null;
      }
      else {
         final PNode parent = pageView.getParent();
         if (parent instanceof DialogView) {
            return (DialogView)parent;
         }
         else {
            return null;
         }
      }
   }


   // Overrides method in parent class.
   public DeviceType getDeviceType() {
      if (getParent() instanceof DamaskWindowTitle) {
         return ((DamaskWindowTitle)getParent()).getDeviceType();
      }
      else {
         final PageRegionView regionView = getPageRegionView();
         if (regionView == null) {
            final PageView pageView = getPageView();
            if (pageView == null) {
               return null;
            }
            else {
               return ((Page)pageView.getModel()).getDeviceType();
            }
         }
         else {
            return ((PageRegion)regionView.getModel())
               .getDeviceType();
         }
      }
   }


   /**
    * Adjusts the transparency of the specified component view, depending on
    * what its device type is and what the current device-type layer is. 
    */
   public void deviceTypeLayerChanged() {
      final DeviceType componentDeviceType =
         ((Component)getModel()).getDeviceType();

      final DamaskLayer layer = getLayer();
      if (layer == null) {
         return;
      }
      if (componentDeviceType == layer.getDeviceTypeForNewElement()) {
         DamaskAppUtils.setInternalColorAlpha(
            this, DamaskLayer.THIS_LAYER_ALPHA);
         // If this view is invisible, do NOT make it selectable or pickable.
         // This ensures that a list box associated with a combo box does not
         // become selectable.
         if (getVisible()) {
            setSelectable(true);
         }
      }
      else {
         DamaskAppUtils.setInternalColorAlpha(
            this, DamaskLayer.OTHER_LAYER_ALPHA);
         setSelectable(false);
      }
      
      repaint();
   }


   /**
    * Returns the editable contents of this component view.
    * 
    * @return either a {@link Label} or a List of Labels.
    */
   public abstract Object getEditableContents();


   /**
    * Returns whether this component view is in Run mode.
    */
   public abstract boolean isInRunMode();


   /**
    * Sets whether this component view is in Run mode, when the controls behave
    * as if the user is interacting with them.
    */
   public abstract void setInRunMode(final boolean flag);
}
