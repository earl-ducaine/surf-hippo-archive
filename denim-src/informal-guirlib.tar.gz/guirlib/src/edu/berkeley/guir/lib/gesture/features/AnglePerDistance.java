package edu.berkeley.guir.lib.gesture.features;

import edu.berkeley.guir.lib.gesture.Feature;
import edu.berkeley.guir.lib.gesture.Gesture;

public class AnglePerDistance extends Feature {
  public AnglePerDistance()
  {
    super();
  }

  public AnglePerDistance(Gesture g)
  {
    super(g);
  }

  public String getName()
  {
    return "angle/distance";
  }
  
  public double getMinValue()
  {
    return Double.MIN_VALUE;
  }
  
  public double getMaxValue()
  {
    return Double.MAX_VALUE;
  }
  
  protected void computeValue()
  {
    TotalAngle totalAngle = new TotalAngle(gesture);
    TotalLength totalLength = new TotalLength(gesture);

    double length = totalLength.getValue();
    if (length != 0) {
      value = totalAngle.getValue() / length;
    }
    else {
      value = 0;
    }
    valueOk = true;
  }

  public void scale(double factor)
  {
  }
}
