package edu.berkeley.guir.lib.gesture.apps;

/*
 * prints out averge feature values for each class
 */

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.features.*;
import java.io.File;
import java.io.PrintStream;
import java.util.*;

public class featurevals {
  public static final Class[] humanFeatures = {
    Curviness2.class,
    AnglePerDistance.class,
    Density1.class,
    Density2.class,
    Curviness.class,
    LogArea.class,
    LogAspect.class
  };

  public static void main(String[] argv)
  {
    if (argv.length != 1) {
      System.err.println("gnames: usage: java featurevals gesturesetfile");
      System.exit(-1);
    }

    GestureSetFrame frame =
      new GestureSetFrame("featurevals", false);

    frame.openFile(new File(argv[0]));

    GestureSet gs = frame.getGestureSetDisplay().getGestureSet();
    printFeatureVals(System.out, gs);
    System.exit(0);
  }

  static void printFeatureVals(PrintStream out, GestureSet gs)
  {
    List featureClasses =
      new LinkedList(Arrays.asList(FeatureVector.defaultFeatureClasses));
    featureClasses.addAll(Arrays.asList(humanFeatures));

    // print titles
    for (Iterator iter = featureClasses.iterator();
	 iter.hasNext(); ) {
      Class featureClass = (Class) iter.next();
      String fullName = featureClass.getName();
      int lastDot = fullName.lastIndexOf('.');
      out.print("\t" + fullName.substring(lastDot+1));
    }
    out.println();
    
    
    for (Iterator it = gs.getCategories().iterator(); it.hasNext();) {
      GestureCategory gc = (GestureCategory)it.next();
      out.print(gc.getName());
      for (Iterator iter = featureClasses.iterator();
	   iter.hasNext(); ) {
	double average = 0;
	Class featureClass = (Class) iter.next();
	try {
	  Feature feature = (Feature) featureClass.newInstance();
	  for (int gNum = 0; gNum < gc.size(); gNum++) {
	    Gesture g = gc.gestureAt(gNum);
	    feature.setGesture(g);
	    average += feature.getValue();
	  }
	}
	catch (InstantiationException e) {
	  System.err.println("Error instantiating feature for class '" +
			     featureClass + "'");
	}
	catch (IllegalAccessException e) {
	  System.err.println("Error accessing class '" + featureClass +"'");
	}
	out.print("\t" + average / gc.size());
      }
      out.println();
    }
  }
}
