package edu.berkeley.guir.damask.event;

import java.util.EventListener;

/** 
 * The listener interface for receiving events regarding when something about
 * a page has changed. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-21-2004 James Lin
 *                               Created PageListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 02-21-2004
 */
public interface PageListener extends EventListener {
   
   /**
    * Invoked when the template of a page is added.
    */
   void templateAdded(PageEvent e);
   
   /**
    * Invoked when the template of a page is removed.
    */
   void templateRemoved(PageEvent e);
}
