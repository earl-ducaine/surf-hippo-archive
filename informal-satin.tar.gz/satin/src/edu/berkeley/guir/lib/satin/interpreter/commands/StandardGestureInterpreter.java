//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter.commands;

import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.recognizer.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.interpreter.rubine.*;
import edu.berkeley.guir.lib.satin.stroke.*;

/**
 * Standard gestures, like cut, copy, paste, delete, and pan.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 02 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class StandardGestureInterpreter 
   extends GestureCommandInterpreterImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 1118908262546911989L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INNER CLASS   =======================================================

   class StandardRubineInterpreter 
      extends RubineInterpreter {

      public StandardRubineInterpreter(String str, Class baseClass) {
         //// First param is the name of the rubine data file.
         //// Second param is whether or not to simplify strokes before
         //// processing.
         super(str, baseClass, false);
      } // of constructor

      protected void 
      handleSingleStroke(SingleStrokeEvent evt, Classification c) {
         String       str = (String) c.getFirstKey();
         TimedStroke  stk = evt.getStroke();

         str = str.trim();

         if (stk.getLength2D(COORD_ABS) < 20) {
            return;
         }

         if (str.startsWith("ViewPort")) {
            handleViewPort(str, stk);
            evt.setConsumed("Viewport");
         }

         else if (str.startsWith("Center")) {
            handleCenter(stk);
            evt.setConsumed("Center");
         }

         else if (str.startsWith("Copy")) {
            handleCopy(stk);
            evt.setConsumed("Copy");
         }

         else if (str.startsWith("Cut")) {
            handleCut(stk);
            evt.setConsumed("Cut");
         }

         else if (str.startsWith("Paste")) {
            handlePaste(stk);
            evt.setConsumed("Paste");
         }

         else if (str.startsWith("Delete")) {
            handleDelete(stk);
            evt.setConsumed("Delete");
         }

         else if (str.startsWith("Undo")) {
            handleUndo(stk);
            evt.setConsumed("Undo");
         }

         else if (str.startsWith("Redo")) {
            handleRedo(stk);
            evt.setConsumed("Redo");
         }
      } // of method


      public Object clone() {
         return (new StandardRubineInterpreter(this.getFileName(),
                                               this.baseClass));
      } // of method
   } // of class

   //===   INNER CLASS   =======================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   protected boolean           flagShallow = true;
   protected RubineInterpreter intrp;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public StandardGestureInterpreter() {
      this("standard.gsa", null);
   } // of constructor

   //-----------------------------------------------------------------

   public StandardGestureInterpreter(Class baseClass) {
      this("standard.gsa", baseClass);
   } // of constructor
   
   //-----------------------------------------------------------------

   /**
    * Initialize the interpreter, using the file with the given name for
    * the gesture stroke data.
    */
   public StandardGestureInterpreter(String filename) {
      this(filename, null);
   }

   //-----------------------------------------------------------------

   /**
    * Initialize the interpreter, using the file with the given name for
    * the gesture stroke data.
    */
   public StandardGestureInterpreter(String filename, Class baseClass) {
      intrp = new StandardRubineInterpreter(filename, baseClass);
      commonInitializations();
   } // of constructor
   
   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Standard Gesture Interpreter");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR / MODIFIER METHODS   =======================================

   /**
    * Set the GraphicalObject retrieval to be shallow (in terms of the data
    * structure, ie one level). This affects how cut, copy, paste, and delete
    * work.
    */
   public void setShallow() {
      flagShallow = true;
   } // of setShallow

   //-----------------------------------------------------------------

   /**
    * Set the GraphicalObject retrieval to be deep (in terms of the data
    * structure, ie one level). This affects how cut, copy, paste, and delete
    * work.
    */
   public void setDeep() {
      flagShallow = false;
   } // of setDeep

   //===   ACCESSOR / MODIFIER METHODS   =======================================
   //===========================================================================



   //===========================================================================
   //===   HANDLE GESTURE METHODS   ============================================

   public void handleSingleStroke(SingleStrokeEvent evt) {
      intrp.handleSingleStroke(evt);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Handle an undo. 
    * Override this method if you want.
    */
   protected void handleUndo(TimedStroke stk) {
      try {
         cmdqueue.undo();
         getAttachedGraphicalObject().damage(DAMAGE_LATER);
      }
      catch (Exception e) {
         Debug.println(e);
      }
   } // of handleUndo

   //-----------------------------------------------------------------

   /**
    * Handle a redo. 
    * Override this method if you want.
    */
   protected void handleRedo(TimedStroke stk) {
      try {
         cmdqueue.redo();
         getAttachedGraphicalObject().damage(DAMAGE_LATER);
      }
      catch (Exception e) {
         Debug.println(e);
      }
   } // of handleRedo

   //-----------------------------------------------------------------

   /**
    * Cut whatever intersects the stroke.
    * Override this method if you want.
    */
   protected void handleCut(TimedStroke stk) {
      GraphicalObjectCollection gobcol;
      Iterator                  it;
      GraphicalObject           attach;
      GraphicalObject           gob;
      CutCommand                cmd = new CutCommand();

      gobcol = getGraphicalObjectsTouching(stk, 2);
      it     = gobcol.getForwardIterator();
      attach = getAttachedGraphicalObject();

      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();
         if (gob != attach) {
            cmd.addGraphicalObject(gob);
         }
      }

      cmdqueue.doCommand(cmd);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Copy whatever is in the center of the stroke.
    * Override this method if you want.
    */
   protected void handleCopy(TimedStroke stk) {
      GraphicalObject gob = getGraphicalObjectCenteredAt(stk);
      if (gob != null && gob != getAttachedGraphicalObject()) {
         cmdqueue.doCommand(new CopyCommand(gob));
      }
   } // of handleCopy

   //-----------------------------------------------------------------

   /**
    * Paste to the bottom-center of the stroke.
    * Override this method if you want.
    */
   protected void handlePaste(TimedStroke stk) {
      GraphicalObject gob  = getAttachedGraphicalObject();
      Rectangle2D     rect = stk.getBounds2D(COORD_ABS);
      Point2D         pt   = new Point2D.Float(
                               (float) (rect.getX() + rect.getWidth()/2),
                               (float) (rect.getY() + rect.getHeight()));
      
      GraphicalObjectLib.absoluteToLocal(gob, pt, pt);
      if (gob instanceof GraphicalObjectGroup) {
         cmdqueue.doCommand(new PasteCommand((GraphicalObjectGroup) gob, 
                                                   pt.getX(), pt.getY()));
      }
   } // of handlePaste

   //-----------------------------------------------------------------

   /**
    * Delete whatever is in the center of the stroke (except ourself of course).
    * Override this method if you want.
    */
   protected void handleDelete(TimedStroke stk) {
      GraphicalObject gob = getGraphicalObjectCenteredAt(stk);
      if (gob != null && gob != getAttachedGraphicalObject()) {
         cmdqueue.doCommand(new DeleteCommand(gob));
      }
   } // of handleDelete

   //-----------------------------------------------------------------

   /**
    * Center the screen to be at the mark.
    * Override this method if you want.
    */
   protected void handleCenter(TimedStroke stk) {
      GraphicalObject gob    = getAttachedGraphicalObject();
      Rectangle2D     gobbds = gob.getBounds2D();
      Rectangle2D     stkbds = stk.getBounds2D();
      double          x1     = gobbds.getX() + gobbds.getWidth()/2;
      double          y1     = gobbds.getY() + gobbds.getHeight()/2;
      double          x2     = stkbds.getX() + stkbds.getWidth()/2;
      double          y2     = stkbds.getY() + stkbds.getHeight()/2;

      AffineTransform[] txArray;
      txArray = AffineTransformLib.animateSlowInSlowOut(
         AffineTransform.getTranslateInstance(x1 - x2, y1 - y2), 10);
      GraphicalObjectLib.animate(gob, txArray);
   } // of handleCenter

   //-----------------------------------------------------------------

   /**
    * Given a gesture name, returns the direction of the pan that the
    * gesture name represents, or -1 if it is not a pan gesture.
    * 
    * @see SatinConstants#DIR_LEFT
    * @see SatinConstants#DIR_RIGHT
    * @see SatinConstants#DIR_UP
    * @see SatinConstants#DIR_DOWN
    * @see SatinConstants#DIR_UP_LEFT
    * @see SatinConstants#DIR_UP_RIGHT
    * @see SatinConstants#DIR_DOWN_LEFT
    * @see SatinConstants#DIR_DOWN_RIGHT
    */
   protected int getViewPortDirection(String str) {
      String strLower = str.toLowerCase();
      int direction = -1;
      
      if (strLower.startsWith("viewportleft")) {
         direction = SatinConstants.DIR_LEFT;
      }
      else if (strLower.startsWith("viewportright")) {
         direction = SatinConstants.DIR_RIGHT;
      }
      else if (strLower.startsWith("viewportup")) {
         direction = SatinConstants.DIR_UP;
      }
      else if (strLower.startsWith("viewportdown")) {
         direction = SatinConstants.DIR_DOWN;
      }
      else if (strLower.startsWith("viewportdiagupright")) {
         direction = SatinConstants.DIR_UP_RIGHT;
      }
      else if (strLower.startsWith("viewportdiagupleft")) {
         direction = SatinConstants.DIR_UP_LEFT;
      }
      else if (strLower.startsWith("viewportdiagdownright")) {
         direction = SatinConstants.DIR_DOWN_RIGHT;
      }
      else if (strLower.startsWith("viewportdiagdownleft")) {
         direction = SatinConstants.DIR_DOWN_LEFT;
      }
      
      return direction;
   }
   
   
   /**
    * Handle a move view port command.
    * Override this method if you want.
    */
   protected void handleViewPort(String str, TimedStroke stk) {
      AffineTransform tx  = new AffineTransform();
      GraphicalObject gob = getAttachedGraphicalObject();
      double          len = stk.getLength2D(COORD_ABS);
      int             direction = getViewPortDirection(str);

      switch (direction) {
      case SatinConstants.DIR_LEFT:
         tx.translate(+len, 0);
         break;
      case SatinConstants.DIR_RIGHT:
         tx.translate(-len, 0);
         break;
      case SatinConstants.DIR_UP:
         tx.translate(0, +len);
         break;
      case SatinConstants.DIR_DOWN:
         tx.translate(0, -len);
         break;
      case SatinConstants.DIR_UP_RIGHT:
         tx.translate(-len/2, +len/2);
         break;
      case SatinConstants.DIR_UP_LEFT:
         tx.translate(+len/2, +len/2);
         break;
      case SatinConstants.DIR_DOWN_RIGHT:
         tx.translate(-len/2, -len/2);
         break;
      case SatinConstants.DIR_DOWN_LEFT:
         tx.translate(+len/2, -len/2);
         break;
      }

      AffineTransform[] txArray;
      txArray = AffineTransformLib.animateSlowInSlowOut(tx, 8);
      
      this.getAttachedGraphicalObject().getSheet().setSheetPanning(true);
      GraphicalObjectLib.animate(gob, txArray);
      this.getAttachedGraphicalObject().getSheet().setSheetPanning(false);      
   } // of method

   //===   HANDLE GESTURE METHODS   ============================================
   //===========================================================================



   //===========================================================================
   //===   GET GOB METHODS   ===================================================

   /**
    * Get things that intersect the stroke.
    * Override this method to change the behavior of how objects intersecting
    * a stroke are selected. For example, in DENIM, this method is modified
    * such that DenimPanel objects can be deleted when zoomed out (ie shallow),
    * and strokes and phrases can be deleted when zoomed in (ie deep).
    */
   protected GraphicalObjectCollection
   getGraphicalObjectsTouching(TimedStroke stk, double thresh) {

      //// 0. Don't do anything if we're not a group.
      if (! (getAttachedGraphicalObject() instanceof GraphicalObjectGroup)) {
         return (null);
      }
      
      GraphicalObject           gob     = getAttachedGraphicalObject();
      GraphicalObject           gobtmp  = null;
      Shape                     s       = stk.getBoundingPoints2D(COORD_ABS);
      GraphicalObjectGroup      gobgrp  = (GraphicalObjectGroup) gob;
      GraphicalObjectCollection gobcol  = new GraphicalObjectCollectionImpl();
      int                       depth;

      //// 1. Set for shallow / deep search.
      if (flagShallow == true) {
         depth = SHALLOW;
      }
      else {
         depth = DEEP;
      }

      //// 2.1. Try searching using the stroke bounds.
      gobcol = gobgrp.getGraphicalObjects(COORD_ABS, 
                                          s, 
                                          ALL,
                                          depth,
                                          INTERSECTS,
                                          thresh,
                                          gobcol);
      return (gobcol);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the GraphicalObject near the center of this TimedStroke.
    */
   protected GraphicalObject 
   getGraphicalObjectCenteredAt(TimedStroke stk) {
      return (getGraphicalObjectCenteredAt(stk, DEFAULT_SELECT_THRESHOLD));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the GraphicalObject near the center of this TimedStroke, with
    * the specified threshold.
    */
   protected GraphicalObject 
   getGraphicalObjectCenteredAt(TimedStroke stk, double thresh) {

      GraphicalObjectCollection gobcol;
      GraphicalObject           gobtmp = null;

      //// 1. Get the graphical objects touching the stroke.
      gobcol = getGraphicalObjectsTouching(stk, thresh);

      //// 2. Return the topmost Graphical Object first.
      if (gobcol.numElements() > 0) {
         gobtmp = GraphicalObjectLib.getTopmostGraphicalObject(gobcol);
      }

      return (gobtmp);
   } // of method

   //===   GET GOB METHODS   ===================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (new StandardGestureInterpreter());
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
