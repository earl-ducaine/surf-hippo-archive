package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.dialogs.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

/**
 * A piece of typed text in Denim.
 *
 * <PRE>
 * Revisions:  1.0.0  02-26-2000  William Lee (maintained by James Lin)
 *                    Created DenimText
 *             2.0.0  10-19-2000  JL
 *                    Combined with DenimTextSwitch
 *                    Renamed TypedText
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 2.0.0, 10-19-2000
 */

public class TypedText
   extends PatchImpl
   implements DenimText, DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -8657905811540275912L;
  // private static final GraphicalObjectCollection emptyCol =
  //    new GraphicalObjectCollectionImpl();
/*
   private static String FONT_FAMILY;
   static {
      // Get the list of font families on this machine.
      String[] familyArray =
         GraphicsEnvironment.getLocalGraphicsEnvironment().
            getAvailableFontFamilyNames();
      List familyList = Arrays.asList(familyArray);

      // If the preferred Denim text font is on this system...
      if (familyList.contains(DenimConstants.DENIM_TEXT_FONT_FAMILY)) {
         // ...then use it
         FONT_FAMILY = DenimConstants.DENIM_TEXT_FONT_FAMILY;
      }
      else {
         FONT_FAMILY = "SansSerif";
      }
   }
  */


   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   private JTextAreaWrapper     textWrapper;
   private JTextArea            textArea;
   private Color                origTextColor;
   private boolean              isLink;
   

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================


   //===========================================================================
   //===   NESTED CLASSES   ====================================================

   public class JTextAreaWrapper extends GObJComponentWrapper {

      JTextAreaWrapper(JTextArea textArea) {
         super(textArea);
		 textArea.setEditable(false);
      }

      //-----------------------------------------------------------------

      private JTextArea textAreaCopy() {
         JTextArea textArea = (JTextArea)getComponent();
         JTextArea newTextArea = new JTextArea(textArea.getText());
         newTextArea.setFont(textArea.getFont());
         newTextArea.setForeground(textArea.getForeground());

         return newTextArea;
      }

      //-----------------------------------------------------------------

      /**
       * Returns a deep clone of this phrase.
       */
      public Object deepClone()  {
         return deepClone(new JTextAreaWrapper(textAreaCopy()));
      } // of method

      //-----------------------------------------------------------------

      /**
       * Makes the given label a deep clone of this phrase, and returns the
       * deep phrase.
       */
      public Object deepClone(JTextAreaWrapper clone) {
         super.deepClone(clone);
         return clone;
      } // of method
   }

   //===   NESTED CLASSES   ====================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates an empty TypedText
    */
   public TypedText() {
      this(new JTextArea("[Label]"));
   }

   //-----------------------------------------------------------------

   /**
    * Creates a TypedText with the given string as its content
    */
   public TypedText(String str) {
      this(new JTextArea(str));
   }

   //-----------------------------------------------------------------

   /**
    * Creates a TypedText with the JTextArea
    */
   public TypedText(JTextArea ta) {
      textArea = new JTextArea();
   	  textArea.setText(ta.getText().trim());
      textArea.setForeground(ta.getForeground());
      textArea.setFont(ta.getFont());
      textWrapper = new JTextAreaWrapper(textArea);
      setTextArea(textArea);
      this.add(textWrapper);
      Style style = this.getStyle();
      style.setDrawColor(NO_COLOR);
      style.setFillColor(NO_COLOR);
      this.setStyle(style);
      
      this.setDrawPatch(false);
      this.setFillPatch(false);
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   /**
    * Gets the color of the whole phrase
    */
   public Color getColor() {
      Color c = textArea.getForeground();
      if(c==null)
   	   c = Color.black;
      return c;
   }

   //===========================================================================
   //===   DENIMTEXT METHODS   =================================================

   /**
    * Sets the color of the whole phrase
    */
   public void setColor(Color c) {
      Debug.println("Changing color to " + c.toString());
      textArea.setForeground(c);
   }
   
   //-----------------------------------------------------------------

   /**
    * Sets the background color of the whole phrase
    */
   public void setBackground(Color c) {
      this.getStyleRef().setFillColor(c);
      textArea.setBackground(c);
   }
   
   //-----------------------------------------------------------------

   /**
    * Sets the transparency of the color of the whole phrase
    */
   public void setTransparency(int transparency) {
      Color c = textArea.getForeground();
      textArea.setForeground(
         new Color(c.getRed(), c.getGreen(), c.getBlue(), transparency));
   }
   //-----------------------------------------------------------------

   /**
    * Makes the phrase appear or not appear to be a hyperlink
    */
   public void setHyperlink(boolean makeHyperlink) {
      if (makeHyperlink && !isLink) {
         origTextColor = getColor();
         setColor(DEFAULT_LINK_COLOR);
         isLink = true;
      }
      else if (!makeHyperlink && isLink) {
         setColor(origTextColor);
         isLink = false;
      }
   }

   //===   DENIMTEXT METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   STROKE METHODS   ====================================================

   /**
    * This should grab the single stroke so that it would open the text field
    * and edit according to the tap position.  NOT WORKING YET
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      /*
      //// 1. If the length is too long, it's not a tap.
      ////    In case you are wondering, 5 is arbitrary.
      TimedStroke stk = evt.getStroke();
      if (stk.getLength2D(COORD_ABS) > 5) {
         return;
      }

      //// 2. Get the candidates for being tapped on.
      GraphicalObjectCollection gobcol = getTapCandidates(evt);
      GraphicalObject           selgob = null;
      DenimSheet                sheet = getSheet();

      //// 3. Can't tap on the crosshairs.
      sheet.setCrosshairsVisible(false);

      //// 3. Get the candidate for being selected.
      selgob = getSelectCandidate(gobcol);

      //// 4.1. Select or deselect.
      if (selgob != null) {
         selectGraphicalObject(selgob);
      }
      //// 4.2. The person must have tapped on the sheet =>
      ////      draw crosshairs where the user tapped if there are no
      ////      selected objects.
      else {
         sheet.setCrosshairsVisible(true);
         sheet.setCrosshairsLocation(stk.getStartPoint2D(COORD_ABS));
      }
      evt.setConsumed();
      evt.setShouldRender(false);
      */
   } // of handleSingleStroke

   //===   STROKE METHODS   ====================================================
   //===========================================================================

   //===========================================================================
   //===   TEXT METHODS   ======================================================

   /**
    * Get the textArea of this TypedText
    */
   public JTextArea getTextArea() {
      return textArea;
   }

   //-----------------------------------------------------------------

   /**
    * Set the textArea of this TypedText
    */
   public void setTextArea(JTextArea ta) {
      textArea = ta;
      textArea.setOpaque(true);
      textArea.setWrapStyleWord(true);
      setEditable(false);
      textArea.requestFocus();

      textWrapper.setComponent(ta); // set the wrapper's element
      this.setBoundingPoints2D(COORD_ABS, textWrapper.getBounds2D(COORD_ABS));
   }

   //-----------------------------------------------------------------

   /**
    * Makes the component editable.
    */
   public void setEditable(boolean flag) {
      textArea.setEditable(flag);
   }

   //-----------------------------------------------------------------

   /**
    * Returns the font inside this textSwitch
    */
   public Font getFont() {
      return textArea.getFont();
   }

   //-----------------------------------------------------------------

   /**
    * Returns the text
    */
   public String getText() {
      return textArea.getText();
   }

   //-----------------------------------------------------------------

   /**
    * Set the carent position at pos.
    */
   public void setCaretPosition(int pos) {
      textArea.setCaretPosition(pos);
   }

   //===   TEXT METHODS   ======================================================
   //===========================================================================


   //===========================================================================
   //===   FONT METHODS   ======================================================

   //===   FONT METHODS   ======================================================
   //===========================================================================


   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Returns a deep clone of this phrase.
    */
   public Object deepClone()  {
      return deepClone(new TypedText());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Makes the given label a deep clone of this phrase, and returns the
    * deep phrase.
    */
   public Object deepClone(TypedText clone) {
      super.deepClone(clone);

      // We know that the only child in the original is a JTextWrapper,
      // so just point textWrapper to that.
      clone.textWrapper = (JTextAreaWrapper)clone.get(0);
      clone.textArea = (JTextArea)clone.textWrapper.getComponent();

      return clone;
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================
   
   //----------------------------------------
   
   /**
    * clear all references hold by this object (In the namespace of this class)
    */
   
   public void deepClear() {
      
      super.deepClear();
      
      textWrapper = null;
      textArea = null;
      origTextColor = null; 

   }
   /*
   public boolean equals(Object obj) {
	   if(obj instanceof TypedText&&
	   		((TypedText)obj).getText().trim().equals(this.getText().trim()))
   		{
   			return true;	
   		}
   		else
   		{
   			return false;
   		}
   } // of equals
*/
} // of class

//==============================================================================

/*
Copyright (c) 2000-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
