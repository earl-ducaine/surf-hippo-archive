package edu.berkeley.guir.suede;

import javax.swing.*;
import java.awt.*;

public class StartNodeView extends AbstNodeView {
    JLabel start = new JLabel("START");

    public StartNodeView(SuedeModel model, AbstNodeModel nodeModel) {
        super(model, nodeModel);
        start.setHorizontalAlignment(SwingConstants.CENTER);
        start.setOpaque(false);
        start.setForeground(AbstLinkView.BALLOON_FG);
        start.setBackground(Color.red);
        add(start);
    }

    public void setBounds(int x, int y, int w, int h) {
        super.setBounds(x,y,w,h);   
        start.setBounds(0,0,w,h);   
    }
    
    public void paintComponent(Graphics g) {
        g.setColor(AbstLinkView.LINK_COLOR);
        g.fillOval(0,0,getWidth()-AbstNodeView.STROKE_WIDTH/2,getHeight()-AbstNodeView.STROKE_WIDTH/2);
        g.setColor(AbstLinkView.BALLOON_FG);
        ((Graphics2D)g).setStroke(AbstNodeView.STROKE);
        g.drawOval(0,0,getWidth()-AbstNodeView.STROKE_WIDTH/2,getHeight()-AbstNodeView.STROKE_WIDTH/2);
        super.paintComponent(g);
    }

    // start nodes have no outbound balloons
    public boolean getDrawBalloon() {
        return false;   
    }
}