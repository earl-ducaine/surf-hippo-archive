package edu.berkeley.guir.damask.pattern;

import java.util.Collection;

import edu.berkeley.guir.damask.InteractionElement;

/** 
 * A marker interface that marks a class as being able to be a member of
 * a pattern instance.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-26-2003 James Lin
 *                               Created PatternInstanceMember
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 06-26-2003
 */
public interface PatternInstanceMember extends InteractionElement {

   /**
    * Returns all pattern instances that this element is a member of.
    */
   Collection/*<PatternInstance>*/ getPatternInstanceMemberships();
   
   /**
    * Called by PatternInstance.addMember() and PatternInstance.removeMember()
    * only.
    */
   void addToPatternInstance(PatternInstance pi);
   
   /**
    * Called by PatternInstance.addMember() and PatternInstance.removeMember()
    * only.
    */
   boolean removeFromPatternInstance(PatternInstance pi);
   
}
