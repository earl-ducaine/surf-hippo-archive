package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that changes the inset of a page region.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-06-2004 James Lin
 *                               Created SetInsetCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-06-2004
 */
public class SetInsetCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final PageRegion region;
   private final int oldInset;
   private final int newInset;

   /**
    * Constructs the command.
    * 
    * @param region the page region whose inset is to be updated
    * @param newInset the new inset of the region
    */
   public SetInsetCommand(final PageRegion region, final int newInset) {
      this.region = region;
      this.newInset = newInset;
      oldInset = region.getInset();
   }


   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Set inset of " + region + ": " + oldInset + "->" + newInset;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      region.setInset(newInset);
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      region.setInset(oldInset);
   }
}
