package edu.berkeley.guir.lib.gesture;

import java.awt.*;
import java.awt.event.*;
import java.util.Observer;
import java.util.Observable;
import javax.swing.*;

/**
 * Display a single gesture.  Has several options: narrowed, selected,
 * showPoints.
 */
public class GesturePointsDisplay extends JPanel implements Observer {
  static final int minDelay = 9;	// in milliseconds
  static final int restartDelay = 5000;
  static final int normalDelay = 10;
  protected static final int dotRadius = 3;
  static final int defaultXOffset = 5;
  static final int defaultYOffset = 5;
  Gesture gesture;
  boolean autoCentering = true;
  protected int xoffset, yoffset;
  protected boolean isSelected;
  // display whether it's selected or not
  protected boolean showSelected = true;
  protected boolean showPointsOn;
  Dimension preferredSize;
  boolean narrowed;
  protected boolean animate = false;
  protected int animatePoints = 0;
  Timer timer;
  boolean validTimings = false;
  
  public GesturePointsDisplay()
  {
    this(null);
  }

  public GesturePointsDisplay(Gesture g)
  {
    this(g, defaultXOffset, defaultYOffset);
  }

  /**
   * Set offsets and gesture at the same time
   */
  public GesturePointsDisplay(Gesture g, int x, int y)
  {
    super();
    setGesture(g);
    setOffset(x, y);
    setBackground(Color.white);
    if (g != null)
      setSize(getMinimumSize());
  }

  public Gesture getGesture()
  {
    return gesture;
  }

  /** Set the displayed gesture.  Does not automatically resize
      itself, so you may want to call revalidate after setting the
      gesture. */
  public void setGesture(Gesture g)
  {
    if (gesture != g) {
      if (gesture != null) {
	gesture.deleteObserver(this);
      }
      //System.out.println("GPD:" + gesture + "\t->" + g);
      gesture = g;
      if (g != null) {
	g.addObserver(this);
	//setMinimumSize(g.getBounds().getSize());
	/*
	  System.err.println("setGesture: " + this +
	  " calling repaint on " + g);
	*/
	/*
	  System.err.println("setGesture: " + this +
	  " returned from repaint on " + g);
	*/
	TimedPolygon polygon = g.getPoints();
	if ((polygon != null) && (polygon.npoints > 1)) {
	  validTimings =
	    polygon.times[0] != polygon.times[polygon.npoints-1];
	  animatePoints = polygon.npoints-1;
	}	  
	if (animate) {
	  stopAnimation();
	  startAnimation();
	}
      }
      else {
	validTimings = false;
      }
      repaint();
    }
  }

  /**
   * When autoCentering is on, the gesture is automatically centered
   * in the widget.
   */
  public boolean getAutoCentering()
  {
    return autoCentering;
  }

  /**
   * When autoCentering is on, the gesture is automatically centered
   * in the widget.
   */
  public void setAutoCentering(boolean on)
  {
    if (autoCentering != on) {
      autoCentering = on;
      repaint();
    }
  }
  
  /**
   * Doesn't really center it for now, just moves it to the origin
   */
  public void centerGesture()
  {
    gesture.normalize();
  }

  public void setPreferredSize(Dimension preferredSize) {
    super.setPreferredSize(preferredSize);
    this.preferredSize = preferredSize;
  }

  public Dimension getPreferredSize()
  {
    return (preferredSize == null) ? getMinimumSize() : preferredSize;
  }
  
  public Dimension getMinimumSize()
  {
    if (gesture != null) {
      Rectangle bounds = gesture.getBounds();
      Insets insets = getInsets();
      return new Dimension(bounds.x + bounds.width + xoffset * 2 +
			   insets.left + insets.right,
			   bounds.y + bounds.height + yoffset * 2 +
			   insets.top + insets.bottom);
    }
    else {
      return super.getMinimumSize();
    }
  }

  // todo: implement auto-centering
  public void paint(Graphics graphics)
  {
    super.paint(graphics);
    //System.err.println("paint: " + this + " painting " + getGesture());
    if (getGesture() != null) {
      Dimension size = getSize();
      
      if (isSelected && showSelected) {
    	graphics.setColor(Color.red);
	graphics.drawRect(0, 0, size.width-1, size.height-1);
      }

      Polygon points = getGesture().getPoints();
      if ((points != null) && (points.npoints > 0)) {
    	Insets insets = getInsets();
	Graphics g = graphics.create();
	// use try...finally to make sure the Graphics is disposed of
	try {
	  g.clipRect(0, 0,
		     size.width - insets.right,
		     size.height - insets.bottom);
	  g.translate(xoffset + insets.left, yoffset + insets.top);
	  
	  g.setColor(Color.black);
	  
	  Graphics pointsGraphics = null;
	  if (showPointsOn) {
	    pointsGraphics = g.create();
	    pointsGraphics.setColor(Color.white);
	  }

	  g.fillOval(points.xpoints[0]-dotRadius,
		     points.ypoints[0]-dotRadius,
		     dotRadius*2, dotRadius*2);
	  int numPoints = (animate ? animatePoints : points.npoints);
	  if (numPoints > 1) {
	    int i;

	    for (i = 1; i < numPoints; i++) {
	      g.drawLine(points.xpoints[i-1], points.ypoints[i-1],
			 points.xpoints[i], points.ypoints[i]);
	      if (showPointsOn) {
		pointsGraphics.
		  drawLine(points.xpoints[i-1], points.ypoints[i-1],
			   points.xpoints[i-1], points.ypoints[i-1]);
	      }
	    }
	  }
	  if (showPointsOn && (numPoints > 0)) {
	    pointsGraphics.
	      drawLine(points.xpoints[numPoints-1],
		       points.ypoints[numPoints-1],
		       points.xpoints[numPoints-1],
		       points.ypoints[numPoints-1]);
	  }
	}
	finally {
	  g.dispose();
	}
      }
    }
  }

  // maybe someday make arg say which part of gesture changed so whole
  // thing doesn't have to be redrawn
  public void update(Observable gesture, Object arg)
  {
    /*
    if ((arg != null) && (arg instanceof TimedPolygon)) {
      preferredSize = null;
      revalidate();
    }
    */
    repaint();
  }

  public void setSelected(boolean on)
  {
    if (isSelected != on) {
      isSelected = on;
      repaint();
    }
  }

  public boolean getSelected()
  {
    return isSelected;
  }

  public boolean toggleSelected()
  {
    isSelected = !isSelected;
    repaint();
    return isSelected;
  }

  /**
   * Space to allow around the gesture
   */
  public void setOffset(int x, int y)
  {
    xoffset = x;
    yoffset = y;
    repaint();
  }

  /**
   * Whether to draw the individual points that compose the gesture
   */
  public void setShowPoints(boolean on)
  {
    if (showPointsOn != on) {
      showPointsOn = on;
      repaint();
    }
  }

  public boolean getShowPoints()
  {
    return showPointsOn;
  }

  public boolean getShowSelected()
  {
    return showSelected;
  }

  /**
   * If true, disables showing the fact that the gesture is selected
   */
  public void setShowSelected(boolean on)
  {
    if (showSelected != on) {
      showSelected = on;
      if (isSelected)
	repaint();
    }
  }

  /**
   * Borrowed narrowing from emacs.  Right now, makes narrowed things
   * highlight instead of hiding non-narrowed things.
   */
  public void setNarrowed(boolean on)
  {
    if (narrowed != on) {
      narrowed = on;
      setBackground(narrowed ? Color.white : Color.lightGray);
      repaint();
    }
  }

  public void toggleNarrowed()
  {
    setNarrowed(!narrowed);
  }

  public void setAnimated(boolean on)
  {
    if (animate != on) {
      animate = on;
      if (on) {
	startAnimation();
      }
      else {
	stopAnimation();
      }
    }
  }

  public boolean isAnimated()
  {
    return animate;
  }

  void startAnimation()
  {
    timer = new Timer(restartDelay, new AnimateStep());
    timer.setRepeats(true);
    timer.setCoalesce(false);
    timer.start();
  }

  void stopAnimation()
  {
    timer.stop();
  }

  class AnimateStep implements ActionListener {
    public AnimateStep()
    {
    }

    public void actionPerformed(ActionEvent e)
    {
      GesturePointsDisplay gpd = GesturePointsDisplay.this;
      TimedPolygon polygon = gpd.gesture.getPoints();
      int delay;
      gpd.animatePoints++;
      if (gpd.animatePoints == (polygon.npoints-1)) {
	// at end, so wait a different time before reanimating
	delay = restartDelay;
      }
      else {
	if (gpd.animatePoints >= polygon.npoints) {
	  gpd.animatePoints = 0;
	}
	if (validTimings) {
	  delay = (int) (polygon.times[gpd.animatePoints+1] -
			 polygon.times[gpd.animatePoints]) * normalDelay;
	}
	else {
	  delay = minDelay;
	}
	gpd.repaint();
      }
      gpd.timer.setDelay(delay);
    }
  }
}
