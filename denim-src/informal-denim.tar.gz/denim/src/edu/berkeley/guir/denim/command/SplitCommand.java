//// See bottom of source code for software license

package edu.berkeley.guir.denim.command;

import java.awt.Rectangle;
import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.interpreters.LabelInterpreter;
import edu.berkeley.guir.denim.interpreters.LabelInterpreter.AddStrokeToLabelCommand;
import edu.berkeley.guir.lib.awt.geom.Polygon2D;
import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.command.InsertCommand;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;
import edu.berkeley.guir.lib.satin.objects.GraphicalObject;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollection;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollectionImpl;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectGroup;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectLib;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;


/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Aug 7, 2004 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class SplitCommand extends UndoableCommand {

   private GraphicalObjectGroup      parent;
   private Point2D               separation;
   
   GraphicalObjectCollection scribbledtexts = null;
   //ScribbledText splittedText = null;
   GraphicalObject splittedText = null;
   
   boolean isVertical;
   
   DenimPanel mergedPanel = null;
   
   public SplitCommand(GraphicalObjectGroup parent, GraphicalObject st, // denimpanel or scirbbledtext 
           Point2D splitpoint, boolean v) {
       super();
       this.parent = parent;
       splittedText = st;
       this.separation = splitpoint;
       this.isVertical = v;
    } // of constructor


   //=======================================================================
   //===   COMMAND   =======================================================

   /**
    * Notifies the command system that this command can be redone.
    */
   public boolean canRedo() {
      return true;
   } // of method

   //-----------------------------------------------------------------

   public void run() {
       cmdsubsys.clearSelected();
       parent.disableDamage();
       // if we are splitting a scribbled text
       if(splittedText instanceof ScribbledText)
       {
           scribbledtexts = ScribbledText.split(parent, (ScribbledText)splittedText, separation, isVertical);
           if(scribbledtexts.isEmpty()==false)
           {
               parent.remove(splittedText);
           }
       }
       else // if we are splitting a denim label
       {
           DenimPanel panel = (DenimPanel)splittedText;
           ScribbledText text = (ScribbledText)(ScribbledText)panel.getLabel().getCaption();
           scribbledtexts = ScribbledText.split(parent, text, separation, isVertical);
           if(scribbledtexts.isEmpty()==false)
           {
               parent.remove(panel);
               this.createNewPanel((ScribbledText)scribbledtexts.get(0));
               DenimPanel panel1 = mergedPanel;
               this.createNewPanel((ScribbledText)scribbledtexts.get(1));
               DenimPanel panel2 = mergedPanel;
               parent.removeAll(scribbledtexts);
               scribbledtexts.clear();
               scribbledtexts.add(panel1);
               scribbledtexts.add(panel2);
               mergedPanel = null;
           }
       }
       parent.enableDamage();
       parent.damage(DAMAGE_NOW);
   }
   
   private void createNewPanel(ScribbledText text) {
       mergedPanel = null;
       
       AffineTransform sheetlocal = parent.getInverseTransform(COORD_ABS);
       Iterator tt = text.getForwardIterator();
       while(tt.hasNext())
       {
           TimedStroke stk = (TimedStroke)tt.next();
           this.addStroke(sheetlocal, stk);
       }       
   }

   
   private DenimLabel createNewLabel(TimedStroke stk) {
       ScribbledText           phrase;
       DenimLabel              label;
       DenimSketch             sketch;
       DenimPanel              panel;
       Rectangle2D             bounds;
       double                  scaleFactor;


       //debug.println("LabelInterpreter: parent = " + parent.getClass() +
       //                   ":" + parent.getUniqueID());

       //phrase      = new Phrase();
       phrase      = new ScribbledText();
       bounds      = stk.getBounds2D(COORD_ABS);
       scaleFactor = GraphicalObjectLib.getScaleFactor(COORD_ABS, parent);

       //// 1. Create phrase.
       ////    Give it a bogus temp location.
       phrase.setBoundingPoints2D(COORD_ABS, new Rectangle(0, 0, 20, 20));
       parent.add(phrase, GraphicalObjectGroup.KEEP_ABS_POS);

       phrase.setBoundingPoints2D(COORD_ABS, bounds);
       phrase.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);

       //// 2. Create label.
       label  = new DenimLabel(phrase);
       bounds = label.getBounds2D(COORD_ABS);
       
       //// 3. Create sketch.
       sketch = new DenimSketch(new Rectangle2D.Double(
                                  bounds.getX(),
                                  bounds.getY() + bounds.getHeight(),
                                  //(int)(DEFAULT_SKETCH_WIDTH  * scaleFactor),
                                  //(int)(DEFAULT_SKETCH_HEIGHT * scaleFactor)));
                                            (int)(DenimSketch.getDefaultSketchWidth()  * scaleFactor),
                                            (int)(DenimSketch.getDefaultSketchHeight() * scaleFactor)));

       //// 4. Create panel.
       panel = new DenimPanel(new Rectangle(0, 0, 1, 1));

       //// throw this into the command queue, so it can be undone
       new InsertCommand(parent, panel,
                                        GraphicalObjectGroup.KEEP_ABS_POS).run();

       panel.setLabel(label);
       panel.setSketch(sketch);

       // HACK: Fix view for sketch, now that it has been added to sheet
       label.initAfterAddLabelToSheet();
       sketch.initAfterAddSketchToSheet();

       //// 5. Adjust the width of the stroke
       stk.getStyleRef().setLineWidth
          ((float)(1.0 / DenimUtils.getTrueAbsXform(stk).getScaleX()));
          
       return label;
    } // of method

   private void addStroke(AffineTransform sheetlocal, TimedStroke stk) {
       Polygon2D poly = stk.getPolygon2D(COORD_ABS);
       poly.transform(sheetlocal);
       TimedStroke s = new TimedStroke(poly);
       s.getStyleRef().setLineWidth
           ((float)(1.0 / DenimUtils.getTrueAbsXform(stk).getScaleX()));
       parent.add(s);
       s.moveTo(COORD_ABS, stk.getLocation2D(COORD_ABS));
       
       if(mergedPanel==null)
       {
           mergedPanel = this.createNewLabel(s).getPanel();
       }
       else
       {
           new LabelInterpreter().new AddStrokeToLabelCommand(mergedPanel.getLabel(), s).run();
       }
   }
   
   //-----------------------------------------------------------------

   public void redo() {
      run();
   } // of method
      
   //-----------------------------------------------------------------

   public void undo() {
       if(scribbledtexts.isEmpty()==false)
       {
           parent.disableDamage();
           parent.addToFront(splittedText);
           parent.removeAll(this.scribbledtexts);
           parent.enableDamage();
           parent.damage(DAMAGE_NOW);
       }
   }
} // of class




//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
    must display the following acknowledgement:

        This product includes software developed by the Group for User 
        Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
    derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/