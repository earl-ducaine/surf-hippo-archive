package edu.berkeley.guir.damask.dialog;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Content;

/** 
 * A dialog that acts as a template for other dialogs.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  05-18-2004 James Lin
 *                               Created TemplateDialog.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-04-2003
 */
public class TemplateDialog extends Dialog {

   /**
    * Creates a dialog with the specified page title, for the specified 
    * device type (which can be DeviceType.ALL).
    */   
   public TemplateDialog(final DeviceType deviceType, final Content pageTitle) {
      super(deviceType, pageTitle);
   }
}
