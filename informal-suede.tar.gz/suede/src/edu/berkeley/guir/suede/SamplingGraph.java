package edu.berkeley.guir.suede;

// This class is a thread that updates the slider position on a node

public class SamplingGraph implements Runnable {

   private ElementViewInter m_element;
   private Thread    thread;
   private CardSound m_cardSound; 
   private boolean   m_isPlay;
   private double    m_duration; //the entire length of the element's audio stream           
        

   public void setElement(ElementViewInter element) {
      m_element = element;
   }
       
       
   public void startCapture(CardSound cardSound) {
      m_isPlay = false; //we're recording, so update the slider record style
      m_cardSound = cardSound;
      start();
   }

         
   public void startPlay(CardSound cardSound) {
      m_isPlay = true; //we're playing, so update the slider play style
      m_cardSound = cardSound;
      m_duration = m_cardSound.getDuration();
      start();
   }

         
   private void start() {
      thread = new Thread(this);
      thread.setName("SamplingGraph");
      thread.start();
      m_cardSound.setToBeginning();
   }


   public void stop() {
      if (thread != null) thread.interrupt();
          
      thread = null;
   }


   /*public void setStopped() {
      m_element.setStopped();         
   }*/

   
   private void updateSliderPlay() {
      m_element.setCurTime(m_cardSound.getSeconds());                    
   }
      
      
   private void updateSliderCapture() {
      m_element.setCurTime(m_cardSound.getSeconds()); 
   }
      
      
   public void run() {
      while (thread != null) {
         if (m_isPlay) updateSliderPlay();
         else updateSliderCapture();
                
         //try { thread.sleep(100); } catch (Exception e) { break; }
		try { Thread.sleep(100); } catch (Exception e) { break; }

      }
                
      //after we're all done, return to the stopped state          
      m_element.setStopped();
   }


} // End class SamplingGraph