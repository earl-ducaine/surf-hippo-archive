//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.graphics;

import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.collection.*;
import edu.berkeley.guir.lib.debugging.*;
import java.util.ArrayList;
import java.awt.geom.*;

/**
 * This class is used as part of the optimizations in rendering animations.
 * Essentially, you queue up everything you want to render. The RepaintQueue
 * then tries to paint everything it can within a specified time limit. If it 
 * fails, then it clears out the queue in preparation for the next animation
 * frame.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 19 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class RepaintQueue {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   /**
    * Most number of objects we can create and render at one time.
    */
   private static final int POOLSIZE = 500;

   //-----------------------------------------------------------------

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   PAINT OBJECT INNER CLASS   ==========================================

   /**
    * An ObjectPool of PaintObjects.
    */
   final class PaintObjectPool extends ObjectPool {

      public PaintObjectPool(int size) {
         super(size);
      } // of constructor

      protected Object createObject() {
         return (new PaintObject());
      } // of createObject
   } // of inner class PaintObjectPool 

   //=================================================================

   /**
    * Specifies the view to render.
    */
   final class PaintObject {
      Style           s;
      AffineTransform tx;
      View            v;

      public PaintObject() {
      } // of default constructor

      public PaintObject(View v, Style s, AffineTransform tx) {
         this.v  = v;
         this.s  = s;
         this.tx = tx;
      } // of constructor

      public final void render(SatinGraphics g) {
         g.pushStyle(s);
         g.pushTransform(tx);
         v.render(g);
         g.popTransform();
         g.popStyle();
      } // of render
   } // of inner class PaintObject

   //===   PAINT OBJECT INNER CLASS   ==========================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   ArrayList       queue = new ArrayList(POOLSIZE);
   PaintObjectPool pool  = new PaintObjectPool(POOLSIZE);

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public RepaintQueue() {
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   QUEUEING METHODS   ==================================================

   public void enqueue(View v, Style s, AffineTransform tx) {
      try {
         PaintObject pobj = (PaintObject) pool.getObject();
         pobj.v  = v;
         pobj.s  = s;
         pobj.tx = tx;
         queue.add(pobj);
      }
      catch (Exception e) {
         Debug.println("Failed to enqueue, out of objects in ObjectPool");
      }
   } // of enqueue

   //===   QUEUEING METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   PAINT METHODS   =====================================================

   private void clear() {
      pool.reset();
      queue.clear();
   } // of clear

   //-----------------------------------------------------------------

   public void blit(SatinGraphics g) {
      PaintObject p;

      for (int i = 0; i < queue.size(); i++) {
         p = (PaintObject) queue.get(i);
         p.render(g);
      }
      clear();
   } // of blit

   //-----------------------------------------------------------------

   public void blit(SatinGraphics g, long ms) {
      PaintObject p;
      long        endTime      = System.currentTimeMillis() + ms;
      int         i;
      boolean     flagBlitRest = false;

      //// 1. Blit everything that we can in the allocated time.
      for (i = 0; i < queue.size(); i++) {
         p = (PaintObject) queue.get(i);
         p.render(g);
         if (System.currentTimeMillis() > endTime) {
            flagBlitRest = true;
            break;
         }
      }

      //// 2. Blit everything else as low quality images.
      if (flagBlitRest == true) {
         g.setRenderQuality(GraphicsConstants.LOWEST_QUALITY);
         for ( ; i < queue.size(); i++) {
            p = (PaintObject) queue.get(i);
            p.render(g);
         }
      }

      //// 3. Clear out the queue.
      clear();
   } // of blit

   //===   PAINT METHODS   =====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
