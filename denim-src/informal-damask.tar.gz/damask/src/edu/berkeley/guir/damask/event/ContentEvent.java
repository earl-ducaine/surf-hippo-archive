package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Content;

/** 
 * An event that indicates that a property of a piece of content has changed.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-23-2004 James Lin
 *                               Created ContentEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 04-23-2004
 */
public class ContentEvent extends EventObject {

   private final Type eventType;   
   private final DeviceType deviceType;
   private final Object oldValue;
   private final Object newValue;
   
   //===========================================================================

   public static class Type {
      private final String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type STROKE_ADDED = new Type("stroke added");
   public static final Type STROKE_REMOVED = new Type("stroke removed");
   public static final Type STROKES_CHANGED = new Type("strokes changed");
   public static final Type TEXT_CHANGED = new Type("text changed");
   public static final Type IMAGE_CHANGED = new Type("image changed");
   public static final Type PREFERRED_DISPLAY_MODE_CHANGED =
      new Type("content's preferred display mode changed");
   public static final Type PROMPT_TEXT_SYNCED =
      new Type("content's prompt text is synchronized with its text");
   public static final Type PROMPT_TEXT_UNSYNCED =
      new Type("content's prompt text is not synchronized with its text");

   //===========================================================================

   /**
    * Constructs a ConnectionEvent, which gets fired when the source,
    * destination, shape, event type, or condition of a connection is changed.
    */
   public ContentEvent(
      final Content source,
      final Type eventType,
      final DeviceType deviceType,
      final Object oldValue,
      final Object newValue) {

      super(source);
      this.eventType = eventType;
      this.deviceType = deviceType;
      this.oldValue = oldValue;
      this.newValue = newValue;
   }
   
   //===========================================================================

   /**
    * Returns the content affected by the event.
    */
   public Content getContent() {
      return (Content)source;
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the device type affected by the event.
    */
   public DeviceType getDeviceType() {
      return deviceType;
   }
   
   //===========================================================================
   
   /**
    * Returns the old value of the property being changed.
    */
   public Object getOldValue() {
      return oldValue;
   }
   
   //===========================================================================
   
   /**
    * Returns the new value of the property being changed.
    */
   public Object getNewValue() {
      return newValue;
   }
}
