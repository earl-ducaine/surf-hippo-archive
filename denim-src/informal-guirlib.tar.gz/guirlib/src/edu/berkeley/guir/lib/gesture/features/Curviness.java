package edu.berkeley.guir.lib.gesture.features;

import java.awt.Polygon;
import edu.berkeley.guir.lib.gesture.Feature;
import edu.berkeley.guir.lib.gesture.Gesture;

/** Approximates gesture curviness by computing sum of all angles
    between two thresholds. */
public class Curviness extends Feature {
  public static double lowerThreshold = 5;
  public static double upperThreshold = 20;

  public Curviness()
  {
    super();
  }

  public Curviness(Gesture g)
  {
    super(g);
  }

  public String getName()
  {
    return "curviness";
  }
  
  public double getMinValue()
  {
    return 0;
  }
  
  public double getMaxValue()
  {
    return Double.MAX_VALUE;
  }
  
  protected void computeValue()
  {
    Polygon points = gesture.getPointsRef();
    value = 0;

    double lowerThresholdRadians = lowerThreshold / 180 * Math.PI;
    double upperThresholdRadians = upperThreshold / 180 * Math.PI;
    for (int i = 2; i < points.npoints; i++) {
      double dx = points.xpoints[i] - points.xpoints[i-1];
      double dy = points.ypoints[i] - points.ypoints[i-1];
      double dx2 = points.xpoints[i-1] - points.xpoints[i-2];
      double dy2 = points.ypoints[i-1] - points.ypoints[i-2];
      double theta = Math.atan2(dx*dy2 - dx2*dy, dx*dx2 + dy*dy2);
      double absTheta = Math.abs(theta);

      if ((absTheta > lowerThresholdRadians) &&
	  (absTheta < upperThresholdRadians))
	value += theta;
    }

    value = Math.abs(value);
    valueOk = true;
  }

  public void scale(double factor)
  {
  }
}
