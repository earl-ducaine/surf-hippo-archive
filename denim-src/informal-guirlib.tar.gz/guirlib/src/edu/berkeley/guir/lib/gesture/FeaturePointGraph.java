package edu.berkeley.guir.lib.gesture;

import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.*;

import javax.swing.*;
import javax.swing.text.*;

import edu.berkeley.guir.lib.gesture.util.Misc;

/**
 * Displays a graph of Feature values for a GestureSet.  Plots the
 * value of every feature for every example Gesture of every
 * GestureCategory.
 */
public class FeaturePointGraph extends JPanel implements Observer,
  Scrollable
{
  private BitSet categoryMask;
  private boolean useWeights = false;
  private Classifier classifier;
  static final int xborder = 30, topBorder = 20, bottomBorder = 80;
  static final int minFeatureOffset = 50;
  static final int categoryOffset = 5;
  Dimension size;
  int axesWidth = 3;
  int xorig;
  int yorig;
  int height;
  int width;
  int featureOffset = minFeatureOffset;
  int numCategories;	// based on categoryMask, if used
  FeaturePicker featurePicker;
  JTextPane[] featureLabels;
  static final int labelHeight = 70; // voodoo constant
  static final int minLabelWidth = 100; // voodoo constant
  FPGraphFeature[] fpFeatureGraphs;

  public FeaturePointGraph(Classifier c, BitSet categoryMask)
  {
    super();
    this.categoryMask = categoryMask;
    classifier = c;
    GestureSet gs = classifier.getGestureSet();
    if (gs != null) {
      gs.addObserver(this);
    }
    initUI();
  }

  public FeaturePointGraph(Classifier c)
  {
    this(c, Misc.not(new BitSet(c.getGestureSet().size())));
  }

  private void initUI()
  {
    setBorder(BorderFactory.createEtchedBorder());
    setBackground(Color.white);
    GridBagLayout gridbag = new GridBagLayout();
    setLayout(gridbag);

    int numFeatures = FeatureVector.defaultSize();

    GridBagConstraints dataConstraints = new GridBagConstraints();
    dataConstraints.fill = GridBagConstraints.VERTICAL;
    dataConstraints.weighty = 1.0;
    GridBagConstraints labelConstraints = new GridBagConstraints();
    labelConstraints.fill = GridBagConstraints.NONE;
    featureLabels = new JTextPane[numFeatures];
    fpFeatureGraphs = new FPGraphFeature[numFeatures];
    FeatureVector dummyFV = new FeatureVector();
    SimpleAttributeSet centerStyle = new SimpleAttributeSet();
    StyleConstants.setAlignment(centerStyle, StyleConstants.ALIGN_CENTER);
    for (int i = 0; i < numFeatures; i++) {
      fpFeatureGraphs[i] = new FPGraphFeature(classifier, i, categoryMask);
      fpFeatureGraphs[i].setBorder(BorderFactory.createEtchedBorder());
      if (i == (numFeatures-1))
	// mark end-of-row
	dataConstraints.gridwidth = GridBagConstraints.REMAINDER;
      add(fpFeatureGraphs[i], dataConstraints);
    }
    
    for (int i = 0; i < numFeatures; i++) {
      DefaultStyledDocument doc = new DefaultStyledDocument();
      try {
	doc.insertString(0, dummyFV.getFeature(i).getName(), centerStyle);
      }
      catch (BadLocationException e) {
	System.err.println("Bogosity in FeaturePointGraph.initUI");
	break;
      }
      featureLabels[i] = new JTextPane(doc);
      featureLabels[i].setEditable(false);
      featureLabels[i].setBorder(BorderFactory.createEtchedBorder());
      int width = fpFeatureGraphs[i].getPreferredSize().width;
      featureLabels[i].
	setPreferredSize(new Dimension((width > minLabelWidth) ?
				       width : minLabelWidth,
				       labelHeight));
      add(featureLabels[i], labelConstraints);
    }
  }
  
  void rebuildUI()
  {
    int numFeatures = FeatureVector.defaultSize();
    GridBagConstraints dataConstraints = new GridBagConstraints();
    dataConstraints.fill = GridBagConstraints.VERTICAL;
    dataConstraints.weighty = 1.0;
    GridBagLayout gridbag = (GridBagLayout) getLayout();

    int lastOne = 0;
    for (int i = 0; i < numFeatures; i++) {
      boolean on = true;
      if (featurePicker != null) {
	on = featurePicker.isFeatureSelected(i);
	fpFeatureGraphs[i].setVisible(on);
	featureLabels[i].setVisible(on);
      }
      if (on) {
	int width = fpFeatureGraphs[i].getPreferredSize().width;
	featureLabels[i].
	  setPreferredSize(new Dimension((width > minLabelWidth) ?
					 width : minLabelWidth,
					 labelHeight));
	featureLabels[i].invalidate();
	gridbag.setConstraints(fpFeatureGraphs[i], dataConstraints);
	lastOne = i;
      }
    }
    dataConstraints.gridwidth = GridBagConstraints.REMAINDER;
    gridbag.setConstraints(fpFeatureGraphs[lastOne], dataConstraints);
    
    invalidate();
    Window w = (Window) getTopLevelAncestor();
    if (w != null)
      w.pack();
    repaint();
  }

  public void setCategoryMask(BitSet catMask)
  {
    if (!catMask.equals(categoryMask)) {
      categoryMask = (BitSet) catMask.clone();
      for (int i = 0; i < fpFeatureGraphs.length; i++) {
	fpFeatureGraphs[i].setCategoryMask(catMask);
      }
      rebuildUI();
    }
  }

  public BitSet getCategoryMask()
  {
    return (BitSet) categoryMask.clone();
  }
  
  public void update(Observable observable, Object arg)
  {
    // todo: maybe someday make this smarter
    if (classifier != null) {
      setClassifier(classifier);
    }
    invalidate();
    repaint();
  }

  public void setFeaturePicker(FeaturePicker fp)
  {
    featurePicker = fp;
    featurePicker.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e)
      {
	rebuildUI();
      }
    });
    rebuildUI();
  }

  /**
   * It is the caller's responsibility to ensure that this Classifier
   * corresponds to the GestureSet being graphed.  Also, it must be trainable
   * when set.  Otherwise this is a no-op.
   */
  public void setClassifier(Classifier c)
  {
    classifier = c;
    if (!classifier.trained) {
      try {
	classifier.train();
	repaint();
      }
      catch (TrainingException e) {
	if (useWeights) {
	  System.err.println("Weights disabled because classifier could not be trained");
	  useWeights = false;
	}
      }
      catch (InterruptedException e) {
	if (useWeights) {
	  System.err.println("Weights disabled because classifier was interrupted while training");
	  useWeights = false;
	}
      }
    }
  }

  /** This has no effect if a trainable classifier has not been set */
  public void weightsOn(boolean on)
  {
    if (useWeights != on) {
      useWeights = on;
      for (int i = 0; i < fpFeatureGraphs.length; i++) {
	fpFeatureGraphs[i].weightsOn(on);
      }
    }
  }

  public Dimension getPreferredScrollableViewportSize()
  {
    return getPreferredSize();
  }
  
  public int getScrollableUnitIncrement(Rectangle visibleRect,
					int orientation,
					int direction)
  {
    return PlotColumn.columnWidth;
  }
  
  public int getScrollableBlockIncrement(Rectangle visibleRect,
					 int orientation,
					 int direction)
  {
    return visibleRect.width;
  }
  
  public boolean getScrollableTracksViewportWidth()
  {
    return false;
  }

  public boolean getScrollableTracksViewportHeight()
  {
    return true;
  }
  
}
