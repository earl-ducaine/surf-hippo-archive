package edu.berkeley.guir.suede;

// ScriptNodes and SingleNodes share several properties, among them the ability to save and the ability to have balloons

public interface SSavableElt
{
    public String save(String path, String externalFileName);
    
    public int getNumBalloons();
    
    public void playBalloon(int i);
    
    public void setStopped();
    
    public void callWhenBalloonFinished();
}