package edu.berkeley.guir.lib.gesture;

import java.util.*;
import java.io.*;
import java.text.ParseException;
import edu.berkeley.guir.lib.gesture.util.*;

public class GestureGroup extends AbstractGestureContainer
  implements Cloneable {
  Vector categories;
  protected CollectionListener listener = new MyCollectionListener();

  public GestureGroup()
  {
    this(null);
  }
  
  public GestureGroup(String name)
  {
    super();
    setName(name);
    categories = new Vector();
  }

  public Vector getCategories()
  {
    return categories;
  }

  public void setCategories(Vector newCategories)
  {
    if (categories != newCategories) {
      Vector oldValue = categories;
      categories = newCategories;
      propChangeSupport.firePropertyChange(CHILDREN_PROP,
					   oldValue, categories);
      setChanged();
      notifyObservers(categories);
    }
  }

  protected List getChildren()
  {
    return categories;
  }
  
  public GestureCategory get(int i)
  {
    return (GestureCategory) categories.get(i);
  }
  
  /**
   * Add the given category to the set if it isn't already in it.
   */
  public void addCategory(GestureCategory gc)
  {
    add(gc);
  }

  public void removeCategory(GestureCategory gc)
  {
    remove(gc);
  }

  public GestureCategory categoryAt(int i)
  {
    return (GestureCategory) categories.get(i);
  }

  private static final Class[] CHILD_TYPES = { GestureCategory.class };
  public Class[] getChildTypes()
  {
    return CHILD_TYPES;
  }
  
  public void update(Observable gestureCategory, Object arg)
  {
    setChanged();
    notifyObservers(gestureCategory);
  }

  public void write(Writer writer) throws IOException
  {
    writer.write("name\t" + name + "\n");
    if (author != null) {
      writer.write("author\t" + author + "\n");
    }
    for (int i = 0; i < categories.size(); i++) {
      writer.write("category\n");
      GestureCategory gc = categoryAt(i);
      gc.write(writer);
    }
    writer.write("endgroup\n");
  }

  public static GestureGroup read(Reader reader) throws IOException,
    ParseException
  {
    GestureGroup result = new GestureGroup();
    
    boolean done = false;
    TokenReader r = new TokenReader(reader);
    while (!done) {
      String token;
      try {
	token = r.readToken().intern();
	//System.out.println("GestureGroup  \ttoken: " + token);
	if (token == "name") {
	  result.name = r.readLine();
	}
	else if (token == "author") {
	  result.author = r.readLine();
	}
	else if (token == "category") {
	  GestureCategory gc = GestureCategory.read(r);
	  result.add(gc);
	}
	else if (token == "endgroup") {
	  done = true;
	}
      }
      catch (EOFException e) {
	done = true;
      }
    }
    //System.err.println("Read set '" + result.getName() + "'");
    return result;
  }
  
  public Object clone()
  {
    GestureGroup gg = (GestureGroup) super.clone();
    gg.categories = (Vector) Misc.deepCopy(categories);
    gg.fixParents();
    return gg;
  }

  public String toString()
  {
    return getName();
  }

  protected class MyCollectionListener extends CollectionAdapter {
    // todo
  }
}
