//// See bottom of source code for software license.
package edu.berkeley.guir.lib.util;

import java.util.LinkedList;
import java.util.List;

/**
 * Utility methods for manipulating classes and classnames.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 23 2004
 */
final public class ClassLib {

    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Utility class, no instances allowed.
     */
    private ClassLib() {
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY METHODS - CLASS HIERARCHY   ================================

    /**
     * Get all of the superclasses and interfaces of this class.
     * For example, given String, return [java.lang.String, java.lang.Object]
     */
    public static final List flatten(Class cl) {
        LinkedList listClasses = new LinkedList();

        //// 1. While we still can go up the inheritance tree...
        while (cl != null) {
            //// 1.1. Add the current class...
            listClasses.add(cl);

            //// 1.2. Add all of the interfaces of the current class...
            Class[] clArr = cl.getInterfaces();
            for (int i = 0; i < clArr.length; i++) {
                listClasses.add(clArr[i]);
            }

            //// 1.3. Get the superclass...
            cl = cl.getSuperclass();
        }

        return (listClasses);
    } // of method

    //===   UTILITY METHODS - CLASS HIERARCHY   ================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY METHODS - STRING PRESENTATION   ============================
    
    /**
     * Given an instance, get a shortened version of the class name.
     * For example, given a String instance like "dog", return
     * String (shortened from java.lang.String). The only exception is if
     * the parameter is of type Class; return the Class's name in this case.
     */
	public static String getShortClassName(final Object obj) {
		final String longName;
		if (obj instanceof Class) {
			longName = ((Class) obj).getName();
		} else {
			longName = obj.getClass().getName();
		}
		return toShortClassName(longName);
	}

    //--------------------

    /**
     * Assuming strClassName is the name of a class, get the short class name.
     */
    public static final String toShortClassName(String strClassName) {
        int    index        = strClassName.lastIndexOf('.');

        //// 1.1. Handle the normal case.
        if (index >= 0) {
            return (strClassName.substring(index + 1));
        }
        //// 1.2. Handle the no-package case.
        else {
            return (strClassName);
        }
    } // of method

    //===   UTILITY METHODS - STRING PRESENTATION   ============================
    //==========================================================================




    //==========================================================================
    //===   UTILITY METHODS - CLASS LOADING   ==================================

    /**
     * Try to load the specified class using the specified ClassLoader.
     */
    public static Class load(String strClassName, ClassLoader loader) {
        if (loader != null) {
            try {
                return (loader.loadClass(strClassName));
            }
            catch( ClassNotFoundException ex ) {
                // ignore
            }
        }
        return (null);
    } // of method

    //----------------------------------------------------------------

    /**
     * Try to load the specified class.
     * @see #loadClass(String,Class)
     */
    public static Class loadClass(String strClassName)
        throws ClassNotFoundException {

        return (loadClass(strClassName, null));
    } // of method

    //----------------------------------------------------------------

    /**
     * Load a class, try first the thread class loader, and
     * if it fails use the loader that loaded this class.
     * Derived from Apache commons-logging.
     *
     * <P>
     * Tries the following ClassLoaders in order:
     * <UL>
     *    <LI>Thread.currentThread().getContextClassLoader()
     *    <LI>clCaller.getClassLoader()
     *    <LI>ClassLib.class.getClassLoader()
     * </UL>
     *
     * @param strClassName is the name of the class to load.
     * @param clCaller     is the Class of the caller (optional).
     *                     This is the second ClassLoader to try. 
     *                     Use null to skip.
     */
    public static Class loadClass(String strClassName, Class clCaller)
        throws ClassNotFoundException {

        Class cl;

        //// 1. First try, try the current thread.
        cl = load(strClassName,Thread.currentThread().getContextClassLoader());
        if (cl != null) {
            return (cl);
        }

        //// 2. Second try, try the caller.
        cl = load(strClassName, clCaller.getClassLoader());
        if (cl != null) {
            return (cl);
        }

        //// 3. Third try, try ClassLib.
        cl = load(strClassName, ClassLib.class.getClassLoader());
        if (cl != null) {
            return (cl);
        }

        //// 4. Return.
        return Class.forName( strClassName );
    } // of method

    //===   UTILITY METHODS - CLASS LOADING   ==================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static void runTestAAA() {
       System.out.println("".getClass());
       System.out.println(getShortClassName(""));
       System.out.println(getShortClassName(Cloneable.class));
    } // of method

    //--------------------

    private static void runTestBBB() {
        System.out.println(flatten(String.class));
        System.out.println();
        System.out.println(flatten(Object.class));
        System.out.println();
        System.out.println(flatten(StringBuffer.class));
        System.out.println();
        System.out.println(flatten(Integer.class));
        System.out.println();
        System.out.println(flatten(LinkedList.class));
        System.out.println();
    } // of method
    
    private static void runTestJackHasBeenHereHahaha() {
    	final String testString = "";
		System.out.println("String =?= "+getShortClassName(testString));
    	System.out.println("String =?= "+getShortClassName(testString.getClass()));
    	final List testList = new LinkedList();
		System.out.println("LinkedList =?= "+getShortClassName(testList));
    	System.out.println("LinkedList =?= "+getShortClassName(testList.getClass()));
    }

    //----------------------------------------------------------------

    public static void main(String[] argv) {
        runTestJackHasBeenHereHahaha();
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
