package edu.berkeley.guir.denim.awt;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.toolbox.*;
import edu.berkeley.guir.lib.awt.*;
import edu.berkeley.guir.lib.io.*;
import java.awt.*;
import java.io.*;
import java.util.*;

/**
 * Plays back Swing events into DENIM.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-31-2001 James Lin
 *                               Separated from
 *                               edu.berkeley.guir.lib.awt.EventPlayer
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 07-31-2001
 */
public class DenimEventPlayer extends EventPlayer {

   private DenimUI ui;
   private java.util.List denimWindows;

   /**
    * Constructs a Robot and buffered reader.
    * If skipRestore is true, just skip over the header of the
    * event file and start replaying.  This is handy for profiling
    * and for cloning objects, but may possibly fail at some point.
    */
   public DenimEventPlayer(java.util.List denimWindows, String filename, boolean skipRestore, float speedFactor)
   throws AWTException, IOException {
      super(FileLib.addFileNameExtension(filename, "txt"),speedFactor);

      this.denimWindows = denimWindows;
      if (skipRestore) skipOverState();
      else restoreState();
   }

   private void skipOverState() throws IOException {
      for (int i = 0; i < denimWindows.size(); i++) {
         String line = in.readLine();
         while (!line.startsWith("----end window")) {
            line = in.readLine();
         }
      }
   }

   /**
    * Restore state of each Denim window.
    */
   private void restoreState() throws IOException {
      for (int i = 0; i < denimWindows.size(); i++) {
         String stateFileName = in.readLine();
         String line = in.readLine();

         String size = line.substring(line.indexOf("(")+1, line.indexOf(")-D"));
         int width = Double.valueOf(size.substring(0, size.indexOf(","))).intValue();
         int height = Double.valueOf(size.substring(size.indexOf(",")+1)).intValue();

         String loc = line.substring(line.lastIndexOf("(")+1, line.indexOf(")-S"));
         int xWin = Double.valueOf(loc.substring(0, loc.indexOf(","))).intValue();
         int yWin = Double.valueOf(loc.substring(loc.indexOf(",")+1)).intValue();

         DenimWindow window = (DenimWindow)denimWindows.get(i);
         ui = window.getDenimUI();

         //sets location and size of window
         window.setLocation(new Point(xWin, yWin));
         window.setSize(new Dimension(width, height));

         //ui.getSheet().clear();
         try {
            // restores what was previously on the canvas
            ui.getSheet().open(new File(stateFileName));
         }
         catch (Exception e) {
         }

         Tool startTool = ui.getCurrentTool();
         Tool match = null;
         if (startTool != null) {
            String startToolName = startTool.getName();

            //drop starting tool
            match = toolMatch(startToolName);
            if (match != null) {
               match.drop(ui.getToolbox().getToolsArea(), new Point(50, 10));
            }
         }

         // restoring state to appropriate coordinates
         line = in.readLine();
         while (!line.startsWith("----end window")) {

            // set the state of the zoom slider
            if (line.startsWith("slider")) {
               ZoomSlider slider = ui.getZoomSlider();
               int value = Integer.parseInt(line.substring(line.indexOf(":")+1));
               slider.setValue(value);
               line = in.readLine();
               continue;
            }

            // set current tool
            if (line.startsWith("currentTool")) {
               String currentTool = line.substring(line.indexOf(":")+1);
               match = toolMatch(currentTool);
               if (match != null) {
                  match.grab();
               }
            }

            // set other tools in toolbox
            if (line.startsWith("otherTool")) {
               String otherTool = line.substring(line.indexOf(":")+1, line.indexOf("@"));
               String location = line.substring(line.indexOf("(")+1,line.lastIndexOf(")-R"));

               match = toolMatch(otherTool);
               if (match != null) {
                  int x = Integer.parseInt(location.substring(0, location.indexOf(",")));
                  int y = Integer.parseInt(location.substring(location.indexOf(",")+1));
                  match.setLocation(new Point(x, y));
               }
            }

            line = in.readLine();
         } // of main while
      } // of for loop
   }

   /**
    * Checks for matching tool in iterator.
    */
   private Tool toolMatch(String compareTool) {
      Tool tool = null;
      Iterator it = ui.getToolsIterator();
      while (it.hasNext()) {
         tool = (Tool)it.next();
         String toolName = tool.getName();

         if (toolName.equalsIgnoreCase(compareTool)) {
            return tool;
         }
      }
      return tool;
   }
   
/*   public void performanceTest() {
      
      edu.berkeley.guir.lib.util.Timer timer = new edu.berkeley.guir.lib.util.Timer();
      
      robot.setAutoWaitForIdle(true);            
           
      System.out.println();

      try {

         timer.resetTimer();
         timer.start();

         String line = in.readLine();

         while (line != null) {

            
            int delay = Integer.parseInt(line.substring(0, line.indexOf("ms")));

            int offset = line.indexOf("MouseEvent[ MOUSE");

            if (offset == -1) {
               offset = line.indexOf("KeyEvent[ KEY");
            }

            if (line.startsWith("MouseEvent[ MOUSE_MOVED", offset)) {
               String coords = line.substring(line.indexOf("(")+1, line.lastIndexOf(")-S"));
               int x = Integer.parseInt(coords.substring(0, coords.indexOf(",")));
               int y = 0;
               if (coords.indexOf(")") == -1) { //in case an extra point gets recorded--it has happened though i don't know why!
                  y = Integer.parseInt(coords.substring(coords.indexOf(",")+1));
               }
               else {
                  y = Integer.parseInt
                     (coords.substring(coords.indexOf(",")+1, coords.indexOf(")")));
               }

               robot.mouseMove(x, y);
            }
            else if (line.startsWith("MouseEvent[ MOUSE_PRESSED", offset)) {
               int button = -1;
               if (line.indexOf("LT") != -1) {
                  button = InputEvent.BUTTON1_MASK;
               }
               else if (line.indexOf("MI") != -1) {
                  button = InputEvent.BUTTON2_MASK;
               }
               else if (line.indexOf("RT") != -1) {
                  button = InputEvent.BUTTON3_MASK;
               }

               robot.mousePress(button);
            }

            else if (line.startsWith("MouseEvent[ MOUSE_RELEASED", offset)) {
               int button = -1;
               if (line.indexOf("LT") != -1) {
                  button = InputEvent.BUTTON1_MASK;
               }
               else if (line.indexOf("MI") != -1) {
                  button = InputEvent.BUTTON2_MASK;
               }
               else if (line.indexOf("RT") != -1) {
                  button = InputEvent.BUTTON3_MASK;
               }

               robot.mouseRelease(button);
            }

            line = in.readLine();
         }
      }
      catch (IOException e) {
         System.out.println("ERROR IOException: " + e);
      }
      
      timer.stop();
      System.out.println("Elapsed time " + timer.getElapsedTime());   
   }
*/
}

//==============================================================================

/*
Copyright (c) 2001 by the Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
