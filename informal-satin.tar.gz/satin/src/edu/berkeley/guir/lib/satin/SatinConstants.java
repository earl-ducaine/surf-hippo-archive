//// See bottom of file for software license 

package edu.berkeley.guir.lib.satin;

import java.awt.geom.*;
import java.util.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.collection.*;
import edu.berkeley.guir.lib.properties.*;
import edu.berkeley.guir.lib.satin.command.*;

/**
 * Satin constants.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 16 1999, JH
 *               Created 
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * 			   - SATIN-v2.1-2,   Nov 8 2002, YL
 * 				 add constant DAMAGE_IDLE
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Nov 8 2002
 */
public interface SatinConstants {

   //===========================================================================
   //===   GLOBAL SATIN PROPERTIES   ===========================================

   /**
    * The name of Satin's properties file. Assumed to be in the current
    * directory, from which Satin is started (via the java interpreter).
    */
   public static final String SATIN_PROPERTIES_FILENAME = "satin.properties";

   //-----------------------------------------------------------------

   /**
    * The location of all of the data and properties files.
    */
   public static final String SATIN_DATA_DIRECTORY_GPROPERTY =
      "SATIN_DATA_DIRECTORY_GPROPERTY";
   
   public static final String SATIN_DATA_DIRECTORY_DEFAULT  = "data/";

   //---------------------------------------------------------------------

   /**
    * The name of the file containing the default debug properties.
    */
   public static final String DEBUG_STYLE_FILE = "Debug.properties";

   /**
    * Global property for debugging style.
    * @see #glprops
    */
   public static final String DEBUG_STYLE_GPROPERTY  = "DEBUG_STYLE";

   //===   GLOBAL SATIN PROPERTIES   ===========================================
   //===========================================================================



   //===========================================================================
   //===   OBJECT POOL INNER CLASSES   =========================================

   //// These used to do something interesting, but we got rid of
   //// ObjectPools, so I changed the values from 20 to 2.
   public static final int DEFAULT_TRANSFORM_POOL_SIZE    = 2;
   public static final int DEFAULT_RECTANGLE_POOL_SIZE    = 2;
   public static final int DEFAULT_STRINGBUFFER_POOL_SIZE = 2;
   public static final int DEFAULT_POLYGON2D_POOL_SIZE    = 2;
   public static final int DEFAULT_POINT2D_POOL_SIZE      = 2;

   //-----------------------------------------------------------------

   /**
    * Designed to overcome a limitation with hashing, namely objects that
    * return the same hashvalue can overwrite each other.
    * Not used anymore.
    */
   public static final class UniquePoint2D extends Point2D.Float {
   	static int counter = 0;
   	int val     = counter++;
   
   	public int hashCode() {
   		return (val);
   	} // of method
   } // of inner class


   /**
    * Object pool of Point2D objects.
    * This used to do something interesting, but I don't believe
    * ObjectPools really provide that much of a benefit anymore, so
    * I got rid of them (JIH).
    */
   public static final class ObjectPoolPoint2D extends ObjectPool {
   	public ObjectPoolPoint2D() {
   		super(DEFAULT_POINT2D_POOL_SIZE);
   	} // of constructor

   	public Object createObject() {
   		return (new Point2D.Float());
   	} // of method

   	public Object getObject() {
   		return (new Point2D.Float());
   	} // of method

   	public void releaseObject(Object obj) {}

   } // of inner class

   //-----------------------------------------------------------------

   /**
    * Designed to overcome a limitation with hashing, namely objects that
    * return the same hashvalue can overwrite each other.
    * Not used anymore.
    */
   public static final class UniqueRectangle2D extends Rectangle2D.Float {
   	static int counter = 0;
   	int val     = counter++;
   
   	public int hashCode() {
   		return (val);
   	} // of method
   } // of inner class
   
   /**
    * Object pool of Rectangle2D objects.
    */
   public static final class ObjectPoolRectangle2D extends ObjectPool {
   	public ObjectPoolRectangle2D() {
   		super(DEFAULT_RECTANGLE_POOL_SIZE);
   	} // of constructor
   
   	public Object createObject() {
   		return (new Rectangle2D.Float());
   	} // of method
   
   	public Object getObject() {
   		return (new Rectangle2D.Float());
   	} // of method
   
   	public void releaseObject(Object obj) {}
     
   } // of inner class
   
   //-----------------------------------------------------------------
   
   /**
    * Designed to overcome a limitation with hashing, namely objects that
    * return the same hashvalue can overwrite each other.
    * Not used anymore.
    */
   public static final class UniqueAffineTransform extends AffineTransform {
   	static int counter = 0;
     	int val     = counter++;
   
   	public int hashCode() {
   		return (val);
   	} // of method
   } // of inner class
   
   /**
    * Object pool of AffineTransform objects.
    */
   public static final class ObjectPoolAffineTransform extends ObjectPool {
     	public ObjectPoolAffineTransform() {
   		super(DEFAULT_TRANSFORM_POOL_SIZE);
   	} // of constructor
   
   	public Object createObject() {
   		return (new AffineTransform());
   	} // of method
   
   	public Object getObject() {
   		return (new AffineTransform());
   	} // of method
   
   	public void releaseObject(Object obj) {}
   
   } // of inner class
   
   //-----------------------------------------------------------------
     
   /**
    * Designed to overcome a limitation with hashing, namely objects that
    * return the same hashvalue can overwrite each other.
    * Not used anymore.
    */
   public static final class UniquePolygon2D extends Polygon2D {
   	static int counter = 0;
   	int val     = counter++;
   
   	public int hashCode() {
   		return (val);
     	} // of method
   } // of inner class
   
   /**
    * Object pool of Polygon2D objects.
    */
   public static final class ObjectPoolPolygon2D extends ObjectPool {
   	public ObjectPoolPolygon2D() {
   		super(DEFAULT_POLYGON2D_POOL_SIZE);
   	} // of constructor
   
     	public Object getObject() {
   		return (new Polygon2D());
   	} // of method
   
   	public void releaseObject(Object obj) {}
   
   	public Object createObject() {
   		return (new Polygon2D());
   	} // of method
   } // of inner class
   
     //-----------------------------------------------------------------
   
   /**
    * Object pool of StringBuffer objects. Fortunately, StringBuffers
    * return unique hashcodes, so we don't need to subclass it. Not that
    * we could if we wanted to, since StringBuffer is final.
    */
   public static final class ObjectPoolStringBuffer extends ObjectPool {
   	public ObjectPoolStringBuffer() {
   		super(DEFAULT_STRINGBUFFER_POOL_SIZE);
   	} // of constructor
     
   	/**
   	 * Clear out the object before using.
   	 */
   	public Object getObject() {
   		return (new StringBuffer());
   		/*
   		  StringBuffer strbuf = (StringBuffer) super.getObject();
   		  strbuf.setLength(0);
   		  return (strbuf);
   		*/
     	} // of getObject
   
   	public void releaseObject(Object obj) {}
   
   	public Object createObject() {
   		return (new StringBuffer(2048));
   	} // of method
   } // of inner class
   
   //===   OBJECT POOL INNER CLASSES   =========================================
   //===========================================================================
     
   
   
   //===========================================================================
   //===   SHARED GLOBAL VARIABLES   ===========================================
   
   /**
    * Random number generator.
    */
   public static Random rand = new Random();
   
     //-----------------------------------------------------------------
   
   /**
    * Object pool of Point2D.
    */
   public static ObjectPool poolPoints = new ObjectPoolPoint2D();
   
   /**
    * Object pool of Rectangle2D.
    */
   public static ObjectPool poolRects = new ObjectPoolRectangle2D();
     
   /**
    * Object pool of AffineTransforms.
    */
   public static ObjectPool poolTx = new ObjectPoolAffineTransform();
     
   /**
    * Object pool of Polygon2D.
    */
   public static ObjectPool poolPolys = new ObjectPoolPolygon2D();
   
     /**
    * Object pool of StringBuffers.
    */
   public static ObjectPool poolStrbuf = new ObjectPoolStringBuffer();
   
   //-----------------------------------------------------------------
   
   /**
    * Global system properties. 
    */
   public static FlexProperties glprops = new FlexProperties();
     
   /**
    * Class default properties for graphical objects and command objects.
    */
   public static ClassProperties clprops = new ClassProperties();
   
   /**
    * Globally shared command subsystem.
    */
   public static CommandSubsystem cmdsubsys = new CommandSubsystem();
   
     /**
    * Globally shared clipboard.
    */
   public static Clipboard clipboard = new Clipboard();
   
   /**
    * Global command queue.
    */
   public CommandQueueManager cmdqueue = new CommandQueueManager();
   
   //===   SHARED GLOBAL VARIABLES   ===========================================
     //===========================================================================
   
   
   
   //===========================================================================
   //===   INTERNAL SATIN CONSTANTS   ==========================================
   
   /** 
    * For separating text when printing. 
    */
   static final String BAR="################################################\n";
     
   //-----------------------------------------------------------------
   
   /**
    * <PRE>
    * o o o
    * o x o
    * o o o
    * </PRE>
    */
   public static final int DIR_CENTER = 99;
     
   /**
    * <PRE>
    * x o o
    * o o o
    * o o o
    * </PRE>
    */
   public static final int DIR_UP_LEFT = 100;
   
   /**
      * <PRE>
    * o x o
    * o o o
    * o o o
    * </PRE>
    */
   public static final int DIR_UP = 101;
   
   /**
    * <PRE>
    * o o x
      * o o o
    * o o o
    * </PRE>
    */
   public static final int DIR_UP_RIGHT = 102;
   
   /**
    * <PRE>
    * o o o
    * o o x
    * o o o
      * </PRE>
    */
   public static final int DIR_RIGHT = 103;
   
   /**
    * <PRE>
    * o o o
    * o o o
    * o o x
    * </PRE>
    */
     public static final int DIR_DOWN_RIGHT = 104;
   
   /**
    * <PRE>
    * o o o
    * o o o
    * o x o
    * </PRE>
    */
   public static final int DIR_DOWN = 105;
   
     /**
    * <PRE>
    * o o o
    * o o o
    * x o o
    * </PRE>
    */
   public static final int DIR_DOWN_LEFT = 106;
   
   /**
    * <PRE>
      * o o o
    * x o o
    * o o o
    * </PRE>
    */
   public static final int DIR_LEFT = 107;
   
   //-----------------------------------------------------------------
   
   /** Local (self) coordinate system constant. */
   public static final int COORD_LOCAL = 10;
     
   /** Relative (parent) coordinate system constant. */
   public static final int COORD_REL   = 11;
   
   /** Absolute (screen) coordinate system constant. */
   public static final int COORD_ABS   = 12;
   
   //-----------------------------------------------------------------
   
   /** 
    * Damage the region and repaint immediately 
      * @see GraphicalObject#damage(int)
    */
   public static final int DAMAGE_NOW   = 20;
   
   /** 
    * Damage the region and repaint lazily 
    * @see GraphicalObject#damage(int)
    */
   public static final int DAMAGE_LATER = 21;
   
   /**
    * Damage the region and repaint under schedule
    * @see GraphicalObject#damage(int)
    */
   public static final int DAMAGE_IDLE = 22;
   
   //-----------------------------------------------------------------
     
   /** 
    * Get all GraphicalObjects that fit the parameters. 
    * @see GraphicalObjectGroup#getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public static final int ALL      = 30;
   
   /** 
    * Get the first GraphicalObjects that fit the parameters. 
    * @see GraphicalObjectGroup#getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
     public static final int FIRST    = 31;
   
   //-----------------------------------------------------------------
   
   /** 
    * Get Graphical Objects shallowly 
    * @see GraphicalObjectGroup#getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public static final int SHALLOW  = 40;
   
   /** 
      * Get Graphical Objects deeply 
    * @see GraphicalObjectGroup#getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public static final int DEEP     = 41;
   
   //-----------------------------------------------------------------
   
   /** 
    * Get GraphicalObjects intersecting the Shape or Point. 
    * @see GraphicalObjectGroup#getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
     public static final int INTERSECTS  = 50;
   
   /** 
    * Get GraphicalObjects contained entirely by the Shape or Point. 
    * @see GraphicalObjectGroup#getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public static final int CONTAINEDBY = 51;
   
   /** 
    * Get GraphicalObjects containing the Shape or Point (within threshold 
    * halo). You can also think of this as a NEAR operation.
      * @see GraphicalObjectGroup#getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public static final int CONTAINS    = 52;
   
   /**
    * An alias for {@link #CONTAINS}.
    * @see GraphicalObjectGroup#getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public static final int NEAR        = CONTAINS;
   
   /** 
      * Get GraphicalObjects above the specified Point. 
    * @see GraphicalObjectGroup#getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public static final int ABOVE       = 54;
   
   /** 
    * Get GraphicalObjects below the specified Point. 
    * @see GraphicalObjectGroup#getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public static final int BELOW       = 55;
   
     //-----------------------------------------------------------------
   
   /**
    * Sometimes we want to know whether a stroke is really a "tap." Since it
    * is hard to hold a pen in only one position, we instead take the
    * bounding box of the stroke and check the width and height of the box.
    * MAX_TAP_WIDTH and MAX_TAP_HEIGHT are the largest width and height that
    * the bounding box of a stroke can be for the stroke to be considered a
    * tap.
    */
   public static final int MAX_TAP_WIDTH = 6;
       
   /**
    * @see MAX_TAP_WIDTH
    */
   public static final int MAX_TAP_HEIGHT = 6;
     
   //---------------------------------------------------------------------
   
     /**
      * The minimum length of a stroke to be added to scribbled text
      */
   public static final int MIN_SCRIBBLE_STK_LEN       = 4;
     
   //===========================================================================
   
   /**
    * Throw out pixels closer together than the square root of this distance
    * (in pixels). Used when creating TimedStroke objects.
    */
   public static final int FILTER_THRESHOLD = 2*2;
   
   /**
      * Default threshold for distances when selecting Graphical Objects
    * in terms of absolute coordinates (screen pixels). That is, you have to 
    * be within this distance in order to be selected.
    */
   public static final int DEFAULT_SELECT_THRESHOLD = 5;
   
   /**
    * Satin damages and repaints in rectangular regions. This value is the
    * amount to enlarge damaged rectangular regions, to make sure we get nearby
    * objects correctly.
    */
     public static final int DEFAULT_REPAINT_THRESHOLD = 6;
   
   //-----------------------------------------------------------------
   
   /**
    * Number of pixels used for spacing for drawing height and width bars.
    */
   public static final int DEBUG_GRAPHICS_OFFSET = 30;
   
   //-----------------------------------------------------------------
   
     /**
    * Tolerance range for floating point.
    */
   public static final double FLOATING_PT_TOLERANCE = 0.001;
   
   //-----------------------------------------------------------------
   
   /**
    * Stretch the object when resized.
    */
   public static final int RESIZE_STRETCH = 0;
       
   /**
    * Change the bounds of the object when resized.
    */
   public static final int RESIZE_CHANGE_BOUNDS = 1;
     
   //===   INTERNAL SATIN CONSTANTS   ==========================================
   //===========================================================================
   
   
   
     //===========================================================================
   //===   NOTIFICATIONS   =====================================================
   
   /**
    * Notification of move, rotate, scale, or translate.
    * The old value is a copy of the old transform (AffineTransform). 
    * The new value is a copy of the new transform (AffineTransform).
    */
   public static final String NOTIFY_TRANSFORM = "xform";
   
   /**
      * Notification of a change in the style.
    * The old value is a copy of the old style (Style). 
    * The new value is a copy of the new style (Style).
    */
   public static final String NOTIFY_STYLE     = "style";
   
   /**
    * Notification of a change in the layer.
    * The old value is a copy of the old layer (String). 
    * The new value is a copy of the new layer (String).
    */
     public static final String NOTIFY_LAYER     = "layer";
   
   /**
    * Notification of a change in the bounding points.
    * The old value is the old bounding box in absolute coordinates.
    * The new value is the new bounding box in absolute coordinates.
    */
   public static final String NOTIFY_BOUNDS    = "bounds";
   
   /**
    * Notification of a change in the location of the top-left corner.
      * The old value is the old location in absolute coordinates.
    * The new value is the new location in absolute coordinates.
    */
   public static final String NOTIFY_LOCATION  = "location";
   
   //===   NOTIFICATIONS   =====================================================
   //===========================================================================
   
   
   
   //===========================================================================
   //===   STYLE PROPERTIES   ==================================================
   
   //// If you add any new Style properties, be sure to update the
   //// Style.java file too.
   
   public static final String KEY_STYLE_LINEWIDTH        = "LineWidth";
   public static final String KEY_STYLE_DRAWFONT         = "DrawFont";
   public static final String KEY_STYLE_DRAWCOLOR        = "DrawColor";
   public static final String KEY_STYLE_DRAWTRANSPARENCY = "DrawTransparency";
   public static final String KEY_STYLE_FILLCOLOR        = "FillColor";
   public static final String KEY_STYLE_FILLTRANSPARENCY = "FillTransparency";
     
   public static final String KEY_STYLE_ENDCAP           = "EndCap";
   public static final String KEY_STYLE_LINEJOIN         = "LineJoin";
   public static final String KEY_STYLE_MITERLIMIT       = "MiterLimit";
   
   public static final String KEY_STYLE_DASHARRAY        = "DashArray";
   public static final String KEY_STYLE_DASHPHASE        = "DashPhase";
   
   //===   STYLE PROPERTIES   ==================================================
   //===========================================================================
   
} // of interface

//==============================================================================

/*
  Copyright (c) 2000 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
