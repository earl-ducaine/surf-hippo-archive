package edu.berkeley.guir.suede.help;

import java.io.File;

 class SelectableFile {
	private File file;
	private boolean selected = false;

	public SelectableFile(File file) {
		this.file = file;
	}
	public String toString() {
		return file.toString() + " selected: " + selected;
	}
	public void setSelected(boolean s) { selected = s; }
	public boolean isSelected()		   { return selected; }
	public File getFile() 			   { return file; }
}