//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import java.awt.geom.*;
import java.util.*;

/**
 * Delete a Graphical Object.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 15 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-2.0.0, Oct  2 2000, JL
 *               Rearranged class hierarchy so that CutCommand is now a
 *               descendant, not parent
 *             - SATIN-v2.1-2.0.1, Oct  7 2000, JH
 *               Damages graphical objects on delete, to ensure that repaint
 *               is done correctly.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-2.0.1, Oct 7 2000
 */
public class DeleteCommand
   extends CommandImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   private static final long serialVersionUID = -9014455929012559983L;
   public  static final String TAG_NAME = "DELETE";

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================


   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   // table of GOb -> Parent - because we delete the gob in execute
   protected Map       gobToParent   = new TreeMap
                                        (new InternalLayerReverseComparator());
   
   // table of relative layer -> list of GObs
   protected SortedMap layerToGob    = new TreeMap();
   
   // table of GOb -> absolutelayer
   protected Map       gobToAbsLayer = new HashMap();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   INNER CLASS   =======================================================

   public class InternalLayerReverseComparator
      implements Comparator {


      /**
       * Compares the absolute layers of two GraphicalObjects, where the layers
       * are stored in the parent class's gobToAbsLayer.
       *
       * @return -1 if obj1 is under obj2
       *          0 if obj1 has the same layer as obj2
       *          1 if obj1 is over obj2
       */
      public int compare(Object gob1, Object gob2) {
         //System.out.println("Is gob1 null?:"+(gob1==null)+"is gob2 null?"+(gob2==null));
         return -GraphicalObjectLib.compareLayers
                ((List)gobToAbsLayer.get(gob1), (List)gobToAbsLayer.get(gob2));
      } // of compare

      public boolean equals(Object obj) {
         return super.equals(obj);
      } // of equals
   }

   //===   INNER CLASS   =======================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public DeleteCommand() {
   } // of constructor

   //===========================================================================

   /**
    * Create the delete command object, deleting the specified
    * GraphicalObject.
    *
    * @param gob is the Graphical Object to delete.
    */
   public DeleteCommand(GraphicalObject gob) {
      addGraphicalObject(gob);
   } // of constructor

   //===========================================================================

   /**
    * Make the specified collection of GraphicalObjects the list of 
    * GraphicalObjects to delete.
    *
    * @param it is an Iterator of Graphical Objects.
    */
   public DeleteCommand(Iterator it) {
      Object      obj;
      while (it.hasNext()) {
         obj = it.next();
         if (obj instanceof GraphicalObject) {
            addGraphicalObject((GraphicalObject) obj);
         }
      } 
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Make the specified collection of Graphical Objects the list of Graphical
    * Objects to delete.
    *
    * @param gobs is a Vector of Graphical Objects.
    */
   public DeleteCommand(Vector gobs) {
      this(gobs.iterator());
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   DELETE METHODS   ====================================================

   /**
    * Add a Graphical Object to the list of Graphical Objects to be deleted.
    *
    * @param gob is the Graphical Object to cut.
    */
   public void addGraphicalObject(GraphicalObject gob) {
      // Save absolute layer. Must do this before saving parent, because the
      // map for object to parent depends on the absolute layer table.
      gobToAbsLayer.put(gob, gob.getAbsoluteLayer());
      
      // Save the parent.
      gobToParent.put(gob, gob.getParentGroup());

      // Save the relative layer.
      Integer relLayer = new Integer(gob.getRelativeLayer());
      if (!layerToGob.containsKey(relLayer)) {
         layerToGob.put(relLayer, new LinkedList());
      }
      ((List)layerToGob.get(relLayer)).add(gob);
   } // of addGraphicalObject

   //-----------------------------------------------------------------

   /**
    * Remove a Graphical Object from the list of Graphical Objects to be
    * deleted. Does nothing if the Graphical Object was not in the list.
    *
    * @param gob is the Graphical Object to remove from the delete command.
    */
   public void removeGraphicalObject(GraphicalObject gob) {
      gobToParent.remove(gob);
      Integer relLayer = new Integer(gob.getRelativeLayer());
      ((List)layerToGob.get(relLayer)).remove(gob);
   } // of removeGraphicalObject

   //-----------------------------------------------------------------

   /**
    * Clear the list of Graphical Objects to be deleted.
    */
   public void clearGraphicalObjects() {
      gobToParent.clear();
      layerToGob.clear();
   } // of clearGraphicalObjects

   //===   DELETE METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      return ("Delete Graphical Object");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   STATUS ACCESSOR METHODS   ===========================================

   public boolean canRedo() {
      return (false);
   } // of canRedo

   //===========================================================================

   public boolean canUndo() {
      return (true);
   } // of canUndo

   //===========================================================================

   public boolean isSignificant() {
      return (true);
   } // of isSignificant

   //===   STATUS ACCESSOR METHODS   ===========================================
   //===========================================================================



   //===========================================================================
   //===   ACTION METHODS   ====================================================

   public void run() {
      Set             keys       = gobToParent.keySet();
      Iterator        it         = keys.iterator();
      Rectangle2D     damageRect = null;
      Sheet           sheet      = null;
      GraphicalObject gob;

      //// 1. Delete the gobs and damage the areas.
      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();

         //// 1.1. Get a reference to the sheet.
         if (sheet == null) {
            sheet = gob.getSheet();
         }

         //// 1.2. Get the bounding box for damage purposes.
         if (damageRect == null) {
            damageRect = gob.getBounds2D(COORD_ABS);
         }
         else {
            damageRect = damageRect.createUnion(gob.getBounds2D(COORD_ABS));
         }

         //// 1.3. Delete the gob.
         gob.delete();
      }

      //// 2. Repaint the damaged areas.
      if (sheet != null) {
         sheet.damage(DAMAGE_LATER, damageRect);
      }

   } // of do

   //===========================================================================

   public void redo() {
      run();
   } // of redo

   //===========================================================================

   public void undo() {
      // The goal of this method is to preserve z-ordering after undo

//      System.out.println("starting undo in deleetcmd 1");
      //// 1. Get the list of Graphical Objects and reinsert.
      Iterator layerIt = layerToGob.keySet().iterator();
//      System.out.println("starting undo in deleetcmd 2");
      //// 2. Iterate over all possible relative layer values
      while (layerIt.hasNext()) {
         Integer layer = (Integer)layerIt.next();
         List gobs = (List)layerToGob.get(layer);
         Iterator gobIt = gobs.iterator();
//         System.out.println("starting undo in deleetcmd 3");
         //// 3. Iterator over all objects that have the current relative
         ////    layer value
         while (gobIt.hasNext()) {
            GraphicalObject gob = (GraphicalObject)gobIt.next();
             GraphicalObjectGroup parent = //a reference to the parent of the gob we deleted in execute
               (GraphicalObjectGroup) gobToParent.get(gob);

            //// 2.1. Add the GraphicalObject.
            parent.addToFront(gob);
            
            //// 2.2. Set the relative layer correctly.
            parent.setRelativeLayer(gob, layer.intValue());

            //// 2.3. Force a repaint.
            parent.damage(DAMAGE_LATER);
         }
      }
   } // of undo

   //===========================================================================

   public void die() {
   } // of die

   //===   ACTION METHODS   ====================================================
   //===========================================================================

   protected String getTagName() {
      return TAG_NAME;
   }
} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
