package edu.berkeley.guir.damask.view;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;
import java.util.List;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.event.ElementContainerEvent;
import edu.berkeley.guir.damask.event.ElementContainerListener;
import edu.berkeley.guir.damask.view.appevent.CanvasEvent;
import edu.berkeley.guir.damask.view.appevent.CanvasListener;
import edu.berkeley.guir.damask.view.nodes.DamaskWindowTitle;
import edu.berkeley.guir.damask.view.nodes.StickyTransformManager;
import edu.berkeley.guir.damask.view.visual.Arrow;
import edu.berkeley.guir.damask.view.visual.VisualLayer;
import edu.berkeley.guir.damask.view.visual.dialog.DialogView;
import edu.berkeley.guir.damask.view.visual.dialog.PageView;
import edu.berkeley.guir.damask.view.voice.dialog.Form;
import edu.berkeley.guir.lib.satin.command.Command;
import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.*;
import edu.umd.cs.piccolo.util.*;

/** 
 * The pane that shows the page templates available for the designer to use
 * and edit.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  02-24-2004 James Lin
 *                               Created TemplatePane.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 02-24-2004
 */
public class TemplatePane extends PPath {
   private static final int PADDING = 25;
   private static final int ANIMATION_LENGTH = 500;
   private boolean expanded = false;
   private PCamera visibleCamera = null;
   private int topDialogView = 0;
   private Page selectedPage = null;
   
   private static final int CHECK_BOX_SIDE_LENGTH = 15;
   private static final int REMOVE_BUTTON_SIDE_LENGTH = 20;
   private static final Color BUTTON_COLOR = new Color(233, 233, 233);
   private static final Color PRESSED_BUTTON_COLOR = Color.LIGHT_GRAY;
   
   private PPath addTemplateButton;
   private PPath upButton;
   private PPath downButton;
   private PNode focus = null;
   private final CanvasListener canvasListener = new CanvasHandler();
   private final TemplateWell templateWell = new TemplateWell();

   private final Map/*<CheckBox, TemplateDialog>*/ checkBoxToDialog =
      new HashMap();
   private final Map/*<InteractionElementView, CheckBox>*/
      dialogViewToCheckBox = new HashMap();
   private final Map/*<PPath, TemplateDialog>*/ removeButtonToDialog =
      new HashMap();
   private final Map/*<InteractionElementView, PPath>*/
      dialogViewToRemoveButton = new HashMap();


   /**
    * Constructs a template pane.
    */
   public TemplatePane() {
      // 1 is arbitrary -- the true value gets set in reposition()
      setPathToRectangle(0, 0, 1, 1);
      setPaint(Color.WHITE);
      
      final PBasicInputEventHandler contentsHandler =
         new ContentsEventHandler();
      //contentsHandler.getEventFilter().setMarksAcceptedEventsAsHandled(true);
      addInputEventListener(contentsHandler);

      addPropertyChangeListener(
         PNode.PROPERTY_PARENT,
         new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
               if (getParent() != null) {
                  initAfterAddToParent();
               }
               else {
                  removeAllChildren();
               }
            }
         }
      );

      templateWell.setStrokePaint(null);
      addChild(templateWell);
   }

   
   /**
    * Runs after the pane is added to a layer.
    */
   protected void initAfterAddToParent() {
      final DamaskLayer layer = (DamaskLayer)getParent();
      final InteractionGraph graph = layer.getDocument().getGraph();
      for (Iterator i = graph.getTemplates(layer.getDeviceType()).iterator();
         i.hasNext();
         ) {
         final TemplateDialog templateDialog = (TemplateDialog)i.next();
         addTemplateToWell(layer, templateDialog);
         // repositionHelper() will put the dialog views in the right locations
      }

      graph.addElementContainerListener(new GraphHandler());
      
      addTemplateButton =
         createButton(new PText("Add Template"), 0, 0, 110, 25, layer);
      addTemplateButton.addInputEventListener(
         new AddTemplateButtonEventHandler());
      addChild(addTemplateButton);

      {      
         final PPath upArrow = new PPath();
         upArrow.moveTo(5, 0);
         upArrow.lineTo(10, 5);
         upArrow.lineTo(0, 5);
         upArrow.closePath();
         upArrow.setPaint(Color.BLACK);
         upButton =
            createButton(upArrow, 0, 0, 20, 20, layer);
         upButton.addInputEventListener(new UpButtonEventHandler());
         addChild(upButton);
      }

      {          
         final PPath downArrow = new PPath();
         downArrow.moveTo(5, 5);
         downArrow.lineTo(10, 0);
         downArrow.lineTo(0, 0);
         downArrow.closePath();
         downArrow.setPaint(Color.BLACK);
         downButton =
            createButton(downArrow, 0, 0, 20, 20, layer);
         downButton.addInputEventListener(new DownButtonEventHandler());
         addChild(downButton);
      }
   }


   /**
    * Returns a button with the specified attributes, and is sticky-z relative
    * to the specified layer.
    */
   private PPath createButton(
      final PNode buttonLabel,
      final double x,
      final double y,
      final double width,
      final double height,
      final DamaskLayer layer) {

      final PPath newButton =
         new PPath(new Rectangle2D.Double(x, y, width, height));
      newButton.setPaint(new Color(233, 233, 233));
      buttonLabel.setOffset(
         (width - buttonLabel.getWidth()) / 2,
         (height - buttonLabel.getHeight()) / 2);
      newButton.addChild(buttonLabel);
      buttonLabel.setPickable(false);
      
      setupStickyZ(layer, newButton);
      newButton.addInputEventListener(new ButtonEventHandler());
      return newButton;
   }


   /**
    * Makes the specified node sticky-z, relative to the specified layer.
    */
   private void setupStickyZ(final DamaskLayer layer, final PNode node) {
      if (layer.getCameraCount() > 0) {
         StickyTransformManager.setupStickyZ(
            node,
            layer.getCamera(0),
            new Point(0, 0),
            1);
      }
      else {
         layer.addPropertyChangeListener(
            PLayer.PROPERTY_CAMERAS,
            new PropertyChangeListener() {
               public void propertyChange(PropertyChangeEvent evt) {
                  if (layer.getCameraCount() > 0) {
                     StickyTransformManager.setupStickyZ(
                        node,
                        layer.getCamera(0),
                        new Point(0, 0),
                        1);
                  }
               }
         });
      }
   }

   /**
    * Returns the image icon with the given file name.
    */
   protected Image getTemplateImage(final String fileName) {
      return Toolkit.getDefaultToolkit().createImage(DamaskApp.class
            .getResource("images/template/" + fileName));
   }

   /**
    * Adds a new template dialog to the template well.
    */
   private void addTemplateToWell(final DamaskLayer layer,
         final TemplateDialog dialog) {

      final InteractionElementView dialogView;
      if (layer instanceof VisualLayer) {
         dialogView = new DialogView(dialog);
      }
      else {
         dialogView = new Form(dialog);
      }

      final CheckBox checkBox = new CheckBox(new Rectangle2D.Double(0, 0,
            CHECK_BOX_SIDE_LENGTH, CHECK_BOX_SIDE_LENGTH));
      checkBox.setPaint(DamaskAppUtils.NO_COLOR);
      checkBox.addInputEventListener(new CheckBoxEventHandler());
      setupStickyZ(layer, checkBox);

      checkBoxToDialog.put(checkBox, dialog);
      dialogViewToCheckBox.put(dialogView, checkBox);
      templateWell.addChild(checkBox);
         
      final PPath removeButton =
         createButton(
            new PImage(getTemplateImage("delete.png"), false),
            0,
            0,
            REMOVE_BUTTON_SIDE_LENGTH,
            REMOVE_BUTTON_SIDE_LENGTH,
            layer);
      
      removeButton.addInputEventListener(
         new RemoveTemplateButtonEventHandler());
      removeButtonToDialog.put(removeButton, dialog);
      dialogViewToRemoveButton.put(dialogView, removeButton);
      
      if (layer.getDocument().getGraph().getDefaultTemplate() != dialog) {
         templateWell.addChild(removeButton);
      }

      templateWell.addChild(dialogView);
   }

   
   /**
    * Updates the states of the check boxes next to the templates and whether
    * they are enabled.
    */
   private void updateCheckBoxes() {
      if (selectedPage == null || selectedPage.isTemplate()) {
         for (Iterator i = checkBoxToDialog.keySet().iterator();
            i.hasNext();
            ) {
            final CheckBox checkBox = (CheckBox)i.next();
            checkBox.setState(false);
            checkBox.setEnabled(false);
         }
      }
      else {
         for (Iterator i = checkBoxToDialog.keySet().iterator();
            i.hasNext();
            ) {
            final CheckBox checkBox = (CheckBox)i.next();
            final Dialog dialog =
               (Dialog)checkBoxToDialog.get(checkBox);
            final Page pageTemplate =
               dialog.getFirstPage(((DamaskLayer)getParent()).getDeviceType());
            checkBox.setState(selectedPage.getTemplates().contains(pageTemplate));
            checkBox.setEnabled(true);
         }
      }
   }

   
   /**
    * Returns all dialog views within this template pane.
    */
   public List/*<InteractionElementView>*/ getViewsOfTemplateDialogs() {
      final List/*<InteractionElementView>*/ dialogViews = new ArrayList();
      for (Iterator i = templateWell.getChildrenIterator(); i.hasNext(); ) {
         final Object child = i.next();
         if ((child instanceof DialogView) || (child instanceof Form)) {
            dialogViews.add(child);
         }
      }
      return dialogViews;
   }
   
   
   /**
    * Returns whether this pane is expanded.
    */
   public boolean isExpanded() {
      return expanded;
   }
   
   /**
    * Sets whether this pane is expanded.
    */
   public void setExpanded(
      final PCamera camera,
      final boolean expanded,
      final boolean animate) {

      this.expanded = expanded;
      templateWell.paintClipped = !expanded;
      reposition(camera, animate);
   }


   /**
    * Returns the width of the pane when expanded. 
    */
   private double getWidthWhenExpanded() {
      final List/*<InteractionElementView>*/ templateViews =
         getViewsOfTemplateDialogs();

      final double templateViewWidth;
      final double removeButtonWidth;
      
      if (templateViews.isEmpty()) {
         templateViewWidth = 0;
         removeButtonWidth = 0;
      }
      else {
         final InteractionElementView firstDialogView =
            ((InteractionElementView)templateViews.get(0));
         
         final DeviceType canvasDeviceType;
         
         if (visibleCamera != null) {
            final DamaskCanvas canvas = (DamaskCanvas)visibleCamera.getComponent();
            canvasDeviceType = canvas.getDeviceType();
         }
         else {
            canvasDeviceType = null;
         }
            
         if (canvasDeviceType == DeviceType.VOICE) {
            templateViewWidth =
               firstDialogView.localToParent(
                  firstDialogView.getBounds()).getWidth();
         }
         else {
            templateViewWidth =
               firstDialogView.getFullBounds().getWidth();
         }
         
         removeButtonWidth =
            ((PPath)dialogViewToRemoveButton.get(firstDialogView))
               .getFullBounds()
               .getWidth();
      }
      return Math.max(
         Math.max(
            PADDING
               + removeButtonWidth
               + PADDING
               + templateViewWidth
               + PADDING
               + upButton.getFullBounds().getWidth()
               + PADDING,
            PADDING
               + removeButtonWidth
               + PADDING
               + templateViewWidth
               + PADDING
               + upButton.getFullBounds().getWidth()
               + PADDING),
         PADDING + addTemplateButton.getFullBounds().getWidth() + PADDING);
   }


   /**
    * Returns the width of the visible part of the pane. 
    */
   public double getVisibleWidth() {
      if (expanded) {
         return getWidthWhenExpanded();
      }
      else {
         return 0;
      }
   }


   /**
    * Returns whether this template pane is visible to the specified camera.
    */
   public boolean isVisibleToCamera(final PCamera camera) {
      return (camera == visibleCamera);
   }

   /**
    * Sets whether this template pane is visible to the specified camera.
    */
   public void setVisibleToCamera(final PCamera camera) {
      if (visibleCamera != null) {
         final DamaskCanvas oldCanvas = (DamaskCanvas)visibleCamera.getComponent();
         setArrowsVisibleToCamera(visibleCamera, false);
         oldCanvas.removeCanvasListener(canvasListener);
         oldCanvas.repaint();
      }
      
      visibleCamera = camera;
      
      if (visibleCamera != null) {
         final DamaskCanvas canvas = (DamaskCanvas)visibleCamera.getComponent();
         setArrowsVisibleToCamera(visibleCamera, true);
         canvas.addCanvasListener(canvasListener);
         canvas.repaint();
         
         // Enable or disable check boxes, depending on if there is a selected
         // page view in the canvas
         selectedPage = canvas.getSelectedPage();
         updateCheckBoxes();
      }
   }


   /**
    * Shows or hides arrows from this template pane for the specified camera.
    */
   private void setArrowsVisibleToCamera(
      final PCamera camera,
      final boolean flag) {

      final DamaskLayer layer = (DamaskLayer)getParent();
      final DeviceType deviceType = layer.getDeviceType();
      
      for (Iterator i = layer.getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof Arrow) {
            final Arrow arrow = (Arrow)child;
            final Page sourcePage =
               ((Connection) arrow.getModel())
                  .getConnectionSource(deviceType)
                  .getPage(deviceType);
            if (sourcePage.isTemplate()) {
               arrow.setVisibleToCamera(camera, flag);
            }
         }
      }
   }


   // Overrides method in parent class.   
   public void fullPaint(PPaintContext paintContext) {
      if (isVisibleToCamera(paintContext.getCamera())) {
         super.fullPaint(paintContext);
      }
   }


   /**
    * Repositions the template pane and the arrows from it.
    * 
    * @param animate true if the repositioning should be animated
    */
   public void reposition(final PCamera camera, final boolean animate) {
      final DamaskLayer layer = (DamaskLayer)getParent();
      final DeviceType deviceType = layer.getDeviceType();

      if (expanded) {
         // "Expand" the pane invisibly, so that we can reanchor the arrows
         setVisible(false);
         repositionHelper(camera, false);

         for (Iterator i = layer.getChildrenIterator(); i.hasNext(); ) {
            final PNode child = (PNode)i.next();
            if (child instanceof Arrow) {
               final Page sourcePage =
                  ((Connection) ((Arrow)child).getModel())
                     .getConnectionSource(deviceType)
                     .getPage(deviceType);
               if (sourcePage.isTemplate()) {
                  ((Arrow)child).reanchor();
               }
            }
         }
         
         // Hide the pane again
         expanded = false;
         repositionHelper(camera, false);
         expanded = true;
         setVisible(true);
      }

      // Show or hide arrows from this template pane
      setArrowsVisibleToCamera(camera, expanded);
      
      // Reposition this pane
      repositionHelper(camera, animate);
   }


   /**
    * Repositions the template pane.
    * 
    * @param animate true if the repositioning should be animated
    */
   private void repositionHelper(final PCamera camera, final boolean animate) {
      final Rectangle2D cameraBounds = camera.getBounds();
      camera.localToView(cameraBounds);
      
      final PAffineTransform transform = getTransform();
      transform.setOffset(
         cameraBounds.getMaxX() - getVisibleWidth(),
         cameraBounds.getMinY());
      if (animate) {
         animateToTransform(transform, ANIMATION_LENGTH);
      }
      else {
         setTransform(transform);
      }

      globalToLocal(cameraBounds);

      setPathTo(
         new Rectangle2D.Double(
            0,
            0,
            getWidthWhenExpanded(),
            cameraBounds.getHeight()));

      repositionDialogViews();
   }


   /**
    * Repositions the dialog views within the template pane.
    */
   private void repositionDialogViews() {
      final List/*<InteractionElementView>*/ dialogViews = getViewsOfTemplateDialogs();
      
      // Reposition the dialog views within the template pane
      int y = 0;
      for (ListIterator i = dialogViews.listIterator(topDialogView);
         i.hasNext();
         ) {
         final InteractionElementView dialogView =
            (InteractionElementView)i.next();

         final double yOffset;
         {
            final DamaskWindowTitle titleBar;
            if (dialogView instanceof DialogView) {
               titleBar =
                  ((PageView)((DialogView)dialogView).getChild(0)).getTitleBar();
               ((DialogView)dialogView).setContentsSelectable(true);
            }
            else {
               titleBar = ((Form)dialogView).getTitleBar();
               ((Form)dialogView).setContentsSelectable(true);
            }
            yOffset = titleBar.getPixelHeight()
               * titleBar.getTransform().getScaleY();
         }

         if (y == 0) {
            y += yOffset;
         }
         
         final PPath checkBox = (PPath)dialogViewToCheckBox.get(dialogView);
         checkBox.setOffset(0, y - yOffset);

         final PPath removeButton =
            (PPath)dialogViewToRemoveButton.get(dialogView);
         removeButton.setOffset(
            0,
            checkBox.getFullBounds().getY()
               + checkBox.getFullBounds().getHeight()
               + 2 * PADDING);
         
         dialogView.setOffset(
            removeButton.getFullBounds().getWidth() + PADDING,
            y);
         
         y += dialogView.getFullBounds().getHeight() + PADDING;
      }
      
      // Reposition the dialog views above the top of the template pane
      if (topDialogView > 0) {
         y = 0;
         for (ListIterator i = dialogViews.listIterator(topDialogView);
            i.hasPrevious();
            ) {
            final InteractionElementView dialogView =
               (InteractionElementView)i.previous();

            final double yOffset;
            {
               final DamaskWindowTitle titleBar;

               if (dialogView instanceof DialogView) {
                  titleBar =
                     ((PageView)((DialogView)dialogView).getChild(0)).getTitleBar();
                  ((DialogView)dialogView).setContentsSelectable(true);
               }
               else {
                  titleBar = ((Form)dialogView).getTitleBar();
                  ((Form)dialogView).setContentsSelectable(true);
               }
               yOffset = titleBar.getPixelHeight()
                         * titleBar.getTransform().getScaleY();
            }
            
            y -= PADDING
               + dialogView.getFullBounds().getHeight()
               + yOffset;

            final PPath checkBox = (PPath)dialogViewToCheckBox.get(dialogView);
            checkBox.setOffset(0, y - yOffset);

            final PPath removeButton = (PPath)dialogViewToRemoveButton.get(dialogView);
            removeButton.setOffset(
               0,
               checkBox.getFullBounds().getHeight() + 2 * PADDING);
      
            dialogView.setOffset(
               removeButton.getFullBounds().getWidth() + PADDING, y);
         }
      }
   }

   // Overrides method in superclass.
   protected void layoutChildren() {
      addTemplateButton.setOffset(PADDING, PADDING);

      final PBounds addTemplateButtonFullBounds =
         addTemplateButton.getFullBounds();

      final Rectangle2D templatePaneBounds = getPathReference().getBounds2D();

      upButton.setOffset(
         templatePaneBounds.getWidth()
            - PADDING
            - upButton.getFullBounds().getWidth(),
         addTemplateButtonFullBounds.getY()
            + addTemplateButtonFullBounds.getHeight()
            + PADDING);

      downButton.setOffset(
         templatePaneBounds.getWidth()
            - PADDING
            - upButton.getFullBounds().getWidth(),
         templatePaneBounds.getHeight()
            - downButton.getFullBounds().getHeight()
            - PADDING);

      templateWell.setPathTo(
         new Rectangle2D.Double(
            0,
            0,
            templatePaneBounds.getWidth()
               - 3 * PADDING
               - upButton.getFullBounds().getWidth(),
            templatePaneBounds.getHeight() - addTemplateButtonFullBounds.getY()
               - addTemplateButtonFullBounds.getHeight()
               - 2 * PADDING));
      templateWell.setOffset(
         PADDING,
         addTemplateButtonFullBounds.getY()
            + addTemplateButtonFullBounds.getHeight()
            + PADDING);

      repositionDialogViews();
   }
   
   //------------------------------------------------------------------------
   
   private static class TemplateWell extends PPath {
      public boolean paintClipped = true;

      //=========================================================================
      // The code below was copied from edu.umd.cs.piccolox.nodes.PClip.

      protected void clipPaint(PPaintContext paintContext) {
         Paint p = getPaint();
         if (p != null) {
            Graphics2D g2 = paintContext.getGraphics();
            g2.setPaint(p);
            g2.fill(getPathReference());
         }
         paintContext.pushClip(getPathReference());
      }

      protected void clipPaintAfterChildren(PPaintContext paintContext) {
         paintContext.popClip(getPathReference());
         if (getStroke() != null && getStrokePaint() != null) {
            Graphics2D g2 = paintContext.getGraphics();
            g2.setPaint(getStrokePaint());
            g2.setStroke(getStroke());
            g2.draw(getPathReference());
         }
      }

      public boolean clipFullPick(PPickPath pickPath) {
         if (getPickable() && fullIntersects(pickPath.getPickBounds())) {
            pickPath.pushNode(this);
            pickPath.pushTransform(getTransformReference(false));

            if (pick(pickPath)) {
               return true;
            }

            if (getChildrenPickable()
               && getPathReference().intersects(pickPath.getPickBounds())) {
               int count = getChildrenCount();
               for (int i = count - 1; i >= 0; i--) {
                  PNode each = getChild(i);
                  if (each.fullPick(pickPath))
                     return true;
               }
            }

            if (pickAfterChildren(pickPath)) {
               return true;
            }

            pickPath.popTransform(getTransformReference(false));
            pickPath.popNode(this);
         }

         return false;
      }

      // The code above was copied from edu.umd.cs.piccolox.nodes.PClip.
      //=========================================================================

      protected void paint(PPaintContext paintContext) {
         if (paintClipped) {
            clipPaint(paintContext);
         }
         else {
            super.paint(paintContext);
         }
      }

      protected void paintAfterChildren(PPaintContext paintContext) {
         if (paintClipped) {
            clipPaintAfterChildren(paintContext);
         }
         else {
            super.paintAfterChildren(paintContext);
         }
      }

      public boolean fullPick(PPickPath pickPath) {
         if (paintClipped) {
            return clipFullPick(pickPath);
         }
         else {
            return super.fullPick(pickPath);
         }
      }
   }
   

   /**
    * Listens to events from an interaction graph. 
    */
   private class GraphHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         final DamaskLayer layer = (DamaskLayer)getParent();
         final InteractionGraph graph = layer.getDocument().getGraph();

         final Object container = e.getSource();
         final InteractionElement element = e.getElement();

         assert graph.equals(container) :
            "ERROR: event source " + container + " is not " + graph;

         if (element instanceof TemplateDialog) {
            final TemplateDialog dialog = (TemplateDialog)element;
            addTemplateToWell(layer, dialog);

            repositionDialogViews();
         }
      }

      public void elementRemoved(ElementContainerEvent e) {
         final DamaskLayer layer = (DamaskLayer)getParent();
         final InteractionGraph graph = layer.getDocument().getGraph();

         final Object container = e.getSource();
         final InteractionElement element = e.getElement();

         assert graph.equals(container) :
            "ERROR: event source " + container + " is not " + graph;

         if (element instanceof TemplateDialog) {
            final TemplateDialog dialog = (TemplateDialog)element;
            final List/*<DialogView>*/ templateDialogsToRemove =
               new ArrayList();
            for (Iterator i = templateWell.getChildrenIterator();
               i.hasNext();
               ) {

               final PNode child = (PNode)i.next();
               if (child instanceof InteractionElementView) {
                  final InteractionElementView dialogView =
                     (InteractionElementView)child;
                  if (dialogView.getModel() == dialog) {
                     templateDialogsToRemove.add(dialogView);
                  }
               }
            }

            for (Iterator i = templateDialogsToRemove.iterator();
               i.hasNext();
               ) {

               final InteractionElementView dialogView =
                  (InteractionElementView)i.next();
               templateWell.removeChild(dialogView);
               
               final CheckBox checkBox =
                  (CheckBox)dialogViewToCheckBox.get(dialogView);
               final PPath removeButton =
                  (PPath)dialogViewToRemoveButton.get(dialogView);

               final int removeButtonIndex =
                  templateWell.indexOfChild(removeButton);
               if (removeButtonIndex != -1) {
                  templateWell.removeChild(removeButtonIndex);
               }
               templateWell.removeChild(checkBox);

               dialogViewToCheckBox.remove(dialogView);
               checkBoxToDialog.remove(checkBox);

               dialogViewToRemoveButton.remove(dialogView);
               removeButtonToDialog.remove(removeButton);
            }
            repositionDialogViews();
         }
      }
   }


   /**
    * Listens to mouse and key events in the template pane tab.
    */
   private class ContentsEventHandler extends PBasicInputEventHandler {
      private DamaskCanvas getCanvas(final PInputEvent event) {
         final PComponent component = event.getComponent();
         if (component instanceof DamaskCanvas) {
            return (DamaskCanvas)component;
         }
         else {
            return null;
         }
      }

      public void mouseEntered(final PInputEvent event) {
         final DamaskCanvas canvas = getCanvas(event);
         if ((canvas != null) && (canvas.getInsideNode() == null)) {
            canvas.setCursor(null);
         }
      }
      
      public void mousePressed(final PInputEvent event) {
      }
      
      public void mouseReleased(final PInputEvent event) {
      }

      public void mouseExited(final PInputEvent event) {
         final DamaskCanvas canvas = getCanvas(event);
         if (canvas != null) {
            canvas.setProperCursor();
         }
      }
   }


   /**
    * Handles mouse events within a button.
    */
   private class ButtonEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         final PNode button = event.getPickedNode();
         button.setPaint(PRESSED_BUTTON_COLOR);
         focus = button;
      }
      
      public void mouseReleased(PInputEvent event) {
         final PNode button = event.getPickedNode();
         
         if (focus == button) {
            button.setPaint(BUTTON_COLOR);
            focus = null;
         }
      }
      
      public void mouseEntered(PInputEvent event) {
         final PNode button = event.getPickedNode();
         if (focus == button) {
            button.setPaint(PRESSED_BUTTON_COLOR);
         }
      }
      
      public void mouseExited(PInputEvent event) {
         final PNode button = event.getPickedNode();
         if (focus == button) {
            button.setPaint(BUTTON_COLOR);
         }
      }
   }


   /**
    * Scrolls the page views within the template well up when the up button
    * is pressed. 
    */   
   private class UpButtonEventHandler extends PBasicInputEventHandler {
      public void mouseReleased(PInputEvent event) {
         if (topDialogView > 0) { 
            topDialogView--;
            repositionDialogViews();
         }
      }
   }

   
   /**
    * Scrolls the page views within the template well down when the down button
    * is pressed. 
    */   
   private class DownButtonEventHandler extends PBasicInputEventHandler {
      public void mouseReleased(PInputEvent event) {
         if (topDialogView < getViewsOfTemplateDialogs().size() - 1) { 
            topDialogView++;
            repositionDialogViews();
         }
      }
   }

   
   /**
    * Adds a new template when the Add Template button is pressed. 
    */   
   private class AddTemplateButtonEventHandler
      extends PBasicInputEventHandler {

      public void mouseReleased(PInputEvent event) {
         final DamaskCanvas canvas = ((DamaskCanvas)event.getComponent());
         final InteractionGraph graph = canvas.getDocument().getGraph();

         final TemplateDialog newTemplate =
            new TemplateDialog(
               DeviceType.ALL,
               new Content(
                  DeviceType.ALL,
                  "Template " + (graph.getTemplates().size() + 1)));
         canvas.getDocument().getCommandQueue().doCommand(canvas,
            new AddTemplateCommand(graph, newTemplate));
      }
   }

   
   /**
    * Removes the selected template when the Remove Template button is pressed. 
    */   
   private class RemoveTemplateButtonEventHandler
      extends PBasicInputEventHandler {

      public void mouseReleased(PInputEvent event) {
         final PPath removeButton = (PPath)event.getPickedNode();
         final DamaskCanvas canvas = ((DamaskCanvas)event.getComponent());

         canvas.getDocument().getCommandQueue().doCommand(
            canvas,
            new RemoveTemplateCommand(
               (TemplateDialog)removeButtonToDialog.get(removeButton)));
      }
   }
   
   
   private static class CheckBox extends PPath {
      private boolean state = false;
      private boolean enabled = true;
      private final PPath checkMark = new PPath();
      
      public CheckBox() {
         super();
         init();
      }

      public CheckBox(Shape aShape) {
         super(aShape);
         init();
      }

      public CheckBox(Shape aShape, Stroke aStroke) {
         super(aShape, aStroke);
         init();
      }

      private void init() {
         setStrokePaint(Color.BLACK);
         checkMark.moveTo(
            CHECK_BOX_SIDE_LENGTH * 0.2f,
            CHECK_BOX_SIDE_LENGTH * 0.5f);
         checkMark.lineTo(
            CHECK_BOX_SIDE_LENGTH * 0.4f,
            CHECK_BOX_SIDE_LENGTH * 0.8f);
         checkMark.lineTo(
            CHECK_BOX_SIDE_LENGTH * 0.8f,
            CHECK_BOX_SIDE_LENGTH * 0.2f);
         checkMark.setStrokePaint(Color.BLACK);
         checkMark.setPickable(false);
      }
      
      public void setState(final boolean state) {
         this.state = state;
         if (state) {
            addChild(checkMark);
         }
         else {
            removeAllChildren();
         }
      }
      
      public boolean getState() {
         return state;
      }
      
      public void setEnabled(final boolean flag) {
         enabled = flag;
         if (enabled) {
            setStrokePaint(Color.BLACK);
            checkMark.setStrokePaint(Color.BLACK);
         }
         else {
            setStrokePaint(Color.LIGHT_GRAY);
            checkMark.setStrokePaint(Color.LIGHT_GRAY);
         }
      }
      
      public boolean isEnabled() {
         return enabled;
      }
   }
   
   /**
    * The event handler for a check box.
    */
   private class CheckBoxEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         final CheckBox checkBox = (CheckBox)event.getPickedNode();
         if (checkBox.isEnabled()) {
            checkBox.setPaint(Color.LIGHT_GRAY);
            focus = checkBox;
         }
      }
      
      public void mouseReleased(PInputEvent event) {
         final CheckBox checkBox = (CheckBox)event.getPickedNode();
         
         if (focus == checkBox) {
            checkBox.setPaint(DamaskAppUtils.NO_COLOR);
            final boolean newState = !checkBox.getState(); 
            checkBox.setState(newState);
            if (selectedPage != null) {
               
               final DamaskCanvas canvas = ((DamaskCanvas)event.getComponent());
               final Page pageTemplate =
                  ((Dialog)checkBoxToDialog
                     .get(checkBox))
                     .getFirstPage(((DamaskLayer)getParent()).getDeviceType());
               final Command command;
               if (newState) {
                  command =
                     new ApplyTemplateToPageCommand(selectedPage, pageTemplate);
               }
               else {
                  command =
                     new UnapplyTemplateToPageCommand(
                        selectedPage, pageTemplate);
               }
               canvas.getDocument().getCommandQueue().doCommand(
                  canvas, command);
            }
         }
         focus = null;
      }
      
      public void mouseEntered(PInputEvent event) {
         final PNode checkBox = event.getPickedNode();
         if (focus == checkBox) {
            checkBox.setPaint(Color.LIGHT_GRAY);
         }
      }
      
      public void mouseExited(PInputEvent event) {
         final PNode checkBox = event.getPickedNode();
         if (focus == checkBox) {
            checkBox.setPaint(DamaskAppUtils.NO_COLOR);
         }
      }
   }

   
   
   /**
    * The event handler for a canvas.
    */
   private class CanvasHandler implements CanvasListener {
      public void selectionChanged(CanvasEvent e) {
      }

      public void selectedPageChanged(CanvasEvent e) {
         assert e.getCanvas() == visibleCamera.getComponent() :
            "Not listening to the correct canvas";

         selectedPage = e.getCanvas().getSelectedPage();       
         updateCheckBoxes();
      }
   }
}
