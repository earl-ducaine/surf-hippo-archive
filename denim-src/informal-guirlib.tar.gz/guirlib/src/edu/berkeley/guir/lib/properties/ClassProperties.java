//// See bottom of source code for software license.

package edu.berkeley.guir.lib.properties;

/**
 * Inheritable properties for a class.
 * <P>
 * You can put in properties for a class of objects in here, and then
 * retrieve them by specifying a class or by passing in an object. There
 * are two advantages to putting key-values in here over putting them as
 * static values in the class:
 * <OL>
 *    <LI> key-values in here are inherited by subclasses, and 
 *    <LI> default values can be assigned for keys
 * </OL>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0-1.0.0, Jun 02 2000, JH
 *               Created class
 *             - GUIRLib-v1.5/1.0.0, Apr 09 2002, JIH
 *               Updated for JDK1.4 with assertions, general cleanup
 *               and removal of cruftiness.
 * </PRE>
 *
 * @author  (<A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   JDK 1.3
 * @version GUIRLib-v1.5/1.0.0, Apr 09 2002 JIH
 */
public class ClassProperties 
   extends FlexProperties {

   //===========================================================================
   //===   KEY GENERATION METHODS   ============================================

   /**
    * Given a class and a property name, generate a key.
    * For example, java.lang.Object and "Name" becomes "java.lang.Object-Name".
    */
   public String generateClassKey(Class cl, String key) {
      return (cl.getName() + "-" + key);
   } // of method


   /**
    * Generate the default value for a key.
    * For example, property "Name" becomes "DEFAULT-Name".
    */
   public String generateDefaultKey(String key) {
      return ("DEFAULT-" + key);
   } // of method

   //===   KEY GENERATION METHODS   ============================================
   //===========================================================================




   //===========================================================================
   //===   PROPERTY METHODS   ==================================================

   /**
    * Recursively go up the inheritance chain, finding the first class that 
    * has a value for this key.
    * <P>
    * Keep in mind that this gets a <B>reference</B> to the specified key.
    * Thus, if you modify the retrieved value, you modify it for everyone. You
    * may want to make a clone of it first.
    */
   public Object getClassProperty(Class cl, String key) {
      //// 1. See if we have the property.
      String strClassKey = generateClassKey(cl, key);
      if (mapProperties.containsKey(strClassKey)) {
         return (mapProperties.get(strClassKey));
      }

      //// 2.1. Recurse up the inheritance chain and try to find the property.
      Class parent = cl.getSuperclass();
      if (parent != null) {
         return (getClassProperty(parent, key));
      }
      //// 2.2. Otherwise use the default property.
      ////      This works out to be null if there is no default.
      else {
         return (mapProperties.get(generateDefaultKey(key)));
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Put a default value in for this key. The default is the value that
    * will be used if the class or any of its superclasses does not have 
    * a value for the specified property.
    */
   public void setDefaultProperty(String key, Object newVal) {
      setProperty(generateDefaultKey(key), newVal);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Put a property in for this class, overriding an old value if there is one.
    */
   public void setClassProperty(Class cl, String key, Object newVal) {
      setProperty(generateClassKey(cl, key), newVal);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Remove the property for this class and key.
    */
   public Object removeClassProperty(Class cl, String key) {
      return (removeProperty(generateClassKey(cl, key)));
   } // of method

   //===   PROPERTY METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) throws Exception {
      ClassProperties props = new ClassProperties();

      props.setClassProperty(Boolean.class, "x", "1");
      props.setClassProperty(String.class,  "x", "2");
      props.setClassProperty(Integer.class, "x", "3");
      props.setClassProperty(Float.class,   "x", "4");

      System.out.println(props);

      System.out.println(props.getClassProperty(String.class, "x"));
      System.out.println(props.getClassProperty(String.class, "y"));

      props.setDefaultProperty("y", "99");
      System.out.println(props.getClassProperty(String.class, "y"));
   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/


