//// See bottom of source code for software license.
package edu.berkeley.guir.lib.debugging;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.DateFormat;

/**
 * A file for logging messages.
 *
 * <P>
 * Error messages should contain:
 * <UL>
 *    <LI>what the error is
 *    <LI>transaction and field in error
 *    <LI>priority of error
 *    <LI>what the program will do (ie assume a value, reject, terminate, etc.)
 * </UL>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~danyelf/">Danyel Fisher</A>
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version May 13 2002 JH
 */
public class LogFile {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   /**
    * Name of the logfile if no logfile name is specified
    */
   public final static String DEFAULT_LOGFILE = "logfile.txt";

   //// Miscellaneous useful constants
   //   Technically should be System.getProperty("line.separator");
   private final static String EOLN   = "\n";

   //===   CONSTANTS   =========================================================
   //===========================================================================




   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   private PrintWriter fWrite;

   private boolean flagPrintTime = true;

   DateFormat dFormatDate;
   DateFormat dFormatTime;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Default constructor: picks default date.
    * Sets the name of the logfile to the default log filename.
    *
    * @exception IOException if there is a problem writing to the file.
    */
    public LogFile() throws IOException {
        this(DEFAULT_LOGFILE);
    } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Convenience constructor: picks a default date format.
    *
    * @param strLogFileName is the filename of the log file.
    * @exception IOException if there is a problem writing to the file.
    */
    public LogFile(String strLogFileName) throws IOException {
        this(new PrintWriter(new FileWriter(strLogFileName, true)));
    } // of constructor

   //-----------------------------------------------------------------

   /**
    * Convenience constructor knows about dates.
    *
    * @param  printWriter is the output stream: perhaps 
    *                     new PrintWriter( System.out );
    * @throws IOException if there is a problem writing to the file.
    */
   public LogFile(PrintWriter printWriter) throws IOException {
       this( printWriter, 
             DateFormat.getDateInstance(DateFormat.MEDIUM),
             DateFormat.getTimeInstance(DateFormat.SHORT));
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Constructor.
    *
    * @param  printWriter is the PrintWriter that points to the log file.
    * @param  dFormatDate is the date format to be used 
    * @throws IOException if there is a problem writing to the file.
    */
   public LogFile(PrintWriter printWriter, DateFormat dFormatDate, 
                  DateFormat dFormatTime)
      throws IOException {

      this.fWrite      = printWriter;
      this.dFormatDate = dFormatDate;
      this.dFormatTime = dFormatTime;
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   FINALIZER   =========================================================

   public void finalize() {
      try {
         fWrite.close();
      }
      catch (Throwable e) {
         //// ignore it
      }
   } // of finalize

   //===   FINALIZER   =========================================================
   //===========================================================================




   //===========================================================================
   //===   UTILITY METHODS   ===================================================

   /**
    * Set whether the time is printed or not.
    */
   public void setPrintTime(boolean flag) {
       flagPrintTime = flag;
   } // of method


   public boolean shouldPrintTime() {
       return (flagPrintTime);
   } // of method

   //-----------------------------------------------------------------

   private String getCurrentDateAndTime() {
       if (shouldPrintTime() == true) {
           Date date = new Date();
           return (dFormatDate.format(date) + " " + dFormatTime.format(date));
       }
       return ("");
   } // of method

   //-----------------------------------------------------------------

   /**
    * Given a severity level, translate it into a String.
    *
    * @param  iSeverity is the severity level.
    * @return A String containing the severity level in words.
    */
   public String getSeverityLevel(int iSeverity) {
      return("" + iSeverity);
   } // of method

   //===   UTILITY METHODS   ===================================================
   //===========================================================================




   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Close the log file.
    */
   public void close() {

      try {
         fWrite.close();
      }
      catch (Throwable e) {
         //// ignore it
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Record the specified message to the log.
    *
    * @param strMessage is the message to log.
    */
   public void logMessage(int iSeverity, String strMessage) {
       //// 1. Set up the header. Print out times only if the flag is set.
       String strHeader = "";
       if (shouldPrintTime() == true) {
           strHeader = getCurrentDateAndTime()     + " "   + 
                       getSeverityLevel(iSeverity) + " - ";
       }

       //// 2. Write out the message to the logfile.
       String strOut = strHeader + strMessage + EOLN;
       fWrite.write(strOut);

       if (fWrite.checkError()) {
          System.err.println("Error in writing to logfile");
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Record the specified message with the specified severity level to 
    * the log.
    *
    * @param strMessage is the message to log.
    */
   public void logMessage(String strMessage) {
       //// 1. Set up the header. Print out times only if the flag is set.
       String strHeader = "";
       if (shouldPrintTime() == true) {
           strHeader = getCurrentDateAndTime() + "   - ";
       }
  
       //// 2. Write out the message to the logfile.
       String strOut = strHeader + strMessage + EOLN;
       fWrite.write(strOut);

       if (fWrite.checkError()) {
          System.err.println("Error in writing to logfile");
       }
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   MAIN    =============================================================

   /**
    * Used for self-testing purposes.
    */
/*
   public static void main(String[] argv) {
      System.out.println("Running self-test...");
      System.out.println("Creating sample logfile 'out.log'...");

      try {
         LogFile log2 = new LogFile();
         LogFile log1 = new LogFile("out.log");
         LogFile log3 = new LogFile(new PrintWriter( System.out ), 
                              DateFormat.getDateInstance(DateFormat.SHORT),
                              DateFormat.getTimeInstance(DateFormat.DEFAULT));

         log1.logMessage(1, "sample error log message");
         Thread.sleep(550);
         log1.logMessage(2, "sample error log message");
         Thread.sleep(550);
         log1.logMessage(3, "sample error log message");
         Thread.sleep(550);
         log1.logMessage(4, "sample error log message");
         Thread.sleep(550);
         log1.logMessage(5, "sample error log message");
         Thread.sleep(550);
         log1.logMessage(6, "sample error log message");
         Thread.sleep(550);
         log1.logMessage(7, "sample error log message");
         Thread.sleep(550);
         log1.logMessage(8, "sample error log message");
         Thread.sleep(550);
         log1.logMessage(9, "sample error log message");
         Thread.sleep(550);
         log1.logMessage(0, "sample error log message");
         Thread.sleep(550);
         log1.logMessage("sample error log message");
         log3.logMessage("Just about done");
         log3.logMessage(2, "Are you blissful?");
         

      }
      catch (Exception e) {
         System.out.println(e);
      }

   } // of main
*/
   //===   MAIN    =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
