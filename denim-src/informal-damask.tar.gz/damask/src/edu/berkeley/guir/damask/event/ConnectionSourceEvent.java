package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.connection.ConnectionSource;

/** 
 * An event that indicates a change to a control.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-19-2004 James Lin
 *                               Created ControlEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-19-2004
 */
public class ConnectionSourceEvent extends EventObject {
   
   private Type eventType;
   private Connection connection;
   
   //===========================================================================

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type OUT_CONNECTION_ADDED =
      new Type("outgoing connection added");
   public static final Type OUT_CONNECTION_REMOVED =
      new Type("outgoing connection removed");

   //===========================================================================

   /**
    * Constructs a ConnectionSourceEvent.
    * 
    * @param source the connection source that is affected
    */
   public ConnectionSourceEvent(
      final ConnectionSource source,
      final Type eventType,
      final Connection connection) {

      super(source);
      this.eventType = eventType;
      this.connection = connection;
   }
   
   //===========================================================================

   /**
    * Returns the originator of the event.
    * 
    * @return the ConnectionSource object that originated the event, or
    * null if the object is not a ConnectionSource.
    */
   public ConnectionSource getConnectionSource() {
      if (source instanceof ConnectionSource) {
         return (ConnectionSource)source;
      }
      else {
         return null;
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the connection associated with this event.
    */
   public Connection getConnection() {
      return connection;
   }
}
