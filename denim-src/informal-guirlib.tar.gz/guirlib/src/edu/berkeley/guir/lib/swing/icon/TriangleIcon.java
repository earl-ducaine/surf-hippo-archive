//// See bottom of file for software license
package edu.berkeley.guir.lib.swing.icon;

import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Shape;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class TriangleIcon 
    extends ImageIcon {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    private static final int   WIDTH  = 8;
    private static final int   HEIGHT = 8;
    private static final Color COLOR  = Color.DARK_GRAY;

    //----------------------------------------------------------------

    /**
     * Dark gray triangle that points down.
     */
    public static final Icon TRIANGLE_DOWN = new TriangleIcon();

    /**
     * Dark gray triangle that points up.
     */
    public static final Icon TRIANGLE_UP   = new TriangleIcon(
                AffineTransform.getRotateInstance(Math.PI, WIDTH/2, HEIGHT/2));

    //===   CONSTANTS   ========================================================
    //==========================================================================



    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    protected TriangleIcon() {
        this(new AffineTransform());
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param txRotate should be how much to rotate by.
     *                 By default, the triangle points down.
     */
    protected TriangleIcon(AffineTransform txRotate) {
        BufferedImage img = new BufferedImage(WIDTH, HEIGHT,
                                              BufferedImage.TYPE_INT_ARGB);
        Graphics2D    g   = img.createGraphics();
        Shape         s;

        //// 1. Clear out the background.
        g.setColor(new Color(0, 0, 0, 0));
        g.fillRect(0, 0, WIDTH, HEIGHT);

        //// 2.2. Fill in the shape.
        s = getShape();
        g.transform(AffineTransform.getRotateInstance(Math.PI/2, 
                                                      WIDTH/2, HEIGHT/2));
        g.transform(txRotate);
        g.setColor(COLOR);
        g.fill(s);

        g.setColor(COLOR);
        g.draw(s);

        setImage(img);
    } // of constructor
 
    //----------------------------------------------------------------

    /**
     * Return a triangle shape pointed to the right.
     */
    protected Shape getShape() {
        Polygon p = new Polygon();
        p.addPoint(0,         0);
        p.addPoint(WIDTH / 2, HEIGHT / 2);
        p.addPoint(0,         HEIGHT);
        return (p);
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
