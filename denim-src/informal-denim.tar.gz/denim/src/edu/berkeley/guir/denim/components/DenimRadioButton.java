package edu.berkeley.guir.denim.components;

import java.awt.geom.Rectangle2D;
import edu.berkeley.guir.denim.DenimText;
import edu.berkeley.guir.denim.toolbox.RubberStamp;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

import java.awt.Color;
import java.awt.geom.Ellipse2D;
import edu.berkeley.guir.lib.satin.objects.*;

/**
 * The definition of a radio button for DENIM designs. This is a built-in
 * component.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-26-2003  James Lin
 *                                Created DenimRadioButton
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 02-26-2003
 */

public class DenimRadioButton extends DenimIntrinsicComponent {

   //===========================================================================
   //===   CONSTANTS   =========================================================


   //===   CONSTANTS   =========================================================
   //===========================================================================

   final static GraphicalObjectCollection mStateCollection;
   
   final static long checkedID = 20;
   final static long uncheckedID = 18;
   final static long checkboxID = 23;


   
   static {
		mStateCollection = new GraphicalObjectCollectionImpl();

        final Patch checked;
        final Patch unchecked;
        
		// unchecked
		unchecked = new PatchImpl(new Rectangle2D.Double(0, 0, 30, 30));
		unchecked.getStyleRef().setDrawColor(new Color(0, 0, 0, 0));
		unchecked.getStyleRef().setFillColor(new Color(0, 0, 0, 0));
		unchecked.getStyleRef().setLineWidth(1.0f);

        TimedStroke radioButtonBorder =
			new TimedStroke(new Ellipse2D.Double(0, 7.5, 15, 15));
		radioButtonBorder.getStyleRef().setDrawColor(Color.BLACK);
		radioButtonBorder.getStyleRef().setLineWidth(1.0f);
		unchecked.add(radioButtonBorder);
	
		// checked		
		//checked = (Patch)unchecked.clone();
		checked = new PatchImpl(new Rectangle2D.Double(0, 0, 30, 30));
		checked.getStyleRef().setDrawColor(new Color(0, 0, 0, 0));
		checked.getStyleRef().setFillColor(new Color(0, 0, 0, 0));
		checked.getStyleRef().setLineWidth(1.0f);

//        PatchImpl filledCircle = new PatchImpl(new Ellipse2D.Double(3.5, 11, 8, 8));
//        filledCircle.setFillPatch(true);
//      Rectangle2D rbox = radioButtonBorder.getBounds2D(COORD_REL);
//      Patch filledCircle = new PatchImpl(new Ellipse2D.Double(
  //                rbox.getMinX()+3.5, rbox.getMinY()+3.5, 8, 8));
      
        //filledCircle.getStyleRef().setDrawColor(Color.BLACK);
        //filledCircle.getStyleRef().setFillColor(Color.BLACK);
        //filledCircle.getStyleRef().setLineWidth(1.0f);
//        filledCircle.setVisible(true);
//        checked.add(filledCircle);//, KEEP_REL_POS);

        radioButtonBorder =
			new TimedStroke(new Ellipse2D.Double(0, 7.5, 15, 15));
		radioButtonBorder.getStyleRef().setDrawColor(Color.BLACK);
		radioButtonBorder.getStyleRef().setLineWidth(1.0f);
		checked.add(radioButtonBorder);
	
        radioButtonBorder =
            new TimedStroke(new Ellipse2D.Double(5.5, 13, 4, 4));
        radioButtonBorder.getStyleRef().setDrawColor(Color.BLACK);
        radioButtonBorder.getStyleRef().setLineWidth(5.0f);
        checked.add(radioButtonBorder);;
        
        unchecked.setUniqueID(uncheckedID);
        checked.setUniqueID(checkedID);
        
		mStateCollection.add(0, unchecked);
		mStateCollection.add(1, checked);  
   }
   
   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create a Denim radio button.
    */
   DenimRadioButton() {
      super();

      name = "Radio Button";
      stamp = new RubberStamp("radio_button.gif", this);
      
      this.setUniqueID(checkboxID);
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   COMPONENT METHODS   =================================================

   /**
    * Create a new instance of a radio button, for use in a Denim storyboard.
    *
    * @param border the border of the radio button
    * @param caption the caption of the radio button
    */
/*   public DenimComponentInstance newInstance(TimedStroke border,
                                             DenimText caption) {
      DenimComponentInstance instance =
         new DenimRadioButtonInstance(this, border, caption);
      instances.add(instance);
      return instance;
   }
*/
   //-----------------------------------------------------------------

   /**
    * Create a new instance of a radio button, for use in a Denim storyboard.
    */
   public DenimComponentInstance newInstance() {
      DenimComponentInstance instance = new DenimRadioButtonInstance(this);
      instances.add(instance);
      return instance;
   }

   //-----------------------------------------------------------------

   /**
    * Create a new instance of a radio button.
    *
    * Called only by DOMUtils.createRadioButtonFromDOMElement()
    */
   public DenimComponentInstance newInstance(
                            Rectangle2D bounds,
                            boolean selected,
                            TimedStroke radioButtonBorder,
                            DenimText caption,
                            boolean createdByStamp) {
      DenimComponentInstance instance =
         new DenimRadioButtonInstance(this, bounds, selected,
                                      radioButtonBorder, caption,
                                      createdByStamp);
      instances.add(instance);
      return instance;
   }

   
   public static boolean isSelected(GraphicalObject obj) {
       if(obj.equals(mStateCollection.get(0)))
       {
           return false;
       }
       else
       {
           return true;
       }
   }
   
   //===   COMPONENT METHODS   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
