package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.view.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.collection.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.satin.widgets.*;
import edu.berkeley.guir.lib.debugging.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

import javax.swing.*;
import java.util.*;
import java.util.List;
import java.awt.image.*;
import edu.berkeley.guir.lib.satin.image.*;
import edu.berkeley.guir.lib.satin.graphics.*;

/**
 * A Denim panel, which typically represents a screen in a GUI or a web page in
 * a web site. A panel is made up of a {@link DenimLabel label}, which is a
 * brief description of what the panel contains, and a {@link DenimSketch
 * sketch}, which is what the screen or web page looks like.
 * 
 * <PRE>
 * 
 * DenimSheet |---> DenimPanel |---> DenimLabel |---> DenimSketch |--->
 * TimedStroke |---> DenimHyperlinkInstance |---> ...
 * 
 * </PRE>
 * 
 * <P>
 * This software is distributed under the <A
 * HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt"> Berkeley Software
 * License </A>.
 * 
 * <PRE>
 * 
 * Revisions: 1.0.0 08-05-1999 JL Created class DenimPanel. 1.1.0 01-12-2003 YL
 * Enabled object frame for speeding dragging (This is the major class for
 * speeded dragging) 1.1.0 05-29-2003 YL getSketch().getView() is not always
 * MultiView
 * 
 * 
 * 
 * </PRE>
 * 
 * @see DenimLabel
 * @see DenimSketch
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin </A>( <A
 *         HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu </A>)
 * @author <A HREF="http://www.cs.berkeley.edu/~newman/">Mark Newman </A>( <A
 *         HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu </A>)
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li </A>( <A
 *         HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu </A>)
 * 
 * @since JDK 1.2
 * @version Version 1.1.0, 05-29-2003
 */
public class DenimPanel extends PatchImpl implements DenimConstants,
        ContextMenuSource, ObjectPhantom {

    //===========================================================================
    //=== CONSTANTS =========================================================

    static final long serialVersionUID = -7889446673189478598L;

    private static final Color ACTIVE_BORDER = Color.blue;

    //=== CONSTANTS =========================================================
    //===========================================================================

    //===========================================================================
    //=== INSTANCE VARIABLES ================================================

    private static boolean transferStateID = true;
    private long stateID = System.currentTimeMillis();

    private DenimLabel label;

    private DenimSketch sketch;

    private PanelBar panelBar = null;

    private DenimSketch backSketch = null; // the "back" of a conditional stack

    private Object container;

    private Map destToNavArrows; // maps dest to set of nav arrows

    private Set navArrows; // all of the outgoing nav arrows

    private boolean isHomePanel;

    private Style normalLabelStyle; // saves the normal style so that

    // it can be restored if the panel
    // stops being the home panel.
    private Style normalSketchStyle;

    private Polygon2D poly;

    private int currentDesignCondition; // the condition that the

    //   sketch is currently
    //   showing at design time,
    //   0 if all of them are shown
    private ComponentConditionMap2D conditionalStates; // 2D grid:

    //   row = component instance
    //   column = condition number
    //   grid entry = state
    private Patch highlighter;

    private boolean showPanelBar = false;

    //=== INSTANCE VARIABLES ================================================
    //===========================================================================

    // object frame for speedup dragging
    Rectangle2D labelFrame = null;

    Rectangle2D sketchFrame = null;

    Vector arrowOrgInFrame = new Vector();

    Vector arrowOrgOutFrame = new Vector();

    Vector arrowNavInFrame = new Vector();

    Vector arrowNavOutFrame = new Vector();

    Vector recoverList = new Vector();

    BufferedImage labelImage = null;

    BufferedImage sketchImage = null;

    // end

    //===========================================================================
    //=== NESTED CLASSES ====================================================

    /**
     * If a patch has more than one condition, then it should be rendered as a
     * "stack" of sketches. BackSketch provides the "bottom sketch" in the
     * stack.
     */
    private class BackSketch extends PatchImpl {
        BackSketch(Rectangle2D r) {
            super(r);
            this.getStyleRef().setFillColor(Color.white);
            this.getStyleRef().setDrawColor(Color.black);
            this.getStyleRef()
                    .setLineWidth(DenimConstants.DEFAULT_BORDER_WIDTH);
        }

        public boolean isVisible() {
            DenimSketch sketch = DenimPanel.this.getSketch();
            if (sketch == null) {
                return false;
            }
            return sketch.isSketchVisible();
        }
    }

    //-----------------------------------------------------------------

    /**
     * Maps component instance (row) and condition number (column) to the state
     * that the component instance should be in at a particular condition. If
     * the state is null, then it does not matter what state the component
     * instance is in in that particular condition.
     */
    public class ComponentConditionMap2D extends Map2D {

        public ComponentConditionMap2D() {
            super();
        }

        public ComponentConditionMap2D(Map2D grid) {
            super(grid);
        }

        /**
         * Returns the header of a column (a condition number) that partially
         * matches the given collection of data (a set of component instances
         * mapped to states), or null if there is no partial match.
         * 
         * A set of component instances mapped to states matches a condition if
         * every component instance-state pair in the column is also in the set,
         * although the set may have other component instace-state pairs. Also,
         * if the state of the component instance does not matter for evaluating
         * a condition, then the state of the component instance in the 2D map
         * and in the given set do not need to match.
         */
        public Object partialMatchCol(Map colData) {
            Set cols = getCols();
            if (cols == null) {
                return null;
            }
            Iterator colIt = cols.iterator();
            while (colIt.hasNext()) {
                Object colHeader = colIt.next();
                boolean match = true;

                Iterator rowIt = getRows().iterator();
                while (rowIt.hasNext()) {
                    DenimComponentInstance rowHeader = (DenimComponentInstance) rowIt
                            .next();
                    if (rowHeader.getDoesMatterInConditionEval()) {
                        Object dataAtRowCol = get(rowHeader, colHeader);
                        if (dataAtRowCol == null) {
                            match = (colData.get(rowHeader) == null);
                        } else if (!dataAtRowCol.equals(colData.get(rowHeader))) {
                            match = false;
                        }
                    }
                }

                if (match) {
                    return colHeader;
                }
            }
            // must have no match
            return null;
        }
    }

    //=== NESTED CLASSES ====================================================
    //===========================================================================

    //-----------------------------------------------------------------

    /**
     * intialize image frame of a panel for multiple selection
     */

    public DenimPanel initFrameForMultiSelection(
            GraphicalObjectCollection selections, List navs, List orgs,
            List internalArrows) {
        if (label != null && label.isVisible()) {
            labelFrame = label.getBounds2D(COORD_ABS);
            labelImage = this.label.getRenderCache().getCacheImage();

        }

        if (sketch != null && sketch.isVisible()
                && !getBounds2D(COORD_ABS).equals(label.getBounds2D(COORD_ABS))) {

            sketchFrame = sketch.getBounds2D(COORD_ABS);
            sketchImage = this.sketch.getRenderCache().getCacheImage();
        }

        getInternalHyperLinks(selections, navs, orgs, internalArrows);

        return this;
    }

    //-----------------------------------------------------------------

    public void releaseResource() {
        labelFrame = null;
        labelImage = null;
        sketchFrame = null;
        sketchImage = null;
    }
    
    //-----------------------------------------------------------------
    
    /**
     * The state id only affects custom component instance. 
     * The ID helps to identify the right state of an instance from the 
     * custom component
     */
    public static void setTransferStateID(boolean b) {
        DenimPanel.transferStateID = b;
    }

    //-----------------------------------------------------------------
    
    public void setStateID(long id) {
        this.stateID = id;
    }

    //-----------------------------------------------------------------
    
    public long getStateID() {
        return this.stateID;
    }

    //-----------------------------------------------------------------

    public Polygon2D getPhantom() {

        Rectangle2D sb = this.getSketch().getBounds2D(COORD_ABS);
        Rectangle2D lb = this.getLabel().getBounds2D(COORD_ABS);

        Polygon2D poly = new Polygon2D();

        poly.addPoint(lb.getMinX(), lb.getMinY());
        poly.addPoint(sb.getMinX(), sb.getMaxY());
        poly.addPoint(sb.getMaxX(), sb.getMaxY());
        poly.addPoint(sb.getMaxX(), sb.getMinY());
        poly.addPoint(lb.getMaxX(), lb.getMaxY());
        poly.addPoint(lb.getMaxX(), lb.getMinY());
        poly.setClosed(true);

        return poly;
    }

    //-----------------------------------------------------------------

    /**
     * get inter-hyperlinks in multi-selection objects
     */

    public void getInternalHyperLinks(GraphicalObjectCollection selections,
            List navs, List orgs, List internalArrows) {

        arrowOrgInFrame.clear();
        arrowOrgOutFrame.clear();
        arrowNavInFrame.clear();
        arrowNavOutFrame.clear();
        recoverList.clear();

        Set labelIncom = this.label.getIncomingArrows();

        for (int i = 0; i < labelIncom.size(); i++) {
            Arrow ar = (Arrow) labelIncom.toArray()[i];
            
            if(ar.isGlobal())
                continue;

            if (ar.getSourcePanel() == null
                    || selections.contains(ar.getSourcePanel())) {
                continue;
            }

            Point2D sp = ar.getStartPoint2D(COORD_ABS);
            Point2D ep = ar.getEndPoint2D(COORD_ABS);

            if (ar.getType() == Arrow.NAV) {
                arrowNavInFrame.add(new Line2D.Double(sp, ep));
            } else {
                arrowOrgInFrame.add(new Line2D.Double(sp, ep));
            }

            recoverList.add(ar);

        }

        Set labelOut = this.label.getOutgoingArrows();

        for (int i = 0; i < labelOut.size(); i++) {
            Arrow ar = (Arrow) labelOut.toArray()[i];
            //  	  	if(((Arrow)labelOut.toArray()[i]).isVisible()==false)
            //  	  		continue;
            if(ar.isGlobal())
                continue;
            
            Point2D sp = ar.getStartPoint2D(COORD_ABS);
            Point2D ep = ar.getEndPoint2D(COORD_ABS);

            if (selections.contains(ar.getDestPanel())) {
                orgs.add(new Line2D.Double(sp, ep));
                internalArrows.add(ar);
            } else
                arrowOrgOutFrame.add(new Line2D.Double(sp, ep));

            recoverList.add(ar);

        }

        Set sketchIncome = this.sketch.getIncomingArrows();

        for (int i = 0; i < sketchIncome.size(); i++) {
            Arrow ar = (Arrow) sketchIncome.toArray()[i];

            if(ar.isGlobal())
                continue;
            
            if (ar.getSheet() == null)
                continue;

            if (ar.getSourcePanel() == null
                    || selections.contains(ar.getSourcePanel())) {
                continue;
            }

            Point2D sp = ar.getStartPoint2D(COORD_ABS);
            Point2D ep = ar.getEndPoint2D(COORD_ABS);

            if (ar.getType() == Arrow.NAV) {
                arrowNavInFrame.add(new Line2D.Double(sp, ep));
            } else {
                arrowOrgInFrame.add(new Line2D.Double(sp, ep));
            }

            recoverList.add(ar);
        }

        Set sketchOut = this.sketch.getOutgoingArrows();

        for (int i = 0; i < sketchOut.size(); i++) {
            Arrow ar = (Arrow) sketchOut.toArray()[i];

            //  	  	if(((Arrow)sketchOut.toArray()[i]).isVisible()==false)
            //  	  		continue;

            if(ar.isGlobal())
                continue;
            
            Point2D sp = ((Arrow) sketchOut.toArray()[i])
                    .getStartPoint2D(COORD_ABS);
            Point2D ep = ((Arrow) sketchOut.toArray()[i])
                    .getEndPoint2D(COORD_ABS);

            if (selections.contains(ar.getDestPanel())) {
                navs.add(new Line2D.Double(sp, ep));
                internalArrows.add(ar);
            } else
                arrowOrgOutFrame.add(new Line2D.Double(sp, ep));

            recoverList.add(ar);
        }

        for (int i = 0; i < navArrows.size(); i++) {
            Arrow ar = (Arrow) navArrows.toArray()[i];

            //   	  	if(recoverList.contains(ar))
            //   	  		continue;

            //   	  	if(((Arrow)navArrows.toArray()[i]).isVisible()==false)
            //   	  		continue;

            if(ar.isGlobal())
                continue;
            
            Point2D sp = ar.getStartPoint2D(COORD_ABS);
            Point2D ep = ar.getEndPoint2D(COORD_ABS);

            if (selections.contains(ar.getDestPanel())) {
                navs.add(new Line2D.Double(sp, ep));
                internalArrows.add(ar);
            } else
                arrowNavOutFrame.add(new Line2D.Double(sp, ep));

            //arrowOutSketchFrame.add(new Line2D.Double(sp,ep));
            recoverList.add(ar);
        }

    }

    //-----------------------------------------------------------------

    /**
     * move mutli-selection panels
     */

    public void moveFrameForMultiSelection(Graphics2D bg, double dx, double dy,
            double adjustX, double adjustY) {

        if (labelFrame != null) {
            labelFrame.setRect(labelFrame.getMinX() + dx, labelFrame.getMinY()
                    + dy, labelFrame.getWidth(), labelFrame.getHeight());
        }

        if (sketchFrame != null) {
            sketchFrame.setRect(sketchFrame.getMinX() + dx, sketchFrame
                    .getMinY()
                    + dy, sketchFrame.getWidth(), sketchFrame.getHeight());
        }

        if (labelFrame != null && labelImage != null) {
            int ox = (int) labelFrame.getMinX();
            int oy = (int) labelFrame.getMinY();

            bg.drawImage(labelImage, ox, oy, this.getSheet());
        }

        if (sketchFrame != null && sketchImage != null) {
            int ox = (int) sketchFrame.getMinX();
            int oy = (int) sketchFrame.getMinY();

            AffineTransform tr = this.getSketch().getTransform(COORD_ABS);
            tr.concatenate(DenimSketch.antiBlurTransform);

            AffineTransform scaleT = AffineTransform.getScaleInstance(tr
                    .getScaleX(), tr.getScaleY());
            AffineTransform trT = AffineTransform.getTranslateInstance(
                    sketchFrame.getMinX(), sketchFrame.getMinY());
            AffineTransform trTP = AffineTransform.getTranslateInstance(
                    -sketchFrame.getMinX(), -sketchFrame.getMinY());
            trT.concatenate(scaleT);
            trT.concatenate(trTP);

            bg.setTransform(trT);

            bg.drawImage(sketchImage, ox, oy, this.getSheet());
            bg.setTransform(AffineTransform.getTranslateInstance(0, 0));
        }

        Rectangle2D wholeFrame = new Rectangle2D.Double();

        if (sketchFrame != null && labelFrame != null)
            Rectangle2D.union(labelFrame, sketchFrame, wholeFrame);
        else if (labelFrame != null)
            wholeFrame = labelFrame;
        else
            wholeFrame = null;

        if (wholeFrame != null) {
            bg.setColor(Color.blue);
            renderSelected(bg, wholeFrame);
        }

        for (int i = 0; i < arrowNavOutFrame.size(); i++) {
            Line2D line = (Line2D) arrowNavOutFrame.get(i);
            line.setLine(line.getP1().getX() + dx, line.getP1().getY() + dy,
                    line.getP2().getX() + adjustX, line.getP2().getY()
                            + adjustY);
        }

        for (int i = 0; i < arrowNavInFrame.size(); i++) {
            Line2D line = (Line2D) arrowNavInFrame.get(i);
            line.setLine(line.getP1().getX() + adjustX, line.getP1().getY()
                    + adjustY, line.getP2().getX() + dx, line.getP2().getY()
                    + dy);
        }

        for (int i = 0; i < arrowOrgOutFrame.size(); i++) {
            Line2D line = (Line2D) arrowOrgOutFrame.get(i);
            line.setLine(line.getP1().getX() + dx, line.getP1().getY() + dy,
                    line.getP2().getX() + adjustX, line.getP2().getY()
                            + adjustY);
        }

        for (int i = 0; i < arrowOrgInFrame.size(); i++) {
            Line2D line = (Line2D) arrowOrgInFrame.get(i);
            line.setLine(line.getP1().getX() + adjustX, line.getP1().getY()
                    + adjustY, line.getP2().getX() + dx, line.getP2().getY()
                    + dy);
        }

        bg.setStroke(new BasicStroke(1));

        bg.setColor(DEFAULT_ORG_ARROW_COLOR);

        for (int i = 0; i < arrowOrgOutFrame.size(); i++) {
            Line2D line = (Line2D) arrowOrgOutFrame.get(i);
            bg.draw(line);
            DenimPanel.drawArrowheads(line, bg);
        }

        for (int i = 0; i < arrowOrgInFrame.size(); i++) {
            Line2D line = (Line2D) arrowOrgInFrame.get(i);
            bg.draw(line);
            DenimPanel.drawArrowheads(line, bg);
        }

        bg.setColor(DEFAULT_NAV_ARROW_COLOR);

        for (int i = 0; i < arrowNavOutFrame.size(); i++) {
            Line2D line = (Line2D) arrowNavOutFrame.get(i);
            bg.draw(line);
            DenimPanel.drawArrowheads(line, bg);
        }

        for (int i = 0; i < arrowNavInFrame.size(); i++) {
            Line2D line = (Line2D) arrowNavInFrame.get(i);
            bg.draw(line);
            DenimPanel.drawArrowheads(line, bg);
        }

    }

    //-----------------------------------------------------------------

    /**
     * Draws the arrowheads and beginning dot for this arrow.
     */

    public static void computeArrowheadParams(Line2D line, int[] retpoints) {

        Point last = new Point();
        Point penult = new Point();
        int x1, x2, y1, y2, x1Offset, x2Offset;
        double m1, m2, b1, b2;
        double th;

        last.setLocation(line.getP2());
        penult.setLocation(line.getP1());

        th = Math.atan((double) (last.y - penult.y)
                / (double) (last.x - penult.x));
        if (last.x > penult.x) {
            th = Math.PI + th;
        }
        if (last.x == penult.x) { // handle the case where arrow slope is
            // infinity
            if (last.y > penult.y) {
                th = -Math.PI / 2.0;
            } else {
                th = Math.PI / 2.0;
            }
        }

        //=== 3. Determine x coordinates of arrowhead endpoints
        x1Offset = (int) (Arrow.getArrowheadLength() * Math.cos(th
                + Arrow.getArrowheadAngle()));
        x2Offset = (int) (Arrow.getArrowheadLength() * Math.cos(th
                - Arrow.getArrowheadAngle()));
        x1 = last.x + x1Offset;
        x2 = last.x + x2Offset;

        //=== 4. Determine linear equations for arrowhead segments
        m1 = Math.tan(th + Arrow.getArrowheadAngle());
        m2 = Math.tan(th - Arrow.getArrowheadAngle());
        b1 = last.y - m1 * last.x;
        b2 = last.y - m2 * last.x;

        //=== 5. Get y values
        y1 = (int) (m1 * x1 + b1);
        y2 = (int) (m2 * x2 + b2);

        //=== 6. Handle case where the slope of an arrowhead is (close to)
        // infinity
        if ((x1 == last.x && y1 == last.y) || m1 > 1000000.0 || m1 < -1000000.0) {
            if (last.y > penult.y) {
                y1 = (int) (last.y - Arrow.getArrowheadLength());
            } else {
                y1 = (int) (last.y + Arrow.getArrowheadLength());
            }
        }
        if ((x2 == last.x && y2 == last.y) || m2 > 1000000.0 || m2 < -1000000.0) {
            if (last.y > penult.y) {
                y2 = (int) (last.y - Arrow.getArrowheadLength());
            } else {
                y2 = (int) (last.y + Arrow.getArrowheadLength());
            }
        }

        retpoints[0] = last.x;
        retpoints[1] = last.y;
        retpoints[2] = x1;
        retpoints[3] = y1;
        retpoints[4] = x2;
        retpoints[5] = y2;

    }

    //-----------------------------------------------------------------

    public static void drawArrowheads(Line2D arrow, Graphics2D g) {

        int[] retpoints = new int[6];

        int startCircleRadius = (int) Arrow.getArrowheadLength();

        g.fillOval((int) arrow.getP1().getX() - startCircleRadius / 2,
                (int) arrow.getP1().getY() - startCircleRadius / 2,
                startCircleRadius, startCircleRadius);

        computeArrowheadParams(arrow, retpoints);

        Polygon arrowhead = new Polygon();
        arrowhead.addPoint(retpoints[0], retpoints[1]);
        arrowhead.addPoint(retpoints[2], retpoints[3]);
        arrowhead.addPoint(retpoints[4], retpoints[5]);
        g.fillPolygon(arrowhead);
    }

    //-----------------------------------------------------------------

    public void disposeObjectFrame() {

        labelFrame = null;
        sketchFrame = null;

        arrowOrgInFrame.clear();
        arrowOrgOutFrame.clear();
        arrowNavInFrame.clear();
        arrowNavOutFrame.clear();
        //	  recoverList.clear();

        labelImage = null;
        sketchImage = null;

    }

    //-----------------------------------------------------------------
    // copied from SATIN

    private void renderSelected(Graphics2D g, Rectangle2D rect) {
        //// 1. Get the size of the handle.
        int size = 6;

        //// 2. Calculate the location of the handles.
        int x = (int) rect.getX();
        int y = (int) rect.getY();
        int w = (int) rect.getWidth();
        int h = (int) rect.getHeight();

        int x1 = x; // top-left
        int y1 = y;
        int x2 = x + w / 2; // top-mid
        int y2 = y;
        int x3 = x + w; // top-right
        int y3 = y;
        int x4 = x + w; // mid-right
        int y4 = y + h / 2;
        int x5 = x + w; // bottom-right
        int y5 = y + h;
        int x6 = x + w / 2; // bottom-mid
        int y6 = y + h;
        int x7 = x; // bottom-left
        int y7 = y + h;
        int x8 = x; // mid-left
        int y8 = y + h / 2;

        //// 3. Paint the handles.
        g.fillRect(x1 - size / 2, y1 - size / 2, size, size);
        g.fillRect(x2 - size / 2, y2 - size / 2, size, size);
        g.fillRect(x3 - size / 2, y3 - size / 2, size, size);
        g.fillRect(x4 - size / 2, y4 - size / 2, size, size);
        g.fillRect(x5 - size / 2, y5 - size / 2, size, size);
        g.fillRect(x6 - size / 2, y6 - size / 2, size, size);
        g.fillRect(x7 - size / 2, y7 - size / 2, size, size);
        g.fillRect(x8 - size / 2, y8 - size / 2, size, size);
    } // of method

    //===========================================================================
    //=== CONSTRUCTORS ======================================================

    /**
     * Performs initializations common to all constructors
     */
    private void init() {
        destToNavArrows = new HashMap();
        navArrows = new HashSet();
        isHomePanel = false;

        //=== This is a patch with no border or fill
        Style style = getStyle();
        style.setDrawColor(NO_COLOR);
        style.setFillColor(NO_COLOR);
        setStyle(style);

        this.setFillPatch(false);
        this.setDrawPatch(false);

        poly = new Polygon2D();

        currentDesignCondition = 1;
        conditionalStates = new ComponentConditionMap2D();
        conditionalStates.addCol(new Integer(currentDesignCondition));
    }

    //-----------------------------------------------------------------

    /**
     * Creates an empty panel. Called by deepClone().
     */
    protected DenimPanel() {
        super();

        label = null;
        sketch = null;

        init();
    }

    //-----------------------------------------------------------------

    /**
     * Creates a panel with the given rectangle as its bounding box.
     */
    public DenimPanel(Rectangle2D r) {
        super(r);

        label = null;
        sketch = null;
        panelBar = null;

        init();
    }

    //-----------------------------------------------------------------

    /**
     * Creates a panel with the given label and sketch.
     */
    /*
     * This constructor is not currently being used.
     */
    public DenimPanel(DenimLabel label, DenimSketch sketch) {
        super();

        if (sketch != null) {
            this.addToBack(sketch, GraphicalObjectGroup.KEEP_ABS_POS);
        }
        this.sketch = sketch;

        if (label != null) {
            this.addToFront(label, GraphicalObjectGroup.KEEP_ABS_POS);
            label.setSketch(sketch);
        }
        this.label = label;

        resize();

        init();

        //debug.println("Created panel: " + this);
    }

    //-----------------------------------------------------------------

    /**
     * Called only by DOMUtils.createDenimPanelFromDOMElement
     */
    public DenimPanel(Rectangle2D bounds, AffineTransform tx, DenimLabel label,
            DenimSketch sketch) {
        super(bounds);
        setTransform(tx);

        addToBack(sketch, GraphicalObjectGroup.KEEP_REL_POS);
        this.sketch = sketch;
        addWatcher(sketch);

        addToFront(label, GraphicalObjectGroup.KEEP_REL_POS);
        this.label = label;
        label.setSketch(sketch);
        addWatcher(label);

        init();

        if (showPanelBar) {
            panelBar = new PanelBar(this);
        }

        //resize();
    }

    //-----------------------------------------------------------------

    /**
     * Creates a panel with the given label and no sketch.
     */
    /*
     * This constructor is not currently being used.
     */
    public DenimPanel(DenimLabel label) {
        this(label, null);
    }

    //-----------------------------------------------------------------

    /**
     * Creates a panel with the given sketch and no label.
     */
    /*
     * This constructor is not currently being used.
     */
    public DenimPanel(DenimSketch sketch) {
        this(null, sketch);
    }

    //-------------------------------------------------------------------

    /*
     * // Shelley and Peter // Wrapped constructor for making DenimPanel device
     * aware public DenimPanel(DeviceType dt, DenimLabel dl, DenimSketch ds) { //
     * call the regular DenimPanel constructor this (dl, ds); // get Device
     * information from DenimUtil DeviceType temp = Denim.getDeviceInfo(); if
     * (temp.getName() != dt.getName()) { // change the device type
     * Denim.setDeviceInfo(dt); } }
     */

    //=== CONSTRUCTORS ======================================================
    //===========================================================================
    /**
     * Turns on or off the "stack" effect, if this panel has more than one
     * condition.
     */
    public void setStackEffect(boolean flag) {
        if (backSketch != null) {
            ((MultiView) backSketch.getView()).get(0).setVisible(flag);
        }
    }

    //-----------------------------------------------------------------

    public boolean isStackEffect() {
        if (backSketch != null) {
            if (backSketch.getView() instanceof MultiView) {
                return ((MultiView) backSketch.getView()).get(0).isVisible();
            } else {
                return backSketch.getView().isVisible();
            }
        } else {
            return false;
        }
    }

    //-----------------------------------------------------------------

    protected void defaultRender(SatinGraphics sg) {
        /*if (SatinImageLib.imageConvertingRender) {
            super.defaultRender(sg);
            return;
        }*/
        super.defaultRender(sg);
    }

    protected void renderSelected(SatinGraphics g, Rectangle2D rect) {
        if (RadarViewPanel.isRadarViewRendering() == false)
            super.renderSelected(g, rect);
    }

    //-----------------------------------------------------------------

    /**
     * Make the panel look like a stack, if appropriate.
     */
    private void initStackEffect() {
        if (getNumConditions() > 1 && backSketch == null && getSketch() != null) {
            backSketch = new DenimSketch(getSketch().getBounds2D(COORD_ABS));
            this.addToBack(backSketch, GraphicalObjectGroup.KEEP_ABS_POS);
            backSketch.moveBy(COORD_ABS, 3, 3);
            backSketch.initAfterAddSketchToSheet();
        }
    }

    //-----------------------------------------------------------------

    public Vector getLabelArrow() {
        Vector col = new Vector();
        col.addAll(label.getIncomingArrows());
        col.addAll(label.getOutgoingArrows());
        return col;
    }

    //-----------------------------------------------------------------

    public Vector getSketchArrow() {
        Vector col = new Vector();
        col.addAll(sketch.getIncomingArrows());
        col.addAll(sketch.getOutgoingArrows());
        col.addAll(navArrows);
        return col;
    }

    //===========================================================================
    //=== INTERNAL METHODS ==================================================

    protected Polygon2D getLocalBoundingPoints2DRef() {
        Rectangle2D sketchAbsBounds = null;
        Rectangle2D labelAbsBounds = null;
        Rectangle2D condAbsBounds = null;

        //// 1. Get the bounds for the sketch and label.
        if (sketch != null && sketch.isSketchVisible()) {
            sketchAbsBounds = sketch.getBounds2D(COORD_ABS);
        }
        if (label != null && label.isVisible()) {
            labelAbsBounds = label.getBounds2D(COORD_ABS);
        }
        if (panelBar != null && panelBar.isVisible()) {
            condAbsBounds = panelBar.getBounds2D(COORD_ABS);
        }

        //// 2. This is a workaround due to constructor
        //// in PatchImpl.
        if (poly == null) {
            return (new Polygon2D(new Rectangle(0, 0, 0, 0)));
        }

        //// 3. Set the size.
        Shape newShape = DenimUtils.createUnion(condAbsBounds, DenimUtils
                .createUnion(labelAbsBounds, sketchAbsBounds));
        if (newShape != null) {
            poly.setToShape(newShape);
        }
        /*
         * if ((sketchAbsBounds != null) && (labelAbsBounds == null)) {
         * poly.setToShape(sketchAbsBounds); } else if ((labelAbsBounds != null) &&
         * (sketchAbsBounds == null)) { poly.setToShape(labelAbsBounds); } else
         * if ((labelAbsBounds != null) && (sketchAbsBounds != null)) {
         * poly.setToShape(sketchAbsBounds.createUnion(labelAbsBounds)); } else {
         * poly.setToShape(new Rectangle(0, 0, 0, 0)); return (poly); }
         */

        poly.transform(getInverseTransform(COORD_ABS));

        return (poly);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Resizes the panel so that its bounding box is the union of the the
     * bounding box of the label and the sketch.
     */
    private void resize() {
        Rectangle2D labelAbsBounds = null;
        Rectangle2D sketchAbsBounds = null;
        Rectangle2D newAbsBounds = null;

        if (label != null) {
            labelAbsBounds = label.getBounds2D(COORD_ABS);
        }

        if (sketch != null) {

            // By default, the size of sketch is that of DeviceType Desktop
            sketchAbsBounds = sketch.getBounds2D(COORD_ABS);

            // Shelley and Peter
            if (Denim.getDeviceInfo().getName() == DeviceType.SMARTPHONE
                    .getName()) {

                double topLeftX = sketchAbsBounds.getMinX();
                double topLeftY = sketchAbsBounds.getMinY();

                DenimSheet sheet = (DenimSheet) getSheet();
                double scaleFactor = sheet.getAbsScale();

                // change the size of sketch bounding box
                double width = Denim.getDeviceInfo().getWidth() * scaleFactor;
                double height = Denim.getDeviceInfo().getHeight() * scaleFactor;

                sketchAbsBounds = new Rectangle2D.Double(topLeftX, topLeftY,
                        width, height);

            }

        }

        //debug.println("BEFORE: Label abs bounds: " +
        // DenimUtils.toShortString(labelAbsBounds));
        //debug.println("Sketch abs bounds: " +
        // DenimUtils.toShortString(sketchAbsBounds));

        //// 1. Set the bounds to include the label and/or sketch
        if ((label != null) && (sketch == null)) {
            newAbsBounds = labelAbsBounds;
        } else if ((sketch != null) && (label == null)) {
            newAbsBounds = sketchAbsBounds;
        } else {
            newAbsBounds = labelAbsBounds.createUnion(sketchAbsBounds);

            // Shelley
            // System.out.println("I am getting a union of sketchAbsBounds and
            // labelAbsBounds");
        }

        // Careful: this.getParentGroup() could be null
        //newRelBounds =
        //   GraphicalObjectLib.absoluteToLocal(this.getParentGroup(),
        //                                      newAbsBounds);

        //debug.println("AFTER: new abs bounds: " +
        // DenimUtils.toShortString(newAbsBounds));
        //debug.println("New rel bounds: " +
        // DenimUtils.toShortString(newRelBounds));

        setBoundingPoints2D(COORD_ABS, newAbsBounds);
        //setBoundingPoints2D(COORD_REL, newRelBounds);

        if (label != null) {
            //debug.println("DURING: New Label abs bounds: " + labelAbsBounds);
            //debug.println("DURING: Current Label abs bounds: " +
            // label.getBounds2D(COORD_ABS));

            Rectangle2D labelRelBounds = GraphicalObjectLib.absoluteToLocal(
                    this, labelAbsBounds);

            label.setBoundingPoints2D(COORD_REL, labelRelBounds);
            //debug.println("RIGHT AFTER: Label abs bounds: " +
            // label.getBounds2D(COORD_ABS));
        }
        //      else if (sketch != null) {
        if (sketch != null) {
            Rectangle2D sketchRelBounds = GraphicalObjectLib.absoluteToLocal(
                    this, sketchAbsBounds);

            sketch.setBoundingPoints2D(COORD_REL, sketchRelBounds);
        }
        //debug.println("AFTER: Panel abs bounds: " + getBounds2D(COORD_ABS));
        //if (label != null) {
        //debug.println("Label abs bounds: " + label.getBounds2D(COORD_ABS));
        //}
        //if (sketch != null) {
        //debug.println("Sketch abs bounds: " + sketch.getBounds2D(COORD_ABS));
        //}
    } // of method

    public static DenimPanel getPanel(GraphicalObject gob) {
        if (gob instanceof DenimPanel)
            return (DenimPanel) gob;
        if (gob.getParentGroup() == null
                || gob.getParentGroup() == gob.getSheet())
            return null;
        return getPanel(gob.getParentGroup());
    }

    public int getResizeMode() {
        return SatinConstants.RESIZE_CHANGE_BOUNDS;
    }

    /**
     * Resize this page, by adjusting the bounds of its sketch. This is gonna
     * take a bit of logic, since the label doesn't resize, and the sketch may
     * be either wider or narrower than the label is right now...
     */
    public void resizePageTo(int cdsys, Rectangle2D stretchRect,
            boolean widthFixed, boolean heightFixed) {
        Rectangle2D labelBounds = null;
        Rectangle2D sketchBounds = null;
        Rectangle2D newSketchBounds = null;
        Rectangle2D newRelBounds = null;

        if (label != null) {
            labelBounds = label.getBounds2D(COORD_REL);
        } else
            labelBounds = new Rectangle2D.Double(0, 0, 0, 0);

        if (sketch != null) {
            double newHeight, newWidth, oldHeight, oldWidth;
            oldHeight = sketch.getHeight2D(COORD_REL);
            oldWidth = sketch.getWidth2D(COORD_REL);
            sketchBounds = sketch.getBounds2D(COORD_REL);
            if (cdsys != COORD_ABS)
                Debug.println("oops, expected COORD_ABS");
            else {
                // newRelBounds = GraphicalObjectLib.absoluteToLocal(this,
                // stretchRect);
                DenimSheet sheet = (DenimSheet) getSheet();
                double scaleFactor = sheet.getAbsScale();
                newRelBounds = new Rectangle2D.Double(sketchBounds.getX(),
                        sketchBounds.getY(), stretchRect.getWidth()
                                * scaleFactor, stretchRect.getHeight()
                                * scaleFactor);
            }
            if (heightFixed)
                newHeight = oldHeight;
            else
                newHeight = newRelBounds.getHeight();//-labelBounds.getHeight();
            if (newHeight < 10)
                newHeight = 10;
            if (widthFixed)
                newWidth = oldWidth;
            else
                newWidth = newRelBounds.getWidth();
            if (!heightFixed && !widthFixed) // proportional
                if (oldWidth / oldHeight > newWidth / newHeight)
                    // used to be fatter, increase width
                    newWidth = newHeight * (oldWidth / oldHeight);
                else
                    newHeight = newWidth * (oldHeight / oldWidth);

            newSketchBounds = new Rectangle2D.Double(sketchBounds.getMinX(),
                    sketchBounds.getMinY() - labelBounds.getHeight(), newWidth,
                    newHeight);

            sketch.setBoundingPoints2D(COORD_REL, newSketchBounds);
            //this.damage(DAMAGE_NOW);
            resize();

        }
    }

    //=== INTERNAL METHODS ==================================================
    //===========================================================================

    //===========================================================================
    //=== ACCESSOR METHODS ==================================================

    /**
     * Returns whether the panel is the home panel. A home panel represents the
     * main screen of a GUI or home page of a web site.
     */
    public boolean isHome() {
        return isHomePanel;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Sets or resets this panel as the home panel.
     */
    public void setHome(boolean flag) {
        isHomePanel = flag;

        if (isHomePanel) {
            normalLabelStyle = getLabel().getStyle();
            normalSketchStyle = getSketch().getStyle();

            Style style = getLabel().getStyleRef();
            style.setDrawColor(DEFAULT_HOME_COLOR);
            style.setLineWidth(DEFAULT_HOME_WIDTH);

            style = getSketch().getStyleRef();
            style.setDrawColor(DEFAULT_HOME_COLOR);
            style.setLineWidth(DEFAULT_HOME_WIDTH);
        } else {
            getLabel().setStyle(normalLabelStyle);
            getSketch().setStyle(normalSketchStyle);
        }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Sets or resets whether this panel is being viewed in the Run window.
     */
    public void setActive(boolean arg) {
        /*
         * if (arg == true) { Style style = getStyle();
         * style.setDrawColor(ACTIVE_BORDER); style.setFillColor(ACTIVE_BORDER);
         * setStyle(style); } else { Style style = getStyle();
         * style.setDrawColor(NO_COLOR); style.setFillColor(NO_COLOR);
         * setStyle(style); }
         */
    }

    //-----------------------------------------------------------------
    public void setHyperLinkVisible(boolean b) {

        for (int i = 0; i < recoverList.size(); i++) {
            Arrow ar = (Arrow) recoverList.get(i);
            ar.setVisible(b);
        }

    }

    //-----------------------------------------------------------------

    /**
     * Returns this panel's sketch.
     */
    public DenimSketch getSketch() {
        return sketch;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Sets the sketch of the panel to the given sketch. The sketch's
     * coordinates should be absolute.
     */
    public void setSketch(DenimSketch newSketch) {
        if (sketch != null) {
            this.remove(sketch);
            removeWatcher(sketch);
        }

        if (newSketch != null) {
            this.addToBack(newSketch, GraphicalObjectGroup.KEEP_ABS_POS);
            this.sketch = newSketch;
            addWatcher(newSketch);

            initStackEffect();

            resize();

            if (label != null) {
                label.setSketch(sketch);
                addWatcher(label);
            }
        }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns this panel's label.
     */
    public DenimLabel getLabel() {
        return label;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Sets the label of the panel to the given label. The label's coordinates
     * should be absolute.
     */
    public void setLabel(DenimLabel newLabel) {
        if (label != null) {
            this.remove(label);
            removeWatcher(label);
        }

        if (newLabel != null) {
            this.addToFront(newLabel, GraphicalObjectGroup.KEEP_ABS_POS);

            this.label = newLabel;
            addWatcher(newLabel);

            if (sketch != null) {
                label.setSketch(sketch);
            }

            resize();

            //debug.println("AFTER: Label's absolute bounds: " +
            // label.getBounds2D(COORD_ABS));
            // Create a conditional control strip for this panel.
            if (showPanelBar) {
                if (panelBar == null) {
                    this.panelBar = new PanelBar(this);
                }
                if (getNumConditions() == 1) {
                    this.panelBar.setVisible(false);
                }
            }
        }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Gets the panel bar of the panel.
     */
    public PanelBar getPanelBar() {
        if(panelBar==null)
            panelBar = new PanelBar(this);
        return panelBar;
    }

    //-----------------------------------------------------------------
    /*
     * public boolean isVisible() { return (true); } // of method
     */
    //=== ACCESSOR METHODS ==================================================
    //===========================================================================
    //===========================================================================
    //=== OTHER METHODS =====================================================
    /**
     * <ul>
     * <li>Adds the panel to the given sheet
     * <li>Puts the panel in the upper left-hand corner of the given sheet
     * <li>Sets the background of text to clear
     * <li>Sets the views of the panel's label and sketch so that they are
     * always visible
     * </ul>
     */
    public void makeVisibleAtUpperLeftIn(Sheet s) {
        //// 1. Add it to the sheet.
        s.add(this);

        //// 2. Make the background of every ScribbledText clear
        setTextBackgroundsTransparent();

        //debug.println();
        //debug.println("orig pan - xform: " +
        // DenimUtils.toShortString(panel.getTransformRef()));
        //debug.println("orig pan - lty : " +
        // panel.getLabel().getLabelView().getStickyTransform().getTranslateY());
        //debug.println(" - ul : " +
        // DenimUtils.toShortString(panel.getUpperLeftTransform()));
        //debug.println("clon pan - xform: " +
        // DenimUtils.toShortString(renderedPanel.getTransformRef()));
        //debug.println("clon pan - lty : " +
        // renderedPanel.getLabel().getLabelView().getStickyTransform().getTranslateY());
        //debug.println(" - ul : " +
        // DenimUtils.toShortString(renderedPanel.getUpperLeftTransform()));

        //// 3.1. Make a default view on the sketch,
        //// giving it the same bounds as the sketch.
        View v = getSketch().getClassPropertyView();
        v.setBoundingPoints2DRef(getSketch().getBoundingPoints2D(COORD_LOCAL));

        //// 3.2. Clear out the old views, making sure that the
        //// new view is the only one.
        if (getSketch().getView() instanceof MultiView) {
            MultiView vm = (MultiView) getSketch().getView();
            vm.clear();
            vm.add(v);
        } else {
            getSketch().setView(v);
        }

        //// 4. Make a default view on the sketch,
        //// giving it the same bounds as the sketch.
        LabelViewWrapper lvw = getLabel().getLabelView();
        lvw.setDisplayRange(0, 0, Double.MAX_VALUE, Double.MAX_VALUE);
        lvw.setVisible(true);

        //// 5. Move it to the upper left-hand corner
        if (getPanelBar() == null || !getPanelBar().isVisible()) {
            moveTo(COORD_ABS, 0, 0);
        } else {
            moveTo(COORD_ABS, 0, -getPanelBar().getHeight2D(COORD_ABS));
        }

        //// 6. Make sure the panel bar is set invisible, if the panel has one.
        if (getPanelBar() != null) {
            getPanelBar().setVisible(false);
        }
    }

    /**
     * Returns the transform that the panel would have if it were placed in the
     * upper left-hand corner of its container. (Currently not being used, but
     * I'm not ready to delete it just yet.)
     */
    /*
     * public AffineTransform getUpperLeftTransform() { AffineTransform xform =
     * getTransformRef();
     * 
     * //// Set the transform of the rendered panel to the transform of the ////
     * original panel but with the panel in the upper left-hand corner. //// The
     * X-translate can be set to 0, but the Y-translate can't due //// to the
     * sticky transform of the label. return new AffineTransform
     * (xform.getScaleX(), xform.getShearY(), xform.getShearX(),
     * xform.getScaleY(), 0,
     * -getLabel().getLabelView().getStickyTransform().getTranslateY() *
     * xform.getScaleY()); }
     */

    //---------------------------------------------------------------------------
    /**
     * Makes the background of all text objects within this panel transparent.
     */
    public void setTextBackgroundsTransparent() {
        setTextBackgroundsTransparent(this);
    }

    private void setTextBackgroundsTransparent(GraphicalObjectGroup grp) {
        Iterator it = grp.getForwardIterator();
        while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject) it.next();
            if (gob instanceof ScribbledText) {
                Style gobStyle = gob.getStyle();
                gobStyle.setFillColor(NO_COLOR);
                gob.setStyle(gobStyle);
            } else if (gob instanceof GraphicalObjectGroup) {
                setTextBackgroundsTransparent((GraphicalObjectGroup) gob);
            }
        }
    }

    //-----------------------------------------------------------------

    public void setUniqueID(int newID) {
        super.setUniqueID(newID);
        if (panelBar != null) {
            panelBar.setUniqueID(newID + 1);
        }
    }

    //=== OTHER METHODS =====================================================
    //===========================================================================

    //===========================================================================
    //=== STROKE METHODS ====================================================

    public void handleSingleStroke(SingleStrokeEvent evt) {
        //// ignore
    } // of handleSingleStroke

    //=== STROKE METHODS ====================================================
    //===========================================================================

    //===========================================================================
    //=== ARROW MANAGEMENT METHODS ==========================================

    /**
     * Tells the panel to keep track of the given navigational arrow. The arrow
     * should originate from within the panel.
     */
    public void trackNavArrow(Arrow arrow) {
        //// Ignore if null.
        if (arrow == null) {
            return;
        }
        if (arrow.getDest() == null) {
            //arrow.delete();
            return;
        }

        navArrows.add(arrow);

        try {
            DenimPanel destPanel = arrow.getDest().getPanel();

            if (!destToNavArrows.containsKey(destPanel)) {
                destToNavArrows.put(destPanel, new HashSet());
            }

            ((Set) (destToNavArrows.get(destPanel))).add(arrow);
        } catch (ClassCastException e) {
            //// This happens if there is an inconsistency in the data
        }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Tells the panel to stop keeping track of the given navigational arrow.
     * The arrow should originate from within the panel.
     */
    public void untrackNavArrow(Arrow arrow) {
        //// Ignore if null.
        if (arrow == null) {
            return;
        }
        if (arrow.getDest() == null) {
            arrow.delete();
        }

        navArrows.remove(arrow);

        DenimPanel destPanel = arrow.getDest().getPanel();
        Set destArrows = (Set) (destToNavArrows.get(destPanel));

        if (destArrows != null) {
            destArrows.remove(arrow);
            if (destArrows.isEmpty()) {
                destToNavArrows.remove(destPanel);
            }
        }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns a set of navigation arrows whose destination is in the same panel
     * as the given object is in.
     */
    public Set getNavArrowsWithDestPanel(ArrowDest dest) {
        DenimPanel destPanel = dest.getPanel();

        return (Set) (destToNavArrows.get(destPanel));
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns the organizational arrow whose destination is in the same panel
     * as the given object is in.
     */
    public Arrow getOrgArrowWithDestPanel(ArrowDest dest) {

        Arrow arrow = null;
        DenimPanel destPanel = dest.getPanel();

        if (sketch != null) {
            arrow = sketch.getArrowWithDest(destPanel.getLabel());
            if (arrow == null) {
                arrow = sketch.getArrowWithDest(destPanel.getSketch());
            }
        }
        if ((arrow == null) && label != null) {
            arrow = label.getArrowWithDest(destPanel.getLabel());
            if (arrow == null) {
                arrow = label.getArrowWithDest(destPanel.getSketch());
            }
        }

        return arrow;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns all outgoing navigational arrows from this panel.
     */
    public Set getNavArrows() {
        return navArrows;
    }

    //-----------------------------------------------------------------

    /**
     * Returns all outgoing timer arrows from this panel.
     */
    public Set getTimerArrows() {
        Set result = new HashSet();

        Iterator it = navArrows.iterator();
        while (it.hasNext()) {
            Arrow arrow = (Arrow) it.next();
            if ((DenimIntrinsicComponent.compareEventTypes(
                    DenimIntrinsicComponent.TIMER, arrow.getInputEventType()))) {
                result.add(arrow);
            }
        }

        return result;
    }

    //-----------------------------------------------------------------

    /**
     * True if at least one incoming arrow exists.
     */
    /*
     * public boolean incomingArrowExists() { Iterator iter =
     * incomingArrows.values().iterator(); // if the iterator turns up anything,
     * this method's true return iter.hasNext(); } // of method
     */

    //-----------------------------------------------------------------
    /**
     * Given a source, find the incoming arrow originating from it
     */
    /*
     * public Arrow getIncomingArrowWithSource(GraphicalObject source) { return
     * (Arrow)(incomingArrows.get(source)); } // of method
     */

    //=== ARROW MANAGEMENT METHODS ==========================================
    //===========================================================================
    //===========================================================================
    //=== CONDITIONAL RELATED METHODS =======================================
    /**
     * Returns the number of conditions this panel has.
     */
    public int getNumConditions() {
        return conditionalStates.getCols().size();
    }

    //-----------------------------------------------------------------

    /**
     * Called when the given component instance is inserted into this panel.
     */
    public void componentInstanceIsAdded(DenimComponentInstance inst) {

        conditionalStates.addRow(inst);
        Iterator colIt = conditionalStates.getCols().iterator();
        //debug.println("inst displayed state: " +
        // DenimUtils.toShortString(inst.getDisplayedState()));
        while (colIt.hasNext()) {
            Object colHeader = colIt.next();
            conditionalStates.put(inst, colHeader, inst.getDisplayedState());
        }

        // Repeat for any embedded component instances
        Iterator it = inst.getForwardIterator();
        while (it.hasNext()) {
            Object obj = it.next();
            if (obj instanceof DenimComponentInstance) {
                componentInstanceIsAdded((DenimComponentInstance) obj);
            }
        }
        //debug.println("conditional states: " +
        // DenimUtils.toShortString(conditionalStates));
    }

    //-----------------------------------------------------------------

    /**
     * Called when the given component instance is removed from this panel.
     */
    public void componentInstanceIsRemoved(DenimComponentInstance inst) {
        conditionalStates.removeRow(inst);

        // Repeat for any embedded component instances
        Iterator it = inst.getForwardIterator();
        while (it.hasNext()) {
            Object obj = it.next();
            if (obj instanceof DenimComponentInstance) {
                componentInstanceIsRemoved((DenimComponentInstance) obj);
            }
        }
        //debug.println("conditional states: " +
        // DenimUtils.toShortString(conditionalStates));
    }

    //-----------------------------------------------------------------

    /**
     * Called when the given component instance in this panel has been cloned.
     */
    public void componentInstanceIsCloned(DenimComponentInstance clone) {
        DenimComponentInstance orig = clone.getCloneSource();
        //debug.println(DenimUtils.toShortString(orig) + "->" +
        //              DenimUtils.toShortString(clone));
        if (orig != null) {

            // Update list of radio buttons
            if (clone instanceof DenimRadioButtonInstance) {
                DenimRadioButtonInstanceContainer parent = (DenimRadioButtonInstanceContainer) clone
                        .getParentGroup();
                parent.removeRadioButton((DenimRadioButtonInstance) orig);
                parent.addRadioButton((DenimRadioButtonInstance) clone);
            }

            conditionalStates.renameRow(orig, clone);

            // Repeat for any embedded component instances
            Iterator it = clone.getForwardIterator();
            while (it.hasNext()) {
                Object obj = it.next();
                if (obj instanceof DenimComponentInstance) {
                    componentInstanceIsCloned((DenimComponentInstance) obj);
                }
            }
        }
    }

    //-----------------------------------------------------------------

    /**
     * Returns the current design-time condition of the panel.
     */
    public int getCurrentDesignTimeCondition() {
        return currentDesignCondition;
    }

    //-----------------------------------------------------------------

    /**
     * Adds a new condition with the given condition number. All conditions
     * above this one are increased by one. The new condition is initialized
     * with the same component instance states as the given condition.
     */
    /*
     * public void addConditionAt(int condition) { //// 1. Rename the conditions
     * with indexes above this one. for (int i = getNumConditions(); i >=
     * condition; i--) { conditionalStates.renameCol(new Integer(i), new
     * Integer(i + 1)); }
     * 
     * //// 2. Insert the new condition. conditionalStates.addCol(new
     * Integer(condition));
     * 
     * //// 3. Initialize the states of the new condition to the condition ////
     * which used to have the given index. conditionalStates.copyCol(new
     * Integer(condition + 1), new Integer(condition));
     * 
     * //debug.println("conditional states: " +
     * DenimUtils.toShortString(conditionalStates));
     * 
     * //// 4. Make the panel bar visible. getPanelBar().setVisible(true);
     * 
     * //// 5. Update the number of conditions shown in the panel bar. if
     * (getPanelBar() != null) { getPanelBar().refresh(); }
     * 
     * //// 6. Make the panel look like a stack. initStackEffect();
     * 
     * //// 7. Refresh the panel to update the panel bar. damage(DAMAGE_NOW); }
     */
    //-----------------------------------------------------------------
    public Object getConditionHead(int i) {
        
        Iterator it = conditionalStates.getCols().iterator();
        while (it.hasNext()) {
            Integer head = (Integer) it.next();
            if (head.intValue() == i) {
                return head;
            }
        }
        return null;
    }

    //-----------------------------------------------------------------

    public void removeCondition(int condition) {

        disableDamage();
        
        LinkedList toDelete = new LinkedList();
        Iterator it = this.getNavArrows().iterator();
        while(it.hasNext())
        {
            Arrow a = (Arrow)it.next();
            if(a.getCondition()==condition)
                toDelete.add(a);
            else if(a.getCondition()>condition)
            {
                a.setCondition(a.getCondition()-1);
            }
        }
        
        it = toDelete.iterator();
        while(it.hasNext())
        {
            Arrow a = (Arrow)it.next();
            a.delete();
        }
        
        conditionalStates.removeCol(getConditionHead(condition));

        //// 1. Rename the conditions with indexes above this one.
        for (int i = condition+1; i <= getNumConditions()+1; i++) {
            conditionalStates
                    .renameCol(getConditionHead(i), new Integer(i - 1));
        }

        //// 4. Make the panel bar visible.
        if (this.getNumConditions() == 1) {
            getPanelBar().setVisible(false);
            currentDesignCondition = 1;
            backSketch.delete();
            backSketch = null;
        } else {
            
            if (condition > this.getNumConditions()) {
                currentDesignCondition = 1;    
            }      
            
            //// 5. Update the number of conditions shown in the panel bar.
            if (getPanelBar() != null) {
                getPanelBar().refresh();
            }
        }


        //// 3. Load the states for the component instances for this
        //// condition.
        Set componentInstances = conditionalStates.getRows();
        it = componentInstances.iterator();
        while (it.hasNext()) {
            DenimComponentInstance inst = (DenimComponentInstance) it.next();
            inst.setDisplayedState((GraphicalObject) (conditionalStates.get(
                    inst, getConditionHead(currentDesignCondition))));
        }

        enableDamage();
        
        this.getSheet().damage(DAMAGE_NOW);
        
    }

    //-----------------------------------------------------------------

    public void addConditionAt(int condition) {
        //// 1. Rename the conditions with indexes above this one.
        for (int i = getNumConditions(); i >= condition; i--) {

            conditionalStates
                    .renameCol(getConditionHead(i), new Integer(i + 1));
        }

        //// 2. Insert the new condition.
        conditionalStates.addCol(new Integer(condition));

        //// 3. Initialize the states of the new condition to the condition
        //// which used to have the given index.
        conditionalStates.copyCol(getConditionHead(condition + 1),
                getConditionHead(condition));

        //debug.println("conditional states: " +
        // DenimUtils.toShortString(conditionalStates));

        //// 4. Make the panel bar visible.
        getPanelBar().setVisible(true);

        //// 5. Update the number of conditions shown in the panel bar.
        if (getPanelBar() != null) {
            getPanelBar().refresh();
        }

        //// 6. Make the panel look like a stack.
        initStackEffect();

        //// 7. Refresh the panel to update the panel bar.
        damage(DAMAGE_NOW);

        this.getSheet().repaint();
    }

    //-----------------------------------------------------------------

    /**
     * Associates the current state of the panel's component instances with the
     * panel's current condition.
     */
    public void saveComponentInstanceStates() {
        //debug.println("old condition: " + currentDesignCondition);
        Set componentInstances = conditionalStates.getRows();
        Iterator it = componentInstances.iterator();
        while (it.hasNext()) {
            DenimComponentInstance inst = (DenimComponentInstance) it.next();
            /*
             * if (conditionalStates.get(inst,
             * conditionalStates.getColHeader(currentDesignCondition)) != null) {
             */conditionalStates.put(inst,
                    getConditionHead(currentDesignCondition), inst
                            .getDisplayedState());
            //     }
            //debug.println(" " + DenimUtils.toShortString(inst) +
            //              "->" + DenimUtils.toShortString(inst.getDisplayedState()));
        }

    }

    //-----------------------------------------------------------------

    /**
     * Changes the panel to show the given condition.
     */
    synchronized public void setCurrentDesignTimeCondition(int condition) {

        Set componentInstances = conditionalStates.getRows();
        Iterator it;

        disableDamage();

        //// 1. Save the displayed state of all of the component instances
        //// for this condition.
        saveComponentInstanceStates();

        //// 2. Change the current condition.
        currentDesignCondition = condition;

        //// 3. Load the states for the component instances for this
        //// condition.
        //debug.println("new condition: " + currentDesignCondition);
        it = componentInstances.iterator();
        while (it.hasNext()) {
            DenimComponentInstance inst = (DenimComponentInstance) it.next();
            //debug.println(" " + DenimUtils.toShortString(inst) +
            //              "->" +
            // DenimUtils.toShortString((GraphicalObject)conditionalStates.get(inst,
            // new Integer(currentDesignCondition))));
            inst.setDisplayedState((GraphicalObject) (conditionalStates.get(
                    inst, getConditionHead(currentDesignCondition))));
        }

        //// 4. Update the current condition shown in the panel bar.
        if (getPanelBar() != null) {
            getPanelBar().refresh();
        }

        //// 5. Change the z-ordering such that arrows not part of this
        //// condition are shown underneath this panel.

        // The root object of DenimSheet deals with the layer
        //this.bringToTopLayer();
        /*
         * it = getNavArrows().iterator(); while (it.hasNext()) { Arrow a =
         * (Arrow) it.next();
         *//*
            * if (a.getCondition() == currentDesignCondition) {
            * a.bringToTopLayer(); }
            */
        /*
         * if (a.getCondition() == currentDesignCondition) {
         * //a.bringToTopLayer(); a.setInCurrentCondition(true); } else {
         * a.setInCurrentCondition(false); }
         */
        //    }
        /*
         * it = getLabel().getIncomingArrows().iterator(); while (it.hasNext()) {
         * Arrow a = (Arrow)it.next(); //a.bringToTopLayer(); // hack
         * a.setInCurrentCondition(true); }
         * 
         * it = getSketch().getIncomingArrows().iterator(); while (it.hasNext()) {
         * Arrow a = (Arrow)it.next(); //a.bringToTopLayer(); // hack
         * a.setInCurrentCondition(true); }
         */
        enableDamage();
        this.getSheet().damage(DAMAGE_NOW);
    }

    //-----------------------------------------------------------------

    /**
     * Returns the current run-time condition of the panel.
     */
    public int getCurrentRunTimeCondition() {

        // If there is only one condition in the conditional states table,
        // then just return it.
        if (conditionalStates.getCols().size() == 1) {
            return 1;
        }

        // Construct a map of component instances -> current states
        Map currentStates = new HashMap();
        Set componentInstances = conditionalStates.getRows();
        Iterator instIt = componentInstances.iterator();

        while (instIt.hasNext()) {
            DenimComponentInstance inst = (DenimComponentInstance) instIt
                    .next();
            currentStates.put(inst, inst.getDisplayedState());
        }

        // Now, check against grid of component states vs. condition numbers
        Object conditionObj = conditionalStates.matchCol(currentStates);
        if (conditionObj != null) {
            return ((Integer) conditionObj).intValue();
        }
        assert false; // "Run time condition does not match"
        return 0;
    }

    //=== CONDITIONAL RELATED METHODS =======================================
    //===========================================================================

    //==========================================================================
    //=== PIE MENU METHODS =================================================

    public PieMenu getContextMenu() {
        PieMenu pieProject = new PieMenu("Page");
        JMenuItem item;

        item = pieProject.add("Add New Condition");
        item.addActionListener(new AddNewConditionListener());
        item.setEnabled(true);

        item = pieProject.add("Set as Home Page");
        item.addActionListener(new SetHomePageListener());
        item.setEnabled(true);

        return pieProject;
    }

    //-----------------------------------------------------------------

    public class AddNewConditionListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            DenimPanel.this.addConditionAt(DenimPanel.this
                    .getCurrentDesignTimeCondition());
        }
    }
    
    public class SetHomePageListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            SetHomeCommand cmd = new SetHomeCommand(
                    (DenimSheet)DenimPanel.this.getSheet(),
                        DenimPanel.this);
            cmdqueue.doCommand(cmd);
        }
    }

    //=== PIE MENU METHODS =================================================
    //==========================================================================

    //===========================================================================
    //=== TOSTRING METHODS ==================================================

    /**
     * Returns a string presentation of this panel.
     */
    public String toDebugString() {
        String s = super.toDebugString();
        if (label == null) {
            s += "\nLabel is null";
        } else {
            s += "\nLabel ID: " + label.getUniqueID();
        }

        if (sketch == null) {
            s += "\nSketch is null";
        } else {
            s += "\nSketch ID: " + sketch.getUniqueID();
        }
        return s;
    } // of method

    /**
     * Returns a briefer string presentation of this panel.
     */
    public String toMediumString() {
        String s = DenimUtils.toShortString(this);
        if (label == null) {
            s += "\n  Label is null";
        } else {
            s += "\n  Label ID: " + label.getUniqueID();
        }

        if (sketch == null) {
            s += "\n  Sketch is null";
        } else {
            s += "\n  Sketch ID: " + sketch.getUniqueID();
            Iterator i = sketch.getForwardIterator();
            while (i.hasNext()) {
                GraphicalObject gob = (GraphicalObject) i.next();
                s += "\n    " + DenimUtils.toShortString(gob);
                if (gob instanceof DenimComponentInstance) {
                    s += "\n      "
                            + ((DenimComponentInstance) gob)
                                    .eventToActionString();
                }
            }
        }
        return s;
    } // of method

    //=== TOSTRING METHODS ==================================================
    //===========================================================================

    //===========================================================================
    //=== CLONE METHODS =====================================================

    /**
     * Returns a deep clone of this panel.
     */
    public Object deepClone() {
        return deepClone(new DenimPanel());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Makes the given panel a deep clone of this panel, and returns the deep
     * clone.
     */
    protected Object deepClone(DenimPanel clone) {
        // debug.println("deepClone() - this before: " + this);

        /*
         * for custom component use
         */
        if(transferStateID)
            clone.stateID = this.stateID;
        
        //// Associate the states of the original panel's component instances
        //// with its current condition.
        saveComponentInstanceStates();

        //// Clone the association between states of the component instances
        //// and conditions.
        clone.conditionalStates = new ComponentConditionMap2D(conditionalStates);

        super.deepClone(clone);

        // debug.println("deepClone() - this after: " + this);
        //debug.println("deepClone() - clone before adjustment: " + clone);

        /*
         * Iterator iter;
         * 
         * iter = this.getForwardIterator(); debug.println("Cloning:"); while
         * (iter.hasNext()) { GraphicalObject next =
         * (GraphicalObject)(iter.next()); debug.println(" " + next.getClass() + ": " +
         * next.getUniqueID()); } debug.println("End cloning:");
         */

        clone.label = null;
        clone.sketch = null;
        clone.panelBar = null;
        clone.backSketch = null;

        if (indexOf(label) >= 0) {
            clone.label = (DenimLabel) clone.get(indexOf(label));
        }

        if (indexOf(sketch) >= 0) {
            clone.sketch = (DenimSketch) clone.get(indexOf(sketch));
        }

        if (indexOf(panelBar) >= 0) {
            clone.panelBar = (PanelBar) clone.get(indexOf(panelBar));
            clone.panelBar.setVisible(panelBar.isVisible());
        }

        if (indexOf(backSketch) >= 0) {
            clone.backSketch = (DenimSketch) clone.get(indexOf(backSketch));
        }

        if (clone.getLabel() != null) {
            clone.addWatcher(clone.getLabel());
            clone.getLabel().setSketch(clone.getSketch());
        }

        if (clone.getSketch() != null) {
            clone.addWatcher(clone.getSketch());
        }

        Style style = clone.getStyle();
        style.setDrawColor(NO_COLOR);
        style.setFillColor(NO_COLOR);
        clone.setStyle(style);

        fixComponentInstances(clone, clone.getSketch());

        return clone;
    }

    private void fixComponentInstances(DenimPanel clone,
            GraphicalObjectGroup group) {

        //// Each panel has a list of conditions, with the condition number
        //// mapped to a set of component instance states. But the cloned
        //// panel's list still refers to the states of the original
        //// component instances, not the states of the cloned component
        //// instances. So modify the list so that it points to the clones.
        Iterator it;

        it = group.getForwardIterator();
        while (it.hasNext()) {
            Object obj = it.next();
            //debug.println("checking: " +
            //              DenimUtils.toShortString((GraphicalObject)obj));
            if (obj instanceof DenimGroup) {
                fixComponentInstances(clone, (DenimGroup) obj);
            } else if (obj instanceof DenimComponentInstance) {
                clone.componentInstanceIsCloned((DenimComponentInstance) obj);
            }
        }
    } // of method

    //=== CLONE METHODS =====================================================
    //===========================================================================

    //----------------------------------------

    /**
     * clear all references hold by this object (In the namespace of this class)
     */

    public void deepClear() {
        super.deepClear();

        label = null;
        sketch = null;
        panelBar = null;
        backSketch = null; // the "back" of a conditional stack
        container = null;

        if (destToNavArrows != null) {
            destToNavArrows.clear();
            destToNavArrows = null;
        }

        if (navArrows != null) {
            navArrows.clear();
            navArrows = null;
        }

        normalLabelStyle = null; // saves the normal style so that
        // it can be restored if the panel
        // stops being the home panel.
        normalSketchStyle = null;
        poly = null;

        conditionalStates = null;
        highlighter = null;

        if (arrowOrgInFrame != null) {
            arrowOrgInFrame.clear();
            arrowOrgInFrame = null;
        }

        if (arrowOrgOutFrame != null) {
            arrowOrgOutFrame.clear();
            arrowOrgOutFrame = null;
        }

        if (arrowNavInFrame != null) {
            arrowNavInFrame.clear();
            arrowNavInFrame = null;
        }

        if (arrowNavOutFrame != null) {
            arrowNavOutFrame.clear();
            arrowNavOutFrame = null;
        }

        if (recoverList != null) {
            recoverList.clear();
            recoverList = null;
        }

        labelFrame = null;
        sketchFrame = null;
        labelImage = null;
        sketchImage = null;
    }

    /**
     * for DOM access
     * 
     * @return
     */
    public ComponentConditionMap2D getConditionStates() {
        /**
         * to sync the data
         */
        saveComponentInstanceStates();

        return conditionalStates;
    }

    public void setInstanceState(long rowID, long stateid) {

        Iterator it = conditionalStates.getRows().iterator();
        DenimComponentInstance instance = null;
        while (it.hasNext()) {
            DenimComponentInstance obj = (DenimComponentInstance) it.next();
            if (obj.getUniqueID() == rowID) {
                instance = obj;
            }
        }

        if (instance == null)
            return;

        DenimComponent template = DenimComponentRegistry.getInstance()
                .getComponent(instance.getComponentType().getName());

        GraphicalObject stateObj = null;

        //Set templatestates= template.getStates();
        GraphicalObjectCollection templatestates = instance.getStates();
        it = templatestates.getForwardIterator();//.iterator();
        while (it.hasNext()) {
            GraphicalObject astate = (GraphicalObject) it.next();
            if (astate.getUniqueID() == stateid) {
                stateObj = astate;
                break;
            }
        }

        if (stateObj != null) {
            instance.setDisplayedState(stateObj);
        }

    }

    public void syncCondition(int col) {
        currentDesignCondition = col;
        saveComponentInstanceStates();
    }

    /**
     * get graphical object by ID
     */

    private static GraphicalObject getGrapicalObject(
            GraphicalObjectGroup group, int id) {
        if (group.getUniqueID() == id) {
            return group;
        }
        Iterator it = group.getForwardIterator();
        while (it.hasNext()) {
            GraphicalObject obj = (GraphicalObject) it.next();
            if (obj instanceof GraphicalObjectGroup) {
                GraphicalObject result = getGrapicalObject(
                        (GraphicalObjectGroup) obj, id);
                if (result != null)
                    return result;
            } else {
                if (obj.getUniqueID() == id)
                    return obj;
            }
        }
        return null;
    }

} // of class

//==============================================================================

/*
 * Copyright (c) 1999-2001 Regents of the University of California. All rights
 * reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. All advertising materials mentioning features or use of this software must
 * display the following acknowledgement:
 * 
 * This product includes software developed by the Group for User Interface
 * Research at the University of California at Berkeley.
 * 
 * 4. The name of the University may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
