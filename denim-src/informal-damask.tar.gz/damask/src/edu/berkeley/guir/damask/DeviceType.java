package edu.berkeley.guir.damask;

import java.util.*;

/** 
 * An instance of this class describes a type of device, along with
 * characteristics of the device.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-18-2003 James Lin
 *                               Created DeviceType
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 03-18-2003
 */
public class DeviceType {
   public static final int CENTER_INSET = -1;
   
   private final String name;
   private final int width;
   private final int height;
   private final int preferredContentHeight;
   private final int gridWidth;
   private final int gridHeight;
   private final int groupDefaultWidth;
   private final int groupDefaultHeight;
   private final int defaultFontSize;
   private final Map/*<Direction, int>*/ insets = new HashMap();
   private final Map/*<Direction, Orientation>*/ orientations = new HashMap();
   private final boolean visual;
   private final boolean audio;
   private final Set regionNames = new HashSet();
   
   // Pre-defined devices
   public static final DeviceType ALL =
      new DeviceType(
         "All",
         0, 0,
         0, 0,
         0, 0,
         null,
         0, null,
         0, null,
         0, null,
         0, null,
         Integer.MAX_VALUE,
         Integer.MAX_VALUE,
         true,
         true);
      
   public static final DeviceType DESKTOP =
      new DeviceType(
         "Desktop",
         800, 600,
         120, 40,
         80, 80,
         Orientation.VERTICAL,
         120, Orientation.HORIZONTAL,
          60, Orientation.HORIZONTAL,
         120, Orientation.VERTICAL,
         120, Orientation.VERTICAL,
         Integer.MAX_VALUE,
         12,
         true,
         true);
      
   // Nokia Series 60: 176x208
   // Microsoft Smartphone: 175x220
   public static final DeviceType SMARTPHONE =
      new DeviceType(
         "Smartphone",
         180, 215,
         180, 20,
         180, 20,
         Orientation.VERTICAL,
         50, Orientation.VERTICAL,
         50, Orientation.VERTICAL,
          0, Orientation.VERTICAL,
          0, Orientation.VERTICAL, 
         19,
         12,
         true,
         true);
      
   public static final DeviceType VOICE =
      new DeviceType(
         "Voice",
         500, 600,
         0, 0,
         0, 0,
         Orientation.VERTICAL,
         0, Orientation.VERTICAL,
         0, Orientation.VERTICAL,
         0, Orientation.VERTICAL,
         0, Orientation.VERTICAL,
         Integer.MAX_VALUE,
         12,
         false,
         true);
   
   //---------------------------------------------------------------------------

   private DeviceType(
      final String name,
      final int width,
      final int height,
      final int gridWidth,
      final int gridHeight,
      final int groupDefaultWidth,
      final int groupDefaultHeight,
      final Orientation centerOrientation,
      final int northInset,
      final Orientation northOrientation,
      final int southInset,
      final Orientation southOrientation,
      final int eastInset,
      final Orientation eastOrientation,
      final int westInset,
      final Orientation westOrientation,
      final int preferredContentHeight,
      final int defaultFontSize,
      final boolean isVisual,
      final boolean isAudio) {

      this.name = name;
      this.width = width;
      this.height = height;
      this.gridWidth = gridWidth;
      this.gridHeight = gridHeight;
      this.groupDefaultWidth = groupDefaultWidth;
      this.groupDefaultHeight = groupDefaultHeight;
      
      insets.put(Direction.NORTH, new Integer(northInset));
      insets.put(Direction.SOUTH, new Integer(southInset));
      insets.put(Direction.EAST, new Integer(eastInset));
      insets.put(Direction.WEST, new Integer(westInset));
      insets.put(Direction.CENTER, new Integer(CENTER_INSET));
      
      orientations.put(Direction.NORTH, northOrientation);
      orientations.put(Direction.SOUTH, southOrientation);
      orientations.put(Direction.EAST, eastOrientation);
      orientations.put(Direction.WEST, westOrientation);
      orientations.put(Direction.CENTER, centerOrientation);

      this.preferredContentHeight = preferredContentHeight;   
      this.defaultFontSize = defaultFontSize;
      this.visual = isVisual;
      this.audio = isAudio;
      
      regionNames.add(Direction.CENTER);
      regionNames.add(Direction.NORTH);
      regionNames.add(Direction.SOUTH);
      regionNames.add(Direction.WEST);
      regionNames.add(Direction.EAST);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Returns the name of the device type.
    */
   public String getName() {
      return name;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the device type's screen width.
    */
   public int getDefaultWidth() {
      return width;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the device type's screen height.
    */
   public int getDefaultHeight() {
      return height;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the device type's grid width.
    */
   public int getGridWidth() {
      return gridWidth;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the device type's grid height.
    */
   public int getGridHeight() {
      return gridHeight;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the default width of a new component group for this device type.
    */
   public int getGroupDefaultWidth() {
      return groupDefaultWidth;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the default height of a new component group for this device type.
    */
   public int getGroupDefaultHeight() {
      return groupDefaultHeight;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns whether the device type has a visual display.
    */
   public boolean isVisual() {
      return visual;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns whether the device type has a visual display.
    */
   public boolean isAudio() {
      return audio;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the preferred height of a piece of content on this device type's
    * screen.
    */
   public int getPreferredContentHeight() {
      return preferredContentHeight;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the default font size of a piece of text on this device type's
    * screen.
    */
   public int getDefaultFontSize() {
      return defaultFontSize;
   }
   
   //---------------------------------------------------------------------------

   /**
    * Throws an IllegalArgumentException if this device type is
    * DeviceType.ALL.
    */   
   public void verifyTypeIsNotAll() {
      DamaskUtils.checkValidArgument(
         this != DeviceType.ALL,
         "deviceType cannot be DeviceType.ALL");
   }
   
   //---------------------------------------------------------------------------

   /**
    * Throws an IllegalArgumentException if this device type is not equal to
    * device type passed in.
    */   
   public void verifyIsEqual(DeviceType deviceType) {
      DamaskUtils.checkValidArgument(
         this == deviceType,
         "The given device type " + deviceType + " does not match " + this);
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns the width between the interior border of the page region
    * with the given direction, and the border of the page, or -1 for
    * Direction.CENTER.
    */
   public int getDefaultInset(final Direction direction) {
      return ((Integer)insets.get(direction)).intValue();
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the orientation of the region with the specified name.
    */
   public Orientation getOrientation(final Direction direction) {
      return (Orientation)orientations.get(direction);
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns the names of the regions in the page.
    */
   public Set getRegionNames() {
      return regionNames;
   }
   
   //---------------------------------------------------------------------------
   
   public String toString() {
      return name; 
   }
   
   //===========================================================================
   
   /**
    * If this device is DeviceType.ALL, then returns a collection of all of the
    * supported types of devices; otherwise, returns a colletion of one item:
    * itself. 
    */
   public Collection getSpecificDeviceTypes() {
      if (this == DeviceType.ALL) {
         return Damask.getSupportedDeviceTypes();
      }
      else {
         final Collection devices = new ArrayList();
         devices.add(this);
         return devices;
      }
   }
}
