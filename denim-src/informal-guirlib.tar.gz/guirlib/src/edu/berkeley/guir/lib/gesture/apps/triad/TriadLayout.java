package edu.berkeley.guir.lib.gesture.apps.triad;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.Vector;

public class TriadLayout implements LayoutManager2 {
  // Using a Vector is overkill in that it'll never have more than 3
  // elements, but I don't want to mess with deleting from the middle.
  // And it'll generalize better if I ever write a CircularLayout.
  static final double sqrt2 = Math.sqrt(2);
  Vector components = new Vector(3); // of Component
  int spacing;
  
  public TriadLayout()
  {
    this(5);
  }

  /** Spacing must be >= 0. */
  public TriadLayout(int spacing)
  {
    if (spacing < 0) {
      throw new
	IllegalArgumentException(this +
				 ":inter-child spacing must be >= 0.");
    }
    this.spacing = spacing;
  }

  public void addLayoutComponent(String name,
				 Component comp)
  {
    addLayoutComponent(comp, null);
  }

  public void addLayoutComponent(Component comp,
				 Object constraints)
  {
    if ((constraints != null) && (constraints instanceof Integer)) {
      int index = ((Integer)constraints).intValue();
      if ((index < 0) || (index > 2)) {
	throw new
	  IllegalArgumentException(this + " can only have 3 children");
      }
      components.setElementAt(comp, index);
    }
    else {
      // add to end, if space available
      if (components.size() >= 3) {
	throw new
	  IllegalArgumentException(this + " can only have 3 children");
      }
      components.addElement(comp);
    }
  }
  
  public void removeLayoutComponent(Component comp)
  {
    components.removeElement(comp);
  }

  /** Compute the minimum radius needed to fit the components */
  private int computeRadius()
  {
    Component c1 = null, c2 = null, c3 = null;
    Dimension dim1 = null, dim2 = null, dim3 = null;
    int w1 = 0, w2 = 0, w3 = 0, h1 = 0, h2 = 0, h3 = 0;
    int size = components.size();
    int radius;
    switch (size) {
    case 3:
      c3 = (Component) components.elementAt(2);
      dim3 = c3.getPreferredSize();
      w3 = dim3.width;
      h3 = dim3.height;
    case 2:
      c2 = (Component) components.elementAt(1);
      dim2 = c2.getPreferredSize();
      w2 = dim2.width;
      h2 = dim2.height;
    case 1:
      c1 = (Component) components.elementAt(0);
      dim1 = c1.getPreferredSize();
      w1 = dim1.width;
      h1 = dim1.height;
      break;
    case 0:
      return 0;
    default:
      throw new RuntimeException(this + " has too many children!");
    }

    radius = (int) Math.round((w1 + w2 + 2*spacing)/sqrt2);

    int r;

    r = (int) Math.round(Math.min((w1 + w3 + 2*spacing)/sqrt2,
				  (h1 + h3 + 2*spacing)/3.0));
    if (r > radius)
      radius = r;
    
    r = (int) Math.round(Math.min((w2 + w3 + 2*spacing)/sqrt2,
				  (h2 + h3 + 2*spacing)/3.0));
    if (r > radius)
      radius = r;

    return radius;
  }
  
  public Dimension preferredLayoutSize(Container parent)
  {
    int radius = computeRadius();

    Insets insets = parent.getInsets();
    int width = insets.left + insets.right;
    int height = insets.top + insets.bottom;

    Component c1 = null, c2 = null, c3 = null;
    Dimension dim1 = null, dim2 = null, dim3 = null;
    int w1 = 0, w2 = 0, w3 = 0, h1 = 0, h2 = 0, h3 = 0;
    int size = components.size();
    switch (size) {
    case 3:
      c3 = (Component) components.elementAt(2);
      dim3 = c3.getPreferredSize();
      w3 = dim3.width;
      h3 = dim3.height;
    case 2:
      c2 = (Component) components.elementAt(1);
      dim2 = c2.getPreferredSize();
      w2 = dim2.width;
      h2 = dim2.height;
    case 1:
      c1 = (Component) components.elementAt(0);
      dim1 = c1.getPreferredSize();
      w1 = dim1.width;
      h1 = dim1.height;
      break;
    case 0:
      return new Dimension(width, height);
    default:
      throw new RuntimeException(this + " has too many elements!");
    }

    width += Math.max(w3, Math.round(radius*sqrt2) + Math.max(w1, w2));
    height += 2*Math.max(Math.max(h1, h2) + Math.round(radius/2),
			 radius + h3/2);

    return new Dimension(width, height);
  }

  public Dimension minimumLayoutSize(Container parent)
  {
    return preferredLayoutSize(parent);
  }

  public void layoutContainer(Container parent)
  {
    // setLocation(int, int), setSize(Dimension or int, int),
    // setBounds(x, y, w, h)

    Insets insets = parent.getInsets();
    Dimension parentSize = parent.getSize();
    int radius = computeRadius();
    int centerX = parentSize.width / 2 + insets.left;
    int centerY = parentSize.height / 2 + insets.top;

    Component c1 = null, c2 = null, c3 = null;
    Dimension dim1 = null, dim2 = null, dim3 = null;
    int size = components.size();
    switch (size) {
    case 3:
      c3 = (Component) components.elementAt(2);
      dim3 = c3.getPreferredSize();
      c3.setSize(dim3);
      setCenter(c3, centerX, centerY + radius);
    case 2:
      c2 = (Component) components.elementAt(1);
      dim2 = c2.getPreferredSize();
      c2.setSize(dim2);
      setCenter(c2, centerX + (int) Math.round(radius/sqrt2),
		centerY - radius/2);
    case 1:
      c1 = (Component) components.elementAt(0);
      dim1 = c1.getPreferredSize();
      c1.setSize(dim1);
      setCenter(c1, centerX - (int) Math.round(radius/sqrt2),
		centerY - radius/2);
      break;
    case 0:
      return;
    default:
      throw new RuntimeException(this + " has too many elements!");
    }
  }

  /** Moves the Component so its center lies at (x,y). */
  static void setCenter(Component c, int x, int y)
  {
    Dimension size = c.getSize();

    c.setLocation(x - size.width / 2, y - size.height / 2);
  }
  
  public Dimension maximumLayoutSize(Container target)
  {
    return preferredLayoutSize(target);
  }

  public float getLayoutAlignmentX(Container target)
  {
    return (float) 0.5;
  }

  public float getLayoutAlignmentY(Container target)
  {
    return (float) 0.5;
  }

  public void invalidateLayout(Container target)
  {
  }

  public static void main(String[] args)
  {
    JFrame f = new JFrame("TriadLayout test");
    JPanel contents = new JPanel();
    contents.setLayout(new TriadLayout());

    contents.add(new JButton("1 fooalksjdflakjssf"));
    contents.add(new JButton("2 barsldkfjslkdfjsl"));
    contents.add(new JButton("3 ishslkdfjsldkjsl1"));
    /*
      Border border = BorderFactory.createEtchedBorder();
      JPanel c;
      c = new JPanel();
      c.setBorder(border);
      c.setPreferredSize(new Dimension(40, 40));
      contents.add(c);
      
      c = new JPanel();
      c.setBorder(border);
      c.setPreferredSize(new Dimension(40, 40));
      contents.add(c);
      
      c = new JPanel();
      c.setBorder(border);
      c.setPreferredSize(new Dimension(40, 40));
      contents.add(c);
      */
    
    contents.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    };
    f.addWindowListener(l);

    f.getContentPane().add(contents);

    f.pack();
    f.show();
  }
}
