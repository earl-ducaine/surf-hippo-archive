package edu.berkeley.guir.denim;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import edu.berkeley.guir.denim.components.DenimComponentInstance;
import edu.berkeley.guir.denim.components.DenimCustomComponentInstance;
import edu.berkeley.guir.denim.components.DenimHyperlinkInstance;
import edu.berkeley.guir.denim.components.DenimIntrinsicComponent;
import edu.berkeley.guir.denim.event.DenimEvent;
import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.Sheet;
import edu.berkeley.guir.lib.satin.objects.GraphicalObject;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollection;
import edu.berkeley.guir.lib.satin.objects.Style;


public class DenimScenarioEditorSheet extends Sheet {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final float dash1[] = { 0.05f };
   static final BasicStroke dashed =
      new BasicStroke(
         0.001f,
         BasicStroke.CAP_BUTT,
         BasicStroke.JOIN_MITER,
         10.0f,
         dash1,
         0.0f);

   //===   CONSTANTS   =========================================================
   //===========================================================================

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private DenimScenarioEditor win; // the run window that the sheet is in
   private DenimPanel renderedPanel;
   private AffineTransform lastTransform = new AffineTransform();

   private Set timers = new HashSet();

   private double panelDisplayWidth;
   private double panelDisplayHeight;

   private DenimComponentInstance oldInst = null; // to check if the mouse 
   // was moved from one to
   // another objecr

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================


   /**
    * Construct a DenimScenarioEditorSheet containing the given panel.
    */
   public DenimScenarioEditorSheet(DenimScenarioEditor win, DenimPanel startingPanel) {
      super();

      this.win = win;
      
      //// 1. 
      setLayout(null);
      setBackground(new Color(255, 255, 255));
      setEnabled(false);
      addMouseListener(new DenimScenarioEditorMouseAdapter());

      //// 2. Get the width of the panel.
      renderPanel(startingPanel);

      DenimPanel displayedPanel = (DenimPanel) this.get(0);
      panelDisplayWidth =
         displayedPanel.getSketch().getWidth2D(SatinConstants.COORD_ABS);
      panelDisplayHeight =
         displayedPanel.getSketch().getHeight2D(SatinConstants.COORD_ABS)
            + displayedPanel.getLabel().getHeight2D(SatinConstants.COORD_ABS);

   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   //===========================================================================
   //===   INNER CLASSES   =====================================================

   class TimerAction implements ActionListener {

      private javax.swing.Timer timer;
      private Arrow arrow;
      private DenimScenarioEditorSheet runSheet;
      private DenimPanel renderedPanel;

      public TimerAction(
         javax.swing.Timer timer,
         DenimScenarioEditorSheet runSheet,
         Arrow arrow,
         DenimPanel renderedPanel) {
         super();
         this.timer = timer;
         this.runSheet = runSheet;
         this.arrow = arrow;
         this.renderedPanel = renderedPanel;
      }
      public void actionPerformed(ActionEvent aEvt) {
         timer.stop();

         // Handle back and forward buttons
         runSheet.getScenarioEditor().pushCurrentPanel();
         runSheet.getScenarioEditor().clearNextPanels();
         //empty the next stack if click on link

         // Fire the event
         DenimComponentInstance inst =
            (DenimComponentInstance) arrow.getSource();
         inst.handleEvent(
            new DenimEvent(inst, arrow.getInputEventType()),
            renderedPanel.getCurrentRunTimeCondition());

      }
   }

   //===   INNER CLASSES   =====================================================
   //===========================================================================

   //===========================================================================
   //===   RUN SHEET METHODS   =================================================

   /*
    * Returns the most nested component instance at the given point in
    * absolute coordinates.
    */
   private DenimComponentInstance findDeepestComponentInstance(Point p) {
      GraphicalObjectCollection gobcol;
      gobcol =
         getGraphicalObjects(COORD_ABS, p, FIRST, DEEP, CONTAINS, 0.0, null);
      GraphicalObject deepObject = gobcol.getFirst();

      while (deepObject != null
         && !(deepObject instanceof DenimComponentInstance)) {
         deepObject = deepObject.getParentGroup();
      }

      return (DenimComponentInstance) deepObject;
   } // of findDeepestComponentInstance

   //-----------------------------------------------------------------

   /**
    * Returns the height of the contents of the sheet.
    */
   public int getVisibleHeight() {
      return (int) panelDisplayHeight + 30;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Returns the width of the contents of the sheet.
    */
   public int getVisibleWidth() {
      return (int) panelDisplayWidth + 10;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Returns the run window that contains this sheet.
    */
   private DenimScenarioEditor getScenarioEditor() {
      return win;
   } // of method

   //===   RUN SHEET METHODS   =================================================
   //===========================================================================

   //===========================================================================
   //===   RENDER METHODS   ====================================================

   /**
    * Draw the specified Denim storyboard panel on the Run sheet, and therefore,
    * in the Run window.
    */
   public void renderPanel(DenimPanel panel) {
      Iterator it;

      //// 1. Turn off beserker mode.
      disableDamage();

      //// 2. Clear out everything in the sheet.
      clear();

      //// 3. Clone the panel to display
      renderedPanel = (DenimPanel) (panel.deepClone());

      //// 4. Add the cloned panel to this sheet, and put it in the upper
      ////    left-hand corner.
      renderedPanel.makeVisibleAtUpperLeftIn(this);


      //// 5a. HACK: Turn off panel bar within component instances in this
      ////     panel and set their color transparency to default
      it = renderedPanel.getSketch().getForwardIterator();
      while (it.hasNext()) {
         Object obj = it.next();

         if (obj instanceof DenimSketchContents) {
            ((DenimSketchContents) obj).setTransparency(
               DenimConstants.DEFAULT_TRANSPARENCY);
         }
         //debug.println("checking: " +
         //              DenimUtils.toShortString((GraphicalObject)obj));
         if (obj instanceof DenimCustomComponentInstance) {
            DenimCustomComponentInstance inst =
               (DenimCustomComponentInstance) obj;
            DenimPanel panelTmp = null;
            Iterator it2 = inst.getForwardIterator();
            while (it2.hasNext()) {
               Object obj2 = it2.next();
               //debug.println("checking: " +
               //              DenimUtils.toShortString((GraphicalObject)obj2));
               if (obj2 instanceof DenimPanel) {
                  panelTmp = (DenimPanel) obj2;
               }
            }
            if (panelTmp != null) {
               //debug.println("turning off: " +
               //              DenimUtils.toShortString((GraphicalObject)panelTmp));
               if (panelTmp.getPanelBar() != null) {
                  panelTmp.getPanelBar().setVisible(false);
               }
               panelTmp.getSketch().getStyleRef().setDrawColorRGBA(0, 0, 0, 0);
            }
         }
      }

      //// 5b. Turn off "stack" effect, if necessary
      renderedPanel.setStackEffect(false);

      //// 6. Disable current timers (that were armed for the previous panel)
      javax.swing.Timer timer;
      it = timers.iterator();
      while (it.hasNext()) {
         timer = (javax.swing.Timer) it.next();
         timer.stop();
      }

      //// 7 Arm any timers that might be in this panel
      Set timerArrows = panel.getTimerArrows();
      it = timerArrows.iterator();
      while (it.hasNext()) {
         Arrow arrow = (Arrow) it.next();
         int delay =
            DenimIntrinsicComponent.getTimerEventSeconds(
               arrow.getInputEventType());

         timer = new javax.swing.Timer(delay * 1000, null);
         timer.addActionListener(
            new TimerAction(timer, this, arrow, renderedPanel));
         timer.start();
         timers.add(timer);
      }

      //// 8. Turn on damage again
      enableDamage();
      damage(DAMAGE_LATER);
      //debug.println("renderedPanel after: " + renderedPanel);

      //// 9. Update the window decorations
      win.update();

   } // of method

   //===   RENDER METHODS   ====================================================
   //===========================================================================

   //===========================================================================
   //===   INNER CLASS MOUSE LISTENERs ==========================================
   /**
    * Handles all mouse motion events inside the run sheet.
    */
   /*
   class DenimScenarioEditorMouseMotionAdapter extends MouseMotionAdapter {

      public void mouseMoved(MouseEvent evt) {

         DenimComponentInstance inst =
            findDeepestComponentInstance(evt.getPoint());
         DenimScenarioEditorSheet rs = (DenimScenarioEditorSheet) evt.getComponent();
         int cond = renderedPanel.getCurrentRunTimeCondition();

         /// 1. handle mouse movement between objects
         if (oldInst != inst) {

            /// 2.1 handle mouse enter to the new instance
            if (inst != null
               && inst instanceof DenimComponentInstance
               && inst.getComponentType().isIntrinsic()) {

               DenimEvent eventAction =
                  new DenimEvent(inst, DenimIntrinsicComponent.MOUSE_ENTER);

               if (inst.hasAction(eventAction, cond)) {

                  // Handle back and forward buttons
                  rs.getScenarioEditor().pushCurrentPanel();
                  rs.getScenarioEditor().clearNextPanels();
                  // activate the action
                  inst.handleEvent(eventAction, cond);
               }
            }

            /// 2.2 handle mouse exit from the "old" instance
            if (oldInst != null
               && oldInst instanceof DenimComponentInstance
               && oldInst.getComponentType().isIntrinsic()) {

               DenimEvent eventAction =
                  new DenimEvent(oldInst, DenimIntrinsicComponent.MOUSE_EXIT);
               if (oldInst.hasAction(eventAction, cond)) {

                  // Handle back and forward buttons
                  rs.getScenarioEditor().pushCurrentPanel();
                  rs.getScenarioEditor().clearNextPanels();
                  // activate the action
                  oldInst.handleEvent(eventAction, cond);
               }
            }
         }

         oldInst = inst;

      } // end of mouseMoved

      public void mouseDragged(MouseEvent evt) {

      } // end of mouseDragged

   } // of DenimScenarioEditorMouseMotionAdapter 
   */

   /**
    * Handles all mouse events inside the scenario sheet.
    */
   class DenimScenarioEditorMouseAdapter extends MouseAdapter {
      private DenimComponentInstance focus;
      private Style focusStyle;

      public void mousePressed(MouseEvent evt) {
         
         if (focus != null) {
            focus.setStyle(focusStyle);
         }

         DenimComponentInstance inst =
            findDeepestComponentInstance(evt.getPoint());

         if (inst != null) {
            focus = inst;
            if (focus instanceof DenimHyperlinkInstance) {
               focusStyle = inst.getStyle();
               inst.getStyleRef().setDrawColor(Color.black);
               inst.getStyleRef().setDrawStroke(dashed);
               DenimScenarioEditorSheet.this.damage(DAMAGE_NOW);
            }
         }
      } // of mousePressed

      public void mouseReleased(MouseEvent evt) {
         
         //debug.println("DenimScenarioEditorSheet: Released");
         //debug.println("this: " + DenimScenarioEditorSheet.this);

         DenimComponentInstance inst =
            findDeepestComponentInstance(evt.getPoint());

         if (inst != null && inst == focus) {
            // Assuming that clicking on a hyperlink is the only way to
            // transition to another panel
            if (focus instanceof DenimHyperlinkInstance) {
               DenimScenarioEditorSheet rs = (DenimScenarioEditorSheet) evt.getComponent();
               
               rs.getScenarioEditor().pushCurrentPanel();
               rs.getScenarioEditor().clearNextPanels();
               //rs.getScenarioEditor().recordPanel(null);
               //empty the next stack if click on link
            }

            /*String eventName = null;

            
            // Check for valid event
            if (SwingUtilities.isLeftMouseButton(evt)) {
               int getClickCount = evt.getClickCount();
               if (getClickCount == 1) {
                  eventName = DenimIntrinsicComponent.LEFT_CLICK;
               } else if (getClickCount == 2) {
                  eventName = DenimIntrinsicComponent.LEFT_2CLICK;
               }
            } else if (SwingUtilities.isRightMouseButton(evt)) {
               int getClickCount = evt.getClickCount();
               if (getClickCount == 1) {
                  eventName = DenimIntrinsicComponent.RIGHT_CLICK;
               } else if (getClickCount == 2) {
                  eventName = DenimIntrinsicComponent.RIGHT_2CLICK;
               }
            }

            // If valid event, then give event to component instance to handle
            if (eventName != null) {
               //debug.println("Event from: " + DenimUtils.toShortString(inst));
               //debug.println("Event type: " + eventName);
               //debug.println("Run time condition: " + renderedPanel.getCurrentRunTimeCondition());
               if (inst.getComponentType().hasEvent(eventName)) {
                  //debug.println("component type has event");
                  inst.handleEvent(
                     new DenimEvent(inst, eventName),
                     renderedPanel.getCurrentRunTimeCondition());
               } else {
                  //debug.println(eventName + " not supported");
               }
            } else {
               //debug.println("No event");
            }
            */
         } else {
            //debug.println("No event source");
         }

      } // of mouseClicked

      public void mouseEntered(MouseEvent evt) {
         /* ###
         DenimComponentInstance inst =
         findDeepestComponentPanel(evt.getPoint());
         
         if (inst != null) {
         inst.handleEvent(
                new DenimEvent(inst,
                      DenimIntrinsicComponent.MOUSE_ENTER),
            1);
            }*/
      } // of mouseEntered

      public void mouseExited(MouseEvent evt) {
         /* ###
            DenimComponentInstance inst =
            findDeepestComponentPanel(DenimScenarioEditorSheet.this, evt.getPoint());
         
         if (inst != null) {
         inst.handleEvent(
             new DenimEvent(inst,
                  DenimIntrinsicComponent.MOUSE_EXIT),
             1);
         //### the cond needs to be changed!!!!!
         }*/
      } // of mouseExited

      public void mouseClicked(MouseEvent evt) {
      } // of mouseReleased

   } // of MouseListener

   //===   INNER CLASS MOUSE LISTENER ==========================================
   //===========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2000 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/

