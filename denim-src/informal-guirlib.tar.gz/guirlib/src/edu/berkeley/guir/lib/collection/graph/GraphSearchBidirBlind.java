//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import edu.berkeley.guir.lib.collection.Queue;
import java.util.HashMap;
import java.util.Iterator;

/**
 * A bidirectional blind search on Graph.
 * This tends to yield the pretty good results in terms of speed and 
 * shortest hops.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Dec 20 1997, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.5/1.2.0, Nov 22 2002, JH
 *               Updated for new Graph APIs
 * </PRE>
 *
 * @author  <A HREF="mailto:jasonh@cs.berkeley.edu">Jason Hong</A>
 * @since   1.1.4
 * @version GUIRLib-v1.5/1.2.0, Nov 22 2002
 */
public class GraphSearchBidirBlind
   implements GraphSearch {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   Graph     g;                 // our reference to the graph
   HashMap   table = new HashMap(GraphConst.DEFAULT_NUMBER_NODES);


   //// The list of nodes we have visited, going forward and backward.
   //// It contains the Paths of how to get to that Node (the table key).
   HashMap mapForward  = new HashMap(GraphConst.DEFAULT_NUMBER_NODES);
   HashMap mapBackward = new HashMap(GraphConst.DEFAULT_NUMBER_NODES);

   //// The list of open nodes going forward and backward
   Queue qForward  = new Queue();
   Queue qBackward = new Queue();

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   SEARCH METHODS   ====================================================

   /**
    * Clears out the paths already created while previously searching.
    * This is generally not needed, except when the underlying Graph data
    * changes.
    */
   public void clear() {
      qForward.clear();
      qBackward.clear();
      mapForward.clear();
      mapBackward.clear();
   } // of method

   //-----------------------------------------------------------------
   
   /**
    * Perform a bidirectional blind search on the graph, with the specified 
    * start and target nodes. Bidirectional searches are guaranteed to have the
    * shortest number of hops.
    *
    * @param  g is the Graph we are searching in.
    * @param  strFrom is the name of the starting node.
    * @param  strTo   is the name of the target node.
    * @return Returns the first successful Path found from the start node
    *         to the target node. The Path is empty if no successful Path
    *         is found, or if either the start or target node does not
    *         exist in the Graph.
    */
   public GraphPath search(Graph g, String strFrom, String strTo) {

      GraphPath   p           = null;   // the current path
      boolean     flagForward = true;   // Search forward or backwards?
      boolean     flagFound   = false;  // Have we found a path?
      String      strNodeAt;            // name of node where we currently are
      GraphNode   nodeAt;               // the node where we currently are
      String      strNodeNext;          // the name of the next open node
      Iterator    it;                   // list of connected Nodes

      this.g = g;



      //// 0.1. Clear out the previous tables
      mapForward.clear();
      mapBackward.clear();

      //// 0.2. Clear out the previous queues
      qForward.clear();
      qBackward.clear();

      //// 0.3. Setup the return path
      GraphPath pathFinal = new GraphPath();



      try {
         //// 1. Ensure that the start and ending nodes are in the Graph
         if (g.nodeExists(strFrom) && g.nodeExists(strTo)) {

            //// 1.1. Initializations - add in the start node
            p = new GraphPath();
            p.addNode(g.getNode(strFrom));
            qForward.enqueue(p);
            mapForward.put(strFrom, p);

            //// 1.2. Initializations - add in the target node
            p = new GraphPath();
            p.addNode(g.getNode(strTo));
            qBackward.enqueue(p);
            mapBackward.put(strTo, p);

            //// 2. While we still have something in the queue and have not
            ////    found what we are looking for
            while (!flagFound && (qForward.size()>0) && (qBackward.size()>0)) {

               //// 2.1. Search forward
               if (flagForward) {
                  //// 2.1.1. Try to dequeue the next thing
                  p           = (GraphPath) qForward.dequeue();
                  nodeAt      = p.getLastNode();
                  strNodeAt   = nodeAt.getName();
                  // System.out.println("searching forward - path " + p);

                  //// 2.1.2. Get the list of nodes connected to this one
                  ////        Since we are searching forward, get the outlinks
                  it = nodeAt.getOutlinks();
                  while (it.hasNext()) {
                     GraphPath newpath = (GraphPath) p.clone();
                     strNodeNext  = (String) it.next();
                     newpath.addNode(g.getNode(strNodeNext), 
                                     g.getWeight(strNodeAt, strNodeNext));

                     //// 2.1.3. See if we have a match with the other table
                     if (mapBackward.containsKey(strNodeNext)) {
                        GraphPath pBackward = (GraphPath) mapBackward.get(strNodeNext);
                        pathFinal = assemblePath(newpath, pBackward);
                        flagFound = true;
                     } 
                     else {
                        // System.out.println("adding path " + newpath);
                        qForward.enqueue(newpath);
                        mapForward.put(strNodeNext, newpath);
                     }
                  }
                  flagForward = false;
               }

               //// 2.2. Search backwards
               else {
                  //// 2.2.1. Try to dequeue the next thing
                  p           = (GraphPath) qBackward.dequeue();
                  nodeAt      = p.getLastNode();
                  strNodeAt   = nodeAt.getName();
                  // System.out.println("searching backward - path " + p);

                  //// 2.2.2. Get the list of nodes connected to this one
                  ////        Since we are searching backward, get the inlinks
                  it = nodeAt.getInlinks();
                  while (it.hasNext()) {
                     GraphPath newpath = (GraphPath) p.clone();
                     strNodeNext  = (String) it.next();
                     newpath.addNode(g.getNode(strNodeNext), 
                                     g.getWeight(strNodeNext, strNodeAt));

                     //// 2.2.3. See if we have a match with the other table
                     if (mapForward.containsKey(strNodeNext)) {
                        GraphPath pForward = (GraphPath) mapForward.get(strNodeNext);
                        pathFinal = assemblePath(pForward, newpath);
                        flagFound = true;
                     } 
                     else {
                        // System.out.println("adding path " + newpath);
                        qBackward.enqueue(newpath);
                        mapBackward.put(strNodeNext, newpath);
                     }
                  }
                  flagForward = true;
               }

            } // of while

         } // of if the start and target nodes exist
      }
      catch (Exception e) {
         //// If this happens you are seriously screwed
         // System.out.println(e);
         pathFinal = new GraphPath();
      }

      return(pathFinal);

   } // of method

   //-----------------------------------------------------------------

   /**
    * Join the forward and backward path together by reversing the backward
    * path and then merging the two together (eliminating the common point).
    *
    * @param pathForward is the forward path found.
    * @param pathBackward is the forward path found.
    */
   private GraphPath assemblePath(GraphPath pathForward, 
                                  GraphPath pathBackward) {
      Iterator  itNodes   = pathBackward.getNodesReversed();
      Iterator  itWeights = pathBackward.getWeightsReversed();
      GraphPath p         = (GraphPath) pathForward.clone();
      
      //// 1. Remove the first element because it is a duplicate
      itNodes.next();

      while (itNodes.hasNext()) {
         Float weight = (Float) itWeights.next();
         p.addNode((GraphNode) itNodes.next(), weight.floatValue());
      }

      return(p);

   } // of method

   //===   SEARCH METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
