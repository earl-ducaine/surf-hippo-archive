/*
 * Copyright (C) 2003 by the Regents of the University of California.
 *  
 * Copyright (C) 2002-2003 by University of Maryland, College Park, MD 20742 
 * All rights reserved. 
 * 
 * This code is based on code in Piccolo.
 * 
 * Piccolo was written at the Human-Computer Interaction Laboratory 
 * www.cs.umd.edu/hcil by Jesse Grosjean under the supervision of Ben Bederson. 
 * The Piccolo website is www.cs.umd.edu/hcil/piccolo 
 */
package edu.berkeley.guir.damask.view.event;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.geom.*;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.List;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.nodes.NonResizableHandle;
import edu.berkeley.guir.damask.view.nodes.ResizableHandle;
import edu.berkeley.guir.damask.view.visual.component.*;
import edu.berkeley.guir.damask.view.visual.component.Panel;
import edu.berkeley.guir.damask.view.visual.dialog.PageRegionView;
import edu.berkeley.guir.damask.view.voice.component.*;
import edu.berkeley.guir.damask.view.voice.dialog.Conversation;
import edu.berkeley.guir.damask.view.voice.dialog.Form;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.event.PDragSequenceEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.util.*;
import edu.umd.cs.piccolox.handles.PBoundsHandle;
import edu.umd.cs.piccolox.handles.PHandle;

/**
 * Provides standard interaction for selection.  Clicking selects the object
 * under the cursor.  Shift-clicking allows multiple objects to be selected.
 * Dragging offers marquee selection.  Pressing the delete key deletes
 * the selection by default.
 * 
 * @author Ben Bederson
 * @author James Lin
 */
public class SelectionEventHandler extends PDragSequenceEventHandler {

   private final static int DASH_WIDTH = 5;
   private final static int NUM_STROKES = 10;

   // The current selection
   private final Set/*<PNode>*/ selection = new HashSet();
   
   // List of nodes whose children can be selected
   private final ArrayList/*<PNode>*/ selectableParents;
   
   private PPath marquee = null;
   private PNode marqueeParent = null;          // Node that marquee is added
                                                // to as a child
   private Point2D presspt = null;
   private Point2D canvasPressPt = null;
   private float strokeNum = 0;
   private final Stroke[] strokes = new Stroke[NUM_STROKES];
   private final Set allItems = new HashSet();  // Used within drag handler
                                                // temporarily
   private final List unselectList = new ArrayList(); // Used within drag
                                                      // handler temporarily
   private final Set marqueeSet = new HashSet();
   private PNode pressNode = null;              // Node pressed on (or null if
                                                // none)
   private boolean deleteKeyActive = false;     // True if DELETE key should
                                                // delete selection
   
   // True if the user tried to select an object in the other layer
   private PNode selectedObjectInOtherLayer = null;
   
   
   private final Map/*<PNode, AffineTransform>*/ origTransforms =
      new HashMap/*<PNode, AffineTransform>*/();
   private final Map/*<ComponentView, PageRegionView>*/ origRegionViews =
      new HashMap/*<ComponentView, PageRegionView>*/();
   private final Map/*<PNode, PNode>*/ nodesToDrag =
      new HashMap/*<PNode, PNode>*/();

   /**
    * Creates a selection event handler.
    * @param marqueeParent The node to which the event handler dynamically adds a marquee
    * (temporarily) to represent the area being selected.
    * @param selectableParent The node whose children will be selected
    * by this event handler.
    */
   public SelectionEventHandler(PNode marqueeParent, PNode selectableParent) {
      this.marqueeParent = marqueeParent;
      this.selectableParents = new ArrayList();
      this.selectableParents.add(selectableParent);
      init();
   }

   /**
    * Creates a selection event handler.
    * @param marqueeParent The node to which the event handler dynamically adds a marquee
    * (temporarily) to represent the area being selected.
    * @param selectableParents A list of nodes whose children will be selected
    * by this event handler.
    */
   public SelectionEventHandler(
      PNode marqueeParent,
      ArrayList selectableParents) {

      this.marqueeParent = marqueeParent;
      this.selectableParents = selectableParents;
      init();
   }

   protected void init() {
      float[] dash = { DASH_WIDTH, DASH_WIDTH };
      for (int i = 0; i < NUM_STROKES; i++) {
         strokes[i] =
            new BasicStroke(
               1,
               BasicStroke.CAP_BUTT,
               BasicStroke.JOIN_MITER,
               1,
               dash,
               i);
      }
   }

   ///////////////////////////////////////////////////////
   // Public static methods for manipulating the selection
   ///////////////////////////////////////////////////////

   protected void select(Collection items, PCamera camera) {
      Iterator itemIt = items.iterator();
      while (itemIt.hasNext()) {
         PNode node = (PNode)itemIt.next();
         select(node, camera);
      }
   }
   
   /**
    * Selects the specified items, and causes the specified canvas to fire
    * a selectionChanged event.
    */
   public void select(Collection items, DamaskCanvas canvas) {
      select(items, canvas.getCamera());
      canvas.fireSelectionChanged();
   }

   protected void select(PNode node, PCamera camera) {
      if (isSelected(node)) {
         return;
      }

      selection.add(node);
      decorateSelectedNode(node, camera);
      
      if (node instanceof Panel) {
         selectPanelChildren((Panel)node, camera);
      }
   }

   /**
    * Selects the specified node, and causes the specified canvas to fire
    * a selectionChanged event.
    */
   public void select(PNode node, DamaskCanvas canvas) {
      select(node, canvas.getCamera());
      canvas.fireSelectionChanged();
   }
   

   /**
    * Selects the specified panel and all objects within the panel.
    */
   private void selectPanelChildren(final Panel panel, final PCamera camera) {
      
      // Since a panel doesn't actually "contain" its children within the
      // Piccolo scenegraph, we have to ask the model of each component view
      // within the containing page region view whether it belongs to the
      // panel's model.
      final ComponentGroup group = (ComponentGroup)panel.getModel();  
      for (Iterator i = panel.getPageRegionView().getChildrenIterator();
         i.hasNext();
         ) {
         final PNode child = (PNode)i.next();
         if (child instanceof ComponentView) {
            final ComponentView componentView = (ComponentView)child;
            final Component component = ((Component)componentView.getModel());
            if (component.getGroup() == group) {
               if (component instanceof Select) {
                  for (Iterator j = child.getChildrenIterator(); j.hasNext();) {
                     final PNode grandchild = (PNode)j.next();
                     if ((grandchild instanceof RadioButton)
                        || (grandchild instanceof CheckBox)) {
                        select(grandchild, camera);
                     }
                  }
               }
               else {
                  select(componentView, camera);
               }
            }
         }
      }
   }

   protected void decorateSelectedNode(PNode node, PCamera camera) {
      if (node instanceof InteractionElementView) {
         final InteractionElementView elementView =
            (InteractionElementView)node;
         if (!elementView.isResizable()) {
            NonResizableHandle.addHandlesTo(
               node,
               camera,
               false,
               elementView.getUseStickyZHandles());
         }
         else {
            ResizableHandle.addHandlesTo(
               node,
               camera,
               false,
               elementView.getUseStickyZHandles());
         }
      }
      //HACK Should use client properties instead
      else if (node instanceof Response.TextGroup) {
         NonResizableHandle.addHandlesTo(node, camera, false, true);
      }
      else {
         ResizableHandle.addHandlesTo(node, camera, false, true);
      }
   }

   protected void unselect(Collection items) {
      Iterator itemIt = items.iterator();
      while (itemIt.hasNext()) {
         PNode node = (PNode)itemIt.next();
         unselect(node);
      }
   }

   /**
    * Unselects the specified items, and causes the canvas to fire a
    * selectionChanged event.
    */
   public void unselect(Collection items, DamaskCanvas canvas) {
      unselect(items);
      canvas.fireSelectionChanged();
   }

   protected void unselect(PNode node) {
      if (!isSelected(node)) {
         return;
      }

      PBoundsHandle.removeBoundsHandlesFrom(node);
      selection.remove(node);
   }

   /**
    * Unselects the specified node, and causes the canvas to fire a
    * selectionChanged event.
    */
   public void unselect(PNode node, DamaskCanvas canvas) {
      unselect(node);
      canvas.fireSelectionChanged();
   }

   protected void unselectAll() {
      for (Iterator it = new HashSet(selection).iterator(); it.hasNext(); ) {
         PNode node = (PNode)it.next();
         unselect(node);
      }
   }

   /**
    * Unselects all currently selected items, and causes the canvas to fire a
    * selectionChanged event.
    */
   public void unselectAll(DamaskCanvas canvas) {
      unselectAll();
      canvas.fireSelectionChanged();
   }

   public boolean isSelected(PNode node) {
      if ((node != null) && (selection.contains(node))) {
         return true;
      }
      else {
         return false;
      }
   }

   public Collection/*<PNode>*/ getSelection() {
      return new HashSet/*<PNode>*/(selection);
   }

   /**
    * Determine if the specified node is selectable (i.e., if it is a child
    * of the one the list of selectable parents.
    */
   protected boolean isSelectable(PNode node) {
      boolean selectable = false;
      
      if (node instanceof PHandle || node instanceof Response.HotSpot) {
         return false;
      }

      Iterator parentsIt = selectableParents.iterator();
      while (parentsIt.hasNext()) {
         PNode parent = (PNode)parentsIt.next();
         if (parent.getChildrenReference().contains(node)) {
            if (node instanceof InteractionElementView) {
               selectable = ((InteractionElementView)node).isSelectable();
            }
            else {
               selectable = true;
            }
            break;
         }
         else if (parent instanceof PCamera) {
            for (int i = 0; i < ((PCamera)parent).getLayerCount(); i++) {
               PLayer layer = ((PCamera)parent).getLayer(i);
               if (layer.getChildrenReference().contains(node)) {
                  selectable = true;
                  break;
               }
            }
         }
      }

      return selectable;
   }

   //////////////////////////////////////////////////////
   // Methods for modifying the set of selectable parents
   //////////////////////////////////////////////////////

   public void addSelectableParent(PNode node) {
      selectableParents.add(node);
   }

   public void removeSelectableParent(PNode node) {
      selectableParents.remove(node);
   }

   public void setSelectableParent(PNode node) {
      selectableParents.clear();
      selectableParents.add(node);
   }

   public void setSelectableParents(Collection c) {
      selectableParents.clear();
      selectableParents.addAll(c);
   }

   public Collection getSelectableParents() {
      return (ArrayList)selectableParents.clone();
   }

   ////////////////////////////////////////////////////////
   // The overridden methods from PDragSequenceEventHandler
   ////////////////////////////////////////////////////////

   protected void startDrag(PInputEvent e) {
      super.startDrag(e);

      initializeSelection(e);

      if (isMarqueeSelection(e)) {
         initializeMarquee(e);

         if (!isOptionSelection(e)) {
            startMarqueeSelection(e);
         }
         else {
            startOptionMarqueeSelection(e);
         }
      }
      else {
         if (!isOptionSelection(e)) {
            startStandardSelection(e);
         }
         else {
            startStandardOptionSelection(e);
         }
      }
   }

   protected void drag(PInputEvent e) {
      super.drag(e);

      if (isMarqueeSelection(e)) {
         updateMarquee(e);

         if (!isOptionSelection(e)) {
            computeMarqueeSelection(e);
         }
         else {
            computeOptionMarqueeSelection(e);
         }
      }
      else {
         dragStandardSelection(e);
      }
   }

   protected void endDrag(PInputEvent e) {
      super.endDrag(e);

      final DamaskCanvas canvas = (DamaskCanvas)e.getComponent(); 

      if (isMarqueeSelection(e)) {
         endMarqueeSelection(e);
      }
      else if (selectedObjectInOtherLayer != null) {
         final DamaskLayer layer =
            ((InteractionElementView)pressNode).getLayer();
         if (DamaskAppUtils.askToChangeLayers(layer, canvas)) {
            select(selectedObjectInOtherLayer, e.getCamera());
         }
      }
      else {
         final DeviceType deviceType = canvas.getDeviceType();
   
         // If objects have been moved, then notify those objects' models
         // of the move
         final MacroCommand cmd = new ModifyGraphMacroCommand();
         
         // If components are being moved, clear out the temporary views
         // and find out which page region they are being dragged to
         for (Iterator selectionIt = selection.iterator(); selectionIt.hasNext();){
            final PNode node = (PNode)selectionIt.next();
            final PNode moveNode = getNodeToMove(node);
            
            if (moveNode instanceof ComponentView) {
               final PNode dragNode = getNodeToDrag(moveNode);
               dragNode.removeFromParent();
               moveNode.setVisible(true);
               moveNode.setTransform((AffineTransform)origTransforms.get(moveNode));
            }
         }
         final Point2D ptCameraCoords =
            e.getPositionRelativeTo(e.getCamera());

         final PNode endNode =
            e.getCamera()
             .pick(ptCameraCoords.getX(), ptCameraCoords.getY(), 1)
             .getPickedNode();
         
         final PageRegionView regionView =
            (PageRegionView)DamaskAppUtils.getAncestor(
               endNode, PageRegionView.class);

         // Keep track of the views that are added in this operation, which
         // can only happen if components are moved from one page region
         // to another.
         final DamaskLayer layer = (DamaskLayer)canvas.getLayer();
         layer.clearTrackedNewAdditions();
         layer.startTrackingNewAdditions();
         
         // For each selected object...
         for (Iterator selectionIt = selection.iterator(); selectionIt.hasNext();){
            final PNode node = (PNode)selectionIt.next();
            final PNode moveNode = getNodeToMove(node);
            final PNode dragNode = getNodeToDrag(moveNode);
            
            if (moveNode instanceof InteractionElementView) {
               final InteractionElementView view = (InteractionElementView)moveNode;
               InteractionElement model = view.getModel();
               
               if (model != null) {
                  boolean simpleTransformChange = true;
                  final PNode newParent;
                  
                  if (moveNode instanceof ComponentView) {
                     newParent = regionView;
                     final PageRegionView origRegionView =
                        (PageRegionView)origRegionViews.get(moveNode);
                     
                     // If the user has dragged a component view on to the
                     // background or a page with a different dialog...
                     if (regionView == null ||
                         ((PageRegion)regionView.getModel()).getPage().getDialog() !=
                            ((PageRegion)origRegionView.getModel()).getPage().getDialog()) {
                        // don't move the component at all
                        simpleTransformChange = false;
                     }
                     // If the user has dragged a component within the same
                     // page region, do a simple move.
                     else if (regionView == origRegionView) {
                        simpleTransformChange = true;
                     }
                     // Otherwise, move the component into another page region,
                     // and change the transform appropriately. 
                     else {
                        simpleTransformChange = false;
                        
                        // Figure out the change between the old transform
                        // and the new one.
                        final AffineTransform oldTransform =
                           (AffineTransform)origTransforms.get(moveNode);
                        
                        final AffineTransform newTransform =
                           dragNode.getLocalToGlobalTransform(null);
                        newTransform.preConcatenate(
                           regionView.getGlobalToLocalTransform(null));
                        
                        AffineTransform deltaTransform = null;
                        try {
                           deltaTransform = oldTransform.createInverse();
                        }
                        catch (NoninvertibleTransformException e1) {
                           // should never happen
                           DamaskAppExceptionHandler.log(e1);
                        }
                        deltaTransform.preConcatenate(newTransform);

                        final Component componentToMove;
                        
                        // If we are moving one radio button or check box,
                        // then we should move all associated controls.
                        if ((moveNode instanceof RadioButton) ||
                            (moveNode instanceof CheckBox)) {
                           componentToMove =
                              ((Select.Item)view.getModel()).getParent();
                        }
                        else {
                           componentToMove = (Component)model;
                        }
                        
                        // Change the page region.
                        cmd.addCommand(
                           new ChangePageRegionCommand(
                              componentToMove,
                              (PageRegion)origRegionView.getModel(),
                              (PageRegion)regionView.getModel()));
                        
                        // Change the transform.
                        if (model instanceof ComponentGroup) {
                           cmd.addCommand(
                              new SetTransformCommand(
                                 (ComponentGroup)model,
                                 (PageRegion)regionView.getModel(),
                                 newTransform));
                        }
                        else {
                           final List/*<Control>*/ controlsToMove =
                              new ArrayList/*<Control>*/();
                           if ((moveNode instanceof RadioButton) ||
                               (moveNode instanceof CheckBox)) {
                              for (Iterator j =
                                      ((Select)componentToMove).getItems()
                                      .iterator();
                                   j.hasNext(); ) {
                                 final Select.Item item = (Select.Item)j.next();
                                 controlsToMove.add(item);
                              }
                           }
                           else {
                              controlsToMove.add(componentToMove);
                           }
                           
                           for (Iterator j = controlsToMove.iterator();
                                j.hasNext(); ) {
                              final Control control = (Control)j.next();
                              final AffineTransform newTransformForControl =
                                 control.getTransform(canvas.getDeviceType());
                              newTransformForControl.preConcatenate(
                                 deltaTransform);
      
                              cmd.addCommand(
                                 new SetTransformCommand(
                                    control,
                                    canvas.getDeviceType(),
                                    newTransformForControl));
                           }
                        }
                     }
                  }
                  else {
                     newParent = moveNode.getParent();
                  }
                  
                  if (simpleTransformChange) {
                     final AffineTransform oldTransform =
                        (AffineTransform)origTransforms.get(view);
                     
                     final AffineTransform newTransform =
                        dragNode.getLocalToGlobalTransform(null);
                     newTransform.preConcatenate(
                        newParent.getGlobalToLocalTransform(null));
                     
                     if (!oldTransform.equals(newTransform)) {
                        if (model instanceof ComponentGroup) {
                           final ComponentGroup group = (ComponentGroup)model;
                           final PageRegion region;
                           if (newParent instanceof PageRegionView) {
                              region = (PageRegion)regionView.getModel();
                           }
                           else {
                              region =
                                 ((Conversation)DamaskAppUtils.getAncestor(
                                    moveNode,
                                    Conversation.class)).getRegionModel();
                           }
                           
                           cmd.addCommand(
                              new SetTransformCommand(
                                 group,
                                 region,
                                 newTransform));
                        }
                        else {
                           cmd.addCommand(
                              new SetTransformCommand(
                                 model,
                                 deviceType,
                                 newTransform));
                        }
                     }
                  }
               }
            }
         }
         
         if (!cmd.isEmpty()) {
            canvas.getDocument().getCommandQueue().doCommand(canvas, cmd);
         }

         // Select the newly added views.
         layer.stopTrackingNewAdditions();
         final List/*<InteractionElementView>*/ newAdds =
            layer.getTrackedNewAdditions();
         if (!newAdds.isEmpty()) {
            unselectAll(canvas);
            for (Iterator j = newAdds.iterator(); j.hasNext(); ) {
               final WeakReference/*<InteractionElementView>*/ ref =
                  (WeakReference)j.next();
               select((InteractionElementView)ref.get(), canvas);
            }
         }
         
         endStandardSelection(e);
      }

      // Fire an event indicating that the selection has changed.
      canvas.fireSelectionChanged();
   }

   ////////////////////////////
   // Additional methods
   ////////////////////////////

   protected boolean isOptionSelection(PInputEvent pie) {
      return pie.isShiftDown();
   }

   protected boolean isMarqueeSelection(PInputEvent pie) {
      return (pressNode == null) ||
             (pressNode instanceof PageRegionView) ||
             (pressNode instanceof Form.Contents);
   }

   protected void initializeSelection(PInputEvent pie) {
      canvasPressPt = pie.getCanvasPosition();
      presspt = pie.getPosition();
      pressNode =
         DamaskAppUtils.getSelectablePickedNode(pie, selectableParents);
      if (pressNode == null) {
         pressNode = pie.getPath().getPickedNode();
         if (pressNode instanceof PCamera) {
            pressNode = null;
         }
      }
      selectedObjectInOtherLayer = null;
   }

   protected void initializeMarquee(PInputEvent e) {
      marquee =
         PPath.createRectangle(
            (float)presspt.getX(),
            (float)presspt.getY(),
            0,
            0);
      marquee.setPaint(null);
      marquee.setStrokePaint(Color.black);
      marquee.setStroke(strokes[0]);
      marqueeParent.addChild(marquee);

      marqueeSet.clear();
   }

   protected void startOptionMarqueeSelection(PInputEvent e) {
   }

   protected void startMarqueeSelection(PInputEvent e) {
      unselectAll();
   }

   protected void startStandardSelection(PInputEvent pie) {
      // Option indicator not down - clear selection, and start fresh
      if (!isSelected(pressNode)) {
         unselectAll();

         if (isSelectable(pressNode)) {
            select(pressNode, pie.getCamera());
         }
         else if ((pressNode instanceof InteractionElementView) &&
                  (((InteractionElementView)pressNode).getModel() instanceof
                    Control) &&
                  ((pressNode.getParent() instanceof InteractionElementView))){
            selectedObjectInOtherLayer = pressNode;
         }
      }
      
      origTransforms.clear();
      origRegionViews.clear();
      nodesToDrag.clear();
      
      for (Iterator i = selection.iterator(); i.hasNext(); ) {
         final PNode selectNode = (PNode)i.next();
         trackNode(selectNode, pie);
      }
   }

   /**
    * @param pie
    * @param selectNode
    */
   private void trackNode(final PNode selectNode, final PInputEvent pie) {
      final PNode moveNode = getNodeToMove(selectNode);
      
      // Store the original transforms of the selected objects
      origTransforms.put(moveNode, moveNode.getTransform());
      
      // For each component view, which is in a page region view, lift it
      // out of the region view and directly on to the canvas, so that it
      // can be moved to another page region view.
      if (moveNode instanceof ComponentView) {
         origRegionViews.put(
            moveNode,
            DamaskAppUtils.getAncestor(moveNode, PageRegionView.class));
         final AffineTransform globalTransform =
            moveNode.getLocalToGlobalTransform(null);
         
         final PNode nodeToDrag = DamaskAppUtils.getPureCopy(moveNode);
         nodesToDrag.put(moveNode, nodeToDrag);

         moveNode.setVisible(false);
         
         final PLayer layer = ((PCanvas)pie.getComponent()).getLayer();
         nodeToDrag.setTransform(globalTransform);
         layer.addChild(nodeToDrag);
      }
   }

   protected void startStandardOptionSelection(PInputEvent pie) {
      // Option indicator is down, toggle selection
      if (isSelectable(pressNode)) {
         if (isSelected(pressNode)) {
            unselect(pressNode);
         }
         else {
            select(pressNode, pie.getCamera());
            trackNode(pressNode, pie);
         }
      }
   }

   protected void updateMarquee(PInputEvent pie) {
      PBounds b = new PBounds();

      if (marqueeParent instanceof PCamera) {
         b.add(canvasPressPt);
         b.add(pie.getCanvasPosition());
      }
      else {
         b.add(presspt);
         b.add(pie.getPosition());
      }

      marquee.setPathToRectangle(
         (float)b.x,
         (float)b.y,
         (float)b.width,
         (float)b.height);
      b.reset();
      b.add(presspt);
      b.add(pie.getPosition());

      allItems.clear();
      PNodeFilter filter = createNodeFilter(b);
      Iterator parentsIt = selectableParents.iterator();
      while (parentsIt.hasNext()) {
         PNode parent = (PNode)parentsIt.next();

         Collection items;
         if (parent instanceof PCamera) {
            items = new ArrayList();
            for (int i = 0; i < ((PCamera)parent).getLayerCount(); i++) {
               ((PCamera)parent).getLayer(i).getAllNodes(filter, items);
            }
         }
         else {
            items = parent.getAllNodes(filter, null);
         }

         Iterator itemsIt = items.iterator();
         while (itemsIt.hasNext()) {
            allItems.add(itemsIt.next());
         }
      }
   }

   protected void computeMarqueeSelection(PInputEvent pie) {
      unselectList.clear();
      // Make just the items in the list selected
      // Do this efficiently by first unselecting things not in the list
      Iterator selectionIt = selection.iterator();
      while (selectionIt.hasNext()) {
         PNode node = (PNode)selectionIt.next();
         if (!allItems.contains(node)) {
            unselectList.add(node);
         }
      }
      unselect(unselectList);

      // Then select the rest
      selectionIt = allItems.iterator();
      while (selectionIt.hasNext()) {
         PNode node = (PNode)selectionIt.next();
         if (!selection.contains(node) && !marqueeSet.contains(node)) {
            marqueeSet.add(node);
         }
      }

      select(allItems, pie.getCamera());
   }

   protected void computeOptionMarqueeSelection(PInputEvent pie) {
      unselectList.clear();
      Iterator selectionIt = selection.iterator();
      while (selectionIt.hasNext()) {
         PNode node = (PNode)selectionIt.next();
         if (!allItems.contains(node) && marqueeSet.contains(node)) {
            marqueeSet.remove(node);
            unselectList.add(node);
         }
      }
      unselect(unselectList);

      // Then select the rest
      selectionIt = allItems.iterator();
      while (selectionIt.hasNext()) {
         PNode node = (PNode)selectionIt.next();
         if (!selection.contains(node) && !marqueeSet.contains(node)) {
            marqueeSet.add(node);
         }
      }

      select(allItems, pie.getCamera());
   }

   protected PNodeFilter createNodeFilter(PBounds bounds) {
      return new BoundsFilter(bounds);
   }

   protected PBounds getMarqueeBounds() {
      if (marquee != null) {
         return marquee.getBounds();
      }
      return new PBounds();
   }

   protected void dragStandardSelection(PInputEvent e) {
      // There was a press node, so drag selection
      final PDimension d = e.getCanvasDelta();
      e.getTopCamera().localToView(d);

      final PDimension gDist = new PDimension();
      for (Iterator selectionIt = selection.iterator(); selectionIt.hasNext();){
         final PNode node = (PNode)selectionIt.next();
         final PNode moveNode = getNodeToMove(node);
         
         boolean move = true;
         if (moveNode instanceof InteractionElementView) {
            move = ((InteractionElementView)node).isMovable();
         }
         
         if (move) {
            // Move both dragNode and moveNode, since other objects, such as
            // arrows, depend on the location of moveNode.
            gDist.setSize(d);
            final PNode dragNode = getNodeToDrag(moveNode);
            dragNode.getParent().globalToLocal(gDist);
            dragNode.offset(gDist.getWidth(), gDist.getHeight());
            
            if (dragNode != moveNode) {
               gDist.setSize(d);
               moveNode.getParent().globalToLocal(gDist);
               moveNode.offset(gDist.getWidth(), gDist.getHeight());
            }
         }
      }
   }


   private PNode getNodeToMove(final PNode node) {
      final PNode moveNode;
      if ((node instanceof Prompt) || (node instanceof Response)) {
         moveNode = DamaskAppUtils.getAncestor(node, VoiceControl.class);
      }
      else {
         moveNode = node;
      }
      return moveNode;
   }

   
   private PNode getNodeToDrag(final PNode node) {
      final PNode dragNode = (PNode)nodesToDrag.get(node);
      if (dragNode == null) {
         return node;
      }
      else {
         return dragNode;
      }
   }

   
   protected void endMarqueeSelection(PInputEvent e) {
      // Remove marquee
      marquee.removeFromParent();
      marquee = null;
      selectedObjectInOtherLayer = null;
   }

   protected void endStandardSelection(PInputEvent e) {
      pressNode = null;
      selectedObjectInOtherLayer = null;
   }

   /**
    * This gets called continuously during the drag, and is used to animate the marquee
    */
   protected void dragActivityStep(PInputEvent aEvent) {
      if (marquee != null) {
         float origStrokeNum = strokeNum;
         strokeNum = (strokeNum + 0.5f) % NUM_STROKES;
         // Increment by partial steps to slow down animation
         if ((int)strokeNum != (int)origStrokeNum) {
            marquee.setStroke(strokes[(int)strokeNum]);
         }
      }
   }

   /**
    * Delete selection when delete key is pressed (if enabled)
    */
   public void keyPressed(PInputEvent e) {
      switch (e.getKeyCode()) {
         case KeyEvent.VK_DELETE :
            if (deleteKeyActive) {
               Iterator selectionIt = selection.iterator();
               while (selectionIt.hasNext()) {
                  PNode node = (PNode)selectionIt.next();
                  node.removeFromParent();
               }
               selection.clear();
            }
      }
   }

   public boolean getSupportDeleteKey() {
      return deleteKeyActive;
   }

   public boolean isDeleteKeyActive() {
      return deleteKeyActive;
   }

   /**
    * Specifies if the DELETE key should delete the selection
    */
   public void setDeleteKeyActive(boolean deleteKeyActive) {
      this.deleteKeyActive = deleteKeyActive;
   }

   //////////////////////
   // Inner classes
   //////////////////////

   protected class BoundsFilter implements PNodeFilter {
      PBounds localBounds = new PBounds();
      PBounds bounds;

      protected BoundsFilter(PBounds bounds) {
         this.bounds = bounds;
      }

      public boolean accept(PNode node) {
         localBounds.setRect(bounds);
         node.globalToLocal(localBounds);
         
         boolean result = true;
         
         if (node instanceof InteractionElementView) {
            result = ((InteractionElementView)node).isSelectable();
         }

         return result && node.getPickable()
            && node.intersects(localBounds)
            && (!(node instanceof PHandle))
            && (!(node instanceof Response.HotSpot))
            && (node != marquee)
            && !selectableParents.contains(node)
            && !isCameraLayer(node);
      }

      public boolean acceptChildrenOf(PNode node) {
         return selectableParents.contains(node) || isCameraLayer(node);
      }

      public boolean isCameraLayer(PNode node) {
         if (node instanceof PLayer) {
            for (Iterator i = selectableParents.iterator(); i.hasNext();) {
               PNode parent = (PNode)i.next();
               if (parent instanceof PCamera) {
                  if (((PCamera)parent).indexOfLayer((PLayer)node) != -1) {
                     return true;
                  }
               }
            }
         }
         return false;
      }
   }
}
