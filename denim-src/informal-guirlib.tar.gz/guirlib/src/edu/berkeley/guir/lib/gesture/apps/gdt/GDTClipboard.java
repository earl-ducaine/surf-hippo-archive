package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.awt.datatransfer.Clipboard;

public class GDTClipboard extends Clipboard
{
  private static GDTClipboard gdtClipboard = new GDTClipboard("gdt");

  public static GDTClipboard getClipboard()
  {
    return gdtClipboard;
  }

  private GDTClipboard(String name)
  {
    super(name);
  }
}
