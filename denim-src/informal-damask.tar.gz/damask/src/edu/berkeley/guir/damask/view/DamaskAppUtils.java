package edu.berkeley.guir.damask.view;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.text.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.view.nodes.DamaskPPath;
import edu.berkeley.guir.damask.view.nodes.StickyTransformManager;
import edu.berkeley.guir.damask.view.visual.Arrow;
import edu.berkeley.guir.damask.view.visual.component.*;
import edu.berkeley.guir.damask.view.visual.component.ComponentView;
import edu.berkeley.guir.damask.view.visual.component.Label;
import edu.berkeley.guir.damask.view.visual.component.Panel;
import edu.berkeley.guir.damask.view.voice.component.Prompt;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.awt.geom.Polygon2D;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.berkeley.guir.lib.util.ClassLib;
import edu.berkeley.guir.lib.util.StringLib;
import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.*;
import edu.umd.cs.piccolo.util.*;
import edu.umd.cs.piccolox.handles.PBoundsHandle;
import edu.umd.cs.piccolox.handles.PHandle;
import edu.umd.cs.piccolox.nodes.PStyledText;
import edu.umd.cs.piccolox.util.PBoundsLocator;


/** 
 * Utilities for Damask.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-01-2003 James Lin
 *                               Created DamaskUtil.
 *                    09-04-2003 James Lin
 *                               Renamed to DamaskAppUtils.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-01-2003
 */
public class DamaskAppUtils {

   public static final Color NO_COLOR = new Color(0, 0, 0, 0); // transparent
   
   public static final String PROPERTY_RESIZE_ANCHOR = "Resize anchor";
   public static final String PROPERTY_RESIZE_CHILDREN_ANCHOR =
      "Resize children anchor";
   public static final String PROPERTY_DISABLED_ICON = "Disabled icon";

   private static final int SQUIGGLE_WIGGLE_WIDTH = 4;
   private static final int SQUIGGLE_GAP_WIDTH = 6;
   private static final int SQUIGGLE_HEIGHT = 6;

   private static final AffineTransform TEMP_TRANSFORM =
      new AffineTransform();

   private static final PText pText = new PText();
   
   private static final Map/*<PNode, Paint>*/ origPaints = new HashMap();
   private static final Map/*<PNode, Paint>*/ origStrokePaints = new HashMap();


   /**
    * Prevents instantiation of this class. 
    */
   private DamaskAppUtils() {}
   
   //---------------------------------------------------------------------------

   /**
    * Returns the ancestor of the specified node whose type is of the
    * specified class.
    */
   public static PNode getAncestor(final PNode node, final Class aClass) {
      PNode ancestor = node;
      while ((ancestor != null) && !(aClass.isInstance(ancestor))) {
         ancestor = ancestor.getParent();
      }
      return ancestor;
   }

   //---------------------------------------------------------------------------

   /**
    * Returns the object that is a descendant of the specified node and is
    * associated with the specified model object.
    */
   public static InteractionElementView getView(
      final PNode node,
      final InteractionElement model) {

      InteractionElementView view = null;

      // Perform a breadth-first search of the scenegraph starting from
      // this layer, looking for an InteractionElementView whose model matches
      // the specified one.
      final List/*<PNode>*/ queue = new LinkedList();
      queue.add(node);

      while (!queue.isEmpty()) {
         final PNode aNode = (PNode)queue.remove(0);
         if (aNode instanceof InteractionElementView) {
            final InteractionElementView currentView =
               (InteractionElementView)aNode;

            if (currentView.getModel() == model) {
               view = currentView;
               break;
            }
         }

         for (Iterator i = aNode.getChildrenIterator(); i.hasNext();) {
            final PNode child = (PNode)i.next();
            queue.add(child);
         }
      }
      queue.clear();

      return view;
   }


   /**
    * Returns the objects that are descendants of the specified node and are
    * associated with the specified model object.
    */
   public static List/*<InteractionElementView>*/ getViews(
      final PNode node,
      final InteractionElement model) {

      final List/*<InteractionElementView>*/ views = new ArrayList();

      // Perform a breadth-first search of the scenegraph starting from
      // this layer, looking for an InteractionElementView whose model matches
      // the specified one.

      // Limit breadth-first search as follows: once one view has been found,
      // set a flag which indicates that no more children should be added to
      // the queue.
      final List/*<PNode>*/ queue = new LinkedList();
      queue.add(node);

      while (!queue.isEmpty()) {
         boolean foundView = false;
         final PNode aNode = (PNode)queue.remove(0);
         if (aNode instanceof InteractionElementView) {
            final InteractionElementView currentView =
               (InteractionElementView)aNode;

            if (currentView.getModel() == model) {
               views.add(currentView);
               foundView = true;
            }
         }

         if (!foundView) {
            for (Iterator i = aNode.getChildrenIterator(); i.hasNext();) {
               final PNode child = (PNode)i.next();
               queue.add(child);
            }
         }
      }
      queue.clear();

      return views;
   }

   //===========================================================================
   
   /**
    * Adds the descendants of the specified group to the specified sets.
    */ 
   private static void addDescendants(
      final ComponentGroup group,
      final Set/*<ComponentGroup>*/ groups,
      final Set/*<Control>*/ controls) {

      for (Iterator i = group.getChildren().iterator(); i.hasNext();) {
         final Component child = (Component)i.next();
         if (child instanceof Control) {
            controls.add(child);
         }
         else if (child instanceof ComponentGroup) {
            groups.add(child);
            addDescendants((ComponentGroup)child, groups, controls);
         }
      }
   }

   /**
    * Given a set of groups that will be deleted, removes the groups that 
    * are contained in other groups in the set, and adds the descendant
    * controls of the groups to the other set.
    */
   private static void removeDescendantGroupsAndAddDescendantControls(
      final Set/*<ComponentGroup>*/ groupsToRemove,
      final Set/*<Control>*/ controlsToRemove) {

      final Set/*<ComponentGroup>*/ redundantGroups = new HashSet();

      for (Iterator i = groupsToRemove.iterator(); i.hasNext();) {
         final ComponentGroup group = (ComponentGroup)i.next();
         addDescendants(group, redundantGroups, controlsToRemove);
      }

      groupsToRemove.removeAll(redundantGroups);
   }

   /**
    * Adds a command to delete the specified group and all of the specified
    * group's descendant groups to the specified command.
    */
   private static void addDeleteDescendantGroupsToCommand(
      final ComponentGroup group,
      final MacroCommand cmd) {

      // Must do postorder traversal
      for (Iterator i = group.getChildren().iterator(); i.hasNext();) {
         final Component child = (Component)i.next();
         if (child instanceof ComponentGroup) {
            addDeleteDescendantGroupsToCommand((ComponentGroup)child, cmd);
         }
      }
      if (group.getGroup() != null) {
         cmd.addCommand(
            new RemoveComponentFromGroupCommand(group.getGroup(), group));
      }
      cmd.addCommand(new RemoveGroupCommand(group));
   }

   /**
    * Returns a command to delete the specified collection of
    * objects from the specified canvas.
    */
   public static MacroCommand createDeleteObjectsCommand(
      final DamaskCanvas canvas,
      final Collection/*<PNode>*/ objsToDel) {

      final MacroCommand cmd = new ModifyGraphMacroCommand();

      // Keep track of how many items are removed from select-type controls.
      final Map/*<Select, Set<Select.Item>>*/ selectItemsToRemove =
         new HashMap();
      final Set/*<ComponentGroup>*/ groupsToRemove = new HashSet();
      final Set/*<Control>*/ controlsToRemove = new HashSet();

      for (Iterator i = objsToDel.iterator(); i.hasNext();) {
         final PNode node = (PNode)i.next();
         InteractionElementView view = null;
         
         if (node instanceof InteractionElementView) {
            view = (InteractionElementView)node;
         }
         else if (node.getParent() instanceof Response) {
            view = (Response)node.getParent();
         }
         
         if (view != null) {
            // If an object to be deleted is selected, unselect it.
            if (canvas.getSelectedObjects().contains(view)) {
               canvas.getSelectionEventHandler().unselect(view, canvas);
            }

            if ((view instanceof RadioButton) || (view instanceof CheckBox)) {
               final Select.Item item = (Select.Item)view.getModel();
               final Select select = item.getParent();

               Set/*<Select.Item>*/ itemsToRemoveFromSelect =
                  (Set)selectItemsToRemove.get(select);

               if (itemsToRemoveFromSelect == null) {
                  itemsToRemoveFromSelect = new HashSet/*<Select.Item>*/();
                  selectItemsToRemove.put(select, itemsToRemoveFromSelect);
               }
               itemsToRemoveFromSelect.add(item);
            }
            else if (view instanceof ControlView) {
               controlsToRemove.add(view.getModel());
            }
            else if (view instanceof Panel) {
               groupsToRemove.add(view.getModel());
            }
            else if (view instanceof Prompt) {
               controlsToRemove.add(view.getModel());
            }
            else if (view instanceof Response) {
               final Control control = (Control)view.getModel();
               controlsToRemove.add(control);
               final Control prevControl =
                  DamaskUtils.getPreviousLowLevelControl(
                     control.getPageRegion(DeviceType.VOICE), control);
               if ((prevControl instanceof Select) ||
                   (prevControl instanceof TextInput)) {
                  controlsToRemove.add(prevControl);
               }
               else if (prevControl instanceof Select.Item) {
                  controlsToRemove.add(((Select.Item)prevControl).getParent());
               }
            }
            else if (view instanceof Arrow) {
               cmd.addCommand(
                  new RemoveConnectionCommand((Connection)view.getModel(), true));
            }
         }
      }

      // If all of the items are to be removed from a select-type control,
      // then remove the control itself instead.
      for (Iterator i = selectItemsToRemove.keySet().iterator();
         i.hasNext();
         ) {
         final Select select = (Select)i.next();
         final Set/*<Select.Item>*/ removedItemsForSelect =
            (Set) selectItemsToRemove.get(select);
         if (removedItemsForSelect.size() == select.getItems().size()) {
            controlsToRemove.add(select);
         }
         else {
            for (Iterator j = removedItemsForSelect.iterator(); j.hasNext();) {
               final Select.Item item = (Select.Item)j.next();
               cmd.addCommand(new RemoveItemCommand(select, item));
            }
         }
      }

      // Add all descendant controls of groups to remove to the set of
      // controls to remove. Remove all descendant groups of groups to remove
      // from the set of groups to remove.
      removeDescendantGroupsAndAddDescendantControls(
         groupsToRemove,
         controlsToRemove);

      // Remove each control.
      for (Iterator i = controlsToRemove.iterator(); i.hasNext();) {
         final Control control = (Control)i.next();
         if (control.getGroup() != null) {
            cmd.addCommand(
               new RemoveComponentFromGroupCommand(
                  control.getGroup(),
                  control));
         }
         cmd.addCommand(new RemoveControlCommand(control));
      }

      // Remove each group, including all of the group's descendant groups.
      for (Iterator i = groupsToRemove.iterator(); i.hasNext();) {
         final ComponentGroup group = (ComponentGroup)i.next();
         addDeleteDescendantGroupsToCommand(group, cmd);
      }

      return cmd;
   }

   //===========================================================================

   /**
    * A filter that returns nodes whose bounds contain the specified point in
    * layer coordinates, and which are children of one of the specified
    * selectable parents. 
    */
   public static class PickableAndSelectableFilter implements PNodeFilter {
      private final Collection selectableParents;
      private final Point2D globalPt;

      public PickableAndSelectableFilter(
         final Collection selectableParents,
         final Point2D globalPt) {

         this.selectableParents = selectableParents;
         this.globalPt = globalPt;
      }

      public boolean accept(PNode node) {
         final Point2D localPt =
            new Point2D.Double(globalPt.getX(), globalPt.getY());
         node.globalToLocal(localPt);

         boolean result = true;

         if (node instanceof InteractionElementView) {
            result = ((InteractionElementView)node).isSelectable();
         }

         return result
            && node.getPickable()
            && node.getBounds().contains(localPt)
            && !(node instanceof PHandle)
            && !(node instanceof Response.HotSpot)
            && !selectableParents.contains(node)
            && !isCameraLayer(node);
      }

      public boolean acceptChildrenOf(PNode node) {
         return selectableParents.contains(node) || isCameraLayer(node);
      }

      public boolean isCameraLayer(PNode node) {
         if (node instanceof PLayer) {
            for (Iterator i = selectableParents.iterator(); i.hasNext();) {
               PNode parent = (PNode)i.next();
               if (parent instanceof PCamera) {
                  if (((PCamera)parent).indexOfLayer((PLayer)node) != -1) {
                     return true;
                  }
               }
            }
         }
         return false;
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Given an input event, returns the node furthest on the pick path that
    * is the child of a selectable parent, or null if there are no selectable
    * parents on the path.
    */
   public static PNode getSelectablePickedNode(
      final PInputEvent pie,
      final Collection selectableParents) {
   
      PNode pickedNode = pie.getPath().getPickedNode();
      if (pickedNode instanceof PCamera) {
         pickedNode = null;
      }
      else {
         // If pressNode is not a child of a selectable parent, then walk up
         // the scenegraph until we find a node that is. If we can't find one,
         // then leave pressNode alone.
         PNode newPickedNode = pickedNode;
         while ((newPickedNode != null)
            && !selectableParents.contains(newPickedNode.getParent())) {
      
            newPickedNode = newPickedNode.getParent();
         }
         pickedNode = newPickedNode;
      }
      return pickedNode;
   }

   //===========================================================================
   
   /**
    * Given a set of nodes, figures out if all of them belong to one panel,
    * and if so, returns that panel, otherwise returns null.
    */
   public static Panel findRootPanel(final Collection/*<PNode>*/ nodes) {
      final Map/*<Component, ComponentView>*/ views =
         new HashMap/*<Component, ComponentView>*/();
      final Set/*<Component>*/ components = new HashSet/*<Component>*/(); 
      final Set/*<ComponentGroup>*/ descendantGroups =
         new HashSet/*<ComponentGroup>*/(); 
      final Set/*<Control>*/ descendantControls = new HashSet/*<Control>*/(); 
      
      for (Iterator i = nodes.iterator(); i.hasNext(); ) {
         final PNode node = (PNode)i.next();
         if (node instanceof ComponentView) {
            final ComponentView componentView = (ComponentView)node;
            final Component component = (Component)componentView.getModel();
            components.add(component);
            views.put(component, componentView);
         }
         else {
            return null;
         }
      }
      
      for (Iterator i = components.iterator(); i.hasNext(); ) {
         final Component component = (Component)i.next();
         if (component instanceof ComponentGroup) {
            addDescendants(
               (ComponentGroup)component,
               descendantGroups,
               descendantControls);
         }
      }
      
      components.removeAll(descendantGroups);
      components.removeAll(descendantControls);
      
      if (components.size() == 1) {
         final Component survivor = (Component)components.iterator().next();
         if (survivor instanceof ComponentGroup) {
            return (Panel)views.get(survivor);
         }
      }
      return null;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Prints out a node and its descendants, along with their transform and
    * bounds.
    */
   public static void printTree(final PNode node) {
      printTree(node, 0);
   }
   
   
   private static void printTree(final PNode node, final int indent) {
      System.out.print(StringLib.spaces(indent * 2) + ClassLib.getShortClassName(node));
      if (node instanceof InteractionElementView) {
         System.out.print(" - " + ((InteractionElementView)node).getModel().getDeviceTypesVisibleTo());
      }
      System.out.println();
      //System.out.println(StringLib.spaces(indent * 2) + "* " + node.getBounds());
      System.out.println(StringLib.spaces(indent * 2) + "* " + node.getTransform());
      final Rectangle2D globalBounds = node.getBounds();
      node.localToGlobal(globalBounds);
      //System.out.println(StringLib.spaces(indent * 2) + "->" + globalBounds);
      for (Iterator i = node.getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         printTree(child, indent + 1);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Prints out a node and its descendants, along with their transform and
    * bounds.
    */
   public static void printAncestors(final PNode node) {
      PNode n = node;
      System.out.println(n);
      System.out.println("   * " + n.getTransform());
      n = n.getParent();
      while (n != null) {
         System.out.println("- " + n);
         System.out.println("   * " + n.getTransform());
         n = n.getParent();
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Takes the specified rectangle in the specified node's local coordinates
    * and transforms it to specified canvas' coordinates. Also returns the
    * changed rectangle.
    */
   public static Rectangle2D localToCanvas(
      final PNode node,
      final PCanvas canvas,
      final Rectangle2D rect) {

      node.localToGlobal(rect);

      final PCamera camera = canvas.getCamera();
      PNode n = node;
      boolean haveSeenCanvasCamera = false;
      while (n != null) {
         haveSeenCanvasCamera |= (n == camera);
         n = n.getParent();
      }
      if (!haveSeenCanvasCamera) {
         camera.viewToLocal(rect);
      }
      
      return rect;      
   }

   //---------------------------------------------------------------------------
   
   /**
    * Takes the specified rectangle in the specified canvas' coordinates
    * and transforms it to specified nodes' local coordinates. Also returns the
    * changed rectangle.
    */
   public static Rectangle2D canvasToLocal(
      final PNode node,
      final PCanvas canvas,
      final Rectangle2D rect) {

      final PCamera camera = canvas.getCamera();
      PNode n = node;
      boolean haveSeenCanvasCamera = false;
      while (n != null) {
         haveSeenCanvasCamera |= (n == camera);
         n = n.getParent();
      }
      if (!haveSeenCanvasCamera) {
         camera.localToView(rect);
      }
      
      node.globalToLocal(rect);

      return rect;      
   }
   
   //===========================================================================

   private static boolean isInvisibleOrWhite(final Paint paint) {
      return (paint == null)
         || (paint.equals(NO_COLOR))
         || (paint.equals(Color.WHITE));
   }

   /**
    * Sets the color of everything within the specified node.
    */
   public static void setInternalColor(final PNode node, final Color color) {
      if (node instanceof Label) {
         ((Label)node).setLabelColor(color);
      }
      else {
         if (node instanceof PPath) {
            final PPath path = (PPath)node;
            if (!isInvisibleOrWhite(path.getStrokePaint())) {
               path.setStrokePaint(color);
            }
         }
         if (node instanceof DamaskPPath) {
            final DamaskPPath path = (DamaskPPath)node;
            if (!isInvisibleOrWhite(path.getStrokePaint())) {
               path.setStrokePaint(color);
            }
         }
         if (!isInvisibleOrWhite(node.getPaint())) {
            node.setPaint(color);
         }
         for (Iterator i = node.getChildrenIterator(); i.hasNext(); ) {
            final PNode child = (PNode)i.next();
            setInternalColor(child, color);
         }
      }
   }


   /**
    * Sets the transparency of everything within the specified node.
    * 
    * @param alpha the new transparency: 0 is invisible, 255 is opaque
    */
   public static void setInternalColorAlpha(final PNode node, final int alpha) {
      if (node instanceof Label) {
         final Label label = ((Label)node);
         label.setLabelColor(
            createTransparentColor(label.getLabelColor(), alpha));
      }
      else {
         if (node instanceof PPath) {
            final PPath path = (PPath)node;
            if (!isInvisibleOrWhite(path.getStrokePaint())) {
               path.setStrokePaint(
                  createTransparentPaint(path.getStrokePaint(), alpha));
            }
         }
         if (node instanceof DamaskPPath) {
            final DamaskPPath path = (DamaskPPath)node;
            if (!isInvisibleOrWhite(path.getStrokePaint())) {
               path.setStrokePaint(
                  createTransparentPaint(path.getStrokePaint(), alpha));
            }
         }
         if (!isInvisibleOrWhite(node.getPaint())) {
            node.setPaint(createTransparentPaint(node.getPaint(), alpha));
         }
         for (Iterator i = node.getChildrenIterator(); i.hasNext(); ) {
            final PNode child = (PNode)i.next();
            setInternalColorAlpha(child, alpha);
         }
      }
   }

   /**
    * Sets the color of everything within the specified node, and saves
    * the original color, which can be reset with {@link popInternalColor}.
    */
   public static void pushInternalColor(final PNode node, final Color color) {
      if (node instanceof Label) {
         final Label label = (Label)node;
         origPaints.put(label, label.getLabelColor());
         label.setLabelColor(color);
      }
      else {
         if (!(node instanceof PHandle || node instanceof Response.HotSpot)) {
            if (node instanceof PPath) {
               final PPath path = (PPath)node;
               if (!isInvisibleOrWhite(path.getStrokePaint())) {
                  origStrokePaints.put(path, path.getStrokePaint());
                  path.setStrokePaint(color);
               }
            }
            if (node instanceof DamaskPPath) {
               final DamaskPPath path = (DamaskPPath)node;
               if (!isInvisibleOrWhite(path.getStrokePaint())) {
                  origStrokePaints.put(path, path.getStrokePaint());
                  path.setStrokePaint(color);
               }
            }
            if (!isInvisibleOrWhite(node.getPaint())) {
               origPaints.put(node, node.getPaint());
               node.setPaint(color);
            }
            for (Iterator i = node.getChildrenIterator(); i.hasNext(); ) {
               final PNode child = (PNode)i.next();
               pushInternalColor(child, color);
            }
         }
      }
   }


   /**
    * Restores the color of everything within the specified node to the color
    * of the node before {@link pushInternalColor} was called on the node. Does
    * nothing if {@link pushInternalColor} was not called on the node once
    * before.
    */
   public static void popInternalColor(final PNode node) {
      if (node instanceof Label) {
         final Label label = (Label)node;
         final Color origColor = (Color)origPaints.get(label);
         if (origColor != null) {
            label.setLabelColor(origColor);
            origPaints.remove(label);
         }
      }
      else {
         if (node instanceof PPath) {
            final PPath path = (PPath)node;
            if (!isInvisibleOrWhite(path.getStrokePaint())) {
               final Color origColor = (Color)origStrokePaints.get(path);
               if (origColor != null) {
                  path.setStrokePaint(origColor);
                  origStrokePaints.remove(path);
               }
            }
         }
         if (node instanceof DamaskPPath) {
            final DamaskPPath path = (DamaskPPath)node;
            if (!isInvisibleOrWhite(path.getStrokePaint())) {
               final Color origColor = (Color)origStrokePaints.get(path);
               if (origColor != null) {
                  path.setStrokePaint(origColor);
                  origStrokePaints.remove(path);
               }
            }
         }
         if (!isInvisibleOrWhite(node.getPaint())) {
            final Color origColor = (Color)origPaints.get(node);
            if (origColor != null) {
               node.setPaint(origColor);
               origPaints.remove(origColor);
            }
         }
         for (Iterator i = node.getChildrenIterator(); i.hasNext(); ) {
            final PNode child = (PNode)i.next();
            popInternalColor(child);
         }
      }
   }
   
   //===========================================================================
   
   /**
    * Creates a new color with the same RGB as the specified color but with the
    * specified transparency.
    */
   public static Color createTransparentColor(
      final Color color,
      final int alpha) {

      return new Color(
         color.getRed(), color.getGreen(), color.getBlue(), alpha);
   }

   //===========================================================================

   /**
    * If the specified paint is a color, then creates a new color with the
    * same RGB as the specified color but with the specified transparency;
    * otherwise, returns the same paint back.
    */
   public static Paint createTransparentPaint(
      final Paint paint,
      final int alpha) {

      if (paint instanceof Color) {
         final Color color = (Color)paint;

         return new Color(
            color.getRed(),
            color.getGreen(),
            color.getBlue(),
            alpha);
      }
      else {
         return paint;
      }
   }
   
   //===========================================================================


   /**
    * Returns a color that is darker version of the specified color by the
    * specified factor.
    */
   public static Color createDarkerColor(final Color color, final double factor) {
      return new Color(
         Math.max((int) (color.getRed() * factor), 0),
         Math.max((int) (color.getGreen() * factor), 0),
         Math.max((int) (color.getBlue() * factor), 0));
   }

   //===========================================================================

   /**
    * Sets the stroke of everything within the specified node to the specified
    * stroke.
    */
   public static void setInternalStroke(final PNode node, final Stroke stroke) {
      if (node instanceof PPath) {
         final PPath path = (PPath)node;
         path.setStroke(stroke);
      }
      else if (node instanceof DamaskPPath) {
         final DamaskPPath path = (DamaskPPath)node;
         path.setStroke(stroke);
      }
      for (Iterator i = node.getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         setInternalStroke(child, stroke);
      }
   }
   
   //===========================================================================

   /**
    * Resizes the specified path so that it has the specified bounds.
    */
   public static void resizeGeneralPath(final GeneralPath path,
      final Rectangle2D newBounds) {

      final Rectangle2D pathBounds = path.getBounds2D();
      final double x = newBounds.getX();
      final double y = newBounds.getY();
      double width = newBounds.getWidth();
      double height = newBounds.getHeight();
      
      // If the new width or height is 0, then change the path to a line or
      // point.
      if ((width <= 0) || (height <= 0)) {
         width = Math.max(width, 0);
         height = Math.max(height, 0);
         if ((width == 0) && (height == 0)) {
            path.reset();
            path.moveTo((float)x, (float)y);
            path.lineTo((float)x, (float)y);
            path.closePath();
         }
         else {
            path.reset();
            path.moveTo((float)x, (float)y);
            path.lineTo((float)(x + width), (float)(y + height));
            path.closePath();
         }
      }
      // If the width or height of the contained path is 0, then change
      // the path to a rectangle.
      else if ((pathBounds.getWidth() == 0) || (pathBounds.getHeight() == 0)) {
         path.reset();
         path.append(new Rectangle2D.Double(x, y, x + width, y + height), false);
      }
      else {
         TEMP_TRANSFORM.setToIdentity();
         TEMP_TRANSFORM.translate(x, y);
         TEMP_TRANSFORM.scale(
            width / pathBounds.getWidth(),
            height / pathBounds.getHeight());
         TEMP_TRANSFORM.translate(-pathBounds.getX(), -pathBounds.getY());
         path.transform(TEMP_TRANSFORM);
      }
   }

   //===========================================================================
   
   /**
    * Returns whether rect2 is contained in rect1. Correctly handles the case
    * where rect2 is either a line or a point. 
    */
   public static boolean containsRect(final Rectangle2D rect1,
      final Rectangle2D rect2) {
      if ((rect1.getHeight() >= 0) && (rect1.getHeight() >= 0) &&
            (rect2.getHeight() == 0) || (rect2.getWidth() == 0)) {
         return (rect1.getX() <= rect2.getX()) &&
            (rect2.getMaxX() <= rect1.getMaxX()) &&
            (rect1.getY() <= rect2.getY()) &&
            (rect2.getMaxY() <= rect1.getMaxY());
      }
      else {
         return rect1.contains(rect2);
      }
   }

   //===========================================================================
   
   /**
    * Transforms the specified rectangle from the local coordinates of the
    * specified node to global coordinates. Correctly handles whether the
    * rectangle is either a line or a point. 
    */
   public static void localToGlobal(final PNode node, final Rectangle2D rect){
      if (rect.getWidth() == 0 || rect.getHeight() == 0) {
         final PAffineTransform regionTransform =
            node.getLocalToGlobalTransform(null);
         final Point2D p1 = new Point2D.Double(rect.getX(), rect.getY());
         final Point2D p2 = new Point2D.Double(rect.getMaxX(), rect.getMaxY());
         regionTransform.transform(p1, p1);
         regionTransform.transform(p2, p2);
         rect.setRect(p1.getX(), p1.getY(),
            p2.getX() - p1.getX(), p2.getY() - p1.getY());
      }
      else {
         node.localToGlobal(rect);
      }
   }

   //===========================================================================
   
   /**
    * Transforms the specified rectangle from global coordinates to the local
    * coordinates of the specified node. Correctly handles whether the
    * rectangle is either a line or a point. 
    */
   public static void globalToLocal(final PNode node, final Rectangle2D rect){
      if (rect.getWidth() == 0 || rect.getHeight() == 0) {
         final PAffineTransform regionTransform =
            node.getGlobalToLocalTransform(null);
         final Point2D p1 = new Point2D.Double(rect.getX(), rect.getY());
         final Point2D p2 = new Point2D.Double(rect.getMaxX(), rect.getMaxY());
         regionTransform.transform(p1, p1);
         regionTransform.transform(p2, p2);
         rect.setRect(p1.getX(), p1.getY(),
            p2.getX() - p1.getX(), p2.getY() - p1.getY());
      }
      else {
         node.globalToLocal(rect);
      }
   }

   //===========================================================================

   /**
    * Adds PBoundsHandles to the given node, which will stick to the given
    * camera in the x and y axes, while zooming in and out along the z axis
    * properly.
    */
   public static void addStickyZBoundsHandlesTo(PNode aNode, PCamera camera) {
      PBoundsHandle[] handles = new PBoundsHandle[] { 
         new PBoundsHandle(PBoundsLocator.createEastLocator(aNode)),
         new PBoundsHandle(PBoundsLocator.createWestLocator(aNode)),
         new PBoundsHandle(PBoundsLocator.createNorthLocator(aNode)),
         new PBoundsHandle(PBoundsLocator.createSouthLocator(aNode)),
         new PBoundsHandle(PBoundsLocator.createNorthEastLocator(aNode)),
         new PBoundsHandle(PBoundsLocator.createNorthWestLocator(aNode)),
         new PBoundsHandle(PBoundsLocator.createSouthEastLocator(aNode)),
         new PBoundsHandle(PBoundsLocator.createSouthWestLocator(aNode))
      };
      
      for (int i = 0, n = handles.length; i < n; i++) {
         final PBoundsHandle handle = handles[i];
         aNode.addChild(handle);
         StickyTransformManager.setupStickyZ(
            handle,
            camera,
            new Point2D.Double(0.5, 0.5));
         handle.relocateHandle(); 
      }
   }

   /**
    * Removes any sticky bounds handles from the specified node that are
    * attached to the specified camera. 
    */
   public static void removeStickyBoundsHandlesFrom(
      PNode aNode,
      PCamera camera) {
      final Set handlesToRemove = new HashSet();
      for (Iterator i = camera.getChildrenIterator(); i.hasNext();) {
         final PNode child = (PNode)i.next();
         if (child instanceof PBoundsHandle) {
            final PBoundsHandle handle = (PBoundsHandle)child;
            final PBoundsLocator l = (PBoundsLocator)handle.getLocator();
            final PNode n = l.getNode();
            if (n == aNode) {
               handlesToRemove.add(handle);
            }
         }
      }
      camera.removeChildren(handlesToRemove);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns the union of the bounds of the specified collection of 
    * GeneralPaths.
    */
   public static Rectangle2D getUnionBounds(
      final Collection/*<GeneralPath>*/ strokes) {
      
      if (strokes.isEmpty()) {
         return new Rectangle2D.Double();
      }
      final Iterator i = strokes.iterator();
      final GeneralPath firstPath = (GeneralPath)i.next();
      final Rectangle2D strokesBounds = firstPath.getBounds2D();
      
      while (i.hasNext()) {
         final GeneralPath path = (GeneralPath)i.next();
         Rectangle2D.union(strokesBounds, path.getBounds2D(), strokesBounds); 
      }
      return strokesBounds;
   }


   /**
    * Constructs a rectangle whose top corners are rounded.
    * 
    * @param rect the rectangle to round off
    * @param arcw the width of the arc to use to round off the top corners
    * @param arch the height of the arc to use to round off the top corners
    */
   public static GeneralPath createHalfRoundRectangle(
      final Rectangle2D rect,
      float arcw,
      float arch) {
         
      return createHalfRoundRectangle(
         (float)rect.getX(),
         (float)rect.getY(),
         (float)rect.getWidth(),
         (float)rect.getHeight(),
         arcw,
         arch);
   }


   /**
    * Constructs a rectangle whose top corners are rounded.
    * 
    * @param x the x-location of the newly constructed rectangle
    * @param y the y-location of the newly constructed rectangle
    * @param w the width to which to set the newly constructed rectangle
    * @param h the height to which to set the newly constructed rectangle
    * @param arcw the width of the arc to use to round off the top corners
    * @param arch the height of the arc to use to round off the top corners
    */
   public static GeneralPath createHalfRoundRectangle(
      float x,
      float y,
      float w,
      float h,
      float arcw,
      float arch) {

      final GeneralPath path = new GeneralPath();
      
      path.moveTo(x, y + h);
      path.lineTo(x, y + arch);
      path.quadTo(x, y, x + arcw, y);
      path.lineTo(x + w - arcw, y);
      path.quadTo(x + w, y, x + w, y + arch);
      path.lineTo(x + w, y + h);
      path.closePath();

      return path;
   }


   /**
    * Constructs a rectangle whose corners are rounded.
    * 
    * @param rect the rectangle to round off
    * @param arcw the width of the arc to use to round off the corners
    * @param arch the height of the arc to use to round off the corners
    */
   public static RoundRectangle2D createRoundRectangle(
      final Rectangle2D rect,
      float arcw,
      float arch) {
      
      return new RoundRectangle2D.Double(
         rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(),
         arcw, arch);
   }


   /**
    * Constructs a voice balloon.
    */
   public static GeneralPath createVoiceBalloon(
      final Rectangle2D rect,
      float arcw,
      float arch,
      float pointX1,
      float pointX2,
      float pointY2,
      float pointX3) {
      
      return createVoiceBalloon(
         (float)rect.getX(),
         (float)rect.getY(),
         (float)rect.getWidth(),
         (float)rect.getHeight(),
         arcw,
         arch,
         pointX1,
         pointX2,
         pointY2,
         pointX3);
   }
      
   /**
    * Constructs a voice balloon.
    */
   public static GeneralPath createVoiceBalloon(
      float x,
      float y,
      float w,
      float h,
      float arcw,
      float arch,
      float pointX1,
      float pointX2,
      float pointY2,
      float pointX3) {
      
      final GeneralPath path = new GeneralPath();
      
      if (arcw > w / 3) {
         arcw = w / 3;
      }
      if (arch > h / 3) {
         arch = h / 3;
      }
      
      float dx = pointX2 - pointX1; 
      
      if (pointX3 < arcw || pointX3 > w - arcw) {
         pointX3 = w - arcw + 1;
      }
      if (pointX1 < arcw || pointX1 > pointX3) {
         pointX1 = arcw - 1;
      }
      
      if (Math.signum(dx) != Math.signum(pointX2 - pointX1)) {
         pointX2 = pointX1 + dx;
      }
      
      path.moveTo(x, y + h - arch);
      path.lineTo(x, y + arch);
      path.quadTo(x, y, x + arcw, y);
      path.lineTo(x + w - arcw, y);
      path.quadTo(x + w, y, x + w, y + arch);
      path.lineTo(x + w, y + h - arch);
      path.quadTo(x + w, y + h, x + w - arcw, y + h);
      path.lineTo(x + pointX3, y + h);
      path.lineTo(x + pointX2, y + h + pointY2);
      path.lineTo(x + pointX1, y + h);
      path.lineTo(x + arcw, y + h);
      path.quadTo(x, y + h, x, y + h - arch);
      
      path.closePath();

      return path;
   }
   
   
   /**
    * Creates a diamond that fits within the specified bounds.  
    */
   public static GeneralPath createDiamond(final Rectangle2D bounds) {
      final GeneralPath path = new GeneralPath();
      path.moveTo((float)bounds.getCenterX(), (float)bounds.getY());
      path.lineTo((float)bounds.getX(), (float)bounds.getCenterY());
      path.lineTo((float)bounds.getCenterX(), (float)bounds.getMaxY());
      path.lineTo((float)bounds.getMaxX(), (float)bounds.getCenterY());
      path.closePath();
      
      return path;
   }


   /**
    * Returns a squiggle of a moderate length. Useful for intrinsic components
    * that are stamped instead of sketched.
    */
   public static PPath createSquiggle() {
      return createSquiggle(13);
   }


   /**
    * Returns a squiggle. Useful for intrinsic components that are
    * stamped instead of sketched.
    * 
    * @param numWiggles how many "wiggles" (up and down strokes) the
    *                   squiggle will have
    */
   public static PPath createSquiggle(int numWiggles) {
      return createSquiggleStroke(numWiggles);
   }


   /**
    * Returns a squiggle as a stroke.
    * 
    * @param numWiggles how many "wiggles" (up and down strokes) the
    *                   squiggle will have
    */
   private static PPath createSquiggleStroke(int numWiggles) {
      
      final PPath squiggle = new PPath();
      squiggle.moveTo(0, SQUIGGLE_HEIGHT);

      for (int x = 1, y = 0; x <= numWiggles; x++) {
         squiggle.lineTo(x * SQUIGGLE_WIGGLE_WIDTH, y);
         if (y == 0) {
            y = SQUIGGLE_HEIGHT;
         }
         else {
            y = 0;
         }
      }
      
      return squiggle;
   }


   /**
    * Returns a node which contains squiggles with the specified lengths.
    */
   public static PNode createSquiggles(int[] lengths) {
      int totalWidth = 0;
      for (int i = 0; i < lengths.length; i++) {
         totalWidth += lengths[i] * SQUIGGLE_WIGGLE_WIDTH + SQUIGGLE_GAP_WIDTH;
      }      
      
      final PNode squiggles = new PNode();
      squiggles.setBounds(0, 0, totalWidth, SQUIGGLE_HEIGHT);
            
      int x = 0;
      for (int i = 0, n = lengths.length; i < n; i++) {
         final PPath squiggle = createSquiggleStroke(lengths[i]);
         squiggles.addChild(squiggle);
         squiggle.setOffset(x, 0);
         x += (SQUIGGLE_WIGGLE_WIDTH * lengths[i]) + SQUIGGLE_GAP_WIDTH;
      }
      return squiggles;
   }
   
   //===========================================================================

   /**
    * Returns a copy of the specified node. The copy uses only the nodes
    * that come with Piccolo. 
    */
   public static PNode getPureCopy(final PNode node) {
      final PNode clone;
      if (node instanceof PPath) {
         clone =
            new PPath((GeneralPath) ((PPath)node).getPathReference().clone());
         ((PPath)clone).setStrokePaint(((PPath)node).getStrokePaint());
      }
      else if (node instanceof DamaskPPath) {
         clone =
            new DamaskPPath(
               (GeneralPath) ((DamaskPPath)node).getPathReference().clone());
         ((DamaskPPath)clone).setStrokePaint(
            ((DamaskPPath)node).getStrokePaint());
      }
      else if (node instanceof PImage) {
         clone = new PImage();
         final Image nodeImage = ((PImage)node).getImage();
         if (nodeImage != null) {
            ((PImage)clone).setImage(nodeImage);
            ((PImage)clone).setAccelerated(((PImage)node).getAccelerated()); 
         }
      }
      else if (node instanceof PText) {
         clone = new PText();
         ((PText)clone).setText(((PText)node).getText());
         ((PText)clone).setFont(((PText)node).getFont());
      }
      else {
         clone = new PNode();
      }
      clone.setPaint(node.getPaint());
      clone.setBounds(node.getBounds());
      clone.setTransform(node.getTransform());
      clone.setVisible(node.getVisible());
   
      for (Iterator i = node.getChildrenIterator(); i.hasNext();) {
         final PNode child = (PNode)i.next();
         if (!(child instanceof PHandle || child instanceof Response.HotSpot)) {
            clone.addChild(getPureCopy(child));
         }
      }
   
      return clone;
   }

   //===========================================================================
   
   /**
    * Returns the bounding box of the specified piece of text when rendered.
    */
   public static Rectangle2D getRenderedTextBounds(
      final String text,
      final int size) {

      pText.setText(text);
      DamaskAppUtils.setFontSize(pText, size);
      return pText.getBounds();
   }

   
   /**
    * Returns the default font used for labels.
    */
   public static Font getDefaultFont() {
      return PText.DEFAULT_FONT;
   }


   /**
    * Sets the font size for the entire specified text.
    */
   public static void setFontSize(final PText text, final int size) {
      text.setFont(text.getFont().deriveFont((float)size));
   }


   /**
    * Returns the font size of the specified text at the specified position, or
    * -1 if the specified text is not styled. 
    */
   public static int getFontSize(final PStyledText text, final int pos) {
      final Document document = text.getDocument();
      if (document instanceof StyledDocument) {
         final StyledDocument styledDoc = (StyledDocument)document;
         final Element charElement = styledDoc.getCharacterElement(pos);
         final Font font = styledDoc.getFont(charElement.getAttributes());
         return font.getSize();
      }
      return -1;
   }


   /**
    * Sets the font size for the entire specified text.
    */
   public static void setFontSize(final PStyledText text, final int size) {
      final Document document = text.getDocument();
      if (document instanceof StyledDocument) {
         final MutableAttributeSet as = new SimpleAttributeSet();
         StyleConstants.setFontSize(as, size);

         ((StyledDocument)document).setParagraphAttributes(
            0,
            document.getLength(),
            as,
            false);
         text.syncWithDocument();
      }
   }


   /**
    * Sets the font for the entire specified text.
    */
   public static void setFont(final PStyledText text, final Font font) {
      final Document document = text.getDocument();
      if (document instanceof StyledDocument) {
         final MutableAttributeSet as = new SimpleAttributeSet();
         StyleConstants.setFontFamily(as, font.getFamily());
         StyleConstants.setFontSize(as, font.getSize());

         ((StyledDocument)document).setParagraphAttributes(
            0,
            document.getLength(),
            as,
            false);
         text.syncWithDocument();
      }
   }


   /**
    * Sets the contents of the specified text to the specified string.
    */
   public static void setText(final PStyledText text, final String string) {
      try {
         final Document document = text.getDocument();
         document.remove(0, document.getLength());
         document.insertString(0, string, null);
         text.syncWithDocument();
      }
      catch (BadLocationException e) {
         // should never happen
         DamaskAppExceptionHandler.log(e);
      }
   }
   
   //===========================================================================

   /**
    * Returns whether the program is using the system's look and feel.
    */
   public static boolean isUsingSystemLookAndFeel() {
      return UIManager.getSystemLookAndFeelClassName().equals(
         UIManager.getLookAndFeel().getClass().getName());
   }

   /**
    * Returns whether this program is running on Mac OS X.
    */
   public static boolean isMac() {
      return System.getProperty("mrj.version") != null; 
   }
   
   
   /**
    * Returns whether this program is running on any version of Windows.
    */
   public static boolean isWindows() {
      return System.getProperty("os.name").startsWith("Windows"); 
   }
   
   
   /**
    * Returns whether this program is running on Windows XP, Windows Server
    * 2003, or above (i.e., Windows NT 5.1 or above).
    */
   public static boolean isWindowsXP() {
      if (isWindows()) {
         final String versionStr = System.getProperty("os.version");
         final String[] versionArray = versionStr.split("\\.");
         if (versionArray.length >= 2) {
            try {
               final int majorVersion = Integer.parseInt(versionArray[0]);
               final int minorVersion = Integer.parseInt(versionArray[1]);
               return ((majorVersion >= 5) && (minorVersion >= 1));
            }
            catch (NumberFormatException e) {
               return false;
            }
         }
         else {
            return false;
         }
      }
      else {
         return false;
      }
   }


   //===========================================================================
   
   /**
    * Returns the directory that user-specific application data is in, creating
    * it if necessary.
    */
   public static File getUserDirectory() {
      String fileName = System.getProperty("user.home");

      if (isWindows()) {
         fileName += File.separator + "Application Data" + File.separator +
                     "Damask" + File.separator;
      }
      else {
         fileName += File.separator + ".damask" + File.separator;
      }

      final File path = new File(fileName);
      if (!path.isDirectory()) {
         path.mkdirs();
      }
      return path;
   }
   
   //---------------------------------------------------------------------------

   private static final Icon backIcon;
   private static final Icon forwardIcon;
   private static final Icon backDisabledIcon;
   private static final Icon forwardDisabledIcon;
   private static final Icon backRolloverIcon;
   private static final Icon forwardRolloverIcon;

   static {
      final String platformName;
      if (DamaskAppUtils.isUsingSystemLookAndFeel()) {
         if (DamaskAppUtils.isMac()) {
            platformName = "mac";
         }
         else if (DamaskAppUtils.isWindows()) {
            if (DamaskAppUtils.isWindowsXP()) {
               platformName = "win_xp";
            }
            else {
               platformName = "win";
            }
         }
         else {
            platformName = "java";
         }
      }
      else {
         platformName = "java";
      }

      final Toolkit tk = Toolkit.getDefaultToolkit();

      backIcon =
         new ImageIcon(tk.getImage(
            DamaskApp.class.getResource(
               "images/run/" + platformName + "/normal/back.png")));

      forwardIcon =
         new ImageIcon(tk.getImage(
            DamaskApp.class.getResource(
               "images/run/" + platformName + "/normal/forward.png")));
      
      {
         final URL backDisabledURL =
            DamaskApp.class.getResource(
               "images/run/" + platformName + "/disabled/back.png");
         if (backDisabledURL == null) {
            backDisabledIcon = null;
         }
         else {
            backDisabledIcon = new ImageIcon(tk.getImage(backDisabledURL));
         }
      }

      {      
         final URL forwardDisabledURL =
            DamaskApp.class.getResource(
               "images/run/" + platformName + "/disabled/forward.png");
         if (forwardDisabledURL == null) {
            forwardDisabledIcon = null;
         }
         else {
            forwardDisabledIcon = new ImageIcon(tk.getImage(forwardDisabledURL));
         }
      }

      {
         final URL backRolloverURL =
            DamaskApp.class.getResource(
               "images/run/" + platformName + "/rollover/back.png");
         if (backRolloverURL == null) {
            backRolloverIcon = null;
         }
         else {
            backRolloverIcon = new ImageIcon(tk.getImage(backRolloverURL));
         }
      }

      {      
         final URL forwardRolloverURL =
            DamaskApp.class.getResource(
               "images/run/" + platformName + "/rollover/forward.png");
         if (forwardRolloverURL == null) {
            forwardRolloverIcon = null;
         }
         else {
            forwardRolloverIcon = new ImageIcon(tk.getImage(forwardRolloverURL));
         }
      }
   }
   

   //---------------------------------------------------------------------------

   /**
    * Creates a cursor from the specified file name.
    */
   public static Cursor createCursor(
      final String fileName,
      final Point hotSpot,
      final String name) {

      try {
         final BufferedImage image =
            ImageIO.read(
               DamaskApp.class.getResource("images/cursors/" + fileName));

         final Toolkit tk = Toolkit.getDefaultToolkit();

         final Dimension cursorSize =
            tk.getBestCursorSize(image.getWidth(), image.getHeight());

         final int cursorWidth = cursorSize.width;
         final int cursorHeight = cursorSize.height;
         
         if ((cursorWidth == 0) && (cursorHeight == 0)) {
            return Cursor.getDefaultCursor();
         }
         else {
            final BufferedImage cursorImage;
            
            if ((cursorWidth > image.getWidth())
               || (cursorHeight > image.getHeight())) {

               cursorImage =
                  new BufferedImage(
                     cursorWidth,
                     cursorHeight,
                     BufferedImage.TYPE_INT_ARGB);
               //try TYPE_INT_ARGB_PRE
               final Graphics2D g = cursorImage.createGraphics();

               // Draw the icon on top of the sized transparent
               // BufferedImage, using sizedTransBim's Graphics object
               g.drawImage(image, 0, 0, null);
               g.dispose();
            }
            else {
               cursorImage = image;
            }
            
            return tk.createCustomCursor(cursorImage, hotSpot, name);
         }
      }
      catch (IOException e) {
         return Cursor.getDefaultCursor();
      }
   }
   
   /**
    * Creates a Back button with the proper icons with the specified
    * action.
    */
   public static JButton createBackButton(final Action action) {
      final JButton backButton = new JButton(action);
      backButton.setIcon(backIcon);
      if (backRolloverIcon != null) {
         backButton.setRolloverIcon(backRolloverIcon);
      }
      if (backDisabledIcon != null) {
         backButton.setDisabledIcon(backDisabledIcon);
      }
      if (!DamaskAppUtils.isWindows()) {
         backButton.setVerticalTextPosition(SwingConstants.BOTTOM);
         backButton.setHorizontalTextPosition(SwingConstants.CENTER);
      }
      return backButton;
   }

   /**
    * Creates a Forward button with the proper icons with the specified
    * action.
    */
   public static JButton createForwardButton(final Action action) {
      final JButton forwardButton = new JButton(action);
      forwardButton.setIcon(forwardIcon);
      if (forwardRolloverIcon != null) {
         forwardButton.setRolloverIcon(forwardRolloverIcon);
      }
      if (forwardDisabledIcon != null) {
         forwardButton.setDisabledIcon(forwardDisabledIcon);
      }
      if (!DamaskAppUtils.isWindows()) {
         forwardButton.setVerticalTextPosition(SwingConstants.BOTTOM);
         forwardButton.setHorizontalTextPosition(SwingConstants.CENTER);
      }
      return forwardButton;
   }

   /**
    * Returns a list of pickable, selectable nodes on the specified canvas
    * at the specified point.
    */
   public static List/*<PNode>*/ getPickedNodes(
      final DamaskCanvas canvas,
      final Point2D pt) {
      
      final List/*<PNode>*/ pickedNodes = new ArrayList/*<PNode>*/();
      
      final Collection selectableParents =
         canvas.getSelectionEventHandler().getSelectableParents();
      
      final PNodeFilter filter =
         new DamaskAppUtils.PickableAndSelectableFilter(selectableParents, pt);
      
      for (Iterator parentsIt = selectableParents.iterator();
         parentsIt.hasNext();
         ) {
         final PNode parent = (PNode)parentsIt.next();
      
         if (parent instanceof PCamera) {
            for (int i = 0; i < ((PCamera)parent).getLayerCount(); i++) {
               ((PCamera)parent).getLayer(i).getAllNodes(filter, pickedNodes);
            }
         }
         else {
            parent.getAllNodes(filter, pickedNodes);
         }
      }
      return pickedNodes;
   }

   //-----------------------------------------------------------------
   
   /**
    * Returns the first point in the path iterator of the specified shape.
    */
   public static Point2D getFirstPoint(final Shape s) {
      return getEndPoints(s)[0];
   }
   
   /**
    * Returns the last point in the path iterator of the specified shape.
    */
   public static Point2D getLastPoint(final Shape s) {
      return getEndPoints(s)[1];
   }
   
   /**
    * Returns the first and last points in the path iterator of the
    * specified shape.
    * 
    * @return an array of two points -- the first is the first point and the
    * second is the last point
    */
   public static Point2D[] getEndPoints(final Shape s) {
      final Polygon2D poly =
         GeomLib.pathIteratorToPolygon2D(s.getPathIterator(IDENTITY_TRANSFORM));

      final Point2D endPoint;
      final Point2D startPoint =
         new Point2D.Float(poly.xpoints[0], poly.ypoints[0]);

      if (poly.isClosed()) {
         endPoint = (Point2D)startPoint.clone();
      }
      else {
         endPoint =
            new Point2D.Float(
               poly.xpoints[poly.npoints - 1],
               poly.ypoints[poly.npoints - 1]);
      }
      return new Point2D[] {startPoint, endPoint};
   }
   
   //-----------------------------------------------------------------
   
   private static final double ARROWHEAD_ANGLE = Math.PI / 4;
   private static final double ARROWHEAD_LENGTH = 8.0;
   private static final AffineTransform IDENTITY_TRANSFORM =
      new AffineTransform();
   
   /**
    * Given a GeneralPath, computes the endpoints of the two arrowhead line
    * segments and returns them as an array of Points.
    * 
    * @param path        the arrow stem
    * @param scaleFactor the factor by which to multiply the arrowhead length                      
    * @return            a Polygon [(x0, y0), (x1, y1), (x2, y2)], where                                     
    * <ul>
    * <li>(x0, y0) is the end point of the arrow stroke itself
    * <li>(x1, y1) is the end point of the arrowhead segment in the 
    *              clockwise direction        
    * <li>(x2, y2) is the end point of the arrowhead segment in the 
    *              counterclockwise direction
    * </ul>
    * 
    * Adapted from edu.berkeley.guir.denim.Arrow.computeArrowheadParams().
    */
   private static Polygon computeArrowheadParams(final Polygon2D polygon,
                                                 final double scaleFactor) {
      final Point last = new Point();
      final Point penult = new Point();
      final int x1, x2, x1Offset, x2Offset;
      int y1, y2;
      final double m1, m2, b1, b2;
      double th;
      
      // 1. Get last two points of the stroke      
      // HACK: currently using the last & 4th to last points to get
      // "best-fit" line for arrow
      last.x = (int) polygon.xpoints[polygon.npoints - 1];
      last.y = (int) polygon.ypoints[polygon.npoints - 1];
      if (polygon.npoints < 9) {
         penult.x = (int) polygon.xpoints[polygon.npoints - 2]; 
         penult.y = (int) polygon.ypoints[polygon.npoints - 2]; 
      }
      else {
         penult.x = (int) polygon.xpoints[polygon.npoints - 8]; 
         penult.y = (int) polygon.ypoints[polygon.npoints - 8];      
      }
         
      // 2. Get angle of the stroke w.r.t. the x-axis
      th = Math.atan((double)(last.y - penult.y) / (double)(last.x - penult.x));
      if (last.x > penult.x) {
         th = Math.PI + th;
      }
      if (last.x == penult.x) { // handle the case where arrow slope is infinity
         if (last.y > penult.y) {
            th = -Math.PI / 2.0;
         }
         else {
            th = Math.PI / 2.0;
         }
      }
      
      // 3. Determine x coordinates of arrowhead endpoints            
      x1Offset = (int) (ARROWHEAD_LENGTH * scaleFactor * Math.cos(th + ARROWHEAD_ANGLE));
      x2Offset = (int) (ARROWHEAD_LENGTH * scaleFactor * Math.cos(th - ARROWHEAD_ANGLE));
      x1 = last.x + x1Offset;
      x2 = last.x + x2Offset;
           
      // 4. Determine linear equations for arrowhead segments
      m1 = Math.tan(th + ARROWHEAD_ANGLE);
      m2 = Math.tan(th - ARROWHEAD_ANGLE);
      b1 = last.y - m1 * last.x;
      b2 = last.y - m2 * last.x;
      
      // 5. Get y values
      y1 = (int) (m1 * x1 + b1);
      y2 = (int) (m2 * x2 + b2);
   
      // 6. Handle case where the slope of an arrowhead is (close to) infinity
      if ((x1 == last.x && y1 == last.y) || m1 > 1000000.0 || m1 < -1000000.0) {
         if (last.y > penult.y) {
            y1 = (int) (last.y - ARROWHEAD_LENGTH * scaleFactor);
         }
         else {
            y1 = (int) (last.y + ARROWHEAD_LENGTH * scaleFactor);
         }
      }
      if ((x2 == last.x && y2 == last.y) || m2 > 1000000.0 || m2 < -1000000.0) {
         if (last.y > penult.y) {
            y2 = (int) (last.y - ARROWHEAD_LENGTH * scaleFactor);
         }
         else {
            y2 = (int) (last.y + ARROWHEAD_LENGTH * scaleFactor);
         }
      }
   
      final Polygon result = new Polygon();
      result.addPoint(last.x, last.y);
      result.addPoint(x1, y1);
      result.addPoint(x2, y2);
      
      return result;
   }

   /**
    * Draws a circle at the beginning and an arrowhead at the end of the
    * specified path within the specified paint context.
    */
   public static void drawArrowheads(
      final DamaskPPath damaskPPath,
      final PPaintContext paintContext) {
      
      drawArrowheads(
         damaskPPath,
         paintContext,
         damaskPPath.getStrokePaint(),
         damaskPPath.getStrokePaint(),
         damaskPPath.getStrokePaint(),
         damaskPPath.getStrokePaint());
   }
   

   /**
    * Draws a circle at the beginning and an arrowhead at the end of the
    * specified path within the specified paint context.
    */
   // Arrowhead-drawing code adapted from
   // edu.berkeley.guir.denim.Arrow.drawArrowheads().
   public static void drawArrowheads(
      final DamaskPPath damaskPPath,
      final PPaintContext paintContext,
      final Paint fillStartPaint,
      final Paint borderStartPaint,
      final Paint fillEndPaint,
      final Paint borderEndPaint) {
      
      final Graphics2D g2 = paintContext.getGraphics();
      final PCamera paintCamera = paintContext.getCamera();

      final GeneralPath path = damaskPPath.getPathReference();      
      final Stroke stroke = damaskPPath.getStroke();

      if (stroke != null) {
         g2.setStroke(stroke);
      }

      final double scale;
      if (paintCamera == null) {
         scale = 1.0;
      }
      else {
         scale = 1.0 / paintContext.getCamera().getViewScale();
      }
   
      // 1. Get the stroke points
      final Polygon2D polygon =
         GeomLib.pathIteratorToPolygon2D(
            path.getPathIterator(IDENTITY_TRANSFORM));

      assert polygon.npoints >= 2: "An arrow needs at least two points.";
   
      // 2. Draw a circle at the beginning of the arrow, to make it stand
      //    out.
      final int startCircleRadius = (int)(ARROWHEAD_LENGTH * scale);
      if (fillStartPaint != null) {
         g2.setPaint(fillStartPaint);
         g2.fillOval((int) polygon.xpoints[0] - startCircleRadius / 2,
                    (int) polygon.ypoints[0] - startCircleRadius / 2,
                    startCircleRadius,
                    startCircleRadius);
      }

      if (borderStartPaint != null) {
         g2.setPaint(borderStartPaint);
         g2.drawOval((int) polygon.xpoints[0] - startCircleRadius / 2,
                    (int) polygon.ypoints[0] - startCircleRadius / 2,
                    startCircleRadius,
                    startCircleRadius);
      }
   
      // 3. If this arrow is not a single-left-click arrow, then draw an icon to show the type
   /*      String eventType = getInputEventType();
         if (eventType != DenimIntrinsicComponent.LEFT_CLICK) {
            int x = (int) poly.xpoints[0] + 5;
            int y = (int) poly.ypoints[0];
            int w = (int) scale * 13;
            int h = (int) scale * 18;
         
            if (eventType == DenimIntrinsicComponent.LEFT_2CLICK) {
               g.drawImage(left2Img, x, y, w, h, null);
            }
            else if (eventType == DenimIntrinsicComponent.RIGHT_CLICK) {
               g.drawImage(right1Img, x, y, w, h, null);
            }
            else if (eventType == DenimIntrinsicComponent.RIGHT_2CLICK) {
               g.drawImage(right2Img, x, y, w, h, null);
            }
            else if (DenimIntrinsicComponent.compareEventTypes(DenimIntrinsicComponent.TIMER, eventType)) {
               Font origFont = g.getFont();
               Font newFont = origFont.deriveFont(origFont.getSize2D() *
                                                  (float)scale);
               g.setFont(newFont);
               g.drawString(eventType.substring(6) + " sec", x + 3, y - 3);
               g.setFont(origFont);
               //g.drawImage(timerImg, x, y, w, h, null);
            }
         }*/

      // 4. Compute the arrowhead parameters
      final Polygon arrowhead = computeArrowheadParams(polygon, scale);
   
      // 5. Draw the arrowheads
      if (fillEndPaint != null) {
         g2.setPaint(fillEndPaint);
         g2.fillPolygon(arrowhead);
      }

      if (borderEndPaint != null) {
         g2.setPaint(borderEndPaint);
         g2.drawPolygon(arrowhead);
      }
      
      //TODO: force repaint of the arrowhead region

      //If the arrow has an output event - draw it next to the arrow head.
//         String outputEvent = getOutputEventType();
//         if (outputEvent != null) {
//             g2.drawString(outputEvent,
//                          ((int) poly.xpoints[poly.npoints - 1]),
//                          ((int) poly.ypoints[poly.npoints - 1]));
//         }
   }

   //-----------------------------------------------------------------
   
   /**
    * Asks the user whether he or she wants to change the current device-type
    * layer in the specified layer.  
    * 
    * @return whether the user wants to change 
    */
   public static boolean askToChangeLayers(
      final DamaskLayer layer, final java.awt.Component parentComponent) {
      
      final DamaskLayer.DeviceTypeLayer deviceTypeLayer = 
         layer.getDeviceTypeLayer();
      
      final String currentLayerString;
      final String otherLayerString;
      if (deviceTypeLayer == DamaskLayer.DeviceTypeLayer.ALL) {
         currentLayerString = "All Devices";
         otherLayerString = "This Device";
      }
      else {
         currentLayerString = "This Device";
         otherLayerString = "All Devices";
      }
      
      final int result = JOptionPane.showConfirmDialog(
         parentComponent,
         "The object you tried to select is in the \"" + otherLayerString +
         "\" layer, but \"" + currentLayerString +
         "\" is the active layer.\nDo you want to change the active layer to \"" +
         otherLayerString + "\"?",
         "Damask",
         JOptionPane.YES_NO_OPTION);
      if (result == JOptionPane.YES_OPTION) {
         if (deviceTypeLayer == DamaskLayer.DeviceTypeLayer.DEVICE) {
            layer.setDeviceTypeLayer(DamaskLayer.DeviceTypeLayer.ALL);
         }
         else {
            layer.setDeviceTypeLayer(DamaskLayer.DeviceTypeLayer.DEVICE);
         }
      }
      return (result == JOptionPane.YES_OPTION);
   }

   /**
    * Adds commands to modify the specified select control so that it contains
    * items from the specified newItems array.
    */
   public static void addCommandsToModifySelectItemsToMacroCommand(
      final Select select,
      final DamaskCanvas canvas,
      final String[] newItems,
      final MacroCommand command,
      final boolean modifyVoiceText) {
      
      // Change the existing items in the select control, where the 
      // old and new items overlap.
      final Iterator it = select.getItems().iterator();
      int i = 0;
      int n = newItems.length;
      while ((i < n) && it.hasNext()) {
         System.out.println(i);
         final Select.Item item = (Select.Item)it.next();
         if (modifyVoiceText && select.getItems().size() == n) {
            System.out.println("prompt");
            command.addCommand(
               new SetVoicePromptTextCommand(item.getContent(), newItems[i]));
         }
         else {
            System.out.println("content");
            command.addCommand(
               new EditContentCommand(
                  item.getContent(),
                  newItems[i]));
         }
      
         command.addCommand(
            new SetContentDisplayModeCommand(
               item.getContent(),
               canvas.getDeviceType(),
               Content.TEXT));
         i++;
      }
   
      // If there are more items in the existing control than in the
      // new list, remove the extraneous items from the control.            
      if (i == n) {
         while (it.hasNext()) {
            final Select.Item item = (Select.Item)it.next();
            command.addCommand(new RemoveItemCommand(select, item));
         }
      }
         
      // If there are less items in the existing control than in the
      // new list, add new items to the control.            
      else {
         final Map/*<DeviceType, AffineTransform>*/ transforms =
            new HashMap();
            
         // Store the transform of the last item in the select control.
         // This is used as the basis for the transforms for the new
         // controls.
         if (i > 0) {
            final Select.Item lastSelectItem =
               (Select.Item)select.getItems().get(i - 1);
   
            for (Iterator deviceIt =
               select.getDeviceTypesVisibleTo().iterator();
               deviceIt.hasNext(); ) {
   
               final DeviceType deviceType = (DeviceType)deviceIt.next();
               final AffineTransform transform =
                  lastSelectItem.getTransform(deviceType);
               
               if (lastSelectItem.getBounds(deviceType) != null) {
                  transform.translate(
                     0, lastSelectItem.getBounds(deviceType).getHeight());
               }
               transforms.put(deviceType, transform);
            }
         }
         else {
            for (Iterator deviceIt =
               select.getDeviceTypesVisibleTo().iterator();
               deviceIt.hasNext(); ) {
   
               final DeviceType deviceType = (DeviceType)deviceIt.next();
               transforms.put(deviceType, new AffineTransform());
            }
         }
   
         // Add the new items               
         while (i < n) {
            final Select.Item newItem;
            final Content newContent =
               new Content(
                  ((DamaskLayer)canvas.getLayer())
                     .getDeviceTypeForNewElement(),
                  newItems[i]);
      
            if (select instanceof SelectOne) {
               newItem = new SelectOne.Item(newContent);
            }
            else {
               newItem = new SelectMany.Item(newContent);
            }
      
            final Rectangle2D newItemTextBounds =
               getRenderedTextBounds(
                  newItems[i],
                  getDefaultFont().getSize());
            final Rectangle2D newItemBounds =
               (Rectangle2D)newItemTextBounds.clone();
      
            newContent.setBounds(select.getDeviceType(), newItemBounds);
            newItem.setBounds(select.getDeviceType(), newItemBounds);
            
            // If the item being added is a radio button in other device
            // types, make sure the caption inset is correct
            for (Iterator deviceIt =
               select.getDeviceTypesVisibleTo().iterator();
               deviceIt.hasNext();
               ) {
   
               final DeviceType deviceType = (DeviceType)deviceIt.next();
               if (select.getStyle(deviceType) == Select.FULL) {
   
                  final PNode defaultView;
                  if (select instanceof SelectOne) {
                     defaultView = RadioButton.createTempView();
                  }
                  else {
                     defaultView = CheckBox.createTempView();
                  }
                  final Rectangle2D bounds = defaultView.getBounds();
                  final PPath captionPath = (PPath)defaultView.getChild(1);
   
                  final Rectangle2D captionPathBounds =
                     captionPath.getPathReference().getBounds2D();
                  final AffineTransform captionPathTransform = captionPath.getTransform();
   
                  final Rectangle2D captionPathBoundsInItemCoords =
                     GeomLib.transformRectangle(captionPathTransform, captionPathBounds);
   
                  newItem.getContent().setTransform(
                     deviceType,
                     captionPathTransform);
   
                  final double topInset =
                     captionPathBoundsInItemCoords.getY() - bounds.getY();
                  final double leftInset =
                     captionPathBoundsInItemCoords.getX() - bounds.getX();
                  final double bottomInset =
                     bounds.getMaxY() - captionPathBoundsInItemCoords.getMaxY();
                  final double rightInset =
                     bounds.getMaxX() - captionPathBoundsInItemCoords.getMaxX();
   
                  newItem.setContentInsets(
                     deviceType,
                     topInset,
                     leftInset,
                     bottomInset,
                     rightInset);
               }
            }
               
            // Set the transform of the new item
            for (Iterator deviceIt =
               select.getDeviceTypesVisibleTo().iterator();
               deviceIt.hasNext(); ) {
   
               final DeviceType deviceType = (DeviceType)deviceIt.next();
   
               final AffineTransform newTransform =
                  (AffineTransform)transforms.get(deviceType);
   
               newItem.setTransform(
                  deviceType,
                  new AffineTransform(newTransform));
   
               newTransform.translate(0, newItemBounds.getHeight());
            }
      
            command.addCommand(new AddItemCommand(select, newItem));
            i++;
         }
      }
   }
}
