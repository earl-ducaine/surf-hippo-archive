package edu.berkeley.guir.damask.component;

/** 
 * A <code>Insets2D</code> object represents the amount of space between
 * a component and its contained content.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-14-2004 James Lin
 *                               Created Insets2D.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-14-2004
 */
public class Insets2D implements Cloneable {
   private final double top;
   private final double left;
   private final double bottom;
   private final double right;

   /**
    * Creates and initializes a new Insets object with the specified top,
    * left, bottom, and right insets
    * @param  top      the inset from the top.
    * @param  left     the inset from the left.
    * @param  bottom   the inset from the bottom.
    * @param  right    the inset from the right.
    */
   public Insets2D(
      final double top,
      final double left,
      final double bottom,
      final double right) {

      this.top = top;
      this.left = left;
      this.bottom = bottom;
      this.right = right;
   }

    /**
     * Checks whether two insets objects are equal, which is true if the
     * value of the inset for each side is equal.
     */
   public boolean equals(Object obj) {
      if (obj instanceof Insets2D) {
         final Insets2D insets = (Insets2D)obj;
         return ((top == insets.top)
               && (left == insets.left)
               && (bottom == insets.bottom)
               && (right == insets.right));
      }
      return false;
   }

    /**
     * Returns the hash code for this Insets.
     */
   public int hashCode() {
      double sum1 = left + bottom;
      double sum2 = right + top;
      double val1 = sum1 * (sum1 + 1) / 2 + left;
      double val2 = sum2 * (sum2 + 1) / 2 + top;
      double sum3 = val1 + val2;
      return (int)(sum3 * (sum3 + 1) / 2 + val2);
   }


   public String toString() {
      return getClass().getName()
         + "[top="
         + top
         + ",left="
         + left
         + ",bottom="
         + bottom
         + ",right="
         + right
         + "]";
   }


   /**
    * Returns a copy of this object.
    */
   public Object clone() {
      try {
         return super.clone();
      }
      catch (CloneNotSupportedException e) {
         // this shouldn't happen, since we are Cloneable
         throw new InternalError("Object doesn't support Cloneable - yeah right");
      }
   }

   /**
    * Returns the inset from the top.
    * This value is added to the top of the contained content's bounds
    * to yield a new location for the top.
    */
   public double getTop() {
      return top;
   }

   /**
    * Returns the inset from the left.
    * This value is added to the left of the contained content's bounds
    * to yield a new location for the left.
    */
   public double getLeft() {
      return left;
   }
   
   /**
    * Returns the inset from the bottom.
    * This value is added to the bottom of the contained content's bounds
    * to yield a new location for the bottom.
    */
   public double getBottom() {
      return bottom;
   }

   /**
    * Returns the inset from the right.
    * This value is added to the right of the contained content's bounds
    * to yield a new location for the right.
    */
   public double getRight() {
      return right;
   }
}
