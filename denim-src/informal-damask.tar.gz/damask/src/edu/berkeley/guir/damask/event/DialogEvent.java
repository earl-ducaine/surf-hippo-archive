package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.dialog.Dialog;

/** 
 * An event that indicates that a dialog has been changed.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-10-2004 James Lin
 *                               Created PageEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-10-2004
 */
public class DialogEvent extends EventObject {

   private final Type eventType;   
   private final Object value;
   
   //===========================================================================

   public static class Type {
      private final String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type INITIAL_CONDITION_CHANGED =
      new Type("initial condition changed");

   //===========================================================================

   /**
    * Constructs a PageEvent, which gets fired when the template of a page is
    * changed.
    */
   public DialogEvent(
      final Dialog source,
      final Type eventType,
      final Object value) {

      super(source);
      this.eventType = eventType;
      this.value = value;
   }
   
   //===========================================================================

   /**
    * Returns the dialog affected by the event.
    */
   public Dialog getDialog() {
      return (Dialog)source;
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the value of the property being changed.
    */
   public Object getValue() {
      return value;
   }
}
