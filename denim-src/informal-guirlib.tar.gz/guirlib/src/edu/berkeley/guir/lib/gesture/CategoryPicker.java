package edu.berkeley.guir.lib.gesture;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;
import java.awt.event.*;
import java.awt.*;
import edu.berkeley.guir.lib.gesture.util.*;

/**
 * Emits ItemEvents when a category is selected or deselected.  The
 * item field is an Integer that indicates which category was
 * (de)selected.
 */
public class CategoryPicker extends Box implements ItemSelectable
{
  final static Dimension iconSize = new Dimension(20, 20);
  JCheckBox[] checkBoxes;
  protected EventListenerList itemListenerList = new EventListenerList();
  int numSelected;
  GestureSet gestureSet;
  Color[] colorScheme;
  BitSet categoryMask;
  
  public CategoryPicker(GestureSet gs, Color[] colorScheme)
  {
    super(BoxLayout.Y_AXIS);
    gestureSet = gs;
    this.colorScheme = colorScheme;
    categoryMask = Misc.not(new BitSet((gestureSet == null) ? 0 :
				       gestureSet.size()));
    buildUI();
  }

  public CategoryPicker(GestureSet gs)
  {
    this(gs, null);
  }

  void buildUI()
  {
    int numRows = gestureSet.size();
    checkBoxes = new JCheckBox[numRows];

    Border raisedBorder = BorderFactory.createRaisedBevelBorder();
    Border loweredBorder = BorderFactory.createLoweredBevelBorder();
    
    for (int i = 0; i < numRows; i++) {
      Color iconColor;
      if (colorScheme == null)
	iconColor = Color.black;
      else {
	iconColor = colorScheme[i % colorScheme.length];
      }
      checkBoxes[i] = new JCheckBox(((GestureContainer) gestureSet.
				     getChild(i)).getName(),
				    true);

      checkBoxes[i].setIcon(new SolidIcon(Color.black, iconSize,
					  raisedBorder));
      checkBoxes[i].setSelectedIcon(new SolidIcon(iconColor, iconSize,
						  loweredBorder));

      checkBoxes[i].addItemListener(new CheckBoxListener(i));
      add(checkBoxes[i]);
    }
    numSelected = numRows;
  }

  public void setCategorySelected(int categoryNum, boolean on)
  {
    checkBoxes[categoryNum].setSelected(on);
  }

  public boolean isCategorySelected(int categoryNum)
  {
    return checkBoxes[categoryNum].isSelected();
  }

  public int getNumSelected()
  {
    return numSelected;
  }
  
  public class CheckBoxListener implements ItemListener
  {
    int cbNum;

    CheckBoxListener(int n)
    {
      cbNum = n;
    }
    
    public void itemStateChanged(ItemEvent e)
    {
      if (e.getStateChange() == ItemEvent.SELECTED)
	numSelected++;
      else
	numSelected--;
      int stateChange = e.getStateChange();
      if (categoryMask != null) {
	switch (stateChange) {
	case ItemEvent.SELECTED:
	  categoryMask.set(cbNum);
	  break;
	case ItemEvent.DESELECTED:
	  categoryMask.clear(cbNum);
	  break;
	default:
	  System.err.println("gdt: error: Bogosity in CategoryPicker$CheckBoxListener");
	  break;
	}
      }
      updateCheckboxes();
      fireItemChange(ItemEvent.ITEM_STATE_CHANGED, cbNum, stateChange);
    }
  }
  
  public void addItemListener(ItemListener l)
  {
    itemListenerList.add(ItemListener.class, l);
  }

  public void removeItemListener(ItemListener l)
  {
    itemListenerList.remove(ItemListener.class, l);
  }

  protected void fireItemChange(int type, int categoryNum, int selectState)
  {
    ItemEvent event = null;
    Object[] listeners = itemListenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ItemListener.class) {
	if (event == null)
	  event = new ItemEvent(this, type, new Integer(categoryNum),
				selectState);
	((ItemListener)listeners[i+1]).itemStateChanged(event);
      }
    }
  }

  /**
   * Returns an array of Integers, the indices of the selected categories
   */
  public Object[] getSelectedObjects()
  {
    Object result[] = new Object[numSelected];
    int ri = 0;
    for (int i = 0; i < checkBoxes.length; i++) {
      if (checkBoxes[i].isSelected())
	result[ri++] = new Integer(i);
    }
    return result;
  }

  public BitSet getCategoryMask()
  {
    return categoryMask;
  }

  public void setCategoryMask(BitSet mask)
  {
    if (mask != categoryMask) {
      categoryMask = mask;
      updateCheckboxes();
    }
  }

  /** Return number of check boxes/categories */
  public int numCategories()
  {
    return checkBoxes.length;
  }

  /** update the checkboxes to reflect current selections */
  void updateCheckboxes()
  {
    int numBoxes = checkBoxes.length;
    for (int i = 0; i < numBoxes; i++) {
      JCheckBox cb = checkBoxes[i];
      if (categoryMask.get(i)) {
	// selected
	if (!cb.isSelected())
	  cb.setSelected(true);
	if (colorScheme != null) {
	  SolidIcon icon = (SolidIcon) cb.getSelectedIcon();
	  icon.setColor(colorScheme[i % colorScheme.length]);
	}
      }
      else {
	if (cb.isSelected())
	  cb.setSelected(false);
      }
      cb.repaint();
    }
  }
}
