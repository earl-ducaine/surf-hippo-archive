package edu.berkeley.guir.damask.view.nodes;

import java.awt.Dimension;
import java.awt.Point;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.visual.component.Label;
import edu.umd.cs.piccolo.PLayer;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * The title bar of a Damask window.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-01-2003 James Lin
 *                               Created DamaskPageTitle.
 *                    09-11-2003 James Lin
 *                               Renamed to PageViewTitle.
 *             2.0.0  10-30-2004 James Lin
 *                               Generalized and renamed to DamaskWindowTitle
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-01-2003
 */
public class DamaskWindowTitle extends PPath {
   public static final int DEFAULT_FONT_SIZE = 18;
   private static final int EMPTY_LABEL_WIDTH = 120;
   
   private Label titleLabel;
   
   private final int height;
   private PropertyChangeListener layerDetector = new LayerDetector();
   
   /**
    * Constructs a title bar for a page view.
    */
   public DamaskWindowTitle() {
      this(DEFAULT_FONT_SIZE);
      addInputEventListener(new BasicInputEventHandler());
   }
   
   /**
    * Constructs a title bar for a page view with the specified text size for
    * the title text.
    */
   public DamaskWindowTitle(final int textSize) {
      height =
         (int)DamaskAppUtils
            .getRenderedTextBounds("Page", textSize)
            .getHeight();
      
      // Listen for when this title bar or one of its ancestors is eventually
      // added to a layer. This is used to setup the sticky-z transform.
      addPropertyChangeListener(PNode.PROPERTY_PARENT, layerDetector);
      
      // Listen for when this title bar is added to a page view, and then
      // add the title content from the page view's model.
      addPropertyChangeListener(
         PNode.PROPERTY_PARENT,
         new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
               if (getParent() instanceof DamaskWindow) {
                  final Content titleContent =
                     ((DamaskWindow)getParent()).getTitleContent();
                  titleContent.setTextSize(
                     ((DamaskWindow)getParent()).getDeviceType(),
                     textSize);
                  titleLabel = new Label(titleContent);
                  titleLabel.setEmptySize(
                     new Dimension(EMPTY_LABEL_WIDTH, height));
                  titleLabel.setMovable(false);
                  titleLabel.setUseStickyZHandles(false);
                  addChild(titleLabel);
               }
            }
      });
   }
   
   /**
    * Returns the window this title bar belongs to.
    */
   public DamaskWindow getWindow() {
      if (getParent() instanceof DamaskWindow) {
         return (DamaskWindow)getParent();
      }
      else {
         return null;
      }
   }
   
   /**
    * Returns the device type of this object.
    */
   public DeviceType getDeviceType() {
      if (getParent() instanceof DamaskWindow) {
         return ((DamaskWindow)getParent()).getDeviceType();
      }
      else {
         return null;
      }
   }
   
   /**
    * Returns the height of the title bar.
    */
   public int getPixelHeight() {
      return height;
   }
   
   /**
    * Returns the label that contains the title.
    */
   public Label getLabel() {
      return titleLabel;
   }

   /**
    * Sets up the sticky-z transform for this title bar.
    */
   protected void setupStickyZ(final PLayer layer) {
      final double scale;
      if (layer instanceof DamaskLayer) {
         scale = ((DamaskLayer)layer).getPageTitleScale();
      }
      else {
         scale = 1;
      }
      
      if (layer.getCameraCount() > 0) {
         StickyTransformManager.setupStickyZ(
            this,
            layer.getCamera(0),
            new Point(0, 0),
            scale);
      }
      else {
         layer.addPropertyChangeListener(
            PLayer.PROPERTY_CAMERAS,
            new PropertyChangeListener() {
               public void propertyChange(PropertyChangeEvent evt) {
                  if (layer.getCameraCount() > 0) {
                     StickyTransformManager.setupStickyZ(
                        DamaskWindowTitle.this,
                        layer.getCamera(0),
                        new Point(0, 0),
                        scale);
                  }
               }
         });
      }
   }

   /**
    * Listens for changes in ancestors to figure out when this object is
    * attached to a layer. 
    */   
   private class LayerDetector implements PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent evt) {
         final PNode node = (PNode)evt.getSource();
         final PNode parent = node.getParent();
         if (parent != null) {
            node.removePropertyChangeListener(PNode.PROPERTY_PARENT, this);
            PNode n = parent;
            while ((n.getParent() != null) && !(n instanceof PLayer)) {
               n = n.getParent();
            }
            
            if (n instanceof PLayer) {
               setupStickyZ((PLayer)n);
            }
            else {
               n.addPropertyChangeListener(PNode.PROPERTY_PARENT, this);
            }
         }
      }
   }


   /**
    * Listens to mouse and key events in the canvas's main camera.
    */
   private class BasicInputEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         if (event.getComponent() instanceof DamaskCanvas) {
            ((DamaskCanvas)event.getComponent()).attachHandles(
               (DamaskWindow)getParent(),
               event.getCamera());
         }
      }
   }
}
