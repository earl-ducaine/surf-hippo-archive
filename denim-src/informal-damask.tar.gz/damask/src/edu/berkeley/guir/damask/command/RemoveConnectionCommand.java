package edu.berkeley.guir.damask.command;

import java.util.Iterator;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionGraph;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that removes a connection from an interaction graph.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  01-07-2004 James Lin
 *                               Created RemoveConnectionCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 01-07-2004
 */
public class RemoveConnectionCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final InteractionGraph graph;
   private Connection connection;
   
   private Trigger sourceLink = null;
   private Content sourceContent = null;

   private final boolean convertLinksToContent;
   
   private ConnectionInfo origConnectionInfo; 
   
   /**
    * Constructs the command.
    * 
    * @param connection the connection to remove
    */
   public RemoveConnectionCommand(final Connection connection, final boolean convertLinksToContent) {
      this.graph = connection.getInteractionGraph();
      this.convertLinksToContent = convertLinksToContent;
      this.connection = connection;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Remove connection " + connection;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      // Store info about the connection for undo.
      origConnectionInfo = new ConnectionInfo(connection);

      // Find out if the source of the connection is a hyperlink, and if so,
      // replace it with a label.
      if (connection instanceof NavConnection) {
         final NavConnection navConnection = (NavConnection)connection;
         sourceLink = null;
         for (Iterator i = connection.getDeviceTypesVisibleTo().iterator();
            i.hasNext();
            ) {

            final DeviceType deviceType = (DeviceType)i.next();
            final Control source = navConnection.getSource(deviceType);
            if (source instanceof Trigger) {
               final Trigger trigger = (Trigger)source;
               if (trigger.getStyle(deviceType) == Trigger.HYPERLINK) {
                  sourceLink = trigger;
               }
            }
         }
      }
      
      // Remove and dispose the connection.
      graph.remove(connection);
      connection.dispose();
      
      if (connection instanceof NavConnection) {
         // If the connection is a nav connection and its source is a hyperlink,
         // convert to content.
         if ((sourceLink != null) && convertLinksToContent) {
            sourceContent = (Content)sourceLink.getContent().clone();
            for (Iterator i = sourceLink.getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
               final DeviceType aDeviceType = (DeviceType)i.next();
               sourceContent.setTransform(aDeviceType, sourceLink.getTransform(aDeviceType));
            }
            sourceLink.getDialog().addControlAfter(
               sourceLink,
               sourceContent);
            sourceLink.getDialog().removeControl(sourceLink);
         }
      }
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      // Convert labels that were links back to links.
      if (sourceContent != null) {
         sourceContent.getDialog().addControlAfter(
            sourceContent,
            sourceLink);
         sourceContent.getDialog().removeControl(sourceContent);
      }
            
      connection = origConnectionInfo.createConnection();
      graph.add(connection);
   }
   
   /**
    * Returns the connection to be removed.
    */
   public Connection getConnection() {
      return connection;
   }
}
