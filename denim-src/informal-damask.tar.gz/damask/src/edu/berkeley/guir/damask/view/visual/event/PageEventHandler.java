package edu.berkeley.guir.damask.view.visual.event;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.event.InputEvent;
import java.awt.geom.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.command.AddDialogCommand;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.view.DamaskCanvas;
import edu.berkeley.guir.damask.view.DamaskLayer;
import edu.berkeley.guir.damask.view.nodes.DamaskWindowTitle;
import edu.berkeley.guir.damask.view.visual.VisualLayer;
import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolo.event.*;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.util.PBounds;

/** 
 * The event handler that handles the page creation tool.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-28-2003 James Lin
 *                               Created PageEventHandler
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-28-2003
 */
public class PageEventHandler extends PDragSequenceEventHandler {
   private static final String DEFAULT_TITLE = "Title";
   private static final Color DRAG_RECT_BORDER = new Color(0, 0, 0, 30);
	private static final Color PAGE_RECT_BORDER = new Color(0, 0, 0, 75);
   private static final Color PAGE_RECT_FILL = new Color(255, 255, 255, 100);

   // The rectangle that is currently getting created.
   private PPath dragRectangle;

   // The rectangle that represents the minimum size of a page
   private PPath pageRectangle;

   // The mouse press location for the current pressed, drag, release sequence.
   private Point2D pressPoint;

   // The current drag location.
   private Point2D dragPoint;

   // True if the drag started within the template pane.
   private boolean startedInTemplatePane;

   // The device type that we are adding the page to
   private DeviceType deviceType;

   public PageEventHandler() {
      setEventFilter(new PInputEventFilter(InputEvent.BUTTON1_MASK));
   }

   public void startDrag(PInputEvent e) {
      super.startDrag(e);        
   
      final VisualLayer layer =
         (VisualLayer) ((PCanvas) e.getComponent()).getLayer();

      // Initialize the locations.
      pressPoint = e.getPosition();
      dragPoint = pressPoint;
      
      startedInTemplatePane =
         layer.getTemplatePane().getFullBounds().contains(pressPoint);
      
      if (startedInTemplatePane) {
         return;
      }

      // Set the minimum-size rectangle to the proper size, depending
      // on the device type.
      pageRectangle = new PPath();
      pageRectangle.setStroke(
         new BasicStroke((float) (1 / e.getCamera().getViewScale())));
      pageRectangle.setPaint(PAGE_RECT_FILL);
      pageRectangle.setStrokePaint(PAGE_RECT_BORDER);
      layer.addChild(pageRectangle);

      // Create a new rectangle and add it to the canvas layer so that
      // we can see it.
      dragRectangle = new PPath();
      dragRectangle.setStroke(
         new BasicStroke((float) (1 / e.getCamera().getViewScale())));
      dragRectangle.setStrokePaint(DRAG_RECT_BORDER);
      layer.addChild(dragRectangle);

      deviceType = layer.getDeviceType();

      // Update the rectangles.
      updateRectangles();
   }

   public void drag(final PInputEvent e) {
      super.drag(e);

      if (startedInTemplatePane) {
         return;
      }

      // update the drag point location.
      dragPoint = e.getPosition();  
   
      // update the rectangle shape.
      updateRectangles();
   }

   public void endDrag(final PInputEvent e) {
      super.endDrag(e);

      if (startedInTemplatePane) {
         return;
      }

      final DamaskCanvas canvas = (DamaskCanvas)e.getComponent();  
      final DamaskLayer layer = (DamaskLayer)canvas.getLayer();
      layer.removeChild(dragRectangle);
      layer.removeChild(pageRectangle);

      // Create a dialog and page
      final Content dialogTitle =
         new Content(layer.getDeviceTypeForNewElement(), DEFAULT_TITLE);
      
      dialogTitle.setTextSize(layer.getDeviceTypeForNewElement(),
         DamaskWindowTitle.DEFAULT_FONT_SIZE);
      
      final AddDialogCommand command =
         new AddDialogCommand(
            canvas.getDocument().getGraph(),
            dialogTitle,
            layer.getDeviceType(),
            (layer.getDeviceTypeLayer() == DamaskLayer.DeviceTypeLayer.ALL),
            new Rectangle2D.Double(
               0,
               0,
               pageRectangle.getWidth(),
               pageRectangle.getHeight()),
            AffineTransform.getTranslateInstance(
               pageRectangle.getX(),
               pageRectangle.getY()));
      canvas.getDocument().getCommandQueue().doCommand(canvas, command);
   }  

   /**
    * Updates both the rectangle that is dragged by the user and the
    * eventual bounds of the page.
    */
   private void updateRectangles() {
      // create a new bounds that contains both the press and current
      // drag point.
      final PBounds dragRectBounds = new PBounds();
      dragRectBounds.add(pressPoint);
      dragRectBounds.add(dragPoint);
   
      // Set the drag rectangle's bounds.
      dragRectangle.setPathTo(dragRectBounds);

      // Set the page's bounds.
      final float newWidth = Math.max(
         (float)dragRectBounds.getWidth(), deviceType.getDefaultWidth());

      final float newHeight = Math.max(
         (float)dragRectBounds.getHeight(), deviceType.getDefaultHeight());

      pageRectangle.setPathToRectangle(
         (float)pressPoint.getX(),
         (float)pressPoint.getY(),
         newWidth,
         newHeight);
   }
}
