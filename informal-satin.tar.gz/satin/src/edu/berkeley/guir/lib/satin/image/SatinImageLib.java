package edu.berkeley.guir.lib.satin.image;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import edu.berkeley.guir.lib.awt.image.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;


/**
 * Utilities for SATIN and images.
 * <P>
 * This class uses software from 
 * <A HREF="http://www.acme.com/java">ACME labs</A>.
 * <P>
 * With the exception of the Acme software, this software is distributed 
 * under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <P>
 * As far as I can tell, here's the 
 * <A HREF="http://www.acm.com/java/software">Acme License</A>:
 * <PRE>
 * Copyright (C)1996,1998 by Jef Poskanzer <jef@acme.com>. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Visit the ACME Labs Java page for up-to-date versions of this and other
 * fine Java utilities: http://www.acme.com/java/
 * </PRE>
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 27 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.0.1, Aug 28 2000, JH
 *               Modified toImage() because all the GIF methods were moved to
 *               edu.berkeley.guir.lib.awt.image
 *             - SATIN-v2.1-1.0.2, Apr 05 2002, JH
 *               Fixed image creation offset in GraphicalObjects.
 *               
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>
 *          )
 * @since   JDK 1.3RC3
 * @version SATIN-v2.1-1.0.1, Aug 28 2000
 */
public class SatinImageLib 
	implements SatinConstants {

	//===========================================================================
	//===   CLASS VARIABLES   ===================================================

	static boolean flagDrawStrokeStartPoint = false;
   
	public static boolean imageConvertingRender = false;

	//-----------------------------------------------------------------

	public static void setDrawStrokeStartPoint(boolean flag) {
		 flagDrawStrokeStartPoint = flag;
	} // of method

	//===   CLASS VARIABLES   ===================================================
	//===========================================================================




	//===========================================================================
	//===   CONSTRUCTOR   =======================================================

	/**
	 * No instances allowed.
	 */
	private SatinImageLib() {
	} // of method

	//===   CONSTRUCTOR   =======================================================
	//===========================================================================




	//===========================================================================
	//===   IMAGE METHODS   =====================================================

	/**
	 * Convert a Graphical Object into an image.
	 *
	 * @param  gob is a Graphical Object.
	 * @return a buffered image with width and height in relative coordinates.
	 */
	public static BufferedImage toImage(GraphicalObject gob) {
		 assert gob != null: "null parameter";

		 LinkedList list = new LinkedList();
		 list.add(gob);
		 return (toImage(list));
	} // of method

    
	/**
	 * vector-based rendering 
	 */
	public static void renderRegion(Graphics2D g2d, Dimension size, Sheet sheet, Rectangle2D region) {

		imageConvertingRender = true;
		
		double w = size.getWidth();
		double h = size.getHeight();
				
		SatinGraphics graphics = new SatinGraphics(g2d);
		
		double sx = w/region.getWidth();
		double sy = h/region.getHeight();
		
		double s = sx<sy? sx: sy;
		
		AffineTransform trans = AffineTransform.getScaleInstance(s,s);

		trans.concatenate(AffineTransform.getTranslateInstance(
				  -region.getMinX(),-region.getMinY()));
		  
		graphics.setBackground(Color.white);//sheet.getBackground());
		graphics.clearRect(0, 0, (int)w,(int)h);
		
		
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
								 RenderingHints.VALUE_ANTIALIAS_ON);
		graphics.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
								 RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
		graphics.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,
								 RenderingHints.VALUE_COLOR_RENDER_QUALITY);
		graphics.setRenderingHint(RenderingHints.KEY_DITHERING,
								 RenderingHints.VALUE_DITHER_DISABLE);
		graphics.setRenderingHint(RenderingHints.KEY_RENDERING,
								 RenderingHints.VALUE_RENDER_QUALITY);
		graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
								 RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
								 RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
		graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
								 RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
		
		graphics.pushTransform(trans);
		
		sheet.render(graphics);
		
		graphics.popTransform();
		
		imageConvertingRender = false;
	}
	
	//-----------------------------------------------------------------
	
	static public BufferedImage toBufferedImage(Dimension size, Sheet sheet, Rectangle2D region, boolean isBW) {
		 
		imageConvertingRender = true;
		
		double w = size.getWidth();
		double h = size.getHeight();
		
		BufferedImage image;
		
		if(isBW)
		{
			image = new BufferedImage((int)w, (int)h, BufferedImage.TYPE_BYTE_INDEXED);
		}
		else
		{
			image = new BufferedImage((int)w, (int)h, BufferedImage.TYPE_INT_RGB);
		}
		
		Graphics2D g2d = image.createGraphics();
		
		SatinGraphics graphics = new SatinGraphics(g2d);
		
		// from Topiary		

		double sx = w/region.getWidth();
		double sy = h/region.getHeight();
		
		double s = sx<sy? sx: sy;
		
		AffineTransform trans = AffineTransform.getScaleInstance(s,s);

		trans.concatenate(AffineTransform.getTranslateInstance(
				  -region.getMinX(),-region.getMinY()));
		  
		graphics.setBackground(Color.white);//sheet.getBackground());
		graphics.clearRect(0, 0, (int)w, (int)h);
	/*	
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
								 RenderingHints.VALUE_ANTIALIAS_ON);
		graphics.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
								 RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
		graphics.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,
								 RenderingHints.VALUE_COLOR_RENDER_QUALITY);
		graphics.setRenderingHint(RenderingHints.KEY_DITHERING,
								 RenderingHints.VALUE_DITHER_DISABLE);
		graphics.setRenderingHint(RenderingHints.KEY_RENDERING,
								 RenderingHints.VALUE_RENDER_QUALITY);
		graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
								 RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
								 RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
		graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
								 RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
		*/
		graphics.pushTransform(trans);
		
		sheet.render(graphics);
		
		graphics.popTransform();
		
		g2d.dispose();
		
		imageConvertingRender = false;
		
		return image;
	}
    
	//-----------------------------------------------------------------
    

	/**
	 * Convert a List of Graphical Objects into an image.
	 *
	 * @param  list is a list of Graphical Objects.
	 * @return a buffered image with width and height in relative coordinates.
	 */
	public static BufferedImage toImage(java.util.List list) {
   	
		 imageConvertingRender = true;
   	   
		 Iterator        it;
		 GraphicalObject gob;
		 Rectangle2D     bounds       = null;   // bounds of list of gobs
		 Rectangle2D     boundsTmp;
		 int             hackWidth    = 1;      // fudge factors
		 int             hackHeight   = 1;      // fudge factors
		 int             maxLineWidth = 0;      // widest linewidth

		 //// 1. Calculate bounds of all gobs.
		 it = list.iterator();
		 while (it.hasNext()) {
			  gob          = (GraphicalObject) it.next();
			  boundsTmp    = gob.getBounds2D(COORD_REL);
			  maxLineWidth = (int) Math.max(maxLineWidth,
													  gob.getStyleRef().getLineWidth());
			  if (bounds == null) {
					bounds = boundsTmp;
			  }
			  else {
					Rectangle2D.union(bounds, boundsTmp, bounds);
			  }
		 }

		 //// 2. Create an image of the right size.
		 int width  = (int) bounds.getWidth()  + hackWidth  + 2*maxLineWidth;
		 int height = (int) bounds.getHeight() + hackHeight + 2*maxLineWidth; 

		 //// 2.1. Modify image size slightly for start dot.
		 if (flagDrawStrokeStartPoint == true) {
			  maxLineWidth += 5;
			  width        += 5;
			  height       += 5;
		 }

		 BufferedImage bimg   = new BufferedImage(width, height,
								BufferedImage.TYPE_INT_ARGB);
		  
		 SatinGraphics sg     = new SatinGraphics(bimg.createGraphics());
         sg.setColor(Color.white);
         sg.fillRect(0,0,bimg.getWidth(),bimg.getHeight());
		 sg.clipRect(0, 0, width, height);

		 //// 3. Prepare to render.
		 it = list.iterator();
		 while (it.hasNext()) {
			  gob = (GraphicalObject) it.next();

			  sg.pushStyle(gob.getStyleRef());
			  sg.pushTransform(gob.getTransformRef());
			  sg.pushTransform(AffineTransform.getTranslateInstance(
													  -bounds.getX() + maxLineWidth,
													  -bounds.getY() + maxLineWidth));
			  gob.render(sg);

			  //// 3.1. Special case for strokes.
			  if (flagDrawStrokeStartPoint == true && gob instanceof TimedStroke) {
					TimedStroke stk = (TimedStroke) gob;
					Point2D     pt  = stk.getStartPoint2D(COORD_LOCAL);
					sg.setColor(gob.getStyleRef().getDrawColor());
					sg.fillOval((int) pt.getX() - 5, (int) pt.getY() - 5, 10, 10);
			  }

			  sg.popTransform();
			  sg.popTransform();
			  sg.popStyle();
		 }
       
		 imageConvertingRender = false;

		 //// 4. Return.
		 return (bimg);
	} // of method
   
	//-----------------------------------------------------------------

	/**
	 * Convert an Image into a GIF file. This method uses software from 
	 * <A HREF="http://www.acme.com/java">ACME labs</A>.
	 */
	public static void toGif(Image img, OutputStream out)
		throws IOException {

		ImageLib.toGif(img, out);
		out.close();
	}
	
	public static void toJPeg(Image img, OutputStream out)
		throws IOException {
	
		ImageLib.toJPeg(img, out);
		out.close();
	}
			

	//===   IMAGE METHODS   =====================================================
	//===========================================================================




	//===========================================================================
	//===   SELF-TESTING MAIN   =================================================

	public static void main(String[] argv) 
		throws FileNotFoundException, IOException {

		FileOutputStream fout = new FileOutputStream("fos.gif");
		JFrame      f = new JFrame();
		TimedStroke stk2;

		stk2 = new TimedStroke();
		stk2.addPoint(4       ,       12);
		stk2.addPoint(5       ,       40);
		stk2.addPoint(3       ,       68);
		stk2.addPoint(1       ,       88);
		stk2.addPoint(1       ,       104);
		stk2.addPoint(2       ,       115);
		stk2.addPoint(6       ,       117);
		stk2.addPoint(25      ,       114);
		stk2.addPoint(56      ,       106);
		stk2.addPoint(77      ,       101);
		stk2.addPoint(96      ,       99);
		stk2.addPoint(109     ,       99);
		stk2.addPoint(111     ,       89);
		stk2.addPoint(109     ,       67);
		stk2.addPoint(114     ,       43);
		stk2.addPoint(117     ,       26);
		stk2.addPoint(118     ,       16);
		stk2.addPoint(115     ,       6);
		stk2.addPoint(108     ,       1);
		stk2.addPoint(99      ,       0);
		stk2.addPoint(67      ,       4);
		stk2.addPoint(34      ,       11);
		stk2.addPoint(13      ,       17);
		stk2.addPoint(3       ,       20);
		stk2.addPoint(0       ,       23);

		ImageIcon icon = new ImageIcon(toImage(stk2));

		f.getContentPane().add(new JLabel(icon));
		f.setSize(500, 500);
		f.setVisible(true);
      
//		  toGif(toImage(stk2), fout);

	} // of method

	//===   SELF-TESTING MAIN   =================================================
	//===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User 
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/


