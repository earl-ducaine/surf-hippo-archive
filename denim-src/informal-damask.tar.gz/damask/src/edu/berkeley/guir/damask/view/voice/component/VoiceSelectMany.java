package edu.berkeley.guir.damask.view.voice.component;

import java.util.*;

import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.component.SelectMany;
import edu.berkeley.guir.damask.event.ElementContainerEvent;
import edu.berkeley.guir.damask.event.ElementContainerListener;
import edu.umd.cs.piccolo.PNode;

/** 
 * A view of a select-many control.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  08-15-2004 James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public class VoiceSelectMany extends VoiceControl {
   private final Map/*<SelectMany.Item, CheckBox>*/ views =
      new HashMap/*<SelectMany.Item, CheckBox>*/();
   private final SelectManyHandler selectManyHandler = new SelectManyHandler();
   private boolean childrenSelectable = true;

   /**
    * Constructs a view of the specified select-many control.
    */
   public VoiceSelectMany(final SelectMany selectMany) {
      super(selectMany);
      selectMany.addElementContainerListener(selectManyHandler);
      super.setSelectable(false);
   }
   
   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      for (Iterator i = ((SelectMany)getModel()).getItems().iterator();
         i.hasNext();
         ) {
         final SelectMany.Item selectManyItem = (SelectMany.Item)i.next();
         final VoiceSelectManyItem voiceSelectManyItem =
            new VoiceSelectManyItem(selectManyItem);
         
         addChild(voiceSelectManyItem);
         views.put(selectManyItem, voiceSelectManyItem);
      }
   }

   
   // Overrides method in parent class.
   public void dispose() {
      super.dispose();
      ((SelectMany)getModel()).removeElementContainerListener(selectManyHandler);
   }


   // Overrides method in parent class.
   public void setSelectable(boolean flag) {
      childrenSelectable = flag;
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final VoiceSelectManyItem item = (VoiceSelectManyItem)i.next();
         item.setSelectable(flag);
      }
   }


   // Overrides method in ancestor class.
   public void setPickable(boolean flag) {
      super.setPickable(flag);
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final VoiceSelectManyItem item = (VoiceSelectManyItem)i.next();
         item.setPickable(flag);
      }
   }
   

   /** 
    * Handles element container events.
    */
   public class SelectManyHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         final SelectMany.Item selectManyItem = (SelectMany.Item)e.getElement();
         final VoiceSelectManyItem voiceSelectManyItem =
            new VoiceSelectManyItem(selectManyItem);
         
         addChild(voiceSelectManyItem);
         voiceSelectManyItem.setSelectable(childrenSelectable);
         voiceSelectManyItem.setPickable(getPickable());
         views.put(selectManyItem, voiceSelectManyItem);
      }
   
      public void elementRemoved(ElementContainerEvent e) {
         final InteractionElement element = e.getElement();
         final PNode elementView = (PNode)views.get(element);
   
         elementView.removeFromParent();
         views.remove(element);
      }
   }
}
