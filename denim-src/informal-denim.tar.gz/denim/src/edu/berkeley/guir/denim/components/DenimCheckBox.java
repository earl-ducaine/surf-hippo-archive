package edu.berkeley.guir.denim.components;

import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.denim.DenimText;
import edu.berkeley.guir.denim.toolbox.RubberStamp;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import javax.swing.SwingUtilities;

import edu.berkeley.guir.denim.CaptionedGraphicalObject;
import edu.berkeley.guir.denim.DenimText;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

/**
 * The definition of a check box for DENIM designs. This is a built-in
 * component.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-26-2003  James Lin
 *                                Created DenimCheckBox
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 02-26-2003
 */

public class DenimCheckBox extends DenimIntrinsicComponent
{

	//===========================================================================
	//===   CONSTANTS   =========================================================

	//===   CONSTANTS   =========================================================
	//===========================================================================

	final static GraphicalObjectCollection mStateCollection;
    final static long checkedID = 13;
    final static long uncheckedID = 11;
    final static long checkboxID = 17;
	
	static {
		mStateCollection = new GraphicalObjectCollectionImpl();
		final Patch checked;
		final Patch unchecked;

		// unchecked
		unchecked = new PatchImpl(new Rectangle2D.Double(0, 0, 30, 30));
		unchecked.getStyleRef().setDrawColor(new Color(0, 0, 0, 0));
		unchecked.getStyleRef().setFillColor(new Color(0, 0, 0, 0));
		unchecked.getStyleRef().setLineWidth(1.0f);

		TimedStroke checkBoxBorder =
			new TimedStroke(new Rectangle2D.Double(0, 7.5, 15, 15));
		checkBoxBorder.getStyleRef().setDrawColor(Color.BLACK);
		checkBoxBorder.getStyleRef().setLineWidth(1.0f);
		unchecked.add(checkBoxBorder);

		// checked
		//	checked = (Patch)unchecked.clone();
		checked = new PatchImpl(new Rectangle2D.Double(0, 0, 30, 30));
		checked.getStyleRef().setDrawColor(new Color(0, 0, 0, 0));
		checked.getStyleRef().setFillColor(new Color(0, 0, 0, 0));
		checked.getStyleRef().setLineWidth(1.0f);

		checkBoxBorder =
			new TimedStroke(new Rectangle2D.Double(0, 7.5, 15, 15));
		checkBoxBorder.getStyleRef().setDrawColor(Color.BLACK);
		checkBoxBorder.getStyleRef().setLineWidth(1.0f);
		checked.add(checkBoxBorder);

		//checked.getStyleRef().setDrawColor(Color.BLACK);
		//checked.getStyleRef().setFillColor(new Color(0, 0, 0, 50));
		//checked.getStyleRef().setLineWidth(1.0f);
		TimedStroke ts1 = new TimedStroke(new Line2D.Double(0, 7.5, 15, 22.5));
		TimedStroke ts2 = new TimedStroke(new Line2D.Double(15, 7.5, 0, 22.5));
		Style style = ts1.getStyle();
		style.setDrawColor(Color.BLACK);
		style.setLineWidth(1.0f);
		ts1.setStyle(style);
		ts2.setStyle(style);
		checked.add(ts1, KEEP_REL_POS);
		checked.add(ts2, KEEP_REL_POS);

        unchecked.setUniqueID(uncheckedID);
        checked.setUniqueID(checkedID);
        
		mStateCollection.add(0, unchecked);
		mStateCollection.add(1, checked);
	}

	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	/**
	 * Create a Denim button.
	 */
	DenimCheckBox()
	{
		super();

		name = "Check Box";
		stamp = new RubberStamp("check_box.gif", this);
        
        this.setUniqueID(checkboxID);
		
	}


	//===   CONSTRUCTORS   ======================================================
	//===========================================================================

	//===========================================================================
	//===   COMPONENT METHODS   =================================================

	/**
	 * Create a new instance of a check box, for use in a Denim storyboard.
	 *
	 * @param border the border of the check box
	 * @param caption the caption of the check box
	 */
	public DenimComponentInstance newInstance(
		TimedStroke border,
		DenimText caption)
	{
		DenimComponentInstance instance =
			new DenimCheckBoxInstance(this, border, caption);
		instances.add(instance);
		return instance;
	}

	//-----------------------------------------------------------------

	/**
	 * Create a new instance of a check box, for use in a Denim storyboard.
	 */
	public DenimComponentInstance newInstance()
	{
		DenimComponentInstance instance = new DenimCheckBoxInstance(this);
		instances.add(instance);
		return instance;
	}

	//-----------------------------------------------------------------

	/**
	 * Create a new instance of a check box.
	 *
	 * Called only by DOMUtils.createCheckBoxFromDOMElement()
	 */
	public DenimComponentInstance newInstance(
		Rectangle2D bounds,
		boolean selected,
		TimedStroke checkBoxBorder,
		DenimText caption,
		boolean createdByStamp)
	{
		DenimComponentInstance instance =
			new DenimCheckBoxInstance(
				this,
				bounds,
				selected,
				checkBoxBorder,
				caption,
				createdByStamp);
		instances.add(instance);
		return instance;
	}
    
   public static boolean isSelected(GraphicalObject obj) {
       if(obj.equals(mStateCollection.get(0)))
       {
           return false;
       }
       else
       {
           return true;
       }
   }

	//===   COMPONENT METHODS   =================================================
	//===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2003 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
