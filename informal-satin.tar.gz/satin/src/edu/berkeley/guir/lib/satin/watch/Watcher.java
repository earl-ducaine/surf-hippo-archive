//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.watch;

import java.io.Serializable;

/**
 * This interface is a replacement for Observer, because Observable is a
 * class instead of an interface.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 08 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public interface Watcher 
   extends Serializable, Cloneable {

   //===========================================================================
   //===   WATCHER INTERFACE   =================================================

   /**
    * Callback method for generic notifications. This typically won't be used.
    *
    * @see   Watchable#notifyWatchers()
    * @see   Watchable#notifyWatchers(java.lang.Object)
    * @param w   is the Watchable object notifying you.
    * @param arg is some agreed upon argument.
    */
   public void onNotify(Watchable w, Object arg);

   //-----------------------------------------------------------------

   /**
    * Callback method for notifications.
    *
    * @see   Watchable#notifyWatchersUpdate(Object)
    * @param w   is the Watchable object that has been updated.
    * @param arg is some agreed upon argument.
    */
   public void onUpdate(Watchable w, Object arg);

   //-----------------------------------------------------------------

   /**
    * Callback method for notifications.
    *
    * @see   edu.berkeley.guir.lib.satin.SatinConstants 
    * @see   Watchable#notifyWatchersUpdate(String, Object, Object)
    * @param w           is the Watchable object that has been updated.
    * @param strProperty is the name of the property to update.
    * @param oldVal      is the old value of the property. This should usually
    *                    be a clone of the old value, so that modifying this
    *                    value should have no effect. Whether this is a copy or
    *                    a reference should be defined in the SatinConstants
    *                    file.
    * @param newVal      is the new value of the property. This should usually
    *                    be a clone of the old value, so that modifying this
    *                    value should have no effect. However, don't clone
    *                    if it is prohibitively expensive to do so. Whether
    *                    this is a copy or a reference should be defined in the
    *                    SatinConstants file.
    */
   public void onUpdate(Watchable w, String strProperty, 
         Object oldVal, Object newVal);

   //-----------------------------------------------------------------

   /**
    * Callback method for notifications of deletions, that is this Graphical
    * Object has been deleted and you should remove it.
    *
    * @see   Watchable#notifyWatchersDelete()
    * @param w is the Watchable object to be deleted.
    */
   public void onDelete(Watchable w);

   //-----------------------------------------------------------------

   /**
    * A happy clone we are.
    */
   public Object clone();

   //===   WATCHER INTERFACE   =================================================
   //===========================================================================

} // of interface

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/

