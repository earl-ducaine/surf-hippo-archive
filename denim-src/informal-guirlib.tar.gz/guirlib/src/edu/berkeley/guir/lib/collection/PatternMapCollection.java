//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * A class for storing lists of objects and matching them.
 * <P>
 * Here's the basic idea. There are three different collections
 * in this object:
 * <UL>
 *    <LI>one for doing exact matches
 *    <LI>one for doing pattern matches
 *    <LI>one that matches all
 * </UL>
 * You can add in multiple objects for each key,
 * and then retrieve on those keys (which might retrieve more than what is
 * directly mapped, due to pattern matches and all matches).
 * <P>
 * This class is useful for doing listeners that are mapped onto
 * several different kinds of events. 
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Aug 31 2000 JIH
 */
public class PatternMapCollection {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    HashMapList mapKeys     = new HashMapList();  // map of exact matches
    HashMapList mapPatterns = new HashMapList();  // map of pattern matches
    List        listAll     = new LinkedList();   // list matching all

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   PATTERN MAP COLLECTION METHODS   ===================================

    /**
     * Map this object to the specified key.
     */
    public void add(String strKey, Object obj) {
        mapKeys.put(strKey, obj);
    } // of method

    /**
     * Remove the specified objects associated with a specific key.
     */
    public void remove(String strKey, Object obj) {
        mapKeys.removeKeyValue(strKey, obj);
    } // of method

    /**
     * Remove all objects associated with a specific key.
     */
    public void clear(String strKey) {
        mapKeys.removeKey(strKey);
    } // of method

    //----------------------------------------------------------------

    /**
     * Map this object to the specified key pattern.
     */
    public void addPattern(String strPattern, Object obj) {
        mapPatterns.put(strPattern, obj);
    } // of method

    /**
     * Remove the specified objects associated with a specific pattern.
     */
    public void removePattern(String strPattern, Object obj) {
        mapPatterns.removeKeyValue(strPattern, obj);
    } // of method

    /**
     * Remove all objects associated with a specific pattern.
     */
    public void clearPattern(String strPattern) {
        mapPatterns.removeKey(strPattern);
    } // of method

    //----------------------------------------------------------------

    /**
     * Map this object to all keys.
     */
    public void addToAll(Object obj) {
        listAll.add(obj);
    } // of method

    /**
     * Remove an object associated with "all".
     */
    public void removeFromAll(Object obj) {
        listAll.remove(obj);
    } // of method

    /**
     * Remove objects associated with "all".
     */
    public void clearAll() {
        listAll.clear();
    } // of method

    //----------------------------------------------------------------

    /**
     * Go thru each pattern and see if they match.
     */
    protected List getMatchingPatterns(String strKey) {
        List     list = new LinkedList();
        Iterator it   = mapPatterns.keySet().iterator();
        String   strPattern;
        List     listTmp;

        //// 1. Find all matching patterns.
        ////    Add associated objects to a running list.
        while (it.hasNext()) {
            strPattern = (String) it.next();
            if (strKey.matches(strPattern) == true) {
                listTmp = (List) mapPatterns.get(strPattern);
                list.addAll(listTmp);
            }
        }

        //// 2. Return.
        return (list);
    } // of method

    //----------------------------------------------------------------

    /**
     * Gets objects associated with this key, patterns matching this key,
     * and any objects mapping to all.
     */
    public List get(String strKey) {
        Collection col;
        List       listObjs = new LinkedList();

        //// 1. Get the normal keys.
        col = (Collection) mapKeys.get(strKey);
        listObjs.addAll(col);

        //// 2. Match the patterns.
        listObjs.addAll(getMatchingPatterns(strKey));

        //// 3. Add all.
        listObjs.addAll(listAll);

        //// 4. Return.
        return (listObjs);
    } // of method

    //===   PATTERN MAP COLLECTION METHODS   ===================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static PatternMapCollection getTestInstanceAAA() {
        PatternMapCollection e = new PatternMapCollection();
        e.add("key1", "norm1");
        e.add("key1", "norm2");
        e.add("key1", "norm3");
        e.add("key2", "norm4");
        e.add("key2", "norm5");
        e.add("key3", "norm6");
        e.add("key3", "norm7");

        e.addPattern(".*?1", "pattern1");  // basically *1
        e.addPattern("key?", "pattern2");
        e.addPattern("key?", "pattern3");

        e.addToAll("all1");
        e.addToAll("all2");

        return (e);
    } // of method

    //----------------------------------------------------------------

    private static void runTestAAA() {
        PatternMapCollection e = getTestInstanceAAA();

        System.out.println(e.get("key1"));
        System.out.println();

        System.out.println(e.get("key2"));
        System.out.println();

        System.out.println(e.get("key3"));
        System.out.println();

        System.out.println(e.get("blah"));
        System.out.println();
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) {
        runTestAAA();
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
