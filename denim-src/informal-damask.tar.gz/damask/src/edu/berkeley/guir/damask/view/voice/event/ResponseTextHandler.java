package edu.berkeley.guir.damask.view.voice.event;

import java.awt.Insets;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.*;

import javax.swing.JComponent;
import javax.swing.border.EmptyBorder;
import javax.swing.text.*;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.event.StyledTextEventHandler;
import edu.berkeley.guir.damask.view.visual.component.ComboBox;
import edu.berkeley.guir.damask.view.voice.VoiceCanvas;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.berkeley.guir.lib.util.StringLib;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PText;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolox.nodes.PStyledText;

/**
 * The event handler for entering text within a response.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-24-2004 James Lin
 *                               Separated from Response.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 */
public class ResponseTextHandler extends StyledTextEventHandler {
   private Response pickedResponse = null;
   private List/*<String>*/ pickedResponseText = new ArrayList/*<String>*/();
   private final PStyledText styledText = createText();
      
   public ResponseTextHandler() {
      super();
      init();
   }

   public ResponseTextHandler(JTextComponent editor) {
      super(editor);
      init();
   }

   private void init() {
      DamaskAppUtils.setFont(styledText, DamaskAppUtils.getDefaultFont());
   }
   
   public void mousePressed(PInputEvent event) {
      final PNode pickedNode = event.getPickedNode();

      final VoiceCanvas canvas = (VoiceCanvas)event.getComponent();
      canvas.setActiveTextHandler(this);

      if (pickedNode instanceof Response.TextGroup) {
         final PNode pickedTextGroup = pickedNode;
         pickedResponse = (Response)pickedTextGroup.getParent();
         
         final DamaskLayer layer = pickedResponse.getLayer();
         
//         if (((Control)pickedResponse.getModel()).getDeviceType() !=
//             layer.getDeviceTypeForNewElement()) {
//            if (!DamaskAppUtils.askToChangeLayers(layer,
//               (JComponent)event.getComponent())) {
//               pickedResponse = null;
//               return;
//            }
//         }

         pickedResponseText.clear();
         int numTextNodes = 0;
         PText firstTextNode = null;
         for (Iterator i = pickedTextGroup.getChildrenIterator(); i.hasNext(); ) {
            final PNode child = (PNode)i.next();
            if (child instanceof PText) {
               final PText textNode = (PText)child;
               numTextNodes++;
               if (numTextNodes == 1) {
                  firstTextNode = textNode;
               }
               pickedResponseText.add(textNode.getText());
            }
         }
         
         if (firstTextNode == null || firstTextNode.getText().trim().equals("")) {
            pickedResponseText.clear();
            pickedResponseText.add("Text");
         }
         
         DamaskAppUtils.setText(
            styledText, StringLib.join(pickedResponseText, "\n"));
         
         DamaskAppUtils.setFontSize(
            styledText, DeviceType.VOICE.getDefaultFontSize());
      
         final Insets pInsets = styledText.getInsets();

         layer.addChild(styledText);
         // will be removed in stopEditing()

         final PBounds textGroupGlobalBounds =
            pickedTextGroup.getFullBounds();
         pickedTextGroup.getParent().localToGlobal(textGroupGlobalBounds);
            
         final Point2D position = textGroupGlobalBounds.getOrigin();

         styledText.setOffset(
            position.getX() + Response.SYNC_BUTTON_WIDTH - pInsets.left,
            position.getY() - pInsets.top);
         
         startEditing(event, styledText);
      }
   }


   public void stopEditing() {
      if (canvas instanceof DamaskCanvas) {
         ((DamaskCanvas)canvas).setTextEditing(false);
      }
      
      if (editedText != null) {
         final DamaskCanvas damaskCanvas = (DamaskCanvas)canvas;
         final DamaskLayer damaskLayer = (DamaskLayer)canvas.getLayer();
         final Document editedDoc = editedText.getDocument(); 
         editedDoc.removeDocumentListener(docListener);
         editedText.setEditing(false);
         editedText.syncWithDocument();

         editedText.removeFromParent();
         
         try {
            final Control control = (Control)pickedResponse.getModel();
            final Control beforeControl =
               DamaskUtils.getPreviousLowLevelControl(
                  control.getPageRegion(damaskCanvas.getDeviceType()),
                  control);
            final MacroCommand command = new ModifyGraphMacroCommand();

            final String[] newTextArray =
               editedDoc.getText(0, editedDoc.getLength()).trim().split(
                  "\\n");
            
            if (newTextArray.length == 0) {
               // don't do anything
            }
            else if (newTextArray.length == 1) {
               if (newTextArray[0].equals("*")) {
                  // The new response should be either a text input
                  // or a text input followed by a trigger.
                  //
                  // If the original response represents a text input,
                  // then do nothing.
                  if (control instanceof TextInput) {
                  }
                  
                  // Otherwise, add a text box and trigger.
                  //
                  // The original response could represent:
                  // * A trigger
                  // * A trigger with a text input, select-one, or
                  //   select-many item before it
                  // * A select-one
                  // * A select-many item
                  // * Content
                  else if (control instanceof Trigger) {
                     command.addCommand(
                        new SetVoicePromptTextCommand(
                           ((Trigger)control).getContent(), "OK"));
                     
                     if (!(beforeControl instanceof TextInput)) {
                        command.addCommand(new AddControlCommand(
                           beforeControl,
                           new TextInput(
                              damaskLayer.getDeviceTypeForNewElement())));
                     }
                     
                     if ((beforeControl instanceof SelectOne) ||
                         (beforeControl instanceof SelectMany.Item)) {
                          DamaskUtils
                          .addCommandsForRemovingControlToMacroCommand(
                             command, beforeControl);
                     }
                  }
                  else {
                     final Trigger trigger =
                        new Trigger(
                           damaskLayer.getDeviceTypeForNewElement(),
                           new Content(
                              damaskLayer.getDeviceTypeForNewElement(),
                              "OK"));
                     
                     command.addCommand(new AddControlCommand(
                        beforeControl,
                        trigger));
                     
                     command.addCommand(new AddControlCommand(
                        beforeControl,
                        new TextInput(
                           damaskLayer.getDeviceTypeForNewElement())));
                     
                     if ((control instanceof SelectOne) ||
                           (control instanceof SelectMany.Item)) {
                        DamaskUtils
                        .addCommandsForRemovingControlToMacroCommand(
                           command, control);
                     }
                  }
               }
               
               
               // If the original response represents a select-one
               // with one item, then edit the contents of that item.
               else if (control instanceof SelectOne &&
                        ((SelectOne)control).getItems().size() == 1) {
                  final SelectOne selectOne = (SelectOne)control;
                  DamaskAppUtils
                  .addCommandsToModifySelectItemsToMacroCommand(
                     selectOne,
                     damaskCanvas,
                     newTextArray,
                     command,
                     true);
               }
               
               else {
                  // The new response should be a trigger.
                  //
                  // The original response could represent:
                  // * A trigger
                  // * A trigger with a text input, select-one, or
                  //   select-many item before it
                  // * A text input, select-one, or select-many item
                  // * Content
                  if (control instanceof Trigger) {
                     command.addCommand(
                        new SetVoicePromptTextCommand(
                           ((Trigger)control).getContent(),
                           newTextArray[0]));
                     
                     if ((beforeControl instanceof TextInput) ||
                         (beforeControl instanceof SelectOne) ||
                         (beforeControl instanceof SelectMany.Item)) {
                          DamaskUtils
                          .addCommandsForRemovingControlToMacroCommand(
                             command, beforeControl);
                     }
                  }
                  else {
                     final Trigger trigger =
                        new Trigger(
                           damaskLayer.getDeviceTypeForNewElement(),
                           new Content(
                              damaskLayer.getDeviceTypeForNewElement(),
                              newTextArray[0]));
                     
                     command.addCommand(new AddControlCommand(
                        beforeControl,
                        trigger));
                     
                     command.addCommand(new AddControlCommand(
                        beforeControl,
                        new TextInput(
                           damaskLayer.getDeviceTypeForNewElement())));
                     
                     if ((control instanceof TextInput) ||
                         (control instanceof SelectOne) ||
                         (control instanceof SelectMany.Item)) {
                        DamaskUtils
                        .addCommandsForRemovingControlToMacroCommand(
                           command, control);
                     }
                  }
               }
            }
            else if (newTextArray.length == 2) {
               // If the object is already a select-many item, then
               // leave it at that. Otherwise, make a select-one
               final Control controlToChange;
               if (pickedResponseText.size() <= 1) {
                  // must be trigger, must add select one before it
                  final SelectOne selectOne =
                     new SelectOne(
                        damaskLayer.getDeviceTypeForNewElement());

                  command.addCommand(
                     new AddControlCommand(beforeControl, selectOne));
                  
                  for (Iterator i = damaskLayer
                     .getDeviceTypeForNewElement()
                     .getSpecificDeviceTypes()
                     .iterator(); i.hasNext();) {
                     final DeviceType aDeviceType = (DeviceType) i.next();
                     if (aDeviceType != DeviceType.VOICE) {
                        selectOne.setStyle(aDeviceType, Select.MINIMAL);
                        command.addCommand(new SetTransformCommand(
                           selectOne,
                           aDeviceType,
                           beforeControl.getTransform(aDeviceType)));

                        final AffineTransform newTriggerTransform = control
                           .getTransform(aDeviceType);
                        //HACK
                        newTriggerTransform.translate(0, ComboBox
                           .createTempView()
                           .getHeight());
                        control.setTransform(aDeviceType, newTriggerTransform);
                     }
                  }
                     
                  controlToChange = selectOne;
               }
               else {
                  if (control instanceof Trigger) {
                     controlToChange = beforeControl;
                  }
                  else {
                     controlToChange = control;
                  }
               }
                  
               // Select-many
               if (controlToChange instanceof SelectMany.Item) {
                  ((SelectMany.Item)controlToChange)
                  .setVoiceResponseTextList(
                     Arrays.asList(newTextArray));
               }
               // Select-one
               else if (controlToChange instanceof SelectOne) {
                  final SelectOne selectOne =
                     (SelectOne)controlToChange;
                  
                  DamaskAppUtils
                     .addCommandsToModifySelectItemsToMacroCommand(
                        selectOne,
                        damaskCanvas,
                        newTextArray,
                        command,
                        true);
               }
               else {
                  assert false: "Control to change must be select-one or select-many item";
               }
            }
            else {
               // select-one
               final SelectOne selectOneToChange;
               
               if (pickedResponseText.size() <= 1) {
                  // original response must be trigger =>
                  // must add select one before it
                  final SelectOne selectOne =
                     new SelectOne(
                        damaskLayer.getDeviceTypeForNewElement());
                  
                  command.addCommand(
                     new AddControlCommand(beforeControl, selectOne));

                  for (Iterator i = damaskLayer
                     .getDeviceTypeForNewElement()
                     .getSpecificDeviceTypes()
                     .iterator(); i.hasNext();) {
                     final DeviceType aDeviceType = (DeviceType) i.next();
                     if (aDeviceType != DeviceType.VOICE) {
                        selectOne.setStyle(aDeviceType, Select.MINIMAL);
                        command.addCommand(new SetTransformCommand(
                           selectOne,
                           aDeviceType,
                           beforeControl.getTransform(aDeviceType)));

                        final AffineTransform newTriggerTransform = control
                           .getTransform(aDeviceType);
                        //HACK
                        newTriggerTransform.translate(0, ComboBox
                           .createTempView()
                           .getHeight());
                        control.setTransform(aDeviceType, newTriggerTransform);
                     }
                  }
             
                  selectOneToChange = selectOne;
                  
                  ((Trigger)control).getContent().setText("OK");
               }
                  
               else if (pickedResponseText.size() == 2 &&
                  beforeControl instanceof SelectMany.Item) {
                  
                  final SelectOne selectOne =
                     new SelectOne(
                        damaskLayer.getDeviceTypeForNewElement());
                  command.addCommand(
                     new AddControlCommand(beforeControl, selectOne));
                  selectOneToChange = selectOne;
                  
                  ((Trigger)control).getContent().setText("OK");

                  DamaskUtils
                     .addCommandsForRemovingControlToMacroCommand(
                        command,
                        beforeControl);
               }
               else {
                  selectOneToChange = (SelectOne)beforeControl;
               }
                  
               DamaskAppUtils
                  .addCommandsToModifySelectItemsToMacroCommand(
                     selectOneToChange,
                     damaskCanvas,
                     newTextArray,
                     command,
                     true);
            }
            if (!command.isEmpty()) {
               damaskCanvas.getDocument().getCommandQueue().doCommand(
                  damaskCanvas, command);
            }
         }
         
         
         catch (BadLocationException e) {
            // should never happen
            DamaskAppExceptionHandler.log(e);
         }
      }

      editor.setVisible(false);
      //HACK
      if (canvas != null) {
         canvas.repaint();
      }

      editedText = null;
   }

   protected JTextComponent createDefaultEditor() {
      final JTextComponent tComp = super.createDefaultEditor();
      tComp.setBorder(new EmptyBorder(0, 0, 0, 0));
      return tComp;
   }
}