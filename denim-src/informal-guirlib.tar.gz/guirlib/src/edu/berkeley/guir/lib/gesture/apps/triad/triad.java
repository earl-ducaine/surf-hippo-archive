package edu.berkeley.guir.lib.gesture.apps.triad;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;

public class triad {
  public static void main(String argv[])
  {
    setDefaults();

    TriadFrame frame = new TriadFrame("Triads");

    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    };
    frame.addWindowListener(l);

    if (argv.length > 0) {
      frame.openFile(new File(argv[0]));
    }

    frame.pack();
    frame.setSize(new Dimension(750, 750));
    frame.show();
  }

  static void setDefaults()
  {
    Font bigFont = new Font("Serif", Font.PLAIN, 18);
    Font smallFont = new Font("Serif", Font.PLAIN, 14);
    UIManager.put("Label.font", bigFont);
    // I don't know why I need to set the foreground color of labels.
    // You'd think that they would be black by default, but under
    // Swing 1.0.3 they're lavendar.
    UIManager.put("Label.foreground", Color.black);
    UIManager.put("MenuItem.font", bigFont);
    UIManager.put("Menu.font", bigFont);
    UIManager.put("Button.font", bigFont);
    UIManager.put("ToggleButton.font", bigFont);
    UIManager.put("TextPane.font", bigFont);
  }
}
