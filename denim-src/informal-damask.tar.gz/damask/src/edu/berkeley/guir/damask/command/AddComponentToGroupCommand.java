package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that adds a component to a component group.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  12-17-2003 James Lin
 *                               Created AddComponentToGroupCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 12-17-2003
 */
public class AddComponentToGroupCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final ComponentGroup group;
   private final Component component;
   
   /**
    * Constructs the command to add the specified component to the
    * specified group.
    *  
    * @param group      the group to add the component to
    * @param component  the component to add
    */      
   public AddComponentToGroupCommand(
      final ComponentGroup group,
      final Component component) {

      this.group = group;
      this.component = component;
   }
   
   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Add component " + component + " to group " + group;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      group.add(component);
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      group.remove(component);
   }
}
