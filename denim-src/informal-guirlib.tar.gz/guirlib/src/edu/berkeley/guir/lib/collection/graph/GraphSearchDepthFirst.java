//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import java.util.HashMap;
import java.util.Iterator;

/**
 * A depth first search for Graph.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Dec 20 1997, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.5/1.2.0, Nov 22 2002, JH
 *               Updated for new Graph APIs
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.1.4
 * @version GUIRLib-v1.5/1.2.0, Nov 22 2002
 */
public class GraphSearchDepthFirst
   implements GraphSearch {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   Graph     g;                 // our reference to the graph
   HashMap   table = new HashMap(GraphConst.DEFAULT_NUMBER_NODES);

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   SEARCH METHODS   ====================================================

   /**
    * Perform a depth-first search on the graph, with the specified start
    * and target nodes.
    *
    * @param  strFrom is the name of the starting node.
    * @param  strTo   is the name of the target node.
    * @return Returns the first successful Path found from the start node
    *         to the target node. The Path is empty if no successful Path
    *         is found, or if either the start or target node does not
    *         exist in the Graph.
    */
   public GraphPath search(Graph g, String strFrom, String strTo) {

      GraphPath p = new GraphPath();
      this.g = g;

      //// 1. Ensure that the start and ending nodes are in the Graph
      if (g.nodeExists(strFrom) && g.nodeExists(strTo)) {
         table.clear();
         depthFirstSearchHelper(0, strFrom, strTo, table, p);
      }

      //// 2. Technically, we should clone the path before returning it 
      ////    for security and safety reasons, since whoever gets it could
      ////    modify the Graph.
      return ((GraphPath) p.clone());
   } // of method

   //-----------------------------------------------------------------

   /**
    * The helper method for depthFirstSearch.
    *
    * @param  weight    is the weight of the edge we just took. If it is the
    *                   first weight in the Path, then it is conveniently
    *                   ignored.
    * @param  strNodeAt is the name of the start node. It is assumed that this
    *                   node exists.
    * @param  strTo     is the name of the destination node. It is assumed that
    *                   this node exists.
    * @param  explored  is a table containing the list of nodes we have been
    *                   to. Nodes are added and removed from this table as we
    *                   descend and backtrack.
    * @param  path      is the list of Nodes we have taken to get to where we
    *                   currently are.
    * @return true if the path was found, false otherwise.
    */
   private boolean depthFirstSearchHelper(float weight, String strNodeAt,
                            String strTo, HashMap explored, GraphPath path) {

      GraphNode nodeAt = g.getNode(strNodeAt); // node we currently are at
      String    strNodeNext;                   // name of next node to explore

      //// 1. Add ourself to the explored list and the path taken so far
      explored.put(strNodeAt, Boolean.TRUE);
      path.addNode(nodeAt, weight);
      // System.out.println("searching from " + strNodeAt + " to " + strTo);

      //// 2. If we are at the destination node, return the Path
      if (strNodeAt.equals(strTo)) {
         return (true);
      }

      //// 3. Otherwise get the list of nodes connected to this one
      Iterator it = nodeAt.getOutlinks();
      while (it.hasNext()) {
         strNodeNext = (String) it.next();
         
         //// 4. If we have not been there, then go there
         if ( ! explored.containsKey(strNodeNext) ) {
            if (depthFirstSearchHelper(g.getWeight(strNodeAt, strNodeNext), 
                                  strNodeNext, strTo, explored, path))
               return (true);
         }
      }

      //// 5. If we get here, then the search down this Path has failed.
      ////    Backtrack after removing the current node from the explored 
      ////    list and from the path.
      explored.remove(strNodeAt);
      path.removeLastNode();
      // System.out.println("backtracking");

      return (false);
   } // of method

   //===   SEARCH METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
