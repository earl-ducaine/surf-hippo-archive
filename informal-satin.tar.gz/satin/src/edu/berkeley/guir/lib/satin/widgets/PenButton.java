package edu.berkeley.guir.lib.satin.widgets;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * @author srk
 *
 * Pen interfaces work better with large targets. This is a standard JButton that just likes to be larger.
 */
public class PenButton extends JButton {
	
	
	public PenButton(String text) {
		this(text, null);
	}
	
	
	public PenButton(Icon icon) {
		this(null, icon);
	}
	
	
	public PenButton(String text, Icon icon) {
		super(text, icon);

		//Make the buttons insets little narrower so we can fit more buttons on a line
		setBorder(BorderFactory.createCompoundBorder(
				((CompoundBorder)(getBorder())).getOutsideBorder(),
				BorderFactory.createEmptyBorder(2, 13, 2, 13)));
	}
	
	
   /**
    * Pen interfaces have selection slop, so big widgets are better
    */
   public Dimension getMinimumSize() {
      return new Dimension(super.getMinimumSize().width, (int)(super.getMinimumSize().height*0.5));
   }

   /**
    * Pen interfaces have selection slop, so big widgets are better
    */
   public Dimension getPreferredSize() {
      return new Dimension(super.getPreferredSize().width, (int)(super.getPreferredSize().height*1.6));
   }

   /**
    * Pen interfaces have selection slop, so big widgets are better
    */
   public Dimension getMaximumSize() {
      return new Dimension(super.getMaximumSize().width, (int)(super.getMaximumSize().height*1.6));
   }

}
