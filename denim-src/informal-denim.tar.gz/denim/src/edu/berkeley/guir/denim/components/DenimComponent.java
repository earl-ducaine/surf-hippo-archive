package edu.berkeley.guir.denim.components;

import edu.berkeley.guir.lib.collection.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.denim.toolbox.RubberStamp;
import java.util.*;

/**
 * A DENIM component. This both stores and allows the viewing of the
 * definition of a component.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-05-1999  James Lin
 *                                Created DenimComponent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 08-05-1999
 */
public abstract class DenimComponent
   extends PatchImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -8603509762379123624L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   //protected Denim denim;

   protected String      name;
   protected RubberStamp stamp;
   protected List        instances;
   protected ArrayList         states;         // of GraphicalObjects
                                         // contains all possible states
   protected Set         supportedEvents;   // of Strings

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================

   GraphicalObjectCollection empty = new GraphicalObjectCollectionImpl();

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * To create a component, call DenimComponentRegistry.put()
    */
   DenimComponent() {
      super();
      this.instances = new LinkedList();
      this.states = new ArrayList();//HashSet();
      this.supportedEvents = new HashSet();
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //-----------------------------------------------------------------

   /**
    * Creates a new instance of this component.
    */
   public abstract DenimComponentInstance newInstance();

   //-----------------------------------------------------------------

   /**
    * Returns an event table, where the events originate from the given
    * instance.
    *
    * This should be used only by the constructor of DenimComponentInstance,
    * so that an instance can initialize its event tables.
    */
   Map2D createEmptyEventTable() {
      Map2D eventTable = new Map2D();
      Iterator setIter = supportedEvents.iterator();

      while (setIter.hasNext()) {
         String eventName = (String)(setIter.next());
         eventTable.addRow(eventName);
      }

      return eventTable;
   }

   //-----------------------------------------------------------------

   /**
    * Returns whether the component is intrinsic (built-in) or not.
    */
   public abstract boolean isIntrinsic();

   //-----------------------------------------------------------------

   /**
    * Returns the rubber stamp used by the designer to insert an instance
    * of this component.
    */
   public RubberStamp getRubberStamp() {
      return stamp;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the name of the component.
    */
   public String getName() {
      return name;
   }

   //-----------------------------------------------------------------

   /**
    * Sets the name of the component to the given string.
    */
   public void setName(String newName) {
      name = newName;
   }

   //-----------------------------------------------------------------

   /**
    * Returns a copy of the set of all possible states that this component
    * can have. You can modify this set without affecting the original set.
    */
//   public Set getStates() {
 //     return new HashSet(states);
 //  }

   //-----------------------------------------------------------------

   /**
    * Adds an event type to the set of events supported by this component.
    */
   public void addEvent(String name) {
      supportedEvents.add(name);
   }

   //-----------------------------------------------------------------

   /**
    * Removes an event type from the set of events supported by this
    * component. If the event type already isn't supported, then this
    * method does nothing.
    */
   public void removeEvent(String name) {
      supportedEvents.remove(name);
   }

   //-----------------------------------------------------------------

   /**
    * Returns whether the given event type is supported by this component.
    */
   public boolean hasEvent(String name) {
      return supportedEvents.contains(name);
   }

   //-----------------------------------------------------------------

   /**
    * Returns all events supported by this component
    */
   public Set getEvents() {
      return supportedEvents;
   }

   //-----------------------------------------------------------------

   /**
    * Returns a string representation of this component.
    */
   public String toDebugString() {
      String output = this.getClass().toString();
      output += "\n" + "Name: " + name;
      output += "\n" + "Stamp: " + stamp;
      output += "\n" + super.toDebugString();
      return output;
   }

   //-----------------------------------------------------------------

   /**
    * Adds the given instance to the list of instances of this component.
    * Called only by DenimComponentInstance()
    */
   void trackInstance(DenimComponentInstance instance) {
      instances.add(instance);
   }

   //-----------------------------------------------------------------

   /**
    * Removes the given instance from the list of instances of this component.
    * Called only by DenimComponentInstance.delete()
    */
   void untrackInstance(DenimComponentInstance instance) {
      instances.remove(instance);
   }
   //-----------------------------------------------------------------
   
   //----------------------------------------
   
   /**
    * clear all references hold by this object (In the namespace of this class)
    */
   
   public void deepClear() {

      super.deepClear();
      
      name = null;
      stamp = null;
      instances = null;
      
      if(states!=null)
      {
         states.clear();
         states = null;
      }
      
      if(supportedEvents!=null)
      {
         supportedEvents.clear();
         supportedEvents = null;
      }
   }

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
