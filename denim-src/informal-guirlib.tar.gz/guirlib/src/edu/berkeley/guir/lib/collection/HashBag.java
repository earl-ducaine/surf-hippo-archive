//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/**
 * A bag collection backed by a HashMap.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Apr 09 2002 JIH
 */
public class HashBag {

   //===========================================================================
   //===   INNER CLASS   =======================================================

   /**
    * Keep track of number of instances.
    */
   class ModifiableInteger {
      int val = 0;

      public String toString() {
         return (Integer.toString(val));
      } // of toString
   } // of class

   //===========================================================================

   /**
    * Iterate over the bag. 
    */
   class BagIterator 
      implements Iterator {

      Iterator keyIt = keySet().iterator();
      Object   obj;
      int      count = 0;

      private void getNextBunch() {
         ModifiableInteger mint;
         obj   = keyIt.next();
         mint  = (ModifiableInteger) map.get(obj);
         count = mint.val;
      } // of getNextBunch

      public boolean hasNext() {
         return (keyIt.hasNext() || count > 0);
      } // of hasNext

      public Object next() {
         if (count == 0) {
            getNextBunch();
         }

         count--;
         return (obj);
      } // of next

      public void remove() {
         throw new UnsupportedOperationException();
      } // of remove
   } // of BagIterator

   //===   INNER CLASS   =======================================================
   //===========================================================================




   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   HashMap map = new HashMap();

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================




   //===========================================================================
   //===   BAG METHODS   =======================================================

   /**
    * @return the current number of items of the item passed in.
    */
   public int add(Object obj) {
      ModifiableInteger mint = (ModifiableInteger) map.get(obj);
      if (mint == null) {
         mint = new ModifiableInteger();
         map.put(obj, mint);
      }
      mint.val++;
      return (mint.val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Clear out all elements in the bag.
    */
   public void clear() {
      map.clear();
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if the bag contains the specified object.
    */
   public boolean contains(Object obj) {
      return (map.containsKey(obj));
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if the bag is empty.
    */
   public boolean isEmpty() {
      return (size() == 0);
   } // of method


   /**
    * See if the bag contains any of this object.
    */
   public boolean isEmpty(Object obj) {
      return (size(obj) == 0);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Iterate over everything in the bag. If an element is in here multiple
    * times, it gets returned multiple times. If you only want unique elements,
    * call {@link #keySet()} and get the iterator from that.
    * <P>
    * This implementation gives a deferred ConcurrentModification exception if
    * you modify the bag while iterating. That is, it won't throw the exception
    * until you get to the next bunch of elements. For example, if you were
    * iterating over the bag {'A'=4, 'B'=3}, modifying the bag won't throw
    * an exception until you go from 'A' to 'B'.
    */
   public Iterator iterator() {
      return (new BagIterator());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the set of elements.
    */
   public Set keySet() {
      return (map.keySet());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Remove an object from the bag.
    */
   public int remove(Object obj) {
      ModifiableInteger mint = (ModifiableInteger) map.get(obj);

      //// 1. Doesn't exist, value of 0.
      if (mint == null) {
         return (0);
      }

      //// 2. If it does exist, subtract one from the count.
      if (mint.val > 0) {
         mint.val--;
      }

      //// 3. See if there are any elements at all.
      if (mint.val == 0) {
         map.remove(obj);
      }

      return (mint.val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the total number of objects in the bag.
    */
   public int size() {
      int               count = 0;
      Iterator          it    = map.values().iterator();
      ModifiableInteger mint;

      while (it.hasNext()) {
         mint   = (ModifiableInteger) it.next();
         count += mint.val;
      }

      return (count);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the number of unique objects in the bag.
    */
   public int sizeKeySet() {
      return (map.size());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the number of instances of this object contained in the bag.
    */
   public int size(Object obj) {
      ModifiableInteger mint = (ModifiableInteger) map.get(obj);
      if (mint == null) {
         return (0);
      }
      else {
         return (mint.val);
      }
   } // of method

   //===   BAG METHODS   =======================================================
   //===========================================================================




   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      return (map.toString());
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================




   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

/*
   public static void main(String[] argv) {
      HashBag bag = new HashBag();

      bag.add(new Character('A'));
      bag.add(new Character('A'));
      bag.add(new Character('A'));
      bag.add(new Character('B'));
      bag.add(new Character('B'));
      bag.add(new Character('A'));
      bag.add(new Character('C'));
      bag.add(new Character('C'));
      bag.add(new Character('C'));
      bag.add(new Character('C'));
      bag.add(new Character('C'));
      bag.add(new Character('B'));  // a=4, b=3, c=5
      System.out.println(bag);
      System.out.println();

      Iterator it = bag.iterator();
      while (it.hasNext()) {
         System.out.println(it.next());
      }
      System.out.println();

      it = bag.iterator();
      while (it.hasNext()) {
         System.out.println(it.next());
         bag.remove(new Character('A'));
      }
      System.out.println();

   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
