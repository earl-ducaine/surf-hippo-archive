package edu.berkeley.guir.damask.view.nodes;

import java.awt.Color;
import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.*;

import edu.berkeley.guir.damask.view.DamaskCanvas;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolo.util.PPaintContext;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * A border that resizes the node that it is attached to.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-29-2003 James Lin
 *                               Created SizingBorder.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-29-2003
 */
public class SizeGrip extends BoundsHandle {
   private static final int WIDTH = 20;
   private static final int HEIGHT = 20;
   private static final Color BACKGROUND_COLOR = new Color(153, 153, 204);
   private static final Color HIGHLIGHT_COLOR = new Color(204, 204, 255);
   private static final Color SHADOW_COLOR = new Color(102, 102, 153);
   
   private PPath[] dimpleHighlights = new PPath[6];
   private PPath[] dimpleShadows = new PPath[6];


   /**
    * Creates a sizing border with the specified locator.
    */
   protected SizeGrip(PNode node) {
      super(PBoundsLocator.createSouthEastLocator(node));
      setPaint(BACKGROUND_COLOR);
      setStrokePaint(BACKGROUND_COLOR);
      
      setPathToPolyline(new float[] {WIDTH, WIDTH,  0,      WIDTH},
                        new float[] {0,     HEIGHT, HEIGHT, 0});
      
      // Create dimples.
      for (int i = 0, n = dimpleHighlights.length; i < n; i++) {
         dimpleHighlights[i] = addDimpleHighlight();
      }
      
      for (int i = 0, n = dimpleShadows.length; i < n; i++) {
         dimpleShadows[i] = addDimpleShadow();
      }
      
      moveDimples(new Point(WIDTH, HEIGHT));
   }


   /**
    * Adds a border to the given node that stick to the given camera.
    */
   public static void addTo(final PNode node, final PCamera camera) {
      final SizeGrip grip = new SizeGrip(node);
      node.addChild(grip);
      StickyTransformManager.setupStickyZ(grip, camera, new Point(WIDTH, HEIGHT));
      grip.relocateHandle(); 
   }


   /**
    * Removes sizing borders from the given node.
    */
   public static void removeFrom(PNode node) {
      final List handles = new ArrayList();

      for (Iterator i = node.getChildrenIterator(); i.hasNext(); ) {
         final PNode each = (PNode)i.next();
         if (each instanceof SizeGrip) {
            handles.add(each);
         }
      }
      node.removeChildren(handles);      
   }


   /**
    * Creates a highlight for a dimple and adds it to this grip. 
    */
   private PPath addDimpleHighlight() {
      PPath highlight = PPath.createRectangle(0, 0, 2, 2);
      highlight.setStrokePaint(HIGHLIGHT_COLOR);
      addChild(highlight);
      return highlight;
   }
   
   /**
    * Creates a shadow for a dimple and adds it to this grip. 
    */
   private PPath addDimpleShadow() {
      PPath shadow = PPath.createRectangle(0, 0, 2, 2);
      shadow.setStrokePaint(SHADOW_COLOR);
      addChild(shadow);
      return shadow;
   }

   /**
    * Moves the dimples relative to the given point in the grip's local
    * coordinate system.
    */
   private void moveDimples(Point2D pt) {
      double x = pt.getX();
      double y = pt.getY();
      
      moveDimple(0, x - 4, y - 4);
      moveDimple(1, x - 4, y - 8);
      moveDimple(2, x - 4, y - 12);

      moveDimple(3, x - 8, y - 4);
      moveDimple(4, x - 8, y - 8);

      moveDimple(5, x - 12, y - 4);
   }
   
   /**
    * Moves the nth dimple relative to the given point in the grip's local
    * coordinate system.
    */
   private void moveDimple(int n, double x, double y) {
      Point2D pt = new Point2D.Double(x, y);
      localToGlobal(pt);
      dimpleShadows[n].globalToLocal(pt);
      dimpleShadows[n].setBounds(pt.getX(), pt.getY(), 2, 2);
      
      pt = new Point2D.Double(x, y);
      localToGlobal(pt);
      dimpleHighlights[n].globalToLocal(pt);
      dimpleHighlights[n].setBounds(pt.getX() + 1, pt.getY() + 1, 2, 2);
   }


   // Overrides method in superclass.
   public void relocateHandle() {
      final PBoundsLocator locator = (PBoundsLocator)getLocator();
      
      final PBounds b = getBoundsReference();
      final double width = b.getWidth();
      final double height = b.getHeight();
      final Point2D aPoint = locator.locatePoint(null);
      
      final PNode located = locator.getNode();
      final PNode parent = getParent();
      
      located.localToGlobal(aPoint);
      globalToLocal(aPoint);
      
      if (parent != located && parent instanceof PCamera) {
         ((PCamera)parent).viewToLocal(aPoint);
      }
      
      setBounds(
         aPoint.getX() - width + 1,
         aPoint.getY() - height + 1,
         width,
         height);

      // Move dimples
      moveDimples(aPoint);
   }
   
   
   // Overrides method in superclass. 
   public void startHandleDrag(Point2D localPt, PInputEvent event) {
      super.startHandleDrag(localPt, event);
      final PComponent eventComponent = event.getComponent();
      if (eventComponent instanceof DamaskCanvas) {
         ((DamaskCanvas)eventComponent).setWindowBoundsChanging(true);
      }
   }


   // Overrides method in superclass. 
   public void endHandleDrag(Point2D localPt, PInputEvent event) {
      super.endHandleDrag(localPt, event);
      final PComponent eventComponent = event.getComponent();
      if (eventComponent instanceof DamaskCanvas) {
         ((DamaskCanvas)eventComponent).setWindowBoundsChanging(false);
      }
   }

   // Overrides method in parent class.
   public void paint(PPaintContext aPaintContext) {
      final PCamera camera = aPaintContext.getCamera();
      
      if (camera != null) {
         if (camera.getComponent() instanceof DamaskCanvas) {
            final boolean childrenVisible;
            if (camera.getViewScale() >= DamaskCanvas.scaleFactor(2)) {
               super.paint(aPaintContext);
               childrenVisible = true;
            }
            else {
               childrenVisible = false;
            }
            for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
               final PNode child = (PNode)i.next();
               child.setVisible(childrenVisible);
            }
         }
      }
   }
}
