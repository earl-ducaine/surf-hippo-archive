package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import java.awt.event.*;
import edu.berkeley.guir.lib.swing.*;
/** Drawing response Card
 **/
public abstract class AbstLinkView extends javax.swing.JComponent
{
	public    static final Color  LINK_COLOR      = new Color(205,255,191);
	public    static final Color  LINK_DRAG_COLOR = new Color(150,180,240);
	public    static final Color  BALLOON_FG      = new Color(19,142,52);
	public    static final Color  BALLOON_BG      = Color.white;
	private   static final int    STROKE_WIDTH    = 2;
	protected static final int    BUTTON_WIDTH    = 18;
	protected static final int    ARC             = 24;
	private   static final int    WIDTH           = 114;
	private   static final int    HEIGHT          = 32;
	private   static final int    BALLOON_0X      = 0;
	private   static final int    BALLOON_0Y      = HEIGHT-1;
	private   static final int    BALLOON_1X      = 20;
	private   static final int    BALLOON_1Y      = HEIGHT-12;
	private   static final int    BALLOON_2X      = 7;
	private   static final int    BALLOON_2Y      = HEIGHT-19;
	private   static final int[]  BALLOON_X       = new int[3];
	private   static final int[]  BALLOON_Y       = new int[3];
	private   static final RoundRectangle2D.Float BG_SHAPE = new RoundRectangle2D.Float(3,0,WIDTH-4,HEIGHT-7,ARC,ARC);

	private   Area           balloon     = new Area(BG_SHAPE);
	protected Area           m_buttonShape = new Area(BG_SHAPE);
	private   boolean        dragging    = false;
	private   Point          oldSourcePt, oldTargetPt;
	protected Arrowhead      m_arrowhead    = new Arrowhead();
	private   Arrowtail      m_arrowtail    = new Arrowtail();
	private   JTextField     m_text         = new JTextField();
	private   SContentPane   m_pane;
	protected LinkModel      m_linkmodel;
	protected Color          m_buttonColor  = LINK_COLOR;
	protected SuedeModel     m_model;
	protected SPlayMenu      m_playMenu = new SPlayMenu();
    
	////////Hongvan's code////////////////////
   private JPopupMenu popup = new JPopupMenu();
   private RolloverMenuItem newPromptCard = new RolloverMenuItem("Create New Prompt Card", Color.black, Color.white, Color.darkGray);
   private RolloverMenuItem newResponseCard = new RolloverMenuItem("Create New Response Card", Color.black, Color.white, Color.darkGray);
   private RolloverMenuItem copy = new RolloverMenuItem("Copy", Color.black, Color.white, Color.darkGray);
   private RolloverMenuItem cut = new RolloverMenuItem("Cut", Color.black, Color.white, Color.darkGray);
   private RolloverMenuItem paste = new RolloverMenuItem("Paste", Color.black, Color.white, Color.darkGray);
   /////////////////////////////////////////
   
	public abstract void setPlayable(boolean b);
    
	public AbstLinkView(SuedeModel model, LinkModel lModel, SContentPane pane) {
	   oldSourcePt = new Point(lModel.getSourcePt());
	   oldTargetPt = new Point(lModel.getTargetPt());
	   m_linkmodel = lModel;

	   m_model = model;
	   setSize(WIDTH,HEIGHT);
	   BALLOON_X[0] = BALLOON_0X;  BALLOON_Y[0] = BALLOON_0Y;
		BALLOON_X[1] = BALLOON_1X;  BALLOON_Y[1] = BALLOON_1Y;
		BALLOON_X[2] = BALLOON_2X;  BALLOON_Y[2] = BALLOON_2Y;
		balloon.add(new Area(new Polygon(BALLOON_X,BALLOON_Y,3)));
		setVisible(true);
		setOpaque(false);
		setLayout(null);
		m_pane = pane;

		m_text.setBounds(8, 0, WIDTH - 2*BUTTON_WIDTH - 8, ARC);
		m_text.setOpaque(false);
		m_text.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		add(m_text);
		m_text.getDocument().addDocumentListener(lModel);
		m_text.setText(lModel.getCaption());
        
		m_arrowhead.setOpaque(false);
		m_arrowhead.setVisible(true);
		ArrowheadMouseListener a = new ArrowheadMouseListener();
		m_arrowhead.addMouseListener(a);
		m_arrowhead.addMouseMotionListener(a);
		m_arrowhead.setForeground(LINK_COLOR);
        
		m_arrowtail.setOpaque(false);
		ArrowtailMouseListener t = new ArrowtailMouseListener();
		m_arrowtail.addMouseListener(t);
		m_arrowtail.addMouseMotionListener(t);
		m_arrowtail.setForeground(LINK_COLOR);
		m_arrowtail.setVisible(true);
                
		BalloonMouseListener listener = new BalloonMouseListener();
		m_text.addMouseListener(listener);
		addMouseListener(listener);          
		setDrawBalloon(m_linkmodel.getDrawBalloon());

		m_buttonShape.subtract(new Area(new Rectangle(WIDTH-2*BUTTON_WIDTH, HEIGHT)));
        
		 ////////////////////Hongvan's code//////////////////////////
		 newPromptCard.addActionListener (new PromptCardActionListener());
		 newResponseCard.addActionListener (new ResponseCardActionListener());
		 copy.addActionListener (new CopyActionListener());
		 cut.addActionListener (new CutActionListener());
		 paste.addActionListener (new PasteActionListener());
		 popup.add(newPromptCard);
		 popup.add(newResponseCard);
		 popup.add(copy); popup.add(cut); popup.add(paste);
		 /////////////////////////////////////////////////////////////
	}
    

	public void paintComponent(Graphics g) {
	   Graphics2D g2d = (Graphics2D)g;
	   g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	   g2d.setColor(BALLOON_BG);
	   g2d.fill(balloon);
       
	   g2d.setColor(m_buttonColor);
	   g2d.fill(m_buttonShape);
	    
	   g2d.setColor(BALLOON_FG);
	   g2d.setStroke(AbstNodeView.STROKE);
	   g2d.draw(balloon);
       
	   g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
	   super.paintComponent(g);
	}
    
    
	// when a new link view is created, we need to also add the balloon, the actual link, and the arrow ends
	public void addLinkToPane() {
	  if (m_pane!=null) {
		m_pane.add(this, SContentPane.NODE_LAYER);
		m_pane.add(getArrowhead(), SContentPane.ARROWHEAD_LAYER);
		m_pane.add(getArrowtail(), SContentPane.ARROWHEAD_LAYER);
		m_pane.repaint();
	  }
	}
  

	// when a link is removed, we need to remove all the link parts we added
	public void removeLinkFromPane() {
	  if (m_pane!=null) {
		m_pane.remove(this);
		m_pane.remove(getArrowhead());
		m_pane.remove(getArrowtail());
		m_pane.repaint();
	  }
	}
 

	public void setDrawBalloon(boolean draw) {
		if (draw) setSize(WIDTH,HEIGHT);
		else setSize(0,0);
	}
	

	public Arrowhead getArrowhead() {
		return m_arrowhead;   
	}
	
	public Arrowtail getArrowtail(){
		return m_arrowtail;   
	}
	
	// update the popup menu
	public void addUserResponse(String s, ActionListener l) {
	   m_playMenu.addMenuItem(s, l);
	}
    
    
	public void clearUserResponses() {
	  m_playMenu.clearMenuItems(); 
	}
    
    
	public void paintLink(Graphics2D g2d) {
		if (m_linkmodel.hasSource())
			m_linkmodel.setSourcePt(getBoundaryPt(m_linkmodel.getSourceView(), m_linkmodel.getTargetPt()));

		if (m_linkmodel.hasTarget())
			m_linkmodel.setTargetPt(getBoundaryPt(m_linkmodel.getTargetView(), m_linkmodel.getSourcePt()));
        
		Point src = m_linkmodel.getSourcePt();
		Point tar = m_linkmodel.getTargetPt();
	    
		setLocation((src.x+tar.x-getWidth())/2, (src.y + tar.y - getHeight())/2);
 
		// arrow code from "John Michael Pirie" <jpirie@visual.com>
		double theta = Math.atan2(tar.y-src.y, tar.x-src.x);

		g2d.setStroke(createArrowParams());        
    
		m_arrowhead.setArrowhead(m_linkmodel.getTargetPt(), theta);
		m_arrowhead.setTarget(m_linkmodel.hasTarget());

		g2d.setColor((dragging) ? LINK_DRAG_COLOR : LINK_COLOR);
		/*g2d.drawLine(src.x+(int)(Math.cos(theta)*m_arrowtail.DIAMETER), 
					 src.y+(int)(Math.sin(theta)*m_arrowtail.DIAMETER), 
					 tar.x-(int)(m_arrowhead.getArrowSize()*Math.cos(theta)), 
					 tar.y-(int)(m_arrowhead.getArrowSize()*Math.sin(theta)));
					 */
		g2d.drawLine(src.x+(int)(Math.cos(theta)*Arrowtail.DIAMETER), 
							 src.y+(int)(Math.sin(theta)*Arrowtail.DIAMETER), 
							 tar.x-(int)(m_arrowhead.getArrowSize()*Math.cos(theta)), 
							 tar.y-(int)(m_arrowhead.getArrowSize()*Math.sin(theta)));
        
		m_arrowtail.setCenter(src.x + (int)(Math.cos(theta)*Arrowtail.RADIUS), 
							  src.y + (int)(Math.sin(theta)*Arrowtail.RADIUS));
		m_arrowtail.setSource(m_linkmodel.hasSource());
	}
	
	public BasicStroke createArrowParams() {
		m_arrowhead.setArrowSize(20);
		return AbstNodeView.STROKE;
	}

	// generalized method to get the boundary point where we draw the arrow tail or head
	// we return a point cropped to the boundary of nodeView for a line coming from nodePt
	private Point getBoundaryPt(AbstNodeView nodeView, Point nodePt) {
		int pxl = nodeView.getX();  int pxr = pxl + nodeView.getWidth();
		int pyt = nodeView.getY();  int pyb = pyt + nodeView.getHeight();
        
		int px = pxl + nodeView.getWidth()/2; // center of source or target in x direction
		int py = pyt + nodeView.getHeight()/2; // center of source or target in y direction
        
		// the p1's are the smaller of (source,target). The p2's are the larger
		int p1x = (px<nodePt.x) ? px : nodePt.x;  int p2x = (px>nodePt.x) ? px : nodePt.x;
		int p1y = (py<nodePt.y) ? py : nodePt.y;  int p2y = (py>nodePt.y) ? py : nodePt.y;

		boolean left   = ((p1x < pxl) && (pxl < p2x));
		boolean right  = ((p1x < pxr) && (pxr < p2x));
		boolean top    = ((p1y < pyt) && (pyt < p2y));
		boolean bottom = ((p1y < pyb) && (pyb < p2y));
        
		// if the line isn't vertical, we can put it in the form y=ax+b;
		if ((nodePt.x!=px) && (nodePt.y!=py)) {
			float a = (float)(nodePt.y-py) / (float)(nodePt.x-px);
			float b = nodePt.y - a*nodePt.x;
            
			int xT = (int)((pyt - b)/a);
			int xB = (int)((pyb - b)/a);
			int yL = (int)(a*pxl + b);
            
			// intersect the bounding box
			// HACK: in the future, we'll need to look at the curve as well
			if ((top) && (pxl<=xT) && (xT<=pxr)) { 
				px = xT;  py  = pyt;
			} else if ((bottom) && (pxl<=xB) && (xB<=pxr)) {
				px = (int)xB;  py = pyt + nodeView.getHeight();                
			} else if ((left) && (pyt<=yL) && (yL<=pyb)) {
				px = nodeView.getX();  py = yL;                
			} else {
				px = nodeView.getX()+nodeView.getWidth();  py = (int)(a*(nodeView.getX()+nodeView.getWidth()) + b);
			}
            
		} else { // the line is vertical or horizontal
			if (top)    py = pyt;
			if (bottom) py = pyt + nodeView.getHeight();
			if (left)   px = nodeView.getX();
			if (right)  px = nodeView.getX() + nodeView.getWidth();
		}
        
		return new Point(px,py);
	}
	

	public abstract boolean isPlaying();
	public abstract boolean isRecording();
	public abstract void setStopped();
	public abstract void setRecording();
	public abstract void setPlaying();
	public abstract void setPaused();
	//public abstract void clickRecord();
    
	public void setCaption(String caption) {
	  m_text.setText(caption);      
	}

	public class ArrowheadMouseListener extends MouseMotionAdapter implements MouseListener {
        
		public void mousePressed(MouseEvent e) { 
			oldSourcePt = m_linkmodel.getSourcePt();
			oldTargetPt = m_linkmodel.getTargetPt();
			m_arrowhead.setForeground(LINK_DRAG_COLOR);  
			dragging = true;
			m_arrowhead.repaint();
		}
        
		public void mouseReleased(MouseEvent e) { 
			m_arrowhead.setForeground(LINK_COLOR); 
			dragging = false;
			m_arrowhead.repaint();
			Container parent = m_arrowhead.getParent();
			parent.remove(m_arrowhead);
			Component c = parent.getComponentAt(m_linkmodel.getTargetPt());
			parent.add(m_arrowhead);
			if (c instanceof AbstNodeView) {
				if(!(c.equals(m_linkmodel.getSourceView()))) {
					// we have hooked link up to an AbstNodeView
					m_linkmodel.setDestinationCard(((AbstNodeView)c).getNodeModel());
					System.out.println ("AbstLinkView:" + ((AbstNodeView)c).getNodeModel().getCaption());  
				}
				else {
					//System.out.println("SAbs: Try to comment this code out");
					m_linkmodel.setSourcePt(new Point(oldSourcePt)); 
					m_linkmodel.setTargetPt(new Point(oldTargetPt));
					m_arrowhead.repaint();
				}
			} else {
				System.out.println ("AbstLinkView: Set Dest Card to null");
				// we probably have unhooked the link to the background
				m_linkmodel.setDestinationCard(null);  
			}
		}
        
		public void mouseEntered(MouseEvent e)  { 
			m_arrowhead.setForeground(LINK_DRAG_COLOR); 
			m_arrowhead.repaint();
		}

		public void mouseExited(MouseEvent e)   {
			if (!dragging) {
				m_arrowhead.setForeground(LINK_COLOR); 
				m_arrowhead.repaint();
			}
		}

		public void mouseClicked(MouseEvent e) {}
        
		public void mouseDragged(MouseEvent e) {
			Point pt = e.getPoint();
			m_linkmodel.setDestinationCard(null);  
			m_linkmodel.setTargetPt(new Point((int)(pt.getX() + m_arrowhead.getX()),
											  (int)(pt.getY() + m_arrowhead.getY())));
			m_arrowhead.setTarget(false);
			m_arrowhead.getParent().repaint();
		}
        
	}
    
	//tail
	public class ArrowtailMouseListener extends MouseMotionAdapter implements MouseListener {
        
		public void mousePressed(MouseEvent e) {
			dragging = true;
			oldSourcePt = new Point(m_linkmodel.getSourcePt());
			oldTargetPt = new Point(m_linkmodel.getTargetPt());
			m_arrowtail.setForeground(LINK_DRAG_COLOR);
			m_arrowtail.repaint();
		}
        
		public void mouseReleased(MouseEvent e) {
		   if (SwingUtilities.isMiddleMouseButton(e) && e.isShiftDown()) {
			 m_model.replaceAudioFromFile((LinkModel)m_linkmodel);
			 return;
		   }
			if(SwingUtilities.isMiddleMouseButton(e) && ! m_model.getAnalysisMode() ) {
				m_model.deleteLinkModel(m_linkmodel);
			} else {
				m_arrowtail.setForeground(LINK_COLOR);
				dragging = false;
				Container parent = m_arrowtail.getParent();
				parent.remove(m_arrowtail);
				Component c = parent.getComponentAt(m_linkmodel.getSourcePt());
				parent.add(m_arrowtail);
				if(c instanceof AbstNodeView){
					if(!(c.equals(m_linkmodel.getTargetView()))) {
						m_linkmodel.setOriginCard(((AbstNodeView)c).getNodeModel());
						setDrawBalloon(m_linkmodel.getDrawBalloon());
					} else {
						//System.out.println("SAbs: Try to comment this code out too");
						m_linkmodel.setSourcePt(new Point(oldSourcePt));
						m_linkmodel.setTargetPt(new Point(oldTargetPt));
					}
				} else {
					m_linkmodel.setOriginCard(null);
					setDrawBalloon(true);
				}
                
				m_arrowtail.repaint();
			}
		}
        
		public void mouseDragged(MouseEvent e){
			Point p = e.getPoint();
			m_linkmodel.setOriginCard(null);
			m_linkmodel.setSourcePt(new Point((int)(p.getX() + m_arrowtail.getX()), 
											  (int)(p.getY() + m_arrowtail.getY())));
			m_arrowtail.setSource(false);
			m_arrowtail.getParent().repaint();
		}
        
		public void mouseMoved(MouseEvent e){}
        
		public void mouseEntered(MouseEvent e){
			m_arrowtail.setForeground(LINK_DRAG_COLOR);
			m_arrowtail.repaint();
		}
        
		public void mouseExited(MouseEvent e) {
			if(!dragging){
				m_arrowtail.setForeground(LINK_COLOR);
				m_arrowtail.repaint();
			}
		}
        
		public void mouseClicked(MouseEvent e) {}
	}
	//tail
    
	public class BalloonMouseListener extends MouseAdapter {
		public void mousePressed(MouseEvent e) {
			if (SwingUtilities.isRightMouseButton(e) && ! m_model.getAnalysisMode()) {
				showPopup(e);
			}
		}
        
		public void mouseReleased(MouseEvent e) {
		   if (SwingUtilities.isMiddleMouseButton(e) && e.isShiftDown()) {
			  m_model.replaceAudioFromFile((LinkModel)m_linkmodel);
			  return;
		   }
		   if (SwingUtilities.isMiddleMouseButton(e) && ! m_model.getAnalysisMode() ) {
			  m_model.deleteLinkModel(m_linkmodel);
		   } else {//Adding balloon inside a prompt Card
			  Point p = e.getPoint();
			  javax.swing.SwingUtilities.convertPointToScreen(p, e.getComponent());
			  javax.swing.SwingUtilities.convertPointFromScreen(p, m_pane);
			  Component target = m_pane.getComponentAt(p);
            
			  /**The user left-dragged or right-dragged from a respsonsecard's balloon
			   * to a promptcard.
			   **/
			  if (target instanceof AbstSingleNodeView) {
				 AbstSingleNodeView nodeTarget = (AbstSingleNodeView)target;
				 ((SingleNodeModel)(nodeTarget.getNodeModel())).addBalloon(m_linkmodel);
			  }
			  /**User rightclick on a response card's balloon
			   * Popup menu show up
			   */
			  else if (SwingUtilities.isRightMouseButton(e) &&
						target instanceof AbstLinkView) {
							showPopup(e);
			  }
		   }
		}
        
		////////////////////////Hongvan's code/////////
		  public void showPopup(MouseEvent e) {
			if (e.isPopupTrigger()) {
			newPromptCard.setEnabled(false);
			newResponseCard.setEnabled(false);
			paste.setEnabled(false);
			popup.show(e.getComponent(),e.getX(), e.getY());
	}
	}
	}//end of BalloonMouseListener
    
	private class PromptCardActionListener implements ActionListener {
			public void actionPerformed (ActionEvent e) {
			//doing nothing. This menu item is not activated on response card
			}
		}
            
			private class ResponseCardActionListener implements ActionListener {
				public void actionPerformed (ActionEvent e) {
					//doing nothing. This menu item is not activated on response card
				}
			}
            
			private class CopyActionListener implements ActionListener {
				public void actionPerformed (ActionEvent e) {
					CopyActionPerformed();
				}
			}
            
			private class CutActionListener implements ActionListener {
				public void actionPerformed (ActionEvent e) {
					 CutActionPerformed();
				}
			}
            
			private class PasteActionListener implements ActionListener {
				public void actionPerformed (ActionEvent e) {
			  //doing nothing. This menu item is not activated on response card     
			}
			}
            
			/** Return the Link Model of this view
			 */
			public LinkModel getLinkModel() {
				return m_linkmodel;
			}
            
			public void CopyActionPerformed() {
						if ( !m_model.getAnalysisMode() ) {
						//Temporarily let it point to promptCard instead of creating a new clone.   
							//m_model.copiedLinkObj = this;
							SuedeModel.copiedLinkObj = this;
							//m_model.copiedObj = null;
							SuedeModel.copiedObj = null;
						}
			}
            
			public void CutActionPerformed() {
				  if ( ! m_model.getAnalysisMode() ) {
						//m_model.copiedObj = null;
						SuedeModel.copiedObj = null;
						//We don't need to use clone()
						//m_model.copiedLinkObj = this;
						SuedeModel.copiedLinkObj = this;
						m_model.deleteLinkModel(m_linkmodel);
					}
			}
	/////////////////////////////////////////////////////////
}