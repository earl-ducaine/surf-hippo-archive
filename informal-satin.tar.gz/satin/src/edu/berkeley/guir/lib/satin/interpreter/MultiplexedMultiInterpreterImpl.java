//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter;

import edu.berkeley.guir.lib.satin.event.*;

/**
 * Let's you choose one-of-many interpreters to be active.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 29 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class MultiplexedMultiInterpreterImpl 
   extends    DefaultMultiInterpreterImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   final static long serialVersionUID = -1203958120958098514L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   Interpreter  currentIntrp = null;
   int          currentIndex = 0;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Does nothing.
    */
   public MultiplexedMultiInterpreterImpl() {
      commonInitializations();
   } // of default constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("MultiplexedMultiInterpreterImpl");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * If no interpreters are currently contained, makes the first one added the
    * current interpreter.
    */
   public Interpreter add(Interpreter intrp) {
      super.add(intrp);
      if (currentIntrp == null) {
         currentIntrp = intrp;
      }
      return (intrp);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set which interpreter is active.
    */
   public void setCurrent(int index) {
      currentIndex = index;
      currentIntrp = get(index);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set which interpreter is active.
    */
   public void setCurrent(Interpreter intrp) {
      if (this.contains(intrp) == true) {
         currentIntrp = intrp;
      }
      else {
         throw new RuntimeException("Does not contain this Interpreter");
      }
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   INTERPRETER METHODS   ===============================================

   /**
    * Called when a stroke is started. Iterates through the list of contained
    * interpreters, firing the new stroke event, until one of the contained
    * interpreters consumes the event.
    */
   public void handleNewStroke(NewStrokeEvent evt) {
      //// 0. Check if enabled first.
      if (isEnabled() == false) {
         return;
      }

      //// 1. Forward the event to the current Interpreter.
      if (currentIntrp != null) {
         currentIntrp.handleNewStroke(evt);
      }
   } // of handleNewStroke

   //-----------------------------------------------------------------

   /**
    * Called when a stroke is updated. Iterates through the list of contained
    * interpreters, firing the update stroke event, until one of the contained
    * interpreters consumes the event.
    */
   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      //// 0. Check if enabled first.
      if (isEnabled() == false) {
         return;
      }

      //// 1. Forward the event to the current Interpreter.
      if (currentIntrp != null) {
         currentIntrp.handleUpdateStroke(evt);
      }
   } // of handleUpdateStroke

   //-----------------------------------------------------------------

   /**
    * Called when a stroke is finished. Iterates through the list of contained
    * interpreters, firing the single stroke event, until one of the contained
    * interpreters consumes the event.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      //// 0. Check if enabled first.
      if (isEnabled() == false) {
         return;
      }

      //// 1. Forward the event to the current Interpreter.
      if (currentIntrp != null) {
         currentIntrp.handleSingleStroke(evt);
      }
   } // of handleSingleStroke

   //===   INTERPRETER METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Clones this MultiInterpreter.
    */
   public Object clone() {
      return (clone(new MultiplexedMultiInterpreterImpl()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Clone chain.
    */
   protected DefaultMultiInterpreterImpl
   clone(MultiplexedMultiInterpreterImpl im) {
      //// 1. Clone chain.
      super.clone(im);

      //// 2. Do clone work.
      im.setCurrent(this.currentIndex);

      //// 3. Return.
      return (im);
   } // of method

   //===   CLONE METHODS   =====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
