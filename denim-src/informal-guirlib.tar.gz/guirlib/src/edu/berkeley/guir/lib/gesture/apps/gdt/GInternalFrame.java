package edu.berkeley.guir.lib.gesture.apps.gdt;

import javax.swing.*;
import edu.berkeley.guir.lib.gesture.*;
import javax.swing.event.*;
import java.beans.*;
import java.awt.Container;
import java.awt.BorderLayout;

/** base class for all gdt internal frames */
public class GInternalFrame extends JInternalFrame
  implements Commander {
  private GestureObjectDisplay gestureObjectDisplay;
  protected EventListenerList listenerList = new EventListenerList();

  protected GInternalFrame()
  {
    super();
    setClosable(true);
    setIconifiable(true);
    setMaximizable(true);
    setResizable(true);
  }

  /** creates an internal frame for displaying data */
  static public GInternalFrame makeInternalFrame(GestureObject data)
  {
    return makeInternalFrame(data, data.getParent().getName());
  }

  static public GInternalFrame makeInternalFrame(GestureObject data,
						 String parentName)
  {
    JScrollPane scroller = new JScrollPane();
    JComponent display = DisplayFactory.create(data, scroller);
    return makeInternalFrame(data, display, scroller);
  }

  /** display must also be a GestureObjectDisplay */
  static public GInternalFrame makeInternalFrame(final GestureObject data,
						 JComponent display,
						 JScrollPane scroller)
  {
    final GInternalFrame frame = new GInternalFrame();
    frame.gestureObjectDisplay = (GestureObjectDisplay) display;
    scroller.setViewportView(display);
    display.setBorder(null);
    frame.gestureObjectDisplay.
      addMenuValidChangeListener(new ChangeListener() {
	public void stateChanged(ChangeEvent e) {
	  CommandUtil.fireMenuValidChangeEvent(frame.listenerList, e);
	}
      });
    data.addPropertyChangeListener(new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent e) {
	String propName = e.getPropertyName();
	if (propName == GestureContainer.NAME_PROP) {
	  frame.updateTitle();
	}
	else if ((propName == GestureObject.PARENT_PROP) &&
		 (e.getNewValue() == null)) {
	  // object was deleted, so close the frame
	  try {
	    frame.setClosed(true);
	  }
	  catch (PropertyVetoException exception) {
	    System.err.println("WARNING: could not close display for " +
			       data);
	  }
	}
      }
    });

    frame.updateTitle();
    Container contents = frame.getContentPane();
    contents.setLayout(new BorderLayout());
    contents.add(scroller, BorderLayout.CENTER);
    if (data instanceof GestureContainer) {
      contents.add(frame.new SizeLabel((GestureContainer) data),
		   BorderLayout.SOUTH);
    }
    
    return frame;
  }

  public void updateTitle()
  {
    StringBuffer title = new StringBuffer();

    GestureObject data = gestureObjectDisplay.getDisplayedObject();
    if (data instanceof GestureContainer) {
      String name = ((GestureContainer) data).getName();
      title.append((name == null) ? "(unnamed)" : name);
    }
    else {
      title.append("example");
    }
    setTitle(title.toString());
    repaint();
  }
  
  public GestureObjectDisplay getGestureObjectDisplay()
  {
    return gestureObjectDisplay;
  }

  public boolean isCommandValid(int id)
  {
    return gestureObjectDisplay.isCommandValid(id);
  }

  public void doCommand(int id)
  {
    gestureObjectDisplay.doCommand(id);
  }

  public void addMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.add(ChangeListener.class, listener);
  }

  public void removeMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.remove(ChangeListener.class, listener);
  }

  protected class SizeLabel extends JLabel
    implements PropertyChangeListener {
    protected GestureContainer gestureContainer;
    
    public SizeLabel(GestureContainer gc)
    {
      super();
      setGestureContainer(gc);
    }

    public void setGestureContainer(GestureContainer gc)
    {
      if (gestureContainer != gc) {
	if (gestureContainer != null) {
	  gestureContainer.removePropertyChangeListener(this);
	}
	gestureContainer = gc;
	if (gestureContainer != null) {
	  gestureContainer.addPropertyChangeListener(this);
	}
	updateTitle();
      }
    }

    protected void updateTitle()
    {
      setText(gestureContainer.size() + " elements");
      this.repaint();
      this.revalidate();
    }
    
    public void propertyChange(PropertyChangeEvent e)
    {
      if (GestureContainer.CHILDREN_PROP == e.getPropertyName()) {
	updateTitle();
      }
    }
  }
}
