package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.GestureObject;
import edu.berkeley.guir.lib.gesture.GestureContainer;
import edu.berkeley.guir.lib.gesture.Gesture;

public interface GDTConstants {
  // menu constants
  int FILE_MENU			= 100;
  int OPEN_ACTION		= 101;
  int SAVE_ACTION		= 102;
  int SAVE_AS_ACTION		= 103;
  int SAVE_ALL_ACTION		= 104;
  int SAVE_TEST_SET_ACTION	= 105;
  int PRINT_ACTION		= 106;
  int PAGE_SETUP_ACTION		= 107;
  int CLOSE_ACTION		= 108;
  int QUIT_ACTION		= 109;
  int NEW_PACKAGE_ACTION	= 110;
  int NEW_TEST_SET_ACTION	= 111;
  
  int EDIT_MENU			= 200;
  int CUT_ACTION		= 201;
  int COPY_ACTION		= 202;
  int PASTE_ACTION		= 203;
  int DELETE_ACTION		= 204;
  int UNDO_ACTION		= 205;
  int REDO_ACTION		= 206;
  int PREFERENCES_ACTION	= 207;
  
  int VIEW_MENU			= 300;
  int NEW_VIEW_ACTION		= 301;
  int WARNINGS_TOGGLE_ACTION	= 302;
  int CLEAR_WARNINGS_ACTION	= 303;
  int ZOOM_IN_ACTION		= 304;
  int ZOOM_OUT_ACTION		= 305;
  int RESET_ZOOM_ACTION		= 306;
  
  int GESTURE_MENU		= 400;
  int NEW_GESTURE_ACTION	= 401;
  int NEW_GROUP_ACTION		= 402;
  int RENAME_ACTION		= 403;
  int ENABLE_ACTION		= 404;
  int DISABLE_ACTION		= 408;
  int TRAIN_SET_ACTION		= 405;
  int ANALYZE_SET_ACTION	= 406;
  int TEST_RECOGNITION_ACTION	= 407;

  //int _ACTION	= ;
  int EXPERT_MENU		= 500;

  int HELP_MENU_ACTION		= 600;
  int HELP_TUTORIAL_ACTION	= 601;
  int HELP_REFERENCE_ACTION	= 602;
  int HELP_ABOUT_ACTION		= 603;
  
  // debugging
  int DEBUG_ACTION_MASK		= 1<<20;
  int VALIDATE_PARENTS_ACTION	= DEBUG_ACTION_MASK+1;
  int DUMP_HUMAN_COORDS_ACTION	= DEBUG_ACTION_MASK+2;
  
  /** Actions that (may) change the data */
  int[]	CHANGE_ACTIONS = {
    NEW_TEST_SET_ACTION, CUT_ACTION, PASTE_ACTION, DELETE_ACTION,
    UNDO_ACTION, REDO_ACTION, PREFERENCES_ACTION, NEW_GESTURE_ACTION,
    NEW_GROUP_ACTION, RENAME_ACTION, ENABLE_ACTION, DISABLE_ACTION
  };

  /** Properties related to significant changes in the gestures.  That
      is, ones that affect recognition or analysis, not just
      display. */
  String[] CHANGE_PROPERTIES = {
    GestureObject.ENABLED_PROP,
    GestureContainer.CHILDREN_PROP,
    GestureContainer.NAME_PROP,
    Gesture.POINTS_PROP
  };
  
  // name prefixes when new objects are created
  String GESTURE_CATEGORY_PREFIX	= "gesture";
  String GESTURE_GROUP_PREFIX	= "group";
  String GESTURE_SET_PREFIX	= "set";

  // properties
  String CORRECT_RECOG_PROP	= "correctly recognized";
  /** value is Classifier.Result from Classifier.classify() */
}
