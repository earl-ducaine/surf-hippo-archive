//// See bottom of source code for software license

package edu.berkeley.guir.denim;

import java.awt.geom.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.image.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.awt.geom.*;

/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Oct 23, 2003 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class CanvasChooser extends JDialog implements SatinConstants
{

	static Rectangle2D viewport = new Rectangle2D.Double(0, 0, 500, 400);
	static final int xedge = 30;
	static final int yedge = 30;

	public class MapView extends JLabel
	{

		DenimSheet mDenimSheet;
		AffineTransform trans;

		Point2D originalpoint;

		BufferedImage mBuffer = null;

		public MapView(DenimSheet sheet)
		{
			mDenimSheet = sheet;
			mDenimSheet.updateContentBounds();
			this.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));

			this.addMouseListener(new MouseAdapter()
			{
				public void mousePressed(MouseEvent evt)
				{
					viewport =
						new Rectangle2D.Double(evt.getX(), evt.getY(), 1, 1);
					originalpoint = (Point2D) evt.getPoint().clone();
				}
			});

			this.addMouseMotionListener(new MouseMotionAdapter()
			{
				public void mouseDragged(MouseEvent evt)
				{
					double minx, maxx;
					if (evt.getPoint().getX() < originalpoint.getX())
					{
						minx = evt.getPoint().getX();
						maxx = originalpoint.getX();
					}
					else
					{
						maxx = evt.getPoint().getX();
						minx = originalpoint.getX();
					}

					double miny, maxy;
					if (evt.getPoint().getY() < originalpoint.getY())
					{
						miny = evt.getPoint().getY();
						maxy = originalpoint.getY();
					}
					else
					{
						maxy = evt.getPoint().getY();
						miny = originalpoint.getY();
					}

					viewport.setFrameFromDiagonal(minx, miny, maxx, maxy);

					Rectangle2D.intersect(
						MapView.this.getBounds(),
						viewport,
						viewport);

					MapView.this.repaint();
				}
			});

			this.addComponentListener(new ComponentAdapter()
			{
				public void componentShown(ComponentEvent e)
				{
					viewport =
						new Rectangle2D.Double(
							viewport.getX(),
							viewport.getY(),
							MapView.this.getWidth(),
							MapView.this.getHeight());
					mBuffer = null;
				}

				public void componentResized(ComponentEvent e)
				{
					mBuffer = null;
				}
			});
		}

		public void paintComponent(Graphics xg)
		{

			super.paintComponent(xg);

			if (mBuffer == null)
			{
				SatinImageLib.imageConvertingRender = true;
				
				mBuffer =
					new BufferedImage(
						this.getWidth(),
						this.getHeight(),
						BufferedImage.TYPE_INT_RGB);

				Graphics2D g = mBuffer.createGraphics();
				g.setClip(xg.getClip());

				Rectangle2D bounds = mDenimSheet.getContentBounds();
				double sx = (this.getWidth()-xedge*2) / bounds.getWidth();
				double sy = (this.getHeight()-yedge*2) / bounds.getHeight();
				double sc = sx > sy ? sy : sx;
				trans = AffineTransform.getTranslateInstance(xedge, yedge);
				trans.concatenate(AffineTransform.getScaleInstance(sc, sc));
				trans.concatenate(
					AffineTransform.getTranslateInstance(
						-bounds.getMinX(),
						-bounds.getMinY()));

				SatinGraphics graphics = new SatinGraphics();
				graphics.setGraphics(g);
				graphics.setIssuer(this);

				graphics.setBackground(mDenimSheet.getBackground());
				graphics.clearRect(0, 0, getWidth(), getHeight());

				graphics.setRenderingHint(
					RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_OFF);
				graphics.setRenderingHint(
					RenderingHints.KEY_ALPHA_INTERPOLATION,
					RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
				graphics.setRenderingHint(
					RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_OFF);
				graphics.setRenderingHint(
					RenderingHints.KEY_COLOR_RENDERING,
					RenderingHints.VALUE_COLOR_RENDER_SPEED);
				graphics.setRenderingHint(
					RenderingHints.KEY_DITHERING,
					RenderingHints.VALUE_DITHER_DISABLE);
				graphics.setRenderingHint(
					RenderingHints.KEY_RENDERING,
					RenderingHints.VALUE_RENDER_SPEED);
				graphics.setRenderingHint(
					RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
				graphics.setRenderingHint(
					RenderingHints.KEY_FRACTIONALMETRICS,
					RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
				graphics.setRenderingHint(
					RenderingHints.KEY_INTERPOLATION,
					RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);

				graphics.setRenderQuality(GraphicsConstants.HIGHEST_QUALITY);

				graphics.pushTransform(trans);

				mDenimSheet.render(graphics);
				
				graphics.setColor(Color.lightGray);
				graphics.draw(bounds);
				
				graphics.popTransform();
				
				viewport = getLocalViewportFromREL(bounds);
				viewport = new Rectangle2D.Double(viewport.getMinX()-5, 
							viewport.getMinY()-5, viewport.getWidth()+10,
							viewport.getHeight()+10);
							
				SatinImageLib.imageConvertingRender = false;
			}

			xg.drawImage(mBuffer, 0, 0, this);
		}
		
		public Rectangle2D getLocalViewportFromREL(Rectangle2D rel) {
			Rectangle2D rDst = new Rectangle2D.Double();
			// transform from REL in Sheet into Mapview
			GeomLib.transformRectangle(this.trans, rel, rDst);
			return rDst;
		}

		public void paint(Graphics g)
		{
			super.paint(g);
			g.setColor(Color.red);
			((Graphics2D) g).setStroke(new BasicStroke(2));
			((Graphics2D) g).draw(viewport);
		}

		public Rectangle2D getSheetRELViewport()
		{
			try
			{
				AffineTransform tr = this.trans.createInverse();
				Rectangle2D rDst = new Rectangle2D.Double();

				// transform from Mapview into REL in Sheet
				GeomLib.transformRectangle(tr, viewport, rDst);

				return rDst;
			}
			catch (Exception ex)
			{
				return viewport;
			}
		}
	}

	JRadioButton btn1;
	JRadioButton btn2;
	MapView mapview;
	DenimSheet mSheet;
	DenimPrinter mPrinter;

	Rectangle2D mRegion;

	public CanvasChooser(DenimSheet sheet, DenimPrinter printer)
	{
		super(printer, "Choose a Region", true);

		mSheet = sheet;
		mPrinter = printer;

		this.setBounds(0, 0, 600, 430);
		int x =
			(int) ((this.getToolkit().getScreenSize().getWidth()
				- this.getBounds().getWidth())
				/ 2);
		int y =
			(int) ((this.getToolkit().getScreenSize().getHeight()
				- this.getBounds().getHeight())
				/ 2);
		this.setBounds(x, y, 600, 430);

		this.setResizable(true);

		mapview = new MapView(mSheet);
		this.getContentPane().add(mapview, BorderLayout.CENTER);

		JPanel buttons = new JPanel();
		this.getContentPane().add(buttons, BorderLayout.SOUTH);

		JButton ok = new JButton("OK");
		JButton cancel = new JButton("Cancel");

		if (printer.mSelectedRegion == null)
		{
			cancel.setEnabled(false);
		}

		buttons.add(ok);
		buttons.add(cancel);

		ok.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent evt)
			{
				mPrinter.mSelectedRegion = mapview.getSheetRELViewport();
				mPrinter.mRegionBuffer = null;
				CanvasChooser.this.setVisible(false);
			}
		});

		cancel.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent evt)
			{
				CanvasChooser.this.setVisible(false);
			}
		});
	}

	public Rectangle2D getSheetRELViewport()
	{
		return this.mapview.getSheetRELViewport();
	}
}

//==============================================================================

/*
Copyright (c) 2003 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User 
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/