//// See bottom of source code for software license.
package edu.berkeley.guir.lib.util;

import java.util.Random;

/**
 * Utilities for dealing with random numbers.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @author  <A HREF="http://www.cs.berkeley.edu/~allanl/">Chris Long</A>
 * @version Last modified Aug 03 2002
 */
public class RandomLib {

   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   static Random librand = new Random();

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================






   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * No instances allowed.
    */
   private RandomLib() {
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================






   //===========================================================================
   //===   RANDOM METHODS   ====================================================

   public static double nextDouble(double a, double b) {
       return (nextDouble(librand, a, b));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a random float x, such that a <= x <= b (inclusive).
    *
    * @param  a is the lower bound.
    * @param  b is the upper bound. Please ensure a < b.
    * @return a float between a and b inclusive.
    */
   public static double nextDouble(Random rand, double a, double b) {

      // a and b are a range of values from a to b
      assert a < b; 
      double r = rand.nextDouble();

      r *= b - a;
      r += a;
      if (r > b) {
         r = b;
      }
      return (r);
   } // of method

   //-----------------------------------------------------------------

   public static float nextFloat(float a, float b) {
       return (nextFloat(librand, a, b));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a random float x, such that a <= x <= b (inclusive).
    *
    * @param  a is the lower bound.
    * @param  b is the upper bound. Please ensure a < b.
    * @return a float between a and b inclusive.
    */
   public static float nextFloat(Random rand, float a, float b) {

      // a and b are a range of values from a to b
      assert a < b; 
      float r = rand.nextFloat();

      r *= b - a;
      r += a;
      if (r > b) {
         r = b;
      }
      return (r);
   } // of method

   //-----------------------------------------------------------------

   public static int nextInt(int a, int b) {
       return (nextInt(librand, a, b));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a random integer x, such that a <= x <= b (inclusive).
    *
    * @param  a is the lower bound.
    * @param  b is the upper bound. Please ensure a < b.
    * @return an integer between a and b inclusive.
    */
   public static int nextInt(Random rand, int a, int b) {

      // failed a < b - a and b are a range of values from a to b
      assert a < b;
      double r = rand.nextDouble();

      r *= (b - a + 1);
      r += a;
      r = Math.floor(r);
      if (r > b) {
         r = b;
      }
      return ((int) r);
   } // of method

   //===   RANDOM METHODS   ====================================================
   //===========================================================================





   //===========================================================================
   //===   MAIN   ==============================================================

   public static void main(String[] argv) {
      int   iterations = 100000;
      int   minval     = 1;
      int   maxval     = 6;
      int[] arr        = new int[maxval - minval + 1];
      int   val;

      for (int i = 0; i < iterations; i++) {
         val = nextInt(minval, maxval);
         arr[val - minval]++;
      }
      for (int i = 0; i < arr.length; i++) {
         System.out.println("array[" + (i + minval) + "] - " + arr[i]);
      }

      for (int i = 0; i < 20; i++) {
         System.out.println(nextFloat(1, 6));
      }
   } // of main

   //===   MAIN   ==============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/

