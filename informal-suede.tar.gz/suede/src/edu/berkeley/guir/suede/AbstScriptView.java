package edu.berkeley.guir.suede;

import java.awt.*;
import javax.swing.*;
import java.util.Vector;

/* An AbstScriptView represents one linear dialog; a set of script nodes. There can be many of 
 * these in design and analysis modes. They are contained in a ScriptPane. There is only one of these
 * at a time in test mode.
 */

public abstract class AbstScriptView extends javax.swing.JComponent {
//public abstract class AbstScriptView extends javax.swing.JScrollPane {
	protected int            numScriptNodes = 0;
	protected SuedeModel     m_model;   
	private   Vector         m_scriptNodes  = new Vector();
	protected JComponent     m_contents     = new JPanel();
	protected ScriptTitleBar m_titleBar     = null;
	protected JScrollPane    m_scroll       = null;
	    
	  
	public AbstScriptView( String name ) {
   	setOpaque(true);
   	setEnabled(true);
   	setVisible(true);
   	//setLayout(new ScrollPaneLayout());
   	setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	    
   	m_contents.setLayout( new BoxLayout( m_contents, BoxLayout.X_AXIS ) );
	        
   	m_scroll = new JScrollPane(m_contents, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER,
                                                   	ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);        
	       
   	if ( name != null ) { // If they want a title bar...
      	m_titleBar = new ScriptTitleBar( name, this );
      	add( m_titleBar  );
   	}
	        
   	add( m_scroll );
	}
		    
		    
	public AbstScriptNodeModel getNode( int n ) {
		return (AbstScriptNodeModel)m_scriptNodes.elementAt( n );
	}
		    
		    
	public int getNumberNodes() {
		return m_scriptNodes.size();
	}
		    
	    
	public void setModel(SuedeModel model) {
   	m_model = model;
	}


	/**
	 * The minimum width is proportional to the number of nodes (it will be 0 with no nodes)
	 * The minimum height is fixed as the preferred height of the scroll pane.
	 */
	public Dimension getMinimumSize() {
		System.out.println ("Do I get called?");
		System.out.println ("m_scroll = " + m_scroll.getPreferredSize().height);
		System.out.println ("m_titleBar = " + m_titleBar.getPreferredSize().height);
   	return new Dimension(numScriptNodes*AbstScriptNodeView.WIDTH,
			m_scroll.getPreferredSize().height + ((m_titleBar != null) ? m_titleBar.getPreferredSize().height : 0 ) );
	}
	    
	    
	public Dimension getPreferredSize() {
		int prefWidth = super.getPreferredSize().width;
		Dimension min = this.getMinimumSize();
		if (min.width > prefWidth) prefWidth = min.width;
		
		//System.out.println("2 AbstScriptView.getPreferredSize: "+prefWidth+", "+min.height);

		return new Dimension(prefWidth, min.height);
	}
	   
	   
	public Dimension getMaximumSize() {
		//System.out.println("2 AbstScriptView.getMaximumSize w:"+super.getMaximumSize().width+" //calls getMin for height");
   	return new Dimension(super.getMaximumSize().width, getMinimumSize().height);   
	}
	    
	    
	public void scrollToEnd( AbstScriptNodeModel lastNode, int buttonWidth ) {
   	Dimension nodeSize = lastNode.getView().getMinimumSize();
   	Rectangle box = new Rectangle( (int)nodeSize.getWidth() * ( numScriptNodes - 1), 0 , 
                                    	(int)nodeSize.getWidth() + buttonWidth, (int)nodeSize.getHeight() );
   	lastNode.getView().scrollRectToVisible( box );
	}


	public void addScriptNode(AbstScriptNodeModel s) {
       m_scriptNodes.add(s);
       AbstScriptNodeView sView = s.getView();
       m_contents.add(sView);
       numScriptNodes++;
       m_contents.revalidate();
   }


   public void saveScript(java.io.PrintWriter pw, String path) {
   	//HV Oct1703
   	System.out.println ("AbstScriptView:saveScript");
      for (int i=0; i<m_scriptNodes.size();i++) {
      		String str = ((AbstScriptNodeModel)m_scriptNodes.get(i)).getCaption();
      		System.out.println (str);
          String tstring = ((AbstScriptNodeModel)m_scriptNodes.get(i)).save(path);
          pw.println(tstring);
      }
   }
}