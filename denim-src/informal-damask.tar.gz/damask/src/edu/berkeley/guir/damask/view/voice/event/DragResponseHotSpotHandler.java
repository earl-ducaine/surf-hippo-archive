package edu.berkeley.guir.damask.view.voice.event;

import java.awt.event.InputEvent;
import java.awt.geom.*;
import java.util.Collections;
import java.util.Iterator;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.component.SelectMany.Item;
import edu.berkeley.guir.damask.connection.*;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.voice.component.Prompt;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.berkeley.guir.damask.view.voice.dialog.Form;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.*;

/** 
 * The event handler that handles moving the endpoints of a response.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-24-2004 James Lin
 *                               Created DragResponseHotSpotHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 11-24-2004
 */
public class DragResponseHotSpotHandler extends PDragSequenceEventHandler {
   
   private Point2D origStartPt = null;
   private Point2D origEndPt = null;
   private Line2D line = new Line2D.Double();
   
   private Response.HotSpot hotSpot = null;
   private Response response = null;
   
   /**
    * Constructs a handler which will instantiate a component of the specified
    * type.
    * 
    * @param componentViewType a class which is a descendant of
    * {@link edu.berkeley.guir.damask.view.visual.component.ComponentView}
    */
   public DragResponseHotSpotHandler() {
      setEventFilter(new PInputEventFilter(InputEvent.BUTTON1_MASK));
   }


   private void updateLine(PInputEvent e) {
      if (hotSpot == response.getStartHotSpot()) {
         line.setLine(e.getPositionRelativeTo(response), origEndPt);
      }
      else {
         line.setLine(origStartPt, e.getPositionRelativeTo(response));
      }
      response.updateArrow(line);
   }

   
   // @Override
   public void startDrag(PInputEvent e) {
      super.startDrag(e);
      
      ((DamaskCanvas)e.getComponent()).stopTextEditing();
      
      final PNode startNode = e.getPickedNode(); 
      hotSpot =
         (Response.HotSpot)DamaskAppUtils.getAncestor(
            startNode, Response.HotSpot.class);
      if (hotSpot == null) {
         return;
      }
      response = hotSpot.getResponse();
      
      origStartPt =
         response.globalToLocal(
            response.getStartHotSpot().localToGlobal(
               response.getStartHotSpot().getBounds().getCenter2D()));
      
      origEndPt =
         response.globalToLocal(
            response.getEndHotSpot().localToGlobal(
               response.getEndHotSpot().getBounds().getCenter2D()));
      
      updateLine(e);
   }


   // @Override
   public void drag(final PInputEvent e) {
      super.drag(e);
      if (hotSpot == null) {
         return;
      }
      updateLine(e);
   }

   // @Override
   public void endDrag(final PInputEvent e) {
      super.endDrag(e);
      if (hotSpot == null) {
         return;
      }
      updateLine(e);

      // Find out what's underneath the hot spot just moved
      final boolean origResponsePickable = response.getPickable();
      final boolean origHotSpotPickable = hotSpot.getPickable();
      response.setPickable(false);
      hotSpot.setPickable(false);

      final DamaskCanvas canvas = (DamaskCanvas)e.getComponent();
      final DeviceType canvasDeviceType = canvas.getDeviceType();
      
      final Point2D ptCameraCoords = e.getPositionRelativeTo(e.getCamera());
      final PNode endNode =
         e.getCamera()
          .pick(ptCameraCoords.getX(), ptCameraCoords.getY(), 1)
          .getPickedNode();

      response.setPickable(origResponsePickable);
      hotSpot.setPickable(origHotSpotPickable);
      
      final Form form = response.getForm();
      final Trigger trigger = (Trigger)response.getModel();

      final MacroCommand cmd = new ModifyGraphMacroCommand();
      final boolean endDangling;


      // Find an existing out connection whose destination is the same
      // as the model of the response's current destination.
      NavConnection origOutConnection = null;
      if (response.getDest() != null) {
         final InteractionElement originalResponseDestModel =
            response.getDest().getModel();
         for (Iterator i = trigger.getOutConnections().iterator();
            i.hasNext();
            ) {
            final Connection connection = (Connection)i.next();
            if (connection.getConnectionDest(canvasDeviceType)
                  == originalResponseDestModel) {
               origOutConnection = (NavConnection)connection;
               break;
            }
         }
      }
      
      final ConnectionDest origOutConnectionDest;
      if (origOutConnection == null) {
         origOutConnectionDest = null;
      }
      else {
         origOutConnectionDest =
            origOutConnection.getConnectionDest(canvasDeviceType);
      }
      
      if (hotSpot == response.getStartHotSpot()) {
         // If the start hot spot was moved over a different prompt, then
         // move the model objects that the response represents after
         // that prompt's model. Erase the page that those objects were on
         // if the page becomes empty.
         final InteractionElement addTarget;

         if (endNode instanceof Prompt && endNode != response.getSource()) {
            addTarget = (Control)((Prompt)endNode).getModel();
            endDangling = false;
         }
         else {
            final Page lastPage =
               ((Dialog)form.getModel()).getLastPage(canvasDeviceType); 
            final Page pageForNewContent;
            if (lastPage.getRegion(Direction.CENTER).getControls().isEmpty()) {
               pageForNewContent = lastPage;
            }
            else {
               pageForNewContent = lastPage.split(Collections.EMPTY_LIST);
            }
            addTarget = pageForNewContent.getRegion(Direction.CENTER);
            endDangling = true;
         }
         
         // The following removes the trigger AND its associated connection
         cmd.addCommand(new RemoveControlCommand(trigger));
         
         if (addTarget instanceof PageRegion) {
            cmd.addCommand(new AddControlCommand((PageRegion)addTarget, trigger));
         }
         else {
            cmd.addCommand(new AddControlCommand((Control)addTarget, trigger));
         }
         
         // Find the control before "control", since if it's a select-many
         // item, select-one, or text input, it is also tied to the response.
         final Control beforeControl =
            DamaskUtils.getPreviousLowLevelControl(
               trigger.getPageRegion(canvasDeviceType), trigger);
         
         // A select-many item poses a difficulty, since it consists of a 
         // prompt and response. Therefore, if beforeControl is a
         // select-many item, we have to "break apart" the response and
         // the prompt. This is done by replacing the select-many item with
         // an instance of content.
         if (beforeControl instanceof SelectMany.Item) {
            final Item item = (SelectMany.Item)beforeControl;
            final AffineTransform itemTransform = item.getTransform(canvasDeviceType);
            final SelectMany selectMany = (SelectMany)item.getParent();
            final Content newContent = 
               new Content(
                  item.getContent(), selectMany.getDeviceType()); 
            cmd.addCommand(new AddControlCommand(selectMany, newContent));
            cmd.addCommand(new RemoveControlCommand(selectMany));
            
            // Add a select-one, which will represent the response instead
            // of the (now deleted) select-many.
            final SelectOne newSelectOne = 
               new SelectOne(selectMany.getDeviceType());
            newSelectOne.addItem(
               new SelectOne.Item(
                  new Content(
                     selectMany.getDeviceType(),
                     item.getVoiceResponseText(0))));
            newSelectOne.addItem(
               new SelectOne.Item(
                  new Content(
                     selectMany.getDeviceType(),
                     item.getVoiceResponseText(1))));

            if (addTarget instanceof PageRegion) {
               cmd.addCommand(
                  new AddControlCommand((PageRegion)addTarget, newSelectOne));
            }
            else {
               cmd.addCommand(
                  new AddControlCommand((Control)addTarget, newSelectOne));
            }
            cmd.addCommand(
               new SetTransformCommand(
                  newSelectOne, canvasDeviceType, itemTransform));
            cmd.addCommand(
               new SetTransformCommand(
                  newContent, canvasDeviceType, itemTransform));
         }
         else if ((beforeControl instanceof SelectOne) ||
               (beforeControl instanceof TextInput)) {
            cmd.addCommand(new RemoveControlCommand(beforeControl));
            if (addTarget instanceof PageRegion) {
               cmd.addCommand(new AddControlCommand((PageRegion)addTarget, beforeControl));
            }
            else {
               cmd.addCommand(new AddControlCommand((Control)addTarget, beforeControl));
            }
         }
         
         // Add back the connection that was removed when the trigger
         // was moved.
         if (origOutConnectionDest != null) {
            final boolean connectionDestIsForAllDeviceTypes;
            if (origOutConnectionDest instanceof Control) {
               connectionDestIsForAllDeviceTypes =
                  ((Control)origOutConnectionDest).isForAllDeviceTypes();
            }
            else {
               connectionDestIsForAllDeviceTypes =
                  ((Page)origOutConnectionDest).getDialog().getDeviceType() ==
                     DeviceType.ALL;
            }
            cmd.addCommand(
               new AddConnectionCommand(
                  canvasDeviceType,
                  trigger.isForAllDeviceTypes() &&
                     connectionDestIsForAllDeviceTypes,
                  trigger,
                  new InvokeEvent(trigger),
                  form.getDesignTimeCondition(),
                  origOutConnectionDest,
                  new GeneralPath(line)));
         }
      }
      else {
         // If the end hot spot was moved over a different prompt or form, then
         // change the destination of the out connection of the response's
         // trigger to the model of that prompt or form.
         ConnectionDest connectionDest = null;
         if (endNode instanceof Prompt && endNode != response.getDest()) {
            connectionDest = (ConnectionDest)((Prompt)endNode).getModel();
         }
         else {
            final Form endForm =
               (Form)DamaskAppUtils.getAncestor(endNode, Form.class);
            if (endForm != null && endForm != form) {
               connectionDest =
                  ((Dialog)endForm.getModel()).getFirstPage(canvasDeviceType);
            }
         }
         
         endDangling = (connectionDest == null);
            
         if (origOutConnection != null) {
            cmd.addCommand(new RemoveConnectionCommand(origOutConnection, false));
         }
         
         // If there isn't an existing connection and connectionDest is not
         // null, then add a new connection.
         if (connectionDest != null) {
            final boolean connectionDestIsForAllDeviceTypes;
            if (connectionDest instanceof Control) {
               connectionDestIsForAllDeviceTypes =
                  ((Control)connectionDest).isForAllDeviceTypes();
            }
            else {
               connectionDestIsForAllDeviceTypes =
                  ((Page)connectionDest).getDialog().getDeviceType() ==
                     DeviceType.ALL;
            }
            cmd.addCommand(
               new AddConnectionCommand(
                  canvasDeviceType,
                  trigger.isForAllDeviceTypes() &&
                     connectionDestIsForAllDeviceTypes,
                  trigger,
                  new InvokeEvent(trigger),
                  form.getDesignTimeCondition(),
                  connectionDest,
                  new GeneralPath(line)));
         }
      }

      if (endDangling) {
         cmd.addCommand(
            new SetVoiceResponseLineCommand(
               (Control)response.getModel(),
               form.getDesignTimeCondition(),
               line));
      }

      if (!cmd.isEmpty()) {
         canvas.getDocument().getCommandQueue().doCommand(
            canvas, cmd);
      }
   }  
}
