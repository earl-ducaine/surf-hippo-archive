package edu.berkeley.guir.damask.command;

import java.awt.geom.GeneralPath;

import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that removes a stroke from a piece of content.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-14-2003 James Lin
 *                               Created RemoveStrokeCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-14-2003
 */
public class RemoveStrokeCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final Content content;
   private final GeneralPath stroke;


   /**
    * Constructs the command.
    *  
    * @param content the content to remove the stroke from
    * @param stroke the stroke to remove
    */      
   public RemoveStrokeCommand(
      final Content content,
      final GeneralPath stroke) {

      this.content = content;
      this.stroke = stroke;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Remove stroke from " + content;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      content.removeStroke(stroke);
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      content.addStroke(stroke);
   }
}
