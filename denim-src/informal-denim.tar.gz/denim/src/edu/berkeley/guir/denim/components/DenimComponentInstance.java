package edu.berkeley.guir.denim.components;

import java.awt.*;
import java.awt.Color;
import java.awt.font.*;
import java.awt.Image;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.*;
import java.util.*;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import edu.berkeley.guir.denim.io.*;
import edu.berkeley.guir.denim.Arrow;
import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.ArrowSource;
import edu.berkeley.guir.denim.ContextMenuSource;
import edu.berkeley.guir.denim.DenimConstants;
import edu.berkeley.guir.denim.DenimPanel;
import edu.berkeley.guir.denim.DenimSheet;
import edu.berkeley.guir.denim.DenimSketch;
import edu.berkeley.guir.denim.DenimSketchContents;
import edu.berkeley.guir.denim.DenimUtils;
import edu.berkeley.guir.denim.action.DenimAction;
import edu.berkeley.guir.denim.action.DispatchDenimEvent;
import edu.berkeley.guir.denim.action.GotoPanel;
import edu.berkeley.guir.denim.event.DenimEvent;
import edu.berkeley.guir.lib.collection.Map2D;
import edu.berkeley.guir.lib.satin.event.SingleStrokeEvent;
import edu.berkeley.guir.lib.satin.image.SatinImageLib;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.widgets.PieMenu;

import edu.berkeley.guir.lib.satin.graphics.*;

/**
 * An instance of a DENIM component. This is what gets inserted into a DENIM
 * design when the user uses a rubber stamp, for example.
 * 
 * A component instance can display any one of the panels from the definition
 * of the component.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-05-1999  James Lin
 *                                Created DenimComponentInstance
 *             1.1.0  11-12-2002  Yang Li
 *                                Supports lightweight dragging
 * 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * 
 * @since   JDK 1.2
 * @version Version 1.1.0, 11-12-2002
 */
public abstract class DenimComponentInstance
	extends PatchImpl
	implements ArrowSource, ContextMenuSource, DenimConstants, DenimSketchContents
{

	//==========================================================================
	//===   CONSTANTS   ========================================================

	static final long serialVersionUID = 7186343057270291356L;

	//===   CONSTANTS   ========================================================
	//==========================================================================

	//==========================================================================
	//===   NONLOCAL VARIABLES   ===============================================

	protected DenimComponent type;
	protected DenimComponentInstance cloneSource;
	protected GraphicalObject displayedState; // the state of the component 
	// definition that this particular
	// instance is displaying
	protected GraphicalObject displayedDisplayedState;
	protected Set arrows; // outgoing arrows
	protected boolean matters = false; // indicates whether or not the 
	// component's state matters for
	// its panel's conditionals. 
	protected Map2D eventToArrow; // maps event & condition -> arrow
	protected Map2D eventToAction; // maps event & condition -> action
	// Events are set by corresponding
	// DenimComponent and should 
	// NEVER be modified

	//===   NONLOCAL VARIABLES   ================================================
	//===========================================================================

	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	/**
	 * Creates an instance of the given type. Called only by subclass's
	 * constructor, which is only called by the type's newInstance().
	 */
	DenimComponentInstance(DenimComponent type)
	{
		super();
		this.type = type;
		this.cloneSource = null;

		arrows = new HashSet();
		eventToArrow = type.createEmptyEventTable();
		eventToAction = type.createEmptyEventTable();

		type.trackInstance(this);

		//=== This is a patch with no border or fill
		Style style = getStyle();
		style.setDrawColor(NO_COLOR);
		style.setFillColor(NO_COLOR);
		setStyle(style);
	} // of constructor

	//===   CONSTRUCTORS   =====================================================
	//==========================================================================

	//===========================================================================
	//===   NESTED CLASSES   ====================================================

	public class DenimComponentInstanceFrame
	{

		Rectangle2D textFrame = null;
		boolean isVisible = false;
		Vector arrowFrame = new Vector();

		public void show(Graphics2D sg)
		{

			if (isVisible)
			{
				return;
			}

			isVisible = true;

			BasicStroke s =
				new BasicStroke(
					1,
					BasicStroke.CAP_SQUARE,
					BasicStroke.JOIN_BEVEL);
			Stroke oldStroke = sg.getStroke();
			Color oldColor = sg.getColor();

			sg.setStroke(s);
			sg.setXORMode(Color.CYAN);

			sg.draw(textFrame);

			for (int i = 0; i < arrowFrame.size(); i++)
			{
				Line2D line = (Line2D) arrowFrame.get(i);
				sg.draw(line);
			}

			sg.setPaintMode();
			sg.setStroke(oldStroke);
			sg.setColor(oldColor);

		}

		public void hide(Graphics2D g)
		{
			if (!isVisible)
			{
				return;
			}

			isVisible = false;

			BasicStroke s =
				new BasicStroke(
					1,
					BasicStroke.CAP_SQUARE,
					BasicStroke.JOIN_BEVEL);
			Stroke oldStroke = g.getStroke();
			Color oldColor = g.getColor();

			g.setStroke(s);
			g.setXORMode(Color.CYAN);

			g.draw(textFrame);

			for (int i = 0; i < arrowFrame.size(); i++)
			{
				Line2D line = (Line2D) arrowFrame.get(i);
				g.draw(line);
			}

			g.setPaintMode();
			g.setStroke(oldStroke);
			g.setColor(oldColor);

		}

		public void moveBy(Graphics2D sg, double dx, double dy)
		{

			if (dx == 0 && dy == 0)
			{
				return;
			}

			hide(sg);

			textFrame.setRect(
				textFrame.getMinX() + dx,
				textFrame.getMinY() + dy,
				textFrame.getWidth(),
				textFrame.getHeight());

			for (int i = 0; i < arrowFrame.size(); i++)
			{
				Line2D line = (Line2D) arrowFrame.get(i);
				line.setLine(
					line.getP1().getX() + dx,
					line.getP1().getY() + dy,
					line.getP2().getX(),
					line.getP2().getY());
			}

			show(sg);

		}

	}
	//===   NESTED CLASSES   ====================================================
	//===========================================================================

	public DenimComponentInstanceFrame getDenimComponentInstanceFrame()
	{

		DenimComponentInstanceFrame result = new DenimComponentInstanceFrame();

		result.textFrame = (Rectangle2D) getBounds2D(COORD_ABS).clone();

		Set navArrows = this.getOutgoingArrows();

		for (int i = 0; i < navArrows.size(); i++)
		{
			Point2D sp =
				((Arrow) navArrows.toArray()[i]).getStartPoint2D(COORD_ABS);
			Point2D ep =
				((Arrow) navArrows.toArray()[i]).getEndPoint2D(COORD_ABS);
			result.arrowFrame.add(new Line2D.Double(sp, ep));
		}

		return result;
	}

	//==========================================================================
	//===   ABSTRACT METHODS   ======================================

	public abstract void setTransparency(int transparency);

	//===   ABSTRACT METHODS   =================================================
	//==========================================================================

	//==========================================================================
	//===   ACCESSOR / MODIFIER METHODS   ======================================

	/**
	 * Returns the type of this component instance.
	 */
	public DenimComponent getComponentType()
	{
		return type;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns which state of the component definition this instance is
	 * showing.
	 */
	public GraphicalObject getDisplayedState()
	{
		return displayedState;
	}

	//-----------------------------------------------------------------

	/**
	 * Sets the state of the component definition this instance is showing
	 * to a copy of the given graphical object.
	 */
	public void setDisplayedState(GraphicalObject gob)
	{
		assert getStates().contains(gob) : DenimUtils.toShortString(gob)
			+ " is not a valid state of "
			+ type.getName();

		displayedState = gob;
		displayedDisplayedState = (GraphicalObject) (gob.deepClone());

		if (matters)
		{
			setTransparency(DenimConstants.DEFAULT_TRANSPARENCY);
		}
		else if(!(this instanceof DenimHyperlinkInstance))
		{
			setTransparency(DenimConstants.LOW_TRANSPARENCY);
		}
	}

	//-----------------------------------------------------------------

	/**
	 * Returns whether the state of this component instance matters in
	 * determining the current run-time condition of the instance's
	 * containing panel.
	 */
	public boolean getDoesMatterInConditionEval()
	{
		return matters;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the DENIM panel that contains this component instance.
	 */
	public DenimPanel getContainingPanel()
	{
		return DenimUtils.getContainingPanel(this);
	}
	//
	//-----------------------------------------------------------------
	//
	/**
	 * Returns the DENIM panel that contains this component instance.
	 */
	public DenimPanel getPanel()
	{
		return getContainingPanel();
	}

	//-----------------------------------------------------------------

	/**
	 * If this component instance is contained within another component
	 * instance, then returns the containing component instance. Otherwise,
	 * returns null.
	 * !It is called from the dispatch event only, which basically expects to 
	 * get a custom component instance
	 */
	public DenimComponentInstance getContainingComponentInstance()
	{
		DenimComponentInstance container = null;

		try
		{
			DenimSketch parentSketch = (DenimSketch) (this.getParentGroup());
			DenimPanel parentPanel =
				(DenimPanel) (parentSketch.getParentGroup());
			container = (DenimComponentInstance) (parentPanel.getParentGroup());
		}
		catch (Exception e)
		{
			container = null;
		}
		return container;
	}

	//-----------------------------------------------------------------
	//
	/**
	 * Returns a string representation of this object.
	 */
	public String toDebugString()
	{
		String output = super.toDebugString();
		output += "\nType:           " + type.getClass() + "\n";
		output += eventToActionString();

		return output;
	}

	//-----------------------------------------------------------------

	/**
	 * Sets the action that occurs when the instance receives an
	 * event of the given type to the given action
	 */
	private void setAction(DenimEvent e, int condition, DenimAction a)
	{

		assert type.hasEvent(e.getName()) : "Component type "
			+ type.getClass().toString()
			+ " does not support Event "
			+ e.getName();

		eventToAction.put(e.getName(), new Integer(condition), a);
	}

	//-----------------------------------------------------------------

	/**
	 * Gets the action that occurs when the instance receives an
	 * event of the given type.
	 */
	private DenimAction getAction(DenimEvent e, int condition)
	{

		DenimAction action =
			(DenimAction) eventToAction.get(
				e.getName(),
				new Integer(condition));

		// If there isn't any action that matches, then see if there is an
		// action which is not an outgoing transition.
		if (action == null)
		{
			action =
				(DenimAction) eventToAction.get(e.getName(), new Integer(1));
			if (action instanceof GotoPanel)
			{
				DenimPanel destPanel = ((GotoPanel) action).getDestPanel();
				if (!(destPanel.getParentGroup() instanceof DenimComponent))
				{
					action = null;
				}
			}
		}
		return action;
	}

	//-----------------------------------------------------------------

	/**
	 * Removes the action associated with the given event type.
	 */
	private DenimAction removeAction(DenimEvent e, int condition)
	{
		DenimAction a = getAction(e, condition);
		setAction(e, condition, null);
		return a;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns whether there is an action that occurs when the instance
	 * receives an event of the given type.
	 */
	public boolean hasAction(DenimEvent e, int condition)
	{
		return (getAction(e, condition) != null);
	}

	//-----------------------------------------------------------------

	/**
	 * Handles the given event by looking up the event type's associated
	 * action and running it.
	 */
	public void handleEvent(DenimEvent e, int condition)
	{

		DenimAction action = getAction(e, condition);

		if (action != null)
		{
			action.copy(this).run();
		}
	}

	//-----------------------------------------------------------------

	/**
	 * Returns a string representation of the event/action table.
	 */
	public String eventToActionString()
	{
		return eventToAction.toString();
	}

	//===   ACCESSOR / MODIFIER METHODS   ======================================
	//==========================================================================

	/**
	 * Delete this component instance.
	 */
	public void delete()
	{
		DenimPanel panel = this.getContainingPanel();
		// Panel should not be null, but we'll check for this because of another
		// bug in DENIM that allows components to be added to the sheet
		if (panel != null)
		{
			panel.componentInstanceIsRemoved(this);
		}
		super.delete();
		type.untrackInstance(this);
	}

	//==========================================================================
	//===   ARROW SOURCE METHODS   =============================================

	/**
	 * Tells the component instance to keep track of the given arrow, and
	 * associates the arrow's input event type with this component instance.
	 * The arrow should originate from the component instance.
	 */
	public void trackArrow(Arrow arrow)
	{
		assert arrow.getSource()
			== this : DenimUtils.toShortString(this)
				+ " should not be tracking "
				+ DenimUtils.toShortString(arrow);

		String eventType = arrow.getInputEventType();
		ArrowDest dest = arrow.getDest();
		int condition = arrow.getCondition();
		DenimPanel panel = getContainingPanel();

		//// 1. Have the panel containing this instance track the arrow.
		panel.trackNavArrow(arrow);

		//// 2. Keep track of the arrow, and associate the arrow's event
		////    and the containing panel's condition to this arrow.
		arrows.add(arrow);
		eventToArrow.put(eventType, new Integer(condition), arrow);

		//// 3. If the arrow isn't dangling, add arrow's event and
		////      destination to action table
		if (!(dest instanceof DenimCustomComponent))
		{

			setAction(
				new DenimEvent(this, eventType),
				condition,
				new GotoPanel(this, dest.getPanel()));
		}

		//// 4. If arrow is dangling and instance's panel is inside a 
		////      component, then add arrow's event and the event it will 
		////      throw into the action table
		else
		{
			GraphicalObject source = arrow.getSource();
			assert source.getParentGroup()
				instanceof DenimCustomComponent : "dest is null but "
					+ DenimUtils.toShortString(source)
					+ " is not in a DenimCustomComponent";

			setAction(
				new DenimEvent(this, eventType),
				condition,
				new DispatchDenimEvent(
					this,
					new DenimEvent(this, arrow.getOutputEventType())));
		}
	}

	//-----------------------------------------------------------------

	/**
	 * Tells the component instance to stop keeping track of the given arrow.
	 * The arrow should originate from the component instance.
	 */
	public void untrackArrow(Arrow arrow)
	{
		assert arrow.getSource()
			== this : DenimUtils.toShortString(this)
				+ " should not be untracking "
				+ DenimUtils.toShortString(arrow);

		String eventType = arrow.getInputEventType();
		int condition = arrow.getCondition();

		arrows.remove(arrow);
		eventToArrow.put(eventType, new Integer(condition), null);

		DenimPanel panel = getContainingPanel();

		// If panel is null, then it has already been deleted and we don't
		// have to worry about cleaning up state
		if (panel != null)
		{
			panel.untrackNavArrow(arrow);

			// remove corresponding event from transition table
			removeAction(new DenimEvent(this, eventType), condition);
		}
	}

	//-----------------------------------------------------------------

	/**
	 * Returns whether the component instance has the given arrow originating
	 * from it.
	 */
	public boolean hasArrow(Arrow arrow)
	{
		return arrows.contains(arrow);
	}

	//-----------------------------------------------------------------

	public Arrow getRedundantArrow(
		String eventType,
		int condition,
		ArrowDest dest)
	{
		Arrow oldArrow =
			(Arrow) eventToArrow.get(eventType, new Integer(condition));
		if (oldArrow == null)
		{
			oldArrow = getContainingPanel().getOrgArrowWithDestPanel(dest);
		}
		return oldArrow;
	}

	//-----------------------------------------------------------------

	public Set getOutgoingArrows()
	{
		return arrows;
	}

	//===   ARROW SOURCE METHODS   =============================================
	//==========================================================================

	//===========================================================================
	//===   DISPATCHING METHODS   ===============================================

	/**
	 * Prevents any single stroke events from being redispatched within
	 * the component.
	 */
	public void redispatchSingleStroke(SingleStrokeEvent evt)
	{
	}

	//===   DISPATCHING METHODS   ===============================================
	//===========================================================================

	//==========================================================================
	//===   MOUSE HANDLING METHODS   ===========================================

	/**
	 * Handles a mouse press. Intended for use during Run mode.
	 */
	public void mousePressed(MouseEvent e)
	{
	}

	//-----------------------------------------------------------------

	/**
	 * Handles a mouse release. Intended for use during Run mode.
	 */
	public void mouseReleased(MouseEvent e)
	{
	}

	//-----------------------------------------------------------------

	/**
	 * Handles a mouse enter. Intended for use during Run mode.
	 */
	public void mouseEntered(MouseEvent e)
	{
	}

	//-----------------------------------------------------------------

	/**
	 * Handles a mouse exit. Intended for use during Run mode.
	 */
	public void mouseExited(MouseEvent e)
	{
	}

	//-----------------------------------------------------------------

	/**
	 * Handles a mouse exit. Intended for use during Run mode.
	 */
	public void mouseDragged(MouseEvent e)
	{
	}

	//===   MOUSE HANDLING METHODS   ===========================================
	//==========================================================================

	//===========================================================================
	//===   CLONE   =============================================================

	public DenimComponentInstance getCloneSource()
	{
		return cloneSource;
	}

	/**
	 * Makes the given sketch a deep clone of this component instance, and
	 * returns the deep clone.
	 */
	protected Object deepClone(DenimComponentInstance clone)
	{
		super.deepClone(clone);
		clone.type = type;
		int index = indexOf(displayedState);
		if (index == -1)
		{
			clone.displayedState = this.getDisplayedState();
		}
		else
		{
			clone.displayedState = clone.get(indexOf(displayedState));
		}

		clone.matters = matters;

		//// 1. Clone the instance's event tables
		clone.eventToArrow = new Map2D(eventToArrow);
		clone.eventToAction = new Map2D(eventToAction);

		//// 2. The clone keeps track of its source so that, later, the clone's
		////    panel can search for references to component instances in the
		////    original panel and replace them with their clones, for example,
		////    the panel's conditionalStates.
		clone.cloneSource = this;

		return clone;
	}

	//===   CLONE   =============================================================
	//===========================================================================

	//==========================================================================
	//===   PIE MENU METHODS   =================================================

	public PieMenu getContextMenu()
	{
		PieMenu pieProject = new PieMenu(type.getName() + "\nInstance");
		JMenuItem item;
		String mattersOrNotString[] = { "Doesn't Matter", "Matters" };

		//      item = pieProject.add("Expand");
		//      item.setEnabled(false);

		//      item = pieProject.add("Contract");
		//      item.setEnabled(false);

		item = pieProject.add("Change State");
		item.addActionListener(new ChangeStateMenuListener());

		try
		{
			if (this.getStates().numElements() <= 1)
			{
				item.setEnabled(false);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}

		item = pieProject.add(mattersOrNotString[(matters) ? 0 : 1]);
		item.addActionListener(new MattersOrNotMenuListener());
		if (getStates().numElements() <= 1
			|| getContainingPanel().getNumConditions() <= 1)
		{
			item.setEnabled(false);
		}

		return pieProject;
	}

	//-----------------------------------------------------------------

	public class ChangeStateMenuListener implements ActionListener
	{

		public void actionPerformed(ActionEvent evt)
		{
			// Setup normal popup menu with all states.
			// We don't use a pie menu because the states are different sizes
			// and the number can change from component to component
			JPopupMenu popup = new JPopupMenu();
			GraphicalObjectCollection states = getStates();
			for(int i=0; i<states.numElements(); i++)
			{
				GraphicalObject gob = (GraphicalObject)states.get(i);
				
				Image stateImg;
				if (gob instanceof DenimPanel)
				{
					stateImg =
						SatinImageLib.toImage(((DenimPanel) gob).getSketch());
				}
				else if(gob instanceof TypedText)
                {
                    TypedText txt = (TypedText)gob;
                    Color old = txt.getTextArea().getForeground();
                    if(old==null)
                        txt.getTextArea().setForeground(Color.black);
                    stateImg = SatinImageLib.toImage(gob);
                }
                else
				{
					stateImg = SatinImageLib.toImage(gob);
				}
				
				Icon stateIcon = new ImageIcon(stateImg);
				JMenuItem menuItem = new JMenuItem(stateIcon);
				menuItem.addActionListener(new ChangeStateListener(gob));
				popup.add(menuItem);
			}

			// Show the pop up
			DenimSheet sheet = (DenimSheet) getSheet();
			popup.show(sheet, sheet.getLastX(), sheet.getLastY());
			popup.repaint();
		} // of actionPerformed
	}

	//-----------------------------------------------------------------

	public void defaultRender(SatinGraphics sg)
	{
		if (HtmlExport.isExporting()&&!(this instanceof DenimHyperlinkInstance))
        {
//		    if(this.isHTMLConvertible()==false)
//                super.defaultRender(sg);
        }
        else
        {
            super.defaultRender(sg);
        }
	}

	//-----------------------------------------------------------------

	public class ChangeStateListener implements ActionListener
	{

		private GraphicalObject state;

		public ChangeStateListener(GraphicalObject newState)
		{
			state = newState;
		}

		public void actionPerformed(ActionEvent evt)
		{
			setDisplayedState(state);
		} // of actionPerformed
	}

	//-----------------------------------------------------------------

	public class MattersOrNotMenuListener implements ActionListener
	{

		public void actionPerformed(ActionEvent evt)
		{
			if (matters)
			{
				// changing to doesn't matter
				setTransparency(DenimConstants.LOW_TRANSPARENCY);
			}
			else
			{
				// changing to matters
				setTransparency(DenimConstants.DEFAULT_TRANSPARENCY);
			}
			matters = !matters;
			DenimComponentInstance.this.damage(DAMAGE_NOW);
		} // of actionPerformed

	}

	//-----------------------------------------------------------------

	//===   PIE MENU METHODS   =================================================
	//==========================================================================

	/**
	 * clear all references hold by this object (In the namespace of this class)
	 */

	public void deepClear()
	{

		super.deepClear();

		type = null;
		cloneSource = null;
		displayedState = null;
		displayedDisplayedState = null;

		if (arrows != null)
		{
			arrows.clear();
			arrows = null;
		}

		eventToArrow = null;
		eventToAction = null;
	}

	abstract public GraphicalObjectCollection getStates();
    public abstract boolean isHTMLConvertible();
} // of class

//==============================================================================

/*
Copyright (c) 1999-2003 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
