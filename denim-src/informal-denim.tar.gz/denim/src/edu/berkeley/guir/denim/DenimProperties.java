package edu.berkeley.guir.denim;

import edu.berkeley.guir.lib.debugging.*;
import java.io.*;
import java.util.*;

/**
 * Class for reading in Denim properties.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-30-1999  JL
 *                    Created class DenimProperties
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 11-30-1999
 */
public class DenimProperties
   implements DenimConstants {

   //===========================================================================
   //===   CLASS VARIABLES AND METHODS   =======================================

   //static final long serialVersionUID = 3693643685539108020L;

   private static final Properties props;
   static {
      props = new Properties();
      initialize();
      load();
   } // of static initialization

   //===   CLASS VARIABLES AND METHODS   =======================================
   //===========================================================================



   //===========================================================================

   /**
    * Get a property.
    *
    * @param  strKey is the name of the property to retrieve.
    * @return Gets the value of the named property.
    */
   public static final String get(String strKey) {
      return (props.getProperty(strKey));
   }

   //===========================================================================

   /**
    * Get satin's globally defined properties.
    *
    * @return Some properties. Key values and default values are defined
    *         in file SatinConstants.java.
    */
   public static final Properties getProperties() {
      return (props);
   }

   /**
    * Get satin's globally defined properties.
    *
    * @return Some properties. Key values and default values are defined
    *         in file SatinConstants.java.
    */
   public static final void set(String key, String value) {
      props.setProperty(key, value);
   }


   /**
    * Clear out the properties and initialize with default values.
    */
   private static void initialize() {

      //// 1. Clear any old properties.
      props.clear();

   } // of initialize

   //===========================================================================

   /**
    * Load up Denim's properties file.
    */
   private static void load() {
      Debug.println("Reading from: " + getFileName());
      try {
         InputStream istream = new FileInputStream(getFileName());
         props.load(istream);
         Debug.println("Loaded properties file!");
      }
      catch (FileNotFoundException e) {
         Debug.println("Cannot find properties file - using defaults.");
      }
      catch (IOException e) {
         Debug.println("Error reading properties file - using defaults.");
         Debug.println(e);
      }
   } // of loadPropertiesFile


   /**
    * Save Denim's properties to the properties file.
    */
   public static void save() {
      try {
         OutputStream istream = new FileOutputStream(getFileName());
         props.store(istream, "Denim Properties");
         Debug.println("Saved properties file!");
      }
      catch (IOException e) {
         Debug.println("Error saving properties file");
         if (Debug.getDebugMode() == Debug.ON) {
            e.printStackTrace();
         }
      }
   } // of savePropertiesFile

   //===   CLASS VARIABLES AND METHODS   =======================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * No instances, if you please.
    */
   protected DenimProperties() {
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================


   /**
    * Returns the file that these properties are in.
    */
   public static String getFileName() {
      return DENIM_DATADIRECTORY + DENIM_PROPERTIES_FILENAME;
   }


   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   /**
    * Print out what properties will be retrieved. Be sure you are in
    * the directory containing the Satin data directory when running.
    */
   public static final void main(String[] argv) {
      Properties p = DenimProperties.getProperties();
      p.list(System.out);
      System.exit(0);
   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class DenimProperties

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
