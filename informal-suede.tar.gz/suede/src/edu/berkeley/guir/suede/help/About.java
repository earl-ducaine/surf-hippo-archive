package edu.berkeley.guir.suede.help;

import javax.swing. *;
import java.awt.*;
import java.awt.event.*;

public class About extends JDialog {

    /** Initializes the Form */
    public About() {
        super ();
        initComponents ();
        pack ();
    }
        private JMenuBar AboutMenuBar;
        private JMenu AboutMenu;
        private JMenuItem CloseItem;
        private JTextField AboutContents;
        
        private void initComponents () {
            AboutMenuBar = new JMenuBar ();
            AboutMenu = new JMenu ();
            CloseItem = new JMenuItem ();
            AboutContents = new JTextField ();

            AboutMenu.setText ("About");

            CloseItem.setText ("Close");
            CloseItem.addActionListener (new ActionListener () {
                                              public void actionPerformed (ActionEvent evt) {
                                                  CloseItemActionPerformed (evt);
                                              }
                                          }
                                         );

            AboutMenu.add (CloseItem);
            AboutMenuBar.add (AboutMenu);
            setTitle ("About");
            addWindowListener (new WindowAdapter () {
                                   public void windowClosing (WindowEvent evt) {
                                       closeDialog (evt);
                                   }
                               }
                              );

            AboutContents.setText ("Suede 1.0 Beta 7");
            AboutContents.setEditable (false);

            getContentPane ().add (AboutContents, BorderLayout.CENTER);

            setJMenuBar (AboutMenuBar);

        }

        private void CloseItemActionPerformed (ActionEvent evt) {
            closeDialog(null);
        }


    /** Closes the dialog */
        private void closeDialog(WindowEvent evt) {
            setVisible (false);
            dispose ();
        }
    }

