package edu.berkeley.guir.denim.components;

import edu.berkeley.guir.denim.*;
import java.awt.geom.*;
import javax.swing.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.watch.*;

/**
 * An instance of a text field in a DENIM design. This is a built-in
 * component.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-29-2001  Boxin Li
 *                                Created DenimIntrinsicComponent
 * </PRE>
 *
 *
 * @since   JDK 1.2
 * @version Version 1.0.0  01-29-2001
 */

public class DenimTextFieldInstance
   extends DenimComponentInstance {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   private JTextField tf;
   private DenimSheet sheet;

   //===   CONSTANTS   =========================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   DenimTextFieldInstance(DenimComponent type) {
      this(type, null);
      super.matters = false;
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   COMPONENT METHODS   =================================================


   DenimTextFieldInstance(DenimComponent type,
                       GraphicalObjectGroup appearance) {
      super(type);
      super.matters = false;
      
      assert type instanceof DenimTextField;
      // "DenimTextFieldInstance can only be created by DenimTextField"

      if (appearance == null) {
         tf = new JTextField();
         tf.setBounds(0,0,100,20);
         tf.setBorder(BorderFactory.createTitledBorder(""));
         tf.setVisible(true);
         displayedState = new GObJComponentWrapper(tf);
      }
      else {
         tf = null;
         displayedState = appearance;
      }

      this.add(displayedState);
      this.setBoundingPoints2D(COORD_LOCAL, displayedState.getBoundingPoints2D(COORD_LOCAL));
      Debug.println("New instance of DenimTextField created.");
   }

   //-----------------------------------------------------------------

   public GObJComponentWrapper getJCWrapper() {
     return (GObJComponentWrapper)displayedState;
   }

   /**
    * Returns the associated JTextField, if there is one.
    */
   public JTextField getJTextField() {
      return tf;
   }

   //===   COMPONENT METHODS   =================================================
   //===========================================================================


   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Returns a deep clone of this textfield instance.
    */
   public Object deepClone() {
      return deepClone(new DenimTextFieldInstance(type));
   }

   //-----------------------------------------------------------------

   /**
    * Sets the clone parameter to a deep clone of this textfield instance,
    * and returns it.
    */
   public Object deepClone(DenimTextFieldInstance clone) {
      super.deepClone(clone);
      return clone;
   }

   //===   CLONE METHODS   =====================================================
   //===========================================================================

   /**
    * Gets the text inside the text field instance.
    */
   public String getText() {
      return tf.getText();
   }

   //-----------------------------------------------------------------

   /**
    * Sets the text inside the text field instance to the given text.
    */
   public void setText(String text) {
      tf.setText(text);
   }

   //-----------------------------------------------------------------

   public void onUpdate(Watchable w, String s, Object oldVal, Object newVal) {
      Debug.println(s + ": " + oldVal + "->" + newVal);
      if ((oldVal instanceof Rectangle2D) &&
          (newVal instanceof Rectangle2D)) {
         Point2D p =  new Point2D.Float();
         Rectangle2D rect = (Rectangle2D)newVal;
         p.setLocation(rect.getX(), rect.getY());
         Point2D pt = GraphicalObjectLib.absoluteToLocal(this, p);
         rect.setRect(pt.getX(), pt.getY(), rect.getWidth(), rect.getHeight());
         if (s == NOTIFY_BOUNDS) {
            setBoundingPoints2D(COORD_LOCAL, (Rectangle2D)newVal);
         }
      }
   }

   //-----------------------------------------------------------------

   public void setTransparency(int transparency) {
   }
   
   //----------------------------------------
   
   /**
    * clear all references hold by this object (In the namespace of this class)
    */
   
   public void deepClear() {
      super.deepClear();
      tf = null;
   }
   
   public GraphicalObjectCollection getStates() {
	   return type.empty;
   }
   
   
   public GraphicalObject getDisplayedState() {
	  return this.displayedState;
   }
      
   public boolean isHTMLConvertible() {
       return true;
   }

} // of class


//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
