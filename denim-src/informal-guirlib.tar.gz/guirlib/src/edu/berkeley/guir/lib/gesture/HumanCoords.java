package edu.berkeley.guir.lib.gesture;

import edu.berkeley.guir.lib.gesture.features.*;
import edu.berkeley.guir.lib.gesture.util.Misc;

/**
  Compute the coordinates of a gesture in human feature-space.
  Based on first similarity experiment.
  */
public class HumanCoords
{
  private HumanCoords() {}
  
  public static double[] computeCoords(Gesture gesture)
  {
    double[] coords = new double[5];
    
    double curviness2 = gestureValue(Curviness2.class, gesture);
    double anglePerDist = gestureValue(AnglePerDistance.class, gesture);
    coords[0] = -0.29285916 * curviness2  -44.16376392873 * anglePerDist +
      2.08250756;

    double totalAbsAngle = gestureValue(TotalAbsAngle.class, gesture);
    double logAspect = gestureValue(LogAspect.class, gesture);
    /* This is Just Wrong.  I don't know where it came from
    coords[1] = -0.006817636 * endsDistance - 0.17072756 * totalAbsAngle +
      2.204771349;
    */
    coords[1] = -0.204093790874 * totalAbsAngle -0.342099976898 * logAspect
      + 1.372313843226;
      
    double cosInitAngle = gestureValue(InitAngleCosine.class, gesture);
    double density1 = gestureValue(Density1.class, gesture);
    coords[2] = -0.58019900 * cosInitAngle + 0.053814637 * density1 -
      0.40120782;

    double endsDistance = gestureValue(EndsDistance.class, gesture);
    double sinInitAngle = gestureValue(InitAngleSine.class, gesture);
    double bbAngle =  gestureValue(BoundsAngle.class, gesture);
    double cosEnds =  gestureValue(EndsAngleCosine.class, gesture);
    coords[3] = -0.814554697 * cosInitAngle + 0.48012199 * sinInitAngle -
      0.531756520 * bbAngle - 0.004912005 * endsDistance -
      1.22419693 * cosEnds + 1.545189697;

    double totalAngle = gestureValue(TotalAngle.class, gesture);
    double sharpness = gestureValue(Sharpness.class, gesture);
    double aspect = gestureValue(Aspect.class, gesture);
    /** This is also Just Wrong.
    double sinEnds = gestureValue(EndsAngleSine.class, gesture);
    double density2 = gestureValue(Density2.class, gesture);
    double curviness = gestureValue(Curviness.class, gesture);
    double logArea = gestureValue(LogArea.class, gesture);
    coords[4] = -1.333697141 * sinInitAngle + 0.0087570207 * endsDistance +
      0.37584357 * cosEnds + 1.94029848 * sinEnds -
      0.132238901 * curviness2 + 0.0233725531 * density2 -
      4.0258576 * curviness - 3.3873568 * logArea + 0.5644005 * logAspect +
      15.5497108;
    */
    coords[4] = -0.604946888172 * cosInitAngle + 0.048878922781 * totalAngle
      + 0.138386160534 * sharpness + 5.706718272706 * aspect
      -2.602023183052;
      
    return coords;
  }

  public static double gestureValue(Class featureClass, Gesture g)
  {
    return FeatureFactory.getFeature(featureClass, g).getValue();
  }
  
  public static double distanceSq(double[] x, double[] y)
  {
    double dist = 0;
    
    for (int i = 0; i < x.length; i++) {
      dist += (x[i] - y[i]) * (x[i] - y[i]);
    }
    return dist;
  }

  public static double[] averageCoords(GestureCategory gc)
  {
    double[] sum = new double[5];
    int numGestures = gc.size();

    for (int j = 0; j < sum.length; j++) {
      sum[j] = 0;
    }
    for (int i = 0; i < numGestures; i++) {
      double[] coords = computeCoords(gc.gestureAt(i));
      for (int j = 0; j < sum.length; j++) {
	sum[j] += coords[j];
      }
    }
    for (int j = 0; j < sum.length; j++) {
      sum[j] /= numGestures;
    }

    return sum;
  }

  public static class DistanceInfo {
    public double distanceSq;
    public Class featureClass;
    public int dimension;
    public int direction;
  }

  public static DistanceInfo getDistanceInfo(GestureCategory gc1,
					     GestureCategory gc2)
  {
    double dist = 0;
    double maxDist = 0;
    int dimension = -1;
    int direction = 0;
    double[] x = averageCoords(gc1);
    double[] y = averageCoords(gc2);
      
    for (int i = 0; i < x.length; i++) {
      double delta = x[i] - y[i];
      double deltaSq = delta * delta;
      dist += deltaSq;
      if (deltaSq > maxDist) {
	maxDist = delta;
	dimension = i;
	direction = Misc.sign(delta);
      }
    }

    DistanceInfo result = new DistanceInfo();
    result.distanceSq = dist;
    result.dimension = dimension;
    result.featureClass = findPrincipleComponent(dimension);
    result.direction = direction;
    return result;
  }
  
  /** computes the average coordinates of all gestures in each category, then
    computes the distance between the averages */
  public static double distanceSq(GestureCategory gc1, GestureCategory gc2)
  {
    double[] average1 = averageCoords(gc1);
    double[] average2 = averageCoords(gc2);

    return distanceSq(average1, average2);
  }

  /** This is the list of which feature contributes most to each of
      the dimensions, normalized for their values (i.e., based on
      their standardized beta coefficient from the mds analysis). */
  private static final Class[] PRINCIPLE_COMPONENTS = {
    Curviness2.class,
    TotalAbsAngle.class,
    Density1.class,
    EndsAngleCosine.class,
    Aspect.class
  };
  public static Class findPrincipleComponent(int dimension)
  {
    return PRINCIPLE_COMPONENTS[dimension];
  }
  
  /* todo
  public static double maxDistance = 0;
  
  public static Double[][] allDistances(GestureSet gestureSet)
  {
    int numCategories = gestureSet.trainingSize();
    
    Double[][] distance = new Double[numCategories][numCategories];

    maxDistance = 0;
    for (int row = 0; row < numCategories; row++) {
      for (int column = row; column < numCategories; column++) {
	double dist = Math.sqrt(distanceSq((GestureCategory)
					   gestureSet.getChild(row),
					   (GestureCategory)
					   gestureSet.getChild(column)));
	Double Dist = new Double(dist);
	distance[row][column] = Dist;
	distance[column][row] = Dist;
	if (dist > maxDistance)
	  maxDistance = dist;
      }
    }

    return distance;
  }
  */
}
