package edu.berkeley.guir.damask.view.voice.component;

import edu.berkeley.guir.damask.component.Component;

/** 
 * A view of a component.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  08-16-2004 James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public abstract class VoiceComponent extends VoicePart {

   /**
    * Creates a view of the specified component.
    */
   protected VoiceComponent(final Component component) {
      super(component);
   }
   
   /**
    * Initializes a view of the specified component.
    * 
    * @param component the component for which this view is created
    * @param useDefaultElementListener true if this instance should add
    * an InteractionElementListener that automatically adjusts the bounds
    * and transform of the view by listening to changes in the model
    */
   protected VoiceComponent(
      final Component component,
      final boolean useDefaultElementListener) {

      super(component, useDefaultElementListener);
   }
}
