package edu.berkeley.guir.denim.interpreters;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.stroke.*;
//import edu.berkeley.guir.denim.dialogs.*;
//import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

/**
 * Handles creating components from selected panels, using the blank rubber
 * stamp tool.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-30-1999 JL
 *                    Created class EraserInterpreter.
 * </PRE>
 *
 * @see    BlankRubberStamp
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version Version 1.0.0, 10-30-1999
 */
public class BlankRubberStampInterpreter
   extends DefaultInterpreterImpl
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 337237824245765579L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================


   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates a blank rubber stamp interpreter.
    */
   public BlankRubberStampInterpreter() {
      super();
      commonInitializations();
   }

   //-----------------------------------------------------------------

   /**
    * Creates a blank rubber stamp interpreter as a copy of the given
    * interpreter.
    */
   public BlankRubberStampInterpreter(BlankRubberStampInterpreter intrp) {
      //// 1. Since this interpreter is stateless, we can do this safely.
      this();
   }

   //-----------------------------------------------------------------

   /**
    * Performs initializations common to constructors.
    */
   private void commonInitializations() {
      setName("Denim Blank Rubber Stamp Interpreter");
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   /**
    * Called when the user taps the blank rubber stamp. Creates a
    * {@link DenimCustomComponent custom component} from the selected panels.
    */
   public void handleNewStroke(NewStrokeEvent evt) {
      DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject();
      TimedStroke stk = evt.getStroke();
      Point2D p = stk.getEndPoint2D(COORD_ABS);

      // 1. Add selected objects to a new "storyboard," which will describe
      //    the new component.
      GraphicalObjectCollection gobcol = cmdsubsys.getSelectedCollection();

      //    If there are no selected objects, then pick the panel close
      //    to the cursor, if any.
      if (gobcol == null || gobcol.isEmpty()) {
         gobcol = sheet.getGraphicalObjects(COORD_ABS, p.getX(), p.getY(),
                                            FIRST, SHALLOW, NEAR);
         GraphicalObject gob = gobcol.getFirst();
         if (gob instanceof DenimPanel) {
            gobcol = new GraphicalObjectCollectionImpl();
            gobcol.add(gob);
         }
      }

      // 2. Ask the user for a name for the new component
      //Window parentWin = (Window)SwingUtilities.getRoot(sheet);
      //Rectangle2D stkbounds = stk.getBounds2D(COORD_ABS);
      //int x = (int)stkbounds.getX() + parentWin.getX();
      //int y = (int)stkbounds.getY() + parentWin.getY();
/*      String componentName = JOptionPane.showInputDialog
         (null,
          "Please enter a name for your new component.",
          "Denim",
          JOptionPane.QUESTION_MESSAGE);
*/
      if (gobcol != null && !gobcol.isEmpty()) {
		
		// 2. Ask the user for a name for the new component
		String componentName = JOptionPane.showInputDialog
		   (null,
			"Please enter a name for your new component.",
			"Denim",
			JOptionPane.QUESTION_MESSAGE);
			
        // 3. Create and register the new component.
        sheet.disableDamage();
        DenimCustomComponent newComponent =
            new DenimCustomComponent(componentName,
               new ImageIcon
                  (Denim.class.getResource("images/stamps/rubber_stamp.gif")),
               gobcol);
         
         // let customized component have a parent
         //newComponent.setVisible(false);
         //sheet.addToBack(newComponent);

         cmdsubsys.clearSelected();
         sheet.enableDamage();
         sheet.damage(DAMAGE_LATER);

         // HACK:
         // 4. Add tool to tools area -- should be handled by component registry?
         /*ToolsArea toolsArea =
            sheet.getDenimUI().getToolbox().getToolsArea();

         RubberStamp stamp = newComponent.getRubberStamp();
         stamp.setLocation(350, 10);
         toolsArea.add(stamp);
         toolsArea.repaint();
         //stamp.setVisible(true);
         //stamp.activate();*/
         evt.setConsumed();
      }
   }

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      return (new BlankRubberStampInterpreter(this));
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
