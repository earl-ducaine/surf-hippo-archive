package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that adds a component group to a page region.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  05-31-2004 James Lin
 *                               Created AddGroupCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 05-31-2004
 */
public class AddGroupCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final Dialog dialog;
   private final ComponentGroup group;
   
   /**
    * Constructs the command.
    *  
    * @param region the page region to add the control to
    * @param control the control to add
    */      
   public AddGroupCommand(final Dialog dialog, final ComponentGroup group) {
      this.dialog = dialog;
      this.group = group;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Add component group " + group.toLongString() + " to dialog " + dialog;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      dialog.addGroup(group);
   }
   

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      dialog.removeGroup(group);
   }
}
