package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.beans.*;
import javax.swing.event.EventListenerList;
import javax.swing.event.ChangeListener;

/** Show a gestureGroup as a thumbnail. */
public class GestureGroupThumbnailPanel extends JPanel
  implements GestureObjectDisplay, GDTConstants {
  protected EventListenerList listenerList = new EventListenerList();
  protected PropertyChangeListener propChangeListener =
    new MyPropChangeListener();
  protected GestureGroup group;
  protected JLabel label;
  protected GesturePointsDisplay icon;
  
  public GestureGroupThumbnailPanel()
  {
    this(null);
  }

  public GestureGroupThumbnailPanel(GestureGroup group)
  {
    this(group, null);
  }

  public GestureGroupThumbnailPanel(GestureGroup group,
				    JScrollPane scrollPane)
  {
    super(new BorderLayout());
    buildUI();
    setGroup(group);
  }

  public void setGroup(GestureGroup group)
  {
    if (this.group != group) {
      if (this.group != null) {
	this.group.removePropertyChangeListener(propChangeListener);
      }
      this.group = group;
      if (group != null) {
	group.addPropertyChangeListener(propChangeListener);
      }
      updateTitle();
      updateIcon();
    }
  }

  public GestureObject getDisplayedObject()
  {
    return group;
  }
  
  protected void buildUI()
  {
    add(new JLabel("Group:"), BorderLayout.NORTH);
    icon = new GesturePointsDisplay();
    add(icon, BorderLayout.CENTER);
    label = new JLabel();
    add(label, BorderLayout.SOUTH);
    updateTitle();
    setBorder(BorderFactory.createLoweredBevelBorder());
  }

  protected void updateIcon()
  {
    if ((group != null) && (group.size() > 0)) {
      GestureCategory cat = group.get(0);
      if ((cat != null) && (cat.size() > 0)) {
	icon.setGesture(cat.gestureAt(0));
	revalidate();
      }
    }
  }
  
  protected void updateTitle()
  {
    String name = (group == null) ? "(no group)" : group.getName();
    label.setText(name);
    repaint();
    revalidate();
  }

  //----------------------------------------------------------------------
  // command handling

  public boolean isCommandValid(int id)
  {
    return false;
  }

  public void doCommand(int id)
  {
    System.err.println("GestureGroupThumbnailPanel handles no commands"
		       + " (was given id " + id + ")");
  }

  public void addMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.add(ChangeListener.class, listener);
  }
  
  public void removeMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.remove(ChangeListener.class, listener);
  }

  public String getInputGestureTitle()
  {
    return "Draw a gesture"; 
  }

  public boolean gestureDrawn(Gesture g)
  {
    System.err.println("GestureGroupThumbnailPanel does not accept gestures");
    return false;
  }

  public boolean canAcceptGesture()
  {
    return false;
  }

  public void setScale(double s)
  {
  }

  public double getScale()
  {
    return 1.0;
  }
  
  public void addActionListener(ActionListener l)
  {
    listenerList.add(ActionListener.class, l);
  }

  public void removeActionListener(ActionListener l)
  {
    listenerList.remove(ActionListener.class, l);
  }

  //----------------------------------------------------------------------
  // helper classes
  
  protected class MyPropChangeListener extends EnableListener {
    public MyPropChangeListener() {
      super(GestureGroupThumbnailPanel.this);
    }
    
    public void propertyChange(PropertyChangeEvent evt) {
      String propName = evt.getPropertyName();
      if (propName == GestureContainer.NAME_PROP) {
	GestureGroupThumbnailPanel.this.updateTitle();
      }
      else if ((propName == GestureContainer.CHILDREN_PROP) ||
	       (propName == GestureContainer.CHILD_CHANGE_PROP)) {
	GestureGroupThumbnailPanel.this.updateIcon();
      }
      super.propertyChange(evt);
    }
  }
}
