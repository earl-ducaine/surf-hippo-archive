//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * A container for a graph.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Nov 06 1997, JH
 *               Created class
 *             - GUIRLib-v1.5/1.1.0, Nov 26 2002, JH
 *               Rewhacked the code, fixed some bugs, updated for JDK1.4
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.3RC1
 * @version GUIRLib-v1.5/1.1.0, Nov 26 2002
 */
public class Graph 
   implements Serializable {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * Default graph parser.
     * @see GraphEdge#PARSER
     * @see GraphNode#PARSER
     */
    public static final GraphParser PARSER = new GraphParserDefaultImpl();

    //===   CONSTANTS   ========================================================
    //==========================================================================





    //==========================================================================
    //===   CLASS VARIABLES   ==================================================

    /**
     * The default max number of GraphNodes in the Graph. This sets the initial
     * size of the HashMap that contains the GraphNodes.
     */
    private static int iNumGraphNodes = GraphConst.DEFAULT_NUMBER_NODES;

    //===   CLASS VARIABLES   ==================================================
    //==========================================================================





    //==========================================================================
    //===   CLASS METHODS   ====================================================

    /**
     * Sets the default number of maximum GraphNodes in the Graph. The graph 
     * will dynamically resize itself if necessary but it is more efficient 
     * this way.
     *
     * @param numGraphNodes is the default number of graph nodes.
     */
    public static void setDefaultNumberOfGraphNodes(int numGraphNodes) {
       if (iNumGraphNodes > GraphConst.DEFAULT_NUMBER_NODES) {
          iNumGraphNodes = numGraphNodes;
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Sets the default number of edges in the Adjacency List of each 
     * GraphNode. The Adjacency List will dynamically resize itself if 
     * necessary but it is more efficient this way.
     *
     * @param numEdges is the number of edges, and must be greater than the
     *        default number of edges. If it is less, then it will revert to
     *        the default number of edges. Ignores negative values.
     */
    public static void setDefaultNumberOfEdges(int numEdges) {
       GraphNode.setDefaultNumberOfEdges(numEdges);
    } // of method

    //===   CLASS METHODS   ====================================================
    //==========================================================================






    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    /**
     * This is the table that contains the GraphNodes. Each GraphNode 
     * itself contains its own adjacency list of inlinks and outlinks. 
     * <P>
     * The key for this table is the name of the GraphNode, and it refers 
     * to the actual GraphNode object. (String graphNodeName -> GraphNode node)
     */
    HashMap mapGraphNodes;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================






    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Default constructor.
     */
    public Graph() {
       mapGraphNodes = new HashMap(iNumGraphNodes);
    } // of default constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================






    //==========================================================================
    //===   MODIFIER METHODS   =================================================

    /**
     * Add a new GraphNode if and only if it is not already in the Graph. If it
     * is already in the Graph, there will be no effect.
     *
     * @param strGraphNodeName is the name of the GraphNode to add to the Graph.
     */
    public void addNode(String strGraphNodeName) {
       //// 1. See if the GraphNode is already in our table. If it is not, then
       ////    add it to the table.
       if ( !nodeExists(strGraphNodeName)) {
          mapGraphNodes.put(strGraphNodeName, new GraphNode(strGraphNodeName));
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add the GraphNode if and only if it is not already in the Graph. If it
     * is already in the Graph, there will be no effect. If it is not, 
     * it will correctly add in the inlinks and outlinks of this GraphNode
     * to the Graph (creating those GraphNodes too if necessary).
     *
     * @param node is the GraphNode to add to the Graph.
     */
    public void addNode(GraphNode node) {
       String   strGraphNodeName;   // the name of the GraphNode we are adding
       String   strGraphNodeTmp;    // temp handle for the name of a GraphNode
       float    weight;             // temp weight when inserting a GraphNode
       Iterator it;

       //// 1. See if the GraphNode is already in our table. If it is not, then
       ////    add it to the table.
       strGraphNodeName = node.getName();
       if ( !nodeExists(strGraphNodeName) ) {
          mapGraphNodes.put(strGraphNodeName.intern(), node);

          //// 2. Now correctly set up the inlinks 
          it = node.getInlinks();
          while (it.hasNext()) {
             strGraphNodeTmp = (String) it.next();
             weight          = node.getInlinkWeight(strGraphNodeTmp);
             addDirectedEdge(strGraphNodeTmp, strGraphNodeName);
          }
          
          //// 3. Now correctly set up the outlinks 
          it = node.getOutlinks();
          while (it.hasNext()) {
             strGraphNodeTmp = (String) it.next();
             weight          = node.getOutlinkWeight(strGraphNodeTmp);
             addDirectedEdge(strGraphNodeName, strGraphNodeTmp);
          }
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Remove this GraphNode from the Graph. No effiect if not in the Graph.
     * The corresponding inlinks and outlinks of the appropriate
     * GraphNode will be updated.
     *
     * @param strGraphNodeName is the name of the GraphNode to remove 
     *                         from the Graph.
     */
    public void removeNode(String strGraphNodeName) {
       Iterator   it;
       GraphNode  nodeTemp;       // temp handle to GraphNode to
                                  // delete the edge to / from

       //// 1. Remove the GraphNode from the map.
       GraphNode node = (GraphNode) mapGraphNodes.remove(strGraphNodeName);

       //// 2. If the GraphNode we retrieved is null, then do nothing. 
       ////    Otherwise, update the links accordingly.
       if (node != null) {

          //// 3. Remove the edges for all of the inlinks
          it = node.getInlinks();
          while (it.hasNext()) {
             nodeTemp = getNode((String) it.next());
             nodeTemp.removeOutlink(strGraphNodeName);
          }

          //// 4. Remove the edges for all of the outlinks
          it = node.getOutlinks();
          while (it.hasNext()) {
             nodeTemp = getNode((String) it.next());
             nodeTemp.removeInlink(strGraphNodeName);
          }
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Remove this GraphNode from the Graph. If it is not in the Graph, 
     * there will be no effect. The corresponding inlinks and outlinks 
     * of the appropriate GraphNode will be updated.
     *
     * @param node is the GraphNode to remove from the Graph.
     */
    public void removeNode(GraphNode node) {
       removeNode(node.getName());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add an edge.
     */
    public void addDirectedEdge(GraphEdge edge) {
        addDirectedEdge(edge.getSourceNode(), 
                        edge.getDestNode(),
                        edge.getWeight());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add a directed edge with the specified weight from one GraphNode to 
     * another GraphNode. 
     *
     * <P>
     * If one of the GraphNodes is not in the Graph already, it will be added.
     * It only adds a <B>directed</B> edge from the from-GraphNode to the 
     * to-GraphNode (storing the inlinks and outlinks for each respective 
     * GraphNode correctly).
     *
     * @param strGraphNodeFrom is the name of the source GraphNode.
     * @param strGraphNodeTo   is the name of the destination GraphNode.
     * @param weight  is the weight of the Edge.
     */
    public void addDirectedEdge(String strGraphNodeFrom, 
                                String strGraphNodeTo, 
                                float  weight) {

       //// 1. Retrieve the GraphNodes. If not exist, instantiate them.
       GraphNode graphNodeFrom = getOrMakeGraphNode(strGraphNodeFrom);
       GraphNode graphNodeTo   = getOrMakeGraphNode(strGraphNodeTo);

       //// 2. Update the respective inlinks and outlinks.
       graphNodeFrom.addOutlink(strGraphNodeTo, weight);
       graphNodeTo.addInlink(strGraphNodeFrom,  -weight);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add a directed edge with the default weight 
     * (GraphConst.DEFAULT_WEIGHT) from one GraphNode to another GraphNode. 
     *
     * <P>
     * If one of the GraphNodes is not in the Graph already, it will be added.
     * It only adds a <B>directed</B> edge from the from-GraphNode to 
     * the to-GraphNode (storing the inlinks and outlinks for each 
     * respective GraphNode correctly).
     *
     * @param strGraphNodeFrom is the name of the source GraphNode.
     * @param strGraphNodeTo   is the name of the destination GraphNode.
     * @see   GraphConst
     */
    public void addDirectedEdge(String strGraphNodeFrom, 
                                String strGraphNodeTo) {
        addDirectedEdge(strGraphNodeFrom, strGraphNodeTo,
                        GraphConst.DEFAULT_WEIGHT);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add a directed edge with the default weight 
     * (GraphConst.DEFAULT_WEIGHT) from one GraphNode to another GraphNode.
     *
     * <P>
     * If one of the GraphNodes is not in the Graph already, it will be added 
     * (with the inlinks and outlinks correctly set up).
     * It only adds a <B>directed</B> edge from the from-GraphNode to 
     * the to-GraphNode (storing the inlinks and outlinks for each respective 
     * GraphNode correctly).
     *
     * @param graphNodeFrom is the source GraphNode.
     * @param graphNodeTo   is the destination GraphNode.
     * @see   GraphConst
     */
    public void addDirectedEdge(GraphNode graphNodeFrom, 
                                GraphNode graphNodeTo) {

        addDirectedEdge(graphNodeFrom.getName(), graphNodeTo.getName());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add a directed edge with the specified weight from one GraphNode to 
     * another GraphNode.
     *
     * <P>
     * If one of the GraphNodes is not in the Graph already, it will be added 
     * (with the inlinks and outlinks correctly set up).
     * It only adds a <B>directed</B> edge from the from-GraphNode to 
     * the to-GraphNode (storing the inlinks and outlinks for each 
     * respective GraphNode correctly).
     *
     * @param graphNodeFrom is the source GraphNode.
     * @param graphNodeTo   is the destination GraphNode.
     * @param weight  is the weight of the Edge.
     */
    public void addDirectedEdge(GraphNode graphNodeFrom, 
                                GraphNode graphNodeTo, 
                                float     weight) {

        addDirectedEdge(graphNodeFrom.getName(), graphNodeTo.getName(), weight);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add an edge.
     */
    public void addUndirectedEdge(GraphEdge edge) {
        addUndirectedEdge(edge.getSourceNode(), 
                          edge.getDestNode(),
                          edge.getWeight());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add an undirected edge with the specified weight from one GraphNode to 
     * another GraphNode. 
     *
     * <P>
     * If one of the GraphNodes is not in the Graph already, it will be added.
     * It adds an <B>undirected</B> edge from the from-GraphNode to the 
     * to-GraphNode (storing the inlinks and outlinks for each respective 
     * node correctly).
     *
     * @param strGraphNodeFrom is the name of the source GraphNode.
     * @param strGraphNodeTo   is the name of the destination GraphNode.
     * @param weight  is the weight of the Edge.
     */
    public void addUndirectedEdge(String strGraphNodeFrom, 
                                  String strGraphNodeTo, 
                                  float  weight) {

       addDirectedEdge(strGraphNodeFrom, strGraphNodeTo,   weight);
       addDirectedEdge(strGraphNodeTo,   strGraphNodeFrom, weight);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add an undirected edge with the default weight 
     * (GraphConst.DEFAULT_WEIGHT) from one GraphNode to another GraphNode. 
     *
     * <P>
     * If one of the GraphNodes is not in the Graph already, it will be added.
     * It adds an <B>undirected</B> edge from the from-GraphNode to the 
     * to-GraphNode (storing the inlinks and outlinks for each respective 
     * node correctly).
     *
     * @param strGraphNodeFrom is the name of the source GraphNode.
     * @param strGraphNodeTo   is the name of the destination GraphNode.
     * @see   GraphConst
     */
    public void addUndirectedEdge(String strGraphNodeFrom, 
                                  String strGraphNodeTo) {

       addDirectedEdge(strGraphNodeFrom, strGraphNodeTo);
       addDirectedEdge(strGraphNodeTo,   strGraphNodeFrom);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add an undirected edge with the default weight 
     * (GraphConst.DEFAULT_WEIGHT) from one GraphNode to another GraphNode.
     *
     * <P>
     * If one of the GraphNodes is not in the Graph already, it will be added 
     * (with the inlinks and outlinks correctly set up).
     * It adds an <B>undirected</B> edge from the from-GraphNode to the 
     * to-GraphNode (storing the inlinks and outlinks for each respective 
     * GraphNode correctly).
     *
     * @param graphNodeFrom is the source GraphNode.
     * @param graphNodeTo   is the destination GraphNode.
     * @see   GraphConst
     */
    public void addUndirectedEdge(GraphNode graphNodeFrom, 
                                  GraphNode graphNodeTo) {
       addDirectedEdge(graphNodeFrom, graphNodeTo);
       addDirectedEdge(graphNodeTo,   graphNodeFrom);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Add an undirected edge with the specified weight from one GraphNode to 
     * another GraphNode.
     *
     * <P>
     * If one of the GraphNodes is not in the Graph already, it will be added 
     * (with the inlinks and outlinks correctly set up).
     * It adds an <B>undirected</B> edge from the from-GraphNode to the 
     * to-GraphNode (storing the inlinks and outlinks for each respective 
     * node correctly).
     *
     * @param graphNodeFrom is the source GraphNode.
     * @param graphNodeTo   is the destination GraphNode.
     * @param weight  is the weight of the Edge.
     */
    public void addUndirectedEdge(GraphNode graphNodeFrom, 
                                  GraphNode graphNodeTo, 
                                  float     weight) {
       addDirectedEdge(graphNodeFrom, graphNodeTo,   weight);
       addDirectedEdge(graphNodeTo,   graphNodeFrom, weight);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Remove a directed edge from one GraphNode to another.
     * If the edge does not exist, nothing will happen.
     * If one of the GraphNodes does not exist, will still try to remove 
     * the edge (if for some strange reason it exists).
     *
     * @param strGraphNodeFrom is the name of the source GraphNode.
     * @param strGraphNodeTo   is the name of the destination GraphNode.
     */
    public void removeDirectedEdge(String strGraphNodeFrom, 
                                   String strGraphNodeTo) {
       //// 1. Get the GraphNodes from the table
       GraphNode graphNodeFrom = getNode(strGraphNodeFrom);
       GraphNode graphNodeTo   = getNode(strGraphNodeTo);

       //// 2. If the from-GraphNode exists, then try to remove the edge
       if (graphNodeFrom != null) {
          graphNodeFrom.removeOutlink(strGraphNodeTo);
       }

       //// 3. If the to-GraphNode exists, then try to remove the edge
       if (graphNodeTo != null) {
          graphNodeTo.removeInlink(strGraphNodeFrom);
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Remove a directed edge from one GraphNode to another.
     * If the GraphNodes are not already in the Graph, they will be added.
     * If the edge does not exist, nothing will happen.
     * If one of the GraphNodes does not exist, will still try to remove 
     * the edge (if for some strange reason it exists).
     *
     * @param graphNodeFrom is the source GraphNode.
     * @param graphNodeTo   is the destination GraphNode.
     */
    public void removeDirectedEdge(GraphNode graphNodeFrom, 
                                   GraphNode graphNodeTo) {
        removeDirectedEdge(graphNodeFrom.getName(), graphNodeTo.getName());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Remove an undirected edge between two GraphNodes.
     * If the edge does not exist, nothing will happen.
     *
     * @param strGraphNodeFrom is the name of the source GraphNode.
     * @param strGraphNodeTo   is the name of the destination GraphNode.
     */
    public void removeUndirectedEdge(String strGraphNodeFrom, 
                                     String strGraphNodeTo) {

       removeDirectedEdge(strGraphNodeFrom, strGraphNodeTo);
       removeDirectedEdge(strGraphNodeTo,   strGraphNodeFrom);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Remove an undirected edge between two GraphNodes.
     * If the edge does not exist, nothing will happen.
     *
     * @param graphNodeFrom is the source GraphNode.
     * @param graphNodeTo   is the destination GraphNode.
     */
    public void removeUndirectedEdge(GraphNode graphNodeFrom, 
                                     GraphNode graphNodeTo) {
       removeDirectedEdge(graphNodeFrom, graphNodeTo);
       removeDirectedEdge(graphNodeTo,   graphNodeFrom);
    } // of method

    //===   MODIFIER METHODS   =================================================
    //==========================================================================





    //==========================================================================
    //===   ACCESSOR METHODS   =================================================

    /**
     * Get a GraphNode from this Graph.
     *
     * @param  strGraphNodeName is the name of the GraphNode to retrieve.
     * @return the GraphNode, or null if it does not exist.
     */
    public GraphNode getNode(String strGraphNodeName) {
       return ((GraphNode) mapGraphNodes.get(strGraphNodeName));
    } // of method

    //-----------------------------------------------------------------

    /**
     * See if the given GraphNode is in the Graph or not.
     *
     * @param  strGraphNodeName is the name of the GraphNode to check for.
     * @return true if the given GraphNode is in the Graph, false otherwise.
     */
    public boolean nodeExists(String strGraphNodeName) {
       return (mapGraphNodes.get(strGraphNodeName) != null);
    } // of method

    //-----------------------------------------------------------------

    /**
     * See if the given GraphNode is in the Graph or not.
     *
     * @param  node is the GraphNode to check for.
     * @return true if the given node is in the Graph, false otherwise.
     */
    public boolean nodeExists(GraphNode node) {
       return (nodeExists(node.getName()));
    } // of method

    //-----------------------------------------------------------------

    /**
     * See if you can get from the from-GraphNode to the to-GraphNode.
     *
     * @param  strGraphNodeFrom is the name of the source GraphNode.
     * @param  strGraphNodeTo   is the name of the destination GraphNode.
     * @return true if the two GraphNodes are adjacent, false otherwise.
     */
    public boolean isAdjacent(String strGraphNodeFrom, String strGraphNodeTo) {
       GraphNode GraphNode = getNode(strGraphNodeFrom);
       if (GraphNode != null) {
          return(GraphNode.hasOutlinkTo(strGraphNodeTo));
       }
       return (false);
    } // of method

    //-----------------------------------------------------------------

    /**
     * See if you can get from the from-GraphNode to the to-GraphNode.
     *
     * @param  graphNodeFrom is the source GraphNode.
     * @param  graphNodeTo   is the destination GraphNode.
     * @return true if the two GraphNodes are adjacent, false otherwise.
     */
    public boolean isAdjacent(GraphNode graphNodeFrom, GraphNode graphNodeTo) {
       return (graphNodeFrom.hasOutlinkTo(graphNodeTo.getName()));
    } // of method

    //-----------------------------------------------------------------

    /**
     * Get the weight of the edge between the from-GraphNode 
     * to the to-GraphNode.
     *
     * @param  strGraphNodeFrom is the name of the source GraphNode.
     * @param  strGraphNodeTo   is the name of the destination GraphNode.
     * @return true if the two GraphNodes are adjacent, false otherwise.
     */
    public float getWeight(String strGraphNodeFrom, String strGraphNodeTo) {
       GraphNode node = getNode(strGraphNodeFrom);
       if (node != null) {
          return (node.getOutlinkWeight(strGraphNodeTo));
       }
       return (Float.NaN);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Get the weight of the edge between the from-GraphNode 
     * to the to-GraphNode.
     *
     * @param  graphNodeFrom is the name of the source GraphNode.
     * @param  graphNodeTo   is the name of the destination GraphNode.
     * @return true if the two GraphNodes are adjacent, false otherwise.
     */
    public float getWeight(GraphNode graphNodeFrom, GraphNode graphNodeTo) {
       return ( graphNodeFrom.getOutlinkWeight(graphNodeTo.getName()) );
    } // of method

    //-----------------------------------------------------------------

    /**
     * Count the number of GraphNodes in this Graph.
     *
     * @return An integer containing the number of GraphNodes in this Graph.
     */
    public int numberOfGraphNodes() {
       return (mapGraphNodes.size());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Count the number of Edges in this Graph.
     *
     * @return An integer containing the number of Edges in this Graph.
     */
    public int numberOfEdges() {
       int         iNumEdges = 0;
       Iterator    it        = mapGraphNodes.values().iterator();
       GraphNode   node;

       while (it.hasNext()) {
          node       = (GraphNode) it.next();
          iNumEdges += node.getOutDegree();
       }

       return (iNumEdges);
    } // of method

    //===   ACCESSOR METHODS   =================================================
    //==========================================================================





    //==========================================================================
    //===   PRIVATE METHODS   ==================================================

    /**
     * If the GraphNode exists already, then retrieve it. If it does not, then
     * make it and return it.
     */
    private GraphNode getOrMakeGraphNode(String strGraphNodeName) {
       //// 1. Try to retrieve the GraphNode.
       GraphNode node = (GraphNode) mapGraphNodes.get(strGraphNodeName);

       //// 2. If the GraphNode does not exist, create it 
       ////    and put it in the table.
       if (node == null) {
          node = new GraphNode(strGraphNodeName);
          mapGraphNodes.put(strGraphNodeName.intern(), node);
       }

       return (node);
    } // of method

    //===   PRIVATE METHODS   ==================================================
    //==========================================================================






    //==========================================================================
    //===   TOSTRING   =========================================================

    /**
     * Convert to a form that can be parsed back in.
     */
    public String toString() {
       StringBuffer strbuf = new StringBuffer();
       Iterator     it     = mapGraphNodes.values().iterator();  // all nodes
       GraphNode    node;                                        // cur node

       List         listEdges = new LinkedList();                // all edges
       Iterator     itOut;                                       // cur edges
       String       strSrc;
       String       strDst;

       //// 1. For each node...
       strbuf.append("NODES\n");
       while (it.hasNext()) {
           //// 1.1. Append it's name.
           node  = (GraphNode) it.next();
           strbuf.append(node.getName());
           strbuf.append("\n");

           //// 1.2. Get the outgoing edges it has and add 
           ////      to the list of Edges.
           itOut = node.getOutlinks();
           while (itOut.hasNext()) {
               strSrc  = node.getName();
               strDst  = (String) itOut.next();
               listEdges.add(new GraphEdge(strSrc, strDst,
                                           node.getOutlinkWeight(strDst)));
           }
       }

       //// 2. Now, for each edge...
       strbuf.append("EDGES\n");
       it = listEdges.iterator();
       while (it.hasNext()) {
           strbuf.append(it.next());
           strbuf.append("\n");
       }

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Debugging purposes.
     */
    public String toDebugString() {
       StringBuffer strbuf = new StringBuffer();
       Iterator     it     = mapGraphNodes.values().iterator();  // all nodes
       GraphNode    node;                                        // cur node

       //// 1. For each node...
       while (it.hasNext()) {
           //// 1.1. Append it's name.
           node  = (GraphNode) it.next();
           strbuf.append(node);
           strbuf.append("\n");
       }
       return (strbuf.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================





    //==========================================================================
    //===   MAIN   =============================================================

    //// Get a graph
    public static Graph getTestInstanceAAA() {
        Graph g = new Graph();
        g.addNode("GraphNode1");
        g.addNode("GraphNode2");
        g.addNode("GraphNode3");
        return (g);
    } // of method


    //// Get a graph
    public static Graph getTestInstanceBBB() {
        Graph g = new Graph();

        g.addNode("GraphNode1");
        g.addNode("GraphNode2");
        g.addNode("GraphNode3");

        g.addDirectedEdge("GraphNode1", "GraphNode3");
        g.addDirectedEdge("GraphNode3", "GraphNode2");
        return (g);
    } // of method


    //// Get a graph
    public static Graph getTestInstanceCCC() {
        Graph graph = new Graph();

        graph.addDirectedEdge("A", "B",  1);
        graph.addDirectedEdge("A", "C",  2);
        graph.addDirectedEdge("A", "D",  3);
        graph.addDirectedEdge("A", "E",  4);
        graph.addDirectedEdge("A", "F",  5);
        graph.addDirectedEdge("B", "BA", 6);
        graph.addDirectedEdge("B", "BB", 7);
        graph.addDirectedEdge("B", "BC", 8);
        graph.addDirectedEdge("C", "B");
        graph.addDirectedEdge("C", "D");
        graph.addDirectedEdge("E", "EA", 9);
        graph.addDirectedEdge("E", "EB", 10);
        graph.addDirectedEdge("E", "EC", 11);
        graph.addDirectedEdge("F", "FA", 12);
        graph.addDirectedEdge("F", "FB", 13);
        graph.addDirectedEdge("D", "BC", 14);
        graph.addDirectedEdge("D", "EA", 15);
        graph.addDirectedEdge("BC", "EA", 16);
        graph.addDirectedEdge("BC", "C");
        graph.addDirectedEdge("BB", "H");
        graph.addDirectedEdge("BC", "H");
        graph.addDirectedEdge("EA", "H");
        graph.addDirectedEdge("FA", "G");
        graph.addDirectedEdge("FA", "E");
        graph.addDirectedEdge("FB", "G");
        graph.addDirectedEdge("FB", "B");
        graph.addDirectedEdge("FB", "I");
        graph.addDirectedEdge("G", "H");
        graph.addDirectedEdge("G", "I");
        graph.addDirectedEdge("BA", "FB");
        graph.addDirectedEdge("BB", "H");
        graph.addDirectedEdge("EC", "FA");
        graph.addDirectedEdge("FA", "EC");
        graph.addDirectedEdge("H", "BA");
        graph.addDirectedEdge("H", "EA");

        return (graph);
    } // of method


    //// Get a graph
    public static Graph getTestInstanceDDD() {
        Graph g = new Graph();

        g.addNode("GraphNode1");
        g.addNode("GraphNode2");
        g.addNode("GraphNode3");

        GraphNode node = new GraphNode("GraphNode4");
        node.addOutlink("GraphNode5");
        node.addOutlink("GraphNode6");

        g.addNode(node);

        return (g);
    } // of method

    //----------------------------------------------------------------

    //// Print out the graphs
    private static void runTestAAA() {
        Graph g;

        g = getTestInstanceAAA();
        System.out.println(g);
        System.out.println();

        g = getTestInstanceBBB();
        System.out.println(g);
        System.out.println();

        g = getTestInstanceCCC();
        System.out.println(g);
        System.out.println();

        g = getTestInstanceDDD();
        System.out.println(g);
        System.out.println();
    } // of method


    //// Do some searches
    private static void runTestBBB() {
        Graph g = getTestInstanceCCC();

        search(g, "A", "BA");
        search(g, "A", "FB");
        search(g, "A", "H");
        search(g, "A", "G");
        search(g, "A", "I");
    } // of method


    //// Test the parser
    private static void runTestCCC() throws Exception {
        printAndParseGraph(getTestInstanceAAA());
        printAndParseGraph(getTestInstanceBBB());
        printAndParseGraph(getTestInstanceCCC());
        printAndParseGraph(getTestInstanceDDD());
    } // of method


    //// Test the parser on the PARC map
    private static void runTestDDD() throws Exception {
        java.io.FileReader frdr = new java.io.FileReader("map-parc-2.txt");
        Graph              g    = PARSER.parse(frdr);
        System.out.println("---------");
        System.out.println(g);
        System.out.println("---------");
        System.out.println(g.toDebugString());

        System.out.println("---------");
        search(g, "2230", "2236");
        System.out.println("---------");
        search(g, "CSLCommons", "2236");
        System.out.println("---------");
        search(g, "2168", "2230");
        System.out.println("---------");
        search(g, "2146", "2238");
        System.out.println("---------");
        search(g, "2160", "2121");
        System.out.println("---------");
        search(g, "2230", "2121");
        System.out.println("---------");
        search(g, "2230", "2146");
    } // of method


    //// Test the parser on the Soda hall map
    private static void runTestEEE() throws Exception {
        java.io.FileReader frdr = new java.io.FileReader("map-soda.txt");
        Graph              g    = PARSER.parse(frdr);
        System.out.println("---------");
        System.out.println(g);
        System.out.println("---------");
        System.out.println(g.toDebugString());

        System.out.println("**********************");
        search(g, "525", "306");
        System.out.println("**********************");
        search(g, "525", "527");
        System.out.println("**********************");
        search(g, "525", "510");
        System.out.println("**********************");
        search(g, "525", "683");
        System.out.println("**********************");
        search(g, "525", "606");
    } // of method

    //----------------------------------------------------------------

    //// Print out a graph, convert it to String, and parse that String.
    //// Just allows manual checking the parsing is working right.
    private static void printAndParseGraph(Graph g) throws Exception {
        System.out.println("--- before -----");
        System.out.println(g.toDebugString());
        System.out.println("--- parsed -----");
        Graph g2 = PARSER.parse(new java.io.StringReader(g.toString()));
        System.out.println(g2.toDebugString());
    } // of method


    //// Do a search. Does timings for comparison.
    private static void search(Graph g, String strFrom, String strTo) {
        long startTime;
        long endTime;
        System.out.println("From " + strFrom + " to " + strTo);

        // System.out.println("DFS");
        // startTime = System.currentTimeMillis();
        // System.out.println(searchDepthFirst(g, strFrom, strTo));
        // endTime = System.currentTimeMillis();
        // System.out.println(endTime - startTime);
        // System.out.println();

        // System.out.println("BFS");
        // startTime = System.currentTimeMillis();
        // System.out.println(searchBreadthFirst(g, strFrom, strTo));
        // endTime = System.currentTimeMillis();
        // System.out.println(endTime - startTime);
        // System.out.println();

        System.out.println("BidirBlind");
        startTime = System.currentTimeMillis();
        System.out.println(searchBidirBlind(g, strFrom, strTo));
        endTime = System.currentTimeMillis();
        System.out.println(endTime - startTime);
        System.out.println();

        System.out.println("------------------------------");
    } // of method

    //----------------------------------------------------------------

    private static GraphPath searchDepthFirst(Graph  g, 
                                              String strFrom, 
                                              String strTo) {
        return (new GraphSearchDepthFirst().search(g, strFrom, strTo));
    } // of method


    private static GraphPath searchBreadthFirst(Graph  g, 
                                                String strFrom, 
                                                String strTo) {
        return (new GraphSearchBreadthFirst().search(g, strFrom, strTo));
    } // of method


    private static GraphPath searchBidirBlind(Graph  g, 
                                              String strFrom, 
                                              String strTo) {
        return (new GraphSearchBidirBlind().search(g, strFrom, strTo));
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestEEE();
    } // of main

    //===   MAIN   =============================================================
    //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
