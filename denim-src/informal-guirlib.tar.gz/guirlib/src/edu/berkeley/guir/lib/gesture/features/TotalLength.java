package edu.berkeley.guir.lib.gesture.features;

import edu.berkeley.guir.lib.gesture.*;
import java.awt.Polygon;
import java.lang.Math;

/**
 * Total length of the gesture
 */
public class TotalLength extends Feature {
  public final double minValue = 0;
  public final double maxValue = Double.POSITIVE_INFINITY;
  
  public TotalLength()
  {
    super();
  }

  public TotalLength(Gesture g)
  {
    super(g);
  }

  public String getName()
  {
    return new String("total length");
  }

  /**
   * Return maximum value this feature can have
   */
  public double getMinValue()
  {
    return minValue;
  }
  
  /**
   * Return minimum value this feature can have
   */
  public double getMaxValue()
  {
    return maxValue;
  }

  /**
   * Non-incremental computation.  Should set value to new value and
   * valueOk to true.
   */
  protected void computeValue()
  {
    Polygon points = gesture.getPointsRef();
    value = 0;
    for (int i = 1; i < points.npoints; i++) {
      double dx = points.xpoints[i] - points.xpoints[i-1];
      double dy = points.ypoints[i] - points.ypoints[i-1];
      double magsq = dx*dx + dy*dy;
      value += Math.sqrt(magsq);
    }
    valueOk = true;
  }

  /**
   * Change @gesture so that the feature changes (ideally by the
   * scale factor).
   */
  public void scale(double factor)
  {
    gesture.normalize();
    TimedPolygon points = gesture.getPoints();

    for (int i = 0; i < points.npoints; i++) {
      points.xpoints[i] *= factor;
      points.ypoints[i] *= factor;
    }
    gesture.setPoints(points);
  }
}
