package edu.berkeley.guir.lib.gesture;

import java.util.Observer;
import java.util.Observable;
import javax.swing.*;
import java.lang.Double;

/**
 * Currently, a very simple (i.e, textual) display of a feature
 * value.
 */
public class FeatureDisplay extends JLabel implements Observer {
  Feature feature;
  
  public FeatureDisplay()
  {
    super();
  }

  public FeatureDisplay(Feature f)
  {
    super();
    setFeature(f);
  }

  public void setFeature(Feature f)
  {
    if (feature != null) {
      feature.deleteObserver(this);
    }
    feature = f;
    if (f != null) {
      f.addObserver(this);
      setText(Double.toString(f.getValue()));
    }
  }

  public void update(Observable observable, Object arg)
  {
    Feature f = (Feature) observable;
    setText(Double.toString(f.getValue()));
  }
}
