package edu.berkeley.guir.damask.view.examples; 


import java.awt.Color; 
import java.awt.geom.AffineTransform; 
import java.awt.geom.NoninvertibleTransformException; 
import java.beans.PropertyChangeEvent; 
import java.beans.PropertyChangeListener; 


import edu.umd.cs.piccolo.PCamera; 
import edu.umd.cs.piccolo.PNode; 
import edu.umd.cs.piccolo.util.PAffineTransform; 
import edu.umd.cs.piccolo.util.PBounds; 


public class PStickyNode extends PNode implements PropertyChangeListener {

   static public final int STICKY = 1;
   static public final int STICKYZ = 2;

   protected PCamera constraintCamera;
   protected PAffineTransform lastCameraTransform;
   protected int constraintType = STICKY;
   protected double stickyPointX = 0.5;
   protected double stickyPointY = 0.5;

   public PStickyNode(PCamera constraintCamera) {
      setBounds(0, 0, 100, 80);
      setPaint(Color.BLUE);
      setConstraintCamera(constraintCamera);
   }

   public PCamera getConstraintCamera() {
      return constraintCamera;
   }

   public void setConstraintCamera(PCamera camera) {
      if (constraintCamera != null) {
         constraintCamera.removePropertyChangeListener(
            PCamera.PROPERTY_VIEW_TRANSFORM,
            this);
      }

      constraintCamera = camera;

      if (constraintCamera != null) {
         constraintCamera.addPropertyChangeListener(
            PCamera.PROPERTY_VIEW_TRANSFORM,
            this);
      }
   }

   public void propertyChange(PropertyChangeEvent cameraViewTransformChanged) {
      if (constraintType == STICKY) {
         applyStickyConstraint();
      }
      else {
         applyStickyZConstraint();
      }
   }

   private void applyStickyConstraint() {
      if (constraintCamera == null)
         return;

      try {
         AffineTransform frame = null;

         if (getParent() != null) {
            frame = getParent().getLocalToGlobalTransform(null);
         }
         else {
            frame = new PAffineTransform();
         }

         AffineTransform t = frame.createInverse();

         t.concatenate(
            constraintCamera.getViewTransformReference().createInverse());
         t.concatenate(frame);

         setTransform(t);
      }
      catch (NoninvertibleTransformException e) {
         e.printStackTrace();
      }
   }

   private void applyStickyZConstraint() {
      if (constraintCamera == null)
         return;
         
      PAffineTransform t = new PAffineTransform();
      double s = 1.0 / constraintCamera.getViewScale();
      PBounds b = getFullBoundsReference();
      t.scaleAboutPoint(
         s,
         b.getX() + (stickyPointX * b.getWidth()),
         b.getY() + (stickyPointY * b.getHeight()));
      setTransform(t);
   }
}
