package edu.berkeley.guir.lib.gesture.apps;

import java.awt.*;
import javax.swing.*;
import edu.berkeley.guir.lib.gesture.util.HystericResizer;
import edu.berkeley.guir.lib.gesture.*;
import javax.swing.event.*;

class simple
{
  static public void main(String argv[])
  {
    JFrame frame = new JFrame("Frame add test");
    
    JPanel p = new JPanel(new FlowLayout());

    GestureInteractor interactor = new GestureInteractor();
    interactor.addChangeListener(myListener(p));
    interactor.setMinimumSize(new Dimension(100, 100));

    JScrollPane scrollPane = new JScrollPane(p);
    
    HystericResizer hr = new HystericResizer();
    scrollPane.addComponentListener(hr);

    JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
					  scrollPane,
					  interactor);
    
    frame.getContentPane().add(splitPane);
    frame.pack();
    frame.setSize(200, 200);
    frame.show();
  }

  static public ChangeListener myListener(final Container container)
  {
    return new ChangeListener() {
      int i = 0;
      public void stateChanged(ChangeEvent e) {
	GestureInteractor interactor = (GestureInteractor) e.getSource();
	Gesture	g = interactor.getGesture();
	Gesture copy = new Gesture(g);
	copy.normalize();
	GestureDisplay gestureDisplay = new GestureDisplay(copy);
	gestureDisplay.setBorder(BorderFactory.createEtchedBorder());
	//gestureDisplay.setSize(100, 100);
	//gestureDisplay.setMinimumSize(new Dimension(100, 100));
	container.add(gestureDisplay);
	container.invalidate();
	//container.validate();

	Window w;
	if (container instanceof Window)
	  w = (Window) container;
	else
	  w = SwingUtilities.windowForComponent(container);
	Dimension oldSize = interactor.getSize();
	w.pack();
	// the +2 is a hack.  For some reason w/o it the window shrinks
	// by 2 pixels each repack
	interactor.setSize(interactor.getSize().width, oldSize.height);
      }
    };
  }
}
