//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.collection.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.util.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;

/**
 * A sample implementation of a Graphical Object Collection. A Collection is
 * just a collection of GraphicalObjects, with no additional semantics
 * attached. This differs from a GraphicalObjectGroup in that GObGroups can be
 * rendered, while GObCollections cannot.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 05 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class GraphicalObjectCollectionImpl
   implements GraphicalObjectCollection {

   //===========================================================================
   //===   CLASS VARIABLES AND METHODS   =======================================

   static final long serialVersionUID = 864134089977095294L;

   //===   CLASS VARIABLES AND METHODS   =======================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   OrderedList list             = new OrderedList();       // collection of GObs
   boolean     flagDirty        = false;                   // bounds up to date?
   Rectangle2D relBounds        = new Rectangle2D.Float(); // relative bounds
   Rectangle2D absBounds        = new Rectangle2D.Float(); // absolute bounds
   boolean     flagIgnoreDelete = false;                   // ignore del msgs?

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create a new, empty collection.
    */
   public GraphicalObjectCollectionImpl() {
      clearObjectBounds();
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Make a shallow clone.
    */
   public GraphicalObjectCollectionImpl(GraphicalObjectCollection gobcol) {
      Iterator it = gobcol.getForwardIterator();
      while (it.hasNext()) {
         GraphicalObject gob = (GraphicalObject)it.next();
         this.addToBack(gob);
      }
   } // of constructor
   
   //-----------------------------------------------------------------

   /**
    * Make a shallow clone.
    */
   public GraphicalObjectCollectionImpl(GraphicalObjectCollectionImpl gobcol) {
      gobcol.clone(this);
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   INTERNAL METHODS   ==================================================

   /**
    * Get the Ordered List. 
    */
   protected OrderedList getOrderedList() {
      return (list);
   } // of getOrderedList

   //-----------------------------------------------------------------

   /**
    * Minor workaround to prevent double delete messages when this
    * class is used by GraphicalObjectGroup.
    */
   void setIgnoreChildDelete(boolean flag) {
      flagIgnoreDelete = flag;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Clear out our cached copies of the collection's bounds.
    */
   private void clearObjectBounds() {
      relBounds.setRect(Float.MAX_VALUE, Float.MAX_VALUE, 0, 0);
      absBounds.setRect(Float.MAX_VALUE, Float.MAX_VALUE, 0, 0);
   } // of clearObjectBounds

   //-----------------------------------------------------------------

   /**
    * Calculate the bounding box of this group.
    * This is O(N) with respect to the number of objects in the group.
    * Should be used when a GraphicalObject is removed.
    */
   private void calculateObjectBounds() {
      Iterator        it        = getForwardIterator();
      boolean         flagFirst = true;
      GraphicalObject gob;

      //// 1. Go thru all of the GObs and recalculate the bounds.
      clearObjectBounds();
      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();
         if (flagFirst == true) {
            flagFirst = false;
            relBounds = gob.getBounds2D(COORD_REL, null, relBounds);
            absBounds = gob.getBounds2D(COORD_ABS, null, absBounds);
         }
         else {
            updateBounds(gob);
         }
      }

      //// 2. Clean, clean, clean are we;
      ////    Evermore, so shall it be!
      flagDirty = false;
   } // of calculateObjectBounds

   //-----------------------------------------------------------------

   /**
    * Update the relative and absolute bounds with this GraphicalObject.
    * Should be used when a GraphicalObject is added.
    *
    * @param gob is the GraphicalObject that is added.
    */
   private void updateBounds(GraphicalObject gob) {
      //// A. Acquire soft-state objects.
      Rectangle2D rect = (Rectangle2D) poolRects.getObject();

      //// 1. Update relative bounds.
      gob.getBounds2D(COORD_REL, null, rect);
      Rectangle2D.union(relBounds, rect, relBounds);

      //// 2. Update absolute bounds.
      gob.getBounds2D(COORD_ABS, null, rect);
      Rectangle2D.union(absBounds, rect, absBounds);

      //// B. Release soft-state objects.
      poolRects.releaseObject(rect);
   } // of updateBounds

   //===   INTERNAL METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   BOUND METHODS   =====================================================

   public Rectangle2D getCollectionBounds2D(int cdsys) {
      return (getCollectionBounds2D(cdsys, new Rectangle2D.Float()));
   } // of method

   //-----------------------------------------------------------------

   public Rectangle2D getCollectionBounds2D(int cdsys, Rectangle2D rect) {
      //// 1. Update the bounds if we are inconsistent.
      ////    NOTE: CHANGED 

      if (flagDirty == true || true) {
         calculateObjectBounds();
      }

      //// 2. Allocate space if we don't have any.
      if (rect == null) {
         rect = new Rectangle2D.Float();
      }

      //// 3. Get the bounds.
      switch (cdsys) {
         case COORD_ABS:
            rect.setRect(absBounds);
            break;
         case COORD_REL:
            rect.setRect(relBounds);
            break;
         case COORD_LOCAL:
            // illegal - doesn't make sense!
         default:
            throw new RuntimeException("What the heck did you pass in?");
      }

      //// 4. Return the bounds.
      return (rect);
   } // of method

   //===   BOUND METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   COLLECTION METHODS   ================================================

   public GraphicalObject add(GraphicalObject gob) {
      return (addToFront(gob));
   } // of add

   //-----------------------------------------------------------------

   public GraphicalObject addToBack(GraphicalObject gob) {
      return (add(numElements(), gob));
   } // of addToBack

   //-----------------------------------------------------------------

   public GraphicalObject addToFront(GraphicalObject gob) {
      return (add(0, gob));
   } // of addToFront


   //-----------------------------------------------------------------

   public GraphicalObject add(int index, GraphicalObject gob) {
       
      if ( !list.contains(gob)) {
         list.add(index, gob);
         gob.addWatcher(this);
         updateBounds(gob);
      }
      return (gob);
   } // of add

   //-----------------------------------------------------------------

   public void clear() {
      Iterator        it = list.iterator();
      GraphicalObject gob;

      //// 1. Remove all callbacks.
      while (it.hasNext()) {
         gob = (GraphicalObject) it.next(); 
         gob.removeWatcher(this); 
      } 
      
      //// 2. Clear out the list.
      list.clear();

      //// 3. Clear out the GObject bounds.
      clearObjectBounds();
   } // of clear

   //-----------------------------------------------------------------

   public boolean contains(GraphicalObject gob) {
      return (list.contains(gob));
   } // of contains

   //-----------------------------------------------------------------

   public GraphicalObject get(int index) {
      return ((GraphicalObject) list.get(index));
   } // of get

   //-----------------------------------------------------------------

   public GraphicalObject getFirst() {
      if (numElements() > 0) {
         return ((GraphicalObject) list.get(0));
      }
      return (null);
   } // of method

   //-----------------------------------------------------------------

   public GraphicalObject getLast() {
      if (numElements() > 0) {
         return ((GraphicalObject) list.get(numElements() - 1));
      } 
      return (null);
   } // of method

   //-----------------------------------------------------------------

   public GraphicalObject getID(long id) {
      Iterator             it = getForwardIterator();
      GraphicalObject      gob;
      GraphicalObjectGroup gobgrp;

      //// 1. For each item in this collection...
      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();

         //// 1.1. If the current item has the specified ID, then return it.
         if (gob.getUniqueID() == id) {
            return (gob);
         }

         //// 1.2. If the current item is a group, then recurse.
         ////      This is essentially a depth-first search.
         if (gob instanceof GraphicalObjectGroup) {
            gobgrp = (GraphicalObjectGroup) gob;
            gob    = gobgrp.getID(id);
            if (gob != null) {
               return (gob);
            }
         }
      }
      return (null);
   } // of getID

   //-----------------------------------------------------------------

   public int indexOf(GraphicalObject gob) {
      return (list.indexOf(gob));
   } // of indexOf

   //-----------------------------------------------------------------

   public boolean isEmpty() {
      return (list.isEmpty());
   } // of isEmpty

   //-----------------------------------------------------------------

   public int numElements() {
      return (list.size());
   } // of size

   //-----------------------------------------------------------------

   public GraphicalObject remove(GraphicalObject gob) {
      boolean hadGob = list.remove(gob);
      if (hadGob) {
         gob.removeWatcher(this);
         flagDirty = true;
      }
      return (gob);
   } // of removeGraphicalObject

   //-----------------------------------------------------------------

   public Iterator getForwardIterator() {
      return (list.getForwardIterator());
   } // of getForwardIterator

   //-----------------------------------------------------------------

   public Iterator getReverseIterator() {
      return (list.getReverseIterator());
   } // of getForwardIterator

   //-----------------------------------------------------------------

   public void sort(Comparator c) {
      Collections.sort(list, c);
   } // of sort

   //===   COLLECTION METHODS   ================================================
   //===========================================================================



   //===========================================================================
   //===   WATCH CALLBACK METHODS   ============================================

   public void onNotify(Watchable w, Object arg) {
      //// ignore
   } // of onNotify

   //-----------------------------------------------------------------

   public void onUpdate(Watchable w, Object arg) {
      flagDirty = true;
   } // of onUpdate

   //-----------------------------------------------------------------

   public void onUpdate(Watchable w, String strProperty, 
         Object oldVal, Object newVal) {
      flagDirty = true;
   } // of onUpdate

   //-----------------------------------------------------------------

   public void onRepaint(GraphicalObject gob) {
      //// ignore
   } // of onRepaint

   //-----------------------------------------------------------------

   public void onRepaint(Rectangle rect) {
      //// ignore
   } // of onRepaint
   
   //-----------------------------------------------------------------

   public void onDelete(Watchable w) {
      if (w instanceof GraphicalObject && !flagIgnoreDelete) {
         remove((GraphicalObject) w);
         flagDirty = true;
      }
   } // of onDelete

   //===   WATCH CALLBACK METHODS   ============================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   /**
    * Print it out.
    */
   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 1. Append data.
      Iterator     it     = getForwardIterator();
      String       strTmp;

      strbuf.append("[\n");
      while (it.hasNext()) {
         strTmp = it.next().toString();
         strbuf.append(StringLib.indent(strTmp, 3) + "\n; \n");
      }
      strbuf.append("]");

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Make a shallow clone.
    *
    * @see #deepClone()
    */
   public Object clone() {
      return (clone(new GraphicalObjectCollectionImpl()));
   } // of clone

   //-----------------------------------------------------------------

   /**
    * Make a shallow clone. You should be aware that this adds another
    * watcher to all of the GraphicalObjects already in the collection.
    */
   protected GraphicalObjectCollectionImpl 
   clone(GraphicalObjectCollectionImpl gobcolClone) {
      //// 1. Copy the list.
      gobcolClone.list      = (OrderedList) this.list.clone();
      gobcolClone.flagDirty = true;

      //// 2. Now add watchers on each of the cloned elements.
      Iterator        it = gobcolClone.list.iterator();
      GraphicalObject gob;

      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();
         gob.addWatcher(gobcolClone);
      }

      return (gobcolClone);
   } // of clone

   //-----------------------------------------------------------------

   /**
    * Make a deep clone of this GraphicalObjectCollection.
    *
    * @see #clone()
    */
   public Object deepClone() {
      return (deepClone(new GraphicalObjectCollectionImpl()));
   } // of deepClone

   //-----------------------------------------------------------------

   /**
    * For deep-clone chaining purposes.
    *
    * @param newGobcol is the object that will be a clone of the current
    *                  object. That is, we copy our parameters into newGobcol.
    */
   protected GraphicalObjectCollectionImpl 
   deepClone(GraphicalObjectCollectionImpl newGobcol) {
      //// 1. Clone the variables.
      ////    Although this currently doesn't do anything, this is just
      ////    in case we have additional variables in the future.
      clone(newGobcol);

      //// 2. Clear out the items in the clone.
      newGobcol.clear();

      //// 3. Add clones of the items in.
      Iterator        it = this.getForwardIterator();
      GraphicalObject gob;
      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();

         //// 3.1. If it is a group, recurse. Otherwise, just add it.
         newGobcol.addToBack((GraphicalObject) gob.deepClone());
      }

      return (newGobcol);

   } // of deepClone

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   MAIN   ==============================================================

   public static void main(String[] argv) {
      GraphicalObjectCollectionImpl gobcol;
      GraphicalObjectImpl           gob;

      gobcol = new GraphicalObjectCollectionImpl();
      gob    = new PatchImpl(new Rectangle(0, 0, 20, 20));
      gobcol.add(gob);
      gob    = new PatchImpl(new Rectangle(30, 60, 20, 20));
      gobcol.add(gob);

      Debug.println(gobcol);
   } // of main

   //===   MAIN   ==============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
