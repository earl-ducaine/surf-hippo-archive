package edu.berkeley.guir.lib.satin.objects;

import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;

/**
 * Wrapper to make graphical objects XY sticky. Still experimental.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v2.1-1.0.0, Aug 24 2000, JH
 *               Created
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class StickyXYGraphicalObjectWrapper
   extends StickyGraphicalObjectWrapper {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   double stickyX;
   double stickyY;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTOR   =======================================================

   /**
    * Create an empty proxy.
    */
   public StickyXYGraphicalObjectWrapper() {
   } // of method

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================



   //===========================================================================
   //===   STICKY METHODS   ====================================================

   public void setStickyLocation(double newX, double newY) {
      stickyX = newX;
      stickyY = newY;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the transform that makes us sticky.
    *
    * @param tx is the storage space.
    */
   protected AffineTransform getStickyTransform(AffineTransform tx) {
      //// 1. Figure out the current translation.
      getUnstickyTransform(COORD_ABS, tx);
      Point2D pt = AffineTransformLib.getTranslateFactor(tx);

      double dx = stickyX - pt.getX(); 
      double dy = stickyY - pt.getY(); 

      //// 2. Set the inverse transform.
      tx.translate(dx, dy);

      return (tx);      
   } // of method

   //===   STICKY METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Done on proxy, not on proxied object.
    */
   public Object clone() {
      StickyXYGraphicalObjectWrapper c = new StickyXYGraphicalObjectWrapper();
      clone(c);
      return (c);
   } // of method


   public StickyXYGraphicalObjectWrapper 
   clone(StickyXYGraphicalObjectWrapper c) {
      //// 1. Clone chain.
      super.clone(c);

      //// 2. Our clone work.
      c.stickyX = this.stickyX;
      c.stickyY = this.stickyY;

      //// 3. Return.
      return (c);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Done on proxy, not on proxied object.
    */
   public Object deepClone() {
      StickyXYGraphicalObjectWrapper c = new StickyXYGraphicalObjectWrapper();
      deepClone(c);
      return (c);
   } // of method

   public StickyXYGraphicalObjectWrapper 
   deepClone(StickyXYGraphicalObjectWrapper c) {
      //// 1. Clone chain.
      super.deepClone(c);

      //// 2. Our clone work.
      c.stickyX = this.stickyX;
      c.stickyY = this.stickyY;

      //// 3. Return.
      return (c);
   } // of method

   //===   CLONE METHODS   =====================================================
   //===========================================================================

} // of interface 

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES { LOSS OF USE, DATA, OR PROFITS { OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
