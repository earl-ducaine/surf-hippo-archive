//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.graphics.*;

/**
 * Sticky view abstract base class.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Feb 28 2000, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3RC1
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public abstract class StickyViewWrapper 
   extends SemanticZoomViewWrapper {

   //===========================================================================
   //===   CONSTANTS   =========================================================


   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   Polygon2D stickypoly = new Polygon2D();  // cached version of bounding pts

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Empty constructor, for subclassing and cloning purposes.
    */
   protected StickyViewWrapper() {
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Wrap a view into a sticky wrapper.
    */
   public StickyViewWrapper(View v) {
      super(v);
      setView(v);
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================


   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Get the unsticky bounds.
    */
   protected Polygon2D getUnstickyBoundingPoints2DRef() {
      return (super.getBoundingPoints2DRef());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the sticky bounds. You can modify the reference, but it won't do any
    * good, since we always update our bounds based on the wrapped-up view.
    */
   public Polygon2D getBoundingPoints2DRef() {
      //// A. Acquire soft-state.
      AffineTransform txTmp = (AffineTransform) poolTx.getObject();

      //// 1. Get the sticky transform.
      getStickyTransform(txTmp);

      //// 2. Apply the transform.
      stickypoly.setToShape(super.getBoundingPoints2DRef());
      stickypoly.transform(txTmp);

      //// B. Release soft-state.
      poolTx.releaseObject(txTmp);
      return (stickypoly);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the transform that makes the view "sticky". One way of thinking about
    * it is that the transform returned by this method "undoes" part of the
    * absolute transform of the Graphical Object attached to this view. For
    * example, Sticky Z would "undo" the zoom part of the absolute transform, 
    * while Sticky R would "undo" the rotation part of the absolute transform.
    * <P>
    * Don't call {@link #getBoundingPoints2DRef()} or any other method that
    * gets or uses the bounds in this method, as that will cause a mutually 
    * recursive call.
    *
    * @param tx is storage space.
    */
   protected abstract AffineTransform getStickyTransform(AffineTransform tx);

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   RENDERING   =========================================================

   public void render(SatinGraphics g) {
      //// A. Acquire soft-state.
      AffineTransform txTmp = (AffineTransform) poolTx.getObject();

      //// 1. Get the sticky transform and apply it.
      getStickyTransform(txTmp);
      g.pushTransform(txTmp);

      //// 2. Render.
      v.render(g);

      //// 3. Restore the absolute transform.
      g.popTransform();

      //// B. Release soft-state.
      poolTx.releaseObject(txTmp);
   } // of render

   //===   RENDERING   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   protected StickyViewWrapper clone(StickyViewWrapper vw) {
      //// 1. Clone chain.
      super.clone(vw);

      //// 2. Do clone work.

      //// 3. Return.
      return (vw);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================


/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/


