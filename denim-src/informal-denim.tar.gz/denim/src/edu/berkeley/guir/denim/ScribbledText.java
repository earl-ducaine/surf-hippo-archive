package edu.berkeley.guir.denim;

import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.denim.command.InsertArrowCommand;
import edu.berkeley.guir.denim.command.SetSheetModifiedCommand;
import edu.berkeley.guir.denim.components.*;

import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.awt.image.*;

/**
 * A piece of scribbled text, which is an aggregation of timed strokes
 * that represent a word or several words in Denim.
 *
 * <PRE>
 * Revisions:  1.0.0  08-05-1999  MWN
 *                    Created.
 *             1.1.0  12-01-1999  JL
 *                    Added Phrase(Rectangle)
 *             2.0.0  03-01-2000  Benson Limketkai
 *                    Separated from Phrase to become Scribble
 *             3.0.0  10-19-2000  JL
 *                    Renamed ScribbledText
 *    		   3.1.0  11-12-2002 YL
 * 					    Supported active feedback
 *             3.1.1  03-07-2003 YL
 *                    Employed external cache inside satin to support active feedback
 *             4.0.0  08-07-2004 YL
 *                    added merging and splitting
 * 
 * 
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~newman/">Mark Newman</A> (
 *         <A HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 4.0.0, 08-07-2004
 */

public class ScribbledText
   extends PatchImpl
   implements DenimText, DenimConstants, ObjectPhantom {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   private   Map     origStyles;
   protected boolean isLink;
   
   protected boolean couldBeCaption = false;
   

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates an empty scribble.
    */
   public ScribbledText() {
      super(new Rectangle(0, 0, 1, 1));
      commonInitializations();
   }

   //-----------------------------------------------------------------

   //=== Take a mess of gobs and add them to this scribble
   //=== This should work with groups and collections
   // TODO: figure out what invariants scribbles should have (in terms of
   // spatial layout)
   /**
    * Takes the given graphical object collection and creates a scribble from
    * them.
    */
   public ScribbledText(GraphicalObjectCollection coll,
                        GraphicalObjectGroup parentGroup) {
      super();

      //Rectangle collBounds; // the bounding box of the collection
      //=== Grab the X and Y values here in case collBounds is a ref
      //===   to an object that might change.
      //int collBoundsX = (int) coll.getCollectionBounds2D(COORD_REL).getX();
      //int collBoundsY = (int) coll.getCollectionBounds2D(COORD_REL).getY();

      //=== Iterate through the collection, remove all GObs from their parent
      //===  and add them to this scribble
      Iterator iter = coll.getForwardIterator();
      while (iter.hasNext()) {
         GraphicalObject gob = (GraphicalObject) iter.next();
         this.add(gob, GraphicalObjectGroup.KEEP_ABS_POS);
      }
      commonInitializations();
   }

   //-----------------------------------------------------------------

   /**
    * Creates a Scribble with the given bounds.
    */
   public ScribbledText(Rectangle2D rect) {
      super(rect);
      commonInitializations();
   }
  	  

   public void setCouldBeCaption(boolean b) {
       couldBeCaption = b;
   }
/*   protected void defaultRender(SatinGraphics g) {
   	
   	
      Rectangle2D box = this.getBounds2D(COORD_LOCAL);
      
      if(ZoomSlider.zoomingInstance==0||this.getCache()==null)
   	  {
	   	
	   	  BufferedImage cache = (BufferedImage)this.getSheet().createImage((int)box.getWidth(),(int)box.getHeight());
	
	   	  Graphics2D g2d = cache.createGraphics();
	      SatinGraphics newG = new SatinGraphics(g2d);
	      newG.pushStyle(g.getStyle());
	      newG.setClip(box);
	      newG.clearAllTransforms();
	   	  
		  super.defaultRender(newG);
	   	  
	   	  newG.dispose();
	   	  
	   	  this.setCache(cache);

   	  }

   	  g.drawImage(this.getCache(), (int)box.getMinX(), (int)box.getMinY(), this.getSheet());
   	  
   }*/
/*   
   public void showFrame(Graphics2D sg) {
   }  	  
  
   public void hideFrame(Graphics2D g) {
   }  	  

   public void moveFrameBy(Graphics2D sg, double dx, double dy) {
  	 
  	 if(dx==0&&dy==0)
  	 {
  	 	return;
  	 }
 
  	 textFrame.setRect(textFrame.getMinX()+dx, textFrame.getMinY()+dy,
  	 			textFrame.getWidth(),textFrame.getHeight());

     Graphics2D bg = this.backgroundImage.createGraphics();
	 
  	 bg.drawImage(this.getSheet().getBufferedImage(), 0, 0, this.getSheet());
  	 
  	 int ox = (int)textFrame.getMinX();
  	 int oy = (int)textFrame.getMinY();
  	 
	 bg.drawImage(textImage, ox, oy, this.getSheet());

     bg.dispose();
	 
	 sg.drawImage(this.backgroundImage, 0, 0, this.getSheet());  	
   }

   
   public ObjectFrame getObjectFrame() {
   	
   	  backgroundImage = (BufferedImage)this.getSheet().createImage(this.getSheet().getWidth(),
   	  							this.getSheet().getHeight());
   	  							
      textImage = this.getCache();
   	  
      textFrame = (Rectangle2D)getBounds2D(COORD_ABS);
   	  
   	  return this;
   }
   
   public void disposeObjectFrame() {
   
   	  backgroundImage = null;
      textImage = null;
      textFrame = null;
      
   }

   public int getBaselineY() {
   	
   		return baselineY;	
   		
   }
   
   public void setBaselineY(int y) {
   	
	   	baselineY = y;
	   	
   }

   //-----------------------------------------------------------------

   public void getTemporalImage(boolean isCreated, Rectangle2D labelBoxAbs, Rectangle2D oldBox, TimedStroke stk) {
   	    

   	 if(isCreated)
   	 {
	     int wi = (int)Math.ceil(labelBoxAbs.getWidth());
	     if(wi<=0)
	     	wi = 1;
	     
	     int he = (int)Math.ceil(labelBoxAbs.getHeight());
	     if(he<=0)
	     	he = 1;
	     	
	     temporalImage = (BufferedImage)this.getSheet().createImage(wi, he);
	     
	     Graphics2D g2d = temporalImage.createGraphics();
	     g2d.setColor(activeImageBg);
	     g2d.fill(new Rectangle2D.Double(0,0,labelBoxAbs.getWidth()+1,labelBoxAbs.getHeight()+1));
	     g2d.setColor(Color.black);
	     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);         
	     g2d.setTransform(AffineTransform.getTranslateInstance(-labelBoxAbs.getMinX(),
	     									-labelBoxAbs.getMinY()));
	     g2d.draw(((TimedStroke)this.getLast()).getPolygon2D(COORD_ABS));
	     g2d.dispose();
	     
   	 }
   	 else
   	 {
         if(!oldBox.contains(stk.getBounds2D(COORD_ABS)))
         {
	         int wi = (int)Math.ceil(labelBoxAbs.getWidth());
	         if(wi<=0)
	         	wi = 1;
	         
	         int he = (int)Math.ceil(labelBoxAbs.getHeight());
	         if(he<=0)
	         	he = 1;
	         		         
	         BufferedImage temp = (BufferedImage)this.getSheet().createImage(wi, he);
	         Graphics2D g2d = temp.createGraphics();			 
	         g2d.setColor(activeImageBg);
	         g2d.fill(new Rectangle2D.Double(0,0,labelBoxAbs.getWidth()+1,labelBoxAbs.getHeight()+1));
	         g2d.setColor(Color.black);
	         g2d.drawImage(temporalImage, 
	         				(int)(oldBox.getMinX()-labelBoxAbs.getMinX()),
	         				(int)(oldBox.getMinY()-labelBoxAbs.getMinY()),
	         				this.getSheet());
       	     g2d.setTransform(AffineTransform.getTranslateInstance(-labelBoxAbs.getMinX(),
	     									-labelBoxAbs.getMinY()));
	         g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		     g2d.draw(stk.getPolygon2D(COORD_ABS));
		     g2d.dispose();
		     temporalImage = temp;
         }
         else
         {
             Graphics2D g2d = temporalImage.createGraphics();			 
	         g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);             
		     g2d.setTransform(AffineTransform.getTranslateInstance(-labelBoxAbs.getMinX(),
	     									-labelBoxAbs.getMinY()));
		     g2d.draw(stk.getPolygon2D(COORD_ABS));
	    	 g2d.dispose();
         }

   	 }

   }   
   
   //-----------------------------------------------------------------   
   
   public void rebuiltTemporalImage(AffineTransform delta, Rectangle2D labelBoxAbs, TimedStroke stk1) {
   	
     int wi = (int)Math.ceil(labelBoxAbs.getWidth());
     if(wi<=0)
     	wi = 1;
     
     int he = (int)Math.ceil(labelBoxAbs.getHeight());
     if(he<=0)
     	he = 1;
     	
     temporalImage = (BufferedImage)this.getSheet().createImage(wi, he);
     
     SatinGraphics g = new SatinGraphics(temporalImage.createGraphics());
     g.setColor(activeImageBg);
     g.fill(new Rectangle2D.Double(0,0,labelBoxAbs.getWidth()+1,labelBoxAbs.getHeight()+1));
     g.setColor(Color.black);
     g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);         
     g.pushTransform(AffineTransform.getScaleInstance(
     		delta.getScaleX(),
     		delta.getScaleY()));
     Iterator it = this.getForwardIterator();

     while(it.hasNext())
     {
    
    	TimedStroke stk = (TimedStroke)it.next();     	

        g.pushTransform(stk.getTransformRef());
        stk.render(g);
        g.popTransform();
     }
     
     g.popTransform();
     g.setTransform(AffineTransform.getTranslateInstance(-labelBoxAbs.getMinX(),
	     									-labelBoxAbs.getMinY()));
     g.draw(stk1.getPolygon2D(COORD_ABS));
     
     g.dispose();

   }
*/      
   //-----------------------------------------------------------------
   
   public void activeFeedback() {

      Rectangle2D patchPos  = this.getBounds2D(COORD_ABS);
      
      int imagew = (int)Math.ceil(patchPos.getWidth());
      
      if(imagew<=0)
         imagew = 1;
        
      int imageh = (int)Math.ceil(patchPos.getHeight());
        
      if(imageh<=0)
         imageh = 1;
         
      BufferedImage tempImage = (BufferedImage)this.getSheet().createImage(imagew, imageh);
     
      this.cacheImageTo(tempImage);

      SatinGraphics gx = new SatinGraphics((Graphics2D)this.getSheet().getGraphics());
      Shape oldClip = gx.getClip();
      gx.clip(patchPos);
      gx.pushTransform(this.getTransform(COORD_ABS));      
      gx.pushStyle(this.getStyleRef());
      this.render(gx);
      gx.popStyle();
      gx.popTransform();
      
      if(oldClip!=null)
        gx.clip(oldClip);
      else
        gx.setClip(null);
       
      this.cacheImageTo(null);
      
      if(Denim.getPlatformState()==Denim.runningOnMac)
      {
         gx.setColor(Color.white);
         gx.fill(patchPos);
      }

      gx.drawImage(tempImage, (int)patchPos.getMinX(), (int)patchPos.getMinY(), this.getSheet());
     
      // draw blue frame around image
      Color oldC = gx.getColor();
      gx.setColor(DenimConstants.activeFrameColor);
      gx.draw(this.getBounds2D(COORD_ABS));
      gx.setColor(oldC);

   }

   
   //-----------------------------------------------------------------

   /**
    * Perform initializations common to all Scribble constructors.
    */
   private void commonInitializations() {
      Style style = getStyle();
      style.setDrawColor(NO_COLOR);
      
      // DEFAULT_SCRIBBLE_BACKGROUND_COLOR is the background color 
      // of the bounding box of scribbled text
      if(Denim.getPlatformState()==Denim.runningOnTablet)
      {
          style.setFillColor(new Color(0,0,0,50));    
      }
      else
      {
      	  if(Denim.getPlatformState()==Denim.runningOnMac)
      	  {
      	  	style.setFillColor(new Color(230,230,230));  
      	  }
      	  else
      	  {
      	  	style.setFillColor(DEFAULT_SCRIBBLE_BACKGROUND_COLOR);
      	  }
      }
//      style.setFillColor(Color.red);  // Shelley: Color
      setStyle(style);
      
      this.setDrawPatch(false);
      this.setFillPatch(true);

      origStyles = null;
      isLink = false;

      setAllowDeepGet(false);
   }
   
   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   /**
    * Ignores single strokes.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      //// ignore
   } // of handleSingleStroke

   //-----------------------------------------------------------------

   /**
    * Returns a deep clone of this scribble.
    */
   public Object deepClone() {
      return deepClone(new ScribbledText());
   }

   //-----------------------------------------------------------------

   /**
    * Makes the given label a deep clone of this scribble, and returns the
    * deep scribble.
    */
   public Object deepClone(ScribbledText clone) {
      super.deepClone(clone);
      return clone;
   }

   //-----------------------------------------------------------------

   public GraphicalObject add(int index, GraphicalObject gob, int pos) {
      GraphicalObject result = super.add(index, gob, pos);

      // If the scribbled text is a link, change the gob being added so that
      // its draw color is the link color
      if (isLink) {
         origStyles.put(gob, gob.getStyle());
         gob.getStyleRef().setDrawColor(DEFAULT_LINK_COLOR);
         // Since this phrase is a link, its parent must be a
         // DenimHyperlinkInstance. Increase its size to match the phrase.
         getParentGroup().setBoundingPoints2D
            (COORD_ABS, getBounds2D(COORD_ABS));
      }
      return result;
   }

   //-----------------------------------------------------------------

   public GraphicalObject remove(GraphicalObject gob) {
      GraphicalObject result = super.remove(gob);
      if (isLink) {
         origStyles.remove(gob);
         // Since this phrase is a link, its parent must be a
         // DenimHyperlinkInstance. Decrease its size to match the phrase.
         getParentGroup().setBoundingPoints2D
            (COORD_ABS, getBounds2D(COORD_ABS));
      }
      return result;
   }

   //-----------------------------------------------------------------

   /**
    * Sets the color of the whole phrase
    */
   public void setColor(Color c) {
      // set all the strokes in the phase to the color c
      Debug.println("Changing color to " + c.toString());
      GraphicalObject currStk;

      Iterator iter = this.getForwardIterator();
      while (iter.hasNext()) {
         currStk = (GraphicalObject) iter.next();
         currStk.getStyleRef().setDrawColor(c);
      }
   }

   //-----------------------------------------------------------------

   /**
    * Sets the background color of the whole phrase
    */
   public void setBackground(Color c) {
      this.getStyleRef().setFillColor(c);
   }

   /**
    * return a 2-element vector
    */
   public static GraphicalObjectCollection split(GraphicalObjectGroup parent, 
           ScribbledText st, Point2D p, boolean isVertical) {
       parent.disableDamage();
       ScribbledText text = (ScribbledText)st.deepClone();
       
       /////////////////////////////////////////////////////
       
       text.applyTransform(st.getTransform(COORD_ABS));
       text.applyTransform(parent.getInverseTransform(COORD_ABS));
       
       /////////////////////////////////////////////////////
       
       parent.add(text, GraphicalObjectGroup.KEEP_REL_POS);
       text.moveTo(COORD_ABS, st.getLocation2D(COORD_ABS));

       Point2D local = new Point2D.Double();
       try
       {
           text.getTransform(COORD_ABS).inverseTransform(p, local);
       }
       catch(Exception ex)
       {
           ex.printStackTrace();
       }
       
       GraphicalObjectCollection col1 = new GraphicalObjectCollectionImpl();
       GraphicalObjectCollection col2 = new GraphicalObjectCollectionImpl();       

       while(text.numElements()>0)
       {
           TimedStroke stk = (TimedStroke)text.get(0);
           if(isVertical==false)
           {
               if(stk.getBounds2D(COORD_REL).getCenterY()<local.getY())
               {
                   parent.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);
                   col1.add(stk);
               }
               else
               {
                   parent.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);
                   col2.add(stk);
               }
           }
           else
           {
               if(stk.getBounds2D(COORD_REL).getCenterX()<local.getX())
               {
                   parent.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);
                   col1.add(stk);
               }
               else
               {
                   parent.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);
                   col2.add(stk);
               }
           }
       }

       GraphicalObjectCollection col = new GraphicalObjectCollectionImpl();
       
       if(!(col1.isEmpty()||col2.isEmpty()))
       {
           /**
            * get the boundingbox and create the new scribbledtext
            */
           ScribbledText text1 = createScribbledText(parent, col1);
           ScribbledText text2 = createScribbledText(parent, col2);

           col.add(text1);
           col.add(text2);
       }
       else
       {
           parent.removeAll(col1);
           parent.removeAll(col2);
       }
       
       parent.remove(text);
       text.delete();       
       parent.enableDamage();
       
       return col;
   }
   
   public static ScribbledText createScribbledText(GraphicalObjectGroup parent, 
           GraphicalObjectCollection col) {
       Rectangle2D bounds = null;
       Iterator it = col.getForwardIterator();
       while(it.hasNext())
       {
           GraphicalObject gob = (GraphicalObject)it.next();
           if(bounds==null)
           {
               bounds = gob.getBounds2D(COORD_REL);
           }
           else
           {
               Rectangle2D.union(gob.getBounds2D(COORD_REL), 
                   bounds,
                   bounds);
           }
       }

       ScribbledText text = new ScribbledText(bounds);
       parent.addToFront(text);

       it = col.getForwardIterator();
       while(it.hasNext())
       {
           TimedStroke stk = (TimedStroke)it.next();
           Point2D pos = stk.getLocation2D(COORD_ABS);
           text.add(stk, GraphicalObjectGroup.KEEP_REL_POS);
           stk.moveTo(COORD_ABS, pos);
       }
       
       return text;
   }

   
   /**
    * merge timedstroke, scribbledtext, hyperlink with scribbledtext contents
    */
   public static ScribbledText merge(GraphicalObjectGroup parent, 
           GraphicalObjectCollection gobs) {

       parent.disableDamage();
       /**
        * if there is any hyperlink
        */
       DenimHyperlinkInstance link = null;
       Iterator it = gobs.getForwardIterator();
       while(it.hasNext())
       {
           GraphicalObject gob = (GraphicalObject)it.next();
           if(gob instanceof DenimHyperlinkInstance)
           {
               link = (DenimHyperlinkInstance)gob;
               break;
           }
       }
       
       /**
        * get the boundingbox and create the new scribbledtext
        */
       Rectangle2D bounds = null;
       it = gobs.getForwardIterator();
       while(it.hasNext())
       {
           GraphicalObject gob = (GraphicalObject)it.next();
           if(bounds==null)
           {
               bounds = gob.getBounds2D(COORD_REL);
           }
           else
           {
               Rectangle2D.union(gob.getBounds2D(COORD_REL), 
                   bounds,
                   bounds);
           }
       }

       ScribbledText text = new ScribbledText(bounds);
       parent.addToFront(text);


       /**
        * put all strokes into text
        */
       it = gobs.getForwardIterator();
       while(it.hasNext())
       {
           GraphicalObject gob = (GraphicalObject)it.next();
           if(gob instanceof TimedStroke)
           {
               GraphicalObject gobclone = (GraphicalObject)gob.deepClone();
               parent.add(gobclone, GraphicalObjectGroup.KEEP_REL_POS);
               gobclone.moveTo(COORD_ABS, gob.getLocation2D(COORD_ABS));
               text.add(gobclone, GraphicalObjectGroup.KEEP_ABS_POS);
           }
           else if(gob instanceof ScribbledText)
           {
               ScribbledText text1 = (ScribbledText)gob.deepClone();
               parent.add(text1, GraphicalObjectGroup.KEEP_REL_POS);
               text1.moveTo(COORD_ABS, gob.getLocation2D(COORD_ABS));
               while(text1.numElements()>0)
               {
                   TimedStroke stk = (TimedStroke)text1.get(0);
                   text.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);
               }               
               parent.remove(text1);
               text1.delete();
         }
         else if(gob instanceof DenimHyperlinkInstance)
         {
               DenimHyperlinkInstance hyper = (DenimHyperlinkInstance)gob;
               ScribbledText t = (ScribbledText)hyper.getContents();
               for(int i=0;i<t.numElements(); i++)
               {
                   TimedStroke stk = (TimedStroke)t.get(i);
                   TimedStroke nstk = (TimedStroke)stk.deepClone();
                   t.add(nstk);
                   text.add(nstk, GraphicalObjectGroup.KEEP_ABS_POS);
                   nstk.moveTo(COORD_ABS, stk.getLocation2D(COORD_ABS));
               }
           }
     }
       
       if(link!=null)
       {
           link.setBoundingPoints2D(COORD_REL, text.getBoundingPoints2D(COORD_REL));
           link.setContents(text);
       }
       parent.enableDamage();
       
       return text;
   }
   
   public void replace(ScribbledText text) {

       GraphicalObjectCollection oldcol = this.getGraphicalObjects();
       
       this.setBoundingPoints2D(COORD_ABS, text.getBounds2D(COORD_ABS));

       while(text.numElements()>0)
       {
           TimedStroke stk = (TimedStroke)text.get(0);
           this.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);       
       }
       
       this.removeAll(oldcol);
   }
   
   public static ScribbledText merge(GraphicalObjectGroup parent, 
           ScribbledText t1, ScribbledText t2) {

       ScribbledText text1 = (ScribbledText)t1.deepClone();
       parent.add(text1, GraphicalObjectGroup.KEEP_REL_POS);
       text1.moveTo(COORD_ABS, t1.getLocation2D(COORD_ABS));
       
       ScribbledText text2 = (ScribbledText)t2.deepClone();
       parent.add(text2, GraphicalObjectGroup.KEEP_REL_POS);
       text2.moveTo(COORD_ABS, t2.getLocation2D(COORD_ABS));
       
       Rectangle2D bounds = new Rectangle2D.Double();
       
       Rectangle2D.union(text1.getBounds2D(COORD_REL), text2.getBounds2D(COORD_REL),
               bounds);

       ScribbledText text = new ScribbledText(bounds);
       parent.addToFront(text);
       
       while(text1.numElements()>0)
       {
           TimedStroke stk = (TimedStroke)text1.get(0);
           text.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);
       }

       while(text2.numElements()>0)
       {
           TimedStroke stk = (TimedStroke)text2.get(0);
           text.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);       
       }

       parent.remove(text1);
       parent.remove(text2);
       text1.delete();
       text2.delete();

       return text;
   }
   
   //-----------------------------------------------------------------

   /**
    * Sets the transparency of the color of the whole phrase
    */
    public void setTransparency(int transparency){

      // set all the strokes in the phase to the given transparency
      GraphicalObject currStk;
      
      Iterator iter = this.getForwardIterator();
      while (iter.hasNext()) {
         currStk = (GraphicalObject) iter.next();
         currStk.getStyleRef().setDrawTransparency(transparency);
      }
    }

   //-----------------------------------------------------------------
   /**
    * Makes the phrase appear or not appear to be a hyperlink 
    */
   public void setHyperlink(boolean makeHyperlink) {
      GraphicalObject currStk;

      if (makeHyperlink && !isLink) {
         origStyles = new HashMap();

         Iterator iter = this.getForwardIterator();
         while (iter.hasNext()) {
            currStk = (GraphicalObject) iter.next();
            origStyles.put(currStk, currStk.getStyle());
            currStk.getStyleRef().setDrawColor(DEFAULT_LINK_COLOR);
         }
         isLink = true;
      }
      else if (!makeHyperlink && isLink) {
         if (origStyles != null) {
            Iterator iter = this.getForwardIterator();
            while (iter.hasNext()) {
               currStk = (GraphicalObject) iter.next();
               currStk.setStyle((Style) origStyles.get(currStk));
            }
         }
         isLink = false;
      }
   }
   
	//-----------------------------------------------------------------
   
   /**
    * clear all references hold by this object (In the namespace of this class)
    */
   
   public void deepClear() {
      super.deepClear();
      
      if(origStyles!=null)
      {
         origStyles.clear();
         origStyles = null;
      }
   }
   
	//-----------------------------------------------------------------
	
	public Polygon2D getPhantom() {
		
		Rectangle2D sb = this.getBounds2D(COORD_ABS);
		
		Polygon2D poly = new Polygon2D();
		
		poly.addPoint(sb.getMinX(),sb.getMinY());
		poly.addPoint(sb.getMinX(),sb.getMaxY());
		poly.addPoint(sb.getMaxX(),sb.getMaxY());
		poly.addPoint(sb.getMaxX(),sb.getMinY());
		poly.setClosed(true);
		
		return poly;  
	}
    
    public boolean isCouldBeCaption() {
        return couldBeCaption;
    }
    
    public boolean isCaption() {
        if(this.getParentGroup()!=null)
        {
            if(this.getParentGroup().getParentGroup()!=null)
            {
                if(this.getParentGroup().getParentGroup() instanceof DenimIntrinsicComponentInstance)
                    return true;
            }
        }
        return false;
    }
    
}

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
