package edu.berkeley.guir.damask.command;

import java.awt.geom.GeneralPath;
import java.util.Arrays;

import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that adds a stroke to a piece of content.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-14-2003 James Lin
 *                               Created AddStrokeCommand.
 *             2.0.0  01-07-2004 James Lin
 *                               Now adds stroke to existing content, instead
 *                               of creating content.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-14-2003
 */
public class AddStrokeCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final Content content;
   private final GeneralPath path;


   /**
    * Constructs the command.
    *  
    * @param content the content to add the stroke to
    * @param region the page region, in whose local coordinates the path
    * parameter is in
    * @param path the path of the stroke
    */      
   public AddStrokeCommand(
      final Content content,
      final GeneralPath path) {

      this.content = content;
      this.path = new GeneralPath(path);
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Add stroke " + Arrays.asList(DamaskAppUtils.getEndPoints(path)) +
         " to content " + content;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      content.addStroke(path);
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      content.removeStroke(path);
   }
}
