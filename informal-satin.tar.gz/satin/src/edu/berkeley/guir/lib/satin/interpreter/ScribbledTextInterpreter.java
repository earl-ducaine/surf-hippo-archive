package edu.berkeley.guir.lib.satin.interpreter;

import java.awt.geom.*;
import java.util.*;
import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.Sheet;
import edu.berkeley.guir.lib.satin.command.Command;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;
import edu.berkeley.guir.lib.satin.event.SingleStrokeEvent;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.watch.Watchable;
import edu.berkeley.guir.lib.satin.watch.Watcher;

/**
 * <p>An interpreter that determines whether strokes belong to scribbled
 * text.</p>
 * 
 * <p>The criteria for belonging in a phrase are:</p>
 * <ul>
 * <li>below the minimum height to be "letter-like"
 * <li>not long and straight   
 * <li>not crossing the boundaries of a sketch
 * </ul>
 * 
 * <p>When a "phraseworthy" stroke is found, either</p>
 * <ul>
 * <li>a new piece of scribbled text is created
 * <li>if it is near enough to an existing phrase, 
 *     and more or less horizontally aligned with it
 *     it is added to the existing phrase (not implemented yet)
 * <li>it can also be vertically aligned with it, if it
 *     is near enough in time to the original creation of 
 *     the phrase (not implemented yet)
 * </ul>
 * 
 * <p>In the current version, only the most recently created scribbled text
 * can be added to.</p>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  1.0.0  before 08-29-1999 MWN
 *                    Created
 *             1.0.1  08-29-1999 MWN
 *                    Added additional tests to distinguish phrases from arrows
 *             1.0.2  06-22-2000 JH
 *                    Removed dead code
 *             2.0.0  10-19-2000 JL
 *                    Renamed ScribbledTextInterpreter
 *             2.1.0  10-17-2001 JL and Scott Klemmer
 *                    Split into SATIN class and DENIM-specific class
 * 
 *  
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~newman/">Mark Newman</A> (
 *         <A HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu</A> )
 * 
 * 
 * @since   JDK 1.2
 * @version Version 2.0.0, 11-12-2002
 */
public class ScribbledTextInterpreter 
   extends DefaultInterpreterImpl 
   implements Watcher, SatinConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 5319980068459537343L;

   //-----------------------------------------------------------------

   public static final double DEFAULT_DISTANCE_THRESHOLD           = 200.0;
   public static final double DEFAULT_VERTICAL_HEIGHT_THRESHOLD    = 80.0;
   public static final double DEFAULT_HORIZONTAL_OFFSET_THRESHOLD  = 40.0;
   public static final double DEFAULT_VERTICAL_OFFSET_THRESHOLD    = 5.0;
   public static final double DEFAULT_STRAIGHTNESS_THRESHOLD       = 0.2;
   
   public static final int    DEFAULT_LETTER_HEIGHT                = 80;
   public static final int    DEFAULT_INTERWORD_SPACE              = 45;
   public static final int    DEFAULT_INTERLINE_SPACE              = 5;

   //===   CONSTANTS   =========================================================
   //===========================================================================
   

   //===========================================================================
   //===   COMMANDS   ==========================================================

   /**
    * Adds a stroke to a scribble.
    *
    * <PRE>
    * Revisions:  1.0.0  07-10-2000 JL
    *                    Created class AddStrokeToScribbleCommand
    * </PRE>
    *
    * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
    *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
    * @since   JDK 1.2
    * @version Version 1.0.0, 07-10-2000
    */
   public class AddStrokeToScribbleCommand 
      extends UndoableCommand {

      //=======================================================================
      //===   INSTANCE VARIABLES   ============================================

      private Patch         scribble;
      private TimedStroke   newStk;
      private Rectangle2D   oldRelBds;     // original rel bds of scribble
      private Rectangle2D   newRelBds;     // new rel bds of scribble
      private Map           stkOldRelLocs; // maps gr objects to rel locations
      private Map           stkNewRelLocs; // maps gr objects to rel locations
      
      
      // bookkeeping variables for interpreter
      private TimedStroke oldLastStk;
      private boolean     oldNewScribbleWasCreated;
      private boolean     oldStrokeWasAddedToScribble;

      //===   INSTANCE VARIABLES   ============================================
      //=======================================================================
      


      //=======================================================================
      //===   CONSTRUCTORS   ==================================================

      /**
       * Construct the command.
       * 
       * @param scribble  the scribble to add the stroke to
       * @param newStk    the stroke to add
       */
      public AddStrokeToScribbleCommand(Patch scribble,
                                        TimedStroke newStk) {
         super();
         this.scribble = scribble;
         this.newStk = newStk;
         
         oldLastStk = lastStk;
         oldNewScribbleWasCreated = newScribbleWasCreated;
         oldStrokeWasAddedToScribble = strokeWasAddedToScribble;
      } // of constructor
      
      //===   CONSTRUCTORS   ==================================================
      //=======================================================================



      //=======================================================================
      //===   NAME ACCESSOR METHODS   =========================================

      public String getPresentationName() {
         return ("add stroke to scribble");
      } // of getPresentationName

      //===   NAME ACCESSOR METHODS   =========================================
      //=======================================================================

      private void setRelLocations(Map relLocs) {
         Iterator it = relLocs.keySet().iterator();
         while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject)it.next();
            gob.moveTo(COORD_REL, (Point2D)relLocs.get(gob));
         }
      }

      //=======================================================================
      //===   COMMAND   =======================================================

      /**
       * Notifies the command system that this command can be redone.
       */
      public boolean canRedo() {
         return true;
      } // of method

      //-----------------------------------------------------------------

      public void run() {
         Iterator it;
         Map stkOldAbsLocs = new HashMap();
         stkOldRelLocs = new HashMap();
         stkNewRelLocs = new HashMap();
         
         // Store the relative location of the scribble
         oldRelBds = scribble.getBounds2D(COORD_REL);
         
         // Save locations on all strokes in scribble
         it = scribble.getForwardIterator();
         while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject)it.next();
            stkOldRelLocs.put(gob, gob.getLocation2D(COORD_REL));
            stkOldAbsLocs.put
               (gob,
                getLocalToAbs(gob, gob.getLocation2D(COORD_LOCAL)));
         }

         // Create a dummy patch with the same size as the scribble
         // will have after the stroke is added
         Rectangle2D oldAbsBds = getLocalToAbs
            (scribble, scribble.getBounds2D(COORD_LOCAL));
         
         Rectangle2D newAbsBds =
            oldAbsBds.createUnion(newStk.getBounds2D(COORD_ABS));
         
         // Calculate the scribble's new relative bounds
         newRelBds = getAbsToLocal(scribble.getParentGroup(), newAbsBds);
         
         Patch dummy = new PatchImpl(newRelBds);
         dummy.setVisible(false);
         scribble.getParentGroup().add(dummy,
                                       GraphicalObjectGroup.KEEP_REL_POS);
         
         // Calculate the new relative bounds of the scribble's strokes
         it = scribble.getForwardIterator();
         while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject)it.next();
            stkNewRelLocs.put
               (gob,
                getAbsToLocal(dummy, (Point2D)stkOldAbsLocs.get(gob)));
         }
         
         // Calculate the new relative position of the new stroke
/*         AffineTransform txOld = getAbsTransform(newStk);
         AffineTransform txApply = getInverseAbsTransform(dummy);
         txApply.concatenate(txOld);
         newStk.setTransform(txApply);
  */       
			GraphicalObjectLib.toLocalCoordinates(newStk, dummy);
         
         // Delete the dummy
         dummy.delete();
         
         // Scale the stroke in case the scribble is wrapped by a transform
         // with a scale factor other than 1.
    /*     double sheetScale =
            GraphicalObjectLib.getScaleFactor(COORD_ABS, scribble.getSheet());

         double scribbleScale =
            GraphicalObjectLib.getScaleFactor(COORD_ABS, scribble);
            
         if (Math.abs(sheetScale - scribbleScale) > 0.01) {
            double strokeScale = sheetScale / scribbleScale;
         
            final TimedPolygon2D newPoly2 =
               newStk.getPolygon2D(
                  COORD_LOCAL,
                  AffineTransform.getScaleInstance(strokeScale, strokeScale),
                  null);
            final TimedStroke newStk2 = new TimedStroke(newPoly2);
            double newStkX = newStk.getBounds2D(COORD_REL).getX();
            double newStkY = newStk.getBounds2D(COORD_REL).getY();
            newStk2.moveTo(COORD_REL, newStkX, newStkY);
            newStk = newStk2;
         }
      */   
         // Now actually add the stroke
         redo();
      } // of method
      
      //-----------------------------------------------------------------

      public void redo() {
         // Resize the scribble to its new bounds
         scribble.disableDamage();
         scribble.disableNotify();
         scribble.setBoundingPoints2D(COORD_REL, newRelBds);
         scribble.enableNotify();
         scribble.enableDamage();
         
         // Set the locations of the other strokes in the scribble
         setRelLocations(stkNewRelLocs);
         
         // Add the stroke
         scribble.add(newStk, GraphicalObjectGroup.KEEP_REL_POS);
         
         // bookkeeping for interpreter
         lastStk                = newStk;
         newScribbleWasCreated  = false;
         strokeWasAddedToScribble = true;
      } // of method
      
      //-----------------------------------------------------------------

      public void undo() {
         // Remove the new stroke
         scribble.remove(newStk);
         
         // Set the locations of the other strokes in the scribble
         setRelLocations(stkOldRelLocs);
         
         // Resize the scribble to its new bounds
         scribble.disableDamage();
         scribble.disableNotify();
         scribble.setBoundingPoints2D(COORD_REL, oldRelBds);
         scribble.enableNotify();
         scribble.enableDamage();
         
         // bookkeeping for interpreter
         lastStk                  = oldLastStk;
         newScribbleWasCreated    = oldNewScribbleWasCreated;
         strokeWasAddedToScribble = oldStrokeWasAddedToScribble;
      } // of method

      //===   COMMAND   =======================================================
      //=======================================================================

   } // of class
   

   /**
    * Creates a new scribble.
    *
    * <PRE>
    * Revisions:  1.0.0  07-10-2000 JL
    *                    Created class CreateNewScribbleCommand
    * </PRE>
    *
    * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
    *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
    * @since   JDK 1.2
    * @version Version 1.0.0, 07-10-2000
    */
   public class CreateNewScribbleCommand 
      extends UndoableCommand {

      //=======================================================================
      //===   INSTANCE VARIABLES   ============================================

      private GraphicalObjectGroup parent;
      private Patch                scribble;
      private Rectangle2D          scribbleRelBds;
      private TimedStroke          stk;
      private Point2D              stkRelLoc;
      
      // bookkeeping variables for interpreter
      private TimedStroke   oldLastStk;
      private boolean       oldNewScribbleWasCreated;
      private boolean       oldStrokeWasAddedToScribble;
      private Patch oldCurrentScribble;

      //===   INSTANCE VARIABLES   ============================================
      //=======================================================================
      


      //=======================================================================
      //===   CONSTRUCTORS   ==================================================

      /**
       * Construct the command.
       * 
       * @param parent    the group to add the scribble to
       * @param scribble  the scribble to add
       * @param stk       the stroke that is the first stroke of the scribble
       */
      public CreateNewScribbleCommand(GraphicalObjectGroup parent,
                                      Patch scribble,
                                      TimedStroke stk) {
         super();
         this.parent = parent;
         this.scribble = scribble;
         this.stk = stk;

         oldLastStk = lastStk;
         oldNewScribbleWasCreated = newScribbleWasCreated;
         oldStrokeWasAddedToScribble = strokeWasAddedToScribble;
         oldCurrentScribble = currentScribble;
      } // of constructor
      
      //===   CONSTRUCTORS   ==================================================
      //=======================================================================



      //=======================================================================
      //===   NAME ACCESSOR METHODS   =========================================

      public String getPresentationName() {
         return ("create new scribble");
      } // of getPresentationName

      //===   NAME ACCESSOR METHODS   =========================================
      //=======================================================================



      //=======================================================================
      //===   COMMAND   =======================================================

      /**
       * Notifies the command system that this command can be redone.
       */
      public boolean canRedo() {
         return true;
      } // of method

      //-----------------------------------------------------------------

      public void run() {
         // Create a dummy patch with the same abs bounds as the new
         // scribble
         Rectangle2D stkAbsBds = stk.getBounds2D(COORD_ABS);

         Patch dummy = new PatchImpl(stkAbsBds);
         dummy.setVisible(false);
         
         parent.add(dummy, GraphicalObjectGroup.KEEP_ABS_POS);
         
         // Get the relative bounds of the dummy, which will be the relative
         // bounds of the scribble
         scribbleRelBds = dummy.getBounds2D(COORD_REL);
         
         // Get the location of the stroke relative to the dummy, which
         // will be the relative bounds of the stroke within the scribble
         Rectangle2D stkRelBds = getAbsToLocal(dummy, stkAbsBds);
         stkRelLoc = new Point2D.Double(stkRelBds.getX(), stkRelBds.getY());
         
         dummy.delete();
         
         // Set the size of the scribble
         scribble.setBoundingPoints2D(COORD_REL, scribbleRelBds);
         
         // Add the scribble to its parent
         parent.add(scribble, GraphicalObjectGroup.KEEP_REL_POS);

         // Add the stroke to the scribble
         scribble.add(stk, GraphicalObjectGroup.KEEP_ABS_POS);
         stk.moveTo(COORD_REL, stkRelLoc);
         
         afterDo();
      } // of method
      
      //-----------------------------------------------------------------

      public void redo() {
         // Add the scribble to its parent
         
         parent.add(scribble, GraphicalObjectGroup.KEEP_REL_POS);
         
         afterDo();
      }
      
      //-----------------------------------------------------------------
      
      private void afterDo() {
         // bookkeeping for interpreter
         if (oldCurrentScribble != null) {
            oldCurrentScribble.removeWatcher(ScribbledTextInterpreter.this);
         }
         scribble.addWatcher(ScribbledTextInterpreter.this);
         lastStk = stk;
         newScribbleWasCreated = true;
         strokeWasAddedToScribble = false;
         currentScribble = scribble;
      } // of method
      
      //-----------------------------------------------------------------

      public void undo() {
         parent.remove(scribble);
         
         // bookkeeping for interpreter
         if (oldCurrentScribble != null) {
            oldCurrentScribble.addWatcher(ScribbledTextInterpreter.this);
         }
         scribble.removeWatcher(ScribbledTextInterpreter.this);
         lastStk                  = oldLastStk;
         newScribbleWasCreated    = oldNewScribbleWasCreated;
         strokeWasAddedToScribble = oldStrokeWasAddedToScribble;
         currentScribble          = oldCurrentScribble;
      } // of method

      //===   COMMAND   =======================================================
      //=======================================================================

   } // of class
   
   //===   COMMANDS   ==========================================================
   //===========================================================================

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   //// Algorithm parameters
   //// the distance below which two strokes are considered "close"
   private double distanceThreshold; 

   //// the height below which a stroke is a candidate for being handwriting
   private double verticalHeightThreshold; 
   private double horizontalOffsetThreshold;
   private double verticalOffsetThreshold;
   private double straightnessThreshold;
        
   //// Handwriting parameters
   private int interWordSpace;
   private int interLineSpace;
   private int letterHeight;
   private int letterHeightSq;
   
   //// Persistent state between invocations of this interpreter
   protected TimedStroke lastStk;
   private Patch currentScribble;
   
   //// Flags to record what happened in handleSingleStroke()
   private boolean newScribbleWasCreated;
   private boolean strokeWasAddedToScribble;
                
   //// reference to parent
   protected GraphicalObjectGroup parent; 
   
   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================


        
   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates a scribbled text interpreter.
    */
   public ScribbledTextInterpreter() {
      //// 0. Interpreter initializations.
      setName("Scribble Interpreter");

      //// 1. Set the distance thresholds.
      distanceThreshold         = DEFAULT_DISTANCE_THRESHOLD;

      //// 2. Set the stroke "looks like a character" thresholds.
      verticalHeightThreshold   = DEFAULT_VERTICAL_HEIGHT_THRESHOLD;
      horizontalOffsetThreshold = DEFAULT_HORIZONTAL_OFFSET_THRESHOLD;
      verticalOffsetThreshold   = DEFAULT_VERTICAL_OFFSET_THRESHOLD;
      straightnessThreshold     = DEFAULT_STRAIGHTNESS_THRESHOLD;

      //// 3. Set the space-between-words thresholds.
      interWordSpace            = DEFAULT_INTERWORD_SPACE;
      interLineSpace            = DEFAULT_INTERLINE_SPACE;
      letterHeight              = DEFAULT_LETTER_HEIGHT;
      letterHeightSq            = letterHeight * letterHeight;
                     
      lastStk                   = null;
      currentScribble           = null;
   } // of constructor
   
   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   STROKE METHODS   ====================================================
   
   //TODO: Add a timer? More an issue for the LabelIntepreter perhaps

   /**
    * Determines whether the stroke is part of a phrase.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      TimedStroke thisStk = evt.getStroke();

      //// 0.1. If the stroke is too short, then ignore.
      if (thisStk.getLength2D(COORD_ABS) < MIN_SCRIBBLE_STK_LEN) {
         return;
      }

      //// 0.2. Disable any damage from occurring on the sheet, so
      ////      that it doesn't look like it's gone beserk.
      parent = (GraphicalObjectGroup) this.getAttachedGraphicalObject();
      parent.disableDamage();

      //// 1. If stroke belongs with current phrase, add it.
      if (isRightSize(thisStk) && belongsWithScribble(thisStk, currentScribble)) {
         cmdqueue.doCommand(new AddStrokeToScribbleCommand(currentScribble,
                                                           thisStk));
         evt.setConsumed(true);
      }
                        
      //// 2. If stroke is phraseworthy, but doesn't belong with the 
      ////    current phrase, start a new phrase.
      else if (isRightSize(thisStk)) { 
         doCreateNewScribbleCommand(parent, thisStk);
         evt.setConsumed(true);
      }

      //// 3. Re-enable the damage.
      parent.enableDamage();
   }

   //===   STROKE METHODS   ====================================================
   //===========================================================================

   
   /**
    * Executes a command to add a stroke to the current scribble.
    */
   public Command getAddStrokeToScribbleCommand(Patch scribble,
                                                TimedStroke stk) {
      return new AddStrokeToScribbleCommand(scribble, stk);
   }        

   
   //===========================================================================
   //===   WATCHER METHODS   ===================================================

   public void onNotify(Watchable w, Object arg) {
   }
   
   public void onUpdate(Watchable w, Object arg) {
   }
   
   public void onUpdate(Watchable w,
                        String strProperty,
                        Object oldVal,
                        Object newVal) {
   }
   
   public void onDelete(Watchable w) {
      if (w == currentScribble) {
         currentScribble = null;
         //debug.println("currentScribble: " + currentScribble);
      }
   }

   
   //===   WATCHER METHODS   ===================================================
   //===========================================================================
   
   
   //===========================================================================
   //===   SIMPLE ACCESSOR / MODIFIER METHODS   ================================

   /**
    * Creates a new patch and adds the stroke just drawn to the patch.
    * If you want to create something besides a PatchImpl or do a command
    * other than simply creating a new patch, override this method.
    * 
    * @param parent the group to which the new patch will be created
    * @param stk    the stroke which will be added to the patch
    */
   protected void doCreateNewScribbleCommand(GraphicalObjectGroup parent,
                                             TimedStroke stk) {
      Patch newScribble = new PatchImpl();
            
      cmdqueue.doCommand(new CreateNewScribbleCommand(parent,
                                                      newScribble,
                                                      stk));
   }
   
   //-----------------------------------------------------------------

   /**
    * Returns the phrase that a "suitable" stroke would be added to.
    */
   public Patch getCurrentScribble() {
      return currentScribble;
   }
   
   //-----------------------------------------------------------------

   /**
    * Returns whether the most recent stroke was added to the current phrase.
    */
   public boolean getStrokeWasAddedToScribble() {
      return strokeWasAddedToScribble;  
   } 
   
   //-----------------------------------------------------------------

   /**
    * Returns whether a new phrase was just created by the interpreter.
    */
   public boolean getNewScribbleWasCreated() {
      return newScribbleWasCreated;
   }
   
   //-----------------------------------------------------------------

   /** 
    * Gets the space between words acceptable for strokes to be 
    * considered part of the same phrase.
    */
   public int getInterWordSpace() {
      return interWordSpace;  
   }
   
   //-----------------------------------------------------------------

   /** 
    * Sets the space between words acceptable for strokes to be 
    * considered part of the same phrase.
    */
   public void setInterWordSpace(int iws) {
      interWordSpace = iws;
   }
   
   //-----------------------------------------------------------------

   /** 
    * Gets the space between lines acceptable for strokes to be 
    * considered part of the same (multi-line) phrase.
    */
   public int getInterLineSpace() {
      return interLineSpace;  
   }
   
   //-----------------------------------------------------------------

   /** 
    * Sets the space between lines acceptable for strokes to be 
    * considered part of the same (multi-line) phrase.
    */   
   public void setInterLineSpace(int ils) {
      interLineSpace = ils;  
   }
      
   //-----------------------------------------------------------------

   /** 
    * Gets the maximum height a stroke can be to be considered handwriting.
    */ 
   public int getLetterHeight() {
      return letterHeight;  
   }
   
   //-----------------------------------------------------------------

   /** 
    * Sets the maximum height a stroke can be to be considered handwriting.
    */  
   public void setLetterHeight(int lh) {
      letterHeight   = lh;
      letterHeightSq = lh * lh;
   }  

   //===   SIMPLE ACCESSOR / MODIFIER METHODS   ================================
   //===========================================================================

   
   //===========================================================================
   //===   IDEALLY UNNECESSARY METHODS   =======================================

   /**
    * HACK:
    * These methods are here because the default implementations do NOT work
    * for sticky objects. For example, DENIM overrides these methods with ones
    * that will work for its sticky objects. Unfortunately, there is no general
    * way to get these methods work with sticky objects, since that would
    * involve making some protected methods in StickyView public, which I am
    * not prepared to do at this time.
    * 
    * Jimmy Lin - 10/17/01
    */
   
   /**
    * Returns a point in absolute coordinates corresponding to the given
    * point in the given graphical object's local coordinate system.
    *
    * @param gob the object whose coordinate system the pt parameter is in
    * @param pt a point which is in gob's coordinate system
    */
   protected Point2D getLocalToAbs(GraphicalObject gob, Point2D pt) {
      return GraphicalObjectLib.localToAbsolute(gob, pt);
   }

   //-----------------------------------------------------------------

   /**
    * Returns a point in the coordinate system of the given graphical object
    * corresponding to the given point in absolute coordinates.
    *
    * @param gob the object whose coordinate system the returned point is in
    * @param pt a point in absolute coordinates
    */
   protected Point2D getAbsToLocal(GraphicalObject gob, Point2D pt) {
      return GraphicalObjectLib.absoluteToLocal(gob, pt);
   }

   //-----------------------------------------------------------------


   /**
    * Returns a rectangle in absolute coordinates corresponding to the given
    * rectangle in the given graphical object's local coordinate system.
    *
    * @param gob the object whose coordinate system the rect parameter is in
    * @param rect a rectangle which is in gob's coordinate system
    */
   protected Rectangle2D getLocalToAbs(GraphicalObject gob,
                                       Rectangle2D rect) {
      return GraphicalObjectLib.localToAbsolute(gob, rect);
   }

   //-----------------------------------------------------------------

   /**
    * Returns a rectangle in the coordinate system of the given graphical
    * object corresponding to the given rectangle in absolute coordinates.
    *
    * @param gob the object whose coordinate system the returned point is in
    * @param rect a rectangle in absolute coordinates
    */
   protected Rectangle2D getAbsToLocal(GraphicalObject gob,
                                       Rectangle2D rect) {
      return GraphicalObjectLib.absoluteToLocal(gob, rect);
   }

   //-----------------------------------------------------------------
   
   /**
    * Returns the absolute transform of the given graphical object.
    */
   protected AffineTransform getAbsTransform(GraphicalObject gob) {
      return gob.getTransform(COORD_ABS);
   }

   //-----------------------------------------------------------------

   /**
    * Returns the inverse absolute transform of the given graphical
    * object.
    */
   protected AffineTransform getInverseAbsTransform(GraphicalObject gob) {
      return gob.getInverseTransform(COORD_ABS);
   }

   //===   IDEALLY UNNECESSARY METHODS   =======================================
   //===========================================================================

   
   //===========================================================================
   //===   MAINTENANCE METHODS   ===============================================

   /**
    * Resize the phrase to accomodate the new graphical object.
    * Uses absolute coordinates for everything since we don't know if 
    * they share a parent.
    */
//   private void resizeScribble(GraphicalObject gob) {
//      Rectangle2D gobBounds = gob.getBounds2D(COORD_REL);
//      Rectangle2D bounds    = currentScribble.getBounds2D(COORD_REL);
//
//
//      double gobMinExtentX = gobBounds.getX();
//      double gobMinExtentY = gobBounds.getY();
//      double gobMaxExtentX = gobBounds.getX() + gobBounds.getWidth();
//      double gobMaxExtentY = gobBounds.getY() + gobBounds.getHeight();
//      double minExtentX    = bounds.getX();
//      double minExtentY    = bounds.getY();
//      double maxExtentX    = bounds.getX() + bounds.getWidth();
//      double maxExtentY    = bounds.getY() + bounds.getHeight();
//      
//      if (gobMinExtentX < minExtentX) minExtentX = gobMinExtentX;
//      if (gobMinExtentY < minExtentY) minExtentY = gobMinExtentY;
//      if (gobMaxExtentX > maxExtentX) maxExtentX = gobMaxExtentX;
//      if (gobMaxExtentY > maxExtentY) maxExtentY = gobMaxExtentY;
//      
//      bounds.x = minExtentX;
//      bounds.y = minExtentY;
//      bounds.width = maxExtentX - minExtentX;
//      bounds.height = maxExtentY - minExtentY;
//      
//
//      Rectangle2D.union(bounds, gobBounds, bounds);
//
//      currentScribble.setBoundingPoints2D(COORD_ABS, bounds);
//      //debug.println("New stroke was at:" + gobBounds);
//      //debug.println("Phrase was resized & repositioned to: " + bounds);
//   }
   
   //===   MAINTENANCE METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   INTERPRETATION METHODS   ============================================
   
   /**
    * <p>Determines whether or not a stroke looks like it could be handwritten 
    * text.</p>
    * 
    * <p>Strokes that belong to a stream of handwritten text are
    * letters, portions of letters, or handwritten words.</p>
    * 
    * <p>Disallowed strokes are those that are:</p>
    * <UL> 
    * <LI>taller than letter height (where letter height should 
    *     ideally be defined on a per-user basis)</LI>
    * <LI>long and mostly straight (having a small absolute 
    *     angle as compared to its length)</LI>
    * </UL>
    */
   public boolean looksLikeText(TimedStroke stk, double scaleFactor) {
      boolean        isRightHeight = false; 
      boolean        isCurvy = false;
      //TotalAbsAngle  absAngle;
      //double         curviness;
      Rectangle2D    bounds;
      
      //// 0. Normalize stroke bounds so that they are expressed in the 
      ////    same terms as, say, the absoluteLength
      bounds = stk.getBounds2D(COORD_ABS);
      
      //// 1. Determine whether this stroke is a reasonable height 
      ////    for handwriting
      if (bounds.getHeight() <= verticalHeightThreshold) {
         isRightHeight = true;
      } else {
         isRightHeight = false;
      }
      
      //// 2. If this stroke is longer than tall, and longer than the 
      ////    minimum arrow dimension, get the absolute angle to see if 
      ////    it's curvy

      //// 2.1 (new strategy:) if absolute length is less than the hypotenuse 
      ////     of the triangle formed by the width of the stroke and the 
      ////     maximum height then it's not curvy enough.
      if (bounds.getWidth() > interWordSpace) {
         int wSq = (int) (bounds.getWidth() * bounds.getWidth());
         if (stk.getLength2D(COORD_ABS) < Math.sqrt(wSq + letterHeightSq)) {
            isCurvy = false;  
         } else {
            isCurvy = true;
         }
      } else {
         isCurvy = true;
      }

      /*
      debug.println("is right height? " + isRightHeight);
      debug.println("is curvy? " + isCurvy);
      debug.println("looks like text? " + (isRightHeight && isCurvy));
      debug.println("-----------------------------");
      */
          
      return (isRightHeight && isCurvy);        
   }
   
   //-----------------------------------------------------------------

   public boolean isRightSize(TimedStroke stk) {
      return (looksLikeText(
                     stk,
                     GraphicalObjectLib.getScaleFactor(COORD_REL, parent)));
   }

   //-----------------------------------------------------------------

   /**
    * Check if the specified stroke "belongs" with the specified phrase.
    */
   public boolean belongsWithScribble(TimedStroke stk, Patch phrase) {
      boolean retVal = false;
          
      //// 1. If no current phrase or no last stroke, return false.
      if (phrase == null || lastStk == null) {
         //debug.println("Something was null, phrase: " + phrase + 
         //              ", lastStk: " + lastStk);
         retVal = false;
      } 
      
      //// 2. If this stroke is close enough to the last stroke, it passes.
      else if (StrokeLib.computeHandwritingDistance(stk, lastStk) 
                                                         < distanceThreshold) {
         retVal = true;
      }

      //// 3. If this stroke is below & close enough to the left side of 
      ////    the phrase. (Scale the vertical threshold to the current
      ////    zoom level of the sheet.)
      else {
         Rectangle2D bdsStk    = stk.getBounds2D(COORD_ABS);
         Rectangle2D bdsPhrase = phrase.getBounds2D(COORD_ABS);
         Sheet sheet =
            this.getAttachedGraphicalObject().getSheet();
         double sheetAbsScale = GraphicalObjectLib.getScaleFactor(COORD_ABS, sheet);

         if ((bdsStk.getX() > bdsPhrase.getX() - horizontalOffsetThreshold) &&
             (bdsStk.getX() < bdsPhrase.getX() + horizontalOffsetThreshold) &&
             (bdsStk.getY() > bdsPhrase.getY() + bdsPhrase.getHeight() -
                           (verticalOffsetThreshold * sheetAbsScale)) &&
             (bdsStk.getY() < bdsPhrase.getY() + bdsPhrase.getHeight() +
                           (verticalOffsetThreshold * sheetAbsScale))) {
            retVal = true;        
         }
         else {
            retVal = false;        
         }
      }

      return retVal;
   } // of method
   
   //===   INTERPRETATION METHODS   ============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      ScribbledTextInterpreter pInterp  = new ScribbledTextInterpreter();

      pInterp.distanceThreshold         = distanceThreshold;
      pInterp.verticalHeightThreshold   = verticalHeightThreshold;
      pInterp.horizontalOffsetThreshold = horizontalOffsetThreshold;
      pInterp.verticalOffsetThreshold   = verticalOffsetThreshold;
      return pInterp;
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
