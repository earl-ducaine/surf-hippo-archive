//// See bottom of source code for software license.
package edu.berkeley.guir.lib.util;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Formats Java Date object as ISO date (ISO8601). Format is 
 * yyyymmdd<B>T</B>hhmmss (the 'T' is a literal T).
 * For example,
 * <PRE>
 * 19960329T083000Z
 * 19960401T235959
 * </PRE>
 *
 * This needs to be fixed so that illegal dates will not be allowed, and that
 * leap years will be calculated correctly. This is because the Calendar class
 * does not check bounds correctly (e.g. February 29 becomes March 1). Go
 * figure.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Apr 09 2002 JIH
 */
public class DateLib {

   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   static final Calendar cal = Calendar.getInstance();

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Utility class, no instances allowed.
    */
   private DateLib() {
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   UTILITY METHODS   ===================================================

   /**
    * Get the current date and time in ISO format.
    *
    * @return a String containing the current date and time.
    */
   public static String getCurrentISODate() {
      return(DateToISO(new Date()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Compare two dates.
    *
    * <PRE>
    * if date1 lthan date2 = -1
    * if date1   =   date2 = 0
    * if date1 gthan date2 = 1
    * </PRE>
    *
    * @param date1 is a Java Date object.
    * @param date2 is a Java Date object.
    */
   public static int compareDate(Date date1, Date date2) {
      if (date2.after(date1)) {
         return (-1);
      }
      if (date1.after(date2)) {
         return (1);
      }
      return(0);
   } // of method

   //-----------------------------------------------------------------

   /**
    * See the other compareDate() method for details.
    *
    * @param date1 is a Java Date object.
    * @param strDate2 is an ISO format date.
    */
   public static int compareDate(Date date1, String strDate2) {
      Date d2 = ISOToDate(strDate2);
      return(compareDate(date1, d2));
   } // of method

   //-----------------------------------------------------------------

   /**
    * See the other compareDate() method for details.
    *
    * @param strDate1 is an ISO format date.
    * @param date2 is a Java Date object.
    */
   public static int compareDate(String strDate1, Date date2) {
      Date d1 = ISOToDate(strDate1);
      return(compareDate(d1, date2));
   } // of method

   //-----------------------------------------------------------------

   /**
    * See the other compareDate() method for details.
    *
    * @param strDate1 is an ISO format date.
    * @param strDate2 is an ISO format date.
    */
   public static int compareDate(String strDate1, String strDate2) {
      Date d1 = ISOToDate(strDate1);
      Date d2 = ISOToDate(strDate2);
      return(compareDate(d1, d2));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Pad the string so that it has length 2.
    */
   private static String padValue(int val) {
      //// 1. Since this is pretty much the only case, we can use a hack
      ////    instead of a nice generalized solution.
      if ((0 <= val) && (val <= 9)) {
         return("0" + val);
      }

      return("" + val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert a Java Date object to an ISO date string.
    */
   public static synchronized String DateToISO(Date date) {
      cal.setTime(date);
      return(  padValue(cal.get(Calendar.YEAR))
             + padValue(cal.get(Calendar.MONTH) + 1)
             + padValue(cal.get(Calendar.DAY_OF_MONTH))
             + "T"
             + padValue(cal.get(Calendar.HOUR_OF_DAY))
             + padValue(cal.get(Calendar.MINUTE))
             + padValue(cal.get(Calendar.SECOND)));
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if the specified String is a valid date.
    */
   public static boolean isValidISODate(String str) {
      //// 1. If we can convert it, it's valid.
      try {
         ISOToDate(str);
      }
      catch (Exception e) {
         return (false);
      }
      return (true);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert an ISO date string to a Java Date object.
    * String format expected is YYYYMMDDTHHMMSS[Z].
    *
    * @param  str is the ISO date string to parse.
    * @throws IllegalArgumentException if the date string cannot be parsed.
    */
   public static synchronized Date ISOToDate(String str) {
      //// 1. Bounds checking. The length of the string must be 15 or 16.
      int strlen = str.length();
      if (! ((15 <= strlen) && (strlen <= 16))) {
         throw new IllegalArgumentException("String must be 15 or 16 chars long");
      }
      if (str.charAt(8) != 'T') {
         throw new IllegalArgumentException("Missing the 'T' in the ISO Date");
      }

      //// 2. Parse the values
      String strYear   = str.substring(0, 4);
      String strMonth  = str.substring(4, 6);
      String strDay    = str.substring(6, 8);
      String strHour   = str.substring(9, 11);
      String strMinute = str.substring(11, 13);
      String strSecond = str.substring(13, 15);

      //// 2.1. Set GMT / Zulu Time if necessary.
      if (str.length() == 16) {
         if (str.charAt(15) == 'Z') {
            cal.setTimeZone(TimeZone.getTimeZone("GMT"));
         }
      }

      // System.out.println(strYear);
      // System.out.println(strMonth);
      // System.out.println(strDay);
      // System.out.println(strHour);
      // System.out.println(strMinute);
      // System.out.println(strSecond);

      //// 3. Convert the values.
      int year   = Integer.parseInt(strYear);
      int month  = Integer.parseInt(strMonth) - 1;  // silly Java starts with 0
      int day    = Integer.parseInt(strDay);
      int hour   = Integer.parseInt(strHour);
      int minute = Integer.parseInt(strMinute);
      int second = Integer.parseInt(strSecond);

      //// 4. Do bounds checking.
      //// 4.1. Check the year.
      if (! ((0 <= year) && (year <= 9999))) {
         throw new IllegalArgumentException("Year value " + year 
               + " is out of range");
      }

      //// 4.2. Check the month.
      if (! ((0 <= month) && (month <= 11))) {
         throw new IllegalArgumentException("Month value " + month
               + " is out of range");
      }

      //// 4.3. Check the day.
      if (! ((1 <= day) && (day <= 31))) {
         throw new IllegalArgumentException("Day value " + day
               + " is out of range");
      }

      //// 4.4. Check the hour.
      if (! ((0 <= hour) && (hour <= 23))) {
         throw new IllegalArgumentException("Hour value " + hour
               + " is out of range");
      }

      //// 4.5. Check the minutes.
      if (! ((0 <= hour) && (hour <= 59))) {
         throw new IllegalArgumentException("Minute value " + minute
               + " is out of range");
      }

      //// 4.6. Check the seconds.
      if (! ((0 <= second) && (second <= 59))) {
         throw new IllegalArgumentException("Seconds value " + second
               + " is out of range");
      }

      //// 5. Set the values.
      cal.set(year, month, day, hour, minute, second);

      return (cal.getTime());

   } // of method

   //===   UTILITY METHODS   ===================================================
   //===========================================================================




   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) {
/*
      Date d = new Date();
      System.out.println(DateToISO(null));
      System.out.println(DateToISO(new Date()));

      System.out.println();
      System.out.println(ISOToDate("19960329T083000Z"));
      System.out.println(ISOToDate("19960401T235959Z"));

      System.out.println();
      System.out.println(ISOToDate("19960329T083000"));
      System.out.println(ISOToDate("19960401T235959"));
      System.out.println(ISOToDate("19960332Z235959"));  // exception
      System.out.println(ISOToDate("19960332T235959"));  // exception
*/
      System.out.println(DateLib.ISOToDate("19960101T000000"));
      System.out.println(DateLib.ISOToDate("19990101T000000"));

      System.out.println(
      DateLib.compareDate("19960101T000000", "19990101T000000"));  


   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
