package edu.berkeley.guir.damask.view;

import java.awt.Window;
import java.awt.geom.AffineTransform;
import java.io.*;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.xml.bind.JAXBException;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.command.ModifyGraphCommand;
import edu.berkeley.guir.damask.io.*;
import edu.berkeley.guir.damask.view.appdialogs.FileDialogUtils;
import edu.berkeley.guir.damask.view.appevent.*;
import edu.berkeley.guir.lib.io.FileLib;
import edu.berkeley.guir.lib.satin.command.Command;
import edu.berkeley.guir.lib.satin.command.LinearCommandQueue;
import edu.umd.cs.piccolo.PCanvas;

/** 
 * Represents a Damask document.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-21-2003 James Lin
 *                               Created GraphView.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-21-2003
 */
public class DamaskDocument {
   private static final Logger logger =
      Logger.getLogger(DamaskDocument.class.getName());
   
   private final InteractionGraph graph;
   private final List/*<DamaskCanvasGroup>*/ canvasGroups = new ArrayList();

   // Command queue that fires events when commands are executed
   private final VerboseCommandQueue cmdQueue = new VerboseCommandQueue();

   private final DocumentEventSource eventSource = new DocumentEventSource(); 

   private final int newDocNum;
   private File file = null;
   
   private int numModifications = 0;

   /**
    * Constructs a view of the specified interaction graph.
    */
   public DamaskDocument(final InteractionGraph graph, final int newDocNum) {
      this.graph = graph;
      this.file = null;
      this.newDocNum = newDocNum;
      init();
   }


   /**
    * Constructs a view of the interaction graph within the specified file.
    */
   public DamaskDocument(final File file) throws JAXBException {
      //final FileReader reader = new FileReader(newFile);
      graph = DamaskReader.open(file);
      this.file = file;
      this.newDocNum = -1;
      init();
   }

   private void init() {
      // Listen for command events from this canvas
      cmdQueue.addCommandListener(new CommandHandler());
      logger.info(this + " created");

      // HACK allows old files with voice to be read
//      for (Iterator i = graph.getDialogs(DeviceType.VOICE).iterator(); i.hasNext(); ) {
//         final Dialog d = (Dialog)i.next();
//         final List/*<Page>*/ pages = new ArrayList(d.getPages(DeviceType.VOICE)); 
//         for (ListIterator j = pages.listIterator(pages.size()); j.hasPrevious(); ) {
//            final Page p = (Page)j.previous();
//            final List/*<Control>*/ controls = new ArrayList(p.getRegion(Direction.CENTER).getControls());
//            if (controls.size() > 1) {
//               for (int k = 0, n = controls.size(); k < n; k++) {
//                  final Control control = (Control)controls.get(k);
//                  if (control.getVoicePromptBounds() != null) {
//                     Rectangle2D bounds =
//                        control.getVoicePromptBounds();
//                     bounds = GeomLib.transformRectangle(control.getTransform(DeviceType.VOICE), bounds);
//                     final double dy = 
//                        bounds.getMaxY() -
//                        d.getBounds(DeviceType.VOICE).getMaxY();
//                     if (dy > 0) {
//                        final AffineTransform newTransform =
//                           control.getTransform(DeviceType.VOICE);
//                        newTransform.translate(0, -dy);
//                        control.setTransform(DeviceType.VOICE, newTransform);
//                     }
//                  }
//                  Control nextControl = null;
//                  if (control instanceof Select || control instanceof TextInput) {
//                     nextControl =
//                        new Trigger(DeviceType.VOICE, new Content(DeviceType.VOICE, "OK"));
//                     d.addControlAfter(control, nextControl);
//                  }
//                  if (nextControl == null) {
//                     p.split(Arrays.asList(new Control[] {control}));
//                  }
//                  else {
//                     p.split(Arrays.asList(new Control[] {control, nextControl}));
//                  }
//                  System.out.println(control);
//                  System.out.println("   " + control.getBounds(DeviceType.VOICE));
//                  System.out.println("   " + control.getTransform(DeviceType.VOICE));
//                  System.out.println("   " + control.getVoicePromptText());
//                  System.out.println("      " + control.getVoicePromptBounds());
//                  System.out.println("   " + control.getVoiceResponseTextList());
//               }
//            }
//         }
//      }
   }

   /**
    * Returns the interaction graph that is the model for this object. 
    */
   public InteractionGraph getGraph() {
      return graph;
   }
   

   /**
    * Adds the specified listener to receive document events.
    */
   public synchronized void addDocumentListener(DocumentListener listener) {
      eventSource.addDocumentListener(listener);
   }


   /**
    * Removes the specified listener so that it no longer receives
    * document events.
    */
   public synchronized void removeDocumentListener(DocumentListener listener) {
      eventSource.removeDocumentListener(listener);
   }


   /**
    * Fires a canvasGroupAdded event.
    */
   protected void fireCanvasGroupAdded() {
      eventSource.fireCanvasGroupAdded(this);
   }


   /**
    * Fires a canvasGroupRemoved event.
    */
   protected void fireCanvasGroupRemoved() {
      eventSource.fireCanvasGroupRemoved(this);
   }


   /**
    * Fires a documentRenamed event.
    */
   protected void fireDocumentRenamed() {
      eventSource.fireDocumentRenamed(this);
   }


   /**
    * Fires a documentBusyStarted event.
    */
   protected void fireDocumentBusyStarted() {
      eventSource.fireDocumentBusyStarted(this);
   }


   /**
    * Fires a documentBusyStopped event.
    */
   protected void fireDocumentBusyStopped() {
      eventSource.fireDocumentBusyStopped(this);
   }


   /**
    * Fires a documentClosed event.
    */
   protected void fireDocumentClosed() {
      eventSource.fireDocumentClosed(this);
   }


   /**
    * Fires a documentModified event.
    */
   protected void fireDocumentModified() {
      eventSource.fireDocumentModified(this);
   }


   /**
    * Fires a documentCleaned event.
    */
   protected void fireDocumentCleaned() {
      eventSource.fireDocumentCleaned(this);
   }

   
   /**
    * Creates a new canvas group for this document. 
    */
   public DamaskCanvasGroup createCanvasGroup() {
      final DamaskCanvasGroup newGroup = new DamaskCanvasGroup();
      canvasGroups.add(newGroup);
      
      fireCanvasGroupAdded();
      return newGroup;
   }


   /**
    * Disassociates the specified canvas group from this document.
    * 
    * @return whether the canvas was removed 
    */
   public boolean removeCanvasGroup(final DamaskCanvasGroup group) {
      final boolean result = canvasGroups.remove(group); 
      fireCanvasGroupRemoved();
      return result;
   }
   
   
   /**
    * Returns the list of canvas groups associated with this document.
    */
   public List/*<DamaskCanvasGroup>*/ getCanvasGroups() {
      return Collections.unmodifiableList(canvasGroups);
   }
   
   
   /**
    * Returns the index of the specified canvas group, or -1 if the canvas
    * group doesn't contain this document.
    */
   public int getCanvasGroupIndex(final DamaskCanvasGroup canvasGroup) {
      return canvasGroups.indexOf(canvasGroup);
   }


   /**
    * Returns the windows that contain this document.
    */
   public Collection/*<Window>*/ getWindows() {
      final Set windows = new HashSet();
      for (Iterator i = canvasGroups.iterator(); i.hasNext(); ) {
         final DamaskCanvasGroup group = (DamaskCanvasGroup)i.next();
         
         for (Iterator j = group.getCanvases().iterator(); j.hasNext(); ) {
            final DamaskCanvas canvas = (DamaskCanvas)j.next();
            windows.add(SwingUtilities.windowForComponent(canvas));
         }
      }
      return windows;
   }


   /**
    * Returns the file name displayed on the title bar, which could be a
    * variant of "untitled" or "Document" if the file hasn't been saved.
    */
   public String getDisplayedFileName() {
      if (file == null) {
         final StringBuffer sb = new StringBuffer();
         if (DamaskAppUtils.isMac()) {
            sb.append("untitled"); 
            if (newDocNum > 1) {
               sb.append(" ");
               sb.append(newDocNum);
            }
         }
         else {
            sb.append("Document" + newDocNum);
         }
         return sb.toString();
      }
      else {
         return file.getName();
      }
   }


   /**
    * Saves this document.
    */
   private void save(final File newFile, final Window parentWindow) {
      try {
         final String newFilePath = newFile.getAbsolutePath();
         // Write to a temporary file.
         final File tempFile = new File(newFilePath + ".part");
         final FileWriter writer = new FileWriter(tempFile);
         DamaskWriter.save(getGraph(), (DamaskFrame)parentWindow, writer);
         writer.close();
         clearModified();
         
         // If the desired file already exists, back it up.
         if (newFile.exists()) {
            final long newFileModified = newFile.lastModified();
            final String dateStr =
               DamaskUtils.dateToISO(newFileModified).replace(':', '-');
            final String bakFileNameMain =
               FileLib.removeFileNameExtension(newFile.getAbsolutePath());
            final String bakFileNameExt =
               FileLib.getFileNameExtension(newFile.getAbsolutePath());
            newFile.renameTo(
               new File(bakFileNameMain + "-" + dateStr + "." + bakFileNameExt));
         }
         
         // Rename the temp file to the desired file name.
         tempFile.renameTo(new File(newFilePath));
         
         logger.info(this + " saved");
      }
      catch (Exception e) {
         JOptionPane.showMessageDialog(
            parentWindow,
            "There is a problem writing "
               + newFile
               + ".\n\n"
               + e.getMessage(),
            "Damask",
            JOptionPane.ERROR_MESSAGE);
         DamaskAppExceptionHandler.log(e);
      }
      
      fireDocumentBusyStopped();
   }


   /**
    * Saves this document.
    */
   private void exportVoiceXML(final File newFile, final Window parentWindow) {
      try {
         final String newFilePath = newFile.getAbsolutePath();
         // Write to a temporary file.
         final File tempFile = new File(newFilePath + ".part");
         final FileWriter writer = new FileWriter(tempFile);
         VoiceXMLWriter.save(getGraph(), writer);
         writer.close();
         clearModified();
         
         // If the desired file already exists, back it up.
         if (newFile.exists()) {
            final long newFileModified = newFile.lastModified();
            final String dateStr =
               DamaskUtils.dateToISO(newFileModified).replace(':', '-');
            final String bakFileNameMain =
               FileLib.removeFileNameExtension(newFile.getAbsolutePath());
            final String bakFileNameExt =
               FileLib.getFileNameExtension(newFile.getAbsolutePath());
            newFile.renameTo(
               new File(bakFileNameMain + "-" + dateStr + "." + bakFileNameExt));
         }
         
         // Rename the temp file to the desired file name.
         tempFile.renameTo(new File(newFilePath));
         
         logger.info(this + " saved");
      }
      catch (IOException e) {
         JOptionPane.showMessageDialog(
            parentWindow,
            "There is a problem writing "
               + newFile
               + ".\n\n"
               + e.getMessage(),
            "Damask",
            JOptionPane.ERROR_MESSAGE);
         DamaskAppExceptionHandler.log(e);
      }
      
      fireDocumentBusyStopped();
   }


   /**
    * Tries to save this document.
    * 
    * @return whether the document was saved
    */
   public boolean trySave(final Window parentWindow) {
      if (file == null) {
         return trySaveAs(parentWindow);
      }
      else {
         save(file, parentWindow);
         return true;
      }
   }


   /**
    * Tries to save this document with a new name.
    * 
    * @return whether the document was saved
    */
   public boolean trySaveAs(final Window parentWindow) {
      final File newFile = FileDialogUtils.showDamaskSaveDialog(parentWindow);
      if (newFile != null) {
         save(newFile, parentWindow);
         setFile(newFile);
         logger.info(this + ": new name");
         return true;
      }
      else {
         return false;
      }
   }


   /**
    * Tries to export this document as a VoiceXML file.
    * 
    * @return whether the document was saved
    */
   public boolean tryExportAsVoiceXML(final Window parentWindow) {
      final File newFile = FileDialogUtils.showExportVoiceXMLDialog(parentWindow);
      if (newFile != null) {
         exportVoiceXML(newFile, parentWindow);
         logger.info(this + ": export as VoiceXML");
         return true;
      }
      else {
         return false;
      }
   }


   /**
    * Tries to close this document, prompting if it hasn't been saved.
    * 
    * @return true if the document is closed 
    */
   public boolean tryClose(Window parentWindow) {
      boolean isClosing;
      if (isModified()) {
         if (parentWindow == null) {
            // Pick any canvas that the document is in
            final DamaskCanvas firstCanvas =
               ((DamaskCanvasGroup)canvasGroups.get(0)).getCanvas(
                  DeviceType.DESKTOP);
            parentWindow = SwingUtilities.windowForComponent(firstCanvas);
         }
         
         final int result =
            FileDialogUtils.promptToSave(parentWindow, getDisplayedFileName());
            
         if (result == JOptionPane.YES_OPTION) {
            isClosing = trySave(parentWindow);
         }
         else if (result == JOptionPane.NO_OPTION) {
            isClosing = true;
         }
         else {
            isClosing = false;
         }
      }
      else {
         isClosing = true;
      }
      
      if (isClosing) {
         logger.info(this + " closed");
         fireDocumentClosed();
         return true;
      }
      else {
         return false;
      }
   }


   /**
    * Returns whether the design that this canvas holds has been modified.
    */
   public boolean isModified() {
      return numModifications != 0;
   }


   private void fireDocumentModifiedOrCleaned(
      int oldNumModifications,
      int newNumModifications) {

      if (oldNumModifications == 0) {
         fireDocumentModified();
      }
      else if ((oldNumModifications != 0) && (newNumModifications == 0)) {
         fireDocumentCleaned();
      }
   }

   /**
    * Increments the number of modifying commands in this graph view.
    */
   protected void incrModified() {
      int oldNumModifications = numModifications;
      numModifications++;
      fireDocumentModifiedOrCleaned(oldNumModifications, numModifications);
   }


   /**
    * Decrements the number of modifying commands in this graph view.  
    */
   protected void decrModified() {
      int oldNumModifications = numModifications;
      numModifications--;
      fireDocumentModifiedOrCleaned(oldNumModifications, numModifications);
   }
   
   
   /**
    * Sets the number of modifying commands in this graph view to 0.
    *
    */
   protected void clearModified() {
      numModifications = 0;
      fireDocumentCleaned();
   }
   
   
   /**
    * Returns the file associated with this graph view. 
    */
   public File getFile() {
      return file;
   }
   
   
   /**
    * Sets the file associated with this graph view. Fires a DocumentRenamed
    * event. 
    */
   protected void setFile(final File file) {
      this.file = file;
      fireDocumentRenamed();
   }

   
   // @Override
   public String toString() {
      return DamaskUtils.toShortString(this) + " (" + getDisplayedFileName() + ")";
   }

   
   // Command queue methods ----------------------------------------------

   /**
    * Returns the command queue for this canvas.
    */
   public VerboseCommandQueue getCommandQueue() {
      return cmdQueue;
   }

   
   /**
    * A command queue that fires events whenever a command is executed.  
    */
   public static class VerboseCommandQueue extends LinearCommandQueue {
      private CommandEventSource commandEventSource = new CommandEventSource();
      private Map/*<Command, PCanvas>*/ canvasForCommand =
         new HashMap/*<Command, PCanvas>*/();
      private Map/*<Command, AffineTransform>*/ cameraTransformForCommand =
         new HashMap/*<Command, AffineTransform>*/();
      private static Logger logger =
         Logger.getLogger(VerboseCommandQueue.class.getName());
      
      /**
       * Adds the specified command listener to receive command events from
       * this canvas.
       */
      public void addCommandListener(final CommandListener listener) {
         commandEventSource.addCommandListener(listener);
      }

      /**
       * Removes the specified command listener so that it no longer receives
       * command events from this canvas.
       */
      public void removeCommandListener(final CommandListener listener) {
         commandEventSource.removeCommandListener(listener);
      }

      // Overrides method in superclass.
      public synchronized void doCommand(
         final PCanvas canvas, final Command cmd) {
         
         super.doCommand(cmd);

         logger.info("Command done: " + cmd.getPresentationName());

         final AffineTransform canvasTransform =
            canvas == null ? null : canvas.getCamera().getViewTransform();

         canvasForCommand.put(cmd, canvas);
         cameraTransformForCommand.put(cmd, canvasTransform);
         commandEventSource.fireCommandExecuted(this,
                                                cmd,
                                                canvas,
                                                canvasTransform);
      }

      // Overrides method in superclass.
      public synchronized void doCommand(final Command cmd) {
         doCommand(null, cmd);
      }

      // Overrides
      public synchronized void undo() throws CannotUndoException {
         final Command edit = (Command)editToBeUndone();
         super.undo();
         logger.info("Command undone: " + edit.getPresentationName());
         commandEventSource.fireCommandUndone(
            this,
            edit,
            (PCanvas)canvasForCommand.get(edit),
            (AffineTransform) cameraTransformForCommand.get(edit));
      }

      // Overrides
      public synchronized void redo() throws CannotRedoException {
         final Command edit = (Command)editToBeRedone();
         super.redo();
         logger.info("Command redone: " + edit.getPresentationName());
         commandEventSource.fireCommandRedone(
            this,
            edit,
            (PCanvas)canvasForCommand.get(edit),
            (AffineTransform) cameraTransformForCommand.get(edit));
      }
   }


   /**
    * Listens for command events. 
    */
   private class CommandHandler implements CommandListener {
      private void update(final CommandEvent e, final int deltaModified) {
         if (e.getCommand() instanceof ModifyGraphCommand) {
            if (deltaModified == 1) {
               incrModified();
            }
            else if (deltaModified == -1) {
               decrModified();
            }
         }
      }
      
      public void commandExecuted(CommandEvent e) {
         update(e, +1);
      }

      public void commandUndone(CommandEvent e) {
         update(e, -1);
      }

      public void commandRedone(CommandEvent e) {
         update(e, +1);
      }
   }


   /**
    * A group of canvases, one for each device type for this document.
    */ 
   public class DamaskCanvasGroup {
      private Map/*<DeviceType, DamaskCanvas>*/ canvases = new HashMap();

      /**
       * Constructs a canvas group. 
       */
      private DamaskCanvasGroup() {
         for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
            i.hasNext();
            ) {

            final DeviceType deviceType = (DeviceType)i.next();
            
            canvases.put(
               deviceType,
               DamaskCanvas.create(this, deviceType));
         }
      }
      
      
      /**
       * Returns the canvas for the specified device type. 
       */
      public DamaskCanvas getCanvas(final DeviceType deviceType) {
         return (DamaskCanvas)canvases.get(deviceType);
      }
      
      
      /**
       * Returns all of the canvases. 
       */
      public Collection/*<DamaskCanvas>*/ getCanvases() {
         return canvases.values();
      }
      
      
      /**
       * Returns the document that contains this group of canvases.
       */
      public DamaskDocument getDocument() {
         return DamaskDocument.this;
      }
   }
}
