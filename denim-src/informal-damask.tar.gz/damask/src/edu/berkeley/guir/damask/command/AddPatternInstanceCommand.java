package edu.berkeley.guir.damask.command;

import java.awt.geom.Point2D;
import java.util.*;

import edu.berkeley.guir.damask.InteractionGraph;
import edu.berkeley.guir.damask.InteractionSubgraph;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.pattern.Pattern;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that creates a template within a graph.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  05-27-2004 James Lin
 *                               Created AddTemplateCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 05-27-2004
 */
public class AddPatternInstanceCommand
   extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final InteractionGraph graph;
   private final Pattern pattern;
   private final Page mergePatternPage;
   private final Point2D mergePt;
   private final Page mergeGraphPage;
   private InteractionSubgraph instanceSubgraph;
   private final Set/*<Component>*/ newComponents = new HashSet/*<Component>*/();

   /**
    * Constructs the command.
    *  
    * @param graph the interaction graph that the template should be added to
    * @param mergePatternPage the page in the pattern to merge
    * @param mergePt the page in the pattern to merge
    */      
   public AddPatternInstanceCommand(
      final InteractionGraph graph,
      final Pattern pattern,
      final Page mergePatternPage,
      final Point2D mergePt) {

      this.graph = graph;
      this.pattern = pattern;
      this.mergePatternPage = mergePatternPage;
      this.mergePt = mergePt;
      this.mergeGraphPage = null;
   }

   /**
    * Constructs the command.
    *  
    * @param graph the interaction graph that the template should be added to
    * @param mergePatternPage the page in the pattern to merge
    * @param mergePt the page in the pattern to merge
    */      
   public AddPatternInstanceCommand(
      final InteractionGraph graph,
      final Pattern pattern,
      final Page mergePatternPage,
      final Page mergeGraphPage) {

      this.graph = graph;
      this.pattern = pattern;
      this.mergePatternPage = mergePatternPage;
      this.mergePt = null;
      this.mergeGraphPage = mergeGraphPage;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Add instance of pattern " + pattern + " to " +
         graph + ", merging " + mergePatternPage + " with " +
         mergeGraphPage + " at " + mergePt;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      instanceSubgraph = graph.mergePatternInstance(
         pattern, mergePatternPage, mergePt, mergeGraphPage, newComponents);
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      for (Iterator i = instanceSubgraph.getPatternInstances().iterator();
           i.hasNext(); ) {
         final PatternInstance instance = (PatternInstance)i.next();
         graph.remove(instance);
         instance.dispose();
      }
      
      for (Iterator i = instanceSubgraph.getConnections().iterator();
           i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         graph.remove(connection);
         connection.dispose();
      }
      
      for (Iterator i = newComponents.iterator(); i.hasNext(); ) {
         final Component component = (Component)i.next();
         final Dialog dialog = component.getDialog();
         if (dialog != null) {
            if (component instanceof ComponentGroup) {
               dialog.removeGroup((ComponentGroup)component);
            }
            else {
               dialog.removeControl((Control)component);
            }
         }
         component.dispose();
      }
      
      for (Iterator i = instanceSubgraph.getDialogs().iterator();
           i.hasNext(); ) {
         final Dialog dialog = (Dialog)i.next();
         graph.remove(dialog);
         dialog.dispose();
      }
   }
}
