package edu.berkeley.guir.denim.components;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import javax.swing.SwingUtilities;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

/**
 * An instance of a check box in a DENIM design. This is a built-in
 * component.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-26-2003  James Lin
 *                                Created DenimCheckBoxInstance
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 02-26-2003
 */

public class DenimCheckBoxInstance
   extends DenimIntrinsicComponentInstance
   implements CaptionedGraphicalObject {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   private static int GAP = 8;

   //===   CONSTANTS   =========================================================
   //===========================================================================

   //===========================================================================
   //===   FIELDS   ============================================================

   private TimedStroke checkBoxBorder;
   private Patch selectedBox; 
   private Patch checkedBox; // checked
   private DenimText caption;
   private boolean state;
   private boolean createdByStamp;
   
   
   //===   FIELDS   ============================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates an instance of a DENIM check box. Called only by
    * DenimCheckBox.newInstance().
    *
    * @param type an instance of DenimCheckBox
    */
   DenimCheckBoxInstance(DenimComponent type) {
      super(type);

      assert (type instanceof DenimCheckBox):
         "DenimCheckBoxInstance can only be created by DenimCheckBox";

      Style style = this.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      this.setStyle(style);

      this.setBoundingPoints2D(COORD_LOCAL,
                               new Rectangle2D.Double(0, 0, 100, 30));

      displayedState = new PatchImpl(new Rectangle2D.Double(0, 0, 100, 30));
      
      // igore strokes
      this.setIgnoreStrokes(true);
      ((PatchImpl)displayedState).setIgnoreStrokes(true);

      
      style = displayedState.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      style.setLineWidth(1.0f);
      displayedState.setStyle(style);

      // Make border
      checkBoxBorder = new TimedStroke(new Rectangle2D.Double(0, 7.5, 15, 15));
      style = checkBoxBorder.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setLineWidth(1.0f);
      checkBoxBorder.setStyle(style);
      ((Patch)displayedState).add(checkBoxBorder, KEEP_REL_POS);

      // Make "selected box", which is a gray box that appears while the user
      // is clicking on the check box
      selectedBox = new PatchImpl(checkBoxBorder);
      style = selectedBox.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setFillColor(new Color(0, 0, 0, 50));
      style.setLineWidth(1.0f);
      selectedBox.setStyle(style);

      // Make a checked box
      checkedBox = new PatchImpl(checkBoxBorder);
      TimedStroke ts1 = new TimedStroke(new Line2D.Double(0, 0, 15, 15));
      TimedStroke ts2 = new TimedStroke(new Line2D.Double(15, 0, 0, 15));

      style = checkedBox.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      style.setLineWidth(1.0f);
      checkedBox.setStyle(style);

      style = ts1.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setLineWidth(1.0f);
      ts1.setStyle(style);
      ts2.setStyle(style);

      checkedBox.add(ts1, KEEP_REL_POS);
      checkedBox.add(ts2, KEEP_REL_POS);

	  state = false;
      createdByStamp = true;

      // Make squiggle caption
      setCaption(DenimIntrinsicComponent.createSquiggle());

      this.add(displayedState, KEEP_REL_POS);
   }

   //-----------------------------------------------------------------

   /**
    * Creates an instance of a DENIM check box, which will look like the given
    * border and have the given caption. Assumes that the given border and
    * caption have the same parent in the scenegraph.
    *
    * Called only by DenimCheckBox.newInstance().
    *
    * @param border the border of the check box
    * @param caption a collection of objects that make up the caption of
    *                the check box
    */
   DenimCheckBoxInstance(DenimComponent type,
                         TimedStroke newBorder,
                         DenimText newCaption) {
      super(type);

      this.checkBoxBorder = (TimedStroke)newBorder.deepClone();
      ((Patch)displayedState).add(checkBoxBorder, KEEP_ABS_POS);
      

      assert (type instanceof DenimCheckBox):
         "DenimCheckBoxInstance can only be created by DenimCheckBox";

      // Set bounding box to be union of the bounding boxes of border
      // and caption
      Rectangle2D newBounds = new Rectangle2D.Double();
      Rectangle2D.union(newBorder.getBounds2D(COORD_REL),
                        newCaption.getBounds2D(COORD_REL),
                        newBounds);
      this.setBoundingPoints2D(COORD_LOCAL,
                               new Rectangle2D.Double(0, 0,
                                                      newBounds.getWidth(),
                                                      newBounds.getHeight()));
      displayedState = new PatchImpl(newBounds);
      // igore strokes
      this.setIgnoreStrokes(true);
      ((PatchImpl)displayedState).setIgnoreStrokes(true);
      
      // Temporarily add the check box
      newBorder.getParentGroup().add(displayedState, KEEP_REL_POS);

      this.caption = (DenimText)newCaption.deepClone();
      ((Patch)displayedState).add(this.caption);

      // Change each object's transform so that its coordinates stay
      // the same
      AffineTransform newTx = displayedState.getInverseTransform(COORD_ABS);
      newTx.concatenate(newCaption.getTransform(COORD_ABS));
      this.caption.setTransform(newTx);

      this.add(displayedState);

      displayedState.delete();


      // Make "selected box", which is a gray box that appears while the user
      // is clicking on the check box
      selectedBox = new PatchImpl(checkBoxBorder);
      Style style = selectedBox.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setFillColor(new Color(0, 0, 0, 50));
      style.setLineWidth(1.0f);
      selectedBox.setStyle(style);

      // Make a checked box
      Rectangle2D bounds = checkBoxBorder.getBounds2D(COORD_LOCAL);
      checkedBox = new PatchImpl(bounds);

      TimedStroke ts1 =
         new TimedStroke(new Line2D.Double(bounds.getMinX(), bounds.getMinY(),
                                           bounds.getMaxX(), bounds.getMaxY()));
      TimedStroke ts2 =
         new TimedStroke(new Line2D.Double(bounds.getMaxX(), bounds.getMinY(),
                                           bounds.getMinX(), bounds.getMaxY()));

      style = checkedBox.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      style.setLineWidth(1.0f);
      checkedBox.setStyle(style);

      style = ts1.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setLineWidth(1.0f);
      ts1.setStyle(style);
      ts2.setStyle(style);

      checkedBox.add(ts1, KEEP_REL_POS);
      checkedBox.add(ts2, KEEP_REL_POS);

      createdByStamp = false;
   }

   //-----------------------------------------------------------------

   DenimCheckBoxInstance(DenimComponent type,
                         Rectangle2D bounds,
                         boolean selected, // false: is not selected, true: selected
                         TimedStroke checkBoxBorder,
                         DenimText caption,
                         boolean createdByStamp) {
      super(type);

      this.setBoundingPoints2D(COORD_LOCAL, bounds);
	  state = selected;
      this.checkBoxBorder = checkBoxBorder;
      this.caption = caption;
      this.createdByStamp = createdByStamp;

      displayedState = new PatchImpl(bounds);

      // igore strokes
      this.setIgnoreStrokes(true);
      ((PatchImpl)displayedState).setIgnoreStrokes(true);

      Style style = displayedState.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      style.setLineWidth(1.0f);
      displayedState.setStyle(style);

      // Make border
      style = checkBoxBorder.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setLineWidth(1.0f);
      checkBoxBorder.setStyle(style);
      ((Patch)displayedState).add(checkBoxBorder, KEEP_REL_POS);

      // Make a checked box
      /*
      Rectangle2D boxBounds = checkBoxBorder.getBounds2D(COORD_LOCAL);
      checkedBox = new PatchImpl(boxBounds);

      TimedStroke ts1 =
         new TimedStroke(new Line2D.Double(boxBounds.getMinX(),
                                           boxBounds.getMinY(),
                                           boxBounds.getMaxX(),
                                           boxBounds.getMaxY()));
      TimedStroke ts2 =
         new TimedStroke(new Line2D.Double(boxBounds.getMaxX(),
                                           boxBounds.getMinY(),
                                           boxBounds.getMinX(),
                                           boxBounds.getMaxY()));

      style = checkedBox.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      style.setLineWidth(1.0f);
      checkedBox.setStyle(style);

      style = ts1.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setLineWidth(1.0f);
      ts1.setStyle(style);
      ts2.setStyle(style);

      checkedBox.add(ts1, KEEP_REL_POS);
      checkedBox.add(ts2, KEEP_REL_POS);
      */
      
      // Make a checked box
      checkedBox = new PatchImpl(checkBoxBorder);
      TimedStroke ts1 = new TimedStroke(new Line2D.Double(0, 0, 15, 15));
      TimedStroke ts2 = new TimedStroke(new Line2D.Double(15, 0, 0, 15));

      style = checkedBox.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      style.setLineWidth(1.0f);
      checkedBox.setStyle(style);

      style = ts1.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setLineWidth(1.0f);
      ts1.setStyle(style);
      ts2.setStyle(style);

      checkedBox.add(ts1, KEEP_REL_POS);
      checkedBox.add(ts2, KEEP_REL_POS);

      // Make selected box, for when the check box is being clicked
      selectedBox = new PatchImpl(checkBoxBorder);
      style = selectedBox.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setFillColor(new Color(0, 0, 0, 50));
      style.setLineWidth(1.0f);
      selectedBox.setStyle(style);

      // Make caption
      ((Patch)displayedState).add(caption, KEEP_REL_POS);

      this.add(displayedState, KEEP_REL_POS);
      
      this.setSelected(selected);
   }
   

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================


   //===========================================================================
   //===   CHECK BOX METHODS   =================================================

   /**
    * Returns whether this check box is selected (checked) or not.
    */
   public boolean getSelected() {
      return state;
   }

	
   //-----------------------------------------------------------------

   /**
    * Sets whether this check box is selected (checked) or not.
    */
   public void setSelected(boolean flag) {
      state = flag;
      if (state) {
         this.add(checkedBox);
      }
      else {
         checkedBox.delete();
      }
      this.damage(DAMAGE_NOW);
   }

   //-----------------------------------------------------------------

   /**
    * Returns whether this check box was created by a stamp (as opposed
    * to sketched).
    */
   public boolean isCreatedByStamp() {
      return createdByStamp;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the border of the check box itself.
    */
   public TimedStroke getButtonBorder() {
      return checkBoxBorder;
   }

   //===   CHECK BOX METHODS   =================================================
   //===========================================================================


   //===========================================================================
   //===   CAPTION METHODS   ===================================================

   public DenimText getCaption() {
      return caption;
   }

   //-----------------------------------------------------------------

   public void setCaption(DenimText newCaption) {
      //// 1. Erase the old caption.
      if (caption != null) {
         caption.delete();
      }

      //// 2. Add the new caption.
      caption = newCaption;
      ((Patch)displayedState).add(caption);//, GraphicalObjectGroup.KEEP_REL_POS);

      //// 3. Move the caption so that it is GAP away from the check box
      ////    and that the check box is vertically centered with the caption.
      Rectangle2D borderBds = checkBoxBorder.getBounds2D(COORD_REL);
      Rectangle2D captionBds = caption.getBounds2D(COORD_REL);
      caption.moveTo(COORD_REL,
                     borderBds.getMaxX() + GAP,
                     (borderBds.getHeight() - captionBds.getHeight()) / 2 +
                      borderBds.getMinY());

      //// 4. Calculate union of bounding boxes of the check box and caption
      ////    in relative coordinates (which are the same as the local
      ////    coordinates of this component).
      double oldHeight = this.getBounds2D(COORD_LOCAL).getHeight();
      Rectangle2D newLocalBds = new Rectangle2D.Double();
      Rectangle2D.union(borderBds,
                        caption.getBounds2D(COORD_REL),
                        newLocalBds);

      //// 5. Change the local bounds of this component to the height and width
      ////    of the rectangle calculated in step 4.
      this.setBoundingPoints2D(COORD_LOCAL,
                               new Rectangle2D.Double(0, 0,
                                                      newLocalBds.getWidth(),
                                                      newLocalBds.getHeight()));
      double newHeight = this.getBounds2D(COORD_LOCAL).getHeight();

      displayedState.setBoundingPoints2D(COORD_LOCAL,
                                         this.getBounds2D(COORD_LOCAL));

      //// 6. Move the check box so that it's centered vertically.
      double dy = (newHeight - oldHeight) / 2;
      checkBoxBorder.moveBy(COORD_REL, 0, dy);
      selectedBox.moveBy(COORD_REL, 0, dy);
      checkedBox.moveBy(COORD_REL, 0, dy);

      //// 7. Make sure the caption is centered vertically.
      caption.moveTo(COORD_REL,
                     caption.getBounds2D(COORD_REL).getMinX(),
                     (newHeight -
                      caption.getHeight2D(COORD_REL)) / 2);

      //// 8. If this component already has a parent, then move the component
      ////    so that the check box does not move on the screen.
      if (this.getParentGroup() != null) {
         this.moveBy(COORD_REL,
                     0,
                     (oldHeight - newHeight) / 2 *
                      getTransform(COORD_REL).getScaleY());
      }
   }

   //===   CAPTION METHODS   ===================================================
   //===========================================================================


   //===========================================================================
   //===   COMPONENT METHODS   =================================================

   public void setTransparency(int transparency) {
   }

   //===   COMPONENT METHODS   =================================================
   //===========================================================================


   //==========================================================================
   //===   MOUSE HANDLING METHODS   ===========================================

   /**
    * Handles a mouse press. Intended for use during Run mode.
    */
   public void mousePressed(MouseEvent e) {
	  this.add(selectedBox);
      this.damage(DAMAGE_NOW);
   }

   //-----------------------------------------------------------------

   /**
    * Handles a mouse release. Intended for use during Run mode.
    */
   public void mouseReleased(MouseEvent e) {
      selectedBox.delete();
      setSelected(!getSelected());
   }

   //-----------------------------------------------------------------

   /**
    * Handles a mouse enter. Intended for use during Run mode.
    */
   public void mouseEntered(MouseEvent e) {
      if (SwingUtilities.isLeftMouseButton(e)) {
         this.add(selectedBox);
         this.damage(DAMAGE_NOW);
      }
   }

   //-----------------------------------------------------------------

   /**
    * Handles a mouse exit. Intended for use during Run mode.
    */
   public void mouseExited(MouseEvent e) {
      if (SwingUtilities.isLeftMouseButton(e)) {
         selectedBox.delete();
         this.damage(DAMAGE_NOW);
      }
   }

   //-----------------------------------------------------------------

   /**
    * Handles a mouse drag. Intended for use during Run mode.
    */
   public void mouseDragged(MouseEvent e) {
   }

   //===   MOUSE HANDLING METHODS   ===========================================
   //==========================================================================

   public void setStateIndex(int i) {
	  if(i==0)
	  {
	  	this.setSelected(false);
	  }
	  else
	  {
	  	this.setSelected(true); 
	  }
   }
   
   public int getStateIndex() {
	  if(this.state)
	  {
	  	return 1;
	  }
	  else 
	  {
	  	return 0;
	  }
   }


   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Returns a deep clone of this button instance.
    */
   public Object deepClone() {
      return deepClone(new DenimCheckBoxInstance(type));
   }

   //-----------------------------------------------------------------

   /**
    * 
    * X might be replicated in super.deepClone!!! 
    * 
    * Sets the clone parameter to a deep clone of this button instance,
    * and returns it.
    */
   public Object deepClone(DenimCheckBoxInstance clone) {
   	  if(state)
   	  {
   	  		this.disableDamage();
   	  	    this.setSelected(false);
   	  	    
			super.deepClone(clone);
	
			Patch cloneDisplayedState = (Patch)clone.displayedState;
	
			clone.checkBoxBorder =
			   (TimedStroke)cloneDisplayedState.get(
				  ((Patch)displayedState).indexOf(checkBoxBorder));
	
			clone.checkedBox = (Patch)checkedBox.deepClone();
			clone.selectedBox = (Patch)selectedBox.deepClone();
	      
			clone.caption =
			   (DenimText)cloneDisplayedState.get(
				  ((Patch)displayedState).indexOf(caption));
	
			clone.state = state;
			clone.createdByStamp = createdByStamp;
			clone.setSelected(true);
	      
	      	this.setSelected(true);
	      	this.enableDamage();
			return clone;
   	  }
   	  else
   	  {
	      super.deepClone(clone);
	
	      Patch cloneDisplayedState = (Patch)clone.displayedState;
	
	      clone.checkBoxBorder =
	         (TimedStroke)cloneDisplayedState.get(
	            ((Patch)displayedState).indexOf(checkBoxBorder));
	
	      clone.checkedBox = (Patch)checkedBox.deepClone();
	      clone.selectedBox = (Patch)selectedBox.deepClone();
	      
	      clone.caption =
	         (DenimText)cloneDisplayedState.get(
	            ((Patch)displayedState).indexOf(caption));
	
	      clone.state = state;
	      clone.createdByStamp = createdByStamp;
	      
	      return clone;
   	  }
   }

   public GraphicalObjectCollection getStates() {
	   return DenimCheckBox.mStateCollection;
   }
   //===   CLONE METHODS   =====================================================
   //===========================================================================
   
   public boolean isHTMLConvertible() {
       if(this.getCaption() instanceof TypedText)
           return true;
       else
           return false;
   }

} // of class

//==============================================================================

/*
Copyright (c) 1999-2003 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
