package edu.berkeley.guir.suede;

import java.awt.*;
import java.util.*;


public class GroupNodeModel extends AbstNodeModel implements Cloneable
{
	private AbstGroupNodeView m_node;
	private String m_groupname = "";
	private String m_label = "";
	private Vector componentList = new Vector();    
    
	private int m_centerX;
	private int m_centerY;
  
	//New contructor that uses feedback
	public GroupNodeModel(SContentPane pane, SuedeModel model, String label, SFeedbackGroup fbg){
		m_node = new GroupDefaultNodeView(model, this, fbg);
		if (fbg!=null) setBounds(fbg.getFBounds());
		setCenter((int)(fbg.getFinishX()-(fbg.getFinishX()-fbg.getStartX())/2), 
						 (int)(fbg.getFinishY()-(fbg.getFinishY()-fbg.getStartY())/2));
		init(model, label);
	}
	//end new constructor
    
	public GroupNodeModel(SContentPane pane, SuedeModel model, Point pt, String label) {
	  m_node = new GroupDefaultNodeView(model, this, label);
	  if (pt!=null) m_node.setCenter((int)(pt.getX()), (int)(pt.getY()));
	  init(model, label);
	}
    
	public void init(SuedeModel model, String label) {
		m_model = model;
		model.getContentPane().add(m_node, SContentPane.GROUP_LAYER);
		m_label = label;
		setGroupName("GROUP" + m_label);
	}
    
	public boolean isOperable(Point p) {
		return true;    
	}
    
	/*Collapses the view of a group node. 
	  Gesture up on a default view turns it into collapsed view.
	  Gesture up on an expanded view returns it to default view.
	  Gesture up on an already-collapsed view does nothing.
	*/
	public void collapse() {
	  String s = getGroupName();
	  SContentPane pane = m_model.getContentPane();
	  pane.remove(m_node);
  
	  if(m_node instanceof GroupDefaultNodeView){
		//System.out.println("default to collapse");
		m_node = new GroupCollapsedNodeView(m_model, this, s);
	  }
	  else if(m_node instanceof GroupExpandedNodeView) {
		//System.out.println("exp to default");
		m_node = new GroupDefaultNodeView(m_model, this, s); 
	  }
	  else {}
	   m_node.setLocation(m_locationX, m_locationY);
		pane.add(m_node, SContentPane.GROUP_LAYER);
	}
    
	/*Expands the view of a group node. 
	  Gesture down on a default view turns it into expanded view.
	  Gesture down on an already-expanded view does nothing.
	  Gesture down on a collapsed view returns it to default.
	*/
	public void expand() {
	  String s = getGroupName();
	  SContentPane pane = m_model.getContentPane();
	   pane.remove(m_node);
	  if(m_node instanceof GroupDefaultNodeView) {
		 //System.out.println("default to exp");
		m_node = new GroupExpandedNodeView(m_model, this, s);
       
	  }
	  else if (m_node instanceof GroupCollapsedNodeView) {
		 //System.out.println("coll to default");
		m_node = new GroupDefaultNodeView(m_model, this, s); 
	  }
	  else {}
	   m_node.setLocation(m_locationX, m_locationY);
		pane.add(m_node, SContentPane.GROUP_LAYER);
     
	}
    
	//constructs the default view of the group node
	public void consDefault() {
		 //System.out.println("constructing default");
	  String s = getGroupName();
	  SContentPane pane = m_model.getContentPane();
	  pane.remove(m_node);
	  m_node = new GroupDefaultNodeView(m_model, this, s);
	  m_node.setLocation(m_locationX, m_locationY);
	  pane.add(m_node, SContentPane.GROUP_LAYER);
	}
    
	public void resize() {
		((AbstGroupNodeView)m_node).resize();   
	}
    
	public Vector getComponents() {
		return componentList;   
	}
    
	public Point getLocationForComponent(AbstNodeView s) {
		return ((AbstGroupNodeView)getView()).getLocationForComponent(s);
	}
    
	public void setBounds(Rectangle r) {
		m_locationX = (int)(r.getX());
		m_locationY = (int)(r.getY());
		width = (int)(r.getWidth());
		height = (int)(r.getHeight());
		if (m_node!=null) m_node.setBounds(r);
	}
    
	public void setCenter(int x, int y) {
		m_centerX = x;
		m_centerY = y;
		m_node.setCenter(x, y);
	}
    
    
	public Rectangle getBounds() {
		return new Rectangle(m_locationX, m_locationY, width, height);   
	}
    
	public int getWidth() {
		return width;    
	}
    
	public int getHeight() {
		return height;
	}
    
	public AbstNodeView getView() {
		return m_node;
	}

	public String getGroupName() {
		m_groupname = getView().getName();
		return m_groupname;
	}

	public void  setGroupName(String lbl) {
		m_groupname = lbl;
		getView().setName(m_groupname);
	}
    
	public String getCaption() {
		return new String("No Caption for a Group");
	}

	public String getLabel() {        
		return m_label;
	}
    
	public void setLabel(String lbl) {
		m_label = lbl;
	}
    
   
	public Point getLocation() {
		return m_node.getLocation();  
	}
    
	public void addToGroup(AbstNodeModel s) {
		componentList.add(s);
		((AbstGroupNodeView)getView()).addToGroup(s);
	}
    
	public void removeFromGroup(AbstNodeModel s) {
		s.setGroupName("");
		componentList.removeElement(s);   
		((AbstGroupNodeView)getView()).removeFromGroup(s);
	}
    
	public String save(String path) {
	  return save(path, m_node.getName() + ".wav");      
	}
    
	public String save(String path, String externalFileName) {
      
		String r = "";
		r = r + "<group>";
    
		r = r + "<label>";
		r = r + getLabel();
		r = r + "</label>";
        
		r = r + "<ux>";
		r = r +  m_node.getX();
		r = r + "</ux>";

		r = r + "<uy>";
		r = r + m_node.getY();
		r = r + "</uy>";
        
		r = r + "<groupname>";
		r = r + getGroupName();
		r = r + "</groupname>";
        
        
		r = r + "</group>";
      
	  return r;
	}
    
    
	public void removeNode() {
	  java.awt.Container p = m_node.getParent();
	  SingleNodeModel temp;
	  //makes sure all single nodes inside the group gets cleared when the group is deleted.
	  //QUESTION: should we delete all nodes inside the group as well?
	  for(int i = 0; componentList.size()>=1;i++) {
		//System.out.println("called");
		temp = (SingleNodeModel)(componentList.get(0));
		temp.clearGroup();
		temp.setLocation(temp.getX(), temp.getY()+i*AbstSingleNodeView.DEFAULT_HEIGHT);
	  }
	  m_node.getParent().remove(m_node);   
	  m_node = null;
	  p.repaint();
	}
    
		 ///////////////Hongvan's code/////////////////////////
	 /**
   * Generate a copy of this GroupNodeModel.
   * @param - none
   * @return
   *   The return value is a copy of this sequence. Subsequent changes to the
   *   copy will not affect the original, nor vice versa. Note that the return
   *   value must be type cast to a <CODE>GroupNodeModel</CODE> before it can be used.
   **/
   public Object clone()
   {  // Clone a GroupNodeModel object.
	  GroupNodeModel answer;

	 // try
	  //{
		answer = (GroupNodeModel) super.clone( );
	 // }
	 /** catch (CloneNotSupportedException e)
	  {  // This exception should not occur. But if it does, it would probably
		 // indicate a programming error that made super.clone unavailable.
		 // The most common error would be forgetting the "Implements Cloneable"

		 // clause at the start of this class.
		 throw new RuntimeException
		 ("This class does not implement Cloneable");
	  }*/
	  //answer.m_node = (AbstGroupNodeView)m_node.clone();
	  answer.componentList = (Vector)componentList.clone();
	  return answer;
   }
//////////////////////////////////////////////////////////////////////
	//{{DECLARE_CONTROLS
	//}}
}