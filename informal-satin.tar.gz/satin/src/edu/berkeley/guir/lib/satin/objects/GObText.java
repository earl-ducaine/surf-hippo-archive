//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import edu.berkeley.guir.lib.util.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import java.awt.*;
import java.awt.geom.*;

/**
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jun 19 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class GObText
   extends GraphicalObjectImpl {

   //===========================================================================
   //===   CLASS METHODS AND VARIABLES   =======================================

   static final long serialVersionUID = -3108921581005924972L;

   //===   CLASS METHODS AND VARIABLES   =======================================
   //===========================================================================
   


   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   StringBuffer strbuf;               // the text that we draw
   int          numRows = 1;          // number of rows
   int          numCols = 1;          // number of cols
   int          heightChars;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public GObText() {
      strbuf = new StringBuffer();
   } // of default constructor

   //-----------------------------------------------------------------

   public GObText(String newStr) {
      set(newStr);
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   TEXT METHODS   ======================================================

   public void set(String newStr) {
      strbuf = new StringBuffer(newStr);
      calculateBounds();
      damage(DAMAGE_LATER, this);
   } // of set

   //-----------------------------------------------------------------

   public void append(String newStr) {
      strbuf.append(newStr);
      calculateBounds();
      damage(DAMAGE_LATER, this);
   } // of append

   //-----------------------------------------------------------------

   public void insert(String newStr, int pos) {
      strbuf.insert(pos, newStr);
      calculateBounds();
      damage(DAMAGE_LATER, this);
   } // of insert

   //-----------------------------------------------------------------

   /**
    * For example, if the text is "the elephantz", then calling 
    * replace("cat", 4, 12) will make it "the catz", and calling
    * replace("cat", 4, 13) will make it "the cat".
    *
    * @param newStr is the String to insert.
    * @param start  is the zero-based index to start replacing from (inclusive).
    * @param end    is the zero-based index to stop at (exclusive).
    */
   public void replace(String newStr, int start, int end) {
      String strFull     = strbuf.toString();
      String strLeading  = strFull.substring(0, start);
      String strTrailing = strFull.substring(end);
      strbuf = new StringBuffer(strLeading + newStr + strTrailing);
      calculateBounds();
      damage(DAMAGE_LATER, this);
   } // of replace

   //-----------------------------------------------------------------

   /**
    * Clears out the text.
    */
   public void clear() {
      strbuf = new StringBuffer();
      calculateBounds();
      damage(DAMAGE_LATER, this);
   } // of clear

   //===   TEXT METHODS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   TEXT LAYOUT METHODS   ===============================================

   /**
    * Get the number of rows in this text graphical object.
    *
    * @return the number of rows.
    */
   public int getNumRows() {
      return (numRows);
   } // of getNumRows

   //-----------------------------------------------------------------

   /**
    * Set the number of rows in this text graphical object.
    *
    * @param newNumRows is the number of rows to set to.
    */
   public void setNumRows(int newNumRows) {
      this.numRows = newNumRows;
      calculateBounds();
      damage(DAMAGE_LATER, this);
   } // of setNumRows

   //-----------------------------------------------------------------

   /**
    * Get the number of columns in this text graphical object.
    *
    * @return the number of columns.
    */
   public int getNumCols() {
      return (numCols);
   } // of getNumCols

   //-----------------------------------------------------------------

   /**
    * Set the number of columns in this text graphical object.
    *
    * @param newNumCols is the number of columns to set to.
    */
   public void setNumCols(int newNumCols) {
      this.numCols = newNumCols;
      calculateBounds();
      damage(DAMAGE_LATER, this);
   } // of setNumCols

   //===   TEXT LAYOUT METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   LOCATION METHODS   ==================================================

   /**
    * A quick way to get the current font metric.
    */
   private FontMetrics getFontMetrics() {
      Font            f       = getStyle().getDrawFont();
      Toolkit         tk      = Toolkit.getDefaultToolkit();
      FontMetrics     fmetric = tk.getFontMetrics(f);
      return (fmetric);
   } // of getFontMetrics

   //-----------------------------------------------------------------

   /**
    * Based on the font used and the number of rows and columns, calculate 
    * the bounds for this GraphicalObject!
    */
   private void calculateBounds() {
      FontMetrics     fmetric = getFontMetrics();
      String          str;
      int             width   = 0;
      int             height  = 0;

      //// 0. Fold the String on the number of columns we are supposed to have.
      str = StringLib.fold(strbuf.toString(), "\n", getNumCols());

      //// 1. Calculate the max width among each of the rows.
      width = GraphicsLib.calculateTotalWidth(str, fmetric);

      //// 2. Calculate the total height.
      height = GraphicsLib.calculateTotalHeight(str, fmetric);

      //// 3. Store the height of the font, so we can use it later when
      ////    rendering.
      heightChars = fmetric.getHeight();

      //// 4. Set the bounds.
      Rectangle bounds;
      bounds        = getBounds();
      bounds.width  = width;
      bounds.height = height;
      setBoundingPoints2D(COORD_REL, bounds);
   } // of calculateBounds

   //===   LOCATION METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   RENDERING METHODS   =================================================

   protected void defaultRender(SatinGraphics g) {
      //// 1. First, get the (x,y) Location of the top-left corner where
      ////    we should start drawing.
      Point2D pt = getLocation2D(COORD_REL);

      //// 2. Okay, drawString actually starts drawing using the specified
      ////    coordinates as the bottom-left corner. So, just add the
      ////    height of what a single line should be, and hopefully we'll
      ////    be okay.
      g.drawString(strbuf.toString(), 
                   (int) pt.getX(), (int) pt.getY() + heightChars);
   } // of defaultRender

   //===   RENDERING METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      GObText gob = new GObText();
      clone(gob);
      return (gob);
   } // of clone

   //-----------------------------------------------------------------

   /**
    * For clone chaining purposes.
    *
    * @see GraphicalObjectImpl#clone(GraphicalObjectImpl)
    */
   protected void clone(GObText gob) {
      //// 1. First call the superclass clone for clone chaining.
      super.clone(gob);

      //// 2. Now clone variables within this current class.
      gob.strbuf      = new StringBuffer(this.strbuf.toString());
      gob.numRows     = this.numRows;
      gob.numCols     = this.numCols;
      gob.heightChars = this.heightChars;
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toDebugString() {
      //// A. Acquire soft-state.
      StringBuffer strbufTmp = (StringBuffer) poolStrbuf.getObject();
     
      //// 1. Append data.
      strbufTmp.append(super.toDebugString() + "\n");
      strbufTmp.append("Text: " + strbuf.toString());

      //// B. Release soft-state.
      String str = strbufTmp.toString();
      poolStrbuf.releaseObject(strbufTmp);

      return (str);
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static void main(String[] argv) {
      GObText t = new GObText();

      t.append("elephantz");
      t.insert("the ", 0);
      System.out.println(t);

      t.replace("cat", 4, 12);
      System.out.println(t);

      t.clear();
      t.append("elephantz");
      t.insert("the ", 0);
      System.out.println(t);
      t.replace("cat", 4, 13);
      System.out.println(t);

   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
