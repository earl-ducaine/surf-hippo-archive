package edu.berkeley.guir.damask;

import java.util.*;

/**
 * An enumerated type describing orientations.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-19-2004 James Lin
 *                               Created Orientation.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 02-19-2004
 */
public class Orientation {
   private String name;

   public static final Orientation HORIZONTAL = new Orientation("Horizontal");
   public static final Orientation VERTICAL = new Orientation("Vertical");

   private static final Orientation[] PRIVATE_VALUES =
      { Orientation.HORIZONTAL, Orientation.VERTICAL };


   private Orientation(String name) {
      this.name = name;
   }


   public String toString() {
      return name;
   }

   
   /**
    * Returns a list of values for orientation.
    */
   public static final List getValues() {
      return Collections.unmodifiableList(
         Arrays.asList(Orientation.PRIVATE_VALUES));
   }
}
