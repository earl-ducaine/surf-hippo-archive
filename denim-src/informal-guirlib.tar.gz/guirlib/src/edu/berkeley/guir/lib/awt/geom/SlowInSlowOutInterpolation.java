//// See bottom of source code for software license
package edu.berkeley.guir.lib.awt.geom;

/**
 * SlowInSlowOut interpolate between two values. Essentially a sigmoid
 * function.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
public class SlowInSlowOutInterpolation 
   extends Interpolation {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   /**
    * Normalize the current/total value in interpolate() to be between 0.0 and 
    * this value here. This is an empirically determined value that makes the
    * sigmoid function spend less time in "dead" zones.
    */
   private static final double NORMALIZE = 10.0;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INTERPOLATION   =====================================================
/*
   public double 
   interpolate(double startValue, double endValue, int current, int total) {
      if (current >= total - 1) {
         return (endValue);
      }
      else {
         double scale = 1 / (1 + Math.exp(-current + (total - 1)/ 2.0));
         double dx    = scale * (endValue - startValue);
         return (startValue + dx);
      }
   } // of interpolate
*/


   public double 
   interpolate(double startValue, double endValue, int current, int total) {
      //// 1.1. Greater than end transition...
      if (current >= total - 1) {
         return (endValue);
      }
      //// 1.2. Less than start transition...
      else if (current < 0) {
         return (startValue);
      }
      //// 1.3. Normal case...
      else {
         //// 1.3.1. Normalize the x value to be between 
         ////        -NORMALIZE/2 and NORMALIZE/2 (empirical),
         ////        for use in the sigmoid function.
         double x     = current * NORMALIZE/total - NORMALIZE/2;
         double scale = 1 / (1 + Math.exp(-x));
         return (startValue + scale*(endValue - startValue));
      }
   } // of interpolate

   //===   INTERPOLATION   =====================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) {
      Interpolation interp = new SlowInSlowOutInterpolation();
      System.out.println(interp.interpolate(0, 1, 0, 10));
      System.out.println(interp.interpolate(0, 1, 1, 10));
      System.out.println(interp.interpolate(0, 1, 2, 10));
      System.out.println(interp.interpolate(0, 1, 3, 10));
      System.out.println(interp.interpolate(0, 1, 4, 10));
      System.out.println(interp.interpolate(0, 1, 5, 10));
      System.out.println(interp.interpolate(0, 1, 6, 10));
      System.out.println(interp.interpolate(0, 1, 7, 10));
      System.out.println(interp.interpolate(0, 1, 8, 10));
      System.out.println(interp.interpolate(0, 1, 9, 10));

      System.out.println();
      System.out.println(interp.interpolate(0, 1, 0,  20));
      System.out.println(interp.interpolate(0, 1, 1,  20));
      System.out.println(interp.interpolate(0, 1, 2,  20));
      System.out.println(interp.interpolate(0, 1, 3,  20));
      System.out.println(interp.interpolate(0, 1, 4,  20));
      System.out.println(interp.interpolate(0, 1, 5,  20));
      System.out.println(interp.interpolate(0, 1, 6,  20));
      System.out.println(interp.interpolate(0, 1, 7,  20));
      System.out.println(interp.interpolate(0, 1, 8,  20));
      System.out.println(interp.interpolate(0, 1, 9,  20));
      System.out.println(interp.interpolate(0, 1, 10, 20));
      System.out.println(interp.interpolate(0, 1, 11, 20));
      System.out.println(interp.interpolate(0, 1, 12, 20));
      System.out.println(interp.interpolate(0, 1, 13, 20));
      System.out.println(interp.interpolate(0, 1, 14, 20));
      System.out.println(interp.interpolate(0, 1, 15, 20));
      System.out.println(interp.interpolate(0, 1, 16, 20));
      System.out.println(interp.interpolate(0, 1, 17, 20));
      System.out.println(interp.interpolate(0, 1, 18, 20));
      System.out.println(interp.interpolate(0, 1, 19, 20));
   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
