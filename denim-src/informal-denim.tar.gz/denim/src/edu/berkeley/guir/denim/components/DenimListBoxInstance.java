package edu.berkeley.guir.denim.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.*;

import javax.swing.JPopupMenu;
import javax.swing.JTextArea;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.interpreters.DenimGestureInterpreter;
import edu.berkeley.guir.denim.interpreters.DenimScribbledTextInterpreter;
import edu.berkeley.guir.denim.interpreters.GroupInterpreter;
import edu.berkeley.guir.denim.interpreters.SemanticCircleSelectInterpreter;
import edu.berkeley.guir.lib.satin.interpreter.DefaultMultiInterpreterImpl;
import edu.berkeley.guir.lib.satin.interpreter.Interpreter;
import edu.berkeley.guir.lib.satin.interpreter.MultiInterpreter;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.objects.GraphicalObject;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollection;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollectionImpl;
import edu.berkeley.guir.lib.satin.objects.Patch;
import edu.berkeley.guir.lib.satin.objects.PatchImpl;
import edu.berkeley.guir.lib.satin.objects.Style;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;
import edu.berkeley.guir.lib.debugging.*;

/**
 * @author shen
 * 
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates. To enable and disable the creation of type
 * comments go to Window>Preferences>Java>Code Generation.
 */
public class DenimListBoxInstance extends DenimIntrinsicComponentInstance
        implements DenimListComponent {

    //===========================================================================
    //=== CONSTANTS =========================================================

    // the size of the list box instance
    private static final int DEFAULT_WIDTH = 180;

    private static final int DEFAULT_HEIGHT = 215;

    // the size of the scroll bar UP or DOWN arrow
    private static final int DEFAULT_ARROW_WIDTH = 10;

    private static final int DEFAULT_ARROW_HEIGHT = 5;

    private static final int DEFAULT_ARROW_X = 10;

    // the outlines of the list box instance
    private static final int MARGIN_X = 5;

    private static final int MARGIN_Y = 7;

    //=== CONSTANTS =========================================================
    //===========================================================================

    //===========================================================================
    //=== FIELDS ============================================================

    private TimedStroke border;

//    private GraphicalObjectCollection items;

//    private GraphicalObjectCollection indices;

    //private Patch inverse;
    private boolean createdByStamp;

    private int selectedIndex;

    private Patch selectedPatch;

    private GraphicalObject selectedItem;

    // For run mode
    private JPopupMenu menu;
    
    private ActionListener itemActionListener = new DenimListBoxItemActionListener();

    //=== FIELDS ============================================================
    //===========================================================================

    //===========================================================================
    //=== LISTENERS =========================================================

    class DenimListBoxItemActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ScribbledText selItem = (ScribbledText) e.getSource();
            int index = DenimListBoxInstance.this.indexOf(selItem);
            DenimListBoxInstance.this.setSelectedIndex(index);
            DenimListBoxInstance.this.damage(DAMAGE_LATER);
            //System.out.println(index);
        }
    }

    //=== LISTENERS =========================================================
    //===========================================================================

    //===========================================================================
    //=== CONSTRUCTORS ======================================================

    /**
     * Create an instance of a DENIM list box. Called only by DenimListBox.
     * newInstance().
     * 
     * @param type
     *            an instance of DenimListBox
     */
    DenimListBoxInstance(DenimComponent type) {
        super(type);
        TimedStroke newBorder;
        //TimedStroke newDownArrow;

        java.util.List listWindow = Denim.getWindows();
        Iterator it = listWindow.iterator();
        boolean found = false;
        Object obj = null;
        while (!found && it.hasNext()) {
            obj = it.next();
            if (obj instanceof DenimWindow) {
                found = true;
            }
        }

        if (!found) {
            System.exit(0);
        }

        DenimSheet sheet = ((DenimWindow) obj).getDenimUI().getSheet();
        double scaleFactor = sheet.getAbsScale();

        // change the size of sketch bounding box
        double width, height;
        if (Denim.getDeviceInfo().getName() == DeviceType.SMARTPHONE.getName()) {
            width = Denim.getDeviceInfo().getWidth() * scaleFactor;
            height = Denim.getDeviceInfo().getHeight() * scaleFactor;
        } else {
            width = 160 * scaleFactor; //80 * scaleFactor;
            height = 150 * scaleFactor;//215 * scaleFactor;
        }

        Rectangle2D boundingBox = new Rectangle2D.Double(0, 0, width, height);

        newBorder = new TimedStroke(boundingBox);

        newBorder.moveTo(COORD_REL, 0, 0);

        // Create items
        GraphicalObjectCollectionImpl items = new GraphicalObjectCollectionImpl();
        //indices = new GraphicalObjectCollectionImpl();

        int[] item1SquiggleLens = { 4, 3, 5 };
        int[] item2SquiggleLens = { 6, 7 };
        int[] item3SquiggleLens = { 3, 6, 5 };

        items.addToBack(DenimIntrinsicComponent
                .createSquiggles(item1SquiggleLens));
        items.addToBack(DenimIntrinsicComponent
                .createSquiggles(item2SquiggleLens));
        items.addToBack(DenimIntrinsicComponent
                .createSquiggles(item3SquiggleLens));

        init(type, newBorder, true, items, 0);
    }

    //-----------------------------------------------------------------

    /**
     * Create an instance of a DENIM list box, which will look like the given
     * objects. The list box will have the same relative coordinates as the
     * given border. Called only by DenimListBox.newInstance().
     * 
     * @param type
     *            an instance of DenimListBox
     * @param border
     *            the border of the list box. Its location will become the
     *            location of the list box.
     * @param items
     *            a collection of graphical objects, each of which represents an
     *            item in the combo box. The items should be in the order they
     *            will appear in the combo box. They should not already have a
     *            parent. The location of each object is ignored.
     */
    DenimListBoxInstance(DenimComponent type, TimedStroke border,
            GraphicalObjectCollection items) {
        this(type, border, false, items, 0);
    }

    //-----------------------------------------------------------------

    /**
     * Create an instance of a DENIM list box, which will look like the given
     * objects. The list box will have the same relative coordinates as the
     * given border. Called only by DenimListBox.newInstance().
     * 
     * @param type
     *            an instance of DenimListBox
     * @param border
     *            the border of the list box. Its location will become the
     *            location of the list box.
     * @param items
     *            a collection of graphical objects, each of which represents an
     *            item in the combo box. The items should be in the order they
     *            will appear in the list box. They should not already have a
     *            parent. The location of each object is ignored.
     */
    public DenimListBoxInstance(DenimComponent type, TimedStroke border,
            boolean createdByStamp, GraphicalObjectCollection items,
            int selectedIndex) {
        super(type);
        init(type, border, createdByStamp, items, selectedIndex);
    }

    //-----------------------------------------------------------------

    /**
     * Shelley Perform common initializations.
     */
    private void init(DenimComponent type, TimedStroke border,
            boolean createdByStamp, GraphicalObjectCollection items,
            int selectedIndex) {

        Debug.println("Init of DenimListBoxInstance");

        assert (type instanceof DenimListBox) : "DenimListBoxInstance can only be created by DenimListBox";

        this.border = border;
        this.createdByStamp = createdByStamp;
        //this.items = items;
        this.selectedItem = null;

        this.setBoundingPoints2D(COORD_LOCAL, border);
        this.setHasClosedBoundingPoints(true);

        Style style = this.getStyle();
        style.setDrawColor(new Color(0, 0, 0, 0));
        style.setFillColor(new Color(0, 0, 0, 0));
        this.setStyle(style);

        // displayedState is a protected variable in DenimComponentInstance.java
        displayedState = new PatchImpl(border);
        displayedState.setHasClosedBoundingPoints(true);

        // igore strokes
        this.setIgnoreStrokes(true);
        ((PatchImpl)displayedState).setIgnoreStrokes(true);
        
        // draw border line in black
        style = displayedState.getStyle();
        style.setDrawColor(Color.BLACK);
        style.setFillColor(Color.WHITE);
        style.setLineWidth(1.0f);
        displayedState.setStyle(style);
        
        //indices = new GraphicalObjectCollectionImpl();

        ///////////////////////////////////////
        
        /*
        for (int i = 1; i <= 9; i++) {
            TimedStroke digit = DenimIntrinsicComponent.createDenimDigit(i);
            Patch p = new PatchImpl(digit);
            p.setHasClosedBoundingPoints(false);

            Style s = p.getStyle();
            s.setDrawColor(Color.BLACK);
            s.setFillColor(Color.WHITE);
            s.setLineWidth(1.0f);
            p.setStyle(s);

            indices.addToBack(p);
        }
*/
        //---------------------------------------------------------------//

        selectedItem = items.get(0);
        ((Patch) displayedState).add(selectedItem);
        selectedItem.moveTo(COORD_REL, MARGIN_X + 50, MARGIN_Y + 20);

        //----------------------------------------------------------------//

        selectedItem = items.get(1);
        ((Patch) displayedState).add(selectedItem);
        selectedItem.moveTo(COORD_REL, MARGIN_X + 50, MARGIN_Y + 60);

        //----------------------------------------------------------------//

        selectedItem = items.get(2);
        ((Patch) displayedState).add(selectedItem);
        selectedItem.moveTo(COORD_REL, MARGIN_X + 50, MARGIN_Y + 100);

        ///////////////

        this.add(displayedState);
        //repaintNum();
        setupInterpreters();
    }

    //=== CONSTRUCTORS ======================================================
    //===========================================================================

    //===========================================================================
    //=== LIST BOX METHODS =================================================

    /**
     * Returns whether this list box was created by a stamp (as opposed to
     * sketched).
     */
    public boolean isCreatedByStamp() {
        return createdByStamp;
    }

    //-----------------------------------------------------------------

    /**
     * Returns the border of the list box.
     */
    public TimedStroke getBorder() {
        return border;
    }

    //-----------------------------------------------------------------

    /**
     * Shelley add a new Item at the bottom of the denim list box
     */
    public void addItem(ScribbledText newItem) {
        // add the new item to the back of items
       // items.addToBack(newItem);

        //bubblesort();

        //repaintNum();

        // get the current DenimWindow
        DenimWindow win = getDenimWindow();

        // get the current DenimSheet
        DenimSheet sheet = win.getDenimUI().getSheet();

        // damage the DenimSheet and have instantanious response
        sheet.damage(DAMAGE_NOW);

        return;
    }


    //---------------------------------------------------------------

    /**
     * Shelley This function returns the current DenimWindow
     * 
     * @return DenimWindow
     */
    public DenimWindow getDenimWindow() {
        // get a link list of windows
        java.util.List listWindow = Denim.getWindows();

        // iterate through all windows
        // the loops stops finding DenimWindow, which must be true
        Iterator it = listWindow.iterator();
        boolean found = false;
        Object obj = null;
        while (!found && it.hasNext()) {
            obj = it.next();
            if (obj instanceof DenimWindow) {
                found = true;
            }
        }

        if (!found) {
            return null;
        } else {
            return (DenimWindow) obj;
        }

    }

    //-----------------------------------------------------------------

    public GraphicalObjectCollection getItems() {
        return ((PatchImpl)this.displayedState).getGraphicalObjects();
    }

    //-----------------------------------------------------------------

    /**
     * Sets the items in this list box.
     */
  
    public void setItems(GraphicalObjectCollection items) {
        updateConditionMap(this.getItems(), items);
        //this.items = items;
        refresh(items);
    }

    private void updateConditionMap(GraphicalObjectCollection old,
            GraphicalObjectCollection newitems) {
        DenimPanel panel = this.getPanel();
        
        if(panel==null)
            return;
        
        Iterator it = panel.getConditionStates().getCols().iterator();
        while (it.hasNext()) {
            
            // get a column
            Object colHeader = it.next();
            
            // get the current state for the column
            GraphicalObject obj = (GraphicalObject) panel.getConditionStates()
                    .get(this, colHeader);
            
            // get the index of the state
            int index = old.indexOf(obj);
            
            if (index >= newitems.numElements()) {
                index = 0;
            }
            
            // update the state
            panel.getConditionStates()
                    .put(this, colHeader, newitems.get(index));
        }

    }

    //-----------------------------------------------------------------

    /**
     * Returns the items in this list box as an array of text strings. If the
     * list box contains a mixture of typed and handwritten items, then a empty
     * string will be placed in the array instead of a handwritten item.
     * 
     * If the list box only contains handwritten squiggles, then this method
     * returns an empty array.
     */
    public String[] getItemsAsText() {
        
        GraphicalObjectCollection items = this.getItems();
        
        String[] itemsAsText = new String[items.numElements()];
        boolean hasText = false;

        int i = 0;
        Iterator it = items.getForwardIterator();
        while (it.hasNext()) {
            Object obj = it.next();
            if (obj instanceof TypedText) {
                itemsAsText[i] = ((TypedText) obj).getText();
                hasText = true;
            } else {
                itemsAsText[i] = "";
            }
            i++;
        }

        if (!hasText) {
            return new String[0];
        } else {
            return itemsAsText;
        }
    }

    //-----------------------------------------------------------------

    /**
     * Sets the items in this list box, in the order specified by the string
     * array.
     */
    public void setItemsAsText(String[] newItems, Font f, Color c) {
        GraphicalObjectCollection newItemsCol =
           new GraphicalObjectCollectionImpl();
        for (int i = 0; i < newItems.length; i++) {
           JTextArea ta = new JTextArea(newItems[i]);
           //ta.setFont(new Font(fontName, Font.PLAIN, fontSize));//TypedText.getFont(TypedText.SMALL_FONT_SIZE));
           ta.setFont(f);
           ta.setForeground(c);
           TypedText txt = new TypedText(ta);
           newItemsCol.addToBack(txt);
        }
        setItems(newItemsCol);
     }

    public void refresh(GraphicalObjectCollection items) {

        this.disableDamage();

        this.displayedState.delete();

        displayedState = new PatchImpl(border);
        displayedState.setHasClosedBoundingPoints(true);

        // draw border line in black
        Style style = displayedState.getStyle();
        style.setDrawColor(Color.BLACK);
        style.setFillColor(Color.WHITE);
        style.setLineWidth(1.0f);
        displayedState.setStyle(style);

        this.add(displayedState);

        Iterator it = items.getForwardIterator();
        double y = 0;
        Rectangle2D box = null;
        int i =0;
        while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject) it.next();
            ((Patch) this.displayedState).add(i, gob);
            i++;
            gob.moveTo(COORD_REL, MARGIN_X, MARGIN_Y + y);
            //System.out.println(gob.getClass().toString());
            if(gob instanceof TypedText)
                ((TypedText) gob).getTextArea().setBackground(NO_COLOR);
            
            if (box == null) {
                box = (Rectangle2D) gob.getBounds2D(COORD_REL).clone();
            } else {
                Rectangle2D.union(box, gob.getBounds2D(COORD_REL), box);
            }
            y += 30;
        }

        border = new TimedStroke(new Rectangle2D.Double(0, 0, box.getMaxX()
                + box.getMinX(), box.getMaxY() + box.getMinY()));
        border.moveTo(COORD_REL, 0, 0);

        this.displayedState.setBoundingPoints2D(COORD_LOCAL, border);
        this.setBoundingPoints2D(COORD_LOCAL, border);

        this.enableDamage();
        setSelectedIndex(getSelectedIndex());
    }

    //-----------------------------------------------------------------

    /**
     * Returns the index of the selected item.
     */
    public int getSelectedIndex() {
        return selectedIndex;
    }

    //-----------------------------------------------------------------

    /**
     * Sets the index of the selected item.
     */
    public void setSelectedIndex(int newIndex) {
        if(selectedItem != null)
        {
            if (selectedItem instanceof TypedText) {
                ((TypedText) selectedItem).getTextArea().setBackground(NO_COLOR);
            } else {
                // do nothing
                ((ScribbledText)selectedItem).setFillPatch(false);
            }
        }
        
        GraphicalObjectCollection items = this.getItems();
        
        int size = items.numElements();

        if (newIndex < 0) {
            selectedIndex = 0;
        } else if (newIndex >= size) {
            selectedIndex = size - 1;
        }
        
        selectedIndex = newIndex;
        selectedItem = items.get(selectedIndex);
        if (selectedItem instanceof TypedText) {
            ((TypedText) selectedItem).getTextArea().setBackground(
                    Color.lightGray);
        } else {
            ((ScribbledText)selectedItem).getStyleRef().setFillColor(Color.lightGray);
            ((ScribbledText)selectedItem).setFillPatch(true);
        }

        if (this.getParentGroup() != null)
            this.getParentGroup().damage(DAMAGE_NOW);
    }

    /**
     * Sets up the interpreters for the sketch.
     */
    private void setupInterpreters() {
        //// Setup the gesture interpreter.
        //// Would it be better to use just one interpreter & share the
        //// reference between all the sketches?
        Interpreter intrp;
        MultiInterpreter gestureIm = new DefaultMultiInterpreterImpl();

        intrp = new SemanticCircleSelectInterpreter();
        intrp.setAcceptLeftButton(false);
        gestureIm.add(intrp);

        intrp = new DenimGestureInterpreter();
        intrp.setAcceptLeftButton(false);
        gestureIm.add(intrp);

        this.setGestureInterpreter(gestureIm);

        //// Setup the ink interpreter.
        MultiInterpreter inkIm = new DefaultMultiInterpreterImpl();

        //DenimUtils.setupToolInterpreters(inkIm);
        inkIm.add(new DenimScribbledTextInterpreter());
        inkIm.add(new GroupInterpreter());
        inkIm.setAcceptMiddleButton(false);
        inkIm.setAcceptRightButton(false);

        this.setInkInterpreter(inkIm);

        this.setAddRightButtonStrokes(false); // only allowed for sheets
        this.setAddMiddleButtonStrokes(false); // only allowed for sheets
    } // of method

    //-----------------------------------------------------------------

    //=== LIST BOX METHODS =================================================
    //===========================================================================

    //===========================================================================
    //=== COMPONENT METHODS =================================================

    public void setTransparency(int transparency) {
    }

    //=== COMPONENT METHODS =================================================
    //===========================================================================

    //===========================================================================
    //=== MOUSE HANDLING METHODS ============================================

    /**
     * Handles a mouse press. Intended for use during Run mode.
     */

    public void mousePressed(MouseEvent e) {
        Point2D pt = e.getPoint();
        Rectangle2D box = this.getBounds2D(COORD_ABS);
        if (box.contains(pt)) {
            int index = (int) ((this.getItems().numElements() * (pt.getY() - box
                    .getMinY())) / box.getHeight());
            this.setSelectedIndex(index);
        }
    }

    //===========================================================================
    //=== CLONE METHODS =====================================================
    /**
     * Returns a deep clone of this list box instance.
     */
    public Object deepClone() {
        return deepClone(new DenimListBoxInstance(type));
    }

    //-----------------------------------------------------------------

    /**
     * Sets the clone parameter to a deep clone of this list box instance, and
     * returns it.
     */
    public Object deepClone(DenimListBoxInstance clone) {
        super.deepClone(clone);

        clone.border = (TimedStroke) border.deepClone();

        clone.createdByStamp = createdByStamp;
        clone.selectedIndex = this.selectedIndex;
        clone.selectedItem = null;

        clone.setSelectedIndex(clone.selectedIndex);
        
        for(int i=0; i<clone.getStates().numElements(); i++)
        {
            ((GraphicalObject)clone.getStates().get(i)).setUniqueID(this.getStates().get(i).getUniqueID());
        }

        return clone;
    }

    //=== CLONE METHODS =====================================================
    //===========================================================================

    public void setStateIndex(int i) {
        this.setSelectedIndex(i);
    }

    public int getStateIndex() {
        return this.getSelectedIndex();
    }

    public GraphicalObjectCollection getStates() {
        //return this.items;
        return this.getItems();
    }
    
    //-----------------------------------------------------------------

    /**
     * Returns the index of the selected item.
     */
    public int getSelectedIndex(GraphicalObject value) {
        return this.getItems().indexOf(value);
    }


    public boolean isHTMLConvertible() {
        if (this.getItems().get(0) instanceof TypedText)
            return true;
        else
            return false;
    }

    public Color getPrintDraw() {
        return Color.black;
    }
    
    
    public Font getFont() {
        GraphicalObject obj = this.getItems().getFirst();
        if(obj instanceof TypedText)
        {
            return ((TypedText)obj).getTextArea().getFont();
        }
        else
        {
            return new Font("SansSerif", Font.PLAIN, 16);
        }
    }
    
    public Color getColor() {
        GraphicalObject obj = this.getItems().getFirst();
        if(obj instanceof TypedText)
        {
            Color c = ((TypedText)obj).getTextArea().getForeground();
            if(c==null)
         	   c = Color.black;
            return c;
        }
        else
        {
            return Color.black;
        }
    }
} // of class

