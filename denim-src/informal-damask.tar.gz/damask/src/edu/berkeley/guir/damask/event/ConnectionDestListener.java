package edu.berkeley.guir.damask.event;

import java.util.EventListener;

/** 
 * The listener interface for receiving events regarding a change in a
 * connection destination. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-19-2004 James Lin
 *                               Created ConnectionDestListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-19-2004
 */
public interface ConnectionDestListener extends EventListener {

   /**
    * Invoked when an incoming connection has been added to a control.
    */
   void inConnectionAdded(ConnectionDestEvent e);
   
   /**
    * Invoked when an incoming connection has been removed to a control.
    */
   void inConnectionRemoved(ConnectionDestEvent e);
}
