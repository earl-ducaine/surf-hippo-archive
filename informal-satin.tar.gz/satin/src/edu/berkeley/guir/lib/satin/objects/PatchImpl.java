//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.satin.image.*;

/**
 * A Graphical Object Group with boundaries, additional kinds of properties
 * and behavior.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 01 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class PatchImpl extends GraphicalObjectGroupImpl implements Patch
{

	//===========================================================================
	//===   CONSTANTS   =========================================================

	static final long serialVersionUID = 823824510587863981L;

	//-----------------------------------------------------------------

	/**
	 * The name of the file containing the current stroke properties.
	 */
	public static final String PATCH_STYLE_FILE = "Patch.properties";

    private boolean ignoreStrokes = false;
	//===   CONSTANTS   =========================================================
	//===========================================================================

	//===========================================================================
	//===   CLASS PROPERTIES   ==================================================

	static {
		//// 1. Class property initializations.
		clprops.setClassProperty(
			PatchImpl.class,
			STYLE_CLPROPERTY,
			new Style(PATCH_STYLE_FILE));
	} // of static init

	//-----------------------------------------------------------------

	//===   CLASS PROPERTIES   ==================================================
	//===========================================================================

	//===========================================================================
	//===   NONLOCAL VARIABLES   ================================================

	StrokeEventFilter addFilter; // what strokes to add
	boolean flagDrawPatch = true; // draw the patch border?
	boolean flagFillPatch = true; // fill in the patch?
	boolean flagDrawChildren = true; // draw children gobs?

	// External Cache Image of this Patch that will disable rendering to bufferedimage of Sheet
	protected BufferedImage externalCacheImage = null;

	//===   NONLOCAL VARIABLES   ================================================
	//===========================================================================

	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	public PatchImpl()
	{
		commonInitializations();
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Make a patch with the specified boundaries.
	 *
	 * @param stk represents the boundary of the Patch.
	 */
	public PatchImpl(TimedStroke stk)
	{
		//// 1. Don't have to normalize the polygon, since the 
		////    call to setBoundingPoints() will do that for us.
		this(stk.getBoundingPoints2D(COORD_LOCAL));
		applyTransform(stk.getTransformRef());
		commonInitializations();
	} // of constructor

    
    public void setIgnoreStrokes(boolean b) {
        ignoreStrokes = b;
    }
    
	//-----------------------------------------------------------------

	/**
	 * Make a patch with the specified boundaries.
	 *
	 * @param s is the shape boundary.
	 */
	public PatchImpl(Shape s)
	{
		this(GraphicalObjectLib.convert(s));
		commonInitializations();
	} // of constructor

	//-----------------------------------------------------------------

	public PatchImpl(Rectangle2D r)
	{
		setBoundingPoints2D(COORD_REL, r);
		commonInitializations();
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Make a patch with the specified boundaries.
	 *
	 * @param newpoly is the boundary.
	 */
	public PatchImpl(Polygon2D newPoly)
	{
		//// 1. Set the shape and the bounding points.
		////    This normalizes and clones the polygon for us.
		setBoundingPoints2D(COORD_REL, newPoly);

		commonInitializations();
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Make a patch with the specified boundaries.
	 *
	 * @param newpoly is the boundary.
	 */
	public PatchImpl(Polygon newPoly)
	{
		//// 1. Set the shape and the bounding points.
		////    This normalizes and clones the polygon for us.
		setBoundingPoints2D(COORD_REL, newPoly);

		commonInitializations();
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Common initializations.
	 */
	private void commonInitializations()
	{
		addFilter = new BasicStrokeEventFilter();
	}

	//===   CONSTRUCTORS   ======================================================
	//===========================================================================

	//===========================================================================
	//===   FILTERING METHODS   =================================================

	/**
	 * Set whether left-button strokes will be added.
	 */
	public void setAddLeftButtonStrokes(boolean flag)
	{
		addFilter.setAcceptLeftButton(flag);
	} // of setAddLeftButtonStrokes

	//-----------------------------------------------------------------

	/**
	 * Set whether middle-button strokes will be added.
	 */
	public void setAddMiddleButtonStrokes(boolean flag)
	{
		addFilter.setAcceptMiddleButton(flag);
	} // of setAddMiddleButtonStrokes

	//-----------------------------------------------------------------

	/**
	 * Set whether right-button strokes will be added.
	 */
	public void setAddRightButtonStrokes(boolean flag)
	{
		addFilter.setAcceptRightButton(flag);
	} // of setAddRightButtonStrokes

	//-----------------------------------------------------------------

	/**
	 * Returns whether left-button strokes are added.
	 */
	public boolean isAddLeftButtonStrokes()
	{
		return addFilter.isLeftButtonAccepted();
	} // of isAddLeftButtonStrokes

	//-----------------------------------------------------------------

	/**
	 * Returns whether middle-button strokes are added.
	 */
	public boolean isAddMiddleButtonStrokes()
	{
		return addFilter.isMiddleButtonAccepted();
	} // of isAddMiddleButtonStrokes

	//-----------------------------------------------------------------

	/**
	 * Returns whether right-button strokes are added.
	 */
	public boolean isAddRightButtonStrokes()
	{
		return addFilter.isRightButtonAccepted();
	} // of isAddRightButtonStrokes

	//===   FILTERING METHODS   =================================================
	//===========================================================================

	//===========================================================================
	//===   DISPATCHING METHODS   ===============================================

	public void handleSingleStroke(SingleStrokeEvent evt)
	{
		//// 1. Add it ourself.
		if (ignoreStrokes==false
                &&!evt.isConsumed() && addFilter.isEventAccepted(evt))
		{
			TimedStroke stk = evt.getStroke();
			InsertCommand cmd = new InsertCommand(this, stk);

			cmd.setAddPolicy(GraphicalObjectGroup.KEEP_ABS_POS);
			cmdqueue.doCommand(cmd);
			evt.setConsumed();
			evt.setShouldRender(false);
		}
	} // of handleSingleStroke

	//===   DISPATCHING METHODS   ===============================================
	//===========================================================================

	//===========================================================================
	//===   GRAPHICAL OBJECT SHAPE METHODS   ====================================

	protected boolean shapeContainsInternal(Point2D pt)
	{
		return (getLocalBoundingPoints2DRef().contains(pt));
	} // of method

	//-----------------------------------------------------------------

	protected boolean shapeContainsInternal(Shape s)
	{
		return (GraphicalObjectLib.contains(getLocalBoundingPoints2DRef(), s));
	} // of method

	//-----------------------------------------------------------------

	protected boolean shapeIntersectsInternal(Shape s)
	{
		return (
			GraphicalObjectLib.intersects(getLocalBoundingPoints2DRef(), s));
	} // of method

	//===   GRAPHICAL OBJECT SHAPE METHODS   ====================================
	//===========================================================================

	//===========================================================================
	//===   LOCATION METHODS   ==================================================

	/**
	 * This method is called by our parent class whenever a Graphical Object 
	 * is added or removed. We don't want to update our bounding points, since
	 * they are already determined, so just do nothing.
	 */
	protected void updateGroupBounds(GraphicalObject gob)
	{
		//// 1. Do nothing, our bounds are set by the polygon.
		return;
	} // of method

	//-----------------------------------------------------------------

	/**
	 * This method is called by our parent class whenever a Graphical Object 
	 * is added or removed. We don't want to update our bounding points, since
	 * they are already determined, so just do nothing.
	 */
	protected void updateGroupBounds()
	{
		//// 1. Do nothing, our bounds are set by the polygon.
		return;
	} // of method

	//===   LOCATION METHODS   ==================================================
	//===========================================================================

	//===========================================================================
	//===   WATCH METHODS   =====================================================

	public void onNotify(Watchable w, Object arg)
	{
	} // of onNotify

	public void onUpdate(Watchable w, Object arg)
	{
	} // of onUpdate

	public void onUpdate(
		Watchable w,
		String strProperty,
		Object oldVal,
		Object newVal)
	{
	} // of onUpdate

	// onDelete is inherited from GraphicalObjectGroupImpl

	//===   WATCH METHODS   =====================================================
	//===========================================================================

	//===========================================================================
	//===   RENDERING   =========================================================

	/**
	 * Set whether we should draw the patch border.
	 */
	public void setDrawPatch(boolean flag)
	{
		flagDrawPatch = flag;
	} // of method
    
    public boolean shouldDrawPatch() {
        return this.flagDrawPatch;
    }

	//-----------------------------------------------------------------

	/**
	 * Set whether we should fill in the patch.
	 */
	public void setFillPatch(boolean flag)
	{
		flagFillPatch = flag;
	} // of method

	public boolean isFillPatch() {
		return this.flagFillPatch;
	}
	
	//-----------------------------------------------------------------

	/**
	 * Set whether we should draw the children or not.
	 */
	public void setDrawChildren(boolean flag)
	{
		flagDrawChildren = flag;
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Renders the children of the patch.
	 */
	protected void renderChildren(SatinGraphics g)
	{
		super.defaultRender(g);
	}

	//-----------------------------------------------------------------

	/**
	 * cache related methods
	 */

	public void cacheImageTo(BufferedImage image)
	{
		externalCacheImage = image;
	}

    public void renderBackgroundImage(SatinGraphics g, Rectangle2D rect) {
        
    }
    
	//-----------------------------------------------------------------

	protected void defaultRender(SatinGraphics g)
	{
		// render to external cached image   	
		if (externalCacheImage != null)
		{
			Graphics2D g2d = externalCacheImage.createGraphics();
			SatinGraphics newG = new SatinGraphics(g2d);
			Rectangle2D box = this.getBounds2D(COORD_LOCAL);
			newG.pushStyle(g.getStyle());
			newG.clearAllTransforms();

			Rectangle2D absBox = this.getBounds2D(COORD_ABS);
			newG.pushTransform(
				AffineTransform.getTranslateInstance(
					-absBox.getMinX(),
					-absBox.getMinY()));

			newG.pushTransform(g.getTransform());

			Shape oldClip = newG.getClip();

			newG.setClip(box);

			//// 1. Draw the Polygons.
			if (flagFillPatch == true)
			{
				newG.fill(getLocalBoundingPoints2DRef());
			}

            renderBackgroundImage(newG, 
                    getLocalBoundingPoints2DRef().getBounds2D());
            
			if (flagDrawPatch == true)
			{
				newG.draw(getLocalBoundingPoints2DRef());
			}

			//// 2. Draw the contained Graphical Objects.
			if (flagDrawChildren == true)
			{
				renderChildren(newG);
			}

			newG.setClip(oldClip);
			newG.dispose();

		}
		else
		{

			//// 1. Draw the Polygons.
			if(SatinImageLib.imageConvertingRender)
			{
				//Rectangle2D bounds = getLocalBoundingPoints2DRef().getBounds2D();
                Polygon2D bounds = (Polygon2D)getLocalBoundingPoints2DRef().clone();
                bounds.transform(g.getGraphics().getTransform());
				//bounds = GeomLib.transformRectangle(
				//		g.getGraphics().getTransform(), bounds);
				Color oldColor = g.getGraphics().getColor();
				Stroke oldStroke = g.getGraphics().getStroke();
				
				if (this.getPrintFill()!=null)
				{
					g.getGraphics().setColor(this.getPrintFill());//this.getStyleRef().getFillColor());
					AffineTransform trans = g.getGraphics().getTransform();
					g.getGraphics().setTransform(AffineTransform.getTranslateInstance(0,0));
					g.getGraphics().fill(bounds);
                    renderBackgroundImage(g, bounds.getBounds2D());
					g.getGraphics().setTransform(trans);
				}

	
				if (this.getPrintDraw()!=null)
				{
					g.getGraphics().setColor(this.getPrintDraw());//this.getStyleRef().getDrawColor());
					AffineTransform trans = g.getGraphics().getTransform();
					g.getGraphics().setTransform(AffineTransform.getTranslateInstance(0,0));
					g.getGraphics().draw(bounds);
					g.getGraphics().setTransform(trans);
				}

				g.getGraphics().setColor(oldColor);
				g.getGraphics().setStroke(oldStroke);

				//// 2. Draw the contained Graphical Objects.
				if (flagDrawChildren == true)
				{
					renderChildren(g);
				}
			}
			else
			{
				if (flagFillPatch == true)
				{
					g.fill(getLocalBoundingPoints2DRef());
                    renderBackgroundImage(g, getLocalBoundingPoints2DRef().getBounds2D());
				}
	
					
				if (flagDrawPatch == true)
				{
                    //g.draw(getLocalBoundingPoints2DRef());
                    Polygon2D p = (Polygon2D)getLocalBoundingPoints2DRef().clone();
                    p.transform(g.getTransform());
                    try
                    {
                        g.pushTransform(g.getTransform().createInverse());
                    }
                    catch(Exception ex)
                    {
                        g.pushTransform(new AffineTransform());
                    }
                    g.draw(p);
                    g.popTransform();
				}
	
	
				//// 2. Draw the contained Graphical Objects.
				if (flagDrawChildren == true)
				{
					renderChildren(g);
				}
			}
		}
	} // of defaultRender

	//===   RENDERING   =========================================================
	//===========================================================================

	//===========================================================================
	//===   CLONE   =============================================================

	public Object clone()
	{
		return (clone(new PatchImpl()));
	} // of clone

	//-----------------------------------------------------------------

	/**
	 * For clone chaining purposes.
	 *
	 * @see GraphicalObjectImpl#clone(GraphicalObjectImpl)
	 */
	protected PatchImpl clone(PatchImpl p)
	{
		//// 1. First call the superclass clone for clone chaining.
		super.clone(p);

		//// 2. Now clone variables within this current class.
		p.flagDrawPatch = this.flagDrawPatch;
		p.flagFillPatch = this.flagFillPatch;
		p.flagDrawChildren = this.flagDrawChildren;

		return (p);
	} // of clone

	//-----------------------------------------------------------------

	/**
	 * Make a deep-clone.
	 */
	public Object deepClone()
	{
		return (deepClone(new PatchImpl()));
	} // of deepClone

	//-----------------------------------------------------------------

	/**
	 * For deep-clone chaining. If you override this method in a subclass, be
	 * sure to call this method, just as you would have to for normal clone
	 * chaining.
	 *
	 * @see #clone()
	 * @see #deepClone()
	 */
	protected PatchImpl deepClone(PatchImpl newPatch)
	{
		//// 1. First, let's do a deep-clone chain.
		super.deepClone(newPatch);

		//// 2. Now clone variables within this current class.
		////    Can't just call setBoundingPoints(), since that clears out
		////    the old transform.
		newPatch.flagDrawPatch = this.flagDrawPatch;
		newPatch.flagFillPatch = this.flagFillPatch;
		newPatch.flagDrawChildren = this.flagDrawChildren;

		return (newPatch);
	} // of deepClone

	//===   CLONE   =============================================================
	//===========================================================================

	//===========================================================================
	//===   MAIN   ==============================================================

	public static void main(String[] argv)
	{
		//StickyZViewWrapper v;

		PatchImpl p1;
		PatchImpl p2;

		p1 = new PatchImpl(new Rectangle(200, 200, 50, 50));
		p1.setView(new StickyZViewWrapper(p1.getView()));
		p1.applyTransform(AffineTransform.getTranslateInstance(20, 20));

		/*
		      v = (StickyZViewWrapper) p1.getView().clone();
		      System.out.println("---v---");
		      System.out.println(v);
		      System.out.println("---p1.v---");
		      System.out.println(p1.getView());
		
		      System.out.println("---predicates---");
		      System.out.println(v == p1.getView());
		      System.out.println(v.getView() == ((StickyZViewWrapper) p1.getView()).getView());
		
		      p2 = new PatchImpl(new Rectangle(10, 30, 50, 70));
		      p2.setView(v);
		
		
		      System.out.println("---v---");
		      System.out.println(v);
		      System.out.println("---p1.v---");
		      System.out.println(p1.getView());
		*/

		Debug.println("----before----");
		Debug.println(p1);
		p2 = (PatchImpl) p1.deepClone();
		p2.applyTransform(AffineTransform.getScaleInstance(2, 2));

		Debug.println("----p2----");
		Debug.println(p2);

		Debug.println("----after----");
		Debug.println(p1);

		Debug.println(p1.getTransform(COORD_ABS));
		Debug.println(p2.getTransform(COORD_ABS));

	} // of main

	//===   MAIN   ==============================================================
	//===========================================================================

	//----------------------------------------

	/**
	 * clear all references hold by this object (In the namespace of this class)
	 */

	public void deepClear()
	{
		super.deepClear();
		addFilter = null;
		externalCacheImage = null;
	}

	public StrokeEventFilter getStrokeEventFilter()
	{
		return this.addFilter;
	}
	
	public Color getPrintFill() {
		return null;
	}
	
	public Color getPrintDraw() {
		return null;		
	}

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
