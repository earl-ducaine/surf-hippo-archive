package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.view.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.graphics.SatinGraphics;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.satin.image.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.awt.image.*;

/**
 * The label describes what a {@link DenimPanel panel}contains.
 * </P>
 * 
 * <PRE>
 * 
 * Revisions: 1.0.0 08-31-1999 MWN Created. Actually created a while ago, but
 * it's never too late to document your code. 1.0.1 11-21-1999 MWN Added
 * Semantic View properties: make labels disappear at overview level 1.0.2
 * 01-06-2003 YL Enabled image cache based rendering to improve the performance
 * Added Denim Label active feedback 1.0.2 01-16-2003 YL Fixed empty label bugs
 * 1.0.2 03-07-2003 YL Merge the implementation of render cache and active
 * feedback cache 1.0.2 03-29-2003 YL Added deep clear
 * 
 * </PRE>
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~newman">Mark Newman </A>( <A
 *         HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu </A>)
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli">Yang Li </A>( <A
 *         HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu </A>)
 * 
 * 
 * @since JDK 1.2
 * @version Version 1.0.2, 03-29-2003
 */
public class DenimLabel extends PatchImpl implements ArrowSource, ArrowDest,
        DenimConstants, CaptionedGraphicalObject {

    //===========================================================================
    //=== CONSTANTS =========================================================

    static final long serialVersionUID = -5578980871859997524L;

    //-----------------------------------------------------------------

    private static final Color labelBorder = NO_COLOR;

    private static final Color labelBackground = Color.white;

    private static final int cushion = 0;

    //=== CONSTANTS =========================================================
    //===========================================================================

    //===========================================================================
    //=== NONLOCAL VARIABLES ================================================

    private DenimText phrase = null;

    private DenimSketch sketch = null;

    private GObImage image;

    private String imageFileLocation = null;

    // the scale factor at which this label always appears
    private double stickyScaleFactor;

    // stores all of the arrows originating from this label
    // maps destinations to arrows
    private HashMap arrows;

    private HashMap incomingArrows; // keeps track of incoming arrows

    //   private boolean incrementalCacheUpdate = false;
    //   private static GraphicalObjectCollection newLabelCreated = new
    // GraphicalObjectCollectionImpl();

    //=== NONLOCAL VARIABLES ================================================
    //===========================================================================

    //===========================================================================
    //=== CONSTRUCTORS ======================================================

    // for deepClone
    protected DenimLabel() {
        this(new Rectangle(0, 0, 1, 1)); // give it some bounds
    } // of constructor

    //-----------------------------------------------------------------

    public DenimLabel(Polygon poly) {
        this(poly.getBounds());
    } // of constructor

    //-----------------------------------------------------------------

    public DenimLabel(TimedStroke stk) {
        this(stk.getBounds());
    } // of constructor

    //-----------------------------------------------------------------

    /**
     * All labels are rectangular, this is the constructor where everything
     * happens. Most other constructors, except DenimLabel(DenimText), redirect
     * to this one.
     * 
     * This constructor does NOT add the label to the parent sheet, unlike the
     * constructor DenimLabel(DenimText). This is, of course, extremely dumb.
     * 
     * It also doesn't set up stickyZ, which it can't do because it doesn't know
     * the parent. Dumb. Somebody fix this.
     */
    public DenimLabel(Rectangle2D rect) {
        super(rect);

        //	  DenimLabel.newLabelCreated.add(this);

        phrase = null;

        commonInit();
    } // of constructor

    //-----------------------------------------------------------------

    /**
     * Create a label from a phrase. The label will be slightly larger than the
     * phrase and be in the same position on the sheet. It will also be added to
     * the parent of the phrase. The phrase will be added to the new label (and
     * therefore removed from its parent).
     */
    public DenimLabel(DenimText phrase) {
        this(new Rectangle(0, 0, 1, 1)); // bogus bounds to start

        GraphicalObjectGroup parent;
        double currScaleFactor;

        parent = phrase.getParentGroup();
        currScaleFactor = GraphicalObjectLib.getScaleFactor(COORD_ABS, this);

        //TODO: this is not clean. Phrases are not added to anything in their
        //constructors & these should work the same. It probably makes more
        //sense to change how phrases are done.
        parent.add(this, GraphicalObjectGroup.KEEP_ABS_POS);

        Rectangle2D phraseBounds = phrase.getBounds2D(COORD_ABS);
        //debug.println("phrase abs bound: " + phraseBounds.toString());
        int cush = (int) (cushion * currScaleFactor);
        this.setBoundingPoints2D(COORD_ABS, new Rectangle2D.Double(phraseBounds
                .getX()
                - cush, phraseBounds.getY() - cush, phraseBounds.getWidth() + 2
                * cush, phraseBounds.getHeight() + 2 * cush));
        //debug.println("label's abs bound: " +
        //              this.getBoundingPoints2D(COORD_ABS).toString());
        this.add(phrase, GraphicalObjectGroup.KEEP_ABS_POS);
        this.phrase = phrase;

        commonInit();

        stickyScaleFactor = currScaleFactor;
        setupStickyZ(stickyScaleFactor);
    } // of constructor

    //-----------------------------------------------------------------

    /**
     * Creates a label with the given bounds, phrase, and zoom factor at which
     * the label is always displayed.
     * 
     * Only used by createDenimLabelFromDOMElement.
     */
    public DenimLabel(Rectangle2D bounds, DenimText phrase,
            double stickyScaleFactor) {

        //this(bounds, "c:/pear.jpg", stickyScaleFactor);
        super(bounds);

        /*
         * if(phrase instanceof TypedText) { String cleanString =
         * ((TypedText)phrase).getTextArea().getText().trim();
         * ((TypedText)phrase).getTextArea().setText(cleanString); }
         */
        this.phrase = phrase;
        add(phrase, GraphicalObjectGroup.KEEP_REL_POS);
        commonInit();
        this.stickyScaleFactor = stickyScaleFactor;
        setupStickyZ(stickyScaleFactor);

    } // of constructor

    //---------------------------------------------------------------------

    /**
     * This is for loading denim labels from a DOM. These particular denim
     * labels have GObImages in them.
     * 
     * Only used by createDenimLabelFromDOMElement.
     */
    public DenimLabel(Rectangle2D bounds, String imageFileLoc,
            double stickyScaleFactor) {
        super(bounds);
        try {
            imageFileLocation = imageFileLoc;
            image = new GObImage(imageFileLoc);
            add(image, GraphicalObjectGroup.KEEP_REL_POS);
        } catch (Exception e) {
            System.out.println("Could not create GOBImage for DenimLabel "
                    + ((image == null) ? "b/c image is null!"
                            : "even though image is valid!"));
            if (image == null)
                System.out.println("The path of image is: " + imageFileLoc);
        }

        commonInit();
        this.stickyScaleFactor = stickyScaleFactor;
        setupStickyZ(stickyScaleFactor);
        damage(SatinConstants.DAMAGE_NOW);
    }

    //-----------------------------------------------------------------

    private void commonInit() {
        arrows = new HashMap();
        incomingArrows = new HashMap();

        Style style = getStyle();
        style.setFillColor(labelBackground);
        style.setDrawColor(labelBorder);
        setStyle(style);
        
        this.setDrawPatch(false);
        this.setFillPatch(true);

        setAllowDeepGet(false);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Show active feedback when editing a label
     */

    public void activeFeedback() {

        Graphics2D g = (Graphics2D) this.getSheet().getGraphics();

        //      incrementalCacheUpdate = true;
        this.getRenderCache().updateCache(null, this.getStyleRef());
        //      incrementalCacheUpdate = false;

        AffineTransform tr = g.getTransform();

        AffineTransform newtr = this.getTransform(COORD_ABS);
        AffineTransform stickyTr = ((LabelViewWrapper) ((SemanticZoomMultiViewImpl) this
                .getView()).get(0)).getStickyTransform();
        newtr.concatenate(stickyTr);

        g.setTransform(newtr);

        Rectangle2D box = getUnstickyLocalBounds();
        g.drawImage(this.getRenderCache().getCacheImage(), (int) box.getMinX(),
                (int) box.getMinY(), (int) box.getWidth(), (int) box
                        .getHeight(), this.getSheet());

        g.setTransform(tr);

        // draw blue frame around image
        Color oldC = g.getColor();
        g.setColor(DenimConstants.activeFrameColor);

        g.draw(this.getBounds2D(COORD_ABS));

        g.setColor(oldC);

    }

    //-----------------------------------------------------------------

    /**
     * Fix up state after label has been added to sheet.
     */
    public void initAfterAddLabelToSheet() {
        double absScaleAtSitemap = DenimUtils.getAbsScaleFactorAt(this,
                SITEMAP_SCALE_FACTOR);

        Iterator it = ((MultiView) this.getView()).iterator();

        while (it.hasNext()) {
            View v = (View) it.next();
            if (v instanceof LabelViewWrapper) {
                LabelViewWrapper lvw = (LabelViewWrapper) v;
                lvw.setDisplayRange(absScaleAtSitemap * 0.63,
                        absScaleAtSitemap * 0.66, 1000, 1000);
            }
        }
    }

    //=== CONSTRUCTORS ======================================================
    //===========================================================================

    //===========================================================================
    //=== XXXXX METHODS =====================================================

    private void setupStickyZ(double scaleFactor) {
        SemanticZoomMultiViewImpl views;
        LabelViewWrapper v;

        v = new LabelViewWrapper(this.getView());
        v.setDesiredScale(scaleFactor);
        views = new SemanticZoomMultiViewImpl();
        views.add(v);
        this.setView(views);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Gets the panel that this label is a part of.
     */
    public DenimPanel getPanel() {
        return (DenimPanel) getParentGroup();
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns the text inside this label.
     */
    public DenimText getPhrase() {
        return phrase;
    } // of method

    //-----------------------------------------------------------------

    public String getImageLocation() {
        return imageFileLocation;
    }

    //-----------------------------------------------------------------

    /**
     * Sets the text inside this label.
     */
    public void setPhrase(DenimText p) {

        remove(phrase);
        phrase = p;

        Point2D absLoc = this.getLocation2D(COORD_ABS);
        int cush = (int) (cushion * ((DenimSheet) getSheet()).getAbsScale());

        add(phrase, GraphicalObjectGroup.KEEP_REL_POS);
        Rectangle2D phraseBounds = phrase.getBounds2D(COORD_ABS);

        this.setBoundingPoints2D(COORD_ABS, new Rectangle2D.Double(absLoc
                .getX()
                - cush, absLoc.getY() - cush, phraseBounds.getWidth() + 2
                * cush, phraseBounds.getHeight() + 2 * cush));

        // The label's view always keeps the label touching the sketch without
        // moving the sketch, which could move the label. So we need to get
        // the location of the label again, before moving the text.
        absLoc = this.getLocation2D(COORD_ABS);
        Point2D phraseNewLoc = DenimUtils.trueAbsToLocal(this, absLoc);

        phrase.moveTo(COORD_REL, phraseNewLoc);
    }

    //-----------------------------------------------------------------

    /**
     * Used only by DENIM classes.
     */
    public LabelViewWrapper getLabelView() {

        MultiView vm = (MultiView) this.getView();
        Iterator it = vm.iterator();
        LabelViewWrapper lvw;

        while (it.hasNext()) {
            View v = (View) it.next();
            if (v instanceof LabelViewWrapper) {
                lvw = (LabelViewWrapper) v;
                return lvw;
            }
        }

        // This shouldn't happen
        assert false; // "DenimLabel does not have a LabelViewWrapper"
        return null;
    }

    //-----------------------------------------------------------------

    /**
     * Sets the sketch that the label is attached to.
     */
    public void setSketch(DenimSketch sketch) {

        // set the image cache invalid
        this.sketch = sketch;
        //getLabelView().setSketch(sketch);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Gets the sketch that the label is attached to.
     */
    public DenimSketch getSketch() {
        return sketch;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Used only by DOMUtils.
     */
    public double getStickyScaleFactor() {
        return stickyScaleFactor;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Used only by DOMUtils.
     */
    public Rectangle2D getUnstickyLocalBounds() {
        return getLabelView().getUnstickyLocalBounds();
    }

    //=== XXXXX METHODS =====================================================
    //===========================================================================

    //===========================================================================
    //=== CAPTION METHODS ===================================================

    public DenimText getCaption() {
        return getPhrase();
    }

    public void setCaption(DenimText caption) {
        setPhrase(caption);
    }

    //=== CAPTION METHODS ===================================================
    //===========================================================================

    //===========================================================================
    //=== ARROW SOURCE METHODS ==============================================

    /**
     * Tells the label to keep track of the given arrow. The arrow should
     * originate from within the panel.
     */
    public void trackArrow(Arrow arrow) {
        //DenimPanel panel = getPanel();
        ArrowDest dest = arrow.getDest();
        arrows.put(dest, arrow);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Tells the label to stop keeping track of the given arrow. The arrow
     * should originate from within the panel.
     */
    public void untrackArrow(Arrow arrow) {
        arrows.remove(arrow.getDest());
    } // of method

    //-----------------------------------------------------------------

    public Set getOutgoingArrows() {
        return new HashSet(arrows.values());
    }

    //-----------------------------------------------------------------

    /**
     * Returns whether the label has the given arrow originating from it.
     */
    public boolean hasArrow(Arrow arrow) {
        return arrows.containsKey(arrow.getDest());
    } // of method

    //-----------------------------------------------------------------

    public Arrow getRedundantArrow(String eventType, int condition,
            ArrowDest dest) {
        return getPanel().getOrgArrowWithDestPanel(dest);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns the arrow with the given destination, or null if there isn't one.
     */
    public Arrow getArrowWithDest(ArrowDest dest) {
        return (Arrow) (arrows.get(dest));
    } // of method

    //=== ARROW SOURCE METHODS ==============================================
    //===========================================================================

    //===========================================================================
    //=== ARROW DEST METHODS ================================================

    public void trackIncomingArrow(Arrow arrow) {
        GraphicalObject source = arrow.getSource();
        incomingArrows.put(source, arrow);
    } // of method

    //-----------------------------------------------------------------

    public void untrackIncomingArrow(Arrow arrow) {
        incomingArrows.remove(arrow.getSource());
    } // of method

    //-----------------------------------------------------------------

    public Set getIncomingArrows() {
        return new HashSet(incomingArrows.values());
    }

    //-----------------------------------------------------------------

    public boolean hasIncomingArrow(Arrow arrow) {
        return incomingArrows.containsKey(arrow.getSource());
    } // of method

    //=== ARROW DEST METHODS ================================================
    //===========================================================================

    //===========================================================================
    //=== STROKE HANDLING METHODS ===========================================

    public void handleSingleStroke(SingleStrokeEvent evt) {
        //// ignore
    } // of handleSingleStroke

    //=== STROKE HANDLING METHODS ===========================================
    //===========================================================================

    //===========================================================================
    //=== REVISED RENDER AND DAMAGE METHODS =================================

    /**
     * update the image cache of label when it's not valid.
     */

    protected void updateCacheInternal(GraphicalObjectRenderingCache grc,
            AffineTransform refTransform, Style refStyle) {

        if (this.getSheet() instanceof DenimSheet) {
            Rectangle2D box = getUnstickyLocalBounds();

            int imagew = (int) Math.ceil(box.getWidth());

            if (imagew <= 0)
                imagew = 1;

            int imageh = (int) Math.ceil(box.getHeight());

            if (imageh <= 0)
                imageh = 1;

            BufferedImage cache = grc.getCacheImage();

            if (cache == null)
                cache = new BufferedImage(imagew, imageh,
                        BufferedImage.TYPE_INT_RGB);

            Graphics2D g2d = cache.createGraphics();
            SatinGraphics newG = new SatinGraphics(g2d);

            refStyle.setDrawTransparency(1);
            newG.pushStyle(refStyle);

            Shape oldClip = newG.getClip();
            newG.setClip(box);

            newG.clearAllTransforms();

            //// 1. draw the background and the frame
            newG.setColor(Color.white);
            newG.fill(box);
            newG.draw(box);

            //// 2. Draw the contained Graphical Objects.
            renderChildren(newG);
        
            newG.setClip(oldClip);
            newG.dispose();

            grc.setCacheImage(cache);
            grc.setCacheTransform(AffineTransform.getTranslateInstance(0, 0));
        }
    }

    //-----------------------------------------------------------------

    /**
     * Regroup fragment labels and merge them to their adjacent clusters
     */

    /*
     * private static void fragmentClearingup() {
     * 
     * if(newLabelCreated.isEmpty()) return;
     * 
     * Iterator it = newLabelCreated.getForwardIterator();
     * 
     * while(it.hasNext()) { GraphicalObject obj = (GraphicalObject)it.next();
     * 
     * if(obj.getBounds2D(COORD_ABS).getWidth()>10&&obj.getBounds2D(COORD_ABS).getHeight()>10) {
     * continue; }
     * 
     * GraphicalObject host = findNearstCluster(obj);
     * 
     * if(host!=null) { merge((DenimLabel)host, (DenimLabel)obj); }
     *  }
     * 
     * newLabelCreated.clear();
     *  }
     */
    //-----------------------------------------------------------------
    /**
     * merge fragment clusters
     */

    /*
     * private static void merge(DenimLabel lab1, DenimLabel lab2) {
     * 
     * lab1.add(lab2.getPhrase());
     *  }
     */
    //-----------------------------------------------------------------
    /**
     * find the nearest label based on size computation
     */

    /*
     * private static GraphicalObject findNearstCluster(GraphicalObject label) {
     * 
     * Iterator it = label.getParentGroup().getForwardIterator();
     * 
     * double factor = 0; GraphicalObject nearest = null; Rectangle2D inter =
     * new Rectangle2D.Double();
     * 
     * 
     * 
     * while(it.hasNext()) { GraphicalObject obj = (GraphicalObject)it.next();
     * 
     * if(label!=obj) {
     * if(label.getBounds2D(COORD_ABS).intersects(obj.getBounds2D(COORD_ABS))) {
     * Rectangle2D.intersect(label.getBounds2D(COORD_ABS),obj.getBounds2D(COORD_ABS),inter);
     * 
     * double temp =
     * inter.getWidth()*inter.getHeight()/(label.getBounds2D(COORD_ABS).getWidth()*label.getBounds2D(COORD_ABS).getHeight());
     * 
     * if(temp > factor) { factor = temp; nearest = obj; } } } }
     * 
     * if(factor < 0.6) return null;
     * 
     * return nearest;
     *  }
     */
    //-----------------------------------------------------------------
    /**
     * Because there is no zooming for label, so cache is valid in most of time
     * except editing
     */

    protected void defaultRender(SatinGraphics g) {

        Point2D absLoc = this.getLocation2D(COORD_ABS);
        Point2D phraseNewLoc = DenimUtils.trueAbsToLocal(this, absLoc);
        Point2D pos = phrase.getLocation2D(COORD_REL);
        if(pos.getX()!=phraseNewLoc.getX()||
                pos.getY()!=phraseNewLoc.getY())
        {
            this.disableDamage();
            phrase.moveTo(COORD_REL, phraseNewLoc);
            this.enableDamage();
        }
        
        if (SatinImageLib.imageConvertingRender) {
            //super.defaultRender(g);
            renderChildren(g);
            return;
        }

        if (!this.getRenderCache().getCacheValidity()) {
            this.getRenderCache().updateCache(null, g.getStyle());
        }

        Rectangle2D box = getUnstickyLocalBounds();
        
        if (this.getSheet().isSheetPanning()
                || RadarViewPanel.isRadarViewRendering()) 
        {
            g.drawImage(this.getRenderCache().getCacheImage(), (int) box
                    .getMinX(), 
                    (int) box.getMinY(), 
                    this.getSheet());
        } 
        else 
        {
            if (ZoomSlider.zoomingInstance == 0) {
                g.fill(getUnstickyLocalBounds());
                g.draw(getUnstickyLocalBounds());
                renderChildren(g);
            } 
            else 
            {
                g.drawImage(this.getRenderCache().getCacheImage(), (int) box
                        .getMinX(), 
                        (int) box.getMinY(), 
                        this.getSheet());
            }
        }
    }

    /**
     * This should become unnecessary once SATIN's sticky mechanism is changed.
     */
    /*
     * protected void defaultRender(SatinGraphics g) { //// 1. Draw the
     * Polygons. g.fill(getUnstickyLocalBounds());
     * g.draw(getUnstickyLocalBounds());
     * 
     * //// 2. Draw the contained Graphical Objects.
     * //if(((DenimSheet)Sheet.sheetInstance).rightAtALevel())
     * renderChildren(g); } // of defaultRender
     */
    //-----------------------------------------------------------------
    public void damage(int sync, Rectangle2D rect) {
        GraphicalObjectGroup parent = getParentGroup();
        if (parent != null) {
            super.damage(sync, rect.createUnion(parent.getBounds2D(COORD_ABS)));
        } else {
            super.damage(sync, rect);
        }
    } // of damage

    //=== REVISED DAMAGE METHODS ============================================
    //===========================================================================

    //===========================================================================
    //=== WATCH METHODS =====================================================

    /**
     * If the label receives an update message, propogate it to all objects that
     * are watching the label.
     */
    public void onUpdate(Watchable w, String strProperty, Object oldVal,
            Object newVal) {
        //debug.println("Label " + getUniqueID() + " propogating update");
        notifyWatchersUpdate(strProperty, oldVal, newVal);
    } // of method

    //=== WATCH METHODS =====================================================
    //===========================================================================

    //===========================================================================
    //=== CLONE =============================================================

    public Object deepClone() {
        return deepClone(new DenimLabel());
    } // of method

    //-----------------------------------------------------------------

    public Object deepClone(DenimLabel clone) {
        super.deepClone(clone);

        // HACK: Unnecessary once SATIN's sticky mechanism is fixed
        clone.setBoundingPoints2D(COORD_LOCAL, getUnstickyLocalBounds());

        if (clone.numElements() > 0) {
            clone.phrase = (DenimText) (clone.get(0));
            // we know the phrase is the first (and
            // only) object that has been added to
            // this patch
        } else {
            clone.phrase = null;
        }
        clone.sketch = sketch;
        clone.stickyScaleFactor = stickyScaleFactor;

        return clone;
    } // of method

    //----------------------------------------

    /**
     * clear all references hold by this object (In the namespace of this class)
     */

    public void deepClear() {
        super.deepClear();
        phrase = null;
        sketch = null;
        image = null;
        imageFileLocation = null;

        if (arrows != null) {
            arrows.clear();
            arrows = null;
        }

        if (incomingArrows != null) {
            incomingArrows.clear();
            incomingArrows = null;
        }

    }

    //=== CLONE =============================================================
    //===========================================================================

} // of class

//==============================================================================

/*
 * Copyright (c) 1999-2001 Regents of the University of California. All rights
 * reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. All advertising materials mentioning features or use of this software must
 * display the following acknowledgement:
 * 
 * This product includes software developed by the Group for User Interface
 * Research at the University of California at Berkeley.
 * 
 * 4. The name of the University may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
