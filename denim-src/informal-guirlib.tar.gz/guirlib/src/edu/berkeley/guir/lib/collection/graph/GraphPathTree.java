//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import edu.berkeley.guir.lib.util.StringLib;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;

/**
 * A Path Tree that represents a hierarchy of siblings and children. You throw
 * Paths into this Tree, and it builds the appropriate hierarchy tree.
 *
 * <P>
 * The left subtree represents a sibling, and the right subtree represents a
 * child.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Dec 01 1997, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.0/1.2.0, Nov 22 2002, JH
 *               Updated for new Graph APIs
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.1.4
 * @version GUIRLib-v1.5/1.2.0, Nov 22 2002
 */
public class GraphPathTree 
   extends    BinaryTree
   implements Serializable, Cloneable {

   //===========================================================================
   //===   CONSTANTS   =========================================================
   
   private final static int INDENT    = 3;

   //===   CONSTANTS   =========================================================
   //===========================================================================





   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   GraphPathTreeFormatter formatter = new GraphPathTreeFormatterDefault();

   //// Nodes are entries in the GraphPathTree.
   //// Hits are search result hits.
   //// Leaves are ends of the tree. A leaf will always be a hit. A hit does
   ////    not have to be a leaf, as it may be part of the path to another hit.
   int numNodes  = 0;   // number of overall nodes in the tree
   int numHits   = 0;   // number of overall hits in the tree
   int numLeaves = 0;   // number of overall leaves in the tree

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   FACTORY METHODS   ===================================================

   public void setDefaultFormatter(GraphPathTreeFormatter f) {
      if (f != null) {
         formatter = f;
      }
   } // of method

   //===   FACTORY METHODS   ===================================================
   //===========================================================================





   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates a new and empty GraphPathTree. 
    */
   public GraphPathTree() {
      //// Note: we keep an empty Node at the top, and every node added
      ////       subsequently is a child of this Node. The reason for this
      ////       is to allow the structure of the Nodes below to change
      ////       as necessary without having to change the root pointer.
      ////
      ////       It also allows us to subclass the GraphPathTree and still have
      ////       most things working correctly still.
      super(new GraphNode("error - should not see this"));
   } // of default constructor

   //===========================================================================

   /**
    * Creates a new GraphPathTree. Used internally only.
    */
   protected GraphPathTree(GraphNode node) {
      super(node);
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Adds a path into this hierarchy tree.
    *
    * @param p is the Path to add into this tree.
    */
   public void addPath(GraphPath p) {

      GraphPathTree    newroot     = null;
      GraphPathTree    prev        = null;
      int              numNewNodes = p.length();  // #nodes in new GraphPathTree
      Iterator         it          = p.getNodesReversed();

      //// 1. Create a temporary hierarchy tree for this Path
      ////    by going through the nodes in the Path backwards (easier)
      while (it.hasNext()) {

         newroot = new GraphPathTree((GraphNode) it.next());
         newroot.setChild(prev);
         prev = newroot;

      } // of while
                            ////////////////////////

      //// 2. Special case where we have an empty tree.
      if (this.child() == null) {
         this.addChild(newroot);
	 numNodes += numNewNodes;
         return;
      }
                            ////////////////////////

      //// 3. Figure out how to add this tree into the current tree. 
      ////    Travel down the sibling-child tree until we don't find a match.
      ////    If we exit out of the while loop normally, it means that the
      ////       current tree already contains the Path. 
      ////    Garbage collection should also take care of the fact that we
      ////       lose the root pointer of the new Path.
      GraphPathTree search     = null;           // result of our search
      GraphPathTree current    = this.child();   // currently are in tree
      boolean       flagCommon = false;          // any matches at all?

      while (newroot != null) {

         search = current.hasSibling(newroot);
         if ( search == null ) {

            search = current.hasChild(newroot);
            if ( search == null ) {
               //// 4.1. Add the new thing in as a child if there was anything 
               ////      in common in the Path and the current tree, or as a 
               ////      sibling if there was nothing in common.
               if (flagCommon) {
                  current.addChild(newroot);
               }
               else {
                  current.addSibling(newroot);
               }
	       numHits++;
               break;
            }
         }

	 //// 3.1. Has one node in common, so one less new node being added
	 numNewNodes--;                  

         //// 3.2. Go down the next node
         newroot    = newroot.child();
         current    = search;
         flagCommon = true;
      }

      // Number of nodes in Path should be >= 0
      // assert numNewNodes >= 0; 
      numNodes += numNewNodes;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the child subtree of the current tree.
    *
    * @param ptree is a GraphPathTree to set the child subtree to.
    */
   protected void setChild(GraphPathTree ptree) {
      setRight(ptree);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the sibling subtree of the current tree.
    *
    * @param ptree is a GraphPathTree to set the sibling subtree to.
    */
   protected void setSibling(GraphPathTree ptree) {
      setLeft(ptree);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the value at the root of this tree.
    *
    * @param node is the value for the root of this tree.
    */
   protected void setData(GraphNode node) {
      setData(node);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a sibling to this tree. Currently, it arbitrarily adds it to the
    * end of the list of siblings, but we can add a heuristic later on.
    *
    * @param ptree is a GraphPathTree to add.
    */
   private void addSibling(GraphPathTree ptree) {

      //// 1. The GraphPathTree will probably never be large enough such that
      ////    recursion will cost a lot
      if (this.sibling() == null) {
         this.setSibling(ptree);
      }
      else {
         this.sibling().addSibling(ptree);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a child to this tree. Currently, it arbitrarily adds it to the
    * end of the list of children, but we can add a heuristic later on.
    *
    * @param ptree is a GraphPathTree to add.
    */
   private void addChild(GraphPathTree ptree) {

      //// 1. The GraphPathTree will probably never be large enough such that
      ////    recursion will cost a lot or overflow.
      if (this.child() == null) {
         this.setChild(ptree);
      }
      else {
         //// This is not a bug - if we cannot add it directly, then it's
         //// a sibling of one of the existing children nodes.
         this.child().addSibling(ptree);
      }
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Get the number of unique nodes currently in this GraphPathTree.
    *
    * @return the number of unique nodes currently in this GraphPathTree.
    */
   public int getNumOfNodes() {
      return(numNodes);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the number of leaves currently in this GraphPathTree. Currently, does
    * not return a useful value.
    *
    * @return an unuseful value.
    */
   public int getNumOfLeaves() {
      return(numLeaves);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the number of hits currently in this GraphPathTree. 
    *
    * @return the number of hits currently in this GraphPathTree. 
    */
   public int getNumOfHits() {
      return(numHits);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Sees if the specified GraphPathTree is a child of the current node. Only
    * checks the specified node itself, does not check the children or 
    * siblings of the specified node.
    *
    * @param  ptree is the GraphPathTree to check for.
    * @return the actual child, or null if it is not a child.
    */
   protected GraphPathTree hasChild(GraphPathTree ptree) {

      GraphPathTree current = this.child();

      while (current != null) {
         if (current.data().equals(ptree.data()))
            return (current);
         current = current.sibling();
      }

      return (null);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Sees if the specified GraphPathTree is a sibling of the current node (or 
    * the same as the current node). Only checks the specified node itself, 
    * does not check the children or siblings of the specified node.
    *
    * @param  ptree is the GraphPathTree to check for.
    * @return the actual sibling, or null if it is not a sibling.
    */
   protected GraphPathTree hasSibling(GraphPathTree ptree) {

      GraphPathTree current = this;

      while (current != null) {
         if (current.data().equals(ptree.data()))
            return (current);
         current = current.sibling();
      }

      return (null);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the value at the root of this tree.
    *
    * @return A Node containing the value at the root of this tree.
    */
   protected GraphNode data() {
      return ((GraphNode) getData());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the child subtree of the current tree.
    *
    * @return the child subtree.
    */
   protected GraphPathTree child() {
      return((GraphPathTree) getRight());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the sibling subtree of the current tree.
    *
    * @return the sibling subtree.
    */
   protected GraphPathTree sibling() {
      return((GraphPathTree) getLeft());
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   TRAVERSAL METHODS   =================================================

   /**
    * Perform an inorder traversal on this tree.
    *
    * @return an Iterator containing the elements of this tree in order.
    */
   public Iterator inOrderTraversal() {
      if (this.child() != null)
         return (this.child().inOrderTraversalHelper());
      else
         return (Collections.EMPTY_LIST.iterator());
   } // of method

   //-----------------------------------------------------------------

   /**
    * The helper to actually perform the inorder traversal.
    *
    * @return an Iterator containing the elements of this tree in order.
    */
   private Iterator inOrderTraversalHelper() {
      return (super.inOrderTraversal());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Perform a preorder traversal on this tree.
    *
    * @return an Iterator containing the elements of this tree in order.
    */
   public Iterator preOrderTraversal() {
      if (this.child() != null)
         return (this.child().preOrderTraversalHelper());
      else
         return (Collections.EMPTY_LIST.iterator());
   } // of method

   //-----------------------------------------------------------------

   /**
    * The helper to actually perform the preorder traversal.
    *
    * @return an Iterator containing the elements of this tree in preorder.
    */
   private Iterator preOrderTraversalHelper() {
      return (super.preOrderTraversal());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Perform a postorder traversal on this tree.
    *
    * @return an Iterator containing the elements of this tree in preorder.
    */
   public Iterator postOrderTraversal() {
      if (this.child() != null)
         return (this.child().postOrderTraversalHelper());
      else
         return (Collections.EMPTY_LIST.iterator());
   } // of method

   //-----------------------------------------------------------------

   /**
    * The helper to actually perform the postorder traversal.
    *
    * @return an Iterator containing the elements of this tree in postorder.
    */
   private Iterator postOrderTraversalHelper() {
      return (super.postOrderTraversal());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print out the traversal in reverse pre-order to the default System.out
    * stream in a formatted order.
    */
   public void printReverseOrderTraversal() {
      printReverseOrderTraversal(new PrintWriter(System.out));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print out the traversal in reverse pre-order to the specified PrintWriter
    * in a formatted order.
    *
    * @param pwriter is the PrintWriter to print out to.
    */
   public void printReverseOrderTraversal(PrintWriter pwriter) {
      this.child().printReverseOrderTraversalHelper(pwriter, 1);
      pwriter.flush();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print out a single node in reverse pre-order to the specified PrintWriter
    * in a formatted order.
    *
    * @param pwriter is the PrintWriter to print out to.
    * @param depth   is the depth of the tree we are at.
    */
   private void printReverseOrderTraversalHelper(PrintWriter pwriter, 
                                                int depth) {

      String strPrefix = StringLib.spaces(INDENT * depth);
      pwriter.println(StringLib.fold(strPrefix, data().toString()));

      if (this.child() != null) {
         this.child().printReverseOrderTraversalHelper(pwriter, depth + 1);
      }

      if (this.sibling() != null) {
         this.sibling().printReverseOrderTraversalHelper(pwriter, depth);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print out the tree in a hierarchy to System.out, using the default
    * layout formatter for the GraphPathTree.
    */
   public void printTraversal() {
      printTraversal(formatter);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print out the tree in a hierarchy to System.out, using the specified
    * layout formatter for the GraphPathTree.
    *
    * @param f is an interface to a layout formatter for GraphPathTrees.
    */
   public void printTraversal(GraphPathTreeFormatter f) {
      printTraversal(new PrintWriter(System.out), f);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print out the tree in a hierarchy to the specified Writer, using the
    * default GraphPathTreeFormatter layout.
    *
    * <P>
    * The order of events is:
    * <UL>
    *    <LI><CODE>onStart()</CODE> (once only)
    *    <LI><CODE>onStartOfNode()</CODE>
    *    <LI>either <CODE>onLeaf()</CODE> or <CODE>onNode()</CODE>
    *    <LI>traverse all of the children
    *    <LI><CODE>onBacktrack()</CODE>
    *    <LI>traverse all of the siblings 
    *    <LI><CODE>onEndOfNode()</CODE>
    *    <LI><CODE>onFinish()</CODE> (once only)
    * </UL>
    *
    * @param pwriter is the PrintWriter to print out to.
    */
   public void printTraversal(PrintWriter pwriter) {
      printTraversal(pwriter, formatter);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print out the tree in a hierarchy to the specified Writer, using the 
    * GraphPathTreeFormatter passed in.
    *
    * @param pwriter is the PrintWriter to print out to.
    * @param f is the formatting object, that is, an interface to an object
    *        that contains methods that can format the layout of this 
    *        GraphPathTree.
    */
   public void printTraversal(PrintWriter pwriter, GraphPathTreeFormatter f) {

      f.onStart(pwriter);
      if (this.child() != null) {
         this.child().printTraversalHelper(pwriter, 1, f);
      }
      f.onFinish(pwriter);
      pwriter.flush();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print out the tree in a hierarchy, with the addition that subclassed
    * methods can add in their own information while printing.
    *
    * @param pwriter is the PrintWriter to print out to.
    * @param depth   is the depth of the tree we are at. We start with depth 1.
    */
   private void printTraversalHelper(PrintWriter pwriter, int depth,
         GraphPathTreeFormatter f) {

      f.onStartOfNode(pwriter, depth);

      if (this.child() == null) {
         f.onLeaf(pwriter, data(), depth);
      }
      else {
         f.onNode(pwriter, data(), depth);
         this.child().printTraversalHelper(pwriter, depth + 1, f);
      }

      f.onBacktrack(pwriter, depth);

      if (this.sibling() != null) {
         this.sibling().printTraversalHelper(pwriter, depth, f);
      }

      f.onEndOfNode(pwriter, depth);
   } // of method

   //===   TRAVERSAL METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Clones this GraphPathTree.
    *
    * @return a GraphPathTree object that has the same values as 
    *         this GraphPathTree object.
    */
   public Object clone() {
      return (null);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   EQUALS   ============================================================

   /*
    * This method checks if a given object is the "same" as this one.
    * In this case, returns true if the source GraphPathTrees are the same.
    *
    * @param obj is the Object to check for equality.
    */
   public boolean equals(Object obj) {
      return(false);
   } // of method

   //===   EQUALS   ============================================================
   //===========================================================================


   
   //===========================================================================
   //===   MAIN    =============================================================
/*
   //
   // Used for self-testing purposes.
   //
   public static void main(String[] argv) {

      Path p;
      GraphPathTree root = new GraphPathTree();
      
      p = new Path();
      p.addNode(new Node("UCB CS Homepage (www.cs.berkeley.edu)"));
      p.addNode(new Node("Computer Science Research at UC Berkeley (www.cs.berkeley.edu/Research)"));
      p.addNode(new Node("Cha-Cha (www.cs.berkeley.edu/Research/cha-cha)"));
      p.addNode(new Node("Jason Hong (www.cs.berkeley.edu/~jasonh/)"));
      root.addPath(p);

      p = new Path();
      p.addNode(new Node("UCB CS Homepage (www.cs.berkeley.edu)"));
      p.addNode(new Node("Computer Science Research at UC Berkeley (www.cs.berkeley.edu/Research)"));
      p.addNode(new Node("Cha-Cha (www.cs.berkeley.edu/Research/cha-cha)"));
      p.addNode(new Node("Mike Chen (www.cs.berkeley.edu/~mikechen/)"));
      root.addPath(p);

      p = new Path();
      p.addNode(new Node("UCB CS Homepage (www.cs.berkeley.edu)"));
      p.addNode(new Node("Computer Science Research at UC Berkeley (www.cs.berkeley.edu/Research)"));
      p.addNode(new Node("Arcade (www.cs.berkeley.edu/~sequin/arcade.html)"));
      root.addPath(p);

      p = new Path();
      p.addNode(new Node("UCB CS Homepage (www.cs.berkeley.edu)"));
      p.addNode(new Node("Computer Science Faculty (www.cs.berkeley.edu/Faculty/)"));
      p.addNode(new Node("James Landay (www.cs.berkeley.edu/~landay/)"));
      root.addPath(p);

      p = new Path();
      p.addNode(new Node("UCB CS Homepage (www.cs.berkeley.edu)"));
      p.addNode(new Node("Computer Science Faculty (www.cs.berkeley.edu/Faculty/)"));
      p.addNode(new Node("Steve McCanne (www.cs.berkeley.edu/~mccanne/)"));
      root.addPath(p);

      p = new Path();
      p.addNode(new Node("SIMS Homepage (www.sims.berkeley.edu)"));
      p.addNode(new Node("SIMS Faculty (www.sims.berkeley.edu/Faculty/)"));
      p.addNode(new Node("Marti Hearst (www.sims.berkeley.edu/~hearst/)"));
      root.addPath(p);

      root.printReverseOrderTraversal();
      System.out.println();
      System.out.println();
      root.printTraversal();

   } // of main
*/
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
