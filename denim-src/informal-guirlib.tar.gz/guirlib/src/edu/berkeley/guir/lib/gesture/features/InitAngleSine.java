package edu.berkeley.guir.lib.gesture.features;

import java.lang.Math;
import java.awt.Polygon;
import edu.berkeley.guir.lib.gesture.*;

/**
 * Sine of the initial angle
 */
public class InitAngleSine extends Feature {
  public double minValue = -1;
  public double maxValue = 1;
  
  public InitAngleSine()
  {
    super();
  }

  public InitAngleSine(Gesture g)
  {
    super(g);
  }

  protected void computeValue()
  {
    Polygon p = gesture.getPointsRef();

    if (p.npoints < 3) {
      value = 0;
    }
    else {
      double x0 = p.xpoints[0];
      double y0 = p.ypoints[0];
      double x2 = p.xpoints[2];
      double y2 = p.ypoints[2];
      double hypot = Math.sqrt((x2-x0)*(x2-x0) + (y2-y0)*(y2-y0));
      value = (hypot == 0) ? 0 : (y2 - y0) / hypot;
    }
    valueOk = true;
  }

  public double getMinValue()
  {
    return minValue;
  }
  
  public double getMaxValue()
  {
    return maxValue;
  }

  public String getName()
  {
    return new String("sine of initial angle");
  }

  /**
   * This is not necessarily the ideal way to scale the sine,
   * but it's a start.
   */
  public void scale(double factor)
  {
    gesture.normalize();
    TimedPolygon points = gesture.getPoints();

    double delta = (points.xpoints[2] - points.xpoints[0]) * factor;
    points.xpoints[0] += delta;

    gesture.setPoints(points);
  }
}
