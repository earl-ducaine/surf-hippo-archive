	/*-------------------------------------------------------------
	|
	|	PROGRAM:
	|
	|	MODULE:   %W%
	|
	|	RELATED
	|	MODULES:
	|
	|	MACHINE:  UNIX   
	|
	|	STARTED:  08-JAN-91  BY:  J.C. Wathey
	|
	|	REVISED:  %G%   BY:  JCW       
	|
	|	STATUS:      incomplete or untested
	|                    compiles; partly tested
	|                    runs; revisions in progress
	|                 -> runs; stable version
	|
	|       CONTAINS: function declarations
	|
	|
	-------------------------------------------------------------*/


void free_memory();

