package edu.berkeley.guir.damask.event;

import java.util.EventListener;

/** 
 * The listener interface for receiving events regarding a change in a control. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-01-2004 James Lin
 *                               Created ControlListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-01-2004
 */
public interface ControlVoiceListener extends EventListener {

   /**
    * Invoked when the text of a control's voice prompt has changed.
    */
   void promptTextChanged(ControlVoiceEvent e);

   /**
    * Invoked when the bounds of a control's voice prompt has changed.
    */
   void promptBoundsChanged(ControlVoiceEvent e);

   /**
    * Invoked when the source of a control's voice response has changed.
    */
   void responseSourceChanged(ControlVoiceEvent e);
   
   /**
    * Invoked when the destination of a control's voice response has changed.
    */
   void responseDestChanged(ControlVoiceEvent e);
   
   /**
    * Invoked when the line of a control's voice response has changed.
    */
   void responseLineChanged(ControlVoiceEvent e);
   
   /**
    * Invoked when the text of a control's voice response has changed.
    */
   void responseTextChanged(ControlVoiceEvent e);
}
