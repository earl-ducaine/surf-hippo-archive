package edu.berkeley.guir.lib.gesture.features;

import edu.berkeley.guir.lib.gesture.*;
import java.awt.Polygon;
import java.lang.Math;

/**
 * The sum of the square of absolute value of the angle at each point.
 */
public class TotalAbsAngle extends Feature {
  public final double minValue = 0;
  public final double maxValue = Double.POSITIVE_INFINITY;
  
  public TotalAbsAngle()
  {
    super();
  }

  public TotalAbsAngle(Gesture g)
  {
    super(g);
  }

  public String getName()
  {
    return new String("total absolute angle");
  }

  /**
   * Return maximum value this feature can have
   */
  public double getMinValue()
  {
    return minValue;
  }
  
  /**
   * Return minimum value this feature can have
   */
  public double getMaxValue()
  {
    return maxValue;
  }

  /**
   * Non-incremental computation.  Should set value to new value and
   * valueOk to true.
   */
  protected void computeValue()
  {
    Polygon points = gesture.getPointsRef();
    value = 0;
    for (int i = 2; i < points.npoints; i++) {
      double dx = points.xpoints[i] - points.xpoints[i-1];
      double dy = points.ypoints[i] - points.ypoints[i-1];
      double dx2 = points.xpoints[i-1] - points.xpoints[i-2];
      double dy2 = points.ypoints[i-1] - points.ypoints[i-2];
      double theta = Math.atan2(dx*dy2 - dx2*dy, dx*dx2 + dy*dy2);
      value += Math.abs(theta);
    }
    valueOk = true;
  }

  /**
   * Change @gesture so that the feature changes (ideally by the
   * scale factor).
   */
  public void scale(double factor)
  {
    // todo
  }
}
