//// See bottom of source code for software license

package edu.berkeley.guir.denim.command;

import java.awt.geom.*;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.awt.geom.*;

/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Nov 18, 2003 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class ResizeCommand extends UndoableCommand {
	
	GraphicalObject mResizedGob;
	Rectangle2D		 mOldRelBounds;
	Rectangle2D     mNewRelBounds;	
	
	public ResizeCommand(GraphicalObject gob, Rectangle2D newRelBounds) {
		this.mResizedGob = gob;
		mOldRelBounds = this.mResizedGob.getBounds2D(COORD_REL);
		mNewRelBounds = (Rectangle2D)newRelBounds.clone();	
	} // of constructor

	//===========================================================================
	//===   NAME ACCESSOR METHODS   =============================================

	public String getPresentationName() {
		return ("resize ");
	} // of getPresentationName

	//===   NAME ACCESSOR METHODS   =============================================
	//===========================================================================



	//===========================================================================
	//===   COMMAND   ===========================================================

	/**
	 * Notifies the command system that this command can be undone.
	 */
	public boolean canRedo() {
		return true;
	} // of method

	//-----------------------------------------------------------------

	public void run() {
		
		if(this.mResizedGob instanceof DenimPanel)
		{
			DenimPanel panel = (DenimPanel)mResizedGob;
			
			panel.getSheet().disableDamage();
            panel.getRenderCache().setCacheInvalide();
            
			panel.moveTo(COORD_REL, new Point2D.Double(
							this.mNewRelBounds.getMinX(), 
							this.mNewRelBounds.getMinY()));
			panel.getSheet().enableDamage();
			
			Rectangle2D box = (Rectangle2D)this.mNewRelBounds.clone();
			
			box = GeomLib.transformRectangle(
								panel.getSheet().getTransform(COORD_ABS), box);

			// minus label height
			double h = panel.getLabel().getHeight2D(COORD_ABS);
			box.setFrame(box.getMinX(), box.getMinY()+h, box.getWidth(), box.getHeight()-h);
						
			try
			{
				AffineTransform tr = panel.getSketch().getTransform(COORD_ABS);
				Point2D newLT = new Point2D.Double();
				Point2D newRB = new Point2D.Double();
				tr.inverseTransform(new Point2D.Double(box.getMinX(), box.getMinY()), newLT); 
				tr.inverseTransform(new Point2D.Double(box.getMaxX(), box.getMaxY()), newRB);
				box.setFrameFromDiagonal(newLT, newRB);
			}
			catch(Exception ex) 
			{
							
			}
			/*	
			Rectangle2D oldBox = panel.getSketch().getView().getBoundingPoints2DRef().getBounds2D();
			
			System.out.println(oldBox.toString());
			System.out.println(panel.getSketch().getBounds2D(COORD_LOCAL));
			System.out.println(this.mOldResizingBounds.toString());
			*/
			box.setFrame(0,0,box.getWidth(),box.getHeight());
			panel.getSketch().getView().setBoundingPoints2DRef(this.getPolygon2D(box));
			
			panel.damage(DAMAGE_NOW);
		}
		/*else if(this.mResizedGob instanceof DenimTextFieldInstance) 
		{
			GObJComponentWrapper wrapper = ((DenimTextFieldInstance)mResizedGob).getJCWrapper();
			JTextField tf = ((DenimTextFieldInstance)mResizedGob).getJTextField();
			if (tf != null) 
			{
				Point2D p = getNewDimension(oldBounds, pt, tf.getWidth(), tf.getHeight());
				if ((p.getX() >= tf.getWidth() && p.getY() >= tf.getHeight()) ||
						(p.getX() >= 15 && p.getY() >= 15)) 
				{
					tf.setBounds(0,0,(int)p.getX(),(int)p.getY());
				}
			}
		}*/
		else
		{
			if (mResizedGob.getResizeMode() == SatinConstants.RESIZE_STRETCH) 
			{
				mResizedGob.applyTransform(AffineTransformLib.resize(this.mOldRelBounds, this.mNewRelBounds));
			}
			else 
			{
				mResizedGob.setBoundingPoints2D(COORD_ABS, this.mNewRelBounds);
			}
            
            if(mResizedGob instanceof GraphicalObjectImpl)
                ((GraphicalObjectImpl)mResizedGob).getRenderCache().setCacheInvalide();
		}
	}

	//-----------------------------------------------------------------
	
	private Polygon2D getPolygon2D(Rectangle2D box) {
		
		Polygon2D pl = new Polygon2D();
				
		pl.addPoint(box.getMinX(),box.getMinY());
		pl.addPoint(box.getMinX(),box.getMaxY());
		pl.addPoint(box.getMaxX(),box.getMaxY());
		pl.addPoint(box.getMaxX(),box.getMinY());
		pl.setClosed(true);
		
		return pl;
	}
	
	//-----------------------------------------------------------------

	public void redo() {
		run();
	}

	//-----------------------------------------------------------------

	public void undo() {
	
		super.undo();
		
		if(this.mResizedGob instanceof DenimPanel)
		{
			DenimPanel panel = (DenimPanel)mResizedGob;
			
			panel.getSheet().disableDamage();
			panel.moveTo(COORD_REL, new Point2D.Double(
							this.mOldRelBounds.getMinX(), 
							this.mOldRelBounds.getMinY()));
			panel.getSheet().enableDamage();
			
			Rectangle2D box = (Rectangle2D)this.mOldRelBounds.clone();
			
			box = GeomLib.transformRectangle(
								panel.getSheet().getTransform(COORD_ABS), box);

			// minus label height
			double h = panel.getLabel().getHeight2D(COORD_ABS);
			box.setFrame(box.getMinX(), box.getMinY()+h, box.getWidth(), box.getHeight()-h);
			box = ResizeCommand.inverseTransformRectangle(panel.getSketch().getTransform(COORD_ABS), box);			
			
			box.setFrame(0,0,box.getWidth(),box.getHeight());
			panel.getSketch().getView().setBoundingPoints2DRef(this.getPolygon2D(box));
		}
/*		else if(this.mResizedGob instanceof DenimTextFieldInstance) 
		{
			GObJComponentWrapper wrapper = ((DenimTextFieldInstance)mResizedGob).getJCWrapper();
			JTextField tf = ((DenimTextFieldInstance)mResizedGob).getJTextField();
			if (tf != null) 
			{
				Point2D p = getNewDimension(oldBounds, pt, tf.getWidth(), tf.getHeight());
				if ((p.getX() >= tf.getWidth() && p.getY() >= tf.getHeight()) ||
						(p.getX() >= 15 && p.getY() >= 15)) 
				{
					tf.setBounds(0,0,(int)p.getX(),(int)p.getY());
				}
			}
		}*/
		else
		{
			if (mResizedGob.getResizeMode() == SatinConstants.RESIZE_STRETCH) 
			{
				mResizedGob.applyTransform(AffineTransformLib.resize(this.mNewRelBounds, this.mOldRelBounds));
			}
			else 
			{
				mResizedGob.setBoundingPoints2D(COORD_ABS, this.mOldRelBounds);
			}
		}
		
		mResizedGob.damage(DAMAGE_NOW);

	}
	
	public static Rectangle2D inverseTransformRectangle(AffineTransform tr, Rectangle2D box) {
		Rectangle2D newBox = new Rectangle2D.Double();
		
		try
		{
			Point2D newLT = new Point2D.Double();
			Point2D newRB = new Point2D.Double();
			tr.inverseTransform(new Point2D.Double(box.getMinX(), box.getMinY()), newLT); 
			tr.inverseTransform(new Point2D.Double(box.getMaxX(), box.getMaxY()), newRB);
			newBox.setFrameFromDiagonal(newLT, newRB);
		}
		catch(Exception ex) 
		{
			newBox = (Rectangle2D)box.clone();
		}
		return newBox;
	}
}


//==============================================================================

/*
Copyright (c) 2003 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User 
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/