package edu.berkeley.guir.denim;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
/**
 * @author Andrew Cuneo
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class Scenario {
   String title;
   Time time;
   LinkedList nodes;

   public Scenario() {
      this("Untitled", new Time("0:00"));
   }
   
   public Scenario(String title) {
      this(title, new Time("0:00"));
   }

   public Scenario(String title, String time) {
      this(title, new Time(time));
   }
   
   
   public Scenario(String title, int time) {
      this(title, new Time(time));            
   }
   
   public Scenario(String title, long time) {
      this(title, new Time(time));
   }   
   
   //main constructor
   public Scenario(String title, Time t) {
      this.title = title;
      this.time = t;  
      nodes = new LinkedList();
   }
   

   public int size() { 
      return nodes.size(); 
   }   

   public static class Time {
      private String dataRight;
      private String dataLeft;
      private long mSecValue;
      public static final int timeMinPrecision = 2;
      public static final int timeMaxPrecision = 2;
      public static final int timeMaxSecDigits = 3;
      public static final int timeMinSecDigits = 0;

      /*
       * takes strings and determines if they are of type:
       * ddd:dd or d:dd
       * as in:
       * tens of seconds seconds : Tenths of seconds hundreths of seconds
       */
      public Time(String t) {
         if (t.length() > (timeMinSecDigits + timeMinPrecision+1)
            && t.length() < (timeMaxPrecision + timeMaxSecDigits+1)) {
            this.dataRight = parseLower(t);
            this.dataLeft = parseUpper(t);
            this.mSecValue = Integer.valueOf(dataLeft).intValue() * 1000 + Integer.valueOf(dataRight).intValue()*10;
         }
      }  
      
      public Time(int miliValue) {   
          updateStringValues((long) miliValue);
          mSecValue = (long) miliValue; 
      }
      
      public Time(long miliValue){
          updateStringValues(miliValue);
          mSecValue = miliValue; 
      }
      
      public void adjustValue(long adjVal) {
         mSecValue += adjVal;
         updateStringValues(mSecValue);         
      }

      public long getDiff(Time t) {
         return mSecValue - t.mSecValue;
      }
      
      public void updateStringValues(long newValue) {
          dataLeft = String.valueOf(newValue / 1000); 
          long k = (newValue - (newValue / 1000)*1000);
         k = k / 10;
         if(k < 10) 
            dataRight = '0'+String.valueOf(k);
         else
            dataRight = String.valueOf(k);
    
      }
               
      public String parseUpper(String toCheck) {
         int k = 0;
         char c='\0'; 
         String toRet = "";
         while(k < toCheck.length()) {
            c = toCheck.charAt(k);
            if(c == ':') break;
            else if(!Character.isDigit(c)) return null;
            k++;
            toRet += c;
         }
         if((k < timeMinSecDigits || k > timeMaxSecDigits) ||
         (k == toCheck.length() && c != ':'))
            return null;
          return toRet;     
      }
      
      
      public String parseLower(String toCheck) {
         int k = toCheck.indexOf(':');
         char c = '\0';
         String toRet = "";
         if((toCheck.length()-k)-1 < timeMinPrecision ||
         (toCheck.length()-k)-1 > timeMaxPrecision)
         return null;
         k++;
         while(k < toCheck.length()) {
            c = toCheck.charAt(k);
            if(!Character.isDigit(c)) return null;
            k++;
            toRet += c;
         }
         return toRet;
      }
            
      public boolean isTimeFormat() {    
         return (dataRight != null && dataLeft != null); 
      }
      
      public String toString() {
         return dataLeft+":"+dataRight;  
      }
      
      public String toStringSec() {
         return String.valueOf(mSecValue);
      }
      
      public long getMSec() {
         return mSecValue;  
      }
   }

   public String getTitle() {
      return title;
   }

   public String getStringTime() {
      return time.toString();
   }

   public String getMiliTime() {
      return time.toStringSec();
   }
   
   public long getLongTime() {
      return time.getMSec();
   }
   
   public Time getTime() {
      return this.time;
   }
   
   public List getNodes() {
      return nodes;
   }

   public void setTitle(String title) {
      this.title = title;
   }
   
   public void setTime(Time time) {
      this.time = time;
   }

   public void adjustTime(long value) {
      time.adjustValue(value);   
   }
   
   public void validateTime() {
      Time t = new Time(0);
      for(Iterator i = nodes.iterator(); i.hasNext(); ) {
         t.adjustValue(((ScenarioNode)i.next()).getTime().mSecValue); 
      }
      this.time = t;  
   }
   
   public void setNodes(LinkedList nodes) {
      this.nodes = nodes;
   }

   public Iterator iterator() {
      return nodes.iterator();
   }

   public Scenario deepClone() {
      return deepClone(this.getTitle());
   }

   public Scenario deepClone(String name) {
      String cloneName;
      if (name == null)
         cloneName = this.getTitle() + " copy";
      else
         cloneName = name;
      Scenario toRet = new Scenario(cloneName, new Scenario.Time(time.getMSec()));
      Iterator it = nodes.iterator();
      while (it.hasNext())
         toRet.nodes.add(((ScenarioNode) it.next()).deepClone());
      return toRet;
   }

   /*
   //the linkedlist is supposed to contain items of this class
   public static class ScenarioNode {
      private DenimPanel panel;
      private String time;

      public ScenarioNode() {

      }

      public ScenarioNode(DenimPanel panel, String time) {
         this.panel = panel;
         this.time = time;
      }

      public String getTime() {
         return time;
      }

      public DenimPanel getPanel() {
         return panel;
      }

      public boolean setTime(String time) {
         if(isTimeFormat(time)) {
            this.time = time;
            return true;
         } else
            return false;
      }

      public void setPanel(DenimPanel panel) {
         this.panel = panel;
      }

      public ScenarioNode deepClone() {
         return new ScenarioNode(this.panel, this.time);
      }
   }
   */
}
