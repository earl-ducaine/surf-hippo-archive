package edu.berkeley.guir.damask.command;

import java.awt.geom.GeneralPath;
import java.awt.geom.NoninvertibleTransformException;
import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that adds a stroke to a piece of content.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-14-2003 James Lin
 *                               Created AddStrokeCommand.
 *             2.0.0  01-07-2004 James Lin
 *                               Now adds stroke to existing content, instead
 *                               of creating content.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-14-2003
 */
public class GroupStrokesCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final Collection/*<Content>*/ contents;
   private final Map/*<Content, Map<PageRegion, Integer>>*/
      contentsRegions = new HashMap/*<Content, Map<PageRegion, Integer>>*/();
   private final DeviceType deviceType;
   private Content newContent;

   /**
    * Constructs the command.
    *  
    * @param contents    the collection of Content to group together
    * @param deviceType  the device type which determines the location
    * of the strokes in the merged content
    */      
   public GroupStrokesCommand(
      final Collection/*<Content>*/ contents, final DeviceType deviceType) {
      
      this.contents = contents;
      this.deviceType = deviceType;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Combined strokes in " + contents + " relative to " + deviceType;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      if (contents.size() <= 1) {
         return;
      }
      
      final Content firstContent;
      {
         final Iterator i = contents.iterator();
         firstContent = (Content)i.next();
         newContent = (Content)firstContent.clone();
         
         while (i.hasNext()) {
            final Content content = (Content)i.next();
            for (Iterator j = content.getStrokes().iterator(); j.hasNext(); ) {
               final GeneralPath path = (GeneralPath)j.next();
               final GeneralPath newPath = (GeneralPath)path.clone();
               newPath.transform(content.getTransform(deviceType));
               try {
                  newPath.transform(
                     newContent.getTransform(deviceType).createInverse());
               }
               catch (NoninvertibleTransformException e) {
                  // should never happen
                  DamaskAppExceptionHandler.log(e);
               }
               newContent.addStroke(newPath);
            }
         }
      }

      for (Iterator i = contents.iterator(); i.hasNext(); ) {
         final Content content = (Content)i.next();
         final Map/*<PageRegion, Integer>*/ regionPositions =
            new HashMap/*<PageRegion, Integer>*/();
         for (Iterator j = content.getDeviceTypesVisibleTo().iterator();
              j.hasNext(); ) {
            final DeviceType aDeviceType = (DeviceType)j.next();
            final PageRegion aRegion = content.getPageRegion(aDeviceType);
            regionPositions.put(
               aRegion, new Integer(aRegion.getControls().indexOf(content)));
         }
         contentsRegions.put(content, regionPositions);
      }
      
      firstContent.getDialog().addControl(
         (Map)contentsRegions.get(firstContent), newContent);
      
      for (Iterator i = contents.iterator(); i.hasNext(); ) {
         final Content content = (Content)i.next();
         content.getDialog().removeControl(content);
      }
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      final Dialog dialog = newContent.getDialog();
      dialog.removeControl(newContent);

      for (Iterator i = contents.iterator(); i.hasNext(); ) {
         final Content content = (Content)i.next();
         dialog.addControl((Map)contentsRegions.get(content), content);
      }
   }
}
