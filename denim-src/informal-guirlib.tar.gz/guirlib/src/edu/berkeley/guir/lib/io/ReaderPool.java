//// See bottom of file for software license
package edu.berkeley.guir.lib.io;

import java.io.FileReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import edu.berkeley.guir.lib.util.Pollable;
import edu.berkeley.guir.lib.util.PollingPool;

/**
 * A pool for polling a collection of Readers.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Aug 11 2002, JH
 */
public class ReaderPool {

    //==========================================================================
    //===   INNER CLASS   ======================================================

    /**
     * A wrapper for Readers.
     */
    class PollableReader implements Pollable {
        Reader rdr;

        public PollableReader(Reader newRdr) {
            rdr = newRdr;
        } // of method

        public boolean isReady() {
            try {
               return (rdr.ready());
            }
            catch (Exception e) {
                e.printStackTrace(System.err);
                return (false);
            }
        } // of method

        public void onReady() {
            fireEvent(rdr);
        } // of method
    } // of inner class

    //===   INNER CLASS   ======================================================
    //==========================================================================






    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    PollingPool pool               = new PollingPool();
    Map         mapReadersPollable = new HashMap();  // Reader -> PollableReader

    //----------------------------------------------------------------

    List listListeners    = new LinkedList();  // list of listeners
    List listListenersTmp = new LinkedList();  // dummy iterator collection

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================






    //==========================================================================
    //===   READER COLLECTION METHODS   ========================================

    public void addReader(Reader rdr) {
        PollableReader pr = new PollableReader(rdr);

        pool.add(pr);
        mapReadersPollable.put(rdr, pr);
    } // of method

    //----------------------------------------------------------------

    public void removeReader(Reader rdr) {
        PollableReader pr = (PollableReader) mapReadersPollable.get(rdr);
        if (pr != null) {
            pool.remove(pr);
        }
    } // of method

    //----------------------------------------------------------------

    public void clearReaders() {
        pool.clear();
    } // of method

    //----------------------------------------------------------------

    public Iterator readers() {
        return (pool.iterator());
    } // of method

    //----------------------------------------------------------------

    public Set getReaders() {
        return (pool.getPollables());
    } // of method

    //===   READER COLLECTION METHODS   ========================================
    //==========================================================================






    //==========================================================================
    //===   LISTENER COLLECTION METHODS   ======================================

    public void addReaderPoolListener(ReaderPoolListener l) {
        listListeners.add(l);
    } // of method

    //----------------------------------------------------------------

    public void removeReaderPoolListener(ReaderPoolListener l) {
        listListeners.remove(l);
    } // of method

    //----------------------------------------------------------------

    public void clearReaderPoolListeners() {
        listListeners.clear();
    } // of method

    //----------------------------------------------------------------

    /**
     * Notify all listeners that this Reader has data to be read.
     */
    private void fireEvent(Reader rdr) {
        // System.out.println("firing ready event to Reader...");

        //// 1. Use a temp to avoid potential ConcurrentModification errors
        listListenersTmp.clear();
        listListenersTmp.addAll(listListeners);

        Iterator           it = listListenersTmp.iterator();
        ReaderPoolListener l;

        //// 2. Notify all.
        while (it.hasNext()) {
            l = (ReaderPoolListener) it.next();
            l.onData(rdr);
        }
    } // of method

    //===   LISTENER COLLECTION METHODS   ======================================
    //==========================================================================






    //==========================================================================
    //===   REGRESSION TESTS   =================================================

    public static void main(String[] argv) throws Exception {
        ReaderPool p = new ReaderPool();
        p.addReaderPoolListener(ReaderPoolListener.CONSOLE);

        Thread.sleep(2000);

        Reader rAA = new FileReader("ReaderPool.java");
        Reader rBB = new FileReader("ReaderPoolListener.java");

        p.addReader(rAA);
        Thread.sleep(2000);
        p.addReader(rBB);
    } // of main

    //===   REGRESSION TESTS   =================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2002 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
