package edu.berkeley.guir.damask.component;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.Iterator;
import java.util.List;

import edu.berkeley.guir.damask.Damask;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.event.ControlVoiceEvent;
import edu.berkeley.guir.damask.event.ControlVoiceListener;
import edu.berkeley.guir.damask.view.visual.component.RadioButton;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.collection.Map2D;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * A select one control, which represents a list of choices that can be
 * made by the end user, but only one choice can be selected at a time.
 * This can be rendered as a set of radio buttons, a drop-down box, or
 * a list box. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-30-2003 James Lin
 *                               Created SelectOne
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 04-30-2003
 */
public class SelectOne extends Select {
   private static final String DEFAULT_VOICE_CAPTION =
      "Please say one of the following: $items";

   //---------------------------------------------------------------------------
   
   /**
    * Constructs a select-one control.
    * 
    * @param deviceType the device type that this control supports. Can be
    * DeviceType.ALL.
    */
   public SelectOne(final DeviceType deviceType) {
      super(deviceType);
      init();
      if (isVisibleToDeviceType(DeviceType.VOICE)) {
         setStyle(DeviceType.VOICE, MINIMAL);
      }
   }

   
   /**
    * Constructs a select-one control, copying properties from the specified
    * select-one control.
    * 
    * @param selectOne the existing select-one control whose properties will
    * be copied
    * @param deviceType the device type that this control supports. Can be
    * DeviceType.ALL.
    */
   public SelectOne(final SelectOne selectOne, final DeviceType deviceType) {
      super(selectOne, deviceType);
      init();
      
      for (Iterator i = selectOne.getItems().iterator(); i.hasNext(); ) {
         final SelectOne.Item item = (SelectOne.Item)i.next();
         final SelectOne.Item newItem = new SelectOne.Item(item, deviceType); 
         addItem(newItem);
         replaceStates(item, newItem);
      }
   }


   private void init() {
      //setVoicePromptText(DEFAULT_VOICE_CAPTION);
   }

   // @Override
   protected void autoPositionForVoice() {
   }
   
   // @Override
   protected void setupVoiceResponses() {
      setupVoiceResponseForControlWithResponseOnly();
   }
   
   // Overrides method in Control class.
   public Object getDefaultState() {
      final List/*<Select.Item>*/ items = getItems();
      if (items.size() >= 1) {
         return items.get(0);
      }
      return null;
   }

   
   /**
    * Replace all states that are equal to the specified state with the
    * first item of this control.
    */   
   private void replaceStatesWithDefaultState(
      final SelectOne.Item stateToReplace) {
      
      final SelectOne.Item defaultState = (SelectOne.Item)getDefaultState();
      final Dialog dialog = getDialog();
      if (dialog != null) {
         for (int j = 0, n = dialog.getNumConditions(); j < n; j++) {
            if (getStateForCondition(dialog, j) == stateToReplace) {
               setStateForCondition(dialog, j, defaultState);
            }
         }
      }
   }
   
   // @Override
   public void addItem(final int index, final Select.Item item) {
      super.addItem(index, item);
      replaceStatesWithDefaultState(null);
      addVoiceResponseText(index, item.getContent().getVoicePromptText());
   }

   // @Override
   public Select.Item removeItem(final int index) {
      final SelectOne.Item removedItem =
         (SelectOne.Item)super.removeItem(index);
      replaceStatesWithDefaultState(removedItem);
      removeVoiceResponseText(index);
      return removedItem;
   }


   // Overrides method in parent class.
   public Component createCopy(DeviceType deviceType) {
      return new SelectOne(this, deviceType);
   }

   
   /**
    * Replaces any state that is equal to item with newItem.
    */ 
   private void replaceStates(
      final SelectOne.Item oldItem, final SelectOne.Item newItem) {

      for (Iterator i = getDialogsWithState().iterator(); i.hasNext(); ) {
         final Dialog dialog = (Dialog)i.next();
         for (int cond = 0, n = dialog.getNumConditions(); cond < n; cond++) {
            final SelectOne.Item state =
               (SelectOne.Item) getStateForCondition(dialog, cond);
            if (state.equals(oldItem)) {
               setStateForCondition(dialog, cond, newItem);
            }
         }
      }
   }

   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      final SelectOne clone = (SelectOne)super.clone();
      
      for (Iterator i = clone.getItems().iterator(); i.hasNext(); ) {
         final SelectOne.Item newItem = (SelectOne.Item)i.next();
         final SelectOne.Item oldItem =
            (SelectOne.Item)newItem.getCloneSourceIfAlive(); 
         clone.replaceStates(oldItem, newItem);
      }
      
      return clone;
   }

   //---------------------------------------------------------------------------

   public static class Item extends Select.Item {
      private static final Map2D/*<DeviceType, Style, Inset>*/ defaultInsets =
         new Map2D/*<DeviceType, Style, Inset>*/();

      // Initialize default insets
      static {
         final Insets2D visualFullInsets;
         {
            final PNode defaultView = RadioButton.createTempView();
            final Rectangle2D bounds = defaultView.getBounds();
            final PPath captionPath = (PPath)defaultView.getChild(1);

            final Rectangle2D captionPathBounds =
               captionPath.getPathReference().getBounds2D();
            final AffineTransform captionPathTransform = captionPath.getTransform();

            final Rectangle2D captionPathBoundsInItemCoords =
               GeomLib.transformRectangle(captionPathTransform, captionPathBounds);

            visualFullInsets =
               new Insets2D(
                  captionPathBoundsInItemCoords.getY() - bounds.getY(),
                  captionPathBoundsInItemCoords.getX() - bounds.getX(),
                  bounds.getMaxY() - captionPathBoundsInItemCoords.getMaxY(),
                  bounds.getMaxX() - captionPathBoundsInItemCoords.getMaxX());
         }
         
         final Insets2D emptyInsets = new Insets2D(0, 0, 0, 0);
         
         for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
              i.hasNext(); ) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            for (Iterator j = Select.getSupportedStyles().iterator();
                 j.hasNext(); ) {
               final Style aStyle = (Style)j.next();
               defaultInsets.put(aDeviceType, aStyle, emptyInsets);
            }
         }
         
         defaultInsets.put(DeviceType.DESKTOP, FULL, visualFullInsets);
         defaultInsets.put(DeviceType.SMARTPHONE, FULL, visualFullInsets);
      }


      public Item(final Content content) {
         super(content);
         init();
      }

      public Item(final Item item, final DeviceType deviceType) {
         super(item, deviceType);
         init();
      }

      private void init() {
         final ControlVoiceHandler voiceHandler = new ControlVoiceHandler();
         getContent().addControlVoiceListener(voiceHandler);
      }

      // @Override
      public Component createCopy(final DeviceType deviceType) {
         return new Item(this, deviceType);
      }
      
      // @Override
      public Insets2D getDefaultInsets(
         final DeviceType deviceType, final Style style) {
         
         return (Insets2D)defaultInsets.get(deviceType, style);
      }

      // @Override
      protected void autoPositionForVoice() {
      }
      
      // @Override
      protected void setupVoiceResponses() {
      }

      // @Override
      protected void updateVoiceDisplayProperties() {
      }

      
      // Overrides method in ancestor class.
      public Object clone() {
         final Item clone = (Item)super.clone();
         if (getContent() != null) {
            clone.setContent((Content)getContent().clone());
            final ControlVoiceHandler cloneVoiceHandler =
               clone.new ControlVoiceHandler();
            clone.getContent().addControlVoiceListener(cloneVoiceHandler);
         }
         return clone;
      }
      
      private class ControlVoiceHandler implements ControlVoiceListener {

         // @Override
         public void promptTextChanged(ControlVoiceEvent e) {
            if (e.getControl() == getContent()) {
               if (getParent() != null) {
                  final SelectOne parent = (SelectOne)getParent();
                  parent.setVoiceResponseText(
                     parent.getItems().indexOf(SelectOne.Item.this),
                     getContent().getVoicePromptText());
               }
            }
         }

         // @Override
         public void promptBoundsChanged(ControlVoiceEvent e) {
         }

         // @Override
         public void responseSourceChanged(ControlVoiceEvent e) {
         }

         // @Override
         public void responseDestChanged(ControlVoiceEvent e) {
         }

         // @Override
         public void responseLineChanged(ControlVoiceEvent e) {
         }

         // @Override
         public void responseTextChanged(ControlVoiceEvent e) {
         }
      }
   }
}
