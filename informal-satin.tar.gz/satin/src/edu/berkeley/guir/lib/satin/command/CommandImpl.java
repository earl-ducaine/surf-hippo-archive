//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import java.util.*;
import javax.swing.undo.*;
import java.io.Serializable;
import edu.berkeley.guir.lib.collection.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.Sheet;

/**
 * A simple implementation of Command.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jun 22 1999, JH
 *               Created class
 *             - SATIN-v1.0-1.1.0, Dec 09 1999, JH
 *               Updated CommandImpl for SATINv2.
 *               Modified the enable/disable to be a counting semaphore.
 *               Renamed doit() to run().
 *               Made commands that can execute() themselves.
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public abstract class CommandImpl
   implements Command, Serializable {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long  serialVersionUID = 6720549862372374770L; 

   //===   CONSTANTS   =========================================================
   //===========================================================================

   //===========================================================================
   //===   CLASS METHODS AND VARIABLES   =======================================

   /**
    * Data structure for checking if a command is enabled or not.
    * A command is enabled if it has a count of 0 or is not in the bag.
    * A command is disabled if it has a positive count.
    */
   static HashBag enabledCounter = new HashBag();

   //-----------------------------------------------------------------

   private boolean isEnabled(String strClassName) {
      int count = enabledCounter.size(strClassName);
      if (count < 0) {
         throw new RuntimeException("Unbalanced number of enable / disable");
      }
      return (count == 0);
   } // of isEnabled

   private void enable(String strClassName) {
      enabledCounter.remove(strClassName);
   } // of enable

   private void disable(String strClassName) {
      enabledCounter.add(strClassName);
   } // of disable

   //-----------------------------------------------------------------

   /**
    * This method is implemented for all subclasses in the superclass.
    */
   public final boolean isEnabled() {
      return (isEnabled(getClass().getName()));
   } // of isEnabled

   //-----------------------------------------------------------------

   /**
    * This method is implemented for all subclasses in the superclass.
    */
   public final boolean isDisabled() {
      return ( !isEnabled());
   } // of isDisabled

   //-----------------------------------------------------------------

   /**
    * This method is implemented for all subclasses in the superclass.
    */
   public void enable() {
      enable(getClass().getName());
   } // of enable

   //-----------------------------------------------------------------

   /**
    * This method is implemented for all subclasses in the superclass.
    */
   public void disable() {
      disable(getClass().getName());
   } // of disable

   //===   CLASS METHODS AND VARIABLES   =======================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   long executionTime;          // the system time first executed

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   QUEUED COMMANDS   ===================================================

   public boolean addEdit(UndoableEdit anEdit) {
      return (false);
   } // of addEdit

   //-----------------------------------------------------------------

   public boolean replaceEdit(UndoableEdit anEdit) {
      return (false);
   } // of replaceEdit

   //===   QUEUED COMMANDS   ===================================================
   //===========================================================================



   //===========================================================================
   //===   TIME METHODS   ======================================================

   public void setExecutionTime() {
      setExecutionTime(System.currentTimeMillis());
   } // of setExecutionTime

   //-----------------------------------------------------------------

   public void setExecutionTime(long l) {
      this.executionTime = l;
   } // of setExecutionTime

   //-----------------------------------------------------------------

   public long getExecutionTime() {
      return (executionTime);
   } // of getExecutionTime

   //===   TIME METHODS   ======================================================
   //===========================================================================

   
   
   
   //===========================================================================
   //===   HISTORY METHODS  =============================================

   public Iterator getOperands() {
		return (new LinkedList()).iterator();
   }
   
   public boolean isOperand( Object o ) {
		Iterator i = getOperands();
		
		while (  i.hasNext() ) {
			if ( i.next().equals( o ) )
				return true;
		}
		
		return false;
   }
   
   protected Object m_author = null;
   
   public void setAuthor( Object author ) {
        m_author = author;
   }
   
   public Object getAuthor() {
        return m_author;
   }

   protected String m_device = "";
   
   public void setDevice( String device ) {
        m_device = device;
   }
   
   public String getDevice() {
      return m_device;
   }
   
   // wrapXML and toXML are specified in the subclasses
   public String getWrappedXML() {
      return wrapXML(toXML());  
   }
   
   // a dummy xml representation; override in your subclass
   protected String toXML() {
        return "<"+getClass()+"></"+getClass()+">";
   }
   
   // called by the subclass's toXML method when serializing commands
   protected String wrapXML(String wrapMe) {
        return "<"+getTagName()+">" + wrapMe + "</"+getTagName()+">";
   }
   
   protected String getTagName() {
      return "CMD";  
   }
   
   
   //===   HISTORY METHODS   ======================================================
   //===========================================================================





   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   /**
    * Override this method in the subclass.
    */
   public String getPresentationName() {
      return (getClass().getName());
   } // of getPresentationName

   //-----------------------------------------------------------------

   /**
    * You <B>don't</B> have to override this method in the subclass.
    */
   public String getRedoPresentationName() {
      if (this.canRedo() == true) {
         return ("redo " + getPresentationName());
      }
      else {
         return ("redo not supported - " + getPresentationName());
      }
   } // of getRedoPresentationName

   //-----------------------------------------------------------------

   /**
    * You <B>don't</B> have to override this method in the subclass.
    */
   public String getUndoPresentationName() {
      if (this.canUndo() == true) {
         return ("undo " + getPresentationName());
      }
      else {
         return ("undo not supported - " + getPresentationName());
      }
   } // of getUndoPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   STATUS ACCESSOR METHODS   ===========================================

   /**
    * Override this method in the subclass.
    * By default, returns false.
    */
   public boolean canRedo() {
      return (false);
   } // of canRedo

   //-----------------------------------------------------------------

   /**
    * Override this method in the subclass.
    * By default, returns false.
    */
   public boolean canUndo() {
      return (false);
   } // of canUndo

   //-----------------------------------------------------------------

   /**
    * Override this method in the subclass.
    * By default, returns false.
    */
   public boolean isSignificant() {
      return (false);
   } // of isSignificant

	/**
	 * Returns the sheet the command was performed on or null by default
	 */
	public Sheet getAssociatedSheet(){
		return null;
	}
   //===   STATUS ACCESSOR METHODS   ===========================================
   //===========================================================================



   //===========================================================================
   //===   ACTION METHODS   ====================================================

   /**
    * Override this method in the subclass.
    */
   public void redo() {
   } // of redo

   //-----------------------------------------------------------------

   /**
    * Override this method in the subclass.
    */
   public void undo() {
   } // of undo

   //-----------------------------------------------------------------

   /**
    * Override this method in the subclass.
    */
   public void die() {
   } // of die

   //-----------------------------------------------------------------

   /**
    * Checks if the command is enabled or not, and executes the command if it
    * is enabled, setting the execution time in the process. Executes command 
    * by calling run(). Override run(), not this method, in your subclass.
    *
    * @see Command#execute()
    */
   public final void execute() {

      if (isEnabled() == true) {
         setExecutionTime();
         run();
         Debug.println("executing " + this.getPresentationName());
      }
      else {
         throw new NotEnabledException(this);
      }
   } // of do

   //-----------------------------------------------------------------

   /**
    * This method is called by execute() if the command is enabled.
    * You should override this method in your subclass to do the dirty work.
    */
   abstract protected void run();

   //===   ACTION METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      return (enabledCounter.toString());
   } // of toString

   public static String debug() {
      return (enabledCounter.toString());
   } // of debug

   //===   TOSTRING   ==========================================================
   //===========================================================================


   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

/*
   static class C1 extends CommandImpl { 
      public void run() {
      }
   }

   static class C2 extends C1 { }
   static class C3 extends C1 { }

   public static void main(String[] argv) {

      System.out.println(CommandImpl.debug());

      new C1().disable();
      System.out.println(CommandImpl.debug());
      new C1().disable();
      System.out.println(CommandImpl.debug());
      new C1().enable();
      System.out.println(CommandImpl.debug());
      new C1().enable();
      System.out.println(CommandImpl.debug());
      System.out.println(new C1().isEnabled());
      System.out.println(new C2().isEnabled());
      System.out.println(new C3().isEnabled());
      System.out.println("----------------");

      new C1().execute();
      new C2().execute();
      new C3().execute();
   }
*/

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
