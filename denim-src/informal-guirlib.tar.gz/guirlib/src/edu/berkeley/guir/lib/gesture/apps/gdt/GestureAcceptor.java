package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.Gesture;

public interface GestureAcceptor {
  boolean canAcceptGesture();
  String getInputGestureTitle();
  /** return true if the input area should be cleared */
  boolean gestureDrawn(Gesture g);
}
