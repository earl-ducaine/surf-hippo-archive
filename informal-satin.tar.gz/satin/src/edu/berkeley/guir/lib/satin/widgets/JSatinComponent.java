package edu.berkeley.guir.lib.satin.widgets;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;

/**
 * Make a Graphical Object a non-interactive widget.
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 27 2000, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>
 *          )
 * @since   JDK 1.3RC3
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class JSatinComponent
   extends    JComponent 
   implements SatinConstants {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   GraphicalObject gob;
   SatinGraphics   sg                    = new SatinGraphics();
   boolean         flagIgnoreTranslation = true;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public JSatinComponent(GraphicalObject newGob) {
      this(newGob, true);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * @param newGob is the Graphical Object to render.
    * @param flag   is true if we want to ignore the Graphical Object's
    *               translate, false if we want to use it.
    */
   public JSatinComponent(GraphicalObject newGob, boolean flagIgnoreTranslate) {
      this.gob                   = newGob;
      this.flagIgnoreTranslation = flagIgnoreTranslate;
      updateSize();
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   SIZING METHODS   ====================================================

   /**
    * Mark the current bounds as dirty and recalculate based off of the
    * Graphical Object.
    */
   public void updateSize() {
      Rectangle2D bounds = gob.getBounds2D(COORD_ABS);
      Dimension   dim    = new Dimension();

      this.setBounds(0, 0, (int) bounds.getWidth()  + 1, 
                           (int) bounds.getHeight() + 1);

      dim.width  = (int) bounds.getWidth()  + 1;
      dim.height = (int) bounds.getHeight() + 1;

      this.setPreferredSize(dim);
      this.setMaximumSize(dim);
      this.setMinimumSize(dim);
   } // of method

   //===   SIZING METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   RENDERING   =========================================================

   public void paintComponent(Graphics g) {
      //// 1. Paint normally.
      super.paintComponent(g);

      //// 2. Setup graphics and transform.
      sg.setGraphics((Graphics2D) g);
      sg.pushStyle(gob.getStyleRef());

      AffineTransform tx;
      if (flagIgnoreTranslation == true) {
         tx = gob.getTransform(COORD_REL);
         tx.translate(-tx.getTranslateX(), -tx.getTranslateY());
      }
      else {
         tx = gob.getTransformRef();
      }
      sg.pushTransform(tx);

      //// 3. Render the graphical object.
      gob.render(sg);
   } // of method

   //===   RENDERING   =========================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) {
      JFrame          f = new JFrame("Test");
      TimedStroke     stk1;
      TimedStroke     stk2;
      JComponent      c;

      stk1 = new TimedStroke();
      stk1.addPoint(0,  0);
      stk1.addPoint(10, 10);
      stk1.addPoint(10, 0);
      stk1.addPoint(0,  10);

      stk2 = new TimedStroke();
      stk2.addPoint(4       ,       12);
      stk2.addPoint(5       ,       40);
      stk2.addPoint(3       ,       68);
      stk2.addPoint(1       ,       88);
      stk2.addPoint(1       ,       104);
      stk2.addPoint(2       ,       115);
      stk2.addPoint(6       ,       117);
      stk2.addPoint(25      ,       114);
      stk2.addPoint(56      ,       106);
      stk2.addPoint(77      ,       101);
      stk2.addPoint(96      ,       99);
      stk2.addPoint(109     ,       99);
      stk2.addPoint(111     ,       89);
      stk2.addPoint(109     ,       67);
      stk2.addPoint(114     ,       43);
      stk2.addPoint(117     ,       26);
      stk2.addPoint(118     ,       16);
      stk2.addPoint(115     ,       6);
      stk2.addPoint(108     ,       1);
      stk2.addPoint(99      ,       0);
      stk2.addPoint(67      ,       4);
      stk2.addPoint(34      ,       11);
      stk2.addPoint(13      ,       17);
      stk2.addPoint(3       ,       20);
      stk2.addPoint(0       ,       23);
      stk2.moveBy(COORD_REL, 100, 100);

      f.getContentPane().setLayout(new FlowLayout());
      c = new JSatinComponent(stk1);
      f.getContentPane().add(c);
      f.getContentPane().add(new JButton("Hey"));
      f.getContentPane().add(new JButton("There"));
      c = new JSatinComponent(stk2);
      f.getContentPane().add(c);

      f.setSize(500, 500);
      f.setVisible(true);

      System.out.println(c);
   } // of method

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
