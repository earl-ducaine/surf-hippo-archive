package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.command.ChangeCaptionCommand;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.interpreters.*;
import edu.berkeley.guir.denim.view.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.satin.image.*;
import java.awt.*;
import java.util.*;
import java.awt.image.*;
import java.awt.geom.*;

/**
 * The sketch is the "page" portion of a {@link DenimPanel}. It contains the
 * drawing of the page contents.
 *
 * <PRE>
 * Revisions:  1.0.0  08-05-1999 JL
 *                    Created class DenimLabel.
 *                    08-31-1999 MWN
 *                    It's never too late to document your code.
 *             1.0.1  11-21-1999 MWN
 *                    Added Semantic View properties.
 *             1.0.2  02-04-2000
 *                    Added conditional Semantic View properties -- sketch
 *                    doesn't appear at sitemap view unless it contains ink.
 *             1.0.3  06-13-2000 JH
 *                    Renamed InterpreterMediator to MultiInterpreter
 *             1.0.4  11-25-2002 YL
 *                    Added image cache
 *                    If sketch is not visible or enabled, overlook the event
 *             1.0.5  03-07-2003 YL
 *                    Refine Cache based on the satin's cache supports
 *             1.0.6  07-12-2003 YL
 *                    Overrided handleSingleStroke for Arrow Cursor selection
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~newman">Mark Newman</A> (
 *          <A HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 1.0.6, 07-12-2003
 */

public class DenimSketch
	extends PatchImpl
	implements ArrowSource, ArrowDest, DenimConstants, DenimRadioButtonInstanceContainer
{

	//===========================================================================
	//===   CONSTANTS   =========================================================

	static final long serialVersionUID = 7142709921194110616L;

	//-----------------------------------------------------------------

	private static final Color sketchBorder = new Color(0, 0, 0);
	private static final Color sketchBackground = Color.white;

	public static final double antiBlurFactor = 3;
	public static final AffineTransform antiBlurTransform =
		AffineTransform.getScaleInstance(
			1 / antiBlurFactor,
			1 / antiBlurFactor);

	private boolean isSketchRendered = false;

	public static final int DEFAULT_SKETCH_WIDTH_VALUE = 450;
    public static final int DEFAULT_SKETCH_HEIGHT_VALUE = 550;
    
    static int default_width = 450;
    static int default_height = 550;

	//===   CONSTANTS   =========================================================
	//===========================================================================

	//===========================================================================
	//===   CLASS VARIABLES   ===================================================

	private static MultiInterpreter prototypeInkInterpreter;
	private static DenimScribbledTextInterpreter prototypeScribbleInterpreter;
	private static GroupInterpreter prototypeGroupInterpreter;

	static {
		//// Setup the prototype interpreters.
		prototypeInkInterpreter = new DefaultMultiInterpreterImpl();
		prototypeScribbleInterpreter = new DenimScribbledTextInterpreter();
		prototypeGroupInterpreter = new GroupInterpreter();

		prototypeInkInterpreter.add(prototypeScribbleInterpreter);
		prototypeInkInterpreter.add(prototypeGroupInterpreter);

		prototypeInkInterpreter.setAcceptMiddleButton(false);
		prototypeInkInterpreter.setAcceptRightButton(false);
	}

	//===   CLASS VARIABLES   ===================================================
	//===========================================================================

	//===========================================================================
	//===   NONLOCAL VARIABLES   ================================================

	private Map arrows; // maps arrows to destinations
	private Map incomingArrows; // maps arrows to sources
	private Set radioButtons; // contains the radio buttons directly
	// added to this sheet

	static private boolean isGridOn = false;
	static private double hGap = 30;
	static private double vGap = 30;
 
    
    
	//===   INSTANCE VARIABLES   ================================================
	//===========================================================================

	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	/**
	 * Performs initializations common to all constructors.
	 */
	private void init()
	{
		setupStyle();
		setupInterpreters();

		arrows = new HashMap();
		incomingArrows = new HashMap();
		radioButtons = new HashSet();
		//isGridOn = false;
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Creates an empty sketch.
	 */
	public DenimSketch()
	{
		super();
		init();
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Creates an empty sketch with its bounds as the given polygon.
	 */
	public DenimSketch(Polygon poly)
	{
		super(poly);
		init();
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Creates an empty sketch with its bounds as the given rectangle.
	 */
	public DenimSketch(Rectangle2D rect)
	{
		super(rect);
		init();
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Creates an empty sketch with its bounds as the given stroke.
	 */
	public DenimSketch(TimedStroke stk)
	{
		super(stk);
		init();
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Fix up state after sketch has been added to sheet.
	 */
	public void initAfterAddSketchToSheet()
	{
		setupSemanticZoom();
	} // of method

	//===   CONSTRUCTORS   ======================================================
	//===========================================================================

	//===========================================================================
	//===   MISCELLANEOUS METHODS   =============================================

	//TODO: Use Default Styles here.
	private void setupStyle()
	{
		Style style = getStyle();
		style.setFillColor(sketchBackground);
		style.setDrawColor(sketchBorder);
		style.setLineWidth(DenimConstants.DEFAULT_BORDER_WIDTH);
		setStyle(style);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Returns the ink interpreter which is the same type as that which
	 * will be created when a DenimSketch is created.
	 */
	public static MultiInterpreter getPrototypeInkInterpreter()
	{
		return prototypeInkInterpreter;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the scribble interpreter which is the same type as that which
	 * will be created when a DenimSketch is created.
	 */
	public static DenimScribbledTextInterpreter getPrototypeScribbleInterpreter()
	{
		return prototypeScribbleInterpreter;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the group interpreter which is the same type as that which
	 * will be created when a DenimSketch is created.
	 */
	public static GroupInterpreter getPrototypeGroupInterpreter()
	{
		return prototypeGroupInterpreter;
	}

	//-----------------------------------------------------------------

	/**
	 * Sets up the interpreters for the sketch.
	 */
	private void setupInterpreters()
	{
		//// Setup the gesture interpreter.
		//// Would it be better to use just one interpreter & share the
		//// reference between all the sketches?
		Interpreter intrp;
		MultiInterpreter gestureIm = new DefaultMultiInterpreterImpl();

		intrp = new SemanticCircleSelectInterpreter();
		intrp.setAcceptLeftButton(false);
		gestureIm.add(intrp);

		intrp = new DenimGestureInterpreter();
		intrp.setAcceptLeftButton(false);
		gestureIm.add(intrp);

		this.setGestureInterpreter(gestureIm);

		//// Setup the ink interpreter.
		MultiInterpreter inkIm = new DefaultMultiInterpreterImpl();

		//DenimUtils.setupToolInterpreters(inkIm);
		inkIm.add(new DenimScribbledTextInterpreter());
		//inkIm.add(new GroupInterpreter());
		inkIm.setAcceptMiddleButton(false);
		inkIm.setAcceptRightButton(false);

		this.setInkInterpreter(inkIm);

		this.setAddRightButtonStrokes(false); // only allowed for sheets
		this.setAddMiddleButtonStrokes(false); // only allowed for sheets
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Sets up the semantic zoom view for the sketch.
	 */
	private void setupSemanticZoom()
	{
		SemanticZoomMultiViewImpl views = new SemanticZoomMultiViewImpl();

		//// Sketch is displayed from just above the sitemap level
		//// all the way through the most zoomed-in (detail view & beyond)

		double absScaleAboveOverview =
			DenimUtils.getAbsScaleFactorAt(this, ZOOM_NOTCH_0);

		double absScaleJustBelowOverview =
			DenimUtils.getAbsScaleFactorAt(this, OVERVIEW_SCALE_FACTOR + .01);

		double absScaleBetweenOverviewAndSitemap =
			DenimUtils.getAbsScaleFactorAt(this, ZOOM_NOTCH_20);

		double absScaleJustBelowSitemap =
			DenimUtils.getAbsScaleFactorAt(this, SITEMAP_SCALE_FACTOR + .01);

		double absScaleJustAboveBetweenSitemapAndStoryboard =
			DenimUtils.getAbsScaleFactorAt(this, ZOOM_NOTCH_40 - .01);

		double absScaleBetweenSitemapAndStoryboard =
			DenimUtils.getAbsScaleFactorAt(this, ZOOM_NOTCH_40);

		// 2. Apply the semantic view wrapper

		//// Sketch is displayed from the top of the zoom slider to just shy of
		//// the notch between sitemap & overview
		SemanticZoomViewWrapper v1 =
			new SemanticZoomViewWrapper(this.getView());
		v1.setDisplayRange(
			absScaleAboveOverview,
			absScaleAboveOverview,
			absScaleJustBelowOverview,
			absScaleBetweenOverviewAndSitemap);
		views.add(v1);

		//// A special view wrapper for just the region between
		//// ZOOM_NOTCH_20 and SITEMAP_SCALE_FACTOR: only display
		//// sketch if there's ink
		SketchViewAtSitemapWrapper v2 =
			new SketchViewAtSitemapWrapper(this.getView());
		v2.setDisplayRange(
			absScaleJustBelowOverview,
			absScaleBetweenOverviewAndSitemap,
			absScaleJustBelowSitemap,
			absScaleJustAboveBetweenSitemapAndStoryboard);
		views.add(v2);

		//// Sketch is displayed from notch between sitemap and storyboard
		//// to below
		v1 = new SemanticZoomViewWrapper(this.getView());
		v1.setDisplayRange(
			absScaleJustBelowSitemap,
			absScaleBetweenSitemapAndStoryboard,
			1000,
			1000);
		views.add(v1);

		this.setView(views);

	} // of method

	//-----------------------------------------------------------------

	/**
	 * Returns the label associated with this sketch.
	 */
	public DenimLabel getLabel()
	{
		DenimPanel panel = getPanel();

		if (panel != null)
		{
			return panel.getLabel();
		}
		else
		{
			return null;
		}
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Returns the panel containing this sketch.
	 */
	public DenimPanel getPanel()
	{
		return (DenimPanel) getParentGroup();
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Deletes this sketch.
	 */
	//public void delete() {
	//debug.println("Sketch deleted!");
	//super.delete();
	//} // of method

	//-----------------------------------------------------------------

	/**
	 * Returns a string briefly describing the sketch.
	 */
	private String toShortString(Map map)
	{
		Iterator i = map.entrySet().iterator();
		String s = "[";

		while (i.hasNext())
		{
			Map.Entry e = (Map.Entry) i.next();
			GraphicalObject key = (GraphicalObject) e.getKey();
			GraphicalObject value = (GraphicalObject) e.getValue();
			if (key == null)
			{
				s += "null ->";
			}
			else
			{
				s += key.getClass() + ":" + key.getUniqueID() + "->";
			}

			if (value == null)
			{
				s += "null\n";
			}
			else
			{
				s += value.getClass() + ":" + value.getUniqueID() + "\n";
			}
		}

		return s + "]";
	}

	//===   MISCELLANEOUS METHODS   =============================================
	//===========================================================================

	//===========================================================================
	//===   RADIO BUTTON CONTAINER METHODS   ====================================

	public boolean addRadioButton(DenimRadioButtonInstance radioButton)
	{
		return radioButtons.add(radioButton);
	}

	public boolean removeRadioButton(DenimRadioButtonInstance radioButton)
	{
		return radioButtons.remove(radioButton);
	}

	public Set getRadioButtons()
	{
		return radioButtons;
	}

	public ArrayList getBuiltinComponents()
	{
		ArrayList list = new ArrayList();
		Iterator it = this.getForwardIterator();
		while (it.hasNext())
		{
			GraphicalObject obj = (GraphicalObject) it.next();
			if (obj instanceof DenimComponentInstance)
			{
				list.add(obj);
			}
		}
		return list;
	}

	//===   RADIO BUTTON CONTAINER METHODS   ====================================
	//===========================================================================

	//===========================================================================
	//===   ARROW SOURCE METHODS   ==============================================

	/**
	 * Tells the sketch to keep track of the given arrow.
	 * The arrow should originate from within the sketch's panel.
	 */
	public void trackArrow(Arrow arrow)
	{
		//DenimPanel panel = getPanel();
		ArrowDest dest = arrow.getDest();

		/*Arrow orgArrow = panel.getOrgArrowWithDest(dest);
		if (orgArrow != null) {
		   orgArrow.delete();
		}
		else {
		   // The case where navigation arrows to the same dest already
		   // exists shoule be taken care of by
		   // ArrowInterpreter.handleSingleStroke().
		   assert panel.getNavArrowsWithDest(dest) == null; 
		   // "Nav arrow already exists, org arrow should not be added");
		}*/

		arrows.put(dest, arrow);
		//debug.println("arrows for " + getUniqueID() + ": " + toShortString(arrows));

	}

	//-----------------------------------------------------------------

	/**
	 * Tells the sketch to stop keeping track of the given arrow.
	 * The arrow should originate from within the sketch's panel.
	 */
	public void untrackArrow(Arrow arrow)
	{
		arrows.remove(arrow.getDest());
	}

	//-----------------------------------------------------------------

	public Set getOutgoingArrows()
	{
		return new HashSet(arrows.values());
	}

	//-----------------------------------------------------------------

	/**
	 * Returns whether the sketch has the given arrow originating from it.
	 */
	public boolean hasArrow(Arrow arrow)
	{
		return arrows.containsKey(arrow.getDest());
	}

	//-----------------------------------------------------------------

	/**
	 * Returns whether an arrow leaves this sketch.
	 */
	public boolean outgoingArrowExists()
	{
		// if iterator turns up anything, there's at least one arrow
		Iterator iter = arrows.values().iterator();
		return iter.hasNext();
	}

	//-----------------------------------------------------------------

	public Arrow getRedundantArrow(
		String eventType,
		int condition,
		ArrowDest dest)
	{
		return getPanel().getOrgArrowWithDestPanel(dest);
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the arrow with the given destination, or null if there isn't one.
	 */
	public Arrow getArrowWithDest(ArrowDest dest)
	{
		return (Arrow) (arrows.get(dest));
	}

	//===   ARROW SOURCE METHODS   ==============================================
	//===========================================================================

	//===========================================================================
	//===   ARROW DEST METHODS   ================================================

	public void trackIncomingArrow(Arrow arrow)
	{
		GraphicalObject source = arrow.getSource();
		incomingArrows.put(source, arrow);
	} // of method

	//-----------------------------------------------------------------

	public void untrackIncomingArrow(Arrow arrow)
	{
		incomingArrows.remove(arrow.getSource());
	} // of method

	//-----------------------------------------------------------------

	public Set getIncomingArrows()
	{
		return new HashSet(incomingArrows.values());
	}
	//-----------------------------------------------------------------

	public boolean hasIncomingArrow(Arrow arrow)
	{
		return incomingArrows.containsKey(arrow.getSource());
	} // of method

	//===   ARROW DEST METHODS   ================================================
	//===========================================================================

	/**
	 * Tells whether this sketch is currently visible. Ideally, we would
	 * override isVisible() for this, but doing so seems to interfere with
	 * the sketch's ability to fade in and out during zooming.
	 *
	 * WE ASSUME that display ranges of the sketch's view don't overlap.
	 * THEREFORE if this sketch is visible according to any view,
	 * it is visible, period.
	 */
	public boolean isSketchVisible()
	{
		//// Figure out the current scale level
		double currScale = GraphicalObjectLib.getScaleFactor(COORD_ABS, this);

		//// If the view of the sketch isn't a semantic zoom view mediator,
		//// then return true
		//// This only happens when the sketch is added to the sheet by DOMUtils
		if (!(getView() instanceof SemanticZoomMultiViewImpl))
		{
			return true;
		}

		//// Figure out the scales within which this sketch is visible
		SemanticZoomMultiViewImpl views =
			(SemanticZoomMultiViewImpl) (this.getView());
		Iterator iter = views.iterator();

		//// So, are we visible?
		SemanticZoomView v;

		//// WE ASSUME that display ranges won't overlap.
		//// THEREFORE if this sketch is visible according to any view
		////     it will be visible, period.

		while (iter.hasNext())
		{
			v = (SemanticZoomView) iter.next();
			if (v.getStartScale() - .01 <= currScale
				&& currScale <= v.getEndScale() + .01)
			{
				if (v instanceof SketchViewAtSitemapWrapper)
				{
					return ((SketchViewAtSitemapWrapper) v).isSketchVisible();
				}
				else
				{
					return (true);
				}
			}
		}

		return (false);
	}

	//===========================================================================
	//===   REVISED DAMAGE METHODS   ============================================

	public void damage(int sync, Rectangle rect)
	{
		GraphicalObjectGroup parent = getParentGroup();
		if (parent != null)
		{
			Rectangle2D.union(rect, parent.getBounds2D(COORD_ABS), rect);
			super.damage(sync, rect);
		}
		else
		{
			super.damage(sync, rect);
		}
	} // of damage

	//===   REVISED DAMAGE METHODS   ============================================
	//===========================================================================

	//===========================================================================
	//===   WATCH METHODS   =====================================================

	/**
	 * If the sketch receives an update message, propogate it to all objects that
	 * are watching the sketch.
	 */
	public void onUpdate(
		Watchable w,
		String strProperty,
		Object oldVal,
		Object newVal)
	{
		//debug.println("Sketch " + getUniqueID() + " propogating update");
		notifyWatchersUpdate(strProperty, oldVal, newVal);
	}

	//===   WATCH METHODS   =====================================================
	//===========================================================================

	/**
	 * Returns whether a grid is drawn within the sketch.
	 */
	static public boolean isGridOn()
	{
		return isGridOn;
	}

	//-----------------------------------------------------------------

	static public void setGrid(double hg, double vg)
	{
		hGap = hg;
		vGap = vg;
	}

	//-----------------------------------------------------------------

	static public double getGridH()
	{
		return hGap;
	}

	//-----------------------------------------------------------------

	static public double getGridV()
	{
		return vGap;
	}

	//-----------------------------------------------------------------

	/**
	 * Sets whether to draw a grid within the sketch or not.
	 */
	static public void setGridOn(boolean flag)
	{
		isGridOn = flag;
	}

	//===========================================================================
	//===   CLONE   =============================================================

	/**
	 * Returns a deep clone of this sketch.
	 */
	public Object deepClone()
	{
		return deepClone(new DenimSketch());
	}

	//-----------------------------------------------------------------

	/**
	 * Makes the given sketch a deep clone of this sketch, and returns the
	 * deep clone.
	 */
	public Object deepClone(DenimSketch clone)
	{
		super.deepClone(clone);
		return clone;
	}

	//-----------------------------------------------------------------

	/**
	 * Update image cache of this sketch when it's not valid.
	 */

	protected void updateCacheInternal(
		GraphicalObjectRenderingCache rc,
		AffineTransform refTransform,
		Style refStyle)
	{
        if(this.getSheet() instanceof DenimSheet)
        {
            // if this is not a focused panel, return
            if(!((DenimSheet)this.getSheet()).isFocusedPanel(this.getPanel()))
                return;
            
    /*        long heapFreeSize = Runtime.getRuntime().freeMemory();
            
            System.out.println(heapFreeSize/1024);
    */
    		Rectangle2D box = this.getBounds2D(COORD_LOCAL);
            
    
    		box.setFrame(
    			box.getMinX(),
    			box.getMinY(),
    			box.getWidth() * antiBlurFactor,
    			box.getHeight() * antiBlurFactor);
    
            BufferedImage cache = this.getRenderCache().getCacheImage();
            
            int w = (int) Math.ceil(box.getWidth());
            int h = (int) Math.ceil(box.getHeight());
            
            if(cache==null||cache.getWidth()!=w||cache.getHeight()!=h)
                cache = (BufferedImage) new BufferedImage(
        				  w, h, BufferedImage.TYPE_INT_RGB);
    
    		Graphics2D g2d = cache.createGraphics();
    
    		SatinGraphics newG = new SatinGraphics(g2d);
    
    		newG.pushStyle(refStyle);
    		newG.setClip(box);
    		newG.clearAllTransforms();
    
    		newG.pushTransform(
    			AffineTransform.getScaleInstance(
    				DenimSketch.antiBlurFactor,
    				DenimSketch.antiBlurFactor));
    
    		newG.fill(getLocalBoundingPoints2DRef().getBounds2D());
    
    		newG.draw(getLocalBoundingPoints2DRef());
    
    		renderChildren(newG);
    
    		newG.dispose();
    
    		// set cache image
    		rc.setCacheImage(cache);
    
    		AffineTransform tempTr = (AffineTransform) refTransform.clone();
    
    		tempTr.concatenate(antiBlurTransform);
    
    		// set cache transform
    		rc.setCacheTransform(tempTr);
        }
	}

	//-----------------------------------------------------------------

	/**
	 * When panning or zooming, render this sketch by cache.
	 * Otherwise, render it with actual graphical objects.
	 */

	protected void defaultRender(SatinGraphics g)
	{

		if (isSketchRendered == false)
			isSketchRendered = true;

        Rectangle2D box = this.getBounds2D(COORD_LOCAL);
        
		if (SatinImageLib.imageConvertingRender)
		{
            
			super.defaultRender(g);
			return;
		}

        /**
         * if it is panning, show a blank page
         */
		if ((this.getSheet() != null && this.getSheet().isSheetPanning())
			|| RadarViewPanel.isRadarViewRendering())
		{
            g.fill(getLocalBoundingPoints2DRef().getBounds2D());

            if (Denim.getPlatformState() == Denim.runningOnMac)
            {
                Rectangle2D tmpR =
                    getLocalBoundingPoints2DRef().getBounds2D();
                Point2D dst1 = new Point2D.Double();
                Point2D dst2 = new Point2D.Double();

                g.getTransform().transform(
                    new Point2D.Double(tmpR.getMinX(), tmpR.getMinY()),
                    dst1);
                g.getTransform().transform(
                    new Point2D.Double(tmpR.getMaxX(), tmpR.getMaxY()),
                    dst2);

                //System.out.println(g.getTransform().toString());
                AffineTransform tmpTr = g.getTransform();
                g.setTransform(AffineTransform.getTranslateInstance(0, 0));

                g.draw(
                    new Rectangle2D.Double(
                        dst1.getX(),
                        dst1.getY(),
                        dst2.getX() - dst1.getX(),
                        dst2.getY() - dst1.getY()));
                g.setTransform(tmpTr);
            }
            else
                g.draw(getLocalBoundingPoints2DRef());
		}
		else
		{
            /**
             * if it is not zooming, show the vector info
             */
			if (ZoomSlider.zoomingInstance == 0)
			{
                if(this.getRenderCache().getCacheValidity()==false)
    				this.getRenderCache().updateCache(
    					g.getTransform(),
    					g.getStyle());
                    
				g.fill(getLocalBoundingPoints2DRef().getBounds2D());

                // draw background image if any
                if(((BackgroundImageContainer)this.getSheet()).getBackgroundName()!=null
                        &&!(this.getPanel().getParentGroup() instanceof DenimCustomComponentInstance))
                {
                    //System.err.println(this.getPanel().getParentGroup().getClass().toString());
                    BufferedImage image = DenimSheet.getImage(((BackgroundImageContainer)this.getSheet()).getBackgroundName());
                    g.drawImage(image, 
                            (int)(box.getWidth()*((BackgroundImageContainer)this.getSheet()).getImageX()),
                            (int)(box.getHeight()*((BackgroundImageContainer)this.getSheet()).getImageY()),
                            (int)(box.getWidth()*((BackgroundImageContainer)this.getSheet()).getImageW()),
                            (int)(box.getHeight()*((BackgroundImageContainer)this.getSheet()).getImageH()),
                            null);
                }


				if (Denim.getPlatformState() == Denim.runningOnMac)
				{
					Rectangle2D tmpR =
						getLocalBoundingPoints2DRef().getBounds2D();
					Point2D dst1 = new Point2D.Double();
					Point2D dst2 = new Point2D.Double();

					g.getTransform().transform(
						new Point2D.Double(tmpR.getMinX(), tmpR.getMinY()),
						dst1);
					g.getTransform().transform(
						new Point2D.Double(tmpR.getMaxX(), tmpR.getMaxY()),
						dst2);

					//System.out.println(g.getTransform().toString());
					AffineTransform tmpTr = g.getTransform();
					g.setTransform(AffineTransform.getTranslateInstance(0, 0));

					g.draw(
						new Rectangle2D.Double(
							dst1.getX(),
							dst1.getY(),
							dst2.getX() - dst1.getX(),
							dst2.getY() - dst1.getY()));
					g.setTransform(tmpTr);
				}
				else
					g.draw(getLocalBoundingPoints2DRef());

                replaceCaptions();
                
				renderChildren(g);
			}
			else /* if it is zooming */
			{
                // if this is not a focused panel, return
				if (!this.getRenderCache().getCacheValidity())
				{
					this.getRenderCache().updateCache(
						g.getTransform(),
						g.getStyle());
				}

                if(this.getRenderCache().getCacheImage()!=null)
                {
    				g.pushTransform(DenimSketch.antiBlurTransform);
    				g.drawImage(
    					this.getRenderCache().getCacheImage(),
    					(int) box.getMinX(),
    					(int) box.getMinY(),
    					this.getSheet());
    				g.popTransform();
                }
                else // draw blank page
                {
                    g.fill(getLocalBoundingPoints2DRef().getBounds2D());

                    if (Denim.getPlatformState() == Denim.runningOnMac)
                    {
                        Rectangle2D tmpR =
                            getLocalBoundingPoints2DRef().getBounds2D();
                        Point2D dst1 = new Point2D.Double();
                        Point2D dst2 = new Point2D.Double();

                        g.getTransform().transform(
                            new Point2D.Double(tmpR.getMinX(), tmpR.getMinY()),
                            dst1);
                        g.getTransform().transform(
                            new Point2D.Double(tmpR.getMaxX(), tmpR.getMaxY()),
                            dst2);

                        //System.out.println(g.getTransform().toString());
                        AffineTransform tmpTr = g.getTransform();
                        g.setTransform(AffineTransform.getTranslateInstance(0, 0));

                        g.draw(
                            new Rectangle2D.Double(
                                dst1.getX(),
                                dst1.getY(),
                                dst2.getX() - dst1.getX(),
                                dst2.getY() - dst1.getY()));
                        g.setTransform(tmpTr);
                    }
                    else
                        g.draw(getLocalBoundingPoints2DRef());
                }
			}
		}

		if (isGridOn())
		{
			drawGrid(g);
		}
	}

    public void renderBackgroundImage(SatinGraphics g, Rectangle2D box) {

    	if(this.getSheet()==null)
    	{
    		return;
    	}
    	
    	if(this.getPanel().getParentGroup() instanceof DenimCustomComponentInstance)
    	{
    		return;
    	}
    	
    	DenimSheet sheet = ((DenimWindow)Denim.getWindows().get(0)).getDenimUI().getSheet();

    	if(sheet.getBackgroundName()!=null)
    	{
	    	BufferedImage image = DenimSheet.getImage(sheet.getBackgroundName());
	
	    	g.drawImage(image, 
	                (int)(box.getWidth()*sheet.getImageX()),
	                (int)(box.getHeight()*sheet.getImageY()),
	                (int)(box.getWidth()*sheet.getImageW()),
	                (int)(box.getHeight()*sheet.getImageH()),
	                null);
    	}
    }
    
    public void replaceCaptions() {
        
        this.disableDamage();
        
        Iterator it = this.getForwardIterator();
        LinkedList col = new LinkedList(); 
        while(it.hasNext())
        {
            GraphicalObject gob = (GraphicalObject)it.next();
            if(gob instanceof ScribbledText&&((ScribbledText)gob).isCouldBeCaption())
            {
                ScribbledText text = (ScribbledText)gob;
                text.setCouldBeCaption(false);
                col.add(text);
            }
        }
        
        it = col.iterator();
        while(it.hasNext())
        {
            ScribbledText text = (ScribbledText)it.next();
            addToComponentCaption(this, text);
        }
        
        this.enableDamage();
    }
    
    private static boolean addToComponentCaption(GraphicalObjectGroup group, 
            ScribbledText text) {
       Iterator it = group.getForwardIterator();
       while(it.hasNext())
       {
           GraphicalObject gob = (GraphicalObject)it.next();
           if(gob instanceof DenimGroup)
           {
               boolean b = addToComponentCaption((DenimGroup)gob, text);
               if(b)
               {
                   return true;
               }
           }
           else
           {
               if(gob instanceof DenimButtonInstance
                       && ((DenimButtonInstance)gob).getCaption() instanceof ScribbledText)
               {
                   ScribbledText caption = (ScribbledText)((DenimButtonInstance)gob).getCaption();
                   Rectangle2D rect = caption.getBounds2D(COORD_ABS);
                   if(text.getBounds2D(COORD_ABS).contains(new Point2D.Double(rect.getCenterX(),rect.getCenterY())))
                   {
                       //((DenimButtonInstance)gob).setCaption(text);
                       cmdsubsys.clearSelected();
/*                       Point2D pos = text.getLocation2D(COORD_ABS);
                       text.applyTransform(AffineTransform.getScaleInstance(5,5));
                       text.moveTo(COORD_ABS, pos);
                       */
                       Iterator tt = text.getForwardIterator();
                       while(tt.hasNext())
                       {
                           GraphicalObject s = (GraphicalObject)tt.next();
                           s.applyTransform(AffineTransform.getScaleInstance(5,5));
                       }
                       text.setBoundingPoints2D(COORD_LOCAL,
                               new Rectangle2D.Double(0,0,
                                       text.getWidth2D(COORD_LOCAL)*5,
                                       text.getHeight2D(COORD_LOCAL)*5));

                       cmdqueue.doCommand(
                            new ChangeCaptionCommand(
                                (CaptionedGraphicalObject) gob,
                                text));
                       return true;
                   }
               }
               else if(gob instanceof DenimRadioButtonInstance
                       && ((DenimRadioButtonInstance)gob).getCaption() instanceof ScribbledText)
               {
                   ScribbledText caption = (ScribbledText)((DenimRadioButtonInstance)gob).getCaption();
                   Rectangle2D rect = caption.getBounds2D(COORD_ABS);
                   if(text.getBounds2D(COORD_ABS).contains(new Point2D.Double(rect.getCenterX(),rect.getCenterY())))
                   {
                       cmdsubsys.clearSelected();
/*                       Point2D pos = text.getLocation2D(COORD_ABS);
                       text.applyTransform(AffineTransform.getScaleInstance(5,5));
                       text.moveTo(COORD_ABS, pos);*/
                       Iterator tt = text.getForwardIterator();
                       while(tt.hasNext())
                       {
                           GraphicalObject s = (GraphicalObject)tt.next();
                           s.applyTransform(AffineTransform.getScaleInstance(5,5));
                       }
                       text.setBoundingPoints2D(COORD_LOCAL,
                               new Rectangle2D.Double(0,0,
                                       text.getWidth2D(COORD_LOCAL)*5,
                                       text.getHeight2D(COORD_LOCAL)*5));

                       cmdqueue.doCommand(
                            new ChangeCaptionCommand(
                                (CaptionedGraphicalObject) gob,
                                text));
                       return true;
                   }
               }
               else if(gob instanceof DenimCheckBoxInstance
                       && ((DenimCheckBoxInstance)gob).getCaption() instanceof ScribbledText) 
               {
                   ScribbledText caption = (ScribbledText)((DenimCheckBoxInstance)gob).getCaption();
                   Rectangle2D rect = caption.getBounds2D(COORD_ABS);
                   if(text.getBounds2D(COORD_ABS).contains(new Point2D.Double(rect.getCenterX(),rect.getCenterY())))
                   {
                       cmdsubsys.clearSelected();
                       Iterator tt = text.getForwardIterator();
                       while(tt.hasNext())
                       {
                           GraphicalObject s = (GraphicalObject)tt.next();
                           s.applyTransform(AffineTransform.getScaleInstance(5,5));
                       }
                       text.setBoundingPoints2D(COORD_LOCAL,
                               new Rectangle2D.Double(0,0,
                                       text.getWidth2D(COORD_LOCAL)*5,
                                       text.getHeight2D(COORD_LOCAL)*5));
                       cmdqueue.doCommand(
                            new ChangeCaptionCommand(
                                (CaptionedGraphicalObject) gob,
                                text));
                       return true;
                   }
               }
           }
       }
       return false;
   }

	//-----------------------------------------------------------------

	public boolean isSketchRendered()
	{
		return isSketchRendered;
	}

	//===   CLONE   =============================================================
	//===========================================================================

	/*public void handleSingleStroke(SingleStrokeEvent evt) {
	   super.handleSingleStroke(evt);
	
	   TimedStroke stk = evt.getStroke();
	   DenimUtils.debugPrintBounds(stk, "Adding");
	   DenimUtils.debugPrintBounds(this, "Parent:");
	   debug.println("");
	}*/

	//----------------------------------------
    
	public static void setDefaultSketchWidth(int w)
	{
		default_width = w;
	}

	public static void setDefaultSketchHeight(int h)
	{
		default_height = h;
	}

	public static int getDefaultSketchWidth()
	{
		return default_width;
	}

	public static int getDefaultSketchHeight()
	{
		return default_height;
	}

	/**
	 * clear all references hold by this object (In the namespace of this class)
	 */

	public void deepClear()
	{
		super.deepClear();

		if (arrows != null)
		{
			arrows.clear();
			arrows = null;
		}

		if (incomingArrows != null)
		{
			incomingArrows.clear();
			incomingArrows = null;
		}
	}
	
	public Color getPrintFill() {
		return sketchBackground;
	}
	
	public Color getPrintDraw() {
		return sketchBorder;		
	}

	/**
	 * Draws a horizontal grid within the sketch.
	 */

	private void drawGrid(SatinGraphics g)
	{

		AffineTransform tr = AffineTransform.getTranslateInstance(0, 0);

		try
		{
			tr =
				AffineTransform
					.getScaleInstance(
						g.getTransform().getScaleX(),
						g.getTransform().getScaleY())
					.createInverse();
		}
		catch (Exception ex)
		{

		}

		g.pushTransform(tr);
		g.setColor(new Color(100, 100, 100, 80));

		Rectangle2D rect = this.getBounds2D(COORD_LOCAL);

		rect.setFrame(
			rect.getMinX(),
			rect.getMinY(),
			rect.getWidth() / tr.getScaleX(),
			rect.getHeight() / tr.getScaleY());

		double pos = 0;

		while (true)
		{
			if (pos >= rect.getMaxY())
				break;
			g.draw(new Line2D.Double(rect.getMinX(), pos, rect.getMaxX(), pos));
			pos += vGap;
		}

		pos = 0;
		while (true)
		{
			if (pos >= rect.getMaxX())
				break;
			g.draw(new Line2D.Double(pos, rect.getMinY(), pos, rect.getMaxY()));
			pos += hGap;
		}

		g.popTransform();
	}
	/*	
	   private void drawGrid(SatinGraphics g) {
	      
	      // Shelley: get the original SatinGraphics color
	      Color hold = g.getColor();
	
	      // Shelley: set the grid color
	      g.setColor(Color.lightGray);   
	      
	      DenimSheet sheet = (DenimSheet)getSheet();
	      double scaleFactor = sheet.getAbsScale();
	      AffineTransform txToApply;
	
	      Point2D TopLeftPoint =
	         ((GraphicalObjectImpl) this).getLocation2D(
	            (SatinConstants.COORD_LOCAL));
	      int tl_x = (int) (TopLeftPoint.getX());
	      int tl_y = (int) (TopLeftPoint.getY());
	      txToApply =
	         AffineTransformLib.scaleAndCenterAt(
	            scaleFactor,
	            tl_x,
	            tl_y,
	            sheet.getBounds2D(COORD_ABS));
	
	      Rectangle2D rect;
	      double w, h, s;
	
	      txToApply.preConcatenate(
	         sheet.getInverseTransform(SatinConstants.COORD_ABS));
	      //    txToApply.preConcatenate(sheet.getInverseTransform(SatinConstants.COORD_LOCAL));
	
	      rect = this.getBounds2D(SatinConstants.COORD_LOCAL);
	      // ss -- this is right
	
	      w = rect.getWidth() * txToApply.getScaleX();
	      h = rect.getHeight() * txToApply.getScaleY();
	      
	      if (Denim.getDeviceInfo().getName() == DeviceType.DESKTOP.getName()) {
	         s = h / 10;
	      } else if (Denim.getDeviceInfo().getName() == DeviceType.SMARTPHONE.getName()) {
	         s = h / 9;
	      } else {
	         s = h / 10;
	      }
	
	      int width = (int) w;
	      int height = (int) h;
	      int step = (int) s;
	
	      int tr_x = (int) (width + TopLeftPoint.getX());
	
	      int temp = 0;
	      for (int i = step; i < height; i = i + step) {
	         temp = tl_y + i;
	         g.drawLine(tl_x, temp, tr_x, temp);
	      }
	      
	      // Shelley: restore the original SatinGraphics color
	      g.setColor(hold);
	
	   }
	*/
	// hack
	public void renderChildrenInternal(SatinGraphics sg)
	{
		super.renderChildren(sg);
	}

	//===========================================================================
	//===   DISPATCHING METHODS   ===============================================

	public void handleSingleStroke(SingleStrokeEvent evt)
	{
		//// 1. Add it ourself.
		if (((DenimSheet) this.getSheet()).getDenimUI().getCurrentTool()
			!= null)
		{
			super.handleSingleStroke(evt);
		}
	} // of handleSingleStroke

	//===   DISPATCHING METHODS   ===============================================
	//===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
