package edu.berkeley.guir.denim.dialogs;

import edu.berkeley.guir.denim.*;
import java.awt.*;
import javax.swing.*;

/**
 * Contains convenience methods to display common dialog boxes related
 * to file management.
 *
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  05-08-1999 JL
 *                    Created FileDialogs by separating it from
 *                    DenimSheet.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 04-30-1999
 */
public class FileDialogs {

   //===========================================================================
   //===   FILE MESSAGES   =====================================================


   /**
    * Pops up a "Save changes to ...?" and returns JOptionPane.YES_OPTION,
    * JOptionPane.NO_OPTION, or JOptionPane.CANCEL_OPTION.
    */
   public static int showPromptForSaveDialog(DenimSheet sheet) {
      int option = JOptionPane.showConfirmDialog
         (sheet,
          "Save changes to " +
          sheet.getDenimUI().getFriendlyProjectName() + "?",
          "Denim",
          JOptionPane.YES_NO_CANCEL_OPTION,
          JOptionPane.WARNING_MESSAGE);
      if (option == JOptionPane.CLOSED_OPTION) {
         return JOptionPane.CANCEL_OPTION;
      }
      else {
         return option;
      }
   }
   
   
   
   //-----------------------------------------------------------------
   
   public static int showPromptForScenarioOvewrite(DenimRunWindow sheet, String title) {
      int option = JOptionPane.showConfirmDialog
         (sheet,
          "You are overwrite changes to the Scenario " +
          title + "; are you sure?",
          "Denim",
          JOptionPane.YES_NO_OPTION,
          JOptionPane.WARNING_MESSAGE);
     
      if(option == JOptionPane.YES_OPTION) {
         return 1;
      } else {
         return 0;
      }
   }

   //-----------------------------------------------------------------

   public static void showSaveFailureDialog(Component c,
                                            String strFileName,
                                            String strMsg) {
      if (strMsg == null) {
         JOptionPane.showMessageDialog(c,
               "Failed to save file " + strFileName + ".",
               "File failed to save",
               JOptionPane.ERROR_MESSAGE);
      }
      else {
         JOptionPane.showMessageDialog(c,
               "Failed to save file " + strFileName +
                     "\nfor the following reason:\n\n" + strMsg,
               "File failed to save",
               JOptionPane.ERROR_MESSAGE);
      }
   } // of showSaveFailureDialog

   //-----------------------------------------------------------------

   public static void showOpenFailureDialog(Component c,
                                            String strFileName,
                                            String strMsg) {
      JOptionPane.showMessageDialog(c,
            "Failed to open file " + strFileName +
                  "\nfor the following reason:\n\n" + strMsg,
            "File failed to open",
            JOptionPane.ERROR_MESSAGE);
   } // of showOpenFailureDialog

   //-----------------------------------------------------------------

   public static void showOpenFailureDialog(Component c,
                                            String strOldFileName,
         String strFileName, String strMsg) {

      if (strFileName == null || strOldFileName.equals(strFileName)) {
         showOpenFailureDialog(c, strOldFileName, strMsg);
      }
      else {
         JOptionPane.showMessageDialog(c,
               "Failed to find file " + strOldFileName +
                     ".\nFailed to open alternative file " + strFileName +
                     "\nfor the following reason:\n\n" + strMsg,
               "File failed to open",
               JOptionPane.ERROR_MESSAGE);
      }
   } // of showOpenFailureDialog

   //-----------------------------------------------------------------

   public static void showFindFailureDialog(Component c,
                                            String strFileName) {
      JOptionPane.showMessageDialog(c,
            "Failed to find file " + strFileName + ".",
            "File failed to open",
            JOptionPane.ERROR_MESSAGE);
   } // of showFindFailureDialog

   //-----------------------------------------------------------------

   public static void showFindFailureDialog(Component c,
                                            String strOldFileName,
                                            String strFileName) {
      if (strFileName == null || strOldFileName.equals(strFileName)) {
         showFindFailureDialog(c, strOldFileName);
      }
      else {
         JOptionPane.showMessageDialog(c,
               "Failed to find file " + strOldFileName +
                     "\nand alternative file " + strFileName + ".",
               "File failed to open",
               JOptionPane.ERROR_MESSAGE);
      }
   } // of showFindFailureDialog

   //===   FILE MESSAGES   =====================================================
   //===========================================================================
}

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
