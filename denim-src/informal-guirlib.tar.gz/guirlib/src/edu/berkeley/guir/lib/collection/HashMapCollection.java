//// See bottom of file for software license
package edu.berkeley.guir.lib.collection;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

/**
 * A Map that, for each key, contains a Collection of objects.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Jul 31 2002 JIH
 */
abstract public class HashMapCollection {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    Map map = createMap();     // (Object key -> Collection value)

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================





    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    /**
     * Specify the kind of map you want. Override this to return
     * different kinds of Maps. By default returns HashMap.
     */
    protected Map createMap() {
        return (new HashMap());
    } // of method

    //----------------------------------------------------------------

    /**
     * Override this method to return a Collection. For example,
     * return new LinkedList() or return new HashSet().
     */
    abstract protected Collection getNewCollectionInstance();

    /**
     * Override this method to return a Collection that contains references
     * to all of the elements in the specified Collection c.
     */
    abstract protected Collection getNewCollectionInstance(Collection c);

    //----------------------------------------------------------------

    /**
     * Get a reference to the Collection associated with this key. If there 
     * is no Collection, create one (but does not add it to the Map, do it 
     * yourself explicitly).
     */
    protected Collection getCollectionInstance(Object key) {
        // assert key != null;

        Object val = map.get(key);
        if (val == null) {
            return (getNewCollectionInstance());
        }
        else {
            return ((Collection) val);
        }
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================





    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Empty constructor.
     */
    public HashMapCollection() {
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Copy constructor
     */
    public HashMapCollection(HashMapCollection m) {
        HashMapCollection mapOrig = m;
        HashMapCollection mapCopy = this;

        Iterator   it = mapOrig.keySet().iterator();
        Object     key;
        Collection c;

        while (it.hasNext()) {
            key  = it.next();
            c    = (Collection) mapOrig.get(key);
            mapCopy.map.put(key, getNewCollectionInstance(c));
        }
    } // of copy constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   INDIVIDUAL KEY METHODS   ===========================================

    /**
     * Get the number of elements associated with the specified key.
     */
    public int size(Object key) {
        Collection c = getCollectionInstance(key);
        return (c.size());
    } // of method

    //----------------------------------------------------------------

    /**
     * Check if there are any elements associated with the specified key.
     */
    public boolean isEmpty(Object key) {
        return (size(key) <= 0);
    } // of method

    //----------------------------------------------------------------

    /**
     * See if this map contains the specified key and value pair.
     */
    public boolean containsKeyValue(Object key, Object value) {
        Collection c = getCollectionInstance(key);
        return (c.contains(value));
    } // of method

    //----------------------------------------------------------------

    /**
     * Return a <B>copy</B> of the Collection of objects associated with 
     * this key. Modifying the copy does not affect the original kept by 
     * this instance.
     *
     * @return a Collection, or an empty Collection if nothing is associated.
     */
    public Object get(Object key) {
        return (getNewCollectionInstance( getCollectionInstance(key) ));
    } // of method

    //----------------------------------------------------------------

    /**
     * Remove the value from the key's collection if it exists. 
     * Does nothing if it doesn't exist.
     */
    public void removeKeyValue(Object key, Object val) {
        Collection c = getCollectionInstance(key);
        c.remove(val);
    } // of method

    //----------------------------------------------------------------

    /**
     * Clear out all values associated with this key.
     *
     * @return the Collection associated with this key (if any), or an 
     *         empty Collection.
     */
    public Object removeKey(Object key) {
        Collection c = getCollectionInstance(key);
        map.remove(key);
        return (c);
    } // of method

    //----------------------------------------------------------------

    /**
     * Add a value to the specified key. Note that keys point to a 
     * Collection of values rather than a single value.
     *
     * @return null always.
     */
    public Object put(Object key, Object value) {
        //// 1. Get a reference to the associated Collection.
        Collection c = getCollectionInstance(key);

        //// 2. Add the value.
        c.add(value);

        //// 3. Put it back in. Does nothing if Collection already existed,
        ////    puts the Collection in if it didn't.
        map.put(key, c);

        //// 4. Return.
        return (null);
    } // of method

    //===   INDIVIDUAL KEY METHODS   ===========================================
    //==========================================================================




    //==========================================================================
    //===   MAP METHODS   ======================================================

    /**
     * Gets the total number of keys in the map.
     * O(1) operation.
     */
    public int sizeKeys() {
        return (map.size());
    } // of method


    /**
     * Gets the total number of values in the map.
     * O(N) operation, where N is size of keys.
     */
    public int sizeValues() {
        int        size = 0;
        Iterator   it   = keySet().iterator();
        Collection c;

        while (it.hasNext()) {
            c     = getCollectionInstance(it.next());
            size += c.size();
        }

        return (size);
    } // of method

    //----------------------------------------------------------------

    /**
     * See if the map contains any keys at all.
     */
    public boolean isEmpty() {
        return (map.isEmpty());
    } // of method

    //----------------------------------------------------------------

    /**
     * See if the map contains the key.
     */
    public boolean containsKey(Object key) {
        // assert key != null;
        return (map.containsKey(key));
    } // of method

    //----------------------------------------------------------------

    /**
     * See if the map contains the value.
     * O(N*M) operation, where N is size of keys and M is size of values.
     */
    public boolean containsValue(Object value) {
        return (values().contains(value));
    } // of method

    //----------------------------------------------------------------

    /**
     * Look for the specified value and remove all instances.
     * O(N*M) operation where N is #keys and M is average removal time 
     * from a Collection.
     */
    public void removeValue(Object val) {
        Iterator it = keySet().iterator();

        while (it.hasNext()) {
            removeKeyValue(it.next(), val);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Clear out the entire map.
     */
    public void clear() {
        map.clear();
    } // of method

    //----------------------------------------------------------------

    /**
     * Get all of the keys.
     */
    public Set keySet() {
        return (map.keySet());
    } // of method

    //----------------------------------------------------------------

    /**
     * O(N*M) operation, where N is size of keys and M is average size of
     * each associated Collection.
     */
    public Collection values() {
        Iterator   it         = keySet().iterator();
        LinkedList listValues = new LinkedList();
        Collection c;

        while (it.hasNext()) {
            c = getCollectionInstance(it.next());
            listValues.addAll(c);
        }

        return (values());
    } // of method

    //===   MAP METHODS   ======================================================
    //==========================================================================




    //==========================================================================
    //===   SPECIAL HASH MAP COLLECTION METHODS   ==============================

    /**
     * Set a key to point to a collection. This is a special API to
     * associate a key to an entire collection, and should only be used 
     * in rare cases in place of put(). Also, this does not conform to the Map
     * interface, so you'll have to cast it as a HashMapCollection.
     * <P>
     * Note: don't use this while iterating over the map, 
     * will lead to ConcurrentModificationError.
     */
    public void setCollection(Object key, Collection value) {
        map.put(key, value);
    } // of method

    //----------------------------------------------------------------

    /**
     * Get a <B>reference</B> to a collection. This is a special API 
     * and should not be used unless absolutely needed. Might return null.
     */
    public Collection getCollection(Object key) {
        return ((Collection) map.get(key));
    } // of method

    //===   SPECIAL HASH MAP COLLECTION METHODS   ==============================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        return (map.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
