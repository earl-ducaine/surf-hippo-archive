package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.GestureObject;
import edu.berkeley.guir.lib.gesture.util.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.beans.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.text.BadLocationException;

/** Show a gestureCategory as a thumbnail. */
public class GestureCategoryThumbnailPanel extends JPanel
  implements GestureObjectDisplay, GDTConstants {
  protected EventListenerList listenerList = new EventListenerList();
  protected CollectionListener listener = new MyCollectionListener();
  protected PropertyChangeListener propChangeListener =
    new MyPropChangeListener();
  protected GestureCategory category;
  protected JScrollPane scrollPane;
  protected double scale = 1.0;
  protected JComponent display;
  protected JLabel title;
  protected JPanel titlePanel;
  protected JButton noticeButton;
  protected boolean noticesVisible;
  
  public GestureCategoryThumbnailPanel()
  {
    this(null);
  }

  public GestureCategoryThumbnailPanel(GestureCategory category)
  {
    this(category, null);
  }

  public GestureCategoryThumbnailPanel(GestureCategory category,
				       JScrollPane scrollPane)
  {
    super(new BorderLayout());
    this.scrollPane = scrollPane;
    buildUI();
    setCategory(category);
  }

  public void setCategory(GestureCategory cat)
  {
    if (cat != category) {
      if (category != null) {
	category.removeCollectionListener(listener);
	category.removePropertyChangeListener(propChangeListener);
      }
      category = cat;
      if (category != null) {
	/*
	System.out.println("adding listeners to " + category.getName());
	*/
	category.addPropertyChangeListener(propChangeListener);
	category.addCollectionListener(listener);
      }
      updateThumbnail();
      updateTitle();
    }
  }

  public GestureObject getDisplayedObject()
  {
    return category;
  }
  
  protected void buildUI()
  {
    /*
    border = BorderFactory.
      createTitledBorder(null,
			 (category == null) ? "(null)" : category.getName(),
			 TitledBorder.CENTER,
			 TitledBorder.BOTTOM);
    setBorder(border);
    */
    updateThumbnail();
    titlePanel = new JPanel(new BorderLayout());
    title = new JLabel();
    titlePanel.add(title, BorderLayout.CENTER);
    add(titlePanel, BorderLayout.SOUTH);
    noticeButton = new JButton(NoticeHandler.NOTICE_ICON);
    noticeButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	List notices = (List)
	  category.getProperty(NoticeHandler.NOTICE_LIST_PROP);
	Notice firstNotice = (Notice) notices.get(0);
	int position = firstNotice.getPosition().getOffset();
	JTextPane textPane = getMainFrame().getSummaryLog().getTextPane();
	try {
	  Rectangle rect = textPane.modelToView(position);
	  textPane.scrollRectToVisible(rect);
	}
	catch (BadLocationException exception) {
	  System.err.println("WARNING: can't find the notice: " +
			     firstNotice);
	}
      }
    });
    noticeButton.setMargin(new Insets(1,1,1,1));
    addHierarchyListener(new HierarchyListener() {
      MainFrame mf;
      PropertyChangeListener listener;

      public void hierarchyChanged(HierarchyEvent e) {
	MainFrame newMf = getMainFrame();
	if (newMf != mf) {
	  if (mf != null) {
	    mf.removePropertyChangeListener
	      (MainFrame.NOTICE_VISIBILITY_CHANGE_PROP, listener);
	  }
	  mf = newMf;
	  // I don't know why this gets called if we don't have a
	  // MainFrame, but it does, so...
	  if (mf != null) {
	    listener = new PropertyChangeListener() {
	      public void propertyChange(PropertyChangeEvent pce) {
		updateNoticeVisibility(mf);
	      }
	    };
	    mf.addPropertyChangeListener
	      (MainFrame.NOTICE_VISIBILITY_CHANGE_PROP, listener);
	    updateNoticeVisibility(mf);
	  }
	}
      }
    });
  }

  protected void updateThumbnail()
  {
    if (display != null) {
      remove(display);
    }
    if ((category != null) && (category.size() > 0)) {
      Gesture g = (Gesture) category.getChild(0);
      display = DisplayFactory.createThumbnail(g, scrollPane);
    }
    else {
      display = new JLabel("No examples");
    }
    add(display, BorderLayout.CENTER);
    setPreferredSize(null);
    repaint();
    revalidate();
  }

  protected void updateNoticeVisibility(MainFrame mf)
  {
    noticesVisible = MainFrame.areWarningsEnabled();
    updateTitle();
  }
  
  protected void updateTitle()
  {
    title.setText((category == null) ? "(null)" : category.getName());
    if (noticesVisible && (category != null) &&
	NoticeHandler.hasNotices(category)) {
      titlePanel.add(noticeButton, BorderLayout.WEST);
    }
    else {
      titlePanel.remove(noticeButton);
    }
    setPreferredSize(null);
    repaint();
    revalidate();
  }

  public Dimension getPreferredSize()
  {
    Dimension result;
    Dimension ourDim = super.getPreferredSize();
    Border border = getBorder();
    if ((border != null) && (border instanceof TitledBorder)) {
      Dimension borderDim = ((TitledBorder) border).getMinimumSize(this);
      int newWidth = (int) Math.max(borderDim.getWidth(),ourDim.getWidth());
      int newHeight = (int) Math.max(borderDim.getHeight(),
				     ourDim.getHeight());
      result = new Dimension(newWidth, newHeight);
    }
    else {
      result = ourDim;
    }
    return result;
  }

  protected MainFrame getMainFrame()
  {
    MainFrame mf = (MainFrame) SwingUtilities.
      getAncestorOfClass(MainFrame.class, this);
    return mf;
  }
  
  //----------------------------------------------------------------------
  // command handling

  public boolean isCommandValid(int id)
  {
    return false;
  }

  public void doCommand(int id)
  {
    System.err.println("GestureCategoryThumbnailPanel handles no commands"
		       + " (was given id " + id + ")");
  }

  public void addMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.add(ChangeListener.class, listener);
  }
  
  public void removeMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.remove(ChangeListener.class, listener);
  }

  public String getInputGestureTitle()
  {
    return null;
  }

  public boolean gestureDrawn(Gesture g)
  {
    System.err.println("GestureCategoryThumbnailPanel does not accept gestures");
    return false;
  }

  public boolean canAcceptGesture()
  {
    return false;
  }
  
  public void setScale(double s)
  {
    scale = s;
    repaint();
  }

  public double getScale()
  {
    return scale;
  }
  
  public void paint(Graphics g)
  {
    Graphics2D g2d = (Graphics2D) g;
    AffineTransform t = g2d.getTransform();
    g2d.scale(scale, scale);
    super.paint(g);
    g2d.setTransform(t);
  }

  public void addActionListener(ActionListener l)
  {
    listenerList.add(ActionListener.class, l);
  }

  public void removeActionListener(ActionListener l)
  {
    listenerList.remove(ActionListener.class, l);
  }

  //----------------------------------------------------------------------
  // helper classes
  
  protected class MyCollectionListener extends CollectionAdapter {
    public void elementAdded(CollectionEvent e) {
      if ((e.getStartIndex() == 0) ||
	  (e.getElementCount() == category.size())) {
	updateThumbnail();
      }
    }
    public void elementRemoved(CollectionEvent e) {
      if (e.getStartIndex() == 0) {
	updateThumbnail();
      }
    }
  }

  protected class MyPropChangeListener extends EnableListener {
    final Border BASIC_BORDER =
      BorderFactory.createLineBorder(Color.green, 3);

    private Color oldBG = null;
    
    public MyPropChangeListener() {
      super(GestureCategoryThumbnailPanel.this);
    }
    
    public void propertyChange(PropertyChangeEvent e) {
      if ((e.getPropertyName() == GestureContainer.NAME_PROP) ||
	  (e.getPropertyName() == NoticeHandler.NOTICE_LIST_PROP)) {
	GestureCategoryThumbnailPanel.this.updateTitle();
      }
      else if (GDTConstants.CORRECT_RECOG_PROP == e.getPropertyName()) {
	Color newBG;
	if (e.getNewValue() == null) {
	  // no longer the recognized gesture
	  newBG = oldBG;
	}
	else {
	  oldBG = GestureCategoryThumbnailPanel.this.getBackground();
	  newBG = Color.white;
	  /*
	  Classifier.Result result = (Classifier.Result) e.getNewValue();
	  newBorder = BorderFactory.
	  createTitledBorder(BASIC_BORDER, result.category.getName(),
			     TitledBorder.CENTER,
			     TitledBorder.BELOW_BOTTOM);
	  */
	}
	GestureCategoryThumbnailPanel.this.setBackground(newBG);
	getComponent(0).setBackground(newBG);
	//GestureCategoryThumbnailPanel.this.setBorder(newBorder);
      }
      else {
	super.propertyChange(e);
      }
    }
  }
}
