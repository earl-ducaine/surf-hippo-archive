package edu.berkeley.guir.damask.pattern;

import java.awt.geom.Rectangle2D;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.lib.util.StringLib;

/** 
 * An instance of a pattern being used.
 * 
 * @see edu.berkeley.guir.damask.Pattern
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-19-2003 James Lin
 *                               Created PatternInstance.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-19-2003
 */

public class PatternInstance extends AbstractInteractionElement {

   private final Pattern pattern;
   private InteractionGraph graph;
   private Set/*<PatternInstanceMember>*/ members =
      new HashSet/*<PatternInstanceMember>*/();

   private ElementContainerSource containerEventSource =
      new ElementContainerSource();
   
   //===========================================================================

   /**
    * Created a new empty instance of the specified pattern.
    */
   public PatternInstance(final Pattern pattern) {
      this.pattern = pattern;
   }
   
   
   //---------------------------------------------------------------------------
   
   /**
    * Frees up any resources associated with this object.
    */   
   public void dispose() {
      setInteractionGraph(null);
   }
   
   //===========================================================================
   
   /**
    * Returns the interaction graph that the dialog is in, or null if it's not
    * in any graph.
    */
   public InteractionGraph getInteractionGraph() {
      return graph;
   }
   
   //---------------------------------------------------------------------------

   /**
    * Sets the interaction graph that the dialog is in. Called only by
    * InteractionGraph.add(Dialog).
    */
   public void setInteractionGraph(InteractionGraph graph) {
      this.graph = graph;
   }
   
   //===========================================================================

   /**
    * Gets the pattern of which this object is an instance.
    */
   public Pattern getPattern() {
      return pattern;
   }
   
   //===========================================================================
   
   /**
    * Returns the elements that are part of this pattern instance.
    * 
    * @return a read-only list of (PatternInstanceMember) members of this
    * pattern
    */
   public Collection/*<PatternInstanceMember>*/ getMembers() {
      return Collections.unmodifiableCollection(members);
   }
   
   //===========================================================================
   
   /**
    * Returns the elements that are part of this pattern instance.
    * 
    * @return a read-only list of (InteractionElement) members of this
    * pattern
    */
   public Collection/*<PatternInstanceMember>*/ getMembers(
      final DeviceType deviceType) {
         
      final Set deviceMembers = new HashSet();
      for (Iterator i = getMembers().iterator(); i.hasNext(); ) {
         final PatternInstanceMember member = (PatternInstanceMember)i.next();
         if (member.isVisibleToDeviceType(deviceType)) {
            deviceMembers.add(member);
         }
      }
      return deviceMembers;
   }
   
   //===========================================================================
   
   /**
    * Adds the given element to the pattern instance for the given device.
    */
   public void add(final PatternInstanceMember element) {
      members.add(element);
      element.addToPatternInstance(this);
      fireElementAdded(ElementContainerEvent.UNKNOWN_INDEX, element);
   }
   
   //===========================================================================
   
   /**
    * Removes the given element from the pattern instance for the given device.
    * 
    * @return true if the pattern instance contained the element
    */
   public boolean remove(final PatternInstanceMember element) {
      final boolean wasRemoved = members.remove(element);
      element.removeFromPatternInstance(this);
      if (wasRemoved) {
         fireElementRemoved(ElementContainerEvent.UNKNOWN_INDEX, element);
      }
      return wasRemoved;
   }
   
   //===========================================================================
   
   // @Override
   public Set/*<DeviceType>*/ getDeviceTypesVisibleTo() {
      final Set/*<DeviceType>*/ deviceTypes = new HashSet();
      for (Iterator i = getMembers().iterator(); i.hasNext(); ) {
         final PatternInstanceMember member = (PatternInstanceMember)i.next();
         deviceTypes.addAll(member.getDeviceTypesVisibleTo());
      }
      return deviceTypes;
   }
   
   //===========================================================================

   // @Override
   public Rectangle2D getBounds(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      
      Rectangle2D bounds = super.getBounds(deviceType);
      
      if (isVisibleToDeviceType(deviceType) && (bounds == null)) {
         bounds = new Rectangle2D.Double(0, 0, 0, 0);
         super.setBounds(deviceType, bounds);
      }
      return bounds;
   }

   //===========================================================================
   
   private String membersToString(int indentLevel, DeviceType deviceType) {
      final StringBuffer sb = new StringBuffer();
      
      for (Iterator i = getMembers(deviceType).iterator(); i.hasNext(); ) {
         final PatternInstanceMember element = (PatternInstanceMember)i.next();
         sb.append(StringLib.spaces(indentLevel * DamaskUtils.INDENT_SPACES));
         sb.append("  - " + element.toString());
         if (i.hasNext()) {
            sb.append("\n");
         }
      }
      
      return sb.toString();
   }
   
   //---------------------------------------------------------------------------

   public String toLongString() {
      final StringBuffer sb = new StringBuffer();

      // 1. Write ourselves
      sb.append(toString());
      sb.append("\n");
      
      // 2. For each device, write the members
      for (Iterator i = Damask.getSupportedDeviceTypes().iterator(); i.hasNext(); ) {
         final DeviceType deviceType = (DeviceType) i.next();
         sb.append("* " + deviceType + "\n");
         sb.append(membersToString(0, deviceType));
      }
      
      return sb.toString();
   }

   //---------------------------------------------------------------------------

   public String toLongString(int indentLevel, final DeviceType deviceType) {
      // 1. Make sure we have a concrete device; "all" is not acceptable here.
      assert deviceType != DeviceType.ALL: "Device cannot be ALL";

      final StringBuffer sb = new StringBuffer();
      
      sb.append(StringLib.spaces(indentLevel * DamaskUtils.INDENT_SPACES));
      sb.append(toString());
      sb.append(membersToString(indentLevel, deviceType));

      return sb.toString();
   }

   //===========================================================================
   
   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public void addElementContainerListener(
      ElementContainerListener listener) {

      containerEventSource.addElementContainerListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public void removeElementContainerListener(
      ElementContainerListener listener) {

      containerEventSource.removeElementContainerListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementAdded events to listeners.
    */
   private void fireElementAdded(final int i, final InteractionElement e) {
      containerEventSource.fireElementAdded(this, null, i, e);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires elementRemoved events to listeners.
    */
   private void fireElementRemoved(final int i, final InteractionElement e) {
      containerEventSource.fireElementRemoved(this, null, i, e);
   }

   //===========================================================================

   public Object clone() {
      final PatternInstance clone = (PatternInstance)super.clone();

      clone.members = new HashSet(members);
      clone.containerEventSource = new ElementContainerSource();
      return clone;
   }
}
