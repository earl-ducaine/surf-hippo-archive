//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.watch;

import java.io.Serializable;

/**
 * This interface is a replacement for Observable, because Observable is a 
 * class instead of an interface. A Watchable object is essentially a set with
 * no duplicates.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 08 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public interface Watchable 
   extends Serializable, Cloneable {

   //===========================================================================
   //===   WATCHABLE INTERFACE   ===============================================

   /**
    * Add a watcher to this object.
    *
    * @param  w is the Watcher to add.
    * @return a reference to the added Watcher.
    */
   public Watcher addWatcher(Watcher w);

   //-----------------------------------------------------------------

   /**
    * Count the number of watchers watching this object.
    */
   public int countWatchers();

   //-----------------------------------------------------------------

   /**
    * Delete a watcher on this object.
    *
    * @return a reference to the removed Watcher.
    */
   public Watcher removeWatcher(Watcher w);

   //-----------------------------------------------------------------

   /**
    * Delete all watchers on this object.
    */
   public void clearWatchers();

   //-----------------------------------------------------------------

   /**
    * Turn off ability to notify others. This works like a counting semaphore.
    * Every time you call this method, the enabled value is incremented by 1.
    * The watch is enabled if and only if the value is 0.
    */
   public void disableNotify();

   //-----------------------------------------------------------------

   /**
    * Turn on ability to notify others.
    *
    * @see #disableNotify()
    */
   public void enableNotify();

   //-----------------------------------------------------------------

   /**
    * Check current ability to notify others.
    *
    * @see #disableNotify()
    * @see #enableNotify()
    */
   public boolean hasNotifyEnabled();

   //-----------------------------------------------------------------

   /**
    * Notify the watchers. This is just a generic method, should not be
    * generally used. 
    */
   public void notifyWatchers();

   //-----------------------------------------------------------------

   /**
    * Notify the watchers. This is just a generic method, should not be
    * generally used. 
    */
   public void notifyWatchers(Object arg);

   //-----------------------------------------------------------------

   /**
    * Notify the watchers that the object has been changed and the change needs
    * to be handled by the watchers.
    *
    * @param arg is the argument to send to all Watchers.
    */
   public void notifyWatchersUpdate(Object arg);

   //-----------------------------------------------------------------

   /**
    * Notify the watchers that some value has been changed. Modifying
    * the parameters should have no effect on this Watchable object.
    * See SatinConstants for a list of predefined property names.
    *
    * @see   edu.berkeley.guir.lib.satin.SatinConstants 
    * @param strProperty is some agreed upon name for the property.
    * @param oldVal      is the old value. 
    * @param newVal      is the new value. It should be a clone, not a
    *                    reference to the actual value, unless it is
    *                    prohibitively expensive to clone. Whether this is a
    *                    copy or a reference should be defined in the
    *                    SatinConstants file.
    */
   public void notifyWatchersUpdate(String strProperty, 
         Object oldVal, Object newVal);

   //-----------------------------------------------------------------

   /**
    * Notify the watchers that this object has been deleted. Notifications 
    * are error-prone, as you may accidentally modify the iterator. Be sure 
    * to clone first.
    */
   public void notifyWatchersDelete();

   //-----------------------------------------------------------------

   /**
    * Make a clone of this Watchable object.
    */
   public Object clone();

   //===   WATCHABLE INTERFACE   ===============================================
   //===========================================================================

} // of interface

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
