package edu.berkeley.guir.damask.view.appevent;

import java.util.EventObject;

import edu.berkeley.guir.damask.view.DamaskCanvas;

/** 
 * An event that indicates that the canvas has been changed.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-11-2004 James Lin
 *                               Created CanvasEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-11-2004
 */
public class CanvasEvent extends EventObject {

   private final Type eventType;   
   
   //---------------------------------------------------------------------------

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   

   public static final Type SELECTION_CHANGED = new Type("selection changed");
   public static final Type SELECTED_PAGE_CHANGED =
      new Type("selected page changed");

   //---------------------------------------------------------------------------

   /**
    * Constructs a CanvasEvent, that indicates that a document has been
    * changed.
    */
   public CanvasEvent(final DamaskCanvas source, final Type eventType) {
      super(source);
      this.eventType = eventType;
   }
   

   /**
    * Returns the canvas that is the source of the event.
    */
   public DamaskCanvas getCanvas() {
      return (DamaskCanvas)source;
   }
   
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
}
