//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter.commands;

import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.stroke.*;

/**
 * Draw a gesture around many objects to select.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jun 27 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class CircleSelectInterpreter 
   extends InterpreterImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -893939878094060567L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   boolean flagShallow = true;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public CircleSelectInterpreter() {
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Circle Select Interpreter");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR / MODIFIER METHODS   =======================================

   public void setDeep() {
      flagShallow = false;
   } // of setDeep

   //-----------------------------------------------------------------

   public void setShallow() {
      flagShallow = true;
   } // of setShallow
   
   
   public boolean isShallow() {
   	  return flagShallow;
   }

   //===   ACCESSOR / MODIFIER METHODS   =======================================
   //===========================================================================



   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   public void handleSingleStroke(SingleStrokeEvent evt) {

      //// 1. Capability check.
      GraphicalObject gob = getAttachedGraphicalObject();
      if (gob == null || !(gob instanceof GraphicalObjectGroup)) {
         return;
      }

      //// 2. Okay, now check if the stroke is sufficiently long enough.
      TimedStroke stk = evt.getStroke();
      if (stk.getLength2D(COORD_ABS) < 80) {
         return;
      }

      //// 3. Check if it looks circle-like.
      ////    See if portions near the beginning and end of the
      ////    stroke intersect or are sufficiently near each other.
      TimedStroke stkA = stk.getSubstroke(0, 0.2);
      TimedStroke stkB = stk.getSubstroke(0.8, 1);
      if (GeomLib.minDistance(stkA.getPolygon2D(COORD_ABS), 
                              stkB.getPolygon2D(COORD_ABS)) > 150) {
         return;
      }

      //// 4. Figure out what objects are contained.
      GraphicalObjectGroup      gobgrp = (GraphicalObjectGroup) gob;
      GraphicalObjectCollection gobcol;

      //// 4.1. If in deep-select mode, find the deepest GraphicalObjectGroup
      ////      and grab from there. Works most of the time.
      int         depth;

      if (flagShallow == true) {
         depth = SHALLOW;
      }
      else {
         depth = DEEP;
      }

      gobcol = gobgrp.getGraphicalObjects(COORD_ABS, 
                                          stk.getPolygon2D(COORD_ABS),
                                          ALL,
                                          depth,
                                          CONTAINEDBY);

      //// 5. If there are any contained objects, add them to the list of
      ////    selected objects.
      if (gobcol.numElements() > 0) {
         cmdsubsys.clearSelected();
         cmdsubsys.addSelected(gobcol.getForwardIterator());
         evt.setConsumed();
      }

   } // of handleSingleStroke

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new CircleSelectInterpreter()));
   } // of method

   //-----------------------------------------------------------------

   protected CircleSelectInterpreter clone(CircleSelectInterpreter intrp) {
      //// 1. Clone chain.
      super.clone(intrp);

      //// 2. Do clone work.
      intrp.flagShallow = this.flagShallow;

      //// 3. Return.
      return (intrp);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
