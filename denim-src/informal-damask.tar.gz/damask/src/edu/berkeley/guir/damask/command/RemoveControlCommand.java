package edu.berkeley.guir.damask.command;

import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that removes a control from a page region and its group.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  01-07-2004 James Lin
 *                               Created RemoveControlCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 01-07-2004
 */
public class RemoveControlCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final Control control;
   private Dialog dialog;
   private ComponentGroup group;
   private final Map/*<PageRegion, Integer>*/ pageRegions =
      new HashMap/*<PageRegion, Integer>*/();
   private final Set/*<ConnectionInfo>*/ connectionInfos =
      new HashSet/*<ConnectionInfo>*/();
   
   /**
    * Constructs the command.
    *  
    * @param control the control to remove
    */      
   public RemoveControlCommand(final Control control) {
      this.control = control;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Remove control " + control;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      dialog = control.getDialog();
      pageRegions.clear();
      connectionInfos.clear();
      
      // Store connection info for undo.
      connectionInfos.addAll(
         ConnectionInfo.createSet(control.getInConnections()));
      connectionInfos.addAll(
         ConnectionInfo.createSet(control.getOutConnections()));

      // Store page regions info for undo.
      for (Iterator i = control.getDeviceTypesVisibleTo().iterator();
         i.hasNext(); ) {
      
         final DeviceType deviceType = (DeviceType)i.next();
         final PageRegion region = control.getPageRegion(deviceType);
         pageRegions.put(region,
            new Integer(region.getControls().indexOf(control)));
      }

      // Remove the connections.
      //TODO This isn't quite right: if an incoming connection is removed
      // and the source is a hyperlink, the link is not turned back into
      // a label. This implementation should probably be changed to extend
      // a ModifyGraphMacroCommand. But it's okay for now, since we have
      // disabled connections linking directly to controls.
      final Set connections = new HashSet();
      connections.addAll(control.getInConnections());
      connections.addAll(control.getOutConnections());
      for (Iterator i = connections.iterator(); i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         connection.getInteractionGraph().remove(connection);
         connection.dispose();
      }
      
      // Remove the control.
      dialog.removeControl(control);
      group = control.getGroup();
      if (group != null) {
         group.remove(control);
      }
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      // Add the control back to the old page regions and group.
      dialog.addControl(pageRegions, control);
      if (group != null) {
         group.add(control);
      }
      
      // Restore the connections associated with the control.
      for (Iterator i = connectionInfos.iterator(); i.hasNext(); ) {
         final ConnectionInfo connectionInfo = (ConnectionInfo)i.next();
         final NavConnection connection =
            (NavConnection)connectionInfo.createConnection();

         control.getInteractionGraph().add(connection);
      }
   }
}
