package edu.berkeley.guir.damask.view;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.view.appevent.DocumentEvent;
import edu.berkeley.guir.damask.view.appevent.DocumentListener;
import edu.berkeley.guir.damask.view.nodes.SizingBorder;
import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.activities.PActivity;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolo.util.PDimension;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * The radar view for Damask.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  01-24-2004 Michelle Xue
 *                               Created DamaskRadarDialog
 * </pre>
 *
 * @author  Michelle Xue
 * @version Version 1.0.0, 01-24-2004
 */
public class DamaskRadarDialog extends JDialog {

   private static double DEFAULT_SCALE = 0.1;
   private static double PAGE_TITLE_SCALE = 0.25;
   
   private static Logger logger =
      Logger.getLogger(DamaskRadarDialog.class.getName());
   
   // The canvas that the dialog contains   
   private final PCanvas radarCanvas;
   
   // The event handler for the canvas
   private final CanvasEventHandler radarCanvasHandler =
      new CanvasEventHandler();

   // The frame that the dialog belongs to
   private final DamaskFrame mainFrame;

   // The canvas that the radar is listening to
   private DamaskCamera mainCamera = null;

   // The handler for the canvas' camera
   private PropertyChangeListener mainCameraHandler = null;

   // Indicates if rectangle causes the main canvas to change
   private boolean listenToMainCamera = true;
   
   // The viewport rectangle and its event handler
   private PPath rectangle = null;
   private RectangleHandler rectHandler = null;
   
   // Fields related to panning the camera
   private final PanActivity panActivity = new PanActivity(-1);
   private final int PAN_JUMP = 10;
   private boolean panActive = false;

   /**
    * Constructs a radar view of the specified frame.
    */
   public DamaskRadarDialog(final DamaskFrame frame) {
      super(frame, "Thumbnail");

      radarCanvas = new PCanvas();
      mainFrame = frame;
      
      frame.getDocument().addDocumentListener(new DocumentHandler());
      updateTitleBar();

      listenToCanvas(frame.getCurrentCanvas());
      frame.addCanvasChangeListener(new ChangeListener() {
         public void stateChanged(ChangeEvent e) {
            listenToCanvas(frame.getCurrentCanvas());
         }
      });

      // Add canvas		
      final JPanel mainPanel = new JPanel();
      mainPanel.setLayout(new BorderLayout());
      mainPanel.add(radarCanvas, BorderLayout.CENTER);

      // Add buttons for panning
      final JButton topButton = new JButton(getRadarIcon("top.gif"));
      final JButton bottomButton = new JButton(getRadarIcon("bottom.gif"));
      final JButton leftButton = new JButton(getRadarIcon("left.gif"));
      final JButton rightButton = new JButton(getRadarIcon("right.gif"));

      // Reduce the left and right margins of the left and right buttons.
      leftButton.setMargin(new Insets(0, 3, 0, 3));
      rightButton.setMargin(new Insets(0, 3, 0, 3));

      topButton.addMouseListener(new PanButtonMouseHandler(0, 1));
      bottomButton.addMouseListener(new PanButtonMouseHandler(0, -1));
      rightButton.addMouseListener(new PanButtonMouseHandler(-1, 0));
      leftButton.addMouseListener(new PanButtonMouseHandler(1, 0));

      mainPanel.add(topButton, BorderLayout.NORTH);
      mainPanel.add(bottomButton, BorderLayout.SOUTH);
      mainPanel.add(rightButton, BorderLayout.EAST);
      mainPanel.add(leftButton, BorderLayout.WEST);

      // Add slider
      final JToolBar sliderBar = new JToolBar();
      sliderBar.setFloatable(false);
      sliderBar.setLayout(new BorderLayout());
      final JSlider slider =
         new JSlider(
            JSlider.VERTICAL,
            DamaskCanvas.SITEMAP,
            DamaskCanvas.BELOW_DETAIL,
            7);
      slider.setInverted(true);
      sliderBar.add(slider, BorderLayout.CENTER);
      slider.addChangeListener(new SliderHandler());

      final JButton zoomOutButton = new JButton(getRadarIcon("zoom_out.png"));
      zoomOutButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            slider.setValue(slider.getValue() - 1);
         }
      });
      sliderBar.add(zoomOutButton, BorderLayout.NORTH);

      final JButton zoomInButton = new JButton(getRadarIcon("zoom_in.png"));
      zoomInButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            slider.setValue(slider.getValue() + 1);
         }
      });
      sliderBar.add(zoomInButton, BorderLayout.SOUTH);

      // Show the dialog
      getContentPane().setLayout(new BorderLayout());
      getContentPane().add(sliderBar, BorderLayout.LINE_START);
      getContentPane().add(mainPanel, BorderLayout.CENTER);
      setSize(250, 250);
      radarCanvas.getCamera().scaleView(DEFAULT_SCALE);
      
      // Listen to canvas events
      radarCanvas.addInputEventListener(radarCanvasHandler);

      final WindowHandler winHandler = new WindowHandler();
      addWindowListener(winHandler);
      addWindowFocusListener(winHandler);
   }

   /**
    * Called when the canvas that the radar view should display is changed.
    */
   private void listenToCanvas(final DamaskCanvas canvas) {
      // Stop listening to property changes from the previous canvas.
      if (mainCamera != null) {
         mainCamera.removePropertyChangeListener(mainCameraHandler);
      }

      mainCamera = (DamaskCamera)canvas.getCamera();
      
      // Listen to property changes from the main window's canvas.
      mainCameraHandler = new MainCameraHandler(mainCamera);
      mainCamera.addPropertyChangeListener(mainCameraHandler);

      final DeviceType deviceType = canvas.getDeviceType();

      // Replace Piccolo's default layer with a Damask Layer.
      final PLayer layer = radarCanvas.getLayer();
      radarCanvas.getRoot().removeChild(layer);
      final PCamera radarCamera = radarCanvas.getCamera();
      radarCamera.removeLayer(layer);
      final DamaskLayer damaskLayer =
         DamaskLayer.create(canvas.getDocument(), deviceType, PAGE_TITLE_SCALE);
      damaskLayer.getTemplatePane().setVisibleToCamera(null);
      radarCanvas.getRoot().addChild(damaskLayer);
      radarCamera.addLayer(0, damaskLayer);

      // Remove the default event handlers from the canvas
      radarCanvas.removeInputEventListener(radarCanvas.getPanEventHandler());

      // Add viewport rectangle
      if (rectangle != null) {
         radarCamera.removeChild(rectangle);
      }
      
      rectangle = new PPath();
      rectangle.setPaint(DamaskAppUtils.NO_COLOR);
      rectangle.setStrokePaint(Color.RED);
      radarCamera.addChild(rectangle);

      radarCamera.setPaint(
         (Color)DamaskCanvas.BACKGROUND_PAINTS.get(
            deviceType, DamaskLayer.DeviceTypeLayer.DEVICE));

      if (rectHandler != null) {
         rectangle.removeInputEventListener(rectHandler);
      }
      rectHandler = new RectangleHandler(canvas);
      rectangle.addInputEventListener(rectHandler);
      ConstraintSizingBorder.addConstraintSizingBordersTo(
         rectangle,
         canvas,
         this);
         
      syncRectangleWithCamera(mainCamera);
      
      radarCanvasHandler.setMainCanvas(canvas);
   }

   /**
    * Changes the bounds of the rectangle to match the bounds of the
    * main canvas.
    */
   private void syncRectangleWithCamera(final PCamera camera) {
      final PBounds bounds = camera.getViewBounds();
      radarCanvas.getCamera().viewToLocal(bounds);
      rectangle.globalToLocal(bounds);
      rectangle.setPathTo(bounds);
   }
   
   /**
    * Pans the radar view.
    */
   public void panCamera(final double dx, final double dy) {
      final PCamera camera = radarCanvas.getCamera();
      camera.translateView(
         dx * PAN_JUMP / camera.getViewScale(),
         dy * PAN_JUMP / camera.getViewScale());
      rectangle.translate(dx * PAN_JUMP, dy * PAN_JUMP);

   }

   /**
    * Sets whether a pan control is active.  
    */
   public void setPanning(final boolean flag) {
      panActive = flag;
      if (panActive) {
         final PRoot root = radarCanvas.getRoot();
         panCamera(panActivity.getDx(), panActivity.getDy());

         // Do the rest of the scrolling after a short delay (500ms).
         panActivity.setStartTime(root.getGlobalTime() + 500);

         root.addActivity(panActivity);
      }
      else {
         panActivity.terminate();
      }

   }

   // @Override
   public void setVisible(boolean flag) {
      super.setVisible(flag);
      if (flag) {
         logger.info(mainFrame + ": Radar view visible");
      }
      else {
         logger.info(mainFrame + ": Radar view not visible");
      }
      mainFrame.onRadarDialogVisibleChanged(flag);
   }

   /**
    * Gets an image for the radar view. 
    */
   public static ImageIcon getRadarIcon(final String fileName) {
      final Image image =
         Toolkit.getDefaultToolkit().createImage(
            DamaskApp.class.getResource("images/radar/" + fileName));
      return new ImageIcon(image);
   }
   
   
   /**
    * Updates the title bar.
    */
   private void updateTitleBar() {
      final String titleBarString = "Thumbnail - "
            + new StringBuffer(mainFrame.getFileNameInTitleBar());
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            setTitle(titleBarString);
         }
      });
   }

   /**
    * An activity that continuously pans the canvas.
    */
   private class PanActivity extends PActivity {
      private double dx;
      private double dy;

      private PanActivity(long aDuration) {
         super(aDuration);
      }

      private PanActivity(long aDuration, long aStepRate) {
         super(aDuration, aStepRate);
      }

      private PanActivity(long aDuration, long aStepRate, long aStartTime) {
         super(aDuration, aStepRate, aStartTime);
      }

      protected void activityStep(long elapsedTime) {
         super.activityStep(elapsedTime);
         panCamera(dx, dy);
      }

      /**
       * Returns the change in x that will occur when this activity is active.
       */
      public double getDx() {
         return dx;
      }

      /**
       * Returns the change in y that will occur when this activity is active.
       */
      public double getDy() {
         return dy;
      }

      /**
       * Sets how much and in which direction the activity should pan
       * the canvas.
       */
      public void setDirection(double dx, double dy) {
         this.dx = dx;
         this.dy = dy;
      }
   }

   private class PanButtonMouseHandler implements MouseListener {
      private double dx;
      private double dy;

      public PanButtonMouseHandler(double x, double y) {
         this.dx = x;
         this.dy = y;
      }

      public void mouseClicked(MouseEvent event) {
      }

      public void mouseEntered(MouseEvent event) {
      }

      public void mouseExited(MouseEvent event) {
      }

      public void mousePressed(MouseEvent event) {
         panActivity.setDirection(dx, dy);
         setPanning(true);
      }

      public void mouseReleased(MouseEvent event) {
         setPanning(false);
      }
   }

   /**
    * Listens to mouse events within the rectangle. 
    */
   private class RectangleHandler extends PBasicInputEventHandler {
      private DamaskCanvas mainCanvas;

      public RectangleHandler(final DamaskCanvas canvas) {
         mainCanvas = canvas;
      }
      
      public void mouseDragged(PInputEvent aEvent) {
         final Dimension2D delta = aEvent.getDeltaRelativeTo(rectangle);
         rectangle.translate(delta.getWidth(), delta.getHeight());
         aEvent.setHandled(true);

         final double scale = radarCanvas.getCamera().getViewScale();
         radarCanvas.getCamera().localToGlobal(delta);
         mainCanvas.getCamera().translateView(
            delta.getWidth() / -scale,
            delta.getHeight() / -scale);
         listenToMainCamera = false;
      }
      
      public void mouseClicked(PInputEvent aEvent) {
         final Rectangle2D rectBounds = rectangle.getBounds();
         final Point2D mousePosition = aEvent.getPositionRelativeTo(rectangle);
         final Dimension2D delta =
            new PDimension(
               mousePosition.getX() - rectBounds.getCenterX(),
               mousePosition.getY() - rectBounds.getCenterY());
         
         rectangle.translate(delta.getWidth(), delta.getHeight());
         aEvent.setHandled(true);

         final double scale = radarCanvas.getCamera().getViewScale();
         radarCanvas.getCamera().localToGlobal(delta);
         mainCanvas.getCamera().translateView(
            delta.getWidth() / -scale,
            delta.getHeight() / -scale);
         listenToMainCamera = false;
      }
   }

   /**
    * Listens to mouse events within the rectangle. 
    */
   private class CanvasEventHandler extends PBasicInputEventHandler {
      private DamaskCanvas mainCanvas = null;

      public void setMainCanvas(final DamaskCanvas canvas) {
         mainCanvas = canvas;
      }
      
      public void mouseClicked(PInputEvent aEvent) {
         if (mainCanvas != null) {
            final Rectangle2D rectBounds = rectangle.getBounds();
            final Point2D mousePosition = aEvent.getPosition();
            ((PCanvas)aEvent.getComponent()).getCamera().viewToLocal(
               mousePosition);
            rectangle.globalToLocal(mousePosition);
            final Dimension2D delta =
               new PDimension(
                  mousePosition.getX() - rectBounds.getCenterX(),
                  mousePosition.getY() - rectBounds.getCenterY());
            rectangle.translate(delta.getWidth(), delta.getHeight());
            aEvent.setHandled(true);

            final double scale = radarCanvas.getCamera().getViewScale();
            radarCanvas.getCamera().localToGlobal(delta);
            mainCanvas.getCamera().translateView(
               delta.getWidth() / -scale,
               delta.getHeight() / -scale);
            listenToMainCamera = false;
         }
      }
   }

   /**
    * Listens to the zoom slider's model.
    */
   private class SliderHandler implements ChangeListener {
      private double scaleFactor(final int zoomLevel) {
         // Derived from empirical values in DENIM
         // scaleFactor(PAGE) must be 0.1
         return DamaskCanvas.scaleFactor(zoomLevel) * DEFAULT_SCALE;
      }

      public void stateChanged(ChangeEvent e) {
         final PCamera camera = radarCanvas.getCamera();
         final PBounds bounds = camera.getViewBounds();

         camera.scaleViewAboutPoint(
            scaleFactor(((JSlider)e.getSource()).getValue())
               / camera.getViewScale(),
            bounds.getCenterX(),
            bounds.getCenterY());
         syncRectangleWithCamera(mainCamera);
      }
   }

   /**
    * Listens to the main window's canvas related to its view. 
    */
   private class MainCameraHandler implements PropertyChangeListener {
      private PCamera mainCamera;
      int n = 3;

      public MainCameraHandler(PCamera p) {
         mainCamera = p;
      }

      public void propertyChange(PropertyChangeEvent e) {
         if (e.getPropertyName().equals(PCamera.PROPERTY_VIEW_TRANSFORM)
            || e.getPropertyName().equals(PNode.PROPERTY_BOUNDS)
            || e.getPropertyName().equals(PNode.PROPERTY_FULL_BOUNDS)) {
            
            if (listenToMainCamera) {
               syncRectangleWithCamera(mainCamera);
            }

            listenToMainCamera = true;
         }
      }
   }

   /**
    * Listens to events from the document being displayed.
    */
   private class DocumentHandler implements DocumentListener {
      public void documentModified(DocumentEvent e) {
         if (e.getDocument() == mainFrame.getDocument()) {
            updateTitleBar();
         }
      }

      public void documentCleaned(DocumentEvent e) {
         if (e.getDocument() == mainFrame.getDocument()) {
            updateTitleBar();
         }
      }

      public void documentRenamed(DocumentEvent e) {
         if (e.getDocument() == mainFrame.getDocument()) {
            updateTitleBar();
         }
      }

      public void documentClosed(DocumentEvent e) {
      }

      public void documentBusyStarted(DocumentEvent e) {
      }

      public void documentBusyStopped(DocumentEvent e) {
      }

      public void canvasGroupAdded(DocumentEvent e) {
      }

      public void canvasGroupRemoved(DocumentEvent e) {
      }
   }
   
   /**
    * Handles resizing the red rectangle.
    */
   private static class ConstraintSizingBorder extends SizingBorder {
      private final DamaskCanvas mainCanvas;
      private final DamaskRadarDialog radarDialog;
      private final PCanvas radarCanvas;

      public ConstraintSizingBorder(
         final PBoundsLocator aLocator,
         final DamaskCanvas mainCanvas,
         final DamaskRadarDialog radarDialog) {

         super(aLocator);
         this.mainCanvas = mainCanvas;
         this.radarDialog = radarDialog;
         this.radarCanvas = radarDialog.radarCanvas;
         setPaint(DamaskAppUtils.NO_COLOR);
         setStrokePaint(DamaskAppUtils.NO_COLOR);
      }

      /**
       * Adds sizing borders to the given node.
       */
      public static void addConstraintSizingBordersTo(
         final PNode aNode,
         final DamaskCanvas mainCanvas,
         final DamaskRadarDialog radarDialog) {

         aNode.addChild(
            new ConstraintSizingBorder(
               PBoundsLocator.createEastLocator(aNode), mainCanvas, radarDialog));
         aNode.addChild(
            new ConstraintSizingBorder(
               PBoundsLocator.createWestLocator(aNode), mainCanvas, radarDialog));
         aNode.addChild(
            new ConstraintSizingBorder(
               PBoundsLocator.createNorthLocator(aNode), mainCanvas, radarDialog));
         aNode.addChild(
            new ConstraintSizingBorder(
               PBoundsLocator.createSouthLocator(aNode), mainCanvas, radarDialog));
         aNode.addChild(
            new ConstraintSizingBorder(
               PBoundsLocator.createNorthEastLocator(aNode), mainCanvas, radarDialog));
         aNode.addChild(
            new ConstraintSizingBorder(
               PBoundsLocator.createNorthWestLocator(aNode), mainCanvas, radarDialog));
         aNode.addChild(
            new ConstraintSizingBorder(
               PBoundsLocator.createSouthEastLocator(aNode), mainCanvas, radarDialog));
         aNode.addChild(
            new ConstraintSizingBorder(
               PBoundsLocator.createSouthWestLocator(aNode), mainCanvas, radarDialog));
      }

      public void dragHandle(PDimension aLocalDimension, PInputEvent aEvent) {
         final PBoundsLocator l = (PBoundsLocator)getLocator();

         final PPath n = (PPath)l.getNode();
         final PBounds b = new PBounds(n.getPathReference().getBounds2D());

         final double ratio = b.height / b.width;

         final PNode parent = getParent();
         if (parent != n && parent instanceof PCamera) {
            ((PCamera)parent).localToView(aLocalDimension);
         }

         localToGlobal(aLocalDimension);
         n.globalToLocal(aLocalDimension);

         final double oldHeight = b.height;
			final double oldX = b.x;
			final double oldY = b.y;

         final double dx = aLocalDimension.getWidth();
         final double dy = aLocalDimension.getHeight();

         switch (l.getSide()) {
            case SwingConstants.NORTH :
               b.setRect(
                  b.x + dy / (2 * ratio),
                  b.y + dy,
                  b.width - dy / (ratio),
                  b.height - dy);

               break;

            case SwingConstants.SOUTH :
               b.setRect(
                  b.x - dy / (2 * ratio),
                  b.y,
                  b.width + dy / ratio,
                  b.height + dy);

               break;

            case SwingConstants.EAST :
               b.setRect(
                  b.x,
                  b.y - ratio * dx / 2,
                  b.width + dx,
                  b.height + ratio * dx);

               break;

            case SwingConstants.WEST :
               b.setRect(
                  b.x + dx,
                  b.y + ratio * dx / 2,
                  b.width - dx,
                  b.height - ratio * dx);

               break;

            case SwingConstants.NORTH_WEST :
               b.setRect(
                  b.x + dy / ratio,
                  b.y + dy,
                  b.width - dy / ratio,
                  b.height - dy);

               break;

            case SwingConstants.SOUTH_WEST :
               b.setRect(b.x + dx, b.y, b.width - dx, b.height - dx * ratio);
               break;

            case SwingConstants.NORTH_EAST :
               b.setRect(b.x, b.y + dy, b.width - dy / ratio, b.height - dy);
               break;

            case SwingConstants.SOUTH_EAST :
               b.setRect(b.x, b.y, b.width + dy / (ratio), b.height + dy);
               break;
         }

         boolean flipX = false;
         boolean flipY = false;

         if (b.width < 0) {
            flipX = true;
            b.width = -b.width;
            b.x -= b.width;
         }

         if (b.height < 0) {
            flipY = true;
            b.height = -b.height;
            b.y -= b.height;
         }

         if (flipX || flipY) {
            flipSiblingBoundsHandles(flipX, flipY);
         }

         final double deltaX = b.x - oldX;
         final double deltaY = b.y - oldY;

         final PCamera mainCamera = mainCanvas.getCamera();
         
         final double scaleFactor = oldHeight / b.getHeight();

         final PBounds oldGlobalBounds = mainCamera.getViewBounds();
         
         mainCamera.translateView(
            oldGlobalBounds.getX(),
            oldGlobalBounds.getY());
               
         mainCamera.scaleView(scaleFactor);

         mainCamera.translateView(
            -oldGlobalBounds.getX(),
            -oldGlobalBounds.getY());
               
			final double scale = radarCanvas.getCamera().getViewScale();
         mainCamera.translateView(-deltaX / scale, -deltaY / scale);

         radarDialog.listenToMainCamera = false;
         n.setPathTo(b);
      }
      
      public void endHandleDrag(Point2D aLocalPoint, PInputEvent aEvent) {
         super.endHandleDrag(aLocalPoint, aEvent);

         final PCamera mainCamera = mainCanvas.getCamera();

         final int newZoomLevel =
            DamaskCanvas.getNearestZoomLevel(mainCamera.getViewScale());
         
         mainCanvas.setZoomLevel(newZoomLevel);
      }  
   }


   /**
    * Responds to window events.
    */
   private class WindowHandler extends WindowAdapter {
      public void windowGainedFocus(WindowEvent e) {
         logger.info(mainFrame + ": Radar view gained focus");
      }

      public void windowLostFocus(WindowEvent e) {
         logger.info(mainFrame + ": Radar view lost focus");
      }
   }
}
