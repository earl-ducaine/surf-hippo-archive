//// See bottom of file for software license
package edu.berkeley.guir.lib.swing.layout;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ComponentEvent;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 * Utilities for managing layout.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 06 2004
 */
public class LayoutLib {

    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * No instances allowed.
     */
    private LayoutLib() {
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   SIZE METHODS   =====================================================

    static JPanel p = new JPanel();

    public synchronized static Dimension getPreferredSize(Component comp) {
        p.removeAll();
        p.add(comp);
        Dimension dim = comp.getPreferredSize();
        p.removeAll();
        return (dim);
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the maximum Dimension of the components.
     */
    public Dimension getMaxSize(Component[] comps) {
        Dimension dim = comps[0].getPreferredSize();
        Dimension dimTmp;

        for (int i = 1; i < comps.length; i++) {
            dimTmp = comps[i].getPreferredSize();
            dim.setSize(
                Math.max(dim.getWidth(),  dimTmp.getWidth()),
                Math.max(dim.getHeight(), dimTmp.getHeight())
            );
        }

        return (dim);
    } // of method

    //===   SIZE METHODS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   RESIZE METHODS   ===================================================

    /**
     * Fake a resize event. Sometimes this is needed to force the
     * component to do its layout correctly, b/c setSize() doesn't
     * always work the way you want it to. Silly AWT / Swing.
     */
    public static void fakeResizeEvent(Component aComp) {
        java.awt.Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(
           new ComponentEvent(aComp, ComponentEvent.COMPONENT_RESIZED)
        );
    } // of method

    //----------------------------------------------------------------

    /**
     * Fake a resize event on the root of the Component.
     */
    public static void fakeResizeEventOnRoot(Component aComp) {
        Component root = SwingUtilities.getRoot(aComp);
        fakeResizeEvent(root);
    } // of method

    //===   RESIZE METHODS   ===================================================
    //==========================================================================




    //==========================================================================
    //===   LAYOUT METHODS   ===================================================

    /**
     * Traverse up the GUI hierarchy and revalidate the containing window.
     */
    public static void revalidateAll(Component aComponent) {
        Component c = SwingUtilities.getRoot(aComponent);
        if (c instanceof Window) {
            Window wnd = (Window) c;
            wnd.invalidate();
            aComponent.invalidate();
            wnd.validate();
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Traverse up the GUI hierarchy and pack the containing window.
     */
    public static void packContainingWindow(Component aComponent) {
        Component c = SwingUtilities.getRoot(aComponent);
        if (c instanceof Window) {
            ((Window) c).pack();
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * @param aComponent is the component whose containing window 
     *                   should be <CODE>pack()</CODE>'ed.
     * @param flagAllowGrowWidth    is true if width  can grow
     * @param flagAllowShrinkWidth  is true if width  can shrink
     * @param flagAllowGrowHeight   is true if height can grow
     * @param flagAllowShrinkHeight is true if height can shrink
     */
    public static void packContainingWindow(Component aComponent, 
                                            boolean   flagAllowGrowWidth,
                                            boolean   flagAllowShrinkWidth,
                                            boolean   flagAllowGrowHeight,
                                            boolean   flagAllowShrinkHeight) {

        Component c = SwingUtilities.getRoot(aComponent);
        if (c instanceof Window) {
            Window    wnd    = (Window) c;
            Dimension dimOld = null;
            Dimension dimNew = null;
            double    width;
            double    height;

            //// Save the current size.
            if (flagAllowGrowWidth    == true ||
                flagAllowShrinkWidth  == true ||
                flagAllowGrowHeight   == true ||
                flagAllowShrinkHeight == true) {
                dimOld = wnd.getSize();
            }

            //// Have to re-calculate preferred sizes again
            aComponent.invalidate();
            wnd.invalidate();
            wnd.validate();

            //// Insert magic here.
            wnd.pack();

            //// See if we should prevent shrinking.
            if (flagAllowGrowWidth    == true ||
                flagAllowShrinkWidth  == true ||
                flagAllowGrowHeight   == true ||
                flagAllowShrinkHeight == true) {

                dimNew = wnd.getSize();
                width  = dimNew.getWidth();
                height = dimNew.getHeight();

                //// If width has grown...
                if (dimOld.getWidth() < dimNew.getWidth()) {
                    if (flagAllowGrowWidth) {
                        width = dimNew.getWidth();
                    }
                    else {
                        width = dimOld.getWidth();
                    }
                }
                //// Else width is same or has shrunk...
                else {
                    if (flagAllowShrinkWidth) {
                        width = dimNew.getWidth();
                    }
                    else {
                        width = dimOld.getWidth();
                    }
                }

                //// If height has grown...
                if (dimOld.getHeight() < dimNew.getHeight()) {
                    if (flagAllowGrowHeight) {
                        height = dimNew.getHeight();
                    }
                    else {
                        height = dimOld.getHeight();
                    }
                }
                //// Else height is same or has shrunk...
                else {
                    if (flagAllowShrinkHeight) {
                        height = dimNew.getHeight();
                    }
                    else {
                        height = dimOld.getHeight();
                    }
                }

                //// Set the size accordingly
                dimNew.setSize(width, height);
                wnd.setSize(dimNew);

                //// Have to re-calculate preferred sizes yet again
                //// This section is very hack-worthy. I tried lots
                //// of different things, like sending component resize events,
                //// telling the layout manager to layout, etc. This is
                //// the best I could figure out.
                wnd.invalidate();
                wnd.validate();

                if (wnd instanceof JFrame) {
                    JFrame f = (JFrame) wnd;
                    f.getContentPane().invalidate();
                    if (f.getContentPane() instanceof JComponent) {
                        JComponent jcomp = (JComponent) f.getContentPane();
                        jcomp.setPreferredSize(jcomp.getPreferredSize());
                        f.pack();
                    }
                    else {
                        // xxx doesn't work?
                        f.getContentPane().validate();
                    }
                }
                else {
                    // xxx doesn't work?
                    wnd.invalidate();
                    wnd.validate();
                }

                wnd.setSize(dimNew);
            }
        }
    } // of method

    //===   LAYOUT METHODS   ===================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static void runTestAAA() {
        System.out.println(getPreferredSize(new JLabel("blah")));
        System.out.println(getPreferredSize(new JLabel("blahblahj")));
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestAAA();
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
