package edu.berkeley.guir.damask.userevent;

import java.util.EventObject;

/** 
 * An event that is triggered by a user action on a Damask design.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-24-2003 James Lin
 *                               Created DamaskUserEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 04-24-2003
 */
public abstract class DamaskUserEvent extends EventObject {
   public DamaskUserEvent(Object source) {
      super(source);
   }

   /**
    * Returns a copy of this event object, with the specified source.
    */
   public abstract DamaskUserEvent createCopy(Object source);
   
   /**
    * Returns whether the specified user event matches this one.
    */
   public boolean matches(final DamaskUserEvent e) {
      return e.getClass() == getClass();
   }
}
