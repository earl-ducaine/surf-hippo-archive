package edu.berkeley.guir.lib.gesture.apps;

/*
 * randomly reassigns names to categories
 */

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.Misc;
import java.io.File;
import java.util.Iterator;

public class grandomize {
  public static void main(String[] argv)
  {
    if (argv.length != 2) {
      System.err.println("grandomize: usage: java grandomize inFile outFile");
      System.exit(-1);
    }

    GestureSetFrame frame =
      new GestureSetFrame("grandomize", false);

    frame.openFile(new File(argv[0]));

    GestureSet gs = frame.getGestureSetDisplay().getGestureSet();
    randomizeNames(gs);
    GestureSetFrame.TypedFile typedFile =
      frame.makeTypedFile(new File(argv[1]), "ASCII");
    frame.saveFile(typedFile);
    
    System.exit(0);
  }

  static void randomizeNames(GestureSet gs)
  {
    String[] names = new String[gs.size()];
    int i;
    Iterator it;
    
    for (it = gs.getCategories().iterator(), i = 0;
         it.hasNext();
         i++) {
      GestureCategory gc = (GestureCategory)it.next();
      names[i] = gc.getName();
    }

    Misc.shuffle(names);
    
    for (it = gs.getCategories().iterator(), i = 0;
         it.hasNext();
         i++) {
      GestureCategory gc = (GestureCategory)it.next();
      gc.setName(names[i]);
    }
  }
}
