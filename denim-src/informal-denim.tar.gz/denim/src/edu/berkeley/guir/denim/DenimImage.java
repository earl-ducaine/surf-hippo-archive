//// See bottom of source code for software license

package edu.berkeley.guir.denim;

import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.util.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.components.DenimComponent;
import edu.berkeley.guir.denim.components.DenimComponentInstance;
import edu.berkeley.guir.lib.awt.geom.Polygon2D;
import edu.berkeley.guir.lib.collection.Map2D;
import edu.berkeley.guir.lib.satin.event.SingleStrokeEvent;
import edu.berkeley.guir.lib.satin.graphics.SatinGraphics;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.objects.PatchImpl;

/* <P>
 * This software is distributed under the 
 * <A HREF="http://dub.washington.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Nov 16, 2006 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.washington.edu/homes/yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.washington.edu">yangli@cs.washington.edu</A> )
 * 
 */

public class DenimImage extends PatchImpl
    implements DenimConstants, DenimHyperlinkContents, ObjectPhantom {

    String imageName;
    boolean link = false;
    /*
    class ImageInternal extends PatchImpl {
        
        ImageInternal(double w, double h) {
            super(new Rectangle2D.Double(0,0,w,h));
            this.setDrawPatch(false);
            this.setFillPatch(false);
        }
      
        protected void defaultRender(SatinGraphics g) {
            
            String pname = DenimUI.getProjectName();
            
            String dir = null;
            if(pname!=null)
                dir = new File(pname).getParentFile().getAbsolutePath();
            else
                dir = System.getProperty("java.io.tmpdir");

            BufferedImage image = (BufferedImage)DenimSheet.getImage(dir, imageName);
           
            Color color;
            if(link)
                color = Color.blue;
            else
                color = Color.lightGray;
            g.setColor(color);
            try
            {
                AffineTransform trans = g.getTransform().createInverse();
                g.pushTransform(trans);
                Rectangle2D rect = this.getBounds2D(COORD_ABS);
                g.drawImage(image, 
                        (int)rect.getMinX(),
                        (int)rect.getMinY(), 
                        (int)rect.getWidth(), 
                        (int)rect.getHeight(), 
                        this.getSheet());
                g.draw(rect);
                g.popTransform();
                
            }
            catch(Exception ex)
            {
                
            }
        }
    }
    */
    public DenimImage(String imagename, Rectangle2D bounds) {
        super(bounds);
        imageName = imagename;
        
      //  ImageInternal internal = new ImageInternal(bounds.getWidth(), bounds.getHeight());
       /// this.addToFront(internal);
    }
    
    private DenimImage(double w, double h) {
        //ImageInternal internal = new ImageInternal(w, h);
       // this.addToFront(internal);
    }
    
    public boolean isLink() {
        return link;
    }
    
    public void handleSingleStroke(SingleStrokeEvent evt) {
    } // of handleSingleStroke
    
    public void setLink(boolean b) {
        link = b;
    }
    
    public String getImageName() {
        return imageName;
    }

    protected void defaultRender(SatinGraphics g) {

        BufferedImage image = (BufferedImage)DenimSheet.getImage(imageName);
       
        Color color;
        if(link)
            color = Color.blue;
        else
            color = Color.lightGray;
        try
        {
            AffineTransform trans = g.getTransform().createInverse();
            
            if(externalCacheImage!=null)
            {
                Graphics2D g2d = externalCacheImage.createGraphics();
                g2d.setColor(color);
                Rectangle2D rect = new Rectangle2D.Double(0, 0, externalCacheImage.getWidth(), externalCacheImage.getHeight());
                g2d.drawImage(image, 
                        (int)rect.getMinX(),
                        (int)rect.getMinY(), 
                        (int)rect.getWidth(), 
                        (int)rect.getHeight(), 
                        this.getSheet());
                g2d.draw(rect);
                g2d.dispose();
            }
            else
            {
                g.setColor(color);
                g.pushTransform(trans);
                Rectangle2D rect = this.getBounds2D(COORD_ABS);
                g.drawImage(image, 
                        (int)rect.getMinX(),
                        (int)rect.getMinY(), 
                        (int)rect.getWidth(), 
                        (int)rect.getHeight(), 
                        this.getSheet());
                g.draw(rect);
                g.popTransform();
            }
        }
        catch(Exception ex)
        {
            
        }
    }

    public Polygon2D getPhantom() {
        
        Rectangle2D sb = this.getBounds2D(COORD_ABS);
        
        Polygon2D poly = new Polygon2D();
        
        poly.addPoint(sb.getMinX(),sb.getMinY());
        poly.addPoint(sb.getMinX(),sb.getMaxY());
        poly.addPoint(sb.getMaxX(),sb.getMaxY());
        poly.addPoint(sb.getMaxX(),sb.getMinY());
        poly.setClosed(true);
        
        return poly;  
    }
    
    public void setHyperlink(boolean flag) {
        link = flag;
    }
    
    //-----------------------------------------------------------------

    /**
     * Returns a deep clone of this scribble.
     */
    public Object deepClone() {
       return deepClone(new DenimImage(this.getWidth2D(COORD_LOCAL),this.getHeight2D(COORD_LOCAL)));
    }

    //-----------------------------------------------------------------

    /**
     * Makes the given label a deep clone of this scribble, and returns the
     * deep scribble.
     */
    public Object deepClone(DenimImage clone) {
       super.deepClone(clone);
       clone.imageName = this.imageName;
       clone.link = this.link;
       return clone;
    }
}



//==============================================================================

/*
Copyright (c) 2006 Regents of the University of Washington.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
    must display the following acknowledgement:

        This product includes software developed by the Group for User 
        Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
    derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/