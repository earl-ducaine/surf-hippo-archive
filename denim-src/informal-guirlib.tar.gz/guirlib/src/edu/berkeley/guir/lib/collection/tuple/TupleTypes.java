//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tuple;

import java.util.Comparator;

import edu.berkeley.guir.lib.util.comparator.DateComparator;
import edu.berkeley.guir.lib.util.comparator.DoubleComparator;
import edu.berkeley.guir.lib.util.comparator.IntegerComparator;
import edu.berkeley.guir.lib.util.comparator.StringComparator;

/**
 * Constants for types within a tuple. For example, String, Date, Integer,
 * Double, and so on.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Nov 21 2002, JH
 */
public final class TupleTypes {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * Is a date.
     */
    public static final int TYPE_DATE    = -1;

    /**
     * Is a double.
     */
    public static final int TYPE_DOUBLE  = -2;

    /**
     * Is an Integer.
     */
    public static final int TYPE_INTEGER = -3;

    /**
     * Is a String.
     */
    public static final int TYPE_STRING  = -4;

    //----------------------------------------------------------------

    //// Flyweight pattern, used to minimize creation of Integers.
    //// Used in mapAttrTypes
    public static final Integer INT_TYPE_DATE    = new Integer(TYPE_DATE);
    public static final Integer INT_TYPE_DOUBLE  = new Integer(TYPE_DOUBLE);
    public static final Integer INT_TYPE_INTEGER = new Integer(TYPE_INTEGER);
    public static final Integer INT_TYPE_STRING  = new Integer(TYPE_STRING);

    //----------------------------------------------------------------

    private static final Comparator COMPARATOR_DATE   = new DateComparator(
                                                         Tuple.getDateFormat());
    private static final Comparator COMPARATOR_INT    = new IntegerComparator();
    private static final Comparator COMPARATOR_DOUBLE = new DoubleComparator();
    private static final Comparator COMPARATOR_STRING = new StringComparator();

    /**
     * Given a sorttype, return a comparator. Returns a String comparator
     * if it doesn't know.
     *
     * @param sorttype is one of TupleTypes.TYPE_DATE, TYPE_DOUBLE,
     *                 TYPE_INTEGER, or TYPE_STRING
     * @see TupleTypes#TYPE_DATE
     * @see TupleTypes#TYPE_DOUBLE
     * @see TupleTypes#TYPE_INTEGER
     * @see TupleTypes#TYPE_STRING
     */
    public static Comparator getComparator(int sorttype) {
        switch (sorttype) {
            case TupleTypes.TYPE_DATE:    return (COMPARATOR_DATE);
            case TupleTypes.TYPE_DOUBLE:  return (COMPARATOR_DOUBLE);
            case TupleTypes.TYPE_INTEGER: return (COMPARATOR_INT);
            case TupleTypes.TYPE_STRING:  return (COMPARATOR_STRING);
            default:                      return (COMPARATOR_STRING);
        }
    } // of method

    //===   CONSTANTS   ========================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
