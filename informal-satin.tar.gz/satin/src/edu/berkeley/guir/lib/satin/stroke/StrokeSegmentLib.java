//// See bottom of file for software license

package edu.berkeley.guir.lib.satin.stroke;

import java.awt.geom.*;
import java.util.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.graph.*;

/**
 * Library for segmenting strokes.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v0.1/1.0.0, Mar 28 2002, JH
 *               Created 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.4
 * @version SATIN-v2.1-1.0.0, Mar 28 2002
 */
public class StrokeSegmentLib {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * Threshold for distances to be considered "near".
     */
    public static final int DEFAULT_DIST_THRESHOLD = 15;

    /**
     * Threshold for segmenting. An arbitrarily selected value that seems 
     * to work.
     */
    public static final int SEGMENT_THRESHOLD = 6;

    public static final int ENDPOINT_ANGLE = 6;

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    /**
     * Library class, no instances allowed.
     */
    private StrokeSegmentLib() {
    } // of constructor

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================




    //==========================================================================
    //===   SEGMENTING PAIR INNER CLASS ========================================

    static class IntersectingPair {
       int xx;      // index of first TimedStroke in array
       int yy;      // index of second TimedStroke in array

       public IntersectingPair(int newXX, int newYY) {
          xx = newXX;
          yy = newYY;
       } // of constructor
    } // of class

    //===   SEGMENTING PAIR INNER CLASS ========================================
    //==========================================================================





    //==========================================================================
    //===   UTILITY METHODS   ==================================================

    /**
     * Return the min value in an array of doubles.
     */
    private static double minValue(double[] arr) {
        double min = Double.MAX_VALUE;

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        return (min);
    } // of method

    //----------------------------------------------------------------

    /**
     * Calculate the average value.
     */
    private static double avg(double[] arr) {
        double sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        return (sum / arr.length);
    } // of method

    //----------------------------------------------------------------

    /**
     * Calculate the standard deviation.
     */
    private static double stdev(double[] arr) {
        double avg = avg(arr);
        double sum = 0;

        for (int i = 0; i < arr.length; i++) {
            sum += (arr[i] - avg) * (arr[i] - avg);
        }
        return (Math.sqrt(sum / arr.length));
    } // of method

    //----------------------------------------------------------------

    /**
     * See if the value at the index is a local maxima, looking forward and
     * backward one index value.
     */
    private static boolean isLocalMaxima1(double[] arr, int i) {

        if (arr.length <= 1) {
            return true;
        }
        if (i == 0) {
            return (arr[0] >= arr[1]);
        }
        else if (i == arr.length - 1) {
            return (arr[arr.length-1] >= arr[arr.length-2]);
        }
        else {
            return ((arr[i] >= arr[i+1]) && (arr[i] > arr[i-1]));
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * See if the value at the index is a local maxima, looking forward and
     * backward two index values.
     */
    private static boolean isLocalMaxima2(double[] arr, int i) {
        int     g,  h,      j,  k;  // indices relative to our current location
        double vg, vh, vi, vj, vk;  // values at these indices
        g = i - 2;
        h = i - 1;
        j = i + 1;
        k = i + 2;

        //// 0. Quick check first.
        if (arr.length <= 2) {
            return true;
        }

        //// 1. Calculate array values, substituting min value if out 
        ////    of bounds.
        if (g < 0) {
            vg = Double.MIN_VALUE;
        }
        else {
            vg = arr[g];
        }

        if (h < 0) {
            vh = Double.MIN_VALUE;
        }
        else {
            vh = arr[h];
        }

        vi = arr[i];

        if (j >= arr.length) {
            vj = Double.MIN_VALUE;
        }
        else {
            vj = arr[j];
        }

        if (k >= arr.length) {
            vk = Double.MIN_VALUE;
        }
        else {
            vk = arr[k];
        }

        //// 3. Compare.
        return (vi >= vh && 
                vi >= vg &&
                vi >  vj && 
                vi >  vk);
    } // of method

    //===   UTILITY METHODS   ==================================================
    //==========================================================================




    //==========================================================================
    //===   GEOMETRIC METHODS   ================================================

    /**
     * Find the min distance between two rectangles.
     * 
     * @return the minimum distance between two rectangles, or 0 if they
     *         intersect.
     */
    private static double distance(Rectangle2D rAA, Rectangle2D rBB) {
        if (rAA.intersects(rBB.getX(), rBB.getY(),
                           rBB.getWidth(), rBB.getHeight())) {
           return (0);
        }
        else {
            //// Calculate the four points of rectangle BB.
            double x1  = rBB.getX();
            double y1  = rBB.getY();
            double x2  = rBB.getX() + rBB.getWidth();
            double y2  = rBB.getY() + rBB.getHeight();

            //// Debugging code
            // System.out.println(rBB);
            // System.out.println("ptsB (" + x1 + ", " + y1 + ") (" + 
            //                               x2 + ", " + y2+ ")");

            //// Convert these four points into lines.
            Line2D lAA = new Line2D.Double(x1, y1, x2, y1);
            Line2D lBB = new Line2D.Double(x2, y1, x2, y2);
            Line2D lCC = new Line2D.Double(x2, y2, x1, y2);
            Line2D lDD = new Line2D.Double(x1, y2, x1, y1);

            //// Debugging code
            // System.out.println("lAA (" + 
            //                    lAA.getX1() + "," + lAA.getY1() + ") (" +
            //                    lAA.getX2() + "," + lAA.getY2() + ")");
            // System.out.println("lBB (" + 
            //                    lBB.getX1() + "," + lBB.getY1() + ") (" +
            //                    lBB.getX2() + "," + lBB.getY2() + ")");
            // System.out.println("lCC (" + 
            //                    lCC.getX1() + "," + lCC.getY1() + ") (" +
            //                    lCC.getX2() + "," + lCC.getY2() + ")");
            // System.out.println("lDD (" + 
            //                    lDD.getX1() + "," + lDD.getY1() + ") (" +
            //                    lDD.getX2() + "," + lDD.getY2() + ")");

            //// Calculate the distance from all four points of AA to lines BB.
            //// Reuse variables x1, y1, x2, y2
            x1 = rAA.getX();
            y1 = rAA.getY();
            x2 = rAA.getX() + rAA.getWidth();
            y2 = rAA.getY() + rAA.getHeight();

            //// Debugging code
            // System.out.println(rAA);
            // System.out.println("ptsA (" + x1 + ", " + y1 + ") (" + 
            //                               x2 + ", " + y2 + ")");

            //// Calculate the min distance.
            double[] dists = new double[16];

            dists[0]  = lAA.ptSegDist(x1, y1);
            dists[1]  = lAA.ptSegDist(x2, y1);
            dists[2]  = lAA.ptSegDist(x2, y2);
            dists[3]  = lAA.ptSegDist(x1, y2);

            dists[4]  = lBB.ptSegDist(x1, y1);
            dists[5]  = lBB.ptSegDist(x2, y1);
            dists[6]  = lBB.ptSegDist(x2, y2);
            dists[7]  = lBB.ptSegDist(x1, y2);

            dists[8]  = lCC.ptSegDist(x1, y1);
            dists[9]  = lCC.ptSegDist(x2, y1);
            dists[10] = lCC.ptSegDist(x2, y2);
            dists[11] = lCC.ptSegDist(x1, y2);

            dists[12] = lDD.ptSegDist(x1, y1);
            dists[13] = lDD.ptSegDist(x2, y1);
            dists[14] = lDD.ptSegDist(x2, y2);
            dists[15] = lDD.ptSegDist(x1, y2);

            //// Debugging code
            // for (int i = 0; i < 16; i++) {
            //     System.out.println(i + ": " + dists[i]);
            // }

            //// Return the min value.
            return (minValue(dists));
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * See if two strokes actually intersect or are near intersection.
     *
     * @param stkAA is the first stroke.
     * @param stkBB is the second stroke.
     * @param thresh is the distance threshold value.
     */
    private static boolean fullOrNearIntersect(TimedStroke stkAA, 
                                           TimedStroke stkBB, double thresh) {
        //// 0. Parameter checks.
        assert thresh >= 0;

        Rectangle2D bdsXX = new Rectangle2D.Float(); // first bding box
        Rectangle2D bdsYY = new Rectangle2D.Float(); // second bding box

        //// 1. Get the bounding boxes.
        stkAA.getBounds2D(SatinConstants.COORD_REL, null, bdsXX);
        stkBB.getBounds2D(SatinConstants.COORD_REL, null, bdsYY);

        //// 2. See if the bounds actually intersect.
        double dist = distance(bdsXX, bdsYY);

        //// 3. Return.
        if (dist <= thresh) {
           return true;
        }
        return (false);
    } // of method

    //----------------------------------------------------------------

    /**
     * Calculate the angle produced by these three points.
     * Borrowed from a feature in Rubine's algorithm.
     *
     * @return Value in radians representing change in angle. Negative value 
     *         means bend to left, positive value means bend to right, where 
     *         "straight" is a line from (x1,y1) to (x2,y2).
     */
    private static double calculateAngle(double x1, double y1, 
                                         double x2, double y2, 
                                         double x3, double y3) {
        double dx  = x3 - x2;
        double dy  = y3 - y2;
        double dx2 = x2 - x1;
        double dy2 = y2 - y1;
        return (Math.atan2(dx*dy2 - dx2*dy, dx*dx2 + dy*dy2));
    } // of method

    //----------------------------------------------------------------

    /**
     * @return an array of doubles, representing the velocity from
     *         point (i) to point (i+1)
     */
    private static double[] calculateVelocity(TimedStroke stk) {
       TimedPolygon2D poly     = stk.getPolygon2D(SatinConstants.COORD_ABS);
       long[]         times    = poly.times;
       float[]        xpts     = poly.xpoints;
       float[]        ypts     = poly.ypoints;
       int            len      = poly.npoints;
       double[]       velocity = new double[len];


       //// 1. Calculate the velocity at each point.
       ////    Uses max() to calculate times because of occasional 0 values.
       double         dist;
       long           time;

       for (int i = 0; i < len - 1; i++) {
          dist        = Point2D.distance(xpts[i],ypts[i],xpts[i+1],ypts[i+1]);
          time        = Math.max(times[i+1] - times[i], 10);
          velocity[i] = dist / time;
          // System.out.println(i + ": " + velocity[i] + " " + 
          //                    dist + " " + time);
       } // of for

       //// 2. Corner case for last point of stroke.
       if (len >= 2) {
           velocity[len - 1] = velocity[len - 2];
       }

       //// 3. Return.
       return (velocity);
    } // of method

    //----------------------------------------------------------------

    /**
     * @return an array of doubles, representing the angle at that point.
     *         For example, arr[i] is the angle from (i-1) to (i) to (i+1).
     *         Value is in radians representing change in angle. Negative 
     *         values mean bend to left, positive value means bend to right, 
     *         where "straight" is a line from (x1,y1) to (x2,y2).
     */
    private static double[] calculateAngleDeltas(Polygon2D poly) {

        double[]  dThetaArr = new double[poly.npoints];
        double    dTheta;
        double    dist;
        float[]   xpts      = poly.xpoints;
        float[]   ypts      = poly.ypoints;

        //// 1. Calculate the relative delta of the angle for each point.
        for (int j = 0; j < poly.npoints; j++) {
            int i, k;

            //// 1.1. Calculate the index following j.
            ////      Wraparound if the polygon is closed.
            k = j + 1;
            if (k >= poly.npoints) {
                if (poly.isClosed()) {
                    k %= poly.npoints;
                }
                else {
                    dThetaArr[j] = ENDPOINT_ANGLE;
                    continue;
                }
            }

            //// 1.2. Calculate the index following j.
            ////      Wraparound if the polygon is closed.
            i = j - 1;
            if (i < 0) {
                if (poly.isClosed()) {
                    i += poly.npoints - 1;
                }
                else {
                    dThetaArr[j] = ENDPOINT_ANGLE;
                    continue;
                }
            }

            //// 1.3. Calculate the distance and angle between the points.
            dist   = Point2D.distance(xpts[j], ypts[j], xpts[k], ypts[k]);
            dTheta = calculateAngle(xpts[i], ypts[i],
                                    xpts[j], ypts[j],
                                    xpts[k], ypts[k]);
            dThetaArr[j] = dTheta;

            /*
            //// These were fudge factors that I removed - JIH
            //// 1.4. Factor in points that are near each other.
            dist         = Math.min(20, dist);
            dThetaArr[j] = dist*dTheta;

            //// 1.5. Augment points that have a high angle.
            ////      Multiplicative value is arbitrary.
            if (Math.abs(dTheta) >= 0.7) {
                dThetaArr[j] *= 4;
            }
            */

             // System.out.println("i " + i + " j " + j + " k " + k);
             // System.out.println(j + ": " + dTheta + "\t" + dist);
        } // of for

        return (dThetaArr);
    } // of method

    //===   GEOMETRIC METHODS   ================================================
    //==========================================================================




    //==========================================================================
    //===   MULTISTROKE SEGMENTATION METHODS   =================================

    /**
     * Given a set of strokes that represent a single multistroke, segment
     * it into a graph. Segment by finding full and near intersections.
     * Uses a default threshold value for "near" distances.
     */
    public static StrokeGraph segment(TimedStroke[] stks) {
       return (segment(stks, DEFAULT_DIST_THRESHOLD));
    } // of method

    //----------------------------------------------------------------

    /**
     * Given a set of strokes that represent a single multistroke, segment
     * it into a graph. Segment by finding full and near intersections.
     *
     * @param  strokes is an array of TimedStroke objects representing 
     *         the multistroke.
     * @param  thresh is the distance threshold value for intersection,
     *         for segmenting.
     * @return a graph containing the TimedStrokes segmented into a 
     *         StrokeGraph.
     */
    public static StrokeGraph segment(TimedStroke[] stks, double thresh) {

       List        listPairs = new LinkedList();        // of IntersectingPair

       //// 1. Find all potential full and near intersections.
       ////    Check bounding boxes of all stroke pairs.
       ////    Then make a list of all of the pairs to check.
       for (int i = 0; i < stks.length; i++) {
           for (int j = i + 1; j < stks.length; j++) {
              if (fullOrNearIntersect(stks[i], stks[j], thresh)) {
                 listPairs.add(new IntersectingPair(i, j));
              }
           }
       }

       //// 2. Now that we have the pairs, segment the strokes and assemble 
       ////    the graph.



       //// 3. Go through each individual stroke, and see if they need 
       ////    further segmenting.

throw new RuntimeException("not implemented yet");


    } // of method

    //----------------------------------------------------------------

    /**
     * Given a set of strokes that represent a single multistroke, segment
     * it into a graph. This variation also allows a rectangle to be specified,
     * outside of which portions of strokes are ignored.
     */
    public static StrokeGraph segment(TimedStroke[] stks, Rectangle2D rect) {
throw new RuntimeException("not implemented yet");
    } // of method

    //===   MULTISTROKE SEGMENTATION METHODS   =================================
    //==========================================================================




    //==========================================================================
    //===   SINGLE STROKE SEGMENTATION METHODS   ===============================

    /**
     * Segment an individual stroke into separate strokes.
     * Ideally, segmentation should be based on:
     * <UL>
     *    <LI>Velocity
     *    <LI>Sharp changes in angle (inflection points)
     * </UL>
     * Right now just does sharp changes in angle.
     */
    public static StrokeGraph segment(TimedStroke stk) {
        Polygon2D   bds  = stk.getBoundingPoints2D(SatinConstants.COORD_REL);
        float[]     xpts = bds.xpoints;
        float[]     ypts = bds.ypoints;
        int         len  = bds.npoints;
        StrokeGraph g    = new StrokeGraph();


        //// 1. Calculate the relative delta of the angle for each point.
        ////    Calculate the velocity for each point as well.
        double[]  dThetaArr    = calculateAngleDeltas(bds);
        double[]  dVelocityArr = calculateVelocity(stk);


        //// 2. Calculate the angle divided by velocity.
        ////    Values above a threshold that are also local 
        ////    maxima are very likely to be inflection points.
        ////    Currently, threshold is set to the average value of
        ////    angle / velocity array.
        double[]  dAngleVelocityArr = new double[len];
        List      listPts   = new LinkedList();

        for (int i = 0; i < dVelocityArr.length; i++) {
            dAngleVelocityArr[i] = Math.abs(dThetaArr[i] / dVelocityArr[i]);
        }

        // System.out.println();
        // System.out.println("avg t  " + avg(dThetaArr) + 
        //                    "\t" + stdev(dThetaArr));
        // System.out.println("avg v  " + avg(dVelocityArr) + 
        //                    "\t" + stdev(dVelocityArr));
        // System.out.println("avg tv " + avg(dAngleVelocityArr) + 
        //                    "\t" + stdev(dAngleVelocityArr));

        double thresh = avg(dAngleVelocityArr);
        for (int i = 0; i < dAngleVelocityArr.length; i++) {
            if (Math.abs(dAngleVelocityArr[i]) >= thresh && 
                isLocalMaxima2(dAngleVelocityArr, i)) {

                listPts.add(new Integer(i));
                // System.out.print("*");
            }
            // System.out.println(i + ": " + dAngleVelocityArr[i] + 
            //                      " a:"  + dThetaArr[i] + 
            //                      " v:"  + dVelocityArr[i]);
        }

        // System.out.println("SORTING");
        // Arrays.sort(dAngleVelocityArr);
        // for (int i = 0; i < dAngleVelocityArr.length; i++) {
        //     System.out.println(dAngleVelocityArr[i]);
        // }

        //// 3. Go through the local extrema points and create new strokes
        ////    from the original stroke.
        List listStks = cutStroke(listPts, xpts, ypts, len, bds.isClosed());


        //// 4. Create a graph out of the list of strokes.
        ////    Add all the strokes, and keep track of connections.
        Iterator    it       = listStks.iterator();
        TimedStroke currStk  = null;
        TimedStroke lastStk  = null;
        TimedStroke firstStk = null;

        while (it.hasNext()) {
            //// 4.1. Add the stroke.
            currStk = (TimedStroke) it.next();
            g.addStroke(currStk);

            //// 4.2. Keep in case we need to handle the wraparound condition.
            if (firstStk == null) {
                firstStk = currStk;
            }

            //// 4.3. Add a connection.
            if (lastStk != null) {
                g.addConnection(lastStk, currStk);
            }
        }

        //// 4.4. Handle the wraparound condition.
        ////      Check for nulls, might happen if only one stroke.
        if (bds.isClosed() == true) {
            if (lastStk != null && firstStk != null) {
                g.addConnection(lastStk, firstStk);
            }
        }

        return (g);
    } // of method

    //----------------------------------------------------------------

    /**
     * Given a list of index values indicating stroke segmentation points,
     * slice the passed-in arrays into a List of TimedStrokes.
     *
     * @param  listPts        is a List of Integers representing index 
     *                        values into arrays xpts and ypts.
     * @param  xpts           is the array of x-values.
     * @param  ypts           is the array of y-values.
     * @param  flagWraparound is true if we should wrap around the points 
     *                        arrays (ie the bounds are closed)
     * @return a list of TimedStrokes in time-order of drawing.
     */
    public static List cutStroke(List listPts, float[] xpts, float[] ypts,
                                 int len, boolean flagWraparound) {

        Collections.sort(listPts);

        Iterator    it        = listPts.iterator();
        int         first     = 0;                   // wraparound condition
        int         start     = 0;                   // start of window
        int         end       = 0;                   // end of window
        List        listStks  = new LinkedList();    // list of final strokes
        boolean     flagFirst = true;                // first extrema?
        Polygon2D   poly;


        //// 3.1. If no points or only 1 point, add the entire stroke.
        if (listPts.size() <= 1) {
            poly = new Polygon2D(xpts, ypts, xpts.length);
            listStks.add(new TimedStroke(poly));
        }
        else {
            while (it.hasNext()) {
                //// 3.2. Get the next extrema value. If this is our first 
                ////      extrema, then save it as our start point and 
                ////      continue on.
                end = ((Integer) it.next()).intValue();
                if (flagFirst == true) {
                    flagFirst = false;
                    start = end;
                    first = start;
                    continue;
                }

                //// 3.3. Create a new timedstroke from start to end.
                ////      Special case to check end == start b/c start 
                ////      is init to 0 and 0 is the first value added.
                if (end == start) {
                    continue;
                }
                poly   = new Polygon2D(xpts, ypts, start, end - start + 1);
                poly.setClosed(false);
                listStks.add(new TimedStroke(poly));

                //// 3.4. Slide the window forward.
                start = end;
            }

            //// 3.5. Handle the wraparound condition.
            if (flagWraparound == true) {
                float[] xpoints = new float[len - end + first + 1];
                float[] ypoints = new float[len - end + first + 1];
                int     copylen = len - end;

                System.arraycopy(xpts, end, xpoints, 0,       copylen);
                System.arraycopy(ypts, end, ypoints, 0,       copylen);
                System.arraycopy(xpts, 0,   xpoints, copylen, first);
                System.arraycopy(ypts, 0,   ypoints, copylen, first);

                poly = new Polygon2D(xpoints, ypoints, xpoints.length);
                poly.setClosed(false);
                listStks.add(new TimedStroke(poly));
            }
        }

        return (listStks);
    } // of method

    //===   SINGLE STROKE SEGMENTATION METHODS   ===============================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static void main(String[] argv) {
    } // of main

    //----------------------------------------------------------------

    private static void testCalculateAngle() {
        System.out.println(Math.toDegrees(calculateAngle(0, 0, 10, 0, 10,    10)));
        System.out.println(Math.toDegrees(calculateAngle(0, 0, 10, 0, 17.07, 7.07)));  //  45
        System.out.println(Math.toDegrees(calculateAngle(0, 0, 10, 0, 2.928, 7.07)));  // 135
        System.out.println(Math.toDegrees(calculateAngle(0, 0, 10, 0, 18.66, 5)));     //  30
        System.out.println(Math.toDegrees(calculateAngle(0, 0, 10, 0, 1.34, 5)));     // 150
    } // of method

    //----------------------------------------------------------------

    private static void testRectDistance(String[] argv) {
        Rectangle2D rAA = new Rectangle2D.Float();
        Rectangle2D rBB = new Rectangle2D.Float();

        rAA.setRect(0, 0, 10, 10);
        rBB.setRect(0, 0, 10, 10);
        System.out.println(distance(rAA, rBB));
        System.out.println();

        rAA.setRect(0, 0, 10, 10);
        rBB.setRect(5, 5, 10, 10);
        System.out.println(distance(rAA, rBB));
        System.out.println();

        rAA.setRect(0,   0, 10, 10);
        rBB.setRect(10, 10, 10, 10);
        System.out.println(distance(rAA, rBB));
        System.out.println();

        rAA.setRect(0,   0, 10, 10);
        rBB.setRect(11, 11, 10, 10);
        System.out.println(distance(rAA, rBB));
        System.out.println();

        rAA.setRect(0,   0, 10, 10);
        rBB.setRect(0,  12, 10, 10);
        System.out.println(distance(rAA, rBB));
        System.out.println();

        rAA.setRect(0,   0, 10, 10);
        rBB.setRect(1,  12, 10, 10);
        System.out.println(distance(rAA, rBB));
        System.out.println();

        rAA.setRect(  0,   0, 10, 10);
        rBB.setRect(100, 100, 10, 10);
        System.out.println(distance(rAA, rBB));
        System.out.println();

    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2002 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/


