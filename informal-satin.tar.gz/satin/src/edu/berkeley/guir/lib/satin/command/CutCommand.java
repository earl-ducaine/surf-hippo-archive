//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import java.util.*;

/**
 * Cut a Graphical Object to the clipboard.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 15 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-2.0.0, Oct  2 2000, JL
 *               Rearranged class hierarchy so that DeleteCommand is now the
 *               parent, not a descendant
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-2.0.0, Oct 2 2000
 */
public class CutCommand
   extends DeleteCommand {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 6107827467298680138L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   protected static Clipboard myClipboard = SatinConstants.clipboard;

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================

   
   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public CutCommand() {
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create the cut command object, cutting the specified GraphicalObject into
    * the clipboard.
    *
    * @param gob is the Graphical Object to cut.
    */
   public CutCommand(GraphicalObject gob) {
      super(gob);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Make the specified collection of Graphical Objects the list of Graphical
    * Objects to cut into the clipboard.
    *
    * @param it is an Iterator of Graphical Objects.
    */
   public CutCommand(Iterator it) {
      super(it);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Make the specified collection of Graphical Objects the list of Graphical
    * Objects to cut into the clipboard.
    *
    * @param gobs is a Vector of Graphical Objects.
    */
   public CutCommand(Vector gobs) {
      super(gobs);
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      return ("Cut Graphical Object to clipboard");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   STATUS ACCESSOR METHODS   ===========================================

   public boolean canRedo() {
      return (false);
   } // of canRedo

   //-----------------------------------------------------------------

   public boolean canUndo() {
      return (true);
   } // of canUndo

   //-----------------------------------------------------------------

   public boolean isSignificant() {
      return (true);
   } // of isSignificant

   //===   STATUS ACCESSOR METHODS   ===========================================
   //===========================================================================

   /**
    * Sets which clipboard paste commands should paste from.
    */
   public static void setClipboard(Clipboard newClipboard) {
      myClipboard = newClipboard;
   }
   
   /**
    * Gets which clipboard paste commands should paste from.
    */
   public static Clipboard getClipboard() {
      return myClipboard;
   }
   


   //===========================================================================
   //===   ACTION METHODS   ====================================================

   public void run() {
      if (gobToParent.isEmpty()) {
         return;
      }
      
      //// 1. Copy to the clipboard.
      myClipboard.clearClipboard();
      myClipboard.copyToClipboard(gobToParent.keySet().iterator());

      //// 2. Delete the copied Graphical Objects.
      super.run();
   } // of method

   //===   ACTION METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
