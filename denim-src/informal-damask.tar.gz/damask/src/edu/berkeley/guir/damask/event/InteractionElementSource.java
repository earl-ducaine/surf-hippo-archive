package edu.berkeley.guir.damask.event;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;

/** 
 * A source of InteractionElementEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-10-2003 James Lin
 *                               Created InteractionElementSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-10-2003
 */
public class InteractionElementSource {
   
   private Vector/*<InteractionElementListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public synchronized void addInteractionElementListener(
      InteractionElementListener listener) {

      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public synchronized void removeInteractionElementListener(
      InteractionElementListener listener) {

      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementBoundsUpdated events to listeners.
    */
   public void fireElementBoundsUpdated(
      final InteractionElement e,
      final DeviceType deviceType) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final InteractionElementEvent event =
         new InteractionElementEvent(
            e,
            InteractionElementEvent.BOUNDS_UPDATED,
            deviceType);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final InteractionElementListener listener =
            (InteractionElementListener)i.next();

         listener.elementBoundsUpdated(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementTransformUpdated events to listeners.
    */
   public void fireElementTransformUpdated(
      final InteractionElement e,
      final DeviceType deviceType) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final InteractionElementEvent event =
         new InteractionElementEvent(
            e,
            InteractionElementEvent.TRANSFORM_UPDATED,
            deviceType);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final InteractionElementListener listener =
            (InteractionElementListener)i.next();

         listener.elementTransformUpdated(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementBorderUpdated events to listeners.
    */
   public void fireElementBorderUpdated(
      final InteractionElement e,
      final DeviceType deviceType) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final InteractionElementEvent event =
         new InteractionElementEvent(
            e,
            InteractionElementEvent.BORDER_UPDATED,
            deviceType);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final InteractionElementListener listener =
            (InteractionElementListener)i.next();

         listener.elementBorderUpdated(event);
      }
   }
}
