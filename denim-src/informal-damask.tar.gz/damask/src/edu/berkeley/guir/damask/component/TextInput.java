package edu.berkeley.guir.damask.component;

import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.util.*;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.view.visual.component.TextBox;
import edu.umd.cs.piccolo.PNode;


/** 
 * A input control, which represents text input from the end user.
 * This can be rendered as a text field. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-30-2003 James Lin
 *                               Created InputText
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 04-30-2003
 */
public class TextInput extends Control {
   public static final String RESPONSE_TEXT = "*";
   
   private Map/*<DeviceType, GeneralPath>*/ borders =
      new HashMap/*<DeviceType, GeneralPath>*/();

   // Initialize default transform for content inside trigger
   private static final Rectangle2D DEFAULT_TEXT_INPUT_BOUNDS;
   static {
      final PNode textBox = TextBox.createTempView();
      DEFAULT_TEXT_INPUT_BOUNDS = textBox.getBounds();
   }
   
   //===========================================================================

   /**
    * Constructs a text input control.
    * 
    * @param deviceType the device type that this control supports. Can be
    * DeviceType.ALL.
    */
   public TextInput(final DeviceType deviceType) {
      super(deviceType);
      init();
   }
   
   //---------------------------------------------------------------------------

   /**
    * Constructs a text input control supporting the specified device type,
    * copying properties from the specified text input control.
    * 
    * @param textInput the control whose properties will be copied
    * @param deviceType the device type that this control supports. Can be
    * DeviceType.ALL.
    */
   public TextInput(final TextInput textInput, final DeviceType deviceType) {
      super(textInput, deviceType);
      borders = new HashMap/*<DeviceType, GeneralPath>*/(textInput.borders);
      init();
   }

   //---------------------------------------------------------------------------
   
   private void init() {
      addVoiceResponseText(0, RESPONSE_TEXT);
   }
   
   //===========================================================================

   /**
    * Returns what the border of this text input should be if it is rendered
    * as a button for the specified device type, or null if there is no border.
    */
   public GeneralPath getBorder(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      return (GeneralPath)borders.get(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets what the border of this text input should be if it is rendered
    * as a button for the specified device type. 
    */
   public void setBorder(final DeviceType deviceType, final GeneralPath border){
      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(deviceType),
         this + " supports " + getDeviceType() + ", not " + deviceType);

      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext(); ) {
         
         final DeviceType aDeviceType = (DeviceType)i.next();
         borders.put(aDeviceType, border);
      }
   }

   //===========================================================================

   /**
    * Returns the content of this control, which is always null.
    */
   public Content getContent() {
      return null;
   }

   //===========================================================================

   // @Override
   protected void autoPositionForDesktop() {
      setBounds(DeviceType.DESKTOP, DEFAULT_TEXT_INPUT_BOUNDS);
      setBorder(DeviceType.DESKTOP, new GeneralPath(DEFAULT_TEXT_INPUT_BOUNDS));
      placeAfterAllControls(DeviceType.DESKTOP);
   }

   //---------------------------------------------------------------------------

   // @Override
   protected void autoPositionForSmartphone() {
      setBounds(DeviceType.SMARTPHONE, DEFAULT_TEXT_INPUT_BOUNDS);
      setBorder(DeviceType.SMARTPHONE, new GeneralPath(DEFAULT_TEXT_INPUT_BOUNDS));
      placeAfterAllControls(DeviceType.SMARTPHONE);
   }

   //---------------------------------------------------------------------------

   // @Override
   protected void autoPositionForVoice() {
   }
   
   // @Override
   protected void setupVoiceResponses() {
      setupVoiceResponseForControlWithResponseOnly();
   }

   //===========================================================================

   public Component createCopy(final DeviceType deviceType) {
      return new TextInput(this, deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      final TextInput clone = (TextInput)super.clone();

      clone.borders = new HashMap();
      for (Iterator i = borders.keySet().iterator(); i.hasNext(); ) {
         final DeviceType deviceType = (DeviceType)i.next();
         clone.borders.put(
            deviceType,
            ((GeneralPath)borders.get(deviceType)).clone());
      }

      return clone;
   }
}
