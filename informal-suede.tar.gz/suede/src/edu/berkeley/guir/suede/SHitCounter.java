package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;

public class SHitCounter extends javax.swing.JLabel
{
    private int m_hits = 0;
    private Color m_circleColor;
    
    public SHitCounter(Color c) {
        setOpaque(false);
        setForeground(Color.white);
        setText("0");
        setHorizontalAlignment(CENTER);
        m_circleColor = c;
    }

    public void setHits(int i) {
        m_hits = i;
        setText(Integer.toString(i));
    }

    public void paintComponent(Graphics g) {  
        Graphics2D g2d = (Graphics2D)g;
        g2d.setColor((m_hits==0) ? Color.gray : m_circleColor);
        g2d.setFont(g2d.getFont().deriveFont(Font.BOLD, 13));
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Ellipse2D oval = new Ellipse2D.Float(getWidth()/2 - getHeight()*0.3f, getHeight()*0.27f, 
                                             getHeight()*0.54f, getHeight()*0.54f);
        g2d.fill(oval);
        super.paintComponent(g);
    }
    
}