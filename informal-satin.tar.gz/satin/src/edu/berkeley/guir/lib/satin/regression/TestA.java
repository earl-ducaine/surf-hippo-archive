package edu.berkeley.guir.lib.satin.regression;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.satin.util.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.metrics.*;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import java.util.Random;


public class TestA 
   implements SatinConstants {

   Sheet     s;
   Rectangle rect;

//----------------------

   public TestA() {
      JFrame f;
      s = new Sheet();
      f = new JFrame();

      s.setVisible(true);
      f.getContentPane().add(s);
      f.setSize(800, 800);
      f.show();
   }

//----------------------

   public class RegressionAddStroke extends ActionItem {

      public void init() {
         s.clear();
      }
   
      public final void doit() {
         s.addToBack(SatinRandomLib.getRandomStroke(rect, 10));
      }
   
      public String getName() {
         return ("Add Stroke");
      }
   }

//----------------------

   public class RegressionAddPatch extends ActionItem {

      public void init() {
         s.clear();
      }
   
      public final void doit() {
         s.addToFront(SatinRandomLib.getRandomPatch(rect));
      }
   
      public String getName() {
         return ("Add Patch");
      }
   } // of 

//----------------------

   public class RegressionTransform extends ActionItem {

      AffineTransform tx;
      String          str;

      public RegressionTransform(AffineTransform tx, String str) {
         this.tx  = tx;
         this.str = str;
      }
   
      public final void doit() {
         s.applyTransform(tx);
      }
   
      public String getName() {
         return (str);
      } // of 
   }

//----------------------

   public class AnimationTransform extends ActionItem {

      AffineTransform[] txArray;
      String            str;
      int               i = 0;

      public AnimationTransform(AffineTransform[] txArray, String str) {
         this.txArray = txArray;
         this.str     = str;
      } 

      public final void doit() {
         s.applyTransform(txArray[i++]);
      } 

      public String getName() {
         return (str);
      } // of 

   } // of AnimationTransform 

//----------------------

   public static AffineTransform
   scaleAndKeepConstant(double scale, int x, int y) {

      AffineTransform tx;

      //// These are numbered backwards since you concatenate backwards
      //// with transforms.

      //// 3. Move back to where we were.
      tx = AffineTransform.getTranslateInstance(x, y);

      //// 2. Scale.
      tx.concatenate(AffineTransform.getScaleInstance(scale, scale));

      //// 1. Move the origin to the specified point.
      tx.concatenate(AffineTransform.getTranslateInstance(-x, -y));

      return (tx);
   } // of scaleAndKeepConstant

//----------------------

   public void suiteZoom() {
      AffineTransform tx;

      tx = scaleAndKeepConstant(1.01, s.getWidth()/2, s.getHeight()/2);
      Regression.run(new RegressionTransform(tx, "Zoom In"), 20);

      tx = scaleAndKeepConstant(0.99, s.getWidth()/2, s.getHeight()/2);
      Regression.run(new RegressionTransform(tx, "Zoom Out"), 20);

      tx = scaleAndKeepConstant(0.99, s.getWidth()/2, s.getHeight()/2);
      Regression.run(new RegressionTransform(tx, "Zoom Out"), 20);

      tx = scaleAndKeepConstant(1.01, s.getWidth()/2, s.getHeight()/2);
      Regression.run(new RegressionTransform(tx, "Zoom In"), 20);
   }

   public void suiteAnimate() {
      AffineTransform[] txArray;

      txArray = AffineTransformLib.animateSlowInSlowOut(scaleAndKeepConstant(3, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Zoom In"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Right"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(-Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Left"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(scaleAndKeepConstant(1.0/3.0, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Zoom Out"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Right"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(-Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Left"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(scaleAndKeepConstant(1.0/3.0, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Zoom Out"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Right"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(AffineTransform.getRotateInstance(-Math.PI/2, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Rotate Left"), 20);

      txArray = AffineTransformLib.animateSlowInSlowOut(scaleAndKeepConstant(3, s.getWidth()/2, s.getHeight()/2), 20);
      Regression.run(new AnimationTransform(txArray, "Animate Zoom In"), 20);

   } 



//----------------------


   public void test() {
      int x = (int) (-0.5*s.getWidth());
      int y = (int) (-0.5*s.getHeight());
      int w = 2*s.getWidth();
      int h = 2*s.getHeight();

      rect = new Rectangle(x, y, w, h);

System.out.println("Visible Tests");
System.out.println("-----------");
      s.clear();
      s.setTransform(new AffineTransform());

      GraphicalObject              gob;
      SemanticZoomView             v;
      SemanticZoomMultiViewImpl med;
      Random                       rand = new Random();

      double fIn    = rand.nextDouble();
      double start  = rand.nextDouble() + 1;
      double end    = rand.nextDouble() + 2;
      double fOut   = rand.nextDouble() + 3;

      gob  = s.addToFront(new PatchImpl(new Rectangle(300, 300, 300, 300)));
      med  = new SemanticZoomMultiViewImpl();
      v    = new SemanticZoomViewWrapper(((GraphicalObjectImpl) gob).getClassPropertyView());
      v.setDisplayRange(fIn, start, end, fOut);
      med.add(v);
      gob.setView(med);

      suiteZoom();
      suiteAnimate();

System.out.println("Not Visible Tests");
System.out.println("-----------------");
      gob.moveTo(COORD_REL, 900000, 900000);
      suiteZoom();
      suiteAnimate();

   } // of test

//----------------------

   public static void main(String[] argv) throws Exception {
      new TestA().test();
   } // of main

//----------------------

}
