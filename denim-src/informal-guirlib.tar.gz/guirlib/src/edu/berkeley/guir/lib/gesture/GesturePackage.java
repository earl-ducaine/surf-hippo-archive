package edu.berkeley.guir.lib.gesture;

import java.io.*;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import edu.berkeley.guir.lib.gesture.util.CollectionEvent;
import edu.berkeley.guir.lib.gesture.util.TokenReader;

/** A collection of a training set and zero or more test sets. */
public class GesturePackage extends AbstractGestureContainer {
  protected GestureSet trainingSet = null;
  protected GestureMetaSet testSets = null;
  
  /** arguments provided to Observers */
  public static final String TEST_SET_ADDED = "test set added";

  public GesturePackage()
  {
    this(new GestureSet());
    trainingSet.setName("Training");
  }

  public GesturePackage(GestureSet trainingSet)
  {
    this(trainingSet, new GestureMetaSet());
    testSets.setName("Test");
  }

  public GesturePackage(GestureSet trainingSet, GestureMetaSet testSets)
  {
    super();
    setTrainingSet(trainingSet);
    setTestSets(testSets);
  }

  public GestureSet getTrainingSet()
  {
    return trainingSet;
  }
  
  public void setTrainingSet(GestureSet gs)
  {
    if (trainingSet != null) {
      trainingSet.removeCollectionListener(collectionListener);
      trainingSet.removePropertyChangeListener(propChangeListener);
      trainingSet.setParent(null);
    }
    GestureSet oldSet = trainingSet;
    trainingSet = gs;
    if (trainingSet != null) {
      /*
      System.out.println("adding listeners in " + this + " on " +
			 trainingSet);
      */
      trainingSet.setParent(this);
      trainingSet.addCollectionListener(collectionListener);
      trainingSet.addPropertyChangeListener(propChangeListener);
    }
    fireCollectionEvent(CollectionEvent.ELEMENT_CHANGED, gs, 0);
    propChangeSupport.firePropertyChange(CHILDREN_PROP, oldSet, gs);
  }

  public GestureMetaSet getTestSets()
  {
    return testSets;
  }

  public void setTestSets(GestureMetaSet sets)
  {
    if (testSets != null) {
      testSets.removeCollectionListener(collectionListener);
      testSets.removePropertyChangeListener(propChangeListener);
      testSets.setParent(null);
    }
    GestureMetaSet oldValue = testSets;
    testSets = sets;
    if (testSets != null) {
      testSets.setParent(this);
      testSets.addCollectionListener(collectionListener);
      testSets.addPropertyChangeListener(propChangeListener);
    }
    fireCollectionEvent(CollectionEvent.ELEMENT_CHANGED, sets, 1);
    propChangeSupport.firePropertyChange(CHILDREN_PROP, oldValue, sets);
  }

  protected List getChildren()
  {
    Object[] a = { trainingSet, testSets };
    return Arrays.asList(a);
  }

  private static final Class[] CHILD_TYPES = {
    GestureMetaSet.class, GestureSet.class
  };
  public Class[] getChildTypes()
  {
    return CHILD_TYPES;
  }

  public void write(Writer writer)
  throws IOException
  {
    writer.write("name\t" + name + "\n");
    if (author != null) {
      writer.write("author\t" + author + "\n");
    }
    writer.write("training\n");
    trainingSet.write(writer);
    writer.write("test\n");
    testSets.write(writer);
    writer.write("endpackage\n");
  }
  
  public static GesturePackage read(Reader reader)
    throws IOException, ParseException
  {
    GesturePackage result = new GesturePackage();
    
    boolean done = false;
    TokenReader r = new TokenReader(reader);
    while (!done) {
      String token;
      try {
	token = r.readToken().intern();
	//System.out.println("GesturePackage\ttoken: " + token);
	if (token == "name") {
	  result.name = r.readLine();
	}
	else if (token == "author") {
	  result.author = r.readLine();
	}
	else if (token == "training") {
	  result.setTrainingSet(GestureSet.read(r));
	}
	else if (token == "test") {
	  result.setTestSets(GestureMetaSet.read(r));
	}
	else if (token == "endpackage") {
	  done = true;
	}
      }
      catch (EOFException e) {
	done = true;
      }
    }

    if (result.name == null) {
      result.name = result.trainingSet.getName();
    }
    result.trainingSet.setName("Training Set");
    result.testSets.setName("Test Sets");
    
    return result;
  }
}
