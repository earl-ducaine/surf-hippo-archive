package edu.berkeley.guir.denim;
 
import edu.berkeley.guir.denim.view.PanelBarView;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.SatinGraphics;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.view.*;
import java.awt.geom.*;
import java.awt.*;
import javax.swing.*;

/**
 * The control widget above each panel that lets the designer set which
 * condition of the panel he or she wants to see.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * Revisions:  1.0.0  11-13-2000  JL
 *                    Created.
 * 			   1.1.0  01-27-2003 YL
 *                    Fixed the bug of setVisible(boolean flag) by checking the class type
 *
 * @see     DenimPanel
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.3
 * @version Version 1.0.0, 11-03-2000
 */

public class PanelBar extends PatchImpl
                      implements DenimConstants {

   private static final int WIDTH = 100;
   private static final int HEIGHT = 20;
   private static final int ARROW_HEIGHT = HEIGHT / 2;
   private static final int ARROW_WIDTH = ARROW_HEIGHT / 2;
   private static final int GAP = 3;

   private PanelBarView pbView;
   private Patch leftArrow;
   private JLabel condLabel;
   private GObJComponentWrapper currentCond;
   private Patch rightArrow;
   private Patch deleteWidget;

   //===========================================================================

   /**
    * Handles taps on the panel bar's left arrow.
    */
   public class TapLeftArrowInterpreter
      extends DefaultInterpreterImpl {

      //-----------------------------------------------------------------

      public TapLeftArrowInterpreter() {
         commonInitializations();
      } // of constructor

      //-----------------------------------------------------------------

      private void commonInitializations() {
         setName("Panel Bar Tap Interpreter");
         setAcceptMiddleButton(false);
         setAcceptRightButton(false);
      } // of commonInitializations

      //-----------------------------------------------------------------

      public void handleSingleStroke(SingleStrokeEvent evt) {
         //// 1. If the length is too long, it's not a tap.
         TimedStroke stk = evt.getStroke();
         if (!StrokeLib.isTap(stk)) {
            return;
         }

         DenimPanel panel = PanelBar.this.getPanel();
         int currentCond = panel.getCurrentDesignTimeCondition();
         if (currentCond == 1) {
            panel.setCurrentDesignTimeCondition(panel.getNumConditions());
         }
         else {
            panel.setCurrentDesignTimeCondition(currentCond - 1);
         }
      } // of handleSingleStroke

      //-----------------------------------------------------------------

      public Object clone() {
         return (new TapLeftArrowInterpreter());
      } // of clone

   } // of class

   //===========================================================================

   /**
    * Handles taps on the panel bar's right arrow.
    */
   public class TapRightArrowInterpreter
      extends DefaultInterpreterImpl {

      //-----------------------------------------------------------------

      public TapRightArrowInterpreter() {
         commonInitializations();
      } // of constructor

      //-----------------------------------------------------------------

      private void commonInitializations() {
         setName("Panel Bar Tap Interpreter");
         setAcceptMiddleButton(false);
         setAcceptRightButton(false);
      } // of commonInitializations

      //-----------------------------------------------------------------

      public void handleSingleStroke(SingleStrokeEvent evt) {
         //// 1. If the length is too long, it's not a tap.
         TimedStroke stk = evt.getStroke();
         if (!StrokeLib.isTap(stk)) {
            return;
         }

         DenimPanel panel = PanelBar.this.getPanel();
         int currentCond = panel.getCurrentDesignTimeCondition();
         if (currentCond == panel.getNumConditions()) {
            panel.setCurrentDesignTimeCondition(1);
         }
         else {
            panel.setCurrentDesignTimeCondition(currentCond + 1);
         }
      } // of handleSingleStroke

      //-----------------------------------------------------------------

      public Object clone() {
         return (new TapRightArrowInterpreter());
      } // of clone

   } // of class

   public class TapDeleteInterpreter 
       extends DefaultInterpreterImpl {
    
       //-----------------------------------------------------------------
    
       public TapDeleteInterpreter() {
          commonInitializations();
       } // of constructor
    
       //-----------------------------------------------------------------
    
       private void commonInitializations() {
          setName("Panel Bar Tap Interpreter");
          setAcceptMiddleButton(false);
          setAcceptRightButton(false);
       } // of commonInitializations
    
       //-----------------------------------------------------------------
    
       public void handleSingleStroke(SingleStrokeEvent evt) {
          //// 1. If the length is too long, it's not a tap.
          TimedStroke stk = evt.getStroke();
          if (!StrokeLib.isTap(stk)) {
             return;
          }
    
          DenimPanel panel = PanelBar.this.getPanel();
          int currentCond = panel.getCurrentDesignTimeCondition();
          panel.removeCondition(currentCond);
       } // of handleSingleStroke
    
       //-----------------------------------------------------------------
    
       public Object clone() {
          return (new TapDeleteInterpreter());
       } // of clone
    
    } // of class

   //===========================================================================

   private static class DeleteButton extends PanelBarArrow {

       static GeneralPath deletePath = new GeneralPath();
       static {
           deletePath.moveTo(0, 0);
           deletePath.lineTo(ARROW_WIDTH*2, ARROW_HEIGHT);
           deletePath.moveTo(0, ARROW_HEIGHT);
           deletePath.lineTo(ARROW_WIDTH*2, 0);
       }

       DeleteButton(Shape s) {
           super(s);
        }
       
       public void defaultRender(SatinGraphics g)
       {
           g.draw(deletePath);
       }
   }
   
   private static class PanelBarArrow extends PatchImpl {
      PanelBarArrow(Shape s) {
         super(s);
      }

      //-----------------------------------------------------------------

      public boolean shapeContains(int cdsys, Point2D pt) {
         //// A. Acquire soft-state.
         AffineTransform tx;
         Point2D         ptTmp = new Point2D.Double();

         //// 1. Get the appropriate coordinate transform to put us into
         ////    local coordinates.
         switch (cdsys) {
            case COORD_ABS:
               tx = DenimUtils.getTrueInvAbsXform(this);
               break;
            case COORD_REL:
            case COORD_LOCAL:
               //// for the other two cases
               tx = getInverseTransform(cdsys);
               break;
            default:
               throw new RuntimeException("Unknown coordinate system parameter");
         }

         //// 2. Now transform the point.
         ptTmp.setLocation(pt.getX(), pt.getY());
         tx.transform(ptTmp, ptTmp);

         //// 3. Delegate to our view handler.
         boolean flagReturn = shapeContainsInternal(pt);

         return (flagReturn);
      } // of method
      //-----------------------------------------------------------------

      public boolean shapeContains(int cdsys, Shape s) {
         //debug.println("comparing abs: " +
         //              DenimUtils.toShortString(DenimUtils.getTrueAbsBds(this)) + " to " +
         //              DenimUtils.toShortString(s.getBounds2D()));
         //// A. Acquire soft-state.
         AffineTransform tx;
         Polygon2D       poly = new Polygon2D();

         //// 1. Get the appropriate transform.
         switch (cdsys) {
            case COORD_ABS:
               tx = DenimUtils.getTrueInvAbsXform(this);
               break;
            case COORD_REL:
            case COORD_LOCAL:
               //// for the other two cases
               tx = getInverseTransform(cdsys);
               break;
            default:
               throw new RuntimeException("Unknown coordinate system parameter");
         }

         //// 2. Set the polygon.
         poly.setToPathIterator(s.getPathIterator(tx));
         //debug.println("comparing local: " +
         //              DenimUtils.toShortString(getLocalBoundingPoints2DRef().getBounds2D()) + " to " +
         //              DenimUtils.toShortString(poly.getBounds2D()));

         //// 3. Now check if we contain the shape.
         boolean flagReturn = shapeContainsInternal(poly);

         return (flagReturn);
      } // of method

      //-----------------------------------------------------------------

      public boolean shapeIntersects(int cdsys, Shape s) {
         //// A. Acquire soft-state.
         AffineTransform tx;
         Polygon2D       poly = new Polygon2D();

         //// 1. Get the appropriate transform.
         switch (cdsys) {
            case COORD_ABS:
               tx = DenimUtils.getTrueInvAbsXform(this);
               break;
            case COORD_REL:
            case COORD_LOCAL:
               //// for the other two cases
               tx = getInverseTransform(cdsys);
               break;
            default:
               throw new RuntimeException("Unknown coordinate system parameter");
         }

         //// 2. Set the polygon.
         poly.setToPathIterator(s.getPathIterator(tx));

         //// 3. Now check if we intersect the shape.
         boolean flagReturn = shapeIntersectsInternal(poly);

         return (flagReturn);
      } // of method

   }

   //===========================================================================


   protected PanelBar() {
      this.setBoundingPoints2D(COORD_REL,
                               new Rectangle2D.Double(0,
                                0,
                                WIDTH,
                                HEIGHT));
      commonInit();
   }
   //-----------------------------------------------------------------
   /**
    * Creates a new conditional control strip for the given panel and adds
    * it to the panel.
    */
   public PanelBar(DenimPanel p) {
      // Make the control the right size
      Rectangle2D labelAbsBds = p.getLabel().getBounds2D(COORD_ABS);
      Rectangle2D condCtlAbsBds =
         new Rectangle2D.Double(labelAbsBds.getX(),
                                labelAbsBds.getY() - HEIGHT,
                                WIDTH,
                                HEIGHT);
      this.setBoundingPoints2D(COORD_ABS, condCtlAbsBds);
      commonInit();
      
      // Add it to the panel
      p.addToFront(this, GraphicalObjectGroup.KEEP_ABS_POS);
   }

   //-----------------------------------------------------------------
   
   private void commonInit() {
      // Set up the sticky view
      pbView = new PanelBarView(this.getView());
      double curScaleFactor =
         GraphicalObjectLib.getScaleFactor(COORD_ABS, this);
      pbView.setDesiredScale(curScaleFactor);
      this.setView(pbView);
      // Set the styles
      Style style = this.getStyleRef();
      style.setFillColorRGBA(255, 255, 255, 128);
      style.setDrawColor(Color.black);
      style.setLineWidth(1.0f);
      // Add left arrow
      GeneralPath leftArrowPath = new GeneralPath();
      leftArrowPath.moveTo(ARROW_WIDTH, 0);
      leftArrowPath.lineTo(0, ARROW_HEIGHT / 2);
      leftArrowPath.lineTo(ARROW_WIDTH, ARROW_HEIGHT);
      leftArrowPath.closePath();
      leftArrow = new PanelBarArrow(leftArrowPath);
      leftArrow.setInkInterpreter(new TapLeftArrowInterpreter());
      this.add(leftArrow);
      leftArrow.getStyleRef().setLineWidth(1.0f);
      leftArrow.getStyleRef().setFillColor(Color.black);
      leftArrow.moveTo(COORD_REL, ARROW_WIDTH, (HEIGHT - ARROW_HEIGHT) / 2);

      // Add # of #
      condLabel = new JLabel();
      refresh();
      currentCond = new GObJComponentWrapper(condLabel);
      this.add(currentCond);
      currentCond.moveTo(COORD_REL,
         leftArrow.getLocation2D(COORD_REL).getX() +
         leftArrow.getBounds2D(COORD_REL).getWidth() +
         GAP,
         (HEIGHT - currentCond.getBounds2D(COORD_REL).getHeight()) / 2);
      // Add right arrow
      GeneralPath rightArrowPath = new GeneralPath();
      rightArrowPath.moveTo(0, 0);
      rightArrowPath.lineTo(ARROW_WIDTH, ARROW_HEIGHT / 2);
      rightArrowPath.lineTo(0, ARROW_HEIGHT);
      rightArrowPath.closePath();
      rightArrow = new PanelBarArrow(rightArrowPath);
      rightArrow.setInkInterpreter(new TapRightArrowInterpreter());
      this.add(rightArrow);
      rightArrow.getStyleRef().setLineWidth(1.0f);
      rightArrow.getStyleRef().setFillColor(Color.black);
      rightArrow.moveTo(COORD_REL,
                        currentCond.getLocation2D(COORD_REL).getX() +
                        currentCond.getBounds2D(COORD_REL).getWidth() +
                        GAP,
                        (HEIGHT - ARROW_HEIGHT) / 2);

      // Add delete
      deleteWidget = new DeleteButton(new Rectangle2D.Double(0,0, ARROW_WIDTH*2, ARROW_HEIGHT));
      deleteWidget.setInkInterpreter(new TapDeleteInterpreter());
      this.add(deleteWidget);
      deleteWidget.getStyleRef().setLineWidth(1.0f);
      deleteWidget.getStyleRef().setFillColor(Color.lightGray);
      deleteWidget.moveTo(COORD_REL,
                        WIDTH - ARROW_WIDTH * 2 - GAP,
                        (HEIGHT - ARROW_HEIGHT) / 2);

      setAddLeftButtonStrokes(false);
   }
   
   //-----------------------------------------------------------------

   public void handleSingleStroke(SingleStrokeEvent evt) {
       //// 1. If the length is too long, it's not a tap.
       TimedStroke stk = evt.getStroke();
       if (!StrokeLib.isTap(stk)) {
           Point2D ps = stk.getStartPoint2D(COORD_ABS);
           Point2D pe = stk.getEndPoint2D(COORD_ABS);
           DenimPanel panel = PanelBar.this.getPanel();
           int currentCond = panel.getCurrentDesignTimeCondition();
           if(pe.getX()-ps.getX()>0)
           {
               if (currentCond == panel.getNumConditions()) {
                   panel.setCurrentDesignTimeCondition(1);
                }
                else {
                   panel.setCurrentDesignTimeCondition(currentCond + 1);
                }
           }
           else
           {
               if (currentCond == 1) {
                  panel.setCurrentDesignTimeCondition(panel.getNumConditions());
               }
               else {
                  panel.setCurrentDesignTimeCondition(currentCond - 1);
               }
           }
       }
       
       evt.setConsumed();
    } // of handleSingleStroke
   
   public void initAfterAddToSheet() {
      setupSemanticZoom();
      if (getPanel().getNumConditions() == 1) {
         setVisible(false);
      }
   }
   //-----------------------------------------------------------------

   /**
    * Sets up the semantic zoom view for the control strip.
    */
   private void setupSemanticZoom() {
      //debug.printStackTrace();
      SemanticZoomMultiViewImpl views = new SemanticZoomMultiViewImpl();

      double absScaleJustBelowSitemap =
            DenimUtils.getAbsScaleFactorAt(this, SITEMAP_SCALE_FACTOR + .01);

      double absScaleBetweenSitemapAndStoryboard =
            DenimUtils.getAbsScaleFactorAt(this, ZOOM_NOTCH_40);

      // 2. Apply the semantic view wrapper

      //// Sketch is displayed from notch between sitemap and storyboard
      //// to below
      SemanticZoomViewWrapper v = new SemanticZoomViewWrapper(this.getView());
      v.setDisplayRange(
        absScaleJustBelowSitemap, absScaleBetweenSitemapAndStoryboard,
        1000,                     1000);
      views.add(v);

      this.setView(views);

   } // of method

   //-----------------------------------------------------------------

   /**
    * Returns the panel which the control strip affects.
    */
   public DenimPanel getPanel() {
      return (DenimPanel)getParentGroup();
   }

   //-----------------------------------------------------------------

   /**
    * Refreshes the information in the panel bar.
    */
   void refresh() {
      if (getPanel() == null) {
         condLabel.setText("1 of 1");
      }
      else {
         condLabel.setText("" +
                           getPanel().getCurrentDesignTimeCondition() +
                           " of " +
                           getPanel().getNumConditions());
      }
   }

   //-----------------------------------------------------------------

   public void setVisible(boolean flag) {
   	
   	  if(getView() instanceof MultiView)
   	  {
   	  	((MultiView)getView()).get(0).setVisible(flag);
   	  }
   	  else
   	  {
   	  	getView().setVisible(flag);
   	  }
   	    
   }

   //-----------------------------------------------------------------

   public void setUniqueID(int newID) {
      // Adjust IDs of panel bar so that they don't potentially clash with
      // other graphical objects
      
      super.setUniqueID(newID);
      leftArrow.setUniqueID(newID + 1);
      currentCond.setUniqueID(newID + 2);
      rightArrow.setUniqueID(newID + 3);
   }
   
   //===========================================================================
   //===   REVISED RENDER AND DAMAGE METHODS   =================================

   /**
    * Used only by DOMUtils.
    */
   public Rectangle2D getUnstickyLocalBounds() {
      return pbView.getUnstickyLocalBounds();
   }

   //-----------------------------------------------------------------

   /**
    * Used only by DenimUtils.
    */
   public AffineTransform getStickyTransform() {
      return pbView.getStickyTransform();
   }
   //-----------------------------------------------------------------

   /**
    * This should become unnecessary once SATIN's sticky mechanism is changed.
    */
   protected void defaultRender(SatinGraphics g) {
      //// 1. Draw the Polygons.
      g.fill(getUnstickyLocalBounds());
      g.draw(getUnstickyLocalBounds());

      //// 2. Draw the contained Graphical Objects.
      renderChildren(g);
   } // of defaultRender

   //===   REVISED RENDER AND DAMAGE METHODS   =================================
   //===========================================================================

   //===========================================================================
   //===   CLONE   =============================================================

   public Object deepClone() {
      return deepClone(new PanelBar());
   } // of method

   //-----------------------------------------------------------------

   public Object deepClone(PanelBar clone) {
      super.deepClone(clone);

      // HACK: Unnecessary once SATIN's sticky mechanism is fixed
      clone.setBoundingPoints2D(COORD_LOCAL, getUnstickyLocalBounds());
      // END HACK

      clone.setVisible(isVisible());

      View v = clone.getView();
      boolean done = false;
      while (!done) {
         if (v instanceof PanelBarView) {
            done = true;
         }
         else if (v instanceof MultiView) {
            v = ((MultiView)v).get(0);
         }
         else if (v instanceof ViewWrapper) {
            v = ((ViewWrapper)v).getView();
         }
         else {
            done = true;
         }
      }
      clone.pbView = (PanelBarView)v;

      return clone;
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

   //----------------------------------------
   
   /**
    * clear all references hold by this object (In the namespace of this class)
    */
   
   public void deepClear() {
      super.deepClear();
      pbView = null;
      leftArrow = null;
      condLabel = null;
      currentCond = null;
      rightArrow = null;
      
   }
   
}
//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
