package edu.berkeley.guir.damask.connection;

import java.awt.geom.GeneralPath;
import java.util.Iterator;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.lib.util.StringLib;


/** 
 * An organization connection between two components. This does imply that 
 * a user can navigate from one of these components to the other.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2003 James Lin
 *                               Created Association
 *                               (later renamed to OrgConnection)
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-20-2003
 */
public class OrgConnection extends Connection {
   
   //===========================================================================
   
   /**
    * Creates an association from the given source to the given
    * destination, from the given device type's perspective.
    */
   public OrgConnection(
      final DeviceType deviceType,
      final boolean forAllDevices,
      final Page sourceForDeviceType,
      final Page destForDeviceType,
      final GeneralPath generalPathForDeviceType) {

      super(
         deviceType,
         forAllDevices,
         sourceForDeviceType,
         Page.class,
         destForDeviceType,
         Page.class,
         generalPathForDeviceType);
      
      DamaskUtils.checkValidArgument(
         deviceType == sourceForDeviceType.getDeviceType(),
         "deviceType parameter must match device type of source parameter");
      DamaskUtils.checkValidArgument(
         deviceType == destForDeviceType.getDeviceType(),
         "deviceType parameter must match device type of dest parameter");
   }
   
   //===========================================================================
   
   /**
    * Returns the source of the connection.
    */
   public Page getSource(final DeviceType deviceType) {
      return (Page)getConnectionSource(deviceType);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Sets the source of the connection to the specified page, which must
    * be in the same dialog as the original source.
    */
   public void setSource(final DeviceType deviceType, final Page newSource) {
      final Page oldSource = getSource(deviceType);
      if (oldSource == newSource) {
         return;
      }
      
      DamaskUtils.checkValidArgument(
         newSource.getDeviceType() == deviceType,
         "The device type of the new source, " +
         newSource + " (" + newSource.getDeviceType() +
         ") must be the same as the deviceType parameter (" + deviceType);
      
      setConnectionSource(deviceType, newSource);
   }
   
   //===========================================================================
   
   /**
    * Returns the destination of the connection.
    */
   public Page getDest(final DeviceType deviceType) {
      return (Page)getConnectionDest(deviceType);
   }
   
   //---------------------------------------------------------------------------

   // @Override
   public String toLongString() {
      final StringBuffer sb = new StringBuffer();

      sb.append(toString());
      sb.append("\n");
      // For each device, recursively write the containees
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType) i.next();
         sb.append("* " + aDeviceType + " - ");
         sb.append(getSource(aDeviceType).toString());
         sb.append(" -> ");
         sb.append(getDest(aDeviceType).toString());
         if (i.hasNext()) {
            sb.append("\n");
         }
      }
      
      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of this connection, with the given indent
    * level and including the components that support the given device.
    */
   // @Override
   public String toLongString(int indentLevel, final DeviceType aDeviceType) {
      // 1. Make sure we have a concrete device; "all" is not acceptable here.
      assert aDeviceType != DeviceType.ALL: "Device cannot be ALL";

      final StringBuffer sb = new StringBuffer();
      
      sb.append(StringLib.spaces(indentLevel * DamaskUtils.INDENT_SPACES));
      sb.append(toString());
      sb.append(": ");
      sb.append(getSource(aDeviceType).toString());
      sb.append(" -> ");
      sb.append(getDest(aDeviceType).toString());
      
      return sb.toString();
   }

   //===========================================================================

   // @Override
   public Object clone() {   
      OrgConnection clone = (OrgConnection)super.clone();
      
      return clone;
   }
}
