package edu.berkeley.guir.damask.view.event;

import java.awt.event.InputEvent;
import java.util.List;

import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.DamaskCanvas;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.event.PDragSequenceEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;

/** 
 * Handles mouse events related to the Eraser tool.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  05-05-2004 Michelle Xue
 *                               Created EraserEventHandler
 * </pre>
 *
 * @author  Michelle Xue
 * @version Version 1.0.0, 05-05-2004
 */
public class EraserEventHandler extends PDragSequenceEventHandler {
   public EraserEventHandler() {
      getEventFilter().setAndMask(InputEvent.BUTTON1_MASK);
   }

   public void startDrag(PInputEvent e) {
      super.startDrag(e);
      erase(e);
   }

   public void drag(PInputEvent e) {
      super.drag(e);
      erase(e);
   }

   /**
    * Erases the object underneath the point in the specified event.
    */
   private void erase(PInputEvent e) {
      final DamaskCanvas currentCanvas = (DamaskCanvas)e.getComponent();
      final List/*<PNode>*/ pickedNodes =
         DamaskAppUtils.getPickedNodes(currentCanvas, e.getPosition());

      final MacroCommand command =
         DamaskAppUtils.createDeleteObjectsCommand(
            currentCanvas, pickedNodes);
      
      if (!command.isEmpty()) {
         currentCanvas.getDocument().getCommandQueue().doCommand(
            currentCanvas, command);
      }
   }
}
