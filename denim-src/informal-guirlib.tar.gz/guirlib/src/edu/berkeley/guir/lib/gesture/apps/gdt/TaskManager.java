package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.util.*;
import java.awt.Color;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.Properties;
import edu.berkeley.guir.lib.gesture.util.Misc;

/** Manage background tasks. */
public class TaskManager {
  /** Time to wait after a change before starting analysis (in ms).  A
      new change resets the timer. */
  private static final long DELAY_AFTER_CHANGE = 10 * 1000;
  private static Map taskManagers = new HashMap();

  private MainFrame mainFrame;
  private List taskList = Collections.synchronizedList(new ArrayList());
  private PropertyChangeListener propChangeListener =
    new MyPropChangeListener();
  private int currentTask = -1;
  private ManagerThread managerThread = null;
  
  private TaskManager(MainFrame mf)
  {
    mainFrame = mf;
    mainFrame.getGesturePackage().
      addPropertyChangeListener(propChangeListener);
    mainFrame.addWindowListener(new WindowAdapter() {
      public void windowClosed(WindowEvent e) {
	if (managerThread != null) {
	  managerThread.halt();
	}
      }
    });
  }
  
  public static TaskManager getTaskManager(MainFrame mainFrame)
  {
    TaskManager newManager;
    if (taskManagers.containsKey(mainFrame)) {
      newManager = (TaskManager) taskManagers.get(mainFrame);
    }
    else {
      newManager = new TaskManager(mainFrame);
      taskManagers.put(mainFrame, newManager);
    }
    return newManager;
  }

  /** add a task to the queue of tasks */
  public void addTask(NoticeTask task)
  {
    taskList.add(task);
    if ((taskCount() == 1) && (managerThread != null)) {
      synchronized (managerThread) {
	managerThread.notify();
      }
    }
  }

  /** removes all tasks from the queue and asks the current thread to
      stop */
  public void removeAllTasks()
  {
    taskList.clear();
    if (managerThread != null) {
      managerThread.halt();
      synchronized (managerThread) {
	managerThread = null;
      }
    }
  }
  
  public void start()
  {
    if (managerThread == null) {
      managerThread = new ManagerThread();
      System.out.println("TM: starting manager thread");
      managerThread.start();
    }
    else {
      System.out.println("Warning: starting when manager thread already exists");
    }
  }
  
  public NoticeTask getTask(int i)
  {
    return (NoticeTask) taskList.get(i);
  }

  public int taskCount()
  {
    return taskList.size();
  }

  private NoticeTask getNextTask()
  {
    NoticeTask result;
    synchronized (taskList) {
      int count = taskCount();
      if (count == 0) {
	result = null;
      }
      else {
	if (currentTask >= (count-1)) {
	  currentTask = -1;
	  result = null;
	}
	else {
	  currentTask++;
	  result = getTask(currentTask);
	}
      }
    }
    return result;
  }

  private void resetTaskIteration()
  {
    currentTask = -1;
  }

  public interface NoticeTask {
    /** Compute any notices that apply.  May be duplicates of old ones. */
    Set computeNotices() throws InterruptedException;
  }

  public static void checkForInterrupt()
    throws InterruptedException
  {
    checkForInterrupt(null);
  }
  
  public static void checkForInterrupt(String details)
    throws InterruptedException
  {
    if (Thread.interrupted()) {
      throw new InterruptedException(details);
    }
  }
  
  private class MyPropChangeListener implements PropertyChangeListener {
    public void propertyChange(PropertyChangeEvent e)
    {
      if (managerThread != null ) {
	PropertyChangeEvent rootEvent = Properties.getRootEvent(e);
	String name = rootEvent.getPropertyName();
	if (Misc.indexOf(GDTConstants.CHANGE_PROPERTIES, name) != -1) {
	  managerThread.changeNotify();
	}
      }
    }
  }

  private class ManagerThread extends Thread {
    private boolean packageChanged;
    private Boolean shouldStop = new Boolean(false);
    
    public ManagerThread()
    {
      super();
      setDaemon(true);
      setPriority(Math.max(Thread.currentThread().getPriority()-2,
			   Thread.MIN_PRIORITY));
      setName("ManagerThread for " + mainFrame.getGesturePackage());
    }

    public void changeNotify()
    {
      //System.out.println("TM: changeNotify");
      packageChanged = true;
      interrupt();
    }

    private boolean isStopTime()
    {
      synchronized (shouldStop) {
	return shouldStop.booleanValue();
      }
    }
    
    public void run()
    {
      //System.out.println("TM: enter run()");
      // make it run the first time through
      packageChanged = true;
      while (!isStopTime()) {
	//System.out.println("TM: top of the main loop");
	// each time through the while loop, process all pending tasks once
	if (packageChanged) {
	  //System.out.println("TM: analysis stale, restarting");
	  resetTaskIteration();
	  packageChanged = false;
	  int i = 0;
	  boolean caughtChange = false;
	  Set oldNotices = NoticeHandler.
	    getNotices(mainFrame.getGesturePackage());
	  Set currentNotices = new HashSet(oldNotices.size());
	  NoticeTask task;
	  for (task = getNextTask();
	       (task != null) && !interrupted() && !isStopTime();
	       task = getNextTask(), i++) {
	    System.out.println("TM: start #" + i);
	    try {
	      currentNotices.addAll(task.computeNotices());
	    }
	    catch (InterruptedException e) {
	      // gesture package must have changed, so restart from the
	      // beginning
	      caughtChange = true;
	      interrupt();
	    }
	    catch (Exception e) {
	      System.err.println("Warning: task " + task +
				 " threw an unexpected exception:");
	      e.printStackTrace();
	    }
	    System.out.println("TM: done  #" + i);
	  }
	  if (task == null) {
	    System.out.println("updating notices");
	    // normal exit, so update notices
	    Set newNotices = new HashSet(currentNotices);
	    newNotices.removeAll(oldNotices);
	    // now newNotices only has new notices
	    NoticeHandler.addNotices(newNotices);
	    Set staleNotices = new HashSet(oldNotices);
	    staleNotices.removeAll(currentNotices);
	    // staleNotices has notices that no longer apply
	    // now, remove stale ones and add new ones
	    for (Iterator iter = staleNotices.iterator(); iter.hasNext();) {
	      Notice notice = (Notice) iter.next();
	      NoticeHandler.removeNotice(notice);
	    }
	    if (mainFrame.areNoticesVisible()) {
	      // show current notices
	      mainFrame.setLogBackground(Color.lightGray);
	      for (Iterator iter = newNotices.iterator(); iter.hasNext();) {
		Notice notice = (Notice) iter.next();
		mainFrame.getNoticeHandler().showNotice(notice);
	      }
	      mainFrame.setLogBackground(Color.white);
	    }
	    mainFrame.updateMetrics();
	    Map noticeSummary = NoticeHandler.
	      getNoticeSummary(mainFrame.getGesturePackage().
			       getTrainingSet());
	    Set keySet = noticeSummary.keySet();
	    for (Iterator iter = keySet.iterator();
		 iter.hasNext();) {
	      Object key = iter.next();
	      Collection value = (Collection) noticeSummary.get(key);
	      System.out.println("\t" + key + "\t" + value.size());
	    }
	    System.out.println("notices updated");
	  }
	  if (caughtChange) {
	    waitForNoChange();
	  }
	}
	else {
	  /*
	  System.out.println("TM: going to sleep...");
	  */
	  // sleep until something happens
	  try {
	    synchronized (this) {
	      this.wait();
	    }
	  }
	  catch (InterruptedException e) {
	  }
	  // now wait until no change occurs for a little while
	  /*
	  System.out.println("TM: wait for changes...");
	  */
	  waitForNoChange();
	  /*
	  System.out.println("TM: woken up");
	  */
	}
      }
      System.out.println("TM: exit run()");
      if (managerThread == this) {
	synchronized (managerThread) {
	  managerThread = null;
	}
      }
    }

    private void waitForNoChange()
    {
      boolean finishedWaiting = false;
      while (!finishedWaiting) {
	try {
	  synchronized (this) {
	    this.wait(DELAY_AFTER_CHANGE);
	  }
	  finishedWaiting = true;
	}
	catch (InterruptedException e) {
	}
      }
    }

    /** Clear all notices from all gestures */
    private void clearNotices()
    {
      clearNotices(mainFrame.getGesturePackage());
    }

    private void clearNotices(GestureContainer container)
    {
      for (Iterator iter = container.iterator(); iter.hasNext();) {
	GestureObject obj = (GestureObject) iter.next();
	obj.unsetProperty(NoticeHandler.NOTICE_LIST_PROP);
	if (obj instanceof GestureContainer) {
	  clearNotices((GestureContainer) obj);
	  obj.unsetProperty(NoticeHandler.NOTICE_DESCENDENTS_PROP);
	}
      }
    }
    
    /** stops the thread at the next possible time */
    public void halt()
    {
      synchronized (shouldStop) {
	shouldStop = new Boolean(true);
      }
      interrupt();
    }
  }
}
