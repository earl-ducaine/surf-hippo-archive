//// See bottom of source code for software license

package edu.berkeley.guir.denim.dialogs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import edu.berkeley.guir.denim.*;

/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Nov 18, 2003 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class DenimProgressDialog extends JDialog {

	private JProgressBar mProgressBar = null;
		
	final int width = 300;
	final int height = 60;
	final int totalsteps = 50;
	private int value = 0;
	
	long mStep = 0;
	
	DenimWindow denimWindow;
	
	class Forward extends TimerTask {
		
		java.util.Timer mTimer = null;
		
		public Forward(java.util.Timer timer) {
			mTimer = timer;	
		}
		
		public void run() {
			value++;
			if(value>totalsteps)
			{
				mTimer.cancel();
				DenimProgressDialog.this.setVisible(false);
				DenimProgressDialog.this.dispose();
			}
			else if(denimWindow.getGlassPane().isVisible()==false)
			{
				value = 50;
			}
			
			mProgressBar.setValue(value);
			int percentage = (int)((double)value/(double)totalsteps*100);
			String str = new String();
			str += percentage;
			str += "%";
			mProgressBar.setString(str);
		}
	}
	
	private long anticipateLoadStep(long size) {
		long totalms = (long)((double)size/236f);
		long timestep = (long)((double)totalms/(double)totalsteps);
		
		if(timestep<10)
			timestep = 10;
			
		return timestep;
	}
	
	private long anticipateSaveStep(long num) {
		long totalms = num/236;
		long timestep = totalms/totalsteps;
		return timestep;
	}
	
	public DenimProgressDialog(DenimWindow win, String title, boolean isLoad, long size) {
		super((Frame)null, title, true);
		
		this.denimWindow = win;
		
		double w = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double h = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setBounds((int)((w-width)/2), (int)((h-height)/2),
							width, height);
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
		mProgressBar = new JProgressBar(0, totalsteps);
		mProgressBar.setStringPainted(true);
		
		this.getContentPane().add(mProgressBar, BorderLayout.CENTER);
		this.setResizable(false);
		
		if(isLoad)
		{
			mStep = this.anticipateLoadStep(size);
		}
		else
		{
			mStep = 50;//this.anticipateSaveStep(size);
		}
		this.addComponentListener(new ComponentAdapter() {
			public void componentShown(ComponentEvent evt) {
				java.util.Timer timer = new java.util.Timer();
				timer.schedule(new Forward(timer), mStep, mStep); 			
			}	
		});
	}
}


//==============================================================================

/*
Copyright (c) 2003 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User 
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/