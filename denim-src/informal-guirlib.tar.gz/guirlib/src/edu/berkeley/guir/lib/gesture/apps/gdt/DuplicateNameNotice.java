package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.util.Arrays;
import java.util.List;
import java.awt.BorderLayout;
import javax.swing.JTextArea;
import edu.berkeley.guir.lib.gesture.*;

public class DuplicateNameNotice extends DefaultNotice {
  private GestureContainer[] containers;
  private String name;
  private boolean displayMe = true;
  
  public DuplicateNameNotice(GestureContainer gc1, GestureContainer gc2)
  {
    GestureContainer[] dummy = { gc1, gc2 };
    containers = dummy;
    name = gc1.getName();
  }

  /** if either container name has changed, expire this */
  public boolean hasExpired()
  {
    return ((containers[0].getName() != name) ||
	    (containers[1].getName() != name));
  }

  protected void displayImpl(SummaryLog log)
  {
    if (displayMe) {
      log.append("Warning: two gestures share the name '" + name +
		 "'. You should rename one.");
      displayMe = false;
    }
  }

  protected void displaySummaryImpl(SummaryLog log)
  {
    // name says it all
  }
  
  public String getName()
  {
    return "Duplicate name: '" + name + "'";
  }

  public List getObjectList()
  {
    return Arrays.asList(containers);
  }

  public HowToPanel getHowToPanel()
  {
    HowToPanel htPanel = new HowToPanel();
    htPanel.add(new JTextArea("To rename an object, select it in the tree and execute the 'Gesture/Rename' menu item."), BorderLayout.CENTER);
    return htPanel;
  }

  public String getReferenceTag()
  {
    return "Duplicate Names";
  }

  /** todo: need to decide what the right semantics are (and if it
      even makes sense to call it equals) based on how it's actually
      used
  public void equals(Object o)
  {
    return super.equals(o) || ((o instanceof DuplicateNameNotice) && ((DuplicateNameNotice) o).
  }
  */
}
