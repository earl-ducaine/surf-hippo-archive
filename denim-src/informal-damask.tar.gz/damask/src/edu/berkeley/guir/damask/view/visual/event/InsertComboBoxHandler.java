package edu.berkeley.guir.damask.view.visual.event;

import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.visual.component.ComboBox;
import edu.berkeley.guir.damask.view.visual.component.ListBox;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * The event handler that handles inserting list boxes into pages.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-26-2004 James Lin
 *                               Created InsertListBoxHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-26-2004
 */
public class InsertComboBoxHandler extends InsertComponentHandler {

   /**
    * Constructs a new list box handler. 
    */
   public InsertComboBoxHandler() {
      super(ComboBox.class);
   }

   // Overrides method in parent class.
   protected Component createNewComponent(
      final DeviceType deviceType,
      final PageRegion region,
      final AffineTransform transform,
      final Rectangle2D bounds) {

      final PNode listBoxDefaultView = ListBox.createTempView();

      final SelectOne selectOne = new SelectOne(deviceType);
      
      selectOne.setBounds(region.getDeviceType(), bounds);
      selectOne.setTransform(region.getDeviceType(), transform);
      
      selectOne.setStyle(deviceType, SelectOne.MINIMAL);

      int index = 1;
      for (Iterator i = listBoxDefaultView.getChildrenIterator(); i.hasNext(); ) {
         final PNode squiggles = (PNode)i.next();
         
         final List squiggleList = new ArrayList();
         for (Iterator j = squiggles.getChildrenIterator(); j.hasNext(); ) {
            final PPath squiggle = (PPath)j.next();
            squiggleList.add(
               new GeneralPath(
                  squiggle.getPathReference().createTransformedShape(
                     squiggle.getTransform())));
         }
         
         final Content caption = new Content(deviceType, squiggleList);
         caption.setText("Item " + index);
         caption.setPreferredDisplayMode(deviceType, Content.INK);
         caption.setBoundsWithoutStretching(deviceType, squiggles.getBounds());         
         
         final SelectOne.Item item = new SelectOne.Item(caption);
         item.setBounds(deviceType, squiggles.getBounds());
         item.setTransform(deviceType, squiggles.getTransform());
         
         selectOne.addItem(item);
         index++;
      }
      
      return selectOne;
   }
}
