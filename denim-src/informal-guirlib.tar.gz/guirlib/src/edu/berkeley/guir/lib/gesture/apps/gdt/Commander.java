package edu.berkeley.guir.lib.gesture.apps.gdt;

import javax.swing.event.ChangeListener;

public interface Commander {
  /** Return whether the command is valid/meaningful/acceptable now
      for this object. */
  boolean isCommandValid(int id);
  void doCommand(int id);
  void addMenuValidChangeListener(ChangeListener listener);
  void removeMenuValidChangeListener(ChangeListener listener);
}
