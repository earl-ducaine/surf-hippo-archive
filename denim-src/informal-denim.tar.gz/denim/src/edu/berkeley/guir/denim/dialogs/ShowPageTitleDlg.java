//// See bottom of source code for software license

package edu.berkeley.guir.denim.dialogs;

import javax.swing.*;

import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.table.*;
import javax.swing.event.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;
import edu.berkeley.guir.lib.awt.geom.*;

/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Nov 16, 2004 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class ShowPageTitleDlg extends JDialog 
    implements SatinConstants {
        
        static final int width = 300;
        static final int height = 400;
        
        DenimSheet sheet = null;
        LinkedList pages = new LinkedList();
        GraphicalObject linkSrc = null;
        
        DenimSheet componentSheet = null;

        int current = 0;
        
        boolean isGlobal = false;
        
        class PageList extends JPanel {
            int height = 0;
            int width = 0;
            LinkedList rects = new LinkedList();
            
            public PageList() {
                
                DenimPanel currenttarget = null;
                if(linkSrc instanceof DenimHyperlinkInstance
                        &&((DenimHyperlinkInstance)linkSrc).getOutgoingArrows().isEmpty()==false)
                {
                    currenttarget = ((Arrow)((DenimHyperlinkInstance)linkSrc).getOutgoingArrows().toArray()[0]).getDestPanel();
                }
                
                Iterator it = pages.iterator();
                while(it.hasNext())
                {
                    DenimPanel panel = (DenimPanel)it.next();
                    while(panel.getLabel().getRenderCache().getCacheValidity()==false)
                    {
                        panel.getLabel().getRenderCache().updateCache(null, panel.getLabel().getStyleRef());
                    }
                    
                    BufferedImage image = (BufferedImage)panel.getLabel().getRenderCache().getCacheImage();
                    rects.add(new Rectangle2D.Float(0, height, image.getWidth(), image.getHeight()));
                    height += image.getHeight();
                    if(image.getWidth()>width)
                        width = image.getWidth();
                    
                    if(currenttarget==panel)
                    {
                        current = pages.indexOf(panel);
                    }
                }
                
                this.addMouseListener(new MouseAdapter() {
                    public void mousePressed(MouseEvent evt) {
                        Iterator it = rects.iterator();
                        while(it.hasNext())
                        {
                            Rectangle2D rect = (Rectangle2D)it.next();
                            if(rect.contains(evt.getPoint()))
                            {
                                current = rects.indexOf(rect);
                                PageList.this.repaint();
                                return;
                            }
                        }                        
                    }
                });
                
                this.setPreferredSize(new Dimension(width, height));
            }
            
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                
                int y = 0;
                Iterator it = pages.iterator();
                while(it.hasNext())
                {
                    DenimPanel panel = (DenimPanel)it.next();
                    BufferedImage image = (BufferedImage)panel.getLabel().getRenderCache().getCacheImage();
                    g.drawImage(
                            image,
                            0, y, this);
                    y += image.getHeight();
                }

                ((Graphics2D)g).setColor(Color.black);
                ((Graphics2D)g).setStroke(new BasicStroke(1));
                
                it = rects.iterator();
                while(it.hasNext())
                {
                    Rectangle2D rect = (Rectangle2D)it.next();
                    ((Graphics2D)g).draw(rect);    
                }
                
                ((Graphics2D)g).setColor(Color.blue);
                ((Graphics2D)g).setStroke(new BasicStroke(4));
                ((Graphics2D)g).draw((Rectangle2D)rects.get(current));
            }
        }


        public ShowPageTitleDlg(DenimWindow win,
                DenimSheet sheetOfMainWindow,
                GraphicalObject txt, DenimPanel startPage) {
            
            super(win, "Choose a Target Page", true);
            
            linkSrc = txt;
            sheet = sheetOfMainWindow;
            
            if(sheet != win.getDenimUI().getSheet())
            {
                isGlobal = true;
                componentSheet = win.getDenimUI().getSheet();
            }
        
            this.setResizable(false);
            double w = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
            double h = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
            this.setBounds((int)((w-width)/2), (int)((h-height)/2),
                                width, height);
            
            Iterator it = sheet.getForwardIterator();
            while(it.hasNext())
            {
                GraphicalObject gob = (GraphicalObject)it.next();
                if(gob instanceof DenimPanel&&
                        gob!=startPage)
                {
                    DenimPanel panel = (DenimPanel)gob;
                    
                    // if it is scribbled text, then add at the last position
                    if(panel.getLabel().getPhrase() instanceof ScribbledText)
                    {
                        pages.addLast(panel);
                    }
                    else // if not, find a place for it
                    {
                        TypedText text = (TypedText)panel.getLabel().getPhrase();
                        int i = 0;
                        for(; i<pages.size(); i++)
                        {
                            DenimText t = ((DenimPanel)pages.get(i))
                                    .getLabel().getPhrase();
                            if(t instanceof ScribbledText
                                ||text.getText().compareToIgnoreCase(((TypedText)t).getText())<0)
                            {
                                break;
                            }
                        }
                        pages.add(i, panel);
                    }
                }
            }
            
            JScrollPane pane = new JScrollPane(new PageList());
            pane.revalidate();
            this.getContentPane().add(pane, BorderLayout.CENTER);
            
            JPanel btns = new JPanel();
            this.getContentPane().add(btns, BorderLayout.SOUTH);
            
            JButton use = new JButton("OK");
            btns.add(use);
            use.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {

                    if(isGlobal) // create a global link
                    {
                        // Insert the arrow
                        DenimPanel dst = (DenimPanel)pages.get(current);
                        Polygon2D poly = new Polygon2D();
                        poly.addPoint(1,1);
                        poly.addPoint(2,2);
                        TimedStroke newStk = new TimedStroke(poly);
                        MacroCommand cmd = new MacroCommand();
                        InsertArrowCommand acmd = new InsertArrowCommand(
                                        componentSheet, newStk,
                                        DenimIntrinsicComponent.LEFT_CLICK,
                                        DenimConstants.DEFAULT_EVENT, 
                                        linkSrc, (ArrowDest)dst.getSketch());
                        cmd.addCommand(acmd);
                        cmd.run();
                        
                        acmd.getInsertedArrow().setGlobalDstID(dst.getSketch().getUniqueID());
                    }
                    else // create a cross-screen link
                    {
                        // Create a new command
                        MacroCommand cmd = new MacroCommand();

                        // Insert the arrow
                        DenimPanel dst = (DenimPanel)pages.get(current);
                        Rectangle2D srcRect = linkSrc.getBounds2D(COORD_ABS);
                        Rectangle2D dstRect = dst.getBounds2D(COORD_ABS);
                        
                        double x1, x2, y1, y2;
                        if(srcRect.getCenterX()>dstRect.getCenterX())
                        {
                            x1 = srcRect.getMinX() + 5;
                            x2 = dstRect.getMaxX() - 5;
                        }
                        else
                        {
                            x1 = srcRect.getMaxX() - 5;
                            x2 = dstRect.getMinX() + 5;                            
                        }
                        
                        y1 = srcRect.getHeight()*Math.random()+srcRect.getMinY();
                        y2 = dstRect.getHeight()*Math.random()+dstRect.getMinY();

                        AffineTransform tr = null;
                        try
                        {
                            tr = dst.getParentGroup().getTransform(COORD_ABS).createInverse();
                        }
                        catch(Exception ex)
                        {
                            ex.printStackTrace();
                        }
                        
                        Point2D p1 = new Point2D.Double();
                        Point2D p2 = new Point2D.Double();
                        
                        tr.transform(new Point2D.Double(x1,y1), p1);
                        tr.transform(new Point2D.Double(x2,y2), p2);
                        
                        TimedStroke newStk = new TimedStroke();
                        newStk.addPoint(p1);
                        newStk.addPoint(p2);
                        newStk.doneAddingPoints();
                        
                        sheet.disableDamage();
                        sheet.add(newStk, GraphicalObjectGroup.KEEP_REL_POS);
                        InsertArrowCommand acmd = new InsertArrowCommand(
                                dst.getParentGroup(), 
                                newStk,
                                DenimIntrinsicComponent.LEFT_CLICK,
                                DenimConstants.DEFAULT_EVENT, 
                                linkSrc, (ArrowDest)dst.getSketch());
                        cmd.addCommand(
                                acmd);
                        cmd.addCommand
                           (new SetSheetModifiedCommand(sheet, true));
                        cmdqueue.doCommand(cmd);
                        acmd.getInsertedArrow().getStyleRef().setLineWidth
                            ((float)(1.0 /acmd.getInsertedArrow().getTransform(COORD_ABS).getScaleX()));
                        acmd.getInsertedArrow().reanchor();
                        newStk.delete();
                        sheet.enableDamage();
                        sheet.damage(DAMAGE_NOW);
                    }
                    
                    ShowPageTitleDlg.this.setVisible(false);
                }
            });
            
            JButton cancel = new JButton("Cancel");
            btns.add(cancel);
            cancel.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    ShowPageTitleDlg.this.setVisible(false);
                }
            });
        }
}



//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
    must display the following acknowledgement:

        This product includes software developed by the Group for User 
        Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
    derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/