package edu.berkeley.guir.damask.event;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.dialog.Dialog;

/** 
 * A source of DialogEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-21-2004 James Lin
 *                               Created DialogEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 02-21-2004
 */
public class DialogEventSource {
   
   private Vector/*<ConnectionListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified listener to receive events from a page.
    */
   public synchronized void addDialogListener(final DialogListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified listener so that it no longer receives
    * events from a page.
    */
   public synchronized void removeDialogListener(final DialogListener listener) {
      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires templateAdded events to listeners.
    */
   public void fireInitialConditionChanged(
      final Dialog dialog,
      final int newInitialCondition) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final DialogEvent event =
         new DialogEvent(
            dialog,
            DialogEvent.INITIAL_CONDITION_CHANGED,
            new Integer(newInitialCondition));

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final DialogListener listener = (DialogListener)i.next();
         listener.initialConditionChanged(event);
      }
   }
}
