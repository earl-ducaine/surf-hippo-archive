package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;
import java.util.*;

/*
 * Constructs the expanded view for group nodes. 
 * All prompt nodes inside an expanded group node has the default prompt node view.
 */
public class GroupExpandedNodeView extends AbstGroupNodeView {
	public GroupExpandedNodeView( SuedeModel model, GroupNodeModel nodeModel, String label){
        super(model, nodeModel);
        m_textField.setBounds(6,0,DEFAULT_WIDTH - TEXT_HEIGHT, TEXT_HEIGHT);
        m_textField.setVisible(true);
        m_textField.setOpaque(false);
        m_textField.setForeground(Color.white);
        m_textField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        m_textField.setFont(m_textField.getFont().deriveFont(Font.BOLD));
        add(m_textField);
        m_textField.setText(label);
        Vector components = ((GroupNodeModel)m_nodemodel).getComponents();
        for (int i=0; i<components.size(); i++) {
            ((SingleNodeModel)components.get(i)).expandInGroup();
            ((SingleNodeModel)components.get(i)).setLocation(m_nodemodel.getX()+HOR_NODE_DIST, 
             m_nodemodel.getY()+i*(AbstSingleNodeView.DEFAULT_HEIGHT+VER_NODE_DIST)+TEXT_HEIGHT);
        }
        setSize(getPreferredSize());
        setName(label);
	}
    
    
	public void paintComponent(Graphics g) {
   	super.paintComponent(g);
   	Graphics2D g2d = (Graphics2D)g;
   	g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
   	g2d.setColor(NODE_FILL);
   	g2d.fill(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, ARC, ARC));   
	}
}