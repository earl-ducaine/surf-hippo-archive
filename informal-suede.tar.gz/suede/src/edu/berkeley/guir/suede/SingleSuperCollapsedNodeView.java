package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.ActionListener;

/*Constructs the prompt node's collapsed view inside a group
*/
public class SingleSuperCollapsedNodeView extends AbstSingleNodeView {
    
    private SText m_textField;
    private final RoundRectangle2D.Float SUPER_CL_SHAPE = new RoundRectangle2D.Float(0,0,CL_WIDTH-1,CL_HEIGHT-1,ARC, ARC);
    private Area        m_superCollapsedTextShape = new Area(SUPER_CL_SHAPE);
    
    public SingleSuperCollapsedNodeView(SuedeModel model, SingleNodeModel nodeModel, String name, ActionListener al, String caption) {
        super(model, nodeModel);  setName(name);
        setLayout(null);
        m_playButton = new PlayButton(false, NODE_STROKE);
  
        m_superCollapsedTextShape.subtract(new Area(new Rectangle(CL_WIDTH-BUTTON_WIDTH, 0, BUTTON_WIDTH, CL_HEIGHT-1)));
        setSize(CL_WIDTH, CL_HEIGHT);
        m_playButton.setBounds(CL_WIDTH - BUTTON_WIDTH, 1, BUTTON_WIDTH, CL_HEIGHT);
        add(m_playButton);       
       
        m_textField = new SText(m_superCollapsedTextShape);
        m_textField.setStroke(null);
        m_textField.setLocation(0,0);
        m_textField.setText(caption);
        m_textField.setEditable(false);
        m_textField.setHighlighter(null);
        add(m_textField);
        
    }
    
    public void setCaption(String s) {
        m_textField.setText(s);
    }
    
    public String getCaption() {
        return m_textField.getText();
    }
    
    public boolean isOperable(Point p) {
        return true;   
    }
    
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D)g;
        g2d.setColor(NODE_STROKE);
        g2d.setStroke(AbstNodeView.STROKE);
        super.paintComponent(g2d);
    }

}