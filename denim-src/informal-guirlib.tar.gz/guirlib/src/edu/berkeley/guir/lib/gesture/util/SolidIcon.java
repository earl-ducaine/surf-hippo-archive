package edu.berkeley.guir.lib.gesture.util;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class SolidIcon implements Icon
{
  Color color;
  Dimension size;
  Border border;

  public SolidIcon(Color color, Dimension size)
  {
    this(color, size, null);
  }
  
  public SolidIcon(Color color, Dimension size, Border border)
  {
    this.color = color;
    this.size = size;
    this.border = border;
  }

  public void setColor(Color c)
  {
    color = c;
  }

  public void paintIcon(Component c,
			Graphics g,
			int x,
			int y)
  {
    Graphics saveGraphics = g.create();
    g.setColor(color);
    g.fillRect(x, y, size.width, size.height);
    if (border != null) {
      border.paintBorder(c, saveGraphics, x, y, size.width, size.height);
    }
  }

  public int getIconWidth()
  {
    return size.width;
  }

  public int getIconHeight()
  {
    return size.height;
  }
}
