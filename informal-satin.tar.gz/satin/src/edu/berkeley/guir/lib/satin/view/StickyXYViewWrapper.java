//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;

/**
 * Doesn't work yet, because I can't do math. 
 * Wraps up views to stick to a certain x-y location.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 16 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3RC1
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class StickyXYViewWrapper 
   extends StickyViewWrapper {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 2772309583094858853L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   double x;                    // x-position to appear at.
   double y;                    // y-position to appear at.

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Does nothing.
    */
   public StickyXYViewWrapper() {
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Wrap a view into a sticky wrapper, making it appear in the same place
    * despite any kind of transformation.
    */
   public StickyXYViewWrapper(View v) {
      super(v);
      setView(v);
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Sticky XY Wrapper");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * This isn't returning the right transform to keep us in place.
    */
   protected AffineTransform getStickyTransform(AffineTransform txTmp) {
      //// 1. Calculate the current translation.
      getAttachedGraphicalObject().getTransform(COORD_ABS, txTmp);
      Point2D pt = AffineTransformLib.getTranslateFactor(txTmp);

      double dx = x - pt.getX();
      double dy = y - pt.getY();

      txTmp.translate(dx, dy);
      return (txTmp);
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Set the absolute location where this view will appear.
    */
   public void setLocation(double x, double y) {
      this.x = x;
      this.y = y;
   } // of setLocation

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new StickyXYViewWrapper()));
   } // of clone

   //-----------------------------------------------------------------

   protected StickyXYViewWrapper clone(StickyXYViewWrapper vw) {
      //// 1. Clone chain.
      super.clone(vw);

      //// 2. Do clone work.
      vw.x = this.x;
      vw.y = this.y;

      //// 3. Return.
      return (vw);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
