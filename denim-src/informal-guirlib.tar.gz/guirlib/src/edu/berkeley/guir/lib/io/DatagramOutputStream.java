//// See bottom of file for software license
package edu.berkeley.guir.lib.io;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketException;

/**
 * An OutputStream that sends packs of data out via DatagramPackets.
 * Give it a destination address and port, and it will stream it out there.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Oct 24 2002, JH
 */
public class DatagramOutputStream
    extends OutputStream {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    DatagramSocket sock;         // our datagram socket to use
    InetAddress    dstAddr;      // destination of our datagram packets
    int            dstPort;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================






    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Creates a new DatagramSocket (on some available port) and binds to it.
     */
    public DatagramOutputStream(InetAddress dstAddr, int dstPort) 
        throws SocketException{

        this(new DatagramSocket(), dstAddr, dstPort);
    } // of method

    //----------------------------------------------------------------

    public DatagramOutputStream(
        DatagramSocket newSock, InetAddress dstAddr, int dstPort) {

        this.sock    = newSock;
        this.dstAddr = dstAddr;
        this.dstPort = dstPort;
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================





    //==========================================================================
    //===   OUTPUTSTREAM METHODS   =============================================

    public void close() {
        sock.close();
    } // of method

    //----------------------------------------------------------------

    public void flush() {
        //// ignore
    } // of method

    //----------------------------------------------------------------

    /**
     * Write out the entire array into a DatagramPacket and send it out.
     * Max size seems to be around 2048, but this might be machine dependent.
     */
    public void write(byte[] b) throws IOException {
        write(b, 0, b.length);
    } // of method

    //----------------------------------------------------------------

    /**
     * Write out the specified portion of the array into a 
     * DatagramPacket and send it out.
     * Max size seems to be around 2048, but this might be machine dependent.
     */
    public void write(byte[] b, int off, int len) throws IOException {
        DatagramPacket packet;
        packet = new DatagramPacket(b, off, len, dstAddr, dstPort);
        sock.send(packet);
    } // of method

    //----------------------------------------------------------------

    public void write(int b) {
        //// ignore
    } // of method

    //===   OUTPUTSTREAM METHODS   =============================================
    //==========================================================================






    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static String generateString(int len) {
        StringBuffer strbuf = new StringBuffer();
        for (int i = 0; i < len; i++) {
            strbuf.append("" + i % 10);
        }
        return (strbuf.toString());
    } // of method


    public static byte[] toByteArray(String str) 
        throws IOException {

        ByteArrayOutputStream bostream = new ByteArrayOutputStream();
        OutputStreamWriter    wtr      = new OutputStreamWriter(bostream);
        wtr.write(str);
        wtr.flush();
        return (bostream.toByteArray());
    } // of method


    public static void write(String str, OutputStream ostream) 
        throws IOException {

        byte[] bArr = toByteArray(str);
        System.out.println("string len:   " + str.length());
        System.out.println("byte arr len: " + bArr.length);
        ostream.write(bArr);
    } // of method

    //==========================================================================

    public static void main(String[] argv) throws Exception {
        OutputStream ostream = new DatagramOutputStream(InetAddress.getLocalHost(), 8080);

        write("dog", ostream);
        write("cat", ostream);
        write(generateString(2048), ostream);
        write(generateString(4096), ostream);  // fails at 2048
        write(generateString(8192), ostream);  // fails at 2048

    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2002 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
