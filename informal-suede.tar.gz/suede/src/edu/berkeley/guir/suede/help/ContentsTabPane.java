package edu.berkeley.guir.suede.help;

import javax.swing. *;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.*;
import java.io.File;

class ContentsTabPane extends JPanel {
     protected JTree FileTree;
     private JScrollPane FilePane;
     protected DefaultTreeModel treeModel;
         
     public ContentsTabPane () {
         super();
         initComponents();
     }
     
     private void initComponents() {
        treeModel = createTreeModel();
        FileTree = new JTree (treeModel);
        FilePane = new JScrollPane(FileTree);
        this.setLayout(new BorderLayout());
        this.add(FilePane, BorderLayout.CENTER);
        
        FileTree.addTreeExpansionListener(new TreeExpansionListener(){
            public void treeCollapsed(TreeExpansionEvent e) {
            }
            public void treeExpanded(TreeExpansionEvent e) {
                    TreePath path = e.getPath();
                    FileNode node = (FileNode)path.getLastPathComponent();

                    if( ! node.isExplored()) {
                            DefaultTreeModel model = 
                                            (DefaultTreeModel)FileTree.getModel();

                            node.explore();
                            model.nodeStructureChanged(node);
                    }
            }
        });
     }
        
    private DefaultTreeModel createTreeModel() {
		File root = new File("M:/");
		FileNode rootNode = new FileNode(root);

		rootNode.explore();
		return new DefaultTreeModel(rootNode);
	}
 }
