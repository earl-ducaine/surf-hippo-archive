package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.awt.datatransfer.DataFlavor;
import java.util.HashMap;
import java.util.Collection;
import edu.berkeley.guir.lib.gesture.*;

public class GestureFlavorFactory {
  private static HashMap flavorMap = new HashMap();
  private static HashMap collectionFlavorMap = new HashMap();
  
  // predefined flavors
  public static final DataFlavor GESTURE_OBJECT_FLAVOR		= GestureFlavorFactory.
    makeDataFlavor(GestureObject.class, "gesture object");
  public static final DataFlavor GESTURE_SET_FLAVOR	= GestureFlavorFactory.
    makeDataFlavor(GestureSet.class, "gesture set");
  public static final DataFlavor GESTURE_CATEGORY_FLAVOR		= GestureFlavorFactory.
    makeDataFlavor(GestureCategory.class, "gesture category");
  public static final DataFlavor GESTURE_GROUP_FLAVOR		= GestureFlavorFactory.
    makeDataFlavor(GestureGroup.class, "gesture group");
  public static final DataFlavor GESTURE_EXAMPLE_FLAVOR		= GestureFlavorFactory.
    makeDataFlavor(Gesture.class, "gesture example");
  public static final DataFlavor GESTURE_EXAMPLE_COLLECTION_FLAVOR	= GestureFlavorFactory.
    makeCollectionDataFlavor(Gesture.class, "gesture example collection");
  public static final DataFlavor GESTURE_CATEGORY_COLLECTION_FLAVOR	= GestureFlavorFactory.
    makeCollectionDataFlavor(GestureCategory.class, "gesture category collection");
  public static final DataFlavor GESTURE_GROUP_COLLECTION_FLAVOR	= GestureFlavorFactory.
    makeCollectionDataFlavor(GestureGroup.class, "gesture group collection");
  public static final DataFlavor GESTURE_SET_COLLECTION_FLAVOR	= GestureFlavorFactory.
    makeCollectionDataFlavor(GestureSet.class, "gesture set collection");
  public static final DataFlavor GESTURE_OBJECT_COLLECTION_FLAVOR	= GestureFlavorFactory.
    makeCollectionDataFlavor(GestureObject.class, "gesture object collection");
  
  private GestureFlavorFactory()
  {
  }

  public static DataFlavor makeDataFlavor(Class c, String name)
  {
    DataFlavor result = new DataFlavor(c, name);
    flavorMap.put(c, result);
    return result;
  }

  public static DataFlavor getDataFlavor(Class c)
  {
    return (DataFlavor) flavorMap.get(c);
  }

  public static DataFlavor makeCollectionDataFlavor(Class c,
						    String name)
  {
    DataFlavor result = new DataFlavor(Collection.class, name);
    collectionFlavorMap.put(c, result);
    return result;
  }

  public static DataFlavor getCollectionDataFlavor(Class c)
  {
    return (DataFlavor) collectionFlavorMap.get(c);
  }
}
