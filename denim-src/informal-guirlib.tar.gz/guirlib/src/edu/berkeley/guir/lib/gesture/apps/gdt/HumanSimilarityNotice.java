package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.util.Arrays;
import java.util.List;
import edu.berkeley.guir.lib.gesture.*;
import java.awt.BorderLayout;

public class HumanSimilarityNotice extends DefaultNotice {
  private MainFrame mainFrame;
  private GestureCategory categoryA, categoryB;
  private Class featureClass;
  private int direction;
  private boolean withinGroup;
  protected HowToPanel howToPanel = null;
  
  public HumanSimilarityNotice(MainFrame mf, GestureCategory catA,
			       GestureCategory catB, Class featureClass,
			       int direction)
  {
    mainFrame = mf;
    categoryA = catA;
    categoryB = catB;
    this.featureClass = featureClass;
    this.direction = direction;
    withinGroup = (categoryA.getParent() == categoryB.getParent()) &&
      (categoryA.getParent() instanceof GestureGroup);
  }

  public boolean hasExpired()
  {
    // todo: fix this
    return false;
  }

  public boolean isWithinGroup()
  {
    return withinGroup;
  }
  
  protected void displayImpl(SummaryLog log)
  {
    //System.out.println("MN: display: " + misrecogGestures.size());
    if (!hasExpired()) {
      log.append("People are likely to perceive two of your gesture categories, ");
      log.appendLink(categoryA);
      log.append(" and ");
      log.appendLink(categoryB);
      log.append(", as very similar. ");
      String message;
      if (withinGroup) {
	message =
	  "This may be desirable since they are in the same group ("
	  + categoryA.getParent().getName() + ").";
      }
      else {
	message =
	  "You may want to change them to make them less similar.";
      }
      log.append(message);
    }
  }

  protected void displaySummaryImpl(SummaryLog log)
  {
    log.appendLink(categoryA);
    log.append(" and ");
    log.appendLink(categoryB);
    log.append(withinGroup ? " (same group)" : " (different groups)");
  }
  
  public String getName()
  {
    return "Similar categories (people)";
  }

  public List getObjectList()
  {
    GestureContainer[] dummy = { categoryA, categoryB };
    return Arrays.asList(dummy);
  }

  public String getReferenceTag()
  {
    return "Too Similar for Humans";
  }

  public HowToPanel getHowToPanel()
  {
    if (howToPanel == null) {
      SummaryLog log = new SummaryLog(mainFrame);
      log.append("To make the gesture categories ");
      log.appendLink(categoryA);
      log.append(" and ");
      log.appendLink(categoryB);
      log.append(" less similar, change the ");
      log.appendFeatureLink(featureClass);
      log.append(".");
      String directionA, directionB;
      if (direction == 1) {
	directionA = "higher";
	directionB = "lower";
      }
      else {
	directionA = "lower";
	directionB = "higher";
      }
      log.append(" Make this feature " + directionA + " for ");
      log.appendLink(categoryA);
      log.append(" and/or " + directionB + " for ");
      log.appendLink(categoryB);
      log.append(".");
      howToPanel = new HowToPanel(mainFrame);
      howToPanel.add(log, BorderLayout.CENTER);
    }
    return howToPanel;
  }
}
