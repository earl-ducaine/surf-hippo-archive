package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.*;
import javax.swing.*;
import java.awt.datatransfer.Transferable;

public class GestureSetPanel extends GestureContainerPanel {
  protected Classifier classifier = null;
  
  public GestureSetPanel()
  {
    this(null);
  }

  public GestureSetPanel(GestureSet gs)
  {
    this(gs, null);
  }
  
  public GestureSetPanel(GestureSet gs, JScrollPane scrollPane)
  {
    super(gs, scrollPane);
  }

  public void setGestureSet(GestureSet gs)
  {
    setGestureContainer(gs);
  }

  public void setGestureContainer(GestureContainer gestureSet)
  {
    if ((gestureSet != null) && !(gestureSet instanceof GestureSet)) {
      throw new IllegalArgumentException("Only GestureSet is allowed, not "
					 + gestureSet.getClass().getName() +
					 "(" + gestureSet + ")");
    }
    if (classifier != null) {
      classifier.setGestureSet((GestureSet) gestureSet);
    }
    super.setGestureContainer(gestureSet);
  }

  public GestureSet getGestureSet()
  {
    return (GestureSet) getGestureContainer();
  }

  public boolean canAcceptGesture()
  {
    return true;
  }
  
  public String getInputGestureTitle()
  {
    return "Draw a gesture to be recognized";
  }

  public boolean gestureDrawn(Gesture gesture)
  {
    MainFrame mf = (MainFrame) SwingUtilities.
      getAncestorOfClass(MainFrame.class, this);
    mf.recognizeGesture(gesture);
    return false;
  }

  protected boolean canPaste(Transferable t)
  {
    return t.isDataFlavorSupported(GestureFlavorFactory.
				   GESTURE_GROUP_COLLECTION_FLAVOR) ||
      t.isDataFlavorSupported(GestureFlavorFactory.GESTURE_GROUP_FLAVOR) ||
      t.isDataFlavorSupported(GestureFlavorFactory.
				   GESTURE_CATEGORY_COLLECTION_FLAVOR) ||
      t.isDataFlavorSupported(GestureFlavorFactory.GESTURE_CATEGORY_FLAVOR);
  }

  public boolean isCommandValid(int id)
  {
    boolean valid;
    switch (id) {
    case NEW_GESTURE_ACTION:
    case NEW_GROUP_ACTION:
      /* todo: enable this?
    case RENAME_ACTION:
      */
      valid = true;
      break;
    default:
      valid = super.isCommandValid(id);
      break;
    }
    return valid;
  }

  public void doCommand(int id)
  {
    switch (id) {
    case NEW_GESTURE_ACTION:
      getGestureSet().
	add(new GestureCategory(Gensym.next(GESTURE_CATEGORY_PREFIX)));
      break;
    case NEW_GROUP_ACTION:
      getGestureSet().
	add(new GestureGroup(Gensym.next(GESTURE_GROUP_PREFIX)));
      break;
    default:
      super.doCommand(id);
      break;
    }
  }
}
