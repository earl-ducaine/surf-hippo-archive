package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.ActionListener;

/*Constructs the collapsed view of a prompt node  
*/
public class SingleCollapsedNodeView extends AbstSingleNodeView {
    
    private SText m_textField;
    private final RoundRectangle2D.Float CL_SHAPE = new RoundRectangle2D.Float(0,0,DEFAULT_WIDTH-1,CL_HEIGHT-1,ARC, ARC);
    private Area       m_collapsedTextShape = new Area(CL_SHAPE);
    
    public SingleCollapsedNodeView(SuedeModel model, SingleNodeModel nodeModel, String name, ActionListener al, String caption) {
        super(model, nodeModel);  setName(name);
        setLayout(null);
        m_playButton = new PlayButton(false, NODE_STROKE);
        m_recordButton = new RecordButton(Color.black, NODE_STROKE);
        if (al != null) {
            m_recordButton.addActionListener(al);    
        }
        setSize(DEFAULT_WIDTH, CL_HEIGHT);
        m_collapsedTextShape.subtract(new Area(new Rectangle(DEFAULT_WIDTH-2*BUTTON_WIDTH, 0, 2*BUTTON_WIDTH, CL_HEIGHT-1)));
        m_playButton.setBounds(DEFAULT_WIDTH - BUTTON_WIDTH, 1, BUTTON_WIDTH, CL_HEIGHT);
        add(m_playButton);                
        m_recordButton.setBounds(DEFAULT_WIDTH - 2*BUTTON_WIDTH, 1, BUTTON_WIDTH, CL_HEIGHT);
        add(m_recordButton);
        m_textField = new SText(m_collapsedTextShape);
        m_textField.setStroke(null);
        m_textField.setLocation(0,0);
        m_textField.setText(caption);
        m_textField.setEditable(false);
        m_textField.setHighlighter(null);
        add(m_textField);
        
    }
    
    public void setCaption(String s) {
        m_textField.setText(s);
    }
    
    public String getCaption() {
        return m_textField.getText();
    }
    
    public boolean isOperable(Point p) {
        if ( m_nodemodel.getSuedeModel().getAnalysisMode() )
            return false;
 
        return true;    
    }
    
    public void paintComponent(Graphics g) {
       
        Graphics2D g2d = (Graphics2D)g; 
        g2d.setColor(NODE_FILL);
        g2d.fill(CL_SHAPE);
        g2d.setColor(NODE_STROKE);
        g2d.setStroke(AbstNodeView.STROKE);
        super.paintComponent(g2d);

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(NODE_STROKE);
        g2d.draw(CL_SHAPE);

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g2d.setStroke(PIXEL_STROKE);
        g2d.drawLine(DEFAULT_WIDTH - 2*BUTTON_WIDTH, 0, DEFAULT_WIDTH - 2*BUTTON_WIDTH, CL_HEIGHT-1);
        g2d.drawLine(DEFAULT_WIDTH - BUTTON_WIDTH,   0, DEFAULT_WIDTH - BUTTON_WIDTH,   CL_HEIGHT-1);
        
            
    }
    
}