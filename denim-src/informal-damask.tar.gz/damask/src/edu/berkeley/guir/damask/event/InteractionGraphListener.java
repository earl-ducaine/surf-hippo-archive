package edu.berkeley.guir.damask.event;

import java.util.EventListener;

/** 
 * The listener interface for receiving events regarding changes to an
 * interaction graph. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-12-2004 James Lin
 *                               Created InteractionGraphListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-12-2004
 */
public interface InteractionGraphListener extends EventListener {
   
   /**
    * Invoked when the home page of an interaction graph has changed.
    */
   void homePageChanged(InteractionGraphEvent e);
}
