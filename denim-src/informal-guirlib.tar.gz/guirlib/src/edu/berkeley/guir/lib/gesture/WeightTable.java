package edu.berkeley.guir.lib.gesture;

import edu.berkeley.guir.lib.gesture.util.Misc;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

/**
 */
public class WeightTable extends JFrame
{
  Classifier classifier;
  JTable table;
  Double[][] weights;
  
  /**
   * exampleMatrix[i][j] should be a Vector if all Gestures from Category
   * i that were categorized as being in Category j.
   */
  WeightTable(Classifier c)
  {
    super("Weight Table");
    classifier = c;
    updateWeights();
    buildUI();
  }

  private void updateWeights()
  {
    weights = Misc.promoteMatrix(classifier.weights);
  }
  
  private void buildUI()
  {
    Container contents = getContentPane();
    contents.setLayout(new BorderLayout());

    // make table
    TableModel dataModel = new AbstractTableModel() {
      FeatureVector dummyFV = new FeatureVector();
      public int getColumnCount() { return weights.length+1; }
      public int getRowCount() { return weights[0].length-1; }
      public Object getValueAt(int r, int c)
      {
	if (c == 0)
	  return getRowName(r);
	else
	  return weights[c-1][r+1];
      }
      public Class getColumnClass(int c)
      {
	return (c == 0) ? String.class : Double.class;
      }
      public String getColumnName(int c)
      {
	if (c == 0)
	  return "Class";
	else
	  return ((GestureContainer) classifier.getGestureSet().
		  getChild(c-1)).getName();
      }
      public String getRowName(int r)
      {
	return dummyFV.getFeature(r).getName();
      }
    };

    table = new JTable(dataModel);
    new ColorRenderer(table);
    table.setRowSelectionAllowed(false);
    table.setColumnSelectionAllowed(false);
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    // this is a hack; really should figure out how big the column
    // needs to be and set it to that
    TableColumnModel tcm = table.getColumnModel();
    for (int i = 1; i < dataModel.getColumnCount(); i++) {
      TableColumn column = tcm.getColumn(i);
      column.setWidth(column.getWidth()/2);
    }

    JScrollPane scrollPane = new JScrollPane(table);
    
    contents.add(scrollPane, BorderLayout.CENTER);

    // make menu bar
    JMenu menu;
    JMenuItem item;
    ActionListener listener;
    JMenuBar menuBar = new JMenuBar();

    menu = new JMenu("Table");
    item = new JMenuItem("Close");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	WeightTable.this.dispose();
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    // add more Graph items here
    menuBar.add(menu);

    getRootPane().setJMenuBar(menuBar);
  }

  class ColorRenderer implements TableCellRenderer
  {
    TableCellRenderer oldRenderer;

    /**
     * Installs itself in table, too
     */
    ColorRenderer(JTable table)
    {
      oldRenderer = table.getDefaultRenderer(Double.class);
      table.setDefaultRenderer(Double.class, this);
    }
    
    public Component getTableCellRendererComponent(JTable table,
						   Object value,
						   boolean isSelected,
						   boolean hasFocus,
						   int row,
						   int column)
    {
      if (value == null) {
	Component defaultComponent = oldRenderer.
	  getTableCellRendererComponent(table, value, isSelected, hasFocus,
					row, column);
	defaultComponent.setBackground(Color.white);
	return defaultComponent;
      }

      double x = ((Double) value).doubleValue();
      
      value = Misc.toString(x, 2);
      
      Component defaultComponent =
	oldRenderer.getTableCellRendererComponent(table, value, isSelected,
						  hasFocus, row, column);

      if (column == 0)
	// header
	defaultComponent.setBackground(Color.lightGray);
      else
	defaultComponent.setBackground(Color.white);

      return defaultComponent;
    }
  }
}
