package edu.berkeley.guir.damask.connection;

import java.util.Collection;

/** 
 * Represents the source of a connection.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  05-07-2003 James Lin
 *                               Created ConnectionSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 05-07-2003
 */
public interface ConnectionSource extends ConnectionEndpoint {

   /**
    * Returns all connections originating from this component.
    */
   Collection/*<Connection>*/ getOutConnections();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the given connection to the collection of connections originating
    * from this component. Only called by Connection.setSource(). 
    */
   void addOutConnection(Connection outConnection);
   
   //---------------------------------------------------------------------------

   /**
    * Removes the given connection to the collection of connections originating
    * from this component. Only called by Connection.setSource(). 
    */
   void removeOutConnection(Connection outConnection);
}
