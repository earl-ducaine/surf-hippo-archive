package edu.berkeley.guir.lib.gesture;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import edu.berkeley.guir.lib.gesture.util.HystericResizer;
import edu.berkeley.guir.lib.gesture.util.Misc;

/**
 * Wrap a FeaturePointGraph in its own frame and add controls for it
 * (e.g., menubar).
 */
public class FPGraphFrame extends JFrame
{
  FeaturePointGraph graph;
  FeaturePicker featurePicker = null;
  CategoryPicker categoryPicker;
  JCheckBoxMenuItem weightsMenuItem;
  
  public FPGraphFrame(Classifier c)
  {
    this(c, null);
  }
       
  public FPGraphFrame(Classifier classifier, String name)
  {
    super();
    GestureSet gestureSet = classifier.getGestureSet();
    setTitle("Feature Graph" +
	     ((gestureSet.getName() == null) ? "" : 
	      (": " + gestureSet.getName())));
    buildUI(classifier);
  }

  private void buildUI(Classifier classifier)
  {
    Container contents = getContentPane();
    contents.setLayout(new BorderLayout());
    GestureSet gestureSet = classifier.getGestureSet();
    graph = new FeaturePointGraph(classifier);
    JScrollPane scrollPane = new JScrollPane(graph);
    scrollPane.
      setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
    
    contents.add(scrollPane, BorderLayout.CENTER);

    // make the category selector
    categoryPicker = new CategoryPicker(gestureSet,
					FPGraphFeature.colorArray);
    ItemListener itemListener = new ItemListener() {
      public void itemStateChanged(ItemEvent e)
      {
	//System.err.println("got item event: " + e);
	graph.setCategoryMask(categoryPicker.getCategoryMask());
	//FPGraphFrame.this.repaint();
      }
    };
    categoryPicker.addItemListener(itemListener);
    JScrollPane categoryPickerScroller =
      new JScrollPane(categoryPicker,
		      JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
		      JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    contents.add(categoryPickerScroller, BorderLayout.WEST);
    
    // make the menu bar
    JMenu menu;
    JMenuItem item;
    ActionListener listener;
    JMenuBar menuBar = new JMenuBar();
    
    menu = new JMenu("Graph");
    item = new JMenuItem("Close");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	FPGraphFrame.this.dispose();
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    // add more Graph items here
    menuBar.add(menu);

    menu = new JMenu("View");
    final JCheckBoxMenuItem cbItem = new JCheckBoxMenuItem("Use weights");
    item = cbItem;
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	graph.weightsOn(cbItem.getState());
      }
    };
    weightsMenuItem = cbItem;
    item.addActionListener(listener);
    menu.add(item);
    item = new JMenuItem("Filter features");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	if (featurePicker == null) {
	  featurePicker = new FeaturePicker("Features");
	  featurePicker.pack();
	  graph.setFeaturePicker(featurePicker);
	}
	featurePicker.show();
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    item = new JMenuItem("Enable all classes");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	BitSet bitSet = new BitSet(categoryPicker.numCategories());
	categoryPicker.setCategoryMask(Misc.not(bitSet));
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    item = new JMenuItem("Disable all classes");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	BitSet bitSet = new BitSet(categoryPicker.numCategories());
	categoryPicker.setCategoryMask(bitSet);
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    // add more Graph items here
    menuBar.add(menu);
	       
    // Make what the user says go
    HystericResizer hr = new HystericResizer();
    getRootPane().addComponentListener(hr);
    getRootPane().setJMenuBar(menuBar);

    // set a resonable initial size
    scrollPane.setSize(new Dimension(600, 400));

    addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e)
      {
	System.err.println("FPGraphFrame hit");
      }
    });
  }

  public FeaturePointGraph getGraph()
  {
    return graph;
  }

  public void setCategoryMask(BitSet categoryMask)
  {
    graph.setCategoryMask(categoryMask);
    categoryPicker.setCategoryMask(categoryMask);
  }

  public void enableWeights(boolean weightsOn)
  {
    weightsMenuItem.setEnabled(weightsOn);
  }
}
