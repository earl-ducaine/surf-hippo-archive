package edu.berkeley.guir.damask.view.visual.component;

import java.awt.Color;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;
import javax.swing.JTextField;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.component.TextInput;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.nodes.PText;
import edu.umd.cs.piccolo.util.PPaintContext;
import edu.umd.cs.piccolo.util.PPickPath;

/** 
 * A text box.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-12-2003 James Lin
 *                               Created TextBox.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 11-12-2003
 */
public class TextBox extends ControlView {

   private static final int DEFAULT_WIDTH = 120;
   private static final int DEFAULT_HEIGHT = 25;
   
   private PText text = new PText();

   /**
    * Constructs a text box and associates it with the specified input. 
    */
   public TextBox(final TextInput textInput) {
      super(textInput, new RunModeEventHandler());
      setStrokePaint(Color.BLACK);
      setPaint(DamaskAppUtils.NO_COLOR);
   }
   
   
   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();

      final DeviceType deviceType = getDeviceType();
      final TextInput textInput = (TextInput)getModel();
      
      // Set the border
      setPathTo(textInput.getBorder(deviceType));
      final Rectangle2D bounds = getModel().getBounds(deviceType);
      if (bounds != null) {
         setBounds(bounds);
      }
     
      addChild(text);
      text.setPickable(false);
      text.setBounds(getBounds());
   }


   /**
    * Returns the text in this text box.
    */
   public Object getState() {
      return text.getText();
   }


   /**
    * Sets the text in this text box. 
    */
   public void setState(final Object state) {
      text.setText((String)state);
   }


   /**
    * Returns a representation of what a text box looks like by default.
    */
   public static PNode createTempView() {
      final PPath border = new PPath(
         new Rectangle2D.Double(0, 0, DEFAULT_WIDTH, DEFAULT_HEIGHT));
      
      return border;
   }


   // Overrides abstract method in parent class.
   public Object getEditableContents() {
      return getContent();
   }

   /**
    * Returns the content of this component view, which is always null.
    */
   public Label getContent() {
      return null;
   }


   //=========================================================================
   // The code below mimics functionality in edu.umd.cs.piccolox.nodes.PClip.

   protected void paint(PPaintContext paintContext) {
      clipPaint(paintContext);
   }

   protected void paintAfterChildren(PPaintContext paintContext) {
      clipPaintAfterChildren(paintContext);
   }

   public boolean fullPick(PPickPath pickPath) {
      return clipFullPick(pickPath);
   }

   // The code above mimics functionality in edu.umd.cs.piccolox.nodes.PClip.
   //=========================================================================

   
   /**
    * The event handler for a text box in Run mode.
    */
   private static class RunModeEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         if (event.getPickedNode() instanceof TextBox) {
            final TextBox textBox = (TextBox)event.getPickedNode();
            final JTextField textField = new JTextField();
         
            textField.setText((String)textBox.getState());

            final Rectangle2D textBoxScreenBds = textBox.getBounds();
            textBox.localToGlobal(textBoxScreenBds);
            event.getTopCamera().viewToLocal(textBoxScreenBds);
            textField.setLocation(
               (int)textBoxScreenBds.getX(),
               (int)textBoxScreenBds.getY());
            textField.setSize(
               (int)textBoxScreenBds.getWidth(),
               (int)textBoxScreenBds.getHeight());
            textField.setText((String)textBox.getState());
            
            ((JComponent)event.getComponent()).add(textField);
            textField.addFocusListener(new TextFieldFocusHandler(textBox));
         }
      }
   }
   
   private static class TextFieldFocusHandler implements FocusListener {
      private final TextBox textBox;
      
      public TextFieldFocusHandler(final TextBox textBox) {
         this.textBox = textBox;
      }
      
      public void focusGained(FocusEvent event) {
      }

      public void focusLost(FocusEvent event) {
         final JTextField textField = (JTextField)event.getComponent();
         final VisualCanvas canvas = (VisualCanvas)textField.getParent();
         
         canvas.setControlState(
            (Control)textBox.getModel(), textField.getText());
         canvas.remove(textField);
         canvas.repaint();
      } 
   }
}
