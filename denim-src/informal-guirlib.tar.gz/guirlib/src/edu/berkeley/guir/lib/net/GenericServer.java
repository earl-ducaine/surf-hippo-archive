//// See bottom of file for software license
package edu.berkeley.guir.lib.net;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import edu.berkeley.guir.lib.io.IOLib;

/**
 * A skeleton framework for a generic server.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Nov 28 2003, JH
 */
public class GenericServer {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    private static final boolean DEBUG = false;

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   INNER CLASS - GPSD SERVER THREAD   =================================

    class ListenThread extends Thread {
        public void run() {
            try {
                listen();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        } // of method
    } // of inner class

    //===   INNER CLASS - GPSD SERVER THREAD   =================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    ServerSocket  svr;
    Socket        sock;
    int           port;
    boolean       flagRun = true;         // keep running the server?

    //----------------------------------------------------------------

    //// Must set one of these to true before starting.
    boolean       flagAsBuffer            = false;
    boolean       flagAsLine              = false;
    boolean       flagAsReaderWriter      = false;
    boolean       flagAsInputOutputStream = false;

    //----------------------------------------------------------------

    //// Accept local connections only
    boolean       flagAcceptLocalhostOnly = false;

    //----------------------------------------------------------------

    ListenThread  thread;
    boolean       flagDaemon = false;

    //----------------------------------------------------------------

    //// Checking for localhost information
    static InetAddress[] localhosts = new InetAddress[0];
    static boolean       flagInit   = false;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    public GenericServer(int aPort) {
        this(aPort, false);
    } // of method

    //----------------------------------------------------------------

    public GenericServer(int aPort, boolean newFlagDaemon) {
        port       = aPort;
        flagDaemon = newFlagDaemon;
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY METHODS   ==================================================

    private static void init() {
        //// 0. Init only once.
        if (flagInit == true) {
            return;
        }
        flagInit = true;

        //// 1. Try to get hosts.
        try {
            localhosts = InetAddress.getAllByName("localhost");
        }
        catch (Exception e) {
            // ignore
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * See if the address is local to the current machine.
     */
    private static boolean isLocal(InetAddress addr) {
        //// 1. Check local address.
        if (addr.isAnyLocalAddress() || addr.isLoopbackAddress()) {
            return (true);
        }

        //// 2. Otherwise, try checking the address manually.
        init();
        for (int i = 0; i < localhosts.length; i++) {
            if (localhosts[i].equals(addr)) {
                return (true);
            }
        }

        //// 3. Failed, so return false.
        return (false);
    } // of method

    //===   UTILITY METHODS   ==================================================
    //==========================================================================



    //==========================================================================
    //===   SERVER METHODS   ===================================================

    public void setAcceptLocalhostOnly() {
        flagAcceptLocalhostOnly = true;
    } // of method

    //----------------------------------------------------------------

    /**
     * Call this if you want data as a buffer (ie server reads it all
     * up and then hands you a StringBuffer).
     */
    public void setGetAsBuffer() {
        flagAsBuffer = true;
    } // of method

    /**
     * Call this if you want data as a line.
     */
    public void setGetAsLine() {
        flagAsLine = true;
    } // of method

    /**
     * Call this if you want data as a stream.
     */
    public void setGetAsInputOutputStream() {
        flagAsInputOutputStream = true;
    } // of method

    /**
     * Call this if you want data as a reader / writer pair.
     */
    public void setGetAsReaderWriter() {
        flagAsReaderWriter = true;
    } // of method

    //===   SERVER METHODS   ===================================================
    //==========================================================================



    //==========================================================================
    //===   CONNECTION METHODS   ===============================================

    /**
     * Start listening synchronously for connections.
     */
    protected void listen() 
        throws IOException {

        svr     = new ServerSocket(port);
        flagRun = true;

        while (flagRun == true) {
            try {
                //// 1. Get the connection.
                sock = svr.accept();

                //// 2. See if it is a valid address.
                if (flagAcceptLocalhostOnly == true) {
                    InetAddress addr = sock.getInetAddress();
                    if (isLocal(addr) == false) {
                        sock.close();
                    }
                }

                //// 3. If valid, handle it.
                if (sock.isConnected() == true) {
                    handleSocket(sock);
                }
            }
            catch (IOException e) {
                // ignore
                e.printStackTrace();
            }
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Start the server synchronously (so only one connection at a time).
     */
    public void start() 
        throws IOException {

        start(true);
    } // of method


    /**
     * Call this to start the server.
     * @param flagSynchronous is true is synchronous (ie blocks on
     *                        the current thread), false if asynchronous
     *                        (we create our own thread internally for you).
     */
    public void start(boolean flagSynchronous) 
        throws IOException {

        //// 1. Do error checking.
        if (!(flagAsBuffer       == true || flagAsLine              == true ||
              flagAsReaderWriter == true || flagAsInputOutputStream == true)) {
            throw new IllegalArgumentException(
                        "Have to set how to handle output, ex. setGetAsLine()");
        }

        //// 2. Start the server.
        if (flagSynchronous == true) {
            listen();
        }
        else {
            thread = new ListenThread();
            thread.setDaemon(flagDaemon);
            thread.start();
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Stop listening for connections.
     */
    public void stop() 
        throws IOException {

        flagRun = false;
        svr.close();
        thread.interrupt();
    } // of method

    //----------------------------------------------------------------

    /**
     * Read in the requests and reply.
     */
    protected void handleSocket(Socket sock) 
        throws IOException {

        //// 1. Setup the requestor info.
        InputStream    istream = sock.getInputStream();
        OutputStream   ostream = sock.getOutputStream();
        Reader         rdr;
        Writer         wtr;
        BufferedReader brdr;
        String         strLine;

        //// 2.1. Dispatch as stream.
        if (flagAsInputOutputStream == true) {
            handleAsInputOutputStream(istream, ostream);
            ostream.flush();
        }
        //// 2.2. Dispatch as reader / writer.
        else if (flagAsReaderWriter == true) {
            rdr     = new InputStreamReader(istream);
            wtr     = new OutputStreamWriter(ostream);
            handleAsReaderWriter(rdr, wtr);
            wtr.flush();
        }
        //// 2.3. Dispatch as a line.
        else if (flagAsLine == true) {
            rdr     = new InputStreamReader(istream);
            wtr     = new OutputStreamWriter(ostream);
            brdr    = new BufferedReader(rdr);

            //// 
            while ((strLine = brdr.readLine()) != null) {
                handleAsLine(strLine, wtr);
                wtr.flush();
            }
        }
        else if (flagAsBuffer == true) {
            wtr     = new OutputStreamWriter(ostream);
            handleAsBuffer(IOLib.readAll(istream), wtr);
            wtr.flush();
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Override this if you want to handle as a stream.
     */
    protected void handleAsInputOutputStream(InputStream  istream,
                                             OutputStream ostream) 
        throws IOException {
    } // of method

    /**
     * Override this if you want to handle as a reader / writer.
     */
    protected void handleAsReaderWriter(Reader rdr,
                                        Writer wtr)
        throws IOException {

    } // of method

    /**
     * Override this if you want to handle as a single line
     * (ended by '\n').
     */
    protected void handleAsLine(String strLine, Writer wtr)
        throws IOException {

    } // of method

    /**
     * Override this if you want to handle as a buffer.
     */
    protected void handleAsBuffer(StringBuffer strbuf, Writer wtr)
        throws IOException {

    } // of method

    //===   CONNECTION METHODS   ===============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
