package edu.berkeley.guir.damask.view;

import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.logging.Logger;

import javax.swing.*;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.view.appevent.RunCanvasEvent;
import edu.berkeley.guir.damask.view.appevent.RunCanvasListener;
import edu.berkeley.guir.damask.view.visual.DamaskPhoneRunFrame;
import edu.berkeley.guir.damask.view.visual.DamaskRunCanvas;
import edu.umd.cs.piccolox.swing.PScrollPane;


/** 
 * The window that contains the Damask application in Run mode.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-25-2003 James Lin
 *                               Created DamaskRunFrame
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 11-25-2003
 */
public class DamaskRunFrame extends JFrame {
   private final DamaskRunCanvas canvas;

   private JButton backButton;
   private JButton forwardButton;
   private final PScrollPane scrollPane;
   
   // Logger
   private static final Logger logger =
      Logger.getLogger(DamaskPhoneRunFrame.class.getName());
   
   /**
    * Constructs a Run window that displays pages from the specified document,
    * and makes the window visible.
    */
   public DamaskRunFrame(final String documentName, final Page page) {
      final DeviceType deviceType = page.getDeviceType();
      
      setTitle(documentName + " [Run - " + deviceType + "] - Damask");

      canvas = new DamaskRunCanvas();
      canvas.addRunCanvasListener(new RunCanvasHandler());

      final Container contentPane = getContentPane();
      contentPane.setLayout(new BorderLayout());

      scrollPane = new PScrollPane(canvas);
      canvas.setContainingScrollPane(scrollPane);
      contentPane.add(scrollPane, BorderLayout.CENTER);

      // Add the toolbar with Back and Forward buttons
      final JToolBar toolBar = new JToolBar();
      backButton = DamaskAppUtils.createBackButton(new BackAction());
      backButton.setEnabled(false);
      
      forwardButton = DamaskAppUtils.createForwardButton(new ForwardAction());
      forwardButton.setEnabled(false);
      
      toolBar.add(backButton);
      toolBar.add(forwardButton);
      toolBar.setFloatable(false);
      contentPane.add(toolBar, BorderLayout.NORTH);

      // View the current page, and make the window the same size as the
      // device type's default dimensions
      canvas.goToPage(page);

      setVisible(true);
      final Insets insets = getInsets();      
      canvas.setPreferredSize(
         new Dimension(
            deviceType.getDefaultWidth() + insets.left + insets.right,
            deviceType.getDefaultHeight()
               + (int)canvas.getCurrentPageView().getOffset().getY()
               + insets.top
               + insets.bottom));
      scrollPane.getViewport().setViewPosition(new Point(0, 0));
      
      pack();

      final WindowHandler winHandler = new WindowHandler();
      addWindowListener(winHandler);
      addWindowFocusListener(winHandler);
      
      logger.info(DamaskRunFrame.this + " opened with view of " +
                  canvas.getCurrentPageView().getModel());
   }

   
   /**
    * Enables or disables the Back and Forward buttons, depending on
    * whether there are pages in their respective stacks.
    */
   protected void updateButtonsEnabled() {
      backButton.setEnabled(canvas.canGoBack());
      forwardButton.setEnabled(canvas.canGoForward());      
   }

   
   // @Override
   public String toString() {
      return DamaskUtils.toShortString(this);
   }

   
   /**
    * The Back action.
    */
   private class BackAction extends AbstractAction {
      public BackAction() {
         super("Back");
         putValue(SHORT_DESCRIPTION, "Go back to the previous page");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_LEFT));
      }

      public void actionPerformed(ActionEvent e) {
         canvas.goBack();
         logger.info(DamaskRunFrame.this + ": back -> " +
                     canvas.getCurrentPageView().getModel());
      }
   }


   /**
    * The Forward action.
    */
   private class ForwardAction extends AbstractAction {
      public ForwardAction() {
         super("Forward");
         putValue(SHORT_DESCRIPTION, "Go forward to the next page");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_RIGHT));
      }

      public void actionPerformed(ActionEvent e) {
         canvas.goForward();
         logger.info(DamaskRunFrame.this + ": forward -> " +
                     canvas.getCurrentPageView().getModel());
      }
   }
   
   
   /**
    * Listens to events from DamaskRunCanvas.
    */
   private class RunCanvasHandler implements RunCanvasListener {
      public void loadCompleted(RunCanvasEvent e) {
         updateButtonsEnabled();
         logger.info(DamaskRunFrame.this + " loaded with view of " +
                     canvas.getCurrentPageView().getModel());
         scrollPane.getVerticalScrollBar().setValue(
            scrollPane.getVerticalScrollBar().getMinimum());
      }
   }

   /**
    * Responds to window events.
    */
   private class WindowHandler extends WindowAdapter {
      public void windowClosing(WindowEvent e) {
         logger.info(DamaskRunFrame.this + " closed");
      }

      public void windowGainedFocus(WindowEvent e) {
         logger.info(DamaskRunFrame.this + " gained focus");
      }

      public void windowLostFocus(WindowEvent e) {
         logger.info(DamaskRunFrame.this + " lost focus");
      }
   }
}
