package edu.berkeley.guir.damask.view.voice;

import java.awt.Cursor;

import edu.berkeley.guir.damask.view.DamaskAppMode;
import edu.umd.cs.piccolo.event.PInputEventListener;

/** 
 * An input mode that Damask can be in. This class associates a mode with a
 * set of input event handlers and mouse cursors.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-08-2004 James Lin
 *                               Created DamaskAppMode by converting
 *                               DamaskApp.EventMode.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-08-2004
 */
public class VoiceMode extends DamaskAppMode {
   private final PInputEventListener formHandler;
   private final PInputEventListener promptHandler;
   private final PInputEventListener responseTextHandler;
   private final PInputEventListener responseHotSpotHandler;
   private final Cursor formCursor;
   private final Cursor promptCursor;
   private final Cursor responseTextCursor;
   private final Cursor responseHotSpotCursor;

   /**
    * Constructs a mode.
    * 
    * @param name                 the name of the mode
    * @param backgroundHandler    the handler of mouse events when the mouse is
    *                              over the canvas background
    * @param formHandler          the handler of mouse events when the mouse is
    *                              over a form
    * @param promptHandler        the handler of mouse events when the mouse is
    *                              over a prompt
    * @param responseTextHandler  the handler of mouse events when the mouse is
    *                              over the voice balloon of the response
    * @param responseStartPointHandler
    *                              the handler of mouse events when the mouse is
    *                              over the start point of the response
    * @param responseEndPointHandler
    *                              the handler of mouse events when the mouse is
    *                              over the end point of the response
    * @param backgroundCursor  the cursor that appears when the mouse is over
    *                           the canvas background
    * @param formCursor        the cursor that appears when the mouse is over
    *                           a page
    * @param textCursor        the cursor that appears when the mouse is over
    *                           a prompt or response's voice balloon
    * @param responseEndpointsCursor
    *                           the cursor that appears when the mouse is over
    *                           either of the endpoints of a response
    */
   public VoiceMode(
      final String name,
      final PInputEventListener backgroundHandler,
      final PInputEventListener formHandler,
      final PInputEventListener promptHandler,
      final PInputEventListener responseTextHandler,
      final PInputEventListener responseHotSpotHandler,
      final Cursor backgroundCursor,
      final Cursor formCursor,
      final Cursor promptCursor,
      final Cursor responseTextCursor,
      final Cursor responseHotSpotCursor) {

      super(name, backgroundHandler, backgroundCursor);
      this.formHandler = formHandler;
      this.formCursor = formCursor;
      this.promptHandler = promptHandler;
      this.responseTextHandler = responseTextHandler;
      this.responseHotSpotHandler = responseHotSpotHandler;
      this.promptCursor = promptCursor;
      this.responseTextCursor = responseTextCursor;
      this.responseHotSpotCursor = responseHotSpotCursor;
   }
   
   /**
    * Returns the event listener to use when the mouse is over a form.
    */
   public PInputEventListener getFormHandler() {
      return formHandler;
   }

   /**
    * Returns the cursor that appears when the mouse is over a form.
    */
   public Cursor getFormCursor() {
      return formCursor;
   }

   /**
    * Returns the event listener to use when the mouse is over the text of a
    * prompt.
    */
   public PInputEventListener getPromptHandler() {
      return promptHandler;
   }

   /**
    * Returns the event listener to use when the mouse is over the text of a
    * response.
    */
   public PInputEventListener getResponseTextHandler() {
      return responseTextHandler;
   }

   /**
    * Returns the event listener to use when the mouse is over the start or
    * end point of a response.
    */
   public PInputEventListener getResponseHotSpotHandler() {
      return responseHotSpotHandler;
   }

   /**
    * Returns the cursor that appears when the mouse is over a prompt.
    */
   public Cursor getPromptCursor() {
      return promptCursor;
   }

   /**
    * Returns the cursor that appears when the mouse is over the text of a
    * response.
    */
   public Cursor getResponseTextCursor() {
      return responseTextCursor;
   }

   /**
    * Returns the cursor that appears when the mouse is over either of the
    * endpoints of a response.
    */
   public Cursor getResponseHotSpotCursor() {
      return responseHotSpotCursor;
   }
   
   public String toString() {
      return "DamaskAppMode:" + getName();
   }
}
