package edu.berkeley.guir.lib.gesture;

import java.io.Serializable;

/**
 * Gestures specifically for training a recognizer
 */
public class GestureTrainingSet extends GestureSet
implements Serializable, Cloneable {
}
