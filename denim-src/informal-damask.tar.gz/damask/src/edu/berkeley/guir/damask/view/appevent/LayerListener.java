package edu.berkeley.guir.damask.view.appevent;

import java.util.EventListener;

/** 
 * The listener interface for receiving events indicating that a layer
 * has been changed.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-21-2004 James Lin
 *                               Created LayerListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-21-2004
 */
public interface LayerListener extends EventListener {
   
   /**
    * Invoked when the device-type layer of a layer has changed.
    */
   void deviceTypeLayerChanged(LayerEvent e);
}
