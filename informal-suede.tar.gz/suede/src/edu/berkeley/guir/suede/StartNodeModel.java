package edu.berkeley.guir.suede;

import java.awt.*;


/*
 *Things that must be changed for model/viewer rewrite:
 *
 * - Do we even need this class? Maybe a StartNodeView should be model-less.
 *
 */


public class StartNodeModel extends AbstNodeModel {
    StartNodeView m_node;
    
    public StartNodeModel(SuedeModel model) {
        m_node = new StartNodeView(model, this);
        m_node.setBounds(50,50,60,40);
        m_node.setVisible(true);
        m_node.setOpaque(false);
        model.getContentPane().add(m_node);
    }

    public AbstNodeView getView() {
        return m_node;
    }

    public String getGroupName() {
        return "";
    }

    public String getCaption() {
       
        return null;
    }

    public String getLabel() {
       
        return new String("START");
    }
    
    public void expand() {
        
    }
    
    public void collapse() {
        
    }
    
    public void consDefault() {
        
    }
    
    public boolean isOperable(Point p) {
        return true;   
    }
	//{{DECLARE_CONTROLS
	//}}
}