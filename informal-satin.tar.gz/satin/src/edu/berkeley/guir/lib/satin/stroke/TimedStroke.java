//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.stroke;

import java.awt.*;
import java.awt.geom.*;

import org.w3c.dom.*;

import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.graphics.SatinGraphics;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.util.StringLib;

/**
 * A single Stroke that can paint itself. This is not a Component 
 * because there would be too many components. This work is based off of
 * Chris Long's GDT Gesture class.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, May 17 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.1.0, Mar 16 2001, JL
 *               Made instance variables protected or private
 * 			   - SATIN-v2.1-2.0.0, Nov 6 2002, YL
 * 				 Modifed damageAroundPoint to enable idle render
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~allanl/">Chris Long</A> (
 *         <A HREF="mailto:allanl@cs.berkeley.edu">allanl@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version SATIN-v2.1-2.0.0, Nov 6 2002
 */
public class TimedStroke
   extends    GraphicalObjectImpl 
   implements SatinConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 1722093520451738482L;
   

   //-----------------------------------------------------------------

   /**
    * The name of the file containins the current stroke properties.
    */
   public static final String TIMEDSTROKE_STYLE_FILE = "TimedStroke.properties";

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //==========================================================================
   //===   CLASS VARIABLES   ==================================================

   static {
      //// 1. Class property initializations.
      clprops.setClassProperty(TimedStroke.class, STYLE_CLPROPERTY, 
                                             new Style(TIMEDSTROKE_STYLE_FILE));
   } // of static init

   //-----------------------------------------------------------------

   //// Soft state optimization variables
   static Rectangle       damageRect = new Rectangle();
   static AffineTransform txBuffer   = new AffineTransform();
   static Point2D         ptA        = new Point2D.Float();
   static Point2D         ptB        = new Point2D.Float();

   boolean widthScalingInvariantDrawing = false;
   
   /**
    * Formerly used for a hack, now unused.
    * 
    * @deprecated
    */
   public static void setDrawFix(boolean flag) {
   } // of method

   //===   CLASS VARIABLES   ==================================================
   //==========================================================================




   //===========================================================================
   //===   NONLOCAL INSTANCE VARIABLES   =======================================

   protected TimedPolygon2D  poly;                     // Local shape of stroke
   protected float           lastx =
                              Float.NEGATIVE_INFINITY; // last x-loc we were at
   protected float           lasty =
                              Float.NEGATIVE_INFINITY; // last y-Loc we were at
   protected double          length;                   // length of stroke

   private   boolean         flagLeft;                 // is left button down?
   private   boolean         flagMiddle;               // is middle button down?
   private   boolean         flagRight;                // is right button down?

   //===   NONLOCAL INSTANCE VARIABLES   =======================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create an empty Stroke.
    */
   public TimedStroke() {
      //// 1. Create an empty stroke.
      poly = new TimedPolygon2D();
      setLocalBoundingPoints2DRef(poly);
      setHasClosedBoundingPoints(false);
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Create a stroke based on this Polygon.
    *
    * @param p is the Polygon to copy as the basis for this stroke.
    *        Should be non-null. Polygon should be in relative coordinates.
    */
   public TimedStroke(Polygon p) {
      //// 1. Create the new polygon.
      poly = new TimedPolygon2D(p);

      //// 2. Set the bounding points.
      setLocalBoundingPoints2DRef(poly);
      setHasClosedBoundingPoints(false);

      //// 3. Calculate length.
      recalculateLength();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a stroke based on this Polygon.
    *
    * @param p is the TimedPolygon to copy as the basis for this stroke.
    *        Should be non-null. TimedPolygon should be in relative coordinates.
    */
   public TimedStroke(Polygon2D p) {
      //// 1. Initializations.
      if (p instanceof TimedPolygon2D) {
         poly = new TimedPolygon2D((TimedPolygon2D) p);
      }
      else {
         poly = new TimedPolygon2D(p);
      }
      setLocalBoundingPoints2DRef(poly);
      setHasClosedBoundingPoints(p.isClosed());

      //// 2. Calculate length.
      recalculateLength();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Convert arbitrary shapes into TimedStrokes. You will encounter problems
    * if the Shape uses MOVE_TO commands on points other than the first.
    */
   public TimedStroke(Shape s) {
       this (new Polygon2D(s));
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Make a copy of the points of this TimedStroke.
    *
    * @param tstk is the TimedStroke to copy.
    */
   public TimedStroke(TimedStroke tstk) {
       this.setStroke(tstk);
   } // of constructor

   //-----------------------------------------------------------------

   public void setStroke(TimedStroke tstk) {
      poly = tstk.getPolygon2D(COORD_LOCAL);
      setLocalBoundingPoints2DRef(poly);
      recalculateLength();
      setTransform(tstk.getTransform(COORD_REL));
      setHasClosedBoundingPoints(tstk.hasClosedBoundingPoints());
   } // of method

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   MOUSE BUTTON METHODS   ==============================================

   /**
    * Check if left button is down.
    */
   public boolean isLeftButton() {
      return (flagLeft);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Check if middle button is down.
    */
   public boolean isMiddleButton() {
      return (flagMiddle);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Check if right button is down.
    */
   public boolean isRightButton() {
      return (flagRight);
   } // of method

   //===========================================================================

   /**
    * Set whether the left button is down.
    */
   public void setLeftButton(boolean flag) {
      flagLeft = flag;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set whether the middle button is down.
    */
   public void setMiddleButton(boolean flag) {
      flagMiddle = flag;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set whether the right button is down.
    */
   public void setRightButton(boolean flag) {
      flagRight = flag;
   } // of method

   //===   MOUSE BUTTON METHODS   ==============================================
   //===========================================================================




   //===========================================================================
   //===   CONSISTENCY METHODS   ===============================================

   public void setHasClosedBoundingPoints(boolean flag) {
      super.setHasClosedBoundingPoints(flag);
      poly.setClosed(flag);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Completely recalculate the length from scratch.
    */
   protected void recalculateLength() {
      length = 0.0;

      //// 1. Doesn't have a length yet, ignore.
      if (poly.npoints < 2) {
         return;
      }

      length = lengthOfStroke(0, poly.npoints-1);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Call this method AFTER adding a new point to update the length.
    */
   protected void updateLength() {
      if (poly.npoints < 2) {
         return;
      }

      length += GeomLib.distance(poly.xpoints[poly.npoints - 2], 
                                 poly.ypoints[poly.npoints - 2], 
                                 poly.xpoints[poly.npoints - 1], 
                                 poly.ypoints[poly.npoints - 1]);
   } // of method

   //===   CONSISTENCY METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   STROKE MODIFIER METHODS   ===========================================

   /**
    * Calculate and damage the minimum damage box around the nth point of
    * the stroke.
    */
   private void damageAroundPoint(int n) {
      float x = poly.xpoints[n];
      float y = poly.ypoints[n];
      
      txBuffer = getTransform(COORD_ABS, txBuffer);

      //// 1.1. If no points, do nothing.
      if (poly.npoints <= 0) {
      }
      //// 1.2. If we only have one point, center around that.
      else if (poly.npoints == 1) {
         ptA.setLocation(x, y);
         ptB.setLocation(x, y);
      }
      //// 1.3. If we want to damage the 0th point, try damaging the next
      ////      one too.
      else if (n == 0) {
         ptA.setLocation(x, y);
         ptB.setLocation(poly.xpoints[1], poly.ypoints[1]);
      }
      //// 1.4. Damage the last point.
      else if (n == poly.npoints - 1) {
         ptA.setLocation(poly.xpoints[n - 1], poly.ypoints[n - 1]);
         ptB.setLocation(x, y);
      }
      //// 1.5. Normal case - damage one before and one after.
      else {
         float minX;
         float minY;
         float maxX;
         float maxY;

         minX = Math.min(poly.xpoints[n - 1], x);
         minX = Math.min(minX, poly.xpoints[n + 1]);

         minY = Math.min(poly.ypoints[n - 1], y);
         minY = Math.min(minY, poly.ypoints[n + 1]);

         maxX = Math.max(poly.xpoints[n - 1], x);
         maxX = Math.max(maxX, poly.xpoints[n + 1]);

         maxY = Math.max(poly.ypoints[n - 1], y);
         maxY = Math.max(maxY, poly.ypoints[n + 1]);
      }

      //// 2. At this point, ptA and ptB represents the two corner points
      ////    of the rectangle to damage.
      txBuffer.transform(ptA, ptA);
      txBuffer.transform(ptB, ptB);
      
      int width = ((int) getStyleRef().getLineWidth()) + 1;
      damageRect.setRect(Math.min(ptA.getX(),  ptB.getX())  - width/2 - 1,
                         Math.min(ptA.getY(),  ptB.getY())  - width/2 - 1,
                         Math.abs(ptA.getX() - ptB.getX())  + width   + 2,
                         Math.abs(ptA.getY() - ptB.getY())  + width   + 2);

      // if the sheet works in idle rendering mode, send idle render request                         
      final Sheet sheet = getSheet();
      if (sheet != null) {
         final int damageMode;
         if(this.getSheet()!=null)
         {
             if (this.getSheet().isIdleRenderingMode()) {
                damageMode = SatinConstants.DAMAGE_IDLE;
             }
             else {
                damageMode = SatinConstants.DAMAGE_LATER;
             }
             damage(damageMode, damageRect);
         }
      }
   } // of method

   //-----------------------------------------------------------------
   
   public void setScalingInvariant(boolean b) {
       widthScalingInvariantDrawing = b;
   }

   public final void addPoint(float x, float y) {
      this.addPoint(x, y, System.currentTimeMillis());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a point to this Stroke. Keep in mind that the order in which points 
    * are added matters. Furthermore, be sure you add points in the same
    * coordinate system.
    *
    * @param x is the x-Location to add.
    * @param y is the y-Location to add.
    */
   public final void addPoint(double x, double y) {
      this.addPoint((float) x, (float) y, System.currentTimeMillis());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a point to this Stroke. Keep in mind that the order in which points 
    * are added matters.
    *
    * @param pt is the Point to add.
    */
   public final void addPoint(Point2D pt) {
      this.addPoint((float) pt.getX(), (float) pt.getY(), 
                    System.currentTimeMillis());
   } // of method

   //-----------------------------------------------------------------

   public final void addPoint(double x, double y, long time) {
      addPoint((float) x, (float) y, time);
   } // of method
   
   public void addPoint(int myX, int myY){
      this.addPoint((float) myX, (float) myY, System.currentTimeMillis());
   } // of method

   //-----------------------------------------------------------------
 
   /**
    * Method returns true if the point is far away enough from the 
    * previous one.
    */
   protected final boolean pointFilter(float x, float y){
      float dx     = lastx - x;
      float dy     = lasty - y;
      float distSq = dx*dx + dy*dy;
      
      if(distSq > FILTER_THRESHOLD){
         lastx = x;
         lasty = y;
         return true;
      }
      else {
         return false;
      }
   } // of method
      
   //-----------------------------------------------------------------

   public void addPoint(float x, float y, long time) {
      if (pointFilter(x,y)) {
         //// 2.1. Update the point.
         poly.addPoint(x, y, time);
         
         //// 2.2. Update the length.
         updateLength();
         
         //// 2.3. Since we are using a bounding points reference,
         ////      mark as dirty.
         setDirty();
         
         //// 2.4. Setup for minimum damage box calculation.
         damageAroundPoint(poly.npoints - 1);
         
      }
   } // of method

   //-----------------------------------------------------------------

   public final void addPoint(Point2D pt, long time) {
      addPoint((float)pt.getX(), (float)pt.getY(), time);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Tell the stroke that we won't add any more points.
    * For efficiency reasons, the local bounding points for TimedStrokes are 
    * not normalized to (0, 0). Calling this method will make that happen.
    */
   public TimedStroke doneAddingPoints() {
      getViewHandler().normalizeBoundingPoints();
      return (this);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Clear the points in this stroke.
    */
   public void clearPoints() {
      poly.clearPoints();
   } // of method

   //-----------------------------------------------------------------
   
   /**
    * Change the nth point of the stroke to the given coordinates. This
    * method does not normalize the local bounding points.
    */
   public final void changePoint(int n, double x, double y) {
      //// 1. Apply the inverse of the stroke's normalizing transform to
      ////    (x, y), so that it gets normalized correctly on display.
      ptA.setLocation(x, y);
      try {
         getViewHandler().getNormalizingTransform().inverseTransform(ptA, ptA);
         getTransform(COORD_ABS).inverseTransform(ptA, ptA);
      }
      catch (NoninvertibleTransformException e) {
         e.printStackTrace();
      }
      
      //// 2. Change the point.
      poly.xpoints[n] = (float)ptA.getX();
      poly.ypoints[n] = (float)ptA.getY();

      //// 3. Update the length.
      updateLength();

      //// 4. Since we are using a bounding points reference,
      ////    mark as dirty.
      setDirty();

      //// 5. Setup for minimum damage box calculation.
      damageAroundPoint(n);
   } // of method

   //===   STROKE MODIFIER METHODS   ===========================================
   //===========================================================================



   //===========================================================================
   //===   STROKE ACCESSOR METHODS   ===========================================

   /**
    * Get a portion of this stroke by specifying points. For example, calling
    * stk.getSubstroke(3, 6) will create a TimedStroke using stk's points
    * numbers 3, 4, and 5.
    *
    * @param  start is the starting point position. Okay if exceeds bounds,
    *               will just stop at bounds.
    * @param  end   is the ending point position. Okay if exceeds bounds, will
    *               just stop at bounds.
    * @return a TimedStroke.
    */
   private TimedStroke getSubstroke(int start, int end) {
      TimedStroke stk = new TimedStroke();
      for (int i = start; i < end && i < poly.npoints; i++) {
         stk.addPoint(poly.xpoints[i], poly.ypoints[i], poly.times[i]);
      }
      stk.setTransform(getTransformRef());
      return (stk);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a portion of this stroke by percentages of length. For example,
    * calling getSubstroke(0.0, 0.5) would get the first 50% of the stroke,
    * cutting the stroke if necessary.
    *
    * @param  start is the start percentage of length, between 0 and 1
    *               inclusive.
    * @param  end   is the ending percentage of length, between 0 and 1
    *               inclusive, and greater than start.
    * @return a TimedStroke that consists of the points in the specified start
    *         and end percentages (above).
    */
   public TimedStroke getSubstroke(double start, double end) {
      int    startPos;
      int    endPos;
      double tmpLength = 0.0;
      int    i         = 0;

      //// 1. If greater than 50%, go forward. Otherwise, go backwards.
      ////    Goal is to figure out the first index with length < startLen.
      if (start <= 0) {
         startPos = 0;
      }
      else {
         //// 1.2. If we are closer to the beginning, then go forward.
         if (start < 0.5) {
            tmpLength = 0.0;
            for (i = 0; tmpLength/length < start && i < poly.npoints - 1; i++) {
               tmpLength += lengthOfStroke(i, i+1);
            }
            startPos = i - 1;
         }
         //// 1.3. Otherwise, go backwards.
         else {
            tmpLength = length;
            for (i = poly.npoints - 1; tmpLength/length > start && i > 0; i--) {
               tmpLength -= lengthOfStroke(i-1, i);
            }
            startPos = i;
         }
      }

      //// 2. If end is closer to start, then continue forward from start.
      ////    Otherwise, go backwards. Goal is to figure out the first 
      ////    index with length < endLen.
      if (end >= 1.0) {
         endPos = poly.npoints - 1;
      }
      else {
         //// 2.2. If we are closer to the beginning, then go
         ////      forward from start. Don't modify tmpLength in this case.
         if (end - start < 1.0 - end) {
            for ( ; tmpLength/length < end && i < poly.npoints - 1; i++) {
               tmpLength += lengthOfStroke(i, i+1);
            }
            endPos = i - 1;
         }
         //// 2.3. Otherwise, go backwards.
         else {
            tmpLength = length;
            for (i = poly.npoints - 1; tmpLength/length > end && i > 0; i--) {
               tmpLength -= lengthOfStroke(i-1, i);
            }
            endPos = i;
         }
      }
      return (getSubstroke(startPos, endPos));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the length of the stroke from index position start to end.
    * If you wanted to calculate the length of the entire stroke, you
    * would call <CODE>lengthOfStroke(0, poly.npoints-1)</CODE>.
    *
    */
   private double lengthOfStroke(int start, int end) {
      double tmplength = 0.0;

      //// 1. Keep shifting points over, add to the length.
      for (int i = start; i < end; i++) {
         tmplength += GeomLib.distance(poly.xpoints[i],   poly.ypoints[i],
                                        poly.xpoints[i+1], poly.ypoints[i+1]);
      }

      return (tmplength);
   } // of method

   //===========================================================================

   /**
    * Get the number of points in the stroke.
    */
   public int getNumPoints() {
      return poly.npoints;
   } // of method
   
   //-----------------------------------------------------------------

   public TimedPolygon2D getPolygon2D(int cdsys) {
      return (getPolygon2D(cdsys, null, null));
   } // of method

   //-----------------------------------------------------------------

   public TimedPolygon2D getPolygon2D(int cdsys, AffineTransform tx,
                                      TimedPolygon2D p) {
      if (p == null) {
         p = new TimedPolygon2D();
      }

      p.setToShape(poly);

      switch (cdsys) {
         case COORD_LOCAL:
            break;
         case COORD_REL:
            p.transform(getTransformRef());
            break;
         case COORD_ABS:
            p.transform(getTransform(COORD_ABS));
            break;
         default:
            throw new RuntimeException("What the heck was that value?");
      }

      if (tx != null) {
         p.transform(tx);
      }
      
      return (p);
   } // of method

   //-----------------------------------------------------------------

   public Point2D getStartPoint2D(int cdsys) {
      return (getStartPoint2D(cdsys, null, null));
   } // of method

   //-----------------------------------------------------------------

   public Point2D getStartPoint2D(int cdsys, AffineTransform tx, Point2D pt) {
      if (pt == null) {
         pt = new Point2D.Float();
      }

      pt.setLocation(poly.xpoints[0], poly.ypoints[0]);

      switch (cdsys) {
         case COORD_LOCAL:
            break;
         case COORD_REL:
            getTransformRef().transform(pt, pt);
            break;
         case COORD_ABS:
            getTransform(COORD_ABS).transform(pt, pt);
            break;
         default:
            throw new RuntimeException("What the heck was that value?");
      }

      if (tx != null) {
         tx.transform(pt, pt);
      }

      return (pt);
   } // of method

   //-----------------------------------------------------------------

   public Point2D getEndPoint2D(int cdsys) {
      return (getEndPoint2D(cdsys, null, null));
   } // of method

   //-----------------------------------------------------------------

   public Point2D getEndPoint2D(int cdsys, AffineTransform tx, Point2D pt) {
      if (pt == null) {
         pt = new Point2D.Float();
      }

      int   pos = poly.npoints - 1;
      pt.setLocation(poly.xpoints[pos], poly.ypoints[pos]);

      switch (cdsys) {
         case COORD_LOCAL:
            break;
         case COORD_REL:
            getTransformRef().transform(pt, pt);
            break;
         case COORD_ABS:
            getTransform(COORD_ABS).transform(pt, pt);
            break;
         default:
            throw new RuntimeException("What the heck was that value?");
      }

      if (tx != null) {
         tx.transform(pt, pt);
      }

      return (pt);
   } // of method

   //-----------------------------------------------------------------

   public double getLength2D(int cdsys) {
      double zz;

      switch (cdsys) {
         case COORD_LOCAL:
            return (length);
         case COORD_REL:
            zz = AffineTransformLib.getScaleFactor(getTransformRef());
            return (zz * length);
         case COORD_ABS:
            zz = AffineTransformLib.getScaleFactor(getTransform(COORD_ABS));
            return (zz * length);
         default:
            throw new RuntimeException("What the heck was that value?");
      }
   } // of method

   //===========================================================================

   /**
    * Get the start time of this Timed Stroke.
    *
    * @return Standard unix time, ie number of milliseconds since Jan. 1, 1970.
    */
   public long getStartTime() {
      return (poly.times[0]);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the end time of this Timed Stroke.
    *
    * @return Standard unix time, ie number of milliseconds since Jan. 1, 1970.
    */
   public long getEndTime() {
      return (poly.times[poly.npoints - 1]);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a reference to the array of times.
    */
   public long[] getTimes() {
      return (poly.times);
   } // of method

   //===   STROKE ACCESSOR METHODS   ===========================================
   //===========================================================================




   //===========================================================================
   //===   RENDERING   =========================================================

   protected void defaultRender(SatinGraphics g) {
      //// 1. Draw the Stroke.
       if(widthScalingInvariantDrawing)
       {
           Polygon2D p = (Polygon2D)poly.clone();
           p.transform(g.getTransform());
           try
           {
               g.pushTransform(g.getTransform().createInverse());
               g.draw(p);
               g.popTransform();
           }
           catch(Exception ex)
           {
               ex.printStackTrace();
           }
       }
       else
       {
           g.draw(poly);
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Render some selection handles on the stroke itself.
    */
   protected void renderSelected(SatinGraphics g, Rectangle2D rect) {
      //// A. Acquire soft-state.
      AffineTransform tx = (AffineTransform) poolTx.getObject();
      Point2D         pt = (Point2D)         poolPoints.getObject();
     
      //// 1. Get our absolute transform.
      getTransform(COORD_ABS, tx);

      //// 2. Paint the handles.
      int len = poly.npoints;
      if (len > 0) {
         //// 1.1. Paint the first point.
         pt.setLocation(poly.xpoints[0], poly.ypoints[0]);
         tx.transform(pt, pt);
         renderSelectionHandle(g, (int) pt.getX(), (int) pt.getY());

         //// 1.2. Paint the last point.
         pt.setLocation(poly.xpoints[len-1], poly.ypoints[len-1]);
         tx.transform(pt, pt);
         renderSelectionHandle(g, (int) pt.getX(), (int) pt.getY());

         //// 1.3. Paint every sixth point (arbitrary).
         for (int i = 1; i < len; i += 6) {
            pt.setLocation(poly.xpoints[i], poly.ypoints[i]);
            tx.transform(pt, pt);
            renderSelectionHandle(g, (int) pt.getX(), (int) pt.getY());
         }
      }

      //// B. Release soft-state.
      poolTx.releaseObject(tx);
      poolPoints.releaseObject(pt);

   } // of method

   //===   RENDERING   =========================================================
   //===========================================================================




   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String getButtonString() {
      int val = 0;
      if (isLeftButton() == true) {
         val += 1;
      }
      if (isMiddleButton() == true) {
         val += 2;
      }
      if (isRightButton() == true) {
         val += 4;
      }

      switch (val) {
         case 0: return ("   "); 
         case 1: return ("L  "); 
         case 2: return (" M "); 
         case 3: return ("LM "); 
         case 4: return ("  R"); 
         case 5: return ("L R"); 
         case 6: return (" MR"); 
         case 7: return ("LMR"); 
      }
      return ("   ");
   } // of method

   //-----------------------------------------------------------------

   public String toDebugString() {
      StringBuffer strbuf = new StringBuffer();
      strbuf.append(super.toDebugString());
      strbuf.append("\nButtons Down:   " + getButtonString());
      strbuf.append("\nStk Points:     " + StringLib.toString(poly));
      return (strbuf.toString());
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================




   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Create a duplicate of this stroke.
    *
    * @return a duplicated Stroke.
    */
   public Object clone() {
      TimedStroke stk = new TimedStroke();
      clone(stk);
      return(stk);
   } // of clone

   //-----------------------------------------------------------------

   /**
    * For clone chaining purposes.
    *
    * @see GraphicalObjectImpl#clone(GraphicalObjectImpl)
    */
   protected TimedStroke clone(TimedStroke stk) {
      //// 1. First call the superclass clone for clone chaining.
      super.clone(stk);

      //// 2. Now clone variables within this current class.
      stk.poly = (TimedPolygon2D) this.poly.clone();
      stk.setHasClosedBoundingPoints(false);

      return (stk);
   } // of clone

   //-----------------------------------------------------------------

   public Object deepClone() {
      return (this.clone());
   } // of deepClone

   //-----------------------------------------------------------------

   protected Object deepClone(TimedStroke gobClone) {
      return (clone(gobClone));
   } // of deepClone

   
   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) {
      TimedStroke s = new TimedStroke();

      s.addPoint(10, 10);
      s.addPoint(20, 10);
      s.addPoint(20, 20);
      s.addPoint(10, 20);

      System.out.println("len " + s.getLength2D(COORD_LOCAL));

      s.getSubstroke(0, 0.5);
      s.getSubstroke(0.0, 1.0);
      s.getSubstroke(0, 0.25);

      System.out.println();


/*
      s.addPoint(10, 10);
      System.out.println(s.getLocalLength());

      s.addPoint(20, 10);
      System.out.println(s.getLocalLength());

      s.addPoint(20, 20);
      System.out.println(s.getLocalLength());

      s.addPoint(10, 20);
      System.out.println(s.getLocalLength());

      s.applyTransform(AffineTransform.getScaleInstance(2, 2));
      System.out.println(s.getLocalLength());
      System.out.println(s.getLength2D());
      System.out.println(s.getAbsoluteLength());

      s.applyTransform(AffineTransform.getRotateInstance(2));
      System.out.println(s.getLocalLength());
      System.out.println(s.getLength2D());
      System.out.println(s.getAbsoluteLength());

      s.applyTransform(AffineTransform.getTranslateInstance(2, 2));
      System.out.println(s.getLocalLength());
      System.out.println(s.getLength2D());
      System.out.println(s.getAbsoluteLength());

      System.out.println();
      System.out.println(s.getBounds());
      System.out.println(s);
      System.out.println();

      TimedStroke s2 = (TimedStroke) s.clone();
      System.out.println(s2.getBounds());
      System.out.println(s2);
*/
   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

   //----------------------------------------
   
   /**
    * clear all references hold by this object (In the namespace of this class)
    */
   
   public void deepClear() {

      super.deepClear();
      poly = null;
   }
   
   public void stroke2DOM(Document doc, Element parent) {

      Element element = doc.createElement("TimedStroke");

      setAttributeFromStroke(element);
      
      Polygon2D refPoly = this.getPolygon2D(COORD_REL);

      Text text = doc.createTextNode(
        "" + refPoly.xpoints[0] + ":" + refPoly.ypoints[0] + ";");

      String s;

      for (int i=1; i<refPoly.npoints; i++)
      {
         s = text.getNodeValue();
         
         text.setNodeValue(s + refPoly.xpoints[i] + ":" + refPoly.ypoints[i] +";");
      }
    
      element.appendChild(text);
      
      parent.appendChild(element);
   }
   
   static public void DOM2Stroke(Element element, GraphicalObjectGroup parent) {
     
      Polygon2D poly = new Polygon2D();

      Text textNode = (Text)element.getFirstChild();

      String s = textNode.getNodeValue();

      int index1 = 0;
      int index2 = s.indexOf(":");

      String strX,strY;
      strX = s.substring(0,index2);
      index1 = s.indexOf(";",index1+1);

      strY = s.substring(index2+1,index1);

      double x=Double.parseDouble(strX);
      double y=Double.parseDouble(strY);

      poly.addPoint(x, y);
      index2=s.indexOf(":",index2+1);

      while(index2!=-1)
      {
         strX = s.substring(index1+1,index2);
         index1 = s.indexOf(";",index1+1);
         
         if(index1!=-1)
         {
           strY = s.substring(index2+1,index1);
         }
         else
         {
           strY=s.substring(index2+1,s.length());
         }
         
         x = Double.parseDouble(strX);
         y = Double.parseDouble(strY);

         poly.addPoint(x, y);
         index2 = s.indexOf(":", index2+1);
      }

      poly.setClosed(false);
      
      TimedStroke wStroke = new TimedStroke(poly);
    
      wStroke.setAttributeToStroke(element);
    
      parent.add(wStroke);
      
   }
   
   private void setAttributeFromStroke(Element element)
   {
      element.setAttribute("id", String.valueOf(this.getUniqueID()));
   }

   private void setAttributeToStroke(Element element)
   {
      this.setUniqueID(Integer.parseInt(element.getAttribute("id")));
   }
      
} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
