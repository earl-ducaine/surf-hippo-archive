package edu.berkeley.guir.denim.toolbox;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import edu.berkeley.guir.denim.*;

/**
 * The toolbox at the bottom of the DENIM window. It contains an area to store
 * the designer's tools and a button that (will someday) clean up the tools in
 * the tools area.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-05-1999 James Lin
 *                               Created Toolbox
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 08-05-1999
 */
public class Toolbox
   extends JPanel {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -6243633000159521683L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private JButton   btnCleanUp;
   private ToolsArea toolsArea;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates the toolbox.
    */
   public Toolbox(boolean simplified) {
      super();
      //this.applet = applet;

      this.setLayout(new BorderLayout());

      // set up tools area
      toolsArea = new ToolsArea();
      toolsArea.setPreferredSize(new Dimension(300,50));
      this.add(toolsArea, BorderLayout.CENTER);

	  if(simplified==false)
	  {
	      // add clean up button to toolbox
	      ImageIcon broomIcon = new ImageIcon
	         (Denim.class.getResource("images/stamps/broom.gif"));
	      this.btnCleanUp = new JButton(broomIcon);
	
	      btnCleanUp.setMargin(new Insets(0, 0, 0, 0));
	      btnCleanUp.setOpaque(true);
	      btnCleanUp.setVisible(true);
	      btnCleanUp.addMouseListener(new CleanUpMouseAdapter());
	      btnCleanUp.setToolTipText("Realigns tools in toolbox");
	
	      this.add(btnCleanUp, BorderLayout.EAST);
	  }
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   XXXXX METHODS   =====================================================

   /**
    * Accesses the "clean up" button.
    */
   public JButton getBtnCleanUp() {
      return btnCleanUp;
   }

   //-----------------------------------------------------------------

   /**
    * Accesses the area where the tools can be stored.
    */
   public ToolsArea getToolsArea() {
      return toolsArea;
   }

   //-----------------------------------------------------------------

   /**
    * Clean up the toolbox.
    */
   class CleanUpMouseAdapter extends MouseAdapter {
       public void mouseClicked(MouseEvent e) {
           ToolsArea toolsArea = getToolsArea();
           Component[] tools = toolsArea.getComponents();
           int componentCount = toolsArea.getComponentCount();
           Collections.sort(Arrays.asList(tools), new ToolLocationComparator());
           for (int i = 0, x = 20; i < componentCount; i++, x += 50) {
               tools[i].setLocation(x,15);
           }

       }
   }

   public class ToolLocationComparator implements Comparator {
      public boolean equals(Object obj1, Object obj2) {
         return (((Component)obj1).getX() == ((Component)obj2).getX());
      }
      
      public int compare(Object obj1, Object obj2) {
         if (((Component)obj1).getX() < ((Component)obj2).getX()) {
            return -1;
         }
         else if (((Component)obj1).getX() > ((Component)obj2).getX()) {
            return 1;
         }
         else {
            return 0;
         }
      }
   }


   //===   XXXXX METHODS   =====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
