package edu.berkeley.guir.lib.gesture;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Wrap a StarPlot in its own frame and add controls for it
 * (e.g., menubar).
 */
public class StarPlotFrame extends JFrame
{
  StarPlot plot;
  FeaturePicker featurePicker = null;
  
  public StarPlotFrame(FeatureVector fv, String name)
  {
    super(name);
    buildUI(fv);
  }

  void buildUI(FeatureVector fv)
  {
    Container contents = getContentPane();
    contents.setLayout(new BorderLayout());
    plot = new StarPlot(fv);
    /*
    JScrollPane scrollPane = new JScrollPane(plot);
    contents.add(scrollPane, BorderLayout.CENTER);
    */
    contents.add(plot, BorderLayout.CENTER);

    JMenu menu;
    JMenuItem item;
    ActionListener listener;
    JMenuBar menuBar = new JMenuBar();
    
    menu = new JMenu("Plot");
    item = new JMenuItem("Filter features");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	if (featurePicker == null) {
	  featurePicker = new FeaturePicker("Star plot features");
	  featurePicker.pack();
	  plot.setFeaturePicker(featurePicker);
	}
	featurePicker.show();
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    item = new JMenuItem("Close");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	StarPlotFrame.this.dispose();
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    // add more Plot items here
    menuBar.add(menu);

    menu = new JMenu("View");

    item = new JMenuItem("Toggle log scale");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	plot.setLogScale(!plot.getLogScale());
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    item = new JMenuItem("Zoom in");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	plot.setScale(plot.getScale() * 2);
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    item = new JMenuItem("Zoom out");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	plot.setScale(plot.getScale() / 2);
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    // add more Plot items here
    menuBar.add(menu);
    
    getRootPane().setJMenuBar(menuBar);
  }
}
