//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import edu.berkeley.guir.lib.satin.*;

/**
 * A wrapper for JComponent objects that does output only (ie the JComponent is
 * displayed, but you can't really interact with it). Back by popular demand.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jun 20 1999, JH
 *               Created class
 *             - SATIN-v2.3-1.0.0, Apr 02 2002, JH
 *               Readded to split between wrappers that do output only and
 *               wrappers that do both input and output (see
 *               GObJComponentWrapper for the one that does both).
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class GObJComponentWrapperOutput
   extends GraphicalObjectImpl implements SatinConstants {

   //===========================================================================
   //===   CLASS METHODS AND VARIABLES   =======================================

   static final long serialVersionUID = -308123049230984017L;
 
   //===   CLASS METHODS AND VARIABLES   =======================================
   //===========================================================================
 



   //===========================================================================
   //===   CONSISTENCY LISTENER INNER CLASS   ==================================

   class ConsistencyListener
      extends ComponentAdapter {

      public void componentMoved(ComponentEvent evt) {
         Rectangle rect = component.getBounds();
         setBoundingPoints2D(COORD_REL, rect);
      } // of componentMoved

      public void componentResized(ComponentEvent evt) {
         Rectangle rect = component.getBounds();
         setBoundingPoints2D(COORD_REL, rect);
      } // of componentMoved

   } // of inner class
   
   //===   CONSISTENCY LISTENER INNER CLASS   ==================================
   //===========================================================================




   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   JComponent        component;
   ComponentListener lstnr;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public GObJComponentWrapperOutput(JComponent newComponent) {
      setComponent(newComponent);
      /*
      if (component != null) {
         addKeyListener(new InternalKeyListener());
      }
      */
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   COMPONENT ACCESSOR METHODS   ========================================

   /**
    * Returns the JComponent in this wrapper
    */
   public JComponent getComponent() {
      return (component);
   } // of method


   //-----------------------------------------------------------------
   
   /**
    * Set the JComponent inside this wrapper
    */
   public void setComponent(JComponent comp) {
      if (comp == null) {
         return;
      }
      //// 1. Clear out old component dependencies.
      if (component != null) {
         component.removeComponentListener(lstnr);
      }

      //// 2. Set the component.
      component = comp;

      //// 2.5 Get the real width if we are text.
      Dimension dim        = comp.getSize();
      int       compWidth  = dim.width;
      int       compHeight = dim.height;

      if (comp instanceof JTextArea) {
         String title    = ((JTextArea) comp).getText();
         JLabel label    = new JLabel(title);
         label.setFont(comp.getFont());
         compWidth = (int)(label.getPreferredSize().width * 1.1);
         compHeight = (int)(label.getPreferredSize().height * 1.1);
      }

      
      //// 3. Set the size.
      component.setBounds(0, 0, compWidth, compHeight);
      setBoundingPoints2D(COORD_REL, component.getBounds());
      lstnr = new ConsistencyListener();
      component.addComponentListener(lstnr);
   } // of method

   //===   COMPONENT ACCESSOR METHODS   ========================================
   //===========================================================================




   //===========================================================================
   //===   GRAPHICALOBJECT METHODS   ===========================================
   
   public void initAfterAddToSheet() {
      super.initAfterAddToSheet();
      getSheet().addToSwingWrapper(this);
   } // of method
   
   //-----------------------------------------------------------------
   
   public void delete() {
      super.delete();
      getSheet().deleteFromSwingWrapper(this);
   } // of method
   
   //===   GRAPHICALOBJECT METHODS   ===========================================
   //===========================================================================

   
   //===========================================================================
   //===   DISPATCHING METHODS   ===============================================

   private void handleMouseEvent(MouseEvent oldEvt) {
      MouseEvent mouseEvt = new MouseEvent(component, oldEvt.getID(), 
         oldEvt.getWhen(), oldEvt.getModifiers(), oldEvt.getX(), oldEvt.getY(), 
         oldEvt.getClickCount(), oldEvt.isPopupTrigger());
      FocusEvent focusEvt = new FocusEvent(component, FocusEvent.FOCUS_GAINED);


      cmdsubsys.postEvent(mouseEvt);
      cmdsubsys.postEvent(focusEvt);
      damage(DAMAGE_LATER);
   } // of method

   //-----------------------------------------------------------------

   public void handleNewStroke(NewStrokeEvent evt) {
      handleMouseEvent((MouseEvent) evt.getMouseEvent());
   } // of method

   //-----------------------------------------------------------------

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      handleMouseEvent((MouseEvent) evt.getMouseEvent());
   } // of method

   //-----------------------------------------------------------------

   public void handleSingleStroke(SingleStrokeEvent evt) {
      handleMouseEvent((MouseEvent) evt.getMouseEvent());
      evt.setConsumed();
   } // of method

   //===   DISPATCHING METHODS   ===============================================
   //===========================================================================




   //===========================================================================
   //===   KEY LISTENER METHODS   ==============================================
   
   public void keyEventDispatcher(KeyEvent evt) {
      component.dispatchEvent(evt);
      //this.damage(SatinConstants.DAMAGE_NOW);
   } // of method
   
   //===   KEY LISTENER METHODS   ==============================================
   //===========================================================================




   //===========================================================================
   //===   RENDERING   =========================================================

   protected void defaultRender(SatinGraphics g) {
      //// 1. Paint the component.
      component.paint(g);
   } // of method

   //===   RENDERING   =========================================================
   //===========================================================================




   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toDebugString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 1. Append data.
      strbuf.append(super.toDebugString() + "\n");
      strbuf.append("Component:      " + component.toString());

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================




   //===========================================================================
   //===   CLONE   =============================================================
   
   public Object clone() {
      return deepClone(new GObJComponentWrapperOutput(null));
   } // of method
   
   //-----------------------------------------------------------------
   
   protected Object deepClone(GObJComponentWrapperOutput cloneTarget) {
      //1. Clone all of the state in the current GraphicalObject into the passed 
      //GraphicalObject
      super.deepClone(cloneTarget);
      
      //2.clone the Jcomponent.  This is a serialization hack.
      try {
         ByteArrayOutputStream out = new ByteArrayOutputStream();
         ObjectOutput os = new ObjectOutputStream(out);
         os.writeObject(component);
         os.flush();
         out.close();
         
         ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
         ObjectInputStream is = new ObjectInputStream(in);
         cloneTarget.component = (JComponent)is.readObject();
         in.close();
         
         /*
         FileOutputStream out = new FileOutputStream("tmp");
         ObjectOutput os = new ObjectOutputStream(out);
         os.writeObject(component);
         os.flush();
         out.close();
         
         FileInputStream in = new FileInputStream("tmp");
         ObjectInputStream is = new ObjectInputStream(in);
         cloneTarget.component = (JComponent)is.readObject();
         in.close();
         */
      }catch (Exception exp) {
         System.out.println("Serialization hack for GObJComponentWrapperOutput::deepClone failed -- "+exp.toString());
      }
      return (cloneTarget);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================



   
   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static void main(String[] argv) {
   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
