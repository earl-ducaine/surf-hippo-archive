package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class AnalysisLinkView extends AbstLinkView {
    private static final int MAX_SECONDS = 7;
    
    private SHitCounter    m_hitCounter   = new SHitCounter(LINK_DRAG_COLOR);
    private ActionListener m_menuListener;

    public AnalysisLinkView(SuedeModel model, LinkModel lm, SContentPane pane) {
        super (model, lm, pane);
        m_hitCounter.setBounds(getWidth() - 2*BUTTON_WIDTH, 0, BUTTON_WIDTH, ARC);
        add(m_hitCounter);
        
        m_playMenu.setBounds(getWidth() - BUTTON_WIDTH, 0, BUTTON_WIDTH, ARC);
        add(m_playMenu);

        m_buttonColor = Color.lightGray;
    }


    public void setPlayable(boolean b) {}
    
    
    public BasicStroke createArrowParams() {
        Vector hits = m_linkmodel.getHits();
        m_arrowhead.setArrowSize(20 + hits.size());
        m_hitCounter.setHits(hits.size());
        return new BasicStroke(hits.size()+1);
    }
	

	public void paintComponent(Graphics g) {
	   super.paintComponent(g);
	   Graphics2D g2d = (Graphics2D)g;
	   g2d.setStroke(new BasicStroke(3));
	   int startX = getWidth() - 2*BUTTON_WIDTH + 3;
	   int yVal = getHeight() - 10;
	   double fraction = m_linkmodel.getAverageResponseLength();

      if (fraction == CardSound.NO_AUDIO) { //draw a long dark gray line b/c there ain't no audio
	      int length = (2*BUTTON_WIDTH - 14);
	      g2d.setColor(Color.darkGray);
	      g2d.drawLine(startX, yVal, startX + length, yVal);
      } else { //draw a line in proportion to the average audio length
	      fraction /= MAX_SECONDS;
	      if (fraction > 1) fraction = 1;
	      int length = (int)(fraction*(2*BUTTON_WIDTH - 14) +0.5);
	      g2d.setColor((length > 0.66*MAX_SECONDS) ? Color.red : (length>0.33*MAX_SECONDS) ? Color.yellow : Color.green);
	      //if (fraction!=0) System.out.println("        average      length is: "+length);
	      g2d.drawLine(startX, yVal, startX + length, yVal);
	   }
	}


    public boolean isPlaying() {
      //System.out.println("Analysis.isPlaying: implement me");
      return false;
    }
    
    
    public boolean isRecording() {
      //System.out.println("Analysis.isRecording: implement me");
      return false;
    }
    
    
    public void setStopped() {
      //System.out.println("Analysis.setStopped: implement me");
    }
    
    
    public void setRecording() {
      //System.out.println("Analysis.setRecording: implement me");
    }
    
    
    public void setPlaying() {
      //System.out.println("Analysis.setPlaying: implement me");
    }
    
    
    public void setPaused() {
      //System.out.println("Analysis.setPaused: implement me");
    }
}