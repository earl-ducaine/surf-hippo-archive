package edu.berkeley.guir.lib.satin.objects;

import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;

/**
 * Make a graphical object's style sticky. Currently, 
 * only the following are sticky:
 * <UL>
 *    <LI>Line width
 * </UL>
 * Still experimental.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v2.1-1.0.0, Dec 02 2000, JH
 *               Created
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class StickyStyleGraphicalObjectWrapper
   extends GraphicalObjectWrapper {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   Style stickyStyle = new Style();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTOR   =======================================================

   /**
    * Create an empty wrapper.
    */
   public StickyStyleGraphicalObjectWrapper() {
      super();
   } // of method

   /**
    * 
    */
   public StickyStyleGraphicalObjectWrapper(GraphicalObject gob) {
      super(gob);
   } // of method

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================



   //===========================================================================
   //===   STYLE METHODS   =====================================================

   /**
    * Called just before a style is retrieved, so that the values can be
    * updated on demand.
    */
   protected void updateStyle() {
      //// 1. Calculate zoom factor.
      AffineTransform tx       = super.getTransform(COORD_ABS);
      double          curScale = AffineTransformLib.getScaleFactor(tx);

      //// 2. Calculate new values and set the style.
      Style s = super.getStyleRef();
      s.setLineWidth((float) (stickyStyle.getLineWidth() / curScale));
   } // of method

   //-----------------------------------------------------------------

   public Style getStickyStyleRef() {
      return (stickyStyle);
   } // of method

   /**
    * Overrided to set the sticky style.
    */
   public Style setStyle(Style newStyle) {
      stickyStyle = newStyle;
      return (newStyle);
   } // of method

   /**
    * Gets a copy of the current style, soft state depending on zoom.
    */
   public Style getStyle() {
      updateStyle();
      return (super.getStyle());
   } // of method

   /**
    * Gets the current style, soft state depending on zoom.
    */
   public Style getStyleRef() {
      updateStyle();
      return (super.getStyleRef());
   } // of method

   //===   STYLE METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Done on proxy, not on proxied object.
    */
   public Object clone() {
      GraphicalObjectWrapper gobw = new GraphicalObjectWrapper();
      clone(gobw);
      return (gobw);
   } // of method


   /**
    * Clone our current state into the passed-in object.
    * Used for clone chaining.
    */
   protected GraphicalObjectWrapper clone(GraphicalObjectWrapper gobw) {
      gobw.parent = this.parent;
      gobw.gob    = this.gob;
      return (gobw);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Done on proxy, not on proxied object.
    */
   public Object deepClone() {
      GraphicalObjectWrapper gobw = new GraphicalObjectWrapper();
      deepClone(gobw);
      return (gobw);
   } // of method


   /**
    * Deep clone our current state into the passed-in object.
    * Used for clone chaining.
    */
   protected GraphicalObjectWrapper deepClone(GraphicalObjectWrapper gobw) {
      gobw.parent = this.parent;
      gobw.gob    = (GraphicalObject) this.gob.deepClone();
      return (gobw);
   } // of method

   //===   CLONE METHODS   =====================================================
   //===========================================================================

} // of interface 

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES { LOSS OF USE, DATA, OR PROFITS { OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
