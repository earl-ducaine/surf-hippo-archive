//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import edu.berkeley.guir.lib.satin.objects.*;
import java.awt.geom.*;

/**
 * Moves a graphical object from one location to another.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 12 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.1.0, Apr 10 2001, JL
 *               Added parameter for coordinate system
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.1.0, Apr 10 2001
 */
public class SetLocationCommand
   extends CommandImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 7508109613025966686L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private GraphicalObject      gob;    // the Graphical Object to move
   private int                  cdsys;  // the coordinate system to use
   private float                newX;   
   private float                newY;
   private AffineTransform      oldTransform;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create the move command object.
    *
    * @param gob    the Graphical Object to move
    * @param x      the x-coordinate to set to, in relative coordinates
    * @param y      the y-coordinate to set to, in relative coordinates
    */
   public SetLocationCommand(GraphicalObject gob, double x, double y) {
      this(gob, COORD_REL, x, y);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create the move command object.
    *
    * @param gob    the Graphical Object to move
    * @param cdsys  the coordinate system to use
    * @param x      the x-coordinate to set to
    * @param y      the y-coordinate to set to
    * 
    * @see   SatinConstants#COORD_LOCAL
    * @see   SatinConstants#COORD_REL
    * @see   SatinConstants#COORD_ABS
    */
   public SetLocationCommand(GraphicalObject gob, int cdsys,
                             double x, double y) {
      this.gob  = gob;
      this.cdsys = cdsys;
      this.newX = (float) x;
      this.newY = (float) y;
   } // of constructor
   
   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      return ("set location of graphical object");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   STATUS ACCESSOR METHODS   ===========================================

   public boolean canRedo() {
      return (true);
   } // of canRedo

   //-----------------------------------------------------------------

   public boolean canUndo() {
      return (true);
   } // of canUndo

   //-----------------------------------------------------------------

   public boolean isSignificant() {
      return (true);
   } // of isSignificant

   //===   STATUS ACCESSOR METHODS   ===========================================
   //===========================================================================



   //===========================================================================
   //===   ACTION METHODS   ====================================================

   public void run() {
      oldTransform = gob.getTransform(COORD_REL);
      gob.moveTo(cdsys, newX, newY);
   } // of run

   //-----------------------------------------------------------------

   public void redo() {
      run();
   } // of redo

   //-----------------------------------------------------------------

   public void undo() {
      gob.setTransform(oldTransform);
   } // of undo

   //-----------------------------------------------------------------

   public void die() {
   } // of die

   //===   ACTION METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
