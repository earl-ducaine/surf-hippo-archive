package edu.berkeley.guir.damask.view.appevent;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.view.DamaskDocument;

/** 
 * A source of document events.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-21-2003 James Lin
 *                               Created DocumentEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 09-21-2003
 */
public class DocumentEventSource {
   
   private Vector/*<DocumentListener>*/ eventListeners = new Vector();


   /**
    * Adds the specified listener to receive document events.
    */
   public synchronized void addDocumentListener(DocumentListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }


   /**
    * Removes the specified listener so that it no longer receives
    * document events.
    */
   public synchronized void removeDocumentListener(DocumentListener listener) {
      eventListeners.remove(listener);
   }

   
   /**
    * Fires documentModified events to listeners.
    */
   public void fireDocumentModified(final DamaskDocument doc) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final DocumentEvent event =
         new DocumentEvent(doc, DocumentEvent.DOCUMENT_MODIFIED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final DocumentListener listener = (DocumentListener)i.next();
         listener.documentModified(event);
      }
   }

   
   /**
    * Fires documentCleaned events to listeners.
    */
   public void fireDocumentCleaned(final DamaskDocument doc) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final DocumentEvent event =
         new DocumentEvent(doc, DocumentEvent.DOCUMENT_CLEANED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final DocumentListener listener = (DocumentListener)i.next();
         listener.documentCleaned(event);
      }
   }

   
   /**
    * Fires documentRenamed events to listeners.
    */
   public void fireDocumentRenamed(final DamaskDocument doc) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final DocumentEvent event =
         new DocumentEvent(doc, DocumentEvent.DOCUMENT_RENAMED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final DocumentListener listener = (DocumentListener)i.next();
         listener.documentRenamed(event);
      }
   }

   
   /**
    * Fires documentClosed events to listeners.
    */
   public void fireDocumentClosed(final DamaskDocument doc) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final DocumentEvent event =
         new DocumentEvent(doc, DocumentEvent.DOCUMENT_CLOSED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final DocumentListener listener = (DocumentListener)i.next();
         listener.documentClosed(event);
      }
   }

   
   /**
    * Fires documentBusyStarted events to listeners.
    */
   public void fireDocumentBusyStarted(final DamaskDocument doc) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final DocumentEvent event =
         new DocumentEvent(doc, DocumentEvent.DOCUMENT_BUSY_STARTED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final DocumentListener listener = (DocumentListener)i.next();
         listener.documentBusyStarted(event);
      }
   }

   
   /**
    * Fires documentBusyStopped events to listeners.
    */
   public void fireDocumentBusyStopped(final DamaskDocument doc) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final DocumentEvent event =
         new DocumentEvent(doc, DocumentEvent.DOCUMENT_BUSY_STOPPED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final DocumentListener listener = (DocumentListener)i.next();
         listener.documentBusyStopped(event);
      }
   }

   
   /**
    * Fires documentBusyStopped events to listeners.
    */
   public void fireCanvasGroupAdded(final DamaskDocument doc) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final DocumentEvent event =
         new DocumentEvent(doc, DocumentEvent.CANVAS_GROUP_ADDED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final DocumentListener listener = (DocumentListener)i.next();
         listener.canvasGroupAdded(event);
      }
   }

   
   /**
    * Fires documentBusyStopped events to listeners.
    */
   public void fireCanvasGroupRemoved(final DamaskDocument doc) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final DocumentEvent event =
         new DocumentEvent(doc, DocumentEvent.CANVAS_GROUP_REMOVED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final DocumentListener listener = (DocumentListener)i.next();
         listener.canvasGroupRemoved(event);
      }
   }
}
