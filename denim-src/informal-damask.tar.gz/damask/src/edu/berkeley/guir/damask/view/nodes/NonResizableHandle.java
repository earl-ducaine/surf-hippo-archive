package edu.berkeley.guir.damask.view.nodes;

import java.awt.Color;

import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * A non-resizable handle on a node, to denote that the node is selected.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-12-2003 James Lin
 *                               Created NonResizableHandle.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 11-12-2003
 */
public class NonResizableHandle extends BoundsHandle {

   /**
    * Creates a non-resizable handle with the specified locator, representing
    * which side or corner of the node to attach the handle.
    */
   public NonResizableHandle(PBoundsLocator aLocator) {
      super(aLocator);
      setPaint(Color.LIGHT_GRAY);
      setStrokePaint(Color.GRAY);
   }


   /**
    * Adds handles to the given node.
    */
   public static void addHandlesTo(PNode aNode) {
      addHandlesTo(aNode, null, false, false);
   }

   /**
    * Adds handles to the given node, which will stick to the given camera.
    */
   public static void addStickyHandlesTo(PNode aNode, PCamera camera) {
      addHandlesTo(aNode, camera, true, false);
   }

   /**
    * Adds handles to the given node, which will stick to the given
    * camera in the x and y axes, while staying constant along the z axis.
    */
   public static void addStickyZHandlesTo(PNode aNode, PCamera camera) {
      addHandlesTo(aNode, camera, false, true);
   }

   /**
    * Adds handles to the given node.
    * 
    * @param aNode the node to add handles to
    * @param camera the camera that the handles will stick to, or null
    *                if the handles should not be sticky
    * @param useSticky true if the handles will stick to the given camera
    * @param useStickyZ true if the handles will stick to the given
    *                    camera in the x and y axes, while staying
    *                    constant along the z axis.
    */
   public static void addHandlesTo(
      final PNode aNode,
      final PCamera camera,
      final boolean useSticky,
      final boolean useStickyZ) {

      addHandlesTo(
         aNode,
         camera,
         useSticky,
         useStickyZ,
         NonResizableHandle.class);
   }


   /**
    * Removes handles from the specified node.
    */
   public static void removeHandlesFrom(PNode aNode) {
      removeHandlesFrom(aNode, NonResizableHandle.class);
   }


   /**
    * Removes any sticky handles from the specified node that are
    * attached to the specified camera. 
    */
   public static void removeStickyHandlesFrom(PNode aNode, PCamera camera) {
      removeStickyHandlesFrom(aNode, camera, NonResizableHandle.class);
   }

   /**
    * Ignore all mouse events.
    */
   protected void installHandleEventHandlers() {
   }
}
