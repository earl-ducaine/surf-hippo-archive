package edu.berkeley.guir.damask.view.visual.dialog;

import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.view.visual.component.ControlView;

/** 
 * A container and viewer of page views.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  12-31-2003 James Lin
 *                               Created PageViewContainer.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 12-31-2003
 */
public interface PageViewContainer {
   
   /**
    * Sets the state that the specified control is in, for the current
    * page in its current condition.
    */
   void setControlState(Control control, Object state);
   
   /**
    * Returns the condition of the current page.
    */
   int getSelectedPageCondition();
   
   /**
    * Goes to the specified page. Makes the specified page the current page.
    */
   void goToPage(Page page);
   
   /**
    * Returns the control view that has the focus in this window.
    */
   ControlView getFocus();

   /**
    * Sets the focus to the specified control view.
    */
   void setFocus(final ControlView controlView);
}
