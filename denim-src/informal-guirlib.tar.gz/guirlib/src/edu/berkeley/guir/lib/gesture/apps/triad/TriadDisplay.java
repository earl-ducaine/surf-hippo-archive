package edu.berkeley.guir.lib.gesture.apps.triad;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.Misc;

/**
  * Emits an ItemEvent when a gesture is picked.  The item passed is an
  * Integer indicating which gesture was picked.
  */
public class TriadDisplay extends JPanel implements ItemSelectable
{
  protected EventListenerList itemListenerList = new EventListenerList();

  public TriadDisplay()
  {
    super(true);
    buildUI();
  }

  protected void buildUI()
  {
    setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
    Border border = BorderFactory.createLoweredBevelBorder();
    for (int i = 0; i < 3; i++) {
      GestureDisplay gestureDisplay = new GestureDisplay();
      JPanel dummy = new JPanel(new BorderLayout());
      dummy.add(gestureDisplay, BorderLayout.CENTER);
      add(dummy);
      gestureDisplay.addMouseListener(new myListener(i));
      gestureDisplay.setBorder(border);
      gestureDisplay.setOffset(5, 5);
    }
  }

  protected GestureDisplay getGestureDisplay(int i)
  {
    return (GestureDisplay) ((Container) getComponent(i)).getComponent(0);
  }
  
  public void setGestures(Gesture g1, Gesture g2, Gesture g3)
  {
    Gesture[] g = {g1, g2, g3};
    setGestures(g);
  }
  
  public void setGestures(Gesture[] gestures)
  {
    setGestures(gestures, false);
  }

  public void setGestures(Gesture[] g, boolean randomize)
  {
    NumberedGesture[] gestures = new NumberedGesture[g.length];
    for (int i = 0; i < 3; i++) {
      gestures[i] = new NumberedGesture(g[i], i);
    }
    
    if (randomize) {
      Misc.shuffle(gestures);
    }

    for (int i = 0; i < 3; i++) {
      GestureDisplay gestureDisplay = getGestureDisplay(i);
      gestureDisplay.setGesture(gestures[i]);
      gestureDisplay.getGesturePointsDisplay().setAnimated(true);
    }
    invalidate();
    Window w = (Window) getTopLevelAncestor();
    if (w != null) {
      w.pack();
    }
  }

  public Gesture[] getGestures()
  {
    Component[] components = getComponents();
    Gesture[] result = new Gesture[3];
    for (int i = 0; i < 3; i++) {
      GestureDisplay gestureDisplay = getGestureDisplay(i);
      result[i] = gestureDisplay.getGesture();
    }
    return result;
  }
  
  public void addItemListener(ItemListener l)
  {
    itemListenerList.add(ItemListener.class, l);
  }

  public void removeItemListener(ItemListener l)
  {
    itemListenerList.remove(ItemListener.class, l);
  }

  public Object[] getSelectedObjects()
  {
    return null;
  }

  protected void fireItemChange(int gestureNum)
  {
    ItemEvent event = null;
    Object[] listeners = itemListenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ItemListener.class) {
	if (event == null)
	  event = new ItemEvent(this, ItemEvent.ITEM_STATE_CHANGED,
				new Integer(gestureNum),
				ItemEvent.SELECTED);
	((ItemListener)listeners[i+1]).itemStateChanged(event);
      }
    }
  }
  
  class myListener extends MouseAdapter {
    int componentNum;
    
    public myListener(int n)
    {
      componentNum = n;
    }

    void invert()
    {
      Component component = getGestureDisplay(componentNum);
      Color fg = component.getForeground();
      Color bg = component.getBackground();
      component.setForeground(bg);
      component.setBackground(fg);
    }
    
    public void mousePressed(MouseEvent e)
    {
      invert();
    }

    public void mouseReleased(MouseEvent e)
    {
      invert();
      GestureDisplay gd = getGestureDisplay(componentNum);
      NumberedGesture gesture = (NumberedGesture) gd.getGesture();
      TriadDisplay.this.fireItemChange(gesture.n);
    }
  }

  class NumberedGesture extends Gesture {
    final int n;

    NumberedGesture(Gesture g, int n)
    {
      super(g);
      this.n = n;
    }
  }
}
