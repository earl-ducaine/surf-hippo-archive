package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import javax.swing.*;

/** Used to create the appropriate display for different gesture types */
public class DisplayFactory {
  private DisplayFactory()
  {
  }

  public static JComponent create(GestureObject gestureObject)
  {
    return create(gestureObject, null);
  }
  
  /** Create an appropriate display widget.  Return null if
      gestureObject is of unknown type.  Result is also guaranteed to
      be a GestureObjectDisplay. */
  public static JComponent create(GestureObject gestureObject,
				  JScrollPane scrollPane)
  {
    JComponent result;

    if (gestureObject instanceof Gesture) {
      result = new GestureObjectPanel(gestureObject);
    }
    else if (gestureObject instanceof GestureSet) {
      result = new GestureSetPanel((GestureSet) gestureObject,
				   scrollPane);
    }
    else if (gestureObject instanceof GestureGroup) {
      result = new GestureGroupPanel((GestureGroup) gestureObject,
					scrollPane);
    }
    else if (gestureObject instanceof GestureCategory) {
      result = new GestureCategoryPanel((GestureCategory) gestureObject,
					scrollPane);
    }
    else {
      result = new GestureContainerPanel((GestureContainer) gestureObject,
					 scrollPane);
    }
    initDisplay((GestureObjectDisplay) result);
    return result;
  }

  public static JComponent createThumbnail(GestureObject gestureObject,
					   JScrollPane scrollPane)
  {
    JComponent result;

    if (gestureObject instanceof Gesture) {
      result = new SimpleGestureObjectPanel(gestureObject);
    }
    else if (gestureObject instanceof GestureCategory) {
      result = new GestureCategoryThumbnailPanel((GestureCategory)
						 gestureObject, scrollPane);
    }
    else if (gestureObject instanceof GestureGroup) {
      result = new GestureGroupThumbnailPanel((GestureGroup)
					      gestureObject, scrollPane);
    }
    else {
      result = new GestureContainerPanel((GestureContainer) gestureObject,
					 scrollPane);
    }
    initThumbnailDisplay((GestureObjectDisplay) result);
    return result;
  }

  protected static void initDisplay(GestureObjectDisplay display)
  {
    GestureObject gestureObj = display.getDisplayedObject();
    ((JComponent) display).
      setBackground(gestureObj.isEnabled() ?
		    GestureObjectDisplay.ENABLED_BACKGROUND :
		    GestureObjectDisplay.DISABLED_BACKGROUND);
  }

  protected static void initThumbnailDisplay(GestureObjectDisplay display)
  {
    initDisplay(display);
    JComponent jc = (JComponent) display;
    if (jc.getBorder() == null) {
      jc.setBorder(BorderFactory.createEtchedBorder());
    }
  }
}
