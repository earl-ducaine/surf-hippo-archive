package edu.berkeley.guir.denim.interpreters;

import java.awt.geom.Point2D;
import java.util.ArrayList;

import edu.berkeley.guir.denim.DenimGroup;
import edu.berkeley.guir.denim.DenimSheet;
import edu.berkeley.guir.denim.command.UngroupCommand;
import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.event.NewStrokeEvent;
import edu.berkeley.guir.lib.satin.event.SingleStrokeEvent;
import edu.berkeley.guir.lib.satin.event.UpdateStrokeEvent;
import edu.berkeley.guir.lib.satin.interpreter.DefaultInterpreterImpl;
import edu.berkeley.guir.lib.satin.objects.GraphicalObject;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

/**
 * Erases objects from the attached container.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-30-1999 JL
 *                    Created class EraserInterpreter.
 * </PRE>
 *
 * @see    edu.berkeley.guir.denim.toolbox.Eraser
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version Version 1.0.0, 10-30-1999
 */
public class EraserInterpreter
   extends DefaultInterpreterImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -8017215452120447905L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   static private ArrayList instances;

   static {
      instances = new ArrayList();
   }

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs an eraser interpreter.
    */
   public EraserInterpreter() {
      super();
      commonInitializations();
   }

   //-----------------------------------------------------------------

   /**
    * Constructs an eraser interpreter as a copy of the given interpreter.
    */
   public EraserInterpreter(EraserInterpreter intrp) {
      //// 1. Since this interpreter is stateless, we can do this safely.
      this();
   }

   //-----------------------------------------------------------------

   /**
    * Performs initializations common to constructors.
    */
   private void commonInitializations() {
      setName("Denim Eraser Interpreter");

      //// Have the class keep track of this instance
      instances.add(this);
   }

   //-----------------------------------------------------------------

   protected void finalize() throws Throwable {
      //// Have the class forget about this instance
      instances.remove(instances.indexOf(this));
      super.finalize();
   }

   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   /**
    * Erases the object near the eraser's location on the given sheet.
    *
    * @param sheet the sheet on which to erase
    * @param p     the point where the eraser is, in absolute coordinates
    */
   private void eraseAt(DenimSheet sheet, Point2D p) {

      GraphicalObject gob = sheet.getObjectToSelect(p);

      // Ideally, if the object is a stroke, we want to erase only part of the
      // stroke next to the eraser. But the algorithm that cuts the stroke
      // is VERY slow, so we have disabled it for now.
      /*
      if (gob instanceof TimedStroke) {
         GraphicalObjectGroup parent = gob.getParentGroup();
         Point p1 = GraphicalObjectUtil.absoluteToLocal(
                       parent, new Point(p.x - 5, p.y - 5));
         Point p2 = GraphicalObjectUtil.absoluteToLocal(
                       parent, new Point(p.x + 5, p.y + 5));
         Rectangle rect = new Rectangle(p1);
         rect.add(p2);


         //Polygon poly = new Polygon();
         //poly.addPoint(p1.x, p1.y);
         //poly.addPoint(p2.x, p1.y);
         //poly.addPoint(p2.x, p2.y);
         //poly.addPoint(p1.x, p2.y);

         //sheet.add(new TimedStroke(poly));

         Iterator iter = StrokeUtil.cutStroke((TimedStroke)gob, rect);

         debug.println("Sheet before: ");
         debug.println(sheet);

         MacroCommand macro = new MacroCommand();
         macro.addCommand(new DeleteCommand(gob));

         while (iter.hasNext()) {
            TimedStroke stk = (TimedStroke) iter.next();

            //debug.println("eraseAt - stk: ");
            //for (int k = 0; k < stk.getBoundingPoints().npoints; k++) {
            //   debug.println("   " + stk.getBoundingPoints().xpoints[k] +
            //                      "," + stk.getBoundingPoints().ypoints[k]);
            //}
            macro.addCommand(
               new InsertCommand(parent, stk,
                                 GraphicalObjectGroup.KEEP_REL_POS));
         }
         CommandSubsystem.getCommandSubsystem().getCommandQueue().doCommand(macro);
         sheet.repaint();

         debug.println("Sheet after: ");
         debug.println(sheet);
      }
      else {*/
      if (gob != null) {
         if (gob instanceof DenimGroup) {
            SatinConstants.cmdqueue.doCommand(new UngroupCommand((DenimGroup)gob));
         }
         else {
            sheet.deleteObject(gob);
         }
         
         sheet.setModified(true);
      }
   }

   //-----------------------------------------------------------------

   /**
    * Start erasing when the user first taps the eraser tool.
    */
   public void handleNewStroke(NewStrokeEvent evt) {
      DenimSheet sheet = (DenimSheet) getAttachedGraphicalObject().getSheet();
      TimedStroke stk = evt.getStroke();
      eraseAt(sheet, stk.getEndPoint2D(COORD_ABS));
      evt.setConsumed();
   }

   //-----------------------------------------------------------------

   /**
    * Continue erasing as the user drags the eraser tool.
    */
   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      DenimSheet sheet = (DenimSheet) getAttachedGraphicalObject().getSheet();
      TimedStroke stk = evt.getStroke();
      eraseAt(sheet, stk.getEndPoint2D(COORD_ABS));
      evt.setConsumed();
   }

   //-----------------------------------------------------------------

   /**
    * Finish erasing.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      //// 1. Force a final, higher quality image rendering.
      getAttachedGraphicalObject().damage(DAMAGE_NOW);
      evt.setConsumed();
   }

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================


   /**
    * Enable or disable <i>all</i> instances of EraserInterpreter.
    */
   public void setEnabled(boolean flag) {
      int i;
      int size = instances.size();

      for (i = 0; i < size; i++) {
         ((EraserInterpreter)instances.get(i)).setEnabledLocally(flag);
      }
   }

   private void setEnabledLocally(boolean flag) {
      super.setEnabled(flag);
   }

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      return (new EraserInterpreter(this));
   } // of clone

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
