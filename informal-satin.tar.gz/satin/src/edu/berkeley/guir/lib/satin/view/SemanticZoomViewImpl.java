//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.util.StringLib;

/**
 * A sample implementation of View, which has a trapezoidally-shaped range 
 * of display values. This view is especially useful when used in conjunction
 * with {@link SemanticZoomMultiViewImpl}, which can fade-in and fade-out
 * the various views an object may have.
 *
 * <P>
 * Be sure to implement {@link ViewImpl#clone()} correctly in your 
 * implementation, as copy and paste depend on it.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 11 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public abstract class SemanticZoomViewImpl 
   extends    ViewImpl 
   implements SemanticZoomView {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -7683529812197365412L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   double          fadeIn     = 0;
   double          startScale = 0;
   double          endScale   = Double.MAX_VALUE;
   double          fadeOut    = Double.MAX_VALUE;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Does nothing.
    */
   public SemanticZoomViewImpl() {
      commonInitializations();
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Create a new semantic zoom view with the specified range.
    *
    * @see #setDisplayRange(double, double)
    */
   public SemanticZoomViewImpl(double start, double end) {
      setDisplayRange(start, end);
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a new semantic zoom view with the specified range.
    *
    * @param fIn  is the fade-in value.
    * @param s    is the start display value.
    * @param e    is the end display value.
    * @param fOut is the fade-out value.
    * @see #setDisplayRange(double, double, double, double)
    */
   public SemanticZoomViewImpl(double fIn, double s, double e, double fOut) {
      setDisplayRange(fIn, s, e, fOut);
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Semantic Zoom View");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   public void setDisplayRange(double fadeIn, double startScale, 
         double endScale, double fadeOut) {

      //// 0.1. Scale values are non-negative.
      if (fadeIn < 0 || startScale < 0 || endScale < 0 || fadeOut < 0) {
         throw new 
           IllegalArgumentException("Scale values should be strictly positive");
      }

      //// 0.2. Each of the values should be in increasing order, with
      ////      fadeIn < startScale < endScale < fadeOut.
      if (! ((fadeIn     <= startScale)   && 
             (startScale <= endScale)     && 
             (endScale   <= fadeOut))) {
         throw new IllegalArgumentException("Scale values must be increasing from left to right (ie fadeIn <= startScale <= endScale <= fadeOut)");
      }

      //// 1. Just set the values.
      this.fadeIn     = fadeIn;
      this.startScale = startScale;
      this.endScale   = endScale;
      this.fadeOut    = fadeOut;
   } // of setDisplayRange

   //-----------------------------------------------------------------

   public void setDisplayRange(double startScale, double endScale) {
      setDisplayRange(startScale, startScale, endScale, endScale);
   } // of setDisplayRange

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   public double getFadeIn() {
      return (fadeIn);
   } // of getFadeIn

   //-----------------------------------------------------------------

   public double getStartScale() {
      return (startScale);
   } // of getStartScale

   //-----------------------------------------------------------------

   public double getEndScale() {
      return (endScale);
   } // of getEndScale

   //-----------------------------------------------------------------

   public double getFadeOut() {
      return (fadeOut);
   } // of getFadeOut

   //-----------------------------------------------------------------

   private final double getAbsoluteScaleFactor() {
      //// A. Acquire soft-state.
      AffineTransform txTmp = (AffineTransform) poolTx.getObject();

      getAttachedGraphicalObject().getTransform(COORD_ABS, txTmp);
      double scale = AffineTransformLib.getScaleFactor(txTmp);

      //// B. Release soft-state.
      poolTx.releaseObject(txTmp);

      return (scale);
   } // of getAbsoluteScaleFactor

   //-----------------------------------------------------------------

   public float getViewDisplayValue() {
      double scale = getAbsoluteScaleFactor();

      //// 1.1. Don't show anything if outside of range.
      ////      Strictly less than, since fadeIn could equal startScale.
      if (scale < fadeIn || scale > fadeOut) {
         return (0);
      }

      //// 1.2. Show completely if inside the range.
      if (startScale <= scale && scale <= endScale) {
         return (1);
      }

      //// 1.3. Otherwise, linearly calculate the fade value.
      if (scale < startScale) {
         return (float) ((scale - fadeIn) / (startScale - fadeIn));
      }
      else {
         return (float) ((fadeOut - scale) / (fadeOut - endScale));
      }
   } // of getViewDisplayValue

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   protected SemanticZoomViewImpl clone(SemanticZoomViewImpl v) {
      //// 1. Clone chain.
      super.clone(v);

      //// 2. Do clone work.
      v.fadeIn     = this.fadeIn;
      v.startScale = this.startScale;
      v.endScale   = this.endScale;
      v.fadeOut    = this.fadeOut;

      //// 3. Return.
      return (v);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 1. Append data.
      strbuf.append(super.toString());
      strbuf.append("\nBounding box:        " + 
            StringLib.toString(getBoundingPoints2DRef().getBounds2D()));
      strbuf.append("\nFadeIn:              " + fadeIn);
      strbuf.append("\nStart Val:           " + startScale);
      strbuf.append("\nEnd Val:             " + endScale);
      strbuf.append("\nFadeOut:             " + fadeOut);
      strbuf.append("\nCur Absolute Scale:  ");
      if (getAttachedGraphicalObject() == null) {
         strbuf.append("not attached");
      }
      else {
         strbuf.append(getAbsoluteScaleFactor());
      }
      
      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
