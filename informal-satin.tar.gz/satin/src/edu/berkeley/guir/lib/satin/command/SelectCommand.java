//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.objects.*;

/**
 * Select a Graphical Object.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 16 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
abstract public class SelectCommand
   extends CommandImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 4803447219676546020L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   GraphicalObject      gob;    // the Graphical Object selected
   GraphicalObjectGroup gobs;   // collection of Graphical Objects
   int                  x;      // absolute coordinates
   int                  y;      // absolute coordinates
   int                  thresh;
   boolean              flagSignificant = false;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Select the specified Graphical Object.
    *
    * @param gob is the Graphical Object to insert.
    */
   public SelectCommand(GraphicalObject gob) {
      this.gob = gob;
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Select the Graphical Object near the specified points.
    *
    * @param gobs is the group to look at.
    * @param x    is the x-coordinates chosen, absolute position.
    * @param y    is the y-coordinates chosen, absolute position.
    */
   public SelectCommand(GraphicalObjectGroup gobs, int x, int y) {
      this(gobs, x, y, DEFAULT_SELECT_THRESHOLD);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Select the Graphical Object near the specified points.
    *
    * @param gobs      is the group to look at.
    * @param x         is the x-coordinates chosen, absolute position.
    * @param y         is the y-coordinates chosen, absolute position.
    * @param threshold is the range to look for objects.
    */
   public 
   SelectCommand(GraphicalObjectGroup gobs, int x, int y, int threshold) {
      this.gobs   = gobs;
      this.x      = x;
      this.y      = y;
      this.thresh = threshold;
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      return ("select graphical object at (" + x + "," + y + ")");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   STATUS ACCESSOR METHODS   ===========================================

   public boolean canRedo() {
      return (false);
   } // of canRedo

   //-----------------------------------------------------------------

   public boolean canUndo() {
      return (true);
   } // of canUndo

   //-----------------------------------------------------------------

   public boolean isSignificant() {
      return (flagSignificant);
   } // of isSignificant

   //===   STATUS ACCESSOR METHODS   ===========================================
   //===========================================================================



   //===========================================================================
   //===   ACTION METHODS   ====================================================

   abstract protected GraphicalObject getGraphicalObject();

   //-----------------------------------------------------------------

   public void run() {
      //// 1. Find the closest Graphical Object if we don't have one.
      if (gob == null) {
         gob = getGraphicalObject();
      }

      //// 2. Add the Graphical Object to the selected list.
      if (gob != null) {
         cmdsubsys.addSelected(gob);
         flagSignificant = true;
      }

      if (gob == null) {
         Debug.println("nothing nearby to select");
      }
      else {
         Debug.println("selected " + gob);
      }

   } // of do

   //-----------------------------------------------------------------

   public void redo() {
      //// ignore
   } // of redo

   //-----------------------------------------------------------------

   public void undo() {
      if (gob != null) {
         cmdsubsys.removeSelected(gob);
      }
   } // of undo

   //-----------------------------------------------------------------

   public void die() {
   } // of die

   //===   ACTION METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
