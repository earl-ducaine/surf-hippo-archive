package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.*;
import javax.swing.event.*;
import java.util.*;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

public class GestureObjectPanel extends SimpleGestureObjectPanel {
  static protected Icon INFO_ICON = new
    ImageIcon(GestureTree.class.getResource("images/graphics-repository/toolbarButtonGraphics/general/Information24.gif"));
  protected PropertyChangeListener propChangeListener =
    new MyPropChangeListener();
  protected EventListenerList listenerList = new EventListenerList();
  protected InfoActionListener infoActionListener;
  protected JButton misrecogButton = null;
  protected GesturePointsDisplay pointsDisplay;
  protected Classifier.Result misrecogResult = null;
  protected JPanel misrecogPanel;
  protected JPanel outlierPanel;
  
  public GestureObjectPanel()
  {
    this(null);
  }

  public GestureObjectPanel(GestureObject object)
  {
    super(object);
    misrecogButton = new JButton();
    /* use normal border, otherwise people might not know it's a button
    misrecogButton.setBorder(BorderFactory.createLineBorder(Color.black));
    */
    misrecogButton.setForeground(Color.red);
    misrecogButton.addActionListener(new MisrecogAction());
    JButton infoButton = new JButton(INFO_ICON);
    infoButton.setMargin(new Insets(1, 1, 1, 1));
    infoActionListener = new InfoActionListener();
    infoButton.addActionListener(infoActionListener);
    
    misrecogPanel = new JPanel();
    misrecogPanel.add(misrecogButton);
    misrecogPanel.add(infoButton);
    if (object.hasProperty(Classifier.MISRECOGNIZED_PROP)) {
      setMisrecogButton((Classifier.Result) object.
			getProperty(Classifier.MISRECOGNIZED_PROP));
    }
    else {
      setMisrecogButton(null);
    }

    JLabel outlierLabel = new JLabel("Outlier");
    outlierPanel = new JPanel();
    outlierPanel.add(outlierLabel);
    updateOutlierPanel();

    JPanel noticePanel = new JPanel();
    noticePanel.setLayout(new BoxLayout(noticePanel, BoxLayout.Y_AXIS));
    noticePanel.add(misrecogPanel);
    noticePanel.add(outlierPanel);
    
    add(noticePanel, BorderLayout.SOUTH);
  }

  protected void updateOutlierPanel()
  {
    Set notices = NoticeHandler.
      getNoticesOfClass(getDisplayedObject(), OutlyingGestureNotice.class);
    outlierPanel.setVisible(notices.size() > 0);
  }
  
  protected void setMisrecogButton(Classifier.Result result)
  {
    misrecogResult = result;
    if (result == null) {
      misrecogPanel.setVisible(false);
    }
    else {
      misrecogPanel.setVisible(true);
      boolean enabled;
      String label;
      if (result.category == null) {
	enabled = false;
	label = "(unrecognized)";
      }
      else {
	enabled = true;
	label = result.category.getName();
      }
      misrecogButton.setEnabled(enabled);
      misrecogButton.setText(label);
      infoActionListener.setClassification(result);
    }
  }

  protected class InfoActionListener implements ActionListener {
    protected Classifier.Result classification = null;
    
    public void actionPerformed(ActionEvent event)
    {
      MainFrame mf = (MainFrame) SwingUtilities.
	getAncestorOfClass(MainFrame.class, GestureObjectPanel.this);
      Classifier classifier = mf.getClassifier();
      Gesture g = (Gesture) getDisplayedObject();
      GestureCategory category = (GestureCategory) g.getParent();
      // need to use the name because it might be a category in a
      // training set
      double[] distByFeature = classifier.
	getNormalizedDistancesByFeature(g, category.getName());
      int maxDistIndex = Misc.maxAbsIndex(Misc.promoteArray(distByFeature));
      Class[] featureClasses = classifier.getFeatureClasses();
      Feature dummyFeature = null;
      try {
	dummyFeature = (Feature) featureClasses[maxDistIndex].newInstance();
      }
      catch (InstantiationException e) {
	System.err.println("Warning: could not instantiate feature of class '"
			   + featureClasses[maxDistIndex].getName() + "':" + e);
	return;
      }
      catch (IllegalAccessException e) {
	System.err.println("Warning: could not access class '"
			   + featureClasses[maxDistIndex].getName() + "':" + e);
	return;
      }
      mf.getNoticeHandler().
	showNotice(new FeatureNotice
		   (dummyFeature, getDisplayedObject(),
		    Misc.sign(distByFeature[maxDistIndex])));
    }

    public void setClassification(Classifier.Result r)
    {
      classification = r;
    }
  }
  
  protected class MisrecogAction implements ActionListener {
    public void actionPerformed(ActionEvent e)
    {
      GestureDesktop desktop = (GestureDesktop) SwingUtilities.
	getAncestorOfClass(GestureDesktop.class, GestureObjectPanel.this);
      desktop.showFrame(GestureObjectPanel.this.misrecogResult.category);
    }  
  }
  
  protected class MyPropChangeListener extends EnableListener {
    public MyPropChangeListener()
    {
      super(GestureObjectPanel.this);
    }

    public void propertyChange(PropertyChangeEvent e)
    {
      if (e.getPropertyName() == Classifier.MISRECOGNIZED_PROP) {
	Classifier.Result newValue = (Classifier.Result) e.getNewValue();
	setMisrecogButton(newValue);
      }
      else if (e.getPropertyName() == NoticeHandler.NOTICE_LIST_PROP) {
	updateOutlierPanel();
      }
      else {
	super.propertyChange(e);
      }
    }
  }
}
