//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tuple.comparator;

import java.util.Comparator;
import edu.berkeley.guir.lib.collection.tuple.Tuple;

/**
 * Compares two tuples according to the values specified by an XPath.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Nov 29 2002, JH
 */
public class TupleXPathComparator
    implements TupleComparator {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    private static final boolean DEBUG = false;

    //===   CONSTANTS   ========================================================
    //==========================================================================





    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    String     strXPath;                       // the path to apply
    Comparator c;                              // comparator on the value.
    boolean    flagIgnoreExceptions = false;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================





    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Set the XPath to sort by and the comparator to compare with.
     * The comparator used depends on the type of the result returned
     * by the xpath. For example, //ContextTuple/@timestamp-created
     * would return a date, so it makes sense to use a date comparator.
     * If it returns an int, then it makes sense to use an int comparator.
     * <P>
     * Sample comparators for doing dates, int, etc are provided in GUIRLib.
     * For Confab, the type of a field is provided by 
     * ContextTupleWrapper.getTypeFromXPath(String).
     * Comparators are also provided by 
     * ContextTupleWrapper.getComparatorFromAttribute(String)
     * and ContextTupleWrapper.getComparatorFromXPath(String)
     * @param newXPath should point to an attribute or value.
     */
    public TupleXPathComparator(String newXPath, Comparator newC) {
        strXPath = newXPath;
        c        = newC;
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   IGNORE EXCEPTIONS   ================================================

    /**
     * Ignore comparison exceptions while sorting, return equality (ie 0).
     * Does not ignore ClassCastException.
     */
    public void setIgnoreExceptions() {
        flagIgnoreExceptions = true;
    } // of method

    //===   IGNORE EXCEPTIONS   ================================================
    //==========================================================================




    //==========================================================================
    //===   COMPARE   ==========================================================

    public int compare(Object objAA, Object objBB) {
        try {
            Tuple tAA = (Tuple) objAA;
            Tuple tBB = (Tuple) objBB;

            //// Debugging
            // System.out.println("tAA \n" + tAA + tAA.getXPath(strXPath));
            // System.out.println("tBB \n" + tBB + tBB.getXPath(strXPath));

            return (c.compare(tAA.getXPath(strXPath), 
                              tBB.getXPath(strXPath)));
        }
        catch (ClassCastException e) {
            if (DEBUG == true) {
                e.printStackTrace();
                System.out.println(this.toString());
                System.out.println("--- objAA ---");
                System.out.println(objAA);
                System.out.println("--- objBB ---");
                System.out.println(objBB);
            }

            IllegalArgumentException ex = new IllegalArgumentException();
            ex.initCause(e);
            throw ex;
        }
        catch (Exception e) {
            if (flagIgnoreExceptions == true) {
                return (0);
            }

            if (DEBUG == true) {
                e.printStackTrace();
                System.out.println(this.toString());
                System.out.println("--- objAA ---");
                System.out.println(objAA);
                System.out.println("--- objBB ---");
                System.out.println(objBB);
            }

            IllegalArgumentException ex = new IllegalArgumentException();
            ex.initCause(e);
            throw ex;
        }
    } // of method

    //===   COMPARE   ==========================================================
    //==========================================================================






    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        StringBuffer strbuf = new StringBuffer();
        strbuf.append(this.getClass());
        strbuf.append("\n   xpath:             " + strXPath);
        strbuf.append("\n   comparator:        " + c.toString());
        strbuf.append("\n   ignore exceptions? " + flagIgnoreExceptions);
        return (strbuf.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
