package edu.berkeley.guir.lib.awt.image;

import java.awt.*;
import java.io.*;
import java.awt.image.*;
import com.sun.image.codec.jpeg.*;

/**
 * Utilities for images.
 * <P>
 * This class uses software from 
 * <A HREF="http://www.acme.com/java">ACME labs</A>.
 * <P>
 * With the exception of the Acme software, this software is distributed 
 * under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <P>
 * As far as I can tell, here's the 
 * <A HREF="http://www.acm.com/java/software">Acme License</A>:
 * <PRE>
 * Copyright (C)1996,1998 by Jef Poskanzer <jef@acme.com>. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Visit the ACME Labs Java page for up-to-date versions of this and other
 * fine Java utilities: http://www.acme.com/java/
 * </PRE>
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.3-1.0.0, Apr 27 1999, JH
 *               Created class
 *             - GUIRLib-v1.4-1.0.0, Aug 31 2000, JH
 *               Touched for GUIRLib release
 *             - GUIRLib-v1.4-1.0.1, Dec 06 2000, JH
 *               Made toGif() close the stream.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>
 *          )
 * @since   JDK 1.3
 * @version GUIRLib-v1.4-1.0.0, Aug 31 2000
 */
public class ImageLib {

   //===========================================================================
   //===   CONSTRUCTOR   =======================================================

   /**
    * No instances allowed.
    */
   private ImageLib() {
   } // of method

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================



   //===========================================================================
   //===   IMAGE METHODS   =====================================================

   /**
    * Convert an Image into a GIF file. This method uses software from 
    * <A HREF="http://www.acme.com/java">ACME labs</A>. Stream is closed
    * afterwards.
    */
   public static void toGif(Image img, OutputStream out)
      throws IOException {
      GifEncoder ge = new GifEncoder(img, out);
      ge.encode(); 
      out.close();
      /* try
       {
           GIFEncoder2 ge = new GIFEncoder2(img);
           ge.Write(out);
       }
       catch(Exception ex)
       {
           ex.printStackTrace();
       }
       out.close();*/
   }
   
   public static void toJPeg(Image img, OutputStream out) throws IOException {
/*		BufferedImage bimg = null;
		int w = img.getWidth(null);
		int h = img.getHeight(null);
		int [] pixels = new int[w * h];
		PixelGrabber pg = new PixelGrabber(img,0,0,w,h,pixels,0,w);
		try { 
		  pg.grabPixels(); 
		  } 
		catch(InterruptedException ie) { 
		  ie.printStackTrace();
		  }

		bimg = new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
		bimg.setRGB(0,0,w,h,pixels,0,w);
*/
//			Encode as a JPEG
		JPEGImageEncoder jpeg = JPEGCodec.createJPEGEncoder(out);
		jpeg.encode((BufferedImage)img);
		out.close();
   }

   //===   IMAGE METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) throws Exception {

   } // of method

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/


