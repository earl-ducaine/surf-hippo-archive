package edu.berkeley.guir.lib.gesture;

import java.util.Observable;
import java.util.Observer;
import java.io.*;
import java.awt.Point;

/*
 * A computed attribute about a Gesture (e.g., total length,
 * size of bounding box diagonal, cosine of initial angle).
 * This is a framework for all features, that does some of the
 * common work.
 *
 * This class observes a Gesture and invalidates itself when the
 * gesture changes.  Does not currently support incremental
 * computation, but probably should someday.
 */
public abstract class Feature extends Observable
implements Serializable, Observer/*, Cloneable*/ {
  protected double value;
  /**
   * true iff value has been recomputed since @gesture changed.
   */
  protected boolean valueOk = false;
  protected Gesture gesture;

  public Feature()
  {
    this(null);
  }

  public Feature(Gesture g)
  {
    super();
    setGesture(g);
  }

  public void newPoint(Point p)
  {
    newPoint(p.x, p.y);
  }
  
  /**
   * Subclasses that incrementally compute the value should override this.
   * It should compute the new value and set valueOk to true.
   */
  public void newPoint(int x, int y)
  {
  }

  public void setGesture(Gesture g)
  {
    if (gesture != null) {
      gesture.deleteObserver(this);
    }
    gesture = g;
    valueOk = false;
    if (g != null) {
      g.addObserver(this);
      update(g, null);
    }
  }
  
  public Gesture getGesture()
  {
    return gesture;
  }

  public double getValue()
  {
    if (!valueOk) {
      computeValue();
      valueOk = true;
    }
    return value;
  }

  /**
   * @param gesture should be a Point, or null
   */
  public void update(Observable gesture, Object arg)
  {
    if ((arg != null) && (arg instanceof Point)) {
      Point p = (Point) arg;
      Gesture g = (Gesture) gesture;
      // sanity check
      if (g != gesture) {
	System.err.println("Feature.update: Bizarreness " +
			   g + " != " + gesture);
	return;
      }
      valueOk = false;
      if (p != null) {
	newPoint(p);
      }
      setChanged();
      notifyObservers(p);
    }
  }

  /* disable this for now since I'm not sure I'll need it */
  /*
  public Feature clone()
  {
    Feature newFeature;
    try {
      newFeature = new Feature();
      newFeature.value = value;
      newFeature.valueOk = value;
      newFeature.gesture = gesture.clone();
    }
    catch (CloneNotSupportedException e) { return null };
    return newFeature;
  }
  */
  
  /**
   * Return a name that will be meaningful to the user
   */
  abstract public String getName();

  /**
   * Return maximum value this feature can have
   */
  abstract public double getMinValue();

  /**
   * Return minimum value this feature can have
   */
  abstract public double getMaxValue();

  /* Subclass-defined methods */
  
  /**
   * Non-incremental computation.  Should set value to new value and
   * valueOk to true.
   */
  abstract protected void computeValue();


  /**
   * Change @gesture so that the feature changes (ideally by the
   * scale factor).
   */
  abstract public void scale(double factor);

  /**
   * Restore observer status
   */
  private void readObject(ObjectInputStream in)
       throws IOException, ClassNotFoundException
  {
    in.defaultReadObject();
    if (gesture != null)
      gesture.addObserver(this);
  }
  
}
