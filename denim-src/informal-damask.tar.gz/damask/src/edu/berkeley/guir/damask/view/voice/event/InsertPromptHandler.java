package edu.berkeley.guir.damask.view.voice.event;

import java.awt.Insets;
import java.awt.geom.*;
import java.util.Collections;
import java.util.Iterator;

import javax.swing.border.EmptyBorder;
import javax.swing.text.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.command.ModifyGraphMacroCommand;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.event.StyledTextEventHandler;
import edu.berkeley.guir.damask.view.voice.VoiceCanvas;
import edu.berkeley.guir.damask.view.voice.dialog.Form;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolox.nodes.PStyledText;

/**
 * The event handler for entering text.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-15-2004 James Lin
 *                               Changed TextHandler from a static inner class
 *                               of DamaskCanvas to its own top-level class 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-15-2004
 */
public class InsertPromptHandler extends StyledTextEventHandler {
   private Form form = null;
   private final PStyledText styledText = createText();
      
   public InsertPromptHandler() {
      super();
      init();
   }

   public InsertPromptHandler(JTextComponent editor) {
      super(editor);
      init();
   }

   private void init() {
      DamaskAppUtils.setFont(styledText, DamaskAppUtils.getDefaultFont());
   }
   
   public void mousePressed(PInputEvent event) {
      final PNode pickedNode = event.getPickedNode();

      final VoiceCanvas canvas = (VoiceCanvas)event.getComponent();
      canvas.setActiveTextHandler(this);
      
      DamaskAppUtils.setText(styledText, "");
      DamaskAppUtils.setFont(styledText, DamaskAppUtils.getDefaultFont());
         
      if (pickedNode instanceof Form.Contents) {
         // Potentially create a new text label
         form = (Form)pickedNode.getParent();

         final Insets pInsets = styledText.getInsets();
         pickedNode.addChild(styledText); // will be removed in stopEditing()

         final Point2D position = event.getPosition();
         pickedNode.globalToLocal(position);

         styledText.setOffset(
            position.getX() - pInsets.left,
            position.getY() - pInsets.top);
            
         startEditing(event, styledText);
      }
   }


   // @Override
   public void stopEditing() {
      if (canvas instanceof DamaskCanvas) {
         ((DamaskCanvas)canvas).setTextEditing(false);
      }
      
      if (editedText != null) {
         final DamaskCanvas damaskCanvas = (DamaskCanvas)canvas;
         final Document editedDoc = editedText.getDocument(); 
         editedDoc.removeDocumentListener(docListener);
         editedText.setEditing(false);
         editedText.syncWithDocument();

         editedText.removeFromParent();
         
         // If the document is empty...
         if (editedText.getDocument().getLength() == 0) {
         }
         else {
            DamaskAppUtils.setFontSize(
               editedText, form.getDeviceType().getDefaultFontSize());
            
            final Rectangle2D bounds = editedText.getBounds();
            final AffineTransform transform = editedText.getTransform();
         
            try {
               final Dialog dialog = (Dialog)form.getModel();
               final DamaskLayer layer =
                  ((DamaskLayer)damaskCanvas.getLayer());
               final DeviceType deviceTypeForText =
                  layer.getDeviceTypeForNewElement();
               final Content content = new Content(deviceTypeForText,
                     editedDoc.getText(0, editedDoc.getLength()));
               content.setTransform(deviceTypeForText, transform);
               content.setVoicePromptBounds(bounds);

               for (Iterator i = deviceTypeForText.getSpecificDeviceTypes().iterator(); i.hasNext(); ) {
                  final DeviceType aDeviceType = (DeviceType)i.next();
                  DamaskAppUtils.setFontSize(
                     editedText, aDeviceType.getDefaultFontSize());
                  
                  final Rectangle2D aDeviceBounds = editedText.getBounds();
                  content.setBounds(aDeviceType, aDeviceBounds);
               }
               
               // Always put the new content on a new "page"
               final Page lastPage =
                  dialog.getLastPage(damaskCanvas.getDeviceType()); 
               final Page pageForNewContent;
               if (lastPage.getRegion(Direction.CENTER).getControls().isEmpty()) {
                  pageForNewContent = lastPage;
               }
               else {
                  pageForNewContent = lastPage.split(Collections.EMPTY_LIST);
               }

               final MacroCommand cmd = new ModifyGraphMacroCommand();
               DamaskUtils.addCommandsForAddingComponentToMacroCommand(
                  cmd,
                  content,
                  pageForNewContent.getRegion(Direction.CENTER));
               damaskCanvas.getDocument().getCommandQueue().doCommand(
                  damaskCanvas, cmd);
            }
            catch (BadLocationException e) {
               // should never happen
               DamaskAppExceptionHandler.log(e);
            }
         }

         editor.setVisible(false);
         canvas.repaint();

         editedText = null;
         form = null;
      }
   }

   protected JTextComponent createDefaultEditor() {
      final JTextComponent tComp = super.createDefaultEditor();
      tComp.setBorder(new EmptyBorder(0, 0, 0, 0));
      return tComp;
   }
}
