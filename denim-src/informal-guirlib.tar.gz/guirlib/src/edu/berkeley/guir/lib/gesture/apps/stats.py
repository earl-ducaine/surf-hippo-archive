for i in range(gs.size()):
	c = gs.categoryAt(i)
	g = c.gestureAt(0)
	fv = FeatureVector(g)
	print c.getName(),
	for j in range(fv.size()):
		val = fv.getValue(j)
		print '\t%f' % val,
	print
