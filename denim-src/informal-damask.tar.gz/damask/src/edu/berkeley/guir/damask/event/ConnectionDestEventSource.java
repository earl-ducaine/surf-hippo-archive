package edu.berkeley.guir.damask.event;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.connection.ConnectionDest;

/** 
 * A source of ConnectionEndpointEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-19-2004 James Lin
 *                               Created ConnectionEndpointEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-19-2004
 */
public class ConnectionDestEventSource {
   
   private Vector/*<ConnectionDestListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public synchronized void addConnectionDestListener(final ConnectionDestListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public synchronized void removeConnectionDestListener(
      final ConnectionDestListener listener) {

      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires inConnectionAdded events to listeners.
    */
   public void fireInConnectionAdded(
      final ConnectionDest e, final Connection connection) {
      
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ConnectionDestEvent event =
         new ConnectionDestEvent(
            e, ConnectionDestEvent.IN_CONNECTION_ADDED, connection);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ConnectionDestListener listener =
            (ConnectionDestListener)i.next();
         listener.inConnectionAdded(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires inConnectionRemoved events to listeners.
    */
   public void fireInConnectionRemoved(
      final ConnectionDest e, final Connection connection) {
      
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ConnectionDestEvent event =
         new ConnectionDestEvent(
            e, ConnectionDestEvent.IN_CONNECTION_REMOVED, connection);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ConnectionDestListener listener = (ConnectionDestListener)i.next();
         listener.inConnectionRemoved(event);
      }
   }
}
