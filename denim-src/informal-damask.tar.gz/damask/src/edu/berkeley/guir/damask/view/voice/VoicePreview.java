package edu.berkeley.guir.damask.view.voice;

import java.util.*;

import javax.swing.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.io.VoiceXMLWriter;
import edu.berkeley.guir.damask.userevent.InvokeEvent;

/** 
 * A class that lets designers preview a voice interface by popping up
 * message boxes, where the text represents the computer prompt, and the
 * text typed into the text field represents the user's response.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  12-07-2004 James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public class VoicePreview {
   private Page currentPage;
   private final java.awt.Component parentComponent;
   private final String documentName;
   private final Map/*<String, Page>*/ templateResponses =
      new HashMap/*<String, Page>*/();
   private final Map/*<String, Page>*/ responses =
      new HashMap/*<String, Page>*/();
   
   public VoicePreview(final java.awt.Component parentComponent,
                       final String documentName,
                       final Dialog startDialog) {
      
      this.parentComponent = parentComponent;
      this.documentName = documentName;
      currentPage = startDialog.getFirstPage(DeviceType.VOICE);
      
      final InteractionGraph graph = startDialog.getInteractionGraph();
      for (Iterator i = graph.getTemplates(DeviceType.VOICE).iterator();
           i.hasNext(); ) {
         final TemplateDialog templateDialog = (TemplateDialog)i.next();
         for (Iterator j = templateDialog.getPages(DeviceType.VOICE).iterator();
              j.hasNext(); ) {
            final Page templatePage = (Page)j.next();
            for (Iterator k = templatePage.getRegion(Direction.CENTER).getControls().iterator();
                 k.hasNext(); ) {
               final Control templateControl = (Control)k.next();
               if (templateControl instanceof Trigger) {
                  final Trigger trigger = (Trigger)templateControl;
                  addTriggerDestsToJumpTable(trigger, templateResponses);                        
               }
            }
         }
      }
   }
   
   /**
    * Previews the voice interface.
    */
   public void go() {
      boolean keepGoing = true;
      while (keepGoing) {
         keepGoing = displayCurrentPage();
      }
   }
   
   /**
    * Previews the current page. If there is an empty trigger in this page, 
    * then this method also follows that trigger to the destination page,
    * and keeps doing this until there are no empty triggers.
    * 
    * @return whether the user has clicked OK
    */
   protected boolean displayCurrentPage() {
      final List/*<Component>*/ origDialogComponents =
         new ArrayList/*<Component>*/();
      final JTextField textField = new JTextField();
      boolean hasAddedTextField = false;
      
      responses.clear();
      hasAddedTextField =
         fillDialogBoxFromPage(origDialogComponents, textField, hasAddedTextField);
      
      // Add a text field even if there are no responses in this page,
      // as long as there are responses in the template.
      if (!hasAddedTextField && !templateResponses.isEmpty()) {
         origDialogComponents.add(textField);
         hasAddedTextField = true;
      }
      
      final int dialogType;
      if (hasAddedTextField) {
         dialogType = JOptionPane.OK_CANCEL_OPTION;
      }
      else {
         dialogType = JOptionPane.DEFAULT_OPTION;
      }
      
      List dialogComponents = new ArrayList(origDialogComponents);
      boolean validResult = false;
      while (!validResult) {
         final int result = JOptionPane.showConfirmDialog(
            parentComponent,
            dialogComponents.toArray(),
            documentName + " [Run - " + currentPage.getDeviceType() + "] - Damask",
            dialogType,
            JOptionPane.PLAIN_MESSAGE);
         
         if (result == JOptionPane.CLOSED_OPTION ||
             (dialogType == JOptionPane.OK_CANCEL_OPTION &&
              result == JOptionPane.CANCEL_OPTION) || 
             (dialogType == JOptionPane.DEFAULT_OPTION &&
              result == JOptionPane.OK_OPTION)) {
            return false;
         }
         
         // Check text field against response and templateResponse table
         // if no key, invalid result (unless there is a * in the table)
         final String userResponse = textField.getText();
         // No input
         if (userResponse.equals("")) {
            dialogComponents = new ArrayList(origDialogComponents);
            dialogComponents.add(0, VoiceXMLWriter.NOINPUT_DEFAULT_AUDIO);
         }
         // Matched response
         else if (hasDestination(userResponse, responses)) {
            Page nextPage = getDestination(userResponse, responses);
            if (nextPage == null) {
               nextPage = getDestination(TextInput.RESPONSE_TEXT, responses);
            }
            if (nextPage == null) {
               JOptionPane.showMessageDialog(
                  parentComponent,
                  "[No destination for your response, " + userResponse + "]");
               return false;
            }
            else {
               currentPage = nextPage;
               validResult = true;
            }
         }
         // No match
         else {
            dialogComponents = new ArrayList(origDialogComponents);
            dialogComponents.add(0, VoiceXMLWriter.NOMATCH_DEFAULT_AUDIO);
         }
      }
      return true;
   }

   /**
    * Reads the current page, and fills in a list that will be used to populate
    * a dialog box simulating the page in voice mode.
    * 
    * @param dialogComponents   the list that will be used to populate the
    *                            dialog box
    * @param textField          a text field to add to the list, if necessary
    * @param hasAddedTextField  whether a text field has been added
    * 
    * @return whether a text field has been added
    */
   private boolean fillDialogBoxFromPage(
      final List dialogComponents,
      final JTextField textField,
      boolean hasAddedTextField) {
      
      final Page origCurrentPage = currentPage;
      
      for (Iterator i =
         currentPage.getRegion(Direction.CENTER).getControls().iterator();
         i.hasNext(); ) {
         
         final Control control = (Control)i.next();
         if (control instanceof Content) {
            dialogComponents.add(
               new JLabel(((Content)control).getVoicePromptText()));
         }
         else if (control instanceof SelectMany) {
            final SelectMany.Item item =
               (SelectMany.Item)((SelectMany)control).getItems().get(0);
            dialogComponents.add(
               new JLabel(item.getVoicePromptText()));
         }
         
         if (!(control instanceof Content) &&
             !((control instanceof Trigger) &&
               ((Trigger)control).getVoiceResponseTextList().size() == 1 &&
               ((Trigger)control).getVoiceResponseTextList().get(0).equals("")) &&
               !hasAddedTextField) {
            
            dialogComponents.add(textField);
            hasAddedTextField = true;
         }
         
         if (control instanceof Select) {
            final List/*<String>*/ itemTexts = new ArrayList/*<String>*/();
            
            final Control controlToOutput;
            if (control instanceof SelectOne) {
               controlToOutput = control;
            }
            else {
               assert ((SelectMany)control).getItems().size() == 1;
               controlToOutput =
                  (SelectMany.Item)((SelectMany)control).getItems().get(0);
            }
            
            for (Iterator k =
                 controlToOutput.getVoiceResponseTextList().iterator();
                 k.hasNext(); ) {
               final String text = (String)k.next();
               if (text.contains(" ")) {
                  itemTexts.add("(" + text.toLowerCase() + ")");
               }
               else {
                  itemTexts.add(text.toLowerCase());
               }
            }
            
            // A trigger following the select allows us to figure out
            // what should happen when one of the items in the select
            // is said.
            if (i.hasNext()) {
               final Control nextControl = (Control)i.next();
               if (nextControl instanceof Trigger) {
                  addTriggerDestsToJumpTable((Trigger)nextControl, responses);
               }
            }
         }
         else if (control instanceof TextInput) {
            // A trigger following the select-one allows us to figure out
            // what should happen when one of the items in the select-one
            // is said.
            if (i.hasNext()) {
               final Control nextControl = (Control)i.next();
               if (nextControl instanceof Trigger) {
                  addTriggerDestsToJumpTable((Trigger)nextControl, responses);
               }
            }
         }
         else if (control instanceof Trigger) {
            final Trigger trigger = (Trigger)control;
            if (trigger.getVoiceResponseTextList().size() == 1 &&
                trigger.getVoiceResponseTextList().get(0).equals("")) {
               dialogComponents.add(
                  new JLabel("------"));
               final NavConnection connection =
                  trigger.getOutConnection(
                     DeviceType.VOICE, new InvokeEvent(trigger), 0 /*condition*/);
               if (connection != null) {
                  final Page destPage =
                     connection.getDest(DeviceType.VOICE).getPage(DeviceType.VOICE);
                  if (destPage != null) {
                     currentPage = destPage;
                     break;
                  }
               }
            }
            else {
               addTriggerDestsToJumpTable(trigger, responses);
            }
         }
      }
      if (origCurrentPage != currentPage) {
         hasAddedTextField =
            fillDialogBoxFromPage(
               dialogComponents, textField, hasAddedTextField);         
      }
      
      return hasAddedTextField;
   }

   private boolean hasDestination(
      final String userResponse,
      final Map/*<String, Page>*/ localResponses) {
      
      return localResponses.containsKey(userResponse.toLowerCase()) ||
             templateResponses.containsKey(userResponse.toLowerCase()) ||
             localResponses.containsKey(TextInput.RESPONSE_TEXT) ||
             templateResponses.containsKey(TextInput.RESPONSE_TEXT);
   }

   private Page getDestination(
      final String userResponse,
      final Map/*<String, Page>*/ localResponses) {
      
      Page nextPage = (Page)localResponses.get(userResponse.toLowerCase());
      if (nextPage == null) {
         nextPage = (Page)localResponses.get(TextInput.RESPONSE_TEXT);
      }
      if (nextPage == null) {
         nextPage = (Page)templateResponses.get(userResponse.toLowerCase());
      }
      if (nextPage == null) {
         nextPage = (Page)templateResponses.get(TextInput.RESPONSE_TEXT);
      }
      return nextPage;
   }
   
   /**
    * For the specified trigger, adds the voice responses and destinations of
    * each response to the specified table.
    */
   private void addTriggerDestsToJumpTable(
      final Trigger trigger, final Map/*<String, Page>*/ jumpTable) {
      
      final NavConnection connection =
         trigger.getOutConnection(
            DeviceType.VOICE, new InvokeEvent(trigger), 0 /*condition*/);
      final Page destPage;
      if (connection == null) {
         destPage = null;
      }
      else {
         destPage =
            connection.getDest(DeviceType.VOICE).getPage(DeviceType.VOICE);
      }
      for (Iterator i = trigger.getVoiceResponseTextList().iterator();
           i.hasNext(); ) {
         final String triggerText = (String)i.next();
         jumpTable.put(triggerText.toLowerCase(), destPage);
      }
   }
}
