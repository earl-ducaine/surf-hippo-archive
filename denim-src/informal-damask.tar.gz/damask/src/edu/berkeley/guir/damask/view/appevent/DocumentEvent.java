package edu.berkeley.guir.damask.view.appevent;

import java.util.EventObject;

import edu.berkeley.guir.damask.view.DamaskDocument;

/** 
 * An event that indicates that a document has been changed.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-21-2003 James Lin
 *                               Created DocumentEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-21-2003
 */
public class DocumentEvent extends EventObject {

   private final Type eventType;   
   
   //---------------------------------------------------------------------------

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   

   public static final Type DOCUMENT_MODIFIED = new Type("document modified");
   public static final Type DOCUMENT_CLEANED = new Type("document cleaned");
   public static final Type DOCUMENT_RENAMED = new Type("document renamed");
   public static final Type DOCUMENT_CLOSED = new Type("document closed");
   public static final Type DOCUMENT_BUSY_STARTED =
      new Type("document started being busy");
   public static final Type DOCUMENT_BUSY_STOPPED =
      new Type("document stopped being busy");
   public static final Type CANVAS_GROUP_ADDED =
      new Type("canvas group added");
   public static final Type CANVAS_GROUP_REMOVED =
      new Type("canvas group removed");

   //---------------------------------------------------------------------------

   /**
    * Constructs a DocumentEvent, that indicates that a document has been
    * changed.
    */
   public DocumentEvent(final DamaskDocument source, final Type eventType) {
      super(source);
      this.eventType = eventType;
   }
   

   /**
    * Returns the document that is the source of the event.
    */
   public DamaskDocument getDocument() {
      return (DamaskDocument)source;
   }
   
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
}
