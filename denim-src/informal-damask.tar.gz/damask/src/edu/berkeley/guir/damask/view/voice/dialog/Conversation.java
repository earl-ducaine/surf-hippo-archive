package edu.berkeley.guir.damask.view.voice.dialog;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.Direction;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.event.ElementContainerEvent;
import edu.berkeley.guir.damask.event.ElementContainerListener;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.pattern.PatternInstanceView;
import edu.berkeley.guir.damask.view.visual.component.ControlView;
import edu.berkeley.guir.damask.view.voice.ResponseDest;
import edu.berkeley.guir.damask.view.voice.VoiceLayer;
import edu.berkeley.guir.damask.view.voice.component.*;
import edu.umd.cs.piccolo.PNode;

/**
 * Represents a conversation, which is a sequence of prompts and responses.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-04-2004 James Lin
 *                               Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 */
public class Conversation extends InteractionElementView implements ResponseDest {
   private static final int TEMPLATE_CONTROLS_ALPHA = 127;
   
   private final ElementContainerListener regionHandler = new PageRegionHandler();
   private final ElementContainerListener templateHandler =
      new TemplatePageRegionHandler();
   private final ElementContainerListener dialogHandler = new DialogHandler();
   private final ElementContainerListener selectManyHandler =
      new SelectManyHandler();

   private final Map/*<Component, VoiceComponent>*/ views = new HashMap();
   private final Map/*<Page, VoiceComponent>*/ viewsFromTemplate =
      new HashMap();

   // The children are in the following order:
   // template controls, panels, normal controls 
   private int firstNormalChildIndex = 0;
   private int firstGroupIndex = 0;

   /**
    * Creates a conversation based on the specified page.
    */
   protected Conversation(final Page page) {
      super(page);
      setPaint(null);
      setStrokePaint(null);
   }

   
   // @Override
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      // Add controls
      final Page page = (Page)getModel();
      final PageRegion region = getRegionModel(); 

      // Listen to events from model objects
      region.addElementContainerListener(regionHandler);
      region.getPage().getDialog().addElementContainerListener(dialogHandler);
      
      for (Iterator i = region.getControls().iterator(); i.hasNext();) {
         final Control control = (Control) i.next();
         addViewForNormalControl(control);
      }
      
      // Make sure the responses are anchored properly.
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof VoiceControl) {
            for (int j = 0,
                    n = ((Dialog)getForm().getModel()).getNumConditions();
                 j < n;
                 j++) {
               
               final Response response = ((VoiceControl)child).getResponse(j);
               if (response != null) {
                  response.updateDestFromModel();
               }
            }
         }
      }
      
      // Add groups
      for (Iterator i = page.getDialog().getGroups().iterator();
         i.hasNext();
         ) {

         final ComponentGroup group = (ComponentGroup)i.next();
         if (group.getTransformInPageRegion(region) != null) {
            addViewForGroup(group);
         }
      }
   }

   
   // @Override
   public void dispose() {
      final PageRegion regionModel = getRegionModel();
      final Dialog dialogModel = ((Page)getModel()).getDialog();
      super.dispose();
      regionModel.removeElementContainerListener(regionHandler);
      dialogModel.removeElementContainerListener(dialogHandler);
   }


   // @Override
   public DeviceType getDeviceType() {
      return ((Page)getModel()).getDeviceType();
   }

   
   /**
    * Returns the page region that this form is a view of.
    */
   public PageRegion getRegionModel() {
      return ((Page)getModel()).getRegion(Direction.CENTER);
   }


   /**
    * Adds the proper view for the specified element.
    */
   private VoiceControl addViewForNormalControl(final Control control) {
      return (VoiceControl)addViewForComponent(getChildrenCount(), control);
   }
   
   /**
    * Returns the form that this conversation is in.
    */
   public Form getForm() {
      return (Form)getParent().getParent();
   }
      
   /**
    * Adds the proper view for the specified element.
    */
   private VoiceControl addViewForNormalControl(
      final int index,
      final Control control) {
      
      return (VoiceControl)addViewForComponent(
         index + firstNormalChildIndex, control);
   }
   
      
   /**
    * Adds the proper view for the specified template element.
    */
   private VoiceControl addViewForTemplateControl(
      final Page template,
      final Control control) {

      return addViewForTemplateControl(template, firstGroupIndex, control);
   }
   
      
   /**
    * Adds the proper view for the specified template element.
    */
   private VoiceControl addViewForTemplateControl(
      final Page template,
      final int index,
      final Control control) {

      final VoiceControl result =
         (VoiceControl)addViewForComponent(index, control);
      firstNormalChildIndex++;
      firstGroupIndex++;
      
      ((List)viewsFromTemplate.get(template)).add(result);
      
      DamaskAppUtils.setInternalColorAlpha(result, TEMPLATE_CONTROLS_ALPHA);

      result.setSelectable(false);
      
      return result;
   }
   
      
   /**
    * Adds the proper view for the specified component group.
    */
   private VoicePanel addViewForGroup(final ComponentGroup group) {
      return addViewForGroup(firstNormalChildIndex - firstGroupIndex, group);
   }
   
      
   /**
    * Adds the proper view for the specified template element.
    */
   private VoicePanel addViewForGroup(
      final int index,
      final ComponentGroup group) {

      final VoicePanel result =
         (VoicePanel)addViewForComponent(index + firstGroupIndex, group);
      firstNormalChildIndex++;
      return result;
   }
   
      
   /**
    * Adds the proper view for the specified element at the specified index.
    */
   private VoiceComponent addViewForComponent(
      int index,
      final Component component) {

      VoiceComponent view = null;

      if (component instanceof Content) {
         view = new VoiceContent((Content)component);
      }
      
      else if (component instanceof SelectMany) {
         view = new VoiceSelectMany((SelectMany)component);
      }
      
      else if //((component instanceof SelectMany.Item) ||
               (component instanceof SelectOne)/*)*/ {
         view = new VoiceSelectOne((SelectOne)component);
      }
      
      else if (component instanceof TextInput) {
         view = new VoiceTextInput((TextInput)component);
      }
      
      else if (component instanceof Trigger) {
         view = new VoiceTrigger((Trigger)component);
      }
      else if (component instanceof ComponentGroup) {
         view = new VoicePanel((ComponentGroup)component);
      }
      else {
         assert false : "element of type "
            + component.getClass()
            + " cannot be added to a page region";
      }
      addChild(index, view);
      final VoiceLayer layer =
         (VoiceLayer)DamaskAppUtils.getAncestor(this, VoiceLayer.class);

      final Form form = getForm();
      if ((form != null) && (layer != null)) {
         if (form.isContentsSelectable()) {
            layer.addSelectableParent(view);
            if (view instanceof VoiceControl) {
               final VoiceControl voiceControl = (VoiceControl)view;
               for (int k = 0,
                     n = ((Dialog)form.getModel()).getNumConditions();
                     k < n;
                     k++) {
                  if (voiceControl.getResponse(k) != null) {
                     layer.addSelectableParent(voiceControl.getResponse(k));
                  }
               }
            }
         }
         else {
            layer.removeSelectableParent(view);
            if (view instanceof VoiceControl) {
               final VoiceControl voiceControl = (VoiceControl)view;
               for (int k = 0,
                     n = ((Dialog)form.getModel()).getNumConditions();
                     k < n;
                     k++) {
                  if (voiceControl.getResponse(k) != null) {
                     layer.removeSelectableParent(voiceControl.getResponse(k));
                  }
               }
            }
         }
      }
      
      if (layer != null) {
         layer.adjustComponentByDeviceTypeLayer(view);
         // Fade the control if its device type doesn't match the current
         // device-type layer.
         layer.adjustComponentByDeviceTypeLayer(view);
         layer.trackAddition(view);
         
         // Add the view to any views of pattern instances it is a member of
         if (component instanceof Control) {
            for (Iterator i =
                  ((Control)component).getPatternInstanceMemberships().iterator();
                  i.hasNext(); ) {
               final PatternInstance instance = (PatternInstance)i.next();
               final PatternInstanceView instanceView =
                 (PatternInstanceView)layer.getView(instance);
               if (instanceView != null) {
                  instanceView.addMemberView(view);
               }
            }
         }
      }
      views.put(component, view);

      return view;
   }


   /**
    * Removes the proper view for the specified template element.
    */
   private void removeViewForTemplateControl(
      final Page template,
      final Control control) {

      final VoiceControl removedView =
         (VoiceControl)removeViewForComponent(control);
      ((List)viewsFromTemplate.get(template)).remove(removedView);
      firstNormalChildIndex--;
      firstGroupIndex--;
   }


   /**
    * Removes the proper view for the specified component group.
    */
   private void removeViewForGroup(final ComponentGroup group) {
      removeViewForComponent(group);
      firstNormalChildIndex--;
   }


   /**
    * Removes the proper view for the specified element.
    * 
    * @return the view that was removed
    */
   private VoiceComponent removeViewForComponent(final Component component) {
      final VoiceControl view = (VoiceControl)views.get(component);

      view.removeFromParent();
      view.dispose();

      views.remove(component);
      
      // If the component is a select control, then stop listening to it
      if (component instanceof Select) {
         ((Select)component).removeElementContainerListener(selectManyHandler);
      }
      
      final DamaskLayer layer = getLayer();
      if (layer != null) {
         // Remove the view from any views of pattern instances it is a member of
         if (component instanceof Control) {
            for (Iterator i =
                 ((Control)component).getPatternInstanceMemberships().iterator();
                 i.hasNext(); ) {
               final PatternInstance instance = (PatternInstance)i.next();
               final PatternInstanceView instanceView =
                  (PatternInstanceView)layer.getView(instance);
               if (instanceView != null) {
                  instanceView.removeMemberView(view);
               }
            }
         }
      }
      return view;
   }

   
   /**
    * Adds the objects from the page's template. 
    */
   protected void addTemplate(final Page newTemplate) {
      // Add the new template's elements (if the template isn't null).
      if (newTemplate != null) {
         if (viewsFromTemplate.get(newTemplate) == null) {
            viewsFromTemplate.put(newTemplate, new ArrayList());
         }

         final PageRegion region = getRegionModel();

         final PageRegion templateRegion =
            newTemplate.getRegion(region.getName());

         for (Iterator i = templateRegion.getControls().iterator();
            i.hasNext();
            ) {
      
            final Control control = (Control)i.next();
            final VoiceControl view =
               addViewForTemplateControl(newTemplate, control);
            view.setSelectable(false);
            DamaskAppUtils.setInternalColorAlpha(
               view, TEMPLATE_CONTROLS_ALPHA);
         }
      
         // Listen to the template for changes
         templateRegion.addElementContainerListener(templateHandler);
      }
   }


   /**
    * Removes the objects from the page's template. 
    */
   protected void removeTemplate(final Page oldTemplate) {
      // Remove the old template's elements.
      if (oldTemplate != null) {
         final PageRegion region = getRegionModel();

         final PageRegion templateRegion =
            oldTemplate.getRegion(region.getName());

         final List/*<ControlView>*/ templateControlViews =
            (List)viewsFromTemplate.get(oldTemplate);

         for (Iterator i = templateControlViews.iterator(); i.hasNext(); ) {
            final ControlView controlView = (ControlView)i.next();
            removeChild(controlView);
            firstNormalChildIndex--;
            firstGroupIndex--;
         }
         templateControlViews.clear();
      
         // Stop listening to the template for changes
         templateRegion.removeElementContainerListener(templateHandler);
      }
   }


   /**
    * Returns the following:
    * 
    * <ul>
    * <li>If the previous voice control is a select-many control, then returns
    * the last item in that control
    * <li>If the specified control is a select-many item, then returns the
    * previous item in the select-many control  
    * <li>If the specified control is the first item in a select-many control,
    * then returns the control before the select-many control (which may
    * be another select-many item)
    * <li>Otherwise, returns the previous control
    * </ul>
    */
   public VoiceControl getPreviousLowLevelControl(
      final VoiceControl voiceControl) {
      
      if (voiceControl instanceof VoiceSelectManyItem) {
         final VoiceSelectManyItem voiceItem =
            (VoiceSelectManyItem)voiceControl;
         
         final VoiceSelectMany voiceSelect =
            (VoiceSelectMany)voiceItem.getParent();
         
         final int index = voiceSelect.indexOfChild(voiceItem); 
         if (index > 0) {
            return (VoiceSelectManyItem)voiceSelect.getChild(index - 1); 
         }
         else {
            return getPreviousLowLevelControl(
               (VoiceSelectMany)voiceItem.getParent());
         }
      }
      else {
         final int childIndex = indexOfChild(voiceControl);
         if (childIndex > 0) {
            final VoiceControl voiceControlBefore =
               (VoiceControl)getChild(childIndex - 1);
            
            if (voiceControlBefore instanceof VoiceSelectMany) {
               return (VoiceSelectManyItem)voiceControlBefore.getChild(
                  voiceControlBefore.getChildrenCount() - 1);
            }
            else {
               return voiceControlBefore;
            }
         }
         else {
            return null;
         }
      }
   }


   /**
    * Returns the following:
    * 
    * <ul>
    * <li>If the next voice control is a select-many control, then returns
    * the first item in that control
    * <li>If the specified control is a select-many item, then returns the
    * next item in the select-many control  
    * <li>If the specified control is the last item in a select-many control,
    * then returns the control after the select-many control (which may
    * be another select-many item)
    * <li>Otherwise, returns the next control
    * </ul>
    */
   public VoiceControl getNextLowLevelControl(
      final VoiceControl voiceControl) {
      
      if (voiceControl instanceof VoiceSelectManyItem) {
         final VoiceSelectManyItem voiceItem =
            (VoiceSelectManyItem)voiceControl;
         
         final VoiceSelectMany voiceSelect =
            (VoiceSelectMany)voiceItem.getParent();
         
         final int index = voiceSelect.indexOfChild(voiceItem); 
         if (index < voiceSelect.getChildrenCount() - 1) {
            return (VoiceSelectManyItem)voiceSelect.getChild(index + 1); 
         }
         else {
            return getNextLowLevelControl(
               (VoiceSelectMany)voiceItem.getParent());
         }
      }
      else {
         final int childIndex = indexOfChild(voiceControl);
         if (childIndex < getChildrenCount() - 1) {
            final VoiceControl voiceControlAfter =
               (VoiceControl)getChild(childIndex + 1);
            
            if (voiceControlAfter instanceof VoiceSelectMany) {
               return (VoiceSelectManyItem)voiceControlAfter.getChild(0);
            }
            else {
               return voiceControlAfter;
            }
         }
         else {
            return null;
         }
      }
   }

   
   /**
    * Returns the previous prompt from the specified control. 
    */
   public VoiceControl getPreviousVoiceControlWithPrompt(
      final VoiceControl voiceControl) {
      
      VoiceControl prevVoiceControl = getPreviousLowLevelControl(voiceControl);
      
      Prompt prevPrompt = prevVoiceControl == null ?
                          null :
                          prevVoiceControl.getPrompt();
      
      while ((prevPrompt == null) && (prevVoiceControl != null)) {
         prevVoiceControl = getPreviousLowLevelControl(prevVoiceControl);
         prevPrompt = prevVoiceControl == null ?
            null :
            prevVoiceControl.getPrompt();
      }
      return prevVoiceControl;
   }
   
   /**
    * Returns the next prompt from the specified control. 
    */
   public VoiceControl getNextVoiceControlWithPrompt(
      final VoiceControl voiceControl) {
      
      VoiceControl nextVoiceControl = getNextLowLevelControl(voiceControl);
      
      Prompt nextPrompt = nextVoiceControl == null ?
                          null :
                          nextVoiceControl.getPrompt();
      
      while ((nextPrompt == null) && (nextVoiceControl != null)) {
         nextVoiceControl = getNextLowLevelControl(nextVoiceControl);
         nextPrompt = nextVoiceControl == null ?
            null :
            nextVoiceControl.getPrompt();
      }
      return nextVoiceControl;
   }


   /**
    * Called when the device-type layer of a layer is changed. 
    */
   protected void deviceTypeLayerChanged() {
      for (Iterator j = getChildrenIterator(); j.hasNext(); ) {
         final PNode child = (PNode)j.next();
         if (child instanceof VoiceControl) {
            ((VoiceControl)child).deviceTypeLayerChanged();
         }
      }
   }


   // @Override
   public Point2D getAnchorPt() {
      // If this conversation is the first in the form, then the response
      // should point to the top middle of the form. Otherwise, it should point
      // to the first prompt in the conversation.
      final Form form = getForm();
      if (form.getContents().indexOfChild(this) == 0) {
         final Point2D anchorPt = form.getAnchorPt();
         form.localToGlobal(anchorPt);
         globalToLocal(anchorPt);
         return anchorPt;
      }
      else {
         if (getChildrenCount() > 0) {
            final PNode firstChild = getChild(firstNormalChildIndex);
            if (firstChild instanceof VoiceControl) {
               final Prompt firstPrompt =
                  ((VoiceControl) getChild(firstNormalChildIndex)).getPrompt(); 
               final Point2D anchorPt =
                  firstPrompt.getBounds().getCenter2D();
               firstPrompt.localToGlobal(anchorPt);
               globalToLocal(anchorPt);
               return anchorPt;
            }
            else {
               final Point2D anchorPt =
                  new Point2D.Double(
                     getBounds().getCenterX(), getBounds().getMinY());
               return anchorPt;
            }
         }
         else {
            final Point2D anchorPt =
               new Point2D.Double(
                  getBounds().getCenterX(), getBounds().getMinY());
            return anchorPt;
         }
      }
   }


   // @Override
   public Rectangle2D getDestBounds() {
      // If this conversation is the first in the form, then the response
      // should point to the top middle of the form. Otherwise, it should point
      // to the first prompt in the conversation.
      final Form form = getForm();
      final Rectangle2D bounds;
      if (form.getContents().indexOfChild(this) == 0) {
         bounds = form.getBounds();
         form.localToGlobal(bounds);
         globalToLocal(bounds);
      }
      else {
         if (getChildrenCount() == 0) {
            bounds = getBounds();
         }
         else {
            final VoiceControl firstControl =
               (VoiceControl) getChild(firstNormalChildIndex);
            if (firstControl == null) {
               bounds = getBounds();
            }
            else {
               final Prompt firstPrompt = firstControl.getPrompt();
               if (firstPrompt == null) {
                  bounds = getBounds();
               }
               else {
                  bounds = firstPrompt.getBounds();
                  firstPrompt.localToGlobal(bounds);
                  globalToLocal(bounds);
               }
            }
         }
      }
      return bounds;
   }
   
   
   /** 
    * Handles element container events from the page region model.
    */
   private class PageRegionHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         addViewForNormalControl(e.getIndex(), (Control)e.getElement());
      }

      public void elementRemoved(ElementContainerEvent e) {
         removeViewForComponent((Control)e.getElement());
      }
   }


   /**
    * Handles events from the dialog associated with the model of this
    * object.
    */
   private class DialogHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         if (e.getElement() instanceof ComponentGroup) {
            final ComponentGroup group = (ComponentGroup)e.getElement();
            if (group.getDeviceTypesVisibleTo().contains(getDeviceType())) {
               if (group.getTransformInPageRegion(getRegionModel()) != null) {
                  addViewForGroup(group);
               }
            }
         }
      }

      public void elementRemoved(ElementContainerEvent e) {
         if (e.getElement() instanceof ComponentGroup) {
            final ComponentGroup group = (ComponentGroup)e.getElement();
            if (group.getDeviceTypesVisibleTo().contains(getDeviceType())) {
               if (group.getTransformInPageRegion(getRegionModel()) != null) {
                  removeViewForGroup(group);
               }
            }
         }
      }
   }

   /** 
    * Handles element container events from the model of the template page.
    */
   private class TemplatePageRegionHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         addViewForTemplateControl(
            ((PageRegion)e.getSource()).getPage(),
            e.getIndex(),
            (Control)e.getElement());
      }

      public void elementRemoved(ElementContainerEvent e) {
         removeViewForTemplateControl(
            ((PageRegion)e.getSource()).getPage(),
            (Control)e.getElement());
      }
   }


   /**
    * Handles events from the select-controls within this form.
    */
   private class SelectManyHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         addViewForNormalControl((Control)e.getElement());
      }

      public void elementRemoved(ElementContainerEvent e) {
         removeViewForComponent((Control)e.getElement());
      }
   }
}
