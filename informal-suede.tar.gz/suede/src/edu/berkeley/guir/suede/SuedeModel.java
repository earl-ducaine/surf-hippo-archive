package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.beans.*;

import java.util.Vector;
import java.util.LinkedList;
import java.io.File;   
import org.w3c.dom.*;
import javax.xml.parsers.*;
import org.xml.sax.*;

/**
  SuedeModel:
	stores all of the required data in the actual data graph
    
	knows how to save the SuedeModel in XML into a specified directory
	FIXME: which already exists; not robust code
    
	FIXME: has knowledge of the parent widget when reading in the
	FIXME: saved file, to add created elements into the scene
    
	aks, 04/26/00
    
    
   The layout here is a bit complex. At the outermost layer is the class SUEDE, the Windows application. 
   As with any JFrame, Suede contains a contentPane. In this case, the contentPane is a JSplitPane, which
   divides the screen into the top script area and the bottom design area. the JSplitPane directly contains
   the ScriptPane for the top area. For the bottom, the SplitPane contains a JScollPane. The ScrollPane in 
   turn contains the designArea.
**/
public class SuedeModel {
   private static final int     EPSILON  = 2500;
   private        final boolean DEBUG    = false;

   private static final String DESIGN_TITLE      = "SUEDE Design - ";
   private static final String ANALYS_TITLE      = "SUEDE Analysis - ";
   private static final String designExtension   = ".sue";
   private static final String analysisExtension = ".sua";
   private static final String dataExtension     = "_data";
          
   // these are to manage unique labels for the cards and links
   private static final String  m_cardprefix     = "";
   private static final String  m_cardlinkprefix = "cl";  

   
   private SContentPane m_designCanvas = new SContentPane();
   private ScriptModel  m_scriptModel;
   private JFrame       m_frame = new JFrame(DESIGN_TITLE); // the containing window. Needed so title can be set on open/save.
   private Vector       m_arraySingleNodeModels = new Vector();  // stores type SingleNodeModel and GroupNodeModel
   private Vector       m_arrayLinkModels       = new Vector();  // stores type LinkModel
   private LinkedList   freeLabels = new LinkedList(); //stores labels to be reused for SingleNodeModels; eliminates "holes"
   private int          m_cardoffsetnum      = 0;
   private int          m_cardlinkoffsetnum  = 0;
   private int          maxLabelNum = 0; //keeps track of the highest label so as not to have duplicates
   private Vector       m_balloonVector      = new Vector();   // used to keep track of bubbles, which are second passed when reading in a file
   private boolean      m_analysisMode   = false; // false for design, test; true for analysis

   private StartNodeModel       m_startNodeModel;
   private ContentMouseListener m_mouse;

	//HV Jan 2204
	private JSplitPane splitP;
	
   /////////Hongvan's code////////////////////
   private JPopupMenu popup = new JPopupMenu();
   private RolloverMenuItem newPromptCard = new RolloverMenuItem("Create New Prompt Card", Color.black, Color.white, Color.darkGray);
   private RolloverMenuItem newResponseCard = new RolloverMenuItem("Create New Response Card", Color.black, Color.white, Color.darkGray);
   private RolloverMenuItem copy = new RolloverMenuItem("Copy", Color.black, Color.white, Color.darkGray);
   private RolloverMenuItem cut = new RolloverMenuItem("Cut", Color.black, Color.white, Color.darkGray);
   private RolloverMenuItem paste = new RolloverMenuItem("Paste", Color.black, Color.white, Color.darkGray);
   //store the position of mouse click on the canvas.
   private Point p;
   //store the copied Object to be pasted either PromptCard's view or groupCard's view
   public static AbstNodeView copiedObj;
   public static AbstLinkView copiedLinkObj;
   //store the copied (dragged) Object to be pasted (added) to another script
   //in the script area.
   public static AbstScriptNodeView copiedScriptNodeObj;
   /////////////////////////////////////////
   
   /**used to keep track of TranscriptNodes*/
   public Vector  scriptNodes = new Vector(); 
   /**used to keep track of SourceNodes*/
   public Vector  sourceNodes = new Vector();
          
   private static int openModels = 0;

   // these are variables for managing the saving order
   private String m_path         = "";
   private String m_filename     = "";
   private String suede_filename = ""; //the name of the sue and sua file
   private int    analysisCount  = 0;
   
   /**
	* The constructor sets up the top-level widget, m_frame. m_frame contains a JSplitPane, p.
	* The JSplitPane contains the m_scriptModel's view at the top, and scroll at the bottom.
	*@param isAnalysisMode A boolean value to set if AnalysisMode is applied or not.
	*/
   public SuedeModel(boolean isAnalysisMode) {
	  m_analysisMode = isAnalysisMode;
	  openModels++;
	  m_frame.setSize(635,600); // the size of the application window
      	
	  // init the classes needed for design mode
	  m_scriptModel = new ScriptModel(m_frame.getWidth(), m_designCanvas);
	  m_scriptModel.setAppModel(this);
	  JScrollPane scroll = new JScrollPane(m_designCanvas, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
												ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

	  if (m_analysisMode){
		 m_designCanvas.setBackground(new Color(41,51,88)); 
	  } else {
		 m_designCanvas.setBackground(new Color(24,40,105)); 
		 ////////////////////Hongvan's code//////////////////////////
		 newPromptCard.addActionListener (new PromptCardActionListener());
		 newResponseCard.addActionListener (new ResponseCardActionListener());
		 copy.addActionListener (new CopyActionListener());
		 cut.addActionListener (new CutActionListener());
		 paste.addActionListener (new PasteActionListener());
		 popup.add(newPromptCard);
		 popup.add(newResponseCard);
		 popup.add(copy); popup.add(cut); popup.add(paste);
		 /////////////////////////////////////////////////////////////
	  }
	  m_designCanvas.setLayout(null); //the design canvas's layout should be null b/c this is the graph area
	  m_designCanvas.setOpaque(true);
	  m_designCanvas.setVisible(true);

	  //the size of the design graph area. b/c there are scrollbars, this can be larger than the app
	  m_designCanvas.setSize(2000,2000);
	  m_designCanvas.setPreferredSize(new Dimension(2000,2000));
      
	 splitP = new JSplitPane(JSplitPane.VERTICAL_SPLIT, m_scriptModel.getScriptAreaView(), scroll);        
	splitP.setResizeWeight(0); //this means that the user cannot make the script area larger than it ought to be
	//	HV Jan 2204
	ScriptPane sp;
	if (! m_analysisMode)
		sp = m_scriptModel.getScriptAreaView();
	else
		sp = m_scriptModel.getTranscriptAreaView();
	int loc = sp.getPreferredSize().height;
	splitP.setDividerLocation(loc);
	System.out.println ("Initial = " + loc);
	splitP.addPropertyChangeListener(
		new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent e) {
				if(e.getPropertyName().equals(
				JSplitPane.LAST_DIVIDER_LOCATION_PROPERTY)) {
					JSplitPane jsp = (JSplitPane)e.getSource();
					
					int dl = jsp.getDividerLocation();
					
					ScriptPane sp;
					if (! m_analysisMode)
						sp = m_scriptModel.getScriptAreaView();
					else
						sp = m_scriptModel.getTranscriptAreaView();	
					int max = sp.getPreferredSize().height;
					if (dl > max)
					splitP.setDividerLocation(max);
					System.out.println ("ghetHai = " + sp.getNumberScripts());
				}
			}
		});
		
	  m_frame.setContentPane(splitP);
	  m_scriptModel.setParentView(splitP);
              
	  m_frame.addWindowListener (new WindowAdapter () {
		 public void windowClosed(WindowEvent e) {  
			openModels--;
			if ( openModels < 1 ) {
			   System.exit (0);
			}
		 }

	   public void windowDeiconified (WindowEvent e) { m_frame.getContentPane().repaint();  } 
	   } );
	
		if ( ! m_analysisMode ) {
		m_mouse = new ContentMouseListener();
		m_designCanvas.addMouseListener(m_mouse);
		m_designCanvas.addMouseMotionListener (m_mouse); 
		}
        
		m_startNodeModel = new StartNodeModel(this);
		
		if ( m_analysisMode ) {
		m_scriptModel.setAnalysisMode();
		} else {
		m_scriptModel.setDesignMode();
		}
	        
		m_frame.setDefaultCloseOperation( WindowConstants.DISPOSE_ON_CLOSE );
		m_frame.setVisible( true );

		
   }

   /** 
	Get a ScriptModel
	@return a ScriptModel
	*/ 
   public ScriptModel getScriptModel() {
		return m_scriptModel;
   }
    
   /**
	*Get a designCanvas ContentPane
	*@return m_designCanvas as a SContentPane.
	*/
   public SContentPane getContentPane() {
		return m_designCanvas;
   }
    
	/**
	 *Tell if the analysisMode is chosen or not
	 *@return a boolean value, m_analysisMode
	 */
	public boolean getAnalysisMode() {
	return m_analysisMode; 
	}
  
    
	public String getDataPath() {
	return m_path + m_filename + dataExtension + "\\";
	}
  
  
	public String nextSmallCardName() {
	return m_scriptModel.nextSmallCardName();
	}
  
  
	public void setAnalysisMode(boolean analysisMode) {
	//System.out.println("setAnalysisMode "+analysisMode);
    
	// if the user selects analysis mode and the system is in design mode, switch to displaying transcripts
	if (analysisMode && !m_analysisMode) m_scriptModel.setAnalysisMode();

	// if the user selects design mode and the system is in analysis mode, switch to displaying scripts
	else if (!analysisMode && m_analysisMode) m_scriptModel.setDesignMode();
 
	m_analysisMode = analysisMode;

	for (int i=0; i<m_arrayLinkModels.size(); i++) {
		if (analysisMode) {
		((LinkModel)(m_arrayLinkModels.get(i))).setAnalysisView();
		}
		else {
		((LinkModel)(m_arrayLinkModels.get(i))).setDesignView();
		}
	}

	m_designCanvas.repaint();
	}
  
  
	public void runTests() {
	if (getNumCards() == 0) {
		MsgBox msg = new MsgBox(m_frame, "Nothing on canvas to test.", 200, 100);
		return;
	}
     
	if (testingStartNode().length() == 0) {
		MsgBox msg = new MsgBox(m_frame, "Please link start to the card you wish to begin testing.");
		return;
	}
        
	if ( m_analysisMode ) { // if in anaylsis mode...
		String filename = getStartingFilename(); // this is probably the wrong thing to do, but OK for now
		if ((filename != null) && (filename.length() > 0)) {
		m_filename = m_filename.substring(0, m_filename.length()-4);
		if (analysisCount > 1) {
			suede_filename = m_filename + "-" + analysisCount;
		}
		else {
			suede_filename = m_filename;
		}

		if (Suede.showPauseDialog) {
			PauseBox msg = new PauseBox(m_frame, 300, 175);
			Suede.showPauseDialog = !msg.getCheckboxState();
		}
		STestFrame testFrame = new STestFrame( filename, suede_filename, this, m_scriptModel.getNumberScripts( true ) /*, PAUSE*/ );
		Point pt = m_frame.getLocation();
		testFrame.setLocation(pt.x + 50, pt.y + 50);
		testFrame.show();
		//silence calibration

		
		if (Suede.enablePauseElim) {
			(testFrame.getCalibrator()).commenceCalibration(); //PAUSE ELIM CODE
		}
		}
	} else { // if in design mode...
		analysisCount +=1;
		//String filename = saveFile( true );
		String filename = save (false, true);
	    System.out.println ("ARE U HERE??");
	    System.out.println (filename);
		if ((filename != null) && (filename.length() > 0)) {
		java.io.File file = new java.io.File( filename );
		SuedeModel analysisModel = new SuedeModel( true );
		//HV Jan 08, 2004
		Point pt = m_frame.getLocation();
		analysisModel.setLocation(pt.x + 50, pt.y + 50);
		analysisModel.analysisCount = analysisCount;
		analysisModel.suede_filename = suede_filename;
		analysisModel.loadCardModel( filename );
		System.out.println ("Parent is " + file.getParent());
		System.out.println (file.getName());
		System.out.println (dataExtension);
		saveAsHTML( file.getParent() + "\\" + file.getName() + dataExtension + "\\" ); // saves the hypertext files that the test window displays
		analysisModel.runTests();
		}
        
	}   
	}
  
  //HV Jan 08, 2004
  	public void setLocation(int x, int y){
  		m_frame.setLocation(x,y);
  	}
  	
  	public Point getLocation(){
  		return m_frame.getLocation();
  	}
  	
	private class ContentMouseListener extends MouseAdapter implements MouseMotionListener {
		private int m_downX;
		private int m_downY;
		private boolean create_link = false;
		private boolean create_node = false;
		private boolean drag_motion = false;
		private JComponent feedback;

		
		/**
		 * When the mouse is pressed on the background, we'll create a link if it's the left mouse button,
		 * and a node if it's the right mouse button
		 */
		public void mousePressed(MouseEvent e) {
			drag_motion = false;
	   	
		//1. If it's the left mouse button, create a link
		if (SwingUtilities.isLeftMouseButton(e)) {
				create_link = true;
				create_node = false;

				//1a. Set up the interactive feedback for the link
				feedback = new SFeedbackLink(0,0);
				feedback.setSize(m_designCanvas.getWidth(), m_designCanvas.getHeight());
				m_designCanvas.add(feedback, JLayeredPane.DRAG_LAYER);
				((SFeedbackLink)feedback).setFColor(AbstLinkView.LINK_COLOR);
				feedback.setVisible(false);

		//2. If it's the right mouse button, create a node
		} else if (SwingUtilities.isRightMouseButton(e)) {
				create_link = false;
				create_node = true;
				feedback = new SFeedbackGroup(0,0);
				feedback.setSize(m_designCanvas.getWidth(), m_designCanvas.getHeight());
				m_designCanvas.add(feedback, JLayeredPane.DRAG_LAYER);
				((SFeedbackGroup)feedback).setFColor(AbstGroupNodeView.NODE_FILL);
				feedback.setVisible(false);
					//Show the popup memnu
					showPopup(e);
		} else {
				create_link = false;
				create_node = false;
		}
	   	
		Point p = e.getPoint();
		SwingUtilities.convertPointToScreen(p, e.getComponent());
		SwingUtilities.convertPointFromScreen(p, m_designCanvas);
		m_downX = p.x;
		m_downY = p.y;
		}
    
    
	public void mouseReleased(MouseEvent e) {
		// THIS CODE IS PART OF THE NEW FEEDBACK CODE
		if(feedback!=null) m_designCanvas.remove(feedback);
			//////Hongvan's code/////////
			p = e.getPoint();
			/////////////////////////////
		//Point p = e.getPoint();
		if (!drag_motion) {
				//Show a popup menu instead of creating new node
				showPopup(e);
		/**if (create_node) {
			addSingleNode(p);
		}**/
		} else {
			Component c = m_designCanvas.getComponentAt(p);
			if (create_link) {
				if (!(c instanceof StartNodeView))
					addLink((SFeedbackLink)feedback);
				else {}
			}
			else if (create_node) {
				//this part makes sure that when a group is drawn over single nodes, 
				//these single nodes automatically get added to the group.
				GroupNodeModel gnm = addGroupNodeModel((SFeedbackGroup)feedback);
				Rectangle r = new Rectangle();
				SingleNodeModel snm;
				Point pt;
				for (int i = 0;i< m_arraySingleNodeModels.size();i++ ){
				if (m_arraySingleNodeModels.elementAt(i)!=null && m_arraySingleNodeModels.elementAt(i) 
				instanceof SingleNodeModel){
                    
				snm = (SingleNodeModel)(m_arraySingleNodeModels.elementAt(i));
				pt = (snm.getView()).getLocation();
				r = javax.swing.SwingUtilities.computeIntersection((int)(pt.getX()), (int)(pt.getY()), (snm.getView()).getWidth(),
										   (snm.getView()).getHeight(),(gnm.getView()).getBounds());
				if(r.getWidth()!=0 && r.getHeight()!=0){
				snm.setGroup(gnm);
				}
				}
				}
			}	
			else {}
			}
            
		m_designCanvas.repaint();
	}


	/**
	 * As the mouse is dragged on the background of the design canvas, we update the interactive feedback.
	 */
	public void mouseDragged(MouseEvent e) {
		Point p = e.getPoint();
		SwingUtilities.convertPointToScreen(p, e.getComponent());
		SwingUtilities.convertPointFromScreen(p, m_designCanvas);
        
		if (((p.y - m_downY)*(p.y - m_downY) + (p.x - m_downX)*(p.x - m_downX)) > SuedeModel.EPSILON) {
		drag_motion = true;
		if (create_node) {
			//calculating start and ending points for the feedback rectangle
			if ((p.x-m_downX)>0 && (p.y-m_downY)>0) {
			((SFeedbackGroup)feedback).setStart(m_downX, m_downY);
			((SFeedbackGroup)feedback).setFinish(p.x, p.y);
			} else if((p.x-m_downX)>0 && (p.y-m_downY)<0) {
			((SFeedbackGroup)feedback).setStart(m_downX, p.y);
			((SFeedbackGroup)feedback).setFinish(p.x, m_downY);
			} else if((p.x-m_downX)<0 && (p.y-m_downY)>0) {
			((SFeedbackGroup)feedback).setStart(p.x, m_downY);
			((SFeedbackGroup)feedback).setFinish(m_downX, p.y);
			}
			else {
			((SFeedbackGroup)feedback).setStart(p.x, p.y);
			((SFeedbackGroup)feedback).setFinish(m_downX, m_downY);
			}
		} else if(create_link) {
			((SFeedbackLink)feedback).setStart(m_downX, m_downY);
			((SFeedbackLink)feedback).setFinish(p.x, p.y);
		}
		else {}
		feedback.setVisible(true);
		feedback.repaint();
		}
		else {
		drag_motion = false;
		feedback.setVisible(false);
		}
	}
        
		public void mouseMoved(MouseEvent e) {
		}
        
		////////////////////Hongvan's code////////////////////////////
		private void showPopup(MouseEvent e) {
		if (e.isPopupTrigger()) {
			copy.setEnabled(false);
			cut.setEnabled(false);
			popup.show(e.getComponent(),
					   e.getX(), e.getY());
		}
		}
		//////////////////////////////////////////////////////////////
	}//end of private class ContentMouseListener
    
	/////////////////////////Hongvan's code//////////////////////
 private class PromptCardActionListener implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				createNewPromptCard();
			}
		}
            
			private class ResponseCardActionListener implements ActionListener {
				public void actionPerformed (ActionEvent e) {
					createNewResponseCard();
				}
			}
            
			private class CopyActionListener implements ActionListener {
				public void actionPerformed (ActionEvent e) {
					//doing nothing, not activated on canvas
				}
			}
            
			private class CutActionListener implements ActionListener {
				public void actionPerformed (ActionEvent e) {
					 //doing nothing, not activated on canvas
				}
			}
            
			private class PasteActionListener implements ActionListener {
				public void actionPerformed (ActionEvent e) {
					if (!getAnalysisMode()) {
						if (copiedObj != null) {
							if (copiedObj instanceof AbstSingleNodeView)
								copyNodetoNode(addSingleNode(p), (SingleNodeModel)copiedObj.getNodeModel());
							else if (copiedObj instanceof AbstGroupNodeView) {
								GroupNodeModel groupNode = addGroupNodeModel(p);     
								copyGrouptoGroup(groupNode, ((GroupNodeModel)copiedObj.getNodeModel()));
							}
						}
						else if (copiedLinkObj != null) {
							copyLinktoLink(addLink(p), copiedLinkObj.getLinkModel());
						}
					}
			}
			}
 
	/**Create a node
	 **/
	public void createNewPromptCard() {
		if (!getAnalysisMode())
			addSingleNode(p);                                           
	}
    
	/**Create a link
	 **/
	public void createNewResponseCard() {
		if (!getAnalysisMode())
			addLink(p);
	else {}
   }
    
	/***/////////////////End of Hongvan's code/////////////////////////// **/
    
	 /*******  file operations  ********/
	/*******  file operations  ********/
	/**
	 * Returns the path to the destination card from the START node
	 */
	private String testingStartNode() {
	Vector links;
	String result = "";
	links = lookupLinkModelByOrigin("START");
      
	if (links.size() == 1) {
		AbstNodeModel destcard = ((LinkModel)links.elementAt(0)).getDestinationCard();
		if (destcard != null) {
		result = getDataPath() + destcard.getLabel() + "_" + getAsciiName(destcard.getLabel()) + ".html";
		}
	} 
	return result;  // return "" unless we have exactly one starting point
	}
  
  
	public String getStartingFilename() {
	String res = null;
	if (DEBUG) {  System.out.println("getting filename for the HTML ... ");  }                        
        
	if (m_path.length() == 0) {
		System.out.println("SAVE FIRST !! ... ");
		//saveFile();
		save(true);
	}

	//m_htmlpath = m_path + m_filename + dataExtension + "\\";
        
	res = testingStartNode();
	return res;
	}

   
	private void saveAnalysis() {
	if (DEBUG) {  System.out.println("saveAnalysisActionPerformed ... ");  }
	try {
		java.io.File file;
		if (m_path.length() > 0) {
		file = new java.io.File(m_path);
		} else {
		file = new java.io.File(System.getProperty("user.dir"));
		}
		javax.swing.JFileChooser fc = new javax.swing.JFileChooser(file);
		fc.setFileFilter(new javax.swing.filechooser.FileFilter () {
			public boolean accept(java.io.File f) {
			if (f.isDirectory()) {
				return true;
			}
			String name = f.getName();
			if (name.endsWith(".txt")) {
				return true;
			}
			return false;
			}
			public String getDescription() {
			return ".txt";
			}
		});

		if (fc.showSaveDialog(null) == javax.swing.JFileChooser.APPROVE_OPTION) {
		java.io.File selectedfile;
		selectedfile = fc.getSelectedFile();
		// the actual call to save the model
		this.saveAnalysis(selectedfile.getParent() + "\\", selectedfile.getName());
		}
	} 
	catch (SecurityException ex) {
		ex.printStackTrace();
	} 
	catch (Exception ex) {
		ex.printStackTrace();
	}
	}

	/**
	 * Saves the design or analysis file according to which mode we are in.
	 */
	public String save (boolean saveAs) {
	return save (saveAs, m_analysisMode);
	}

	/**
	 * Saves the design or analysis file according to which mode we are in.
	 */
	public String save (boolean saveAs, boolean isForAnalysis) {
	String ret = null;
	try {
		java.io.File file;
		if (m_path.length() > 0) {
		file = new java.io.File(m_path);
		} else {
		file = new java.io.File(System.getProperty("user.dir"));
		}
	    
		final String extension = isForAnalysis ? analysisExtension : designExtension;
	    
		if (saveAs || suede_filename.equalsIgnoreCase("")) {
		ret = saveAsFile( file, extension, isForAnalysis);
		}
		else {
		ret = saveFileNew( file, extension );
		}
	}
	catch (SecurityException ex) {
		ex.printStackTrace();
	} 
	catch (Exception ex) {
		ex.printStackTrace();
	}
	return ret; //return the path and name of the file
	}

	/**
	 * Saves a file that has a pre-existing name.
	 */
	public String saveFileNew(File file, String extension) {
	String savename = suede_filename + extension;
	saveCardModel(m_path, savename);
	return m_path + savename;
	}

	/**
	 * Prompts the user for a file name in the following case:
	 * 1. The user chose "Save As..."
	 * 2. There is no existing filename for the file.
	 */
	public String saveAsFile(File file, String ext, boolean isForAnalysis) {
	final String extension = ext;
	javax.swing.JFileChooser fc = new javax.swing.JFileChooser(file);
	fc.setFileFilter(new javax.swing.filechooser.FileFilter () {
		public boolean accept(java.io.File f) {
			if (f.isDirectory()) {
			return true;
			}
			String name = f.getName();
			if (name.endsWith(extension)) {
			return true;
			}
			return false;
		}
		public String getDescription() {
			return "Suede files";
		}
		});

	boolean saveBoth = false;
	String savename = "";

	if (isForAnalysis) { 
		if (suede_filename.equalsIgnoreCase("")) {
		fc.setDialogTitle( "Save design and analysis as..." );
		saveBoth = true;
		}
		else {
		fc.setDialogTitle( "Save analysis as..." );
		}
		fc.setApproveButtonText( "Save Analysis" );
	    
	}
	else {
		 fc.setDialogTitle( "Save design as..." );
		 fc.setApproveButtonText( "Save Design" );
	}

	String name = "";
	if (fc.showSaveDialog(null) == javax.swing.JFileChooser.APPROVE_OPTION) {
		java.io.File selectedfile;
		selectedfile = fc.getSelectedFile();
		name = selectedfile.getName();
	    
		// want suede_filename to be filename without its extension
		if (!name.endsWith(extension)) {
		suede_filename = name;
		name = name + extension;
		}
		else {
		suede_filename = name.substring(0, name.indexOf("."));
		}
	    
	    
		// keep around the path as we might find it useful later
		m_path = selectedfile.getParent() + "\\"; 
	    	    
		// the actual call to save the model
		if (saveBoth) {
		/* NOTE: in this case, the analysis must also be saved for testing.*/
		saveCardModel(m_path, suede_filename+analysisExtension);
		saveCardModel(m_path, suede_filename+designExtension);
		}
		else {
		saveCardModel(m_path, name);
		}
	}
	return m_path + name;
	}
	

	public void saveAsHTML() {//-FIRST:event_saveAsMenuItemActionPerformed

	if (DEBUG) {  System.out.print("saveAsHTMLMenuItemActionPerformed ... ");  }
	try {
		java.io.File file;

		if (m_path.length() == 0) {
		System.out.println("SAVE FIRST !! ... ");
		//saveFile();
		save(true);
		} else {
		System.out.println("Saving in same directory as saved file: " + m_path );        
		}

		//m_htmlpath = m_path;
		if (getDataPath().length() > 0) {
		file = new java.io.File(getDataPath());
		} else {
		file = new java.io.File(System.getProperty("user.dir"));
		}

		// the actual call to save the model
		this.saveAsHTML(getDataPath() + m_filename + dataExtension + "\\" );
      
	} catch (SecurityException ex) {
		ex.printStackTrace();
	} catch (Exception ex) {
		ex.printStackTrace();
	}



	}//-LAST:event_saveAsMenuItemActionPerformed

	public void openFile () {//-FIRST:event_openMenuItemActionPerformed
     
	if (DEBUG) {  System.out.print("openMenuItemActionPerformed ... ");  }
	try {
		java.io.File file = new java.io.File(System.getProperty("user.dir"));
		javax.swing.JFileChooser fc = new javax.swing.JFileChooser(file);
		fc.setFileFilter(new javax.swing.filechooser.FileFilter () {
			public boolean accept(java.io.File f) {
			if (f.isDirectory()) {
				return true;
			}
			String name = f.getName();
			if (name.endsWith(designExtension) || name.endsWith( analysisExtension ) ) {
				return true;
			}
			return false;
			}
			public String getDescription() {
			return "Suede files";
			}
		});

		if (fc.showOpenDialog(null) == javax.swing.JFileChooser.APPROVE_OPTION) {
		java.io.File selectedfile;
		selectedfile = fc.getSelectedFile();
        
		// keep around the path as we might find it useful later
		m_path = selectedfile.getParent() + "\\"; // + selectedfile.getName() + dataExtension + "\\";
        
		// Determine whether to open design or analysis
		boolean isAnalysis = selectedfile.getName().endsWith( analysisExtension );
		SuedeModel newModel = null;
           
		newModel = new SuedeModel( isAnalysis );
		if (getNumCards() != 0) {
			Point pt = getLocation();
			newModel.setLocation(pt.x + 50, pt.y + 50);
		} 
		  
		if ( m_arraySingleNodeModels.isEmpty() && m_arrayLinkModels.isEmpty() ) {// if this is empty window...
			// m_frame.setVisible( false ); // Do this so window listener knows it's closed
			m_frame.dispose(); // Do this to free memory
		}
        
		// the actual call to load up the model  
		  
		newModel.loadCardModel( selectedfile.getParent() + "\\" + selectedfile.getName() );
		System.out.println (selectedfile.getParent() + "\\" + selectedfile.getName());
		String name = selectedfile.getName();
		newModel.suede_filename = name.substring(0, name.indexOf('.'));
           
		//this.loadCardModel(selectedfile.getParent() + "\\" + selectedfile.getName());
        
		m_arraySingleNodeModels = newModel.getArrayNodeModels();
        
		}
	} 
	catch (SecurityException ex) {
		ex.printStackTrace();
	} 
	catch (Exception ex) {
		ex.printStackTrace();
	}
	}//-LAST:event_openMenuItemActionPerformed


	/** 
	 * points to an audio file and loads that up as a replacement
	 * for a specific card
	 */
	public void replaceAudioFromFile (AbstNodeModel thecard) {

	if (DEBUG) {  System.out.print("openAudioFileActionPerformed ... ");  }
	try {
		java.io.File file = new java.io.File(System.getProperty("user.dir"));
		javax.swing.JFileChooser fc = new javax.swing.JFileChooser(file);
		fc.setFileFilter(new javax.swing.filechooser.FileFilter () {
			public boolean accept(java.io.File f) {
			if (f.isDirectory()) {
				return true;
			}
			String name = f.getName();
			if (name.endsWith(".wav")) {
				return true;
			}
			return false;
			}
			public String getDescription() {
			return ".wav";
			}
		});

		if (fc.showOpenDialog(null) == javax.swing.JFileChooser.APPROVE_OPTION) {
		java.io.File selectedfile;
		selectedfile = fc.getSelectedFile();
        
		// keep around the path as we might find it useful later
		//$REVIEW: source of audio bug?
		//m_path = selectedfile.getParent() + "\\";
        
		// the actual call to load up the model
		if (thecard instanceof SingleNodeModel) {
			((SingleNodeModel)thecard).fillAudio(selectedfile.getParent() + "\\" + selectedfile.getName());
		}
		else if (thecard instanceof LinkModel) {
			((LinkModel)thecard).fillAudio(selectedfile.getParent() + "\\" + selectedfile.getName());
		}
		}
	} catch (SecurityException ex) {
		ex.printStackTrace();
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	}
  
  
  
  
	/******* end file operations ********/
  
	/******* lookup operations ******/
	public SingleNodeModel lookupSingleNodeModel(String label) {
		System.out.println ("Size Array = " + m_arraySingleNodeModels.size());
	for (int i = 0; i < m_arraySingleNodeModels.size(); i++ ) {
		if (m_arraySingleNodeModels.elementAt(i) instanceof SingleNodeModel) {
			System.out.println (i + " = " + ((SingleNodeModel)(m_arraySingleNodeModels.elementAt(i))).getCaption());
		if (((SingleNodeModel)(m_arraySingleNodeModels.elementAt(i))).getLabel().compareTo(label) == 0) {
			return (SingleNodeModel)(m_arraySingleNodeModels.elementAt(i));
		}
		}
	}
	return null;
	}
  
  
	private Vector lookupLinkModelByOrigin(String origname) {
	Vector result = new Vector();
	AbstNodeModel origcard;
    
	for (int i = 0; i < m_arrayLinkModels.size(); i++ ) {
		origcard = ((LinkModel)(m_arrayLinkModels.elementAt(i))).getOriginCard();            
		if (origcard != null) {
		if (origcard.getLabel().compareTo(origname) == 0) {
			result.add((LinkModel)(m_arrayLinkModels.elementAt(i)));
		}         
		}
	}    
	return result;
	}
  
	private LinkModel lookupLinkModel(String origname, String destname) {
	AbstNodeModel origcard, destcard;
    
	for (int i = 0; i < m_arrayLinkModels.size(); i++ ) {
		origcard = ((LinkModel)(m_arrayLinkModels.elementAt(i))).getOriginCard();
		destcard = ((LinkModel)(m_arrayLinkModels.elementAt(i))).getDestinationCard();
      
		if ((origcard != null) && (destcard != null)) {
		if (origcard.getLabel().compareTo(origname) == 0  && 
			destcard.getLabel().compareTo(destname) == 0) {
			return (LinkModel)(m_arrayLinkModels.elementAt(i));
		}
		}
	}    
	return null;
	}
  
  
	public LinkModel lookupLinkModel(String label) {
	for (int i = 0; i < m_arrayLinkModels.size(); i++ ) {
		if (((LinkModel)(m_arrayLinkModels.elementAt(i))).getLabel().compareTo(label) == 0) {
		return (LinkModel)(m_arrayLinkModels.elementAt(i));
		}
	}    
	return null;
	}
  
	/******* end lookup operations ******/

  
	/******* copying operations ******/
  
    
	/*
	 * NOTE: This is also where we increment the number of hits on the old card!!
	 * NOTE: to get speech bubbles to work, need to change the audio on the original card
	 */
	public void updateTranscriptWithLink(String label, int userID, TranscriptNodeModel script) {
	LinkModel slc = lookupLinkModel(label);
	//slc.setAudioAndAdd(audio);  // to get speech bubbles to work, need to change the audio on the original card
	slc.addTestResponse(script);
	sourceNodes.add(slc); //source and script nodes stored to update pop-up analysis info upon ending a test
	scriptNodes.add(script);
	//slc.incrementNumberOfHits(userID);  
	script.updateTranscriptWithLink(slc);
	}
    
    
	/*
	 * NOTE: This is also where we increment the number of hits on the old card!!
	 * NOTE: to get speech bubbles to work, need to change the audio on the original card
	 */    
	public void updateTranscriptWithLink(String cardorig, String carddest, 
					 /*AudioInputStream newAIS, */ int userID, TranscriptNodeModel script) {
	String tgroupname;
	LinkModel slc = lookupLinkModel(cardorig, carddest);
      
	// group special cases
	if (slc == null) {  // we must have matched to the destination card's group
		System.out.println ("cardorig = " + cardorig);
		System.out.println ("carddest = " + carddest);
		System.out.println ("userID = " + userID);
		System.out.println ("script = " + script.getCaption());
		System.out.println (lookupSingleNodeModel(carddest));
		tgroupname = lookupSingleNodeModel(carddest).getGroupName();
		if (tgroupname.length() > 0) {          
		slc = lookupLinkModel(cardorig, getGroupByName(tgroupname).getLabel());
		}
      
		if (slc == null) {  // we must have matched from a group as the origin
		tgroupname = lookupSingleNodeModel(cardorig).getGroupName();
		if (tgroupname.length() > 0) {
			slc = lookupLinkModel(getGroupByName(tgroupname).getLabel(), carddest);
		}
          
		if (slc == null) {  // we must be group to group
			slc = lookupLinkModel(getGroupByName(lookupSingleNodeModel(cardorig).getGroupName()).getLabel(), getGroupByName(lookupSingleNodeModel(carddest).getGroupName()).getLabel());
		}
		if (slc == null) {
			if (DEBUG) { System.out.println("Failure in matching up link to link!!"); }  
		}
		}
        
        
	}
	// FIXME: this is where we must double check if we have a group to group link
      
	//slc.setAudioAndAdd(script.getAudio());  // to get speech bubbles to work, need to change the audio on the original card
	slc.addTestResponse(script);
	sourceNodes.add(slc); //source and script nodes stored to update pop-up analysis info upon ending a test
	scriptNodes.add(script);
      
	script.updateTranscriptWithLink(slc);
	}
  
  
	/*
	 * sets the audio of a ScriptNodeModel into a regular card
	 */
	public synchronized void copyScriptNodeModeltoNode(SingleNodeModel cifS, AbstScriptNodeModel csif) {    
	cifS.setCaption(csif.getCaption());    
	// $REVIEW right now we are copying the audio, when we may want to be sharing it!!
	cifS.setAudio(csif.getAudio());
	}
  
	/*
	 * sets the audio of a ScriptNodeModel into a link
	 */
	public synchronized void copyScriptNodeModeltoLinkModel(LinkModel clink, AbstScriptNodeModel csif) {
	clink.setCaption(csif.getCaption());
	javax.sound.sampled.AudioInputStream ais = csif.getAudio();
	// $REVIEW right now we are copying the audio, when we may want to be sharing it!!
	clink.setAudio(ais);
	}
  
	/////////////////////////Hongvan's code/////////////////////////////////////
	/*
	 * sets the audio of a prompt card into a regular prompt card
	 */
	public synchronized void copyNodetoNode(SingleNodeModel dest, SingleNodeModel source) {
		dest.setCaption(source.getCaption());
		dest.setAudio(source.getAudio());
	}
	/*
	 * copy all the nodes in one group SOURCE to another group DEST
	 */
	public synchronized void copyGrouptoGroup(GroupNodeModel dest, GroupNodeModel source) {
		Vector componentList = source.getComponents();
		for (int i = 0; i < componentList.size(); i +=1) {
			SingleNodeModel node = new SingleNodeModel(this, m_designCanvas, getNextCardName());
			copyNodetoNode (node, (SingleNodeModel)(componentList.elementAt(i)));
			dest.addToGroup(node);
			node.collapse();
		}
	}
	/*
	 * copy the audio of a link card(response card) to a regular card on 
	 */
	public synchronized void copyLinktoLink(LinkModel dest, LinkModel source) {
		dest.setCaption(source.getCaption());
		dest.setAudio(source.getAudio());
	}
	///////////////////////////////////////////////////////////////////////////
    
	/******* adding operations ******/
  
	/*
	 * @param Point evtPoint
	 */
	public SingleNodeModel addSingleNode (Point evtPoint) {
	SingleNodeModel node = new SingleNodeModel(this, m_designCanvas, getNextCardName());
	//node.setLocation(evtPoint.x, evtPoint.y); 
	node.setCenter(evtPoint.x, evtPoint.y); 
  
	setCard(node, getNumCards()+1);
	return node;
	}
  
  
	/*
	 * adds a link to the content pane at the right point
	 * 
	 * @param java.awt.Point evtPoint
	 */
  
	public LinkModel addLink(SFeedbackLink fbl) {
	LinkModel cLink = new LinkModel(this, m_designCanvas, nextLinkModelName(), fbl);
	setLinkModel(cLink, getNumLinkModels()+1);
	return cLink;
	}
  
  
	private LinkModel addLink(AbstNodeModel source, AbstNodeModel target) {
	LinkModel cLink = new LinkModel(this, m_designCanvas, nextLinkModelName(), source, target);
	// add to the SuedeModel
	setLinkModel(cLink, getNumLinkModels()+1);
	return cLink;
	}  
  

	/*
	 * adds a link to the content pane at the right point
	 * 
	 * @param java.awt.Point evtPoint
	 */
	public LinkModel addLink(AbstNodeModel source) {
	LinkModel cLink = new LinkModel(this, m_designCanvas, nextLinkModelName(), source);
	// add to the SuedeModel
	setLinkModel(cLink, getNumLinkModels()+1);
	return cLink;
	}  
  
  
	/*
	 * adds a link to the content pane at the right point
	 * 
	 * @param java.awt.Point evtPoint
	 */
	public LinkModel addLink(Point p) {
	LinkModel cLink = new LinkModel(this, m_designCanvas, nextLinkModelName(), p);
	// add to the SuedeModel
	setLinkModel(cLink, getNumLinkModels()+1);
	return cLink;
	}  
  
  
	private GroupNodeModel addGroupNodeModel(SFeedbackGroup fbg) {
	GroupNodeModel group = new GroupNodeModel(m_designCanvas, this, getNextCardName(), fbg);
	setCard(group, getNumCards()+1);
	return group;
	}
  
  
	private GroupNodeModel addGroupNodeModel(Point p) {
	GroupNodeModel group = new GroupNodeModel(m_designCanvas, this, p, getNextCardName());
	// add to the SuedeModel twice
	// both as a node 
	setCard(group, getNumCards()+1);
	return group;
	}  
  
  
  
  
	/*******  deleting operations ******/
  
	public void deleteCard (AbstNodeModel dc) {
	LinkModel clink;
	if (m_arrayLinkModels != null) {
		for (int i = 0; i < m_arrayLinkModels.size(); i++) {
		clink = (LinkModel) m_arrayLinkModels.elementAt(i);
		if (dc == clink.getOriginCard()) {
			clink.setOriginCard(null);
		} else if (dc == clink.getDestinationCard()) {
			clink.setDestinationCard(null); 
		}
		}
	}
    
	// FIXME FIXMEFIXMEFIXMEFIXMEFIXMEFIXMEFIXME
	// FIXME: if a dc is a GROUP we want to walk the cards in it and delete their groupname.  it won't hurt right now.
	// FIXME FIXMEFIXMEFIXMEFIXMEFIXMEFIXMEFIXME
  
	m_arraySingleNodeModels.removeElement(dc);
	freeLabels.add(dc.getLabel());
	dc.removeNode();
	dc = null;
	}
  

	public void deleteLinkModel (LinkModel clink) {
        
	// FIXME FIXMEFIXMEFIXMEFIXMEFIXMEFIXMEFIXME
	// FIXME: if a clink is a SPEECH BUBBLE we want to walk the cards in it and delete their groupname. we're screwed for now.
	// FIXME FIXMEFIXMEFIXMEFIXMEFIXMEFIXMEFIXME
    
	m_arrayLinkModels.removeElement(clink);
	clink.removeNode();    
	clink = null;
	}
  
 
  
  
	/******* end deleting operations ******/
  
  
	/*
	 * does an internal search by the label of the internal cards, might return a GroupNodeModel or a SingleNodeModel
	 *
	 * @param String thename
	 */
	private AbstNodeModel getCardByName(String thename) {
	AbstNodeModel tfr, result = null; 
    
	if (thename.compareTo("START")==0)
		return m_startNodeModel;
    
	if (thename.compareTo("null") != 0) {
		for (int i = 0; i < m_arraySingleNodeModels.size(); i++) {          
		tfr = (AbstNodeModel) m_arraySingleNodeModels.elementAt(i);
		if (tfr.getLabel().equalsIgnoreCase(thename)) {
			result = tfr;
			break;  // jump out of the loop
		}
		}
	}
	return result;
	}
  
  
	/*
	 * does an internal search by group name for group cards, return GroupNodeModel
	 */
	private GroupNodeModel getGroupByName(String thename) {
	AbstNodeModel tfr;
	GroupNodeModel result = null;
	// search this in reverse to get the most recent groups first
	for (int i = m_arraySingleNodeModels.size() - 1; i >= 0; i--) {          
		tfr = (AbstNodeModel) m_arraySingleNodeModels.elementAt(i);
		if (tfr instanceof GroupNodeModel) {
		if (((GroupNodeModel)tfr).getGroupName().equalsIgnoreCase(thename)) {
			result =(GroupNodeModel)tfr;
			break;  // jump out of the loop
		}
		}
	}    
	return result;
	}
  
  
	// ******************************************************************
	// **************************** loadCardModel ***********************
	// ******************************************************************  
  
	/*private void clearCompensatingList() {
	  m_compensatinglist.clear();
	  }
  
	  private void addToCompensatingList(String origname, String finname) {
	  String arr[] = new String[2];
	  arr[0] = origname;
	  arr[1] = finname;
	  m_compensatinglist.add(arr);   
	  }
  
	  private String lookInCompensatingList(String origname) {
	  String tmparr[];
	  // we need to look through this list in reverse order to get the most recent additions first!
	  for (int i = m_compensatinglist.size() - 1; i >= 0; i-- ) {
	  tmparr = (String [])m_compensatinglist.elementAt(i);
	  if (tmparr[0].compareTo(origname) == 0) {
	  return tmparr[1];
	  }
	  }
	  return origname;
	  }*/
  
  
	/*
	 * linkname is the name of the linked card (not yet run through the compensating list)
	 * and the bubbleptrptr is the pointer location that we fix after reading all links
	 */
	private void addToBalloonVector(String linkname/*, int bubbleptrptr*/, SingleNodeModel cardwithbubble) {
	m_balloonVector.add(new LinkNameAndSingleNode(linkname, cardwithbubble));      
	}
  
  
	private void fixListOfBubbles() {
	LinkNameAndSingleNode pair;
	LinkModel thelink;
	for (int i = 0; i < m_balloonVector.size(); i++ ) {
		pair = (LinkNameAndSingleNode)m_balloonVector.elementAt(i);
		//thelink = lookupLinkModel(lookInCompensatingList(pair.linkName));
		thelink = lookupLinkModel(pair.linkName);
		if ((pair.singleNode != null)&&(thelink!=null)) {
		pair.singleNode.loadBalloon(thelink);        
		} 
	}
	}
  
	private class LinkNameAndSingleNode {
	public String linkName;
	public SingleNodeModel singleNode;

	public LinkNameAndSingleNode(String ln, SingleNodeModel sn) {
		linkName = ln;
		singleNode = sn;
	}
	}

	private String getChildrenValue(String tag, String children) {
	while (children.indexOf("&lt;") != -1) {
		int i = children.indexOf("&lt;");
		children = children.substring(0, i) + "<" + children.substring(i+4);
	}
	while (children.indexOf("&gt;") != -1) {
		int i = children.indexOf("&gt;");
		children = children.substring(0, i) + ">" + children.substring(i+4);
	} 
		    
	//removes the tags
	String begTag = "<"+tag+">";
	String endTag = "</"+tag+">";
	children = children.substring(begTag.length(), children.indexOf(endTag));
		
	return children;
	}
  
	/*
	 * parses an XML NodeList and enters the right information into
	 * an recently created LinkModel.
	 *    NodeList - read in from the saved out model file
	 *    LinkModel - created before this function is called
	 *
	 * @param NodeList nlist, LinkModel nlink
	 */
   
	private void fillLink (NodeList nlist, LinkModel nlink)
	throws SAXException
	{
	String tag, value = "";
      
	for (int j = 0; j < nlist.getLength(); j++) {     
		tag = nlist.item(j).getNodeName();
        
		if (DEBUG) {
		emit ("<");
		emit (tag);
		emit (">=");      
		emit ("" + nlist.item(j).getNodeType());
		emit (":");
		}
        
		if (nlist.item(j).getNodeType() == 1) {
          
		if (nlist.item(j).getChildNodes().item(0) == null) {
			value = "";
			emit ( value );
		} else {
			String children = nlist.item(j).getChildNodes().toString();
		    
			value = getChildrenValue(tag, children);
		    
			//value = nlist.item(j).getChildNodes().item(0).getNodeValue();   
		    
			if (DEBUG) {  emit (nlist.item(j).getChildNodes().item(0).getNodeValue());  }
		}
          
          
		} else if (nlist.item(j).getNodeType() == 3) {
		value = "";
		}
        
		// check if we have a value beside a tag
		if (value.length() > 0) {
		// go through the cases for the tags, value pairs:          
		try {
			if (tag.equals("label")) {
			nlink.setLabel(value);
                
			// HACK: update the offset to be the value of this, so we know we are always higher than this in new labels
			try {
				int tmp = Integer.parseInt(value.substring(m_cardlinkprefix.length()));
				if (tmp > m_cardlinkoffsetnum) {
				m_cardlinkoffsetnum = tmp;
				} else {  // if we are too low, we better increment the label for this card so we don't get screwed with repeated labels
				m_cardlinkoffsetnum = m_cardlinkoffsetnum + 1;
				// first keep track of this
				//addToCompensatingList(value, m_cardlinkprefix + m_cardlinkoffsetnum);                
				nlink.setLabel(m_cardlinkprefix + m_cardlinkoffsetnum);
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}  
                
			} else if (tag.equals("cardorig")) {
			AbstNodeModel cif = getCardByName(value);//lookInCompensatingList(value));
               
			nlink.setOriginCard(cif); // regardless if null or not!      
			if (cif != null) {
				if (cif instanceof StartNodeModel) {
				nlink.setDrawBalloon(false);
				}
			}
			} else if (tag.equals("carddest")) {
                 
			AbstNodeModel cif = getCardByName(value);//lookInCompensatingList(value));  // regardless if null or not!
			nlink.setDestinationCard(cif);
			} else if (tag.equals("filename")) {
			nlink.fillAudio(getDataPath() + value);  // reads the audio from the specified filename
			} else if (tag.equals("caption")) {
			nlink.setCaption(value);  // reads the audio from the specified filename
			} else if (tag.equals("sx")) {
			nlink.setSx(Integer.parseInt(value));  // reads the audio from the specified filename                
			} else if (tag.equals("sy")) {
			nlink.setSy(Integer.parseInt(value));  // reads the audio from the specified filename                 
			} else if (tag.equals("tx")) {
			nlink.setTx(Integer.parseInt(value));  // reads the audio from the specified filename   
			} else if (tag.equals("ty")) {
			nlink.setTy(Integer.parseInt(value));  // reads the audio from the specified filename   
			} else if (tag.equals("pause")) {
			nlink.setPauseDuration(Double.parseDouble(value));
			}
              
		} catch (Exception ex) {
			ex.printStackTrace(System.out);
		}
		}        
        
		if ( m_analysisMode )
		nlink.setAnalysisView();
		else
		nlink.setDesignView();
        
		if (DEBUG) {
		emit ("\n");
		}
	}
	}
  
  
	/*
	 * parses an XML NodeList and enters the right information into
	 * an recently created GroupNodeModel.
	 *    NodeList - read in from the saved out model file
	 *    SingleNodeModel - created before this function is called
	 *
	 * @param NodeList nlist, GroupNodeModel ngroup
	 */
	private void fillGroup (NodeList nlist, GroupNodeModel ngroup)
	throws SAXException
	{
	String tag, value = "";
	for (int j = 0; j < nlist.getLength(); j++) {
		tag = nlist.item(j).getNodeName();
		if (DEBUG) {
		emit ("<");
		emit (nlist.item(j).getNodeName());
		emit (">=");      
		emit ("" + nlist.item(j).getNodeType());
		emit (":");
		}
        
		if (nlist.item(j).getNodeType() == 1) {

		if (nlist.item(j).getChildNodes().item(0) == null) {
			value = "";
			emit ( value );
		} else {
			value = nlist.item(j).getChildNodes().item(0).getNodeValue();            
			if (DEBUG) {  emit (nlist.item(j).getChildNodes().item(0).getNodeValue());  }
		}
		} else if (nlist.item(j).getNodeType() == 3) {
		if (DEBUG) {  emit (nlist.item(j).getNodeValue()); }
		value = "";
		}
        
		// check if there is something in the value field      
		if (value.length() > 0) {
		// go through the cases for the tags, value pairs
		try {
			if (tag.equals("label")) {
			ngroup.setLabel(value);                                
                
			// HACK: update the offset to be the value of this, so we know we are always higher than this in new labels
			try {
				int tmp = Integer.parseInt(value.substring(m_cardprefix.length()));
                   
				int tmp_group_offset = m_cardoffsetnum;
				if (tmp > tmp_group_offset) {
				tmp_group_offset = tmp;
				} else {  // if we are too low, we better increment the label for this card so we don't get screwed with repeated labels                                        
				tmp_group_offset = tmp_group_offset + 1;                  
				// first keep track of this
				//addToCompensatingList(value, m_cardprefix + m_cardoffsetnum);
				// then change the label
				ngroup.setLabel(m_cardprefix + tmp_group_offset);
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				System.exit(1);
			}                  
			} else if (tag.equals("ux")) {
			ngroup.setLocation(Integer.parseInt(value), ngroup.getLocation().y);
			} else if (tag.equals("uy")) {
			ngroup.setLocation(ngroup.getLocation().x, Integer.parseInt(value));
			} else if (tag.equals("groupname")) {
			ngroup.setGroupName(value);
			}
       
		} catch (Exception ex) {
			ex.printStackTrace(System.out);
		}
		}        
        
		if (DEBUG) {  emit ("\n");  }
	}
}
    
	/*
	 * parses anopen XML NodeList and enters the right information into
	 * an recently created SingleNodeModel.
	 *    NodeList - read in from the saved out model file
	 *    SingleNodeModel - created before this function is called
	 *
	 * @param NodeList nlist, SingleNodeModel ncard
	 */
	private void fillCard (NodeList nlist, SingleNodeModel ncard) throws SAXException {
	//System.out.println("Entering fillCard");
	String tag, value = "";

	for (int j = 0; j < nlist.getLength(); j++) {
		tag = nlist.item(j).getNodeName();
     
		if (DEBUG)
		emit ("<"+nlist.item(j).getNodeName()+">=" + nlist.item(j).getNodeType()+":");
        
		if (nlist.item(j).getNodeType() == 1) {

		if (nlist.item(j).getChildNodes().item(0) == null) {
			value = "";
			emit ( value );
		} else {
			String children = nlist.item(j).getChildNodes().toString();
			value = getChildrenValue(tag, children);

			//		    value = nlist.item(j).getChildNodes().item(0).getNodeValue();            
			if (DEBUG) {  emit (nlist.item(j).getChildNodes().item(0).getNodeValue());  }
		}
		} else if (nlist.item(j).getNodeType() == 3) {
		if (DEBUG) {  emit (nlist.item(j).getNodeValue()); }
		value = "";
		}
        
		// check if there is something in the value field      
		if (value.length() > 0) {
		// go through the cases for the tags, value pairs
		try {
			if (tag.equals("label")) {
			ncard.setLabel(value);
                
                
			// HACK: update the offset to be the value of this, so we know we are always higher than this in new labels
			try {
				int tmp_card_offsetnum = m_cardoffsetnum;
				int tmp = Integer.parseInt(value.substring(m_cardprefix.length()));
                 
				if (tmp > tmp_card_offsetnum) {
				tmp_card_offsetnum = tmp;
				} else {  // if we are too low, we better increment the label for this card so we don't get screwed with repeated labels                                        
				tmp_card_offsetnum = tmp_card_offsetnum + 1;                  
				// first keep track of this
				//addToCompensatingList(value, m_cardprefix + m_cardoffsetnum);
				// then change the label
                   
				ncard.setLabel(m_cardprefix + tmp_card_offsetnum); 
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				System.exit(1);
			}  
                
			} else if (tag.equals("ux")) {
			ncard.setLocation(Integer.parseInt(value), ncard.getLocation().y);
			} else if (tag.equals("uy")) {
			ncard.setLocation(ncard.getLocation().x, Integer.parseInt(value));
			} else if (tag.equals("caption")) {
			ncard.setCaption(value);
			} else if (tag.equals("filename")) {
                
			ncard.fillAudio(getDataPath() + value);  // reads the audio from the specified filename
			/*String linkname = value.substring(value.lastIndexOf('\\')+1, value.lastIndexOf('.'));
			  if (linkname.indexOf(m_cardlinkprefix) != -1) {
			  if(value.indexOf("NO_AUDIO")!=-1) {
			  System.out.println("we have a bubble with no audio for " + ncard.getLabel());
			  addToBalloonVector(linkname/*,-1, ncard);                   
							   } else { // we have a bubble
							   System.out.println("we have a bubble for " + ncard.getLabel() + " as " + linkname);
							   addToBalloonVector(linkname/*, ncard.getAudioPtrPtr(), ncard);     
											}
											}*/
			}
                
                
			else if (tag.equals("groupname")) {
			ncard.setGroupName(value);
			if (!ncard.setGroup(getGroupByName(value))) {
				ncard.setGroupName("");
			}
			} 
              
			// this is a speech bubble: the data between the tags is the name of the link
			// while loading, we simply put all the ballons in the list (b/c the link they refer to may not be loaded yet)
			// after loading, we go through the whole list and add bubbles
			else if (tag.equals("balloon")) {
			addToBalloonVector(value, ncard);
			}
              
		} catch (Exception ex) {
			ex.printStackTrace(System.out);
		}
		}        
        
		if (DEBUG) {  emit ("\n");  }
	}
	}
    
    
	private void emit (String tag) {
	System.out.print(tag);
	}
  
	/*
	 * takes a path and filename and reads in the XML representing the SUEDE
	 * model.  
	 * 
	 * uses the XML imports listed at the top of this file!
	 * 
	 * @param String path, String filename
	 */
	private void loadCardModel( String filename ) {

	Document doc;  java.io.File ifile;

	ifile = new java.io.File( filename );
	m_path = ifile.getParent() + "\\";
	m_filename = ifile.getName();
	   
	//m_path = filename.substring( 0, filename.lastIndexOf('\\') + 1 );
	//System.out.println( "Set path to: " + m_path );
	   
	// Set the window title
	String suede_filename = m_filename.substring(0, m_filename.length()-4);
	if ( filename.endsWith( designExtension ) || (!m_analysisMode)) {
		m_frame.setTitle( DESIGN_TITLE + suede_filename);
	}
	else {
		if (analysisCount > 1) {
		m_frame.setTitle( ANALYS_TITLE + suede_filename + "-" + analysisCount);
		}
		else {
		m_frame.setTitle( ANALYS_TITLE + suede_filename);
		}
	}
         
          
	try {
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();           
             
             

		// the main variable, doc, stores the XML representation of the suede file
		doc = docBuilder.parse (ifile);
		doc.getDocumentElement ().normalize ();
		if (DEBUG) { System.out.println ("Root element of the doc is " + doc.getDocumentElement().getNodeName() + "\n"); }
                                 
            
            
			// the root element is SUEDE
			// first level children are: card, cardsmall, cardlink
			// cardlinks must be read in AFTER cards; that is how they are written out
			// second level children are the specific values of the input elements
			// list of bubbles assists us in rehooking up bubbles that are read in
            
            
			m_balloonVector.clear();

			for (int i = 0; i < doc.getDocumentElement().getChildNodes().getLength(); i++) {
		Node node = doc.getDocumentElement().getChildNodes().item(i);
              
		if (node.getNodeType() == 1) {  // we only want to pull out Element nodes, those with children
                
			if (node.getNodeName().equals("group")) {
                  
			GroupNodeModel ngroup = this.addGroupNodeModel(new java.awt.Point(0,0));
			//FIXME:
			m_cardoffsetnum = m_cardoffsetnum - 1;
			// bug? the label for this card will get incremented and assigned automatically,
			// and then it will get rewritten when read-in.  it's already in the list of cardModel.
			fillGroup(node.getChildNodes(), ngroup);
                
			// if we hit a card, parse its child XML
			// FIXME: we don't do enough error checking in this 4/26/00 aks                
			} else if (node.getNodeName().equals("card")) {
                  
			SingleNodeModel ncard = addSingleNode(new Point(0,0));
			//FIXME:
			m_cardoffsetnum = m_cardoffsetnum - 1;
			// bug? the label for this card will get incremented and assigned automatically,
			// and then it will get rewritten when read-in.  it's already in the list of cardModel.
			fillCard(node.getChildNodes(), ncard);

			} else if (node.getNodeName().equals("scripts")) {
			m_scriptModel.loadScripts(node.getChildNodes());
                
			} else if (node.getNodeName().equals("transcripts")) {
			//HV Oct1703
			System.out.println ("#ofScripts= " + 
				m_scriptModel.getNumberScripts(true));
			//ScriptPane p = m_scriptModel.getScriptAreaView();
			ScriptPane p = m_scriptModel.getTranscriptAreaView();
			Vector s = p.getScripts();
			for (int y = 0; y < s.size(); y++){
			AbstScriptView sv = (AbstScriptView)s.get(y);
			System.out.println ("***Script#" +y);
			for (int z = 0; z < sv.getNumberNodes(); z ++){
				String str = ((AbstScriptNodeModel)sv.getNode(z)).getCaption();
				System.out.println ("sv" + z +":" + str);
			}
			}		
			m_scriptModel.loadTranscripts(node.getChildNodes());
			
			// if we hit a cardlink add it to the page
			// FIXME: we don't do enough error checking in this  4/26/00 aks
			}  else if (node.getNodeName().equals("cardlink")) {
                   
			LinkModel nlink = this.addLink(null, null);   
                  
			m_cardlinkoffsetnum = m_cardlinkoffsetnum - 1;
			// fill in the sample data structures
			fillLink(node.getChildNodes(), nlink);
                  
                  
			//System.out.println(nlink.getOriginCard());
			} 
                
			setMaxLabelNum();  //sets maxLabelNum to highest card label value
		}
			}
            
            
	} catch (SAXParseException err) {
		System.out.println ("** Parsing error" 
				+ ", line " + err.getLineNumber ()
				+ ", uri " + err.getSystemId ());
		System.out.println("   " + err.getMessage ());
		// print stack trace as below

	} catch (SAXException e) {
		Exception	x = e.getException ();
		((x == null) ? e : x).printStackTrace ();
	} catch (Throwable t) {
		t.printStackTrace ();
	}   
        
	fixListOfBubbles();
	}
  
	/**
	 * Goes through the m_arraySingleNodeModels to find the highest value
	 * label. This label is used as the starting point for labels when
	 * adding new cards to an opened file. This ensures no overlap.
	 */
	private void setMaxLabelNum() {
	AbstNodeModel node;
	for (int i = 0; i < m_arraySingleNodeModels.size(); i++) {  
		node = (AbstNodeModel) m_arraySingleNodeModels.elementAt(i);
		int labelValue = Integer.parseInt(node.getLabel());
		maxLabelNum = Math.max(maxLabelNum, labelValue);
	}
	}
  
	// ******************************************************************
	// **************************** saveCardModel ***********************
	// ******************************************************************
  
  
	/*
	 * set's up the XML file format used for saving out these particular
	 * data structures
	 *
	 * @param String path, String filename
	 */
	private void saveCardModel(String path, String filename) {
	// temporary variables
	DesignScriptNodeModel  tsmcard;
	int i;
	AbstNodeModel tcard;
	LinkModel     tlink;
	String        tstring;
    
    
    
	// Set the window title
	suede_filename = filename.substring(0, filename.length()-4);
	if ( filename.endsWith( designExtension ) || (!m_analysisMode)) {
		m_frame.setTitle( DESIGN_TITLE + suede_filename );
	}
	else {
		m_frame.setTitle( ANALYS_TITLE + suede_filename );
	}
	
	try {
		java.io.FileOutputStream fos;
		java.io.PrintWriter pw;
        
		fos = new java.io.FileOutputStream(path + filename);
		pw = new java.io.PrintWriter(fos);
      
		path = path + filename + dataExtension + "\\";
      
		File dataDir = new File( path );
		dataDir.mkdir();
      
		//path = ".\\" + filename + dataExtension + "\\";
      
		// begin the XML
		pw.println("<SUEDE>");
            
		// print out the groups first, embedded in the list of cards
		for (i = 0; i < m_arraySingleNodeModels.size(); i++) {
		tcard = (AbstNodeModel) m_arraySingleNodeModels.elementAt(i);
		if (tcard instanceof GroupNodeModel)  {
			tstring = ((GroupNodeModel)tcard).save(path);
			if (DEBUG) { System.out.println(tstring); }
			pw.println(tstring);
            
		}
		}
      
		// print out the cards
      
		for (i = 0; i < m_arraySingleNodeModels.size(); i++) {
		tcard = (AbstNodeModel) m_arraySingleNodeModels.elementAt(i);
		if (tcard instanceof SingleNodeModel)  {
			tstring = ((SingleNodeModel)tcard).save(path);
			if (DEBUG) { System.out.println(tstring); }
			pw.println(tstring);
             
		}
		}
      
		// print out the Links
		// I moved this above the scripts to try to fix a loading bug.
		// I hope the ordering wasn't important to anything else
		for (i = 0; i < m_arrayLinkModels.size(); i++) {
		tlink = (LinkModel) m_arrayLinkModels.elementAt(i);
		tstring = tlink.save(path);

			  
		if (DEBUG) { System.out.println(tstring); }
		pw.println(tstring);
          
		}
		// end the XML

		// print out the scriptcards
		/*for (i = 0; i < m_arrayScriptCards.size(); i++) {
		  tsmcard = (DesignScriptNodeModel) m_arrayScriptCards.elementAt(i);
		  tstring = tsmcard.save(path);
		  if (DEBUG) { System.out.println(tstring);  }
		  pw.println(tstring);
		  }*/
		m_scriptModel.saveScriptModel(pw, path);
		pw.println("</SUEDE>");   
      
		pw.close();
		fos.close();  
	} catch (Exception e) {
		e.printStackTrace(System.out);
	}
	}
  
  
  
	// ******************************************************************
	// ****************************** saveAsHTML ************************
	// ******************************************************************
  
	/*
	 * makes a string legal for saving into the directory
	 */
	private String cleanString(String s) {    
	//System.out.println(s);    
	s = s.replace('?', '_');
	s = s.replace('\\', '_');
	s = s.replace('/', '_');
	s = s.replace('<', '_');
	s = s.replace('>', '_');
	s = s.replace(':', '_');
	s = s.replace(';', '_');
	s = s.replace('(', '_');
	s = s.replace(')', '_');
	s = s.replace('$', '_');
	s = s.replace('!', '_');
	//System.out.println(s);
	return s;
	}
  
  
  
	private String getAsciiName(String name) {
	int ASCII_A = 64; // one less
	int i =0;
	try {
		i = Integer.parseInt(name);
	} catch (Exception e) {
		System.out.println("Not an Integer: " + name);
		return "";
	}
    
	char[] lettername = new char[1];
	lettername[0] = (char)(ASCII_A + i);
	return new String(lettername);
	}
  
  
	/*
	 * walks through the list of links to get the globals.
	 */
	private String getGlobals () {
    
	String s = "";
	boolean gotglobal = false;
    
	LinkModel tlink;
   
	s += "<h2>global:</h2> <P>";
          
	s += "<UL>";
   
    
	// globals are the links that start out with null
	for (int i = 0; i < m_arrayLinkModels.size(); i++) {
		tlink = (LinkModel) m_arrayLinkModels.elementAt(i);
        
		if (tlink.isGlobal() && tlink.getDestinationCard() != null) {
		s += "<B><a href=\"";
		s += tlink.getLabel() + "#" + tlink.getDestinationCard().getLabel() + "_" + getAsciiName(tlink.getDestinationCard().getLabel()) + ".html\">";
		s += tlink.getCleanedCaption();
		s += "</a></B>";
		s += "<P>";
		s += "\n";
		gotglobal = true;
		}
		if (DEBUG) { System.out.println(s); }
	}
    
	s += "</UL>";
    
	// don't return a global string if there is no global
	if (!gotglobal) {
		s = "";
	}
    
	return s;
	}
  
	/*
	 * walks throug hthe list of cards and pulls out the cards that are part of a specific group
	 * 
	 */
	private String getGroupHTML ( String groupname , String linktoname ) {
    
	SingleNodeModel tcard;
	String sg = "";

      
	sg += "<H2>option:    " + linktoname + "</H2>";
          
	sg += "<UL>";
	// print out the cards
	for (int i = 0; i < m_arraySingleNodeModels.size(); i++) {
		if (m_arraySingleNodeModels.elementAt(i) instanceof SingleNodeModel) { 
		tcard = (SingleNodeModel) m_arraySingleNodeModels.elementAt(i);
		if (DEBUG) { System.out.println("against " + tcard.getGroupName() + tcard.getGroupName().equalsIgnoreCase(groupname)); }          
		if (tcard.getGroupName().equalsIgnoreCase(groupname)) {
            
			if (DEBUG) { System.out.println("matched " + tcard.getLabel() + " with groupname " + tcard.getGroupName()); }                                            
			sg +=  "<B><a href = \"";
			sg += tcard.getLabel() + "_" + getAsciiName(tcard.getLabel()) + ".html\">";
			sg += tcard.getCleanedCaption();
			sg += "</a></B>";
			sg += "<P>";
			sg += "\n";            
		}     
		}
	}   
	sg = sg + "</UL>";
	return sg;
	}
  
  
	/*
	 * print out the links for either a card or a group
	 */
	private String getLinksForCard (AbstNodeModel tcard) {
	String result = "";
		LinkModel tlink;
		System.out.println ("tcard = " + tcard.getCaption());
	// print out the cardlinks
	for (int i = 0; i < m_arrayLinkModels.size(); i++) {                             
              
		String link = "";
                
                
		tlink = (LinkModel) m_arrayLinkModels.elementAt(i);
                
		AbstNodeModel tdest = tlink.getDestinationCard();
		System.out.println (i + "tlink = " + tlink.getCaption());
		if (tdest != null) {
		System.out.println (i + "tdest = " + tdest.getCaption());
		}
		else {
			System.out.println (i + "tdest = null");
		}
		System.out.println (i + "originCard = " + tlink.getOriginCard().getCaption());
		//HV Oct 1703
		//Changes made to fix the bug in Test mode when the design graph ended with a link
		//The last link was not printed out.
		//if ((tdest!=null)&&(tcard == tlink.getOriginCard())) {                
         if (tcard == tlink.getOriginCard())  { 
         	if (tdest != null)   {   
			// if we are linked to a group as the destination, then print out the group's HTML
			if (tdest instanceof GroupNodeModel) {
				if (DEBUG) { System.out.println("matching " + tdest.getGroupName()); }                      
				link = getGroupHTML(tdest.getGroupName(), cleanString(tlink.getCaption()));                    
			} else {  // just print out the reference to that card
				link += "<B><a href = \"";
				link += tdest.getLabel() + "_" + getAsciiName(tdest.getLabel()) + ".html\">";
				link += tlink.getCleanedCaption();
				link += "</a></B>";
				link += "<P>";
				link += "\n";
			}
         	}
         	//HV Oct 1703 The last card is a link in design graph
         	//Question: I am not sure if it makes sense to have a design graph ended with
         	//a link card instead of a prompt card. Not sure if we should worry about 
         	//this case. 
         	//Since wat the last link card is supposed to link to????
         	//I temporarily make it link to a page called EndTest
         	else if (tdest == null && i == m_arrayLinkModels.size() - 1) {
				link += "<B><a href = \"";
				link += (tlink.getOriginCard().getLabel() + 1) + "_";
				link += getAsciiName(tlink.getOriginCard().getLabel() + 1) + ".html\">";
				link += tlink.getCleanedCaption();
				link += "</a></B>";
				link += "<P>";
				link += "\n";
         	}//end of else if (tdest == null && i == m_arrayLinkModels.size() - 1)
		}
                
		if (DEBUG) { System.out.println(link); }
		result = result + link;
                
	}
              
	return result;
	}
  
	/*
	 * @param String path
	 */
	private void saveAsHTML(String path) {
    
	// temporary variables
	SingleNodeModel tcard;
	String tstring;
	String globalstring = "";
    
	// we should be able to walk all of the captions to be able to print out
	// a set of linked up HTML
   
	globalstring = getGlobals();
    
    
	// we need a file for every card!
	for (int j = 0; j < m_arraySingleNodeModels.size(); j++) {
		if (m_arraySingleNodeModels.elementAt(j) instanceof SingleNodeModel) { 
		tcard = (SingleNodeModel)m_arraySingleNodeModels.elementAt(j);
		if (DEBUG) { System.out.println( j + " " + tcard.getCaption() + "\n" ); } 
        
		try {
			java.io.FileOutputStream fos;
			java.io.PrintWriter pw;
			fos = new java.io.FileOutputStream(path + tcard.getLabel() + "_" + getAsciiName(tcard.getLabel()) + ".html");
			pw = new java.io.PrintWriter(fos);
            
			//java.io.BufferedWriter bw = new java.io.BufferedWriter(new java.io.FileWriter(file));
			// begin the XML
			//pw.println("<HTML>");

			pw.println("<H2>State: " + tcard.getCleanedCaption() + "</H2>");
            
            
			pw.println("<UL>");
           
            
              
			tstring = getLinksForCard(tcard);  
			pw.println(tstring);
          
            
			if (tcard.getGroupName().length() > 0) {
			pw.println("</UL>From the group:<UL><br>");
			tstring = getLinksForCard(getGroupByName(tcard.getGroupName()));
			pw.println(tstring); 
			}
            
			pw.println(globalstring);
          

			// end the XML
			pw.println("</UL></HTML>");   
           
			pw.close();
			fos.close();  
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		}
	}        
	}
    
  
	/*
	 * @param String path, String filename
	 */
	private void saveAnalysis(String path, String filename) {
    System.out.println ("Have you ever called me?");
	// temporary variables
	TranscriptNodeModel tsmcard;
	int i;
	SingleNodeModel tcard;
	LinkModel       tlink;
	String          tstring;
    
	try {
		java.io.FileOutputStream fos;
		java.io.PrintWriter pw;
      
		fos = new java.io.FileOutputStream(path + filename);
		pw = new java.io.PrintWriter(fos);
      
		// begin the XML
		pw.println("Analysis:");
		pw.println("(Card,\tNumber Of Hits,\tCaption)");
      
		// print out the cards
		for (i = 0; i < m_arraySingleNodeModels.size(); i++) {
		tcard = (SingleNodeModel) m_arraySingleNodeModels.elementAt(i);
		tstring = "(" + tcard.getLabel() + ",\t" + tcard.getNumberOfHits() + ",\t" + tcard.getCaption() + ")";
		if (DEBUG) { System.out.println(tstring); }
		pw.println(tstring);
		}
        
		pw.println("\n");
		pw.println("\n");
		pw.println("(Link,\tCaption,\t\tNumber Of Hits)");
      
		// print out the cardlinks
		for (i = 0; i < m_arrayLinkModels.size(); i++) {
		tlink = (LinkModel) m_arrayLinkModels.elementAt(i);
		System.out.println("*********** this calls getHits?");
		tstring = "(" + tlink.getLabel() + ",\t" + tlink.getHits().size() + ",\t" + tlink.getCaption() + ")";          
		if (DEBUG) { System.out.println(tstring); }
		pw.println(tstring);
		}
		// end the XML
		pw.println("\n");
		pw.println("End analysis");   
      
		pw.close();
		fos.close();  
	} catch (Exception e) {
		e.printStackTrace(System.out);
	}
	}

  
	// **********************************************************************  
	// **************************** SingleNodeModel ***********************
	// **********************************************************************  
	private int getNumCards() {
	return m_arraySingleNodeModels.size();
	}
  
	public Vector getArrayNodeModels() {
	return m_arraySingleNodeModels;
	}
  
	/*
	 * makes up a name for each card, right now differentiates card
	 * numbers based on adding the card number to the string representing the card.
	 */
	private String getNextCardName() {
    
	m_cardoffsetnum = m_cardoffsetnum + 1;
	String cardName = ""; 
     
	// $REVIEW do we want to reuse labels? saves labels but also
	// confusing when labels do not come back in order
     
	/*if (!freeLabels.isEmpty()) {
	  cardName = (String)freeLabels.removeFirst();
	  }
	  else {*/
     
		int cardValue = Math.max(maxLabelNum, getNumCards());
		cardName = (new Integer(cardValue+1).toString());
		if (maxLabelNum < getNumCards()) {
		System.out.println("Should always be equal or greater than getNumCards.");
		}
		maxLabelNum++;
	//}
 
	/*return m_cardprefix + m_cardoffsetnum;*/
	return cardName;
	}
  
  
	private AbstNodeModel getCard (int pos) {
	return (AbstNodeModel) m_arraySingleNodeModels.elementAt(pos);
	}
  
  
	/*
	 * either sets the card at a specific position or if that position
	 * doesn't exist yet, adds the card to the end of the list.
	 * FIXME: this is really bad, and should be split into two routines, 
	 * FIXME: but the guess is that there are going to be some bookkeeping issues once cards are deleted
	 */
	private void setCard (AbstNodeModel nodeModel, int pos) {  
	if (m_arraySingleNodeModels.size() > pos) {
		m_arraySingleNodeModels.setElementAt(nodeModel, pos);
	} else {
		m_arraySingleNodeModels.addElement(nodeModel);
	}
	}
  
  
	// **********************************************************************
	// ***************************** LinkModel *******************************
	// **********************************************************************
  
  
	public int getNumLinkModels() {
	return m_arrayLinkModels.size();
	}
  
	/*
	 * makes up a name for each cardlink, right now differentiates cardlink
	 * numbers based on adding the cardlink number to the string representing the cardlink.
	 */
	private String nextLinkModelName() {
	m_cardlinkoffsetnum = m_cardlinkoffsetnum + 1;
	return m_cardlinkprefix + m_cardlinkoffsetnum;
	}
  
	public LinkModel getLinkModel (int pos) {
	return (LinkModel) m_arrayLinkModels.elementAt(pos);
	}
 
	/*
	 * either set's the card at a specific position or if that position
	 * doesn't exist yet, adds the card to the end of the list.
	 * FIXME: this is really bad, and should be split into two routines, 
	 * FIXME: but the guess is that there are going to be some bookkeeping issues once cards are deleted
	 */
	private void setLinkModel (LinkModel clink, int pos) {
	if (m_arrayLinkModels.size() > pos) {
		m_arrayLinkModels.setElementAt(clink, pos);
	} else {
		m_arrayLinkModels.addElement(clink);
	}
	}
  
	private class MsgBox extends Dialog implements ActionListener {
	boolean id = false;
	Button ok;

	MsgBox(Frame frame, String s){
		super(frame, "", true);
		setLayout(new BorderLayout());
		
		addMessage(s);
		addOKButton();
		createFrame(frame);
		pack();
		setVisible(true);
	}
		
	MsgBox(Frame frame, String s, int width, int height){
		super(frame, "", true);
		setLayout(new BorderLayout());
		
		addMessage(s);
		addOKButton();
		createFrame(frame);
		pack();
		this.setSize(width, height);
		setVisible(true);
	}
	
	private void addMessage(String s) {
		Label l = new Label();
		l.setText(s);
		l.setAlignment(Label.CENTER);
		add(l, BorderLayout.CENTER);
	}
	
	private void addOKButton() {
		Panel p = new Panel();
		p.setLayout(new FlowLayout());
		p.add(ok = new Button("OK"));
		ok.addActionListener(this); 
		add(p, BorderLayout.SOUTH);
	}
	
	private void createFrame(Frame frame) {
		Point p = frame.getLocationOnScreen();
		Dimension d = frame.getSize();
		this.setLocation(p.x + d.width/4, p.y + d.height/3);
	}

	public void actionPerformed(ActionEvent ae){
		if(ae.getSource() == ok) {
		setVisible(false);
		}
	}
	}

	private class PauseBox extends Dialog implements ActionListener {
	boolean id = false;
	Button yes;
	Button no;
	Checkbox cb;

	PauseBox(Frame frame){
		super(frame, "", true);
		setLayout(new GridLayout(5, 1));
		
		addMessage();
		addCheckbox();
		addYesNoButtons();
		createFrame(frame);
		pack();
		setVisible(true);
	}
		
	PauseBox(Frame frame, int width, int height){
		super(frame, "", true);
		setLayout(new GridLayout(4, 1));
		
		addMessage();
	  
		addCheckbox();
		addYesNoButtons();
		createFrame(frame);
		pack();
		this.setSize(width, height);
		setVisible(true);
	}
	
	private void addMessage() {
	   
		Label l1 = new Label("   Would you like to enable pause elimination?");
		l1.setAlignment(Label.LEFT);
		add(l1);
	    
		Panel p = new Panel();
		p.setLayout(new GridLayout(3, 1));
	    
		Label l2 = new Label("   NOTE: If you click 'Yes', calibration begins ");
		l2.setAlignment(Label.LEFT);
		Label l3 = new Label("   immediately; please remain silent at this time.");
		l3.setAlignment(Label.LEFT);
	    
		p.add(l2);
		p.add(l3);
		p.add(new Label()); //dummy space

		add(p);

	}

	private void addCheckbox() {
		Panel p = new Panel();
		cb = new Checkbox("Do not ask me again.");
		p.add(cb);
		add (p);
	}

	private boolean getCheckboxState() {
		return cb.getState();
	}

	private void addYesNoButtons() {
		Panel p = new Panel();
		p.setLayout(new FlowLayout());
		p.add(yes = new Button("Yes"));
		p.add(no = new Button("No"));
		yes.addActionListener(this); 
		no.addActionListener(this);
		add(p);
	}
	
	private void createFrame(Frame frame) {
		Point p = frame.getLocationOnScreen();
		Dimension d = frame.getSize();
		this.setLocation(p.x + d.width/4, p.y + d.height/3);
	}

	public void actionPerformed(ActionEvent ae){
		if(ae.getSource() == yes) {
		Suede.enablePauseElim = true;
		setVisible(false);
		}
		else if (ae.getSource() == no) {
		Suede.enablePauseElim = false;
		setVisible(false);
		}
	}
	}
}














