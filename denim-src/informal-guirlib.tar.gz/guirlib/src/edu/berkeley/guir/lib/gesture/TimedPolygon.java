package edu.berkeley.guir.lib.gesture;

import java.awt.Polygon;
import java.awt.Rectangle;
import java.io.Serializable;

public class TimedPolygon extends Polygon
  implements Serializable, Cloneable
{
  // in the tradition of Polygon, make this public
  public long[] times;

  public TimedPolygon()
  {
    super();
    times = new long[4];
  }

  public TimedPolygon(int[] x, int[] y, int numPoints)
  {
    this(x, y, System.currentTimeMillis(), numPoints);
  }
  
  public TimedPolygon(int[] x, int[] y, long time, int numPoints)
  {
    super(x, y, numPoints);
    times = new long[numPoints];
    for (int i = 0; i < numPoints; i++) {
      times[i] = time;
    }
  }
  
  public TimedPolygon(int[] x, int[] y, long[] t, int numPoints)
  {
    super(x, y, numPoints);
    times = new long[t.length];
    System.arraycopy(t, 0, times, 0, npoints);	
  }

  public TimedPolygon(Polygon p)
  {
    this(p.xpoints, p.ypoints, p.npoints);
  }
  
  public TimedPolygon(TimedPolygon p)
  {
    this(p.xpoints, p.ypoints, p.times, p.npoints);
  }
  
  public void addPoint(int x, int y)
  {
    addPoint(x, y, System.currentTimeMillis());
  }

  public void addPoint(int x, int y, long t)
  {
    super.addPoint(x, y);

    if (npoints == times.length) {
      // resize the times array
      long[] temp = new long[times.length * 2];
      System.arraycopy(times, 0, temp, 0, times.length);
      times = temp;
    }

    times[npoints-1] = t;
  }

  public Object clone()
  {
    try {
      TimedPolygon result = (TimedPolygon) super.clone();
      result.xpoints = (int[]) xpoints.clone();
      result.ypoints = (int[]) ypoints.clone();
      result.times = (long[]) times.clone();
      if (bounds != null) {
	result.bounds = (Rectangle) bounds.clone();
      }
      return result;
    }
    catch (CloneNotSupportedException e) {
      return null;
    }
  }
}
