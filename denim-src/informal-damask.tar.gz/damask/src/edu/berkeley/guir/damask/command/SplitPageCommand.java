package edu.berkeley.guir.damask.command;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.Collection;
import java.util.Iterator;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.Direction;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that splits a page.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-18-2003 James Lin
 *                               Created SplitPageCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-06-2004
 */
public class SplitPageCommand
   extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final Page page;
   private Rectangle2D pageOldBounds;
   private final Collection/*<Control>*/ controlsInNewPage;
   private final double splitY;


   /**
    * Constructs the command.
    *  
    * @param page the page to split
    * @param controlsInNewPage the controls that will be in the new page
    * @param splitY the y-coordinate of the split location, in the
    *         page's center region's coordinate system
    */      
   public SplitPageCommand(final Page page,
         final Collection/*<Control>*/ controlsInNewPage,
         final double splitY) {
      this.page = page;
      this.controlsInNewPage = controlsInNewPage;
      this.splitY = splitY;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Split " + page + " from " + controlsInNewPage;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      final Page page2 = page.split(controlsInNewPage);
      
      if (page.getDeviceType() != DeviceType.VOICE) {
         // Find the change in page's height 
         final PageRegion pageCenter = page.getRegion(Direction.CENTER);
         final double dh = pageCenter.getBounds().getHeight() - splitY;
         
         // Change page's height
         pageOldBounds = page.getBounds();
         page.setBounds(
            new Rectangle2D.Double(pageOldBounds.getX(), pageOldBounds.getY(),
               pageOldBounds.getWidth(), pageOldBounds.getHeight() - dh));
         
         // Change page2's height
         final Rectangle2D page2OldBounds = page2.getBounds();
         page2.setBounds(
            new Rectangle2D.Double(page2OldBounds.getX(), page2OldBounds.getY(),
               pageOldBounds.getWidth(), pageOldBounds.getHeight() - splitY));
         
         // Move the controls in the new page up.
         final DeviceType page2DeviceType = page2.getDeviceType();
         for (Iterator i = controlsInNewPage.iterator(); i.hasNext(); ) {
            final Control control = (Control)i.next();
            final AffineTransform transform =
               control.getTransform(page2DeviceType);
            transform.translate(0, -splitY);
            control.setTransform(page2DeviceType, transform);
         }
      }
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      page.mergeWithAdjacent();
      page.setBounds(pageOldBounds);
      
      // Move the controls that were in the new page back down.
      final DeviceType pageDeviceType = page.getDeviceType();
      if (pageDeviceType != DeviceType.VOICE) {
         for (Iterator i = controlsInNewPage.iterator(); i.hasNext(); ) {
            final Control control = (Control)i.next();
            final AffineTransform transform =
               control.getTransform(pageDeviceType);
            transform.translate(0, splitY);
            control.setTransform(pageDeviceType, transform);
         }
      }
   }
}
