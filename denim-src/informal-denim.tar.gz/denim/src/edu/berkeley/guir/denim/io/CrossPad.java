package edu.berkeley.guir.denim.io;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;

import electricInk.api.*;
import electricInk.io.aggregate.*;
import electricInk.util.*;

import java.awt.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;

/**
 * Handles importing CrossPad notes as pages in DENIM.
 *
 * <PRE>
 * Revisions:  1.0.0  July 13, 2001 FL
 *                    Creation
 * </PRE>
 *
 * @since J2EE 1.2.1, J2SE 1.3
 * @version 1.0.0
 * @author <a href="http://www.cs.berkeley.edu/~fli/">Francis Li</a> (
 *         <a href="mailto:fli@cs.berkeley.edu">fli@cs.berkeley.edu</a>)
 */
public class CrossPad extends Object {

    private static final float XP_WIDTH     = 15.25f;
    private static final float XP_HEIGHT    = 23f;

    /** Offset due to the paper pad binding.
     */
    private static final float XP_OFFSET    = 1f;

    /** Conversion from centimeters (used by electricInk api) to pixels such
     * that the width of one XP page (6" ~ 15.25cm) fits the default width of a
     * DENIM sketch.
     */
    private static final float XP_TOPIXELS  =
        DenimSketch.getDefaultSketchWidth() / XP_WIDTH;

    private CrossPad() {
    }

    public static void open(String filename, DenimSheet sheet)
    throws electricInk.io.InitializationException,
           electricInk.io.FileFormatException,
           java.io.FileNotFoundException,
           java.io.IOException {
        // Ink reader initialization
        AttributesAggregator agg = new AttributesAggregator(true);
        electricInk.io.Reader.setDefaultDeviceFormatHandler(
            "electricInk.util.BasicDeviceFormatAttributeHandler");
        electricInk.io.Reader.setDefaultInkMgrFormatHandler(
            "electricInk.util.SimpleInkMgrFmtAttrHand");
        electricInk.io.Reader.setDefaultAttributeDemarshaller(
            "electricInk.io.aggregate.AttributesAggregator");

        RandomAccessFile f = new RandomAccessFile(filename, "r");
        /* Can't use without reference to an actual JFrame (could create a hidden one, but...)
        InkProgressBar progress = new InkProgressBar(null,
            "Reading notes...",
            "Please wait while your notes are being loaded.");
        */
        electricInk.io.Reader reader = new electricInk.io.Reader(f);
        PageSet ps = reader.readPageSet(agg);
        f.close();

        sheet.clear();

        // HACK: Zoom into storyboard view
        ZoomSlider slider = sheet.getDenimUI().getZoomSlider();
        slider.setAnimateZoom(false);
        slider.setValue(50); // Storyboard value
        slider.setAnimateZoom(true);

        // For each of the rest of the children, get and add the graphical object
        SceneGraphBuilder builder = new SceneGraphBuilder(sheet);
        builder.traversePageSet(ps);

        // Refresh
        sheet.damage(SatinConstants.DAMAGE_NOW);
    }

    private static class SceneGraphBuilder extends APIWalker {
        private DenimSheet      sheet;
        private DenimPanel      currentPanel;
        private ScribbledText   currentScribble;
        private Grouper         grouper;

        private double          scaleFactor;
        private int             pageNum;
        private double          pageX, pageY;
        private float           toPixels;

        public SceneGraphBuilder(DenimSheet sheet) {
            this.sheet      = sheet;
            currentPanel    = null;
            currentScribble = null;
            //// Instantiate a new grouper to handle grouping strokes
            grouper         = new Grouper(sheet);
            //// Get the scale factor of the sheet
            scaleFactor     = GraphicalObjectLib.getScaleFactor(
                GraphicalObjectGroup.COORD_ABS, sheet);
            pageNum         = 0;
            pageX           = 0;
            pageY           = 0;
        }

        /** New version of libraries for TransNote breaks the API Walker
         * class- luckily, it's easy to reproduce the iteration.
         */
        public void traversePageSet(PageSet pset) {
            visitPageSet(pset);
            visitPageSetAttributes(pset.getAttributes());

            Vector pages = pset.pages();
            Iterator i = pages.iterator();
            while (i.hasNext()) {
                Page page = (Page) i.next();
                visitPage(page);
                visitPageAttributes(page.getAttributes());
                Vector scribbles = page.scribbles();
                Iterator j = scribbles.iterator();
                while (j.hasNext()) {
                    Scribble s = (Scribble) j.next();
                    visitScribble(s);
                    visitScribbleAttributes(s.getAttributes());
                }
            }
        }

        protected void visitPageSet(PageSet pset) {
        }

        protected void visitPageSetAttributes(AttributeSet att) {
        }

        protected void visitPage(Page page) {
            PageSize size = page.getMinimumPageSize();
            float width, height;
            if (size.width() <= (PageSize.XP_SIZE.width() + 1)) {
                width = PageSize.XP_SIZE.width();
                height = PageSize.XP_SIZE.height();
            } else {
                width = PageSize.LETTER_SIZE.width();
                height = PageSize.LETTER_SIZE.height();
            }
            toPixels = DenimSketch.getDefaultSketchWidth() / width;
            Debug.println("CrossPad page size: " + width + ", " + height);

            //// Align the pages in a row
            pageX = pageNum * (DenimSketch.getDefaultSketchWidth() + 50) *
                scaleFactor;
            pageY = 0;

            //// Create a label
            TypedText denimText = new TypedText("Page " +
                Integer.toString(pageNum + 1));
            denimText.moveTo(SatinConstants.COORD_REL,
                pageX,
                pageY);
            sheet.add(denimText, GraphicalObjectGroup.KEEP_ABS_POS);

            DenimLabel label = new DenimLabel(denimText);
            Rectangle2D bounds = label.getBounds2D(SatinConstants.COORD_ABS);

            //// Create a sketch of the appropriate size and aspect ratio
            DenimSketch sketch = new DenimSketch(new Rectangle2D.Double(
                pageX,
                bounds.getHeight(),
                DenimSketch.getDefaultSketchWidth() * scaleFactor,
                height / width * DenimSketch.getDefaultSketchWidth() *
                    scaleFactor));

            //// Create panel with dummy bounds
            currentPanel = new DenimPanel(new Rectangle(0, 0, 1, 1));
            sheet.add(currentPanel, GraphicalObjectGroup.KEEP_ABS_POS);

            //// Set the label and sketch on the panel
            currentPanel.setLabel(label);
            currentPanel.setSketch(sketch);

            // HACK: Fix view for sketch, now that it has been added to sheet
            label.initAfterAddLabelToSheet();
            sketch.initAfterAddSketchToSheet();

            //// Reset current scribble reference for grouping strokes
            currentScribble = null;
            pageNum += 1;
        }

        protected void visitPageAttributes(AttributeSet att) {
        }

        /** Handle a scribble in the page. Iterates through each stroke in the
         * scribble. Note that the CrossPad does NOT do automatic grouping so
         * most scribbles only contain ONE stroke.  The exception is for
         * manually grouped strokes by the user using the keyword feature
         */
        protected void visitScribble(Scribble scribble) {
            //// Get timestamp to set in TimedStroke
            Date date = scribble.getTimestamp();

            //// Has this scribble been marked by the user as a keyword?
            boolean isKeyword = false;
            if (KeywordAttribute.getKeywordAttribute(scribble) != null) {
                isKeyword = true;
            }

            //// If there is more than one stroke then this is an explicit group
            //// so we reset the grouping algorithm
            boolean isGrouped = false;
            if (scribble.strokeCount() > 1) {
                isGrouped = true;
                currentScribble = null;
            }

            Vector strokes = scribble.strokes();
            Iterator i = strokes.iterator();
            while (i.hasNext()) {
                //// Create a new SATIN TimedStroke for each stroke and add to
                //// the appropriate ScribbledText
                electricInk.api.Stroke s = (electricInk.api.Stroke) i.next();

                int numPoints = s.pointCount();
                float[] x = new float[numPoints];
                float[] y = new float[numPoints];
                int index = 0;

                Vector points = s.points();
                Iterator j = points.iterator();
                while (j.hasNext()) {
                    electricInk.api.Point p = (electricInk.api.Point) j.next();
                    x[index] = p.x() * toPixels;
                    y[index] = (p.y() - XP_OFFSET) * toPixels;
                    index += 1;
                }

                TimedPolygon2D poly = new TimedPolygon2D(x, y, date.getTime(),
                                                         numPoints);
                TimedStroke tstk = new TimedStroke(poly);
                AffineTransform scale = AffineTransform.getScaleInstance(
                    scaleFactor, scaleFactor);
                AffineTransform translate =
                    AffineTransform.getTranslateInstance(pageX, pageY +
                    currentPanel.getLabel().getBounds2D(SatinConstants.COORD_ABS).getHeight());
                tstk.applyTransform(scale);
                tstk.applyTransform(translate);

                //// Perform grouping of strokes
                if (isGrouped) {
                    //// If this is an explicit group, we don't need to test
                    //// the strokes
                    if (currentScribble == null) {
                        currentScribble = grouper.createNewScribble(tstk);
                    } else {
                        grouper.addStrokeToScribble(currentScribble, tstk);
                    }
                } else {
                    boolean isRightSize = grouper.isRightSize(tstk);
                    if (isRightSize && grouper.belongsWithScribble(tstk,
                            currentScribble)) {
                        grouper.addStrokeToScribble(currentScribble, tstk);
                    } else if (isRightSize) {
                        currentScribble = grouper.createNewScribble(tstk);
                    } else {
                        currentPanel.getSketch().add(tstk,
                            GraphicalObjectGroup.KEEP_ABS_POS);
                    }
                }
            }

            //// If a keyword, set this scribble as the label of the page
            if (isKeyword) {
                //// Get a copy of the scribble
                ScribbledText clone = (ScribbledText) currentScribble.deepClone();

                //// Reset the transform on the scribble and its strokes back to
                //// original size
                AffineTransform identity = new AffineTransform();
                clone.setTransform(identity);
                Iterator k = clone.getForwardIterator();
                while (k.hasNext()) {
                    GraphicalObject go = (GraphicalObject) k.next();
                    go.setTransform(identity);
                }

                //// Now that the original scale of the strokes are restored,
                //// get the bounds and translate to the origin.
                Rectangle2D bounds = clone.getCollectionBounds2D(
                    SatinConstants.COORD_ABS);
                Debug.println(bounds);
                AffineTransform translate =
                    AffineTransform.getTranslateInstance(-bounds.getX(),
                                                         -bounds.getY());
                k = clone.getForwardIterator();
                while (k.hasNext()) {
                    GraphicalObject go = (GraphicalObject) k.next();
                    go.applyTransform(translate);
                }

                //// Set the scribble's bounding box appropriately
                bounds = new Rectangle2D.Double(0,
                                                0,
                                                bounds.getWidth(),
                                                bounds.getHeight());
                clone.setBoundingPoints2D(SatinConstants.COORD_ABS, bounds);

                //// Add it to the sheet and move it into position
                sheet.add(clone, GraphicalObjectGroup.KEEP_ABS_POS);
                clone.moveTo(SatinConstants.COORD_ABS,
                                       pageX,
                                       pageY);

                //// Create the label
                DenimLabel label = new DenimLabel(clone);

                //// Adjust the position of the sketch to the label height
                currentPanel.getSketch().moveTo(SatinConstants.COORD_ABS,
                                                pageX,
                                                pageY + bounds.getHeight());

                //// Add the new label
                currentPanel.setLabel(label);

                //// Do whatever magic Jimmy did to make it work
                label.initAfterAddLabelToSheet();
                currentPanel.getSketch().initAfterAddSketchToSheet();
            }

            //// Again if there was more than one stroke then this is an
            //// explicit group so we reset the grouping algorithm
            if (isGrouped) {
                currentScribble = null;
            }
        }

        protected void visitScribbleAttributes(AttributeSet att) {
        }

        /** We extend the ScribbledTextInterpreter so we can reuse the
         * stroke grouping mechanisms in it.
         */
        private class Grouper extends ScribbledTextInterpreter {
            public Grouper(DenimSheet sheet) {
                parent = sheet;
            }

            /** Since we're not really using this as an interpreter, we need
             * to fake that it is attached to an object.
             */
            public GraphicalObject getAttachedGraphicalObject() {
                return parent;
            }

            public void addStrokeToScribble(ScribbledText scribble,
                    TimedStroke stroke) {
                AddStrokeToScribbleCommand cmdAdd =
                    new AddStrokeToScribbleCommand(scribble, stroke);
                cmdAdd.run();
            }

            public ScribbledText createNewScribble(TimedStroke stroke) {
                ScribbledText scribble = new ScribbledText();

                CreateNewScribbleCommand cmdCreate =
                    new CreateNewScribbleCommand(currentPanel.getSketch(),
                                                 scribble,
                                                 stroke);
                cmdCreate.run();

                return scribble;
            }
        }
    }
}

//==============================================================================

/*
Copyright (c) 2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
