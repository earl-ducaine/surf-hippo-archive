//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.event;

import java.util.EventObject;
import java.io.Serializable;

/**
 * An AND filter for stroke events.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 25 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class BasicStrokeEventFilter
   extends    BasicSatinEventFilter
   implements StrokeEventFilter, Serializable {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   boolean flagAcceptLeft   = true;
   boolean flagAcceptMiddle = true;
   boolean flagAcceptRight  = true;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Accepts all.
    */
   public BasicStrokeEventFilter() {
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Set the values in the filter.
    */
   public BasicStrokeEventFilter(boolean left, boolean middle, boolean right) {
      setAcceptLeftButton(left);
      setAcceptMiddleButton(middle);
      setAcceptRightButton(right);
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   FILTER METHODS   ====================================================

   public boolean isLeftButtonAccepted() {
      return (flagAcceptLeft);
   } // of isLeftButtonAccepted

   //-----------------------------------------------------------------

   public boolean isMiddleButtonAccepted() {
      return (flagAcceptMiddle);
   } // of isMiddleButtonAccepted

   //-----------------------------------------------------------------

   public boolean isRightButtonAccepted() {
      return (flagAcceptRight);
   } // of isRightButtonAccepted

   //-----------------------------------------------------------------

   public void setAcceptLeftButton(boolean flag) {
      flagAcceptLeft = flag;
   } // of setAcceptLeftButton

   //-----------------------------------------------------------------

   public void setAcceptMiddleButton(boolean flag) {
      flagAcceptMiddle = flag;
   } // of setAcceptMiddleButton

   //-----------------------------------------------------------------

   public void setAcceptRightButton(boolean flag) {
      flagAcceptRight = flag;
   } // of setAcceptRightButton

   //-----------------------------------------------------------------

   public boolean isEventAccepted(StrokeEvent evt) {
      if (super.isEventAccepted(evt) == false) {
         return (false);
      }

      if (evt.isLeftButton() == true && isLeftButtonAccepted() == false) {
         return (false);
      }
      if (evt.isMiddleButton() == true && isMiddleButtonAccepted() == false) {
         return (false);
      }
      if (evt.isRightButton() == true && isRightButtonAccepted() == false) {
         return (false);
      }
      return (true);
   } // of isEventAccepted


   //-----------------------------------------------------------------

   public boolean isEventAccepted(EventObject evt) {
      if (evt instanceof StrokeEvent) {
         return (isEventAccepted((StrokeEvent) evt));
      }
      return (false);
   } // of isEventAccepted

   //===   FILTER METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new BasicStrokeEventFilter()));
   } // of method

   //-----------------------------------------------------------------

   protected BasicStrokeEventFilter clone(BasicStrokeEventFilter f) {
      //// 1. Clone chain.
      super.clone();

      //// 2. Do clone work.
      f.flagAcceptLeft   = this.flagAcceptLeft;
      f.flagAcceptMiddle = this.flagAcceptMiddle;
      f.flagAcceptRight  = this.flagAcceptRight;

      //// 3. Return.
      return (f);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      StringBuffer strbuf = new StringBuffer(super.toString());

      strbuf.append("\nleft-button:      " + isLeftButtonAccepted());
      strbuf.append("\nmiddle-button:    " + isMiddleButtonAccepted());
      strbuf.append("\nright-button:     " + isRightButtonAccepted());

      return (strbuf.toString());
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
