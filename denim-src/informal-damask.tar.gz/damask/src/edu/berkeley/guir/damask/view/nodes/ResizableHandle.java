package edu.berkeley.guir.damask.view.nodes;

import java.awt.Shape;
import java.awt.geom.*;
import java.util.*;

import javax.swing.SwingConstants;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.visual.component.Label;
import edu.berkeley.guir.damask.view.visual.component.Panel;
import edu.berkeley.guir.damask.view.visual.dialog.PageRegionView;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.nodes.PText;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolo.util.PDimension;
import edu.umd.cs.piccolox.handles.PBoundsHandle;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * A handle that stretches the node and all of its children.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  11-17-2003 James Lin
 *                               Created StretchHandle.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 11-17-2003
 */
public class ResizableHandle extends BoundsHandle {
   private Map/*<PPath, Shape>*/ origPaths = new HashMap();
   private Map/*<PText, Rectangle2D>*/ origTextBounds = new HashMap();
   private Map/*<PText, int>*/ origTextSize = new HashMap();
   private Map/*<Node, Rectangle2D>*/ origBoundsPct = new HashMap();
   private List/*<PNode>*/ objectsToResize = new ArrayList();

   /**
    * Creates a non-resizable handle with the specified locator, representing
    * which side or corner of the node to attach the handle.
    */
   public ResizableHandle(PBoundsLocator aLocator) {
      super(aLocator);
   }


   /**
    * Adds handles to the given node.
    */
   public static void addHandlesTo(PNode aNode) {
      addHandlesTo(aNode, null, false, false);
   }

   /**
    * Adds handles to the given node, which will stick to the given camera.
    */
   public static void addStickyHandlesTo(PNode aNode, PCamera camera) {
      addHandlesTo(aNode, camera, true, false);
   }

   /**
    * Adds handles to the given node, which will stick to the given
    * camera in the x and y axes, while staying constant along the z axis.
    */
   public static void addStickyZHandlesTo(PNode aNode, PCamera camera) {
      addHandlesTo(aNode, camera, false, true);
   }

   /**
    * Adds handles to the given node.
    * 
    * @param aNode the node to add handles to
    * @param camera the camera that the handles will stick to, or null
    *                if the handles should not be sticky
    * @param useSticky true if the handles will stick to the given camera
    * @param useStickyZ true if the handles will stick to the given
    *                    camera in the x and y axes, while staying
    *                    constant along the z axis.
    */
   public static void addHandlesTo(
      final PNode aNode,
      final PCamera camera,
      final boolean useSticky,
      final boolean useStickyZ) {

      addHandlesTo(aNode, camera, useSticky, useStickyZ, ResizableHandle.class);
   }


   /**
    * Removes handles from the specified node.
    */
   public static void removeHandlesFrom(PNode aNode) {
      removeHandlesFrom(aNode, ResizableHandle.class);
   }


   /**
    * Removes any sticky handles from the specified node that are
    * attached to the specified camera. 
    */
   public static void removeStickyHandlesFrom(PNode aNode, PCamera camera) {
      removeStickyHandlesFrom(aNode, camera, ResizableHandle.class);
   }

   /**
    * Calculates the bounds of the specified node and its descendants
    * as percentages of the bounds of the specified ancestor node.
    */
   private void storeOrigBoundsPct(final PNode node, final PNode ancestor) {
      final PBounds nodeGlobalBds = node.getBounds();
      node.localToGlobal(nodeGlobalBds);

      if (node instanceof PPath) {
         final PPath path = (PPath)node;
         origPaths.put(path, new GeneralPath(path.getPathReference()));
      }
      else if (node instanceof DamaskPPath) {
         final DamaskPPath path = (DamaskPPath)node;
         origPaths.put(path, new GeneralPath(path.getPathReference()));
      }
      else if (node instanceof PText) {
         origTextBounds.put(node, node.getBounds());
         origTextSize.put(
            node,
            new Integer(((PText)node).getFont().getSize()));
      }

      final PBounds ancestorGlobalBds = ancestor.getBounds();
      ancestor.localToGlobal(ancestorGlobalBds);

      origBoundsPct.put(
         node,
         new Rectangle2D.Double(
            (nodeGlobalBds.getX() - ancestorGlobalBds.getX())
               / ancestorGlobalBds.getWidth(),
            (nodeGlobalBds.getY() - ancestorGlobalBds.getY())
               / ancestorGlobalBds.getHeight(),
            nodeGlobalBds.getWidth() / ancestorGlobalBds.getWidth(),
            nodeGlobalBds.getHeight() / ancestorGlobalBds.getHeight()));

      for (Iterator i = node.getChildrenIterator(); i.hasNext();) {
         final PNode child = (PNode)i.next();
         storeOrigBoundsPct(child, ancestor);
      }
   }


   // Overrides method in ancestor class.
   public void startHandleDrag(Point2D aLocalPoint, PInputEvent aEvent) {
      super.startHandleDrag(aLocalPoint, aEvent);
      objectsToResize.clear();
      if (aEvent.getComponent() instanceof DamaskCanvas) {
         for (Iterator i =
                 ((DamaskCanvas)aEvent.getComponent()).getSelectedObjects()
                 .iterator();
              i.hasNext(); ) {
            final PNode node = (PNode)i.next();
            if (!(node instanceof InteractionElementView) ||
                 ((InteractionElementView)node).isResizable()) {
               objectsToResize.add(node);
            }
         }
      }
      else {
         objectsToResize.add(((PBoundsLocator) getLocator()).getNode());
      }

      for (Iterator i = objectsToResize.iterator(); i.hasNext(); ) {
         final PNode node = (PNode)i.next();
         storeOrigBoundsPct(node, node);
      }
   }


   // Overrides method in ancestor class.
   public void dragHandle(PDimension aLocalDimension, PInputEvent aEvent) {
      PBoundsLocator l = (PBoundsLocator) getLocator();
            
      PNode node = l.getNode();
      PNode parent = getParent();
      if (parent != node && parent instanceof PCamera) {
         ((PCamera)parent).localToView(aLocalDimension);
      }

      localToGlobal(aLocalDimension);
      node.globalToLocal(aLocalDimension);
      
      for (Iterator i = objectsToResize.iterator(); i.hasNext(); ) {
         final PNode n = (PNode)i.next();
         
         double dx = aLocalDimension.getWidth();
         double dy = aLocalDimension.getHeight();
   
         PBounds b = n.getBounds();
         
         final boolean toStretchObject =
            !(n instanceof InteractionElementView) ||
            ((InteractionElementView)n).isStretchedWhenResized();
         
         // If the node has a RESIZE_ANCHOR property that is equal to CENTER,
         // then resize the node about the center.
         if (toStretchObject &&
             (n.getClientProperty(DamaskAppUtils.PROPERTY_RESIZE_ANCHOR)
              == Direction.CENTER)) {
   
             switch (l.getSide()) {
                case SwingConstants.NORTH:
                   b.setRect(b.x, b.y + dy/2, b.width, b.height - dy);
                   break;
               
                case SwingConstants.SOUTH:
                   b.setRect(b.x, b.y - dy/2, b.width, b.height + dy);
                   break;
               
                case SwingConstants.EAST:
                   b.setRect(b.x - dx/2, b.y, b.width + dx, b.height);
                   break;
               
                case SwingConstants.WEST:
                   b.setRect(b.x + dx/2, b.y, b.width - dx, b.height);
                   break;
               
                case SwingConstants.NORTH_WEST:
                   b.setRect(b.x + dx/2, b.y + dy/2, b.width - dx, b.height - dy);
                   break;
               
                case SwingConstants.SOUTH_WEST:
                   b.setRect(b.x + dx/2, b.y - dy/2, b.width - dx, b.height + dy);
                   break;
               
                case SwingConstants.NORTH_EAST:
                   b.setRect(b.x - dx/2, b.y + dy/2, b.width + dx, b.height - dy);
                   break;
               
                case SwingConstants.SOUTH_EAST:
                   b.setRect(b.x - dx/2, b.y - dy/2, b.width + dx, b.height + dy);
                   break;
             }
         }
         else {
            switch (l.getSide()) {
               case SwingConstants.NORTH:
                  b.setRect(b.x, b.y + dy, b.width, b.height - dy);
                  break;
               
               case SwingConstants.SOUTH:
                  b.setRect(b.x, b.y, b.width, b.height + dy);
                  break;
               
               case SwingConstants.EAST:
                  b.setRect(b.x, b.y, b.width + dx, b.height);
                  break;
               
               case SwingConstants.WEST:
                  b.setRect(b.x + dx, b.y, b.width - dx, b.height);
                  break;
               
               case SwingConstants.NORTH_WEST:
                  b.setRect(b.x + dx, b.y + dy, b.width - dx, b.height - dy);
                  break;
               
               case SwingConstants.SOUTH_WEST:
                  b.setRect(b.x + dx, b.y, b.width - dx, b.height + dy);
                  break;
               
               case SwingConstants.NORTH_EAST:
                  b.setRect(b.x, b.y + dy, b.width + dx, b.height - dy);
                  break;
               
               case SwingConstants.SOUTH_EAST:
                  b.setRect(b.x, b.y, b.width + dx, b.height + dy);
                  break;
            }
         }
   
         boolean flipX = false;
         boolean flipY = false;
         
         if (b.width < 0) {
            flipX = true;
            b.width = -b.width;
            b.x -= b.width;
         }
         
         if (b.height < 0) {
            flipY = true;
            b.height = -b.height;
            b.y -= b.height;
         }
         
         if (flipX || flipY) {
            flipSiblingBoundsHandles(flipX, flipY);
         }
         
         // The only difference between the superclass's implementation of
         // dragHandle() and this one are the following lines.
         
         // Instead of directly setting n's bounds to b, we want to keep
         // the coordinates of the upper-left-hand corner the same, and change
         // the transform of n.
         final PBounds origBounds = n.getBounds();
         final AffineTransform translation =
            AffineTransform.getTranslateInstance(
               b.getX() - origBounds.getX(),
               b.getY() - origBounds.getY());
         translation.concatenate(n.getTransform());
         n.setTransform(translation);
         n.setBounds(origBounds.getX(), origBounds.getY(), b.getWidth(), b.getHeight());
   
         if (toStretchObject) {
            final PBounds nodeGlobalBds = n.getBounds();
            n.localToGlobal(nodeGlobalBds);
      
            for (Iterator j = n.getChildrenIterator(); j.hasNext(); ) {
               final PNode child = (PNode)j.next();
               if (!(child instanceof PBoundsHandle)) {
                  stretch(child, nodeGlobalBds);
               }
            }
         }
         else {
            // If the node has a RESIZE_CHILDREN_ANCHOR property equal to CENTER,
            // then recenter the children of this node
            if (n.getClientProperty(DamaskAppUtils.PROPERTY_RESIZE_CHILDREN_ANCHOR)
               == Direction.CENTER) {
                  
               double dw = b.width - origBounds.width;
               double dh = b.height - origBounds.height;
               
               for (Iterator j = n.getChildrenIterator(); j.hasNext(); ) {
                  final PNode child = (PNode)j.next();
                  child.translate(dw/2, dh/2);
               }
            }
         }
      }
   }
   
   
   /**
    * Stretches the specified node to the bounds that are percentages of
    * the specified ancestor node's bounds. The percentages are stored
    * in the origBoundsPct field.
    */
   private void stretch(
      final PNode node,
      final PBounds ancestorGlobalBds) {

      final Rectangle2D nodeBdsPct = (Rectangle2D)origBoundsPct.get(node);
      
      // If the node is a PPath or DamaskPPath, then restore the original
      // points of the path before setting the bounds. This ensures that
      // the path does not lose precision if it is resized smaller and smaller.
      if (node instanceof PPath) {
         final PPath path = (PPath)node;
         path.setPathTo((Shape)origPaths.get(path));
      }
      else if (node instanceof DamaskPPath) {
         final DamaskPPath path = (DamaskPPath)node;
         path.setPathTo((Shape)origPaths.get(path));
      }

      final PBounds oldBounds = node.getBounds();
      
      final PDimension newSize =
         new PDimension(
            nodeBdsPct.getWidth() * ancestorGlobalBds.getWidth(),
            nodeBdsPct.getHeight() * ancestorGlobalBds.getHeight());
      node.globalToLocal(newSize);
      
      final Point2D newOrigin;

      // Move the node proportionally relative to its parent, unless the
      // node is a PText within a Label, in which case keep the
      // origin the same.
      if ((node instanceof PText)
         && (node.getParent() instanceof Label)) {

         newOrigin = oldBounds.getOrigin();
      }
      else {
         newOrigin =
            new Point2D.Double(
               ancestorGlobalBds.getX()
                  + nodeBdsPct.getX() * ancestorGlobalBds.getWidth(),
               ancestorGlobalBds.getY()
                  + nodeBdsPct.getY() * ancestorGlobalBds.getHeight());
         node.globalToLocal(newOrigin);
      }

      final PBounds newBounds = new PBounds();
      newBounds.setOrigin(newOrigin.getX(), newOrigin.getY());
      newBounds.setSize(newSize.getWidth(), newSize.getHeight());
      
      final AffineTransform translation =
         AffineTransform.getTranslateInstance(
            newBounds.getX() - oldBounds.getX(),
            newBounds.getY() - oldBounds.getY());
      translation.concatenate(node.getTransform());
      node.setTransform(translation);
      node.setBounds(
         oldBounds.getX(),
         oldBounds.getY(),
         newBounds.getWidth(),
         newBounds.getHeight());

      // If the node is text, change the size of the text to match the bounds
      if (node instanceof PText) {
         final PText text = (PText)node;
         final Rectangle2D origBounds = (Rectangle2D)origTextBounds.get(text);
         final double fracSize =
            Math.min(
               newBounds.getWidth() / origBounds.getWidth(),
               newBounds.getHeight() / origBounds.getHeight());
         
         DamaskAppUtils.setFontSize(
            text,
            (int)(((Integer)origTextSize.get(text)).intValue() * fracSize));
      }


      // Stretch the node's children.
      for (Iterator i = node.getChildrenIterator(); i.hasNext();) {
         final PNode child = (PNode)i.next();
         if (!(child instanceof PBoundsHandle)) {
            stretch(child, ancestorGlobalBds);
         }
      }
   }


   /**
    * Adds commands, for the specified device type, to set the bounds of
    * the specified view's model and all of its children to the specified
    * macro command.
    */
   protected void addStretchCommand(
      final InteractionElementView view,
      final DeviceType deviceType,
      final MacroCommand command) {

      final PBounds viewBounds = view.getBounds();
      final InteractionElement model = view.getModel();
      
      if (view instanceof Panel) {
         final ComponentGroup componentGroup = (ComponentGroup)model;
         final PageRegion currentRegion =
            (PageRegion) ((PageRegionView) ((Panel)view).getParent())
               .getModel();
         command.addCommand(
            new SetBoundsCommand(
               componentGroup,
               currentRegion,
               viewBounds));
         command.addCommand(
            new SetTransformCommand(
               componentGroup,
               currentRegion,
               view.getTransform()));
      }
      else {
         if ((view instanceof Label)
            && (((Label)view).getDisplayMode() == Content.TEXT)) {
            final Label label = (Label)view;
            command.addCommand(
               new SetTextSizeCommand(
                  (Content)label.getModel(),
                  deviceType,
                  label.getText().getFont().getSize()));
         }
         else {
            command.addCommand(
               new SetBoundsCommand(model, deviceType, viewBounds));
         }
         command.addCommand(
            new SetTransformCommand(
               model,
               deviceType,
               view.getTransform()));
      }
         
      for (Iterator i = view.getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof InteractionElementView) {
            addStretchCommand(
               (InteractionElementView)child, deviceType, command);
         }
      }
   }

   
   protected void addResizeCommand(
      final InteractionElementView view,
      final DeviceType deviceType,
      final MacroCommand cmd) {
      
      final Rectangle2D oldBounds =
         view.getModel().getBounds(deviceType);
      final Rectangle2D newBounds = view.getBounds();
      if (!oldBounds.equals(newBounds)) {
         cmd.addCommand(
            new SetBoundsCommand(view.getModel(), deviceType, newBounds));
      }

      final AffineTransform oldTransform =
         view.getModel().getTransform(deviceType);
      final AffineTransform newTransform = view.getTransform();
      if (!oldTransform.equals(newTransform)) {
         cmd.addCommand(
            new SetTransformCommand(view.getModel(), deviceType, newTransform));
      }
   
      // Move children if necessary
      if (view
         .getClientProperty(DamaskAppUtils.PROPERTY_RESIZE_CHILDREN_ANCHOR)
         == Direction.CENTER) {
         for (Iterator i = view.getChildrenIterator(); i.hasNext();) {
            final PNode childNode = (PNode)i.next();
            if (childNode instanceof InteractionElementView) {
               final InteractionElementView child =
                  (InteractionElementView)childNode;
               final AffineTransform oldChildTransform =
                  child.getModel().getTransform(deviceType);
               final AffineTransform newChildTransform = child.getTransform();
               if (!oldChildTransform.equals(newChildTransform)) {
                  cmd.addCommand(
                     new SetTransformCommand(
                        child.getModel(),
                        deviceType,
                        newChildTransform));
               }
            }
         }
      }
   }
      

   // Overrides method in ancestor class.
   public void endHandleDrag(Point2D aLocalPoint, PInputEvent aEvent) {
      super.endHandleDrag(aLocalPoint, aEvent);

      if (aEvent.getComponent() instanceof DamaskCanvas) {
         final DamaskCanvas canvas = (DamaskCanvas)aEvent.getComponent(); 
         final MacroCommand command = new ModifyGraphMacroCommand();
         
         for (Iterator i = canvas.getSelectedObjects().iterator();i.hasNext();){
            final InteractionElementView view = (InteractionElementView)i.next();
            if (view.isStretchedWhenResized()) {
               addStretchCommand(view, canvas.getDeviceType(), command);
            }
            else {
               addResizeCommand(view, canvas.getDeviceType(), command);
            }
         }
         
         canvas.getDocument().getCommandQueue().doCommand(canvas, command);
      }

      origPaths.clear();
      origTextBounds.clear();
      origTextSize.clear();
      origBoundsPct.clear();
   }
}
