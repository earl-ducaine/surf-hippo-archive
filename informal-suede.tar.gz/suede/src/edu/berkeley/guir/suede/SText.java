package edu.berkeley.guir.suede;

import java.awt.*;

public class SText extends javax.swing.JTextField
{
    private static final Insets INSETS = new Insets(0,6,0,6);
    
    private Shape bgShape;
    private Color stroke;
    
	public SText(Shape shape)
	{
        bgShape = shape;
        setBounds(bgShape.getBounds());
        setOpaque(false);
        setBorder(javax.swing.BorderFactory.createEmptyBorder());
	}

    public void setStroke(Color c) {
        stroke = c;
    }

    public Insets getInsets() {
        return INSETS;   
    }
    
    public void setShape(Shape shape) {
        bgShape = shape;
        setBounds(bgShape.getBounds());
    }

    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D)g;
        g2d.setColor(Color.white);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.fill(bgShape);
        g2d.setColor(stroke);
        g2d.draw(bgShape);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        super.paintComponent(g);
    }

}