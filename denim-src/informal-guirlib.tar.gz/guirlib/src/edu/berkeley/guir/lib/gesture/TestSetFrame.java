package edu.berkeley.guir.lib.gesture;

import javax.swing.JMenu;

public class TestSetFrame extends GestureSetFrame
{
  /** the set against which this one is recognized */
  GestureSetFrame parentFrame;
  
  public TestSetFrame(GestureSetFrame parent)
  {
    this("test set", parent);
  }

  public TestSetFrame(String name, GestureSetFrame parent)
  {
    super(name);
    parentFrame = parent;

    initFrame();
  }

  protected JMenu constructTestMenu()
  {
    JMenu menu = super.constructTestMenu();
    /* todo
    
    JMenuItem item;
    ActionListener listener;

    item = new JMenuItem("Recognize test set");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
	{
	  if (!parentFrame.train()) {
	    message("Cannot recognize test set unless training succeeds.");
	  }
	  else {
	    Vector[][] m = parentFrame.classifier.
	      classificationMatrix(gestureSetDisplay.getGestureSet());
	    JFrame f =
	      new ClassificationMatrix(m, gestureSetDisplay,
				       parentFrame.gestureSetDisplay.getGestureSet());
	    f.pack();
	    f.show();
	    message("Recognition done");
	  }
	}
    };
    item.addActionListener(listener);
    menu.add(item);
    */
    
    return menu;
  }
  
  /*
  private void buildUI()
  {
    JMenuItem item = new JMenuItem("");
    ActionListener listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	FileDialog fileChooser = 
	  new FileDialog((Frame) statusWindow.getTopLevelAncestor(), "Open",
			 FileDialog.LOAD);
	fileChooser.setFilenameFilter(new myFilenameFilter());
	String directory = (lastDirectory != null) ? lastDirectory : "data";
	fileChooser.setDirectory(directory);
	fileChooser.show();
	String baseName = fileChooser.getFile();
	if (baseName != null) {
	  // ok
	  File f = new File(fileChooser.getDirectory(), baseName);
	  openFile(f);
	}
	else {
	  // cancel
	}
      }
    testMenu.add
  }
  */
}
