package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.beans.*;
import edu.berkeley.guir.lib.web.WebBrowserFrame;
import edu.berkeley.guir.lib.web.WebBrowserPanel;
import java.awt.Dimension;
import java.net.URL;
import javax.swing.SwingUtilities;

public class ReferenceManager {
  protected static final String REFERENCE_FRAME_PROP = "REFERENCE_FRAME";
  protected static ReferenceManager defaultManager = new ReferenceManager();
  protected static final String REFERENCE_MANUAL = "doc/reference.html";
  protected static final String TUTORIAL = "doc/tutorial.html";
  
  protected ReferenceManager() {}

  public static ReferenceManager getManager()
  {
    return defaultManager;
  }
  
  public void showTutorial(MainFrame mainFrame)
  {
    showReference(mainFrame, TUTORIAL, null);
  }
  
  public void showReferenceManual(MainFrame mainFrame)
  {
    showReference(mainFrame, (String) null);
  }
  
  public void showReference(MainFrame mainFrame, Notice notice)
  {
    showReference(mainFrame, REFERENCE_MANUAL, notice.getReferenceTag());
  }
  
  public void showReference(MainFrame mainFrame, String referenceTag)
  {
    showReference(mainFrame, REFERENCE_MANUAL, referenceTag);
  }
  
  public void showReference(final MainFrame mainFrame,
			    final String fileName,
			    final String referenceTag)
  {
    mainFrame.moreBusy();
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
	showReferenceImpl(mainFrame, fileName, referenceTag);
      }
    });
  }
  
  protected void showReferenceImpl(final MainFrame mainFrame,
				   final String fileName,
				   final String refTag)
  {
    WebBrowserFrame browserFrame = (WebBrowserFrame)
      mainFrame.getRootPane().getClientProperty(REFERENCE_FRAME_PROP);
    if (browserFrame == null) {
      browserFrame = new WebBrowserFrame();
      //browser.pack();
      browserFrame.setSize(new Dimension(800, 800));
      browserFrame.setTitle(mainFrame.getGesturePackage().getName() +
			    " - " + "Reference - quill");
      mainFrame.getRootPane().
	putClientProperty(REFERENCE_FRAME_PROP, browserFrame);
    }
    final URL url = this.getClass().getClassLoader().getResource(fileName);
    if (url == null) {
      mainFrame.message("ERROR: Can't find reference manual (at '" +
			fileName + "').\n");
      mainFrame.lessBusy();
      return;
    }
    final WebBrowserFrame finalBrowserFrame = browserFrame;
    final WebBrowserPanel finalBrowserPanel =
      browserFrame.getWebBrowserPanel();
    PropertyChangeListener l = new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent evt) {
	/*
	System.out.println("propertyChange:");
	if (evt != null) {
	  System.out.println("\t" + evt.getPropertyName());
	  System.out.println("\t" + evt.getOldValue());
	  System.out.println("\t" + evt.getNewValue());
	}
	else {
	  System.out.println("\tnull");
	}
	System.out.println("--------------------");
	debug.printStackTrace(System.out);
	System.out.println("--------------------");
	*/
	try {
	  finalBrowserPanel.
	  removePropertyChangeListener(WebBrowserPanel.
				       NEW_PAGE_LOADED_EVENT, this);
	  // makes it the height of the whole screen :-(
	  //finalBrowserFrame.pack();
	  finalBrowserFrame.setVisible(true);
	  finalBrowserFrame.toFront();
	  if (refTag != null) {
	    finalBrowserPanel.scrollToReference(refTag);
	  }
	}
	finally {
	  mainFrame.lessBusy();
	}
      } 
    };
    
    finalBrowserPanel.
      addPropertyChangeListener(WebBrowserPanel.NEW_PAGE_LOADED_EVENT, l);

    String oldUrl = finalBrowserPanel.getCurrentUrl();
    //System.out.println("Setting url: " + url);
    finalBrowserPanel.goToUrl(url);
    //System.out.println("url set");
    String newUrl = finalBrowserPanel.getCurrentUrl();
    if (newUrl.equals(oldUrl)) {
      //System.out.println("manual prop change");
      l.propertyChange(null);
    }
  }

  public static String getFeatureTag(Class featureClass)
  {
    String wholeName = featureClass.getName();
    int lastDot = wholeName.lastIndexOf('.');
    return wholeName.substring(lastDot+1);
  }
}
