package edu.berkeley.guir.damask.view.event;

import java.awt.event.InputEvent;
import java.awt.geom.Point2D;

import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.event.PDragSequenceEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;

/** 
 * Handles mouse events related to the Hand tool.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  10-07-2004 James Lin
 *                               Created PanningHandEventHandler
 * </pre>
 *
 * @author  James Lin
 * @version Version 1.0.0, 10-07-2004
 */
public class PanningHandEventHandler extends PDragSequenceEventHandler {
   
   private Point2D lastPosition;
   
   public PanningHandEventHandler() {
      getEventFilter().setAndMask(InputEvent.BUTTON1_MASK);
   }

   public void startDrag(PInputEvent e) {
      super.startDrag(e);
      lastPosition = e.getCanvasPosition();
   }

   public void drag(PInputEvent e) {
      super.drag(e);
      
      final Point2D position = e.getCanvasPosition();
      final PCamera camera = e.getTopCamera();
      final double cameraScale = camera.getViewScale();
      
      final double dx = position.getX() - lastPosition.getX();
      final double dy = position.getY() - lastPosition.getY();
      camera.translateView(dx / cameraScale, dy / cameraScale);
      lastPosition = position;
   }
}
