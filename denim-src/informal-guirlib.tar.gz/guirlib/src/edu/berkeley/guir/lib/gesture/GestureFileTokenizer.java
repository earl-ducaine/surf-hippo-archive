package edu.berkeley.guir.lib.gesture;

import java.io.StreamTokenizer;
import java.io.Reader;

public class GestureFileTokenizer extends StreamTokenizer {
  public GestureFileTokenizer(Reader r)
  {
    super(r);
    whitespaceChars(0, ' ');
    wordChars('!', '~'); // all letters, numbers, & punctuation
    wordChars(128 + 32, 255);
  }
}
