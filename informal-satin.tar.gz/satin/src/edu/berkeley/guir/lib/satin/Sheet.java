//// See bottom of file for software license

package edu.berkeley.guir.lib.satin;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import java.awt.image.*;
import javax.swing.undo.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.util.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.satin.view.*;

/**
 * Essentially a SATIN Panel. The Panel contains patches and screen objects.
 * <P>
 * There are a number of ways of configuring how the Sheet handles strokes by
 * default. They include:
 * <UL>
 *    <LI>{@link #setEnabled(boolean)} sets whether the Sheet handles any
 *        strokes at all. This can be used to temporarily disable strokes.
 *        You can check the current enabled status by calling
 *        {@link #isEnabled()}.
 *    <LI>You can set whether the Sheet completely ignores strokes created by
 *        the left, middle, or right button by calling
 *        {@link #setAcceptLeftButton(boolean)},
 *        {@link #setAcceptMiddleButton(boolean)}, or
 *        {@link #setAcceptRightButton(boolean)}.
 *    <LI>You can set whether the Sheet draws strokes created by
 *        the left, middle, or right button by calling
 *        {@link #setDrawLeftButtonStrokes(boolean)},
 *        {@link #setDrawMiddleButtonStrokes(boolean)}, or
 *        {@link #setDrawRightButtonStrokes(boolean)}. Of course, this only
 *        works if the strokes are accepted in the first place (see above).
 *    <LI>You can set whether the Sheet adds strokes created by
 *        the left, middle, or right button by calling
 *        {@link #setAddLeftButtonStrokes(boolean)},
 *        {@link #setAddMiddleButtonStrokes(boolean)}, or
 *        {@link #setAddRightButtonStrokes(boolean)}.
 * </UL>
 *
 * <P>
 * To change the background color, use
 * {@link #setBackground(Color) setBackground(Color)} just like a normal
 * JComponent.
 *
 * <P>
 * Be very careful about calling {@link Component#repaint() repaint}, as that
 * may cause strange painting errors, especially during animation. It's safer
 * to use the {@link #damage(int)} methods included in this class.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, May 19 1998, JH
 *               Created
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.1.0, Nov 20 2000, JH
 *               Added methods setLeftCurrentStlye() and setRightCurrentStyle()
 *               to set how strokes look while being rendered.
 * 			   - SATIN-v2.1-2,   Nov 22 2002, YL
 *                Add render system to Sheet
 *                Rebuilt double buffering, get rid of swing's double buffer to get more control to optimize render
 * 			   - SATIN-v2.1-2,   Jan 27 2003  YL
 *                Fixed the bug of stackoverflow caused by recursive invocations of damage and paint of component
 *                Solution is to check whether the current render is finished, if not, using idle-render, otherwise render immediatly.
 *             - SATIN-v2.1-2,   May 30 2003  YL
 *                commented "synchronized" in paint and paintComponent that can cause deadlock
 * 				
 * 
 * 				 
 * 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.3RC1
 * @version SATIN-v2.1-2.0.0, May 30 2003
 */

public class Sheet
	extends    javax.swing.JPanel
	implements GraphicalObjectGroup,
				  SatinConstants,
				  GraphicalObjectCollection,  //// <- for JavaDoc purposes
				  GraphicalObject,
				  Watchable,
				  Watcher,
				  Shape,
				  StrokeListener {

	//===========================================================================
	//===   CLASS METHODS AND VARIABLES   =======================================

	static final long serialVersionUID = 8577810670053556841L;

	//===   CLASS METHODS AND VARIABLES   =======================================
	//===========================================================================

	/** 
	 * For IDLE Rendering system
	 */
	private boolean isIdleRenderingMode = false;
   
	protected RenderServer renderServer = null;
	protected java.util.Timer renderTimer = null;
	protected int bufferedRenderRequests = 0;

	private boolean isManageSwingPeer = false; 
	
	/**
	 * sheet own double buffer
	 */
	private BufferedImage sBufferedImage = null;
	private boolean isSDoublebufferEnabled = true;
	private boolean isFirstRender = true;
   
	// for performance optimization
	private boolean isPanning = false;
   
	// for checking render process
   
	public static final int paintNotStarted = 0;
	public static final int painting = 1;
	public static final int paintJustFinished = 2;
   
	private int paintProcess = 0;
    
    /**
     * The lock for rendering to the physical screen
     * 
     * It will be unlocked automatically in 5 seconds if 
     * it is not unlocked explicitly.
     */
    private final long lockLimit = 5000;
    private boolean shouldRenderToScreen = true;
    private java.util.Timer unlocker = null;
    class AutomaticUnlock extends TimerTask {
        public void run() {
            shouldRenderToScreen = true;
        }
    }


	//===========================================================================
	//===   CLASS METHODS AND VARIABLES   =======================================

	public static String BACKGROUND_COLOR_PROPERTY = "BACKGROUND_COLOR_PROPERTY";
	public static String BACKGROUND_COLOR_DEFAULT  = "204, 204, 204";

	/**
	 * Name of file describing how strokes drawn with "left" button are rendered.
	 */
	public static String LEFTSTROKE_STYLE_FILE    = "LeftStroke.properties";

	/**
	 * Name of file describing how strokes drawn with "right"
	 * button are rendered.
	 */
	public static String RIGHTSTROKE_STYLE_FILE   = "RightStroke.properties";

	//-----------------------------------------------------------------

	static {
		//// 1. Global inits.
		glprops.setProperty(SATIN_DATA_DIRECTORY_GPROPERTY,
								  SATIN_DATA_DIRECTORY_DEFAULT);

		glprops.setProperty(BACKGROUND_COLOR_PROPERTY,
								  BACKGROUND_COLOR_DEFAULT);

		//// 2. Local inits.

	} // of static init

	//===   CLASS METHODS AND VARIABLES   =======================================
	//===========================================================================



	//===========================================================================
	//===   SHEET GRAPHICALOBJECT GROUP INNER CLASS   ===========================

	/**
	 * This class handles the Graphical Objects in the sheet.
	 * This also handles the repainting.
	 *
	 * <P>
	 * The real reason this class is here is because I really need multiple
	 * inheritance, since Sheet is both a JComponent and a GraphicalObjectGroup.
	 * Since I don't want to rewrite a lot of the code already in
	 * GraphicalObjectGroupImpl, I just delegated a lot of its functions here.
	 *
	 * <P>
	 * Subclassing the GraphicalObjectGroupImpl as an inner class is actually a
	 * really clean solution, giving us the benefits of delegation and
	 * inheritance.
	 */
	public class SheetGraphicalObjectGroup
		extends GraphicalObjectGroupImpl {

		//==============================================================
		//===   CONSTRUCTOR   ==========================================

		public SheetGraphicalObjectGroup() {
			//// 1. Watch ourself.
			super.addWatcher(Sheet.this);
		} // of constructor

		//===   CONSTRUCTOR   ==========================================
		//==============================================================



		//==============================================================
		//===   DAMAGE METHODS   =======================================
      
      
		public void disableDamage() {
			if (Sheet.this != null) {
				Sheet.this.disableDamage();
			}
		} // of disableDamage

		//--------------------------------------------------------------

		public void enableDamage() {
			if (Sheet.this != null) {
				Sheet.this.enableDamage();
			}
		} // of enableDamage

		//--------------------------------------------------------------

		public boolean hasDamageEnabled() {
			if (Sheet.this != null) {
				return (Sheet.this.hasDamageEnabled());
			}
			else {
				return (true);
			}
		} // of hasDamageEnabled

		//--------------------------------------------------------------

		public void damage(int sync) {
			Sheet.this.damage(sync);
		} // of method

		public void damage(int sync, GraphicalObject gob) {
			Sheet.this.damage(sync, gob);
		} // of method

		public void damage(int sync, Rectangle2D rect) {
			Sheet.this.damage(sync, rect);
		} // of method

		public void damage(int sync, Rectangle2D oldRect, Rectangle2D newRect) {
			Sheet.this.damage(sync, oldRect, newRect);
		} // of method

		//===   DAMAGE METHODS   =======================================
		//==============================================================



		//==============================================================
		//===   NOTIFICATION METHODS   =================================

		/**
		 * This is here so that the Sheet can call the original version of
		 * this method.
		 */
		public void superNotify(Watchable w, Object arg) {
			super.onNotify(w, arg);
		} // of notify

		//--------------------------------------------------------------

		/**
		 * This is here so that the Sheet can call the original version of
		 * this method.
		 */
		public void superUpdate(Watchable w, Object arg) {
			super.onUpdate(w, arg);
		} // of update

		//--------------------------------------------------------------

		/**
		 * This is here so that the Sheet can call the original version of
		 * this method.
		 */
		public void superUpdate(Watchable w, String strProperty,
				Object oldVal, Object newVal) {
			super.onUpdate(w, strProperty, oldVal, newVal);
		} // of superUpdate

		//--------------------------------------------------------------

		/**
		 * This is here so that the Sheet can call the original version of
		 * this method.
		 */
		public void superDelete(Watchable w) {
			super.onDelete(w);
		} // of superDelete

		//==============================================================

		public void onNotify(Watchable w, Object arg) {
			Sheet.this.onNotify(w, arg);
		} // of onNotify

		//--------------------------------------------------------------

		public void onUpdate(Watchable w, Object arg) {
			Sheet.this.onUpdate(w, arg);
		} // of onUpdate

		//--------------------------------------------------------------

		public void onUpdate(Watchable w, String strProperty,
				Object oldVal, Object newVal) {
			Sheet.this.onUpdate(w, strProperty, oldVal, newVal);
		} // of superUpdate

		//--------------------------------------------------------------

		public void onDelete(Watchable w) {
			Sheet.this.onDelete(w);
		} // of onDelete

		//===   NOTIFICATION METHODS   =================================
		//==============================================================



		//==============================================================
		//===   HANDLER METHODS   ======================================

		public void preProcessNewStroke(NewStrokeEvent evt) {
			Sheet.this.preProcessNewStroke(evt);
		} // of preProcessNewStroke

		public void superPreProcessNewStroke(NewStrokeEvent evt) {
			super.preProcessNewStroke(evt);
		} // of superPreProcessNewStroke

		//--------------------------------------------------------------

		public void redispatchNewStroke(NewStrokeEvent evt) {
			Sheet.this.redispatchNewStroke(evt);
		} // of redispatchNewStroke

		public void superRedispatchNewStroke(NewStrokeEvent evt) {
			super.redispatchNewStroke(evt);
		} // of superRedispatchNewStroke

		//--------------------------------------------------------------

		public void postProcessNewStroke(NewStrokeEvent evt) {
			Sheet.this.postProcessNewStroke(evt);
		} // of postProcessNewStroke

		public void superPostProcessNewStroke(NewStrokeEvent evt) {
			super.postProcessNewStroke(evt);
		} // of superPostProcessNewStroke

		//--------------------------------------------------------------

		public void handleNewStroke(NewStrokeEvent evt) {
			Sheet.this.handleNewStroke(evt);
		} // of handleNewStroke

		public void superHandleNewStroke(NewStrokeEvent evt) {
			super.handleNewStroke(evt);
		} // of superHandleNewStroke

		//--------------------------------------------------------------

		public void preProcessUpdateStroke(UpdateStrokeEvent evt) {
			Sheet.this.preProcessUpdateStroke(evt);
		} // of preProcessUpdateStroke

		public void superPreProcessUpdateStroke(UpdateStrokeEvent evt) {
			super.preProcessUpdateStroke(evt);
		} // of superPreProcessUpdateStroke

		//--------------------------------------------------------------

		public void redispatchUpdateStroke(UpdateStrokeEvent evt) {
			Sheet.this.redispatchUpdateStroke(evt);
		} // of redispatchUpdateStroke

		public void superRedispatchUpdateStroke(UpdateStrokeEvent evt) {
			super.redispatchUpdateStroke(evt);
		} // of superRedispatchUpdateStroke

		//--------------------------------------------------------------

		public void postProcessUpdateStroke(UpdateStrokeEvent evt) {
			Sheet.this.postProcessUpdateStroke(evt);
		} // of postProcessUpdateStroke

		public void superPostProcessUpdateStroke(UpdateStrokeEvent evt) {
			super.postProcessUpdateStroke(evt);
		} // of superPostProcessUpdateStroke

		//--------------------------------------------------------------

		public void handleUpdateStroke(UpdateStrokeEvent evt) {
			Sheet.this.handleUpdateStroke(evt);
		} // of handleUpdateStroke

		public void superHandleUpdateStroke(UpdateStrokeEvent evt) {
			super.handleUpdateStroke(evt);
		} // of superHandleUpdateStroke

		//--------------------------------------------------------------

		public void preProcessSingleStroke(SingleStrokeEvent evt) {
			Sheet.this.preProcessSingleStroke(evt);
		} // of preProcessSingleStroke

		public void superPreProcessSingleStroke(SingleStrokeEvent evt) {
			super.preProcessSingleStroke(evt);
		} // of superPreProcessSingleStroke

		//--------------------------------------------------------------

		public void redispatchSingleStroke(SingleStrokeEvent evt) {
			Sheet.this.redispatchSingleStroke(evt);
		} // of redispatchSingleStroke

		public void superRedispatchSingleStroke(SingleStrokeEvent evt) {
			super.redispatchSingleStroke(evt);
		} // of superRedispatchSingleStroke

		//--------------------------------------------------------------

		public void postProcessSingleStroke(SingleStrokeEvent evt) {
			Sheet.this.postProcessSingleStroke(evt);
		} // of postProcessSingleStroke

		public void superPostProcessSingleStroke(SingleStrokeEvent evt) {
			super.postProcessSingleStroke(evt);
		} // of superPostProcessSingleStroke

		//--------------------------------------------------------------

		public void handleSingleStroke(SingleStrokeEvent evt) {
			Sheet.this.handleSingleStroke(evt);
		} // of handleSingleStroke

		public void superHandleSingleStroke(SingleStrokeEvent evt) {
			super.handleSingleStroke(evt);
		} // of superHandleSingleStroke

		//===   HANDLER METHODS   ======================================
		//==============================================================



		//==============================================================
		//===   PARENTAL METHODS   =====================================

		public Sheet getSheet() {
			return Sheet.this;
		} // of getSheet

		//===   PARENTAL METHODS   =====================================
		//==============================================================



		//==============================================================
		//===   LOCATION METHODS   =====================================

		////
		//// Basically, ignore all methods that will cause us to move around
		//// or change our bounds. We ALWAYS want our top-left corner to be
		//// (0, 0).
		////

		//--------------------------------------------------------------

		public void setBoundingPoints2D(int cdsys, Shape s) {
			//// ignore
		} // of setLocalBoundingPoints

		//--------------------------------------------------------------

		public Rectangle2D getCollectionBounds2D(int cdsys) {
			return (Sheet.this.getBounds());
		} // of method

		//--------------------------------------------------------------

		public Rectangle2D getCollectionBounds2D(int cdsys, Rectangle2D rect) {
			if (rect == null) {
				rect = new Rectangle2D.Float();
			}

			rect.setRect(Sheet.this.getBounds());

			return (rect);
		} // of method

		//--------------------------------------------------------------

		protected void updateBoundingPoints() {
			//// do nothing, our bounds are already set.
		} // of method

		//--------------------------------------------------------------

		/**
		 * Our bounds is always the size of the Sheet.
		 */
		public Polygon2D getBoundingPoints2D(int cdsys) {
			return (getBoundingPoints2D(cdsys, null, null));
		} // of method

		//--------------------------------------------------------------

		/**
		 * Our bounds is always the size of the Sheet.
		 */
		public Polygon2D getBoundingPoints2D(int cdsys, AffineTransform tx,
														 Polygon2D poly) {
			if (poly == null) {
				poly = new Polygon2D();
			}

			switch (cdsys) {
				case COORD_LOCAL:
					poly.setToShape(getBounds2D(COORD_ABS));
					break;
				case COORD_REL:
					poly.setToShape(getBounds2D(COORD_ABS));
					break;
				case COORD_ABS:
					poly.setToShape(getBounds2D(COORD_ABS));
					break;
			}

			return (poly);
		} // of method

		//--------------------------------------------------------------

		/**
		 * Our bounds is the coordinate system.
		 */
		public Rectangle2D getBounds2D(int cdsys) {
			return (getBounds2D(cdsys, null, null));
		} // of method

		//--------------------------------------------------------------

		public Rectangle2D getBounds2D(int cdsys, AffineTransform tx,
												 Rectangle2D rect) {
			if (rect == null) {
				rect = new Rectangle2D.Float();
			}

			switch (cdsys) {
				case COORD_LOCAL:
					Polygon2D p = getBoundingPoints2D(COORD_ABS);
					p.transform(Sheet.this.getInverseTransform(COORD_REL));
					rect.setRect(p.getBounds2D());
					break;
				case COORD_REL:
					//// same as absolute
				case COORD_ABS:
					rect.setRect(0,                     0,
									 Sheet.this.getWidth(), Sheet.this.getHeight());
					break;
				default:
					throw new RuntimeException("What the heck did you pass in?");
			}

			return (rect);
		} // of method

		//===   LOCATION METHODS   =====================================
		//==============================================================



		//==============================================================
		//===   GRAPHICAL OBJECT SHAPE METHODS   =======================

		public boolean shapeContains(GraphicalObject gob) {
			return (Sheet.this.shapeContains(gob));
		} // of method

		public boolean shapeContains(int cdsys, Point2D pt) {
			return (Sheet.this.shapeContains(cdsys, pt));
		} // of method

		public boolean shapeContains(int cdsys, double x, double y) {
			return (Sheet.this.shapeContains(cdsys, x, y));
		} // of method

		public boolean shapeContains(int cdsys, Shape s) {
			return (Sheet.this.shapeContains(cdsys, s));
		} // of method

		public boolean shapeIntersects(GraphicalObject gob) {
			return (Sheet.this.shapeIntersects(gob));
		} // of method

		public boolean shapeIntersects(int cdsys, Shape s) {
			return (Sheet.this.shapeIntersects(cdsys, s));
		} // of method

		//===   GRAPHICAL OBJECT SHAPE METHODS   =======================
		//==============================================================



		//==============================================================
		//===   SHAPE METHODS   ========================================

		public boolean contains(double x, double y) {
			return (Sheet.this.contains(x, y));
		} // of contains

		//--------------------------------------------------------------

		public boolean contains(double x, double y, double w, double h) {
			return (Sheet.this.contains(x, y, w, h));
		} // of contains

		//--------------------------------------------------------------

		public boolean contains(Point2D p) {
			return (Sheet.this.contains(p));
		} // of contains

		//--------------------------------------------------------------

		public boolean contains(Rectangle2D r) {
			return (Sheet.this.contains(r));
		} // of contains

		//--------------------------------------------------------------

		public Rectangle2D getBounds2D() {
			return (Sheet.this.getBounds2D());
		} // of getBounds2D

		public void setTransform (AffineTransform trans){
			//check for 0 scale factors and remove any that exist
			if (trans.getScaleX() == 0 ||
				 trans.getScaleY() == 0){
				 System.err.println("ERROR setTransform (AffineTransform): AffineTransform cannot have a 0 element on diagonal");

				 ////set 0 scale factors to 1
				 trans = new AffineTransform(trans.getScaleX() != 0 ?
													  trans.getScaleX(): 1.0,
													  trans.getShearY(),
													  trans.getShearX(),
													  trans.getScaleY() !=0 ?
													  trans.getScaleY() : 1.0,
													  trans.getTranslateX(),
													  trans.getTranslateY());
			}

			super.setTransform(trans);
		}
		//--------------------------------------------------------------

		public PathIterator getPathIterator(AffineTransform at) {
			return (super.getPathIterator(at));
		} // of getPathIterator

		//--------------------------------------------------------------

		public PathIterator getPathIterator(AffineTransform at, double flatness) {
			return (super.getPathIterator(at, flatness));
		} // of getPathIterator

		//--------------------------------------------------------------

		public boolean intersects(double x, double y, double w, double h) {
			return (Sheet.this.intersects(x, y, w, h));
		} // of intersects

		//--------------------------------------------------------------

		public boolean intersects(Rectangle2D r) {
			return (Sheet.this.intersects(r));
		} // of intersects

		//===   SHAPE METHODS   ========================================
		//==============================================================

	} // of inner class

	//===   SHEET GRAPHICALOBJECT GROUP INNER CLASS   ===========================
	//===========================================================================



	//===========================================================================
	//===   EVENT LISTENERS   ===================================================

	/**
	 * Called when the user undoes an action by keyboard.
	 */
	protected synchronized void undoInternal() {
		try {
			cmdqueue.undo();
		}
		catch (CannotUndoException e) {
			JOptionPane.showMessageDialog(Sheet.this,
					"Beginning of history: nothing to undo",
					"Error during undo",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Called when the user redoes an action by keyboard.
	 */
	protected synchronized void redoInternal() {
		try {
			cmdqueue.redo();
		}
		catch (CannotRedoException e) {
			JOptionPane.showMessageDialog(Sheet.this,
					"End of history: nothing to redo",
					"Error during redo",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Called when the user pastes by keyboard.
	 */
	protected void pasteInternal() {
		cmdqueue.doCommand(new PasteCommand(Sheet.this));
	}


	/**
	 * Called when the user cuts by keyboard.
	 */
	protected void cutInternal() {
		Iterator it = cmdsubsys.getSelected();
		cmdqueue.doCommand(new CutCommand(it));
	}


	/**
	 * Called when the user copies by keyboard.
	 */
	protected void copyInternal() {
		Iterator it = cmdsubsys.getSelected();
		cmdqueue.doCommand(new CopyCommand(it));
	}


	/**
	 * Called when the user deletes by keyboard.
	 */
	protected void deleteInternal() {
		Iterator it = cmdsubsys.getSelected();
		cmdqueue.doCommand(new DeleteCommand(it));
	}


	/**
	 * Some debugging and standard keys.
	 */
	class InternalKeyListener
		extends KeyAdapter {

		public void keyReleased(KeyEvent evt) {
			if (GOBWithFocus != null) {
				if (GOBWithFocus instanceof GObJComponentWrapper) {
					//debug.println("The component with focus is now "+DenimUtils.toShortString(GOBWithFocus));
					((GObJComponentWrapper)GOBWithFocus).keyEventDispatcher(evt);
				}
			}
		}

		public void keyTyped(KeyEvent evt) {
			if (GOBWithFocus != null) {
				if (GOBWithFocus instanceof GObJComponentWrapper) {
					//debug.println("The component with focus is now "+DenimUtils.toShortString(GOBWithFocus));
					((GObJComponentWrapper)GOBWithFocus).keyEventDispatcher(evt);
				}
			}
		}

		public void keyPressed(KeyEvent evt) {
			if (GOBWithFocus != null) {
				if (GOBWithFocus instanceof GObJComponentWrapper) {
					//debug.println("The component with focus is now "+DenimUtils.toShortString(GOBWithFocus));
					((GObJComponentWrapper)GOBWithFocus).keyEventDispatcher(evt);
				}
			}
			else {
				int dx    = 0;
				int dy    = 0;
				int stepx = Sheet.this.getWidth()  / 4;
				int stepy = Sheet.this.getHeight() / 4;

				switch (evt.getKeyCode()) {

					//// Visual Debug - Ctrl-Alt-D
				case KeyEvent.VK_D:
					if (evt.isAltDown() && evt.isControlDown()) {
						GraphicalObjectImpl.setClassDebugProperty
							(!GraphicalObjectImpl.getClassDebugProperty());
						Sheet.this.damage(DAMAGE_LATER);
					}
					break;

					//// Debug Window - Ctrl-Alt-W
				case KeyEvent.VK_W:
					if (evt.isAltDown() && evt.isControlDown()) {
						Debug.setUseWindow(true);
					}
					break;

					//// Debug Window - Dump Undo/Redo History Contents
				case KeyEvent.VK_H:
					if (evt.isAltDown() && evt.isControlDown()) {
			cmdqueue.dump();
					}
					break;

					//// Pan - Up, down, left, right
				case KeyEvent.VK_UP:
					dy = -stepy;
					break;
				case KeyEvent.VK_DOWN:
					dy = +stepy;
					break;
				case KeyEvent.VK_LEFT:
					dx = -stepx;
					break;
				case KeyEvent.VK_RIGHT:
					dx = +stepx;
					break;

				case KeyEvent.VK_BACK_SPACE:
				case KeyEvent.VK_DELETE:
					//// Cut - Ctrl-X (Mac: Command-Z) or Shift-Del
					if (evt.isShiftDown()) {
						cutInternal();
					}
					//// Delete - Del or Backspace
					else {
						deleteInternal();
					}
					break;

					//// Cut - Ctrl-X (Mac: Command-Z) or Shift-Del
				case KeyEvent.VK_X:
					if (evt.isControlDown() || evt.isMetaDown()) {
						cutInternal();
					}
					break;

					//// Copy - Ctrl-C (Mac: Command-C) or Ctrl-Ins
				case KeyEvent.VK_C:
					if (evt.isControlDown() || evt.isMetaDown()) {
						copyInternal();
					}
					break;

				case KeyEvent.VK_INSERT:
					//// Copy - Ctrl-C (Mac: Command-C) or Ctrl-Ins
					if (evt.isControlDown() || evt.isMetaDown()) {
						copyInternal();
					}
					//// Paste  - Ctrl-V (Mac: Command-V) or Shift-Ins
					else if (evt.isShiftDown()) {
						pasteInternal();
					}
					break;

					//// Paste  - Ctrl-V (Mac: Command-V) or Shift-Ins
				case KeyEvent.VK_V:
					if (evt.isControlDown() || evt.isMetaDown()) {
						pasteInternal();
					}
					break;

					/// Redo - Ctrl-Y (Mac: Command-Y)
				case KeyEvent.VK_Y:
					if (evt.isControlDown() || evt.isMetaDown()) {
						redoInternal();
					}
					break;

					/// Undo - Ctrl-Z (Mac: Command-Z)
				case KeyEvent.VK_Z:
					if (evt.isControlDown() || evt.isMetaDown()) {
						undoInternal();
					}
					break;
				}

				//// Do animations
				if (dx != 0 || dy != 0) {
					AffineTransform   tx;
					AffineTransform[] txArray;
					int               numFrm = 5;

					tx      = AffineTransform.getTranslateInstance(dx, dy);
					txArray = AffineTransformLib.animateLinearly(tx, numFrm);
					GraphicalObjectLib.animate(Sheet.this, txArray);
				}
			}
		} // of method

	} // of inner class

	//===========================================================================

	/**
	 * Set the input focus to the sheet if we draw in it.
	 */
	class InternalMouseListener
		extends MouseAdapter {
		 public void mouseClicked(MouseEvent e) {
		  setGobWithFocus(new Point(e.getX(), e.getY()));
	  }

		public void mousePressed(MouseEvent evt) {
			Sheet.this.requestFocus();
		} // of method

		public void mouseEntered(MouseEvent evt) {
			setRepaintManager();
		}

	} // of inner class


	//===========================================================================

	/**
	 * Repaint manager used to intercept refresh calls and forward it to
	 * appropriate GOB
	 */
	 public class DenimRepaintManager extends RepaintManager {
		public synchronized void addDirtyRegion(JComponent c, int x, int y, int w, int h) {
			Object wrapper;
			wrapper = c.getParent();
			if(wrapper == swingWrapper) {
				if (GOBWithFocus != null) {
					if(((GraphicalObjectImpl)GOBWithFocus).isRenderFinished())
						GOBWithFocus.damage(DAMAGE_NOW);
					else
						GOBWithFocus.damage(DAMAGE_IDLE);
				}
			}
			super.addDirtyRegion(c,x,y,w,h);
		}
	} // of inner class




	//===   EVENT LISTENERS   ===================================================
	//===========================================================================



	//===========================================================================
	//===   NONLOCAL INSTANCE VARIABLES   =======================================

	protected StrokeAssembler           asm;             // stroke asm for sheet
	protected TimedStroke               currentStk;      // stroke being drawn
	protected Style                     leftStyle;       // left stroke style
	protected float                     leftLineWidth;   // left line width
	protected Style                     rightStyle;      // right stroke style
	protected float                     rightLineWidth;  // right line width

	protected boolean                   flagDrawCurrent; // draw current stroke?
	protected boolean                   flagDamage;

	protected SheetGraphicalObjectGroup gobs;            // collection of GObs
	protected Style                     selectedStyle;   // selected GObs style

	protected Watchable                 watchable;       // callback object

	protected StrokeEventFilter         drawFilter;      // what strokes to draw
	protected StrokeEventFilter         addFilter;       // what strokes to add

	protected transient int             damageCount = 0;
	protected transient SatinGraphics   graphics    = new SatinGraphics();

	protected GraphicalObject           GOBWithFocus;    // which GOB has focus
	protected JComponent                swingWrapper = new JComponent(){};
																		  // a 0x0 JComponent
	protected DenimRepaintManager       repaintManager;
	protected boolean                   keepJavaAntialiasing = false;
	private   GlobalID                  globalID = null; // tuple for distributed apps

	//-----------------------------------------------------------------

	//// Used for calculating damage bounds
	static Rectangle repaintRect = new Rectangle();

	//===   NONLOCAL INSTANCE VARIABLES   =======================================
	//===========================================================================

	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	/**
	 * Default constructor.
	 */
	public Sheet() {
	  
	  //// 0. create render server
	  renderServer = new RenderServer(this);
	  
		//// 1. Setup the command subsystem.
		cmdsubsys.initializeCommandSubsystem(this);
		cmdsubsys.addWatcher(this);
		cmdsubsys.clearSelected();

		//// 2. Setup the tree of objects.
		gobs = new SheetGraphicalObjectGroup();
		setSize(getBounds().width, getBounds().height);

		//// 3. Create a new stroke assember. This also automatically adds
		////    itself as a mouse listener and mouse motion listener.
		asm = new StrokeAssembler(this);
      
      

		//// 4. Set up listeners on ourself.
		addMouseListener(new InternalMouseListener());
		addKeyListener(new InternalKeyListener());

		//// 5. Set up the current styles.
		setLeftCurrentStyle(new Style(LEFTSTROKE_STYLE_FILE,
										 new TimedStroke().getStyle()));
		setRightCurrentStyle(new Style(RIGHTSTROKE_STYLE_FILE,
										 new TimedStroke().getStyle()));

		//// 6. Set up the select style.
		selectedStyle = new Style();
		selectedStyle.setDrawColor(Color.black);
		selectedStyle.setFillColor(Color.black);

		//// 7. Setup our callback.
		watchable = new WatchableImpl();

		//// 8. Setup Swing double buffering.
		setDoubleBuffered(false);// set double buffer to false because it conflicts with our own double buffer
     
		addMouseListener(new InternalMouseListener());

		//// 9. Allow damage.
		flagDamage = true;

		//// 10. Setup the draw and add stroke filters.
		drawFilter = new BasicStrokeEventFilter();
		addFilter  = new BasicStrokeEventFilter();

		//// 11. Setup our background color.
		try {
			String strColor   = (String) glprops.getProperty(BACKGROUND_COLOR_PROPERTY);
			Color  bkgrdColor = ParserLib.parseColor(strColor);
			setBackground(bkgrdColor);
		}
		catch(Exception e) {
			//// ignore
		}

		//// 12. Set up bug workarounds.
		TimedStroke.setDrawFix(true);

		//// 13. Set the focus on us.
		requestFocus();

		//// 14. Init GOBWithFocus
		GOBWithFocus = null;

		//// 15.  Setup the swing wrapper
		swingWrapper.setVisible(true);
		swingWrapper.setSize(0, 0);
		this.add(swingWrapper);

		//// 16.  set the repaintmanager
		repaintManager = new DenimRepaintManager();
      
     
	} // of default constructor

	//-----------------------------------------------------------------

	/**
	 * Create a Sheet with the specified width and height.
	 *
	 * @param w is the width of the Sheet.
	 * @param h is the height of the Sheet.
	 */
	public Sheet(int w, int h) {
		this();
		setBoundingPoints2D(COORD_LOCAL, new Rectangle(0, 0, w, h));
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Create a Sheet with the specified width and height dimensions.
	 *
	 * @param dim is the width and height dimensions.
	 */
	public Sheet(Dimension dim) {
		this(dim.width, dim.height);
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Set this sheet to be the same as the specified sheet. Handy for
	 * deserialization. Don't use the passed-in variable after calling
	 * this method, as it will be stripped bare.
	 *
	 * @param sheet is the Sheet that contains the objects that we want.
	 *              Don't use variable sheet after calling this method,
	 *              since many of the variables will be shared, and since
	 *              we move all of the GraphicalObjects from the passed-in
	 *              sheet to this sheet.
	 */
	public void setSheet(Sheet sheet) {
		//// 1. Copy each of the values over to the current sheet.
		asm            = sheet.asm;
		leftStyle      = sheet.leftStyle;
		rightStyle     = sheet.rightStyle;
		leftLineWidth  = sheet.leftLineWidth;
		rightLineWidth = sheet.rightLineWidth;
		selectedStyle  = sheet.selectedStyle;
		watchable      = sheet.watchable;

		//// 2. Copy each of the GraphicalObjects in the passed-in sheet
		////    first to an array, and then to this sheet. The indirection
		////    is necessary in order to avoid ConcurrentModificationErrors
		////    in the iterator.
		Iterator        it   = sheet.gobs.getForwardIterator();
		int             size = sheet.gobs.numElements();
		Object[]        objs = new Object[size];
		int             i    = 0;

		gobs.clear();

		while (it.hasNext()) {
			objs[i] = it.next();
			i++;
		}

		for (i = 0; i < size; i++) {
			gobs.addToBack((GraphicalObject) objs[i]);
		}

		damage(DAMAGE_LATER);

	} // of setSheet

	//===   CONSTRUCTORS   ======================================================
	//===========================================================================


	//===========================================================================
	//===   METHODS RELATED TO EMBEDDED JCOMPONENTS   ===========================

	public void setRepaintManager() {
		RepaintManager.setCurrentManager(repaintManager);
	}

	//===========================================================================

	public void addToSwingWrapper(GraphicalObject gob) {
		swingWrapper.add(((GObJComponentWrapper)gob).getComponent());
	}

	//-----------------------------------------------------------------

	public void deleteFromSwingWrapper(GraphicalObject gob) {
		swingWrapper.remove(((GObJComponentWrapper)gob).getComponent());
	}

	//===========================================================================

	public void setResizeMode(int m) {
		gobs.setResizeMode(m);
	}

	//-----------------------------------------------------------------

	public int getResizeMode() {
		return gobs.getResizeMode();
	}

	//===========================================================================

	public void setGobWithFocus(GraphicalObject g) {
	  if (g != null) {
		 GOBWithFocus = g;
		 ((GObJComponentWrapper)GOBWithFocus).getComponent().requestFocus();
	  }
	}

	//-----------------------------------------------------------------

	/**
	 * Set the gob with focus
	 */
	private void setGobWithFocus(Point pt) {
	  GOBWithFocus = null;
		GraphicalObjectCollection gobcol = new GraphicalObjectCollectionImpl();

		//// 1. Get all deep graphical objects near the point within 0 points.
		getGraphicalObjects(COORD_ABS, pt, SatinConstants.ALL, SatinConstants.DEEP, SatinConstants.NEAR, 1, gobcol);

		//// 2. Get the object that _strictly_ contains the point.
		Iterator        it = gobcol.getForwardIterator();
		GraphicalObject gob = null;
		float           gobDist = Float.MAX_VALUE;
		float           dist;
		//debug.println("************stack trace*****************");
		//debug.printStackTrace();
		//debug.println("************stack trace*****************");

		while (it.hasNext()) {
			gob  = (GraphicalObject) it.next();
			if ((gob.isVisible()) && (gob instanceof GObJComponentWrapper)) {
				dist = gob.minDistance(COORD_ABS, pt);
				if (dist < gobDist) {
					gobDist = dist;
					GOBWithFocus = gob;
				}
			}
		}
		if (GOBWithFocus != null) {
			//debug.println("*****************GOBWithFocus is not null********************");
			((GObJComponentWrapper)GOBWithFocus).getComponent().requestFocus();
		}
		else {
			//debug.println("*****************GOBWithFocus is null********************");
		}
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject getGobWithFocus() {
		return GOBWithFocus;
	}

	//===   METHODS RELATED TO EMBEDDED JCOMPONENTS   ===========================
	//===========================================================================


	//===========================================================================
	//===   SHEET METHODS   =====================================================

	public void setAutoScroll(boolean flag) {
		asm.setAutoScroll(flag);
	} // of method

	//===========================================================================

	/**
	 * Set whether ink is enabled for this Sheet or not.
	 */
	public void setEnabled(boolean flag) {
		asm.setEnabled(flag);
	} // of setEnabled

	//-----------------------------------------------------------------

	/**
	 * Check whether ink is enabled for this Sheet or not.
	 */
	public boolean isEnabled() {
		return (asm.isEnabled());
	} // of isEnabled

	//===========================================================================

	/**
	 * Set whether any left-button strokes will be dispatched at all.
	 */
	public void setAcceptLeftButton(boolean flag) {
		asm.setAcceptLeftButton(flag);
	} // of setAcceptLeftButton

	//-----------------------------------------------------------------

	/**
	 * Set whether any middle-button strokes will be dispatched at all.
	 */
	public void setAcceptMiddleButton(boolean flag) {
		asm.setAcceptMiddleButton(flag);
	} // of setAcceptMiddleButton

	//-----------------------------------------------------------------

	/**
	 * Set whether any right-button strokes will be dispatched at all.
	 */
	public void setAcceptRightButton(boolean flag) {
		asm.setAcceptRightButton(flag);
	} // of setAcceptRightButton

	//===========================================================================

	/**
	 * Set whether left-button strokes will be drawn.
	 */
	public void setDrawLeftButtonStrokes(boolean flag) {
		drawFilter.setAcceptLeftButton(flag);
	} // of setDrawLeftButtonStrokes

	//-----------------------------------------------------------------

	/**
	 * Set whether middle-button strokes will be drawn.
	 */
	public void setDrawMiddleButtonStrokes(boolean flag) {
		drawFilter.setAcceptMiddleButton(flag);
	} // of setDrawMiddleButtonStrokes

	//-----------------------------------------------------------------

	/**
	 * Set whether right-button strokes will be drawn.
	 */
	public void setDrawRightButtonStrokes(boolean flag) {
		drawFilter.setAcceptRightButton(flag);
	} // of setDrawRightButtonStrokes

	//===========================================================================

	/**
	 * Set whether left-button strokes will be added.
	 */
	public void setAddLeftButtonStrokes(boolean flag) {
		addFilter.setAcceptLeftButton(flag);
	} // of setAddLeftButtonStrokes

	//-----------------------------------------------------------------

	/**
	 * Set whether middle-button strokes will be added.
	 */
	public void setAddMiddleButtonStrokes(boolean flag) {
		addFilter.setAcceptMiddleButton(flag);
	} // of setAddMiddleButtonStrokes

	//-----------------------------------------------------------------

	/**
	 * Set whether right-button strokes will be added.
	 */
	public void setAddRightButtonStrokes(boolean flag) {
		addFilter.setAcceptRightButton(flag);
	} // of setAddRightButtonStrokes

	//===   SHEET METHODS   =====================================================
	//===========================================================================



	//===========================================================================
	//===   ID METHODS   ========================================================

	public long getUniqueID() {
		return (gobs.getUniqueID());
	} // of getUniqueID

	//-----------------------------------------------------------------

	public void setUniqueID(long newID) {
		gobs.setUniqueID(newID);
	} // of setUniqueID

	//===   ID METHODS   ========================================================
	//===========================================================================



	//===========================================================================
	//===   PROPERTY METHODS   ==================================================

	public Iterator getPropertyNames() {
		return (gobs.getPropertyNames());
	} // of method

	//-----------------------------------------------------------------

	public Object getProperty(String strPropertyName) {
		return (gobs.getProperty(strPropertyName));
	} // of method

	public void setProperty(String strPropertyName, Object newVal) {
		gobs.setProperty(strPropertyName, newVal);
	} // of method

	public Object removeProperty(String strPropertyName) {
		return (gobs.removeProperty(strPropertyName));
	} // of method

	//-----------------------------------------------------------------

	public java.util.List getIndexedProperty(String strPropertyName) {
		return (gobs.getIndexedProperty(strPropertyName));
	} // of method

	public Object getIndexedProperty(String strPropertyName, int index) {
		return (gobs.getIndexedProperty(strPropertyName, index));
	} // of method

	public void
	setIndexedProperty(String strPropertyName, int index, Object newVal) {
		gobs.setIndexedProperty(strPropertyName, index, newVal);
	} // of method

	public void addIndexedProperty(String strPropertyName, Object newVal) {
		gobs.addIndexedProperty(strPropertyName, newVal);
	} // of method

	public Object removeIndexedProperty(String strPropertyName, int index) {
		return (gobs.removeIndexedProperty(strPropertyName, index));
	} // of method

	public java.util.List removeIndexedProperty(String strPropertyName) {
		return (gobs.removeIndexedProperty(strPropertyName));
	} // of method

	public void clearIndexedProperty(String strPropertyName) {
		gobs.clearIndexedProperty(strPropertyName);
	} // of method

	//===   PROPERTY METHODS   ==================================================
	//===========================================================================



	//===========================================================================
	//===   VIEW METHODS   ======================================================

	public View getView() {
		return (gobs.getView());
	} // of getView

	//-----------------------------------------------------------------

	public void setView(View v) {
		gobs.setView(v);
	} // of setView
   
	//-----------------------------------------------------------------
	
	public void setMangeSwingPeer(boolean b) {
		isManageSwingPeer = b;
	}

	//===   VIEW METHODS   ======================================================
	//===========================================================================



	//===========================================================================
	//===   INTERPRETER METHODS   ===============================================

	public Interpreter getGestureInterpreter() {
		return (gobs.getGestureInterpreter());
	} // of getGestureInterpreter

	public Interpreter setGestureInterpreter(Interpreter intrp) {
		return (gobs.setGestureInterpreter(intrp));
	} // of getGestureInterpreter

	//-----------------------------------------------------------------

	public Interpreter getInkInterpreter() {
		return (gobs.getInkInterpreter());
	} // of getInkInterpreter

	public Interpreter setInkInterpreter(Interpreter intrp) {
		return (gobs.setInkInterpreter(intrp));
	} // of getInkInterpreter

	//-----------------------------------------------------------------
	//===   INTERPRETER METHODS   ===============================================
	//===========================================================================



	//===========================================================================
	//===   STYLE METHODS   =====================================================

	public Style setStyle(Style newStyle) {
		return (gobs.setStyle(newStyle));
	} // of method


	public Style getStyle() {
		return (gobs.getStyle());
	} // of method


	public Style getStyleRef() {
		return (gobs.getStyleRef());
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Set the style for how the current stroke is drawn when left button is
	 * down.
	 */
	public void setLeftCurrentStyle(Style newStyle) {
		leftStyle     = (Style) newStyle.clone();
		leftLineWidth = leftStyle.getLineWidth();
	} // of method


	/**
	 * Get a copy of the style for how the current stroke is drawn when left
	 * button is down.
	 */
	public Style getLeftCurrentStyle() {
		return ((Style) leftStyle.clone());
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Set the style for how the current stroke is drawn when the right button
	 * is down.
	 */
	public void setRightCurrentStyle(Style newStyle) {
		rightStyle     = (Style) newStyle.clone();
		rightLineWidth = rightStyle.getLineWidth();
	} // of method


	/**
	 * Get a copy of the style for how the current stroke is drawn when the
	 * right button is down.
	 */
	public Style getRightCurrentStyle() {
		return ((Style) rightStyle.clone());
	} // of method




	//-----------------------------------------------------------------

	/**
	 * Set the style for how the selected objects are drawn.
	 */
	public Style setSelectedStyle(Style newStyle) {
		selectedStyle = (Style) newStyle.clone();
		return (newStyle);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Get the style for how the selected objects are drawn.
	 */
	public Style getSelectedStyle() {
		return ((Style) selectedStyle.clone());
	} // of method

	//===   STYLE METHODS   =====================================================
	//===========================================================================



	//===========================================================================
	//===   GRAPHICALOBJECT LAYER METHODS   =====================================

	public int getRelativeLayer() {
		return (gobs.getRelativeLayer());
	} // of method

	public void setRelativeLayer(int layer) {
		gobs.setRelativeLayer(layer);
	} // of method

	public java.util.List getAbsoluteLayer() {
		return (gobs.getAbsoluteLayer());
	} // of method

	public void bringUpALayer() {
		gobs.bringUpALayer();
	} // of method

	public void bringDownALayer() {
		gobs.bringDownALayer();
	} // of method

	public void bringToTopLayer() {
		gobs.bringToTopLayer();
	} // of method

	public void bringToBottomLayer() {
		gobs.bringToBottomLayer();
	} // of method

	//===   GRAPHICALOBJECT LAYER METHODS   =====================================
	//===========================================================================



	//===========================================================================
	//===   TRANSFORMATION METHODS   ============================================

	public void applyTransform(AffineTransform tr) {
		gobs.applyTransform(tr);
	} // of method

	public void setTransform(AffineTransform tr) {
		gobs.setTransform(tr);
	} // of method

	public AffineTransform getTransformRef() {
		return (gobs.getTransformRef());
	} // of method

	public AffineTransform getTransform(int cdsys) {
		return (gobs.getTransform(cdsys));
	} // of method

	public AffineTransform getTransform(int cdsys, AffineTransform outTx) {
		return (gobs.getTransform(cdsys, outTx));
	} // of method

	public AffineTransform getInverseTransform(int cdsys) {
		return (gobs.getInverseTransform(cdsys));
	} // of method

	public AffineTransform getInverseTransform(int cdsys, AffineTransform tx) {
		return (gobs.getInverseTransform(cdsys, tx));
	} // of method

	//===   TRANSFORMATION METHODS   ============================================
	//===========================================================================



	//===========================================================================
	//===   MISCELLANEOUS LOCATION METHODS   ====================================

	/**
	 * Ignored, since we always have closed bounding points.
	 */
	public void setHasClosedBoundingPoints(boolean flag) {
		//// ignore
	} // of method

	//-----------------------------------------------------------------

	/**
	 * @return true always.
	 */
	public boolean hasClosedBoundingPoints() {
		return (true);
	} // of method

	//-----------------------------------------------------------------

	public float minDistance(int cdsys, double x, double y) {
		return (gobs.minDistance(cdsys, x, y));
	} // of method

	//-----------------------------------------------------------------

	public float minDistance(int cdsys, Point2D pt) {
		return (gobs.minDistance(cdsys, pt));
	} // of method

	//===   MISCELLANEOUS LOCATION METHODS   ====================================
	//===========================================================================



	//===========================================================================
	//===   VIEW ACCESSOR METHODS   =============================================

	public Point2D getLocation2D(int cdsys) {
		return (gobs.getLocation2D(cdsys));
	} // of method

	public Point2D getLocation2D(int cdsys, AffineTransform tx, Point2D pt) {
		return (gobs.getLocation2D(cdsys, tx, pt));
	} // of method

	public Rectangle2D getBounds2D(int cdsys) {
		return (gobs.getBounds2D(cdsys));
	} // of method

	public Rectangle2D getBounds2D(int cdsys, AffineTransform tx,
											 Rectangle2D rect) {
		return (gobs.getBounds2D(cdsys, tx, rect));
	} // of method

	public Polygon2D getBoundingPoints2D(int cdsys) {
		return (gobs.getBoundingPoints2D(cdsys));
	} // of method

	public Polygon2D getBoundingPoints2D(int cdsys, AffineTransform tx,
													 Polygon2D poly) {
		return (gobs.getBoundingPoints2D(cdsys, tx, poly));
	} // of method

	public float getWidth2D(int cdsys) {
		return (gobs.getWidth2D(cdsys));
	} // of method

	public float getHeight2D(int cdsys) {
		return (gobs.getHeight2D(cdsys));
	} // of method

	//-----------------------------------------------------------------

	/** Yes, we contain everything.  */
	public boolean shapeContains(GraphicalObject gob) {
		return (true);
	} // of method

	/** Yes, we contain everything.  */
	public boolean shapeContains(int cdsys, Point2D pt) {
		return (true);
	} // of method

	/** Yes, we contain everything.  */
	public boolean shapeContains(int cdsys, double x, double y) {
		return (true);
	} // of method

	/** Yes, we contain everything.  */
	public boolean shapeContains(int cdsys, Shape s) {
		return (true);
	} // of method

	/** Yes, we intersect everything.  */
	public boolean shapeIntersects(GraphicalObject gob) {
		return (true);
	} // of method

	/** Yes, we intersect everything.  */
	public boolean shapeIntersects(int cdsys, Shape s) {
		return (true);
	} // of method

	//===   VIEW ACCESSOR METHODS   =============================================
	//===========================================================================



	//===========================================================================
	//===   VIEW MODIFIER METHODS   =============================================

	/**
	 * @return false always.
	 */
	public boolean isSelectable() {
		return (false);
	} // of method

	/**
	 * Ignored.
	 */
	public void setSelectable(boolean flag) {
	} // of method

	public void moveTo(int cdsys, double x, double y) {
		gobs.moveTo(cdsys, x, y);
	} // of method

	public void moveTo(int cdsys, double x, double y, double theta) {
		System.out.println("Sheet man, you cain't rotate me!");
	} // of method

	public void moveTo(int cdsys, Point2D pt) {
		gobs.moveTo(cdsys, pt);
	} // of method

	public void moveBy(int cdsys, double dx, double dy) {
		gobs.moveBy(cdsys, dx, dy);
	} // of method

	public void moveBy(int cdsys, Point2D pt) {
		gobs.moveBy(cdsys, pt);
	} // of method

	public void setBoundingPoints2D(int cdsys, Shape s) {
		gobs.setBoundingPoints2D(cdsys, s);
	} // of method

	//===   VIEW MODIFIER METHODS   =============================================
	//===========================================================================



	//===========================================================================
	//===   SHAPE METHODS   =====================================================

	public boolean contains(double x, double y) {
		return (true);
	} // of method


	public boolean contains(double x, double y, double w, double h) {
		return (true);
	} // of method


	public boolean contains(Point2D p) {
		return (true);
	} // of method


	public boolean contains(Rectangle2D r) {
		return (true);
	} // of method

	//-----------------------------------------------------------------

	public Rectangle2D getBounds2D() {
		return (getBounds());
	} // of method

	//-----------------------------------------------------------------

	public PathIterator getPathIterator(AffineTransform at) {
		return (gobs.getPathIterator(at));
	} // of method


	public PathIterator getPathIterator(AffineTransform at, double flatness) {
		return (gobs.getPathIterator(at, flatness));
	} // of method

	//-----------------------------------------------------------------

	public boolean intersects(double x, double y, double w, double h) {
		return (true);
	} // of method


	public boolean intersects(Rectangle2D r) {
		return (true);
	} // of method

	//===   SHAPE METHODS   =====================================================
	//===========================================================================



	//===========================================================================
	//===   DISPATCHING METHODS   ===============================================

	/**
	 * Start dispatching a new stroke.
	 * Renders the stroke if and only if the draw filter accepts this event
	 * (see {@link #setDrawLeftButtonStrokes(boolean)}), and if the event says
	 * it should render (see {@link SatinEvent#setShouldRender(boolean)}).
	 */
	public void onNewStroke(NewStrokeEvent evt) {
   	
		  // for idle rendering 
		  if(renderTimer!=null)
		{
		  renderTimer.cancel();
		  renderTimer = null;
		}
      
      
		evt.appendDispatchee(this.gobs);
      
		//// 0.1. Draw the stroke?
		flagDrawCurrent = true;

		//// 0.2. Save our reference to the current stroke.
//	XXX multiuser strokes functionality needed
		currentStk = evt.getStroke();


		//// 1. Inversely scale the width of the stroke by our zoom factor.
/*
		AffineTransform tx    = getTransformRef();
		float           scale = (float) AffineTransformLib.getScaleFactor(tx);

		//// 2. Modify the current style.
		currentStyle.setLineWidth((float) lineWidth/scale);

		//// 3. Modify the new stroke.
		Style style = currentStk.getStyle();
		style.setLineWidth((float) (style.getLineWidth()/scale));
		currentStk.setStyle(style);
*/


		//// 4. Temporarily set the parent of this stroke.
		currentStk.setParentGroup(this);

		//// 5. Figure out who to dispatch to.
		gobs.onNewStroke(evt);

		flagDrawCurrent = evt.shouldRender() && drawFilter.isEventAccepted(evt);
	} // of method

	//-----------------------------------------------------------------

	public void preProcessNewStroke(NewStrokeEvent evt) {
		gobs.superPreProcessNewStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void redispatchNewStroke(NewStrokeEvent evt) {
		gobs.superRedispatchNewStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void postProcessNewStroke(NewStrokeEvent evt) {
		gobs.superPostProcessNewStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void handleNewStroke(NewStrokeEvent evt) {
		gobs.superHandleNewStroke(evt);
	} // of method

	//===========================================================================

	/**
	 * @see #onNewStroke(NewStrokeEvent)
	 */
	public void onUpdateStroke(UpdateStrokeEvent evt) {
//	XXX multiuser strokes functionality needed
		currentStk = evt.getStroke();

		//// 1. Figure out who to dispatch to.
		////    The handleNewStroke() method should be called for us by the
		////    SheetGraphicalObjectGroup inner class, since we overrided it.
		gobs.onUpdateStroke(evt);

		//// 2. Check if we should render this stroke.
		////    Since adding points automatically calls damage(),
		////    we don't have to do anything else.
		flagDrawCurrent = evt.shouldRender() && drawFilter.isEventAccepted(evt);
	} // of method

	//-----------------------------------------------------------------

	public void preProcessUpdateStroke(UpdateStrokeEvent evt) {
		gobs.superPreProcessUpdateStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void redispatchUpdateStroke(UpdateStrokeEvent evt) {
		gobs.superRedispatchUpdateStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void postProcessUpdateStroke(UpdateStrokeEvent evt) {
		gobs.superPostProcessUpdateStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void handleUpdateStroke(UpdateStrokeEvent evt) {
		gobs.superHandleUpdateStroke(evt);
	} // of method

	//===========================================================================

	/**
	 * @see #onNewStroke(NewStrokeEvent)
	 */
	public void onSingleStroke(SingleStrokeEvent evt) {
//	XXX multiuser strokes functionality needed?
		Rectangle       rect;

		//// 1. Delegate the dispatching to the collection of
		////    Graphical Objects.
		currentStk = evt.getStroke();
		rect       = GraphicalObjectLib.getRenderBounds(currentStk);
		currentStk = null;


		//// 2. Figure out who to dispatch to.
		gobs.onSingleStroke(evt);

		//// 3. Whether we add the stroke or not, we need to redraw, since
		////    the region always needs to be repainted.
		flagDrawCurrent = evt.shouldRender() && drawFilter.isEventAccepted(evt);

		if(this.isIdleRenderingMode)
		{
		  damage(DAMAGE_IDLE, rect);      	
		}
		else
		{
			damage(DAMAGE_LATER, rect);
		}
      
		// for idle rendering
		if(renderTimer == null)
		{
		  renderTimer = new java.util.Timer();
		  renderTimer.schedule(new RenderChecker(this),RenderServer.optimizedInterval);
		}

	} // of method

	//-----------------------------------------------------------------   
 
	public TimedStroke getCurrentStroke() {
		  return currentStk;
	}

	//-----------------------------------------------------------------   
   
	public void clearCurrentStroke() {
		  currentStk = null;
	}
      
  //-----------------------------------------------------------------

	public void preProcessSingleStroke(SingleStrokeEvent evt) {
		gobs.superPreProcessSingleStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void redispatchSingleStroke(SingleStrokeEvent evt) {
		gobs.superRedispatchSingleStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void postProcessSingleStroke(SingleStrokeEvent evt) {
		gobs.superPostProcessSingleStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void handleSingleStroke(SingleStrokeEvent evt) {
		//// 0. Initializations.
		TimedStroke stk = evt.getStroke();

		//// 1.1. Ignore strokes that are too short.
		if (stk.getLength2D(COORD_ABS) < 10) {
			return;
		}

		//// 1.2. Check the add filter.
		if (addFilter.isEventAccepted(evt) == false) {
			return;
		}

		//// 2. Just add the stroke.
		cmdqueue.doCommand(new InsertCommand(this, stk));
	} // of method

	//===   DISPATCHING METHODS   ===============================================
	//===========================================================================

	//===========================================================================
	//===   METHODS OF RENDER SUBSYSTEM ====================================================

	 /**
	  * buffer upcoming render requests no what the types of render requests
	  */

	 public void bufferUpcomingRender(int count) {
      	
			if(count <= 0)
				return;
      		
			bufferedRenderRequests = count;
      	
	 }
    
	 //--------------------------------------------------------------      
          
	 /**
	  * flush all buffered render requests
	  */

	 public void flushRenderRequests() {
      	
		renderServer.flush(DAMAGE_LATER);
		bufferedRenderRequests = 0;
	 }

	 //--------------------------------------------------------------      
        
	 public void setFlushSpeed(double p)
	 {
		renderServer.setFlushSpeed(p);
	 }
   
	 //--------------------------------------------------------------      
    
	 public boolean isIdleRenderingMode() {
		return isIdleRenderingMode;
	 }
    
	 //--------------------------------------------------------------      
    
	 public void setIdleRenderingMode(boolean b) {
		isIdleRenderingMode = b;
	 }

        
	 /**
	  * some controls for realtime render
	  */

	 public void enableRealtimeRender() {
		renderServer.startRealtimeRender();
	 }
    
	 //--------------------------------------------------------------      
        
	 public void disableRealtimeRender() {
		renderServer.endRealtimeRender();
	 }
    
	 /**
	  * functions for customized double buffer
	  */
    
	 public void setSheetDoubleBufferEnabled(boolean b) {
		isSDoublebufferEnabled = b;
	 }

	//--------------------------------------------------------------      
    
	 public boolean isSheetDoubleBufferEnabled() {
		return isSDoublebufferEnabled;
	 }
    
	 //--------------------------------------------------------------      
	 public BufferedImage getBufferedImage() {
		return sBufferedImage;
	 }

    
	 /**
	  * whether the scenegraph should be rendered to screen or internal buffer
	  */
    
	 public boolean isRenderToScreen() {
		return shouldRenderToScreen;
	 }
    
	 public void setRenderToScreen(boolean toScreen) {
    	
		shouldRenderToScreen = toScreen;
    	
		if(toScreen)
		{
			RepaintManager.currentManager(this).setDoubleBufferingEnabled(true);
		}
		else
		{
			RepaintManager.currentManager(this).setDoubleBufferingEnabled(false);    		
		}
        
        if(shouldRenderToScreen==false)
        {
            unlocker = new java.util.Timer();
            unlocker.schedule(new AutomaticUnlock(), lockLimit);
        }
        else
        {
            if(unlocker!=null)
            {
                unlocker.cancel();
                unlocker = null;
            }
        }
	 }


	//===========================================================================
	//===   DAMAGE METHODS   ====================================================

	public void disableDamage() {
		damageCount++;
	} // of method

	//-----------------------------------------------------------------

	public void enableDamage() {
		damageCount--;
		if (damageCount < 0) {
			throw new RuntimeException(
				"Error - unbalanced number of disable/enable damage calls made");
		}
	} // of method

	//-----------------------------------------------------------------

	public boolean hasDamageEnabled() {
		return (damageCount <= 0);
	} // of method

	//===========================================================================

	public void setClipToBounds(boolean flag) {
		gobs.setClipToBounds(flag);
	} // of method

	//-----------------------------------------------------------------

	public boolean isClippedToBounds() {
		return (gobs.isClippedToBounds());
	} // of method

	//===========================================================================

	public void damage(int sync) {
		//// 0. First check if damage is enabled.
		if (hasDamageEnabled() == false) {
			return;
		}

		damage(sync, this);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Damage an area for immediate or optimized repainting.
	 *
	 * @param rect is the region to repaint.
	 */

	 public void damage(int sync, Rectangle2D rect) {
			//// 0. First check if damage is enabled.
			if (hasDamageEnabled() == false) {
				return;
			}
	
			//// 1. Enlarge the rectangle a little.
			repaintRect.x      = (int) (rect.getX()  -   DEFAULT_REPAINT_THRESHOLD);
			repaintRect.y      = (int) (rect.getY()  -   DEFAULT_REPAINT_THRESHOLD);
			repaintRect.width  = (int) (rect.getWidth()  +
												 2*DEFAULT_REPAINT_THRESHOLD);
			repaintRect.height = (int) (rect.getHeight() +
												 2*DEFAULT_REPAINT_THRESHOLD);
	
			// finally, send the render request to render server
			if(bufferedRenderRequests>0)
			{
				bufferedRenderRequests--;
				renderServer.sendARequest(repaintRect, DAMAGE_IDLE);	
			}
			else
				renderServer.sendARequest(repaintRect, sync);

	 } // of method
   
    

	/**
	 * Damage an area for repainting.
	 *
	 * @param gob is the GraphicalObject to repaint.
	 */
	public void damage(int sync, GraphicalObject gob) {
		//// 0. First check if damage is enabled.
		if (hasDamageEnabled() == false) {
			return;
		}

		//// 1. Don't forget to add a little around the edges due to
		////    size of strokes.
		damage(sync, GraphicalObjectLib.getRenderBounds(gob));
	} // of method

	//-----------------------------------------------------------------

	public void damage(int sync, Rectangle2D oldRect, Rectangle2D newRect) {
		//// 0. First check if damage is enabled.
		if (hasDamageEnabled() == false) {
			return;
		}

		Rectangle2D.union(oldRect, newRect, oldRect);
		damage(sync, oldRect);
	} // of method

	//===   DAMAGE METHODS   ====================================================
	//===========================================================================

	//-----------------------------------------------------------------
   
	public boolean isSheetPanning() {
		return isPanning;
	}

	public void setSheetPanning(boolean b) {
		isPanning = b;
	}
   
	//===========================================================================
	//===   PARENTAL METHODS   ==================================================

	/**
	 * This method should not normally be used.
	 * Add a Graphical Object into a Graphical Object Group instead.
	 *
	 * @see GraphicalObject#setParentGroup(GraphicalObjectGroup)
	 */
	public void setParentGroup(GraphicalObjectGroup newparent) {
		gobs.setParentGroup(newparent);
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectGroup getParentGroup() {
		return (gobs.getParentGroup());
	} // of method

	//-----------------------------------------------------------------

	public Sheet getSheet() {
		return this;
	} // of method

	//-----------------------------------------------------------------

	public void initAfterAdd() {
		gobs.initAfterAdd();
	}

	//-----------------------------------------------------------------

	public void initAfterAddToSheet() {
		gobs.initAfterAddToSheet();
	}

	//-----------------------------------------------------------------

	/**
	 * Ignore. Doesn't make sense to delete the Sheet.
	 */
	public void delete() {
	} // of method

	//===   PARENTAL METHODS   ==================================================
	//===========================================================================



	//===========================================================================
	//===   GRAPHICALOBJECTGROUP LAYER METHODS   ================================

	public int getRelativeLayer(GraphicalObject gob) {
		return (gobs.getRelativeLayer(gob));
	} // of method

	public void setRelativeLayer(GraphicalObject gob, int layer) {
		gobs.setRelativeLayer(gob, layer);
	} // of method

	public java.util.List getAbsoluteLayer(GraphicalObject gob) {
		return (gobs.getAbsoluteLayer(gob));
	} // of method

	public void bringUpALayer(GraphicalObject gob) {
		gobs.bringUpALayer(gob);
	} // of method

	public void bringUpNLayers(GraphicalObject gob, int n) {
		gobs.bringUpNLayers(gob, n);
	} // of method

	public void bringUpNLayers(int n) {
		gobs.bringUpNLayers(n);
	} // of method

	public void bringDownALayer(GraphicalObject gob) {
		gobs.bringDownALayer(gob);
	} // of method

	public void bringDownNLayers(GraphicalObject gob, int n) {
		gobs.bringDownNLayers(gob, n);
	} // of method

	public void bringDownNLayers(int n) {
		gobs.bringDownNLayers(n);
	} // of method

	public void bringToTopLayer(GraphicalObject gob) {
		gobs.bringToTopLayer(gob);
	} // of method

	public void bringToBottomLayer(GraphicalObject gob) {
		gobs.bringToBottomLayer(gob);
	} // of method

	//===   GRAPHICALOBJECTGROUP LAYER METHODS   ================================
	//===========================================================================




	//===========================================================================
	//===   COLLECTION METHODS   ================================================

	/**
	 * Add a GraphicalObject to the top layer.
	 */
	public GraphicalObject add(GraphicalObject gob) {
		return (gobs.add(gob));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Add a GraphicalObject to the bottom layer.
	 */
	public GraphicalObject addToBack(GraphicalObject gob) {
		return (gobs.addToBack(gob));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Add a GraphicalObject to the top layer.
	 */
	public GraphicalObject addToFront(GraphicalObject gob) {
		return (gobs.addToFront(gob));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject add(int index, GraphicalObject gob) {
		return (gobs.add(index, gob));
	} // of method

	//===========================================================================

	public GraphicalObject add(GraphicalObject gob, int pos) {
		return (gobs.add(gob, pos));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Add a GraphicalObject to the bottom layer.
	 */
	public GraphicalObject addToBack(GraphicalObject gob, int pos) {
		return (gobs.addToBack(gob, pos));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Add a GraphicalObject to the top layer.
	 */
	public GraphicalObject addToFront(GraphicalObject gob, int pos) {
		return (gobs.addToFront(gob, pos));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject add(int index, GraphicalObject gob, int pos) {
		return (gobs.add(index, gob, pos));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Clear out everything on the Sheet. Also, clear out the selected objects.
	 */
	public void clear() {
		gobs.clear();
		cmdsubsys.clearSelected();
	} // of method

	//-----------------------------------------------------------------

	public boolean contains(GraphicalObject gob) {
		return (gobs.contains(gob));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject get(int index) {
		return (gobs.get(index));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject getFirst() {
		return (gobs.getFirst());
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject getLast() {
		return (gobs.getLast());
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject getID(long id) {
		if (getUniqueID() == id) {
			return this;
		}
		else {
			return (gobs.getID(id));
		}
	} // of getID

	//-----------------------------------------------------------------

	public Rectangle2D getCollectionBounds2D(int cdsys) {
		return (gobs.getCollectionBounds2D(cdsys));
	} // of method

	//-----------------------------------------------------------------

	public Rectangle2D getCollectionBounds2D(int cdsys, Rectangle2D rect) {
		return (gobs.getCollectionBounds2D(cdsys, rect));
	} // of method

	//-----------------------------------------------------------------

	public int indexOf(GraphicalObject gob) {
		return (gobs.indexOf(gob));
	} // of indexOf

	//-----------------------------------------------------------------

	public boolean isEmpty() {
		return (gobs.isEmpty());
	} // of isEmpty

	//-----------------------------------------------------------------

	/**
	 * Actually does nothing, since ordering is imposed by layers.
	 */
	public void sort(Comparator c) {
		//// ignore
	} // of sort

	//-----------------------------------------------------------------

	public int numElements() {
		return (gobs.numElements());
	} // of size

	//-----------------------------------------------------------------

	public GraphicalObject remove(GraphicalObject gob) {
		return (gobs.remove(gob));
	} // of remove

	//-----------------------------------------------------------------

	public Iterator getForwardIterator() {
		return (gobs.getForwardIterator());
	} // of getForwardIterator

	//-----------------------------------------------------------------

	public Iterator getReverseIterator() {
		return (gobs.getReverseIterator());
	} // of getForwardIterator

	//===   COLLECTION METHODS   ================================================
	//===========================================================================



	//===========================================================================
	//===   MODIFIER METHODS   ==================================================

	public void removeAll(GraphicalObjectCollection gobcol) {
		gobs.removeAll(gobcol);
	} // of method

	//===   MODIFIER METHODS   ==================================================
	//===========================================================================



	//===========================================================================
	//===   GROUP QUERY METHODS   ===============================================

	public boolean getAllowDeepGet() {
		return (gobs.getAllowDeepGet());
	}

	//-----------------------------------------------------------------

	public void setAllowDeepGet(boolean flag) {
		gobs.setAllowDeepGet(flag);
	}

	//-----------------------------------------------------------------
	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, Point2D pt, int num, int depth, int gettype,
							  double thresh, GraphicalObjectCollection out) {

		return (gobs.getGraphicalObjects(cdsys, pt, num, depth,
												  gettype, thresh, out));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, double x, double y, int num, int depth,
				int gettype, double thresh, GraphicalObjectCollection out) {

		return (gobs.getGraphicalObjects(cdsys, x, y, num, depth,
												  gettype, thresh, out));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, Shape s, int num, int depth, int gettype,
							  double thresh, GraphicalObjectCollection out) {

		return (gobs.getGraphicalObjects(cdsys, s, num, depth,
												  gettype, thresh, out));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(GraphicalObject gob, int num, int depth, int gettype,
							  double thresh, GraphicalObjectCollection out) {

		return (gobs.getGraphicalObjects(gob, num, depth,
												  gettype, thresh, out));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, Point2D pt, int num, int depth, int gettype) {

		return (gobs.getGraphicalObjects(cdsys, pt, num, depth, gettype));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, double x, double y, int num, int depth,
				int gettype) {

		return (gobs.getGraphicalObjects(cdsys, x, y, num, depth, gettype));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, Shape s, int num, int depth, int gettype) {

		return (gobs.getGraphicalObjects(cdsys, s, num, depth, gettype));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(GraphicalObject gob, int num, int depth, int gettype) {

		return (gobs.getGraphicalObjects(gob, num, depth, gettype));
	} // of method

	//===   GROUP QUERY METHODS   ===============================================
	//===========================================================================



	//===========================================================================
	//===   WATCHABLE INTERFACE   ===============================================

	public Watcher addWatcher(Watcher w) {
		return (gobs.addWatcher(w));
	} // of addWatcher

	public int countWatchers() {
		return (gobs.countWatchers());
	} // of countWatchers

	public Watcher removeWatcher(Watcher w) {
		return (gobs.removeWatcher(w));
	} // of removeWatcher

	public void clearWatchers() {
		gobs.clearWatchers();
	} // of clearWatchers

	public void enableNotify() {
		gobs.enableNotify();
	} // of enableNotify

	public void disableNotify() {
		gobs.disableNotify();
	} // of disableNotify

	public boolean hasNotifyEnabled() {
		return (gobs.hasNotifyEnabled());
	} // of hasNotifyEnabled

	public void notifyWatchers() {
		gobs.notifyWatchers(this);
	} // of notifyWatchers

	public void notifyWatchers(Object arg) {
		gobs.notifyWatchers(arg);
	} // of notifyWatchers

	public void notifyWatchersUpdate(Object arg) {
		gobs.notifyWatchersUpdate(arg);
	} // of notifyWatchersUpdate

	public void notifyWatchersUpdate(String strProperty,
			Object newVal, Object oldVal) {
		gobs.notifyWatchersUpdate(strProperty, newVal, oldVal);
	} // of notifyWatchersUpdate

	public void notifyWatchersDelete() {
		gobs.notifyWatchersDelete();
	} // of notifyWatchersDelete

	//===   WATCHABLE INTERFACE   ===============================================
	//===========================================================================



	//===========================================================================
	//===   WATCH METHODS   =====================================================

	public void onNotify(Watchable w, Object arg) {
		gobs.superNotify(w, arg);
	} // of onNotify

	//-----------------------------------------------------------------

	public void onUpdate(Watchable w, Object arg) {
		gobs.superUpdate(w, arg);
	} // of onUpdate

	//-----------------------------------------------------------------

	public void onUpdate(Watchable w, String strProperty,
			Object oldVal, Object newVal) {
		gobs.superUpdate(w, strProperty, oldVal, newVal);
	} // of onUpdate

	//-----------------------------------------------------------------

	public void onDelete(Watchable w) {
		gobs.superDelete(w);
	} // of onDelete

	//===   WATCH METHODS   =====================================================
	//===========================================================================



	//===========================================================================
	//===   COMPONENT METHODS   =================================================

	public void setSize(int w, int h) {
		super.setSize(w, h);
		gobs.setBoundingPoints2D(COORD_LOCAL, getBounds());
	} // of setSize

	//-----------------------------------------------------------------

	public void setSize(Dimension dim) {
		super.setSize(dim);
		gobs.setBoundingPoints2D(COORD_LOCAL, getBounds());
	} // of setSize

	//-----------------------------------------------------------------

        /**
         * @deprecated
         */
	public boolean isFocusTraversable() {
		return (true);
	} // of method

        //-----------------------------------------------------------------
      
        public boolean isFocusable() {
           return (true);
        } // of method

	//===   COMPONENT METHODS   =================================================
	//===========================================================================




	//===========================================================================
	//===   AWT METHODS   =======================================================

	public void setBackground(Color bkgrd) {
		super.setBackground(bkgrd);
		if (graphics != null) {
			graphics.setBackground(bkgrd);
		}
	} // of setBackground

	//-----------------------------------------------------------------

	/**
	 * Set whether SATIN should use its own anti-aliasing when
	 * paintComponent() is called, or whether it should use keep the
	 * anti-aliasing settings in the graphics context passed into
	 * paintComponent().
	 *
	 * @param flag true if SATIN should use the graphics context's
	 *             anti-aliasing settings
	 */
	public void setKeepJavaAntialiasing(boolean flag) {
		keepJavaAntialiasing = flag;
	}

	//-----------------------------------------------------------------

	/**
	 * Get whether strokes being drawn in the sheet are smoothed
	 * out, or whether they are drawn exactly as the user draws
	 * them.
	 *
	 * @return true if strokes are being smoothed out
	 */
	public boolean getSmoothStrokes() {
		return asm.getRenderCurvy();
	}
    
    public void resetStrokeAssembler()
    {
        asm.reset();
    }

	//-----------------------------------------------------------------

	/**
	 * Set whether strokes being drawn in the sheet should be smoothed
	 * out, or whether they should be drawn exactly as the user draws
	 * them.
	 *
	 * @param flag true if strokes should be smoothed out
	 */
	public void setSmoothStrokes(boolean flag) {
		asm.setRenderCurvy(flag);
	}

	//-----------------------------------------------------------------

	public void render(SatinGraphics g) {
		 gobs.render(g);
	} // of render

	//-----------------------------------------------------------------
	   
	public RenderServer getRenderServer() {
		return renderServer;
	}

	//-----------------------------------------------------------------
	
	private Rectangle getLatestBounds(String id) {
		Iterator it = this.gobs.getForwardIterator();
		while(it.hasNext())
		{
			GraphicalObject obj = (GraphicalObject)it.next();
			if(obj instanceof SwingPeer)
			{
				if(((SwingPeer)obj).getName().equals(id))
				{
					return ((SwingPeer)obj).getLatestBounds();
				}
			}
		}
		return null;
	}
	

	//-----------------------------------------------------------------
	
	private void paintSwingPeerComponent(Graphics g) {
		/*
		for(int i=0; i<this.getComponentCount(); i++)
		{
			Component com = this.getComponent(i);
			Rectangle bounds = this.getLatestBounds(com.getName());
			
			if(bounds!=null)
			{
				if(this.getBounds().intersects(bounds))
				{
					com.setVisible(true);
					com.setBounds(bounds);
				}
				else
				{
					com.setVisible(false);
				}
				
			}
			else
			{
				com.setVisible(false);
			}
		}
		*/
		this.paintChildren(g);
	}
	
	//-----------------------------------------------------------------
   
	/**
	 * override the paint method to enable sheet own double buffer
	 */

	public void paint(Graphics g) {
   	
//		  synchronized (this) {

			if(isFirstRender)
			{
				sBufferedImage = (BufferedImage)createImage(this.getWidth(),this.getHeight());
				isFirstRender = false;
			}
    
			// adjust the size of double buffer when the sheet is resized
			// bug fixing when sheet is in splitpan
			if(this.getWidth()!=sBufferedImage.getWidth()||this.getHeight()!=sBufferedImage.getHeight())
			{
				sBufferedImage = (BufferedImage)createImage(this.getWidth(),this.getHeight());
				//g.setClip(this.getBounds());
				renderServer.sceneGraphChanged = true;
			}
   	
			Graphics myg = g;
   	
			if(isSDoublebufferEnabled)
			{
				if(sBufferedImage!=null)
				{
					myg = sBufferedImage.createGraphics();
					myg.setClip(g.getClip());
				}
			}
   
			// if scenegraph changed, redraw the scenegraph	
			if(renderServer.sceneGraphChanged)
			{
				this.paintComponent(myg);
				renderServer.sceneGraphChanged = false;
            
				if(isManageSwingPeer)
				{
					//this.paintChildren(myg);
					//this.setAllChildrenInvisible();
					paintSwingPeerComponent(myg);
				}
			}


			if(isManageSwingPeer==false)
				this.paintChildren(myg);

			if(isSDoublebufferEnabled)
			{
				if(sBufferedImage!=null&&shouldRenderToScreen)
				g.drawImage(sBufferedImage,0,0,this);
			}
//		  }
	}
   
	//-----------------------------------------------------------------
   
	public void paintComponent(Graphics g) {
//		  synchronized (this) {

			paintProcess = Sheet.painting;
         
			//// 0. Determine what the render quality should be.
			//// 0.1. If animating, try to render everything as quickly as possible.
			if (GraphicalObjectLib.isAnimating() == true) {
				graphics.setRenderQuality(GraphicsConstants.LOW_QUALITY);
			}
			//// 0.2. If interacting via a stroke, render everything quickly.
			else if (currentStk != null) {
				graphics.setRenderQuality(GraphicsConstants.MEDIUM_QUALITY);
			}
			//// 0.3. Otherwise, render higher-quality images.
			else {
				graphics.setRenderQuality(GraphicsConstants.HIGHEST_QUALITY);
			}
   
			//// 1. Update the current Graphics context.
			////    If this throws an exception, that means you're missing
			////    JDK1.2, which uses Graphics2D instead of Graphics.
			graphics.setGraphics((Graphics2D) g, keepJavaAntialiasing);
			graphics.setIssuer("sheet");
   
			//2. Render the background
			paintComponentBackground(graphics);
   
			//// Some debugging info...
			// debug.println("repaint clip: " + g.getClipBounds());

/*
 //// this is the alternative rendering model
 //// doesn't work with transitions for some reason

		queueAllViews(this);

		//// 3.1. If animating, try to render everything as quickly as possible.
		if (GraphicalObjectLib.isAnimating() == true) {
			graphics.setRenderQuality(GraphicsConstants.MEDIUM_QUALITY);
			q.blit(graphics);
		}
		//// 3.2. If interacting via a stroke, render everything quickly.
		else if (currentStk != null) {
			graphics.setRenderQuality(GraphicsConstants.MEDIUM_QUALITY);
			q.blit(graphics);
		}
		//// 3.3. Otherwise, render higher-quality images.
		else {
			graphics.setRenderQuality(GraphicsConstants.HIGHEST_QUALITY);
			q.blit(graphics);
		}
*/

			//// 4.1. Push the current style and transform.
			graphics.pushStyle(gobs.getStyleRef());
			graphics.pushTransform(gobs.getTransformRef());
   
			//// 4.2. Paint all of the gobs in our collection of gobs.
			gobs.render(graphics);
         
			//// 4.3. Render the current stroke if there is one.
			if (currentStk != null && flagDrawCurrent == true && currentStk.getNumPoints()>0) {
				Style currentStyle;
   
				//// 4.3.1. Render right button down strokes differently than left down
				////        Not sure of best way to do this, since we want gestures
				////        line widths to appear absolute, but it's not always clear
				////        what to do with normal drawing strokes.
				if (currentStk.isRightButton()) {
					AffineTransform tx    = getTransformRef();
					double          scale = AffineTransformLib.getScaleFactor(tx);
					currentStyle = (Style) rightStyle.clone();
					currentStyle.setLineWidth((float) Math.max(rightLineWidth/scale,1));
				}
				else {
            	
					currentStyle = (Style) leftStyle.clone();
					currentStyle.setLineWidth(leftLineWidth);
				}
            
				graphics.pushStyle(currentStk.getStyleRef());
				graphics.pushStyle(currentStyle);
				graphics.pushTransform(currentStk.getTransformRef());
				currentStk.render(graphics);
				graphics.popTransform();
				graphics.popStyle();
				graphics.popStyle();
   
			}
   
			//// 4.4. Pop the current style and transform.
			graphics.popTransform();
			graphics.popStyle();

			paintProcess = Sheet.paintJustFinished;
//		  }

	} // of paintComponent

      
	//-----------------------------------------------------------------
   
	public boolean isPaintFinished() {
		if(paintProcess == Sheet.paintJustFinished)
		{
			paintProcess = Sheet.paintNotStarted;   
			return true;
		}
		else
		{
			return false;
		}
	}
   
	//-----------------------------------------------------------------   


	/**
	 * Paint the background
	 */
	protected void paintComponentBackground(SatinGraphics graphics) {
		//// Clear the entire area. Clearing the entire area
		////  and then redrawing is not as expensive an operation
		////  as it may seem, since what is rendered is automatically sent
		////  to a double buffer and clipped to the dirty region.
		graphics.setBackground(getBackground());
		graphics.clearRect(0, 0, getWidth(), getHeight());
		graphics.setTransparency(1);
	}

	//-----------------------------------------------------------------

	/**
	 * Breadth-first queueing of all views.
	 */
/*
	private void queueAllViews(GraphicalObjectGroup gobgrp) {
		Iterator        it;
		GraphicalObject gob;
		Object          obj;

		//// 1. Enqueue all current-level views.
		it = gobgrp.getForwardIterator();
		while (it.hasNext()) {
			gob = (GraphicalObject) it.next();
			//// 1.1. Enqueue only if it has a valid view value.
			if (gob.getView().getViewDisplayValue() > 0) {
				q.enqueue(gob.getView(), gob.getStyle(),
							 gob.getTransform(COORD_ABS));
			}
		}

		//// 2. Recurse on all groups.
		it = gobgrp.getForwardIterator();
		while (it.hasNext()) {
			obj = it.next();
			if (obj instanceof GraphicalObjectGroup) {
				queueAllViews((GraphicalObjectGroup) obj);
			}
		}

	} // of queueAllViews
*/
	//===   AWT METHODS   =======================================================
	//===========================================================================



	//===========================================================================
	//===   TOSTRING   ==========================================================

	/**
	 * Return debugging information for the entire system. Warning: this can be
	 * quite large!
	 */
	public String toString() {
		return (super.toString() + "\n" +
				  "\n" + gobs.toDebugString()  +
				  "\nAdd Filter:\n"  + StringLib.indent(addFilter.toString(), 3) +
				  "\nDraw Filter:\n" + StringLib.indent(drawFilter.toString(), 3) +
				  "\n" + cmdsubsys.toString());
	} // of toString

	//===   TOSTRING   ==========================================================
	//===========================================================================

	/*
	 *  Used by subclasses for unpacking remote events
	 */
	public void addCommandToSheet(String cmdInXML) {
		System.out.println("Write ya own xml to command method!");
		System.out.println("I'm not doing anything with " + cmdInXML);
	}


	/**
	 * For historical reasons, SATIN objs have two id's. an unique integer ID 
	 * used for single-machine applications, and a {hostname, id} pair used 
	 * for distributed apps. Note that the id in the pair will equal the local 
	 * id on the machine that created the object, but it will be different 
	 * than the local id of that object on other machines.
	 */
	public void setGlobalID(String host, int id) {
		globalID = new GlobalID(host, id);
	}


	/**
	 * For historical reasons, SATIN objs have two id's. an unique integer ID 
	 * used for single-machine applications, and a {hostname, id} pair used 
	 * for distributed apps. Note that the id in the pair will equal the local 
	 * id on the machine that created the object, but it will be different 
	 * than the local id of that object on other machines.
	 */
	public void setGlobalID(GlobalID guid) {
		globalID = guid;
	}
    
    public StrokeAssembler getStrokeAssember() {
        return asm;
    }


	/**
	 * For historical reasons, SATIN objs have two id's. an unique integer ID 
	 * used for single-machine applications, and a {hostname, id} pair used 
	 * for distributed apps. Note that the id in the pair will equal the local 
	 * id on the machine that created the object, but it will be different 
	 * than the local id of that object on other machines.
	 */
	public GlobalID getGlobalID() {
		return globalID;
	}


	/**
	 * For historical reasons, SATIN objs have two id's. an unique integer ID 
	 * used for single-machine applications, and a {hostname, id} pair used 
	 * for distributed apps. Note that the id in the pair will equal the local 
	 * id on the machine that created the object, but it will be different 
	 * than the local id of that object on other machines.
	 */
	public String getGlobalIDXML() {
		return globalID.toXML();
	}


	//===========================================================================
	//===   CLONE   =============================================================

	/**
	 * My clone sleeps alone as a shallow clone. Not implemented.
	 */
	public Object clone() {
		// XXX
		throw new RuntimeException("Clone not implemented for Sheet");
	} // of clone

	//-----------------------------------------------------------------

	/**
	 * My clone sleeps alone as a deep clone. Not implemented.
	 */
	public Object deepClone() {
		// XXX
		throw new RuntimeException("Clone not implemented for Sheet");
	} // of clone

	//===   CLONE   =============================================================
	//===========================================================================

    public boolean shouldRenderSelections() {
        return true;
    }
    
	//===========================================================================
	//===   MAIN   ==============================================================

/*
	public static void main(String[] argv) throws Exception {
		JPanel p = new JPanel();
		p.setSize(450, 450);
		debug.println(">>> Set panel size to 450x450 <<<");
		debug.println("size:   " + p.getSize());
		debug.println("bounds: " + p.getBounds());


		debug.println("\n-----\n");


		p.setBounds(0, 0, 500, 500);
		debug.println(">>> Set panel bounds to [x=0, y=0, w=500, h=500] <<<");
		debug.println("size:   " + p.getSize());
		debug.println("bounds: " + p.getBounds());


		debug.println("\n-----\n");


		JFrame f = new JFrame();
		f.setSize(300, 300);
		f.setVisible(true);

		Sheet  s = new Sheet(new Dimension(300, 300));
		f.setContentPane(s);

		debug.println("Create new Sheet 300x300");
		debug.println("w: " + s.getWidth2D(COORD_REL));
		debug.println("h: " + s.getHeight2D(COORD_REL));
		debug.println("bounds: " + s.getBounds2D(COORD_REL));
		debug.println("bd pts: " +
							 StringLib.toString(s.getBoundingPoints2D(COORD_REL)));

		debug.println("local bounds: " + s.getBounds2D(COORD_LOCAL));
		debug.println("local bd pts: " +
							 StringLib.toString(s.getBoundingPoints2D(COORD_LOCAL)));

		debug.println("abs bounds: " + s.getBounds2D(COORD_ABS));
		debug.println("abs bd pts: " +
							 StringLib.toString(s.getBoundingPoints2D(COORD_ABS)));


		debug.println("\n-----\n");


		s.setSize(600, 600);
		debug.println(">>> Resize Sheet to 600x600 <<<");
		debug.println("w: " + s.getWidth2D(COORD_REL));
		debug.println("h: " + s.getHeight2D(COORD_REL));
		debug.println("bounds: " + s.getBounds2D(COORD_REL));
		debug.println("bd pts: " +
							 StringLib.toString(s.getBoundingPoints2D(COORD_REL)));

		debug.println("local bounds: " + s.getBounds2D(COORD_LOCAL));
		debug.println("local bd pts: " +
							 StringLib.toString(s.getBoundingPoints2D(COORD_LOCAL)));

		debug.println("abs bounds: " + s.getBounds2D(COORD_ABS));
		debug.println("abs bd pts: " +
							 StringLib.toString(s.getBoundingPoints2D(COORD_ABS)));


		debug.println("\n-----\n");


		s.setSize(300, 300);
		debug.println(">>> Resize Sheet to 300x300 <<<");
		debug.println("w: " + s.getWidth2D(COORD_REL));
		debug.println("h: " + s.getHeight2D(COORD_REL));
		debug.println("bounds: " + s.getBounds2D(COORD_REL));
		debug.println("bd pts: " +
							 StringLib.toString(s.getBoundingPoints2D(COORD_REL)));

		debug.println("local bounds: " + s.getBounds2D(COORD_LOCAL));
		debug.println("local bd pts: " +
							 StringLib.toString(s.getBoundingPoints2D(COORD_LOCAL)));

		debug.println("abs bounds: " + s.getBounds2D(COORD_ABS));
		debug.println("abs bd pts: " +
							 StringLib.toString(s.getBoundingPoints2D(COORD_ABS)));


		debug.println("\n-----\n");


		debug.println(s);
	} // of main
*/
	//===   MAIN   ==============================================================
	//===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
