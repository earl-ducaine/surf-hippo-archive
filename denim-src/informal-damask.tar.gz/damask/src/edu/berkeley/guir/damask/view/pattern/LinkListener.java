package edu.berkeley.guir.damask.view.pattern;

import java.net.URL;
import java.util.logging.Logger;

import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import edu.berkeley.guir.damask.pattern.Pattern;

/**
 * Listens for events on a hyperlink within the pattern browser, and displays
 * the destination of the link either within the browser or an external
 * web browser.
 *  
 * <P>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * @author Qing Li
 * @author <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */
public class LinkListener implements HyperlinkListener {
   private static final Logger logger =
      Logger.getLogger(LinkListener.class.getName());
   
   private final JEditorPane editorPane;
   private final JLabel status;
   private final PatternBrowser browser;

   public LinkListener(
      final JEditorPane editorPane,
      final JLabel status,
      final PatternBrowser browser) {

      this.editorPane = editorPane;
      this.status = status;
      this.browser = browser;
   }

   public LinkListener(
      final JEditorPane editorPane,
      final PatternBrowser browser) {

      this(editorPane, null, browser);
   }

   public void hyperlinkUpdate(HyperlinkEvent he) {
      final HyperlinkEvent.EventType type = he.getEventType();
      if (type == HyperlinkEvent.EventType.ENTERED) {
         if (status != null) {
            status.setText(he.getURL().toString());
         }
      }
      else if (type == HyperlinkEvent.EventType.EXITED) {
         if (status != null) {
            status.setText("");
         }
      }
      else if (type == HyperlinkEvent.EventType.ACTIVATED) {
         final URL link = he.getURL();
         if (link.getProtocol().equals("http")) {
            final Pattern possiblePattern =
               PatternBrowser.getPatternFromURL(link);
            if (possiblePattern != null) {
               browser.displayPattern(possiblePattern);
               logger.info("displaying pattern " + possiblePattern);
            }
            else {
               browser.launchURL(link);
               logger.info("launching external browser " + link);
            }
         }
      }
   }
}