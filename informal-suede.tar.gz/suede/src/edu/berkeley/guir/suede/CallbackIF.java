package edu.berkeley.guir.suede;

public interface CallbackIF {
 
  public void callback();
}