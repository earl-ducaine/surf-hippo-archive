package edu.berkeley.guir.denim.io;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.awt.image.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;
import edu.berkeley.guir.lib.satin.graphics.SatinGraphics;
import edu.berkeley.guir.lib.satin.image.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.*;
import java.io.*;
import java.util.List;
import javax.imageio.*;

/**
 * Exports the contents of a DenimSheet as a set of HTML pages.
 * 
 * <P>
 * This software is distributed under the <A
 * HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt"> Berkeley Software
 * License </A>.
 * 
 * <PRE>
 * 
 * Revisions: 1.0.0 06-28-2000 Carol Hu Created class HtmlExport. 2.0.0
 * 11-29-2000 James Lin Fixed 2.1.0 03-16-2001 James Lin Enabled saving
 * scenarios, fixed bugs.
 * 
 * </PRE>
 * 
 * @author Carol Hu
 * @since JDK 1.2
 * @version Version 2.1.0, 03-16-2001
 */
public class HtmlExport implements SatinConstants {

    static boolean isExporting = false;

    //===========================================================================
    //=== INSTANCE VARIABLES ================================================

    private DenimSheet sheet;

    // The table of contents file
    private File indexFile;

    // The directory under which the supporting HTML and GIF files are saved
    private File supportingDir;

    //final int htmlTopEdge = 0;

    //final int htmlLeftEdge = 0;//26;

    final int captionXOffset = 26;
    //final int controlYOffset = 2;
    
    int radiobtnIndex = 1;
    int checkboxIndex = 1;
    int buttonIndex = 1;
    
    /*
    final int height_radiobutton = 20;
    final int height_checkbox = 20;
    final int height_combobox = 20;
    final int height_textfield = 20;*/

    //=== INSTANCE VARIABLES ================================================
    //===========================================================================

    //===========================================================================
    //=== CONSTRUCTORS ======================================================

    /**
     * Creates an exporter which will export the given sheet to the given file
     * name.
     */
    public HtmlExport(DenimSheet sheet, String indexFileName) {
        this.sheet = sheet;
        indexFile = new File(indexFileName);

        // strip the extension and add "_files"
        int periodLocation = indexFileName.lastIndexOf('.');
        String bareFileName;

        if (periodLocation >= 0) {
            bareFileName = indexFileName.substring(0, periodLocation);
        } else {
            bareFileName = indexFileName;
        }

        supportingDir = new File(bareFileName + "_files");
        supportingDir.mkdir();
    }

    //=== CONSTRUCTORS ======================================================
    //===========================================================================

    //===========================================================================
    //=== UTILITY EXPORT METHODS ============================================

    /**
     * Returns the name of the GIF file corresponding to the given ID number
     */
   /* private String computeGifName(GraphicalObject gob) {
        return "page" + Long.toString(gob.getUniqueID()) + ".gif";
    }
    */
    private String computeJPEGName(GraphicalObject gob) {
        return "page" + Long.toString(gob.getUniqueID()) + ".jpg";
    }
    
    private String computeJPEGName(DenimComponent com, long stateid) {
        return "page" + Long.toString(com.getUniqueID()) + "_" + stateid + ".jpg";
    }


    /**
     * Returns the name of the GIF file corresponding to the given ID number
     */
/*    private String computeGifName(DenimCustomComponent com, long stateid) {
        return "page" + Long.toString(com.getUniqueID()) + "_" + stateid + ".gif";
    }
  */  
    //-----------------------------------------------------------------

    /**
     * Returns the name of the HTML file corresponding to the given ID number
     */
    private String computeHtmlName(GraphicalObject gob) {
        return "page" + Long.toString(gob.getUniqueID()) + ".html";
    }

    //-----------------------------------------------------------------

    /**
     * Appends the given scenario name to the front of the name of the given
     * HTML file
     */
    private String computeScenarioHtmlName(String scenario, int pageNum) {
        return "scenario_" + scenario + "_" + pageNum + ".html";
    }

    //-----------------------------------------------------------------

    /**
     * Returns the absolute path of the given file name.
     */
    private File getAbsFile(String filename) {
        return new File(supportingDir, filename);
    }

    //-----------------------------------------------------------------

    /**
     * Converts the given DenimPanel into a GIF file.
     */
    private void exportPanelToGif(DenimPanel origPanel, DenimPanel renderedPanel)
            throws IOException, FileNotFoundException {

        File f = getAbsFile(computeJPEGName(origPanel));
        //FileOutputStream fout = new FileOutputStream(f);
        //Image img = SatinImageLib.toImage(renderedPanel);
        BufferedImage img = toImage(origPanel, renderedPanel.getSketch());
        //Image qimg = Quantize.quantizeImage(img, 256);
        //SatinImageLib.toGif(qimg, fout);
        //SatinImageLib.toGif(img, fout);
        //SatinImageLib.toJPeg(img, fout);
        ImageIO.write(img, "JPEG", f);
    }

    private void customComponentInstanceToGif(DenimCustomComponent com)
            throws IOException, FileNotFoundException {
        
        Iterator it = com.getStatesRef().iterator();
        while(it.hasNext())
        {
            DenimPanel state = (DenimPanel)it.next();
            File f = getAbsFile(computeJPEGName(com, state.getUniqueID()));
            
            if(f.exists()) // the component has been exported
                break;
            
            DenimPanel renderedPanel = (DenimPanel) state.deepClone();
            Sheet s = new Sheet();
            renderedPanel.makeVisibleAtUpperLeftIn(s);
            renderedPanel.setUniqueID(state.getUniqueID());
            renderedPanel.setTextBackgroundsTransparent();
            Style style = renderedPanel.getStyle();
            style.setFillColor(Color.white);
            renderedPanel.setStyle(style);
            renderedPanel.getSketch().getStyleRef().setDrawColor(
                    Color.white);
            renderedPanel.getSketch().getStyleRef().setFillColor(
                    Color.white);
            renderedPanel.getLabel().getStyleRef()
                    .setDrawColor(Color.white);
            renderedPanel.getLabel().getStyleRef()
                    .setFillColor(Color.white);
            

            FileOutputStream fout = new FileOutputStream(f);
            Image img = toImage(null, renderedPanel.getSketch());
            Image qimg = Quantize.quantizeImage(img, 256);
            SatinImageLib.toGif(qimg, fout);
        }
    }
    
    public static BufferedImage toImage(DenimPanel orig, DenimSketch sketch) {
        SatinImageLib.imageConvertingRender = true;
        
        AffineTransform scale = sketch.getPanel().getTransform(COORD_REL);
        
        int w = (int)(sketch.getWidth2D(COORD_LOCAL)*scale.getScaleX());
        int h = (int)(sketch.getHeight2D(COORD_LOCAL)*scale.getScaleY());
        BufferedImage bimg = new BufferedImage(
                w, h,
                BufferedImage.TYPE_INT_RGB);
                //BufferedImage.TYPE_INT_ARGB);
        
        SatinGraphics sg = new SatinGraphics(bimg.createGraphics());
        sg.setColor(Color.white);
        sg.fillRect(0, 0, bimg.getWidth(), bimg.getHeight());
        
        if(orig!=null&&((BackgroundImageContainer)orig.getSheet()).getBackgroundName()!=null)
        {
            Rectangle2D box = new Rectangle2D.Double(0, 0, bimg.getWidth(), bimg.getHeight());
            BufferedImage image = DenimSheet.getImage(((BackgroundImageContainer)orig.getSheet()).getBackgroundName());
            sg.drawImage(image, 
                    (int)(box.getWidth()*((BackgroundImageContainer)orig.getSheet()).getImageX()),
                    (int)(box.getHeight()*((BackgroundImageContainer)orig.getSheet()).getImageY()),
                    (int)(box.getWidth()*((BackgroundImageContainer)orig.getSheet()).getImageW()),
                    (int)(box.getHeight()*((BackgroundImageContainer)orig.getSheet()).getImageH()),
                    null);
        }
        
        sg.clipRect(0, 0, bimg.getWidth(), bimg.getHeight());


        sg.pushTransform(AffineTransform.getScaleInstance(scale.getScaleX(),scale.getScaleY()));
        Iterator it = sketch.getReverseIterator(); 
        while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject) it.next();
            sg.pushStyle(gob.getStyleRef());
            sg.pushTransform(gob.getTransformRef());
            gob.render(sg);
            sg.popTransform();
            sg.popStyle();
        }
        sg.popTransform();
        sg.dispose();
        SatinImageLib.imageConvertingRender = false;
        return (bimg);
    }

    //=== UTILITY EXPORT METHODS ============================================
    //===========================================================================

    //===========================================================================
    //=== MAIN EXPORT METHODS ===============================================

    /**
     * Exports the sheet as a set of HTML and GIF files.
     */
    public void export() throws IOException, FileNotFoundException,
            NoninvertibleTransformException {

        isExporting = true;
        createTableOfContents();
        exportSheetToGifsAndHtmlPages();
        exportScenariosToHtmlPages();
        isExporting = false;
    }

    //-----------------------------------------------------------------

    /**
     * Creates an HTML file for each page in the given scenario.
     */
    private void exportScenarioToHtml(String scenario) throws IOException {

        List panels = sheet.getScenario(scenario);
        ListIterator it = panels.listIterator();

        while (it.hasNext()) {
            int i = it.nextIndex();
            DenimPanel panel = (DenimPanel) it.next();

            // Write the header of the file
            File f = getAbsFile(computeScenarioHtmlName(scenario, i));
            String nextPage;
            if (it.hasNext()) {
                nextPage = computeScenarioHtmlName(scenario, i + 1);
            } else {
                nextPage = "../" + indexFile.getName();
            }

            PrintWriter out = new PrintWriter(new BufferedWriter(
                    new FileWriter(f)));
            out.println("<HTML>");
            out.println("<HEAD><TITLE>" + scenario + ": Page " + i
                    + "</TITLE></HEAD>");
            out.println("<BODY>");
            out.print("<A HREF=\"" + nextPage + "\">");
            out.print("<IMG SRC=\"" + computeJPEGName(panel)
                    + "\" border=0 alt=\"\">");
            out.println("</A>");

            if (!it.hasNext()) {
                out.println("<P>End of scenario</P>");
            }
            out.println("</BODY>");
            out.println("</HTML>");
            out.close();
        }
    }

    //-----------------------------------------------------------------

    /**
     * Creates HTML files for each scenario.
     */
    private void exportScenariosToHtmlPages() throws IOException {
        Set scenarios = sheet.getScenarioNames();
        if (scenarios != null) {
            Iterator it = scenarios.iterator();
            while (it.hasNext()) {
                exportScenarioToHtml((String) it.next());
            }
        }
    }

    //-----------------------------------------------------------------

    /**
     * Makes a table of contents page, listing the names of all scenarios in the
     * DenimSheet.
     */
    private void createTableOfContents() throws FileNotFoundException,
            IOException {

        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(
                indexFile)));

        // Write the header
        out.println("<HTML>");
        out.println("<HEAD><TITLE>Table of Contents</TITLE></HEAD>");
        out.println("<BODY>");

        // Write link to home page
        out.println("<P><A HREF=\"" + supportingDir.getName() + "/"
                + computeHtmlName(sheet.getHomePanel())
                + "\">Browse site</A></P>");

        // Write the scenarios
        Set scenarios = sheet.getScenarioNames();
        if (scenarios != null) {
            Iterator it = scenarios.iterator();

            while (it.hasNext()) {
                String current = (String) it.next();
                //DenimPanel firstPanel =
                // (DenimPanel)sheet.getScenario(current).get(0);
                String firstPanelFileName = computeScenarioHtmlName(current, 0);

                out.println("<A HREF=\"" + supportingDir.getName() + "/"
                        + firstPanelFileName + "\">" + current + "</A><BR>"
                        + '\n');
            }
        }

        // Write the footer
        out.println("</BODY>");
        out.println("</HTML>");
        out.close();
    }

    //-----------------------------------------------------------------

    private String groupToHtml(AffineTransform trans, PatchImpl group, HashMap map) {

        String html = new String();

        // dealing with radio buttons
        html += this.radioBtnsToHtml((DenimRadioButtonInstanceContainer) group);

        Iterator it = group.getForwardIterator();
        while (it.hasNext()) 
        {
            
            GraphicalObject gob = (GraphicalObject) it.next();
            Rectangle2D box = gob.getBounds2D(COORD_REL);
            box = GeomLib.transformRectangle(trans, box);
            
            if (gob instanceof DenimGroup) 
            {
                AffineTransform tr = (AffineTransform) trans.clone();
                tr.concatenate(gob.getTransform(COORD_REL));
                html += this.groupToHtml(tr, (DenimGroup) gob, map);
            } 
            else if (gob instanceof DenimIntrinsicComponentInstance) 
            {
                DenimIntrinsicComponentInstance obj = 
                    (DenimIntrinsicComponentInstance)gob;
                
                if (obj instanceof DenimCheckBoxInstance) {
                    DenimText text = ((DenimCheckBoxInstance) obj).getCaption();
                    
                    html += "\n<INPUT TYPE=\"checkbox\" ";
                    html += "name= \"";
                    html += obj.getUniqueID();
                    html += "\" ";
                    html += "id=\"dnm";
                    html += obj.getUniqueID();
                    html += "\"";
                    
                    html += " onChange=\"updatecondition('";
                    html += "dnm";
                    html += obj.getUniqueID();
                    html += "')\"";
                    
                    if(((DenimCheckBoxInstance)obj).getSelected())
                    {
                        html += " CHECKED";
                    }
                    
                    html += ">";

                    html += "<label id=\"dnm" + obj.getUniqueID() + "c"
                        + "\" for=\"" + obj.getUniqueID() + "\">";
            
                    if (text instanceof TypedText) {
                        html += ((TypedText) text).getText();
                    }
                    else {
                        html += "checkbox" + checkboxIndex;
                        checkboxIndex++;
                    }
                    
                    html += "</label>";
                    html += "</INPUT>";
                } else if (obj instanceof DenimButtonInstance) {
                    html += "\n<BUTTON TYPE=SUBMIT";
                    html += " id=\"dnm";
                    html += obj.getUniqueID();
                    html += "\"";
                    //html += "style=\"width:" + (int) box.getWidth() * 10 + ";";
                    //html += "height:" + (int) box.getHeight() * 10 + "\"";
                    
                    DenimButtonInstance btn = (DenimButtonInstance)map.get(obj);
                    
                    if(btn.getOutgoingArrows().isEmpty()==false)
                    {
                        html += " onClick=\"btnclicked('dnm" + btn.getUniqueID() + "')\"";
                    }
                    
                    html += ">";
                    DenimText text = ((DenimButtonInstance) obj).getCaption();
                    if (text instanceof TypedText) {
                        html += ((TypedText) text).getText();
                    } else {
                        html += "button" + buttonIndex;
                        buttonIndex++;
                    }
                    html += "</BUTTON>";
                } else if (obj instanceof DenimComboBoxInstance) {
                    html += "\n<select class=size11 id=dnm";
                    html += obj.getUniqueID();

                    DenimComboBoxInstance combo = (DenimComboBoxInstance) obj;
                    
                    // script and default value
                    html += " onChange=\"Javascript:listupdated('";
                    html += "dnm";
                    html += obj.getUniqueID();
                    html += "')\"";
                    // end
                    
                    html += ">";

                    Iterator item = combo.getItems().getForwardIterator();
                    int i = 1;
                    while (item.hasNext()) {
                        Object ci = item.next();
                        if(ci instanceof TypedText)
                        {
                            String str = ((TypedText) ci).getText();
                            html += "<option ";
                            if (i == combo.getSelectedIndex()+1) {
                                html += "selected ";
                            }
    
                            html += "value=";
                            html += i;
    
                            html += ">" + str;
                            i++;
                        }
                        else
                        {
                            String str = "item" + i; 
                            html += "<option ";
                            if (i == combo.getSelectedIndex()+1) {
                                html += "selected ";
                            }
    
                            html += "value=";
                            html += i;
    
                            html += ">" + str;
                            html += "\n";
                            i++;
                        }
                    }
                    html += "</select>";
                } else if (obj instanceof DenimListBoxInstance) {
                    DenimListBoxInstance list = (DenimListBoxInstance)obj;
                    html += "\n<Select id=\"dnm";
                    html += gob.getUniqueID();
                    html += "\" SIZE=";
                    html += list.getItems().numElements();

                    // script and default value
                    html += " onChange=\"Javascript:listupdated('";
                    html += "dnm";
                    html += obj.getUniqueID();
                    html += "')\"";
                    // end
                    
                    html += ">";
                    
                    int i = 1;
                    Iterator item = list.getItems().getForwardIterator();
                    while(item.hasNext())
                    {
                        html += "<OPTION";
                        //System.err.println(list.getSelectedIndex());
                        if(i==list.getSelectedIndex()+1)
                            html += " selected";
                        html += ">";
                        
                        Object ci = item.next();
                        if(ci instanceof TypedText)
                        {
                            //TypedText text = (TypedText)item.next();
                            html += ((TypedText)ci).getText();
                        }
                        else
                        {
                            html += "item" + i;
                        }
                        i++;
                        html += "</OPTION>\n";
                    }
                    html += "</Select>";                      
                } 
            }
            else if (gob instanceof DenimTextFieldInstance) 
            {
                    html += "\n<INPUT TYPE=\"text\" ";
                    html += "name= \"";
                    html += gob.getUniqueID();
                    html += "\" ";
                    html += "id=\"dnm";
                    html += gob.getUniqueID();
                    html += "\"";
                    //html += "\" ";
                    //html += "size=\"";
                    //html += (int) box.getWidth();
                    html += "\">";
            }
        }
        return html;
    }

    //-----------------------------------------------------------------
    private String radioBtnsToHtml(DenimRadioButtonInstanceContainer co) {

        String html = new String();

        html += "<FORM>";
        Iterator it = co.getRadioButtons().iterator();
        while (it.hasNext()) {
            DenimRadioButtonInstance radio = (DenimRadioButtonInstance) it
                    .next();
            
            //if(radio.isHTMLConvertible()==false)
            //    continue;
            
            html += "<INPUT TYPE=\"RADIO\" NAME=\"";
            html += ((GraphicalObject) co).getUniqueID();
            html += "\" VALUE=\"";
            html += radio.getUniqueID();
            html += "\"";
            html += "id=\"dnm";
            html += radio.getUniqueID();
            html += "\"";
            
            html += " onChange=\"updatecondition('";
            html += "dnm";
            html += radio.getUniqueID();
            html += "')\"";
            
            if(((DenimRadioButtonInstance)radio).getSelected())
            {
                html += " selected";
            }
            
            html += ">";
            
            html += "<label id=\"dnm" + radio.getUniqueID() + "c" + "\" for=\""
                    + radio.getUniqueID() + "\">";
            if (radio.getCaption() instanceof TypedText) {
                html += ((TypedText) radio.getCaption()).getText();
            } else {
                html += "radiobutton" + radiobtnIndex;
                radiobtnIndex++;
            }
            html += "</label>";
            html += "</INPUT>";
        }
        html += "</FORM>";
        return html;
    }

    //-----------------------------------------------------------------

    private String panelToCSS(DenimPanel renderedPanel, Hashtable customBounds) {
        String css = new String();
        css += "<style type=\"text/css\">";
        css += "body {margin-left: 0; margin-top: 0}";
        css += " #dnmbackground {position: absolute; top: 0px; left: 0px; z-index: 0}";
        css += this
                .componentTreeToCSS(renderedPanel, renderedPanel.getSketch(), 1, customBounds);

        css += "</style>";
        return css;
    }

    private String customToScripts(
            DenimPanel origPanel, Hashtable customBounds, Hashtable linkmaps) {
        
        //AffineTransform trans = 
        //    renderedPanel.getSketch().getTransform(COORD_REL);
        
        String css = new String();
        
        // image map table 3D
        css += "imagemaptable = new Array();";
        
        // exporting custom components
        int linkitemcount = 0;
        
        Iterator it = customBounds.keySet().iterator();//renderedPanel.getSketch().getForwardIterator();
        
        while(it.hasNext())
        {
            GraphicalObject obj = (GraphicalObject)it.next();
            if(obj instanceof DenimCustomComponentInstance)
            {
                DenimCustomComponentInstance dcci = (DenimCustomComponentInstance)obj;
                Rectangle2D dccibounds = (Rectangle2D)customBounds.get(dcci);

                String instanceID = "dnm" + dcci.getUniqueID();
                
                ArrayList states = ((DenimCustomComponent)dcci.getComponentType()).getStatesRef();

                Iterator sit = states.iterator();
                
                while(sit.hasNext())
                {
                    DenimPanel state = (DenimPanel)sit.next();
                    /*
                    String srcImage = computeGifName(
                            (DenimCustomComponent)dcci.getComponentType(), 
                            state.getUniqueID());
                    */
                    Iterator arrows = state.getNavArrows().iterator();
                    while (arrows.hasNext()) {
                        try {
                            Arrow current = (Arrow) arrows.next();
                            GraphicalObject src = current.getOrigSource();
                            if (current.getOrigDest() != null) {
                                DenimPanel dest = current.getOrigDest().getPanel();
                                if(!(src instanceof DenimButtonInstance)) // find a valid link
                                {
                                    String linkID = instanceID + "_" + src.getUniqueID();
                                    
                                    String dstImage = computeJPEGName(
                                            dcci.getComponentType(), 
                                            dest.getUniqueID()); 
                                      
                                    Rectangle2D bounds = src.getBounds2D(COORD_REL);
                                    
                                    //AffineTransform scale = dcci.getTransform(COORD_ABS);
                                    
                                    Rectangle2D localb = state.getSketch().getBounds2D(COORD_LOCAL);
                                    
                                    double l = bounds.getMinX()/localb.getWidth();
                                    double t = bounds.getMinY()/localb.getHeight();
                                    double r = bounds.getMaxX()/localb.getWidth();
                                    double b = bounds.getMaxY()/localb.getHeight();
                                    
                                    //System.err.println(l + "," + t + "," + r + "," + b);
                                    
                                    String value = "<AREA SHAPE=\"RECT\" COORDS=";
                                    String coord = "\"";
                                    coord += Integer.toString((int)(dccibounds.getWidth()*l)) + ",";
                                    coord += Integer.toString((int)(dccibounds.getHeight()*t)) + ",";
                                    coord += Integer.toString((int)(dccibounds.getWidth()*r)) + ",";
                                    coord += Integer.toString((int)(dccibounds.getHeight()*b)) + "\"";
                                    //System.err.println(coord);
                                    
                                    value += coord;
                                    
                                    //if(states.contains(dest)==false)
                                    //{
                                        value += " HREF=";
                                    //}
                                    //else
                                    //{
                                     //   value += " HREF=\"dummy.html\"";
                                      //  value += " onClick=";
                                    //}
                                    
                                    String action = "";
                                    if(states.contains(dest)==false)
                                    {
                                        action = "\"" + computeHtmlName(dest) + "\"";
                                        value += action + " ";
                                    }
                                    else
                                    {
                                        action = "\"javascript:selectItem(\\'" + linkID + "\\')\"";
                                        String action1 = "\"javascript:selectItem('" + linkID + "')\"";
                                        value += action1 + " ";
                                    }
                                    /*
                                    value += "instanceid=\"";
                                    value += instanceID;
                                    value += "\"";
                                   */
                                    value += "id=\"";
                                    value += linkID;
                                    value += "\"";
                                    value += ">";

                                    String stateid = instanceID+"_"+Long.toString(state.getUniqueID());
                                    
                                    Object ikey = linkmaps.get(stateid);
                                    if(ikey==null)
                                    {
                                        LinkedList list = new LinkedList();
                                        linkmaps.put(stateid, list);
                                        list.add(value);
                                    }
                                    else
                                    {
                                        LinkedList list = (LinkedList)ikey;
                                        list.add(value);
                                    }
                                    
                                    css += "\n";
                                    
                                    css += "imagemaptable[";
                                    css += linkitemcount;
                                    linkitemcount++;
                                    css += "] = new Array(";
                                    
                                    // linkid
                                    css += "'" + linkID + "', ";
                                    css += "'" + instanceID + "', ";
                                    String dstID = instanceID+"_"+Long.toString(dest.getUniqueID());
                                    css += "'" + dstID + "', ";
//                                    css += "'" + srcImage + "', ";
                                    css += "'" + dstImage + "', ";
                                    css += "'" + Long.toString(dest.getUniqueID()) + "'";
//                                    css += "'" + action + "'";
                                    css += ");";
                                    
                                }
                            }
                        } catch (Exception e) {
                            //// ignore and try to go on
                        }
                    }
                }
            }
        }
        
        css += "\n";   
        css += "\n"; 
        
        String conditiontable = new String();
        conditiontable += "conditiontable = new Array();";
        conditiontable += "\n";
        
        DenimPanel.ComponentConditionMap2D map2d = origPanel.getConditionStates();
        it = map2d.getCols().iterator();

        while(it.hasNext())
        {
            Object colHeader = it.next();
            Map col = map2d.getCol(colHeader);
            
            conditiontable += "conditiontable["+((Integer)colHeader).intValue()+"] = new Array(";
            boolean first = true;
            
            Iterator rowit = map2d.getRows().iterator();
            while(rowit.hasNext())
            {
                DenimComponentInstance instance = (DenimComponentInstance)rowit.next();

                if(instance.getDoesMatterInConditionEval()==false)
                {
                    continue;
                }
                
                GraphicalObject value = (GraphicalObject)col.get(instance);
                if(first==false)
                    conditiontable += " ,";
                else
                    first = false;
                conditiontable += "'dnm" + instance.getUniqueID() + "', '";

                //System.err.println(colHeader.toString() + " : " + value.getUniqueID());
                
                if(instance instanceof DenimRadioButtonInstance)
                {
                    if(DenimRadioButton.isSelected(value))
                        conditiontable += "true";
                    else
                        conditiontable += "false";
                }
                else if(instance instanceof DenimCheckBoxInstance)
                {
                    if(DenimCheckBox.isSelected(value))
                        conditiontable += "true";
                    else
                        conditiontable += "false";                    
                }
                else if(instance instanceof DenimComboBoxInstance)
                {
                    DenimComboBoxInstance combo = (DenimComboBoxInstance)instance;
                    conditiontable += combo.getSelectedIndex(value);
                }
                else if(instance instanceof DenimListBoxInstance)
                {
                    DenimListBoxInstance list = (DenimListBoxInstance)instance;
                    conditiontable += list.getSelectedIndex(value);                    
                }
                else if(instance instanceof DenimCustomComponentInstance)
                {
                    conditiontable += value.getUniqueID();
                }
                     
                conditiontable += "'";
            }
            
            conditiontable += ");\n";
        }
        
        css += conditiontable;
        
        css += "\n";
        
        String btnconditiontable = new String();
        btnconditiontable += "btnconditiontable = new Array();";
        btnconditiontable += "\n";
        
        it = map2d.getCols().iterator();
        while(it.hasNext())
        {
            Object colHeader = it.next();
            int currentCondition = ((Integer)colHeader).intValue();
            
            btnconditiontable += "btnconditiontable["+((Integer)colHeader).intValue()+"] = new Array(";
            boolean first = true;
            
            Iterator arrows = origPanel.getNavArrows().iterator();
            while (arrows.hasNext()) {
                Arrow current = (Arrow) arrows.next();
                
                if(current.getCondition()!=currentCondition)
                    continue;
                
                GraphicalObject src = current.getOrigSource();
                
                if(!(src instanceof DenimButtonInstance))
                    continue;
                
                if (current.getOrigDest() != null) {
                    DenimPanel dest = current.getOrigDest().getPanel();
                    if(src instanceof DenimButtonInstance)
                    {
                        if(first==false)
                            btnconditiontable += ", ";
                        else
                            first = false;
                        btnconditiontable += "'dnm" + src.getUniqueID() + "', '";
                        btnconditiontable += computeHtmlName(dest);
                        btnconditiontable += "'";
                    }
                }
            }
            
            btnconditiontable += ");\n";
        }
        
        css += btnconditiontable;
        css += "\n"; 
        
        css += "function btnclicked(btnid)\n";
        css += "{\n";
        css += "    for (j = 0; j<btnconditiontable[currentcondition].length; j++) {" + "\n";
        css += "        if(btnconditiontable[currentcondition][j]==btnid) {" + "\n";
        css += "            document.location = btnconditiontable[currentcondition][j+1];\n";     
        css += "            break;" + "\n";
        css += "        }" + "\n";
        css += "    }" + "\n";
        css += "}\n";

        css += "\n";   
        css += "\n";   

        css += "currentcondition = " + origPanel.getCurrentDesignTimeCondition() + ";";
        
        css += "\n";   
        css += "\n";   
        
        css += "function listupdated(listid) {" + "\n";
        css += "    component = document.getElementById(listid);" + "\n";        
        css += "    expectStates = new Array();" + "\n";
        css += "    for (j = 0; j<conditiontable[currentcondition].length; j++) {" + "\n";
        css += "        expectStates[j] = conditiontable[currentcondition][j];" + "\n";
        css += "        if(expectStates[j]==listid) {" + "\n";
        css += "            expectStates[j+1] = '' + component.options.selectedIndex;" + "\n";    
        css += "            j++;" + "\n";
        css += "        }" + "\n";
        css += "    }" + "\n";
        css += "\n"; 
        css += "    for (i = 1; i<conditiontable.length; i++) {" + "\n";
        css += "        if(i==currentcondition)" + "\n";
        css += "            continue;" + "\n";
        css += "        for (j = 0; j<expectStates.length; j++) {" + "\n";
        css += "            if(expectStates[j]!=conditiontable[i][j])" + "\n";
        css += "                break;" + "\n";
        css += "        }" + "\n";
        css += "\n";    
        css += "        if(j == expectStates.length)" + "\n";
        css += "        {" + "\n";
        css += "            currentcondition = i;" + "\n";
        css += "            img = document.getElementById('dnmbackground');" + "\n";
        css += "            img.setAttribute('USEMAP', '#condition'+currentcondition);" + "\n";
        css += "        }" + "\n";
        css += "    }" + "\n";
        css += "}" + "\n";
        css += "\n";   
        css += "\n";   
        css += "function updatecondition(compid) {" + "\n";
        css += "    component = document.getElementById(compid);" + "\n";        
        css += "    expectStates = new Array();" + "\n";
        css += "    for (j = 0; j<conditiontable[currentcondition].length; j++) {" + "\n";
        css += "        expectStates[j] = conditiontable[currentcondition][j];" + "\n";
        css += "        if(expectStates[j]==compid) {" + "\n";
        css += "            if(component.checked)" + "\n";    
        css += "            {" + "\n";    
        css += "                expectStates[j+1] = 'true';" + "\n";    
        css += "            }" + "\n";    
        css += "            else" + "\n";    
        css += "            {" + "\n";    
        css += "                expectStates[j+1] = 'false';" + "\n";    
        css += "            }" + "\n";    
        css += "            j++;" + "\n";
        css += "        }" + "\n";
        css += "    }" + "\n";
        css += "\n"; 
        css += "    for (i = 1; i<conditiontable.length; i++) {" + "\n";
        css += "        if(i==currentcondition)" + "\n";
        css += "            continue;" + "\n";
        css += "        for (j = 0; j<expectStates.length; j++) {" + "\n";
        css += "            if(expectStates[j]!=conditiontable[i][j])" + "\n";
        css += "                break;" + "\n";
        css += "        }" + "\n";
        css += "\n";    
        css += "        if(j == expectStates.length)" + "\n";
        css += "        {" + "\n";
        css += "            currentcondition = i;" + "\n";
        css += "            img = document.getElementById('dnmbackground');" + "\n";
        css += "            img.setAttribute('USEMAP', '#condition'+currentcondition);" + "\n";
        css += "        }" + "\n";
        css += "    }" + "\n";
        css += "}" + "\n";
        css += "\n";   
        css += "\n";   
        css += "function selectItem(linkid) {" + "\n";
        css += "    i = 0;" + "\n";
        css += "    for (; i < imagemaptable.length; i++) {" + "\n";
        css += "        if(imagemaptable[i][0]==linkid) {" + "\n";
        css += "            instanceID = imagemaptable[i][1];" + "\n";
        css += "            destMapName = imagemaptable[i][2];" + "\n";
        css += "            nextSrcImg = imagemaptable[i][3];" + "\n";
        css += "\n";                                        
        css += "            img = document.getElementById(instanceID);" + "\n";
        css += "            img.setAttribute('SRC', nextSrcImg);" + "\n";
        css += "            img.setAttribute('USEMAP', '#'+destMapName);" + "\n";
        css += "            \n";                    
        css += "            break;" + "\n";
        css += "        }" + "\n";
        css += "    }" + "\n";
        css += "\n"; 
        css += "    expectStates = new Array();" + "\n";
        css += "    for (j = 0; j<conditiontable[currentcondition].length; j++) {" + "\n";
        css += "        expectStates[j] = conditiontable[currentcondition][j];" + "\n";
        css += "        if(expectStates[j]==instanceID) {" + "\n";
        css += "            expectStates[j+1] = imagemaptable[i][4];" + "\n";
        css += "            j++;" + "\n";
        css += "        }" + "\n";
        css += "    }" + "\n";
        css += "\n"; 
        css += "    for (i = 1; i<conditiontable.length; i++) {" + "\n";
        css += "        if(i==currentcondition)" + "\n";
        css += "            continue;" + "\n";
        css += "        for (j = 0; j<expectStates.length; j++) {" + "\n";
        css += "            if(expectStates[j]!=conditiontable[i][j])" + "\n";
        css += "                break;" + "\n";
        css += "        }" + "\n";
        css += "\n";    
        css += "        if(j == expectStates.length)" + "\n";
        css += "        {" + "\n";
        css += "            currentcondition = i;" + "\n";
        css += "            img = document.getElementById('dnmbackground');" + "\n";
        css += "            img.setAttribute('USEMAP', '#condition'+currentcondition);" + "\n";
        css += "        }" + "\n";
        css += "    }" + "\n";
        css += "}" + "\n";
        
        return css;
    }

    //-----------------------------------------------------------------

    private String componentTreeToCSS(DenimPanel renderedPanel, PatchImpl group, int zorder, Hashtable customBounds) {

        String css = new String();
        AffineTransform panelTrans = renderedPanel.getTransform(COORD_REL);
        AffineTransform scaleTrans = AffineTransform.getScaleInstance(panelTrans.getScaleX(), panelTrans.getScaleY());
        
        Iterator it = group.getReverseIterator();//group.getForwardIterator();
        while (it.hasNext()) {
            GraphicalObject obj = (GraphicalObject) it.next();
            if (obj instanceof DenimGroup) {
                css += this.componentTreeToCSS(renderedPanel, (DenimGroup) obj, zorder, customBounds);
            } else if (obj instanceof DenimComponentInstance
                    //&& ((DenimComponentInstance)obj).isHTMLConvertible() 
                    && !(obj instanceof DenimHyperlinkInstance)) {
                
                long id = obj.getUniqueID();
                GraphicalObject objContainer = obj;
                
                AffineTransform tx = new AffineTransform();
                while (!(objContainer instanceof DenimSketch)) {//DenimPanel)) {
                    tx.preConcatenate(objContainer.getTransform(COORD_REL));
                    objContainer = objContainer.getParentGroup();
                }
                
                tx.preConcatenate(scaleTrans);
                
                Rectangle2D bounds = GeomLib.transformRectangle(tx, obj
                        .getBounds2D(COORD_LOCAL));

                css += "#dnm";
                css += id;
                css += " {position: absolute;";
                //css += " font-size: smaller;";
                //css += (int) bounds.getHeight()/2;
                //css += "px;";
                css += " top: ";
                css += (int) bounds.getMinY();
                css += "px;";
                css += " left: ";
                css += (int) bounds.getMinX();
                css += "px;";
                
                if(obj instanceof DenimListBoxInstance||
                        obj instanceof DenimTextFieldInstance||
                        obj instanceof DenimButtonInstance||
                        obj instanceof DenimCustomComponentInstance) {
                    
                    css += " height: ";
                    css += (int) bounds.getHeight();
                    css += "px;";
                    css += " width: ";
                    css += (int) bounds.getWidth();
                    css += "px;";
                }
                
                if(obj instanceof DenimCustomComponentInstance) {
                    customBounds.put(obj, bounds);
                }

                if(obj instanceof DenimCustomComponentInstance) {
                    css += " z-index: ";
                    css += zorder;
                    css += ";";
                    zorder++;
                }
                
                css += " }";

                css += "#dnm";
                css += id + "c";
                css += " {position: absolute;";
                css += " top: ";
                css += (int) bounds.getMinY();
                css += "px;";
                css += " left: ";
                css += (int) bounds.getMinX()
                        + this.captionXOffset;
                css += "px;";
                css += " height: ";
                css += (int) bounds.getHeight();
                css += "px;";
                css += " width: ";
                css += (int) bounds.getWidth();
                css += "px;";
                css += " }";

            }
        }
        return css;
    }

    //-----------------------------------------------------------------

    /**
     * Creates an HTML file for the given panel with client-side image maps for
     * each DENIM link.
     */
    private void exportPanelToHtml(DenimPanel origPanel,
            DenimPanel renderedPanel, HashMap map) throws FileNotFoundException,
            IOException, NoninvertibleTransformException {

        // Write the header of the file
        File f = getAbsFile(computeHtmlName(origPanel));
        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f)));
        out.println("<HTML>");
        out.println("<HEAD><TITLE>DENIM Output</TITLE>");

        Hashtable customBounds = new Hashtable();
        // output CSS data
        out.println(this.panelToCSS(renderedPanel, customBounds));
        //out.println("<style type=\"text/css\">");
        //out.println("#test {position: absolute; top: 30px; left: 40px}");
        //out.println("</style>");

        /**
         * Embed Java Scripts into pages
         */
        out.println("<SCRIPT language=\"JavaScript\">");//TYPE=\"text/javascript\">");
        //out.println("<!--");
        
        Hashtable linkmaps = new Hashtable();
        out.println(this.customToScripts(origPanel,  
                customBounds, linkmaps));
        
        //out.println("//-->");
        out.println("</SCRIPT>");

        out.println("</HEAD>");
        out.println("<BODY>");
        
        String conditiontable = new String();
        conditiontable += "conditiontable = new Array();";
        conditiontable += "\n";
        
        // all nav arrows are conditioned
        DenimPanel.ComponentConditionMap2D map2d = renderedPanel.getConditionStates();
        Iterator it = map2d.getCols().iterator();

        while(it.hasNext())
        {
            Object colHeader = it.next();
            int currentCondition = ((Integer)colHeader).intValue();
            
            // Write the imagemap - background
            out.println("<MAP NAME=\"condition" + currentCondition + "\">");
            
            Iterator arrows = origPanel.getNavArrows().iterator();
            while (arrows.hasNext()) {
                try {
                    Arrow current = (Arrow) arrows.next();
                    
                    if(current.getCondition()!=currentCondition)
                        continue;
                    
                    GraphicalObject src = current.getOrigSource();
                    if (current.getOrigDest() != null) {
                        DenimPanel dest = current.getOrigDest().getPanel();
    
                        if(!(src instanceof DenimButtonInstance))
                        {
                            Rectangle2D bounds = src.getBounds2D(COORD_REL);
                            AffineTransform scale = renderedPanel.getTransform(COORD_REL);
                            out.print("<AREA SHAPE=\"RECT\" COORDS=\"");
                            out.print(Integer.toString((int)( bounds.getMinX() * scale.getScaleX())) + ",");
                            out.print(Integer.toString((int)( bounds.getMinY() * scale.getScaleY())) + ",");
                            out.print(Integer.toString((int)( bounds.getMaxX() * scale.getScaleX())) + ",");
                            out.print(Integer.toString((int)( bounds.getMaxY() * scale.getScaleY()))
                                    + "\" HREF=\"");
                            out.println(computeHtmlName(dest) + "\">");
                        }
                    }
                } catch (Exception e) {
                    //// ignore and try to go on
                }
            }
    
            // Write out the rest of the HTML page for the panel
            out.println("</MAP>");
        }
        
        // exporting custom components' map links
        it = linkmaps.keySet().iterator();
        while(it.hasNext())
        {
            String stateid = (String)it.next();
            LinkedList list = (LinkedList)linkmaps.get(stateid);
            out.println("<MAP NAME=\"" + stateid + "\">");
            Iterator lit = list.iterator();
            while(lit.hasNext())
            {
                String v = (String)lit.next();
                out.println(v);
            }
            out.println("</MAP>");
        }
                
        out.print("<IMG id=\"dnmbackground\" SRC=\"");
        out.print(computeJPEGName(origPanel));
        out.println("\" USEMAP=\"#condition" + origPanel.getCurrentDesignTimeCondition() + "\" border=0>");

        // exporting custom components
        it = origPanel.getSketch().getForwardIterator(); // renderedPanel
        while(it.hasNext())
        {
            GraphicalObject obj = (GraphicalObject)it.next();
            if(obj instanceof DenimCustomComponentInstance)
            {
                out.print("<IMG SRC=\"");
                DenimCustomComponentInstance dcci = (DenimCustomComponentInstance)obj;
                
                // export the images of the custom component
                this.customComponentInstanceToGif((DenimCustomComponent)dcci.getComponentType());
                
                // embed the image of the current state in the HTML
                out.print(computeJPEGName(
                        (DenimCustomComponent)dcci.getComponentType(), 
                                    dcci.getDisplayedState().getUniqueID()));

                out.print("\" id=\"dnm");
                out.print(dcci.getUniqueID());
                out.print("\" ");
                out.println("USEMAP=\"#dnm" + dcci.getUniqueID() + "_" + dcci.getDisplayedState().getUniqueID() + "\" border=0>");
            }
        }
        
        //test
        //out.print("<INPUT id=\"test\" TYPE=\"CHECKBOX\" NAME=\"chkFriend\"
        // VALUE=\"Chandler\">box</INPUT>");
        //out.println(this.radioBtnsToHtml(renderedPanel.getSketch()));
        radiobtnIndex = 1;
        checkboxIndex = 1;
        buttonIndex = 1;

        out.println(
                groupToHtml(
                        renderedPanel.getSketch().getTransform(COORD_REL),
                        renderedPanel.getSketch(),
                        map));

        out.println("</BODY>");
        out.println("</HTML>");
        out.close();
    }

    //-----------------------------------------------------------------
    
    private void getCloneMapping(HashMap map, GraphicalObjectGroup orig, GraphicalObjectGroup clone) {
        
        Iterator iter1 = orig.getForwardIterator();
        Iterator iter2 = clone.getForwardIterator();
        while(iter1.hasNext()&&iter2.hasNext())
        {
            Object obj1 = iter1.next();
            Object obj2 = iter2.next();
            if(obj1 instanceof GraphicalObjectGroup)
            {
                map.put(obj2, obj1);
                getCloneMapping(map, (GraphicalObjectGroup)obj1, (GraphicalObjectGroup)obj2);
            }
            else
            {
                map.put(obj2, obj1);
            }
        }
    }
    //-----------------------------------------------------------------

    /**
     * Creates an HTML file for every panel in the sheet.
     */
    private void exportSheetToGifsAndHtmlPages() throws FileNotFoundException,
            IOException, NoninvertibleTransformException {

        Iterator iter = sheet.getForwardIterator();
        while (iter.hasNext()) {
            Object obj = iter.next();
            if (obj instanceof DenimPanel) {
                DenimPanel panel = (DenimPanel) obj;

                // Clone the panel. Take the cloned panel and place it on a new
                // sheet, with the panel at full size in the upper left-hand
                // corner of the sheet.
                DenimPanel renderedPanel = (DenimPanel) panel.deepClone();
                
                HashMap map = new HashMap();
                this.getCloneMapping(map, panel, renderedPanel);
                
                Sheet s = new Sheet();
                renderedPanel.makeVisibleAtUpperLeftIn(s);

                renderedPanel.setUniqueID(panel.getUniqueID());
                renderedPanel.setTextBackgroundsTransparent();
                Style style = renderedPanel.getStyle();
                style.setFillColor(Color.white);
                renderedPanel.setStyle(style);
                renderedPanel.getSketch().getStyleRef().setDrawColor(
                        Color.white);
                renderedPanel.getSketch().getStyleRef().setFillColor(
                        Color.white);
                renderedPanel.getLabel().getStyleRef()
                        .setDrawColor(Color.white);
                renderedPanel.getLabel().getStyleRef()
                        .setFillColor(Color.white);
                //renderedPanel.getLabel().delete();
                
                Iterator it = map.keySet().iterator();
                while(it.hasNext())
                {
                    GraphicalObject gob = (GraphicalObject)it.next();
                    //System.err.print("clone : " + gob.getUniqueID() + " " + gob.getClass().toString() + "  --->  ");
                    GraphicalObject orig = (GraphicalObject)map.get(gob);
                    gob.setUniqueID(orig.getUniqueID());
                    //System.err.println("orig : " + gob.getUniqueID() + " " + gob.getClass().toString());
                }

                exportPanelToGif(panel, renderedPanel);
                exportPanelToHtml(panel, renderedPanel, map);
            }
        }
    }

    public static boolean isExporting() {
        return isExporting;
    }

    //=== MAIN EXPORT METHODS ===============================================
    //===========================================================================

} // of class

//==============================================================================

/*
 * Copyright (c) 1999-2001 Regents of the University of California. All rights
 * reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. All advertising materials mentioning features or use of this software must
 * display the following acknowledgement:
 * 
 * This product includes software developed by the Group for User Interface
 * Research at the University of California at Berkeley.
 * 
 * 4. The name of the University may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
