package edu.berkeley.guir.lib.gesture.features;

import edu.berkeley.guir.lib.gesture.Feature;
import edu.berkeley.guir.lib.gesture.Gesture;

public class Density1 extends Feature {
  public Density1()
  {
    super();
  }

  public Density1(Gesture g)
  {
    super(g);
  }

  public String getName()
  {
    // todo
    return "density1 (length/dist travelled)";
  }
  
  public double getMinValue()
  {
    return Double.MIN_VALUE;
  }
  
  public double getMaxValue()
  {
    return Double.MAX_VALUE;
  }
  
  protected void computeValue()
  {
    double totalLength = new TotalLength(gesture).getValue();
    double endsDist = new EndsDistance(gesture).getValue();

    if (endsDist != 0) {
      value = totalLength / endsDist;
    }
    else {
      value = 0;
    }
    valueOk = true;
  }

  public void scale(double factor)
  {
  }
}
