//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import java.awt.*;
import java.awt.geom.*;
import java.io.Serializable;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.view.*;

/**
 * Handles the view portions of GraphicalObjects.
 *
 * <P>
 * Everything in here is in local coordinates. That is, (0,0) is defined to be
 * the top-left corner of the GraphicalObject, without any transforms applied
 * anywhere.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Oct 06 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class ViewHandler 
   implements SatinConstants, Serializable, Cloneable {

   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   static final long serialVersionUID = 2848203958293850059L;

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================




   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   GraphicalObjectImpl attach;         // GOb we are attached to
   Style               style;          // style of the view
   AffineTransform     txNormalize;    // tx to get us to (0,0)
   View                v;              // current view

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTOR   =======================================================

   /**
    * For cloning purposes.
    */
   private ViewHandler() {
      initialize();
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Set the GraphicalObject that this view is attached to.
    */
   public ViewHandler(GraphicalObjectImpl gob) {
      attach = gob;
      initialize();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Copy constructor.
    *
    * @param viewHandler is the ViewHandler to copy.
    */
   public ViewHandler(ViewHandler viewHandler) {
     this.attach      =                   viewHandler.attach;
     this.style       = (Style)           viewHandler.style.clone();
     this.txNormalize = (AffineTransform) viewHandler.txNormalize.clone();
     this.v           = (View)            viewHandler.v.clone();
   } // of copy constructor

   //-----------------------------------------------------------------

   private void initialize() {
      //// 1. Initialize to some known value.
      style         = new Style();
      txNormalize   = new AffineTransform();
   } // of init

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================




   //===========================================================================
   //===    MODIFIER METHODS   =================================================

   /**
    * Set the GraphicalObject this ViewHandler is attached to.
    */
   public GraphicalObject setAttachedGraphicalObject(GraphicalObjectImpl gob) {
      attach   = gob;
      v.setAttachedGraphicalObject(gob);
      return (gob);
   } // of method

   //===    MODIFIER METHODS   =================================================
   //===========================================================================




   //===========================================================================
   //===    VIEW METHODS   =====================================================

   public void setView(View v) {
      this.v = v;
      v.setAttachedGraphicalObject(attach);
   } // of method

   //-----------------------------------------------------------------

   public View getView() {
      return (v);
   } // of method

   //-----------------------------------------------------------------

   public void setVisible(boolean flag) {
      v.setVisible(flag);
   } // of method

   //-----------------------------------------------------------------

   public boolean isVisible() {
      return (v.isVisible());
   } // of method

   //===    VIEW METHODS   =====================================================
   //===========================================================================




   //===========================================================================
   //===   STYLE METHODS   =====================================================

   public Style setStyle(Style newStyle) {
      try {
         style = (Style) newStyle.clone();
      }
      catch (Exception e) {
         Debug.println(e);
      }
      return (newStyle);
   } // of method

   //-----------------------------------------------------------------

   public Style getStyle() {
      return ((Style) style.clone());
   } // of method

   //-----------------------------------------------------------------

   public Style getStyleRef() {
      return (style);
   } // of method

   //===   STYLE METHODS   =====================================================
   //===========================================================================




   //===========================================================================
   //===   MISCELLANEOUS BOUNDING METHODS   ====================================

   /**
    * See if the view's bounding points are already normalized or not.
    *
    * @return true if normalized already, false if not.
    */
   public boolean isNormalized() {
      return (v.getBoundingPoints2DRef().isNormalized());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Normalize the view's bounding points, such that its
    * top-left bounds are at (0,0), keeping the transform correct.
    */
   public Point2D normalizeBoundingPoints() {
      //// 0. Don't do anything if already normalized.
      if (isNormalized() == true) {
         return null;
      }

      //// 1. Change the top-left corner to be (0,0).
      Point2D pt = v.getBoundingPoints2DRef().normalize();
      setNormalizingTransform(
            AffineTransform.getTranslateInstance(-pt.getX(), -pt.getY()));

      return pt;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the transform that would normalize this view to (0,0).
    */
   public AffineTransform getNormalizingTransform() {
      return (txNormalize);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Apply a new transform to the normalizing transform, the one that
    * specifies how to normalize the coordinates to (0,0).
    */
   public AffineTransform applyNormalizingTransform(AffineTransform newTx) {
      txNormalize.preConcatenate(newTx);
      return (newTx);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the transform that would normalize this view to (0,0).
    */
   public AffineTransform setNormalizingTransform(AffineTransform newTx) {
      //// 1. Calculate the new transform. First, undo the old
      ////    normalizing transform.
      AffineTransform txTmp = attach.getTransformRef();
      try {
         AffineTransform txInverse = txNormalize.createInverse();
         txInverse.preConcatenate(txTmp);
      }
      catch (Exception e) {
         //// this should never happen
         Debug.println(e);
      }

      //// 2.1. Now, apply the new normalizing transform.
      txTmp.concatenate(newTx);
      attach.setTransformInternal(txTmp);

      //// 2.2. Stupid hack [tm] because setTransform() blows it away.
      txNormalize = (AffineTransform) newTx.clone();
      return (newTx);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the normalizing transform to the identity if it is not already.
    */
   public void clearNormalizingTransform() {
      if (txNormalize.isIdentity() == false) {
         txNormalize.setToIdentity();
      }
   } // of method

   //===   MISCELLANEOUS BOUNDING METHODS   ====================================
   //===========================================================================




   //===========================================================================
   //===   BOUNDING METHODS   ==================================================

   /**
    * Set the shape of this view (local coordinates).
    *
    * @param s is the shape to set to.
    */
   public void setViewBoundingPoints2D(Shape s) {
      //// 1. Set the view bounding points.
      v.setBoundingPoints2DRef(new Polygon2D(s));

      //// 2. Normalize the bounding points.
      normalizeBoundingPoints();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the shape of the view (local coordinates).
    *
    * @param newPoly will be copied.
    */
   public void setViewBoundingPoints2D(Polygon2D newPoly) {
      //// 1. Set the view bounding points.
      v.setBoundingPoints2DRef(new Polygon2D(newPoly));

      //// 2. Normalize the bounding points.
      normalizeBoundingPoints();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set a reference to the shape of the view (local coordinates).
    *
    * @param newPoly is the polygon to set the reference to.
    */
   public void setViewBoundingPoints2DRef(Polygon2D newPoly) {
      v.setBoundingPoints2DRef(newPoly);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the view bounding points.
    */
   public Polygon2D getViewBoundingPoints2D() {
      return (new Polygon2D(v.getBoundingPoints2DRef()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a reference to the view bounding points.
    */
   public Polygon2D getViewBoundingPoints2DRef() {
      return (v.getBoundingPoints2DRef());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set whether the view has closed bounding points or not.
    */
   public boolean setHasClosedBoundingPoints(boolean flag) {
      v.getBoundingPoints2DRef().setClosed(flag);
      return (flag);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Check whether the view has closed bounding points or not.
    */
   public boolean hasClosedBoundingPoints() {
      return (v.getBoundingPoints2DRef().isClosed());
   } // of method

   //===   BOUNDING METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   RENDERING METHODS   =================================================

   public void render(SatinGraphics g) {
      if (isVisible() == true) {
         v.render(g);
      }
   } // of method

   //===   RENDERING METHODS   =================================================
   //===========================================================================




   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 1. Append data.
      strbuf.append(  "bounds: " + getViewBoundingPoints2DRef());
      strbuf.append("\nstyle:  " + getStyleRef());
      strbuf.append("\nview:   " + getView());

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================




   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (new ViewHandler(this));
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
