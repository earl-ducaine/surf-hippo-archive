package edu.berkeley.guir.lib.gesture;

import java.io.Serializable;

/**
 * Gestures specifically for testing the recognition of a recognizer
 */
public class GestureTestSet extends GestureSet
implements Serializable, Cloneable {
}
