package edu.berkeley.guir.lib.awt.image;

import java.awt.image.*;
import java.util.Hashtable;
import java.util.Vector;

/**
 * <PRE>
 * Revisions:  - GUIRLib-v1.0-1.0.0, Jan 21 2000, FL
 *               Created class
 *             - GUIRLib-v1.4-1.0.0, Aug 31 2000, JH
 *               Touched for GUIRLib release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~fli/">Francis Li</A> (
 *          <A HREF="mailto:fli@cs.berkeley.edu">fli@cs.berkeley.edu</A>)
 * @since   JDK 1.3
 * @version GUIRLib-v1.4-1.0.0, Aug 31 2000
 */
public class FrameGrabber implements ImageConsumer
{
   protected Vector vecImages = new Vector ();
   protected BufferedImage bimgCurrent = null;
   protected Hashtable hashCurrent = new Hashtable ();
   protected ColorModel modelCurrent = ColorModel.getRGBdefault ();
   protected int intWidth = -1, intHeight = -1;

   protected Vector vecObservers = new Vector ();   
   
   /** Creates new TwainConsumer */
   public FrameGrabber () 
   {
   }
   
   public Vector getImages ()
   {
      return (Vector) vecImages.clone ();
   }
   
   public void clearImages ()
   {
      vecImages.clear ();
   }
   
   public void addObserver (ImageObserver io)
   {
      if (null != io)
         if (false == vecObservers.contains (io))
            vecObservers.add (io);      
   }
   
   public void removeObserver (ImageObserver io)
   {
      if (null != io)
         vecObservers.remove (io);
   }
   
   public void setProperties (Hashtable props) 
   {
      hashCurrent = props;         
   }
   
   public void setPixels (int x, int y, int w, int h, ColorModel cm, int[] pixels, int off, int scansize) 
   {
      if (null == bimgCurrent)
      {
         if ((intWidth > 0) && (intHeight > 0))
         {
            if (null == modelCurrent)
               bimgCurrent = new BufferedImage (intWidth, intHeight, BufferedImage.TYPE_INT_RGB);
            else
               bimgCurrent = new BufferedImage (modelCurrent, modelCurrent.createCompatibleWritableRaster (intWidth, intHeight), modelCurrent.isAlphaPremultiplied(), hashCurrent);
         }
      }
      
      for (int i = 0; i < h; i++)
      {
         for (int j = 0; j < w; j++)
         {
            int pix = pixels[(x + j) + (y + i) * scansize];
            bimgCurrent.setRGB (x + j, y + i, cm.getRGB (pix));
         }
      }
   }
   
   public void setPixels (int x, int y, int w, int h, ColorModel cm, byte[] pixels, int off, int scansize)
   {
   }
   
   public void setColorModel (ColorModel model) 
   {
      modelCurrent = model;
   }
   
   public void imageComplete (int status) 
   {
      switch (status)
      {
         case ImageConsumer.SINGLEFRAMEDONE:
         case ImageConsumer.STATICIMAGEDONE:
         {
            if (null != bimgCurrent)
            {
               vecImages.add (bimgCurrent);
               int intFlags = ImageObserver.WIDTH | ImageObserver.HEIGHT;
               intFlags |= (status == ImageConsumer.SINGLEFRAMEDONE) ? ImageObserver.FRAMEBITS : ImageObserver.ALLBITS;
               for (int i = 0; i < vecObservers.size (); i++)
                  ((ImageObserver) vecObservers.elementAt (i)).imageUpdate (bimgCurrent, intFlags, 0, 0, intWidth, intHeight);
            }
            break;
         }
         case ImageConsumer.IMAGEABORTED:
         {
            for (int i = 0; i < vecObservers.size (); i++)
               ((ImageObserver) vecObservers.elementAt (i)).imageUpdate (null, ImageObserver.ABORT, 0, 0, 0, 0);
            
            break;
         }            
         case ImageConsumer.IMAGEERROR:
         {
            for (int i = 0; i < vecObservers.size (); i++)
               ((ImageObserver) vecObservers.elementAt (i)).imageUpdate (null, ImageObserver.ERROR, 0, 0, 0, 0);
            
            break;
         }            
         default:
         {
         }
      }
      
      bimgCurrent = null;
      hashCurrent = new Hashtable ();
      modelCurrent = ColorModel.getRGBdefault ();
      intWidth = intHeight = -1;
   }
   
   public void setDimensions (int width, int height) 
   {
      intWidth = width;
      intHeight = height;
   }
   
   public void setHints (int hintflags) 
   {
   }
}

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/




