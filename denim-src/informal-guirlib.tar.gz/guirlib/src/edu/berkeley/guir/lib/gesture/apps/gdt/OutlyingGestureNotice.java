package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.util.List;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.Misc;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;

public class OutlyingGestureNotice extends DefaultNotice {
  static protected Icon INFO_ICON = new
    ImageIcon(GestureTree.class.getResource("images/graphics-repository/toolbarButtonGraphics/general/Information24.gif"));
  private List outlyingGestures;
  private MainFrame mainFrame;
  private GestureActionListener gestureActionListener;
  
  public OutlyingGestureNotice(MainFrame mf, List outlyingGestures)
  {
    mainFrame = mf;
    this.outlyingGestures = outlyingGestures;
    gestureActionListener = new GestureActionListener();
  }

  public boolean hasExpired()
  {
    // todo: fix this
    return outlyingGestures.size() == 0;
  }

  protected void displayImpl(SummaryLog log)
  {
    //System.out.println("MN: display: " + outlyingGestures.size());
    if (!hasExpired()) {
      log.append("There are " + outlyingGestures.size() + " ");
      log.appendLink("training gestures", gestureActionListener,
		     "Make a new view of the training gestures");
      log.append(" that are very different from others for their gesture category. This may indicate mistakes in entering training gestures.");
    }
  }

  protected void displaySummaryImpl(SummaryLog log)
  {
    log.appendLink(outlyingGestures.size() + " training gestures",
		   gestureActionListener,
		   "Make a new view of the training gestures");
  }

  public String getName()
  {
    return "Outlying gestures";
  }

  public List getObjectList()
  {
    return outlyingGestures;
  }

  public String getReferenceTag()
  {
    return "Outlying Gesture";
  }

  protected class GestureActionListener implements ActionListener {
    public void actionPerformed(ActionEvent e)
    {
      ShadowGestureContainer container =
	new ShadowGestureContainer(outlyingGestures);
      container.setName("Outlying gestures");
      JScrollPane scrollPane = new JScrollPane();
      OutlyingGestureContainerPanel panel =
	new OutlyingGestureContainerPanel(scrollPane);
      panel.setShadowGestureContainer(container);
      GInternalFrame iFrame = GInternalFrame.
	makeInternalFrame(container, panel, scrollPane);
      mainFrame.getDesktop().showFrame(iFrame);
    }
  }
  
  protected class OutlyingGestureContainerPanel
    extends GestureContainerPanel {
    protected final Border BORDER = BorderFactory.createEtchedBorder();
    protected ShadowGestureContainer shadowContainer;


    public OutlyingGestureContainerPanel(JScrollPane scroller)
    {
      super(scroller);
    }

    public void setShadowGestureContainer(ShadowGestureContainer container)
    {
      shadowContainer = container;
      super.setGestureContainer(container);
    }
    
    protected void addGestureObject(GestureObject gestureObj,
				    JScrollPane scrollPane, int index)
    {
      final Gesture gesture = (Gesture) gestureObj;
      GestureObjectPanel gesturePanel = (GestureObjectPanel)
	DisplayFactory.create(gestureObj, scrollPane);
      JButton okButton = new JButton("Gesture OK");
      okButton.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	  shadowContainer.remove(gesture, false);
	}
      });
      JButton button = new JButton("Show " + gesture.getParent().getName());
      button.setForeground(Color.green.darker().darker());
      button.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	  GestureDesktop desktop = (GestureDesktop) SwingUtilities.
	    getAncestorOfClass(GestureDesktop.class, (Component)
			       e.getSource());
	  desktop.showFrame(gesture.getParent());
	}
      });
      JButton infoButton = new JButton(INFO_ICON);
      infoButton.setMargin(new Insets(1, 1, 1, 1));
      ActionListener infoActionListener =
	new InfoActionListener(gesture);
      infoButton.addActionListener(infoActionListener);
      JPanel buttonPanel = new JPanel();
      buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
      buttonPanel.add(okButton);
      buttonPanel.add(Box.createHorizontalGlue());
      buttonPanel.add(button);
      buttonPanel.add(Box.createHorizontalGlue());
      buttonPanel.add(infoButton);
      gesturePanel.add(buttonPanel, BorderLayout.SOUTH);
      gesturePanel.setBorder(BORDER);
      this.add(gesturePanel, index);
    }
  }

  public class InfoActionListener implements ActionListener {
    protected Gesture gesture;
    
    public InfoActionListener(Gesture g)
    {
      gesture = g;
    }
    
    public void actionPerformed(ActionEvent event)
    {
      Classifier classifier = mainFrame.getClassifier();
      GestureCategory category = (GestureCategory) gesture.getParent();
      // need to use the name because it might be a category in a
      // training set
      double[] distByFeature = classifier.
	getNormalizedDistancesByFeature(gesture, category.getName());
      int maxDistIndex = Misc.maxAbsIndex(Misc.promoteArray(distByFeature));
      Class[] featureClasses = classifier.getFeatureClasses();
      Feature dummyFeature = null;
      try {
	dummyFeature = (Feature) featureClasses[maxDistIndex].newInstance();
      }
      catch (InstantiationException e) {
	System.err.println
	  ("Warning: could not instantiate feature of class '"
	   + featureClasses[maxDistIndex].getName() + "':" + e);
	return;
      }
      catch (IllegalAccessException e) {
	System.err.println("Warning: could not access class '"
			   + featureClasses[maxDistIndex].getName() + "':"
			   + e);
	return;
      }
      mainFrame.getNoticeHandler().
	showNotice(new FeatureNotice
		   (dummyFeature, gesture,
		    Misc.sign(distByFeature[maxDistIndex])));
    }
  }
}
