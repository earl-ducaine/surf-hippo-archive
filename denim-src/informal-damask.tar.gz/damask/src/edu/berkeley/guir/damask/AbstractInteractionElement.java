package edu.berkeley.guir.damask;

import java.awt.geom.*;
import java.lang.ref.WeakReference;
import java.util.*;

import edu.berkeley.guir.damask.event.InteractionElementListener;
import edu.berkeley.guir.damask.event.InteractionElementSource;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.id.GUID;
import edu.berkeley.guir.lib.util.ClassLib;

/** 
 * An element of interaction. This includes pages, components, and interaction
 * graphs.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2003 James Lin
 *                               Created InteractionElement.
 *             1.1.0  06-12-2003 James Lin
 *                               Split AbstractInteractionElement from
 *                               InteractionElement.
 *             1.2.0  06-25-2003 James Lin
 *                               Split AbstractPatternInstanceMember from
 *                               AbstractInteractionElement.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.2.0, 06-25-2003
 */
public abstract class AbstractInteractionElement implements InteractionElement {
   private GUID id;
   private WeakReference cloneSource;   // if this object was created as
                                        // a result of clone, then
                                        // cloneSource is the source of
                                        // the clone operation
   private WeakReference lastClone;     // the object that was created by
                                        // the most recent clone operation
   private Map/*<DeviceType, Rectangle2D>*/ bounds = new HashMap();
   private Map/*<DeviceType, AffineTransform>*/ transforms = new HashMap();
   
   private InteractionElementSource elementEventSource =
      new InteractionElementSource();
   
   //===========================================================================
   
   public AbstractInteractionElement() {
      id = new GUID();
      cloneSource = null;
      lastClone = null;
   }
   
   //---------------------------------------------------------------------------
   
   public AbstractInteractionElement(final AbstractInteractionElement element) {
      this();
      bounds = new HashMap/*<DeviceType, Rectangle2D>*/(element.bounds);
      transforms =
         new HashMap/*<DeviceType, AffineTransform>*/(element.transforms);
   }
   
   //===========================================================================
   
   /**
    * Returns the ID of this element.
    */
   public GUID getId() {
      return id;
   }
   
   //===========================================================================
   
   /**
    * Returns the object that was cloned to create this object, if this
    * object was created via a call to clone(). Returns null if this object
    * was not created by a clone, or if the original object has been
    * garbage collected.
    */
   public InteractionElement getCloneSourceIfAlive() {
      if (cloneSource != null) {
         return (InteractionElement)cloneSource.get();
      }
      else {
         return null;
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the object that was most recently cloned from this object,
    * or null if there has been no clones created or if the clone has been
    * garbage collected.
    */
   public InteractionElement getMostRecentCloneIfAlive() {
      if (lastClone != null) {
         return (InteractionElement)lastClone.get();
      }
      else {
         return null;
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the interaction graph that the connection is in, or null if
    * it's not in any graph.
    */
   public abstract InteractionGraph getInteractionGraph();

   //===========================================================================
   
   /**
    * Returns all of the device types that this element is visible to. 
    */
   public Set/*<DeviceType>*/ getDeviceTypesVisibleTo() {
      // Most implementations are more strict than this (e.g., Component, Page)
      return new HashSet(bounds.keySet());
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns whether this this element is visible to the given device type. 
    */
   public boolean isVisibleToDeviceType(final DeviceType deviceType) {
      if (deviceType == DeviceType.ALL) {
         final Set/*<DeviceType>*/ visibleDeviceTypes =
            getDeviceTypesVisibleTo();
         final Set/*<DeviceType>*/ allDeviceTypes =
            new HashSet(DeviceType.ALL.getSpecificDeviceTypes());
            
         for (Iterator i = visibleDeviceTypes.iterator(); i.hasNext(); ) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            allDeviceTypes.remove(aDeviceType);
         }
         return allDeviceTypes.isEmpty();
      }
      else {
         return getDeviceTypesVisibleTo().contains(deviceType);
      }
   }
   
   //===========================================================================
   
   public Rectangle2D getBounds(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      final Rectangle2D result = (Rectangle2D) bounds.get(deviceType);
      if (result == null) {
         return null;
      }
      else {
         return (Rectangle2D)result.clone();
      }
   }
   
   //---------------------------------------------------------------------------
   
   public Rectangle2D getBoundsInParentCoords(final DeviceType deviceType) {
      final Rectangle2D bounds = getBounds(deviceType);
      if (bounds == null) {
         return null;
      }

      final AffineTransform transform = getTransform(deviceType);
      return GeomLib.transformRectangle(transform, bounds);
   }
   
   //---------------------------------------------------------------------------
   
   public void setBounds(
      final DeviceType deviceType,
      final Rectangle2D newBounds) {

      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(deviceType),
         this + " supports " + getDeviceTypesVisibleTo() + ", not " +
         deviceType);

      final Rectangle2D newBoundsClone;
      if (newBounds == null) {
         newBoundsClone = null;
      }
      else {
         newBoundsClone = (Rectangle2D)newBounds.clone();
      }
      
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
           i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next(); 
         bounds.put(aDeviceType, newBoundsClone);
         fireElementBoundsUpdated(aDeviceType);
      }
   }

   //---------------------------------------------------------------------------
   
   public Point2D getLocation(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      final Rectangle2D bounds = getBounds(deviceType);
      return new Point2D.Double(bounds.getX(), bounds.getY());
   }
   
   //---------------------------------------------------------------------------
   
   public void setLocation(
      final DeviceType deviceType,
      final Point2D newLocation) {

      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(deviceType),
         this + " supports " + getDeviceTypesVisibleTo() + ", not " +
         deviceType);

      final Collection c = deviceType.getSpecificDeviceTypes();
      for (Iterator i = c.iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next(); 
         final Rectangle2D newBounds = getBounds(aDeviceType);
         newBounds.setRect(
            newLocation.getX(),
            newLocation.getY(),
            newBounds.getWidth(),
            newBounds.getHeight());
         bounds.put(aDeviceType, newBounds);
         fireElementBoundsUpdated(aDeviceType);
      }
   }
   
   //---------------------------------------------------------------------------
   
   public AffineTransform getTransform(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      final AffineTransform result =
         (AffineTransform) transforms.get(deviceType);
      if (result == null) {
         return new AffineTransform();
      }
      else {
         return (AffineTransform) result.clone();
      }
   }
   
   //---------------------------------------------------------------------------
   
   public void setTransform(
      final DeviceType deviceType,
      final AffineTransform newTransform) {

      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(deviceType),
         this + " supports " + getDeviceTypesVisibleTo() + ", not " +
         deviceType);

      final AffineTransform newTransformClone;
      if (newTransform == null) {
         newTransformClone = null;
      }
      else {
         newTransformClone = (AffineTransform)newTransform.clone();
      }

      final Collection c = deviceType.getSpecificDeviceTypes();
      for (Iterator i = c.iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         transforms.put(aDeviceType, newTransformClone);
         fireElementTransformUpdated(aDeviceType);
      }
   }

   //===========================================================================

   /**
    * Adds the specified element listener to receive events from this element.
    */
   public void addInteractionElementListener(
      final InteractionElementListener listener) {

      elementEventSource.addInteractionElementListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified element listener so that it no longer receives
    * events from this element.
    */
   public void removeInteractionElementListener(
      final InteractionElementListener listener) {

      elementEventSource.removeInteractionElementListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementBoundsUpdated events to listeners.
    */
   protected void fireElementBoundsUpdated(final DeviceType deviceType) {
      elementEventSource.fireElementBoundsUpdated(this, deviceType);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementTransformUpdated events to listeners.
    */
   protected void fireElementTransformUpdated(final DeviceType deviceType) {
      elementEventSource.fireElementTransformUpdated(this, deviceType);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementBorderUpdated events to listeners.
    */
   protected void fireElementBorderUpdated(final DeviceType deviceType) {
      elementEventSource.fireElementBorderUpdated(this, deviceType);
   }
   
   //===========================================================================
   
   public Object clone() {
      try {
         AbstractInteractionElement clone =
            (AbstractInteractionElement) super.clone();
         clone.id = new GUID();
         clone.bounds = new HashMap(bounds);
         clone.transforms = new HashMap(transforms);
         clone.elementEventSource = new InteractionElementSource();
         clone.cloneSource = new WeakReference(this);
         lastClone = new WeakReference(clone);
         
         return clone;
      }
      catch (CloneNotSupportedException e) {
         throw new Error("Object doesn't support clone - yeah right");
      }
   }

   //===========================================================================
   
   /**
    * Returns a short string representation of this element.
    */
   public String toString() {
      final StringBuffer sb = new StringBuffer();
      final String className = ClassLib.getShortClassName(this);
      sb.append(className.replaceAll("\\$", "."));
      sb.append(getId().toShortString());
      
      return sb.toString();
   }
   
   //---------------------------------------------------------------------------
   
   public abstract String toLongString(
      int indentLevel,
      final DeviceType deviceType);
}
