package edu.berkeley.guir.lib.gesture;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Wrap a GSStarPlot in a JFrame.  Add a menubar for setting options.
 */
public class GSStarPlotFrame extends JFrame
{
  GSStarPlot plot;
  FeaturePicker featurePicker = null;
  
  public GSStarPlotFrame(Classifier classifier)
  {
    this(classifier, "Star plot: " + classifier.getGestureSet().getName());
  }
       
  public GSStarPlotFrame(Classifier classifier, String name)
  {
    super(name);
    buildUI(classifier);
  }

  void buildUI(Classifier classifier)
  {
    Container contents = getContentPane();
    contents.setLayout(new BorderLayout());
    plot = new GSStarPlot(classifier);
    JScrollPane scrollPane = new JScrollPane(plot);
    scrollPane.
      setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
    scrollPane.setPreferredSize(new Dimension(500, 200));
    
    contents.add(scrollPane, BorderLayout.CENTER);

    JMenu menu;
    JMenuItem item;
    ActionListener listener;
    JMenuBar menuBar = new JMenuBar();
    
    menu = new JMenu("Plot");
    /* todo
    item = new JMenuItem("Filter features");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	if (featurePicker == null) {
	  featurePicker = new FeaturePicker("Star plot features");
	  featurePicker.pack();
	  plot.setFeaturePicker(featurePicker);
	}
	featurePicker.show();
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    */
    
    item = new JMenuItem("Close");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	GSStarPlotFrame.this.dispose();
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    // add more Plot items here
    menuBar.add(menu);

    menu = new JMenu("View");

    /*
    item = new JMenuItem("Toggle log scale");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	plot.setLogScale(!plot.getLogScale());
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    item = new JMenuItem("Zoom in");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	plot.setScale(plot.getScale() * 2);
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    item = new JMenuItem("Zoom out");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	plot.setScale(plot.getScale() / 2);
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    */
    
    // add more View items here
    menuBar.add(menu);
    
    getRootPane().setJMenuBar(menuBar);
    pack();
  }
}
