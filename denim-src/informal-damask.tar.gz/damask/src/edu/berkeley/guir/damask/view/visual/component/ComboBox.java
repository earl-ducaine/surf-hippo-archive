package edu.berkeley.guir.damask.view.visual.component;

import java.awt.Color;
import java.awt.geom.*;
import java.util.Iterator;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.SelectOne;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.visual.dialog.PageView;
import edu.berkeley.guir.damask.view.visual.dialog.PageViewContainer;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.util.PPaintContext;
import edu.umd.cs.piccolo.util.PPickPath;

/** 
 * A combo box.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-08-2004 James Lin
 *                               Created ComboBox.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 02-08-2004
 */
public class ComboBox extends ControlView {
   private static final int ARROW_WIDTH = 10;
   private static final int ARROW_HEIGHT = 7;

   private static final int DEFAULT_WIDTH = 100;
   protected static final int DEFAULT_HEIGHT =
      (int)DamaskAppUtils
         .getRenderedTextBounds(
            "AAA",
            DamaskAppUtils.getDefaultFont().getSize())
         .getHeight();
   private static final int DROP_DOWN_LIST_SIZE = 5;
   
   private final PPath downArrow;
   
   private final ListBox dropDownList;
   private Label selectedLabel = null;
   private SelectOne.Item selectedItem;

   /**
    * Constructs a combo box and associates it with the specified select-one
    * object. 
    */
   public ComboBox(final SelectOne selectOne) {
      super(selectOne, new RunModeEventHandler());
      
      setStretchedWhenResized(false);
      
      setStrokePaint(Color.BLACK);
      setPaint(Color.WHITE);
      
      // Create the list box that will appear when the user clicks the down
      // arrow in Run mode.
      dropDownList = new ListBox(selectOne, false);
      
      // Add the down arrow.
      downArrow = createDownArrow();
      addChild(downArrow);
   }
   
   
   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      final DeviceType deviceType = getDeviceType();
      final SelectOne selectOne = (SelectOne)getModel();
      
      // Set the border
      final Rectangle2D bounds = selectOne.getBounds(deviceType); 
      setPathTo(bounds);

      dropDownList.setVisible(false);
      dropDownList.setSelectable(false);
      dropDownList.setPickable(false);
      
      getParent().addChild(dropDownList);
      dropDownList.setPathTo(
         new Rectangle2D.Double(
            0, 0,
            getWidth(), DROP_DOWN_LIST_SIZE * ListBox.DEFAULT_LINE_HEIGHT));
      dropDownList.setOffset(
         getFullBounds().getX(),
         getFullBounds().getMaxY());
      
      // Set the state of the combo box to match the model
      final PageView pageView = getPageView();
      if (pageView != null) {
         final Dialog pageDialog = ((Page)(pageView.getModel())).getDialog();
         final Dialog controlDialog = selectOne.getDialog();
         final int condition;
         if (pageDialog == controlDialog) {
            condition = pageView.getDesignTimeCondition();
         }
         else {
            // Combo box actually represents a template control
            condition = controlDialog.getInitialCondition();
         }
         setState(
            selectOne.getStateForCondition(controlDialog, condition));
      }
   }


   /**
    * Draws the down arrow for the combo box.
    */
   private static PPath createDownArrow() {
      // Draw down arrow
      final GeneralPath downArrowPath = new GeneralPath();
      downArrowPath.moveTo(ARROW_WIDTH / 2, ARROW_HEIGHT);
      downArrowPath.lineTo(ARROW_WIDTH, 0);
      downArrowPath.lineTo(0, 0);
      downArrowPath.closePath();
         
      final PPath downArrow = new PPath(downArrowPath);
      downArrow.setPaint(Color.BLACK);
      downArrow.setPickable(false);
      
      return downArrow;
   }

   /**
    * Returns the contents of this list box.
    */
   public Object getEditableContents() {
      return dropDownList.getEditableContents();
   }


   /**
    * Returns the selected item in this list box.
    * 
    * @return an instance of {@link edu.berkeley.guir.damask.component.SelectOne.Item}
    */
   public Object getState() {
      return selectedItem;
   }


   /**
    * Sets the selected item in this list box.
    * 
    * @param state an instance of {@link edu.berkeley.guir.damask.component.SelectOne.Item}
    */
   public void setState(final Object state) {
      selectedItem = (SelectOne.Item)state;
      dropDownList.setState(state);
      if (selectedLabel != null) {
         selectedLabel.dispose();
         selectedLabel.removeFromParent();
      }
      if (selectedItem != null) {
         selectedLabel = new Label(selectedItem.getContent(), false);
         selectedLabel.setPickable(false);
         addChild(selectedLabel);
      }
      dropDownList.setVisible(false);
      dropDownList.setPickable(false);
   }

   /**
    * Returns the number of items in this list box.
    */
   protected int getItemCount() {
      return dropDownList.getItemCount();
   }


   /**
    * Returns a representation of what a list box looks like by default.
    */
   public static PNode createTempView() {
      final PPath border =
         new PPath(new Rectangle2D.Double(0, 0, DEFAULT_WIDTH, DEFAULT_HEIGHT));

      // construct squiggles for list box items
      final int[] itemSquiggleLengths = new int[] { 4, 3, 5 };
      
      final PNode squiggles =
         DamaskAppUtils.createSquiggles(itemSquiggleLengths);
      border.addChild(squiggles);
      final double oldHeight = squiggles.getHeight();
      squiggles.setBounds(0, 0, DEFAULT_WIDTH, DEFAULT_HEIGHT);
      squiggles.setOffset(0, 0);
      
      // Vertically center the squiggles within the list box item
      if (oldHeight < DEFAULT_HEIGHT) {
         final AffineTransform centeringTransform =
            AffineTransform.getTranslateInstance(
               0, (DEFAULT_HEIGHT - oldHeight) / 2);
         for (Iterator j = squiggles.getChildrenIterator(); j.hasNext(); ) {
            final PPath child = (PPath)j.next();
            child.getPathReference().transform(centeringTransform);
         }
      }
      
      final PPath downArrow = createDownArrow();
      
      downArrow.setOffset(
         DEFAULT_WIDTH - 5 - downArrow.getWidth(),
         (DEFAULT_HEIGHT - downArrow.getHeight()) / 2);

      border.addChild(downArrow);
      
      return border;
   }

   /**
    * Returns the list that drops down when the user clicks on the combo box.
    */
   protected ListBox getDropDownList() {
      return dropDownList;
   }

   // Overrides method in parent class.
   public void setInRunMode(boolean flag) {
      super.setInRunMode(flag);
      dropDownList.setInRunMode(flag);
   }
   
   
   // Overrides method in superclass.
   protected void layoutChildren() {
      if (selectedLabel != null) {
         final AffineTransform centeringTransform =
            AffineTransform.getTranslateInstance(
               0, (getHeight() - selectedLabel.getHeight()) / 2);
         selectedLabel.setTransform(centeringTransform);
      }
      downArrow.setOffset(
         getWidth() - 5 - downArrow.getWidth(),
         (getHeight() - downArrow.getHeight()) / 2);
   }
   

   //=========================================================================
   // The code below mimics functionality in edu.umd.cs.piccolox.nodes.PClip.

   protected void paint(PPaintContext paintContext) {
      clipPaint(paintContext);
   }

   protected void paintAfterChildren(PPaintContext paintContext) {
      clipPaintAfterChildren(paintContext);
   }

   public boolean fullPick(PPickPath pickPath) {
      return clipFullPick(pickPath);
   }

   // The code above mimics functionality in edu.umd.cs.piccolox.nodes.PClip.
   //=========================================================================


   /**
    * The event handler for a list box in Run mode.
    */
   private static class RunModeEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         if (event.getPickedNode() instanceof ComboBox) {
            final ComboBox comboBox = (ComboBox)event.getPickedNode();

            // Set the border of the list box
            final ListBox dropDownList = comboBox.getDropDownList();
            if (dropDownList.getVisible()) {
               dropDownList.setVisible(false);
               dropDownList.setPickable(false);
            }
            else {
               dropDownList.setPathTo(
                  new Rectangle2D.Double(
                     0,
                     0,
                     comboBox.getWidth(),
                     DROP_DOWN_LIST_SIZE * ListBox.DEFAULT_LINE_HEIGHT));
               dropDownList.setOffset(
                  comboBox.getFullBounds().getX(),
                  comboBox.getFullBounds().getMaxY());
               dropDownList.setState(comboBox.getState());
               dropDownList.setVisible(true);
               dropDownList.setPickable(true);
            }
         }
         container.setFocus((ComboBox)
            DamaskAppUtils.getAncestor(event.getPickedNode(), ComboBox.class));
      }
   }
}
