package edu.berkeley.guir.denim.components;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;

import javax.swing.*;
import java.util.*;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

/**
 * An instance of a push button in a DENIM design. This is a built-in
 * component.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-21-1999  James Lin
 *                                Created DenimButtonInstance
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 08-21-1999
 */

public class DenimButtonInstance
   extends DenimIntrinsicComponentInstance
   implements CaptionedGraphicalObject {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 3725842061214852532L;
   private static final int DEFAULT_WIDTH = 80;
   private static final int DEFAULT_HEIGHT = 20;
   private static final int DEFAULT_CORNER_RADIUS = 7;
   private static final int MARGIN_X = 8;
   private static final int MARGIN_Y = 4;

   //===   CONSTANTS   =========================================================
   //===========================================================================

   //===========================================================================
   //===   FIELDS   ============================================================

   private Patch inverse;
   private TimedStroke border;
   private DenimText caption;
   
   // true if radio button was stamped, false if it was sketched
   private boolean createdByStamp;

   //===   FIELDS   ============================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create an instance of a DENIM button. Called only by
    * DenimButton.newInstance().
    *
    * @param type an instance of DenimButton
    */
   DenimButtonInstance(DenimComponent type) {
      super(type);

      assert (type instanceof DenimButton):
         "DenimButtonInstance can only be created by DenimButton";
         
      super.matters = false;

      // construct button's perimeter
      Style style = this.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      this.setStyle(style);
      
      border = new TimedStroke(
                  new RoundRectangle2D.Double(0, 0,
                                              DEFAULT_WIDTH, DEFAULT_HEIGHT,
                                              DEFAULT_CORNER_RADIUS, 
                                              DEFAULT_CORNER_RADIUS));

      this.setBoundingPoints2D(COORD_LOCAL, border);
      
      displayedState = new PatchImpl(border);
      
      // igore strokes
      this.setIgnoreStrokes(true);
      ((PatchImpl)displayedState).setIgnoreStrokes(true);
      
      style = displayedState.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setFillColor(Color.WHITE);
      style.setLineWidth(1.0f);
      displayedState.setStyle(style);

      // construct squiggle in button
      DenimText squiggle = DenimIntrinsicComponent.createSquiggle();
      this.caption = squiggle;
      ((Patch)displayedState).add(squiggle);
      squiggle.moveTo(COORD_REL,
                      (displayedState.getWidth2D(COORD_LOCAL) -
                       squiggle.getWidth2D(COORD_REL)) / 2,
                      (displayedState.getHeight2D(COORD_LOCAL) -
                       squiggle.getHeight2D(COORD_REL)) / 2);

      this.add(displayedState);

      // Create inverse image of button      
      inverse = new PatchImpl(displayedState);
      
      style = inverse.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setFillColor(Color.BLACK);
      style.setLineWidth(1.0f);
      inverse.setStyle(style);
      
      ScribbledText inverseSquiggle = (ScribbledText)squiggle.deepClone();
      inverseSquiggle.setColor(Color.WHITE);
      inverseSquiggle.setBackground(Color.BLACK);
      inverse.add(inverseSquiggle, GraphicalObjectGroup.KEEP_REL_POS);
      

      

   }

   
   //-----------------------------------------------------------------

   /**
    * Create an instance of a DENIM button, which will look like the given
    * objects. The parameters are not modified.
    * 
    * Called only by DenimButton.newInstance().
    */
   DenimButtonInstance(DenimComponent type,
                       TimedStroke newBorder,
                       DenimText newCaption) {
      super(type);
      
      super.matters = false;
      
      this.border = (TimedStroke)newBorder.deepClone();

      assert (type instanceof DenimButton):
         "DenimButtonInstance can only be created by DenimButton";

      this.setBoundingPoints2D(COORD_LOCAL,
                               border.getBoundingPoints2D(COORD_LOCAL));

      Style style = this.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      this.setStyle(style);
      
      displayedState = new PatchImpl(border);

      // igore strokes
      this.setIgnoreStrokes(true);
      ((PatchImpl)displayedState).setIgnoreStrokes(true);

      style = displayedState.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setFillColor(Color.WHITE);
      style.setLineWidth(1.0f);
      displayedState.setStyle(style);

      this.caption = (DenimText)newCaption.deepClone();   
      ((Patch)displayedState).add(this.caption);
         
      // Change each object's transform so that its coordinates stay 
      // the same
      AffineTransform newTx = border.getInverseTransform(COORD_ABS);
      newTx.concatenate(newCaption.getTransform(COORD_ABS));
      this.caption.setTransform(newTx);

      this.add(displayedState);
      
      // Create inverse of button
      inverse = new PatchImpl(border);
      
      style = inverse.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setFillColor(Color.BLACK);
      style.setLineWidth(1.0f);
      inverse.setStyle(style);

      DenimText inverseCaption = (DenimText)this.caption.deepClone();
      inverseCaption.setColor(Color.WHITE);
      inverseCaption.setBackground(Color.BLACK);
      inverse.add(inverseCaption);
      
      
   }

   //-----------------------------------------------------------------

   DenimButtonInstance(DenimComponent type,
                       Rectangle2D bounds,
                       TimedStroke border,
                       DenimText caption,
                       boolean createdByStamp) {
      super(type);
      
      super.matters = false;
      
      this.setBoundingPoints2D(COORD_LOCAL, bounds);
      this.border = border;
      this.caption = caption;
      this.createdByStamp = createdByStamp;

      displayedState = new PatchImpl(bounds);
      
      // igore strokes
      this.setIgnoreStrokes(true);
      ((PatchImpl)displayedState).setIgnoreStrokes(true);

      Style style = displayedState.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      style.setLineWidth(1.0f);
      displayedState.setStyle(style);

      // Make border
      style = border.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setLineWidth(1.0f);
      border.setStyle(style);
      ((Patch)displayedState).add(border, KEEP_REL_POS);

      // Make caption
      ((Patch)displayedState).add(caption, KEEP_REL_POS);
      
      this.add(displayedState, KEEP_REL_POS);
      
      // Create inverse of button
      inverse = new PatchImpl(border);
      
      style = inverse.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setFillColor(Color.BLACK);
      style.setLineWidth(1.0f);
      inverse.setStyle(style);
      
      // For each object in contents, add its clone to the new button
      // and make it white
      DenimText inverseCaption = (DenimText)this.caption.deepClone();
      inverseCaption.setColor(Color.WHITE);
      inverseCaption.setBackground(Color.BLACK);
      inverse.add(inverseCaption);
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================


   //===========================================================================
   //===   BUTTON METHODS   ====================================================

   /**
    * Returns whether this button was created by a stamp (as opposed
    * to sketched).
    */
   public boolean isCreatedByStamp() {
      return createdByStamp;
   }

   //-----------------------------------------------------------------
   
   /**
    * Returns the border of the button.
    */
   public TimedStroke getButtonBorder() {
      return border;
   }

   //===   BUTTON METHODS   ====================================================
   //===========================================================================


   //===========================================================================
   //===   COMPONENT METHODS   =================================================

   public void setTransparency(int transparency) {
   }

   //===   COMPONENT METHODS   =================================================
   //===========================================================================

   //===========================================================================
   //===   CAPTION METHODS   ===================================================
   
   public DenimText getCaption() {
      return caption;
   }
   
   //-----------------------------------------------------------------
   
   public void setCaption(DenimText newCaption) {
      caption.delete();
      
      caption = newCaption;
      
      border = new TimedStroke(
                  new RoundRectangle2D.Double(
                     0, 0,
                     caption.getBounds2D(COORD_REL).getWidth() + 2 * MARGIN_X,
                     caption.getBounds2D(COORD_REL).getHeight() + 2 * MARGIN_Y,
                     DEFAULT_CORNER_RADIUS, 
                     DEFAULT_CORNER_RADIUS));

      ((Patch)displayedState).add(caption);
      caption.moveTo(COORD_REL, MARGIN_X, MARGIN_Y);

      DenimText inverseCaption = (DenimText)this.caption.deepClone();
      inverseCaption.setColor(Color.WHITE);
      inverseCaption.setBackground(Color.BLACK);
      inverse.clear();
      inverse.add(inverseCaption, KEEP_REL_POS);

      this.setBoundingPoints2D(COORD_LOCAL, border);
      displayedState.setBoundingPoints2D(COORD_LOCAL, border);
      inverse.setBoundingPoints2D(COORD_LOCAL, border);
   }

   //===   CAPTION METHODS   ===================================================
   //===========================================================================


   //==========================================================================
   //===   MOUSE HANDLING METHODS   ===========================================
   
   /**
    * Handles a mouse press. Intended for use during Run mode.
    */
   public void mousePressed(MouseEvent e) {
      this.add(inverse);
      this.damage(DAMAGE_NOW);
   }
   
   //-----------------------------------------------------------------

   /**
    * Handles a mouse release. Intended for use during Run mode.
    */
   public void mouseReleased(MouseEvent e) {
      inverse.delete();
      this.damage(DAMAGE_NOW);
   }
   
   //-----------------------------------------------------------------

   /**
    * Handles a mouse enter. Intended for use during Run mode.
    */
   public void mouseEntered(MouseEvent e) {
      //System.out.println("   mouse left button? " + SwingUtilities.isLeftMouseButton(e));
      if (SwingUtilities.isLeftMouseButton(e)) {
         this.add(inverse);
         this.damage(DAMAGE_NOW);
      }
   }
   
   //-----------------------------------------------------------------

   /**
    * Handles a mouse exit. Intended for use during Run mode.
    */
   public void mouseExited(MouseEvent e) {
     // System.out.println("   mouse left button? " + SwingUtilities.isLeftMouseButton(e));
      if (SwingUtilities.isLeftMouseButton(e)) {
         inverse.delete();
         this.damage(DAMAGE_NOW);
      }
   }
   
   //-----------------------------------------------------------------

   /**
    * Handles a mouse drag. Intended for use during Run mode.
    */
   public void mouseDragged(MouseEvent e) {
   }

   //===   MOUSE HANDLING METHODS   ===========================================
   //==========================================================================


   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Returns a deep clone of this button instance.
    */
   public Object deepClone() {
      return deepClone(new DenimButtonInstance(type));
   }

   //-----------------------------------------------------------------

   /**
    * Sets the clone parameter to a deep clone of this button instance,
    * and returns it.
    */
   public Object deepClone(DenimButtonInstance clone) {
      super.deepClone(clone);
      
      clone.inverse = (Patch)inverse.deepClone();
      clone.border = (TimedStroke)border.deepClone();
      clone.caption = (DenimText)caption.deepClone();
      clone.createdByStamp = createdByStamp;
      
      return clone;
   }
   
   
   public void setStateIndex(int i) {
   	  // do nothing
   }
   
   public int getStateIndex() {
   	  return 0;
   }
   
   public GraphicalObjectCollection getStates() {
   	   return type.empty;
   }
   
   public GraphicalObject getDisplayedState() {
	  return this.displayedState;
   }

   public boolean isHTMLConvertible() {
       if(this.getCaption() instanceof TypedText)
           return true;
       else
           return false;
   }
   
    public Color getPrintDraw() {
        return Color.black;
    }
   //===   CLONE METHODS   =====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
