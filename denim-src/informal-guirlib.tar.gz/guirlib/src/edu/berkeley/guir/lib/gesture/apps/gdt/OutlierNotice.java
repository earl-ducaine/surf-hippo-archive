package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.Matrix;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.BorderLayout;
import java.awt.event.*;
import javax.swing.JComponent;

public class OutlierNotice extends DefaultNotice {
  protected MainFrame mainFrame;
  /** first 2 are catA and catB, respectively, rest are outliers */
  protected List categoryList;
  protected HowToPanel howToPanel = null;
  
  public OutlierNotice(MainFrame mf, List outliers,
		       GestureCategory catA, GestureCategory catB)
  {
    mainFrame = mf;
    categoryList = new ArrayList();
    categoryList.add(catA);
    categoryList.add(catB);
    /*
    System.out.println("adding outliers for\t" + catA + "\t& " + catB +
		       ":\t" + outliers.size());
    */
    categoryList.addAll(outliers);
    /*
    System.out.println("\tcatList size: " + categoryList.size());
    */
  }
  
  protected void displayImpl(SummaryLog log)
  {
    GestureCategory catA = (GestureCategory) categoryList.get(0);
    GestureCategory catB = (GestureCategory) categoryList.get(1);
    List outliers = categoryList.subList(2, categoryList.size());
    int numOutliers = outliers.size();
    /*
    System.out.println("got outliers for\t" + catA + "\t& " + catB +
		       ":\t" + numOutliers);
    System.out.println("\tcatList size: " + categoryList.size());
    */
    log.append("Categories ");
    log.appendLink(catA);
    log.append(" and ");
    log.appendLink(catB);
    log.append(" are likely to be misrecognized because of " +
	       ((numOutliers > 1) ? "these categories" : "this category") +
	       ": ");
    displayCategories(log, outliers);
    log.append(". Changing " + ((numOutliers > 1) ? "them" : "it") +
	       " to be more like ");
    log.appendLink(catA);
    log.append(" and ");
    log.appendLink(catB);
    log.append(" will improve recognition.");
  }

  protected void displayCategories(SummaryLog log, Collection categories)
  {
    int numCategories = categories.size();
    for (Iterator iter = categories.iterator(); iter.hasNext();) {
      GestureCategory outlier = (GestureCategory) iter.next();
      if (!iter.hasNext() && (numCategories > 1)) {
	log.append((numCategories == 2) ? " and " : "and ");
      }
      log.appendLink(outlier);
      if (iter.hasNext() && (numCategories > 2)) {
	log.append(", ");
      }
    }
  }
  
  protected void displaySummaryImpl(SummaryLog log)
  {
    GestureCategory catA = (GestureCategory) categoryList.get(0);
    GestureCategory catB = (GestureCategory) categoryList.get(1);
    List outliers = categoryList.subList(2, categoryList.size());
    log.appendLink(catA);
    log.append(" and ");
    log.appendLink(catB);
    log.append(": ");
    displayCategories(log, outliers);
  }
  
  public List getObjectList()
  {
    return categoryList;
  }

  public String getName()
  {
    return "Outlying category";
  }

  public String getReferenceTag()
  {
    return "Outlying Category";
  }

  public HowToPanel getHowToPanel()
  {
    if (howToPanel == null) {
      // designer needs to move outlier(s) closer to catA and catB
      SummaryLog log = new SummaryLog(mainFrame);
      GestureCategory catA = (GestureCategory) categoryList.get(0);
      GestureCategory catB = (GestureCategory) categoryList.get(1);
      List outliers = categoryList.subList(2, categoryList.size());
      int numOutliers = outliers.size();

      log.append("To make the gesture categories ");
      log.appendLink(catA);
      log.append(" and ");
      log.appendLink(catB);
      log.append(" easier to recognize, change one or more of the following categories in the recommended way.\n");

      for (Iterator iter = outliers.iterator(); iter.hasNext();) {
	GestureCategory outlierCat = (GestureCategory) iter.next();
	log.append("\n");
	JComponent thumbnail =
	  DisplayFactory.createThumbnail(outlierCat, log);
	log.append(thumbnail);
	final FeatureInfo info =
	  getMostDifferentFeature(catA, catB, outlierCat);
	log.append(" Change this category so its ");
	log.appendLink(info.featureName, new ActionListener() {
	  public void actionPerformed(ActionEvent e) {
	    ReferenceManager.getManager().
	      showReference(mainFrame, info.featureTag);
	  }
	},
	  "Find out what this feature is");
	log.append(" is " + (info.increaseFeature ? " higher " : " lower ")
		   + ".");
      }
      howToPanel = new HowToPanel(mainFrame);
      howToPanel.add(log, BorderLayout.CENTER);
    }
    return howToPanel;
  }

  protected class FeatureInfo {
    String featureTag;
    String featureName;
    boolean increaseFeature;
  }
  
  /** Figure out which Feature to change outlierCat by to make it more
      like catA and catB. */
  protected FeatureInfo getMostDifferentFeature(GestureCategory catA,
						GestureCategory catB,
						GestureCategory outlierCat)
  {
    // Find positions of the 3 categories in feature space.  Find
    // position midway between A and B (called M).  Find principal
    // component of vector from outlier to M (i.e., M - outlier).
    // Summary: principle component of ((A+B)/2 - outlier)

    Classifier classifier = mainFrame.getClassifier();
    Class[] featureClasses = classifier.getFeatureClasses();
    double[] A = FeatureFactory.getValues(featureClasses, catA);
    double[] B = FeatureFactory.getValues(featureClasses, catB);
    double[] O = FeatureFactory.getValues(featureClasses, outlierCat);
    double[] diff = Matrix.subtract(Matrix.multiply(0.5, Matrix.add(A, B)),
				    O);
    int index = classifier.findPrincipleComponent(diff);
    FeatureInfo result = new FeatureInfo();
    result.featureTag = ReferenceManager.
      getFeatureTag(featureClasses[index]);
    result.increaseFeature = diff[index] > 0;
    result.featureName = FeatureFactory.
      getFeatureName(featureClasses[index]);
    if (result.featureName == null) {
      result.featureName = "UNKNOWN";
    }
    return result;
  }
}
