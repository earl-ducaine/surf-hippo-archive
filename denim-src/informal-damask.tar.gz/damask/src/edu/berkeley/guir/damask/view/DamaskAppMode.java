package edu.berkeley.guir.damask.view;

import java.awt.*;

import edu.umd.cs.piccolo.event.PInputEventListener;

/** 
 * An input mode that Damask can be in. This class associates a mode with a
 * set of input event handlers and mouse cursors.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-08-2004 James Lin
 *                               Created DamaskAppMode by converting
 *                               DamaskApp.EventMode.
 *                    07-15-2004 James Lin
 *                               Split VisualMode from DamaskAppMode
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-08-2004
 */

public class DamaskAppMode {
   private final String name;
   private final PInputEventListener eventHandler;
   private final Cursor cursor;

   /**
    * Constructs a mode.
    * 
    * @param name              the name of the mode
    * @param eventHandler      the handler of mouse events
    * @param cursor  the cursor of the mode
    */
   public DamaskAppMode(
      final String name,
      final PInputEventListener eventHandler,
      final Cursor cursor) {

      this.name = name;
      this.eventHandler = eventHandler;
      this.cursor = cursor;
   }
   
   /**
    * Returns the name of the mode.
    */
   public String getName() {
      return name;
   }
   
   /**
    * Returns the event listener to use when the mouse is over the canvas.
    */
   public PInputEventListener getDefaultHandler() {
      return eventHandler;
   }

   /**
    * Returns the cursor that appears when the mouse is over the canvas.
    */
   public Cursor getDefaultCursor() {
      return cursor;
   }

   public String toString() {
      return "DamaskAppMode:" + getName();
   }
}
