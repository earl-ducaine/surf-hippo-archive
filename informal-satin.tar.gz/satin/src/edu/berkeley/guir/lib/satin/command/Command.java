//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import java.util.*;
import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.Sheet;

/**
 * Satin specific commands. Command objects make operations first-order
 * objects, allowing us to easily undo and redo things.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jun 22 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public interface Command
   extends javax.swing.undo.UndoableEdit,
           SatinConstants {

   //===========================================================================
   //===   ACTION METHODS   ====================================================

   /**
    * Execute the command this object represents. The problem with the existing
    * undo mechanism provided by Java Swing is that the unit of reification is
    * a completed edit. In other words, Swing's version of a command knows how
    * to undo itself and knows how to redo itself, but does not know how to
    * execute itself in the first place!
    */
   public void execute();

   //-----------------------------------------------------------------

   /**
    * Test if this command is enabled or not. It is similar to isDisabled().
    * This should be a static method, but Java does not allow static methods in
    * interfaces. However, the underlying variable should be static.
    *
    * @return true if the command can be executed, false otherwise.
    */
   public boolean isEnabled();

   //-----------------------------------------------------------------

   /**
    * Test if this command is disabled or not. It is similar to isEnabled().
    * This should be a static method, but Java does not allow static methods in
    * interfaces. However, the underlying variable should be static.
    *
    * @return true if the command can not be executed, false otherwise.
    */
   public boolean isDisabled();

   //-----------------------------------------------------------------

   /**
    * Enable this command, allowing execution.
    * This should be a static method, but Java does not allow static methods in
    * interfaces. However, the underlying variable should be static.
    */
   public void enable();

   //-----------------------------------------------------------------

   /**
    * Disable this command, disallowing execution.
    * This should be a static method, but Java does not allow static methods in
    * interfaces. However, the underlying variable should be static.
    */
   public void disable();

   //===   ACTION METHODS   ====================================================
   //===========================================================================


   //===========================================================================
   //===   HISTORY METHODS  =============================================

   
   public Iterator getOperands();
   public boolean isOperand( Object o );
   
   public Object getAuthor();
   public void setAuthor( Object author );
   
   public String getDevice();
   public void setDevice( String device );
   
   public String getWrappedXML();

   
   //===   HISTORY METHODS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   TIME METHODS   ======================================================

   /**
    * Set the time this command was executed to the current time.
    */
   public void setExecutionTime();

   //-----------------------------------------------------------------

   /**
    * Set the time this command was executed to the specified time.
    *
    * @param l is the time to set the execution time to.
    */
   public void setExecutionTime(long l);

   //-----------------------------------------------------------------

   /**
    * Get the system time this command was first executed.
    *
    * @return a long representing time in ms. Just normal Java time.
    */
   public long getExecutionTime();

   //===   TIME METHODS   ======================================================
   //===========================================================================
   
   /**
    * Get the Sheet the command is associated with.  May return null
    * for certain commands until completely implemented.
    *
    * @return a Sheet
    */
   public Sheet getAssociatedSheet();

} // of interface

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
