package edu.berkeley.guir.lib.satin.objects;

import java.awt.*;
import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.watch.*;
import java.util.List;

/**
 * A simple straight-line arrow.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v2.1-1.0.0, Nov 02 2000, JH
 *               Created.
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Nov 02 2000
 */
public class LineArrow
   extends    TimedStroke
   implements Watcher {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   public static final String ARROW_STYLE_FILE = "Arrow.properties";

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS PROPERTIES   ==================================================

   //// Currently all equilateral triangles.
   static Polygon shapeArrowHead1;
   static Polygon shapeArrowHead2;
   static Polygon shapeArrowHead3;

   static {
      //// 1. Class property initializations.
      Style s = new Style(ARROW_STYLE_FILE);

      clprops.setClassProperty(LineArrow.class, STYLE_CLPROPERTY, s);

      shapeArrowHead1 = new Polygon();
      shapeArrowHead1.addPoint(0,  5);
      shapeArrowHead1.addPoint(10, 0);
      shapeArrowHead1.addPoint(0, -5);

      shapeArrowHead2 = new Polygon();
      shapeArrowHead2.addPoint(0,  8);
      shapeArrowHead2.addPoint(16, 0);
      shapeArrowHead2.addPoint(0, -8);

      shapeArrowHead3 = new Polygon();
      shapeArrowHead3.addPoint(0,  10);
      shapeArrowHead3.addPoint(20,  0);
      shapeArrowHead3.addPoint(0, -10);
   } // of static init


   //===   CLASS PROPERTIES   ==================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   //// Hook onto these as start and end points.
   protected GraphicalObject gobStart;
   protected GraphicalObject gobEnd;

   //// Flags for drawing.
   protected boolean         flagDrawArrowHead  = true;
   protected boolean         flagDrawArrowLine  = true;

   //// Otherwise use these fixed points.
   protected Point2D         ptStart            = new Point2D.Float(0, 0);
   protected Point2D         ptEnd              = new Point2D.Float(0, 1);

   protected Point2D         ptArrowHeadVector  = new Point2D.Float();
   protected Shape           shapeArrowHead     = shapeArrowHead1;
   protected AffineTransform txArrowHead        = new AffineTransform();

   //// Recalculate endpoints?
   protected boolean         flagDirty          = true;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public LineArrow() {
      commonInit();
   } // of constructor

   //-----------------------------------------------------------------

   public LineArrow(Point2D ptStart, Point2D ptEnd) {
      setStartPoint(ptStart);
      setEndPoint(ptEnd);
      commonInit();
   } // of constructor

   //-----------------------------------------------------------------

   public LineArrow(float x1, float y1, float x2, float y2) {
      setStartPoint(x1, y1);
      setEndPoint(x2, y2);
      commonInit();
   } // of constructor

   //-----------------------------------------------------------------

   public LineArrow(GraphicalObject gobStart, GraphicalObject gobEnd) {
      setStartGraphicalObject(gobStart);
      setEndGraphicalObject(gobEnd);
      commonInit();
   } // of method

   //-----------------------------------------------------------------

   private void commonInit() {
      updateBounds();
   } // of method

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ARROW METHODS   =====================================================

   /**
    *
    * @param x1  is the x of the start point.
    * @param y1  is the y of the start point.
    * @param x2  is the x of the end point.
    * @param y2  is the y of the end point.
    * @param len is the length to add to the end point.
    *            Use a negative value to subtract.
    * @return dx dy
    */
   protected Point2D
   calcLineDelta(double x1, double y1, double x2, double y2, double len) {
      Point2D pt = new Point2D.Float();

      //// 1. Just see if we are near infinite slope.
      ////    If so, just hardwire the solution.
      if (Math.abs(x1 - x2) < 0.001) {
         if (y2 > y1) {
            pt.setLocation(0, -len);
         }
         else {
            pt.setLocation(0, +len);
         }
      }
      //// 2. Otherwise solve for x and y.
      else {
         int    sx = 1;
         int    sy = 1;
         if (x1 < x2) {
            sx = -1;
         }
         if (y1 < y2) {
            sy = -1;
         }


         double m  = (y2 - y1) / (x2 - x1);
         double dx = sx * Math.abs((float) (len / Math.sqrt(m*m + 1)));
         double dy = sy * Math.abs(m *dx);




         pt.setLocation(dx, dy);
      }
      return (pt);
   } // of method

   //-----------------------------------------------------------------

   public void setDirty(boolean flag) {
      flagDirty = flag;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Calculate the endpoints when one or both of the endpoints point to a
    * Graphical Object.
    */
   protected void calculateGraphicalObjectPoints() {
      if (flagDirty == false) {
         return;
      }

      Point2D  ptAA      = getStartPoint(COORD_ABS);
      Point2D  ptBB      = getEndPoint(COORD_ABS);
      boolean  flagSetAA = false;
      boolean  flagSetBB = false;

      //// 1.1. Get the bounds of the two graphical object.
      if (gobStart != null) {
         Rectangle2D bdsStart = gobStart.getBounds2D(COORD_ABS);
         ptAA       = new Point2D.Float(
                         (float) (bdsStart.getX() + bdsStart.getWidth()  / 2),
                         (float) (bdsStart.getY() + bdsStart.getHeight() / 2));
         flagSetAA  = true;
      }
      if (gobEnd != null) {
         Rectangle2D bdsEnd   = gobEnd.getBounds2D(COORD_ABS);
         ptBB       = new Point2D.Float(
                         (float) (bdsEnd.getX()   + bdsEnd.getWidth()  / 2),
                         (float) (bdsEnd.getY()   + bdsEnd.getHeight() / 2));
         flagSetBB  = true;
      }

      //// 1.2. Calculate the line between the two gob center points.
      Line2D      line       = new Line2D.Float(ptAA, ptBB);

      //// 1.3. Calculate intersect points between line and graphical objs.
      ////      Use the first item in these lists, or the center points
      ////      if the lists are empty.
      if (flagSetAA == true) {
         Polygon2D polyAA = gobStart.getBoundingPoints2D(COORD_ABS);
         List      listAA = GeomLib.calcIntersectPoints(line, polyAA);
         if (listAA.size() > 0) {
            ptStart = (Point2D) listAA.get(0);
         }
         else {
            ptStart = ptAA;
         }
         GraphicalObjectLib.absoluteToLocal(this, ptStart, ptStart);
      }

      if (flagSetBB == true) {
         Polygon2D polyBB = gobEnd.getBoundingPoints2D(COORD_ABS);
         List      listBB = GeomLib.calcIntersectPoints(line, polyBB);
         if (listBB.size() > 0) {
            ptEnd = (Point2D) listBB.get(0);
         }
         else {
            ptEnd = ptBB;
         }
/*
         //// Shift the arrow a little bit away from the dest gob
         //// so that the arrowhead doesn't overlap.
         Point2D dpt = calcLineDelta(ptStart.getX(), ptStart.getY(),
                                     ptEnd.getX(),   ptEnd.getY(),
                                     -shapeArrowHead.getBounds2D().getHeight());

         ptEnd.setLocation(ptEnd.getX() + dpt.getX(),
                           ptEnd.getY() + dpt.getY());

*/
         GraphicalObjectLib.absoluteToLocal(this, ptEnd, ptEnd);
      }

      updateBounds();
      flagDirty = false;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Copies the values in the point.
    */
   public void setStartPoint(Point2D pt) {
      setStartPoint(pt.getX(), pt.getY());
      setDirty();
   } // of method

   public void setStartPoint(float x, float y) {
      ptStart.setLocation(x, y);
      setDirty();
      updateBounds();
   } // of method

   public void setStartPoint(double x, double y) {
      ptStart.setLocation((float) x, (float) y);
      setDirty();
      updateBounds();
   } // of method

   /**
    * Set the graphical object that we start from.
    */
   public void setStartGraphicalObject(GraphicalObject gob) {
      gobStart = gob;
      gob.addWatcher(this);
      setDirty();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get either the center of the bounding box of the start graphical object
    * if it was defined through
    * {@link #setStartGraphicalObject(GraphicalObject)}, or
    * the fixed point that was set through {@link #setStartPoint(Point2D)}.
    *
    * @param cdsys is the coordinate system to return in.
    */
   public Point2D getStartPoint(int cdsys) {
      AffineTransform tx = getTransform(cdsys);
      return (tx.transform(ptStart, null));
   } // of method

   public GraphicalObject getStartGraphicalObject() {
      return (gobStart);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Copies the values in the point.
    */
   public void setEndPoint(Point2D pt) {
      setEndPoint(pt.getX(), pt.getY());
      setDirty();
   } // of method

   public void setEndPoint(float x, float y) {
      ptEnd.setLocation(x, y);
      setDirty();
      updateBounds();
   } // of method

   public void setEndPoint(double x, double y) {
      ptEnd.setLocation((float) x, (float) y);
      setDirty();
      updateBounds();
   } // of method

   /**
    * Set the graphical object that we end at (and the arrowhead points to).
    */
   public void setEndGraphicalObject(GraphicalObject gob) {
      gobEnd = gob;
      gob.addWatcher(this);
      setDirty();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get either the center of the bounding box of the end graphical object
    * if it was defined through
    * {@link #setEndGraphicalObject(GraphicalObject)}, or
    * the fixed point that was set through {@link #setEndPoint(Point2D)}.
    *
    * @param cdsys is the coordinate system to return in.
    */
   public Point2D getEndPoint(int cdsys) {
      AffineTransform tx = getTransform(cdsys);
      return (tx.transform(ptEnd, null));
   } // of method

   public GraphicalObject getEndGraphicalObject() {
      return (gobEnd);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the direction the arrowhead should point, where
    * (0,0) is where you are now. Normalized so that the distance
    * is 1.
    */
   public void setArrowHeadVector(Point2D pt) {
      setArrowHeadVector((float) pt.getX(), (float) pt.getY());
   } // of method

   public void setArrowHeadVector(float x, float y) {
      double dist = Math.sqrt(x * x + y * y);
      ptArrowHeadVector.setLocation(x / dist, y / dist);
      updateArrowHeadAngle();
   } // of method

   public void setArrowHeadVector(double x, double y) {
      setArrowHeadVector((float) x, (float) y);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Update the angle for the arrow head.
    */
   protected void updateArrowHeadAngle() {
      //// Figure out the angle for the arrow head.
      double t = Math.atan2(ptArrowHeadVector.getY(), ptArrowHeadVector.getX());
      txArrowHead.setToIdentity();
      txArrowHead.translate(ptEnd.getX(), ptEnd.getY());

      Point2D dpt;
      dpt = calcLineDelta(ptStart.getX(), ptStart.getY(),
                          ptEnd.getX(),   ptEnd.getY(),
                          -shapeArrowHead.getBounds2D().getHeight());
      txArrowHead.translate(dpt.getX(), dpt.getY());


      txArrowHead.rotate(t);
   } // of method


   /**
    * Update the bounds of the arrow. Is automatically called if the dirty
    * flag is set (ex. when one of the Graphical Objects endpoints is moved).
    */
   protected void updateBounds() {
      clearPoints();
      addPoint(ptStart);
      addPoint(ptEnd);

      setArrowHeadVector(ptEnd.getX() - ptStart.getX(),
                         ptEnd.getY() - ptStart.getY());

      updateArrowHeadAngle();
   } // of method

   //===   ARROW METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   GRAPHICAL OBJECT SHAPE METHODS   ====================================

   /**
    * Here in case we ever want to override and deal with arrow heads.
    */
   protected final boolean shapeContainsInternal(Point2D pt) {
      if (super.shapeContainsInternal(pt) == true) {
         return (true);
      }
      else {
         return (false);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Here in case we ever want to override and deal with arrow heads.
    */
   protected final boolean shapeContainsInternal(Shape s) {
      if (super.shapeContainsInternal(s) == true) {
         return (true);
      }
      else {
         return (false);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Here in case we ever want to override and deal with arrow heads.
    */
   protected final boolean shapeIntersectsInternal(Shape s) {
      if (super.shapeIntersectsInternal(s) == true) {
         return (true);
      }
      else {
         return (false);
      }
   } // of method

   //-----------------------------------------------------------------

   private AffineTransform getArrowHeadTransform(int cdsys) {
      AffineTransform tx = getTransform(cdsys);

      updateArrowHeadAngle();
      tx.preConcatenate(txArrowHead);
      return (tx);
   } // of method

   protected boolean lineContains(Point2D pt) {
      return (Line2D.ptLineDistSq(ptStart.getX(), ptStart.getY(),
                                  ptEnd.getX(),   ptEnd.getY(),
                                  pt.getX(),      pt.getY()) <= 0);
   } // of method

   //===   GRAPHICAL OBJECT SHAPE METHODS   ====================================
   //===========================================================================



   //===========================================================================
   //===   ARROW RENDERING ACCESSOR / MODIFIER METHODS   =======================

   public void setDrawArrowHead(boolean flag) {
      flagDrawArrowHead = flag;
   } // of method

   public boolean getDrawArrowHead() {
      return (flagDrawArrowHead);
   } // of method

   //-----------------------------------------------------------------

   public void setDrawArrowLine(boolean flag) {
      flagDrawArrowLine = flag;
   } // of method

   public boolean getDrawArrowLine() {
      return (flagDrawArrowLine);
   } // of method

   //===   ARROW RENDERING ACCESSOR / MODIFIER METHODS   =======================
   //===========================================================================



   //===========================================================================
   //===   RENDERING   =========================================================

   protected void defaultRender(SatinGraphics g) {
      //super.defaultRender(g);

      calculateGraphicalObjectPoints();

      //// 1. Draw a line.
      if (getDrawArrowLine() == true) {
         drawArrowLine(g);
      }

      //// 2. Draw an arrowhead.
      if (getDrawArrowHead() == true) {
         drawArrowHead(g);
      }
   } // of defaultRender

   //-----------------------------------------------------------------

   /**
    * Draw the arrowhead portion of the arrow.
    */
   protected void drawArrowHead(SatinGraphics g) {
      g.pushTransform(txArrowHead);
      g.fill(shapeArrowHead);
      g.popTransform();
   } // of method

   /**
    * Draw the line portion of the arrow.
    */
   protected void drawArrowLine(SatinGraphics g) {
      Point2D ptAA = getStartPoint(COORD_LOCAL);
      Point2D ptBB = getEndPoint(COORD_LOCAL);

      g.drawLine((int) ptAA.getX(), (int) ptAA.getY(),
                 (int) ptBB.getX(), (int) ptBB.getY());
   } // of method

   //===   RENDERING   =========================================================
   //===========================================================================



   //===========================================================================
   //===   WATCHER METHODS   ===================================================

   public void onNotify(Watchable w, Object arg) {
      setDirty(true);
   } // of method

   public void onUpdate(Watchable w, Object arg) {
      setDirty(true);
   } // of method

   public void onUpdate(Watchable w, String strProperty,
                                            Object oldVal, Object newVal) {
      setDirty(true);
   } // of method

   public void onDelete(Watchable w) {
   } // of method

   //===   WATCHER METHODS   ===================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * For clone chaining purposes.
    *
    * @see GraphicalObjectImpl#clone(GraphicalObjectImpl)
    */
   protected LineArrow clone(LineArrow newArrow) {
      //// 1. First call the superclass clone for clone chaining.
      super.clone(newArrow);

      //// 2. Do work.
      newArrow.ptStart = new Point2D.Float((float) ptStart.getX(),
                                           (float) ptStart.getY());
      newArrow.ptEnd   = new Point2D.Float((float) ptEnd.getX(),
                                           (float) ptEnd.getY());

      //// 3. Return.
      return (newArrow);
   } // of clone

   //-----------------------------------------------------------------

   /**
    * For deep-clone chaining. If you override this method in a subclass, be
    * sure to call this method, just as you would have to for normal clone
    * chaining.
    *
    * @see #clone()
    * @see #deepClone()
    */
   protected LineArrow deepClone(LineArrow newArrow) {
      //// 1. Defer work to other clone method, since we don't contain
      ////    other objects.
      super.clone(newArrow);

      //// 2. Return.
      return (newArrow);
   } // of deepClone

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   MAIN   ==============================================================
/*
   public static void main(String[] argv) {
   } // of main
*/
   //===   MAIN   ==============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
