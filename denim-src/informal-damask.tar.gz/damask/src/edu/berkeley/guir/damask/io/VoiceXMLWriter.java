package edu.berkeley.guir.damask.io;

import java.io.*;
import java.util.*;

import org.jdom.*;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.connection.ConnectionDest;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.lib.util.StringLib;

/**
 * Exports the voice portion of a Damask design as a VoiceXML file 
 * to a disk, stream, URL, or DOM tree.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  03-12-2004 James Lin
 *                               Created DamaskMarshaller.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 03-12-2004
 */
public class VoiceXMLWriter {
   private static final java.util.regex.Pattern INVALID_ID_CHARS =
      java.util.regex.Pattern.compile("[^\\.\\w]");

   private static XMLOutputter outputter = new XMLOutputter();
   static {
      outputter.setFormat(Format.getPrettyFormat());
   }
   
   public static final String NOINPUT_DEFAULT_AUDIO =
      "I'm sorry, I didn't hear you.";
   public static final String NOMATCH_DEFAULT_AUDIO =
      "I'm sorry, I didn't get that.";
   
   /**
    * Prevents instantiation.
    */
   private VoiceXMLWriter() {
   }


   /**
    * Takes the specified interaction graph and frame and writes out an
    * XML representation to the specified stream.
    */
   public static void save(
      final InteractionGraph realGraph,
      final OutputStream outStream)
      throws IOException {

      final Document document = writeDamask(realGraph);
      outputter.output(document, outStream);
   }


   /**
    * Takes the specified interaction graph and frame and writes out an
    * XML representation to the specified writer.
    */
   public static void save(
      final InteractionGraph realGraph,
      final Writer writer)
      throws IOException {

      final Document document = writeDamask(realGraph);
      outputter.output(document, writer);
   }


   /**
    * Takes the specified interaction graph and frame, and creates a content
    * tree to be written out as XML.
    */
   private static Document writeDamask(final InteractionGraph realGraph) {

      final Document doc = new Document();
      final Element root = new Element("vxml");
      root.setAttribute("version", "2.0");
      doc.setRootElement(root);
      
      // Add templates to the design
      for (Iterator i = realGraph.getTemplates().iterator(); i.hasNext(); ) {
         final TemplateDialog realTemplate = (TemplateDialog)i.next();
         root.addContent(writeTemplate(realTemplate));
      }

      // Add the home dialog to the design first
      final Page homePage = realGraph.getHomePage(DeviceType.VOICE);
      final Dialog homeDialog =
         homePage == null ? null : homePage.getDialog();
      
      for (Iterator i = realGraph.getDialogs().iterator(); i.hasNext(); ) {
         final Dialog realDialog = (Dialog)i.next();
         if (realDialog == homeDialog) {
            root.addContent(writeDialog(realDialog));
         }
      }

      // Add the rest of the dialogs to the design
      for (Iterator i = realGraph.getDialogs().iterator(); i.hasNext(); ) {
         final Dialog realDialog = (Dialog)i.next();
         if (realDialog != homeDialog &&
             realDialog.isVisibleToDeviceType(DeviceType.VOICE)) {
            root.addContent(writeDialog(realDialog));
         }
      }
      
      return doc;
   }


   /**
    * Takes the specified dialog, and creates a content tree fragment to be
    * written out as XML.
    */
   private static List/*<Element>*/ writeDialog(final Dialog realDialog) {
      final List/*<Element>*/ result = new ArrayList/*<Element>*/();
      for (Iterator i = realDialog.getPages(DeviceType.VOICE).iterator();
         i.hasNext();
         ) {
         final Page realPage = (Page)i.next();
         final String realPageId = writeId(realPage);

         final Element form = new Element("form");
         form.setAttribute("id", "form" + realPageId);
         
         // either block or field will be added, not both
         final Element field = new Element("field");
         field.setAttribute("name", realPageId);

         final Element block = new Element("block");
         block.setAttribute("name", realPageId);


         final Element filled = new Element("filled");
         
         
         final Map/*<String, Page>*/ ifTable = new HashMap/*<String, Page>*/();
         
         final List/*<String>*/ utterances = new ArrayList/*<String>*/();
         
         final PageRegion realRegion = realPage.getRegion(Direction.CENTER);
         
         //TODO handle other conditions besides 0
         final int condition = 0;

         for (Iterator j = realRegion.getControls().iterator(); j.hasNext(); ) {
            final Control realControl = (Control)j.next();
            if (realControl instanceof Content) {
               final Element prompt = new Element("prompt");
               field.addContent(prompt);
               
               {
                  final Element audio = new Element("audio");
                  prompt.addContent(audio);
                  audio.addContent(((Content)realControl).getVoicePromptText());
               }

               {
                  final Element audio = new Element("audio");
                  block.addContent(audio);
                  audio.addContent(((Content)realControl).getVoicePromptText());
               }
            }
            else if (realControl instanceof SelectMany) {
               assert ((SelectMany)realControl).getItems().size() == 1;
               final SelectMany.Item item =
                  (SelectMany.Item)((SelectMany)realControl).getItems().get(0);
               final Element prompt = new Element("prompt");
               field.addContent(prompt);
               
               final Element audio = new Element("audio");
               prompt.addContent(audio);
               audio.addContent(item.getVoicePromptText());
            }
            
            if (realControl instanceof Select) {
               final List/*<String>*/ itemTexts = new ArrayList/*<String>*/();
               String utteranceString;
               
               final Control controlToOutput;
               if (realControl instanceof SelectOne) {
                  controlToOutput = realControl;
               }
               else {
                  assert ((SelectMany)realControl).getItems().size() == 1;
                  controlToOutput =
                     (SelectMany.Item)((SelectMany)realControl).getItems().get(0);
               }
               
               for (Iterator k =
                    controlToOutput.getVoiceResponseTextList().iterator();
                    k.hasNext(); ) {
                  final String text = (String)k.next();
                  if (text.contains(" ")) {
                     itemTexts.add("(" + text.toLowerCase() + ")");
                  }
                  else {
                     itemTexts.add(text.toLowerCase());
                  }
               }
               utteranceString = "[" + StringLib.join(itemTexts) + "]";
               
               // A trigger following the select-one allows us to figure out
               // what should happen when one of the items in the select-one
               // is said.
               if (j.hasNext()) {
                  final Control nextControl = (Control)j.next();
                  if (nextControl instanceof Trigger) {
                     final String triggerId = writeId(nextControl);
                     utteranceString +=
                        " {<" +
                        field.getAttributeValue("name") +
                        " \"" +
                        triggerId +
                        "\">}";
                     final NavConnection connection =
                        ((Trigger)nextControl).getOutConnection(
                           DeviceType.VOICE,
                           new InvokeEvent(nextControl),
                           condition);
                     if (connection != null) {
                        ifTable.put(
                           field.getAttributeValue("name") + " == '" + triggerId + "'",
                           connection.getDest(DeviceType.VOICE).getPage(
                              DeviceType.VOICE));
                     }
                  }
               }
               utterances.add(utteranceString);
            }
            else if (realControl instanceof TextInput) {
               // A trigger following the select-one allows us to figure out
               // what should happen when one of the items in the select-one
               // is said.
               if (j.hasNext()) {
                  final Control nextControl = (Control)j.next();
                  if (nextControl instanceof Trigger) {
                     final NavConnection connection =
                        ((Trigger)nextControl).getOutConnection(
                           DeviceType.VOICE,
                           new InvokeEvent(nextControl),
                           condition);
                     if (connection != null) {
                        final ConnectionDest dest = connection.getDest(DeviceType.VOICE);
                        final Page destPage = dest.getPage(DeviceType.VOICE);
                        final Element nomatch = new Element("nomatch");
                        field.addContent(nomatch);
                        final Element gotoElement = new Element("goto");
                        nomatch.addContent(gotoElement);
                        gotoElement.setAttribute(
                           "next",
                           "#form" +
                              writeId(destPage));
                     }
                  }
               }
            }
            else if (realControl instanceof Trigger) {
               final NavConnection connection =
                  ((Trigger)realControl).getOutConnection(
                     DeviceType.VOICE,
                     new InvokeEvent(realControl),
                     condition);
               if (connection != null) {
                  final Page destPage =
                     connection.getDest(DeviceType.VOICE).getPage(
                        DeviceType.VOICE);
                  for (Iterator k = realControl.getVoiceResponseTextList().iterator();
                       k.hasNext(); ) {
                     final String responseOrigText = (String)k.next();
                     final String responseText = responseOrigText.toLowerCase();
                     if (responseText.equals("")) {
                        final Element gotoElement = new Element("goto");
                        block.addContent(gotoElement);
                        gotoElement.setAttribute(
                           "next", "#form" + writeId(destPage));
                     }
                     else {
                        String utteranceString;
                        if (responseText.contains(" ")) {
                           utteranceString = "[(" + responseText + ")]";
                        }
                        else {
                           utteranceString = "[" + responseText + "]";
                        }
                        
                        final String triggerId = writeId(realControl);
                        utteranceString +=
                           " {<" +
                           field.getAttributeValue("name") +
                           " \"" +
                           triggerId +
                           "\">}";

                        ifTable.put(
                           field.getAttributeValue("name") + " == '" + triggerId + "'",
                           destPage);
                        utterances.add(utteranceString);
                     }
                  }
               }
            }
         }
         
         if (!utterances.isEmpty()) {
            final Element grammar = new Element("grammar");
            grammar.setAttribute("type", "application/x-gsl");
            grammar.setAttribute("mode", "voice");
            utterances.add(0, "[");
            utterances.add("]");
            grammar.addContent(new CDATA(StringLib.join(utterances, "\n")));
            field.addContent(grammar);
         }
         
         boolean firstEntry = true;
         final Element ifElement = new Element("if");
         for (Iterator k = ifTable.keySet().iterator(); k.hasNext(); ) {
            final String ifCond = (String)k.next();
            if (firstEntry) {
               ifElement.setAttribute("cond", ifCond);
               final Element gotoElement = new Element("goto");
               ifElement.addContent(gotoElement);
               gotoElement.setAttribute("next", "#form" + writeId((Page)ifTable.get(ifCond)));
               firstEntry = false;
            }
            else if (!ifCond.equals("")){
               final Element elseIfElement = new Element("elseif");
               ifElement.addContent(elseIfElement);
               elseIfElement.setAttribute("cond", ifCond);
               final Element gotoElement = new Element("goto");
               gotoElement.setAttribute("next", "#form" + writeId((Page)ifTable.get(ifCond)));
               ifElement.addContent(gotoElement);
            }
         }
         if (ifTable.containsKey("")) {
            final Element gotoElement = new Element("goto");
            gotoElement.setAttribute("next", "#form" + writeId((Page)ifTable.get("")));
            if (ifElement.getChildren().size() > 0) {
               ifElement.addContent(new Element("else"));
               ifElement.addContent(gotoElement);
            }
            else {
               filled.addContent(gotoElement);
            }
         }
         if (ifElement.getChildren().size() > 0) {
            filled.addContent(ifElement);
         }
         if (filled.getChildren().size() > 0) {
            field.addContent(filled);
         }
         
         // Either add the block or the field to the form.
         if (block.getChild("goto") != null) {
            form.addContent(block);
         }
         else if (field.getChildren().size() > 0) {
            // Provide default noinput and nomatch, so the application
            // doesn't completely crash with unrecognized input.
            {
               final Element noinput = new Element("noinput");
               field.addContent(noinput);
            
               final Element audio = new Element("audio");
               noinput.addContent(audio);
               audio.addContent(NOINPUT_DEFAULT_AUDIO);
               
               noinput.addContent(new Element("reprompt"));
            }
            
            if (field.getChild("nomatch") == null) {
               final Element nomatch = new Element("nomatch");
               field.addContent(nomatch);
               
               final Element audio = new Element("audio");
               nomatch.addContent(audio);
               audio.addContent(NOMATCH_DEFAULT_AUDIO);
               
               nomatch.addContent(new Element("reprompt"));
            }
            form.addContent(field);
         }
         if (form.getChildren().size() > 0) {
            result.add(form);
         }
      }

      return result;
   }


   /**
    * Takes the specified dialog, and creates a content tree fragment to be
    * written out as XML.
    */
   private static List/*<Element>*/ writeTemplate(
      final TemplateDialog realDialog) {
      
      final List/*<Element>*/ result = new ArrayList/*<Element>*/();
      for (Iterator i = realDialog.getPages(DeviceType.VOICE).iterator();
         i.hasNext();
         ) {
         final Page realPage = (Page)i.next();
         final PageRegion realRegion = realPage.getRegion(Direction.CENTER);
         
         //TODO handle other conditions besides 0
         final int condition = 0;

         for (Iterator j = realRegion.getControls().iterator(); j.hasNext(); ) {
            final Control realControl = (Control)j.next();
            final Element linkElement = new Element("link");
            String utteranceString = null;
            if (realControl instanceof Content) {
               // ignore
            }
            else if (realControl instanceof Select) {
               final List/*<String>*/ itemTexts = new ArrayList/*<String>*/();
               
               final Control controlToOutput;
               if (realControl instanceof SelectOne) {
                  controlToOutput = realControl;
               }
               else {
                  assert ((SelectMany)realControl).getItems().size() == 1;
                  controlToOutput =
                     (SelectMany.Item)((SelectMany)realControl).getItems().get(0);
               }
               
               for (Iterator k =
                    controlToOutput.getVoiceResponseTextList().iterator();
                    k.hasNext(); ) {
                  final String text = (String)k.next();
                  if (text.contains(" ")) {
                     itemTexts.add("(" + text.toLowerCase() + ")");
                  }
                  else {
                     itemTexts.add(text.toLowerCase());
                  }
               }
               utteranceString = "[" + StringLib.join(itemTexts) + "]";
               
               // A trigger following the select-one allows us to figure out
               // what should happen when one of the items in the select-one
               // is said.
               if (j.hasNext()) {
                  final Control nextControl = (Control)j.next();
                  if (nextControl instanceof Trigger) {
                     final NavConnection connection =
                        ((Trigger)nextControl).getOutConnection(
                           DeviceType.VOICE,
                           new InvokeEvent(nextControl),
                           condition);
                     linkElement.setAttribute("next", "#form" +
                        writeId(connection.getDest(DeviceType.VOICE).getPage(
                           DeviceType.VOICE)));
                  }
               }
            }
            else if (realControl instanceof TextInput) {
               // ignore
            }
            else if (realControl instanceof Trigger) {
               final String responseText = realControl.getVoiceResponseText(0).toLowerCase();
               if (responseText.contains(" ")) {
                  utteranceString = "[(" + responseText + ")]";
               }
               else {
                  utteranceString = "[" + responseText + "]";
               }
               
               final NavConnection connection =
                  ((Trigger)realControl).getOutConnection(
                     DeviceType.VOICE,
                     new InvokeEvent(realControl),
                     condition);
               if (connection != null) {
                  linkElement.setAttribute("next", "#form" +
                     writeId(connection.getDest(DeviceType.VOICE).getPage(
                        DeviceType.VOICE)));
               }
            }
            
            if (linkElement.getAttributeValue("next") != null) {
               final Element grammar = new Element("grammar");
               grammar.setAttribute("type", "application/x-gsl");
               grammar.setAttribute("mode", "voice");
               grammar.addContent(new CDATA(utteranceString));
               linkElement.addContent(grammar);
               result.add(linkElement);
            }
         }
      }

      return result;
   }


   /**
    * Creates an XML-compatible ID for the specified interaction element.
    */
   private static String writeId(
      final edu.berkeley.guir.damask.InteractionElement realElement) {

      // Replace the invalid characters in the ID string with underscores.
      java.util.regex.Matcher matcher =
         INVALID_ID_CHARS.matcher(realElement.getId().toString());

      return "id" + matcher.replaceAll("_");
   }
}
