//// See bottom of source code for software license.
package edu.berkeley.guir.lib.util;

/**
 * Sleep for a specified (and extendable) amount of time 
 * before executing.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Apr 09 2002 JIH
 */
abstract public class DelayedThread {

    //==========================================================================
    //===   INNER CLASS - INTERNAL THREAD   ====================================

    /**
     * Does the grunt work of delaying.
     */
    class InternalThread extends Thread {

        public void run() {
            long currentTimeMillis;
            
            //// 1. Sleep until needed.
            currentTimeMillis = System.currentTimeMillis();
            while (currentTimeMillis < timeWakeup) {
                try {
                    sleep(timeWakeup - currentTimeMillis);
                }
                catch (Exception e) {
                    // ignore
                }
                currentTimeMillis = System.currentTimeMillis();
            }

            //// 2. Do the task.
            flagRunning = false;
            if (flagAbort == false) {
                doTask();
            }
        } // of method

    } // of inner class

    //===   INNER CLASS - INTERNAL THREAD   ====================================
    //==========================================================================



    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    long    timeWakeup;
    boolean flagRunning = false; // true if running, false otherwise
    boolean flagAbort   = false; // true if should abort

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================



    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    public DelayedThread() {
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================



    //==========================================================================
    //===   RUN   ==============================================================

    /**
     * Automatically calls <CODE>start()</CODE> on this thread.
     * Can call multiple times to re-start the countdown.
     *
     * @param millisOffset is about how long to wait (from now) 
     *                     before calling doTask.
     */
    public void setDelay(int millisOffset) {
        timeWakeup = System.currentTimeMillis() + millisOffset;
        if (flagRunning == false) {
            flagRunning = true;
            new InternalThread().start();
        }
    } // of method

    //--------------------

    /** 
     * Override this method.
     * Do the task that should be done after the delay.
     */
    public abstract void doTask();

    //--------------------

    /**
     * Abort the task. Ok to call multiple times.
     * Calling {@link #setDelay(int)} restarts.
     */
    public void abort() {
        flagAbort   = true;
        flagRunning = false;
    } // of method

    //----------------------------------------------------------------

    /**
     * Get how much more time before activation.
     * @return millis remaining before activation, or 0.
     */
    public int getDelay() {
        return (int) (Math.max(0, timeWakeup - System.currentTimeMillis()));
    } // of method

    //===   RUN   ==============================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static DelayedThread getTestInstanceAAA() {
        DelayedThread t = new DelayedThread() {
            public void doTask() {
                System.out.println("running thread");
            }
        };
        return (t);
    } // of method

    //----------------------------------------------------------------

    //// Test continuation
    private static void runTestAAA() throws Exception {
        DelayedThread t = getTestInstanceAAA();

        t.setDelay(5000);
        System.out.println("Delay 5000");
        System.out.println(t.getDelay());

        System.out.println("Sleep 3000");
        System.out.println(t.getDelay());
        Thread.sleep(3000);

        System.out.println(t.getDelay());
        System.out.println("Delay 5000");
        t.setDelay(5000);
        System.out.println(t.getDelay());
    } // of method

    //--------------------

    //// Test abort
    private static void runTestBBB() throws Exception {
        DelayedThread t = getTestInstanceAAA();

        t.setDelay(5000);
        System.out.println("Delay 5000");
        System.out.println(t.getDelay());

        System.out.println("Sleep 3000");
        System.out.println(t.getDelay());
        Thread.sleep(3000);

        t.abort();
        System.out.println("abort");
        System.out.println(t.getDelay());
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestBBB();
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
