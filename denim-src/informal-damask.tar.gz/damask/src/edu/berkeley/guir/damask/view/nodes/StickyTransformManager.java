package edu.berkeley.guir.damask.view.nodes;

import java.awt.geom.*;
import java.beans.*;

import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;
import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.util.*;

/** 
 * Utilities for sticky objects.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-01-2003 James Lin
 *                               Created StickyTransformManager
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-01-2003
 */
public final class StickyTransformManager {

   /**
    * Prevents instantiation of this class. 
    */
   private StickyTransformManager() {
   }

   /**
    * Makes the specified node stick to the specified camera.
    */
   public static void setupSticky(final PNode node, final PCamera camera) {
      new StickyTransformHandler(node, camera);
   }

   private static class StickyTransformHandler
      implements PropertyChangeListener {

      private final PNode node;
      private final PCamera constraintCamera;

      private StickyTransformHandler(
         final PNode node,
         final PCamera constraintCamera) {

         this.node = node;
         this.constraintCamera = constraintCamera;
         constraintCamera.addPropertyChangeListener(
            PCamera.PROPERTY_VIEW_TRANSFORM,
            this);
         applyStickyConstraint();
      }

      public void propertyChange(PropertyChangeEvent cameraViewTransformChanged) {
         applyStickyConstraint();
      }

      private void applyStickyConstraint() {
         try {
            AffineTransform frame = null;

            if (node.getParent() != null) {
               frame = node.getParent().getLocalToGlobalTransform(null);
            }
            else {
               frame = new PAffineTransform();
            }

            final AffineTransform t = frame.createInverse();

            t.concatenate(
               constraintCamera.getViewTransformReference().createInverse());
            t.concatenate(frame);

            node.setTransform(t);
         }
         catch (NoninvertibleTransformException e) {
            DamaskAppExceptionHandler.log(e);
         }
      }
   }


   /**
    * Makes the specified node stick to the specified camera in the x and y
    * axes, while allowing the node to zoom in and out along the z-axis
    * properly.
    * 
    * @param node the node which will be made sticky
    * @param camera the camera to stick the node to
    * @param stickyPoint indicates where the node will stick, relative to its
    *         bounds.
    *         (0, 0) represents the upper-left corner, and (1, 1) represents
    *         the lower-right.
    */
   public static void setupStickyZ(
      final PNode node,
      final PCamera camera,
      final Point2D stickyPoint) {

      new StickyZTransformHandler(node, camera, stickyPoint, 1);
   }


   /**
    * Makes the specified node stick to the specified camera in the x and y
    * axes at a magnification fixed at the specified scale, while allowing
    * the node to zoom in and out along the z-axis properly.
    * 
    * @param node the node which will be made sticky
    * @param camera the camera to stick the node to
    * @param stickyPoint indicates where the node will stick, relative to its
    *         bounds.
    *         (0, 0) represents the upper-left corner, and (1, 1) represents
    *         the lower-right.
    * @param scale the scale at which the node will be drawn
    */
   public static void setupStickyZ(
      final PNode node,
      final PCamera camera,
      final Point2D stickyPoint,
      final double scale) {

      new StickyZTransformHandler(node, camera, stickyPoint, scale);
   }

   private static class StickyZTransformHandler
      implements PropertyChangeListener {

      private final PNode node;
      private final PCamera constraintCamera;
      private final double stickyPointX;
      private final double stickyPointY;
      private final double scale;

      private StickyZTransformHandler(
         final PNode node,
         final PCamera constraintCamera,
         final Point2D stickyPoint,
         final double scale) {

         this.node = node;
         this.constraintCamera = constraintCamera;

         this.stickyPointX = stickyPoint.getX();
         this.stickyPointY = stickyPoint.getY();
         
         this.scale = scale;

         constraintCamera.addPropertyChangeListener(
            PCamera.PROPERTY_VIEW_TRANSFORM,
            this);
         applyStickyZConstraint();
      }

      public void propertyChange(PropertyChangeEvent cameraViewTransformChanged) {
         applyStickyZConstraint();
      }

      /**
       * Applies the inverse of the constraint camera's scale, so that the 
       * specified node always appears at the same scale. 
       */
      public void applyStickyZConstraint() {
         final PAffineTransform t = new PAffineTransform();
         final double s = scale / constraintCamera.getViewScale();
         final PBounds b = node.getFullBoundsReference();
         t.scaleAboutPoint(
            s,
            b.getX() + (stickyPointX * b.getWidth()),
            b.getY() + (stickyPointY * b.getHeight()));
         node.setTransform(t);
      }
   }
}
