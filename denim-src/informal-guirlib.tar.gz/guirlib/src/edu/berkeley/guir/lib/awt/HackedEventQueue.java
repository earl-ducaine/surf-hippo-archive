//// See bottom of code for software license.
package edu.berkeley.guir.lib.awt;

import edu.berkeley.guir.lib.util.*;
import java.awt.AWTEvent;
import java.awt.EventQueue;
import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;

/**
 * A hacked up version of the Event Queue. The DigitalDesk has a problem
 * with the right and left mouse buttons. Here is an event trace that shows the
 * problem:
 *
 * <PRE>
 * MouseEvent[MOUSE_MOVED,        (145,95) on frame0]
 * MouseEvent[MOUSE_PRESSED,  L   (145,95) on frame0]
 * MouseEvent[MOUSE_DRAGGED,  L   (145,103) on frame0]
 * MouseEvent[MOUSE_DRAGGED,  L   (145,104) on frame0]
 * MouseEvent[MOUSE_PRESSED,    R (145,104) on frame0]
 * MouseEvent[MOUSE_DRAGGED,  L R (145,105) on frame0]
 * MouseEvent[MOUSE_DRAGGED,  L R (149,119) on frame0]
 * MouseEvent[MOUSE_RELEASED,   R (149,119) on frame0]
 * MouseEvent[MOUSE_RELEASED, L   (149,119) on frame0]
 * MouseEvent[MOUSE_CLICKED,  L   (149,119) on frame0] -- should not be clicked
 * MouseEvent[MOUSE_MOVED,        (149,120) on frame0]
 * </PRE>
 *
 * <P>
 * Here is a code example:
 * <CODE>
 *    Toolkit    tk = Toolkit.getDefaultToolkit();
 *    EventQueue q  = tk.getSystemEventQueue();
 *    q.push(new HackedEventQueue());
 * </CODE>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.3-1.0.0, Mar 18 1999, JH
 *               Created class
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version GUIRLib-v1.4-1.0.0, Aug 31 2000
 */
public class HackedEventQueue 
   extends EventQueue {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   boolean flagDragLeft   = false;
   boolean flagDragMid    = false;
   boolean flagDragRight  = false;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   HACKED UP EVENTS   ==================================================

   public void dispatchEvent(AWTEvent evt) {

      if (evt instanceof MouseEvent) {
         MouseEvent msevt = (MouseEvent) evt;

         switch (msevt.getID()) {
            case MouseEvent.MOUSE_PRESSED:
               if (SwingUtilities.isLeftMouseButton(msevt)) {
                  flagDragLeft   = false;
               }
               if (SwingUtilities.isMiddleMouseButton(msevt)) {
                  flagDragMid    = false;
               }
               if (SwingUtilities.isRightMouseButton(msevt)) {
                  flagDragRight  = false;
               }
               break;

            case MouseEvent.MOUSE_DRAGGED:
               if (SwingUtilities.isLeftMouseButton(msevt)) {
                  flagDragLeft   = true;
               }
               if (SwingUtilities.isMiddleMouseButton(msevt)) {
                  flagDragMid    = true;
               }
               if (SwingUtilities.isRightMouseButton(msevt)) {
                  flagDragRight  = true;
               }
               break;

            case MouseEvent.MOUSE_CLICKED:
               if (SwingUtilities.isLeftMouseButton(msevt) && flagDragLeft) {
                  return;
               }
               if (SwingUtilities.isMiddleMouseButton(msevt) && flagDragMid) {
                  return;
               }
               if (SwingUtilities.isRightMouseButton(msevt) && flagDragRight) {
                  return;
               }
               break;
            default:
               break;
         }
         System.out.println(StringLib.toString(msevt));
      }
      super.dispatchEvent(evt);
   } // of dispatchEvent

   //===   HACKED UP EVENTS   ==================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
