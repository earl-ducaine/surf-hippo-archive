package edu.berkeley.guir.damask.dialog;

import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.connection.*;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.util.StringLib;

/** 
 * A page, which represents a high-level unit of interaction, such as a web
 * page, a cell phone screen, or a voice prompt.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2003 James Lin
 *                               Created Page.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-20-2003
 */
public class Page
   extends AbstractInteractionElement
   implements ConnectionSource, ConnectionDest {

   private Dialog dialog;
   private final DeviceType deviceType;
   private Map/*<Direction, PageRegion>*/ regions = new HashMap();

   private final List/*<Page>*/ templates = new ArrayList/*<Page>*/();
   
   private Content title;
   
   private Set/*<OrgConnection>*/ outOrgConnections = new HashSet();
   private Set/*<Connection>*/ inConnections = new HashSet();
   
   private PageEventSource pageEventSource = new PageEventSource();
   private ConnectionSourceEventSource connectionSourceEventSource =
      new ConnectionSourceEventSource();
   private ConnectionDestEventSource connectionDestEventSource =
      new ConnectionDestEventSource();

   //===========================================================================

   public Page(
      final DeviceType deviceType,
      final Dialog dialog,
      final Content title) {
         
      this.dialog = dialog;
      this.title = title;
      
      this.deviceType = deviceType;
      
      setBounds(
         new Rectangle2D.Double(
            0,
            0,
            deviceType.getDefaultWidth(),
            deviceType.getDefaultHeight()));

      setTransform(deviceType, new AffineTransform());

      // Add page regions to the page.
      for (Iterator i = deviceType.getRegionNames().iterator(); i.hasNext(); ) {
         Direction name = (Direction)i.next();
         regions.put(name, new PageRegion(this, name));
      }
      
      // Initialize the bounds and transforms of the page regions.
      for (Iterator i = getRegions().iterator(); i.hasNext(); ) {
         PageRegion region = (PageRegion)i.next();
         region.updateBoundsAndTransform();
      }
      
      // Set up which page regions each region should listen to. This must
      // be done after the page regions are added to the page.
      for (Iterator i = getRegions().iterator(); i.hasNext(); ) {
         PageRegion region = (PageRegion)i.next();
         region.initListeners();
      }
   }

   //---------------------------------------------------------------------------

   public Page(
      final DeviceType deviceType,
      final Dialog dialog,
      final Page oldPage,
      final Map/*<Component, Component>*/ controlCopies) {
      
      this(deviceType, dialog, (Content)controlCopies.get(oldPage.getTitle()));
      
      for (Iterator i = oldPage.getRegions().iterator(); i.hasNext(); ) {
         final PageRegion oldRegion = (PageRegion)i.next();
         final PageRegion newRegion = getRegion(oldRegion.getName());

         for (Iterator j = oldRegion.getControls().iterator(); j.hasNext(); ) {
            final Control oldControl = (Control)j.next();
            final Control newControl = (Control)controlCopies.get(oldControl);
            newRegion.add(newControl);
         }
      }

      setTransform(oldPage.getTransform());
   }
         
   //===========================================================================

   /**
    * Frees up any resources associated with this object.
    */   
   public void dispose() {
      // For each region, remove all controls from region
      for (Iterator i = regions.values().iterator(); i.hasNext(); ) {
         final PageRegion region = (PageRegion)i.next();
         
         for (Iterator j = new ArrayList/*<Control>*/(region.getControls()).iterator(); j.hasNext(); ) {
            final Control control = (Control)j.next();
            region.remove(control);
            control.dispose();
         }
      }

      // Remove any connections from this page's graph whose source
      // is this page.   
      for (Iterator i = outOrgConnections.iterator(); i.hasNext(); ) {
         OrgConnection out = (OrgConnection)i.next();
         out.getInteractionGraph().remove(out);
      }
      outOrgConnections.clear();
      outOrgConnections = null;
      
      // Remove any connections from this page's graph whose destination
      // is this page.   
      for (Iterator i = inConnections.iterator(); i.hasNext(); ) {
         Connection in = (Connection)i.next();
         in.getInteractionGraph().remove(in);
      }
      inConnections.clear();
      inConnections = null;

      regions.clear();
      regions = null;

      dialog = null;
   }

   //===========================================================================

   public Page getPage(final DeviceType deviceType) {
      deviceType.verifyIsEqual(this.getDeviceType());
      return this;
   }

   //===========================================================================

   /**
    * Returns the dialog this page is in.
    */
   public Dialog getDialog() {
      return dialog;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets the dialog this page is in. Called only by Dialog.clone().
    */
   protected void setDialog(Dialog dialog) {
      this.dialog = dialog;
   }

   //===========================================================================

   /**
    * Returns an unmodifiable collection of regions within this page.
    */
   public Collection/*<PageRegion>*/ getRegions() {
      return Collections.unmodifiableCollection(regions.values());
   }

   //===========================================================================

   /**
    * Returns the names of the regions within this page.
    */
   public Set/*<Direction>*/ getRegionNames() {
      return getDeviceType().getRegionNames();
   }

   //===========================================================================

   /**
    * Returns the group within the specified region of this page.
    */
   public PageRegion getRegion(Direction name) {
      return (PageRegion)regions.get(name);
   }

   //===========================================================================

   /**
    * Returns the width of the west or east region, or the height of the north
    * or south region. If the region with the given name does not exist,
    * returns 0.
    */
   public int getRegionInset(Direction regionName) {
      if (getRegionNames().contains(regionName)) {
         return getRegion(regionName).getInset();
      }
      else {
         return 0;
      }
   }

   //===========================================================================

   /**
    * Returns the title of this page.
    */
   public Content getTitle() {
      return title;
   }

   //===========================================================================

   /**
    * Returns the bounds of this page.
    */
   public Rectangle2D getBounds() {
      return getBounds(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the bounds of this page.
    */
   public void setBounds(final Rectangle2D bounds) {
      setBounds(deviceType, bounds);
   }

   //===========================================================================

   /**
    * Returns the transform of this page.
    */
   public AffineTransform getTransform() {
      return getTransform(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the transform of this page.
    */
   public void setTransform(final AffineTransform bounds) {
      setTransform(deviceType, bounds);
   }

   //===========================================================================

   protected AffineTransform getGlobalTransform(final DeviceType deviceType) {
      final AffineTransform transform = getTransform(deviceType);
      final Dialog dialog = getDialog();
      if (dialog != null) {
         transform.preConcatenate(dialog.getTransform(deviceType));
      }
      
      return transform;
   }

   //---------------------------------------------------------------------------

   // Implements method in ConnectionEndpoint.
   public Rectangle2D localToGlobal(
      final DeviceType deviceType,
      final Rectangle2D rect) {

      return GeomLib.transformRectangle(getGlobalTransform(deviceType), rect);
   }

   //---------------------------------------------------------------------------

   // Implements method in ConnectionEndpoint.
   public Rectangle2D globalToLocal(
      final DeviceType deviceType,
      final Rectangle2D rect) {

      try {
         return GeomLib.transformRectangle(
            getGlobalTransform(deviceType).createInverse(),
            rect);
      }
      catch (NoninvertibleTransformException e) {
         // should never happen
         DamaskAppExceptionHandler.log(e);
      }
      return null;
   }

   //===========================================================================

   /**
    * Splits this page, by creating a new page and adding the specified
    * controls (which should all be in the center region), and returns
    * the new page. Both this page and the new page are in this page's dialog.
    * Also, the new page shares all of its regions with this page, except
    * for the center region.
    */
   public Page split(final Collection/*<Control>*/ controls) {
      final Page newPage =
         new Page(getDeviceType(), getDialog(), (Content)getTitle().clone());
      final AffineTransform transform = getTransform();
      
      // In voice, the "pages" are put on top of each other, since they
      // actually represent conversations. For all other devices, the new page
      // should be underneath the original page.
      if (getDeviceType() != DeviceType.VOICE) {
         transform.preConcatenate(
            AffineTransform.getTranslateInstance(0, getBounds().getHeight() + 50));
      }
      newPage.setTransform(transform);
      
      final Dialog d = getDialog();
      d.add(d.indexOf(this) + 1, newPage);
      
      // Add given controls to center region of new page.
      final PageRegion newPageCenter = newPage.getRegion(Direction.CENTER);
            
      for (Iterator i = controls.iterator(); i.hasNext(); ) {
         final Control control = (Control)i.next();
         
         if (!control.getPageRegion(getDeviceType()).
              equals(getRegion(Direction.CENTER))) {
            //HACK to get around the fact that voice controls might be
            // in the wrong region
            continue;
            //throw new IllegalArgumentException(
            //   control + " should be in center region of " + this);
         }
         
         newPageCenter.add(control);
         
         // Readjust connections out of the control
         final Set controlOutConnections = new HashSet(control.getOutConnections()); 
         for (Iterator j = controlOutConnections.iterator(); j.hasNext(); ) {
            final Connection outConnection = (Connection)j.next();
            if (outConnection.isVisibleToDeviceType(getDeviceType())) {
               outConnection.refresh(getDeviceType());
            }
         }
      }

      // Copy the controls from the other regions to the corresponding
      // regions of the new page.
      //TODO We really want the other regions to simply be references to
      // the corresponding regions of the original page, i.e., a region
      // can be in more than one page. Unfortunately, there is too much
      // code in Damask right now that assumes a page region can only be
      // in one page, so we will punt on this for now.
      // Make the regions of new page point to the regions of this page,
      // except for the center.
      for (Iterator i = Direction.getValues().iterator(); i.hasNext(); ) {
         Direction name = (Direction)i.next();
         if (name != Direction.CENTER) {
            final PageRegion oldRegion = getRegion(name);
            if (oldRegion != null) {
               final PageRegion newRegion = newPage.getRegion(name);
               for (Iterator j = oldRegion.getControls().iterator();
                    j.hasNext(); ) {
                  final Control oldControl = (Control)j.next();
                  newRegion.add(
                     (Control)oldControl.createCopy(getDeviceType()));
               }
            }
         }
      }
      
      return newPage;
   }
   
   //===========================================================================
   
   /**
    * Merges the contents and the connections of the page after this one back
    * into this one.
    */
   public void mergeWithAdjacent() {
      final Dialog d = getDialog();
      final Page page2 = d.getPage(getDeviceType(), d.indexOf(this) + 1);
      if (page2 != null) {
         merge(page2);
      }
   }

   //===========================================================================
   
   /**
    * Merges the contents and the connections of the specified page back
    * into this one.
    */
   public void merge(final Page page2) {
      final Dialog d = getDialog();
      DamaskUtils.checkValidArgument(
         page2.getDialog() == d,
         page2 + " must be in the same dialog as " + this + ", which is " + d);

      for (Iterator i = getRegions().iterator(); i.hasNext(); ) {
         final PageRegion region = (PageRegion)i.next();

         // Move the controls in page2's region to this page's corresponding
         // region.
         final List/*<Control>*/ page2Controls = 
            new ArrayList/*<Control>*/(
               page2.getRegion(region.getName()).getControls()); 

         for (Iterator j = page2Controls.iterator(); j.hasNext(); ) {
            final Control control = (Control)j.next();
            region.add(control);
            
            // Readjust connections out of the control
            for (Iterator k = control.getOutConnections().iterator();k.hasNext();){
               final Connection outConnection = (Connection)k.next();
               if (outConnection.isVisibleToDeviceType(getDeviceType())) {
                  outConnection.refresh(getDeviceType());
               }
            }
         }         
      }
      // Move connections in and out of page2 to this page.
      takeConnections(page2);
    
      // Remove page2 from its dialog.
      d.remove(page2);
   }

   /**
    * Moves the connections from the given page to this page, eliminating
    * duplicates.
    */
   protected void takeConnections(final Page page2) {
      // Move page2's out connections to this page.
      final Set/*<Connection>*/ page2OutConnections =
         new HashSet(page2.getOutConnections());
      for (Iterator i = page2OutConnections.iterator(); i.hasNext(); ) {
         final OrgConnection c = (OrgConnection)i.next();
         c.setSource(getDeviceType(), this);
      }
      
      // Move page2's in connections to this page.
      final Set/*<Connection>*/ page2InConnections =
         new HashSet(page2.getInConnections());
      for (Iterator i = page2InConnections.iterator(); i.hasNext(); ) {
         final Connection c = (Connection)i.next();
         c.adjustDestPage(getDeviceType(), this);
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the type of device that this page is for.
    */
   public DeviceType getDeviceType() {
      return deviceType;
   }

   //---------------------------------------------------------------------------

   public Set/*<DeviceType>*/ getDeviceTypesVisibleTo() {
      final Set/*<DeviceType>*/ deviceTypes = new HashSet();
      deviceTypes.add(deviceType);
      return deviceTypes;
   }

   //===========================================================================

   /**
    * Returns the interaction graph that the page is in, or null if it's not
    * in any graph.
    */
   public InteractionGraph getInteractionGraph() {
      Dialog d = getDialog();
      if (d != null) {
         return d.getInteractionGraph();
      }
      else {
         return null;
      }
   }

   //===========================================================================

   public Collection/*<Connection>*/ getOutConnections() {
      return Collections.unmodifiableCollection(outOrgConnections);
   }

   //---------------------------------------------------------------------------

   public void addOutConnection(final Connection outConnection) {
      if (!outOrgConnections.contains(outConnection)) {
         outOrgConnections.add(outConnection);
         fireOutConnectionAdded(outConnection);
      }
   }

   //---------------------------------------------------------------------------

   public void removeOutConnection(final Connection outConnection) {
      if (outOrgConnections.contains(outConnection)) {
         outOrgConnections.remove(outConnection);
         fireOutConnectionRemoved(outConnection);
      }
   }

   //---------------------------------------------------------------------------

   public boolean containsOutConnectionWithDest(final ConnectionDest dest) {
      for (Iterator i = getOutConnections().iterator(); i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         for (Iterator j = connection.getDeviceTypesVisibleTo().iterator();
            j.hasNext();
            ) {
            final DeviceType aDeviceType = (DeviceType)j.next();
            if (connection.getConnectionDest(aDeviceType) == dest) {
               return true;
            }
         }
      }
      return false;
   }

   //---------------------------------------------------------------------------

   public Collection/*<Connection>*/ getInConnections() {
      return Collections.unmodifiableCollection(inConnections);
   }

   //---------------------------------------------------------------------------

   public void addInConnection(final Connection inConnection) {
      if (!inConnections.contains(inConnection)) {
         inConnections.add(inConnection);
         fireInConnectionAdded(inConnection);
      }
   }

   //---------------------------------------------------------------------------

   public void removeInConnection(final Connection inConnection) {
      if (inConnections.contains(inConnection)) {
         inConnections.remove(inConnection);
         fireInConnectionRemoved(inConnection);
      }
   }

   //---------------------------------------------------------------------------

   public boolean containsInConnectionWithSource(final ConnectionSource source){
      for (Iterator i = getInConnections().iterator(); i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         for (Iterator j = connection.getDeviceTypesVisibleTo().iterator();
            j.hasNext();
            ) {
            final DeviceType aDeviceType = (DeviceType)j.next();
            if (connection.getConnectionSource(aDeviceType) == source) {
               return true;
            }
         }
      }
      return false;
   }

   //===========================================================================
   
   /**
    * Returns the templates of this page.
    */
   public List/*<Page>*/ getTemplates() {
      return Collections.unmodifiableList(templates);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the template to this page.
    */
   public void addTemplate(final Page template) {
      DamaskUtils.checkValidArgument(template.isTemplate(),
         template + " is not a template");
      
      templates.add(template);
      fireTemplateAdded(template);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the template from this page.
    */
   public boolean removeTemplate(final Page template) {
      DamaskUtils.checkValidArgument(template.isTemplate(),
         template + " is not a template");
      
      final boolean wasRemoved = templates.remove(template);
      if (wasRemoved) {
         fireTemplateRemoved(template);
      }
      return wasRemoved;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns whether this page is itself a template.
    */
   public boolean isTemplate() {
      return getDialog() instanceof TemplateDialog;
   }
   
   //===========================================================================

   /**
    * Adds the specified page listener to receive events from this element.
    */
   public void addPageListener(final PageListener listener) {
      pageEventSource.addPageListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified page listener so that it no longer receives
    * events from this element.
    */
   public void removePageListener(final PageListener listener) {
      pageEventSource.removePageListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires templateAdded events to listeners.
    */
   protected void fireTemplateAdded(final Page newTemplate) {
      pageEventSource.fireTemplateAdded(this, newTemplate);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires templateRemoved events to listeners.
    */
   protected void fireTemplateRemoved(final Page oldTemplate) {
      pageEventSource.fireTemplateRemoved(this, oldTemplate);
   }

   //===========================================================================

   /**
    * Adds the specified control listener to receive events from this control.
    */
   public void addConnectionDestListener(final ConnectionDestListener listener) {
      connectionDestEventSource.addConnectionDestListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified control listener so that it no longer receives
    * events from this control.
    */
   public void removeConnectionDestListener(final ConnectionDestListener listener) {
      connectionDestEventSource.removeConnectionDestListener(listener);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Fires inConnectionAdded events to listeners.
    */
   protected void fireInConnectionAdded(final Connection connection) {
      connectionDestEventSource.fireInConnectionAdded(this, connection);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires inConnectionRemoved events to listeners.
    */
   protected void fireInConnectionRemoved(final Connection connection) {
      connectionDestEventSource.fireInConnectionRemoved(this, connection);
   }

   //===========================================================================

   /**
    * Adds the specified control listener to receive events from this control.
    */
   public void addConnectionSourceListener(final ConnectionSourceListener listener) {
      connectionSourceEventSource.addConnectionSourceListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified control listener so that it no longer receives
    * events from this control.
    */
   public void removeConnectionSourceListener(final ConnectionSourceListener listener) {
      connectionSourceEventSource.removeConnectionSourceListener(listener);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Fires outConnectionAdded events to listeners.
    */
   protected void fireOutConnectionAdded(final Connection connection) {
      connectionSourceEventSource.fireOutConnectionAdded(this, connection);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires outConnectionRemoved events to listeners.
    */
   protected void fireOutConnectionRemoved(final Connection connection) {
      connectionSourceEventSource.fireOutConnectionRemoved(this, connection);
   }

   //===========================================================================

   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      return clone(null, new HashMap());
   }

   //===========================================================================

   /**
    * Returns a clone of this object.
    * 
    * @param elementClones a mapping of elements to their clones. Used by
    * Dialog.clone() so that elements that are in different pages but the same
    * dialog will only be cloned once and reused in the pages' clones.
    */
   protected Object clone(final Dialog cloneDialog, final Map elementClones) {
      final Page clone = (Page) super.clone();

      clone.dialog = cloneDialog;
      clone.pageEventSource = new PageEventSource();
      clone.regions = new HashMap/*<Direction, PageRegion>*/();
      
      for (Iterator i = regions.keySet().iterator(); i.hasNext(); ) {
         final Direction name = (Direction)i.next();
         final PageRegion clonePageRegion =
            (PageRegion)getRegion(name).clone(clone, elementClones);
         clone.regions.put(name, clonePageRegion);
      }

      clone.outOrgConnections = new HashSet();
      clone.inConnections = new HashSet();

      clone.title = (Content)elementClones.get(title);
      if (clone.title == null) {
         clone.title = (Content)title.clone();
      }

      return clone;
   }
   
   //===========================================================================

   /**
    * Returns a string representation of this page, including the components
    * for <em>all</em> devices.
    */
   public String toLongString() {
      final StringBuffer sb = new StringBuffer();

      sb.append(toString());
      sb.append("\n");
      for (Iterator i = regions.keySet().iterator(); i.hasNext(); ) {
         final Direction name = (Direction)i.next();
         final PageRegion region = (PageRegion)regions.get(name); 
         
         if (region.getControls().size() != 0) {
            sb.append(region.toLongString(1, getDeviceType()));
            if (i.hasNext()) {
               sb.append("\n");
            }
         }
      }
      
      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of this page, with the given indent
    * level and including the components that support the given device.
    */
   public String toLongString(
      final int indentLevel,
      final DeviceType aDeviceType) {
      // Make sure the device type matches the one supported by the page.
      if (aDeviceType != deviceType) {
         throw new IllegalArgumentException("aDeviceType must match getDeviceType()");
      }

      final StringBuffer sb = new StringBuffer();

      sb.append(StringLib.spaces(indentLevel * DamaskUtils.INDENT_SPACES));
      sb.append(toString());
      sb.append("\n");
      for (Iterator i = regions.keySet().iterator(); i.hasNext();) {
         final Direction name = (Direction)i.next();
         final PageRegion region = (PageRegion)regions.get(name); 
         
         if (region.getControls().size() != 0) {
            sb.append(region.toLongString(indentLevel + 1, aDeviceType));
            if (i.hasNext()) {
               sb.append("\n");
            }
         }
      }

      return sb.toString();
   }

   //---------------------------------------------------------------------------
   
   // @Override
   public Rectangle2D getVoiceResponseDestBounds() {
      final Dialog dialog = getDialog();
      final List controls = getRegion(Direction.CENTER).getControls();
      if (dialog.indexOf(this) == 0 || controls.isEmpty()) {
         final Rectangle2D dialogBounds = dialog.getBounds(DeviceType.VOICE);
         return new Rectangle2D.Double(
            dialogBounds.getX(), dialogBounds.getY(),
            dialogBounds.getWidth(), 1);
      }
      else {
         return ((Control)controls.get(0)).getVoicePromptBounds();
      }
   }
   
   //---------------------------------------------------------------------------
   
   public String toString() {
      return super.toString() + " - " + getTitle().getText();
   }
}
