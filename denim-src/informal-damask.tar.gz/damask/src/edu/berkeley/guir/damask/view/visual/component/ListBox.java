package edu.berkeley.guir.damask.view.visual.component;

import java.awt.Color;
import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.SelectOne;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.event.ElementContainerEvent;
import edu.berkeley.guir.damask.event.ElementContainerListener;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.visual.dialog.*;
import edu.berkeley.guir.damask.view.visual.dialog.DialogView;
import edu.berkeley.guir.damask.view.visual.dialog.PageViewContainer;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.activities.PActivity;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.util.PPaintContext;
import edu.umd.cs.piccolo.util.PPickPath;

/** 
 * A list box.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-25-2004 James Lin
 *                               Created ListBox.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-25-2004
 */
public class ListBox extends ControlView {

   private static final int DEFAULT_WIDTH = 100;
   protected static final int DEFAULT_LINE_HEIGHT =
      (int)DamaskAppUtils
         .getRenderedTextBounds(
            "AAA",
            DamaskAppUtils.getDefaultFont().getSize())
         .getHeight();
   private static final int DEFAULT_NUM_LINES = 3;
   private static final int DEFAULT_HEIGHT =
      DEFAULT_LINE_HEIGHT * DEFAULT_NUM_LINES;
   
   private SelectOne.Item selectedItem;
   private Label highlightedLabel;
   private final Map/*<SelectOne.Item, Label>*/ itemToLabel = new HashMap();
   private final Map/*<Label, SelectOne.Item>*/ labelToItem = new HashMap();
   private final PNode items = new PNode();
   private final PPath highlightBar = new PPath();
   private final ScrollBar scrollBar = new ScrollBar(this);
   
   private final ScrollActivity scrollActivity = new ScrollActivity(-1);

   private final ItemHandler itemHandler = new ItemHandler();

   /**
    * Constructs a list box and associates it with the specified select-one
    * object. 
    */
   public ListBox(final SelectOne selectOne) {
      this(selectOne, true);
   }
   
   /**
    * Constructs a list box and associates it with the specified select-one
    * object. 
    * 
    * @param selectOne the select-one object for which this view is created
    * @param useDefaultElementListener true if this instance should add
    * an InteractionElementListener that automatically adjusts the bounds
    * and transform of the view by listening to changes in the model
    */
   public ListBox(
      final SelectOne selectOne,
      final boolean useDefaultElementListener) {

      super(selectOne, new RunModeEventHandler(), useDefaultElementListener);
      setStretchedWhenResized(false);
      selectOne.addElementContainerListener(itemHandler);
      
      setStrokePaint(Color.BLACK);
      setPaint(Color.WHITE);
      
      // Add the bar that will be used to highlight items. This is the first
      // child because it is always behind every other child.
      highlightBar.setPaint(Color.BLACK);
      highlightBar.setVisible(false);
      highlightBar.setPickable(false);
      addChild(highlightBar);

      // Add the node that will contain the items of the list box.      
      addChild(items);
      
      // Add the scroll bar. This is the last child because it is always in
      // front of every other child. All labels representing list items should
      // be added to positions lower than the scroll bar. 
      addChild(scrollBar);
   }
   
   
   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      final DeviceType deviceType = getDeviceType();
      final SelectOne selectOne = (SelectOne)getModel();
      
      // Set the border
      setPathTo(selectOne.getBounds(deviceType));
      
      // Set the contents
      for (Iterator i = selectOne.getItems().iterator(); i.hasNext(); ) {
         final SelectOne.Item item = (SelectOne.Item)i.next();
         addItem(item);
      }
      
      // Set the state of the list box to match the model
      final PageView pageView = getPageView();
      if (pageView != null) {
         final Dialog pageDialog = ((Page)(pageView.getModel())).getDialog();
         final Dialog controlDialog = selectOne.getDialog();
         final int condition;
         if (pageDialog == controlDialog) {
            condition = pageView.getDesignTimeCondition();
         }
         else {
            // List box actually represents a template control
            condition = controlDialog.getInitialCondition();
         }
         setState(
            selectOne.getStateForCondition(controlDialog, condition));
      }
   }


   /**
    * Returns the contents of this list box.
    */
   public Object getEditableContents() {
      return items.getChildrenReference();
   }


   /**
    * Returns the selected item in this list box.
    * 
    * @return an instance of {@link edu.berkeley.guir.damask.component.SelectOne.Item}
    */
   public Object getState() {
      return selectedItem;
   }


   /**
    * Sets the selected item in this list box.
    * 
    * @param state an instance of {@link edu.berkeley.guir.damask.component.SelectOne.Item}
    */
   public void setState(final Object state) {
      selectedItem = (SelectOne.Item)state;
      highlightLabel((Label)itemToLabel.get(selectedItem));
   }

   
   /**
    * Returns the selected label.
    */
   protected Label getSelectedLabel() {
      return highlightedLabel;
   }


   /**
    * Highlights the specified label.
    */
   protected void highlightLabel(final Label label) {
      if (highlightedLabel != null) {
         highlightedLabel.setLabelColor(Color.BLACK);
      }
      highlightedLabel = label;
      if (highlightedLabel != null) {
         highlightedLabel.setLabelColor(Color.WHITE);
         final Rectangle2D labelBounds = highlightedLabel.getFullBounds(); 
         highlightBar.setVisible(true);
         highlightBar.setPathTo(
            new Rectangle2D.Double(
               labelBounds.getX(),
               labelBounds.getY(),
               getWidth(),
               labelBounds.getHeight()));
      }
   }
   
   
   /**
    * Returns the label that contains the specified point in the list box's
    * coordinate system.
    */
   public Label getLabelAt(final Point2D pt) {
      for (Iterator i = items.getChildrenIterator(); i.hasNext(); ) {
         final PNode node = (PNode)i.next();
         if (node instanceof Label) {
            final Label label = (Label)node;
            final Rectangle2D labelBounds = label.getFullBounds();
            if ((labelBounds.getY() <= pt.getY())
               && (pt.getY() <= labelBounds.getY() + labelBounds.getHeight())) {
               return label;
            }
         }
      }
      return null;
   }
   
   
   /**
    * Returns the item at the specified point in the list box's
    * coordinate system.
    */
   public SelectOne.Item getItemAt(final Point2D pt) {
      final Label label = getLabelAt(pt);
      if (label == null) {
         return null;
      }
      else {
         return (SelectOne.Item)labelToItem.get(label);
      }
   }


   /**
    * Returns the node whose children are the items in the list box.
    */
   protected PNode getItems() {
      return items;
   }

   /**
    * Returns the number of items in this list box.
    */
   protected int getItemCount() {
      // don't count the highlight bar or the scroll bar
      return items.getChildrenCount();
   }


   /**
    * Adds the specified item to the list box.
    */
   protected void addItem(final SelectOne.Item item) {
      addItem(getItemCount(), item);
   }
   
   /**
    * Adds the specified item to the list box at the specified index.
    */
   protected void addItem(final int index, final SelectOne.Item item) {
      final Label label = new Label(item.getContent());
      items.addChild(index, label);

      label.setBounds(item.getBounds(getDeviceType()));
      label.setTransform(item.getTransform(getDeviceType()));
      label.setPickable(false);
      
      item.addInteractionElementListener(label.getElementHandler());

      itemToLabel.put(item, label);
      labelToItem.put(label, item);
   }
   
   /**
    * Removes the specified item from the list box.
    */
   protected void removeItem(final SelectOne.Item item) {
      final Label label = (Label)itemToLabel.get(item);

      item.removeInteractionElementListener(label.getElementHandler());

      label.removeFromParent();
      itemToLabel.remove(item);
      labelToItem.remove(label);
   }

   /**
    * Returns a representation of what a list box looks like by default.
    */
   public static PNode createTempView() {
      final PPath border =
         new PPath(
            new Rectangle2D.Double(
               0, 0,
               DEFAULT_WIDTH, DEFAULT_HEIGHT));

      // construct squiggles for list box items
      final int[][] itemSquiggleLengths =
         { new int[] { 4, 3, 5 }, new int[] { 6, 7 }, new int[] { 3, 6, 5 } };
      
      for (int i = 0, n = itemSquiggleLengths.length; i < n; i++) {
         final PNode squiggles =
            DamaskAppUtils.createSquiggles(itemSquiggleLengths[i]);
         border.addChild(squiggles);
         final double oldHeight = squiggles.getHeight();
         squiggles.setBounds(0, 0, squiggles.getWidth(), DEFAULT_LINE_HEIGHT);
         squiggles.setOffset(0, i * DEFAULT_LINE_HEIGHT);
         
         // Vertically center the squiggles within the list box item
         if (oldHeight < DEFAULT_LINE_HEIGHT) {
            final AffineTransform centeringTransform =
               AffineTransform.getTranslateInstance(
                  0, (DEFAULT_LINE_HEIGHT - oldHeight) / 2);
            for (Iterator j = squiggles.getChildrenIterator(); j.hasNext(); ) {
               final PPath child = (PPath)j.next();
               child.getPathReference().transform(centeringTransform);
            }
         }
      }
      
      return border;
   }


   // Overrides method in parent class.
   public void setInRunMode(boolean flag) {
      super.setInRunMode(flag);
      scrollBar.setInRunMode(flag);
   }


   /**
    * Returns the y-coordinate of the top of the bounds of the first item,
    * in the list box's coordinate system.
    */
   protected int getFirstItemMinY() {
      if (items.getChildrenCount() == 0) {
         return (int)getBounds().getMinY();
      }
      final Label firstItem = (Label)items.getChild(0);
      final Rectangle2D firstItemBounds = firstItem.getBounds();
      firstItem.localToGlobal(firstItemBounds);
      globalToLocal(firstItemBounds);
      
      final int firstItemMinY = (int)firstItemBounds.getY();
      
      return firstItemMinY;
   }
   
   
   /**
    * Returns the y-coordinate of the bottom of the bounds of the last item,
    * in the list box's coordinate system.
    */
   protected int getLastItemMaxY() {
      if (items.getChildrenCount() == 0) {
         return (int)getBounds().getMinY();
      }
      final Label lastItem =
         (Label)items.getChild(items.getChildrenCount() - 1);
      final Rectangle2D lastItemBounds = lastItem.getBounds();
      lastItem.localToGlobal(lastItemBounds);
      globalToLocal(lastItemBounds);
      
      final int lastItemMaxY = (int)lastItemBounds.getMaxY();
      return lastItemMaxY;
   }

   
   /**
    * Scrolls the contents by the specified number of pixelsx. Positive means
    * scroll up, negative means scroll down. 
    */
   protected void translateItems(final int dy) {
      for (Iterator i = items.getChildrenIterator(); i.hasNext(); ) {
         final Label label = (Label)i.next();
         label.translate(0, dy);
      }
      
      // Put the highlight bar in the right place.
      highlightLabel(highlightedLabel);
   }

   
   /**
    * Sets the transforms of the list box items' models to the items'
    * transforms.
    */
   protected void setItemModelsTransforms() {
      for (Iterator i = items.getChildrenIterator(); i.hasNext(); ) {
         final Label label = (Label)i.next();
         ((SelectOne.Item)labelToItem.get(label)).setTransform(
            label.getDeviceType(),
            label.getTransform());
      }
   }
   
   
   // Overrides method in superclass.
   protected void layoutChildren() {
      if (getBounds().getMaxY() > getLastItemMaxY()) {
         if (getBounds().getY() > getFirstItemMinY()) { 
            translateItems((int)getBounds().getMaxY() - getLastItemMaxY());
         }
      }
      
      scrollBar.setPathTo(
         new Rectangle2D.Double(0, 0, ScrollBar.WIDTH, getHeight()));
      scrollBar.setOffset(getWidth() - ScrollBar.WIDTH, 0);

      // Layout the children of the scroll bar. By putting it here (in the
      // method that changes the full bounds of the scroll bar) instead
      // of ScrollBar.layoutChildren(), we avoid a "soft" infinite loop.
      // Putting the code in ScrollBar.layoutChildren() would result in
      // ListBox.layoutChildren() being called, which would result in
      // ScrollBar.layoutChildren() being called, etc.
      final double childrenHeight =
         getLastItemMaxY() - getFirstItemMinY();
      final double firstItemMinY = getFirstItemMinY();
      final double height = getHeight(); 
      scrollBar.setVisible(childrenHeight > height);

      scrollBar.getDownButton().setOffset(0, height - ScrollBar.BUTTON_SIZE);

      final double scrollBarShaftHeight = scrollBar.getShaftHeight();
      scrollBar.getElevator().setPathTo(
         new Rectangle2D.Double(
            0,
            0,
            ScrollBar.WIDTH,
            Math.max(
               ScrollBar.Elevator.MIN_HEIGHT,
               scrollBarShaftHeight * height / childrenHeight)));

      scrollBar.getElevator().setOffset(
         0,
         scrollBarShaftHeight * (-firstItemMinY / childrenHeight)
            + ScrollBar.BUTTON_SIZE);
   }


   /**
    * Scrolls the contents by the specified number of lines. Positive means
    * scroll up, negative means scroll down. 
    */
   public void scrollItems(final int numLines) {
      final int proposedDy = numLines * DEFAULT_LINE_HEIGHT;
      int dy = proposedDy;
      
      // Don't let the first item in the list go below the first line in the
      // list box.
      if (proposedDy > 0) {
         final int firstItemMinY = getFirstItemMinY();
         if (firstItemMinY >= 0) {
            return;
         }
         else if (firstItemMinY + proposedDy > 0) {
            dy = -firstItemMinY;
         }
      }

      // Don't let the last item in the list go above the last line in the
      // list box.
      else {
         final int lastItemMaxY = getLastItemMaxY();
         final double listBoxMaxY = getBounds().getMaxY();

         if (lastItemMaxY <= listBoxMaxY) {
            return;
         }
         else if (lastItemMaxY + proposedDy < listBoxMaxY) {
            dy = (int)listBoxMaxY - lastItemMaxY;
         }
      }
      translateItems(dy);
   }


   /**
    * Continuously scroll the associated list box by the specified number of
    * lines. Positive means scroll up, negative means scroll down, 0 means
    * stop scrolling. 
    */
   protected void doScrollActivity(final int numLines) {
      if (numLines != 0) {
         // Scroll once immediately.
         scrollItems(numLines);
         
         // Do the rest of the scrolling after a short delay (400ms).
         scrollActivity.setNumLines(numLines);
         scrollActivity.setStartTime(getRoot().getGlobalTime() + 400);
         getRoot().addActivity(scrollActivity);
      }
      else {
         scrollActivity.terminate();
      }
   }
   

   //=========================================================================
   // The code below mimics functionality in edu.umd.cs.piccolox.nodes.PClip.

   protected void paint(PPaintContext paintContext) {
      clipPaint(paintContext);
   }

   protected void paintAfterChildren(PPaintContext paintContext) {
      clipPaintAfterChildren(paintContext);
   }

   public boolean fullPick(PPickPath pickPath) {
      return clipFullPick(pickPath);
   }

   // The code above mimics functionality in edu.umd.cs.piccolox.nodes.PClip.
   //=========================================================================


   /**
    * An activity that continuously scrolls the list box.
    */
   private class ScrollActivity extends PActivity {
      private int numLines;

      private ScrollActivity(long aDuration) {
         super(aDuration);
      }

      private ScrollActivity(long aDuration, long aStepRate) {
         super(aDuration, aStepRate);
      }

      private ScrollActivity(long aDuration, long aStepRate, long aStartTime) {
         super(aDuration, aStepRate, aStartTime);
      }

      protected void activityStep(long elapsedTime) {
         super.activityStep(elapsedTime);

         scrollItems(numLines);
      }

      /**
       * Sets how much the activity should scroll the list box. Positive means
       * scroll up, negative means scroll down
       */
      public void setNumLines(final int numLines) {
         this.numLines = numLines;
      }
   }


   /**
    * The event handler for a list box in Run mode.
    */
   private static class RunModeEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         final PageViewContainer container =
            (PageViewContainer)event.getComponent();
         if (event.getPickedNode() instanceof ListBox) {
            final ListBox listBox = (ListBox)event.getPickedNode();
            final Label labelToHighlight =
               listBox.getLabelAt(event.getPositionRelativeTo(listBox));
            if (labelToHighlight != null) {
               listBox.highlightLabel(labelToHighlight);
            }
         }
         container.setFocus((ListBox)
            DamaskAppUtils.getAncestor(event.getPickedNode(), ListBox.class));
      }
      
      public void mouseDragged(PInputEvent event) {
         if (event.getPickedNode() instanceof ListBox) {
            final ListBox listBox = (ListBox)event.getPickedNode();
            final Label labelToHighlight =
               listBox.getLabelAt(event.getPositionRelativeTo(listBox));
            if (labelToHighlight != null) {
               listBox.highlightLabel(labelToHighlight);
            }
         }
      }
      
      public void mouseReleased(PInputEvent event) {
         if (event.getPickedNode() instanceof ListBox) {
            final PageViewContainer container =
               (PageViewContainer)event.getComponent();
            final ListBox listBox = (ListBox)event.getPickedNode();
            final Label labelToHighlight =
               listBox.getLabelAt(event.getPositionRelativeTo(listBox));

            if (labelToHighlight != null) {
               listBox.highlightLabel(labelToHighlight);
            }

            final SelectOne.Item selectOneItem =
               (SelectOne.Item)listBox.labelToItem.get(
                  listBox.highlightedLabel);

            // Change state of list box
            container.setControlState(
               (SelectOne)listBox.getModel(),
               selectOneItem);

            // Follow an outgoing connection, if any
            final DeviceType deviceType = listBox.getDeviceType();

            if (selectOneItem != null) {
               final NavConnection connection =
                  selectOneItem.getOutConnection(
                     listBox.getDeviceType(),
                     new InvokeEvent(selectOneItem),
                     container.getSelectedPageCondition());

               if (connection != null) {
                  container.goToPage(
                     connection.getDest(deviceType).getPage(deviceType));
               }
            }
         }
      }
   }


   /** 
    * Handles element container events.
    */
   public class ItemHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         final SelectOne.Item item = (SelectOne.Item)e.getElement();
         addItem(e.getIndex(), item);
      }

      public void elementRemoved(ElementContainerEvent e) {
         final SelectOne.Item item = (SelectOne.Item)e.getElement();
         removeItem(item);
      }
   }
}
