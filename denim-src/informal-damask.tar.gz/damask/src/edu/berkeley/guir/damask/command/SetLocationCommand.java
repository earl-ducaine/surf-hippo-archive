package edu.berkeley.guir.damask.command;

import java.awt.geom.Point2D;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that changes the bounds of an interaction element.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-09-2003 James Lin
 *                               Created UpdateBoundsCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-09-2003
 */
public class SetLocationCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final InteractionElement element;
   private final DeviceType deviceType;
   
   private final Point2D newLocation;
   private final Point2D oldLocation;


   /**
    * Constructs the command.
    * 
    * @param element the element whose location is to be updated
    * @param newLocation the new location of the element
    */
   public SetLocationCommand(
      final InteractionElement element,
      final DeviceType deviceType,
      final Point2D newLocation) {
         
      this.element = element;
      this.deviceType = deviceType;
      this.newLocation = newLocation;
      oldLocation = element.getLocation(deviceType);
   }


   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Set location of " + element + ": " + oldLocation + "->" + newLocation;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      element.setLocation(deviceType, newLocation);
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      element.setLocation(deviceType, oldLocation);
   }
}
