package edu.berkeley.guir.denim.annotation;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.debugging.*;
import java.awt.*;
import java.awt.geom.*;

/**
 * An audio annotation.
 *
 * <PRE>
 * Revisions:  1.0.0  11-26-1999 JL
 *                    Created class AudioAnnotation.
 *             1.0.1  12-06-1999 JL
 *                    Moved into denim.annotation package.
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version Version 1.0.1, 12-06-1999
 */
public class AudioAnnotation extends PatchImpl
                             implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   private static final int WIDTH  = 24;
   private static final int HEIGHT = 24;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private String          fileName;
   private GraphicalObject anchor;
   private boolean         beingEdited;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================


   /**
    * Draw a line from (x1, y1) to (x2, y2). Used by the constructor to
    * draw the annotation icon.
    */
   private void addLine(int x1, int y1, int x2, int y2) {
      this.add(DenimUtils.makeStrokeFromLine(x1, y1, x2, y2,
                                             AUDIO_ICON_OUTLINE_COLOR));
   }

   /**
    * Create an audio annotation.
    *
    * @param anchor the graphical object that the annotation is attached to
    * @param fileName the name of the file that stores the audio
    */
   public AudioAnnotation(GraphicalObject anchor, String fileName) {
      this.anchor = anchor;
      this.fileName = fileName;

      // setup sticky
      SemanticZoomMultiViewImpl views = new SemanticZoomMultiViewImpl();
      this.setView(views);
      StickyZViewWrapper v =
         new StickyZViewWrapper(this.getView(), 1);
      views.add(v);

      // This is a patch with no border or fill
      Style style = this.getStyle();
      style.setDrawColor(NO_COLOR);
      style.setFillColor(NO_COLOR);
      this.setStyle(style);

      this.setBoundingPoints2D(COORD_REL, new Rectangle(0, 0, WIDTH, HEIGHT));

      addLine(2, 9, 2, 13);
      addLine(3, 14, 6, 14);
      addLine(7, 15, 11, 19);
      addLine(12, 20, 14, 20);
      addLine(15, 19, 16, 18);
      addLine(16, 17, 16, 5);
      addLine(16, 4, 15, 3);
      addLine(14, 2, 12, 2);
      addLine(11, 3, 7, 7);
      addLine(6, 8, 3, 8);

      addLine(13, 19, 12, 18);
      addLine(11, 17, 11, 5);
      addLine(12, 4, 13, 3);

      addLine(12, 13, 13, 13);
      addLine(14, 12, 14, 10);
      addLine(13, 9, 12, 9);

      addLine(19, 8, 21, 6);
      addLine(19, 12, 22, 12);
      addLine(19, 16, 21, 18);

      beingEdited = false;
   }

   /**
    * Returns the preferred width of the annotation icon, in absolute units.
    */
   public int getPreferredAbsoluteWidth() {
      return WIDTH;
   }

   /**
    * Returns the preferred height of the annotation icon, in absolute units.
    */
   public int getPreferredAbsoluteHeight() {
      return HEIGHT;
   }

   /**
    * Returns the name of the file that stores the audio.
    */
   public String getAudioFileName() {
      return fileName;
   }

   /**
    * Sets the file that stores the audio to the file with the given name.
    */
   public void setAudioFileName(String fileName) {
      this.fileName = fileName;
   }

   /**
    * Returns the object that the annotation is anchored to.
    */
   public GraphicalObject getAnchor() {
      return anchor;
   }

   /**
    * Sets the object to which the annotation is anchored to the given object.
    */
   public void setAnchor(GraphicalObject newAnchor) {
      anchor = newAnchor;
   }

   /**
    * Returns whether the designer is currently editing this annotation.
    */
   public boolean isBeingEdited() {
      return beingEdited;
   }

   /**
    * Sets whether the designer is currently editing this annotation.
    */
   public void setBeingEdited(boolean flag) {
      beingEdited = flag;
   }

   /**
    * Adds this annotation to the given graphical object group at the
    * given location, and makes the given sheet keep track of this annotation.
    *
    * @param parent the group to add the annotation to
    * @param location the annotation's new position, in coordinates relative to
    *        the parent
    * @param sheet the sheet which should keep track of this annotation
    */
   public void addMyselfTo(GraphicalObjectGroup parent, Point2D location,
                           DenimSheet sheet) {
      double scaleFactor =
         ((DenimSheet)parent.getSheet()).getDenimUI().
            getZoomSlider().getScaleFactor();
      this.moveTo(COORD_REL, location);
      this.setBoundingPoints2D(COORD_REL,
         new Rectangle2D.Double(
                location.getX(),
                location.getY(),
                (getPreferredAbsoluteWidth() / scaleFactor),
                (getPreferredAbsoluteHeight() / scaleFactor)));
      parent.add(this, GraphicalObjectGroup.KEEP_REL_POS);

      /*setAbsoluteBoundingPoints(
         new Rectangle(absLocation.x - getPreferredAbsoluteWidth() / 2,
                       absLocation.y - getPreferredAbsoluteHeight() / 2,
                       getPreferredAbsoluteWidth(),
                       getPreferredAbsoluteHeight()));
      parent.add(this, GraphicalObjectGroup.KEEP_ABS_POS);*/
      Debug.println("Attached annotation to " + anchor.getClass() + ":" +
                         anchor.getUniqueID());
      Debug.println("Added icon to " + parent.getClass() + ":" +
                         parent.getUniqueID());

      sheet.getSheetAnnotations().addAudioAnnotation(this);
   }

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
