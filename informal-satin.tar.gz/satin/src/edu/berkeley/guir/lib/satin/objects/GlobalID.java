package edu.berkeley.guir.lib.satin.objects;

import java.net.*;

/*
 * A GlobalID extends the notion of a local int-based SATIN ID to include hostname
 * This is useful for remote object passing
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
*/
public class GlobalID {
   public static final String HOST     = "HOST";
   public static final String ID       = "ID";
   public static final String TAG_NAME = "GLOBALID";
   
   private String host;
   private long    id;
   
   public GlobalID(String host, int id) {
      this.host = host;
      this.id = id;
   }
   
   /**
    * Used by the localhost to create a GlobalID with the local hostname and
    * the passed in satin id
    */
	public GlobalID(long id) {
		this.id = id;

		InetAddress inet = null;
		try {
			inet = InetAddress.getLocalHost();
		} catch (Exception e) {
			System.out.println(e.toString());
	   }	
	   
	   this.host = (inet!=null) ? inet.getHostName() : "localhost";
   }
   
   public String getHost() { return host; }

   public long    getID() { return id; }
   
   
   /**
    *  Another global ID is the same as us if their host and id are the same
    */
   public boolean equals(Object obj) {
      if (obj instanceof GlobalID)
         return ((((GlobalID)obj).getHost().equals(host))&&(((GlobalID)obj).getID()==id));  
      else return false;
   }
   
   
   public String toXML() {
      return "<"+TAG_NAME+"><"+HOST+">" + host + "</"+HOST+"><"+ID+">" + id + "</"+ID+"></"+TAG_NAME+">"  ;
   }
   
}

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
