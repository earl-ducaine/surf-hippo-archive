package edu.berkeley.guir.lib.gesture.util;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class awt
{
  /**
   * The analogous Swing function is slightly broken (IMHO) because
   * if the passed Component <i>is</i> a Window it does does not get
   * returned.  */
  public static Window getWindow(Component c)
  {
    Window result;
    if (c == null)
      result = null;
    else if (c instanceof Window)
      result = (Window) c;
    else
      result = SwingUtilities.windowForComponent(c);

    return result;
  }

  /**
   * Figure out how big s will be when rendered in c.
   */
  public static Dimension getTextSize(Component c, String s)
  {
    FontMetrics fm = c.getFontMetrics(c.getFont());
    return new Dimension(fm.stringWidth(s),
			 fm.getMaxAscent() + fm.getMaxDescent());
  }

  /**
   * The Graphics object passed in paint* routines do not account for
   * insets, which is silly.  This function accounts for that.
   */
  public static Dimension sizeWithInsets(Graphics g, JComponent c)
  {
    Insets insets = c.getInsets();
    Dimension size = c.getSize();

    g.translate(insets.left, insets.top);
    size.width -= (insets.left + insets.right);
    size.height -= (insets.top + insets.bottom);
    g.clipRect(0, 0, size.width, size.height);

    return size;
  }

  /** Return the index of child in container, or -1 if child is not in
      container */
  public static int getChildIndex(Container container, Component child)
  {
    int numComponents = container.getComponentCount();
    for (int i = 0; i < numComponents; i++) {
      if (container.getComponent(i).equals(child)) {
	return i;
      }
    }
    return -1;
  }

  public static String eventModifiers(InputEvent e)
  {
    StringBuffer result = new StringBuffer("");
    if (e.isAltDown()) {
      result.append("A");
    }
    if (e.isAltGraphDown()) {
      result.append("G");
    }
    if (e.isControlDown()) {
      result.append("C");
    }
    if (e.isMetaDown()) {
      result.append("M");
    }
    if (e.isShiftDown()) {
      result.append("S");
    }
    return result.toString();
  }
}
