package edu.berkeley.guir.lib.gesture.util;

import javax.swing.table.*;

public interface CTableModel extends TableModel
{
  String getRowName(int row);
  void setRowName(int rowNumber, Object newName);
}
