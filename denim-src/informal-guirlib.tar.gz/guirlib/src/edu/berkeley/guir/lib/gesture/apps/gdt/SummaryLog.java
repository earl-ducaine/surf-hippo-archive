package edu.berkeley.guir.lib.gesture.apps.gdt;

import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Point;
import javax.swing.text.*;
import edu.berkeley.guir.lib.gesture.GestureContainer;
import edu.berkeley.guir.lib.gesture.FeatureFactory;

/** A scrolling log.  Intended to be mainly text, but widgets are
    allowed.  Not user-editable by default. */
public class SummaryLog extends JScrollPane {
  public static Icon START_ICON = new
    ImageIcon(SummaryLog.class.getResource("images/circle.bm"));
  protected static MutableAttributeSet hyperlinkAttributes;
  static {
    hyperlinkAttributes = new SimpleAttributeSet();
    StyleConstants.setUnderline(hyperlinkAttributes, true);
    StyleConstants.setForeground(hyperlinkAttributes, Color.blue);
  }
  public static final String FONT = "SummaryLog.font";
  /** the name of the tooltip attribute */
  protected static final String TOOLTIP_ATTRIB = "TOOLTIP_ATTRIB";

  protected JTextPane textPane = new JTextPane();
  protected MainFrame mainFrame;
  
  public SummaryLog(MainFrame mf)
  {
    super();
    mainFrame = mf;
    buildUI();
  }

  protected void buildUI()
  {
    textPane.setFont(UIManager.getFont(FONT));
    setViewportView(textPane);
    /*
    textPane.setLineWrap(true);
    textPane.setWrapStyleWord(true);
    */
    textPane.setAutoscrolls(true);
    textPane.setEditable(false);
    textPane.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
	if (SwingUtilities.isLeftMouseButton(e)) {
	  ActionListener link = getHyperlink(e);
	  if (link != null) {
	    link.actionPerformed(new ActionEvent(textPane, 0, null));
	  }
	}
      }
    });
    textPane.addMouseMotionListener(new MouseMotionAdapter() {
      public void mouseMoved(MouseEvent e) {
	if ((getHyperlink(e) != null) &&
	    (textPane.getCursor() !=
	     Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR))) {
	  textPane.setCursor(Cursor.
			     getPredefinedCursor(Cursor.HAND_CURSOR));
	  String toolTip = getToolTip(e);
	  if (toolTip != null) {
	    textPane.setToolTipText(toolTip);
	  }
	}
	else {
	  textPane.setCursor(Cursor.
			     getPredefinedCursor(Cursor.TEXT_CURSOR));
	  textPane.setToolTipText(null);
	}
      }
    });
  }

  /** get the attributes of the text at e */
  protected AttributeSet getAttributes(MouseEvent e)
  {
    int pos = getPosition(e);
    StyledDocument styledDoc = (StyledDocument) textPane.getDocument();
    ((AbstractDocument) styledDoc).readLock();
    AttributeSet as = null;
    try {
      as = styledDoc.getCharacterElement(pos).getAttributes();
    }
    finally {
      ((AbstractDocument) styledDoc).readUnlock();
    }
    return as;
  }
  
  /** Return hyperlink at MouseEvent, or null if there is none */
  protected ActionListener getHyperlink(MouseEvent e)
  {
    AttributeSet as = getAttributes(e);
    ActionListener link = (ActionListener)
      as.getAttribute(SummaryConstants.Link);
    return link;
  }

  /** return the tool tip for the text at e, or null if there is none */
  protected String getToolTip(MouseEvent e)
  {
    AttributeSet as = getAttributes(e);
    return (String) as.getAttribute(TOOLTIP_ATTRIB);
  }
  
  public int getPosition(MouseEvent e)
  {
    Point p = e.getPoint();
    int pos = textPane.viewToModel(p);
    return pos;
  }

  public void setTextBackground(Color c)
  {
    textPane.setBackground(c);
  }
  
  public void message(String msg)
  {
    append(msg + "\n");
    scrollToEnd();
  }

  public void scrollToEnd()
  {
    try {
      textPane.setCaretPosition(textPane.getDocument().getLength()-1);
    }
    catch (Exception e) {
      System.err.println("WARNING: another error in Sun's JTextPane: " + e);
    }
  }
  
  protected void selectEnd()
  {
    int length = textPane.getDocument().getLength();
    try {
      textPane.setSelectionStart(length);
      textPane.setSelectionEnd(length);
    }
    catch (Exception e) {
      System.err.println("WARNING: another error in Sun's JTextPane: " + e);
    }
  }

  public void append(String msg)
  {
    append(msg, null);
  }
  
  public void append(String msg, AttributeSet as)
  {
    Document document = textPane.getDocument();
    try {
      document.insertString(document.getLength(), msg, as);
    }
    catch (BadLocationException e) {
      System.err.println("WARNING: weirdness in SummaryLog Document: " + e);
    }
    catch (RuntimeException e) {
      System.err.println("WARNING: another error in Sun's JTextPane: " + e);
    }
  }

  public void append(Component component)
  {
    selectEnd();
    component.setFont(textPane.getFont());
    try {
      textPane.setEditable(true);
      textPane.insertComponent(component);
      textPane.setEditable(false);
      // validate() might fix ArrayIndexOutOfBoundsException in
      // SizeRequirements
      textPane.validate();
    }
    catch (Exception e) {
      System.err.println("WARNING: another error in Sun's JTextPane: " + e);
    }
  }

  public void append(Icon icon)
  {
    selectEnd();
    try {
      textPane.setEditable(true);
      textPane.insertIcon(icon);
      textPane.setEditable(false);
    }
    catch (Exception e) {
      System.err.println("WARNING: another error in Sun's JTextPane: " + e);
    }
  }

  /** append the starting icon to the log */
  public void appendStartIcon()
  {
    append(START_ICON);
    append(" ");
  }
  
  public JButton appendButton(String label, ActionListener actionListener)
  {
    // factors affecting size: insets, border, alignmentX, alignmentY
    JButton button = new JButton(label);
    if (actionListener != null) {
      button.addActionListener(actionListener);
    }
    button.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    append(button);
    return button;
  }

  public void appendLink(String label, ActionListener listener)
  {
    appendLink(label, listener, null);
  }
  
  public void appendLink(String label, ActionListener listener,
			 String tooltip)
  {
    MutableAttributeSet as = new SimpleAttributeSet(hyperlinkAttributes);
    if (tooltip != null) {
      as.addAttribute(TOOLTIP_ATTRIB, tooltip);
    }
    SummaryConstants.setLink(as, listener);
    append(label, as);
  }

  /** append a hyperlink that causes the GestureContainer to be
      displayed */
  public void appendLink(final GestureContainer container)
  {
    ActionListener l = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	mainFrame.getDesktop().showFrame(container);
      }
    };
    String name = container.getName();
    appendLink(name, l, "Make new view for " + name);
  }

  public void appendFeatureLink(Class featureClass)
  {
    final String featureName = FeatureFactory.
      getFeatureName(featureClass);
    final String featureTag = ReferenceManager.
      getFeatureTag(featureClass);
    appendLink(featureName, new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	ReferenceManager.getManager().
	  showReference(mainFrame, featureTag);
      }
    },
      "Find out what this feature is");
  }
  
  /** The returned position does not move when text is appended. */
  public Position createEndPosition()
  {
    Document doc = textPane.getDocument();
    Position result = null;
    try {
      result = doc.createPosition(doc.getLength()-1);
    }
    catch (BadLocationException e) {
    }
    return result;
  }

  public JTextPane getTextPane()
  {
    return textPane;
  }

  public Document getDocument()
  {
    return textPane.getDocument();
  }

  public int length()
  {
    return textPane.getDocument().getLength();
  }

  public void clear()
  {
    textPane.setText("");
  }
  
  public MainFrame getMainFrame()
  {
    return mainFrame;
  }
  
  public static class SummaryConstants {
    private String representation;

    public SummaryConstants(String rep)
    {
      representation = rep;
    }

    /** Attribute for an active link.  Value is an ActionListener. */
    public static final Object Link =
      new SummaryConstants("gdt summary link");

    public static ActionListener getLink(AttributeSet a)
    {
      return (ActionListener) a.getAttribute(Link);
    }

    public static void setLink(MutableAttributeSet a,
			       ActionListener listener)
    {
      a.addAttribute(Link, listener);
    }
  }
}
