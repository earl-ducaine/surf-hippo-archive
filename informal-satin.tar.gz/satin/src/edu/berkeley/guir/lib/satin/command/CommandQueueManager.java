package edu.berkeley.guir.lib.satin.command;

import java.util.*;
import edu.berkeley.guir.lib.satin.remote.*;
import edu.berkeley.guir.lib.satin.Sheet;
import javax.swing.undo.*;

/**
 * <P>
 * Keeps track of multiple command queues.  Usually, there is only
 * one default command queue for each application, even when multiple 
 * sheets are involved.  However, for instances when commands do not
 * belong in the default command queue, CommandQueueManager provides 
 * the method createQueueFor(Sheet mySheet) which creates a separate
 * command queue for the commands that operate on mySheet to reside.
 * These auxillary command queue's are placed in a Vector.
 * 
 * <P>
 * The method doCommand(Command cmd) will find the appropriate 
 * command queue to execute the command.  The appropriate command
 * queue is found by querying the cmd object's origin sheet through
 * the Command method getAssociatedSheet.  If the returned sheet has an
 * associated auxillary command queue (createQueueFor was previously
 * called with the sheet), then the command is executed using that
 * auxillary command queue, otherwise the command is executed using
 * the default command queue.  Not all the command subclasses implement
 * getAssociatedSheet, which by default returns null.
 *
 * <P>
 * The auxillary command queue can be accessed by the methods
 * setCommandQueueFor and getQueueFor.
 **/

public class CommandQueueManager implements CommandQueue {
	private CommandQueue defaultCommandQ    = new LinearCommandQueue();
	private Vector       auxillaryCommandQs = new Vector();
		
	/**
	 * This can be used to set a different subclass of CommandQueue (e.g., a Branched queue)
	 * as the main queue
	 */
	public void setCommandQueue(CommandQueue q){
		this.defaultCommandQ = q;
	}	
	
	
	public CommandQueue getCommandQueue() {
		return defaultCommandQ;
	}
	
	
	public void doCommand(Command cmd) {
		Sheet mySheet = cmd.getAssociatedSheet();
		//The common case
		if(mySheet==null){
			defaultCommandQ.doCommand(cmd);
			return;
		}
		Enumeration auxQs = auxillaryCommandQs.elements();
		while(auxQs.hasMoreElements()){
			SheetWithCommandQueue q = (SheetWithCommandQueue)auxQs.nextElement();
			if(q.getSheet() == mySheet){
				q.getCommandQueue().doCommand(cmd);
				return;
			}
		}
		//If none of the Aux CommandQs match mySheet, then the defaultCommandQ is used.
		defaultCommandQ.doCommand(cmd);
	}
	
	
	public void clear() {
		defaultCommandQ.clear();
		auxillaryCommandQs = new Vector();
	}
	
	/**
	  * If we have a commandQueue that can handle remote events, set the RemoteSocketMgr.
	 **/
	public void setRemoteSocketMgr(RemoteSocketMgr m) { 	   
	   if (defaultCommandQ instanceof RemoteCommandQueue) {
	      ((RemoteCommandQueue)defaultCommandQ).setRemoteSocketMgr(m); 
	   }
	}
	
	public void    dump()                       { defaultCommandQ.dump();}
	public boolean addEdit(UndoableEdit anEdit) { return defaultCommandQ.addEdit(anEdit);}
	public boolean canRedo()                    { return defaultCommandQ.canRedo();}
	public boolean canUndo()                    { return defaultCommandQ.canUndo();}
	public void    die()                        { defaultCommandQ.die();}
	public String  getPresentationName()        { return defaultCommandQ.getPresentationName();}
	public String  getRedoPresentationName()    { return defaultCommandQ.getRedoPresentationName();}
	public String  getUndoPresentationName()    { return defaultCommandQ.getUndoPresentationName();}
	public boolean isSignificant()              { return defaultCommandQ.isSignificant();}
	public void    redo()                       { defaultCommandQ.redo();}
	public void    undo()                       { defaultCommandQ.undo();}
	public boolean replaceEdit(UndoableEdit anEdit)  {return defaultCommandQ.replaceEdit(anEdit);}
	
	//==========================================================================
	//===  Auxillary Command Queue Methods =====================================
	
	/**
	 * Creating a new auxillary queue for the sheet
	 */	
	public void createQueueFor(Sheet mySheet){
		SheetWithCommandQueue newQ = new SheetWithCommandQueue(mySheet);
		auxillaryCommandQs.add(newQ);
	}
	
	/**
	 * Getting the associated queue for the sheet
	 */
	public CommandQueue getQueueFor(Sheet mySheet){
		Enumeration auxQs = auxillaryCommandQs.elements();
		while(auxQs.hasMoreElements()){
			SheetWithCommandQueue q = (SheetWithCommandQueue)auxQs.nextElement();
			if(q.getSheet() == mySheet){
				return q.getCommandQueue();
			}
		}
		return defaultCommandQ;
	}
	
	/**
	 * Can be used to set a different subclass of CommandQueue in the auxillary
	 * queue.
	 */
	public void setCommandQueueFor(Sheet mySheet, CommandQueue myQ){
	   Enumeration auxQs = auxillaryCommandQs.elements();
		while(auxQs.hasMoreElements()){
			SheetWithCommandQueue q = (SheetWithCommandQueue)auxQs.nextElement();
			if(q.getSheet() == mySheet){
				q.setCommandQueue(myQ);
			}
		}
	}
	
	/**
	 * Bundles the command queue and its associated sheet into a nice compact
	 * object to store in the vector auxillaryCommandQs.
	 */
	//===========================================================================
	//===   SHEET WITH COMMAND QUEUE  ===========================================

	private class SheetWithCommandQueue {
		private CommandQueue q 					= new LinearCommandQueue();
		private Sheet 		 pairedSheet		= null;
		
		public SheetWithCommandQueue(Sheet paired){
			pairedSheet = paired;
		}
		public Sheet getSheet(){
			return pairedSheet;
		}		
		
		public void setCommandQueue(CommandQueue q) {
			this.q = q;
		}
		public CommandQueue getCommandQueue() {
			return q;
		}
	}	
	
	//===   SHEET WITH COMMAND QUEUE  ===========================================	
	//===========================================================================

}

	
	
	
	
	
	

