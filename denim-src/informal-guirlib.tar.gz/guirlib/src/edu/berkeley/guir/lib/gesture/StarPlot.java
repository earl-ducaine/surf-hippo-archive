package edu.berkeley.guir.lib.gesture;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class StarPlot extends JPanel implements Observer
{
  FeatureVector featureVector = null;
  boolean logScale = false;
  double scale = 1.0;
  FeaturePicker featurePicker = null;
  public Color negativeColor = Color.blue;
  double[] values = null;
  double[] featureScales = null;
  double[] weights = null;
  
  public StarPlot(FeatureVector myFeatureVector)
  {
    super();
    featureVector = myFeatureVector;
    featureVector.addObserver(this);
    buildUI();
  }

  public StarPlot(double[] valueVector)
  {
    super();
    values = valueVector;
    buildUI();
  }

  private void buildUI()
  {
    setPreferredSize(new Dimension(200, 200));
    setDoubleBuffered(true);
    setBackground(Color.white);
    addKeyListener(new KeyBindings());
    addMouseListener(new SimpleFocus());
  }
  
  public void setFeaturePicker(FeaturePicker fp)
  {
    featurePicker = fp;
    featurePicker.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e)
      {
	repaint();
      }
    });
    repaint();
  }

  public void setFeatureScales(double[] scales)
  {
    featureScales = scales;
    repaint();
  }
  
  public void setWeights(double[] w)
  {
    weights = w;
    repaint();
  }
  
  public void paintComponent(Graphics graphics)
  {
    Graphics g = graphics.create();
    // use try...finally to make sure the Graphics is disposed of
    try {
      Insets insets = getInsets();
      
      if (featureVector != null)
	values = featureVector.getValues();
      
      super.paintComponent(g.create());
      g.translate(getWidth()/2 + insets.left, getHeight()/2 + insets.top);
      
      int numFeatures = values.length;
      int numSelected = (featurePicker == null) ? numFeatures :
	featurePicker.getNumSelected();
      if (numSelected > 0) {
	double deltaTheta = 2 * Math.PI / numSelected;

	double theta = 0;
	int lastx = 0, lasty = 0;
	int firstx = 0, firsty = 0;
	boolean first = true;
	for (int i = 0; i < numFeatures; i++) {
	  if ((featurePicker == null) ||
	      (featurePicker.isFeatureSelected(i))) {
	    Graphics tempGraphics = g.create();
	    double featureValue = values[i];
	    if (featureScales != null)
	      featureValue *= featureScales[i];
	    if (weights != null) {
	      featureValue *= weights[i+1];
	    }

	    if (featureValue < 0) {
	      tempGraphics.setColor(negativeColor);
	      featureValue = -featureValue;
	    }
	    if (logScale) {
	      featureValue = Math.log(featureValue);
	      if (featureValue < 0)
		featureValue = 0;
	    }
	    
	    featureValue *= scale;
	    
	    int x = (int) Math.round(Math.sin(theta) * featureValue);
	    int y = (int) -Math.round(Math.cos(theta) * featureValue);
	    
	    tempGraphics.drawLine(0, 0, x, y);
	    tempGraphics.drawString(Integer.toString(i), x, y);
	    if (first) {
	      firstx = x;
	      firsty = y;
	      first = false;
	    }
	    else {
	      // if not the first time, draw a connecting line
	      g.drawLine(lastx, lasty, x, y);
	    }
	    lastx = x;
	    lasty = y;
	    theta += deltaTheta;
	  }
	}
	g.drawLine(lastx, lasty, firstx, firsty);
      }
    }
    finally {
      g.dispose();
    }
  }

  public void setLogScale(boolean on)
  {
    if (on != logScale) {
      logScale = on;
      repaint();
    }
  }

  public boolean getLogScale()
  {
    return logScale;
  }

  public void setScale(double newScale)
  {
    if (newScale != scale) {
      scale = newScale;
      repaint();
    }
  }
  
  public double getScale()
  {
    return scale;
  }

  public void update(Observable o, Object arg)
  {
    if (o instanceof FeatureVector)
      repaint();
  }

  public void setTitle(String title)
  {
    setBorder(BorderFactory.
	      createTitledBorder(BorderFactory.createEtchedBorder(),
				 title,
				 TitledBorder.CENTER,
				 TitledBorder.TOP));
    repaint();
  }
  
  class KeyBindings extends KeyAdapter
  {
    public void keyTyped(KeyEvent e)
    {
      switch (e.getKeyChar()) {
      case '+':
	setScale(getScale()*2);
	break;
      case '-':
	setScale(getScale()/2);
	break;
      case 'l':
	setLogScale(!getLogScale());
	break;
      default:
	break;
      }
    }
  }

  class SimpleFocus extends MouseAdapter
  {
    public void mouseEntered(MouseEvent e)
    {
      requestFocus();
    }
  }
}
