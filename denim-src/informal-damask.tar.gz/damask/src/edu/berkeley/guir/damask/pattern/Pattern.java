package edu.berkeley.guir.damask.pattern;

import java.net.URL;
import java.util.*;

import edu.berkeley.guir.damask.InteractionGraph;
import edu.berkeley.guir.damask.InteractionSubgraph;
import edu.berkeley.guir.damask.view.pattern.PatternParser;

/** 
 * An interaction pattern. The structure of a pattern is based on
 * those by Alexander et al, Gamma et al, and the Design of Sites book.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-19-2003 James Lin
 *                               Created Pattern.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-19-2003
 */

public class Pattern {
   final java.util.regex.Pattern PATTERN_LETTER_NUMBER_PAIR =
      java.util.regex.Pattern.compile(".*\\((\\p{Alpha}*)(\\p{Digit}*)\\).*");

   private String ID;
   private String collectionID;
   private String name;
   private URL illustrationURL;
   private String illustrationText;
   private String background;
   private String problem;
   private String forces;
   private Set/*<InteractionSubgraph>*/ examples;
   private String solutionText;
   private PatternSolution solution;
   private URL solutionImageURL;
   private String solutionImageText;
   private Set/*<Pattern>*/ inRefs;
   private Set/*<Pattern>*/ outRefs;
   private String relatedPatternsText;
   private String credits;
   
   private String group;
   private int indexInGroup;
   
   private URL patternURL;

   //===========================================================================

   /**
    * Constructs a blank pattern.
    */
   public Pattern() {
      ID = "";
      collectionID = "";
      name = "";
      illustrationURL = null;
      illustrationText = "";
      background = "";
      problem = "";
      forces = "";
      examples = new HashSet();
      solution = new PatternSolution(this);
      solutionImageURL = null;
      solutionText = "";
      inRefs = new HashSet();
      outRefs = new HashSet();
      
      patternURL = null;
   }

   //===========================================================================

   /**
    * Constructs a blank pattern.
    */
   public Pattern(
         final String collectionID,
         final String patternID,
         final URL patternURL) {
      this();
      this.ID = patternID;
      this.collectionID = collectionID;
      this.patternURL = patternURL;
      name = PatternParser.getPatternName(patternURL);
      setGroupAndIndex();
   }

   //===========================================================================
   
   private void openFromFileIfNecessary() {
      if (patternURL != null) {
         final URL url = patternURL;
         patternURL = null;
         PatternParser.parseInto(url, this);
      }
   }

   //===========================================================================

   /**
    * Returns the ID of this pattern.
    */
   public String getID() {
      return ID;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the ID of this pattern.
    */
   public void setID(String string) {
      openFromFileIfNecessary();
      ID = string;
   }

   //===========================================================================

   /**
    * Returns the ID of this pattern's collection.
    */
   public String getCollectionID() {
      return collectionID;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the ID of this pattern's collection.
    */
   public void setCollectionID(String string) {
      openFromFileIfNecessary();
      collectionID = string;
   }


   //===========================================================================

   /**
    * Returns the name of this pattern.
    */
   public String getName() {
      return name;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the name of this pattern.
    */
   public void setName(String name) {
      openFromFileIfNecessary();
      this.name = name;
      setGroupAndIndex();
   }

   //===========================================================================
   
   /**
    * Sets the group and index within the group that this pattern is in.
    * 
    * This assumes that this information is represented within the name --
    * if the name of the pattern is PATTERN (A5), then the group is "A" and
    * the index is 5. 
    */
   private void setGroupAndIndex() {
      java.util.regex.Matcher matcher =
         PATTERN_LETTER_NUMBER_PAIR.matcher(name);
      if (matcher.matches()) {
         group = matcher.group(1);
         try {
            indexInGroup = Integer.parseInt(matcher.group(2));
         }
         catch (NumberFormatException ex) {
            indexInGroup = -1;
         }
      }
      else {
         group = null;
         indexInGroup = -1;
      }
   }
   
   //---------------------------------------------------------------------------

   /**
    * Returns the group that this pattern is in.
    * 
    * This assumes that the group is represented within the name -- if the
    * name of the pattern is PATTERN (A5), then the group is "A". 
    */
   public String getGroup() {
      return group;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the index of this pattern within the pattern's group.
    * 
    * This assumes that the index is represented within the name -- if
    * the name of the pattern is PATTERN (A5), then the index is 5. 
    */
   public int getIndexInGroup() {
      return indexInGroup;
   }

   //===========================================================================

   /**
    * Returns the URL of the sensitizing background image of this pattern.
    */
   public URL getIllustrationURL() {
      openFromFileIfNecessary();
      return illustrationURL;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the sensitizing background image of this pattern.
    */
   public void setIllustrationURL(final URL url) {
      openFromFileIfNecessary();
      this.illustrationURL = url;
   }

   //===========================================================================

   /**
    * Returns the caption of the sensitizing background image of this pattern.
    */
   public String getIllustrationText() {
      openFromFileIfNecessary();
      return illustrationText;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the caption of the sensitizing background image of this pattern.
    */
   public void setIllustrationText(String text) {
      openFromFileIfNecessary();
      this.illustrationText = text;
   }

   //===========================================================================

   /**
    * Returns the background information on this pattern.
    */
   public String getBackground() {
      openFromFileIfNecessary();
      return background;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the background information on this pattern.
    */
   public void setBackground(String background) {
      openFromFileIfNecessary();
      this.background = background;
   }

   //===========================================================================
   
   /**
    * Returns the problem that this pattern addresses.
    */
   public String getProblem() {
      openFromFileIfNecessary();
      return problem;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the problem that this pattern addresses.
    */
   public void setProblem(String problem) {
      openFromFileIfNecessary();
      this.problem = problem;
   }

   //===========================================================================
   
   /**
    * Returns the forces that affect this pattern.
    */
   public String getForces() {
      openFromFileIfNecessary();
      return forces;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the forces that affect this pattern.
    */
   public void setForces(String forces) {
      openFromFileIfNecessary();
      this.forces = forces;
   }
   
   //===========================================================================
   
   /**
    * Returns examples of this pattern in use.
    * 
    * @return a read-only collection of examples (as PatternInstances)
    */
   public Collection getExamples() {
      openFromFileIfNecessary();
      return Collections.unmodifiableCollection(examples);
   }

   //===========================================================================
   
   /**
    * Creates an instance of this pattern. Also adds the new instance to this
    * pattern's set of examples.
    */
   public InteractionSubgraph createPatternInstance(InteractionGraph graph) {
      openFromFileIfNecessary();
      final InteractionSubgraph subgraph = solution.createPatternInstance(graph);
      examples.add(subgraph);
      
      return subgraph;
   }
   
   //===========================================================================
   
   /**
    * Returns the generalized solution of this pattern for all devices.
    */
   public PatternSolution getSolution() {
      openFromFileIfNecessary();
      return solution;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the generalized solution of this pattern for all devices.
    */
   public void setSolution(final PatternSolution solution) {
      openFromFileIfNecessary();
      this.solution = solution;
   }
   
   //===========================================================================
   
   /**
    * Returns the text of the generalized solution of this pattern.
    */
   public String getSolutionText() {
      openFromFileIfNecessary();
      return solutionText;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the text of the generalized solution of this pattern.
    */
   public void setSolutionText(final String solutionText) {
      openFromFileIfNecessary();
      this.solutionText = solutionText;
   }
   
   //===========================================================================
   
   /**
    * Returns the URL of the solution illustration of this pattern.
    */
   public URL getSolutionImageURL() {
      openFromFileIfNecessary();
      return solutionImageURL;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the URL of the solution illustration of this pattern.
    */
   public void setSolutionImageURL(final URL url) {
      openFromFileIfNecessary();
      this.solutionImageURL = url;
   }
   
   //===========================================================================
   
   /**
    * Returns the caption of the solution illustration of this pattern.
    */
   public String getSolutionImageText() {
      openFromFileIfNecessary();
      return solutionImageText;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the caption of the solution illustration of this pattern.
    */
   public void setSolutionImageText(final String text) {
      openFromFileIfNecessary();
      this.solutionImageText = text;
   }

   //===========================================================================
   
   /**
    * Returns patterns that use this pattern.
    * 
    * @return a read-only collection of patterns (as Patterns)
    */
   public Collection/*<Pattern>*/ getInRefs() {
      openFromFileIfNecessary();
      return Collections.unmodifiableCollection(inRefs);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the given pattern to the set of patterns which use the given
    * pattern.
    */
   public void addInRef(Pattern pattern) {
      openFromFileIfNecessary();
      inRefs.add(pattern);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given pattern from the set of patterns which use the given
    * pattern.
    * 
    * @return whether the given pattern was being used by this pattern
    */
   public boolean removeInRef(Pattern pattern) {
      openFromFileIfNecessary();
      return inRefs.remove(pattern);
   }

   //===========================================================================
   
   /**
    * Returns patterns that this pattern uses.
    * 
    * @return a read-only collection of patterns (as Patterns)
    */
   public Collection/*<Pattern>*/ getOutRefs() {
      openFromFileIfNecessary();
      return Collections.unmodifiableCollection(outRefs);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the given pattern to the set of patterns that this pattern uses.
    */
   public void addOutRef(Pattern pattern) {
      openFromFileIfNecessary();
      outRefs.add(pattern);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given pattern from the set of patterns that this pattern uses.
    * 
    * @return whether the given pattern was being used by this pattern
    */
   public boolean removeOutRef(Pattern pattern) {
      openFromFileIfNecessary();
      return outRefs.remove(pattern);
   }
   
   //===========================================================================
   
   /**
    * Returns the text describing the patterns related to this pattern.
    */
   public String getRelatedPatternsText() {
      openFromFileIfNecessary();
      return relatedPatternsText;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the text describing the patterns related to this pattern.
    */
   public void setRelatedPatternsText(final String text) {
      openFromFileIfNecessary();
      this.relatedPatternsText = text;
   }
   
   //===========================================================================
   
   /**
    * Returns the credits for this pattern.
    */
   public String getCredits() {
      openFromFileIfNecessary();
      return credits;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the credits for this pattern.
    */
   public void setCredits(final String credits) {
      openFromFileIfNecessary();
      this.credits = credits;
   }
   
   //---------------------------------------------------------------------------
   
   // @Override
   public String toString() {
      return collectionID + ":" + ID;
   }
}
