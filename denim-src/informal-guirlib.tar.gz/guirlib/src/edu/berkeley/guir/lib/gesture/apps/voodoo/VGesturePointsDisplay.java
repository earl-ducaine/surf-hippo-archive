package edu.berkeley.guir.lib.gesture.apps.voodoo;

import java.awt.*;
import edu.berkeley.guir.lib.gesture.GesturePointsDisplay;
import edu.berkeley.guir.lib.gesture.util.Misc;

public class VGesturePointsDisplay extends GesturePointsDisplay {
  public static double straightThreshold = 5 / 180.0 * Math.PI;
  public static double cornerThreshold = 60 / 180.0 * Math.PI;
  public static Color straightColor = Color.red;
  public static Color curvyColor = Color.blue;
  
  public VGesturePointsDisplay()
  {
    super(null);
  }

  // snipped from GesturePointsDisplay and modified
  public void paint(Graphics graphics)
  {
    super.paint(graphics);
    //System.err.println("paint: " + this + " painting " + getGesture());
    if (getGesture() != null) {
      Dimension size = getSize();
      
      if (isSelected && showSelected) {
    	graphics.setColor(Color.red);
	graphics.drawRect(0, 0, size.width-1, size.height-1);
      }

      Polygon points = getGesture().getPoints();
      if ((points != null) && (points.npoints > 0)) {
	double straightLen = 0;
	double curvyLen = 0;
    	Insets insets = getInsets();
	Graphics g = graphics.create();
	// use try...finally to make sure the Graphics is disposed of
	try {
	  g.clipRect(insets.left, insets.top, size.width - insets.right,
		     size.height - insets.bottom);
	  g.translate(xoffset + insets.left, yoffset + insets.top);
	  
	  g.setColor(Color.black);
	  
	  Graphics pointsGraphics = null;
	  // use try...finally to make sure the Graphics is disposed of
	  try {
	    if (showPointsOn) {
	      pointsGraphics = g.create();
	      pointsGraphics.setColor(Color.white);
	    }

	    g.fillOval(points.xpoints[0]-dotRadius,
		       points.ypoints[0]-dotRadius,
		       dotRadius*2, dotRadius*2);
	    int numPoints = (animate ? animatePoints : points.npoints);
	    if (numPoints > 1) {
	      int i;

	      g.drawLine(points.xpoints[0], points.ypoints[0],
			 (points.xpoints[0] + points.xpoints[1])/2,
			 (points.ypoints[0] + points.ypoints[1])/2);
	      for (i = 1; i < (numPoints-1); i++) {
		boolean straight = isStraight(i);
		g.setColor(straight ? straightColor : curvyColor);
		double segmentLen = (dist(i-1, i) + dist(i, i+1))/2;
		if (straight) {
		  straightLen += segmentLen;
		}
		else {
		  curvyLen += segmentLen;
		}
		
		g.drawLine((points.xpoints[i-1] + points.xpoints[i])/2,
			   (points.ypoints[i-1] + points.ypoints[i])/2,
			   points.xpoints[i], points.ypoints[i]);
		g.drawLine(points.xpoints[i], points.ypoints[i],
			   (points.xpoints[i] + points.xpoints[i+1])/2,
			   (points.ypoints[i] + points.ypoints[i+1])/2);
		if (showPointsOn) {
		  pointsGraphics.
		    fillOval(points.xpoints[i]-1, points.ypoints[i]-1,
			     3, 3);
		}
	      }
	      g.drawLine((points.xpoints[numPoints-2] +
			  points.xpoints[numPoints-1])/2,
			 (points.ypoints[numPoints-2] +
			  points.ypoints[numPoints-1])/2,
			 points.xpoints[numPoints-1],
			 points.ypoints[numPoints-1]);
	    }
	    if (showPointsOn && (numPoints > 0)) {
	      pointsGraphics.
		drawLine(points.xpoints[numPoints-1],
			 points.ypoints[numPoints-1],
			 points.xpoints[numPoints-1],
			 points.ypoints[numPoints-1]);
	    }
	    final double totalLen = straightLen + curvyLen;

	    String percentStr;
	    if (straightLen > curvyLen) {
	      g.setColor(straightColor);
	      percentStr = Misc.toString(straightLen / totalLen, 2);
	    }
	    else {
	      g.setColor(curvyColor);
	      percentStr = Misc.toString(curvyLen / totalLen, 2);
	    }
	    g.drawString(percentStr, 0, 0);
	  }
	  finally {
	    if (showPointsOn) {
	      pointsGraphics.dispose();
	    }
	  }
	}
	finally {
	  g.dispose();
	}
      }
    }
  }

  boolean isStraight(int index)
  {
    double theta = computeAngle(index);

    return (theta < straightThreshold) || (theta > cornerThreshold);
  }

  double computeAngle(int index)
  {
    double Ax, Ay, Bx, By;

    Polygon points = getGesture().getPoints();
    Ax = points.xpoints[index] - points.xpoints[index-1];
    Ay = points.ypoints[index] - points.ypoints[index-1];
    Bx = points.xpoints[index+1] - points.xpoints[index];
    By = points.ypoints[index+1] - points.ypoints[index];

    double magA, magB;
    magA = Math.sqrt(Ax * Ax + Ay * Ay);
    magB = Math.sqrt(Bx * Bx + By * By);
    
    double dotProduct = (Ax * Bx + Ay * By) / (magA * magB);
    double theta = Math.acos(dotProduct);

    return theta;
  }

  double dist(int i, int j)
  {
    Polygon points = getGesture().getPoints();
    int dx, dy;
    dx = points.xpoints[i] - points.xpoints[j];
    dy = points.ypoints[i] - points.ypoints[j];
    return Math.sqrt(dx * dx + dy * dy);
  }
}
