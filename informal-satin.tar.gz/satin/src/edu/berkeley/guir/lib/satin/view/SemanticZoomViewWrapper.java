//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import edu.berkeley.guir.lib.util.StringLib;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.objects.*;

/**
 * Wraps normal views into a semantic-zoom view.
 * A semantic zoom view is only displayed at certain programmer-specified
 * zoom levels.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 11 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class SemanticZoomViewWrapper 
   extends    ViewWrapper
   implements SemanticZoomView {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 2087432905825712779L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   double  fadeIn     = 0;
   double  startScale = 0;
   double  endScale   = Double.MAX_VALUE;
   double  fadeOut    = Double.MAX_VALUE;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Empty constructor, does nothing.
    */
   public SemanticZoomViewWrapper() {
      commonInitializations();
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Wrap a view into a semantic-zoom wrapper. By default, this semantic zoom
    * wrapper is active from zoom scale 0 to infinity.
    */
   public SemanticZoomViewWrapper(View v) {
      setView(v);
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a new semantic zoom view with the specified range.
    *
    * @see #setDisplayRange(double, double)
    */
   public SemanticZoomViewWrapper(View v, double start, double end) {
      setView(v);
      setDisplayRange(start, end);
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a new semantic zoom view with the specified range.
    *
    * @param fIn  is the fade-in value.
    * @param s    is the start display value.
    * @param e    is the end display value.
    * @param fOut is the fade-out value.
    * @see   #setDisplayRange(double, double, double, double)
    */
   public SemanticZoomViewWrapper(View v, double fIn, double s, 
         double e, double fOut) {

      setView(v);
      setDisplayRange(fIn, s, e, fOut);
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Semantic Zoom Wrapper");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   public void setDisplayRange(double fadeIn, double startScale, 
         double endScale, double fadeOut) {

      //// 0.1. Scale values are non-negative.
      if (fadeIn < 0 || startScale < 0 || endScale < 0 || fadeOut < 0) {
         throw new 
           IllegalArgumentException("Scale values should be strictly positive");
      }

      //// 0.2. Each of the values should be in increasing order, with
      ////      fadeIn < startScale < endScale < fadeOut.
      if (! ((fadeIn     <= startScale)   && 
             (startScale <= endScale)     && 
             (endScale   <= fadeOut))) {
         throw new IllegalArgumentException("Scale values must be increasing from left to right (ie fadeIn <= startScale <= endScale <= fadeOut)");
      }

      //// 1. Just set the values.
      this.fadeIn     = fadeIn;
      this.startScale = startScale;
      this.endScale   = endScale;
      this.fadeOut    = fadeOut;
   } // of setDisplayRange

   //-----------------------------------------------------------------

   public void setDisplayRange(double startScale, double endScale) {
      setDisplayRange(startScale, startScale, endScale, endScale);
   } // of setDisplayRange

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   public double getFadeIn() {
      return (fadeIn);
   } // of getFadeIn

   //-----------------------------------------------------------------

   public double getStartScale() {
      return (startScale);
   } // of getStartScale

   //-----------------------------------------------------------------

   public double getEndScale() {
      return (endScale);
   } // of getEndScale

   //-----------------------------------------------------------------

   public double getFadeOut() {
      return (fadeOut);
   } // of getFadeOut

   //-----------------------------------------------------------------

   /**
    * Get the absolute scale factor.
    */
   protected double getScaleFactor() {
      double          scale;

      //// 1. Calculations.
      scale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                getAttachedGraphicalObject());
      //scale = getAttachedGraphicalObject().getTransform(COORD_ABS).getScaleX();
      
      return (scale);
   } // of getAbsoluteScaleFactor

   //-----------------------------------------------------------------

   public float getViewDisplayValue() {
      double scale = getScaleFactor();
      double s;

      //// 1.1. Don't show anything if outside of range.
      ////      Strictly less than, since fadeIn could equal startScale.
      if (scale < fadeIn || scale > fadeOut) {
         return (0);
      }

      //// 1.2. Show completely if inside the range.
      if (startScale <= scale && scale <= endScale) {
         return (1);
      }

      //// 1.3. Otherwise, linearly calculate the fade value.
      if (scale < startScale) {
         s = ((scale - fadeIn) / (startScale - fadeIn));
      }
      else {
         s = ((fadeOut - scale) / (fadeOut - endScale));
      }

      if (s < FLOATING_PT_TOLERANCE) {
         return (0);
      }
      return ((float) s);
   } // of getViewDisplayValue

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 1. Append data.
      strbuf.append(super.toString());
      strbuf.append("\nBounding Box:        " +
            StringLib.toString(getBoundingPoints2DRef().getBounds2D()));
      strbuf.append("\nFadeIn:              " + getFadeIn());
      strbuf.append("\nStart Val:           " + getStartScale());
      strbuf.append("\nEnd Val:             " + getEndScale());
      strbuf.append("\nFadeOut:             " + getFadeOut());
      strbuf.append("\nCur Absolute Scale:  ");
      if (getAttachedGraphicalObject() == null) {
         strbuf.append("not attached");
      }
      else {
         strbuf.append(getScaleFactor());
         strbuf.append("\nAttached Gob:        " +
                       getAttachedGraphicalObject().getClass() +
                       getAttachedGraphicalObject().getUniqueID());
         strbuf.append("\nRel transform:       " +
                       getAttachedGraphicalObject().getTransform(COORD_REL));
         strbuf.append("\nAbs transform:       " +
                       getAttachedGraphicalObject().getTransform(COORD_ABS));
         if (getAttachedGraphicalObject().getParentGroup() != null) {
            strbuf.append("\nParent Rel transform:" +
               getAttachedGraphicalObject().getParentGroup().getTransform(COORD_REL));
            strbuf.append("\nParent Abs transform:" +
               getAttachedGraphicalObject().getParentGroup().getTransform(COORD_ABS));
         }
         if (getAttachedGraphicalObject().getSheet() != null) {
            strbuf.append("\nSheet Rel transform: " +
                  getAttachedGraphicalObject().getSheet().getTransform(COORD_REL));
            strbuf.append("\nSheet Abs transform: " +
                  getAttachedGraphicalObject().getSheet().getTransform(COORD_ABS));
         }
      }

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);
      
      return (str);
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   RENDERING   =========================================================

   public void render(SatinGraphics g) {
      v.render(g);
   } // of render

   //===   RENDERING   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new SemanticZoomViewWrapper()));
   } // of method

   //-----------------------------------------------------------------

   protected SemanticZoomViewWrapper clone(SemanticZoomViewWrapper vw) {
      //// 1. Clone chain.
      super.clone(vw);

      //// 2. Do clone work.
      vw.fadeIn     = this.fadeIn;
      vw.startScale = this.startScale;
      vw.endScale   = this.endScale;
      vw.fadeOut    = this.fadeOut;

      //// 3. Return.
      return (vw);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static void main(String[] argv) {
      PatchImpl p1 = new PatchImpl(new java.awt.Rectangle(10, 10, 25, 35));
      PatchImpl p2;

      p1.setView(new SemanticZoomViewWrapper(p1.getView()));

      debug.println("before");
      debug.println(p1.getView());

      p2 = (PatchImpl) p1.clone();

      debug.println("after");
      debug.println(p2.getView());
   } // of method
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
