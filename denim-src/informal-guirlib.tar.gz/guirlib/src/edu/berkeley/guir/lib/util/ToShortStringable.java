/*
 * Created on Sep 16, 2003
 */
package edu.berkeley.guir.lib.util;

/**
 * 
 * @author  <a href="http://guir.berkeley.edu/projects/papier-mache">Jack Li</a> ( jack(AT)eecs{DOT}berkeley{DOT}edu )
 */
public interface ToShortStringable {
	String toShortString();
}
