/*
 * RemoteOutgoingSocket.java
 * Created on November 6, 2001, 3:33 PM
 */

package edu.berkeley.guir.lib.satin.remote;

import java.io.*;
import java.net.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.command.*;

/**
 * @author  Scott Klemmer, Katie Everitt
 * @version 1.3
 */
public class RemoteOutgoingSocket extends Thread {
   private RemoteSocketMgr         m_manager       = null;
    
   private int                     m_port          = -1;
   private Socket                  m_outConnection = null;
   private PrintWriter             m_out           = null;
   private BufferedReader          m_outEcho       = null;
   private String                  m_hostName      = null;

   /** Creates new GRemoteOutgoingSocket */
   public RemoteOutgoingSocket(RemoteSocketMgr manager,int port_num) {
      m_manager = manager;
      m_port = port_num;    
   }
    

   public void connectToHost(String hostName) {
      System.out.println("RemoteOutSocket connect to host called");
      m_hostName = hostName;     
      start();
   }


   private void establishConnection() {
      System.out.println("RemoteOutSocket establishConnection called");

      try {
         m_outConnection = new Socket(m_hostName, m_port);
         
         //NOTE: If we get here, it means that the Socket did *not* throw an exception. Ergo, we're connected
         System.out.println("Connection Established: Connected to " + m_hostName + " - " + m_port);
         // We set the socket manager here because we use whether the manager exists to determine 
         // if we should send an event remotely.
         SatinConstants.cmdqueue.setRemoteSocketMgr(m_manager);
         m_manager.setRemoteListener((RemoteCommandQueue)(SatinConstants.cmdqueue.getCommandQueue()));
         
      } catch (UnknownHostException e) {
         System.out.println("RemoteOutgoingSocket: Unknown host - " + m_hostName);
      } catch (SecurityException se) {
         System.out.println("RemoteOutgoingSocket: Security Exception");
      } catch (IOException e) {            
         //It fails here -- When does an IOException happen?????
         System.out.println("IOException, the problem is:"+e.getMessage());
         try {Thread.sleep(500);} catch (InterruptedException e2) { }
         return;
      }

      try{
         m_out = new PrintWriter(m_outConnection.getOutputStream(), true);        
      } catch (IOException e) {
         System.out.println("RemoteOutgoingSocket: Failed to create OutputStream.");
      }
           
      try {
         m_outEcho = new BufferedReader(new InputStreamReader(m_outConnection.getInputStream()));
      } catch (IOException e) {
         System.out.println("RemoteOutgoingSocket: Failed to create InputStream (Response Echo).");
      }
   }

       
   public void run() {
      System.out.println("RemoteOutSocket run called");
      while (true) {
         if (m_outConnection == null) {
            //if we haven't made a connection
               establishConnection();
         } else {
            //have a connection already
               try {
                  IOEvent rEvent = null;
                  System.out.println("RemoteOutgoingSocket: Awaiting outgoing event...");
                  while (rEvent == null) {
                     rEvent = m_manager.getOutgoingEvent(m_port);
                     if (rEvent == null) {
                           try { Thread.sleep(50); } catch (InterruptedException e) { }
                     }
                    }
                    System.out.println("RemoteOutgoingSocket: Sending outgoing event...");
                    // Send Over Socket...
                    m_out.println(rEvent.getXML());

                    String echo = m_outEcho.readLine();
                    //m_manager.postEcho(m_port, echo);
                    
                 } catch (IOException e) {
                    System.out.println("RemoteOutgoingSocket: Connection lost...\n");
                    try {
                        m_outConnection.close();
                        m_outConnection = null;
                    } catch (IOException e2) {
                    }
                }
            }   
        }
    }
}