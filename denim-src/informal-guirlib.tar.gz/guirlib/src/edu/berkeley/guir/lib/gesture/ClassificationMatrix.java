package edu.berkeley.guir.lib.gesture;

import edu.berkeley.guir.lib.gesture.util.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;

/**
 * Displays how all example Gestures in a GestureSet were classified.
 * Clicking on an element of the table brings up the appropriate
 * GestureCategoryFrame, narrowed to the Gestures corresponding to the
 * element.
 */
public class ClassificationMatrix extends JFrame implements Observer
{
  /**
   * examples[i][j] is a Vector of all Gestures from Category i that
   * were categorized as being in Category j.
   */
  Vector[][] examples;
  /**
   * percentages[i][j] is the fraction of all Gestures from Category i that
   * were categorized as being in Category j.
   */
  Double[][] percentages;
  /** The set the examples that were tested come from. */
  String[] rowNames;
  String[] colNames;
  GestureSet exampleSet;
  /** The display of the exampleSet (not always available). */
  GestureSetDisplay exampleSetDisplay = null;
  /** The set they are being recognized in. */
  GestureSet targetSet;
  CTable table;
  boolean markedOld = false;
  
  /**
   * exampleMatrix[i][j] should be a Vector of all Gestures from Category
   * i that were categorized as being in Category j.
   * If gsd is non-null, clicking on a cell brings up the appropriate
   * Category with the offending gestures highlighted.
   */
  ClassificationMatrix(Vector[][] exampleMatrix, GestureSet example,
		       GestureSet target)
  {
    super("Classification Matrix");
    init(exampleMatrix, example, target);
  }
  
  ClassificationMatrix(Vector[][] exampleMatrix,
		       GestureSetDisplay exampleDisplay, GestureSet target)
  {
    super("Classification Matrix");
    exampleSetDisplay = exampleDisplay;
    init(exampleMatrix, exampleDisplay.getGestureSet(), target);
  }

  ClassificationMatrix(Vector[][] exampleMatrix, GestureSetDisplay gsd)
  {
    this(exampleMatrix, gsd, gsd.getGestureSet());
  }
		       
  private void init(Vector[][] exampleMatrix,
		    GestureSet example, GestureSet target)
  {
    examples = exampleMatrix;
    exampleSet = example;
    targetSet = target;
    exampleSet.addObserver(this);
    targetSet.addObserver(this);
    computePercentages();
    buildUI();
  }
  
  private void computePercentages()
  {
    int numRows = examples.length;
    int numCols = examples[0].length;
    Double[][] temp = new Double[numRows][numCols];
    boolean[] interestingRow = new boolean[numRows];
    boolean[] interestingColumn = new boolean[numCols];
    int numInterestingRows = 0;
    int numInterestingColumns = 0;
    double[] numExamples = new double[numRows];
    
    for (int row = 0; row < numRows; row++) {
      numExamples[row] = 0;
      for (int column = 0; column < numCols; column++) {
	int count;
	if (examples[row][column] == null)
	  count = 0;
	else {
	  count = examples[row][column].size();
	  numExamples[row] += count;
	}
	temp[row][column] = new Double(count);
	if (entryIsInteresting(row, column, (double) count)) {
	  if (!interestingRow[row]) {
	    interestingRow[row] = true;
	    numInterestingRows++;
	  }
	  if (!interestingColumn[column]) {
	    interestingColumn[column] = true;
	    numInterestingColumns++;
	  }
	}
      }
    }

    int destRow = 0, destColumn;
    percentages = new Double[numInterestingRows][numInterestingColumns];
    rowNames = new String[numInterestingRows];
    colNames = new String[numInterestingColumns];
    for (int sourceRow = 0; sourceRow < numRows; sourceRow++) {
      if (interestingRow[sourceRow]) {
	rowNames[destRow] = ((GestureContainer) exampleSet.
			     getChild(sourceRow)).getName();
	destColumn = 0;
	for (int sourceColumn = 0;
	     sourceColumn < numCols;
	     sourceColumn++) {
	  if (interestingColumn[sourceColumn]) {
	    colNames[destColumn] = ((GestureContainer) targetSet.
				    getChild(sourceColumn)).getName();
	    Double current = temp[sourceRow][sourceColumn];
	    if (entryIsInteresting(sourceRow, sourceColumn,
				   current.doubleValue()))
	      percentages[destRow][destColumn] =
		new Double(current.doubleValue() / numExamples[sourceRow]);
	    else
	      percentages[destRow][destColumn] = null;
	    destColumn++;
	  }
	}
	destRow++;
      }
    }
  }
  
  private void buildUI()
  {
    Container contents = getContentPane();
    contents.setLayout(new BorderLayout());

    // make table
    CTableModel dataModel = new AbstractCTableModel() {
      public int getColumnCount() { return percentages[0].length; }
      public int getRowCount() { return percentages.length; }
      public Object getValueAt(int r, int c)
      {
	return percentages[r][c];
      }
      public Class getColumnClass(int c)
      {
	return Double.class;
      }
      public String getColumnName(int c)
      {
	return colNames[c];
      }
      public String getRowName(int r)
      {
	return rowNames[r];
      }
    };

    table = new CTable(dataModel);
    new ColorRenderer(table);
    table.setRowSelectionAllowed(false);
    table.setColumnSelectionAllowed(false);
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    table.addMouseMotionListener(new ToolTipUpdater(table));
    if (exampleSetDisplay != null) {
      table.addMouseListener(new MyMouseListener());
      // this is a hack; really should figure out how big the column
      // needs to be and set it to that
      TableColumnModel tcm = table.getColumnModel();
      for (int i = 0; i < dataModel.getColumnCount(); i++) {
	TableColumn column = tcm.getColumn(i);
	column.setWidth(column.getWidth()/2);
      }
    }
    
    JScrollPane scrollPane = new JScrollPane(table);
    
    contents.add(scrollPane, BorderLayout.CENTER);

    // make menu bar
    JMenu menu;
    JMenuItem item;
    ActionListener listener;
    JMenuBar menuBar = new JMenuBar();

    menu = new JMenu("Table");
    item = new JMenuItem("Close");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	ClassificationMatrix.this.dispose();
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    // add more Graph items here
    menuBar.add(menu);

    getRootPane().setJMenuBar(menuBar);
  }

  boolean entryIsInteresting(int row, int column, double value)
  {
    return (((GestureContainer) exampleSet.getChild(row)).getName().
	    equals(((GestureContainer) targetSet.getChild(column)).
		   getName()) &&
	    (value != 1.0)) || (value != 0.0);
  }
  
  class ColorRenderer implements TableCellRenderer
  {
    TableCellRenderer stringRenderer;
    TableCellRenderer objectRenderer;

    /**
     * Installs itself in table, too
     */
    ColorRenderer(JTable table)
    {
      stringRenderer = table.getDefaultRenderer(String.class);
      objectRenderer = table.getDefaultRenderer(Object.class);
      table.setDefaultRenderer(Double.class, this);
      table.setDefaultRenderer(String.class, this);
    }
    
    public Component getTableCellRendererComponent(JTable table,
						   Object value,
						   boolean isSelected,
						   boolean hasFocus,
						   int row,
						   int column)
    {
      if (value == null) {
	Component defaultComponent = objectRenderer.
	  getTableCellRendererComponent(table, value, isSelected, hasFocus,
					row, column);
	defaultComponent.setBackground(Color.white);
	return defaultComponent;
      }

      double x;
      TableCellRenderer renderer;
      if (value instanceof String) {
	x = 0;
	renderer = stringRenderer;
      }
      else {
	x = ((Double) value).doubleValue();
	value = new Long(Math.round(x * 100.0));
	renderer = objectRenderer;
      }
      
      Component defaultComponent =
	renderer.getTableCellRendererComponent(table, value,
					       isSelected, hasFocus,
					       row, column);
      boolean diagonal = rowNames[row].equals(colNames[column]);
      if ((diagonal) && (x < 1)) {
	defaultComponent.setBackground(Color.yellow);
      }
      else if (!diagonal && (x > 0)) {
	defaultComponent.setBackground(Color.red);
      }
      else {
	defaultComponent.setBackground(Color.white);
      }

      return defaultComponent;
    }
  }

  public void update(Observable o, Object arg)
  {
    if (!markedOld) {
      setTitle(getTitle() + " - OLD");
      markedOld = true;
    }
  }
       
  class MyMouseListener extends MouseAdapter
  {
    public void mousePressed(MouseEvent e)
    {
      Point p = e.getPoint();
      int row = table.rowAtPoint(p);
      int column = table.columnAtPoint(p);
      if ((column >= 0) && (examples[row][column] != null)) {
	GestureCategoryThumbnail gct =
	  exampleSetDisplay.getGestureCategoryThumbnail(row);
	gct.createCategoryFrame();
	GestureCategoryDisplay gcd =
	  gct.getCategoryFrame().getGestureCategoryDisplay();
	String inName = table.getModel().getColumnName(row);
	String outName = table.getModel().getColumnName(column);
	gcd.narrow(examples[row][column],
		   inName + " classified as " + outName);
	gct.showCategoryFrame();
      }
      else {
	System.err.println("No examples there");
      }
    }
  }
}
