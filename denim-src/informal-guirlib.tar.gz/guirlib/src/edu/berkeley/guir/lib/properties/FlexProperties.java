package edu.berkeley.guir.lib.properties;

import java.beans.*;
import java.io.*;
import java.util.*;
import edu.berkeley.guir.lib.collection.*;

/**
 * A generic class for defining and managing properties. Properties are 
 * specified through a {@link PropertySchema} object, and are set in this 
 * class. Instances of this class are intended to be used within other classes.
 *
 * <P>
 * The {@link PropertySchema} defines a single schema for a property. For 
 * example, it specifies the name of the property, and whether it is a simple 
 * one, bound, constrained, or indexed.
 *
 * <P>
 * Simple, bound, constrained, and indexed properties are the same as in 
 * <A HREF="http://java.sun.com/beans/">Java Beans</A>. 
 * <UL>
 *    <LI><I>Simple</I> properties have no semantics
 *    <LI><I>Bound</I> properties notify 
 *        {@link PropertyChangeListener Property Change listeners}
 *    <LI><I>Constrained</I> properties notify 
 *        {@link VetoableChangeListener Veto Change listeners} first, 
 *        and then Property Change Listeners
 *    <LI><I>Indexed</I> properties are just properties that contain a list 
 *        of values.
 * </UL>
 *
 * <P>
 * The FlexProperties contains a set of PropertySchema objects, as 
 * well as the values for properties. When properties are set or modified, 
 * the schema is checked at runtime to ensure that everything is okay. If it 
 * is, then the property value is modified, and the appropriate listeners 
 * are notified.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0-1.0.0, Jun 02 2000, JH
 *               Created class
 *             - GUIRLib-v1.5/1.0.0, Apr 09 2002, JIH
 *               Updated for JDK1.4 with assertions, general cleanup
 *               and removal of cruftiness.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>
 *          )
 * @since   JDK 1.3
 * @version GUIRLib-v1.5/1.0.0, Apr 09 2002 JIH
 */
public class FlexProperties 
   implements PropertyConstants {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   //// Source object, object we are attached to and properties we represent
   Object         src;

   //// Accept items specified in the schema only?
   boolean        flagSpecifiedOnly = false;

   //// Default type of properties.
   int            defaultPropertyType = PROPERTY_SIMPLE;

   //-----------------------------------------------------------------

   //// Property listeners and enabled / disabled counters.
   EventListeners evtlstnrs     = new EventListeners();
   HashBag        bagEnabled    = new HashBag();
   int            enabledCount  = 0;

   //// (String, strPropertyName) -> (Schema, Property Schema)
   HashMap        mapSchema     = new HashMap();

   //// (String, strPropertyName) -> (Object, value)
   HashMap        mapProperties = new HashMap();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates a new properties object, points to itself as the source
    * by default.
    */
   public FlexProperties() {
      setSourceObject(this);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Creates a new properties object.
    *
    * @param src is the Object this FlexProperties object represents 
    *            (ie who contains the FlexProperties). This is here 
    *            because FlexProperties are more of a helper class than 
    *            something that contains properties itself.
    */
   public FlexProperties(Object src) {
      setSourceObject(src);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Creates a new properties object that only allows the specified schema.
    *
    * @param src  is the Object this FlexProperties object represents 
    *             (ie who contains the FlexProperties).
    * @param flag is true if only specified properties are accepted.
    * @see #setSpecifiedOnly(boolean)
    */
   public FlexProperties(Object src, boolean flag) {
      setSourceObject(src);
      setSpecifiedOnly(flag);
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================





   //===========================================================================
   //===   INSTANCE PROPERTY METHODS   =========================================

   /**
    * Set who this properties object is attached to.
    * Must be private because the property and vetoable change support
    * do not allow the source to be changed.
    */
   public void setSourceObject(Object obj) {
      src = obj;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set whether we accept properties that have been specified in the schema
    * only or not.
    *
    * @param flag is true if only specified properties are accepted.
    */
   public void setSpecifiedOnly(boolean flag) {
      flagSpecifiedOnly = flag;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Sets the default schema type of all properties created in this instance.
    *
    * @param type is either {@link #PROPERTY_SIMPLE}, {@link #PROPERTY_BOUND},
    *             or {@link #PROPERTY_CONSTRAINED}. Don't use 
    *             {@link #PROPERTY_INDEXED}, since that is used automatically
    *             if one of the indexed property methods is used.
    */
   public void setDefaultPropertyType(int type) {
      switch (type) {
         case PROPERTY_SIMPLE:
         case PROPERTY_BOUND:
         case PROPERTY_CONSTRAINED:
            defaultPropertyType = type;
            break;
         case PROPERTY_INDEXED:
            throw new RuntimeException(
         "Don't use PROPERTY_INDEXED in this case - see javadoc documentation");

         default:
            throw new RuntimeException("Invalid property type value");
      }
   } // of method

   //===   INSTANCE PROPERTY METHODS   =========================================
   //===========================================================================





   //===========================================================================
   //===   SCHEMA METHODS   ====================================================

   /**
    * Add a schema.
    */
   public void addSchema(PropertySchema schema) {
      mapSchema.put(schema.getPropertyName(), schema);
   } // of method
   

   /**
    * Remove a schema.
    */
   public PropertySchema removeSchema(PropertySchema schema) {
      return (PropertySchema) (mapSchema.remove(schema.getPropertyName()));
   } // of method


   /**
    * Get a reference to the property schema by its property name.
    *
    * @return A reference to the stored schema. This means if you change the
    *         returned value, you really change it for everyone.
    */
   public PropertySchema getSchema(String strPropertyName) {
      return (PropertySchema) (mapSchema.get(strPropertyName));
   } // of method


   /**
    * Check if it contains a certain schema.
    */
   public boolean containsSchema(PropertySchema schema) {
      return (mapSchema.containsKey(schema.getPropertyName()));
   } // of method


   /**
    * Check if it contains a certain schema.
    */
   public boolean containsSchema(String strPropertyName) {
      return (mapSchema.containsKey(strPropertyName));
   } // of method

   //===   SCHEMA METHODS   ====================================================
   //===========================================================================





   //===========================================================================
   //===   ENABLE / DISABLE METHODS   ==========================================

   /**
    * Enable notifications to be sent. Should only be called after a
    * {@link #disableNotify()} method call, otherwise an exception will 
    * be thrown.
    *
    * @throws RuntimeException if there are an un-balanced number of disable
    *                          and enable calls.
    */
   public void enableNotify() {
      if (enabledCount == 0) {
         throw new RuntimeException(
            "Error - unbalanced number of disable / enable notify calls made"
         );
      }
      enabledCount--;
   } // of method


   /**
    * Enable notifications on the specified property. 
    *
    * @throws RuntimeException if there are an un-balanced number of disable
    *                          and enable calls.
    */
   public void enableNotify(String strProperty) {
      if (bagEnabled.size(strProperty) == 0) {
         throw new RuntimeException(
            "Error - unbalanced number of disable / enable notify calls made on"
            + strProperty
         );
      }
      bagEnabled.remove(strProperty);
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if notifications are enabled in general.
    */
   public boolean isEnabled() {
      return (enabledCount <= 0);
   } // of method


   /**
    * See if notifications are enabled on the specified property.
    */
   public boolean isEnabled(String strProperty) {
      if (enabledCount > 0 || bagEnabled.size(strProperty) > 0) {
         return (false);
      }
      return (true);
   } // of method

   //-----------------------------------------------------------------

   /**
    * @see #enableNotify()
    */
   public void disableNotify() {
      enabledCount++;
   } // of method


   /**
    * @see #enableNotify(String)
    */
   public void disableNotify(String strProperty) {
      bagEnabled.add(strProperty);
   } // of method

   //===   ENABLE / DISABLE METHODS   ==========================================
   //===========================================================================





   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   /**
    * Fire if property is enabled.
    *
    * @see #isEnabled()
    * @see #isEnabled(String)
    */
   public void firePropertyChange(PropertyChangeEvent evt) {
      if (isEnabled(evt.getPropertyName())) {
         evtlstnrs.firePropertyChange(evt);
      }
   } // of method


   /**
    * Convenience method, see {@link #firePropertyChange(PropertyChangeEvent)}
    */
   public void firePropertyChange(String str, boolean oldVal, boolean newVal) {
      if (isEnabled(str)) {
         evtlstnrs.firePropertyChange(src, str, oldVal, newVal);
      }
   } // of method


   /**
    * Convenience method, see {@link #firePropertyChange(PropertyChangeEvent)}
    */
   public void firePropertyChange(String str, int oldVal, int newVal) {
      if (isEnabled(str)) {
         evtlstnrs.firePropertyChange(src, str, oldVal, newVal);
      }
   } // of method


   /**
    * Convenience method, see {@link #firePropertyChange(PropertyChangeEvent)}
    */
   public void firePropertyChange(String str, Object oldVal, Object newVal) {
      if (isEnabled(str)) {
         evtlstnrs.firePropertyChange(src, str, oldVal, newVal);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Fire if property is enabled.
    *
    * @see #isEnabled()
    * @see #isEnabled(String)
    */
   public void fireVetoableChange(PropertyChangeEvent evt) 
      throws PropertyVetoException {

      if (isEnabled(evt.getPropertyName())) {
         evtlstnrs.fireVetoableChange(evt);
      }
   } // of method


   /**
    * Convenience method, see {@link #fireVetoableChange(PropertyChangeEvent)}
    */
   public void fireVetoableChange(String str, boolean oldVal, boolean newVal)
      throws PropertyVetoException {

      if (isEnabled(str)) {
         evtlstnrs.fireVetoableChange(src, str, oldVal, newVal);
      }
   } // of method


   /**
    * Convenience method, see {@link #fireVetoableChange(PropertyChangeEvent)}
    */
   public void fireVetoableChange(String str, int oldVal, int newVal) 
      throws PropertyVetoException {

      if (isEnabled(str)) {
         evtlstnrs.fireVetoableChange(src, str, oldVal, newVal);
      }
   } // of method


   /**
    * Convenience method, see {@link #fireVetoableChange(PropertyChangeEvent)}
    */
   public void fireVetoableChange(String str, Object oldVal, Object newVal) 
      throws PropertyVetoException {

      if (isEnabled(str)) {
         evtlstnrs.fireVetoableChange(src, str, oldVal, newVal);
      }
   } // of method

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================





   //===========================================================================
   //===   PROPERTY METHODS   ==================================================

   /**
    * @return an iterator on String objects.
    */
   public Iterator getPropertyNames() {
      return (mapProperties.keySet().iterator());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Ensure that the specified property is not a list.
    *
    * @param strPropertyName is the name of the property to check.
    * @param flagIndexed     means we want indexed access to it.
    */
   private PropertySchema 
   doPropertyCheck(String strPropertyName, boolean flagIndexed) {
      //// 1. Get the schema for this property.
      PropertySchema schema = getSchema(strPropertyName);

      //// 2.1. Do type checking on the schema property type.
      if (schema != null) {
         //// 2.1.1. If we are an indexed property, then make sure we try to
         ////        access as indexed. 
         ////        If we are not an indexed property, then make sure we don't 
         ////        try to access as indexed.
         if (schema.isIndexedProperty() != flagIndexed) {
            if (schema.isIndexedProperty() == true) {
               throw new RuntimeException(
                               "Non-indexed access on an indexed property - " +
                                strPropertyName);
            }
            else {
               throw new RuntimeException(
                               "Indexed access on a non-indexed property - " +
                               strPropertyName);
            }
         }
      }
      //// 2.2. Allow properties that were specified only?
      else {
         if (flagSpecifiedOnly == true) {
            throw new RuntimeException(
                             "Specified property not registered in schema - " +
                             strPropertyName);
         }
      }

      return (schema);
   } // of method



   /**
    * Use for simple, bound, and constrained properties.
    * Use to add or remove properties.
    *
    * @param flagRemove is true if removing, false if putting a real value.
    * @param newVal     is null if removing.
    */
   private void setPropertyRegression(boolean flagRemove, 
                                      String  strPropertyName, 
                                      Object  newVal) {
      //// 1. Do the runtime checks on the schema.
      ////    If the schema does not exist, create one by default.
      PropertySchema schema = doPropertyCheck(strPropertyName, false);
      if (schema == null) {
         schema = new PropertySchema(strPropertyName, defaultPropertyType);
         addSchema(schema);
      }
      Object oldVal = mapProperties.get(strPropertyName);


      try {
         //// 2. First check if value is valid.
         if (schema.acceptValue(oldVal, newVal) == false) {
            throw new IllegalArgumentException("Invalid val for this property");
         }

         //// 3. Fire veto change.
         if (schema.isConstrainedProperty() == true) {
            fireVetoableChange(strPropertyName, oldVal, newVal);
         }

         //// 4. No one vetoed, commit the change.
         if (flagRemove == true) {
            mapProperties.remove(strPropertyName);
         }
         else {
            mapProperties.put(strPropertyName, newVal);
         }

         //// 5. Fire property change.
         if (schema.isConstrainedProperty() || schema.isBoundProperty()) {
            firePropertyChange(strPropertyName, oldVal, newVal);
         }
      }
      catch (IllegalArgumentException e) {
         schema.onIllegalArgumentException(e, oldVal, newVal);
      }
      catch (PropertyVetoException e) {
         schema.onPropertyVetoException(e, oldVal, newVal);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a reference to a property.
    *
    * @return The property value, or null if it doesn't exist (or if its value
    *         is null). Remember that you get a reference to the stored value. 
    */
   public Object getProperty(String strPropertyName) {
      //// 1. Do the runtime checks.
      doPropertyCheck(strPropertyName, false);

      return (mapProperties.get(strPropertyName));
   } // of method


   /**
    * Set a property. Use for simple, bound, and constrained properties.
    * <P>
    * If {@link #setSpecifiedOnly(boolean)} is set to false (which it is by
    * default), then a property schema will be created. The type of this
    * new schema is normally {@link #PROPERTY_SIMPLE} unless another one is
    * specified by {@link #setDefaultPropertyType(int)}.
    */
   public void setProperty(String strPropertyName, Object newVal) {
      setPropertyRegression(false, strPropertyName, newVal);
   } // of method


   /**
    * Remove a property. Does nothing if it doesn't exist.
    */
   public Object removeProperty(String strPropertyName) {
      //// 1. Get the old value.
      Object oldVal = mapProperties.get(strPropertyName);

      //// 2. Return it.
      if (oldVal != null) {
         setPropertyRegression(true, strPropertyName, null);
      }
      return (oldVal);
   } // of method

   //===========================================================================

   /**
    * Get the list associated with this property.
    * Creates the list lazily if necessary.
    *
    * @param strPropertyName      is the property whose list we want.
    * @param flagOpAllowNewSchema specifies whether the op we are doing allows
    *                             creation of new schema (true) or not (false).
    */
   private LinkedList getList(String strPropertyName, 
                              boolean flagOpAllowNewSchema) {
      //// 1. Get the schema for this property.
      ////    Ensure that it is a list.
      ////    Create indexed schema lazily if it does not exist.
      PropertySchema schema = doPropertyCheck(strPropertyName, true);
      if (schema == null) {
         //// 1.1. If we only allow specified schema, then exception.
         if (flagSpecifiedOnly == true) {
            throw new RuntimeException(
                             "Specified property not registered in schema - " +
                             strPropertyName);
         }

         //// 1.2. If reading, then no new schema. Otherwise, allow new schema.
         if (flagOpAllowNewSchema == true) {
            schema = new PropertySchema(strPropertyName, PROPERTY_INDEXED);
            addSchema(schema);
         }
         else {
            return (null);
         }
      }


      //// 2. Retrieve the list.
      LinkedList list = (LinkedList) mapProperties.get(strPropertyName);
      if (list == null) {
         list = new LinkedList();
         mapProperties.put(strPropertyName, list);
      }

      return (list);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get all of an indexed property.
    */
   public List getIndexedProperty(String strPropertyName) {
      //// 1. Retrieve the list.
      return (getList(strPropertyName, false));
   } // of method


   /**
    * Get an indexed property at the specified index.
    *
    * @throws IndexOutOfBoundsException if out of bounds.
    * @return The property value, or null if it doesn't exist (or if its value
    *         is null). Remember that you get a reference to the stored value. 
    */
   public Object getIndexedProperty(String strPropertyName, int index) {
      //// 1. Retrieve the item in the list.
      return (getList(strPropertyName, false).get(index));
   } // of method


   /**
    * Set a value in the specified indexed property.
    *
    * @throws IndexOutOfBoundsException if out of bounds.
    */
   public void 
   setIndexedProperty(String strPropertyName, int index, Object newVal) {
      getList(strPropertyName, true).set(index, newVal);
   } // of method


   /**
    * Add a value to the back of the specified indexed property.
    * <P>
    * If {@link #setSpecifiedOnly(boolean)} is set to false (which it is by
    * default), then an indexed property schema will be created. 
    */
   public void addIndexedProperty(String strPropertyName, Object newVal) {
      getList(strPropertyName, true).add(newVal);
   } // of method


   /**
    * Remove a value from the specified indexed property.
    *
    * @throws IndexOutOfBoundsException if out of bounds.
    */
   public Object removeIndexedProperty(String strPropertyName, int index) {
      return (getList(strPropertyName, false).remove(index));
   } // of method


   /**
    * Remove an indexed property entirely.
    */
   public List removeIndexedProperty(String strPropertyName) {
      //// 1. Retrieve the list.
      List list = getList(strPropertyName, false);

      //// 2. Remove it.
      mapProperties.remove(strPropertyName);

      //// 3. Return.
      return (list);
   } // of method


   /**
    * Clear out all of the values from the specified indexed property.
    */
   public void clearIndexedProperty(String strPropertyName) {
      List list = getList(strPropertyName, false);
      if (list != null) {
         list.clear();
      }
   } // of method

   //===   PROPERTY METHODS   ==================================================
   //===========================================================================





   //===========================================================================
   //===   PROPERTY LISTENER METHODS   =========================================

   /**
    * Add a listener on a bound property.
    * Why Javasoft didn't call it addBoundPropertiesListener() is beyond me...
    */
   public void addPropertyChangeListener(PropertyChangeListener l) {
      evtlstnrs.addPropertyChangeListener(l);
   } // of method


   /**
    * Add a listener on a bound property.
    */
   public void addPropertyChangeListener(String str, PropertyChangeListener l) {
      evtlstnrs.addPropertyChangeListener(str, l);
   } // of method


   /**
    * Remove a listener on a bound property.
    */
   public void removePropertyChangeListener(PropertyChangeListener l) {
      evtlstnrs.removePropertyChangeListener(l);
   } // of method


   /**
    * Remove a listener on a bound property.
    */
   public void 
   removePropertyChangeListener(String str, PropertyChangeListener l) {
      evtlstnrs.removePropertyChangeListener(str, l);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a listener on a constrained property.
    * Why Javasoft didn't call it addConstrainedPropertiesListener() is 
    * beyond me...
    */
   public void addVetoableChangeListener(VetoableChangeListener l) {
      evtlstnrs.addVetoableChangeListener(l);
   } // of method


   /**
    * Add a listener on a constrained property.
    */
   public void addVetoableChangeListener(String str, VetoableChangeListener l) {
      evtlstnrs.addVetoableChangeListener(str, l);
   } // of method


   /**
    * Remove a listener on a constrained property.
    */
   public void removeVetoableChangeListener(VetoableChangeListener l) {
      evtlstnrs.removeVetoableChangeListener(l);
   } // of method


   /**
    * Remove a listener on a constrained property.
    */
   public void 
   removeVetoableChangeListener(String str, VetoableChangeListener l) {
      evtlstnrs.removeVetoableChangeListener(str, l);
   } // of method

   //===   PROPERTY LISTENER METHODS   =========================================
   //===========================================================================






   //===========================================================================
   //===   INPUT / OUTPUT METHODS   ============================================

   public void load(Reader rdr) 
       throws IOException {

       BufferedReader brdr    = new BufferedReader(rdr);
       String         strLine = null;
       String         strKey;
       String         strVal;

       //// 1. For each line...
       while ((strLine = brdr.readLine()) != null) {
           //// 1.1. Ignore lines starting with '#'
           if (strLine.startsWith("#") == true) {
               continue;
           }

           //// 1.2. Parse lines for '=', cutting whitespace
           int index = strLine.indexOf('=');
           if (index <= 0) {
               throw new IOException("Error parsing line in properties file: " 
                                                           + strLine);
           }
           strKey = strLine.substring(0, index).trim();
           strVal = strLine.substring(index + 1).trim();


// xxx
// add simple API and example to JavaDoc
// get rid of interface PropertyConstants
// need to handle indexed properties (lists) and normal properties
System.out.println("key: " + strKey);
System.out.println("val: " + strVal);

       }
   } // of method

   //-----------------------------------------------------------------

   public void store(Writer wtr)
       throws IOException {
   } // of method

   //===   INPUT / OUTPUT METHODS   ============================================
   //===========================================================================





   //===========================================================================
   //===   TOSTRING   ==========================================================

   /**
    * Print out schema and properties.
    */
   public String toString() {
      StringBuffer strbuf = new StringBuffer();
      Iterator     it;
      Object       key;

      //// 1. For each key, get the schema and property.
      it = mapSchema.keySet().iterator();
      while (it.hasNext()) {
         key = it.next();
         PropertySchema s = getSchema((String) key);
         strbuf.append(s + " [Value: " + mapProperties.get(key) + "]\n");
      }

      return (strbuf.toString());
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================





   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   //// For regression test purposes
   private static class RegressionPropertyChangeListener 
      implements PropertyChangeListener { 

      String str = "";

      public RegressionPropertyChangeListener() {
      } // of constructor

      public RegressionPropertyChangeListener(String newstr) {
         this.str = newstr;
      } // of constructor

      public void propertyChange(PropertyChangeEvent evt) {
         System.out.println(str + "Property Change");
         System.out.println("   " + evt.getPropertyName());
         System.out.println("   " + evt.getOldValue());
         System.out.println("   " + evt.getNewValue());
      } // of method
   } // of inner class

   //-----------------------------------------------------------------

   //// For regression test purposes
   private static class RegressionVetoableChangeListener 
      implements VetoableChangeListener { 

      String str = "";

      public RegressionVetoableChangeListener() {
      } // of constructor

      public RegressionVetoableChangeListener(String newstr) {
         this.str = newstr;
      } // of constructor

      public void vetoableChange(PropertyChangeEvent evt) {
         System.out.println(str + "Vetoable Change");
         System.out.println("   " + evt.getPropertyName());
         System.out.println("   " + evt.getOldValue());
         System.out.println("   " + evt.getNewValue());
      } // of method
   } // of inner class

   //-----------------------------------------------------------------

   //// Test how schema are added by default.
   private static void runTestAAA() throws Exception {
      FlexProperties props = new FlexProperties();

      //// 1. Should be simple property by default.
      props.setProperty("Name", "Myname");
      System.out.println(props);

      //// 2. Change it to bound.
      props.setDefaultPropertyType(PROPERTY_BOUND);
      props.setProperty("Occupation", "Myoccupation");
      System.out.println(props);

      //// 3. Change it to constrained.
      props.setDefaultPropertyType(PROPERTY_CONSTRAINED);
      props.setProperty("Address", "Myaddress");
      System.out.println(props);

      //// 4. Try out indexed.
      props.addIndexedProperty("names", "lucky");
      props.addIndexedProperty("names", "buffy");
      System.out.println(props);

      System.out.println("-----");

      //// 5. Try getting. No schema should be created.
      props.setDefaultPropertyType(PROPERTY_SIMPLE);
      props.getProperty("aaa");
      props.setDefaultPropertyType(PROPERTY_BOUND);
      props.getProperty("bbb");
      props.setDefaultPropertyType(PROPERTY_CONSTRAINED);
      props.getProperty("ccc");
      System.out.println(props);

      System.out.println("-----");

      //// 6. Try getting indexed. No schema should be created.
      props.getIndexedProperty("ddd");
      props.clearIndexedProperty("eee");
      props.removeIndexedProperty("eee");
      System.out.println(props);
   } // of method

   //-----------------------------------------------------------------

   //// Test out listening on specific properties.
   public static void runTestBBB() throws Exception {
      Object         src   = new Object();
      FlexProperties props = new FlexProperties(src);

      //// 1. Add some listeners.
      props.addPropertyChangeListener("dog_t", 
                              new RegressionPropertyChangeListener("dog"));
      props.addPropertyChangeListener("cat_t", 
                              new RegressionPropertyChangeListener("cat"));
      props.addPropertyChangeListener(
                              new RegressionPropertyChangeListener("all"));

      //// 2. Add schema
      PropertySchema s;
      s = new PropertySchema("dog_t");
      s.setConstrainedProperty();
      props.addSchema(s);

      s = new PropertySchema("cat_t");
      s.setConstrainedProperty();
      props.addSchema(s);

      //// 3. Add a property.
      props.setProperty("dog_t", "labrador");
      props.setProperty("cat_t", "meowth");
      System.out.println(props);
      System.out.println();
      System.out.println();

      //// 4. Try out enable / disable.
      props.disableNotify();
      props.setProperty("dog_t", "arcanine");
      props.setProperty("cat_t", "persian");
      System.out.println(props);

      props.enableNotify();
      props.disableNotify("dog_t");
      props.setProperty("dog_t", "dogval");
      props.setProperty("cat_t", "catval");
      System.out.println(props);
   } // of method

   //-----------------------------------------------------------------

   //// Testing out basic setting and getting
   public static void runTestCCC() throws Exception {
      Object         src   = new Object();
      FlexProperties props = new FlexProperties(src);

      //// Add listeners
      props.addPropertyChangeListener(new RegressionPropertyChangeListener());
      props.addVetoableChangeListener(new RegressionVetoableChangeListener());

      //// Add schema
      PropertySchema s = new PropertySchema("dog_t");
      s.setConstrainedProperty();
      props.addSchema(s);

      //// Add properties
      props.setProperty("dog_t", "labrador");
      props.setProperty("dog_t", "retriever");
      System.out.println(props);

      //// Add indexed properties
      props.addIndexedProperty("names", "lucky");
      props.addIndexedProperty("names", "buffy");
      System.out.println(props);
      System.out.println(props.getIndexedProperty("names"));
      props.setIndexedProperty("names", 1, "fido");
      System.out.println(props.getIndexedProperty("names"));
      System.out.println(props.getIndexedProperty("names", 3));
   } // of method

   //-----------------------------------------------------------------

   public static void runTestDDD() throws Exception {
      FlexProperties p = new FlexProperties();
      p.load(new FileReader("out.txt"));
   } // of method

   //===========================================================================

   public static void main(String[] argv) throws Exception {
       runTestAAA();
       runTestBBB();
       runTestCCC();
   } // of method

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
