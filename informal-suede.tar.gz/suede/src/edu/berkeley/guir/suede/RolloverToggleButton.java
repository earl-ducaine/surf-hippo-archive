package edu.berkeley.guir.suede;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RolloverToggleButton extends JToggleButton {
    private static final int SPACE = 16;
    
    private Color bg;
    private Color fg;
    private Color roll;
    private SelectedIcon selectedIcon;
    
    public RolloverToggleButton(String s, Color b, Color f, Color r) {
        super(s);
        bg =b;   fg = f;  roll = r;
        setVisible(true);   setOpaque(true);
        setBackground(bg);  setForeground(fg);
        setFocusPainted(false);
        setContentAreaFilled(true);
        setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, fg));
        addMouseListener(new RollListener());
        selectedIcon = new SelectedIcon(s, b, f, r);
        setSelectedIcon(selectedIcon);
    }
            
    public int setXHeight(int x, int h) {
        this.setBounds(x,0,getIdealWidth(), h);
        selectedIcon.setBounds(0,0,getIdealWidth(), h);
        return x+getIdealWidth();
    }
                
    public int getIdealWidth() { return getPreferredSize().width + SPACE;   }
            
    private class RollListener implements MouseListener {
        public void mouseClicked(MouseEvent e) {}
        public void mouseExited(MouseEvent e)  { setForeground(fg); }
        public void mouseEntered(MouseEvent e) { setForeground(roll); }
        public void mousePressed(MouseEvent e) {}
        public void mouseReleased(MouseEvent e){}
    }
    
    private class SelectedIcon extends ImageIcon{
        JLabel label;
        int width;  int height;
        Color bg;   Color fg;    Color roll;

        public SelectedIcon(String s, Color b, Color f, Color r) {
            label = new JLabel(s, CENTER);
            label.setVisible(true);
            label.setOpaque(true);
            label.setForeground(b);
            label.setBackground(r);
            bg = b;   fg = f;   roll = r;
        }
        
        public void setBounds(int x, int y, int w, int h) {
            width = w;  height = h;
            label.setBounds(0,0,w,h);
        }
        
        public void paintIcon(Component c, Graphics g, int x, int y) {  
            label.paint(g);
        }
        
        public int getIconHeight() { return height;}
        public int getIconWidth() { return width;}
   }
}
