//// See bottom of file for software license
package edu.berkeley.guir.lib.sql;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import edu.berkeley.guir.lib.collection.tuple.Tuple;

/**
 * Some common sql library methods.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version GUIRLib Jan 08 2004 JIH
 */
public class SqlLib {

    //==========================================================================
    //===   TUPLE   ============================================================

    /**
     * @param rset is the ResultSet from a query
     * @param strTupleType is the type of the Tuple to return, ie
     *                     the name of the main XML tag
     */
    public static List createListOfTuplesFromResultSet(ResultSet rset,
                                                       String    strTupleType) 
        throws SQLException {

        List listResults = new LinkedList();

        //// 0. Early exit if no results.
        if (rset == null) {
            return (listResults);
        }

        //// 1. Crunch the results into Tuples.
        ResultSetMetaData metadata = rset.getMetaData();
        int               numCols  = metadata.getColumnCount();
        String            strColName;
        String            strColType;
        Tuple             t;

        String            strVal;
        double            dVal;
        long              lVal;
        int               iVal;

        while (rset.next()) {
            t = new Tuple(strTupleType);
            for (int i = 1; i <= numCols; i++) {  // not a bug, SQL starts w/ 1
                strColName = metadata.getColumnName(i);
                strColType = metadata.getColumnTypeName(i);

                if ("VARCHAR".equals(strColType) || "CHAR".equals(strColType)) {
                    strVal = rset.getString(i);
                    t.setAttribute(strColName, strVal);
                }
                else if ("DOUBLE".equals(strColType)) {
                    dVal = rset.getDouble(i);
                    t.setAttribute(strColName, dVal);
                }
                else if ("FLOAT".equals(strColType)) {
                    dVal = rset.getFloat(i);
                    t.setAttribute(strColName, dVal);
                }
                else if ("LONG".equals(strColType)) {
                    lVal = rset.getLong(i);
                    t.setAttribute(strColName, lVal);
                }
                else if ("INTEGER".equals(strColType)) {
                    iVal = rset.getInt(i);
                    t.setAttribute(strColName, iVal);
                }
                else {
                    throw new IllegalArgumentException(
                       "Don't know how to handle type: " + strColType);
                }
            }
            listResults.add(t);
        }
        return (listResults);
    } // of method

    //===   TUPLE   ============================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
