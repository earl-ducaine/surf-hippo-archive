//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*; 
import edu.berkeley.guir.lib.properties.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.util.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.awt.image.*;
import java.util.List;

/**
 * This is a sample implementation class for GraphicalObjects. 
 *
 * <H2>Introduction</H2>
 * A GraphicalObject is anything with some state, dynamically redefinable
 * views on that state, and dynamically redefinable behaviors to manipulate
 * that state. See {@link GraphicalObject} for background information on
 * Model-View-Controller, Interpreters, and Views.
 *
 * <P>
 * This implementation of GraphicalObject separates all of the interaction
 * portions into an {@link InteractionHandler}, all of the view portions into a
 * {@link ViewHandler}, and all of the watch portions into a {@link
 * WatchableImpl}. Although there is a lot of indirection, we feel that this
 * significantly improves flexibility and generality.
 *
 * <H2>Getting Started</H2>
 * To start using this base implementation, you must override at least one 
 * method, the {@link #defaultRender(SatinGraphics)} method. This method simply
 * tells the system how to draw the GraphicalObject under normal conditions.
 * Note that you cannot override {@link #render(SatinGraphics)}, as it is a
 * final method in this implementation.
 * <UL>
 *    <LI>{@link #render(SatinGraphics)}
 *    <LI>{@link #defaultRender(SatinGraphics)}
 * </UL>
 * 
 * <P>
 * You must also call {@link #setBoundingPoints2D(int, Shape)} before the 
 * GraphicalObject is rendered. This method just sets the bounds of the 
 * GraphicalObject, so the system knows where the GraphicalObject is and 
 * what is looks like.
 * <UL>
 *   <LI>{@link #setBoundingPoints2D(int, Shape)},
 * </UL>
 *
 * <P>
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 * GraphicalObject going.
 *
 * <H2>The Coordinate Systems</H2>
 * Here is a good point to describe the different coordinate systems.
 * Generally speaking, we support access to three different coordinate systems,
 * termed <EM>local</EM>, <EM>relative</EM>, and <EM>absolute</EM>,
 * <UL>
 *    <LI><B>Local coordinates</B> are in the current GraphicalObject's 
 *        coordinate space. Here, the top-left corner is always (0,0), and
 *        there are no transforms applied anywhere. This coordinate system is
 *        represented by the constants {@link SatinConstants#COORD_LOCAL}.
 *    <LI><B>Relative coordinates</B> are in the coordinate space of the
 *        the parent of the current GraphicalObject. This coordinate system is 
 *        represented by the constants {@link SatinConstants#COORD_REL}.
 *    <LI><B>Absolute coordinates</B> are screen coordinates, that is what you
 *        actually see on the screen. This coordinate system is represented by 
 *        the constants {@link SatinConstants#COORD_ABS}.
 * </UL>
 *
 * <P>
 * It is important to know what coordinate system you are in at all times. In
 * general, <B>this will likely be the most common bug you encounter</B>. I
 * wish there was a way to simplify this, but there seems to be times when 
 * you need easy access to the various coordinate systems. 
 * <A HREF="mailto:denim-dev@cs.berkeley.edu">Let us know</A> if you have 
 * any better ideas.
 *
 * <P>
 * There are a host of utilities that convert from one coordinate system to
 * another, in {@link GraphicalObjectLib}. Here's a quick overview:
 * <UL>
 *    <LI>{@link GraphicalObjectLib#toLocalCoordinates(GraphicalObject,
 *        GraphicalObject)} moves the first GraphicalObject to the coordinate
 *        space of the other GraphicalObject, but keeping it in the same
 *        absolute coordinates. In other words, you change the coordinate
 *        system but it still appears in the same place.
 *    <LI>{@link GraphicalObjectLib#toLocalCoordinates(GraphicalObject,
 *        Point2D, GraphicalObject)} and 
 *        {@link GraphicalObjectLib#toLocalCoordinates(GraphicalObject,
 *        Point2D, GraphicalObject, Point2D)} convert points from one coordinate
 *        space to another.
 *    <LI>{@link GraphicalObjectLib#localToAbsolute(GraphicalObject, Point2D)}
 *        and {@link GraphicalObjectLib#localToAbsolute(GraphicalObject, 
 *        Point2D, Point2D)} moves a point in some GraphicalObject's local
 *        coordinates to absolute coordinates.
 *    <LI>{@link GraphicalObjectLib#absoluteToLocal(GraphicalObject, Point2D)}
 *        and {@link GraphicalObjectLib#absoluteToLocal(GraphicalObject, 
 *        Point2D, Point2D)} do the opposite, moving from absolute to local
 *        coordinates.
 * </UL>
 * 
 * <H2>Interaction and Views</H2>
 * You should also look at these three following methods, as these define the 
 * behavior of the GraphicalObject when strokes are drawn on it. Currently,
 * these are the only events we support, but we'll see what happens later on.
 * <UL>
 *   <LI>{@link #handleNewStroke(NewStrokeEvent)}
 *   <LI>{@link #handleUpdateStroke(UpdateStrokeEvent)}
 *   <LI>{@link #handleSingleStroke(SingleStrokeEvent)}
 * </UL>
 * 
 * <P>
 * For a more in-depth description of what happens behind the scenes, check out
 * {@link GraphicalObject#onNewStroke(NewStrokeEvent)}. This event model is a
 * key aspect to understanding how the system works.
 *
 * <P>
 * If you've skimmed over the docs, you probably noticed the methods 
 * {@link #setGestureInterpreter(Interpreter)}, 
 * {@link #setInkInterpreter(Interpreter)}, and {@link #setView(View)}. 
 * Basically, these methods let you plug-in new Interpreters and Views.
 * You may want to look over the interface for {@link Interpreter} and 
 * {@link View} before proceeding.
 *
 * <P>
 * The <B>Gesture Interpreter</B> lets you try to process strokes as 
 * gestures, such as cut and copy. The <B>Ink Interpreter</B> lets you 
 * preprocess strokes as ink, such as straightening it up. Again, check out
 * {@link GraphicalObject#onNewStroke(NewStrokeEvent)} for a diagram showing
 * exactly when these Interpreters are used.
 *
 * <P>
 * <B>Views</B> let you specify how this GraphicalObject is displayed.
 * If you recall from earlier, there are two different rendering methods,
 * {@link #render(SatinGraphics)} and {@link #defaultRender(SatinGraphics)}.
 * Note that the <CODE>defaultRender()</CODE> method is not part of 
 * GraphicalObject, but part of this implementation. The reason for this is 
 * that in this implementation, <CODE>render()</CODE> simply delegates the
 * rendering to the current View. By default, the current View just calls
 * <CODE>defaultRender()</CODE>. Thus the reason for two different rendering 
 * methods.
 *
 * <P>
 * So what if you want to have more than one {@link Interpreter} or 
 * {@link View}? This is where {@link MultiInterpreter}s and {@link MultiView}s
 * come in.
 * {@link MultiInterpreter} is a special kind of Interpreter that contains
 * multiple Interpreters. The MultiInterpreter simply decides in what order
 * the Interpreters are called and how to combine their results. A
 * {@link MultiView} does the same thing for Views. An example of a
 * MultiView is the {@link SemanticZoomMultiViewImpl}, which lets you
 * change how GraphicalObjects appear at different zoom levels.
 *
 * <H2>Notifications</H2>
 * Notifications are another aspect of the system. Notifications differ from
 * events in that events are <EM>user-generated</EM>, whereas notifications are
 * <EM>system-generated</EM>. Events can be considered to be input messages 
 * from the user, while notifications are messages from one part of the system
 * to another, in order to keep it consistent.
 *
 * <P>
 * One special kind of notification is the <EM>damage</EM> notification, used 
 * to force the current GraphicalObject to be repainted. There are a host of 
 * damage methods, with the primary differences being <EM>when</EM> the 
 * repainting occurs and <EM>what area</EM> is to be repainted. For
 * example, calling {@link #damage(int)} with the 
 * {@link SatinConstants#DAMAGE_NOW} constant forces the GraphicalObject to be 
 * repainted immediately, while calling {@link #damage(int, Rectangle2D)} with 
 * the {@link SatinConstants#DAMAGE_LATER} constant repaints the specified
 * rectangle at a later time, when it is more convenient for the system. 
 * In most cases, the damage call is made for you automatically.
 *
 * <P>
 * The more general mechanism for notifications is implemented in two methods,
 * {@link #notifyWatchersUpdate(Object)} and 
 * {@link #notifyWatchersUpdate(String, Object, Object)}. Check out 
 * {@link SatinConstants} for some constants that define the existing types of
 * messages in Satin. Again, in most cases, notifications are automatically 
 * sent for you, but there may be cases in your own subclasses that you want to
 * send out additional messages.
 *
 * <P>
 * The notification and damage mechanisms can be disabled, via the
 * {@link #disableNotify()} and {@link #disableDamage()} methods.
 * They can also be re-enabled via the {@link #enableNotify()} and 
 * {@link #enableDamage()} methods. The methods {@link #hasNotifyEnabled()} and
 * {@link #hasDamageEnabled()} can be used to check the current status. 
 * The general notification mechanism and damage mechanism are independent of 
 * one another. Disabling one has no effect on the other.
 *
 * <P>
 * Please note that the enable/disable mechanism works like a counting 
 * semaphore. Every time you call a <CODE>disable</CODE> method, the disabled 
 * value is incremented by one. Every time you call a <CODE>enable</CODE> 
 * method, the disabled value is decremented by one. The mechanism is enabled 
 * if and only if the value is 0. 
 * 
 * <H2>Other Methods Needed for Correctness</H2>
 * There are two methods you should override for correctness, 
 * {@link #toString()}, and {@link #clone()} and {@link #deepClone()}. The 
 * system will still work (for the most part) if you don't override these, 
 * but it won't be 100% correct.
 *
 * <P>
 * The {@link #toString()} method is used to get debugging statements. The 
 * default implementation of toString() provides a great deal of debugging 
 * information about known state, but needs some help to print out debugging
 * information about state internal to your own GraphicalObject. Just override
 * toString(), make the super call to toString() as the first thing you do, and
 * just append the information.
 *
 * <P>
 * The {@link #clone()} and {@link #deepClone()} methods are used for copying 
 * GraphicalObjects. If you don't implement these methods correctly, then you
 * can't do copying-and-pasting.
 * 
 * <P>
 * Lastly, there is method that you <EM>may</EM> have to override for 
 * correctness. GraphicalObject defines 
 * {@link #minDistance(int, double, double)} assuming that you want the minimum 
 * distance from the specified point to any point on your GraphicalObject, 
 * handling open polygons and points inside the Polygon correctly. This will 
 * probably be right for nearly every GraphicalObject.
 * <UL>
 *    <LI>{@link #minDistance(int,double,double)}
 * </UL>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Oct 06 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.1.0, Feb 26 2001, JL
 *               * Changed return type of getRelativeLayer() from String to int
 *               * Changed return type of getAbsoluteLayer() from String to
 *                 List of Integers
 *
 *             - SATIN-v2.1-2.0.0, Nov 12 2002, YL
 *               Enabled idle rendering
 *
 *             - SATIN-v2.1-2.0.0, Jan 27 2003, YL
 *               Added flag isRenderingFished to check the progress of render
 * 				 
 *             - SATIN-v2.1-2.0.0, FEb 28 2003, YL
 *               Built render cache in
 *             - SATIN-v2.1-2.0.0, Nov 18 2003, YL
 *               Added the propogation of cache invalidity
 * 
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 2.1.0, 11-18-2003
 */
public abstract class GraphicalObjectImpl
	implements GraphicalObject, 
				  Watchable,                   //// <- for Javadoc purposes
				  Shape,
				  StrokeListener {

	//===========================================================================
	//===   CONSTANTS   =========================================================

	static final long serialVersionUID = -6330140664442146288L;
   

	//===   CONSTANTS   =========================================================
	//===========================================================================


	//===========================================================================
	//===   PROPERTIES   ========================================================

	boolean shouldRenderSelectionHandles = true;
	
	//// Static class initializations.
	static {
		//// 0.1. Initialize global properties.


		//// 0.2. Initialize default properties.
		clprops.setDefaultProperty(STYLE_CLPROPERTY,new Style());
		clprops.setDefaultProperty(VIEW_CLPROPERTY, new DefaultView());
		clprops.setDefaultProperty(INKINTRP_CLPROPERTY,     
																  new DefaultInterpreterImpl());
		clprops.setDefaultProperty(GESTUREINTRP_CLPROPERTY, 
																  new DefaultInterpreterImpl());

		//// 1. Initialize class properties.

		// none to init

	} // of static init

	//-----------------------------------------------------------------

	/**
	 * Set graphical debugging mode.
	 */
	public static void setClassDebugProperty(boolean flag) {
		defaultFlagDebug = flag;
	} // of method

	public static boolean getClassDebugProperty() {
		return (defaultFlagDebug);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Convenience method to set a property.
	 */
	public final void setClassProperty(String strPropertyName, Object obj) {
		clprops.setClassProperty(this.getClass(), strPropertyName, obj);
	} // of method

	/**
	 * Convenience method to get a reference to the specified property.
	 */
	public final Object getClassProperty(String strPropertyName) {
		return (clprops.getClassProperty(this.getClass(), strPropertyName));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Convenience method for setting the view class property.
	 */
	public final void setClassPropertyView(View v) {
		setClassProperty(VIEW_CLPROPERTY, v);
	} // of method

	/**
	 * Convenience method for getting the view class property.
	 */
	public final View getClassPropertyView() {
		View v = (View) getClassProperty(VIEW_CLPROPERTY);
		return ( (View) v.clone() );
	} // of method

   
	//-----------------------------------------------------------------
	//-----------------------------------------------------------------

	public boolean isRenderFinished() {
		return this.isRenderFinished;
	}

	//-----------------------------------------------------------------   
   
	public GraphicalObjectRenderingCache getRenderCache() {
		return renderCache;
	}

	//-----------------------------------------------------------------   
   
	protected void updateCacheInternal(GraphicalObjectRenderingCache grc, AffineTransform refTransform, Style refStyle) {
	}

	//-----------------------------------------------------------------
	//-----------------------------------------------------------------
   
	/**
	 * Convenience method for setting the view class property.
	 */
	public final void setClassPropertyStyle(Style s) {
		setClassProperty(STYLE_CLPROPERTY, s);
	} // of method

	/**
	 * Convenience method for getting the view class property.
	 */
	public final Style getClassPropertyStyle() {
		Style s = (Style) getClassProperty(STYLE_CLPROPERTY);
		return ( (Style) s.clone() );
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Convenience method for setting the view class property.
	 */
	public final void setClassPropertyGestureInterpreter(Interpreter intrp) {
		setClassProperty(GESTUREINTRP_CLPROPERTY, intrp);
	} // of method

	/**
	 * Convenience method for getting the view class property.
	 */
	public final Interpreter getClassPropertyGestureInterpreter() {
		Interpreter i = (Interpreter) getClassProperty(GESTUREINTRP_CLPROPERTY);
		return ( (Interpreter) i.clone() );
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Convenience method for setting the view class property.
	 */
	public final void setClassPropertyInkInterpreter(Interpreter intrp) {
		setClassProperty(INKINTRP_CLPROPERTY, intrp);
	} // of method

	/**
	 * Convenience method for getting the view class property.
	 */
	public final Interpreter getClassPropertyInkInterpreter() {
		Interpreter i = (Interpreter) getClassProperty(INKINTRP_CLPROPERTY);
		return ( (Interpreter) i.clone() );
	} // of method

	//===   PROPERTIES   ========================================================
	//===========================================================================





	//===========================================================================
	//===   CLASS METHODS AND VARIABLES   =======================================

	private static boolean defaultFlagDebug;
	private static Style   debugStyle    = new Style(DEBUG_STYLE_FILE);
	private static Style   selectedStyle = new Style();

	//===   CLASS METHODS AND VARIABLES   =======================================
	//===========================================================================





	//===========================================================================
	//===   DELEGATION INNER CLASSES   ==========================================

	/** 
	 * Handles our interactions.
	 */
	final class InternalInteractionHandler extends InteractionHandler {
		public InternalInteractionHandler() {
			super(GraphicalObjectImpl.this);
		} // of default constructor
	} // of inner class

	//-----------------------------------------------------------------

	/**
	 * Handles our view.
	 */
	final class InternalViewHandler extends ViewHandler {
		public InternalViewHandler() {
			super(GraphicalObjectImpl.this);
		} // of default constructor
	} // of inner class
   
   
	/**
	 * INNER CLASS: Rendering Cache
	 */
   
	public class GraphicalObjectRenderingCache {
   
		// image cache for graphical object   
		private BufferedImage cacheImage = null;
   
		private AffineTransform cacheTransform = null; // for anti Blur purpose
      
		// the validity of the cache
		private boolean isCacheValid = false;
   
		private GraphicalObject attachedGob = null;
   
      
		public GraphicalObjectRenderingCache(GraphicalObject obj) {
			attachedGob = obj;
		}
      
		//===========================================================================
		//===   IMAGE CACHE ACCESS ==================================================
   
   
		public BufferedImage getCacheImage() {

			if(isCacheValid)
				return cacheImage;
			else
				return null;

		}

		//-----------------------------------------------------------------
      
		public BufferedImage getCacheHistory() {
			return cacheImage;
		}   

		//-----------------------------------------------------------------
   
		public AffineTransform getCacheTransform() {

			if(isCacheValid)
				return cacheTransform;
			else
				return null;

		}
   
		//-----------------------------------------------------------------

		/**
		 * restriced usage
		 */   

		public void setCacheTransform(AffineTransform tr) {
			cacheTransform = tr;
		}
   
        
		public void setCacheImage(BufferedImage ci) {
				 cacheImage = ci;
		}
   
   
		//-----------------------------------------------------------------
      
		/**
		 * Update image cache of this graphical object and set validity true
		 */
   
		public void updateCache(AffineTransform refTransform, Style refStyle) {
			
            ((GraphicalObjectImpl)attachedGob).updateCacheInternal(this, refTransform, refStyle);
         
			if(cacheImage!=null)
				isCacheValid = true;
		}
   
		//-----------------------------------------------------------------
         
		public boolean getCacheValidity() {
			return isCacheValid;
		}

		//-----------------------------------------------------------------
      
		public void setCacheInvalide() {
			isCacheValid = false;
			GraphicalObjectImpl gob = ((GraphicalObjectImpl)this.attachedGob.getParentGroup());
			if(gob!=null)
				gob.getRenderCache().setCacheInvalide();
		}      
	}

	//-----------------------------------------------------------------

	/**
	 * The default view, just calls {@link #defaultRender(SatinGraphics)}.
	 */
	final static class DefaultView extends DefaultViewImpl {
   	
		public DefaultView() {
			setName("DefaultView");
		} // of DefaultView
      

		public void render(SatinGraphics g) {
			//// Just wanted to avoid the cost of a method call
			((GraphicalObjectImpl) gob).defaultRender(g);
		}

		public Object clone() {
			return (clone(new DefaultView()));
		} // clone

		protected DefaultView clone(DefaultView v) {
			//// 1. Clone chain.
			super.clone(v);
			return (v);
		} // of method
	} // of inner class

	//===   DELEGATION INNER CLASSES   ==========================================
	//===========================================================================



	//===========================================================================
	//===   NONLOCAL VARIABLES   ================================================

	FlexProperties       properties = new FlexProperties(this);

	long                  id = -1;       // our local unique ID - if you still 
													//    have a val of -1 then something 
													//    is wrong
	GraphicalObjectGroup parent;        // parent of this Graphical object
													//    recalculated if flagDirty is true

	private GlobalID     globalID = null; // unique global id tuple for 
													  // distributed apps

	//// Delegation variables
	InteractionHandler   interaction;   // handles our interactions
	ViewHandler          view;          // handles our views
	WatchableImpl        watchable;     // allow others to observe us
													// notify others on changes

	//// View variables
	AffineTransform      tx;            // the transform to use for this object
	Polygon2D            xBoundingPts;  // bounding points after transformation
	boolean              flagDirty;     // do we have to update the bounds
													//    and render image?
	boolean              flagSelectable = true;

	//// Instance properties
	HashMap              mapProperties;

	//// Damage variables
	transient int        damageCount      = 0;
	boolean              flagClipToBounds = false;

	//// Resize mode
	private int          resizeMode;

	// is render finished   
	private boolean isRenderFinished = true;

	// latest render time
	private long latestRenderTime = 0; 
      
	// rendering cache
	private GraphicalObjectRenderingCache renderCache = null;
   
	//---------------------------------------------------------------------------

	//// Soft-state optimization variables for rendering
	Rectangle            rectClipBoundsAA = new Rectangle();
	Rectangle2D          rectClipBoundsBB = new Rectangle2D.Float();

	//===   NONLOCAL VARIABLES   ================================================
	//===========================================================================



	//===========================================================================
	//===   CONSTRUCTOR   =======================================================

	/**
	 * Default constructor, does nothing fancy.
	 */
	public GraphicalObjectImpl() {
		//// 0. Create a new watchable object and disable notifications.
		watchable = new WatchableImpl();

		disableNotify();
		//disableDamage();

		//// 1. Get a unique ID value.
		id = GraphicalObjectLib.getUniqueID();
		globalID = new GlobalID(id); //aussie shoudl be get local host

		//// 2. Initialize the view and interaction handlers.
		initialize();

		//// 3. Setup the style. Set the style directly in view, since
		////    we want to avoid notifications and repaints.
		view.setStyle(getClassPropertyStyle());

		//// 4. Setup the transforms. 
		tx       = new AffineTransform();

		//// 5. Set graphical debugging flag to value from properties file. 
		////    Set dirty flag to true, since it has to be drawn at least once.
		setDirty();

		//enableDamage();
		enableNotify();
      
		//// 6. Set the default resize mode to stretch
		resizeMode = SatinConstants.RESIZE_STRETCH;
      
		//// 7. build cache
		renderCache = new GraphicalObjectRenderingCache(this);
            
	} // of default constructor

	//-----------------------------------------------------------------

	/**
	 * Constructor for clone-chaining purposes.
	 * <P>
	 * Cloning in Java is broken, since there is no clone chaining (like there
	 * is constructor chaining). This means that the bottom-most subclass has to
	 * do all of the work, unless you have constructors like these to help out.
	 */
	public GraphicalObjectImpl(GraphicalObjectImpl gob) {
		gob.clone(this);
	} // of constructor

	//-----------------------------------------------------------------

	/**
	 * Initialize class-specific things, like the interaction handler and view
	 * handler.
	 */
	private void initialize() {
		//// 1. Create the Interaction Handler.
		InteractionHandler ihandler = createNewInteractionHandler();
		ihandler.setGestureInterpreter(getClassPropertyGestureInterpreter());
		ihandler.setInkInterpreter(getClassPropertyInkInterpreter());
		setInteractionHandler(ihandler);

		//// 2. Create the View Handler.
		ViewHandler vhandler = createNewViewHandler();
		vhandler.setView(new DefaultView());
		setViewHandler(vhandler);
	} // of initialize

	//===   CONSTRUCTOR   =======================================================
	//===========================================================================





	//===========================================================================
	//===   PROTECTED METHODS FOR ACCESSING HANDLERS   ==========================

	/**
	 * Override this method if you want to use your own InteractionHandler.
	 * This method is called automatically in the constructor.
	 */
	protected InteractionHandler createNewInteractionHandler() {
		return (new InternalInteractionHandler());
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Get the interaction handler, the object that we delegate most of our
	 * interactions to.
	 */
	protected InteractionHandler getInteractionHandler() {
		return (interaction);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Set the interaction handler.
	 */
	protected InteractionHandler 
	setInteractionHandler(InteractionHandler newHandler) {
		this.interaction = newHandler;
		newHandler.setAttachedGraphicalObject(this);
		return (newHandler);
	} // of method

	//=================================================================

	/**
	 * Override this method if you want to use your own ViewHandler.
	 * This method is called automatically in the constructor.
	 */
	protected ViewHandler createNewViewHandler() {
		return (new InternalViewHandler());
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Get the view handler, the object that we delegate most of our views to.
	 */
	protected ViewHandler getViewHandler() {
		return (view);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Set the view handler.
	 */
	protected ViewHandler setViewHandler(ViewHandler newHandler) {
		this.view = newHandler;
		newHandler.setAttachedGraphicalObject(this);
		return (newHandler);
	} // of method

	//===   PROTECTED METHODS FOR ACCESSING HANDLERS   ==========================
	//===========================================================================





	//===========================================================================
	//===   ID METHODS   ========================================================

	public long getUniqueID() {
		return (id);
	} // of method

	//-----------------------------------------------------------------

	public void setUniqueID(long newID) {
		this.id = newID;
      
		// Make sure that any GraphicalObjects created afterwards cannot have
		// the same unique ID as this GraphicalObject
        
        /*
		if (newID >= GraphicalObjectLib.uniqueID) {
			GraphicalObjectLib.uniqueID = newID + 1;
		}
        */
        /**
         * Yang Li: we also need to make sure that 
         * the objects created release this id
         * 
         * use time instead
         */
        
	} // of method

	//-----------------------------------------------------------------

	/**
	 * For historical reasons, SATIN objs have two id's. an unique integer
	 * ID used for single-machine applications, and a {hostname, id} pair
	 * used for distributed apps. Note that the id in the pair will equal
	 * the local id on the machine that created the object, but it will be
	 * different than the local id of that object on other machines.  
	 */
	public void setGlobalID(String host, int id) {
		globalID = new GlobalID(host, id);
	} // of method
   
	//-----------------------------------------------------------------

	/**
	 * For historical reasons, SATIN objs have two id's. an unique integer
	 * ID used for single-machine applications, and a {hostname, id} pair
	 * used for distributed apps. Note that the id in the pair will equal
	 * the local id on the machine that created the object, but it will be
	 * different than the local id of that object on other machines.  
	 */
	public void setGlobalID(GlobalID guid) {
		globalID = guid;  
	} // of method

	//-----------------------------------------------------------------

	/**
	 * For historical reasons, SATIN objs have two id's. an unique integer
	 * ID used for single-machine applications, and a {hostname, id} pair
	 * used for distributed apps. Note that the id in the pair will equal
	 * the local id on the machine that created the object, but it will be
	 * different than the local id of that object on other machines.  
	 */
	public GlobalID getGlobalID() {
		return globalID;
	} // of method

	//-----------------------------------------------------------------

	/**
	 * For historical reasons, SATIN objs have two id's. an unique integer
	 * ID used for single-machine applications, and a {hostname, id} pair
	 * used for distributed apps. Note that the id in the pair will equal
	 * the local id on the machine that created the object, but it will be
	 * different than the local id of that object on other machines.  
	 */
	public String getGlobalIDXML() {
		return globalID.toXML();
	} // of method

	//===   ID METHODS   ========================================================
	//===========================================================================





	//===========================================================================
	//===   PROPERTY METHODS   ==================================================
   
	public Iterator getPropertyNames() {
		return (properties.getPropertyNames());
	} // of method

	//-----------------------------------------------------------------

	public Object getProperty(String strPropertyName) {
		return (properties.getProperty(strPropertyName));
	} // of method

	public void setProperty(String strPropertyName, Object newVal) {
		properties.setProperty(strPropertyName, newVal);
	} // of method

	public Object removeProperty(String strPropertyName) {
		return (properties.removeProperty(strPropertyName));
	} // of method

	//-----------------------------------------------------------------

	public java.util.List getIndexedProperty(String strPropertyName) {
		return (properties.getIndexedProperty(strPropertyName));
	} // of method

	public Object getIndexedProperty(String strPropertyName, int index) {
		return (properties.getIndexedProperty(strPropertyName, index));
	} // of method

	public void
	setIndexedProperty(String strPropertyName, int index, Object newVal) {
		properties.setIndexedProperty(strPropertyName, index, newVal);
	} // of method

	public void addIndexedProperty(String strPropertyName, Object newVal) {
		properties.addIndexedProperty(strPropertyName, newVal);
	} // of method

	public Object removeIndexedProperty(String strPropertyName, int index) {
		return (properties.removeIndexedProperty(strPropertyName, index));
	} // of method

	public java.util.List removeIndexedProperty(String strPropertyName) {
		return (properties.removeIndexedProperty(strPropertyName));
	} // of method

	public void clearIndexedProperty(String strPropertyName) {
		properties.clearIndexedProperty(strPropertyName);
	} // of method

	//===   PROPERTY METHODS   ==================================================
	//===========================================================================





	//===========================================================================
	//===   VIEW METHODS   ======================================================

	public void setView(View v) {
		view.setView(v);
	} // of method

	//-----------------------------------------------------------------

	public View getView() {
		return (view.getView());
	} // of method

	//===   VIEW METHODS   ======================================================
	//===========================================================================






	//===========================================================================
	//===   INTERPRETER METHODS   ===============================================

	public Interpreter getGestureInterpreter() {
		return (interaction.getGestureInterpreter());
	} // of method

	//-----------------------------------------------------------------

	public Interpreter setGestureInterpreter(Interpreter intrp) {
		return (interaction.setGestureInterpreter(intrp));
	} // of method

	//-----------------------------------------------------------------

	public Interpreter getInkInterpreter() {
		return (interaction.getInkInterpreter());
	} // of method

	//-----------------------------------------------------------------

	public Interpreter setInkInterpreter(Interpreter intrp) {
		return (interaction.setInkInterpreter(intrp));
	} // of method

	//===   INTERPRETER METHODS   ===============================================
	//===========================================================================





	//===========================================================================
	//===   STYLE METHODS   =====================================================

	public Style setStyle(Style newStyle) {
		//// 0. Setup for notifications.
		Style oldStyle = view.getStyle();

		//// 1. Set the style.
		view.setStyle(newStyle);

		//// 2. Update watchers.
		setDirty();
		notifyWatchersUpdate(NOTIFY_STYLE, oldStyle, newStyle);
		damage(DAMAGE_LATER, this);

		return (newStyle);
	} // of setStyle

	//-----------------------------------------------------------------

	public Style getStyle() {
		return (view.getStyle());
	} // of method

	//-----------------------------------------------------------------

	public Style getStyleRef() {
		return (view.getStyleRef());
	} // of method

	//===   STYLE METHODS   =====================================================
	//===========================================================================





	//===========================================================================
	//===   RESIZE MODE METHODS   ===============================================

	public void setResizeMode(int resizeMode) {
		this.resizeMode = resizeMode;
	}
   
	//-----------------------------------------------------------------

	public int getResizeMode() {
		return resizeMode;
	}

	//===   RESIZE MODE METHODS   ===============================================
	//===========================================================================





	//===========================================================================
	//===   LAYER METHODS   =====================================================

	public int getRelativeLayer() {      
		if (parent != null) {
			return (parent.getRelativeLayer(this));
		}
		else {
			return -1;
		}
	} // of method
   

	//-----------------------------------------------------------------

	public void setRelativeLayer(int layer) {
		//// 0. Setup for notifications.
		List oldLayer = null;
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			oldLayer = getAbsoluteLayer();
		}

		//// 1. Set the layer this object is in.
		if (parent != null) {
			parent.setRelativeLayer(this, layer);
		}

		//// 2. Update watchers.
		setDirty();
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			notifyWatchersUpdate(NOTIFY_LAYER, oldLayer, getAbsoluteLayer());
			damage(DAMAGE_LATER, this);
		}
	} // of method

	//-----------------------------------------------------------------

	public java.util.List getAbsoluteLayer() {
		if (parent != null) {
			List layersList = parent.getAbsoluteLayer();
			int  layerSelf  = parent.getRelativeLayer(this);

			if (layersList == null) {
				layersList = new ArrayList();
			}
			layersList.add(new Integer(layerSelf));
         
			return layersList;
		}
		return null;
	} // of method
   
	//-----------------------------------------------------------------

	public void bringUpALayer() {
		//// 0. Setup for notifications.
		List oldLayer = null;
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			oldLayer = getAbsoluteLayer();
		}

		//// 1. Bring up.
		GraphicalObjectGroup gobs = getParentGroup();
		if (gobs != null) {
			parent.bringUpALayer(this);
		}

		//// 2. Update watchers.
		setDirty();
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			notifyWatchersUpdate(NOTIFY_LAYER, oldLayer, getAbsoluteLayer());
			damage(DAMAGE_LATER, this);
		}
	} // of method

	//-----------------------------------------------------------------

	public void bringUpNLayers(int n) {
		//// 0. Setup for notifications.
		List oldLayer = null;
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			oldLayer = getAbsoluteLayer();
		}

		//// 1. Bring up.
		GraphicalObjectGroup gobs = getParentGroup();
		if (gobs != null) {
			parent.bringUpNLayers(this, n);
		}

		//// 2. Update watchers.
		setDirty();
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			notifyWatchersUpdate(NOTIFY_LAYER, oldLayer, getAbsoluteLayer());
			damage(DAMAGE_LATER, this);
		}
	} // of method

	//-----------------------------------------------------------------

	public void bringDownALayer() {
		//// 0. Setup for notifications.
		List oldLayer = null;
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			oldLayer = getAbsoluteLayer();
		}

		//// 1. Bring down.
		GraphicalObjectGroup gobs = getParentGroup();
		if (gobs != null) {
			parent.bringDownALayer(this);
		}

		//// 2. Update watchers.
		setDirty();
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			notifyWatchersUpdate(NOTIFY_LAYER, oldLayer, getAbsoluteLayer());
			damage(DAMAGE_LATER, this);
		}
	} // of method

	//-----------------------------------------------------------------

	public void bringDownNLayers(int n) {
		//// 0. Setup for notifications.
		List oldLayer = null;
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			oldLayer = getAbsoluteLayer();
		}

		//// 1. Bring up.
		GraphicalObjectGroup gobs = getParentGroup();
		if (gobs != null) {
			parent.bringDownNLayers(this, n);
		}

		//// 2. Update watchers.
		setDirty();
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			notifyWatchersUpdate(NOTIFY_LAYER, oldLayer, getAbsoluteLayer());
			damage(DAMAGE_LATER, this);
		}
	} // of method

	//-----------------------------------------------------------------

	public void bringToTopLayer() {
		//// 0. Setup for notifications.
		List oldLayer = null;
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			oldLayer = getAbsoluteLayer();
		}

		//// 1. Bring to top.
		GraphicalObjectGroup gobs = getParentGroup();
		if (gobs != null) {
			parent.bringToTopLayer(this);
		}

		//// 2. Update watchers.
		setDirty();
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			notifyWatchersUpdate(NOTIFY_LAYER, oldLayer, getAbsoluteLayer());
			damage(DAMAGE_LATER, this);
		}
	} // of method

	//-----------------------------------------------------------------

	public void bringToBottomLayer() {
		//// 0. Setup for notifications.
		List oldLayer = null;
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			oldLayer = getAbsoluteLayer();
		}

		//// 1. Bring to bottom.
		GraphicalObjectGroup gobs = getParentGroup();
		if (gobs != null) {
			parent.bringToBottomLayer(this);
		}

		//// 2. Update watchers.
		setDirty();
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			notifyWatchersUpdate(NOTIFY_LAYER, oldLayer, getAbsoluteLayer());
			damage(DAMAGE_LATER, this);
		}
	} // of method

	//===   LAYER METHODS   =====================================================
	//===========================================================================





	//===========================================================================
	//===   INTERNAL STATE CONSISTENCY METHODS   ================================

	/**
	 * Call this method if this GraphicalObject's bounds have been changed.
	 * Normally, you will not use this method.
	 *
	 * @see #isDirty()
	 */
	protected void setDirty() {
		flagDirty    = true;
		xBoundingPts = null;
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Check if this GraphicalObject's bounds are dirty (ie the GraphicalObject
	 * has been moved or reshaped, etc) and should be recalculated.
	 * Normally, you will not have to use this method.
	 *
	 * @see #setDirty()
	 */
	protected boolean isDirty() {
//		  return (flagDirty || xBoundingPts == null);
//	XXX
return (true);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Update cached copies of our bounds.
	 */
	protected void updateBoundingPoints() {
		//// 1. See if we have a cached version already.
		if (isDirty() == true) {
			//// 2. Run the transform and recalculate the bounding points.
			xBoundingPts = getLocalBoundingPoints2DRef().transformCopy(
																		  getTransformRef());
			flagDirty    = false;
		}
	} // of method

	//===   INTERNAL STATE CONSISTENCY METHODS   ================================
	//===========================================================================





	//===========================================================================
	//===   INTERNAL OPTIMIZATION ACCESS METHODS   ==============================

	/**
	 * An internal version of setTransform() that does not try to update the
	 * normalizing transform. Used by the ViewHandler when mucking around with
	 * the normalizing transform, in order to prevent mutually recursive calls.
	 */
	protected void setTransformInternal(AffineTransform newTx) {
		//// 1. Set the transform.
		this.tx = newTx;

		//// 2. No real need to update watchers, since this is an internal
		////    method. Just update the region.
		setDirty();
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Set the reference to the bounding points.
	 */
	protected void setLocalBoundingPoints2DRef(Polygon2D poly) {
		view.setViewBoundingPoints2DRef(poly);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Get a reference of the local bounding points instead of a copy. 
	 * Internal method.
	 * <P>
	 * You can override this behavior to grab the bounding points from somewhere
	 * else instead of from the views if you want.
	 * <P>
	 * Because this method can be overridden, ViewHandler's method
	 * {@link ViewHandler#getViewBoundingPoints2DRef()} should not be called.
	 * Instead, this method should be used.
	 */
	protected Polygon2D getLocalBoundingPoints2DRef() {
		return (view.getViewBoundingPoints2DRef());
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Get a reference of the relative bounding points instead of a copy. 
	 * Internal method.
	 * <P>
	 * You can override this behavior to grab the bounding points from somewhere
	 * else instead of from the views if you want.
	 */
	protected Polygon2D getBoundingPoints2DRef() {
		updateBoundingPoints();
		if (hasClosedBoundingPoints()) {
			xBoundingPts.setClosed(true);
		}
		else {
			xBoundingPts.setClosed(false);
		}

		return (xBoundingPts);
	} // of method

	//===   INTERNAL OPTIMIZATION ACCESS METHODS   ==============================
	//===========================================================================





	//===========================================================================
	//===   TRANSFORMATION METHODS   ============================================

	public void applyTransform(AffineTransform newTx) {
		//// A. Acquire soft-state objects.
		Rectangle2D     oldBounds = null;
		Rectangle2D     newBounds = null;
		Point2D         ptOld     = null;
		Point2D         ptNew     = null;
		AffineTransform txOld     = null;
		AffineTransform txNew     = null;

		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			oldBounds = (Rectangle2D) poolRects.getObject();
			oldBounds = getBounds2D(COORD_ABS, null, oldBounds);
		}
		if (hasNotifyEnabled() == true) {
			txOld     = (AffineTransform) poolTx.getObject();
			txOld.setTransform(tx);
		}

		//// 1. Apply the transformation.
		tx.preConcatenate(newTx);

		//// 2. Send notifications.
		setDirty();
		if (hasDamageEnabled() == true || hasNotifyEnabled()) {
			newBounds = (Rectangle2D) poolRects.getObject();
			newBounds = getBounds2D(COORD_ABS, null, newBounds);
		}
		if (hasNotifyEnabled() == true) {
			ptOld = (Point2D) poolPoints.getObject();
			ptNew = (Point2D) poolPoints.getObject();
			ptOld.setLocation(oldBounds.getX(), oldBounds.getY());
			ptNew.setLocation(newBounds.getX(), newBounds.getY());
			txNew = (AffineTransform) poolTx.getObject();
			txNew.setTransform(tx);

			notifyWatchersUpdate(NOTIFY_TRANSFORM, txOld, txNew);
			notifyWatchersUpdate(NOTIFY_LOCATION,  ptOld, ptNew);
		}

		//// 3. Damage if necessary.
		////    DAMAGE_NOW required because of animation.
		if (hasDamageEnabled() == true) {
			damage(DAMAGE_NOW, oldBounds, newBounds);
		}

		//// B. Release soft-state objects.
		poolRects.releaseObject(oldBounds);
		poolRects.releaseObject(newBounds);
		poolTx.releaseObject(txOld);
		poolTx.releaseObject(txNew);
		poolPoints.releaseObject(ptOld);
		poolPoints.releaseObject(ptNew);
	} // of method

	//-----------------------------------------------------------------

	public void setTransform(AffineTransform newTx) {
		//// A. Acquire soft-state objects.
		Rectangle2D     oldBounds = null;
		Rectangle2D     newBounds = null;
		Point2D         ptOld     = null;
		Point2D         ptNew     = null;
		AffineTransform txOld     = null;
		AffineTransform txNew     = null;

		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			oldBounds = (Rectangle2D) poolRects.getObject();
			getBounds2D(COORD_ABS, null, oldBounds);
		}
		if (hasNotifyEnabled() == true) {
			txOld     = (AffineTransform) poolTx.getObject();
			txOld.setTransform(tx);
		}

		//// 1. Clear out the transform due to the bounds.
		view.clearNormalizingTransform();

		//// 2. Set the transform. New implementation does not create an
		////    extra transform.
		this.tx.setTransform(newTx);

		//// 3. Update watchers.
		setDirty();
		if (hasDamageEnabled() == true || hasNotifyEnabled()) {
			newBounds = (Rectangle2D) poolRects.getObject();
			newBounds = getBounds2D(COORD_ABS, null, newBounds);
		}
		if (hasNotifyEnabled() == true) {
			ptOld = (Point2D) poolPoints.getObject();
			ptNew = (Point2D) poolPoints.getObject();
			ptOld.setLocation(oldBounds.getX(), oldBounds.getY());
			ptNew.setLocation(newBounds.getX(), newBounds.getY());
			txNew = (AffineTransform) poolTx.getObject();
			txNew.setTransform(tx);

			notifyWatchersUpdate(NOTIFY_TRANSFORM, txOld, txNew);
			notifyWatchersUpdate(NOTIFY_LOCATION,  ptOld, ptNew);
		}

		//// 4. Damage if necessary.

		if (hasDamageEnabled() == true
                &&this.getSheet()!=null) {
      	
			if(this.getSheet().isIdleRenderingMode())
			{
				damage(DAMAGE_IDLE, oldBounds, newBounds);	
			}
			else
			{
				damage(DAMAGE_LATER, oldBounds, newBounds);
			}
         
		}


		//// B. Release soft-state objects.
		poolRects.releaseObject(oldBounds);
		poolRects.releaseObject(newBounds);
		poolTx.releaseObject(txOld);
		poolTx.releaseObject(txNew);
		poolPoints.releaseObject(ptOld);
		poolPoints.releaseObject(ptNew);

	} // of method

	//-----------------------------------------------------------------

	public AffineTransform getTransform(int cdsys) {
		return (getTransform(cdsys, null));
	} // of method

	//-----------------------------------------------------------------

	public AffineTransform getTransform(int cdsys, AffineTransform outTx) {
		if (outTx == null) {
			outTx = new AffineTransform();
		}

		switch (cdsys) {
			case COORD_LOCAL:
				outTx.setToIdentity();
				break;

			case COORD_REL:
				outTx.setTransform(tx);
				break;

			case COORD_ABS:
				outTx.setTransform(tx);
				GraphicalObject gob = this;

				//// 1. Use preConcatenate() for optimization purposes, since
				////    we don't want to make copies of transforms unnecessarily.
				////    Just be sure to evaluate from left-to-right.
				while ((gob = gob.getParentGroup()) != null) {
					outTx.preConcatenate(gob.getTransformRef());
				}

				break;

			default:
				throw new RuntimeException("Invalid coordinate system value");
		}

		return (outTx);
	} // of method

	//-----------------------------------------------------------------

	public AffineTransform getInverseTransform(int cdsys) {
		return (getInverseTransform(cdsys, null));
	} // of method

	//-----------------------------------------------------------------

	public AffineTransform getInverseTransform(int cdsys, 
			AffineTransform outTx) {

		//// 1. Allocate storage if necessary.
		if (outTx == null) {
			outTx = new AffineTransform();
		}

		//// 2. Get the transform and invert it.
		outTx = getTransform(cdsys, outTx);
		try {
			outTx.setTransform(outTx.createInverse());
		}
		catch (Exception e) {
			Debug.println("This should never really happen");
		}

		//// 3. Return the transform.
		return (outTx);
	} // of method

	//-----------------------------------------------------------------

	public AffineTransform getTransformRef() {
		return (tx);
	} // of method

	//===   TRANSFORMATION METHODS   ============================================
	//===========================================================================





	//===========================================================================
	//===   PARENTAL METHODS   ==================================================

	/**
	 * This method should not normally be used.
	 * Add a Graphical Object into a Graphical Object Group instead.
	 */
	public void setParentGroup(GraphicalObjectGroup newParent) {
		//// 1. Check if null. No need to repaint. Actually need this check, 
		////    because removing from a group causes a call to this, which
		////    can lead to infinite recursion.
		if (newParent == null) {
			parent = null;
			return;
		}

		//// 2. Check if newParent is really a new parent. 
		if (newParent == parent) {
			return;
		}

		//// 3. Remove ourself from the old parent.
		if (parent != null) {
			parent.remove(this);
		}

		//// 4. Update our reference to our new parent.
		parent = newParent;
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectGroup getParentGroup() {
		return (parent);
	} // of method

	//-----------------------------------------------------------------

	public Sheet getSheet() {
		if (parent != null) {
			return parent.getSheet();
		}
		else {
			return null;
		}
	} // of method

	//-----------------------------------------------------------------

	public void delete() {
		//// 1. Avast, ye matey! Keel-haul and delete me!
		notifyWatchersDelete();
	} // of method

	//-----------------------------------------------------------------
   
	public void initAfterAdd() {
	}

	//-----------------------------------------------------------------
   
	public void initAfterAddToSheet() {
	}

	//===   PARENTAL METHODS   ==================================================
	//===========================================================================





	//===========================================================================
	//===   MISCELLANEOUS Location METHODS   ====================================

	public float minDistance(int cdsys, double x, double y) {
		return (minDistance(cdsys, new Point2D.Float((float) x, (float) y)));
	} // of method

	//-----------------------------------------------------------------

	public float minDistance(int cdsys, Point2D pt) {
		Point2D ptTmp = (Point2D) poolPoints.getObject();
		float   dist;

		switch (cdsys) {
			case COORD_ABS:
				//// 1. Transform the point from absolute to local coordinates.
				GraphicalObjectLib.absoluteToLocal(this, pt, ptTmp);
				break;

			case COORD_REL:
				//// 1. Transform the point from relative to local coordinates.
				AffineTransform tx = getTransformRef();
				tx.transform(pt, ptTmp);
				break;

			case COORD_LOCAL:
				ptTmp.setLocation(pt);
				break;

			default:
				throw new RuntimeException("Invalid coordinate system value");
		}


		dist = minLocalDistance(ptTmp.getX(), ptTmp.getY());
		poolPoints.releaseObject(ptTmp);
		return (dist);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Assumes the specified point is in local coordinates.
	 * Override this method if needed.
	 */
	protected float minLocalDistance(double x, double y) {
		return (getLocalBoundingPoints2DRef().minDistance(x, y));
	} // of method

	//===   MISCELLANEOUS Location METHODS   ====================================
	//===========================================================================





	//===========================================================================
	//===   VIEW ACCESSOR METHODS   =============================================

	public Point2D getLocation2D(int cdsys) {
		return (getLocation2D(cdsys, null, null));
	} // of method

	//-----------------------------------------------------------------

	public Point2D getLocation2D(int cdsys, AffineTransform tx, Point2D pt) {
		//// Implementation Note:
		////    This code is duplicated at StickyGraphicalObject.java
		////    Changes to this code should be mirrored there.
		////    Yes I know that copying and pasting code is bad, but that's
		////    what you get when you don't have multiple inheritance.

		//// A. Acquire soft-state objects.
		Rectangle2D tmpRect = (Rectangle2D) poolRects.getObject();

		//// 1. Get an updated copy of the bounds (transformed).
		tmpRect = getBounds2D(cdsys, tx, tmpRect);

		//// 2. Create storage if none was specified.
		if (pt == null) {
			pt = new Point2D.Float();
		}

		//// 3. Transform.
		if (tx != null) {
			tx.transform(pt, pt);
		}

		//// 4. Update the point location and return it.
		pt.setLocation(tmpRect.getX(), tmpRect.getY());

		//// B. Release soft-state objects.
		poolRects.releaseObject(tmpRect);

		return (pt);
	} // of method

	//-----------------------------------------------------------------

	public Rectangle2D getBounds2D(int cdsys) {
		return (getBounds2D(cdsys, null, null));
	} // of method

	//-----------------------------------------------------------------

	public Rectangle2D getBounds2D(int cdsys, AffineTransform tx, 
											 Rectangle2D rect) {
		//// Implementation Note:
		////    This code is duplicated at StickyGraphicalObject.java
		////    Changes to this code should be mirrored there.
		////    Yes I know that copying and pasting code is bad, but that's
		////    what you get when you don't have multiple inheritance.

		//// A. Acquire soft-state objects.
		Polygon2D tmpPoly = (Polygon2D) poolPolys.getObject();

		//// 1. Get an updated copy of the bounding points (transformed).
		tmpPoly = getBoundingPoints2D(cdsys, tx, tmpPoly);

		//// 2. Create storage if none was specified.
		if (rect == null) {
			rect = new Rectangle2D.Float();
		}

		//// 3. Transform.
		if (tx != null) {
			tmpPoly.transform(tx);
		}

		//// 4. Update the rectangle and return it.
		rect.setRect(tmpPoly.getBounds2D());

		//// B. Release soft-state objects.
		poolPolys.releaseObject(tmpPoly);

		return (rect);
	} // of method

	//-----------------------------------------------------------------

	public Polygon2D getBoundingPoints2D(int cdsys) {
		return (getBoundingPoints2D(cdsys, null, null));
	} // of method

	//-----------------------------------------------------------------

	public Polygon2D getBoundingPoints2D(int cdsys, AffineTransform tx,
													 Polygon2D poly) {
		//// 1. Create storage if none was specified.
		if (poly == null) {
			poly = new Polygon2D();
		}

		//// 2. Get an updated copy of the bounding points (transformed).
		switch (cdsys) {
			case COORD_LOCAL:
				poly.setPoly(getLocalBoundingPoints2DRef());
				break;

			case COORD_REL:
				updateBoundingPoints();
				poly.setPoly(xBoundingPts);
				break;

			case COORD_ABS:
				AffineTransform txTmp = (AffineTransform) poolTx.getObject();
				getTransform(COORD_ABS, txTmp);
				poly.setPoly(getLocalBoundingPoints2DRef());
				poly.transform(txTmp);
				poolTx.releaseObject(txTmp);
				break;

			default:
				throw new RuntimeException("Invalid coordinate system value");
		}

		//// 2. Apply the transform.
		if (tx != null) {
			poly.transform(tx);
		}

		//// 3. Set closed or not.
		if (hasClosedBoundingPoints()) {
			poly.setClosed(true);
		}
		else {
			poly.setClosed(false);
		}

		//// 4. Return the polygon.
		return (poly);
	} // of method

	//-----------------------------------------------------------------

	public float getWidth2D(int cdsys) {
		//// A. Acquire soft-state objects.
		Rectangle2D tmpRect = (Rectangle2D) poolRects.getObject();

		//// 1. Get an updated copy of the bounds (transformed).
		tmpRect = getBounds2D(cdsys, tx, tmpRect);

		//// B. Release soft-state objects.
		poolRects.releaseObject(tmpRect);

		//// 2. Get the width.
		return ((float) tmpRect.getWidth());
	} // of method

	//----------------------------------------------------------

	public float getHeight2D(int cdsys) {
		//// A. Acquire soft-state objects.
		Rectangle2D tmpRect = (Rectangle2D) poolRects.getObject();

		//// 1. Get an updated copy of the bounds (transformed).
		tmpRect = getBounds2D(cdsys, tx, tmpRect);

		//// B. Release soft-state objects.
		poolRects.releaseObject(tmpRect);

		//// 2. Get the height.
		return ((float) tmpRect.getHeight());
	} // of method

	//----------------------------------------------------------

	public void setHasClosedBoundingPoints(boolean flag) {
		view.setHasClosedBoundingPoints(flag);
	} // of method

	//----------------------------------------------------------

	public boolean hasClosedBoundingPoints() {
		return (view.hasClosedBoundingPoints());
	} // of method

	//===   VIEW ACCESSOR METHODS   =============================================
	//===========================================================================





	//===========================================================================
	//===   VIEW MODIFIER METHODS   =============================================

	public boolean isSelectable() {
		return (flagSelectable);
	} // of method

	public void setSelectable(boolean flag) {
		flagSelectable = flag;
	} // of method

	//----------------------------------------------------------

	public void moveTo(int cdsys, double x, double y) {
		//// A. Acquire soft-state.
		AffineTransform tx = (AffineTransform) poolTx.getObject();
      
		//// 1. Do the move.
		switch (cdsys) {
			case COORD_LOCAL:
				//// A. Acquire soft-state.
				Point2D pt = (Point2D) poolPoints.getObject();

				getLocation2D(cdsys, null, pt);
				tx.setToTranslation(x - pt.getX(), y - pt.getY());
				applyTransform(tx);

				//// B. Release soft-state.
				poolPoints.releaseObject(pt);
				break;

			case COORD_REL:
			case COORD_ABS:

				////
				//// Here's the big picture of what this portion of moveTo() does.
				//// I'll explain it in terms of COORD_ABS.
				////
				//// A. Figure out what our transform should be when this method
				////    is done. This is easy, because we just take the existing
				////    transform, and set its translation to be the x and y
				////    parameters passed in. Let's call this [txAbs-self-new].
				////
				//// B. So, let's break it down. How is [txAbs-self-new] calculated?
				////    [txAbs-self-new] = [txAbs-parent] * [tx-rel-self] * [txNorm]
				////
				////       where [txAbs-parent] is absolute transform of parent
				////             [tx-rel-self]  is our own current transform
				////             [txNorm]       is a normalizing transform 
				////                            so that our bounds are at (0, 0)
				////
				////    We know [txAbs-parent] as well as [txNorm]. Thus 
				////    calculating [tx-rel-self] is just a matter of doing the
				////    correct inverse multiplies.
				////
				//// C. Once we have calculated [tx-rel-self], we just set our
				////    current transform to it, and we should now be in the right
				////    place.
				////

				//// 1. Get the current transform.
				getTransform(cdsys, tx);

				//// 2. Figure out the transform that will make our location
				////    be right.
				double[] matrix = new double[6];
				tx.getMatrix(matrix);

				//// 2.1. Set the translation to be the move-to destination.
				//// [0]m00 [2]m01 [4]m02
				//// [1]m10 [3]m11 [5]m12
				tx.setTransform(matrix[0], matrix[1], 
									 matrix[2], matrix[3], 
									 x,         y);

				//// 2.2. At this point, tx is what our absolute transform should 
				////      be. Do some inversions to calculate what our local 
				////      transform should now be.
				if (cdsys == COORD_ABS) {
					//// A. Acquire soft-state.
					AffineTransform txiParent = (AffineTransform) poolTx.getObject();

					getParentGroup().getInverseTransform(COORD_ABS, txiParent);
					tx.preConcatenate(txiParent);

					//// B. Release soft-state.
					poolTx.releaseObject(txiParent);
				}

				//// 2.3. Account for translation due to existing bounding points.
				Rectangle2D rect = getLocalBoundingPoints2DRef().getBounds2D();
				tx.translate(-rect.getX(), -rect.getY());


				//System.out.println("before: " + getLocation2D(COORD_ABS));
				//System.out.println("   " + getTransform(COORD_ABS));
				//System.out.println("   " + getLocalBoundingPoints2DRef().getBounds2D());
				setTransform(tx);
				//System.out.println("after:  " + getLocation2D(COORD_ABS));
				//System.out.println("   " + getTransform(COORD_ABS));
				//System.out.println("   " + getLocalBoundingPoints2DRef().getBounds2D());

				break;

			default:
				throw new RuntimeException("Invalid coordinate system value");
		}
      
		//// B. Release soft-state.
		poolTx.releaseObject(tx);
	} // of method
   
   
	/**
	 * rotate around the center of the object and then move to x,y
	 */
	public void moveTo(int cdsys, double x, double y, double theta) {
		//// 1. move so the center is at (0,0)
		moveTo(cdsys, -getBounds2D(cdsys).getWidth()/2, -getBounds2D(cdsys).getHeight()/2);
      
		//// 2. Rotate around the center of the object
		applyTransform(AffineTransform.getRotateInstance(theta));
      
		//// 3. Do the translation last
		moveTo(cdsys,x,y);

	}
   
	//----------------------------------------------------------

	public void moveTo(int cdsys, Point2D pt) {
		moveTo(cdsys, pt.getX(), pt.getY());
	} // of method

	//----------------------------------------------------------

	/**
	 * WARNING: I've had some problems using this method, I'm not sure
	 * it's working correctly. (Ethan)
	 */
	
	public void moveBy(int cdsys, double dx, double dy) {
		switch (cdsys) {
			case COORD_LOCAL:
				applyTransform(AffineTransform.getTranslateInstance(dx, dy));
				break;

			case COORD_REL:
			case COORD_ABS:
				//// A. Acquire soft-state objects.
				Point2D ptPos  = (Point2D) poolPoints.getObject();

				getLocation2D(cdsys, null, ptPos);
				ptPos.setLocation(ptPos.getX() + dx, ptPos.getY() + dy);
				moveTo(cdsys, ptPos.getX(), ptPos.getY());

				//// B. Release soft-state objects.
				poolPoints.releaseObject(ptPos);
				break;

			default:
				throw new RuntimeException("Invalid coordinate system value");
		}
	} // of method

	//----------------------------------------------------------

	public void moveBy(int cdsys, Point2D pt) {
		moveBy(cdsys, pt.getX(), pt.getY());
	} // of method

	//----------------------------------------------------------

	public void setBoundingPoints2D(int cdsys, Shape s) {
		//// A. Acquire soft-state objects.
		Rectangle2D oldBounds = null;
		Rectangle2D newBounds = null;
		Point2D     ptOld     = null;
		Point2D     ptNew     = null;

		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			oldBounds = (Rectangle2D) poolRects.getObject();
			oldBounds = getBounds2D(COORD_ABS, null, oldBounds);
		}
		if (hasNotifyEnabled() == true) {
			ptOld = (Point2D) poolPoints.getObject();
			ptOld.setLocation(oldBounds.getX(), oldBounds.getY());
		}

		//// 1. Setup the bounding points.
		Polygon2D p = new Polygon2D(s);
		switch (cdsys) {
			case COORD_ABS:
				p.transform(getInverseTransform(COORD_ABS));
				break;

			case COORD_REL:
				setTransform(new AffineTransform());
				break;

			case COORD_LOCAL:
				break;

			default:
				throw new RuntimeException("Invalid coordinate system value");
		}

		disableNotify();
		disableDamage();

		view.setViewBoundingPoints2D(p);
		this.xBoundingPts = null;

		enableDamage();
		enableNotify();
      
        this.getRenderCache().setCacheInvalide();
        
		//// 2. Notify our watchers.
		////    Since damage or notify must be enabled for the if statement
		////    to proceed, it is okay to get the absolute bounds since at least
		////    one of the two statements below will be called.
		setDirty();
		if (hasDamageEnabled() == true || hasNotifyEnabled() == true) {
			newBounds = (Rectangle2D) poolRects.getObject();
			newBounds = getBounds2D(COORD_ABS, null, newBounds);
			ptNew = (Point2D) poolPoints.getObject();
			ptNew.setLocation(newBounds.getX(), newBounds.getY());
			notifyWatchersUpdate(NOTIFY_BOUNDS,   oldBounds, newBounds);
			notifyWatchersUpdate(NOTIFY_LOCATION, ptOld,     ptNew);
		}

		//// 3. Notify damage.
		if (hasDamageEnabled() == true) {
			damage(DAMAGE_LATER, oldBounds, newBounds);
		}

		//// B. Release soft-state objects.
		poolRects.releaseObject(oldBounds);
		poolRects.releaseObject(newBounds);
		poolPoints.releaseObject(ptOld);
		poolPoints.releaseObject(ptNew);

	} // of method

	//===   VIEW MODIFIER METHODS   =============================================
	//===========================================================================





	//===========================================================================
	//===   DISPATCHING METHODS   ===============================================

	public void onNewStroke(NewStrokeEvent evt) {
		interaction.onNewStroke(evt);
	} // of method

	public void preProcessNewStroke(NewStrokeEvent evt) {
		interaction.preProcessNewStroke(evt);
	} // of method

	public void redispatchNewStroke(NewStrokeEvent evt) {
		interaction.redispatchNewStroke(evt);
	} // of method

	public void postProcessNewStroke(NewStrokeEvent evt) {
		interaction.postProcessNewStroke(evt);
	} // of method

	public void handleNewStroke(NewStrokeEvent evt) {
		interaction.handleNewStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void onUpdateStroke(UpdateStrokeEvent evt) {
		interaction.onUpdateStroke(evt);
	} // of method

	public void preProcessUpdateStroke(UpdateStrokeEvent evt) {
		interaction.preProcessUpdateStroke(evt);
	} // of method

	public void redispatchUpdateStroke(UpdateStrokeEvent evt) {
		interaction.redispatchUpdateStroke(evt);
	} // of method

	public void postProcessUpdateStroke(UpdateStrokeEvent evt) {
		interaction.postProcessUpdateStroke(evt);
	} // of method

	public void handleUpdateStroke(UpdateStrokeEvent evt) {
		interaction.handleUpdateStroke(evt);
	} // of method

	//-----------------------------------------------------------------

	public void onSingleStroke(SingleStrokeEvent evt) {
		interaction.onSingleStroke(evt);
	} // of method

	public void preProcessSingleStroke(SingleStrokeEvent evt) {
		interaction.preProcessSingleStroke(evt);
	} // of method

	public void redispatchSingleStroke(SingleStrokeEvent evt) {
		interaction.redispatchSingleStroke(evt);
	} // of method

	public void postProcessSingleStroke(SingleStrokeEvent evt) {
		interaction.postProcessSingleStroke(evt);
	} // of method

	public void handleSingleStroke(SingleStrokeEvent evt) {
		interaction.handleSingleStroke(evt);
	} // of method

	//===   DISPATCHING METHODS   ===============================================
	//===========================================================================





	//===========================================================================
	//===   GRAPHICAL OBJECT SHAPE METHODS   ====================================

	/**
	 * Internal method. Assumes pt is already in local coordinates.
	 * Override for specific Graphical Object behavior.
	 */
	protected boolean shapeContainsInternal(Point2D pt) {
		  return (getLocalBoundingPoints2DRef().contains(pt));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Internal method. Assumes s is already in local coordinates.
	 * Override for specific Graphical Object behavior.
	 */
	protected boolean shapeContainsInternal(Shape s) {
		return (GraphicalObjectLib.contains(this, s));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Internal method. Assumes s is already in local coordinates.
	 * Override for specific Graphical Object behavior.
	 */
	protected boolean shapeIntersectsInternal(Shape s) {
		return (GraphicalObjectLib.intersects(this, s));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * In most cases should not override this method.
	 * @see #shapeContainsInternal(Point2D) for overriding.
	 */
	public boolean shapeContains(GraphicalObject gob) {
		return (shapeContains(COORD_ABS, gob.getBoundingPoints2D(COORD_ABS)));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * In most cases should not override this method.
	 * @see #shapeContainsInternal(Point2D) for overriding.
	 */
	public boolean shapeContains(int cdsys, Point2D pt) {
		//// A. Acquire soft-state. 
		AffineTransform tx    = (AffineTransform) poolTx.getObject();
		Point2D         ptTmp = (Point2D)         poolPoints.getObject();

		//// 1. Get the appropriate coordinate transform to put us into
		////    local coordinates.
		switch (cdsys) {
			case COORD_ABS:
			case COORD_REL:
			case COORD_LOCAL:
				//// for all three cases
				getInverseTransform(cdsys, tx);
				break;
			default:
				throw new RuntimeException("Unknown coordinate system parameter");
		}

		//// 2. Now transform the point.
		ptTmp.setLocation(pt.getX(), pt.getY());
		tx.transform(ptTmp, ptTmp);

		//// 3. Delegate to our view handler.
		boolean flagReturn = shapeContainsInternal(ptTmp);

		//// B. Release soft-state.
		poolTx.releaseObject(tx);
		poolPoints.releaseObject(ptTmp);

		return (flagReturn);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * In most cases should not override this method.
	 * @see #shapeContainsInternal(Point2D) for overriding.
	 */
	public boolean shapeContains(int cdsys, double x, double y) {
		//// A. Acquire soft-state.
		Point2D pt = (Point2D) poolPoints.getObject();

		//// 1. Delegate.
		pt.setLocation(x, y);
		boolean flagReturn = shapeContains(cdsys, pt);

		//// B. Release soft-state.
		poolPoints.releaseObject(pt);

		return (flagReturn);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * In most cases should not override this method.
	 * @see #shapeContainsInternal(Shape) for overriding.
	 */
	public boolean shapeContains(int cdsys, Shape s) {
		//// A. Acquire soft-state.
		AffineTransform tx   = (AffineTransform) poolTx.getObject();
		Polygon2D       poly = (Polygon2D)       poolPolys.getObject();

		//// 1. Get the appropriate transform.
		switch (cdsys) {
			case COORD_ABS:
			case COORD_REL:
			case COORD_LOCAL:
				//// for all three cases
				getInverseTransform(cdsys, tx);
				break;
			default:
				throw new RuntimeException("Unknown coordinate system parameter");
		} 

		//// 2. Set the polygon.
		poly.setToPathIterator(s.getPathIterator(tx));

		//// 3. Now check if we contain the shape.
		boolean flagReturn = shapeContainsInternal(poly);

		//// B. Release soft-state.
		poolTx.releaseObject(tx);
		poolPolys.releaseObject(poly);

		return (flagReturn);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * In most cases should not override this method.
	 * @see #shapeIntersectsInternal(Shape) for overriding.
	 */
	public boolean shapeIntersects(GraphicalObject gob) {
		return (shapeIntersects(COORD_ABS, gob.getBoundingPoints2D(COORD_ABS)));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * In most cases should not override this method.
	 * @see #shapeIntersectsInternal(Shape) for overriding.
	 */
	public boolean shapeIntersects(int cdsys, Shape s) {
		//// A. Acquire soft-state.
		Rectangle2D     r1   = (Rectangle2D)     poolRects.getObject();
		AffineTransform tx   = (AffineTransform) poolTx.getObject();
		Polygon2D       poly = (Polygon2D)       poolPolys.getObject();

		//// 1. Get the appropriate transform.
		switch (cdsys) {
			case COORD_ABS:
			case COORD_REL:
			case COORD_LOCAL:
				//// for all three cases
				getInverseTransform(cdsys, tx);
				break;
			default:
				throw new RuntimeException("Unknown coordinate system parameter");
		} 

		//// 2. Set the polygon.
		poly.setToPathIterator(s.getPathIterator(tx));

		//// 3. Now check if we intersect the shape.
		boolean flagReturn = shapeIntersectsInternal(poly);
      
		//// B. Release soft-state.
		poolRects.releaseObject(r1);
		poolTx.releaseObject(tx);
		poolPolys.releaseObject(poly);

		return (flagReturn);
	} // of method

	//===   GRAPHICAL OBJECT SHAPE METHODS   ====================================
	//===========================================================================




	//===========================================================================
	//===   SHAPE METHODS   =====================================================

	/**
	 * See if this GraphicalObject contains the specified point.
	 * <P>
	 * Use {@link GraphicalObjectLib#toLocalCoordinates(GraphicalObject, 
	 * Point2D, GraphicalObject)} or 
	 * {@link GraphicalObjectLib#toLocalCoordinates(GraphicalObject, Point2D,
	 * GraphicalObject, Point2D)} to convert the point. Since you want the
	 * coordinates in relative coordinates (ie our parent's coordinates), 
	 * you would do something like:
	 * <CODE>
	 *    dst.contains(
	 *       GraphicalObjectLib.toLocalCoordinates(src, pt, dst.getParentGroup())
	 *    );
	 * </CODE>
	 *
	 * In most cases should not override this method.
	 * @see #shapeIntersectsInternal(Shape) for overriding.
	 *
	 * @param x is the x-coordinate of the point (relative coords).
	 * @param y is the y-coordinate of the point (relative coords).
	 */
	public boolean contains(double x, double y) {
		return (shapeContains(COORD_REL, x, y));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * See if this GraphicalObject contains the specified rectangle.
	 * <P>
	 * In most cases should not override this method.
	 * @see #shapeIntersectsInternal(Shape) for overriding.
	 *
	 * @see   #contains(double, double) for an example of converting coordinate
	 *        systems correctly.
	 * @param x is the top-left of the rectangle (in this GraphicalObject's
	 *          coordinate space, ie relative).
	 * @param y is the top-left of the rectangle (in this GraphicalObject's
	 *          coordinate space, ie relative).
	 * @param w is the width of the rectangle.
	 * @param h is the height of the rectangle.
	 */
	public boolean contains(double x, double y, double w, double h) {
		//// A. Acquire soft-state.
		Rectangle2D rect = (Rectangle2D) poolRects.getObject();

		//// 1. Check.
		rect.setRect(x, y, w, h);
		boolean flagReturn = shapeContains(COORD_REL, rect);

		//// B. Release soft-state.
		poolRects.releaseObject(rect);

		return (flagReturn);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * See if this GraphicalObject contains the specified point.
	 * <P>
	 * In most cases should not override this method.
	 * @see #shapeIntersectsInternal(Shape) for overriding.
	 *
	 * @see   #contains(double, double) for an example of converting coordinate
	 *        systems correctly.
	 * @param p is the point to check (in this GraphicalObject's
	 *          coordinate space, ie relative).
	 */
	public boolean contains(Point2D p) {
		return (shapeContains(COORD_REL, p));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * See if this GraphicalObject contains the specified rectangle.
	 * <P>
	 * In most cases should not override this method.
	 * @see #shapeIntersectsInternal(Shape) for overriding.
	 *
	 * @param r is the rectangle to check (in this GraphicalObject's
	 *          coordinate space, ie relative).
	 */
	public boolean contains(Rectangle2D r) {
		return (shapeContains(COORD_REL, r));
	} // of method

	//-----------------------------------------------------------------

	public Rectangle getBounds() {
		return (getBoundingPoints2DRef().getBounds());
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Get the relative bounds.
	 */
	public Rectangle2D getBounds2D() {
		return (getBoundingPoints2DRef().getBounds2D());
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Get the path iterator, relative coordinates.
	 * Supppose that if you wanted to get the absolute bounds path iterator, you
	 * could call getPathIterator(getAbsoluteTransform()).
	 * <P>
	 * In most cases should not override this method.
	 * @see #shapeIntersectsInternal(Shape) for overriding.
	 */
	public PathIterator getPathIterator(AffineTransform at) {
		return (getBoundingPoints2DRef().getPathIterator(at));
	} // of method

	//-----------------------------------------------------------------

	public PathIterator getPathIterator(AffineTransform at, double flatness) {
		return (getBoundingPoints2DRef().getPathIterator(at, flatness));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Check if the specified rectangle intersects this GraphicalObject
	 * (relative coordinates).
	 * <P>
	 * In most cases should not override this method.
	 * @see #shapeIntersectsInternal(Shape) for overriding.
	 *
	 * @see   #contains(double, double) for an example of converting coordinate
	 *        systems correctly.
	 */
	public boolean intersects(double x, double y, double w, double h) {
		//// A. Acquire soft-state.
		Rectangle2D rect = (Rectangle2D) poolRects.getObject();

		//// 1. Check.
		rect.setRect(x, y, w, h);
		boolean flagReturn = shapeIntersects(COORD_REL, rect);

		//// B. Release soft-state.
		poolRects.releaseObject(rect);

		return (flagReturn);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Check if the specified rectangle intersects this GraphicalObject
	 * (relative coordinates).
	 * <P>
	 * In most cases should not override this method.
	 * @see #shapeIntersectsInternal(Shape) for overriding.
	 */
	public boolean intersects(Rectangle2D r) {
		return (shapeIntersects(COORD_REL, r));
	} // of method

	//===   SHAPE METHODS   =====================================================
	//===========================================================================




	//===========================================================================
	//===   WATCHABLE INTERFACE   ===============================================

	public Watcher addWatcher(Watcher w) {
		return (watchable.addWatcher(w));
	} // of method

	public int countWatchers() {
		return (watchable.countWatchers());
	} // of method

	public Watcher removeWatcher(Watcher w) {
		return (watchable.removeWatcher(w));
	} // of method

	public void clearWatchers() {
		watchable.clearWatchers();
	} // of method

	public void enableNotify() {
		watchable.enableNotify();
	} // of method

	public void disableNotify() {
		watchable.disableNotify();
	} // of method

	public boolean hasNotifyEnabled() {
		return (watchable.hasNotifyEnabled());
	} // of method

	public void notifyWatchers() {
		watchable.notifyWatchers(this);
	} // of method

	public void notifyWatchers(Object arg) {
		watchable.notifyWatchers(this, arg);
	} // of method

	public void notifyWatchersUpdate(Object arg) {
		watchable.notifyWatchersUpdate(this, arg);
	} // of method

	public void notifyWatchersUpdate(String strProperty, 
			Object oldVal, Object newVal) {
		watchable.notifyWatchersUpdate(this, strProperty, oldVal, newVal);
	} // of method

	public void notifyWatchersDelete() {
		watchable.notifyWatchersDelete(this);
	} // of method

	//===   WATCHABLE INTERFACE   ===============================================
	//===========================================================================





	//===========================================================================
	//===   DISPLAY METHODS   ===================================================

	public void setVisible(boolean flag) {
		view.setVisible(flag);
	} // of method

	//-----------------------------------------------------------------

	public boolean isVisible() {
		return (view.isVisible());
	} // of method

	//-----------------------------------------------------------------

	public void disableDamage() {
		damageCount++;
	} // of method

	//-----------------------------------------------------------------

	public void enableDamage() {
		damageCount--;
		if (damageCount < 0) {
			throw new RuntimeException(
				"Error - unbalanced number of disable/enable damage calls made");
		}
	} // of method

	//-----------------------------------------------------------------

	public boolean hasDamageEnabled() {
		return (damageCount == 0);
	} // of method

	//-----------------------------------------------------------------

	public void setClipToBounds(boolean flag) {
		flagClipToBounds = flag;
	} // of method

	//-----------------------------------------------------------------

	public boolean isClippedToBounds() {
		return (flagClipToBounds);
	} // of method

	//===========================================================================

	public void damage(int sync) {
		damage(sync, this);
	} // of method

	//-----------------------------------------------------------------

	public void damage(int sync, GraphicalObject gob) {
		//// 0. Check if notify is enabled before doing anything.
		if (hasDamageEnabled() == false) {
			return;
		}

		//// 1. Just propogate the damage message.
		GraphicalObjectGroup p = getParentGroup();
		if (p != null) {
			p.damage(sync, gob);
		}
	} // of method

	//-----------------------------------------------------------------

	public void damage(int sync, Rectangle2D rect) {
		//// 0. Check if notify is enabled before doing anything.
		if (hasDamageEnabled() == false) {
			return;
		}

		//// 1. Just propogate the damage message.
		GraphicalObjectGroup p = getParentGroup();
		if (p != null) {
			p.damage(sync, rect);
		}
	} // of method

	//-----------------------------------------------------------------

	public void damage(int sync, Rectangle2D oldBounds, Rectangle2D newBounds) {
		//// 0. Check if notify is enabled before doing anything.
		if (hasDamageEnabled() == false) {
			return;
		}

		//// 1. Just propogate the damage message.
		Rectangle.union(oldBounds, newBounds, oldBounds);
		damage(sync, oldBounds);
	} // of method

	//===========================================================================

	//===========================================================================
   
	public long getLatestRenderTime() {
		return latestRenderTime;
	}

	//===========================================================================
   
	/**
	 * Don't override this method. Instead, add a View to the ViewHandler.
	 */
	public final void render(SatinGraphics g) {
		//// 0.1. Quick check if we are visible or not.
		////      Automatically deselect ourself if we are not visible.
		////      Also, don't render if we are not visible.
		if (isVisible() == false) { 
			if (cmdsubsys.isSelected(this)) {
				cmdsubsys.removeSelected(this);
			}
			return;
		}

		//// 0.2. Now check if we are in the clip region.
		////      If so, proceed. If not, then abort.
      
	      
		if (rectClipBoundsAA == null) {
			rectClipBoundsAA = new Rectangle();
		}
		if (rectClipBoundsBB == null) {
			rectClipBoundsBB = new Rectangle2D.Float();
		}
		rectClipBoundsAA = g.getClipBounds(rectClipBoundsAA);
		rectClipBoundsBB = getBounds2D(COORD_LOCAL, null, rectClipBoundsBB);
      
		//// 0.2.1. "Intersects" doesn't work if one of the rectangles has
		////        a width or height of 0, so make the rectangle a little wider
		if ((rectClipBoundsBB.getWidth() == 0) || 
			 (rectClipBoundsBB.getHeight() == 0)) {
			rectClipBoundsBB.setRect(rectClipBoundsBB.getX(),
											 rectClipBoundsBB.getY(),
											 rectClipBoundsBB.getWidth() + 1,
											 rectClipBoundsBB.getHeight() + 1);
		}
        
		if (rectClipBoundsAA.intersects(rectClipBoundsBB) == false) {
			// debug.println("not rendering " + getUniqueID());
			// debug.println("   g clip  " + rectClipBoundsAA);
			// debug.println("   lcl bds " + rectClipBoundsBB);
			return;
		}
         
		// debug.println("rendering " + getUniqueID());
		// debug.println("   g clip  " + rectClipBoundsAA);
		// debug.println("   lcl bds " + rectClipBoundsBB);

		//// 1.1. Set the clip before rendering, so we only draw in bounds.
		if (isClippedToBounds() == true) {
			g.clipRect((int) rectClipBoundsBB.getX(), 
						  (int) rectClipBoundsBB.getY(),
						  (int) rectClipBoundsBB.getWidth(), 
						  (int) rectClipBoundsBB.getHeight());
		}

		//// 1.2. Render normally.

		if(this.getSheet()!=null)
			latestRenderTime = this.getSheet().getRenderServer().getLatestRenderTimeStamp();               
      
		isRenderFinished = false;
      
		view.render(g);
      
		isRenderFinished = true;

		//// 1.3. Reset the clip.
		if (isClippedToBounds() == true) {
			g.setClip(rectClipBoundsAA.x,     rectClipBoundsAA.y, 
						 rectClipBoundsAA.width, rectClipBoundsAA.height);
		}

		//// 2. Debugging and selected.
		if (defaultFlagDebug == true || cmdsubsys.isSelected(this) == true) {
			Rectangle2D rect = getBounds2D(COORD_ABS);

			//// 2.1. Setup the coordinate system and debugging drawing style.
			g.ignoreTransforms();

			//// 2.2. Render the debugging info.
			////      If it is a stroke and not normalized, ignore.
			////      If not visible, ignore.
			////      This is a little broken, since parent classes shouldn't
			////      know about children classes.
			if (! (this instanceof TimedStroke && view.isNormalized() == false) &&
				  defaultFlagDebug == true) {
				g.pushStyle(debugStyle);
				renderDebug(g, rect);
				g.popStyle();
			}

            
			//// 2.3. Render selected info.
			if (shouldRenderSelectionHandles&&
					cmdsubsys.isSelected(this)
                    &&this.isVisible()
                    &&this.getSheet().shouldRenderSelections()) {
				g.pushStyle(selectedStyle);
/*            
                Iterator it = cmdsubsys.getSelected();
                GraphicalObject mygob = (GraphicalObject)it.next();
                System.err.println("selected " + mygob.getClass().toString() + " " + mygob.getUniqueID());
                System.err.println("this object " + this.getClass().toString() + "  " + this.getUniqueID());
                System.err.println("its parent " + this.getParentGroup().getClass().toString() + " " + this.getParentGroup().getUniqueID());
  */              
				renderSelected(g, rect);
				g.popStyle();
			}

			//// 2.4. Restore the coordinate system and debugging drawing style.
			g.dontIgnoreTransforms();
		}
	} // of method
	
	public void setShouldRenderSelectionHandles(boolean b) {
		shouldRenderSelectionHandles = b;
	}
   
	//-----------------------------------------------------------------

	/**
	 * The default method for rendering. This method is used by the DefaultView
	 * to render. Override this method in subclasses.
	 */
	protected abstract void defaultRender(SatinGraphics g);

	//-----------------------------------------------------------------

	/**
	 * Render the graphical debugging information. 
	 * <P>
	 * This method is called only if this Graphical Object's view is visible
	 * (see {@link #isVisible() and View#isVisible()}), and if it is not the 
	 * current stroke.
	 * <P>
	 * Default behavior is to render the absolute bounding box and absolute
	 * coordinates of the bounding box.
	 * <P>
	 * Override this method in a subclass to change how the debugging
	 * information is rendered on screen. When this method is called,
	 * {@link SatinGraphics#ignoreTransforms()} has already been called for you.
	 * After this method is done, {@link SatinGraphics#dontIgnoreTransforms()}
	 * will be called for you. In other words, you are in absolute coordinates
	 * for rendering.
	 *
	 * @param g    is the SatinGraphics context.
	 * @param rect is the bounding box (absolute coordinates).
	 */
	protected void renderDebug(SatinGraphics g, Rectangle2D rect) {
		//// 1. Draw the coordinates of the bounds.
		renderAllCoordBounds(g, rect);

		//// 2. Draw the bounding box.
		renderBoundingBox(g, rect);

		//// 3. Draw the height and width.
		// renderDimensions(g, rect);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Render how this Graphical Object is displayed when selected.
	 * <P>
	 * This method is called only if this Graphical Object's view is visible
	 * (see {@link #isVisible() and View#isVisible()}).
	 * <P>
	 * Default behavior is to render selection handles around the bounding box.
	 * <P>
	 * Override this method in a subclass to change how the debugging
	 * information is rendered on screen. When this method is called,
	 * {@link SatinGraphics#ignoreTransforms()} has already been called for you.
	 * After this method is done, {@link SatinGraphics#dontIgnoreTransforms()}
	 * will be called for you. In other words, you are in absolute coordinates
	 * for rendering.
	 *
	 * @param g    is the SatinGraphics context.
	 * @param rect is the bounding box (absolute coordinates).
	 */
	protected void renderSelected(SatinGraphics g, Rectangle2D rect) {
		//// 1. Get the size of the handle.
		int size = 6;

		//// 2. Calculate the location of the handles.
		int x = (int) rect.getX();
		int y = (int) rect.getY();
		int w = (int) rect.getWidth();
		int h = (int) rect.getHeight();

		int x1 = x;               // top-left
		int y1 = y;
		int x2 = x + w/2;         // top-mid
		int y2 = y;
		int x3 = x + w;           // top-right
		int y3 = y;
		int x4 = x + w;           // mid-right
		int y4 = y + h/2;
		int x5 = x + w;           // bottom-right
		int y5 = y + h;
		int x6 = x + w/2;         // bottom-mid
		int y6 = y + h;
		int x7 = x;               // bottom-left
		int y7 = y + h;
		int x8 = x;               // mid-left
		int y8 = y + h/2;

		//// 3. Paint the handles.
		g.fillRect(x1 - size/2, y1 - size/2, size, size);
		g.fillRect(x2 - size/2, y2 - size/2, size, size);
		g.fillRect(x3 - size/2, y3 - size/2, size, size);
		g.fillRect(x4 - size/2, y4 - size/2, size, size);
		g.fillRect(x5 - size/2, y5 - size/2, size, size);
		g.fillRect(x6 - size/2, y6 - size/2, size, size);
		g.fillRect(x7 - size/2, y7 - size/2, size, size);
		g.fillRect(x8 - size/2, y8 - size/2, size, size);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Paint a selection handle centered at the specified coordinate.
	 *
	 * @param x is the x-coordinate to paint at.
	 * @param y is the y-coordinate to paint at.
	 */
	protected void renderSelectionHandle(SatinGraphics g, int x, int y) {
		//// 1. Get the size of the handle.
		int size = 6;

		//// 2. Fill it in.
		g.fillRect(x - size/2, y - size/2, size, size);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Draw one of those neat debugging coordinates!
	 */
	private void 
	renderBoxedNum(SatinGraphics g, Font font, int val, int x, int y, int pos) {
		String    str  = "" + val;
		Rectangle rect = GraphicsLib.calculateBoundingBox(str, font, x, y, pos);

		rect.x = x;
		rect.y = y;
		g.fillRect(rect, pos);
		g.drawString(str, x, y, pos);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Render the tiny boxes displaying the numerical coordinates of 
	 * the bounding box.
	 */
	protected void renderAllCoordBounds(SatinGraphics g, Rectangle2D bounds) {
		//// 1. Abbreviations for the coordinates.
		int x1 = (int) bounds.getX();                        // left
		int y1 = (int) bounds.getY();                        // top
		int x2 = (int) (bounds.getX() + bounds.getWidth());  // right
		int y2 = (int) (bounds.getY() + bounds.getHeight()); // bottom
		int w  = (int) bounds.getWidth();                    // width
		int h  = (int) bounds.getHeight();                   // height

		//// 2. Calling graphical debugging routines.
		renderBoxedNum(g, g.getFont(), x1, x1, y1 + (int) (0.25*h), 
				SatinGraphics.LEFT);
		renderBoxedNum(g, g.getFont(), y1, x1 + (int) (0.25*w), y1,         
				SatinGraphics.TOP);
		renderBoxedNum(g, g.getFont(), x2, x2, y1 + (int) (0.75*h), 
				SatinGraphics.RIGHT);
		renderBoxedNum(g, g.getFont(), y2, x1 + (int) (0.75*w), y2,         
				SatinGraphics.BOTTOM);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Render the bounding box around this GraphicalObject.
	 */
	protected void renderBoundingBox(SatinGraphics g, Rectangle2D bounds) {
		g.drawRect((int) bounds.getX(),     (int) bounds.getY(), 
					  (int) bounds.getWidth(), (int) bounds.getHeight());
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Render the height and width of this GraphicalObject.
	 */
	protected void renderDimensions(SatinGraphics g, Rectangle2D bounds) {

		//// 0. If the area is too small, just forget it.
		if (bounds.getWidth()  < 2*DEBUG_GRAPHICS_OFFSET ||
			 bounds.getHeight() < 2*DEBUG_GRAPHICS_OFFSET) {
			return;
		}

		//// 1. Figure out the (x,y) coordinates of the bounds.
		int x1 = (int) bounds.getX();                         // left
		int y1 = (int) bounds.getY();                         // top
		int x2 = (int) (bounds.getX() + bounds.getWidth());   // right
		int y2 = (int) (bounds.getY() + bounds.getHeight());  // bottom

		//// 2.1. Draw the height line.
		g.drawLine(x2 - DEBUG_GRAPHICS_OFFSET, y2 - 2*DEBUG_GRAPHICS_OFFSET, 
					  x2 - DEBUG_GRAPHICS_OFFSET, y1 + 2*DEBUG_GRAPHICS_OFFSET);

		//// 2.2. Draw the value of the height.
		renderBoxedNum(g, g.getFont(), (int) bounds.getHeight(), 
							x2 - DEBUG_GRAPHICS_OFFSET,
							y1 + (int) (0.3 * bounds.getHeight()), 
							SatinGraphics.CENTER);

		//// 3.1. Draw the width line.
		g.drawLine(x2 - 2*DEBUG_GRAPHICS_OFFSET, y2 - DEBUG_GRAPHICS_OFFSET, 
					  x1 + 2*DEBUG_GRAPHICS_OFFSET, y2 - DEBUG_GRAPHICS_OFFSET);

		//// 3.2. Draw the value of the width.
		renderBoxedNum(g, g.getFont(), (int) bounds.getWidth(), 
							x1 + (int) (0.3 * bounds.getWidth()),
							y2 - DEBUG_GRAPHICS_OFFSET, 
							SatinGraphics.CENTER);
	} // of method

	//===   DISPLAY METHODS   ===================================================
	//===========================================================================




	//===========================================================================
	//===   EQUALS   ============================================================

	/**
	 * Simply tests if the two IDs are the same or not. 
	 *
	 * @return true if the GraphicalObjects are the same, false otherwise.
	 */
	public boolean equals(Object obj) {
		if (obj instanceof GraphicalObject) {
			GraphicalObject gob = (GraphicalObject) obj;
			if (gob.getUniqueID() == getUniqueID()) {
				return (true);
			}
		}
		return (false);
	} // of equals

	//===   EQUALS   ============================================================
	//===========================================================================
   
	//===========================================================================
	//===   CLONE   =============================================================

	/**
	 * My clone sleeps alone...
	 */
	public Object clone() {
		//// 1. You should never see this error.
		throw new RuntimeException("The method clone() in class " + 
				this.getClass() + " has not been correctly overridden yet...");
	} // of clone

	//-----------------------------------------------------------------

	/**
	 * Clone all of the state in the current GraphicalObject into the passed
	 * GraphicalObject. This is necessary for clone chaining.
	 * Does not set the parent, though, as that doesn't quite make sense.
	 *
	 * @param  gobClone is a GraphicalObject that will get the same
	 *                  GraphicalObject state as the current Graphical Object.
	 * @return a reference to gobClone.
	 */
	protected GraphicalObjectImpl clone(GraphicalObjectImpl gobClone) {
		gobClone.parent       = null;
		gobClone.tx           = (AffineTransform) this.tx.clone();
		gobClone.flagDirty    = true;

		 //// 1. Clone the view handler. No need to clone the interaction handler,
		////    since it is initialized correctly in the constructor.
		gobClone.setViewHandler((ViewHandler) view.clone());

		return (gobClone);
	} // of clone

	//-----------------------------------------------------------------

	/**
	 * If you do not override this method, it calls clone() by default.
	 */
	public Object deepClone() {
		return (this.clone());
	} // of deepClone

	//-----------------------------------------------------------------

	protected GraphicalObjectImpl deepClone(GraphicalObjectImpl gobClone) {
		return (clone(gobClone));
	} // of deepClone

	//===   CLONE   =============================================================
	//===========================================================================





	//===========================================================================
	//===   TOSTRING   ==========================================================

	public String getPresentationName() {
		StringBuffer strbuf = new StringBuffer(BAR);

		//// 1. Clip the class name.
		String strClass = this.getClass().toString();
		int    index    = strClass.lastIndexOf('.');
		if (index >= 0) {
			strClass = strClass.substring(index + 1);
		}

		//// 2. Make the presentation name.
		String strPres = "   " + strClass + " ID: " + this.getUniqueID() + "   ";

		//// 3. Stick it into the right place in the string buffer.
		strbuf.replace(3, strPres.length() + 3, strPres);

		return (strbuf.toString());
	} // of method

	//-----------------------------------------------------------------

	public final String toString() {
		//// A. Allocate soft-state.
		StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

		//// 1. Append the header.
		strbuf.append(BAR + getPresentationName());

		//// 2. Append the data.
		strbuf.append(toDebugString());

		//// 3. Append the footer.
		strbuf.append("\n" + getPresentationName() + BAR);

		//// B. Release soft-state.
		String str = strbuf.toString();
		poolStrbuf.releaseObject(strbuf);

		return (str);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Some debugging info. The general rule used for all toStrings() in SATIN
	 * is to use "\n" for newlines, and not to have a terminating newline.
	 * Override this method in subclasses.
	 * <P>
	 * <B>Do not call method toString() in any implementation of 
	 * toDebugString()</B>. Method toString() calls toDebugString().
	 */
	public String toDebugString() {
		//// A. Allocate soft-state.
		StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

		//// 1. Append Graphical Object data.
		strbuf.append("ParentID:       ");
		GraphicalObjectGroup parent = getParentGroup();
		if (parent == null) {
			strbuf.append("No parent");
		}
		else {
			strbuf.append(parent.getUniqueID());
		}
      
		strbuf.append("\nRel Layer:      " + getRelativeLayer());
		strbuf.append("\nAbs Layer:      " + getAbsoluteLayer());
		strbuf.append("\nLocation:       " + 
				 StringLib.toString(getLocation2D(COORD_REL)));
		strbuf.append("\nTransform:      " + getTransformRef());
		strbuf.append("\nClosedBdingPts: " + hasClosedBoundingPoints());
		strbuf.append("\nLocalBounds:    " + 
				 StringLib.toString(getBounds2D(COORD_LOCAL)));
		strbuf.append("\nLocalBdingPts:  " + 
				 StringLib.toString(getBoundingPoints2D(COORD_LOCAL)));
		strbuf.append("\nBounds:         " + 
				 StringLib.toString(getBounds2D(COORD_REL)));
		strbuf.append("\nBdingPts:       " + 
				 StringLib.toString(getBoundingPoints2D(COORD_REL)));
		strbuf.append("\nAbsBounds:      " + 
				 StringLib.toString(getBounds2D(COORD_ABS)));
		strbuf.append("\nAbsBdingPts:    " + 
				 StringLib.toString(getBoundingPoints2D(COORD_ABS)));
		strbuf.append("\nWatched by:     " + watchable.toString());
		strbuf.append("\nStyle:\n"         +
				 StringLib.indent(getStyleRef().toString(), 3));

		strbuf.append("\nInkInterpreter:\n" + 
				 StringLib.indent(getInkInterpreter().toString(), 3));
      
		strbuf.append("\nGestureInterpreter:\n" + 
			  StringLib.indent(getGestureInterpreter().toString(), 3));

		strbuf.append("\nView:\n" + StringLib.indent(getView().toString(), 3));

		//// B. Release soft-state.
		String str = strbuf.toString();
		poolStrbuf.releaseObject(strbuf);

		return (str);
	} // of toString

	//===   TOSTRING   ==========================================================
	//===========================================================================
   
	//----------------------------------------
   
	/**
	 * clear all references hold by this object (In the namespace of this class)
	 */
   
	public void deepClear() {
		tx = null;
		xBoundingPts = null;
		renderCache = null;
		rectClipBoundsAA = null;
		rectClipBoundsBB = null;
	}

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User 
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
