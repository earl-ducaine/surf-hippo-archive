//// See bottom of file for software license
package edu.berkeley.guir.lib.collection;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Map libraries.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Nov 20 2003 JIH
 */
public class MapLib {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    public static final String DEFAULT_COMMENT   = "# ";
    public static final char   DEFAULT_DELIMITER = '=';

    //===   CONSTANTS   ========================================================
    //==========================================================================



    //==========================================================================
    //===   MAP UTILITY METHODS   ==============================================

    /**
     * Invert the map so that the values are keys.
     * Assumes that values are unique, otherwise non-deterministic.
     * For example:
     * <PRE>
     *    a=alice               alice=a
     *    b=bob           to    bob  =b
     *    c=carol               carol=c
     * </PRE>
     * Only does a snapshot, does not maintain state if either 
     * map is changed. For a more efficient implementation, see
     * Jakarta Collections package class DoubleOrderedMap, at
     * <A * HREF="http://jakarta.apache.org/commons/collections/api/org/apache/commons/collections/DoubleOrderedMap.html">http://jakarta.apache.org/commons/collections/api/org/apache/commons/collections/DoubleOrderedMap.html</A>
     */
    public static Map invert(Map mapToInvert) {
        Map      mapInverted = new HashMap();
        Iterator it          = mapToInvert.keySet().iterator();
        Object   key;
        Object   val;

        while (it.hasNext()) {
            key = it.next();
            val = mapToInvert.get(key);
            mapInverted.put(val, key);   // put in backwards, not a bug
        }
        return (mapInverted);
    } // of method

    //===   MAP UTILITY METHODS   ==============================================
    //==========================================================================



    //==========================================================================
    //===   MAP LOAD / SAVE METHODS   ==========================================

    /**
     * Load up a map from a String. Example:
     * <PRE>
     * # this is a comment
     * # blank lines also ignored
     * # ignores trailing spaces (b/c too error prone otherwise)
     * key1=val1
     * key2=val2
     * key3=val3
     * </PRE>
     * Creates a new map.
     */
    public static Map loadMap(String strText) {
        try {
            return (loadMap(strText, new HashMap()));
        }
        catch (Exception e) {
            e.printStackTrace();
            return (new HashMap());
        }
    } // of method

    /**
     * Loads into the specified map.
     */
    public static Map loadMap(String strText, Map m) {
        return (loadMap(strText, m, DEFAULT_COMMENT, DEFAULT_DELIMITER));
    } // of method

    /**
     *
     */
    public static Map loadMap(String strText, 
                              Map    m,
                              String strComment,
                              char   chDelimiter) {
        try {
            return (loadMap(new StringReader(strText), m, 
                            strComment, chDelimiter));
        }
        catch (Exception e) {
            e.printStackTrace();
            return (m);
        }
    } // of method

    //----------------------------------------------------------------

    public static Map loadMap(Reader rdr) throws IOException {
        return (loadMap(rdr, new HashMap()));
    } // of method

    public static Map loadMap(Reader rdr, Map m) throws IOException {
        return (loadMap(rdr, m, DEFAULT_COMMENT, DEFAULT_DELIMITER));
    } // of method

    /**
     * @param rdr           is the Reader to read from
     * @param m             is the Map to put the results into
     * @param strComment    is the String to use as a comment, if line starts
     *                      with it then ignore. For example, "# "
     * @param chDelimiter   is the delimiter to use, for example '=' or ' '
     */
    public static Map loadMap(Reader rdr, 
                              Map    m,
                              String strComment,
                              char   chDelimiter) throws IOException {
        BufferedReader brdr;

        //// 1. Use a buffered reader instead.
        if (rdr instanceof BufferedReader) {
            brdr = (BufferedReader) rdr;
        }
        else {
            brdr = new BufferedReader(rdr);
        }

        //// 2. Read line by line.
        String strLine;
        int    index;
        int    startindex;
        String strKey;
        String strVal;

        while ((strLine = brdr.readLine()) != null) {
            //// 2.1. Ignore comments and blank lines.
            if (strLine.startsWith(strComment) || strLine.length() <= 0) {
                continue;
            }

            //// 2.2. Try to parse the line.
            index      = strLine.indexOf(chDelimiter);
            startindex = index;
            if (index < 0) {
                continue;
            }
            else {
                int len = strLine.length();
                for (int i = index + 1; i < len; i++) {
                    if (strLine.charAt(i) == chDelimiter) {
                        continue;
                    }
                    index = i - 1;
                    break;
                }

                strKey = strLine.substring(0, startindex);
                strVal = strLine.substring(index + 1);
            }
            m.put(strKey, strVal);
        }

        //// 3. Return.
        return (m);
    } // of method

    //----------------------------------------------------------------

    public static Map loadMap(InputStream istream) throws IOException {
        return (loadMap(istream, new HashMap()));
    } // of method

    public static Map loadMap(InputStream istream, Map m) throws IOException {
        return (loadMap(istream, m, DEFAULT_COMMENT, DEFAULT_DELIMITER));
    } // of method

    public static Map loadMap(InputStream istream, 
                              Map         m,
                              String      strComment,
                              char        chDelimiter) throws IOException {
        return (loadMap(new InputStreamReader(istream), m,
                        strComment, chDelimiter));
    } // of method

    //----------------------------------------------------------------

    public static String saveMapAsString(Map m) {
        StringWriter wtr = new StringWriter();
        saveMapToWriter(m, wtr);
        return (wtr.toString());
    } // of method

    /**
     * @param keys is the keys to use in order.
     */
    public static String saveMapAsString(Map m, Object[] keys) {
        StringWriter wtr = new StringWriter();
        saveMapToWriter(m, wtr, keys);
        return (wtr.toString());
    } // of method

    //----------------------------------------------------------------

    public static void saveMapToWriter(Map m, Writer wtr) {
        Set      setKeys = m.keySet();
        Object[] keys    = setKeys.toArray();
        saveMapToWriter(m, wtr, keys);
    } // of method

    /**
     * @param keys is the keys to use in order.
     */
    public static void saveMapToWriter(Map m, Writer wtr, Object[] keys) {
        String strKey;
        String strVal;

        try {
            for (int i = 0; i < keys.length; i++) {
                strKey = "" + keys[i];
                strVal = "" + m.get(keys[i]);
                wtr.write(strKey);
                wtr.write("=");
                wtr.write(strVal);
                wtr.write("\n");
            }
            wtr.flush();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    } // of method

    //===   MAP LOAD / SAVE METHODS   ==========================================
    //==========================================================================



    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static Map getTestInstanceAAA() {
        Map mapTest = new HashMap();
        mapTest.put("a", "alice");
        mapTest.put("b", "bob");
        mapTest.put("c", "carol");
        return (mapTest);
    } // of method

    private static Map getTestInstanceBBB() {
        Map mapTest = new HashMap();
        mapTest.put("a", "alice");
        mapTest.put("b", "bob");
        mapTest.put("c", "carol");
        mapTest.put("z", "alice");
        return (mapTest);
    } // of method

    //----------------------------------------------------------------

    private static void runTestAAA() {
        Map mapTest = getTestInstanceAAA();
        System.out.println(mapTest);
        System.out.println(invert(mapTest));
    } // of main

    private static void runTestBBB() {
        Map    mapAA   = getTestInstanceBBB();
        Map    mapBB;
        String strMap  = saveMapAsString(mapAA);

        System.out.println("===mapAA");
        System.out.println(mapAA);
        System.out.println("===strMap");
        System.out.println(strMap);

        mapBB = loadMap(strMap);
        System.out.println("===mapBB");
        System.out.println(mapBB);

        System.out.println("===========================");

        strMap = saveMapAsString(mapAA, new String[] {"alice", "b", "", null});
        System.out.println("===strMap");
        System.out.println(strMap);

        mapBB = loadMap(strMap);
        System.out.println("===mapBB");
        System.out.println(mapBB);
    } // of main

    //----------------------------------------------------------------

    public static void main(String[] argv) {
        runTestBBB();
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
