//// See bottom of file for software license
package edu.berkeley.guir.lib.util.comparator;

import java.util.Comparator;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * A comparator for Date objects. 
 * Allows Strings or Date instances.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Dec 06 2002 JIH
 */
public class DateComparator
    implements Comparator {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    public static final DateFormat DEFAULT_DATEFORMAT = 
                                 new SimpleDateFormat("yyyy.MM.dd HH:mm:ss z");

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    DateFormat dformat = DEFAULT_DATEFORMAT;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Use the default DateFormat, ie
     * java.util.SimpleDateFormat("yyyy.MM.dd HH:mm:ss z");
     */
    public DateComparator() {
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Use the specified DateFormat.
     * Needed only if the objects passed to compare() are Strings that
     * are to be converted.
     */
    public DateComparator(DateFormat df) {
        dformat = df;
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   ACCESSOR METHODS   =================================================

    /**
     * Override this to return the desired DateFormat.
     */
    protected DateFormat getDateFormat() {
        return (dformat);
    } // of method

    //===   ACCESSOR METHODS   =================================================
    //==========================================================================




    //==========================================================================
    //===   COMPARATOR METHODS   ===============================================

    /**
     * @param objAA can be either a Date or a String in the right format.
     * @param objBB can be either a Date or a String in the right format.
     */
    public int compare(Object objAA, Object objBB) {
        Date dAA;
        Date dBB;

        //// 1.1. If they are Strings, then convert to Date.
        if (objAA instanceof String && objBB instanceof String) {
            try {
                dAA = getDateFormat().parse((String) objAA);
            }
            catch (Exception e) {
                ClassCastException newex = new ClassCastException(
                                             "Not a date format: " + objAA);
                throw newex;
            }

            try {
                dBB = getDateFormat().parse((String) objBB);
            }
            catch (Exception e) {
                ClassCastException newex = new ClassCastException(
                                             "Not a date format: " + objBB);
                throw newex;
            }
        }
        //// 1.2. If they are Dates, cast.
        else {
            dAA = (Date) objAA;
            dBB = (Date) objBB;
        }

        return (dAA.compareTo(dBB));
    } // of method

    //===   COMPARATOR METHODS   ===============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
