package edu.berkeley.guir.damask.view.nodes;

import java.awt.Color;
import java.awt.Point;
import java.awt.geom.Point2D;

import javax.swing.SwingConstants;

import edu.berkeley.guir.damask.Direction;
import edu.berkeley.guir.damask.command.SetInsetCommand;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.DamaskCanvas;
import edu.berkeley.guir.damask.view.visual.dialog.PageRegionView;
import edu.berkeley.guir.damask.view.visual.dialog.PageViewContents;
import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolo.util.PDimension;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * A border that resizes a page region view.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-05-2004 James Lin
 *                               Created PageRegionViewSizingBorder.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-05-2004
 */
public class PageRegionViewSizingBorder extends StickySizingBorder {
   private static final int OTHER_SIZE = 50;
   
   private PageRegionView changingRegionView;

   /**
    * Creates a sizing border with the specified locator.
    */
   public PageRegionViewSizingBorder(
      final PBoundsLocator aLocator,
      final PCamera constraintCamera) {
         
      super(aLocator, constraintCamera);
      setPaint(Color.LIGHT_GRAY);
      setStrokePaint(DamaskAppUtils.NO_COLOR);
   }


   /**
    * Adds a border to the given node that stick to the given camera.
    */
   public static void addPageRegionViewSizingBorderTo(
      PBoundsLocator locator,
      PCamera camera) {
         
      final PageRegionViewSizingBorder border =
         new PageRegionViewSizingBorder(locator, camera);
      locator.getNode().addChild(border);
      StickyTransformManager.setupStickyZ(border, camera, new Point(0, 0));
      border.relocateHandle();
   }

   
   // Overrides method in ancestor class.
   public void startHandleDrag(Point2D aLocalPoint, PInputEvent aEvent) {
      super.startHandleDrag(aLocalPoint, aEvent);
      changingRegionView = null;
   }

   
   // Overrides method in ancestor class.
   public void dragHandle(PDimension aLocalDimension, PInputEvent aEvent) {
      final PBoundsLocator l = (PBoundsLocator) getLocator();
      final PageRegionView n = (PageRegionView)l.getNode();
      final PageViewContents contents = (PageViewContents)n.getParent();

      final PageRegionView centerRegion =
         contents.getRegionView(Direction.CENTER);
      final PageRegionView northRegion =
         contents.getRegionView(Direction.NORTH);
      final PageRegionView southRegion =
         contents.getRegionView(Direction.SOUTH);
      final PageRegionView eastRegion = contents.getRegionView(Direction.EAST);
      final PageRegionView westRegion = contents.getRegionView(Direction.WEST);

      final PNode parent = getParent();
      if (parent != n && parent instanceof PCamera) {
         ((PCamera)parent).localToView(aLocalDimension);
      }

      localToGlobal(aLocalDimension);
      n.globalToLocal(aLocalDimension);
      
      final int dx = (int)aLocalDimension.getWidth();
      final int dy = (int)aLocalDimension.getHeight();
      
      final int locatorSide = l.getSide();
      
      if ((((n == westRegion) || (n == centerRegion) || (n == eastRegion)) &&
            (locatorSide == SwingConstants.SOUTH))
          || (n == southRegion)) {
         changingRegionView = southRegion;
         southRegion.setInset(Math.max(0, southRegion.getInset() - dy));
      }
      else if ((((n == westRegion) || (n == centerRegion) || (n == eastRegion)) &&
            (locatorSide == SwingConstants.NORTH))
          || (n == northRegion)) {
         changingRegionView = northRegion;
         northRegion.setInset(Math.max(0, northRegion.getInset() + dy));
      }
      else if (((n == westRegion) && (locatorSide == SwingConstants.EAST))
          || ((n == centerRegion) && (locatorSide == SwingConstants.WEST))) {
         changingRegionView = westRegion;
         westRegion.setInset(Math.max(0, westRegion.getInset() + dx));
      }
      else if (((n == eastRegion) && (locatorSide == SwingConstants.WEST))
            || ((n == centerRegion) && (locatorSide == SwingConstants.EAST))) {
        changingRegionView = eastRegion;
        eastRegion.setInset(Math.max(0, eastRegion.getInset() - dx));
      }
      
      if (changingRegionView != null) {
         // forces layoutChildren
         changingRegionView.getParent().signalBoundsChanged();
      }
   }


   // Overrides method in superclass.
   public void relocateHandle() {
      double nodeWidth = OTHER_SIZE;
      double nodeHeight = OTHER_SIZE;
      float cornerWidth = 0;
      float cornerHeight = 0;
      
      if (CORNER_SIZE*2 > nodeWidth + BORDER_SIZE*2) {
         cornerWidth = ((float)nodeWidth + BORDER_SIZE*2) / 2;
         nodeWidth = 0;
      }
      
      if (CORNER_SIZE*2 > nodeHeight + BORDER_SIZE*2) {
         cornerHeight = ((float)nodeHeight + BORDER_SIZE*2) / 2;
         nodeHeight = 0;
      }
      
      resizeHandle(nodeWidth,
                   nodeHeight,
                   cornerWidth,
                   cornerHeight,
                   BORDER_SIZE);
      
      final PBoundsLocator locator = (PBoundsLocator)getLocator();
      
      final PBounds b = getBoundsReference();
      final double width = b.getWidth();
      final double height = b.getHeight();
      final Point2D aPoint = locator.locatePoint(null);
      
      final PNode located = locator.getNode();
      final PNode parent = getParent();
      
      located.localToGlobal(aPoint);
      globalToLocal(aPoint);
      
      if (parent != located && parent instanceof PCamera) {
         ((PCamera)parent).viewToLocal(aPoint);
      }
      
      final double newCenterX = aPoint.getX();
      final double newCenterY = aPoint.getY();

      if (newCenterX != b.getCenterX() || newCenterY != b.getCenterY()) {
         switch (locator.getSide()) {
            case SwingConstants.NORTH :
               setBounds(
                  newCenterX - width/2,
                  newCenterY,
                  width,
                  height);
               break;

            case SwingConstants.SOUTH :
               setBounds(
                  newCenterX - width/2,
                  newCenterY - BORDER_SIZE,
                  width,
                  height);
               break;

            case SwingConstants.WEST :
               setBounds(
                  newCenterX,
                  newCenterY - height/2,
                  width,
                  height);
               break;

            case SwingConstants.EAST :
               setBounds(
                  newCenterX - BORDER_SIZE,
                  newCenterY - height/2,
                  width,
                  height);
               break;
         }
      }
   }

   // Overrides method in superclass. 
   public void endHandleDrag(Point2D localPt, PInputEvent event) {
      super.endHandleDrag(localPt, event);

      if (changingRegionView != null) {
         final DamaskCanvas canvas = ((DamaskCanvas) event.getComponent());
         canvas.getDocument().getCommandQueue().doCommand(
            canvas,
            new SetInsetCommand(
               (PageRegion) changingRegionView.getModel(),
               changingRegionView.getInset()));
      }
   }
}
