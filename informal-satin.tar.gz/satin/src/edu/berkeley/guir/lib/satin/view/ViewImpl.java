//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.util.StringLib;

/**
 * A sample implementation of View, designed to be subclassed.
 * Be sure to implement clone() correctly!
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 11 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public abstract class ViewImpl 
   implements View {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 4847550940120905079L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   protected GraphicalObject gob;  // GraphicalObject we are attached to
   protected Polygon2D       poly        = new Polygon2D(); // our bounds
   private   String          strName     = "unnamed";
   private   boolean         flagVisible = true;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public ViewImpl() {
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   public void setBoundingPoints2DRef(Polygon2D p) {
      this.poly = p;
      if(this.gob!=null)
          ((GraphicalObjectImpl)this.gob).getRenderCache().setCacheInvalide();
   } // of method

   //-----------------------------------------------------------------

   public GraphicalObject setAttachedGraphicalObject(GraphicalObject newGob) {
      this.gob = newGob;
      return (newGob);
   } // of method

   //-----------------------------------------------------------------

   public String setName(String strName) {
      this.strName = strName;
      return (strName);
   } // of method

   //-----------------------------------------------------------------

   public void setVisible(boolean flag) {
      flagVisible = flag;
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   public Polygon2D getBoundingPoints2DRef() {
      return (poly);
   } // of method

   //-----------------------------------------------------------------

   public GraphicalObject getAttachedGraphicalObject() {
      return (gob);
   } // of method

   //-----------------------------------------------------------------

   public String getName() {
      return (strName);
   } // of method

   //-----------------------------------------------------------------

   public boolean isVisible() {
      return (flagVisible && (getViewDisplayValue() > 0));
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      Polygon2D p = getBoundingPoints2DRef();

      //// 1. Append data.
      strbuf.append(  "View Name:           " + getName());
      strbuf.append("\nCurrent bounding box:" + 
            StringLib.toString(p.getBounds2D()));
      strbuf.append("\nCurrent bounds:      " + p);
      strbuf.append("\nflagVis:             " + flagVisible);
      strbuf.append("\nCurrent Display Val: ");
      if (getAttachedGraphicalObject() == null) {
         strbuf.append("Not attached");
      }
      else {
         strbuf.append(getViewDisplayValue());
      }

      strbuf.append("\nAttached GOb ID:     ");
      if (getAttachedGraphicalObject() == null) {
         strbuf.append("Not attached");
      }
      else {
         strbuf.append(getAttachedGraphicalObject().getUniqueID());
      }

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Deep clone. You must override this method. So there.
    */
   public abstract Object clone();

   //-----------------------------------------------------------------

   /**
    * Make the passed view the same as us. For clone chaining purposes.
    */
   protected ViewImpl clone(ViewImpl v) {
      v.setAttachedGraphicalObject(this.getAttachedGraphicalObject());
      v.setVisible(this.isVisible());
      v.setBoundingPoints2DRef((Polygon2D) 
                                     this.getBoundingPoints2DRef().clone());
      return (v);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
