//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import java.awt.*;
import java.awt.geom.*;
import java.io.Serializable;
import java.util.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.satin.view.*;

/**
 * A GraphicalObject is anything with some state, dynamically redefinable 
 * views on that state, and dynamically redefinable behaviors to manipulate
 * that state.
 *
 * <P>
 * The idea behind a GraphicalObject is to separate an object into the Model, 
 * View, Controller pattern (MVC). The Model is the underlying data structures,
 * the Controllers handle the input, and the Views handle the output. A Model
 * can have multiple Controllers and Views.
 *
 * <P>
 * In the standard MVC, the Model is the center of the triad, with Views and 
 * Controllers attached to it. What we are investigating with SATIN is to see
 * if we can make the View more central, dynamically changing the Model and
 * Controllers as necessary. 
 *
 * <P>
 * The reason for this is to support not what the computer recognizes, but 
 * what the human perceives. Since the View is the portion that the human 
 * perceives, we wish to make it more central to interaction. Interpreters try 
 * to recognize what's on the screen (ie what you perceive) and try to help 
 * you manage and manipulate the information in a useful way.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Oct 26 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.1.0, Feb 26 2001, JL
 *               * Changed return type of getRelativeLayer() from String to int
 *               * Changed return type of getAbsoluteLayer() from String to
 *                 List of Integers
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3RC1
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public interface GraphicalObject
   extends SatinConstants,
           Cloneable, 
           Serializable, 
           Watchable,
           Shape,
           StrokeListener {

   //===========================================================================
   //===   CLASS PROPERTIES   ==================================================

   /**
    * Class property for Style. New instances of a given subclass will use this
    * style as their default style.
    * @see #clprops
    */
   public static final String STYLE_CLPROPERTY        = "STYLE";

   /**
    * Class property for View. New instances of a given subclass will use this
    * View as their default view.
    * @see #clprops
    */
   public static final String VIEW_CLPROPERTY         = "VIEW";

   /**
    * Class property for View. New instances of a given subclass will use this
    * interpreter as their default gesture interpreter.
    * @see #clprops
    */
   public static final String GESTUREINTRP_CLPROPERTY = "GESTUREINTRP";

   /**
    * Class property for View. New instances of a given subclass will use this
    * interpreter as their default ink interpreter.
    * @see #clprops
    */
   public static final String INKINTRP_CLPROPERTY     = "INKINTRP";

   //===   CLASS PROPERTIES   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ID METHODS   ========================================================

   /**
    * Set the ID of this GraphicalObject. It is designed for network access,
    * and should not normally be called.
    *
    * @return the ID value set.
    */
   public void setUniqueID(long newID);

   /**
    * Get the ID of this GraphicalObject. This value should be set by the
    * constructor.
    *
    * @return an integer containing the ID value.
    */
   public long getUniqueID();


   public void setGlobalID(GlobalID guid);

   public void setGlobalID(String host, int id);

   public GlobalID getGlobalID();
   
   public String getGlobalIDXML();

   //===   ID METHODS   ========================================================
   //===========================================================================



   //===========================================================================
   //===   PROPERTY METHODS   ==================================================
   
   /** @see FlexProperties#getPropertyNames() */
   public Iterator getPropertyNames();

   //-----------------------------------------------------------------

   /** @see FlexProperties#getProperty(String) */
   public Object getProperty(String strPropertyName);

   /** @see FlexProperties#setProperty(String, Object) */
   public void setProperty(String strPropertyName, Object newVal);

   /** @see FlexProperties#removeProperty(String) */
   public Object removeProperty(String strPropertyName);

   //-----------------------------------------------------------------

   /** @see FlexProperties#getIndexedProperty(String) */
   public java.util.List getIndexedProperty(String strPropertyName);

   /** @see FlexProperties#getIndexedProperty(String, int) */
   public Object getIndexedProperty(String strPropertyName, int index);

   /** @see FlexProperties#setIndexedProperty(String, int, Object) */
   public void 
   setIndexedProperty(String strPropertyName, int index, Object newVal);

   /** @see FlexProperties#addIndexedProperty(String, Object) */
   public void addIndexedProperty(String strPropertyName, Object newVal);

   /** @see FlexProperties#removeIndexedProperty(String, int) */
   public Object removeIndexedProperty(String strPropertyName, int index);

   /** @see FlexProperties#removeIndexedProperty(String) */
   public java.util.List removeIndexedProperty(String strPropertyName);

   /** @see FlexProperties#clearIndexedProperty(String) */
   public void clearIndexedProperty(String strPropertyName);

   //===   PROPERTY METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   VIEW METHODS   ======================================================

   /**
    * Set the View for this GraphicalObject. This sets the bounding points
    * for the View to be the same as this GraphicalObject by default.
    * 
    * @see #getView()
    * @see View#setBoundingPoints2DRef(Polygon2D)
    */
   public void setView(View v);

   /**
    * Get the current View for this GraphicalObject, the object that handles
    * how the the GraphicalObject is displayed.
    *
    * @see #setView(View)
    */
   public View getView();

   //===   VIEW METHODS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   INTERPRETER METHODS   ===============================================

   /**
    * Set the current Gesture Interpreter, which tries to handle strokes as
    * gestures.
    *
    * @param  intrp is the new Interpreter to use.
    * @return the current Interpreter.
    */
   public Interpreter setGestureInterpreter(Interpreter intrp);

   /**
    * Get the current Gesture Interpreter, which tries to handle strokes as
    * gestures.
    *
    * @return the current Interpreter.
    */
   public Interpreter getGestureInterpreter();

   //-----------------------------------------------------------------

   /**
    * Set the current Ink Interpreter, which tries to handle strokes as Ink.
    *
    * @param  intrp is the new Interpreter to use.
    * @return the current Interpreter.
    */
   public Interpreter setInkInterpreter(Interpreter intrp);

   /**
    * Get the current Ink Interpreter, which tries to handle strokes as Ink.
    *
    * @return the current Interpreter.
    */
   public Interpreter getInkInterpreter();

   //===   INTERPRETER METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   STYLE METHODS   =====================================================

   /**
    * Set the current Style for this Graphical Object.
    * <P>
    * Notifies Watchers of an update when called.
    *
    * @param the Style to set to. A null value means use default values.
    */
   public Style setStyle(Style newStyle);

   //-----------------------------------------------------------------

   /**
    * Get a copy of the current Style for this Graphical Object.
    *
    * @return the current Style.
    */
   public Style getStyle();

   //-----------------------------------------------------------------

   /**
    * Get a reference of the current Style for this Graphical Object.
    *
    * @return the current Style.
    */
   public Style getStyleRef();

   //===   STYLE METHODS   =====================================================
   //===========================================================================

   //===========================================================================
   //===   RESIZE MODE METHODS   ===============================================

   /**
    * Set the resize mode for this Graphical Object, either to stretch when
    * resized or simply have its bounds changed.
    * 
    * @see    SatinConstants#RESIZE_STRETCH
    * @see    SatinConstants#RESIZE_CHANGE_BOUNDS
    */
   public void setResizeMode(int resizeMode);

   //-----------------------------------------------------------------
   
   /**
    * Gets the resize mode for this Graphical Object, either to stretch when
    * resized or simply have its bounds changed.
    * 
    * @see    SatinConstants#RESIZE_STRETCH
    * @see    SatinConstants#RESIZE_CHANGE_BOUNDS
    */
   public int getResizeMode();
   
   //===   RESIZE MODE METHODS   ===============================================
   //===========================================================================
   

   //===========================================================================
   //===   LAYER METHODS   =====================================================

   /**
    * Get the current layer this Graphical Object is in. Layers are a property 
    * of all Graphical Objects, and only specify a relative Z-ordering
    * (not an absolute one). That is, we only know if a Graphical Object
    * is above or below another, but not by how much (b/c didn't think it would
    * be that useful, and would increase complexity).  Layers may also be 
    * nested (through Graphical Object Groups).
    *
    * <PRE>
    *
    * Main Tree
    * |--  
    * |    A Collection
    * |    |--
    * |    |   Relative: 1
    * |    |   Absolute: 1
    * |    |
    * |    |    |--
    * |    |    |   Relative: 1
    * |    |    |   Absolute: [1,1]
    * |    |    |--
    * |    |
    * |    |    |--
    * |    |    |   Relative: 2
    * |    |    |   Absolute: [1,2]
    * |    |    |--
    * |    |--
    * |
    * |    Another Collection
    * |    |--
    * |    |   Relative: 2
    * |    |   Absolute: 2
    * |    |
    * |    |    |--
    * |    |    |   Relative: 1
    * |    |    |   Absolute: [2,1]
    * |    |    |--
    * |    |--
    * |--
    * </PRE>
    *
    * @return a non-negative value representing the current layer we are in,
    *         or a negative value if the object has no parent.
    */
   public int getRelativeLayer();

   /**
    * A convenience method to set what layer this object is in. Usually, 
    * this should not be used.
    * <P>
    * Notifies Watchers of an update when called.
    *
    * @param layer is the non-negative layer value to set to. If it is set
    *              too high, it is just sent to the bottom-most layer.
    */
   public void setRelativeLayer(int layer);

   //-----------------------------------------------------------------

   /**
    * Get the absolute layer this object is in.
    *
    * @return a List of Integers, like [1,3,2] or [2,1,1], or null if
    * this object is not in any group.
    */
   public java.util.List getAbsoluteLayer();

   //-----------------------------------------------------------------

   /**
    * Bring this Graphical Object up one layer in its current group.
    * Does nothing if the operation is not possible.
    * <P>
    * Notifies Watchers of an update when called.
    */
   public void bringUpALayer();

   /**
    * Bring this Graphical Object up N layers in its current group.
    * Brings up as many layers as possible.
    * <P>
    * Notifies Watchers of an update when called.
    *
    * @param n is the number of layers to move this GraphicalObject up.
    */
   public void bringUpNLayers(int n);

   //-----------------------------------------------------------------

   /**
    * Bring this Graphical Object down one layer in its current group.
    * Does nothing if the operation is not possible.
    * <P>
    * Notifies Watchers of an update when called.
    */
   public void bringDownALayer();

   /**
    * Bring this Graphical Object down N layers in its current group.
    * Brings up as many layers as possible.
    * <P>
    * Notifies Watchers of an update when called.
    *
    * @param n is the number of layers to move this GraphicalObject down.
    */
   public void bringDownNLayers(int n);

   //-----------------------------------------------------------------

   /**
    * Bring this Graphical Object to the top of its current group.
    * Does nothing if the operation is not possible.
    * <P>
    * Notifies Watchers of an update when called.
    */
   public void bringToTopLayer();

   /**
    * Bring this Graphical Object to the bottom of its current group.
    * Does nothing if the operation is not possible.
    * <P>
    * Notifies Watchers of an update when called.
    */
   public void bringToBottomLayer();

   //===   LAYER METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   TRANSFORM METHODS   =================================================

   /**
    * Apply an affine Transform to this Graphical Object.
    * <P>
    * Notifies Watchers of an update when called.
    *
    * @param newTx is a Transform to apply. No modifications are made to newTx.
    */
   public void applyTransform(AffineTransform newTx);

   /**
    * Set and apply a copy of the specified AffineTransform to this 
    * GraphicalObject.
    * <P>
    * Notifies Watchers of an update when called.
    *
    * @param newTx is a Transform to apply. Removes the old one completely. 
    *              No modifications are made to newTx.
    */
   public void setTransform(AffineTransform newTx);

   /**
    * Get a reference to the current transform. For optimization purposes.
    */
   public AffineTransform getTransformRef();

   //-----------------------------------------------------------------

   /**
    * Get a copy of the current transform for this GraphicalObject. 
    *
    * @param  cdsys is the coordinate system.
    * @return a copy of the current Transform.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public AffineTransform getTransform(int cdsys);

   /**
    * Get a copy of the current transform, putting the results in outTx.
    *
    * @param  cdsys is the coordinate system.
    * @param  outTx is the storage space.
    * @return a reference to <CODE>outTx</CODE>.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public AffineTransform getTransform(int cdsys, AffineTransform outTx);

   //-----------------------------------------------------------------

   /**
    * Get the inverse of the transform.
    *
    * @param  cdsys is the coordinate system to use.
    * @return the inverse transform in the specified coordinate system.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public AffineTransform getInverseTransform(int cdsys);

   /**
    * Get the inverse transform.
    *
    * @param  cdsys is the coordinate system to use.
    * @param  outTx is the output storage. Use null to create a new object.
    * @return a reference to <CODE>outTx</CODE>
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public AffineTransform getInverseTransform(int cdsys, AffineTransform outTx);

   //===   TRANSFORM METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   MISCELLANEOUS LOCATION METHODS   ====================================

   /**
    * Calculate the closest distance from the specified point to self.
    * This method assumes that the GraphicalObject can be described as a
    * Polygon. The distance is defined as 0 if the point is within
    * this GraphicalObject and the GraphicalObject is closed. Otherwise, it is 
    * the minimum distance from the specified point to the nearest point in 
    * the GraphicalObject.
    *
    * @param cdsys is the coordinate system.
    * @param x     is the x-coordinate.
    * @param y     is the y-coordinate.
    * @see   SatinConstants#COORD_LOCAL
    * @see   SatinConstants#COORD_REL
    * @see   SatinConstants#COORD_ABS
    */
   public float minDistance(int cdsys, double x, double y);

   //-----------------------------------------------------------------

   /**
    * Calls the other {@link #minDistance(int, double, double)} method.
    */
   public float minDistance(int cdsys, Point2D pt);

   //===   MISCELLANEOUS LOCATION METHODS   ====================================
   //===========================================================================



   //===========================================================================
   //===   VIEW ACCESSOR METHODS   =============================================

   /**
    * Get the location of the top-left corner of the bounding box for 
    * all of the visible views of this GraphicalObject.
    *
    * @see    #getLocation2D(int, AffineTransform, Point2D)
    * @param  cdsys is the coordinate system to use.
    * @return a Point2D containing the Location of the top-left 
    *         corner of this object's bounding box.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public Point2D getLocation2D(int cdsys);

   /**
    * Get the location of the top-left corner of the bounding box for
    * all of the visible views of this GraphicalObject.
    *
    * @param  cdsys is the coordinate system to use.
    * @param  tx    is the transform to apply after the location is 
    *               retrieved. Use null for none.
    * @param  pt    is where to store the output. Use null to create a
    *               new point. Use for optimization purposes.
    * @return a reference to <CODE>pt</CODE>.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public Point2D getLocation2D(int cdsys, AffineTransform tx, Point2D pt);

   //-----------------------------------------------------------------
   
   /**
    * Get the bounds of all of the visible views of this GraphicalObject.
    * 
    * @see    #getBounds2D(int)
    * @param  cdsys is the coordinate system to use.
    * @return a reference to rect.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public Rectangle2D getBounds2D(int cdsys);

   /**
    * Get the bounds of all of the visible views of this GraphicalObject.
    *
    * @param  cdsys is the coordinate system to use.
    * @param  tx    is the transform to apply after the location is 
    *               retrieved. Use null for none.
    * @param  rect  is the Rectangle to put the results in. Use null to create
    *               a new Rectangle. Use for optimization purposes.
    * @return a reference to <CODE>rect</CODE>.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public Rectangle2D getBounds2D(int cdsys, AffineTransform tx, 
                                  Rectangle2D rect);

   //-----------------------------------------------------------------

   /**
    * Get a Polygon describing the outer boundary of all of the visible 
    * views of this GraphicalObject.
    *
    * @param  cdsys is the coordinate system to use.
    * @return a Polygon representing this GraphicalObject's bounding points.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public Polygon2D getBoundingPoints2D(int cdsys);

   /**
    * Get a Polygon describing the outer boundary of all of the visible 
    * views of this GraphicalObject.
    *
    * @param  cdsys is the coordinate system to use.
    * @param  tx    is the transform to apply after the location is 
    *               retrieved. Use null for none.
    * @param  poly  is the Polygon to put the results in. Use null to 
    *               create a new Polygon. Use for optimization purposes.
    * @return a reference to <CODE>poly</CODE>.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public Polygon2D getBoundingPoints2D(int cdsys, AffineTransform tx, 
                                        Polygon2D poly);

   //-----------------------------------------------------------------

   /**
    * Get the width of all of the visible views of this GraphicalObject.
    *
    * @param  cdsys is the coordinate system to use.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public float getWidth2D(int cdsys);

   /**
    * Get the height of all of the visible views of this GraphicalObject.
    *
    * @param  cdsys is the coordinate system to use.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public float getHeight2D(int cdsys);

   //-----------------------------------------------------------------

   /**
    * Set whether or not this GraphicalObject is a closed shape or not.
    * By default is true.
    */
   public void setHasClosedBoundingPoints(boolean flag);

   /**
    * Check if the bounding points describing this GraphicalObject is a closed
    * Polygon (e.g. a box) or an open Polygon (e.g. most ink strokes).
    *
    * @return true if the GraphicalObject is closed, false otherwise.
    */
   public boolean hasClosedBoundingPoints();

   //===   VIEW ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   GRAPHICAL OBJECT SHAPE METHODS   ====================================

   /**
    * See if the specified GraphicalObject fits entirely within our bounds.
    * <P>
    * Don't confuse this method with 
    * {@link GraphicalObjectCollection#contains(GraphicalObject)}.
    *
    * @param  gob is the GraphicalObject to check. It doesn't matter what
    *             coordinate space gob is in, it will be moved to the correct
    *             space.
    * @return true if gob is contained, false otherwise.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public boolean shapeContains(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * See if we contain the specified point.
    *
    * @param  cdsys is the coordinate system of the point.
    * @param  pt    is the point.
    * @return true if we contain the point, false otherwise.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public boolean shapeContains(int cdsys, Point2D pt);

   //-----------------------------------------------------------------

   /**
    * See if we contain the specified point.
    *
    * @param  cdsys is the coordinate system of the point.
    * @param  x     is the x-coordinate.
    * @param  y     is the y-coordinate.
    * @return true if we contain the point, false otherwise.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public boolean shapeContains(int cdsys, double x, double y);

   //-----------------------------------------------------------------

   /**
    * See if we contain the specified rectangle.
    *
    * @param  cdsys is the coordinate system of the point.
    * @param  s     is the shape to check.
    * @return true if we contain the point, false otherwise.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public boolean shapeContains(int cdsys, Shape s);

   //-----------------------------------------------------------------

   /**
    * See if the specified GraphicalObject intersects the 
    * this GraphicalObject. Two GraphicalObjects intersect if they share
    * any two points in common.
    *
    * @param  gob is checked to see if it intersects this GraphicalObject.
    *             It doesn't matter what coordinate space gob is in, it will be
    *             moved to the correct space.
    * @return true if gob intersects this GraphicalObject, false otherwise.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public boolean shapeIntersects(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * See if we intersect the specified shape.
    *
    * @param  cdsys is the coordinate system of the point.
    * @param  s     is the shape to check.
    * @return true if we contain the point, false otherwise.
    * @see    SatinConstants#COORD_LOCAL
    * @see    SatinConstants#COORD_REL
    * @see    SatinConstants#COORD_ABS
    */
   public boolean shapeIntersects(int cdsys, Shape s);

   //===   GRAPHICAL OBJECT SHAPE METHODS   ====================================
   //===========================================================================



   //===========================================================================
   //===   VIEW MODIFIER METHODS   =============================================

   /**
    * Check whether or not this Graphical Object can be selected.
    *
    * @return true if it can be selected, false otherwise.
    */
   public boolean isSelectable();

   /**
    * Set whether or not this Graphical Object can be selected.
    *
    * @param flag is true to set this Graphical Object as selectable, 
    *             false otherwise.
    */
   public void setSelectable(boolean flag);

   //-----------------------------------------------------------------

   /**
    * Move directly to the specified position.
    * <P>
    * Notifies Watchers of an update when called.
    *
    * @param cdsys is the coordinate system to use.
    * @param x     is the x-coordinate to move to.
    * @param y     is the y-coordinate to move to.
    * @see   SatinConstants#COORD_LOCAL
    * @see   SatinConstants#COORD_REL
    * @see   SatinConstants#COORD_ABS
    */
   public void moveTo(int cdsys, double x, double y);

   /**
    * Calls moveTo and then applyTransform.
    */
   public void moveTo(int cdsys, double x, double y, double theta);

   /**
    * Calls the other {@link #moveTo(int, double, double)} method.
    */
   public void moveTo(int cdsys, Point2D pt);

   //-----------------------------------------------------------------

   /**
    * Move relative to where we currently are.
    * <P>
    * Notifies Watchers of an update when called.
    *
    * @param cdsys is the coordinate system to use.
    * @param dx    is the change in x-coordinate to move.
    * @param dy    is the change in y-coordinate to move.
    * @see   SatinConstants#COORD_LOCAL
    * @see   SatinConstants#COORD_REL
    * @see   SatinConstants#COORD_ABS
    */
   public void moveBy(int cdsys, double dx, double dy);

   /**
    * Calls the other {@link #moveBy(int, double, double)} method.
    */
   public void moveBy(int cdsys, Point2D pt);

   //-----------------------------------------------------------------

   /**
    * Set the bounding points for our default view. 
    * <P>
    * Notifies Watchers of an update when called.
    *
    * @param cdsys is the coordinate system to use.
    * @param s     is the shape that describes our bounds.
    * @see   #getView()
    * @see   SatinConstants#COORD_LOCAL
    * @see   SatinConstants#COORD_REL
    * @see   SatinConstants#COORD_ABS
    */
   public void setBoundingPoints2D(int cdsys, Shape s);

   //===   VIEW MODIFIER METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   DISPATCHING METHODS   ===============================================

   //// Also see StrokeListener

   //-----------------------------------------------------------------

   /**
    * Here is an overview of how dispatching works in Satin.
    * The ASCII diagram below shows the lifecycle of a {@link TimedStroke} as 
    * it is dispatched. When a TimedStroke is created, a message is dispatched 
    * to the {@link Sheet} signifying that a Stroke is being created, via
    * onNewStroke(). As the TimedStroke is updated, 
    * <CODE>onUpdateStroke()</CODE> is called on the Sheet. After it is 
    * completed, <CODE>onSingleStroke()</CODE> is called on the Sheet.
    *
    * <PRE>
    *     ---------------    ------------------    ------------------
    * ---&gt;|onNewStroke()|---&gt;|onUpdateStroke()|---&gt;|onSingleStroke()|
    *     ---------------    ------------------    ------------------
    *                                   |    ^
    *                                   |    |
    *                                   |____|
    *
    * </PRE>
    *
    * <P>
    * Here's what happens in Sheet when onNewStroke() is called, in order.
    * <UL>
    *    <LI><CODE>onNewStroke()</CODE> - message that a new stroke is 
    *                                     being created
    *    <UL>
    *       <LI><CODE>preProcessNewStroke()</CODE> - use interpreter to process 
    *                                                stroke as gesture
    *       <LI><CODE>redispatchNewStroke()</CODE> - redispatch the stroke 
    *                                                to others
    *       <LI><CODE>postProcessNewStroke()</CODE> - use interpreter to 
    *                                                 process stroke as ink
    *       <LI><CODE>handleNewStroke()</CODE> - handle the stroke, ie add, 
    *                                            ignore, etc.
    *    </UL>
    * </UL>
    *
    * The same happens when <CODE>onUpdateStroke()</CODE> and 
    * <CODE>onSingleStroke()</CODE> are called.
    * <P>
    * Here's a full example of what happens. Suppose you are drawing a stroke 
    * on top of a GraphicalObject (which in turn is contained by the Sheet). 
    * In the notation below, the sheet is designated with <B>s</B> and the
    * GraphicalObject is designated with <B>g</B>. The indentation represents
    * different levels of the call stack. Here are the methods that are called:
    * <PRE>
    * s.onNewStroke()                      // this occurs once per TimedStroke
    *    s.preProcessNewStroke()
    *    s.redispatchNewStroke()
    *       g.onNewStroke()
    *          g.preProcessNewStroke()
    *             g.getGestureInterpreter().handleNewStroke()
    *          g.redispatchNewStroke()
    *          g.postProcessNewStroke()
    *             g.getInkInterpreter().handleNewStroke()
    *          g.handleNewStroke()
    *    s.postProcessNewStroke()
    *    s.handleNewStroke()
    *
    * s.onUpdateStroke()                   // this occurs multiple times
    *    s.preProcessUpdateStroke()
    *    s.redispatchUpdateStroke()
    *       g.onUpdateStroke()
    *          g.preProcessUpdateStroke()
    *             g.getGestureInterpreter().handleUpdateStroke()
    *          g.redispatchUpdateStroke()
    *          g.postProcessUpdateStroke()
    *             g.getInkInterpreter().handleUpdateStroke()
    *          g.handleUpdateStroke()
    *    s.postProcessUpdateStroke()
    *    s.handleUpdateStroke()
    *
    * s.onSingleStroke()                   // this occurs once per TimedStroke
    *    s.preProcessSingleStroke()
    *    s.redispatchSingleStroke()
    *       g.onSingleStroke()
    *          g.preProcessSingleStroke()
    *             g.getGestureInterpreter().handleSingleStroke()
    *          g.redispatchSingleStroke()
    *          g.postProcessSingleStroke()
    *             g.getInkInterpreter().handleSingleStroke()
    *          g.handleSingleStroke()
    *    s.postProcessSingleStroke()
    *    s.handleSingleStroke()
    * </PRE>
    *
    * @see    StrokeListener for information on how to manipulate the event.
    * @param  evt is the event to dispatch. evt should be in this
    *             GraphicalObject's local coordinate space when this method is
    *             called.
    */
   public void onNewStroke(NewStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void preProcessNewStroke(NewStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void redispatchNewStroke(NewStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void postProcessNewStroke(NewStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void handleNewStroke(NewStrokeEvent evt);

   //-----------------------------------------------------------------

   /** @see #onNewStroke(NewStrokeEvent) */
   public void onUpdateStroke(UpdateStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void preProcessUpdateStroke(UpdateStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void redispatchUpdateStroke(UpdateStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void postProcessUpdateStroke(UpdateStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void handleUpdateStroke(UpdateStrokeEvent evt);

   //-----------------------------------------------------------------

   /** @see #onNewStroke(NewStrokeEvent) */
   public void onSingleStroke(SingleStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void preProcessSingleStroke(SingleStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void redispatchSingleStroke(SingleStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void postProcessSingleStroke(SingleStrokeEvent evt);

   /** @see #onNewStroke(NewStrokeEvent) */
   public void handleSingleStroke(SingleStrokeEvent evt);

   //===   DISPATCHING METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   DISPLAY METHODS   ===================================================

   /**
    * Set whether this GraphicalObject should be displayed or not.
    */
   public void setVisible(boolean flag);

   //-----------------------------------------------------------------

   /**
    * Check whether this GraphicalObject is visible or not.
    */
   public boolean isVisible();

   //-----------------------------------------------------------------

   /**
    * Turn off damage mechanism temporarily. This works like a counting
    * semaphore. Every time this method is called, the disable value is
    * incremented. The damage mechanism is enabled if and only if the disable
    * value is 0.
    * <P>
    * This method is useful if you are doing multiple operations to the
    * same GraphicalObject all at once, but don't want to damage the 
    * GraphicalObject until all the operations are done.
    *
    * @see #enableDamage()
    * @see #hasDamageEnabled()
    */
   public void disableDamage();

   //-----------------------------------------------------------------

   /**
    * Re-enable damage mechanism.
    *
    * @see #disableDamage()
    * @see #hasDamageEnabled()
    */
   public void enableDamage();

   //-----------------------------------------------------------------

   /**
    * See if damage is enabled or not.
    *
    * @see #disableDamage()
    * @see #enableDamage()
    */
   public boolean hasDamageEnabled();

   //-----------------------------------------------------------------

   /**
    * Set whether the GraphicalObject should be clipped to bounds or not.
    * Slows down performance if true. Default is false.
    *
    * @param flag specifies whether the GraphicalObject should be clipped
    *             to bounds or not.
    */
   public void setClipToBounds(boolean flag);

   //-----------------------------------------------------------------

   /**
    * Check whether the GraphicalObject should be clipped to bounds or not.
    *
    * @return true if the GraphicalObject should be clipped to bounds, false
    *         otherwise.
    */
   public boolean isClippedToBounds();

   //-----------------------------------------------------------------

   /**
    * If this GraphicalObject {@link #hasNotifyEnabled()}, mark this 
    * GraphicalObject as damaged and repaint.
    *
    * @param sync is either {@link SatinConstants#DAMAGE_NOW} or
    *             {@link SatinConstants#DAMAGE_LATER}
    * @see   SatinConstants#DAMAGE_NOW
    * @see   SatinConstants#DAMAGE_LATER
    */
   public void damage(int sync);

   //-----------------------------------------------------------------

   /**
    * If this GraphicalObject {@link #hasNotifyEnabled()}, mark the specified
    * GraphicalObject as damaged and repaint.
    *
    * @param sync is either {@link SatinConstants#DAMAGE_NOW} or
    *             {@link SatinConstants#DAMAGE_LATER}
    * @param gob is the GraphicalObject to repaint.
    * @see   SatinConstants#DAMAGE_NOW
    * @see   SatinConstants#DAMAGE_LATER
    */
   public void damage(int sync, GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * If this GraphicalObject {@link #hasNotifyEnabled()}, mark the specified
    * region as damaged and repaint.
    *
    * @param sync is either {@link SatinConstants#DAMAGE_NOW} or
    *             {@link SatinConstants#DAMAGE_LATER}
    * @param rect is the rectangle to damage (absolute coordinates).
    * @see   SatinConstants#DAMAGE_NOW
    * @see   SatinConstants#DAMAGE_LATER
    */
   public void damage(int sync, Rectangle2D rect);

   //-----------------------------------------------------------------

   /**
    * If this GraphicalObject {@link #hasNotifyEnabled()}, mark the specified
    * regions as damaged and repaint. This method is typically used when 
    * transforms are applied, when the GraphicalObject was in one place 
    * and is now in another.
    *
    * @param sync    is either {@link SatinConstants#DAMAGE_NOW} or
    *                {@link SatinConstants#DAMAGE_LATER}
    * @param oldRect is the rectangle to damage (absolute coordinates).
    * @param newRect is the rectangle to damage (absolute coordinates).
    * @see   SatinConstants#DAMAGE_NOW
    * @see   SatinConstants#DAMAGE_LATER
    */
   public void damage(int sync, Rectangle2D oldRect, Rectangle2D newRect);

   //-----------------------------------------------------------------

   /**
    * Render this graphical object in the specified Graphics context.
    * <P>
    * When this method is called for you, your Style and Transform has 
    * already been set. This has several implications. 
    * <P>
    * First, you can just use the normal drawing methods, like drawLine(), 
    * and they will automatically use the thickness and other properties as set
    * in Style. You can still set colors and fonts and such if you want,
    * though.
    * <P>
    * Secondly, your coordinate system is set such that (0,0) is your
    * top-left corner.
    * <P>
    * Third, since your transform is already set, you don't have to do anything
    * special to get rotation. Just draw normally.
    * <P>
    * Fourth, while in render(), do not call any methods that use 
    * {@link SatinConstants#COORD_REL} or {@link SatinConstants#COORD_ABS},
    * since the transform has already been applied. Instead, use
    * {@link SatinConstants#COORD_LOCAL}.
    * <P>
    * So in other words, all you have to do is just draw the GraphicalObject
    * normally, and everything else will be handled for you. However, do NOT
    * call anything that uses the transformed bounds, since that will apply 
    * the transform twice (the transform has already been applied once).
    *
    * @param g is the Graphics context to draw in.
    */
   public void render(SatinGraphics g);

   //===   DISPLAY METHODS   ===================================================
   //===========================================================================



   //===========================================================================
   //===   PARENTAL METHODS   ==================================================

   /**
    * Get the parent of this Graphical object.
    *
    * @return the Parent of this Graphical Object, or null if it does not
    *         have a parent.
    */
   public GraphicalObjectGroup getParentGroup();

   //-----------------------------------------------------------------

   /**
    * Set who the parent of this Graphical Object is. This method should not 
    * be normally called, but it is necessary to have since we need a way of
    * setting parents when adding Graphical Objects to Groups.
    * <P>
    * Please note that this does not necessarily add this GraphicalObject to
    * the specified parent. Typically, this method will be called for you when 
    * a GraphicalObject is added to a Group or Patch.
    *
    * @param newParent is the parent to set to. Use null if this object does
    *                  not have a parent.
    */
   public void setParentGroup(GraphicalObjectGroup newParent);

   //-----------------------------------------------------------------

   /**
    * Get the sheet that this Graphical object is in.
    * 
    * @return the Sheet that this Graphical Object is in, or null if it is
    *         not in a Sheet.
    */
   public Sheet getSheet();

   //-----------------------------------------------------------------
   
   /**
    * This method is called after this object is added to a group.
    */
   public void initAfterAdd();

   //-----------------------------------------------------------------
   
   /**
    * This method is called after this object is first added to a sheet.
    */
   public void initAfterAddToSheet();
   
   //-----------------------------------------------------------------

   /**
    * Delete this object. Useful only if this object has a parent.
    * Essentially, this means that you cannot delete the root of the 
    * interactor tree.  
    * <P>
    * Also notifies Watchers of a delete when called.
    */
   public void delete();

   //===   PARENTAL METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Clone this object shallowly, copying references to any children
    * this GraphicalObject has.
    */
   public Object clone();

   //-----------------------------------------------------------------

   /**
    * Clone this object deeply, recursively deep-cloning any children
    * this GraphicalObject has.
    */
   public Object deepClone();

   //===   CLONE METHODS   =====================================================
   //===========================================================================

} // of interface 

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
