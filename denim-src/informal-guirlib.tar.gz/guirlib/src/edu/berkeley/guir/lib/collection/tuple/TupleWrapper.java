//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tuple;

import edu.berkeley.guir.lib.collection.tuple.comparator.TupleComparator;
import edu.berkeley.guir.lib.collection.tuple.filter.TupleFilter;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Wraps up another Tuple.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Dec 15 2002, JH
 */
public class TupleWrapper
    extends Tuple {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    Tuple wrappedTuple;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================



    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * @param t is the Tuple to wrap.
     */
    public TupleWrapper(Tuple t) {
        setWrappedTuple(t);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param  t            is the Tuple to wrap.
     * @param  strTupleType is the type the tuple must be.
     * @throws IllegalArgumentException if strTupleType and t.getTupleType()
     *                                  do not match.
     */
    public TupleWrapper(Tuple t, String strTupleType) {
        if (strTupleType.equals(t.getTupleType()) == false) {
            throw new IllegalArgumentException(
               "Tuple to be wrapped does not match required tuple type: " +
               strTupleType);
        }

        setWrappedTuple(t);
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================



    //==========================================================================
    //===   WRAPPER METHODS   ==================================================

    public void setWrappedTuple(Tuple t) {
        wrappedTuple = t;
    } // of method

    public Tuple getWrappedTuple() {
        return (wrappedTuple);
    } // of method

    //===   WRAPPER METHODS   ==================================================
    //==========================================================================



    //==========================================================================
    //===   TUPLE METHODS   ====================================================

    public void setTupleType(String str) {
        wrappedTuple.setTupleType(str);
    } // of method

    //--------------------

    public String getTupleType() {
        return (wrappedTuple.getTupleType());
    } // of method

    public boolean isTupleType(String strTupleType) {
        return (wrappedTuple.isTupleType(strTupleType));
    } // of method

    //--------------------

    public void setDynamicSize(boolean flag) {
        wrappedTuple.setDynamicSize(flag);
    } // of method

    public boolean hasDynamicSize() {
        return (wrappedTuple.hasDynamicSize());
    } // of method

    //--------------------

    public void setAttributes(Map map) {
        wrappedTuple.setAttributes(map);
    } // of method

    public void setAttribute(String strKey, String strVal) {
        wrappedTuple.setAttribute(strKey, strVal);
    } // of method

    public void setAttribute(String strKey, int val) {
        wrappedTuple.setAttribute(strKey, val);
    } // of method

    public void setAttribute(String strKey, long val) {
        wrappedTuple.setAttribute(strKey, val);
    } // of method

    public void setAttribute(String strKey, double val) {
        wrappedTuple.setAttribute(strKey, val);
    } // of method

    //--------------------

    public String getAttribute(String strKey) {
        return (wrappedTuple.getAttribute(strKey));
    } // of method

    public int getAttributeAsInt(String strKey) {
        return (wrappedTuple.getAttributeAsInt(strKey));
    } // of method

    public long getAttributeAsLong(String strKey) {
        return (wrappedTuple.getAttributeAsLong(strKey));
    } // of method

    public double getAttributeAsDouble(String strKey) {
        return (wrappedTuple.getAttributeAsDouble(strKey));
    } // of method

    //--------------------

    public void clearAttributes() {
        wrappedTuple.clearAttributes();
    } // of method

    //--------------------

    public Iterator attributeKeys() {
        return (wrappedTuple.attributeKeys());
    } // of method

    public Map getAttributes() {
        return (wrappedTuple.getAttributes());
    } // of method

    public int getNumAttributes() {
        return (wrappedTuple.getNumAttributes());
    } // of method

    //--------------------

    public void setTo(Tuple t) {
        wrappedTuple.setTo(t);
    } // of method

    //--------------------

    public void addTuples(List list) {
        wrappedTuple.addTuples(list);
    } // of method

    public void addTuple(Tuple tuple) {
        wrappedTuple.addTuple(tuple);
    } // of method

    //--------------------

    public Iterator tuples() {
        return (wrappedTuple.tuples());
    } // of method

    //--------------------

    public void clearTuples() {
        wrappedTuple.clearTuples();
    } // of method

    //--------------------

    public void removeTuple(Tuple t) {
        wrappedTuple.removeTuple(t);
    } // of method

    public void removeTuplesByAttribute(String strAttribute) {
        wrappedTuple.removeTuplesByAttribute(strAttribute);
    } // of method

    public void removeTuplesByAttribute(String strAttribute, String strPattern){
        wrappedTuple.removeTuplesByAttribute(strAttribute, strPattern);
    } // of method

    //--------------------

    public Tuple getTuple(int i) {
        return (wrappedTuple.getTuple(i));
    } // of method

    public Tuple getFirstTuple() {
        return (wrappedTuple.getFirstTuple());
    } // of method

    public Tuple getLastTuple() {
        return (wrappedTuple.getLastTuple());
    } // of method

    public List getTuples() {
        return (wrappedTuple.getTuples());
    } // of method

    public List getTuples(TupleComparator c) {
        return (wrappedTuple.getTuples(c));
    } // of method

    public List getTuples(TupleFilter f) {
        return (wrappedTuple.getTuples(f));
    } // of method

    public Tuple getTupleByType(String strTupleType) {
        return (wrappedTuple.getTupleByType(strTupleType));
    } // of method

    public List getTuplesByType(String strTupleType) {
        return (wrappedTuple.getTuplesByType(strTupleType));
    } // of method

    public Tuple getTupleByAttribute(String strAttribute) {
        return (wrappedTuple.getTupleByAttribute(strAttribute));
    } // of method

    public List getTuplesByAttribute(String strAttribute) {
        return (wrappedTuple.getTuplesByAttribute(strAttribute));
    } // of method

    public Tuple getTupleByAttribute(String strAttribute, 
                                     String strPattern) {
        return (wrappedTuple.getTupleByAttribute(strAttribute, strPattern));
    } // of method

    public List getTuplesByAttribute(String strAttribute, 
                                    String strPattern) {
        return (wrappedTuple.getTuplesByAttribute(strAttribute,strPattern));
    } // of method

    //--------------------

    public void sortTuples(Comparator c) {
        wrappedTuple.sortTuples(c);
    } // of method

    //--------------------

    public int getNumTuples() {
        return (wrappedTuple.getNumTuples());
    } // of method

    //--------------------

    public String getXPath(String strXPath) throws Exception {
        return (wrappedTuple.getXPath(strXPath));
    } // of method

    //===   TUPLE METHODS   ====================================================
    //==========================================================================



    //==========================================================================
    //===   OBJECT METHODS   ===================================================

    public int hashCode() {
        return (wrappedTuple.hashCode());
    } // of method

    //--------------------

    public String getHashKey() {
        return (wrappedTuple.getHashKey());
    } // of method

    //===   OBJECT METHODS   ===================================================
    //==========================================================================



    //==========================================================================
    //===   TOSTRING   =========================================================

    public void toString(StringBuffer strbuf, int indent, boolean flagMulti) {
        wrappedTuple.toString(strbuf, indent, flagMulti);
    } // of method

    //----------------------------------------------------------------

    public String toString() {
        return (wrappedTuple.toString());
    } // of method

    public String toString(boolean flag) {
        return (wrappedTuple.toString(flag));
    } // of method

    //----------------------------------------------------------------

    public String toXml() {
        return (wrappedTuple.toXml());
    } // of method

    public String toXml(boolean flag) {
        return (wrappedTuple.toXml(flag));
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
