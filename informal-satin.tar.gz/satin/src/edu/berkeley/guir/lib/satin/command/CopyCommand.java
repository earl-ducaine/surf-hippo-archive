//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.util.*;
import java.util.*;

/**
 * Copy a Graphical Object to the clipboard.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 14 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class CopyCommand
   extends CommandImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -3875655884154094856L;

   //===   CONSTANTS   =========================================================
   //===========================================================================


   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   protected static Clipboard myClipboard = SatinConstants.clipboard;

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================

   
   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   protected Set copySet = new TreeSet(new LayerReverseComparator());

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public CopyCommand() {
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create the copy command object, copying the specified GraphicalObject
    * into the clipboard.
    *
    * @param gob is the Graphical Object to insert.
    */
   public CopyCommand(GraphicalObject gob) {
      addGraphicalObject(gob);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Make the specified collection of Graphical Objects the list of Graphical
    * Objects to copy into the clipboard.
    *
    * @param it is the Iterator of Graphical Objects to copy.
    */
   public CopyCommand(Iterator it) {
      Object      obj;
      while (it.hasNext()) {
         obj = it.next();
         if (obj instanceof GraphicalObject) {
            addGraphicalObject((GraphicalObject) obj);
         }
      }
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Make the specified collection of Graphical Objects the list of Graphical
    * Objects to copy into the clipboard.
    *
    * @param gobs is the Vector of Graphical Objects to copy.
    */
   public CopyCommand(Vector gobs) {
      this(gobs.iterator());
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   COPY METHODS   ======================================================

   /**
    * Add a Graphical Object to the list of Graphical Objects to be copied.
    *
    * @param gob is the Graphical Object to copy.
    */
   public void addGraphicalObject(GraphicalObject gob) {
      copySet.add(gob);
   } // of addGraphicalObject

   //-----------------------------------------------------------------

   /**
    * Remove a Graphical Object from the list of Graphical Objects to be copied.
    * Does nothing if the Graphical Object was not in the list.
    *
    * @param gob is the Graphical Object to remove from the copy command.
    */
   public void removeGraphicalObject(GraphicalObject gob) {
      copySet.remove(gob);
   } // of removeGraphicalObject

   //-----------------------------------------------------------------

   /**
    * Clear the list of Graphical Objects to be copied.
    */
   public void clearGraphicalObjects() {
      copySet.clear();
   } // of clearGraphicalObjects

   //===   COPY METHODS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      return ("copy graphical object to clipboard");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   STATUS ACCESSOR METHODS   ===========================================

   public boolean canRedo() {
      return (false);
   } // of canRedo

   //-----------------------------------------------------------------

   public boolean canUndo() {
      return (false);
   } // of canUndo

   //-----------------------------------------------------------------

   public boolean isSignificant() {
      return (false);
   } // of isSignificant

   //===   STATUS ACCESSOR METHODS   ===========================================
   //===========================================================================

   
   //===========================================================================
   //===   CLASS METHODS   =====================================================

   /**
    * Sets which clipboard paste commands should paste from.
    */
   public static void setClipboard(Clipboard newClipboard) {
      myClipboard = newClipboard;
   }
   
   //===   CLASS METHODS   =====================================================
   //===========================================================================

   
   //===========================================================================
   //===   ACTION METHODS   ====================================================

   public void run() {
      if (copySet.isEmpty()) {
         return;
      }
      myClipboard.clearClipboard();
      myClipboard.copyToClipboard(copySet.iterator());
   } // of do

   //-----------------------------------------------------------------

   public void redo() {
      //// ignore, no point in redo'ing a copy command
   } // of redo

   //-----------------------------------------------------------------

   public void undo() {
      //// ignore, no point in undo'ing a copy command
   } // of undo

   //-----------------------------------------------------------------

   public void die() {
   } // of die

   //===   ACTION METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
