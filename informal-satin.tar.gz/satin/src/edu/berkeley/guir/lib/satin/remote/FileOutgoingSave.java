
package edu.berkeley.guir.lib.satin.remote;

import java.io.*;

/**
 * @author  RL, Katie Everitt
 * @version 1.4
 */
public class FileOutgoingSave extends Thread {
   private InOutMgr                m_manager       = null;
    
   private String                  m_pathAndFilename = "";
   private FileOutputStream        m_out           = null;
   private FileWriter              m_writeOut      = null;


   /** Creates new GRemoteOutgoingSocket */
   public FileOutgoingSave(InOutMgr manager, String pathAndFilename) {
      m_manager = manager;
      m_pathAndFilename = pathAndFilename;
   }
    

   public void openFile() {
		boolean append = true;
		try {
      	m_out = new FileOutputStream(m_pathAndFilename,append);
			m_writeOut = new FileWriter(m_pathAndFilename,append);
					
			} catch (IOException e){
      		System.err.println(e);
   		}
   }
   
   public void closeFile() {
		try {
      	// Flush output out to file.  This isn't done automatically.
      		m_writeOut.flush();
      		m_writeOut.close();
      		m_out.close();
   		} catch (IOException e){
      		System.err.println(e);
   		}
   }

   private void addString(String XML) {
      try{
         m_writeOut.write(XML);
         m_writeOut.write("\n");
         m_writeOut.flush();
      }catch(IOException e){
         System.out.println("Error in SaveOutgoingDisk:addString(String XML)");  
      }
   }

      
   public void run() {
      System.out.println("SaveOutgoingDisk run called");
      openFile();
      while (true) {
         try {
            IOEvent ioEvent = null;
            System.out.println("SaveOutgoingDisk: Awaiting outgoing event...");
            while (ioEvent == null) {
               ioEvent = m_manager.getOutgoingEvent();
               if (ioEvent == null) {
                  try { Thread.sleep(50); } catch (InterruptedException e) { }
               }
            }
            System.out.println("SaveOutgoingDisk: Saving outgoing event...");
            // Save
            addString(ioEvent.getXML());
         } catch (Exception e) {
            System.out.println("SaveOutgoingDisk: Exception ---------------\n");
            closeFile();
         }
      }
   }
}   