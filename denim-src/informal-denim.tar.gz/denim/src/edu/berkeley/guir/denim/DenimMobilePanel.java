package edu.berkeley.guir.denim;

/**
 * @author shen
 *
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import javax.swing.border.Border;

import edu.berkeley.guir.denim.components.DenimListBoxInstance;

public class DenimMobilePanel extends JPanel {

   private DenimRunSheet runSheet;
   private DenimPanel currentPanel;


   //-------------------------------------------------------------------

   /**
    * Given a DenimRunSheet, it creates a mobile panel layout without
    * phonescreen
    */
   public DenimMobilePanel(DenimRunSheet runSheet) {
      this.runSheet = runSheet;
      init();
   }

   //-----------------------------------------------------------------------

   /**
    * Properly sizes and places all buttons so that the buttons tile OK.
    * Without that, They are likely to be cut off and out of order.
    * Properly  sets the border of each buttons so that it clearly
    * defines regions within the bounds.
    */
   public void init() {

      Border compound, raisedbevel, loweredbevel, empty;

      raisedbevel = BorderFactory.createRaisedBevelBorder();
      loweredbevel = BorderFactory.createLoweredBevelBorder();
      empty = BorderFactory.createEmptyBorder();
      compound = BorderFactory.createCompoundBorder(raisedbevel, loweredbevel);

      // set a DenimMobileLayoutManager for this DenimMobilePanel
      setLayout(new DenimMobileLayoutManager(new Dimension(12, 14)));

      // create five control buttons as the layouts of Nokia, Motorola,
      // ericsson, and etc
      JButton jcomp_sflt = new JButton("SFLF");
      jcomp_sflt.setBorder(raisedbevel);
      add(jcomp_sflt, new Rectangle(0, 0, 3, 3));

      JButton jcomp_sfrt = new JButton("SFRF");
      jcomp_sfrt.setBorder(raisedbevel);
      add(jcomp_sfrt, new Rectangle(9, 0, 3, 3));

      JButton jcomp_home = new JButton("HOME");
      jcomp_home.setBorder(raisedbevel);
      add(jcomp_home, new Rectangle(0, 3, 3, 3));

      JButton jcomp_back = new JButton("BACK");
      jcomp_back.setBorder(raisedbevel);
      add(jcomp_back, new Rectangle(9, 3, 3, 3));

      JButton jcomp_menu = new JButton("MENU");
      jcomp_menu.setBorder(compound);
      add(jcomp_menu, new Rectangle(5, 2, 2, 2));

      // create four image navigation buttons: up, down, prev, next
      ImageIcon up =
         new ImageIcon(Denim.class.getResource("images/toolbar/UpArrow.gif"));
      JButton jcompUp = new JButton(up);
      jcompUp.addActionListener(new NavUpAction());
      jcompUp.setEnabled(true);
      jcompUp.setBorder(empty);
      add(jcompUp, new Rectangle(5, 0, 2, 2));

      ImageIcon down =
         new ImageIcon(Denim.class.getResource("images/toolbar/DownArrow.gif"));
      JButton jcompDown = new JButton(down);
      jcompDown.addActionListener(new NavDownAction());
      jcompDown.setEnabled(true);
      jcompDown.setBorder(empty);
      add(jcompDown, new Rectangle(5, 4, 2, 2));

      ImageIcon prev =
         new ImageIcon(Denim.class.getResource("images/toolbar/PrevArrow.gif"));
      JButton jcompPrev = new JButton(prev);
      jcompPrev.setBorder(empty);
      add(jcompPrev, new Rectangle(3, 2, 2, 2));

      ImageIcon next =
         new ImageIcon(Denim.class.getResource("images/toolbar/NextArrow.gif"));
      JButton jcompNext = new JButton(next);
      jcompNext.setBorder(empty);
      add(jcompNext, new Rectangle(7, 2, 2, 2));

      // create ten numeric buttons and two character buttons,
      // namely, "*" and "#"
      JButton jcomp1 = new JButton("1");
      jcomp1.addActionListener(new Button1Action());
      jcomp1.setEnabled(true);
      jcomp1.setBorder(raisedbevel);
      add(jcomp1, new Rectangle(0, 6, 4, 2));

      JButton jcomp2 = new JButton("2");
      jcomp2.addActionListener(new Button2Action());
      jcomp2.setEnabled(true);
      jcomp2.setBorder(raisedbevel);
      add(jcomp2, new Rectangle(4, 6, 4, 2));

      JButton jcomp3 = new JButton("3");
      jcomp3.addActionListener(new Button3Action());
      jcomp3.setEnabled(true);
      jcomp3.setBorder(raisedbevel);
      add(jcomp3, new Rectangle(8, 6, 4, 2));

      JButton jcomp4 = new JButton("4");
      jcomp4.addActionListener(new Button4Action());
      jcomp4.setEnabled(true);
      jcomp4.setBorder(raisedbevel);
      add(jcomp4, new Rectangle(0, 8, 4, 2));

      JButton jcomp5 = new JButton("5");
      jcomp5.addActionListener(new Button5Action());
      jcomp5.setEnabled(true);
      jcomp5.setBorder(raisedbevel);
      add(jcomp5, new Rectangle(4, 8, 4, 2));

      JButton jcomp6 = new JButton("6");
      jcomp6.addActionListener(new Button6Action());
      jcomp6.setEnabled(true);
      jcomp6.setBorder(raisedbevel);
      add(jcomp6, new Rectangle(8, 8, 4, 2));

      JButton jcomp7 = new JButton("7");
      jcomp7.addActionListener(new Button7Action());
      jcomp7.setEnabled(true);
      jcomp7.setBorder(raisedbevel);
      add(jcomp7, new Rectangle(0, 10, 4, 2));

      JButton jcomp8 = new JButton("8");
      jcomp8.addActionListener(new Button8Action());
      jcomp8.setEnabled(true);
      jcomp8.setBorder(raisedbevel);
      add(jcomp8, new Rectangle(4, 10, 4, 2));

      JButton jcomp9 = new JButton("9");
      jcomp9.addActionListener(new Button9Action());
      jcomp9.setEnabled(true);
      jcomp9.setBorder(raisedbevel);
      add(jcomp9, new Rectangle(8, 10, 4, 2));

      JButton jcompStar = new JButton("*");
      jcompStar.addActionListener(new ButtonStarAction());
      jcompStar.setEnabled(true);
      jcompStar.setBorder(raisedbevel);
      add(jcompStar, new Rectangle(0, 12, 4, 2));

      JButton jcomp0 = new JButton("0");
      jcomp0.addActionListener(new ButtonZeroAction());
      jcomp0.setEnabled(true);
      jcomp0.setBorder(raisedbevel);
      add(jcomp0, new Rectangle(4, 12, 4, 2));

      JButton jcompPound = new JButton("#");
      jcompPound.addActionListener(new ButtonPoundAction());
      jcompPound.setBorder(raisedbevel);
      jcompPound.setEnabled(true);
      add(jcompPound, new Rectangle(8, 12, 4, 2));

   }

   //---------------------------------------------------------------------------------

   /**
    * Finds the indexed item in DenimListBox and highlight the item
    * @param index -- a single digit
    */
   public void displaySelectedItem(int index) {
      // Assumes that the first element in the sheet is the panel
      assert runSheet.numElements()
         == 1 : "RunSheet does not have only one child";

      if (index < 1 || index > 9) {
         throw new IllegalArgumentException(
                "Error: Invalid argument at displaySelectedItem in MobilePanelTest");
      }

      DenimPanel dp = (DenimPanel) runSheet.get(0);
      DenimSketch ds = dp.getSketch();

      Iterator it = ds.getForwardIterator();
      boolean found = false;
      Object obj = null;
      while (it.hasNext() && !found) {
         obj = it.next();
         if (obj instanceof DenimListBoxInstance) {
            found = true;
         }
      }

      if (found) {
         ((DenimListBoxInstance) obj).setSelectedIndex(index);
      }

   }

   //--------------------------------------------------------------------------

   /**
    * Highlights the selected item via pressing navigation buttons
    * @param up -- True if pressing Navigation Up button;
    *  false if pressing Navigation Down button.
    */
   public void displayNavItem(boolean up) {
      // Assumes that the first element in the sheet is the panel
      assert runSheet.numElements()
         == 1 : "RunSheet does not have only one child";

      DenimPanel dp = (DenimPanel) runSheet.get(0);
      DenimSketch ds = dp.getSketch();

      Iterator it = ds.getForwardIterator();
      boolean found = false;
      Object obj = null;
      while (it.hasNext() && !found) {
         obj = it.next();
         if (obj instanceof DenimListBoxInstance) {
            found = true;
         }
      }

      if (found) {

         int selectedIndex = ((DenimListBoxInstance) obj).getSelectedIndex();
         int size = ((DenimListBoxInstance) obj).getItems().numElements();
         if (up) {
            selectedIndex--;
            if (selectedIndex < 0) {
               selectedIndex = 0;
            }
         } else {
            selectedIndex++;
            if (selectedIndex >= size)
               selectedIndex = size - 1;
         }
         displaySelectedItem(selectedIndex+1);
      }
   }

   //---------------------------------------------------------------------
   //--------  Twelve Inner classes, one for each button -----------------
   //--------  on a denim mobile panel   ---------------------------------
   //---------------------------------------------------------------------

      class Button1Action implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem(1);
         }
      }

      //------------------------------------------------------------------

      class Button2Action implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem(2);
         }
      }

      //------------------------------------------------------------------

      class Button3Action implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem(3);
         }
      }

      //------------------------------------------------------------------

      class Button4Action implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem(4);
         }
      }

      //------------------------------------------------------------------

      class Button5Action implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem(5);
         }
      }

      //------------------------------------------------------------------

      class Button6Action implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem(6);
         }
      }

      //------------------------------------------------------------------

      class Button7Action implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem(7);
         }
      }

      //------------------------------------------------------------------

      class Button8Action implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem(8);
         }
      }

      //------------------------------------------------------------------

      class Button9Action implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem(9);
         }
      }

      //------------------------------------------------------------------

      class ButtonStarAction implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem('*');
         }
      }

      //------------------------------------------------------------------

      class ButtonZeroAction implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem(0);
         }
      }

      //------------------------------------------------------------------

      class ButtonPoundAction implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displaySelectedItem('#');
            // See above comment
         }
      }

      //------------------------------------------------------------------

      class NavUpAction implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displayNavItem(true);
         }
      }

      //------------------------------------------------------------------

      class NavDownAction implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            displayNavItem(false);
         }
      }

}
