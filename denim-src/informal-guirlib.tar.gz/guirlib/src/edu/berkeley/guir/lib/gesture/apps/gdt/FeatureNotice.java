package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.util.Collections;
import java.util.List;
import edu.berkeley.guir.lib.gesture.*;

public class FeatureNotice extends DefaultNotice {
  protected Feature feature;
  protected int direction;
  protected GestureObject relatedGObject;

  /** direction is negative if the feature is too low, positive if
      it is too high */
  public FeatureNotice(Feature f, GestureObject relatedObj, int direction)
  {
    feature = f;
    this.direction = direction;
    relatedGObject = relatedObj;
  }

  protected void displayImpl(SummaryLog log)
  {
    log.append("This gesture is different from its gesture category mostly because its ");
    log.appendLink(feature.getName(), referenceListener,
		   "Get an explanation for this feature");
    String directionString = (direction < 0) ? "low" : "high";
    log.append(" is too " + directionString + ".");
  }

  protected void displaySummaryImpl(SummaryLog log)
  {
    log.appendLink(feature.getName(), referenceListener,
		   "Get an explanation for this feature");
    String directionString = (direction < 0) ? "low" : "high";
    log.append(": too " + directionString);
  }

  public String getName()
  {
    return "Feature";
  }

  public String getReferenceTag()
  {
    String fullClassName = feature.getClass().getName();
    return fullClassName.substring(fullClassName.lastIndexOf('.')+1);
  }

  public List getObjectList()
  {
    return Collections.singletonList(relatedGObject);
  }
}

