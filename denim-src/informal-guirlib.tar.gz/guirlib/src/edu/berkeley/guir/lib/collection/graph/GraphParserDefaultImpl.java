//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

/**
 * Parser for a Graph.
 * Here is an example:
 * <PRE>
 * NODES
 * UNDIRECTED-EDGES
 * 2230, 2A
 * 2203, 2A
 * 2A, 2L
 * 2A, 2B
 * 2232, 2B
 * 2234, 2B
 * 2B, 2C
 * 2236, 2C
 * 2238, 2C
 * 2C, 2D
 * 2D, 2E
 * 2242, 2E
 * 2246, 2E
 * </PRE>
 * In this case, the edges are undirected. The reason NODES is empty is because
 * it is redundant. This is for cases where there are unlinked nodes. You can
 * add the same nodes under NODES if you want, but it's redundant.
 * <P>
 * Here is an example of directed edges:
 * <PRE>
 * NODES
 * EDGES
 * 2230, 2A
 * 2203, 2A
 * 2A, 2L
 * 2A, 2B
 * </PRE>
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.5/1.0.0, Nov 22 2002, JH
 *               Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.1.4
 * @version GUIRLib-v1.5/1.0.0, Nov 22 2002
 */
public class GraphParserDefaultImpl
    implements GraphParser {

    //==========================================================================
    //===   CONSTANTS   ========================================================
    
    /**
     * Keyword in graph file for start of nodes.
     */
    private static final String NODES            = "NODES";

    /**
     * Keyword in graph file for start of directed edges.
     */
    private static final String EDGES            = "EDGES";

    /**
     * Keyword in graph file for start of undirected edges.
     */
    private static final String UNDIRECTED_EDGES = "UNDIRECTED-EDGES";

    //===   CONSTANTS   ========================================================
    //==========================================================================





    //==========================================================================
    //===   PARSING METHODS   ==================================================

    protected Graph createNewGraph() {
        return (new Graph());
    } // of method

    //----------------------------------------------------------------

    public Graph parse(Reader rdr) 
        throws IOException {

        return (parse(rdr, GraphNode.PARSER, GraphEdge.PARSER));
    } // of method

    //----------------------------------------------------------------

    public Graph parse(Reader          rdr, 
                       GraphNodeParser nparser, 
                       GraphEdgeParser eparser)
        throws IOException {

        BufferedReader brdr;                            // graph data to parse
        Graph          g            = createNewGraph(); // graph to return
        boolean        flagNodes    = true;             // parsing nodes/edges?
        boolean        flagDirected = true;

        //// 1. Buffer the reader.
        if (rdr instanceof BufferedReader) {
            brdr = (BufferedReader) rdr;
        }
        else {
            brdr = new BufferedReader(rdr);
        }

        //// 2. Start your parsing!
        String    strLine;
        GraphNode node;
        GraphEdge edge;

        while ((strLine = brdr.readLine()) != null) {
            //// 2.1. Start parsing Nodes.
            if (NODES.equals(strLine)) {
                flagNodes = true;
            }
            //// 2.2. Start parsing Edges.
            else if (EDGES.equals(strLine)) {
                flagNodes    = false;
                flagDirected = true;
            }
            else if (UNDIRECTED_EDGES.equals(strLine)) {
                flagNodes    = false;
                flagDirected = false;
            }
            else {
                //// 2.3. Parse a node.
                if (flagNodes == true) {
                    node = nparser.parse(strLine);
                    g.addNode(node);
                }
                //// 2.4. Parse an edge.
                else {
                    edge = eparser.parse(strLine);
                    if (flagDirected == true) {
                        g.addDirectedEdge(edge);
                    }
                    else {
                        g.addUndirectedEdge(edge);
                    }
                }
            }
        }

        //// 3. Return.
        return (g);
    } // of method

    //===   PARSING METHODS   ==================================================
    //==========================================================================

} // of interface

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
