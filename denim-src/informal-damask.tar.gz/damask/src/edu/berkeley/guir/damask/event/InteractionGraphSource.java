package edu.berkeley.guir.damask.event;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionGraph;

/** 
 * A source of InteractionGraphEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-12-2004 James Lin
 *                               Created InteractionGraphSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-12-2004
 */
public class InteractionGraphSource {
   
   private Vector/*<InteractionGraphListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified listener to receive events from this graph.
    */
   public synchronized void addInteractionGraphListener(
      final InteractionGraphListener listener) {

      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified listener so that it no longer receives
    * events from this graph.
    */
   public synchronized void removeInteractionGraphListener(
      final InteractionGraphListener listener) {

      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires homePageChanged events to listeners.
    */
   public void fireHomePageChanged(
      final InteractionGraph graph,
      final DeviceType deviceType) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final InteractionGraphEvent event =
         new InteractionGraphEvent(
            graph,
            InteractionGraphEvent.HOME_PAGE_CHANGED,
            deviceType);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final InteractionGraphListener listener =
            (InteractionGraphListener)i.next();

         listener.homePageChanged(event);
      }
   }
}
