//// See bottom of source code for license.
package edu.berkeley.guir.lib.io;

import java.io.File;

/**
 * Miscellaneous file libraries, for manipulating files, directories, and
 * class files.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Jan 07 2004, JH
 */
public class FileLib {

   //===========================================================================
   //===   FILE CONSTANTS   ====================================================

   /**
    * HTTP file protocol header.
    */
   public final static String    FILE_PROTOCOL     = "file:////";

   /**
    * File extension for serialized files.
    */
   public final static String    SERIALIZED_EXT    = ".ser";

   /**
    * File extension for zip files.
    */
   public final static String    ZIP_EXT           = ".zip";

   /**
    * File extension for Java class files.
    */
   public final static String    CLASS_EXT         = ".class";

   private final static String DEFAULT_ROOT = "file";
   private final static String DEFAULT_EXT  = "tmp";

   //===   FILE CONSTANTS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   private static int iFileCount = 0;       // used for generating files

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * No instances of this class allowed.
    */
   private FileLib() {
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   URL METHODS   =======================================================

   /**
    * Given a path name in the file system, convert it to a URL.
    *
    * @param  strName is the name of the file (or path) to convert.
    * @return Returns the URL of this file.
    */
   public static String fileNameToURL(String strName) {
      return(FILE_PROTOCOL + strName);
   } // of fileNameToURL

   //-----------------------------------------------------------------

   /**
    * Given a URL to a file in the local file system, convert it to the file
    * name.
    *
    * @param  strName is the URL.
    * @return Returns the file name.
    */
   public static String URLToFileName(String strName) {
      if (strName.startsWith(FILE_PROTOCOL)) {
         return(strName.substring(FILE_PROTOCOL.length()));
      }
      return(strName);
   } // of fileNameToURL

   //-----------------------------------------------------------------

   /**
    * Convert the filename (or path) from the local system format to an
    * http-like format. For example, given "c:\temp\filename.txt" in MSDOS, 
    * convert it to "c:/temp/filename.txt".
    *
    * @param  strName is the name of the file (or path) to convert.
    * @return Returns a String containing the network name of the file.
    */
   public static String localNameToNetworkName(String strName) {
      //// 1. Adjust the class name to the network environment
      return(strName.replace(File.separatorChar, '/'));
   } // of localNameToNetworkName

   //-----------------------------------------------------------------

   /**
    * Convert the filename (or path) from an http-like format to the local 
    * system format. For example, given "/tmp/filename.txt" convert it to
    * to "\tmp\filename.txt" on MS-DOS.
    *
    * @param  strName is the name of the file (or path) to convert.
    * @return Returns a String containing the network name of the file.
    */
   public static String networkNameToLocalName(String strName) {
      //// 1. Adjust the class name to the network environment
      return(strName.replace('/', File.separatorChar));
   } // of networkNameToLocalName

   //===   URL METHODS   =======================================================
   //===========================================================================



   //===========================================================================
   //===   UTILITY METHODS   ===================================================

   /**
    * Ensure that the filename ends with the specified extension.
    *
    * @param  strFileName  is the name of the file.
    * @param  strExtension is the file extension, e.g. "gif" or "dat".
    * @return a String that ends with strExtension.
    */
   public static String 
   addFileNameExtension(String strFileName, String strExtension) {
      if (!strFileName.endsWith(strExtension)) {
         return (strFileName + "." + strExtension);
      }
      return (strFileName);
   } // of addFileNameExtension

   //-----------------------------------------------------------------

   /**
    * Ensure that the filename ends with the specified extension.
    *
    * @see #addFileNameExtension(String, String)
    */
   public static String addFileNameExtension(File f, String strExtension) {
      return (addFileNameExtension(f.getAbsolutePath(), strExtension));
   } // of addFileNameExtension

   //-----------------------------------------------------------------

   /**
    * Given the name of a file, get the file extension. Assumes that 
    * the period ('.') is used as the extension.
    *
    * @param  strFileName is the name of the file.
    * @return a String containing the extension of the file (without the
    *         period).
    */
   public static String getFileNameExtension(String strFileName) {
      int periodLocation = strFileName.lastIndexOf('.');

      if (periodLocation >= 0) {
         return (strFileName.substring(periodLocation + 1));
      }
      return ("");
   } // of getFileNameExtension

   
   //-----------------------------------------------------------------

   /**
    * Removes the file extension from the name of a file, if it has one.
    * Assumes that anything after the last period (".") is the extension.
    *
    * @param  strFileName is the name of the file.
    */
   public static String removeFileNameExtension(String strFileName) {
      int periodLocation = strFileName.lastIndexOf('.');

      if (periodLocation >= 0) {
         return (strFileName.substring(0, periodLocation));
      }
      return ("");
   } // of getFileNameExtension

   //-----------------------------------------------------------------

   /**
    * Given the name of a local file, get the absolute path of that file.
    *
    * @param  strFileName is the name of a file on the local system (using
    *         local values for filename and path separators).
    * @return Returns the local path of the file.
    */
   public static String getFilePath(String strFileName) {

      File   file    = new File(strFileName);
      String strPath = file.getAbsolutePath();

      return (strPath.substring(0, strPath.length() - strFileName.length()));

   } // of getFilePath

   //-----------------------------------------------------------------

   /**
    * Fixes a file name to conform to the zip file format.
    *
    * @param  strFileName is the name of the file. For example, in
    *         MS-DOS, strFileName could be "\temp\myfile.doc".
    * @return Returns a String that has the local directory separator
    *         replaced with a '/'. For example, given "\temp\myfile.doc", it
    *         returns "/temp/myfile.doc".
    */
   public static String localNameToZip(String strFileName) {
      //// 1. Adjust the file name to the zip format
      return (localNameToNetworkName(strFileName));
   } // of localNameToZip

   //-----------------------------------------------------------------

   /**
    * Generate a unique filename in the current directory. It will be of the
    * form "file#.tmp".
    *
    * @return A unique filename that does not exist in the current directory.
    */
   public static String generateUniqueFileName() {
      return( generateUniqueFileName( DEFAULT_ROOT, DEFAULT_EXT ) );
   } // of generateUniqueFileName

   //-----------------------------------------------------------------

   /**
    * Generate a unique filename in the current directory.
    *
    * @param  strRoot is the base of the file.
    * @param  strExt is the filename extension, "" for no extension.
    *         
    * @return A unique filename that does not exist in the current directory.
    */
   public static String generateUniqueFileName(String strRoot, 
                                               String strExt) {
      return ( generateUniqueFileName("", strRoot, strExt) );
   } // of generateUniqueFileName

   //-----------------------------------------------------------------

   /**
    * Generate a unique filename in the specified directory. It will be of the
    * form "file#.tmp". Creates the directory if necessary.
    *
    * @param  strPath is the base path of the file. Use "" for current
    *         directory. Can end with or without trailing slash, like
    *         "/etc/" or "/bin".
    * @param  strRoot is the base of the file, "" for no extension.
    * @param  strExt is the filename extension, "" for no extension. 
    *         For example, ".gif" or ".exe".
    * @return A unique filename that does not exist in the specified directory.
    */
   public static synchronized String 
   generateUniqueFileName(String strPath, String strRoot, String strExt) {

      boolean done            = false;  // have we found a unique filename yet?
      String  strFileNameTemp = null;   // temporary file name
      File    tempFile;                 // dummy file variable

      //// 1. Adjust the path name to the local system.
      ////    Also make sure the path ends with the separator
      ////    For example, it should be of the form /tmp/transport/
      strPath = networkNameToLocalName(strPath);
      if ( !(strPath.equals("") || strPath.endsWith(File.separator)) )
         strPath += File.separator;

      //// 2. Add in the "." for extensions if it doesn't have one already
      if ( !strExt.equals("") )
         if ( strExt.charAt(0) != '.' )
            strExt = "." + strExt;

      //// 3. Create the directory that the file should be in.
      tempFile = new File(strPath);
      tempFile.mkdirs();

      //// 4. Generate a unique name in that directory
      while ( !done ) {
         strFileNameTemp = strPath + strRoot + iFileCount + strExt;
         tempFile        = new File(strFileNameTemp);
         done            = !tempFile.exists();
         iFileCount++;
      }

      return( strFileNameTemp );

   } // of generateUniqueFileName

   //===   UTILITY METHODS   ===================================================
   //===========================================================================



   //===========================================================================
   //===   DIRECTORY METHODS   =================================================

   /**
    * Get the name of all of the files in the current working directory.
    * This requires security access to system property "user.dir".
    *
    * @return    An array of Strings that contains the name of the files in
    *            the current directory.
    * @exception Throws SecurityException if access to "user.dir" is denied.
    */
   public static String[] getFilesInCurrentDirectory() {

      //// 1. Get the current directory
      String strCurrentDir = System.getProperty("user.dir");

      //// 2. Retrieve.
      return(getFilesInDirectory(strCurrentDir));

   } // of getFilesInCurrentDirectory

   //-----------------------------------------------------------------

   /**
    * Get the name of all of the files in the specified directory.
    *
    * @return    An array of Strings that contains the name of the files in
    *            the current directory. 
    */
   public static String[] getFilesInDirectory(String strDir) {
      //// 1. Convert to a File object
      File fileCurrentDir = new File(strDir);

      //// 2. Get the files in this directory
      String[] strFileNameArray = fileCurrentDir.list();

      //// 3. If there are no files, return an empty array.
      if (strFileNameArray == null) {
         strFileNameArray = new String[0];
      }

      return(strFileNameArray);
   } // of getFilesInDirectory

   //===   DIRECTORY METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS FILE METHODS   ================================================

   /**
    * Drop the ".class" extension (if it exists).
    *
    * @param  strClassName is the name of a class (with or without package 
    *         names included).
    * @return The name of the class without the extension.
    */
   public static String stripClassExtension(String strClassName) {

      //// 1. See if it ends with ".class" or not
      ////    if it does, get rid of the ".class" extension temporarily
      if ( strClassName.endsWith(CLASS_EXT))
         strClassName = strClassName.substring(0, strClassName.length() - 6);

      return (strClassName);

   } // of stripClassExtension

   //-----------------------------------------------------------------

   /**
    * See if the String ends with the ".class" extension.
    *
    * @param  strClassName is the name of a class (with or without package 
    *         names included).
    * @return true if it ends in ".class", false otherwise.
    */
   public static boolean hasClassExtension(String strClassName) {

      //// 1. See if it ends with ".class" or not
      ////    if it does, get rid of the ".class" extension temporarily
      if ( strClassName.endsWith(CLASS_EXT))
         return (true);

      return (false);

   } // of hasClassExtension

   //-----------------------------------------------------------------

   /**
    * Fixes the class file name to the local system so it can be searched for
    * in the local system.
    *
    * @param  strClassName is the name of the Class to find in the form
    *         of "java.lang.Object" or "Object.class".
    * @return Returns a String that has the '.' replaced with the local
    *         directory separator and tags ".class" on to the end. For example,
    *         "java/lang/Object.class".
    */
   public static String classNameToLocalSystem(String strClassName) {

      //// 1. See if it ends with ".class" or not
      ////    if it does, get rid of the ".class" extension temporarily
      strClassName = stripClassExtension(strClassName);

      //// 2. Adjust the class name to the local environment
      strClassName = strClassName.replace('.', File.separatorChar);

      //// 3. Reappend ".class" extension
      strClassName += CLASS_EXT;

      return ( strClassName );

   } // of classNameToLocalSystem

   //-----------------------------------------------------------------

   /**
    * Given a fully qualified class name, extract the class name out of it.
    *
    * @param  strFullClassName is the fully qualified class name, including
    *         packages. For example, "java.lang.Object" or
    *         "java.lang.Object.class".
    * @return Returns the class name. For example, given "java.lang.Object"
    *         or "java.lang.Object.class" it returns "Object".
    */
   public static String getClassName(String strFullClassName) {

      int     iLastPosPeriod;
      String  strTemp;
      String  strReturn;

      //// 1. See if it ends with ".class" or not
      ////    if it does, get rid of the ".class" extension
      strTemp = stripClassExtension(strFullClassName);

      //// 2. Find the position of the last period '.'
      iLastPosPeriod = strTemp.lastIndexOf('.');

      //// 3. If there is no period '.' then no package name and return
      ////    original String passed in (the +1 is b/c lastIndexOf() returns -1
      ////    if it cannot find a period.
      ////    Otherwise, find last period '.' and take class name.
      strReturn = strTemp.substring(iLastPosPeriod + 1);

      return (strReturn);

   } // of getClassName

   //-----------------------------------------------------------------

   /**
    * Given a fully qualified class name, extract the package name out of it.
    *
    * @param  strFullClassName is the fully qualified class name, including
    *         packages. For example, "java.lang.Object" or
    *         "java.lang.Object.class".
    * @return Returns the package name. For example, given "java.lang.Object",
    *         it returns "java.lang". Given "Object", it returns an empty 
    *         String "".
    */
   public static String getPackageName(String strFullClassName) {

      String strReturn;
      int    iLastPosPeriod;

      //// 1. See if it ends with ".class" or not
      ////    if it does, get rid of the ".class" extension temporarily
      strFullClassName = stripClassExtension(strFullClassName);
      
      //// 2. Find the position of the last period '.'
      iLastPosPeriod = strFullClassName.lastIndexOf('.');

      //// 3. If there is no period '.' then no package name. Return empty.
      if (iLastPosPeriod < 0)
         return ("");

      //// 4. If there was a period '.', then lop off the end
      strReturn = strFullClassName.substring(0, iLastPosPeriod);

      return(strReturn);

   } // of getPackageName

   //-----------------------------------------------------------------

   /**
    * Given the fully qualified name of a class, get the directory of the
    * package.
    *
    * @param  strFullClassName is the fully qualified class name, including
    *         packages. For example, "java.lang.Object" or
    *         "java.lang.Object.class".
    * @return Returns the package name. For example, given "java.lang.Object",
    *         it returns "java/lang/". Given "Object", it returns an empty 
    *         String "".
    */
   public static String getPackageDirectory(String strFullClassName) {

      String strPackageName;

      //// 1. Get the package name
      strPackageName = getPackageName(strFullClassName);

      //// 2. Make sure it's not an empty package name
      if ( strPackageName.equals("") )
         return ("");

      //// 3. Convert it to a directory name
      strPackageName = strPackageName.replace('.', File.separatorChar);

      //// 4. Append a final directory marker
      strPackageName += File.separator;

      return (strPackageName);

   } // of getPackageDirectory

   //===   CLASS FILE METHODS   ================================================
   //===========================================================================


   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static void main(String[] argv) {

      System.out.println(fileNameToURL("d:/jason/PrinterBoard"));
      System.out.println(URLToFileName("file://d:/jason/PrinterBoard"));

      System.out.println(getFileNameExtension("file.exe"));
      System.out.println(getFileNameExtension("file.exe.com"));
      System.out.println(getFileNameExtension("file.txt"));
      System.out.println(getFileNameExtension("file..txt.pdf.ps"));
      System.out.println(getFileNameExtension("files"));

      System.out.println(generateUniqueFileName("d:/jason/PrinterBoard", "", ".gif"));
      System.out.println(generateUniqueFileName("d:/jason/PrinterBoard/", "", "gif"));
   }
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
