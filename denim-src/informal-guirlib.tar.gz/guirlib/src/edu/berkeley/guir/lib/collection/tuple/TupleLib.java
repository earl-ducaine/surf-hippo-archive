//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tuple;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import edu.berkeley.guir.lib.collection.HashMapList;

/**
 * Library methods for Tuples.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Dec 15 2002 JIH
 */
public class TupleLib {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    private static final boolean DEBUG = false;

    //----------------------------------------------------------------

    /**
     * An immutable empty Tuple.
     */
    public static final Tuple EMPTY = new EmptyTuple();

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY - LIST OPERATIONS   ========================================

    /**
     * Given a List of Tuples, create a new wrapper tuple that contains
     * all of them. For example, given a bunch of DOG tuples, create
     * a new tuple that represents DOGS which contains the number of
     * tuples and all of the original DOG tuples.
     *
     * <P>
     * Reverse this operation by calling tupleToList()
     *
     * @param strListName is the name of the containing Tuple
     * @param listTuples  is a List of Tuple instances
     */
    public static Tuple listToTuple(String strListName, List listTuples) {
        Tuple t = new Tuple(strListName);
        t.setDynamicSize(true);
        t.addTuples(listTuples);
        return (t);
    } // of method

    //----------------------------------------------------------------

    /**
     * Given a Tuple that contains other tuples, extract the contained tuples.
     * <P>
     * Reverse this operation by calling listToTuple()
     */
    public static List tupleToList(Tuple t) {
        return (t.getTuples());
    } // of method

    //===   UTILITY - LIST OPERATIONS   ========================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY - LIST EXTRACTION METHODS   ================================

    /**
     * Extract the specified attribute from a List of Tuples, 
     * returning a List of String. Null values pruned out.
     */
    public static List extractAttribute(List listTuples, String strAttr) {
        Iterator it = listTuples.iterator();
        Tuple    t;
        String   strVal;
        List     listAttributes = new LinkedList();

        while (it.hasNext()) {
            t      = (Tuple) it.next();
            strVal = t.getAttribute(strAttr);
            if (strVal != null) {
                listAttributes.add(strVal);
            }
        }
        return (listAttributes);
    } // of method

    //----------------------------------------------------------------

    /**
     * Extract the specified xpath from a List of Tuples, 
     * returning a List of String. Null values pruned out.
     */
    public static List extractXPath(List listTuples, String strXPath) {
        Iterator it = listTuples.iterator();
        Tuple    t;
        String   strVal;
        List     listXPaths = new LinkedList();

        while (it.hasNext()) {
            try {
                t      = (Tuple) it.next();
                strVal = t.getXPath(strXPath);
                if (strVal != null) {
                    listXPaths.add(strVal);
                }
            }
            catch (Exception e) {
                // ignore
                e.printStackTrace();
            }
        }
        return (listXPaths);
    } // of method

    //----------------------------------------------------------------

    /**
     * Given a List of Tuples of type Location, go through them
     * and eliminate duplicates on the specified field. For example,
     * suppose we had the following list:
     * <PRE>
     *  [&lt;Location CityName="Berkeley"
     *         CountryCode="USA"
     *          RegionCode="CA"
     *             ZIPCode="94709"
     *            distance="0.6727996028070231"
     *                 lat="37.8784"
     *                 lon="-122.2655" /&gt;,
     *   &lt;Location CityName="Kensington"
     *         CountryCode="USA"
     *          RegionCode="CA"
     *             ZIPCode="94707"
     *            distance="1.6337797953079822"
     *                 lat="37.8931"
     *                 lon="-122.2765" /&gt;,
     *   &lt;Location CityName="Berkeley"
     *         CountryCode="USA"
     *          RegionCode="CA"
     *             ZIPCode="94703"
     *            distance="1.7503613286733137"
     *                 lat="37.863"
     *                 lon="-122.2749" /&gt;, ]
     * </PRE>
     *
     * If we called this method on attribute <CODE>"CityName"</CODE>,
     * then we would keep the first instance of CityName "Berkeley"
     * but not the second.
     *
     * <P>
     * Assumes the List is already in some sort of sorted order.
     *
     * @param listTuples   is a List of Tuple instances
     * @param strAttribute is the attribute to be unique on
     */
    public static List unique(List listTuples, String strAttribute) {
        Set      setVals = new HashSet();  // set of values we have seen
        Iterator it      = listTuples.iterator();
        Tuple    t;
        String   strVal;
        List     listOut = new LinkedList();

        while (it.hasNext()) {
            t      = (Tuple) it.next();
            strVal = t.getAttribute(strAttribute);

            // If we already have it, skip and continue
            if (setVals.contains(strVal) == true) {
                continue;
            }
            // Otherwise, add it.
            else {
                listOut.add(t);
                setVals.add(strVal);
            }
        }

        return (listOut);
    } // of method

    //===   UTILITY - LIST EXTRACTION METHODS   ================================
    //==========================================================================




    //==========================================================================
    //===   UTILITY - INDEXING OPERATIONS   ====================================

    /**
     * Convert a list of Tuples into a Map of Lists, with key
     * defined as the value specified by the xpath. Null values returned
     * by applying the xpath is ok.
     * <P>
     * For example, you could specify an xpath to the date, and
     * the Map returned would have key values of unique dates, with values
     * being the Tuples that have that date.
     */
    public static HashMapList index(List listTuples, String strXPath) {
        HashMapList map = new HashMapList();
        Iterator    it  = listTuples.iterator();
        Tuple       t;
        String      strXPathVal;

        while (it.hasNext()) {
            try {
                t = (Tuple) it.next();
                strXPathVal = t.getXPath(strXPath);
                map.put(strXPathVal, t);
            }
            catch (Exception e) {
                // ignore
                if (DEBUG == true) {
                    e.printStackTrace();
                }
            }
        }

        return (map);
    } // of method

    //===   UTILITY - INDEXING OPERATIONS   ====================================
    //==========================================================================




    //==========================================================================
    //===   INNER CLASS - IMMUTABLE TUPLE WRAPPER   ============================

    /**
     * A wrapper that makes a Tuple immutable.
     * Throws UnsupportedOperationException for things it can't do.
     */
    public static class ImmutableTupleWrapper 
        extends TupleWrapper {

        //======================================================================
        //===   CONSTRUCTORS   =================================================

        public ImmutableTupleWrapper(Tuple t) {
            super(t);
        } // of constructor

        //===   CONSTRUCTORS   =================================================
        //======================================================================




        //======================================================================
        //===   MODIFIER METHODS   =============================================

        private void unsupported() {
            throw new UnsupportedOperationException("Immutable");
        } // of method

        //------------------------------------------------------------

        public void setTupleType(String str) {
            unsupported();
        } // of method

        public void setDynamicSize(boolean flag) {
            unsupported();
        } // of method

        public void setAttributes(Map map) {
            unsupported();
        } // of method

        public void setAttribute(String strKey, String strVal) {
            unsupported();
        } // of method

        public void clearAttributes() {
            unsupported();
        } // of method

        public void setTo(Tuple t) {
            unsupported();
        } // of method

        public void addTuples(List list) {
            unsupported();
        } // of method

        public void addTuple(Tuple tuple) {
            unsupported();
        } // of method

        public void clearTuples() {
            unsupported();
        } // of method

        public void removeTuple(Tuple t) {
            unsupported();
        } // of method

        //===   MODIFIER METHODS   =============================================
        //======================================================================

    } // of inner class

    //===   INNER CLASS - IMMUTABLE TUPLE WRAPPER   ============================
    //==========================================================================




    //==========================================================================
    //===   INNER CLASS - EMPTY TUPLE   ========================================

    /**
     * An immutable empty tuple.
     */
    public static final class EmptyTuple 
        extends Tuple {

        //======================================================================
        //===   CONSTRUCTORS   =================================================

        public EmptyTuple() {
            super("empty");
        } // of constructor

        //===   CONSTRUCTORS   =================================================
        //======================================================================




        //======================================================================
        //===   TUPLE TYPE METHODS   ===========================================

        public void setTupleType(String str) {
            super.setTupleType("empty");
        } // of method

        //===   TUPLE TYPE METHODS   ===========================================
        //======================================================================




        //======================================================================
        //===   SIZE METHODS   =================================================

        public void setDynamicSize(boolean flag) {
        } // of method

        //===   SIZE METHODS   =================================================
        //======================================================================




        //======================================================================
        //===   ATTRIBUTE METHODS   ============================================

        public void setAttributes(Map map) {
        } // of method

        public void setAttribute(String strKey, String strVal) {
        } // of method

        public void clearAttributes() {
        } // of method

        //===   ATTRIBUTE METHODS   ============================================
        //======================================================================




        //======================================================================
        //===   TUPLE METHODS   ================================================

        public void addTuples(List list) {
        } // of method

        public void addTuple(Tuple tuple) {
        } // of method

        public void clearTuples() {
        } // of method

        public void removeTuple(Tuple t) {
        } // of method

        //===   TUPLE METHODS   ================================================
        //======================================================================

    } // of inner class

    //===   INNER CLASS - EMPTY TUPLE   ========================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static List getTestInstanceAAA() {
        List  listTuples = new LinkedList();
        Tuple t;

        t = new Tuple("Location");
        t.setAttribute("CityName", "Berkeley");
        t.setAttribute("ZIPCode",  "94709");
        listTuples.add(t);

        t = new Tuple("Location");
        t.setAttribute("CityName", "Kensington");
        t.setAttribute("ZIPCode",  "94707");
        listTuples.add(t);

        t = new Tuple("Location");
        t.setAttribute("CityName", "Berkeley");
        t.setAttribute("ZIPCode",  "94703");
        listTuples.add(t);

        return (listTuples);
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        System.out.println(getTestInstanceAAA());
        System.out.println();
        System.out.println(unique(getTestInstanceAAA(), "CityName"));
        System.out.println();
        System.out.println(unique(getTestInstanceAAA(), "ZIPCode"));
        System.out.println();
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
