package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.component.Select;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that adds an item to a select-one or select-many control.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  10-22-2003 James Lin
 *                               Created AddControlCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 10-22-2003
 */
public class AddItemCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private static final int DEFAULT_INDEX = -1;
   
   private final Select control;
   private final int index;
   private final Select.Item item;
   
   /**
    * Constructs the command.
    *  
    * @param control the control to add the item to
    * @param index the position to add the item
    * @param item the item to add
    */      
   public AddItemCommand(
      final Select control,
      final int index,
      final Select.Item item) {

      this.control = control;
      this.index = index;
      this.item = item;
   }
   
   /**
    * Constructs the command.
    *  
    * @param control the control to add the item to
    * @param item the item to add
    */      
   public AddItemCommand(final Select control, final Select.Item item) {
      this(control, DEFAULT_INDEX, item);
   }


   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Add " + item.toLongString() + " to " + control;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      if (index == DEFAULT_INDEX) {
         control.addItem(item);
      }
      else {
         control.addItem(index, item);
      }
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      control.removeItem(item);
   }
}
