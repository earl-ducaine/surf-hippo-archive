package edu.berkeley.guir.damask.userevent;

/** 
 * An event which indicates that a pen or mouse has stopped hovering over
 * a UI object.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-05-2003 James Lin
 *                               Created HoverOffEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-05-2003
 */
public class HoverOffEvent extends DamaskUserEvent {
   public HoverOffEvent(Object source) {
      super(source);
   }

   // @Override
   public DamaskUserEvent createCopy(Object source) {
      return new HoverOffEvent(source);
   }
}
