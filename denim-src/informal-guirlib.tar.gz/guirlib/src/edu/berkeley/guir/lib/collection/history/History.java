//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.history;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * A collection of HistoryEvents.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Jan 30 2004
 */
public interface History {

    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    /**
     * Add a single event.
     * <P>
     * Note that a HistoryEvent might not appear if the
     * Comparator value for this History returns 0 (ie the specified
     * event is equal to another already in here). A common example
     * of this is creating two HistoryEvents such that they have the
     * same time. The Comparator says the two are equal, so only
     * one is actually inserted.
     */
    public void addEvent(HistoryEvent evt);

    //--------------------

    /**
     * Add all events.
     */
    public void addAllEvents(History history);

    //--------------------

    /**
     * @param events is a List of HistoryEvent instances.
     */
    public void addAllEvents(Collection events);

    //--------------------

    /**
     * @param it is an Iterator of HistoryEvent instances to add.
     */
    public void addAllEvents(Iterator it);

    //----------------------------------------------------------------

    /**
     * Remove a specific event.
     */
    public void removeEvent(HistoryEvent evt);

    //--------------------

    /**
     * Remove the index'th event.
     * Not efficient, O(N) implementation.
     */
    public void removeEvent(int index);

    //----------------------------------------------------------------

    /**
     * Clear out all events.
     */
    public void clearEvents();

    //----------------------------------------------------------------

    /**
     */
    public boolean containsEvent(HistoryEvent evt);

    //----------------------------------------------------------------

    /**
     * Get the index'th event.
     * Not efficient, O(N) implementation.
     */
    public HistoryEvent getEvent(int index);

    //----------------------------------------------------------------

    /**
     * @return the number of HistoryEvent objects contained
     */
    public int size();

    //----------------------------------------------------------------

    /**
     * @return an Iterator of HistoryEvent objects. There is no
     *         guaranteed order, sort first if desired.
     */
    public Iterator events();

    //--------------------

    /**
     * @param flagForward is true if want to go in regular forward order,
     *                    false to go in reverse order.
     */
    public Iterator events(boolean flagForward);

    //----------------------------------------------------------------

    /**
     * Get a copy of the History as a list.
     */
    public List asList();

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================



    //==========================================================================
    //===   COMMON QUERY METHODS   =============================================

    /**
     * Gets the first entry, which depends on how things are sorted.
     * By default, this returns the oldest.
     */
    public HistoryEvent getFirstEntry();

    //--------------------

    /**
     * Gets the last entry, which depends on how things are sorted.
     * By default, this returns the newest.
     */
    public HistoryEvent getLastEntry();

    //----------------------------------------------------------------

    /**
     * Get the first HistoryEvent that matches the specified field.
     * @param flagForward is true if we should go in forward order,
     *                      false if in reverse order.
     */
    public HistoryEvent getByField(boolean flagForward, 
                                   String  strField, 
                                   String  strVal);

    //===   COMMON QUERY METHODS   =============================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING METHODS   =================================================

    /**
     * Specifies how a HistoryEvent is printed out.
     */
    public String toString(HistoryEvent evt);

    //----------------------------------------------------------------

    public String toString();

    //----------------------------------------------------------------

    /**
     * Write out the data to a Writer. Useful, for example, 
     * in sending out to a ZIPStream for compression.
     * <P>
     * Does not <CODE>close()</CODE> the stream, you should do
     * that yourself.
     */
    public void toWriter(Writer wtr) 
        throws IOException;

    //===   TOSTRING METHODS   =================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
