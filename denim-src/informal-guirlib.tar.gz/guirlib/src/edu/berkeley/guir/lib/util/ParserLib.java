//// See bottom of source code for software license.
package edu.berkeley.guir.lib.util;

import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Simple parsing on common data types found in strings.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Jan 02 2004 JIH
 */
final public class ParserLib {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    private static final boolean DEBUG = false;

    //----------------------------------------------------------------

    /**
     * Typical delimiters when parsing.
     */
    public static final String DELIMITERS = " ,\t\n\r";

    //===   CONSTANTS   ========================================================
    //==========================================================================



    //==========================================================================
    //===   SPACE-SEPARATED PARSER   ===========================================

    /**
     * Parse a space separated value, ex: "A B C D E" into {"A","B", ...}.
     * Treats multiple spaces as a single space,
     * essentially the same behavior as StringTokenizer, but handles
     * quotes correctly, for example "Washington, DC" is a single
     * value despite the fact it has an internal space.
     */
    public static String[] parseSSV(String strLine) {
        return (parseByDelimiter(strLine, ' ', true));
    } // of method

    //===   SPACE-SEPARATED PARSER   ===========================================
    //==========================================================================



    //==========================================================================
    //===   TAB-SEPARATED PARSER   =============================================

    /**
     * Parse tab separated values.
     */
    public static String[] parseTSV(String strLine) {
        int    startIndex = 0;
        int    endIndex   = 0;
        int    len        = strLine.length();
        List   listToks   = new LinkedList();
        String strTmp;

        // System.out.println(strLine);

        //// 1. Parse.
        while (startIndex < len && endIndex < len) {
            endIndex = strLine.indexOf('\t', startIndex);
            if (endIndex < 0) {
                strTmp   = strLine.substring(startIndex);
                endIndex = len;
            }
            else {
                strTmp     = strLine.substring(startIndex, endIndex);
                startIndex = endIndex + 1;
            }
            listToks.add(strTmp);
        }

        //// 2. Special case if it ends with a comma.
        if (strLine.endsWith("\t")) {
            listToks.add("");
        }

        //// 3. Return.
        if (DEBUG == true) {
            System.out.println(listToks + " " + listToks.size());
            Iterator it = listToks.iterator();
            while (it.hasNext()) {
                System.out.println("   " + it.next());
            }
        }

        return (String[]) (listToks.toArray(new String[0]));
    } // of method

    //===   TAB-SEPARATED PARSER   =============================================
    //==========================================================================



    //==========================================================================
    //===   CSV PARSER   =======================================================

    /**
     * Parse a comma separated value, ex: "A,B,C,D,E" into {"A","B", ...}.
     * Works correctly for blank values (unlike StringTokenizer),
     * for example "A,,C" is saved as three values and "A,B," is also
     * three values.
     * <P>
     * Also handles quotes right, for example "Washington, DC" is a single
     * value despite the fact it has an internal comma.
     * @see edu.berkeley.guir.lib.util.StringLib#toCSV(String[])
     */
    public static String[] parseCSV(String strLine) {
        return (parseByDelimiter(strLine, ',', false));
    } // of method

    /**
     * Parse a String by the specified delimiter. Tokens containing
     * the delimiter should be surrounded with quotes (").
     * @param strLine      is the line to parse
     * @param chDelimiter  is the delimiter to parse on
     * @param flagCoalesce is whether to coalesce multiple delimiters as one
     *                     (true) or to treat each one as one (false).
     * @see #parseCSV(String)
     */
    public static String[] parseByDelimiter(String  strLine, 
                                            char    chDelimiter,
                                            boolean flagCoalesce) {
        int    startIndex = 0;
        int    endIndex   = 0;
        int    len        = strLine.length();
        List   listToks   = new LinkedList();
        String strTmp;

        // System.out.println(strLine);

        //// Set startIndex to be the first non chDelimiter char
        if (flagCoalesce == true) {
            for (int i = 0; i < len; i++) {
                if (strLine.charAt(i) == chDelimiter) {
                    startIndex++;
                }
                else {
                    break;
                }
            }
        }

        //// 1. Go thru the String char by char...
        while (startIndex < len && endIndex < len) {
            //// 1.1. If we start with a quote, then jump to end of quote.
            if (strLine.charAt(startIndex) == '"') {
                startIndex++;
                endIndex   = strLine.indexOf('"', startIndex);
                strTmp     = strLine.substring(startIndex, endIndex);
                startIndex = endIndex + 2;
            }
            //// 1.2. Otherwise, find the next comma and jump there.
            else {
                //// Did we get to the end by coalescing and incrementing?
                boolean flagIncrementingEnd = false;

                endIndex = strLine.indexOf(chDelimiter, startIndex);

                //// 1.2.1. Treat consecutive instances of chDelimiter as one.
                while (flagCoalesce == true &&
                       0 <= endIndex && endIndex + 1 < len) {
                    if (strLine.charAt(endIndex + 1) == chDelimiter) {
                        endIndex++;
                    }
                    else {
                        break;
                    }

                    ///// We got to the end by incrementing.
                    if (endIndex + 1 >= len) {
                        flagIncrementingEnd = true;
                        break;
                    }
                }
                //// If we have reached the end of the String by incrementing,
                //// means no more tokens.
                if (flagCoalesce == true && flagIncrementingEnd == true &&
                    endIndex + 1 >= len) {
                    break;
                }



                //// 1.2.2. If did not find delimiter, means we are at the end.
                if (endIndex < 0) {
                    strTmp   = strLine.substring(startIndex);
                    endIndex = len;
                }
                //// Otherwise, copy it and move the startIndex over.
                else {
                    strTmp     = strLine.substring(startIndex, endIndex);
                    startIndex = endIndex + 1;
                }
            }
            listToks.add(strTmp);
        }

        //// 2. Special case if it ends with a comma.
        if (flagCoalesce == false && strLine.endsWith("" + chDelimiter)) {
            listToks.add("");
        }

        //// 3. Return.
        if (DEBUG == true) {
            System.out.println(listToks + " " + listToks.size());
            Iterator it = listToks.iterator();
            while (it.hasNext()) {
                System.out.println("   " + it.next());
            }
        }

        return (String[]) (listToks.toArray(new String[0]));
    } // of method

    //===   CSV PARSER   =======================================================
    //==========================================================================



    //==========================================================================
    //===   ARRAY PARSER   =====================================================

    /**
     * Given a String representing an array, figure out how big the
     * array should be.
     */
    private static int getArraySize(String str) {
        //// 1.   Calculate the size of the array to return.
        //// 1.1. Do this by first counting the number of commas.
        int size = StringLib.countNumOfChar(',', str);
 
        //// 1.2. Now see if the last character is a comma or not, since
        ////      arrays may or may not end with a comma.
        ////      If it is not, then increment the size by one.
        if (str.charAt(str.length() - 1) != ',') {
            size++;
        }
  
        return (size);
    } // of method

    //==========================================================================

    /**
     * @param  str looks like "1, 2, 3, 5" or "0,7,18,"
     * @return an array of ints.
     * @throws ParseException if there was a parsing error.
     */
    public final static int[] parseIntArray(String str) 
        throws ParseException {

        StringTokenizer strtok = new StringTokenizer(str, DELIMITERS);
        int             size;
        int[]           intArray;

        //// 1. Get the size of the array.
        str      = str.trim();
        size     = getArraySize(str);
        intArray = new int[size];

        //// 2. Now just go through the elements.
        for (int i = 0; i < size; i++) {
           intArray[i] = Integer.parseInt(strtok.nextToken());
        }

        return (intArray);
    } // of method

    //----------------------------------------------------------------

    /**
     * @param  str looks like "1.0, 2.0, 3.0, 2.5" or "2.0, 2.718,"
     * @return an array of floats.
     * @throws ParseException if there was a parsing error.
     */
    public final static float[] parseFloatArray(String str) 
        throws ParseException {

        StringTokenizer strtok = new StringTokenizer(str, DELIMITERS);
        int             size;
        float[]         fArray;

        //// 1. Get the size of the array.
        str    = str.trim();
        size   = getArraySize(str);
        fArray = new float[size];

        //// 2. Now just go through the elements.
        for (int i = 0; i < size; i++) {
            fArray[i] = Float.valueOf(strtok.nextToken()).floatValue();
        }

        return (fArray);
    } // of method

    //===   ARRAY PARSER   =====================================================
    //==========================================================================




    //==========================================================================
    //===   LIST PARSER   ======================================================

    /**
     * @param str is standard toString() for a List, for example
     *            "[location, activity]" or "[a, b, c, d, e, f, g]"
     * @return a List of Strings, properly parsed
     * @throws ParseException if there was a parsing error.
     */
    public final static List parseList(String str)
        throws ParseException {

        //// 1. Error checking.
        if (str.startsWith("[") == false || str.endsWith("]")   == false) {
            throw new ParseException("Not a valid List: " + str);
        }
        str = str.substring(1, str.length() - 1);

        //// 2. Tokenize.
        List            list   = new LinkedList();
        StringTokenizer strtok = new StringTokenizer(str, ", ");

        while (strtok.hasMoreTokens()) {
            list.add(strtok.nextToken());
        }

        //// 3. Done.
        return (list);
    } // of method

    //===   LIST PARSER   ======================================================
    //==========================================================================




    //==========================================================================
    //===   MAP PARSER   =======================================================

    /**
     * Parse things like the following as a Map.
     * <PRE>
     *    Date: 08/02/1999
     *    Name: John
     *    Occupation: Programmer
     *    Address: blah
     * </PRE>
     * @param str is the String to parse.
     * @param ch  is the dividing char, ex. ':' or '='
     */
    public static final Map parseAsMap(String str, char ch) {
       char[]          chArray = new char[] {ch, '\r', '\n'};
       StringTokenizer strtok  = new StringTokenizer(str, new String(chArray));
       Map             map     = new HashMap();
       String          strKey  = "";
       String          strVal  = "";
       boolean         flagParsingName = true;

       //// 1. Parse into a Map.
       while (strtok.hasMoreTokens()) {
          //// 1.1. Calculate the length of the next token, the property key.
          if (flagParsingName == true) {
             strKey = strtok.nextToken();
             flagParsingName = false;
          }
          //// 1.2. Skip the next token, the property value.
          else {
             strVal          = strtok.nextToken();
             flagParsingName = true;
             map.put(strKey, strVal);
          }
       }

       return (map);
    } // of method

    //===   MAP PARSER   =======================================================
    //==========================================================================




    //==========================================================================
    //===   COLOR PARSER   =====================================================

    /**
     *
     * @param  str is either one of the color constants defined in 
     *             java.awt.Color, or a 3 or 4-tuple of ints specifying rgba.
     *             For example, "black", "white", "180, 180, 200", or 
     *             "200, 200, 200, 200".
     * @return a Color object if the color was known.
     * @throws ParseException if there was a parsing error.
     */
    public final static Color parseColor(String str) 
        throws ParseException {

        try {
            str = str.toLowerCase();
            if (StringLib.containsChars(str, "0123456789")) {
                return (parseColorTuple(str));
            }
            else {
                return (parseColorName(str));
            }
       }
       catch (Exception e) {
            throw new ParseException(e.getMessage());
       }
    } // of method

    //----------------------------------------------------------------

    private final static Color parseColorTuple(String str) 
        throws Exception {

        StringTokenizer strtok = new StringTokenizer(str, DELIMITERS);
        String          strR, strG, strB, strA;
        int             r,    g,    b,    a;
  
        strR = strtok.nextToken();
        strG = strtok.nextToken();
        strB = strtok.nextToken();

        r = Integer.parseInt(strR);
        g = Integer.parseInt(strG);
        b = Integer.parseInt(strB);

        if (strtok.hasMoreTokens()) {
            strA = strtok.nextToken();
            a    = Integer.parseInt(strA);
            return (new Color(r, g, b, a));
        }
        else {
            return (new Color(r, g, b));
        }
    } // of method

    //----------------------------------------------------------------

    private final static Color parseColorName(String str)
        throws Exception {

        if (str.equalsIgnoreCase("black")) {
           return (Color.black);
        }
        if (str.equalsIgnoreCase("blue")) {
           return (Color.blue);
        }
        if (str.equalsIgnoreCase("cyan")) {
           return (Color.cyan);
        }
        if (str.equalsIgnoreCase("darkGray")) {
           return (Color.darkGray);
        }
        if (str.equalsIgnoreCase("gray")) {
           return (Color.gray);
        }
        if (str.equalsIgnoreCase("green")) {
           return (Color.green);
        }
        if (str.equalsIgnoreCase("lightGray")) {
           return (Color.lightGray);
        }
        if (str.equalsIgnoreCase("magenta")) {
           return (Color.magenta);
        }
        if (str.equalsIgnoreCase("orange")) {
           return (Color.orange);
        }
        if (str.equalsIgnoreCase("pink")) {
           return (Color.pink);
        }
        if (str.equalsIgnoreCase("red")) {
           return (Color.red);
        }
        if (str.equalsIgnoreCase("white")) {
           return (Color.white);
        }
        if (str.equalsIgnoreCase("yellow")) {
           return (Color.yellow);
        }

        return (Color.black);
    } // of method

    //===   COLOR PARSER   =====================================================
    //==========================================================================




    //==========================================================================
    //===   SELF TESTING MAIN   ================================================

    private static void runTestAAA() throws Exception {
      System.out.println(parseColor("black"));
      System.out.println(parseColor("white"));
      System.out.println(parseColor("180, 180, 180"));
      System.out.println(parseColor("200, 200, 200, 200"));

      System.out.println(StringLib.toString(parseFloatArray("1,2, 3,  4, 5.0, 6.145, 7.123")));


      System.out.println("--------------");
      System.out.println(parseList( "[location, activity]" ));
      System.out.println(parseList( "[a, b, c, d, e, f, g]"));
      System.out.println(parseList( "[]" ));
      System.out.println(parseList( "" ));
    } // of method

    //----------------------------------------------------------------

    private static void runTestBBB() {
        parseCSV("A,B,C,D,E");
        System.out.println("----------------");
        parseCSV("A,B,C,D,E,");
        System.out.println("----------------");
        parseCSV("A,,C,,E,");
        System.out.println("----------------");
        parseCSV(",,C,,E,");
        System.out.println("----------------");
        parseCSV(",");
        System.out.println("----------------");
        parseCSV("");
        System.out.println("----------------");
        parseCSV("\"Washington, DC\"");
        System.out.println("----------------");
        parseCSV("\"Washington, DC\",Atlanta,\"Washington, DC\"");
        System.out.println("----------------");
        parseCSV("\"Washington, DC\",Atlanta,\"Washington, DC\",");
        System.out.println("----------------");
        parseCSV("\"Washington, DC\",\"Washington, DC\",");
    } // of method


    private static void runTestCCC() {
        parseSSV("A B C D E");
        System.out.println("----------------");
        parseSSV("A B C D E ");
        System.out.println("----------------");
        parseSSV("A  C  E ");
        System.out.println("----------------");
        parseSSV("  C  E ");
        System.out.println("----------------");
        parseSSV(" ");
        System.out.println("----------------");
        parseSSV("");
        System.out.println("----------------");
        parseSSV("\"Washington, DC\"");
        System.out.println("----------------");
        parseSSV("\"Washington, DC\" Atlanta \"Washington, DC\"");
        System.out.println("----------------");
        parseSSV("\"Washington, DC\" Atlanta \"Washington, DC\" ");
        System.out.println("----------------");
        parseSSV("\"Washington, DC\" \"Washington, DC\" ");
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestBBB();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        runTestCCC();
    } // of main

    //===   SELF TESTING MAIN   ================================================
    //==========================================================================

} // of class 

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
