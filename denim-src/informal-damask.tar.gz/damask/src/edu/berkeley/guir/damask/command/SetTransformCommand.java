package edu.berkeley.guir.damask.command;

import java.awt.geom.AffineTransform;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that changes the bounds of an interaction element.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-09-2003 James Lin
 *                               Created UpdateBoundsCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-09-2003
 */
public class SetTransformCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final InteractionElement element;
   private final DeviceType deviceType;
   private final PageRegion region;
   
   private final AffineTransform newTransform;
   private final AffineTransform oldTransform;

   /**
    * Constructs the command.
    * 
    * @param element the element whose transform is to be updated
    * @param deviceType the device type for which the element's transform is
    *                    to be updated
    * @param newTransform the new transform of the element
    */
   public SetTransformCommand(
      final InteractionElement element,
      final DeviceType deviceType,
      final AffineTransform newTransform) {
         
      this.element = element;
      this.deviceType = deviceType;
      this.region = null;
      this.newTransform = newTransform;
      oldTransform = element.getTransform(deviceType);
   }

   /**
    * Constructs the command.
    * 
    * @param group the component group whose transform is to be updated
    * @param pageRegion the page region for which the group's transform is
    *                    to be updated
    * @param newTransform the new transform of the group
    */
   public SetTransformCommand(
      final ComponentGroup group,
      final PageRegion region,
      final AffineTransform newTransform) {
         
      this.element = group;
      this.deviceType = null;
      this.region = region;
      this.newTransform = newTransform;
      oldTransform = group.getTransformInPageRegion(region);
   }


   // Overrides method in superclass.   
   public String getPresentationName() {
      if (element instanceof ComponentGroup) {
         final ComponentGroup group = (ComponentGroup)element;
         return "Set transform of " + group + " in " + region + ": "
            + oldTransform + "->" + newTransform;
      }
      else {
         return "Set transform of " + element + " for " + deviceType + ": "
            + oldTransform + "->" + newTransform;
      }
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      if (element instanceof ComponentGroup) {
         ((ComponentGroup)element).setTransformInPageRegion(
            region,
            newTransform);
      }
      else {
         element.setTransform(deviceType, newTransform);
      }
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      if (element instanceof ComponentGroup) {
         ((ComponentGroup)element).setTransformInPageRegion(
            region,
            oldTransform);
      }
      else {
         element.setTransform(deviceType, oldTransform);
      }
   }
}
