//// See bottom of file for software license
package edu.berkeley.guir.lib.noise;

import java.util.Random;

/**
 * Library for generating Perlin noise. 
 * See <A HREF="http://mrl.nyu.edu/~perlin/doc/oscar.html">
 * http://mrl.nyu.edu/~perlin/doc/oscar.html</A>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Apr 02 2002
 */
public class NoiseLib {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    public static final int B  = 0x100;
    public static final int BM = 0xff;

    public static final int N  = 0x1000;
    public static final int NP = 12;
    public static final int NM = 0xfff;

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   CLASS VARIABLES   ==================================================

    static int[]     p     = new int[B + B + 2];
    static float[][] g3    = new float[B + B + 2][3];
    static float[][] g2    = new float[B + B + 2][2];
    static float[]   g1    = new float[B + B + 2];
    static boolean   start = true;
    static Random    rand  = new Random();

    //===   CLASS VARIABLES   ==================================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    /**
     * No instances allowed.
     */
    private NoiseLib() {
    } // of constructor

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================




    //==========================================================================
    //===   NOISE METHODS   ====================================================

    private static final float s_curve(float t) {
        return (t * t * (3 - 2*t));
    } // of method

    //----------------------------------------------------------------

    /**
     * Linear interpolation.
     */
    private static final float lerp(float t, float a, float b) {
        return (a + t * (b - a));
    } // of method

    //----------------------------------------------------------------

    /**
     * Return ints uniformly in range from 0 to 2**31-1
     */
    private static final int random() {
        return (Math.abs(rand.nextInt()));
    } // of method

    //==========================================================================

    private static void normalize2(float v[]) {
        float s = (float) Math.sqrt(v[0]*v[0] + v[1]*v[1]);
        v[0] = v[0] / s;
        v[1] = v[1] / s;
    } // of method

    //----------------------------------------------------------------

    private static void normalize3(float v[]) {
        float s = (float) Math.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
        v[0] = v[0] / s;
        v[1] = v[1] / s;
        v[2] = v[2] / s;
    } // of method

    //==========================================================================

    /**
     * Generates lookup tables.
     */
    public static void init() {
        int i, j, k;

        for (i = 0; i < B; i++) {
            p[i] = i;

            g1[i] = (float)((random() % (B + B)) - B) / B;

            for (j = 0; j < 2; j++) {
                g2[i][j] = (float)((random() % (B + B)) - B) / B;
            }
            normalize2(g2[i]);

            for (j = 0; j < 3; j++) {
                g3[i][j] = (float)((random() % (B + B)) - B) / B;
            }
            normalize3(g3[i]);
        }

        for (i = B-1; i >= 0; i--) {
            k    = p[i];
            p[i] = p[j = random() % B];
            p[j] = k;
        }

        for (i = 0; i < B + 2; i++) {
            p[B + i] = p[i];
            g1[B + i] = g1[i];
            for (j = 0; j < 2; j++) {
                g2[B + i][j] = g2[i][j];
            }
            for (j = 0; j < 3; j++) {
                g3[B + i][j] = g3[i][j];
            }
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * 1D noise.
     */
    public static double noise1(float x) {
        int     bx0, bx1;
        float   rx0, rx1, sx, t, u, v;

        //// Make sure class variables have been initialized.
        if (start == true) {
            start = false;
            init();
        }

        //// Setup
        t   = x + N;
        bx0 = ((int) t) & BM;
        bx1 = (bx0 + 1) & BM;
        rx0 = t - (int) t;
        rx1 = rx0 - 1;

        //// Noise calcuations.
        sx  = s_curve(rx0);

        u   = rx0 * g1[ p[bx0] ];
        v   = rx1 * g1[ p[bx1] ];

        return (lerp(sx, u, v));
    } // of method

    //----------------------------------------------------------------

    /**
     * 2D noise.
     */
    public static double noise2(float x, float y) {
        int   bx0, bx1, by0, by1, b00, b10, b01, b11;
        float rx0, rx1, ry0, ry1, q[], sx, sy, a, b, t, u, v;
        int   i, j;

        //// Make sure class variables have been initialized.
        if (start == true) {
            start = false;
            init();
        }

        //// Setup.
        t   = x + N;
        bx0 = ((int) t) & BM;
        bx1 = (bx0 + 1) & BM;
        rx0 = t - (int) t;
        rx1 = rx0 - 1;

        t   = y + N;
        by0 = ((int) t) & BM;
        by1 = (by0  +1) & BM;
        ry0 = t - (int) t;
        ry1 = ry0 - 1;

        //// Noise calculations.
        i = p[bx0];
        j = p[bx1];

        b00 = p[i + by0];
        b10 = p[j + by0];
        b01 = p[i + by1];
        b11 = p[j + by1];

        sx = s_curve(rx0);
        sy = s_curve(ry0);

        q = g2[b00]; u = rx0 * q[0] + ry0 * q[1];
        q = g2[b10]; v = rx1 * q[0] + ry0 * q[1];
        a = lerp(sx, u, v);

        q = g2[b01]; u = rx0 * q[0] + ry1 * q[1];
        q = g2[b11]; v = rx1 * q[0] + ry1 * q[1];
        b = lerp(sx, u, v);

        return lerp(sy, a, b);
    } // of method

    //----------------------------------------------------------------

    /**
     * 3D noise.
     */
    public float noise3(float x, float y, float z) {
        int bx0, bx1, by0, by1, bz0, bz1, b00, b10, b01, b11;
        float rx0, rx1, ry0, ry1, rz0, rz1, q[], sy, sz, a, b, c, d, t, u, v;
        int i, j;

        if (start == true) {
            start = false;
            init();
        }

        //// Setup.
        t = x + N;
        bx0 = ((int)t) & BM;
        bx1 = (bx0+1) & BM;
        rx0 = t - (int)t;
        rx1 = rx0 - 1.0f;

        t = y + N;
        by0 = ((int)t) & BM;
        by1 = (by0+1) & BM;
        ry0 = t - (int)t;
        ry1 = ry0 - 1.0f;

        t = z + N;
        bz0 = ((int)t) & BM;
        bz1 = (bz0+1) & BM;
        rz0 = t - (int)t;
        rz1 = rz0 - 1.0f;

        i = p[bx0];
        j = p[bx1];

        b00 = p[i + by0];
        b10 = p[j + by0];
        b01 = p[i + by1];
        b11 = p[j + by1];

        //// Noise calculations.
        t  = s_curve(rx0);
        sy = s_curve(ry0);
        sz = s_curve(rz0);

        q = g3[b00 + bz0]; u = rx0 * q[0] + ry0 * q[1] + rz0 * q[2];
        q = g3[b10 + bz0]; v = rx1 * q[0] + ry0 * q[1] + rz0 * q[2];
        a = lerp(t, u, v);

        q = g3[b01 + bz0]; u = rx0 * q[0] + ry1 * q[1] + rz1 * q[2];
        q = g3[b11 + bz0]; v = rx1 * q[0] + ry1 * q[1] + rz1 * q[2];
        b = lerp(t, u, v);

        c = lerp(sy, a, b);

        q = g3[b00 + bz1]; u = rx0 * q[0] + ry0 * q[1] + rz0 * q[2];
        q = g3[b10 + bz1]; v = rx1 * q[0] + ry0 * q[1] + rz0 * q[2];
        a = lerp(t, u, v);

        q = g3[b01 + bz1]; u = rx0 * q[0] + ry1 * q[1] + rz1 * q[2];
        q = g3[b11 + bz1]; v = rx1 * q[0] + ry1 * q[1] + rz1 * q[2];
        b = lerp(t, u, v);

        d = lerp(sy, a, b);

        return lerp(sz, c, d);
    } // of method

    //===   NOISE METHODS   ====================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2002 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
