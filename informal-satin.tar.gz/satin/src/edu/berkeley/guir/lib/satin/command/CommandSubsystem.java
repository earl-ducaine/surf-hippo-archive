//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.beans.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.util.StringLib;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.watch.*;

/**
 * Command central for commands. All necessary values and references to
 * objects should be obtainable through here. Everything in the command 
 * package should be able to access everything in this class. This class 
 * simply decouples the command package from everything else.
 *
 * <P>
 * Some of the useful things the CommandSubsystem does include:
 * <UL>
 *    <LI>Maintain the last (x,y) coordinate selected
 *    <LI>Maintain the collection of selected Graphical Objects
 *    <LI>Contain the last Graphical Object added
 * </UL>
 *
 * <P>
 * The reason this is a Watchable object is that the system needs to know what
 * objects are selected in order to render correctly. If these objects change, 
 * the system also needs to know that. Hence, this class is Watchable.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 03 1999, JH
 *               Created class
 *             - SATIN-v1.0-1.0.1, Jun 28 2000, JH
 *               Added JavaBeans notification messages (PropertyChange).
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class CommandSubsystem 
   extends    WatchableImpl
   implements SatinConstants,
              MouseListener, 
              MouseMotionListener {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static long serialVersionUID = 91472039982497383L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   PROPERTIES AND MESSAGES   ===========================================

   /**
    * Message sent when an item is selected.
    * Old: Null. New: GraphicalObject selected.
    */
   public static final String SELECTED_ADDED   = "SELECTED_ADDED";

   /**
    * Message sent when an item is de-selected.
    * Old: GraphicalObject deselected. New: Null
    */
   public static final String SELECTED_REMOVED = "SELECTED_REMOVED";

   //===   PROPERTIES AND MESSAGES   ===========================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   int                       lastX;         // the last x-coordinate selected
   int                       lastY;         // the last y-coordinate selected
   GraphicalObjectCollection selectedGobs;  // the collection of selected GObs
   GraphicalObject           lastGob;       // last Graphical Object added
   EventQueue                evtqueue;      // a reference to the evt queue
   Sheet                     sheet;
   PropertyChangeSupport     csupport;      // for notifications

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public CommandSubsystem() {
      selectedGobs = new GraphicalObjectCollectionImpl();
      csupport     = new PropertyChangeSupport(this);
   } // of default constructor

   //-----------------------------------------------------------------

   public void initializeCommandSubsystem(Sheet newSheet) {
      newSheet.addMouseListener(cmdsubsys);
      sheet = newSheet;
   } // of method

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MOUSE LISTENER METHODS   ============================================

   /**
    * Keep track of where the mouse is in the Sheet.
    */
   private void processMouseEvent(MouseEvent evt) {
      this.lastX = evt.getX();
      this.lastY = evt.getY();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Keep track of where the mouse is in the Sheet.
    */
   public void mouseClicked(MouseEvent evt) {
      processMouseEvent(evt);
   } // of method

   //-----------------------------------------------------------------

   public void mouseEntered(MouseEvent evt) { }
   public void mouseExited(MouseEvent evt)  { }
   public void mouseDragged(MouseEvent evt) { }
   public void mouseMoved(MouseEvent evt)   { }

   //-----------------------------------------------------------------

   /**
    * Keep track of where the mouse is in the Sheet.
    */
   public void mousePressed(MouseEvent evt) {
      processMouseEvent(evt);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Keep track of where the mouse is in the Sheet.
    */
   public void mouseReleased(MouseEvent evt) {
      processMouseEvent(evt);
   } // of method

   //===   MOUSE LISTENER METHODS   ============================================
   //===========================================================================



   //===========================================================================
   //===   EVENT QUEUE METHODS   ===============================================

   private EventQueue getEventQueue() {
      try {
         if (evtqueue != null) {
            return (evtqueue);
         }
         evtqueue = Toolkit.getDefaultToolkit().getSystemEventQueue();
      }
      catch (Exception e) {
         Debug.println("Cannot retrieve event queue - cannot activate widgets");
         Debug.println(e);
      }
      return (evtqueue);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Throw an event into the System event queue. This allows
    * Satin to activate widgets.
    */
   public void postEvent(AWTEvent evt) {
      getEventQueue().postEvent(evt);
   } // of method

   //===   EVENT QUEUE METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   SELECTED GRAPHICAL OBJECT METHODS   =================================

   public boolean isSelected(GraphicalObject gob) {
      if (gob == null) {
         return (false);
      }

      return (selectedGobs.contains(gob));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the list of selected objects.
    *
    * @param g is the collection of Graphical Objects to set to.
    */
   public void setSelected(GraphicalObjectCollection g) {
      this.selectedGobs = g;
      if (sheet != null) {
         sheet.damage(DAMAGE_LATER,
                      selectedGobs.getCollectionBounds2D(COORD_ABS));
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Clear out the list of selected objects.
    */
   public void clearSelected() {
      //// 1. Create a list for damage purposes.
      Iterator        it   = selectedGobs.getForwardIterator();
      LinkedList      list = new LinkedList();
      GraphicalObject gob;

      while (it.hasNext()) {
         list.add(it.next());
      }

      //// 2. Send out removed messages.
      selectedGobs.clear();
      it = list.iterator();
      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();
         gob.damage(DAMAGE_LATER);
         csupport.firePropertyChange(SELECTED_REMOVED, gob, null);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Remove the specified Graphical Object from the selected list.
    *
    * @param gob is the Graphical Object to remove from the selected list.
    */
   public void removeSelected(GraphicalObject gob) {
      if (selectedGobs.remove(gob) != null && sheet != null) {
         sheet.damage(DAMAGE_LATER, gob);
         csupport.firePropertyChange(SELECTED_REMOVED, gob, null);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add the specified GraphicalObject to the selected list if it is not
    * already (can only be in the list at most once).
    *
    * @param gob is the Graphical Object to add to the selected list.
    */
   public void addSelected(GraphicalObject gob) {
      if (gob.isSelectable() == true) {
         selectedGobs.addToBack(gob);
         if (sheet != null) {
            sheet.damage(DAMAGE_LATER, gob);
         }
         csupport.firePropertyChange(SELECTED_ADDED, null, gob);
      }
   } // of method

   //-----------------------------------------------------------------

   /** 
    * Add the GraphicalObjects in the iterator to the selected list.
    */
   public void addSelected(Iterator it) {
      while (it.hasNext()) {
         addSelected((GraphicalObject) it.next());
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a copy of the list of selected Graphical Objects. Modify the copy to
    * your heart's content.
    *
    * @return a forward iterator to a Graphical Object Collection.
    */
   public Iterator getSelected() {
      return ((GraphicalObjectCollection)selectedGobs.clone()).
                                                        getForwardIterator();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Returns a reference to the actual collection of selected objects.
    * Be careful, as any modifications to this collection will modify the list
    * of selected objects. Furthermore, be aware that cloning this list
    * will increase the number of watchers for each of the contained objects.
    */
   public GraphicalObjectCollection getSelectedCollection() {
      return (selectedGobs);
   } // of method

   //===   SELECTED GRAPHICAL OBJECT METHODS   =================================
   //===========================================================================



   //===========================================================================
   //===   MOUSE LOCATION METHODS   ============================================

   /**
    * Get the last mouse location clicked.
    *
    * @return a Point containing the last x- and y- mouse coordinates clicked.
    */
   public Point getAbsoluteLastLocation() {
      return (new Point(lastX, lastY));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the last mouse location clicked.
    *
    * @param  pt is the storage space to put the answer in.
    * @return a Point containing the last x- and y- mouse coordinates clicked.
    */
   public Point getAbsoluteLastLocation(Point pt) {
      pt.x = lastX;
      pt.y = lastY;
      return (pt);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the last mouse x-location clicked.
    *
    * @return an int containing the last x- mouse coordinate clicked.
    */
   public int getAbsoluteLastXLocation() {
      return(lastX);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the last mouse y-location clicked.
    *
    * @return an int containing the last y- mouse coordinate clicked.
    */
   public int getAbsoluteLastYLocation() {
      return(lastY);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the last mouse location clicked, in the specified GraphicalObject's
    * coordinate system.
    *
    * @param  gob is the GraphicalObject whose coordinate system we will use.
    * @return a Point containing the last x- and y- mouse coordinates clicked.
    */
   public Point getLocalLastLocation(GraphicalObject gob) {
      return (getLocalLastLocation(gob, new Point()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the last mouse location clicked, in the specified GraphicalObject's
    * coordinate system.
    *
    * @param  gob is the GraphicalObject whose coordinate system we will use.
    * @param  pt is the storage space to put the answer in.
    * @return a Point containing the last x- and y- mouse coordinates clicked.
    */
   public Point getLocalLastLocation(GraphicalObject gob, Point pt) {
      Point ptTmp = getAbsoluteLastLocation();
      GraphicalObjectLib.absoluteToLocal(gob, ptTmp, pt);
      return (pt);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the last mouse x-location clicked, in the specified GraphicalObject's
    * coordinate system.
    *
    * @param  gob is the GraphicalObject whose coordinate system we will use.
    * @return an int containing the last y- mouse coordinate clicked.
    */
   public int getLocalLastXLocation(GraphicalObject gob) {
      Point pt = getLocalLastLocation(gob);
      return (pt.x);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the last mouse y-location clicked, in the specified GraphicalObject's
    * coordinate system.
    *
    * @param  gob is the GraphicalObject whose coordinate system we will use.
    * @return an int containing the last y- mouse coordinate clicked.
    */
   public int getLocalLastYLocation(GraphicalObject gob) {
      Point pt = getLocalLastLocation(gob);
      return (pt.y);
   } // of method

   //===   MOUSE LOCATION METHODS   ============================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Set the last Graphical Object added. Used by {@link InsertCommand}.
    *
    * @param gob is the last Graphical Object added.
    */
   public void setLastGraphicalObject(GraphicalObject gob) {
      this.lastGob = gob;
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Get the last Graphical Object added by {@link InsertCommand}.
    *
    * @return the last Graphical Object added.
    */
   public GraphicalObject getLastGraphicalObject() {
      return (lastGob);
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   PROPERTY CHANGE METHODS   ===========================================

   public void addPropertyChangeListener(PropertyChangeListener l) {
      csupport.addPropertyChangeListener(l);
   } // of method

   //-----------------------------------------------------------------

   public void addPropertyChangeListener(String strPropertyName, 
                                         PropertyChangeListener l) {
      csupport.addPropertyChangeListener(strPropertyName, l);
   } // of method

   //-----------------------------------------------------------------

   public void removePropertyChangeListener(PropertyChangeListener l) {
      csupport.removePropertyChangeListener(l);
   } // of method

   //-----------------------------------------------------------------

   public void removePropertyChangeListener(String strPropertyName, 
                                            PropertyChangeListener l) {
      csupport.removePropertyChangeListener(strPropertyName, l);
   } // of method

   //===   PROPERTY CHANGE METHODS   ===========================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      StringBuffer strbuf = new StringBuffer();

      strbuf.append(  "Last Pos:       "     + getAbsoluteLastLocation());
      strbuf.append("\nSelected GObs:  "     + getSelectedCollection());
      strbuf.append("\nLast GOb Added: [");
      if (lastGob != null) {
          strbuf.append("\n" + StringLib.indent(getLastGraphicalObject().toString(), 3) + "\n");
      }
      strbuf.append("]\n");

      return (strbuf.toString());
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
