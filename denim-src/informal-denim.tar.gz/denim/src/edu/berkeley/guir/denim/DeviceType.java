package edu.berkeley.guir.denim;

/** 
 * An instance of this class describes a type of device, along with
 * characteristics of the device.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-18-2003 James Lin
 *                               Created DeviceType
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 03-18-2003
 */
public class DeviceType {
   private String name;
   private int width;
   private int height;
   private boolean visual;
   private boolean audio;
   
   // Pre-defined devices
   public static DeviceType ANY =
      new DeviceType("Any", 0, 0, true, true);
      
   public static DeviceType DESKTOP =
      new DeviceType("Desktop", 800, 600, true, true);
      
   // Nokia Series 60: 176x208
   // Microsoft Smartphone: 175x220
   public static DeviceType SMARTPHONE =
      new DeviceType("Smartphone", 180, 215, true, true);
      
   public static DeviceType VOICE =
      new DeviceType("Voice", 0, 0, false, true);
   
   //---------------------------------------------------------------------------

   private DeviceType(String name, int width, int height, boolean isVisual,
                      boolean isAudio) {
      this.name = name;
      this.width = width;
      this.height = height;
      this.visual = isVisual;
      this.audio = isAudio;
   }
   
   //---------------------------------------------------------------------------

   /**
    * Returns the name of the device.
    */
   public String getName() {
      return name;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the device's screen width.
    */
   public int getWidth() {
      return width;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the device's screen height.
    */
   public int getHeight() {
      return height;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns whether the device has a visual display.
    */
   public boolean isVisual() {
      return visual;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns whether the device has a visual display.
    */
   public boolean isAudio() {
      return audio;
   }
}

