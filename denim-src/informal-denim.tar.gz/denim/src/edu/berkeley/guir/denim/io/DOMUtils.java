package edu.berkeley.guir.denim.io;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.annotation.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.toolbox.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;

import org.w3c.dom.*;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextArea;
import javax.swing.ImageIcon;
import java.awt.geom.*;
import java.util.*;
import java.net.*;

/**
 * Contains functions to convert DenimSheets and its contents to and from
 * a DOM.
 *
 * <PRE>
 * Revisions:  1.0.0  12-01-1999  JL
 *                    Created DOMUtils
 *             2.0.0  09-24-2004
 *                    Enabled saving for 
 *                      CustomComponent, 
 *                      Conditional, 
 *                      States of BuiltIn Components
 *                      Options
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 2.0.0, 09-24-2004
 */

public class DOMUtils implements DenimConstants {

   static final String ID_TAG = "ID";
   static final String ID_REF_TAG = "IDRef";
   static final String X_TAG = "x";
   static final String Y_TAG = "y";
   static final String WIDTH_TAG = "Width";
   static final String HEIGHT_TAG = "Height";
   static final String TIME_TAG = "TimeMs";
   static final String BOUNDING_BOX_TAG = "BoundingBox";
   static final String CONTENTS_TAG = "Contents";
   static final String TIMED_POINT_TAG = "TimedPoint";
   static final String TIMED_STROKE_TAG = "TimedStroke";
   static final String TIMED_STROKE_WITH_PARENT_TAG = "TimedStrokeWithParent";
   static final String SCRIBBLE_TAG = "Scribble";
   static final String IMAGE_TAG = "Image";
   static final String DENIM_TEXT_TAG = "DenimText";
   static final String TEXT_TAG = "Text";
   static final String FONT_TAG = "Font";
   static final String FONT_SIZE_TAG = "Size";
   static final String FONT_NAME_TAG = "Name";
   static final String FONT_STYLE_TAG = "Style";
   static final String STICKY_SCALE_FACTOR_TAG = "StickyScaleFactor";
   static final String DENIM_LABEL_TAG = "DenimLabel";
   static final String HYPERLINK_TAG = "DenimHyperlinkInstance";
   static final String TEXT_FIELD_TAG = "DenimTextFieldInstance";
   static final String BUTTON_TAG = "Button";
   static final String CAPTION_TAG = "Caption";
   static final String LIST_ITEM_TAG = "ListItem";
   static final String LIST_ITEMS_TAG = "ListItems";
   static final String SELECTED_INDEX_TAG = "SelectedIndex";
   static final String DOWN_ARROW_TAG = "DownArrow";
   static final String FILLED_TAG = "Filled";
   static final String CREATED_BY_STAMP_TAG = "CreatedByStamp";
   static final String SELECTED_TAG = "Selected";
   static final String RADIO_BUTTON_TAG = "RadioButton";
   static final String BUTTON_BORDER_TAG = "ButtonBorder";
   static final String BORDER_TAG = "Border";
   static final String GROUP_TAG = "Group";
   static final String CHECK_BOX_TAG = "CheckBox";
   static final String LIST_BOX_TAG = "ListBox";
   static final String COMBO_BOX_TAG = "ComboBox";
   static final String DENIM_SKETCH_TAG = "DenimSketch";
   static final String DENIM_PANEL_TAG = "DenimPanel";
   static final String INK_ANNOTATION_TAG = "InkAnnotation";
   static final String ANCHOR_ID_REF_TAG = "AnchorIDRef";
   static final String AUDIO_SRC_TAG = "AudioSrc";
   static final String PARENT_ID_REF_TAG = "ParentIDRef";
   static final String AUDIO_ANNOTATION_TAG = "AudioAnnotation";
   static final String ANNOTATIONS_TAG = "Annotations";
   static final String ANNOTATIONS_BY_REVIEWER_TAG = "AnnotationsByReviewer";
   static final String INK_ANNOTATION_REF_TAG = "InkAnnotationRef";
   static final String ANNOTATION_REFS_TAG = "AnnotationRefs";
   static final String ANNOTATION_REFS_BY_REVIEWER_TAG = "AnnotationRefsByReviewer";
   static final String REVIEWER_TAG = "Reviewer";
   static final String EVENT_TYPE_TAG = "EventType";
   static final String SRC_REF_TAG = "SrcRef";
   static final String DEST_REF_TAG = "DestRef";
   static final String ARROW_TAG = "Arrow";
   static final String ARROW_CONDITION = "ArrowCondition";
   static final String VERSION_TAG = "Version";
   static final String SCENARIOS_TAG = "Scenarios";
   static final String SCENARIO_TAG = "Scenario";
   static final String SCENARIO_NAME_TAG = "Name";
   static final String SCENARIO_TIME_TAG = "Time";
   static final String UID_TAG = "UID";
   static final String[][] M_TAG = { {"m00", "m01", "m02"},
                                     {"m10", "m11", "m12"} };
   static final String AFFINE_TRANSFORM_TAG = "AffineTransform";
   static final String AUTHOR_URL_TAG = "AuthorURL";
   static final String DENIM_SHEET_TAG = "DenimSheet";
   static final String DENIM_CUSTOM_COMPONENT_TAG = "DenimCustomComponent";
   static final String NAME_TAG = "Name";
   static final String DENIM_IMAGE_FILE_TAG = "DenimImageFile";

   static final String CUSTOMINSTANCE_ID = "CustomComponentInstance";
    
   //-----------------------------------------------------------------

   /**
    * Converts a string into a DOM element of the form <tag>text</tag>.
    */
   static Element toDOMElement(Document doc, String text, String tagName) {
      Element e = doc.createElement(tagName);
      e.appendChild(doc.createTextNode(text));
      return e;
   }



   /**
    * Returns a string from the DOM element <blah>text</blah>.
    */
   static String createStringFromDOMElement(Element e, String tagName) {
      assert e.getTagName().equals(tagName):
         e.getTagName() + " is not " + tagName;

      // Make sure element has only one child
      NodeList children = e.getChildNodes();
      assert children.getLength() == 1:
         "<" + e.getTagName() + "> should have one child";

      // Make sure element's child is a text node
      try {
         assert children.item(0).getNodeType() == Node.TEXT_NODE:
            "<" + e.getTagName() + ">'s child should be text";

         Text text = (Text)children.item(0);

         return text.getData();
      }
      catch (NullPointerException ex) {
         return "";
      }
   }

   //---------------------------------------------------------------------------
  /*
   static String createFileNameFromDOMElement(Element e){
      System.err.println("--> creatFileNameFromDOMElement");
      assert e.getTagName().equals(DENIM_IMAGE_FILE_TAG);
      // "Element " + e.getTagName() + " is not a DENIM_IMAGE_FILE_TAG");

      NodeList children = e.getChildNodes();
      String s = createStringFromDOMElement((Element)children.item(1), TEXT_TAG);
      System.err.println("--> creatFileNameFromDOMElementwith s = " + s);
      return s;
   }
*/

   //-----------------------------------------------------------------

   /**
    * Converts an integer into a DOM element of the form <tag>num</tag>.
    */
   static Element toDOMElement(Document doc, int num, String tagName) {
      return toDOMElement(doc, Integer.toString(num), tagName);
   }

   /**
    * Returns an integer from the DOM element <blah>num</blah>.
    */
   static int createIntFromDOMElement(Element e, String tagName) {
      String s = createStringFromDOMElement(e, tagName);

      // Extract the number from the contained text node
      int num = -1;
      try {
         num = Integer.parseInt(s);
      }
      catch (NumberFormatException ex) {
          assert false: 
              "<" + e.getTagName() + ">'s child should be an integer, not " + s;
      }
      
      return num;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a boolean into a DOM element of the form
    * <tag>true or false</tag>.
    */
   static Element toDOMElement(Document doc, boolean flag, String tagName) {
      return toDOMElement(doc, Boolean.toString(flag), tagName);
   }

   /**
    * Returns a boolean from the DOM element <blah>true or false</blah>.
    */
   static boolean createBooleanFromDOMElement(Element e, String tagName) {
      String s = createStringFromDOMElement(e, tagName);

      // Extract the boolean value from the contained text node
      return Boolean.valueOf(s).booleanValue();
   }

   //-----------------------------------------------------------------

   /**
    * Converts a long into a DOM element of the form <tag>num</tag>.
    */
   static Element toDOMElement(Document doc, long num, String tagName) {
      return toDOMElement(doc, Long.toString(num), tagName);
   }


   /**
    * Returns a long from the DOM element <blah>num</blah>.
    */
   static long createLongFromDOMElement(Element e, String tagName) {
      String s = createStringFromDOMElement(e, tagName);

      // Extract the number from the contained text node
      long num = -1;
      try
      {
          num = Long.parseLong(s);
      }
      catch(NumberFormatException ex1)
      {
          ex1.printStackTrace();
      }

      return num;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a float into a DOM element of the form <tag>num</tag>.
    */
   static Element toDOMElement(Document doc, float num, String tagName) {
      return toDOMElement(doc, Float.toString(num), tagName);
   }


   /**
    * Returns a double from the DOM element <blah>num</blah>.
    */
   static float createFloatFromDOMElement(Element e, String tagName) {
      String s = createStringFromDOMElement(e, tagName);

      // Extract the number from the contained text node
      float num = -1;
      try {
         num = Float.parseFloat(s);
      }
      catch (NumberFormatException ex) {
         assert false: 
            "<" + e.getTagName() + ">'s child should be a float, not " + s;
      }

      return num;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a double into a DOM element of the form <tag>num</tag>.
    */
   static Element toDOMElement(Document doc, double num, String tagName) {
      return toDOMElement(doc, Double.toString(num), tagName);
   }


   /**
    * Returns a double from the DOM element <blah>num</blah>.
    */
   static double createDoubleFromDOMElement(Element e, String tagName) {
      String s = createStringFromDOMElement(e, tagName);

      // Extract the number from the contained text node
      double num = -1;
      try {
         num = Double.parseDouble(s);
      }
      catch (NumberFormatException ex) {
         assert false: 
            "<" + e.getTagName() + ">'s child should be a double, not " + s;
      }

      return num;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a rectangle into a DOM element. The element's form is
    *
    * <tagName>
    *   <x>nn</x>
    *   <y>nn</y>
    *   <Width>nn</Width>
    *   <Height>nn</Height>
    * </tagName>
    */
   static Element toDOMElement(Document doc, Rectangle2D rect, String tagName) {
      Element e = doc.createElement(tagName);
      e.appendChild(toDOMElement(doc, rect.getX(), X_TAG));
      e.appendChild(toDOMElement(doc, rect.getY(), Y_TAG));
      e.appendChild(toDOMElement(doc, rect.getWidth(), WIDTH_TAG));
      e.appendChild(toDOMElement(doc, rect.getHeight(), HEIGHT_TAG));

      return e;
   }

   /**
    * Reads a DOM element and returns a Rectangle2D.
    */
   static Rectangle2D createRectangle2DFromDOMElement(Element e, String tagName) {
      // Make sure element has right number of children
      NodeList children = e.getChildNodes();
      int len = children.getLength();
      assert len == 4: "<" + e.getTagName() + "> should have four children";

      return new Rectangle2D.Float(
         createFloatFromDOMElement((Element)children.item(0), X_TAG),
         createFloatFromDOMElement((Element)children.item(1), Y_TAG),
         createFloatFromDOMElement((Element)children.item(2), WIDTH_TAG),
         createFloatFromDOMElement((Element)children.item(3), HEIGHT_TAG));
   }

   //-----------------------------------------------------------------

   /**
    * Converts a point into a DOM element. The element's form is
    *
    * <tagName>
    *   <x>nn</x>
    *   <y>nn</y>
    * </tagName>
    */
   static Element toDOMElement(Document doc, Point2D point, String tagName) {
      Element e = doc.createElement(tagName);
      e.appendChild(toDOMElement(doc, point.getX(), X_TAG));
      e.appendChild(toDOMElement(doc, point.getY(), Y_TAG));

      return e;
   }

   /**
    * Reads a DOM element and returns a Point2D.
    */
   static Point2D createPoint2DFromDOMElement(Element e, String tagName) {
      // Make sure element has right number of children
      NodeList children = e.getChildNodes();
      int len = children.getLength();
      assert len == 2: "<" + e.getTagName() + "> should have 2 children";

      return new Point2D.Float(
         createFloatFromDOMElement((Element)children.item(0), X_TAG),
         createFloatFromDOMElement((Element)children.item(1), Y_TAG));
   }

   //-----------------------------------------------------------------


   /**
    * Converts a TimedPoint into a DOM element. The element's form is
    *
    * <TimedPoint>
    *   <x>nn</x>
    *   <y>nn</y>
    *   <Time>nn</Time>
    * </TimedPoint>
    */
   static Element toDOMElement(Document doc, float x, float y,
                               long millisecs) {
      Element e = doc.createElement(TIMED_POINT_TAG);
      e.appendChild(toDOMElement(doc, x, X_TAG));
      e.appendChild(toDOMElement(doc, y, Y_TAG));
      e.appendChild(toDOMElement(doc, millisecs, TIME_TAG));

      return e;
   }

   /**
    * Reads a DOM element and returns a TimedPoint.
    */
   static TimedPoint2D createTimedPoint2DFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(TIMED_POINT_TAG):
         "Element " + e.getTagName() + " is not TimedPoint";

      // Make sure element has right number of children
      NodeList children = e.getChildNodes();
      int len = children.getLength();
      assert len == 3:
         "<" + e.getTagName() + "> should have three children";

      TimedPoint2D pt = new TimedPoint2D();

      // Extract x, y, time from children
      pt.x = createFloatFromDOMElement((Element)children.item(0), X_TAG);
      pt.y = createFloatFromDOMElement((Element)children.item(1), Y_TAG);
      pt.time = createLongFromDOMElement((Element)children.item(2), TIME_TAG);

      return pt;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a TimedStroke into a DOM element. The element's form is
    *
    * <TimedStroke>
    *   <ID>xx</ID>
    *   <AffineTransform>
    *     ...
    *   </AffineTransform>
    *   <TimedPoint>
    *     ...
    *   </TimedPoint>
    *   ...
    * </TimedStroke>
    */
   static Element toDOMElement(Document doc, TimedStroke stk) {
      return toDOMElement(doc, stk, false);
   }

   static Element toDOMElement(Document doc, TimedStroke stk,
                               boolean includeParent) {
      Element e;
      
      if (includeParent) {
         e = doc.createElement(TIMED_STROKE_WITH_PARENT_TAG);
      }
      else {
         e = doc.createElement(TIMED_STROKE_TAG);
      }

      if(stk.getStyleRef().getDrawColor()==Color.green)
          e.setAttribute("Color", "green");
      else if(stk.getStyleRef().getDrawColor()==Color.red)
          e.setAttribute("Color", "red");
      else
          e.setAttribute("Color", "black");
      
      // Create <ID>
      e.appendChild(toDOMElement(doc, stk.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, stk.getTransform(COORD_REL)));

      if (includeParent) {
         // Create <ParentIDRef>
         e.appendChild(toDOMElement(doc, stk.getParentGroup().getUniqueID(),
                                    PARENT_ID_REF_TAG));
      }

      //DenimUtils.debugPrintBounds(stk, "Saving");
      //DenimUtils.debugPrintBounds(stk.getParentGroup(), "Parent");

      TimedPolygon2D poly = stk.getPolygon2D(COORD_LOCAL);
      for (int i = 0; i < poly.npoints; i++) {
         // Create <TimedPoint>...</TimedPoint>
         e.appendChild(toDOMElement(doc,
                                    poly.xpoints[i],
                                    poly.ypoints[i],
                                    poly.times[i]));
      }

      return e;
   }

   /**
    * Reads a DOM element and returns a TimedStroke.
    */
   static TimedStroke createTimedStrokeFromDOMElement(Element e) {
      return createTimedStrokeFromDOMElement(e, null, false,
                                             TIMED_STROKE_TAG);
   }

   static TimedStroke createTimedStrokeFromDOMElement(Element e,
                                                      DenimSheet sheet,
                                                      boolean includeParent) {
      return createTimedStrokeFromDOMElement(e, sheet, includeParent,
                                             TIMED_STROKE_WITH_PARENT_TAG);
   }
   
   static TimedStroke createTimedStrokeFromDOMElement(Element e,
                                                      DenimSheet sheet,
                                                      boolean includeParent,
                                                      String tagName) {
       return createTimedStrokeFromDOMElement(e, sheet, includeParent,
                                             TIMED_STROKE_WITH_PARENT_TAG, true);
   }
                                                     	
static TimedStroke createTimedStrokeFromDOMElement(Element e,
                                                      DenimSheet sheet,
                                                      boolean includeParent,
                                                      String tagName, 
                                                      boolean makeCurvy) {
      // Make sure element has right tag
      assert e.getTagName().equals(tagName):
                    "Element " + e.getTagName() +
                    " is not " + tagName;

      TimedStroke stk;
      if (makeCurvy) stk = new TimedCurvyStroke();
      else stk = new TimedStroke();
      NodeList children = e.getChildNodes();
      int len = children.getLength();

      // Get ID from first child
      //if (!includeParent) {
         stk.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));
      //}

      // Get transform from second child
      stk.setTransform(createAffineTransformFromDOMElement(
                            (Element)children.item(1)));

      if(e.hasAttribute("Color"))
      {
          String c = e.getAttribute("Color");
          if(c.equals("green"))
          {
              stk.getStyleRef().setDrawColor(Color.green);
          }
          else if(c.equals("red"))
          {
              stk.getStyleRef().setDrawColor(Color.red);
          }
          else
          {
              stk.getStyleRef().setDrawColor(Color.black);
          }
      }
      

      // For each of the rest of the children, get and add a timed point
      for (int i = (includeParent ? 3 : 2); i < len; i++) {
         TimedPoint2D pt =
            createTimedPoint2DFromDOMElement((Element)children.item(i));
         stk.addPoint(pt.x, pt.y, pt.time);
      }
      stk.doneAddingPoints();

      // If includeParent, then get the parent from the second child, and
      // add the stroke to the parent
      if (includeParent) {
         GraphicalObjectGroup parent =
            (GraphicalObjectGroup)
            sheet.getID(createLongFromDOMElement((Element)children.item(2),
                                                PARENT_ID_REF_TAG));
         parent.add(stk, GraphicalObjectGroup.KEEP_REL_POS);
      }

      return stk;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a Scribble into a DOM element. The element's form is
    *
    * <Scribble>
    *   <ID>xx</ID>
    *   <AffineTransform>
    *     ...
    *   </AffineTransform>
    *   <BoundingBox>
    *     ...
    *   </BoundingBox>
    *   <TimedStroke>
    *   ...
    *   </TimedStroke>
    *   ...
    * </Scribble>
    */
   static Element toDOMElement(Document doc, ScribbledText scribble) {
      Element e = doc.createElement(SCRIBBLE_TAG);

      // Create <ID>
      e.appendChild(toDOMElement(doc, scribble.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, scribble.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, scribble.getBounds2D(COORD_LOCAL),
                                 BOUNDING_BOX_TAG));

      // Create <TimedStroke>...
      Iterator it = scribble.getReverseIterator();
      while (it.hasNext()) {
         GraphicalObject gob = (GraphicalObject)it.next();
         // HACK: toDOMElement should be a method of the graphical object,
         // so we can dispatch to the right type
         e.appendChild(toDOMElement(doc, (TimedStroke)gob));
      }

      return e;
   }
   
   static DenimImage createImageFromDOMElement(Element e) {
       // Make sure element has right tag
       assert e.getTagName().equals(IMAGE_TAG):
                     "Element " + e.getTagName() + " is not image";

       NodeList children = e.getChildNodes();

       // Get BoundingBox from 3rd child
       DenimImage image =
          new DenimImage(e.getAttribute("Image"),
                  createRectangle2DFromDOMElement
             ((Element)children.item(2), BOUNDING_BOX_TAG));
       
       if(e.getAttribute("isLink").toLowerCase().startsWith("true"))
           image.setLink(true);
       else
           image.setLink(false);


       // Get transform from 2nd child
       image.setTransform(createAffineTransformFromDOMElement(
                             (Element)children.item(1)));

       // Get ID from first child
       image.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                  ID_TAG));
       
       

       return image;
    }

   /**
    * Reads a DOM element and returns a Scribble.
    */
   static ScribbledText createScribbleFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(SCRIBBLE_TAG):
                    "Element " + e.getTagName() + " is not Scribble";

      NodeList children = e.getChildNodes();
      int len = children.getLength();

      // Get BoundingBox from 3rd child
      ScribbledText scribble =
         new ScribbledText(createRectangle2DFromDOMElement
            ((Element)children.item(2), BOUNDING_BOX_TAG));


      // Get transform from 2nd child
      scribble.setTransform(createAffineTransformFromDOMElement(
                            (Element)children.item(1)));

      // Get ID from first child
      scribble.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));

      // For each of the rest of the children, get and add the graphical object
      for (int i = 3; i < len; i++) {
         if (children.item(i).getNodeName().equals(TIMED_STROKE_TAG)) {
            TimedStroke stk =
               createTimedStrokeFromDOMElement((Element)children.item(i));
            scribble.add(stk, GraphicalObjectGroup.KEEP_REL_POS);
         }
      }

      return scribble;
   }

   /**
    * Converts a Font object into a DOM element. The element's form is
    *
    * <Font>
    *   <Name>
    *     ...
    *   </Name>
    *   <Size>
    *     ...
    *   </Size>
    *   <Style>
    *     ...
    *   </Style>
    * </Font>
    */
   static Element toDOMElement(Document doc, Font font) {
      // Create <Font>
      Element e = doc.createElement(FONT_TAG);
      // Create <Name>
      e.appendChild(toDOMElement(doc, font.getFontName(),
                                 FONT_NAME_TAG));
      // Create <Style>
      e.appendChild(toDOMElement(doc, font.getStyle(),
                                 FONT_STYLE_TAG));
      // Create <Size>
      e.appendChild(toDOMElement(doc, font.getSize(),
                                 FONT_SIZE_TAG));

      return e;
   }

   /**
    * Reads a DOM element and returns a Font.
    */
   static Font createFontFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(FONT_TAG):
                    "Element " + e.getTagName() + " is not Font";

      NodeList children = e.getChildNodes();
      Font font = new Font
         (createStringFromDOMElement((Element)children.item(0), FONT_NAME_TAG),
          createIntFromDOMElement((Element)children.item(1), FONT_STYLE_TAG),
          createIntFromDOMElement((Element)children.item(2), FONT_SIZE_TAG)
         );
      return font;
   }

   /**
    * Converts a TypedText into a DOM element. The element's form is
    *
    * <DenimText>
    *   <ID>xx</ID>
    *   <AffineTransform>
    *     ...
    *   </AffineTransform>
    *   <BoundingBox>
    *     ...
    *   </BoundingBox>
    *   <Font>
    *   ...
    *   </Font>
    *   <Text>
    *   ...
    *   </Text>
    *   ...
    * </DenimText>
    */
   static Element toDOMElement(Document doc, TypedText text) {
      Element e = doc.createElement(DENIM_TEXT_TAG);

      if(text.getColor()==Color.green)
          e.setAttribute("Color", "green");
      else if(text.getColor()==Color.red)
          e.setAttribute("Color", "red");
      else
          e.setAttribute("Color", "black");
      
      
      // Create <ID>
      e.appendChild(toDOMElement(doc, text.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, text.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, text.getBounds2D(COORD_LOCAL),
                                 BOUNDING_BOX_TAG));

      // Create <Font>
      e.appendChild(toDOMElement(doc, text.getFont()));

      // Create <Text>
      e.appendChild(toDOMElement(doc, text.getText(), TEXT_TAG));
      return e;
   }

   /**
    * Reads a DOM element and returns a TypedText.
    */
   static TypedText createTypedTextFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(DENIM_TEXT_TAG):
                   "Element " + e.getTagName() + " is not TypedText";

      NodeList children = e.getChildNodes();


      // Make the DenimText using the 4th and 5th child
      JTextArea ta = new JTextArea();
      ta.setFont(createFontFromDOMElement((Element)children.item(3)));
      ta.setText(createStringFromDOMElement((Element)children.item(4), TEXT_TAG));
      TypedText text = new TypedText(ta);

      // Get BoundingBox from 3rd child
      //text.setBoundingPoints2D
      //   (COORD_REL, createRectangle2DFromDOMElement((Element)children.item(2));

      // Get transform from 2nd child
      text.setTransform(createAffineTransformFromDOMElement
         ((Element)children.item(1)));

      // Get ID from first child
      text.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));

      if(e.hasAttribute("Color"))
      {
          if(e.getAttribute("Color").equalsIgnoreCase("green"))
              text.setColor(Color.green);
          else if(e.getAttribute("Color").equalsIgnoreCase("red"))
              text.setColor(Color.red);
          else
              text.setColor(Color.BLACK);
      }
      
      return text;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a DenimText into a DOM element. Simply delegates to
    * functions for converting ScribbledText or TypedText.
    */
   static Element toDOMElement(Document doc, DenimText text) {
      if (text instanceof ScribbledText) {
         return toDOMElement(doc, (ScribbledText)text);
      }
      else {
         return toDOMElement(doc, (TypedText)text);
      }
   }

   //-----------------------------------------------------------------

   /**
    * Converts a DenimText into a DOM element. Simply delegates to
    * functions for converting ScribbledText or TypedText.
    */
   static Element toDOMElement(Document doc, DenimImage image) {
       Element e = doc.createElement(IMAGE_TAG);

       // Create <ID>
       e.appendChild(toDOMElement(doc, image.getUniqueID(), ID_TAG));

       // Create <AffineTransform>
       e.appendChild(toDOMElement(doc, image.getTransform(COORD_REL)));

       // Create <BoundingBox>
       e.appendChild(toDOMElement(doc, image.getBounds2D(COORD_LOCAL),
                                  BOUNDING_BOX_TAG));

       e.setAttribute("Image", image.getImageName());
       e.setAttribute("isLink", Boolean.toString(image.isLink()));

       return e;
   }
   
   /**
    * Reads a DOM element and returns a DenimText.
    */
   static DenimText createDenimTextFromDOMElement(Element e) {
      DenimText text = null;
      if (e.getTagName().equals(DENIM_TEXT_TAG)) {
         text = createTypedTextFromDOMElement(e);
      }

      else if (e.getTagName().equals(SCRIBBLE_TAG)) {
         text = createScribbleFromDOMElement(e);
      }
      else {
         assert false:
            "Element must be DenimText or Scribble, not " + e.getTagName();
      }
      return text;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a DenimLabel into a DOM element. The element's form is
    *
    * <DenimLabel>
    *   <ID>xx</ID>
    *   <AffineTransform>
    *     ...
    *   </AffineTransform>
    *   <BoundingBox>xx</ID>
    *   <StickyScaleFactor>xx</StickyScaleFactor>
    *   <Scribble>
    *     ...
    *   </Scribble>
    *   or
    *   <DenimText>
    *     ...
    *   </DenimText>
    * </DenimLabel>
    */
   static Element toDOMElement(Document doc, DenimLabel label) {
      Element e = doc.createElement(DENIM_LABEL_TAG);

      // Create <ID>
      e.appendChild(toDOMElement(doc, label.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      AffineTransform tx = label.getTransform(COORD_REL);
      e.appendChild(toDOMElement(doc, tx));

      // Create <BoundingBox>
      Rectangle2D newBounds = label.getUnstickyLocalBounds();

      e.appendChild(toDOMElement(doc, newBounds, BOUNDING_BOX_TAG));
      //debug.println(DenimUtils.toShortString(label));
      //debug.println("  local bounds: " + newBounds);

      // Create <StickyScaleFactor>
      e.appendChild(toDOMElement(doc, label.getStickyScaleFactor(),
                                 STICKY_SCALE_FACTOR_TAG));

      // Create <Scribble>
      // Modified by Will, added DneimText support
      if (label.getPhrase() instanceof ScribbledText) {
         e.appendChild(toDOMElement(doc, (ScribbledText)label.getPhrase()));
      }
      //Added Outpost image support:  Modified by Robert
      else if(!(label.getImageLocation()==null)){
         e.appendChild(toDOMElement(doc, label.getImageLocation(), DENIM_IMAGE_FILE_TAG));
      }else{
         e.appendChild(toDOMElement(doc, (TypedText)label.getPhrase()));
      }


      //DenimUtils.debugPrintBounds(label, "Saving");

      return e;
   }


   /**
    * Reads a DOM element and returns a DenimLabel.
    */
   static DenimLabel createDenimLabelFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(DENIM_LABEL_TAG):
                    "Element " + e.getTagName() + " is not DenimLabel";

      // Make sure element has right number of children
      NodeList children = e.getChildNodes();
      int len = children.getLength();
      assert len == 5:
                    "<" + e.getTagName() + "> should have 5 children";

      // Get bounding box from 3rd child
      Rectangle2D bounds = createRectangle2DFromDOMElement(
                           (Element)children.item(2), BOUNDING_BOX_TAG);

      // Get sticky scale factor from 4th child
      double stickyScaleFactor = createDoubleFromDOMElement(
                           (Element)children.item(3), STICKY_SCALE_FACTOR_TAG);
      // Get Scribble from 5th child
      Element labelContents = (Element)children.item(4);
      DenimText phrase;
      DenimLabel label;
      String imageFile;
      if (labelContents.getTagName().equals(DENIM_TEXT_TAG)) {
         phrase = createTypedTextFromDOMElement((Element)children.item(4));
         // Create DenimLabel
         label = new DenimLabel(bounds, phrase, stickyScaleFactor);
      }

      else if (labelContents.getTagName().equals(DENIM_IMAGE_FILE_TAG)) {
         imageFile = createStringFromDOMElement((Element)children.item(4), DENIM_IMAGE_FILE_TAG);
         // Create DenimLabel
         label = new DenimLabel (bounds, imageFile, stickyScaleFactor);
      }

      else {
         phrase = createScribbleFromDOMElement((Element)children.item(4));
         // Create DenimLabel
         label = new DenimLabel(bounds, phrase, stickyScaleFactor);
      }

      // Get transform from 2nd child
      label.setTransform(createAffineTransformFromDOMElement(
                            (Element)children.item(1)));

      // Get ID from 1st child
      label.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                ID_TAG));


      //DenimUtils.debugPrintBounds(label, "Just loaded");
      return label;
   }



   //-----------------------------------------------------------------

   /**
    * Converts a DenimHyperlinkInstance into a DOM element. The element's
    * form is
    *
    * <DenimHyperlinkInstance>
    *   <ID>xx</ID>
    *   <AffineTransform>
    *     ...
    *   </AffineTransform>
    *   <BoundingBox>
    *     ...
    *   </BoundingBox>
    *   <TimedStroke>
    *   ...
    *   </TimedStroke>
    *   ...
    * </DenimSketch>
    */
   static Element toDOMElement(Document doc, DenimHyperlinkInstance link) {
      Element e = doc.createElement(HYPERLINK_TAG);

      // Create <ID>
      e.appendChild(toDOMElement(doc, link.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, link.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, link.getBounds2D(COORD_LOCAL),
                                 BOUNDING_BOX_TAG));

      // Create <TimedStroke> or <Scribble>
      Iterator it = link.getReverseIterator();
      GraphicalObject gob = (GraphicalObject)it.next();
      // HACK: toDOMElement should be a method of the graphical object,
      // so we can dispatch to the right type
      if (gob instanceof TimedStroke) {
         e.appendChild(toDOMElement(doc, (TimedStroke)gob));
         while (it.hasNext()) {
            gob = (GraphicalObject)it.next();
            // HACK: toDOMElement should be a method of the graphical object,
            // so we can dispatch to the right type
            if (gob instanceof TimedStroke) {
               e.appendChild(toDOMElement(doc, (TimedStroke)gob));
            }
            else {
               assert false:
                "What? A DenimHyperlink shouldn't contain " + gob.getClass();
            }
         }
      }
      else if (gob instanceof ScribbledText) {
         e.appendChild(toDOMElement(doc, (ScribbledText)gob));
      }
      else if (gob instanceof TypedText) {
         e.appendChild(toDOMElement(doc, (TypedText)gob));
      }
     else if (gob instanceof DenimGroup) { // new for grouping anchors
         e.appendChild(toDOMElement(doc, (DenimGroup)gob));
      }
     else if (gob instanceof DenimImage) { // new for grouping anchors
         e.appendChild(toDOMElement(doc, (DenimImage)gob));
      }
      else {
         assert false: 
          "What? A DenimHyperlink shouldn't contain " + gob.getClass();
      }

      return e;
   }

   /**
    * Reads a DOM element and returns a DenimHyperlinkInstance.
    */
   static DenimHyperlinkInstance createDenimHyperlinkInstanceFromDOMElement
      (Element e,
      GraphicalObjectGroup parent) {

      // Make sure element has right tag
      assert e.getTagName().equals(HYPERLINK_TAG):
                    "Element " + e.getTagName() + " is not DenimHyperlink";

      NodeList children = e.getChildNodes();
      int len = children.getLength();

      // Get BoundingBox from third child
      Rectangle2D bounds = createRectangle2DFromDOMElement(
                           (Element)children.item(2), BOUNDING_BOX_TAG);

      // Get transform from second child
      AffineTransform tx = createAffineTransformFromDOMElement(
                            (Element)children.item(1));

      // Create hyperlink instance from first stroke
      Node child;
      String childName;
      DenimHyperlinkInstance link = null;

      child = (Element)children.item(3);
      childName = child.getNodeName();

      if (childName.equals(TIMED_STROKE_TAG)) {
         TimedStroke stk;
         stk = createTimedStrokeFromDOMElement((Element)child);

         link = (DenimHyperlinkInstance)
            ((DenimHyperlink)DenimComponentRegistry.getInstance().getComponent(
               "DenimHyperlink")).newInstance(bounds, tx, stk, parent);


         // For each of the rest of the children, get and add the graphical object
         for (int i = 4; i < len; i++) {
            child = children.item(i);
            childName = child.getNodeName();
            if (childName.equals(TIMED_STROKE_TAG)) {
               stk = createTimedStrokeFromDOMElement((Element)child);
               link.add(stk, GraphicalObjectGroup.KEEP_REL_POS);
            }
            else {
               assert false:
                  "Element " + childName + " cannot be within a " +
                    e.getTagName();
            }
         }
      }
      else if (childName.equals(SCRIBBLE_TAG)) {
         ScribbledText scribble = createScribbleFromDOMElement((Element)child);

         link = (DenimHyperlinkInstance)
            ((DenimHyperlink)DenimComponentRegistry.getInstance().getComponent(
               "DenimHyperlink")).newInstance(bounds, tx, scribble, parent);
      }
      else if (childName.equals(DENIM_TEXT_TAG)) {
         TypedText text = createTypedTextFromDOMElement((Element)child);

         link = (DenimHyperlinkInstance)
            ((DenimHyperlink)DenimComponentRegistry.getInstance().getComponent(
               "DenimHyperlink")).newInstance(bounds, tx, text, parent);
      }
      else if (childName.equals(IMAGE_TAG)) {
          DenimImage image = createImageFromDOMElement((Element)child);

          link = (DenimHyperlinkInstance)
             ((DenimHyperlink)DenimComponentRegistry.getInstance().getComponent(
                "DenimHyperlink")).newInstance(bounds, tx, image, parent);
       }
      else if (childName.equals(GROUP_TAG)) { // new for grouping anchors
            DenimGroup group =
               createGroupFromDOMElement((Element)child);
            finishCreatingDenimGroup((Element)child, group);
         link = (DenimHyperlinkInstance)
            ((DenimHyperlink)DenimComponentRegistry.getInstance().getComponent(
               "DenimHyperlink")).newInstance(bounds, tx, group, parent);
      }
      else {
         assert false:
            "Element " + childName + " cannot be within a " +
               e.getTagName();
      }

      // Get ID from first child
      link.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));

      return link;
   }


   //-----------------------------------------------------------------

   /**
    * Converts a DenimButtonInstance into a DOM element. The element's
    * form is
    *
    * <Button>
    *   <ID>xx</ID>
    *   <AffineTransform>
    *     ...
    *   </AffineTransform>
    *   <BoundingBox>
    *     ...
    *   </BoundingBox>
    *   <ButtonBorder>
    *   ...
    *   </ButtonBorder>
    *   <Caption>
    *   ...
    *   </Caption>
    *   <CreatedByStamp>
    *   ...
    *   </CreatedByStamp>
    * </Button>
    */
   static Element toDOMElement(Document doc, DenimButtonInstance button) {
      Element e = doc.createElement(BUTTON_TAG);
      Element newElement;

      // Create <ID>
      e.appendChild(toDOMElement(doc, button.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, button.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, button.getBounds2D(COORD_LOCAL),
                                 BOUNDING_BOX_TAG));

      // Create <ButtonBorder>
      newElement = doc.createElement(BUTTON_BORDER_TAG);
      e.appendChild(newElement);
      newElement.appendChild(toDOMElement(doc, button.getButtonBorder()));
      
      // Create <CreatedByStamp>
      e.appendChild(toDOMElement(doc, button.isCreatedByStamp(),
                                 CREATED_BY_STAMP_TAG));
      
      // Create <Caption>
      newElement = doc.createElement(CAPTION_TAG);
      e.appendChild(newElement);
      newElement.appendChild(toDOMElement(doc, button.getCaption()));
      
      return e;
   }

   //-----------------------------------------------------------------

   /**
    * Reads a DOM element and returns a button.
    */
   static DenimButtonInstance createButtonFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(BUTTON_TAG):
                    "Element " + e.getTagName() + " is not " + BUTTON_TAG;

      NodeList children = e.getChildNodes();

      // Get bounding box from 3rd child
      Rectangle2D bounds = createRectangle2DFromDOMElement
            ((Element)children.item(2), BOUNDING_BOX_TAG);

      // Get button border from 4th child
      Element buttonBorderElem = (Element)children.item(3);
      TimedStroke border = createTimedStrokeFromDOMElement(
         (Element)buttonBorderElem.getFirstChild());
      
      // Get created by stamp from 5th child
      boolean createdByStamp =
         createBooleanFromDOMElement((Element)children.item(4), CREATED_BY_STAMP_TAG);

      // Get caption from 6th child
      Element captionElem = (Element)children.item(5);
      DenimText caption =
         createDenimTextFromDOMElement((Element)captionElem.getFirstChild());

      // Create button         
      DenimButton buttonDef =
         (DenimButton)DenimComponentRegistry.getInstance().getComponent("Button");

      DenimButtonInstance button =
         (DenimButtonInstance)buttonDef.newInstance(
            bounds, border, caption, createdByStamp);

      // Get transform from 2nd child
      button.setTransform(createAffineTransformFromDOMElement(
                            (Element)children.item(1)));

      // Get ID from first child
      button.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));

      return button;
   }

   //-----------------------------------------------------------------

   /**
    * Reads a DOM element and returns a CheckBoxGroup (sort of).
    */
   static GraphicalObjectCollection createCheckBoxGroupFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(GROUP_TAG):
                    "Element " + e.getTagName() + " is not " + GROUP_TAG;

      GraphicalObjectCollection gobcol = new GraphicalObjectCollectionImpl();

      NodeList children = e.getChildNodes();
      int len = children.getLength();

      // For each of the rest of the children, get and add the graphical object
      for (int i = 0; i < len; i++) {
         DenimCheckBoxInstance checkbox =
            createCheckBoxFromDOMElement((Element)children.item(i));
         gobcol.add(checkbox);
      }

      return gobcol;
   }

   //-----------------------------------------------------------------

   /**
	* Converts a DenimCustomComponentInstance into a DOM element.
	*/
   static Element toDOMElement(Document doc, DenimCustomComponentInstance cusCom) {
		Element e = doc.createElement(CUSTOMINSTANCE_ID);
	
		// Create <ID>
		e.appendChild(toDOMElement(doc, cusCom.getUniqueID(), ID_TAG));
	
		// Create <AffineTransform>
		e.appendChild(toDOMElement(doc, cusCom.getTransform(COORD_REL)));
	
		// Create <BoundingBox>
		e.appendChild(toDOMElement(doc, cusCom.getBounds2D(COORD_LOCAL),
								   BOUNDING_BOX_TAG));
	
		String type = cusCom.getComponentType().getName();
		long state = cusCom.getDisplayedState().getUniqueID();
		
		e.appendChild(toDOMElement(doc, type, NAME_TAG));
		e.appendChild(toDOMElement(doc, state, ID_TAG));
	
		return e;
   }

   //-----------------------------------------------------------------

   /**
	* Reads a DOM element and returns a DenimCustomComponentInstance.
	*/
   
   static DenimCustomComponentInstance createDenimCustomComponentInstanceFromDOMElement(Element e) {

		assert e.getTagName().equals(CUSTOMINSTANCE_ID):
					  "Element " + e.getTagName() + " is not CustomComponentInstance";
	
		NodeList children = e.getChildNodes();
		int len = children.getLength();
	
		// create a DenimCustomComponentInstance
		long state = createLongFromDOMElement((Element)children.item(4),ID_TAG);
		String type = createStringFromDOMElement((Element)children.item(3),NAME_TAG);
		
		DenimComponent template = DenimComponentRegistry.getInstance().getComponent(type);
		DenimCustomComponentInstance custinstance = (DenimCustomComponentInstance)template.newInstance();
		
		//Set states= template.getStates();
		Iterator it = custinstance.getStates().getForwardIterator();
		//Iterator it = states.iterator();
		while(it.hasNext())
		{
			GraphicalObject obj = (GraphicalObject)it.next();
			if(obj.getUniqueID()==state)
			{
				custinstance.setDisplayedState(obj);				
				break;
			}
		}
		
		// Get BoundingBox from 3rd child
		custinstance.setBoundingPoints2D(COORD_REL, createRectangle2DFromDOMElement
			  ((Element)children.item(2), BOUNDING_BOX_TAG));
	
	
		// Get transform from 2nd child
	    custinstance.setTransform(createAffineTransformFromDOMElement(
							  (Element)children.item(1)));
	
		// Get ID from first child
	    custinstance.setUniqueID(createLongFromDOMElement((Element)children.item(0),
												   ID_TAG));
	
		return custinstance;
   }


   //-----------------------------------------------------------------

   /**
    * Converts a check box into a DOM element.
    */
   static Element toDOMElement(Document doc, DenimCheckBoxInstance checkBox) {
      Element e = doc.createElement(CHECK_BOX_TAG);
      Element newElement;

      // Create <ID>
      e.appendChild(toDOMElement(doc, checkBox.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, checkBox.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, checkBox.getBounds2D(COORD_LOCAL),
                                 BOUNDING_BOX_TAG));

      // Create <ButtonBorder>
      newElement = doc.createElement(BUTTON_BORDER_TAG);
      e.appendChild(newElement);
      newElement.appendChild(toDOMElement(doc, checkBox.getButtonBorder()));
      
      // Create <CreatedByStamp>
      e.appendChild(toDOMElement(doc, checkBox.isCreatedByStamp(),
                                 CREATED_BY_STAMP_TAG));
      
      // Create <Caption>
      newElement = doc.createElement(CAPTION_TAG);
      e.appendChild(newElement);
      newElement.appendChild(toDOMElement(doc, checkBox.getCaption()));
      
      // Create <Selected>
      e.appendChild(toDOMElement(doc, checkBox.getSelected(), SELECTED_INDEX_TAG));
      
      return e;
   }

   //-----------------------------------------------------------------

   /**
    * Reads a DOM element and returns a check box.
    */
   static DenimCheckBoxInstance createCheckBoxFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(CHECK_BOX_TAG):
                    "Element " + e.getTagName() + " is not " + CHECK_BOX_TAG;

      NodeList children = e.getChildNodes();

      // Get bounding box from 3rd child
      Rectangle2D bounds = createRectangle2DFromDOMElement
            ((Element)children.item(2), BOUNDING_BOX_TAG);

      // Get button border from 4th child
      Element buttonBorderElem = (Element)children.item(3);
      // bug fix: specify new last parameter so stroke is not curvy.  --marcr
      TimedStroke checkBoxBorder = createTimedStrokeFromDOMElement(
         (Element)buttonBorderElem.getFirstChild(), null, false, TIMED_STROKE_TAG, false);
      
      // Get created by stamp from 5th child
      boolean createdByStamp =
         createBooleanFromDOMElement((Element)children.item(4), CREATED_BY_STAMP_TAG);

      // Get caption from 6th child
      Element captionElem = (Element)children.item(5);
      DenimText caption =
         createDenimTextFromDOMElement((Element)captionElem.getFirstChild());
         
      // Get selected from 7th child
      boolean selected =
         createBooleanFromDOMElement((Element)children.item(6), SELECTED_TAG);

      DenimCheckBox checkBoxDef =
         (DenimCheckBox)DenimComponentRegistry.getInstance().getComponent("Check Box");
         
      DenimCheckBoxInstance checkBox =
         (DenimCheckBoxInstance)checkBoxDef.newInstance(
            bounds, selected, checkBoxBorder, caption, createdByStamp);

      // Get transform from 2nd child
      checkBox.setTransform(createAffineTransformFromDOMElement(
                            (Element)children.item(1)));

      // Get ID from first child
      checkBox.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));

      return checkBox;
   }

   //-----------------------------------------------------------------

   /**
    * Reads a DOM element and returns a RadioButtonGroup (sort of).
    */
   static GraphicalObjectCollection createRadioButtonGroupFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(GROUP_TAG):
                    "Element " + e.getTagName() + " is not " + GROUP_TAG;

      GraphicalObjectCollection gobcol = new GraphicalObjectCollectionImpl();

      NodeList children = e.getChildNodes();
      int len = children.getLength();

      // For each of the rest of the children, get and add the graphical object
      for (int i = 0; i < len; i++) {
         DenimRadioButtonInstance radioButton =
            createRadioButtonFromDOMElement((Element)children.item(i));
         gobcol.add(radioButton);
      }

      return gobcol;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a DenimRadioButtonInstance into a DOM element.
    */
   static Element toDOMElement(Document doc, DenimRadioButtonInstance radio) {
      Element e = doc.createElement(RADIO_BUTTON_TAG);
      Element newElement;

      // Create <ID>
      e.appendChild(toDOMElement(doc, radio.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, radio.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, radio.getBounds2D(COORD_LOCAL),
                                 BOUNDING_BOX_TAG));

      // Create <ButtonBorder>
      newElement = doc.createElement(BUTTON_BORDER_TAG);
      e.appendChild(newElement);
      newElement.appendChild(toDOMElement(doc, radio.getButtonBorder()));
      
      // Create <CreatedByStamp>
      e.appendChild(toDOMElement(doc, radio.isCreatedByStamp(),
                                 CREATED_BY_STAMP_TAG));
      
      // Create <Caption>
      newElement = doc.createElement(CAPTION_TAG);
      e.appendChild(newElement);
      newElement.appendChild(toDOMElement(doc, radio.getCaption()));
      
      // Create <Selected>
      e.appendChild(toDOMElement(doc, radio.getSelected(), SELECTED_TAG));
      
      return e;
   }

   //-----------------------------------------------------------------

   /**
    * Reads a DOM element and returns a radio button.
    */
   static DenimRadioButtonInstance createRadioButtonFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(RADIO_BUTTON_TAG):
                    "Element " + e.getTagName() + " is not " + RADIO_BUTTON_TAG;

      NodeList children = e.getChildNodes();

      // Get bounding box from 3rd child
      Rectangle2D bounds = createRectangle2DFromDOMElement
            ((Element)children.item(2), BOUNDING_BOX_TAG);

      // Get button border from 4th child
      Element buttonBorderElem = (Element)children.item(3);
      // bug fix: specify new last parameter so stroke is not curvy.  --marcr
      TimedStroke radioButtonBorder = createTimedStrokeFromDOMElement(
         (Element)buttonBorderElem.getFirstChild(), null, false, TIMED_STROKE_TAG, false);      
      // Get created by stamp from 5th child
      boolean createdByStamp =
         createBooleanFromDOMElement((Element)children.item(4), CREATED_BY_STAMP_TAG);

      // Get caption from 6th child
      Element captionElem = (Element)children.item(5);
      DenimText caption =
         createDenimTextFromDOMElement((Element)captionElem.getFirstChild());
         
      // Get selected from 7th child
      boolean selected =
         createBooleanFromDOMElement((Element)children.item(6), SELECTED_TAG);

      DenimRadioButton radioButtonDef =
         (DenimRadioButton)DenimComponentRegistry.getInstance().getComponent("Radio Button");
         
      DenimRadioButtonInstance radioButton =
         (DenimRadioButtonInstance)radioButtonDef.newInstance(
            bounds, selected, radioButtonBorder, caption, createdByStamp);

      // Get transform from 2nd child
      radioButton.setTransform(createAffineTransformFromDOMElement(
                            (Element)children.item(1)));

      // Get ID from first child
      radioButton.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));

      return radioButton;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a DenimComboBoxInstance into a DOM element.
    */
   static Element toDOMElement(Document doc, DenimComboBoxInstance comboBox) {
      Element e = doc.createElement(COMBO_BOX_TAG);
      Element newElement;

      // Create <ID>
      e.appendChild(toDOMElement(doc, comboBox.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, comboBox.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, comboBox.getBounds2D(COORD_LOCAL),
                                 BOUNDING_BOX_TAG));

      // Create <ButtonBorder>
      newElement = doc.createElement(BUTTON_BORDER_TAG);
      e.appendChild(newElement);
      newElement.appendChild(toDOMElement(doc, comboBox.getBorder()));
      
      // Create <DownArrow>
      newElement = doc.createElement(DOWN_ARROW_TAG);
      e.appendChild(newElement);
      newElement.appendChild(toDOMElement(doc, comboBox.getDownArrow()));
      newElement.appendChild(toDOMElement(doc,
                                          comboBox.isDownArrowFilled(),
                                          FILLED_TAG));
      
      
      // Create <CreatedByStamp>
      e.appendChild(toDOMElement(doc, comboBox.isCreatedByStamp(),
                                 CREATED_BY_STAMP_TAG));
      
      // Create <ListItems>
      Element listItemsElement = doc.createElement(LIST_ITEMS_TAG);
      e.appendChild(listItemsElement);
      
      GraphicalObjectCollection gobcol = comboBox.getItems();
      for (Iterator it = gobcol.getForwardIterator(); it.hasNext(); ) {
         // Create <ListItem>
         newElement = doc.createElement(LIST_ITEM_TAG);
         listItemsElement.appendChild(newElement);
         
         GraphicalObject gob = (GraphicalObject)it.next();

         // Add new element to <ListItem>
         if (gob instanceof TimedStroke) {
            newElement.appendChild(toDOMElement(doc, (TimedStroke)gob));
         }
         else if (gob instanceof ScribbledText) {
            newElement.appendChild(toDOMElement(doc, (ScribbledText)gob));
         }
         else if (gob instanceof TypedText) {
            newElement.appendChild(toDOMElement(doc, (TypedText)gob));
         }
         else {
            assert false:
               "An instance of " + gob.getClass() + " cannot be within a list item";
         }
         
      }
      
      // Create <SelectedIndex>
      e.appendChild(toDOMElement(doc, comboBox.getSelectedIndex(), SELECTED_TAG));
      
      return e;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a DenimComboBoxInstance into a DOM element.
    */
   static Element toDOMElement(Document doc, DenimListBoxInstance listBox) {
      Element e = doc.createElement(LIST_BOX_TAG);
      Element newElement;

      // Create <ID>
      e.appendChild(toDOMElement(doc, listBox.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, listBox.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, listBox.getBounds2D(COORD_LOCAL),
                                 BOUNDING_BOX_TAG));

      // Create <ButtonBorder>
      newElement = doc.createElement(BUTTON_BORDER_TAG);
      e.appendChild(newElement);
      newElement.appendChild(toDOMElement(doc, listBox.getBorder()));
      
      // Create <CreatedByStamp>
      e.appendChild(toDOMElement(doc, listBox.isCreatedByStamp(),
                                 CREATED_BY_STAMP_TAG));
      
      // Create <ListItems>
      Element listItemsElement = doc.createElement(LIST_ITEMS_TAG);
      e.appendChild(listItemsElement);
      
      GraphicalObjectCollection gobcol = listBox.getItems();
      for (Iterator it = gobcol.getForwardIterator(); it.hasNext(); ) {
         // Create <ListItem>
         newElement = doc.createElement(LIST_ITEM_TAG);
         listItemsElement.appendChild(newElement);
         
         GraphicalObject gob = (GraphicalObject)it.next();

         // Add new element to <ListItem>
         if (gob instanceof TimedStroke) {
            newElement.appendChild(toDOMElement(doc, (TimedStroke)gob));
         }
         else if (gob instanceof ScribbledText) {
            newElement.appendChild(toDOMElement(doc, (ScribbledText)gob));
         }
         else if (gob instanceof TypedText) {
            newElement.appendChild(toDOMElement(doc, (TypedText)gob));
         }
         else {
            assert false:
               "An instance of " + gob.getClass() + " cannot be within a list item";
         }
         
      }
      
      // Create <SelectedIndex>
      e.appendChild(toDOMElement(doc, listBox.getSelectedIndex(), SELECTED_TAG));
      
      return e;
   }

   //-----------------------------------------------------------------

   static DenimListBoxInstance createListBoxFromDOMElement(Element e) {
       // Make sure element has right tag
       assert e.getTagName().equals(LIST_BOX_TAG):
                     "Element " + e.getTagName() + " is not " + LIST_BOX_TAG;

       NodeList children = e.getChildNodes();

       // Get button border from 4th child
       Element buttonBorderElem = (Element)children.item(3);
       TimedStroke border = createTimedStrokeFromDOMElement(
          (Element)buttonBorderElem.getFirstChild());

       // Get created by stamp from 5th child
       boolean createdByStamp =
          createBooleanFromDOMElement((Element)children.item(4), CREATED_BY_STAMP_TAG);
       
       // Get items from 6th child
       GraphicalObjectCollection items = new GraphicalObjectCollectionImpl();
       Element listItemsElem = (Element)children.item(5);
       NodeList listItems = listItemsElem.getChildNodes();
       int numItems = listItems.getLength();
       for (int i = 0; i < numItems; i++) {
          Element listItemElem = (Element)listItems.item(i);
          Element child = (Element)listItemElem.getFirstChild();

          String childName = child.getNodeName();

          if (childName.equals(TIMED_STROKE_TAG)) {
             TimedStroke stk =
                createTimedStrokeFromDOMElement((Element)child);
             items.addToBack(stk);
          }

          else if (childName.equals(SCRIBBLE_TAG)) {
             ScribbledText scribble =
                createScribbleFromDOMElement((Element)child);
             items.addToBack(scribble);
          }

          else if (childName.equals(DENIM_TEXT_TAG)) {
             TypedText text =
                createTypedTextFromDOMElement((Element)child);
             items.addToBack(text);
          }

          else {
             assert false:
                "Element " + childName + " cannot be within a " + e.getTagName();
          }
       }
       
       // Get selected index from 6th child
       int selectedIndex =
          createIntFromDOMElement((Element)children.item(6), SELECTED_INDEX_TAG);

       DenimListBox listBoxDef =
          (DenimListBox)DenimComponentRegistry.getInstance().getComponent("List Box");
          
       DenimListBoxInstance listBox =
          (DenimListBoxInstance)listBoxDef.newInstance();
             //border, createdByStamp, items, selectedIndex);
       
       listBox.setBoundingPoints2D(COORD_REL, border);
       listBox.setItems(items);
       listBox.setSelectedIndex(selectedIndex);

       // Get transform from 2nd child
       listBox.setTransform(createAffineTransformFromDOMElement(
                             (Element)children.item(1)));

       // Get ID from first child
       listBox.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                  ID_TAG));

       return listBox;
    }

    //-----------------------------------------------------------------   

   /**
    * Reads a DOM element and returns a ComboBox.
    */
   static DenimComboBoxInstance createComboBoxFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(COMBO_BOX_TAG):
                    "Element " + e.getTagName() + " is not " + COMBO_BOX_TAG;

      NodeList children = e.getChildNodes();

      // Get button border from 4th child
      Element buttonBorderElem = (Element)children.item(3);
      TimedStroke border = createTimedStrokeFromDOMElement(
         (Element)buttonBorderElem.getFirstChild());

      // Get down arrow from 5th child
      Element downArrowElem = (Element)children.item(4);
      TimedStroke downArrow = createTimedStrokeFromDOMElement(
         (Element)downArrowElem.getFirstChild());
      boolean downArrowFilled = createBooleanFromDOMElement(
         (Element)downArrowElem.getLastChild(), FILLED_TAG);
      
      // Get created by stamp from 6th child
      boolean createdByStamp =
         createBooleanFromDOMElement((Element)children.item(5), CREATED_BY_STAMP_TAG);

      // Get items from 7th child
      GraphicalObjectCollection items = new GraphicalObjectCollectionImpl();
      Element listItemsElem = (Element)children.item(6);
      NodeList listItems = listItemsElem.getChildNodes();
      int numItems = listItems.getLength();
      for (int i = 0; i < numItems; i++) {
         Element listItemElem = (Element)listItems.item(i);
         Element child = (Element)listItemElem.getFirstChild();

         String childName = child.getNodeName();

         if (childName.equals(TIMED_STROKE_TAG)) {
            TimedStroke stk =
               createTimedStrokeFromDOMElement((Element)child);
            items.addToBack(stk);
         }

         else if (childName.equals(SCRIBBLE_TAG)) {
            ScribbledText scribble =
               createScribbleFromDOMElement((Element)child);
            items.addToBack(scribble);
         }

         else if (childName.equals(DENIM_TEXT_TAG)) {
            TypedText text =
               createTypedTextFromDOMElement((Element)child);
            items.addToBack(text);
         }

         else {
            assert false:
               "Element " + childName + " cannot be within a " + e.getTagName();
         }
      }
      
      // Get selected index from 8th child
      int selectedIndex =
         createIntFromDOMElement((Element)children.item(7), SELECTED_INDEX_TAG);

      DenimComboBox comboBoxDef =
         (DenimComboBox)DenimComponentRegistry.getInstance().getComponent("Combo Box");
         
      DenimComboBoxInstance comboBox =
         (DenimComboBoxInstance)comboBoxDef.newInstance(
            border, downArrow, downArrowFilled, createdByStamp, items,
            selectedIndex);

      // Get transform from 2nd child
      comboBox.setTransform(createAffineTransformFromDOMElement(
                            (Element)children.item(1)));

      // Get ID from first child
      comboBox.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));

      return comboBox;
   }

   //-----------------------------------------------------------------

   /**
    * Converts a DenimTextFieldInstance into a DOM element. The element's
    * form is
    *
    * <DenimTextFieldInstance>
    *   <ID>xx</ID>
    *   <AffineTransform>
    *     ...
    *   </AffineTransform>
    *   <BoundingBox>
    *     ...
    *   </BoundingBox>
    *   <Text>
    *   ...
    *   </Text>
    *   ...
    * </DenimSketch>
    */
   static Element toDOMElement(Document doc, DenimTextFieldInstance tf) {
      Element e = doc.createElement(TEXT_FIELD_TAG);

      // Create <ID>
      e.appendChild(toDOMElement(doc, tf.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, tf.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, tf.getBounds2D(COORD_LOCAL),
                                 BOUNDING_BOX_TAG));

      // Create <Text>
      e.appendChild(toDOMElement(doc, tf.getText(), TEXT_TAG));

      return e;
   }

   /**
    * Reads a DOM element and returns a DenimTextFieldInstance.
    */
   static DenimTextFieldInstance createDenimTextFieldInstanceFromDOMElement
      (Element e) {

      // Make sure element has right tag
      assert e.getTagName().equals(TEXT_FIELD_TAG):
         "Element " + e.getTagName() + " is not DenimTextFieldInstance";

      NodeList children = e.getChildNodes();

      // Create text field instance
      DenimTextFieldInstance tf;

      tf = (DenimTextFieldInstance)
           ((DenimTextField)DenimComponentRegistry.getInstance().getComponent(
            "DenimTextField")).newInstance();

      // Get ID from first child
      tf.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                              ID_TAG));

      // Get transform from second child
      tf.setTransform(createAffineTransformFromDOMElement
         ((Element)children.item(1)));

      // Get BoundingBox from third child
      //Rectangle2D bounds = createRectangle2DFromDOMElement(
      //                     (Element)children.item(2), BOUNDING_BOX_TAG);

      // Get text from Text node
      NodeList textNodes = e.getElementsByTagName(TEXT_TAG);
      
      assert textNodes.getLength() == 1:
         "DenimTextFieldInstance must have 1 Text child node";
         
      tf.setText(createStringFromDOMElement((Element)textNodes.item(0),
                                            TEXT_TAG));

      return tf;
   }

   //-----------------------------------------------------------------
   
   /**
    * Converts a DenimGroup into a DOM element.
    */
    static Element toDOMElement(Document doc, DenimGroup group) {
      Element e = doc.createElement(GROUP_TAG);

      // Create <ID>
      e.appendChild(toDOMElement(doc, group.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, group.getTransform(COORD_REL)));

      // Create <Border>
      Element newElement = doc.createElement(BORDER_TAG);
      e.appendChild(newElement);
      newElement.appendChild(toDOMElement(
         doc, new TimedStroke(group.getBoundingPoints2D(COORD_LOCAL))));

      // Create <TimedStroke> or <DenimHyperlinkInstance>...
      addCollectionToDOMElement(e, group.getReverseIterator());
      
      return e;
    }
   

   /**
    * Reads a DOM element and returns an empty DenimGroup.
    */
   static DenimGroup createGroupFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(GROUP_TAG):
                    "Element " + e.getTagName() + " is not Group";

      NodeList children = e.getChildNodes();

      // Get Border from 3rd child
      Element borderElem = (Element)children.item(2);
      TimedStroke border = createTimedStrokeFromDOMElement(
         (Element)borderElem.getFirstChild());
      
      DenimGroup group = new DenimGroup(border);

      // Get transform from 2nd child
      group.setTransform(createAffineTransformFromDOMElement(
                            (Element)children.item(1)));

      // Get ID from 1st child
      group.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));

      return group;
   }

   static void finishCreatingDenimGroup(Element e, DenimGroup group) {
      addDOMElementChildrenToCollection(
         e, GROUP_TAG, 3, e.getChildNodes().getLength(), group);
   }
   
   //-----------------------------------------------------------------

   /**
    * Converts a DenimSketch into a DOM element. The element's form is
    *
    * <DenimSketch>
    *   <ID>xx</ID>
    *   <AffineTransform>
    *     ...
    *   </AffineTransform>
    *   <BoundingBox>
    *     ...
    *   </BoundingBox>
    *   <TimedStroke>
    *   ...
    *   </TimedStroke>
    *   <DenimHyperlinkInstance>
    *   ...
    *   </DenimHyperlinkInstance>
    *   ...
    * </DenimSketch>
    */
    static Element toDOMElement(Document doc, DenimSketch sketch) {
      Element e = doc.createElement(DENIM_SKETCH_TAG);

      // Create <ID>
      e.appendChild(toDOMElement(doc, sketch.getUniqueID(), ID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, sketch.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, sketch.getBounds2D(COORD_LOCAL),
                                 BOUNDING_BOX_TAG));

      // Create <TimedStroke> or <DenimHyperlinkInstance>...
      addCollectionToDOMElement(e, sketch.getReverseIterator());
      /*Iterator it = sketch.getReverseIterator();
      while (it.hasNext()) {
         GraphicalObject gob = (GraphicalObject)it.next();
         // HACK: toDOMElement should be a method of the graphical object,
         // so we can dispatch to the right type
         if (gob instanceof TimedStroke) {
            e.appendChild(toDOMElement(doc, (TimedStroke)gob));
         }
         else if (gob instanceof ScribbledText) {
            e.appendChild(toDOMElement(doc, (ScribbledText)gob));
         }
         else if (gob instanceof TypedText) {
            e.appendChild(toDOMElement(doc, (TypedText)gob));
         }
         else if (gob instanceof DenimHyperlinkInstance) {
            e.appendChild(toDOMElement(doc, (DenimHyperlinkInstance)gob));
         }
         else if (gob instanceof DenimTextFieldInstance) {
            e.appendChild(toDOMElement(doc, (DenimTextFieldInstance)gob));
         }
         else if (gob instanceof DenimRadioButtonInstance) {
            e.appendChild(toDOMElement(doc, (DenimRadioButtonInstance)gob));
         }
         else {
            assert false: 
               "What? A DenimSketch shouldn't contain " + gob.getClass();
         }
      }*/

      //DenimUtils.debugPrintBounds(sketch, "Saving");

      return e;
   }

   /**
    * Reads a DOM element and returns an empty DenimSketch.
    */
   static DenimSketch createDenimSketchFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(DENIM_SKETCH_TAG):
                    "Element " + e.getTagName() + " is not DenimSketch";

      NodeList children = e.getChildNodes();

      // Get BoundingBox from 3rd child
      DenimSketch sketch =
         new DenimSketch(createRectangle2DFromDOMElement(
                           (Element)children.item(2), BOUNDING_BOX_TAG));

      // Get transform from 2nd child
      sketch.setTransform(createAffineTransformFromDOMElement(
                            (Element)children.item(1)));

      // Get ID from 1st child
      sketch.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));
      return sketch;
   }

   //-----------------------------------------------------------------

   /**
    * Adds objects from a collection with the given iterator to the
    * given DOM element.
    */
   static void addCollectionToDOMElement(Element e, Iterator it) {
      Document doc = e.getOwnerDocument();
      
      // Create <TimedStroke> or <DenimHyperlinkInstance>...
      while (it.hasNext()) {
         GraphicalObject gob = (GraphicalObject)it.next();
         // HACK: toDOMElement should be a method of the graphical object,
         // so we can dispatch to the right type
         if (gob instanceof TimedStroke) {
            e.appendChild(toDOMElement(doc, (TimedStroke)gob));
         }
         else if (gob instanceof ScribbledText) {
            e.appendChild(toDOMElement(doc, (ScribbledText)gob));
         }
         else if (gob instanceof TypedText) {
            e.appendChild(toDOMElement(doc, (TypedText)gob));
         }
         else if (gob instanceof DenimHyperlinkInstance) {
            e.appendChild(toDOMElement(doc, (DenimHyperlinkInstance)gob));
         }
         else if (gob instanceof DenimTextFieldInstance) {
            e.appendChild(toDOMElement(doc, (DenimTextFieldInstance)gob));
         }
         else if (gob instanceof DenimRadioButtonInstance) {
            e.appendChild(toDOMElement(doc, (DenimRadioButtonInstance)gob));
         }
         else if (gob instanceof DenimCheckBoxInstance) {
            e.appendChild(toDOMElement(doc, (DenimCheckBoxInstance)gob));
         }
         else if (gob instanceof DenimComboBoxInstance) {
            e.appendChild(toDOMElement(doc, (DenimComboBoxInstance)gob));
         }
         else if (gob instanceof DenimButtonInstance) {
            e.appendChild(toDOMElement(doc, (DenimButtonInstance)gob));
         }
         else if (gob instanceof DenimListBoxInstance) {
            e.appendChild(toDOMElement(doc, (DenimListBoxInstance)gob));
         }
         else if (gob instanceof DenimGroup) {
            e.appendChild(toDOMElement(doc, (DenimGroup)gob));
         }
         else if (gob instanceof DenimCustomComponentInstance)
         {
			e.appendChild(toDOMElement(doc, (DenimCustomComponentInstance)gob));
         }
         else if (gob instanceof DenimImage)
         {
            e.appendChild(toDOMElement(doc, (DenimImage)gob));
         }
         else {
            assert false: 
               "What? A DenimSketch shouldn't contain " + gob.getClass();
         }
      }

   }

   /**
    * Adds all of the elements nested with the given DOM element to the given
    * GraphicalObjectCollection.
    */
   static void addDOMElementChildrenToCollection(
      Element e, String tagName, int firstChildNum, int beyondLastChildNum, 
      GraphicalObjectCollection gobcol) {

      assert e.getTagName().equals(tagName):
                    "Element " + e.getTagName() + " is not " + tagName;

      NodeList children = e.getChildNodes();
      
      for (int i = firstChildNum; i < beyondLastChildNum; i++) {
         Node child = children.item(i);
         String childName = child.getNodeName();

         if (childName.equals(TIMED_STROKE_TAG)) {
            TimedStroke stk =
               createTimedStrokeFromDOMElement((Element)child);
            gobcol.add(stk);

            //DenimUtils.debugPrintBounds(stk, "Adding");
            //DenimUtils.debugPrintBounds(sketch, "Parent");
            //debug.println("");
         }

         else if (childName.equals(SCRIBBLE_TAG)) {
            ScribbledText scribble =
               createScribbleFromDOMElement((Element)child);
            gobcol.add(scribble);
         }

         else if (childName.equals(IMAGE_TAG)) {
             DenimImage image =
                createImageFromDOMElement((Element)child);
             gobcol.add(image);
          }
         
         else if (childName.equals(DENIM_TEXT_TAG)) {
            TypedText text =
               createTypedTextFromDOMElement((Element)child);
            gobcol.add(text);
         }

         else if (childName.equals(HYPERLINK_TAG)) {
            if (gobcol instanceof GraphicalObjectGroup) {
               DenimHyperlinkInstance link =
                  createDenimHyperlinkInstanceFromDOMElement(
                     (Element)child,
                     (GraphicalObjectGroup)gobcol);
            }
         }

         else if (childName.equals(TEXT_FIELD_TAG)) {
            DenimTextFieldInstance tf =
               createDenimTextFieldInstanceFromDOMElement((Element)child);
            gobcol.add(tf);
         }

         else if (childName.equals(BUTTON_TAG)) {
            DenimButtonInstance button =
               createButtonFromDOMElement((Element)child);
            gobcol.add(button);
            DenimPanel panel = button.getContainingPanel();
            if (panel != null) {
               panel.componentInstanceIsAdded(button);
            }
         }

         else if (childName.equals(COMBO_BOX_TAG)) {
            DenimComboBoxInstance comboBox =
               createComboBoxFromDOMElement((Element)child);
            gobcol.add(comboBox);
            DenimPanel panel = comboBox.getContainingPanel();
            if (panel != null) {
               panel.componentInstanceIsAdded(comboBox);
            }
         }
         
         else if (childName.equals(LIST_BOX_TAG)) {
             DenimListBoxInstance listBox =
                createListBoxFromDOMElement((Element)child);
             gobcol.add(listBox);
             DenimPanel panel = listBox.getContainingPanel();
             if (panel != null) {
                panel.componentInstanceIsAdded(listBox);
             }
         }

         else if (childName.equals(CHECK_BOX_TAG)) {
            DenimCheckBoxInstance checkBox =
               createCheckBoxFromDOMElement((Element)child);
            gobcol.add(checkBox);
            DenimPanel panel = checkBox.getContainingPanel();
            if (panel != null) {
               panel.componentInstanceIsAdded(checkBox);
            }
         }

         else if (childName.equals(RADIO_BUTTON_TAG)) {
            DenimRadioButtonInstance radioButton =
               createRadioButtonFromDOMElement((Element)child);
            gobcol.add(radioButton);
            DenimPanel panel = radioButton.getContainingPanel();
            if (panel != null) {
               panel.componentInstanceIsAdded(radioButton);
            }
         }

         else if (childName.equals(GROUP_TAG)) {
            DenimGroup group =
               createGroupFromDOMElement((Element)child);
            gobcol.add(group);
            finishCreatingDenimGroup((Element)child, group);
         }
         
         else if (childName.equals(CUSTOMINSTANCE_ID)) {
			DenimCustomComponentInstance custinstance =
				createDenimCustomComponentInstanceFromDOMElement((Element)child);
			gobcol.add(custinstance);
			DenimPanel panel = custinstance.getContainingPanel();
			if (panel != null) {
			   panel.componentInstanceIsAdded(custinstance);
			}
		 }

         else {
            assert false:
               "Element " + childName + " cannot be within a " + e.getTagName();
         }
      }
   }


   /**
    * Adds all of the elements nested with a <DenimSketch> to the given
    * DenimSketch. At this point, the DenimSketch has been added to the
    * appropriate container.
    */
   static void finishCreatingDenimSketch(Element e, DenimSketch sketch) {
      // Make sure element has right tag
      assert e.getTagName().equals(DENIM_SKETCH_TAG):
                      "Element " + e.getTagName() + " is not DenimSketch";

      NodeList children = e.getChildNodes();
      int len = children.getLength();

      // make sure the given DenimSketch is the same as the DenimSketch
      // in the DOM
      long id = createLongFromDOMElement((Element)children.item(0), ID_TAG);
      assert sketch.getUniqueID() == id:
                 "Element " + e.  getTagName() + " does not have ID " + id +
                   ", has " +  sketch.getUniqueID() + " instead.";

      addDOMElementChildrenToCollection(e, DENIM_SKETCH_TAG, 3, len, sketch);
      
      /*// For each of the rest of the children, get and add the graphical object
      for (int i = 3; i < len; i++) {
         Node child = children.item(i);
         String childName = child.getNodeName();

         if (childName.equals(TIMED_STROKE_TAG)) {
            TimedStroke stk =
               createTimedStrokeFromDOMElement((Element)child);
            sketch.add(stk, GraphicalObjectGroup.KEEP_REL_POS);

            //DenimUtils.debugPrintBounds(stk, "Adding");
            //DenimUtils.debugPrintBounds(sketch, "Parent");
            //debug.println("");
         }

         else if (childName.equals(SCRIBBLE_TAG)) {
            ScribbledText scribble =
               createScribbleFromDOMElement((Element)child);
            sketch.add(scribble, GraphicalObjectGroup.KEEP_REL_POS);
         }

         else if (childName.equals(DENIM_TEXT_TAG)) {
            TypedText text =
               createTypedTextFromDOMElement((Element)child);
            sketch.add(text, GraphicalObjectGroup.KEEP_REL_POS);
         }

         else if (childName.equals(HYPERLINK_TAG)) {
            DenimHyperlinkInstance link =
               createDenimHyperlinkInstanceFromDOMElement((Element)child,
                                                          sketch);
         }

         else if (childName.equals(TEXT_FIELD_TAG)) {
            DenimTextFieldInstance tf =
               createDenimTextFieldInstanceFromDOMElement((Element)child);
            sketch.add(tf, GraphicalObjectGroup.KEEP_REL_POS);
         }

         else if (childName.equals(BUTTON_TAG)) {
            DenimHyperlinkInstance button =
               createDenimButtonInstanceFromDOMElement((Element)child, sketch);
         }

         else if (childName.equals(COMBO_BOX_TAG)) {
            ScribbledText comboBox =
               createComboBoxFromDOMElement((Element)child);
            sketch.add(comboBox, GraphicalObjectGroup.KEEP_REL_POS);
         }

         else if (childName.equals(CHECK_BOX_TAG)) {
            ScribbledText checkBox =
               createCheckBoxFromDOMElement((Element)child);
            sketch.add(checkBox, GraphicalObjectGroup.KEEP_REL_POS);
         }

         else if (childName.equals(RADIO_BUTTON_TAG)) {
            DenimRadioButtonInstance radioButton =
               createRadioButtonFromDOMElement((Element)child);
            sketch.add(radioButton, GraphicalObjectGroup.KEEP_REL_POS);
            sketch.getPanel().componentInstanceIsAdded(radioButton);
         }

         else if (childName.equals(GROUP_TAG)) {
            GraphicalObjectCollection gobcol =
               createCheckBoxGroupFromDOMElement((Element)child);
            for (Iterator it = gobcol.getReverseIterator(); it.hasNext(); ) {
               ScribbledText checkBox = (ScribbledText)it.next();
               sketch.add(checkBox, GraphicalObjectGroup.KEEP_REL_POS);
            }
         }

         else {
            assert false:
               "Element " + childName + " cannot be within a " + e.getTagName();
         }

      }*/
   }

   //-----------------------------------------------------------------

   /**
    * Converts a DenimPanel into a DOM element. The element's form is
    *
    * <DenimPanel>
    *   <ID>xx</ID>
    *   <AffineTransform>
    *     ...
    *   </AffineTransform>
    *   <BoundingBox>
    *     ...
    *   </BoundingBox>
    *   <DenimLabel>
    *   ...
    *   </DenimLabel>
    *   <DenimSketch>
    *   ...
    *   </DenimSketch>
    * </DenimSketch>
    *
    * The BoundingBox element isn't strictly necessary, but we're not sure
    * whether DenimPanel(DenimLabel, DenimSketch) works properly, so it's
    * better safe than sorry.
    */
   static Element toDOMElement(Document doc, DenimPanel panel) {
      
      panel.saveComponentInstanceStates();
       
      Element e = doc.createElement(DENIM_PANEL_TAG);
      
      e.setAttribute("IsHome", Boolean.toString(panel.isHome()));

      e.setAttribute("StateID", Long.toString(panel.getStateID()));
      
      // Create <ID>
      e.appendChild(toDOMElement(doc, panel.getUniqueID(), ID_TAG));

      //DenimUtils.debugPrintBounds(panel, "Saving");

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, panel.getTransform(COORD_REL)));

      // Create <BoundingBox>
      e.appendChild(toDOMElement(doc, panel.getBounds2D(COORD_LOCAL), BOUNDING_BOX_TAG));

      // Create <DenimLabel>
      e.appendChild(toDOMElement(doc, panel.getLabel()));

      // Create <DenimSketch>
      e.appendChild(toDOMElement(doc, panel.getSketch()));
      
      // save conditional to DOM
	  panel.syncCondition(panel.getCurrentDesignTimeCondition());
	  DenimPanel.ComponentConditionMap2D states = panel.getConditionStates();
	  int condition = panel.getCurrentDesignTimeCondition();
	  e.appendChild(toDOMElement(doc, states, condition));
	  
      return e;
   }

   /**
    * 
    * Root
    *    currentcondition
    * 	 instances
    *      ComponentInstance
    *        id
    *        states
    *          	state1
    *           state2
    *             ...
    *           staten
    *      
    */
   
   private static Element toDOMElement(Document doc, DenimPanel.ComponentConditionMap2D states, int currentCondition) {

		Element root = doc.createElement("ComponentConditionMap2D");
		
		//print(states);
				
		root.setAttribute("CurrentCondition", Integer.toString(currentCondition));
		root.setAttribute("ConditionNum", Integer.toString(states.numCols()));
	
		for(int i=0; i<states.getRows().size(); i++)
		{
			Object rowHeader = states.getRowHeader(i);
			long rowid = ((DenimComponentInstance)states.getRowHeader(i))
								.getUniqueID();
								
			Iterator it = states.getCols().iterator();
			while(it.hasNext())
			{
				Integer colHeader = (Integer)it.next();
                
                if(colHeader==null)
                    continue;
				
				Element state = doc.createElement("State");
				root.appendChild(state);
				
				state.setAttribute("RowHead", Long.toString(rowid));
				state.setAttribute("ColHead", colHeader.toString());
				state.setAttribute("Value", 
						Long.toString(((GraphicalObject)states.get(rowHeader, colHeader)).getUniqueID()));
			}
		}
		return root;
   }
   
   //---------------------------------------------------------------------
   
   private static void addStateMap2DToPanel(Element e, DenimPanel panel) {
	
		// Make sure element has right tag
		assert e.getTagName().equals("ComponentConditionMap2D"):
					"Element " + e.getTagName() + " is not ComponentConditionMap2D";

		int currentCondition = Integer.parseInt(e.getAttribute("CurrentCondition"));
		int conditionNum = Integer.parseInt(e.getAttribute("ConditionNum"));

		//put some values in the map
	    panel.syncCondition(1);

		//it's insertion not appending
		// index 0 is already there
		for(int i=1; i<conditionNum; i++)
		{
			//yes, insert at index 1 each time
			panel.addConditionAt(1);
			//print(panel.getConditionStates());	
		}

		/**
		 * put states in the map2D
		 */
		NodeList list = e.getChildNodes();
	    //print(panel.getConditionStates());
//		System.out.println("---------------------------------------------");
		for(int i=0; i<conditionNum; i++)
		{
			ArrayList column = getColumn(list, i+1);
			Iterator it = column.iterator();
			while(it.hasNext())
			{
				Element child = (Element)it.next();
				long rowid = Long.parseLong(
									child.getAttribute("RowHead"));
				long valueid = Long.parseLong(
									child.getAttribute("Value"));
				panel.setInstanceState(rowid, valueid);
			}
			panel.syncCondition(i+1);
			//print(panel.getConditionStates());				
		}
//		System.out.println("---------------------------------------------");
		panel.setCurrentDesignTimeCondition(currentCondition);
   }
   
   static void print(DenimPanel.ComponentConditionMap2D map2D) {
	  System.out.println("###############   Start  #################");
	  
      Iterator it = map2D.getCols().iterator();
      while(it.hasNext())
      {
		Object colH = it.next();
	 	 System.out.println("---> A condition <----- " + ((Integer)colH).toString());

		 Iterator rowH = map2D.getRows().iterator();
		 while(rowH.hasNext())
		 {
		 	Object row = rowH.next();
		 	GraphicalObject gob = (GraphicalObject)map2D.get(row, colH);
		 	long id = gob.getUniqueID();
		 	System.out.println("state: " + id);
		 }
      }
      
	  System.out.println("################    End   #################");
   }
   
   static private ArrayList getColumn(NodeList list, int col) {
   		ArrayList res = new ArrayList();
		int len = list.getLength();
		for(int i=0; i<len; i++)
		{
			Element child = (Element)list.item(i);
			int colid = Integer.parseInt(
								child.getAttribute("ColHead"));
			if(col==colid)
				res.add(child);
		}   	  
		return res;
   }
   
   
   /**
    * Reads a DOM element and returns a DenimPanel.
    */
   static void addDenimPanelFromDOMElement(Element e, DenimSheet sheet) {
      // Make sure element has right tag
      assert e.getTagName().equals(DENIM_PANEL_TAG):
                    "Element " + e.getTagName() + " is not DenimPanel";

      // Make sure element has right number of children
      NodeList children = e.getChildNodes();
      int len = children.getLength();
      assert len == 5: "<" + e.getTagName() + "> should have 5 children";

      // Get bounds from 3rd child
      Element sketchElement = (Element)children.item(4);
      DenimSketch sketch = createDenimSketchFromDOMElement(sketchElement);
      DenimLabel label = createDenimLabelFromDOMElement(
                           (Element)children.item(3));

      Rectangle2D newBounds = createRectangle2DFromDOMElement(
                           (Element)children.item(2), BOUNDING_BOX_TAG);

      // Get transform from 2nd child
      AffineTransform tx = createAffineTransformFromDOMElement(
                            (Element)children.item(1));

      DenimPanel panel = new DenimPanel(newBounds, tx, label, sketch);
      
      if(e.hasAttribute("StateID"))
          panel.setStateID(Long.parseLong(e.getAttribute("StateID")));


          
      sheet.add(panel, GraphicalObjectGroup.KEEP_REL_POS);

      finishCreatingDenimSketch(sketchElement, sketch);

      //debug.println("rectangle: " + createRectangle2DFromDOMElement(
      //                     (Element)children.item(2), BOUNDING_BOX_TAG));

      // Get ID from 1st child
      panel.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                ID_TAG));

      // HACK: Fix view for label and sketch, now that they have been
      // added to sheet
      label.initAfterAddLabelToSheet();
      sketch.initAfterAddSketchToSheet();


      // If the label contains scribbled text, then adjust the width of the
      // strokes
      if (label.getPhrase() instanceof ScribbledText) {
         ScribbledText phrase = (ScribbledText)label.getPhrase();
         Iterator it = phrase.getForwardIterator();
         while (it.hasNext()) {
            TimedStroke stk = (TimedStroke)it.next();
            stk.getStyleRef().setLineWidth
               ((float)(1.0 / DenimUtils.getTrueAbsXform(stk).getScaleX()));
         }
      }

      //DenimUtils.debugPrintBounds(panel, "Creating");
      //DenimUtils.debugPrintBounds(sketch, "Creating");
      //DenimUtils.debugPrintBounds(label, "Creating");
      //return panel;
      
      if(children.getLength()>5)
      	  addStateMap2DToPanel((Element)children.item(5), panel);
      
      if(e.hasAttribute("IsHome"))
      {
          if(e.getAttribute("IsHome").startsWith("true"))
          {
              sheet.setHomePanel(panel);
          }
      }
   }


   //-----------------------------------------------------------------

   /**
    * Converts an InkAnnotation into a DOM element. The element's
    * form is
    *
    * <InkAnnotation>
    *   <AnchorIDRef>...</AnchorIDRef>
    *   <TimedStroke>
    *   ...
    *   </TimedStroke>
    *   ...
    * </InkAnnotation>
    *
    * @param saveRefsOnly true if the DOM should represent the actual
    * strokes or only the IDs of the strokes
    */
   static Element toDOMElement(Document doc, InkAnnotation annos,
                               boolean saveRefsOnly) {
      Element e;
      if (saveRefsOnly) {
         e = doc.createElement(INK_ANNOTATION_REF_TAG);
      }
      else {
         e = doc.createElement(INK_ANNOTATION_TAG);
      }

      // Create <AnchorIDRef>. Ignored for now.
      e.appendChild(toDOMElement(doc, annos.getAnchor().getUniqueID(),
                                 ANCHOR_ID_REF_TAG));

      // Create <TimedStroke>...
      Iterator it = annos.getReverseIterator();
      while (it.hasNext()) {
         TimedStroke stk = (TimedStroke)it.next();
         if (saveRefsOnly) {
            e.appendChild(toDOMElement(doc, stk.getUniqueID(), ID_REF_TAG));
         }
         else {
            e.appendChild(toDOMElement(doc, stk, true));
         }
      }

      return e;
   }

   /**
    * Reads a DOM element and returns a InkAnnotation.
    */
   static InkAnnotation
   createInkAnnotationFromDOMElement(Element e, DenimSheet sheet,
                                     String reviewer, boolean loadRefsOnly) {
      String tagName = e.getTagName();

      if (tagName.equals(INK_ANNOTATION_TAG)) {
         assert !loadRefsOnly: 
          tagName + " encountered, but you only want to load refs.";
      }
      else if (tagName.equals(INK_ANNOTATION_REF_TAG)) {
         assert loadRefsOnly: 
          tagName + " encountered, but you want to load strokes.";
      }
      else {
         assert false:
            "Element " + e.getTagName() + " is not " +
            INK_ANNOTATION_TAG + " or " + INK_ANNOTATION_REF_TAG;
      }

      NodeList children = e.getChildNodes();
      int len = children.getLength();

      // Get anchor ID from first child
      InkAnnotation anno = new InkAnnotation(
         sheet.getID(createLongFromDOMElement((Element)children.item(0),
                                             ANCHOR_ID_REF_TAG)));

      // For each of the rest of the children, get and add the graphical object
      Style annoPenStyle;

      if (reviewer.equals(DenimUserProperties.get(PROP_USER))) {
         annoPenStyle = AnnotationPen.getClassStyle();
      }
      else {
         annoPenStyle = AnnotationPen.getOtherStyle();
      }

      for (int i = 1; i < len; i++) {
         Node child = children.item(i);
         String childName = child.getNodeName();

         if (childName.equals(TIMED_STROKE_WITH_PARENT_TAG)) {
            assert !loadRefsOnly:
                          TIMED_STROKE_WITH_PARENT_TAG +
                          " not allowed in " + tagName;

            GraphicalObject annoGob =
               createTimedStrokeFromDOMElement((Element)child, sheet, true);
            annoGob.setStyle(annoPenStyle);
            anno.add(annoGob);
         }

         else if (childName.equals(ID_REF_TAG)) {
            assert loadRefsOnly:
                          ID_REF_TAG + " not allowed in " + tagName;

            GraphicalObject annoGob =
               sheet.getID(createLongFromDOMElement((Element)child,
                                                   ID_REF_TAG));
            // annoGob could be null if it refers to an annotation that was
            // deleted by the user before saving
            if (annoGob != null) {
               annoGob.setStyle(annoPenStyle);
               anno.add(annoGob);
            }
         }
         else {
            assert false: childName + " not allowed in " + tagName;
         }
      }

      return anno;
   }

   //-----------------------------------------------------------------

   /**
    * Converts an AudioAnnotation into a DOM element. The element's
    * form is
    *
    * <AudioAnnotation>
    *   <AnchorIDRef>...</AnchorIDRef>
    *   <AudioSrc>...</AudioSrc>
    * </AudioAnnotation>
    *
    */
   static Element toDOMElement(Document doc, AudioAnnotation anno) {
      if (anno.getAnchor() != null) {
         Element e = doc.createElement(AUDIO_ANNOTATION_TAG);

         // Create <AnchorIDRef>
         e.appendChild(toDOMElement(doc, anno.getAnchor().getUniqueID(),
                                    ANCHOR_ID_REF_TAG));

         // Create <AudioSrc>
         // use file name in DOM
         e.appendChild(toDOMElement(doc, anno.getAudioFileName(), AUDIO_SRC_TAG));

         // Create <AbsX>
         Point2D loc = anno.getLocation2D(COORD_REL);
         e.appendChild(toDOMElement(doc, loc.getX(), X_TAG));

         // Create <AbsY>
         e.appendChild(toDOMElement(doc, loc.getY(), Y_TAG));

         // Create <ParentIDRef>
         e.appendChild(toDOMElement(doc, anno.getParentGroup().getUniqueID(),
                                    PARENT_ID_REF_TAG));

         return e;
      }
      else {
         return null;
      }
   }

   /**
    * Reads a DOM element and returns an AudioAnnotation.
    */
   static AudioAnnotation
   createAudioAnnotationFromDOMElement(Element e, DenimSheet sheet) {
      // Make sure element has right tag
      assert e.getTagName().equals(AUDIO_ANNOTATION_TAG):
         "Element " + e.getTagName() + " is not " + AUDIO_ANNOTATION_TAG;

      NodeList children = e.getChildNodes();

      // Get anchor ID from first child
      GraphicalObject anchor =
         sheet.getID(createLongFromDOMElement((Element)children.item(0),
                                             ANCHOR_ID_REF_TAG));

      // Get audio file name from second child
      String audioFileName =
         createStringFromDOMElement((Element)children.item(1), AUDIO_SRC_TAG);

      float x =
         createFloatFromDOMElement((Element)children.item(2), X_TAG);

      float y =
         createFloatFromDOMElement((Element)children.item(3), Y_TAG);

      GraphicalObjectGroup parent = (GraphicalObjectGroup)sheet.getID(
         createLongFromDOMElement((Element)children.item(4), PARENT_ID_REF_TAG));

      if (anchor != null && parent != null) {
         AudioAnnotation anno = new AudioAnnotation(anchor, audioFileName);
         anno.addMyselfTo(parent, new Point2D.Float(x, y), sheet);
         return anno;
      }
      else {
         return null;
      }
   }

   //-----------------------------------------------------------------

   /**
    * Converts a user's annotations into a DOM element. The element's
    * form is
    *
    *   <AnnotationRefsByReviewer>
    *     <Reviewer>bobo</Reviewer>
    *     <InkAnnotationRef>
    *       ...
    *     </InkAnnotationRef>
    *     <AudioAnnotation>
    *       ...
    *     </AudioAnnotation>
    *   </AnnotationRefsByReviewer>
    *
    */
   static Element toDOMElement(Document doc, Map.Entry annoEntry,
                               boolean saveRefsOnly) {
      Element e;

      if (saveRefsOnly) {
         e = doc.createElement(ANNOTATION_REFS_BY_REVIEWER_TAG);
      }
      else {
         e = doc.createElement(ANNOTATIONS_BY_REVIEWER_TAG);
      }

      // Create <Reviewer>
      //debug.println("Creating DOM Elements for annos for: " + annoEntry.getKey());

      String user = (String)annoEntry.getKey();

      e.appendChild(toDOMElement(doc, user, REVIEWER_TAG));

      // Create <InkAnnotation>... or <AudioAnnotation>...
      Map annosByAnchor = (Map)annoEntry.getValue();
      Iterator annosIter = annosByAnchor.values().iterator();

      while (annosIter.hasNext()) {
         List annos = (List)annosIter.next();
         Iterator annoIter = annos.iterator();

         while (annoIter.hasNext()) {
            Object anno = annoIter.next();

            //debug.println("Creating DOM element for anno: " + anno.getClass());

            // HACK: If toDOMElement were a method, instanceof wouldn't be
            // necessary
            if (anno instanceof InkAnnotation) {
               // debug.println("anno: " + anno.getClass());
               e.appendChild(toDOMElement(doc, (InkAnnotation)anno, saveRefsOnly));
            }
            else if (anno instanceof AudioAnnotation) {
               Element newElement = toDOMElement(doc, (AudioAnnotation)anno);
               if (newElement != null) {
                  e.appendChild(newElement);
               }
            }
            else {
               assert false:
                    "Children of <" + e.getTagName() +
                    "> must be InkAnnotation or AudioAnnotation, not " +
                    (anno == null ? null : anno.getClass());
            }
         }
      }

      return e;
   }

   /**
    * Reads a DOM element and returns an entry to a map of annotations.
    *
    * Unlike all of the other create*FromDOMElement, this method is void
    * because we must add the new informaton directly to a map. We can't
    * return a new Map.Entry.
    */
   static void
   addAnnotationMapEntryFromDOMElement(Element e, DenimSheet sheet,
                                       boolean loadRefsOnly) {
      String tagName = e.getTagName();
      NodeList children = e.getChildNodes();
      int len = children.getLength();

      if (tagName.equals(ANNOTATIONS_BY_REVIEWER_TAG)) {
         assert !loadRefsOnly: 
            tagName + " encountered, but you only want to load refs.";
      }
      else if (tagName.equals(ANNOTATION_REFS_BY_REVIEWER_TAG)) {
         assert loadRefsOnly: 
            tagName + " encountered, but you want to load strokes.";
      }
      else {
         assert false:
              "Element " + e.getTagName() + " is not " +
              ANNOTATIONS_BY_REVIEWER_TAG + " or " + 
              ANNOTATION_REFS_BY_REVIEWER_TAG;
      }

      // Get Reviewer from first child
      String user = createStringFromDOMElement((Element)children.item(0),
                                               REVIEWER_TAG);

      // For each of the rest of the children, get and add the annotations
      //List annos = new ArrayList();

      for (int i = 1; i < len; i++) {
         Node child = children.item(i);
         String childName = child.getNodeName();
         if (childName.equals(INK_ANNOTATION_TAG) ||
             childName.equals(INK_ANNOTATION_REF_TAG)) {
            InkAnnotation penAnno =
               createInkAnnotationFromDOMElement(
                  (Element)child, sheet, user, loadRefsOnly);
            //debug.println("adding pen annotation: " + penAnno);
            sheet.getSheetAnnotations().addInkAnnotation(user, penAnno);
            //annos.add(penAnno);
            /*
            annos.add(
               createPenAnnotationFromDOMElement(
                  (Element)child, sheet, loadRefsOnly));
            */
         }
         else if (childName.equals(AUDIO_ANNOTATION_TAG)) {
            AudioAnnotation newAnno =
               createAudioAnnotationFromDOMElement((Element)child, sheet);
            if (newAnno != null) {
               sheet.getSheetAnnotations().addAudioAnnotation(user, newAnno);
               //annos.add(newAnno);
            }
         }
         else {
            assert false: childName + " not allowed in " + tagName;
         }
      }

      //sheet.getSheetAnnotations()
      //     .getAnnotationsForCurrentVersion()
      //     .put(user, annos);
   }

   //-----------------------------------------------------------------

   /**
    * Converts a map of annotations into a DOM element. The element's
    * form is
    *
    * <AnnotationRefs>
    *   <AnnotatedUIDs>   ---+
    *      <UID>...</UID>    |-- not implemented yet
    *      ...               |
    *   </AnnotatedUIDs>  ---+
    *   <AnnotationRefsByReviewer>
    *       ...
    *   </AnnotationRefsByReviewer>
    *   ...
    * </AnnotationRefs>
    *
    */
   static Element toDOMElement(Document doc, SheetAnnotations sheetAnnos,
                               boolean saveRefsOnly) {
      Element e;

      if (saveRefsOnly) {
         e = doc.createElement(ANNOTATION_REFS_TAG);
      }
      else {
         e = doc.createElement(ANNOTATIONS_TAG);
         e.appendChild(toDOMElement(doc, sheetAnnos.getVersion(),
                                    VERSION_TAG));
      }

      Iterator entryIter =
         sheetAnnos.getAnnotations().entrySet().iterator();

      while (entryIter.hasNext()) {
         // Create <AnnotationRefsByReviewer>
         Map.Entry entry = (Map.Entry)entryIter.next();

         // If we are saving standalone annotations, then we only want to
         // save the annotations of the current user
         if (!saveRefsOnly) {
            String key = (String)entry.getKey();
            if (key.equals(DenimUserProperties.get(PROP_USER))) {
               e.appendChild(toDOMElement(doc, entry, saveRefsOnly));
            }
         }
         else {
            e.appendChild(toDOMElement(doc, entry, saveRefsOnly));
         }
      }

      return e;
   }

   /**
    * Reads a DOM element, extracts the annotations, and adds them to
    * the given sheet.
    */
   static void
   addSheetAnnotationsFromDOMElement(Element e, DenimSheet sheet,
                                     boolean loadRefsOnly) {
      String tagName = e.getTagName();
      NodeList children = e.getChildNodes();
      int len = children.getLength();
      int i = 0;

      if (tagName.equals(ANNOTATIONS_TAG)) {
         assert !loadRefsOnly: 
            tagName + " encountered, but you only want to load refs.";

         // Read <Version>
         sheet.getSheetAnnotations()
              .setVersion(createIntFromDOMElement(
                             (Element)children.item(0), VERSION_TAG));
         i = 1;
      }
      else if (tagName.equals(ANNOTATION_REFS_TAG)) {
         assert loadRefsOnly: 
            tagName + " encountered, but you want to load strokes.";
      }
      else {
         assert false:
              "Element " + e.getTagName() + " is not " +
              ANNOTATIONS_TAG + " or " + ANNOTATION_REFS_TAG;
      }

      // Process rest of children
      for (; i < len; i++) {
         Node child = children.item(i);
         String childName = child.getNodeName();
         if (childName.equals(ANNOTATIONS_BY_REVIEWER_TAG) ||
             childName.equals(ANNOTATION_REFS_BY_REVIEWER_TAG)) {
            addAnnotationMapEntryFromDOMElement(
                  (Element)child, sheet, loadRefsOnly);
         }
         else {
            assert false: childName + " not allowed in " + tagName;
         }
      }
   }

   //-----------------------------------------------------------------

   /**
    * Converts an arrow into a DOM element. The element's
    * form is
    *
    * <Arrow>
    *   <ID>...</ID>
    *   <EventType>...</EventType>
    *   <SrcRef>...</SrcRef>
    *   <DestRef>...</DestRef>
    *   <AffineTransform>
    *     ...
    *   </AffineTransform>
    *   <TimedPoint>
    *      ...
    *   </TimedPoint>
    *   ...
    * </Arrow>
    *
    * Ugh, this should use the TimedStroke toDOMElement, but I'm
    * too lazy to figure out a nice way of reusing it right now.
    */
   static Element toDOMElement(Document doc, Arrow arrow) {
      Element e = doc.createElement(ARROW_TAG);
      
      e.setAttribute(DOMUtils.ARROW_CONDITION, Integer.toString(arrow.getCondition()));

      // Create <ID>
      e.appendChild(toDOMElement(doc, arrow.getUniqueID(), ID_TAG));

      // Create <EventType>
      e.appendChild(toDOMElement(doc, arrow.getInputEventType(),
                                 EVENT_TYPE_TAG));

      // Create <SrcRef>
      //debug.println("Source: " + DenimUtils.toShortString(arrow.getOrigSource()));
      e.appendChild(toDOMElement(doc, arrow.getOrigSource().getUniqueID(),
                                 SRC_REF_TAG));

      // Create <DestRef>
      //debug.println("Dest: " + DenimUtils.toShortString(arrow.getOrigDest()));
      e.appendChild(toDOMElement(doc, arrow.getOrigDest().getUniqueID(),
                                 DEST_REF_TAG));

      // Create <AffineTransform>
      //debug.println("origTransform: " + arrow.getOrigTransform());

      e.appendChild(toDOMElement(doc, arrow.getOrigTransform()));

      // Create <TimedPoint>...
      TimedPolygon2D poly = arrow.getOrigStroke().getPolygon2D(COORD_LOCAL);
      for (int i = 0; i < poly.npoints; i++) {
         // Create <TimedPoint>...</TimedPoint>
         e.appendChild(toDOMElement(doc,
                                    poly.xpoints[i],
                                    poly.ypoints[i],
                                    poly.times[i]));
      }

      return e;
   }

   /**
    * Reads a DOM element and adds the corresponding arrow to the given sheet.
    *
    * Ugh, this should use the TimedStroke createFromDOMElement, but I'm
    * too lazy to figure out a nice way of reusing it right now.
    */
   static void addArrowFromDOMElement(Element e, DenimSheet sheet, DenimPanel dummypanel) {

      // Make sure element has right tag
      assert e.getTagName().equals(ARROW_TAG):
         "Element " + e.getTagName() + " is not Arrow";

      NodeList children = e.getChildNodes();
      int len = children.getLength();

      // Get ID from first child
      long ID = createLongFromDOMElement((Element)children.item(0),
                                       ID_TAG);

      // Get EventType from second child
      String eventType = createStringFromDOMElement((Element)children.item(1),
                                                    EVENT_TYPE_TAG);

      // Get SrcRef from third child
      long id = createLongFromDOMElement((Element)children.item(2),
              SRC_REF_TAG);
      
      //System.out.println(sheet.getID(id).getClass().toString());

      ArrowSource src = null;
      try
      {
          src = (ArrowSource)sheet.getID(id);
      }
      catch(Exception ex)
      {
          ex.printStackTrace();
      }
         
      
      if(src==null)
      {
          /**
           * search the component as well in case it is a global link
           */
          Collection registeredComponents = DenimComponentRegistry.getInstance().getComponents();
          Iterator iter = registeredComponents.iterator();
          while (iter.hasNext()) {
             DenimComponent temp= (DenimComponent) iter.next();
             if(!temp.isIntrinsic())
             {
                src = (ArrowSource)temp.getID(id);
                if(src!=null)
                    break;
             }
          }
      }
      
      if(src==null)
      {
          System.err.println("Arrow source cannot be found!");
          return;
      }
      
      // Get DestRef from fourth child
      
      long dstid = createLongFromDOMElement((Element)children.item(3),
              DEST_REF_TAG);
      
      ArrowDest dest =
         (ArrowDest)sheet.getID(dstid);
      
      // For each of the rest of the children, get and add a timed point
      TimedStroke stk = new TimedStroke();
      for (int i = 5; i < len; i++) {
         TimedPoint2D pt = createTimedPoint2DFromDOMElement((Element)children.item(i));
         stk.addPoint(pt.x, pt.y, pt.time);
      }

      //debug.println("src: " + DenimUtils.toShortString(src));
      //debug.println("dest: " + DenimUtils.toShortString(dest));

      int condition = 1;
      
      if(e.hasAttribute(DOMUtils.ARROW_CONDITION))
          condition = Integer.parseInt(e.getAttribute(DOMUtils.ARROW_CONDITION));
      
      Arrow arrow;
      
      if(dest==null)
      {
          System.err.println("dest of arrow cannot be found while loading, keep id instead");
          dest = dummypanel.getSketch();
          arrow = new Arrow(stk, eventType, condition,
                  (ArrowSource)src, (ArrowDest)dest);
          arrow.setGlobalDstID(dstid);
      }
      else
      {
          arrow = new Arrow(stk, eventType, condition,
                  (ArrowSource)src, (ArrowDest)dest);
      }
      

      arrow.setUniqueID(ID);
      sheet.add(arrow, GraphicalObjectGroup.KEEP_REL_POS);

      // Get transform from fifth child
      arrow.initAfterAdd(createAffineTransformFromDOMElement(
                         (Element)children.item(4)));
      //debug.println(DenimUtils.toShortString(arrow));
      //debug.println("   Relative bounds: " + arrow.getBounds2D(COORD_REL));
      //debug.println("origTransform: " + arrow.getOrigTransform());
   }

   //-----------------------------------------------------------------

   /**
    * Converts an AffineTransform into a DOM element. The element's
    * form is
    *
    * <AffineTransform>
    *   <m00>..</m00>
    *   <m10>..</m10>
    *   <m01>..</m01>
    *   <m11>..</m11>
    *   <m02>..</m02>
    *   <m12>..</m12>
    * </AffineTransform>
    */
   static Element toDOMElement(Document doc, AffineTransform xform) {
      Element e = doc.createElement(AFFINE_TRANSFORM_TAG);

      double[] flatMatrix = new double[6];

      xform.getMatrix(flatMatrix);

      double[][] matrix = new double[2][3];
      matrix[0][0] = flatMatrix[0];
      matrix[1][0] = flatMatrix[1];
      matrix[0][1] = flatMatrix[2];
      matrix[1][1] = flatMatrix[3];
      matrix[0][2] = flatMatrix[4];
      matrix[1][2] = flatMatrix[5];

      for (int i = 0; i < 2; i++) {
         for (int j = 0; j < 3; j++) {
            e.appendChild(toDOMElement(doc, matrix[i][j], M_TAG[i][j]));
         }
      }

      return e;
   }

   /**
    * Reads a DOM element and returns an AffineTransform.
    */
   static AffineTransform createAffineTransformFromDOMElement(Element e) {
      // Make sure element has right tag
      assert e.getTagName().equals(AFFINE_TRANSFORM_TAG):
                    "Element " + e.getTagName() + " is not AffineTransform";

      // Make sure element has right number of children
      NodeList children = e.getChildNodes();
      int len = children.getLength();
      assert len == 6:
                    "<" + e.getTagName() + "> should have six children";

      double[][] m = new double[2][3];

      int childNum = 0;
      for (int i = 0; i < 2; i++) {
         for (int j = 0; j < 3; j++) {
            m[i][j] = createDoubleFromDOMElement(
                              (Element)children.item(childNum), M_TAG[i][j]);
            childNum++;
         }
      }

      return new AffineTransform(m[0][0], m[1][0],
                                 m[0][1], m[1][1],
                                 m[0][2], m[1][2]);
   }

   /**
    * Reads a DOM element and returns an entry to a map of scenarios.
    *
    * Unlike all of the other create*FromDOMElement, this method is void
    * because we must add the new informaton directly to a map. We can't
    * return a new Map.Entry.
    */
   static void
   addScenariosFromDOMElement(Element e, DenimSheet sheet) {
      NodeList children = e.getChildNodes();
      int len = children.getLength();
      Scenario curScen;
      for (int i = 0; i < len; i++) {
         Element scenario = (Element)children.item(i);
         NodeList scenarioParts = scenario.getChildNodes();
         int scenarioLength = scenarioParts.getLength();

         String name = createStringFromDOMElement((Element)scenarioParts.item(0), SCENARIO_NAME_TAG);
         String time = createStringFromDOMElement((Element)scenarioParts.item(1), SCENARIO_TIME_TAG);
         curScen = new Scenario(name, new Scenario.Time(Integer.valueOf(time).longValue()));
         // iterate over the IDs
         for (int j = 2; j < scenarioLength; j+=2) {
            DenimPanel panel = (DenimPanel)sheet.getID(
               createLongFromDOMElement((Element)scenarioParts.item(j), ID_TAG));
            time = createStringFromDOMElement((Element)scenarioParts.item(j+1), SCENARIO_TIME_TAG);
            curScen.getNodes().add(new ScenarioNode(panel, new Scenario.Time(Long.valueOf(time).longValue())));
         }
         sheet.addScenario(curScen);
      }
   }


   //-----------------------------------------------------------------

   /**
    * Converts a set of scenarios into a DOM element. The element's
    * form is
    *
    * <Scenarios>
    *   <Scenario>
    *       ...
    *   </Scenario>
    *   ...
    * </Scenarios>
    *
    */
   static Element toDOMElement(Document doc, List scenarios, DenimSheet sheet) {
      Element e = doc.createElement(SCENARIOS_TAG);
      Iterator iter = scenarios.iterator();
      Scenario curScen;
      while (iter.hasNext()) {
         curScen = (Scenario)iter.next();
         e.appendChild(toDOMElement(doc, curScen));
      }
      return e;
   }

  /**
    * Converts a scenario into a DOM element. The element's
    * form is
    *
    * <Scenario>
    *   <Name>...</Name>
    *   <ID>...</ID>
    *   ...
    *   <ID>...</ID>
    * </Scenario>
    *
    */
   static Element toDOMElement(Document doc, Scenario scen) {
      Element e = doc.createElement(SCENARIO_TAG);
      // Create <Name>
      e.appendChild(toDOMElement(doc, scen.getTitle(), SCENARIO_NAME_TAG));
      e.appendChild(toDOMElement(doc, scen.getMiliTime(), SCENARIO_TIME_TAG));
      // Create <ID>s
      Iterator iter = scen.iterator();
      ScenarioNode curSN;
      while (iter.hasNext()) {
         curSN = (ScenarioNode)iter.next();
         e.appendChild(toDOMElement(doc, curSN.getPanel().getUniqueID(), ID_TAG));
         e.appendChild(toDOMElement(doc, curSN.getMiliTime(), SCENARIO_TIME_TAG));     
      }
      return e;
   }

   /**
    * Converts a DenimSheet into a DOM element. The element's
    * form is
    *
    * <DenimSheet>
    *   <ID>...</ID>
    *   <Version>...</Version>
    *   <UID>...</UID>
    *   <AffineTransform>
    *      ...
    *   </AffineTransform>
    *   <TimedStroke>   --+
    *      ...            |
    *   </TimedStroke>    |
    *   <DenimPanel>      |
    *      ...            +--- in any order
    *   </DenimPanel>     |
    *   <Arrow>           |
    *      ...            |
    *   </Arrow>          |
    *      ...          --+
    *   <AnnotationsRef>
    *      ...
    *   </AnnotationsRef>
    * </DenimSheet>
    */
   public static Element toDOMElement(Document doc, DenimSheet sheet) {
      // HACK: Save sheet's transform and zoom into storyboard view
      sheet.disableDamage();
      AffineTransform tx = sheet.getTransform(COORD_REL);

      ZoomSlider slider = sheet.getDenimUI().getZoomSlider();
      slider.setAnimateZoom(false);
      slider.setValue(50); // Storyboard value
      slider.setAnimateZoom(true);

      // Create DOM Element
      Element e = doc.createElement(DENIM_SHEET_TAG);
      
      if(sheet.backgroundName!=null)
      {
          e.setAttribute("IMAGE_X", Double.toString(sheet.imageX));
          e.setAttribute("IMAGE_Y", Double.toString(sheet.imageY));
          e.setAttribute("IMAGE_W", Double.toString(sheet.imageW));
          e.setAttribute("IMAGE_H", Double.toString(sheet.imageH));
          
          e.setAttribute("BACKGROUND_IMAGE", sheet.backgroundName);
      }
      
      e.setAttribute("PAGE_WIDTH", Integer.toString(DenimSketch.getDefaultSketchWidth()));
      e.setAttribute("PAGE_HEIGHT", Integer.toString(DenimSketch.getDefaultSketchHeight()));

      // Create <ID>
      e.appendChild(toDOMElement(doc, sheet.getUniqueID(), ID_TAG));

      // Create <Version>
      e.appendChild(toDOMElement(doc, sheet.getVersion(), VERSION_TAG));

      // Create <UID>
      e.appendChild(toDOMElement(doc, sheet.getUID().toString(), UID_TAG));

      // Create <AffineTransform>
      e.appendChild(toDOMElement(doc, tx));

      // Create <AuthorURL>
      URL authorURL = sheet.getAuthorURL();
      if (authorURL != null) {
         e.appendChild(toDOMElement(doc, sheet.getAuthorURL().toString(),
                                    AUTHOR_URL_TAG));
      }

	  /**
	   * save the component first -- YL
	   */
	  Collection registeredComponents = DenimComponentRegistry.getInstance().getComponents();
	  Iterator iter = registeredComponents.iterator();
	  while (iter.hasNext()) {
		 DenimComponent temp= (DenimComponent) iter.next();
		 if(!temp.isIntrinsic())
		    e.appendChild(toDOMElement (doc, (DenimCustomComponent) temp, false));
	  }

      // Create <TimedStroke>, etc....
      Iterator it = sheet.getReverseIterator();
      while (it.hasNext()) {
         GraphicalObject gob = (GraphicalObject)it.next();
         // HACK: toDOMElement should be a method of the graphical object,
         // so we can dispatch to the right type
         if (gob instanceof Arrow) {
            e.appendChild(toDOMElement(doc, (Arrow)gob));
         }
         else if (gob instanceof TimedStroke) {
            // Arrows add invisible strokes to the sheet which are the arrows'
            // original strokes. We don't need to save them.
            if (gob.isVisible()) {
               e.appendChild(toDOMElement(doc, (TimedStroke)gob));
            }
         }
         else if (gob instanceof DenimPanel) {
            e.appendChild(toDOMElement(doc, (DenimPanel)gob));
         }
         else if (gob instanceof DenimSheet.Crosshairs) {
            // ignore
         }
         else if (gob instanceof AudioAnnotation) {
            // ignore
         }
         else {
            assert false: 
               "What? A DenimSheet shouldn't contain " + gob.getClass();
         }
      }


      // Create <Scenarios>
      e.appendChild(toDOMElement(doc, sheet.getScenarios(), sheet));

      // Create <AnnotationsRef>
      e.appendChild(toDOMElement(doc, sheet.getSheetAnnotations(), true));




      // Zoom the sheet to the proper scale factor.
      double newScale = AffineTransformLib.getScaleFactor(tx);
      slider.setAnimateZoom(false);
      slider.setValue(DenimUtils.getZoomSliderValue(newScale));
      slider.setAnimateZoom(true);

      //// Pan to the correct location.
      sheet.setTransform(tx);
      sheet.enableDamage();

      return e;
   }

   /**
    * Changes the given DenimSheet to include the data from the given
    * DOM element.
    */
   public static DenimSheet changeDenimSheetFromDOMElement(Element e,
                                                           DenimSheet sheet) {
      // Make sure element has right tag
      assert e.getTagName().equals(DENIM_SHEET_TAG) :
                      "Element " + e.getTagName() + " is not DenimSheet";

      NodeList children = e.getChildNodes();
      int len = children.getLength();
      int firstGobElement;

      //DenimSheet sheet = new DenimSheet(null);
      sheet.clear();
      
      if(e.hasAttribute("BACKGROUND_IMAGE")&&
              e.getAttribute("BACKGROUND_IMAGE").trim().length()!=0)
      {
          sheet.imageX = Double.parseDouble(e.getAttribute("IMAGE_X"));
          sheet.imageY = Double.parseDouble(e.getAttribute("IMAGE_Y"));
          sheet.imageW = Double.parseDouble(e.getAttribute("IMAGE_W"));
          sheet.imageH = Double.parseDouble(e.getAttribute("IMAGE_H"));
          
          sheet.backgroundName = e.getAttribute("BACKGROUND_IMAGE");
      }
      else
      {
          sheet.backgroundName = null;
      }

      if(e.hasAttribute("PAGE_WIDTH"))
      {
          DenimSketch.setDefaultSketchWidth(Integer.parseInt(e.getAttribute("PAGE_WIDTH")));
          DenimSketch.setDefaultSketchHeight(Integer.parseInt(e.getAttribute("PAGE_HEIGHT")));
      }

      // Get Satin object ID from first child
      sheet.setUniqueID(createLongFromDOMElement((Element)children.item(0),
                                                 ID_TAG));

      // Get version from second child
      sheet.setVersion(createIntFromDOMElement((Element)children.item(1),
                                                VERSION_TAG));

      // Get UID from third child
      sheet.setUID(new DenimUID(
                      createStringFromDOMElement((Element)children.item(2),
                                                 UID_TAG)));

      // Get transform from fourth child.
      AffineTransform newTx = createAffineTransformFromDOMElement(
                                 (Element)children.item(3));

      // HACK: Zoom into storyboard view
      ZoomSlider slider = sheet.getDenimUI().getZoomSlider();
      slider.setAnimateZoom(false);
      slider.setValue(50); // Storyboard value
      slider.setAnimateZoom(true);

      /*// Zoom the sheet to the proper scale factor.
      ZoomSlider slider = sheet.getDenimUI().getZoomSlider();
      double newScale = AffineTransformLib.getScaleFactor(newTx);
      slider.setAnimateZoom(false);
      slider.setValue(DenimUtils.getZoomSliderValue(newScale));
      slider.setAnimateZoom(true);

      //// Pan to the correct location.
      sheet.setTransform(newTx);*/

      // Get author URL from fifth child, if it is one
      Element fifthElement = (Element)children.item(4);
      if (fifthElement.getTagName().equals(AUTHOR_URL_TAG)) {
         String authorURLStr = createStringFromDOMElement(
                                             (Element)children.item(4),
                                             AUTHOR_URL_TAG);
         try {
            sheet.setAuthorURL(new URL(authorURLStr));
         }
         catch (MalformedURLException ex) {
            Debug.println(authorURLStr + " is not a valid URL. Setting subscriber URL to null.");
            sheet.setAuthorURL(null);
         }
         firstGobElement = 5;
      }
      else {
         sheet.setAuthorURL(null);
         firstGobElement = 4;
      }
      
      sheet.setCrosshairsVisible(true);

      /*
       * creat a dummy panel for those global arrows
       */
      DenimPanel dummypanel = new DenimPanel(new Rectangle2D.Double(0,0,100,100));
      dummypanel.setLabel(new DenimLabel(new Rectangle2D.Double(0,0,6,6), new TypedText("dummypanel"), 1));
      dummypanel.setSketch(new DenimSketch());
      sheet.addToBack(dummypanel);
      
      // For each of the rest of the children, get and add the graphical object
      for (int i = firstGobElement; i < len - 1; i++) {
         Node child = children.item(i);
         String childName = child.getNodeName();

         if (childName.equals(TIMED_STROKE_TAG)) {
            TimedStroke stk =
               createTimedStrokeFromDOMElement((Element)child);
            sheet.add(stk, GraphicalObjectGroup.KEEP_REL_POS);
         }
         else if (childName.equals(DENIM_PANEL_TAG)) {
            addDenimPanelFromDOMElement((Element)child, sheet);
         }
         else if (childName.equals(ARROW_TAG)) {
            addArrowFromDOMElement((Element)child, sheet, dummypanel);
         }
         else if (childName.equals(DENIM_CUSTOM_COMPONENT_TAG)) {
            addCustomComponentFromDOMElement((Element) child, sheet, dummypanel);
         }
      }

      Iterator it = dummypanel.getSketch().getIncomingArrows().iterator();
      while(it.hasNext())
      {
          Arrow a = (Arrow)it.next();
          editCustomComponent(a, sheet);
          dummypanel.untrackNavArrow(a);
      }

      
      dummypanel.delete();
      
      
      // Get scenarios
      Element nextElement = (Element)children.item(len-2);
      if (nextElement.getTagName().equals(SCENARIOS_TAG)) {
         addScenariosFromDOMElement(nextElement, sheet);
      }

      // Finally, add the annotation map
      addSheetAnnotationsFromDOMElement((Element)children.item(len-1),
                                        sheet, true);

      // Refresh
      sheet.damage(DAMAGE_NOW);

      // Zoom the sheet to the proper scale factor.
      double newScale = AffineTransformLib.getScaleFactor(newTx);
      slider.setAnimateZoom(false);
      slider.setValue(DenimUtils.getZoomSliderValue(newScale));
      slider.setAnimateZoom(true);

      //// Pan to the correct location.
      sheet.setTransform(newTx);
      
      return sheet;
   }
   /*
   private static void checkPage(String index, DenimSheet sheet, DenimPanel dummypanel) {
       System.out.println(" number " + sheet.numElements());
       DenimPanel panel;
       Iterator it = sheet.getForwardIterator();
       while(it.hasNext())
       {
           GraphicalObject gob = (GraphicalObject)it.next();
           if(gob instanceof DenimPanel)
               panel = (DenimPanel)gob;
           else
               continue;
           
           DenimText txt = panel.getLabel().getPhrase();
           
           if(txt instanceof TypedText)
           {
               TypedText ttx = (TypedText)txt;
               if(ttx.getText().equalsIgnoreCase("login"))
               {
                   System.out.println(index + " login page ");
                   return;
               }
           }
       }
       System.out.println(index + " NO login page");
   }
   */
   private static void editCustomComponent(Arrow arrow, DenimSheet mainSheet) {
       
       DenimCustomComponent component;
       
       GraphicalObjectGroup grp = arrow.getSourcePanel().getParentGroup();
       
       if(grp instanceof DenimCustomComponent)
           component = (DenimCustomComponent)grp;
       else
           return;
       
       DenimSheet sheet = new DenimUI().getSheet();//new DenimSheet(new DenimUI(), false);
       sheet.addToFront(component, GraphicalObjectGroup.KEEP_REL_POS);

       //// 1. Get the selected items.
       Iterator iter = component.getForwardIterator();

       //// 2. Set the selected Graphical Objects to be copied.
       DenimCopyCommand copyCommand = new DenimCopyCommand(iter);
       copyCommand.run();
        
       Point2D tp = new Point2D.Double(300,300);
       try
       {
           sheet.getTransform(COORD_ABS).inverseTransform(tp,tp);
       }
       catch(Exception ex)
       {
           ex.printStackTrace();
       } 

       new DenimPasteCommand(sheet, tp).run();
       sheet.remove(component);

       /*
        * replacing arrows
        */
/*     InsertArrowCommand acmd = new InsertArrowCommand(
                       sheet, arrow,
                       DenimIntrinsicComponent.LEFT_CLICK,
                       DenimConstants.DEFAULT_EVENT, 
                       arrow.getSource(), 
                       (ArrowDest)mainSheet.getID(arrow.getGlobalDstID()));
       acmd.run();
       acmd.getInsertedArrow().setGlobal(true);
  */     
       component.update(sheet); 
       
       sheet.clear();
       
       DenimClipboard.cmdqueue.clear();
       DenimConstants.denimClipboard.clearClipboard();
       //updateCustomComponent(component, mainSheet);
       
   }
   /*
   private static void updateCustomComponent(DenimCustomComponent component, GraphicalObjectGroup mainSheet) {
       Iterator iter = mainSheet.getForwardIterator();
       while(iter.hasNext())
       {
           GraphicalObject gob = (GraphicalObject)iter.next();
           if(gob instanceof DenimCustomComponentInstance)
           {
               DenimCustomComponentInstance instance = (DenimCustomComponentInstance)gob;
               if(instance.getComponentType()==component)
               {
                   instance.setDisplayedState(((DenimCustomComponent)component).getLeftMostPanel());
               }
           }
           else if(gob instanceof GraphicalObjectGroup)
           {
               updateCustomComponent(component, (GraphicalObjectGroup)gob);
           }
       }
   }

*/




   /** converts a DenimCustomComponent into a DOM element*/

   public static Element toDOMElement(Document doc, DenimCustomComponent cust, boolean isExport) {


      // Create DOM Element
      Element e = doc.createElement(DENIM_CUSTOM_COMPONENT_TAG);

      // Create <Name>
      e.appendChild(toDOMElement(doc, cust.getName().toString(), NAME_TAG));

      // Create <TimedStroke>, etc....
      Iterator it = cust.getReverseIterator();
      while (it.hasNext()) {
         GraphicalObject gob = (GraphicalObject)it.next();
         // HACK: toDOMElement should be a method of the graphical object,
         // so we can dispatch to the right type
         if (gob instanceof Arrow
                 &&(isExport==false||((Arrow)gob).isGlobal()==false)) {
            e.appendChild(toDOMElement(doc, (Arrow)gob));
         }
         else if (gob instanceof TimedStroke) {
            // Arrows add invisible strokes to the sheet which are the arrows'
            // original strokes. We don't need to save them.
            if (gob.isVisible()) {
               e.appendChild(toDOMElement(doc, (TimedStroke)gob));
            }
         }
         else if (gob instanceof DenimPanel) {
            e.appendChild(toDOMElement(doc, (DenimPanel)gob));
         }
         else {
            assert false: "What? A DenimCustomComponent shouldn't contain " +
                                 gob.getClass();
         }
      }
      return e;
   }


   /**
    * Changes the given DenimCustomComponent to include the data from the given
    * DOM element.
    */
   public static DenimCustomComponent addCustomComponentFromDOMElement(
           Element e, DenimSheet sheet, DenimPanel dummypanel) {

      
      GraphicalObjectCollectionImpl gobCollImp = new GraphicalObjectCollectionImpl();
      NodeList children = e.getChildNodes();
      int len = children.getLength();

      // Make sure element has right tag
      assert e.getTagName().equals(DENIM_CUSTOM_COMPONENT_TAG):
         "Element " + e.getTagName() + " is not DenimCustomComponent";

      // Get Name from first child
      String componentName = createStringFromDOMElement((Element)children.item(0), NAME_TAG);

      // For each of the rest of the children, get and add the graphical object
      DenimSheet dummySheet = new DenimUI().getSheet();//new DenimSheet(new DenimUI(), false);
      for (int i = 1; i < len; i++) {
         Node child = children.item(i);
         String childName = child.getNodeName();
         if (childName.equals(DENIM_PANEL_TAG)) {
            addDenimPanelFromDOMElement((Element)child, dummySheet);
         }
      }

      for (int i = 1; i < len; i++) {
         Node child = children.item(i);
         String childName = child.getNodeName();
         if (childName.equals(ARROW_TAG)) {
            addArrowFromDOMElement((Element)child, dummySheet, dummypanel);
            // do it at the last
         }
         else if (childName.equals(TIMED_STROKE_TAG)) {
            TimedStroke stk =
               createTimedStrokeFromDOMElement((Element)child);
            dummySheet.add(stk);
         }
      }

      Iterator gobIter = dummySheet.getReverseIterator();
      while(gobIter.hasNext()) {
        gobCollImp.add((GraphicalObject) gobIter.next());
      }
      
      DenimCustomComponent custComp = new DenimCustomComponent(componentName,
               new ImageIcon(Denim.class.getResource("images/stamps/rubber_stamp.gif")),
               gobCollImp);

		// let customized component have a parent
		//custComp.setVisible(false);
		//sheet.addToBack(custComp);
		
      dummySheet.clear();
      
      //DenimComponentRegistry.getInstance().registerComponent(custComp);
      return custComp;
   }

}


//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
