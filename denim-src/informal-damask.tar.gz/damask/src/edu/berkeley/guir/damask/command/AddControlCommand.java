package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.component.Trigger;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that adds a control to a page region.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  10-22-2003 James Lin
 *                               Created AddControlCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 10-22-2003
 */
public class AddControlCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private Dialog dialog;
   private final PageRegion region;
   private final Control control;
   private final Control controlBefore;
   private Page voicePageWithTrigger = null;
   private Page splitVoicePage = null;
   
   // store this separately, since control.toLongString() can change
   // depending on its bounds, etc
   private final String controlString;
   
   /**
    * Constructs the command.
    *  
    * @param region the page region to add the control to
    * @param control the control to add
    */      
   public AddControlCommand(final PageRegion region, final Control control) {
      this.region = region;
      controlBefore = null;
      this.control = control;
      controlString = control.toLongString();
   }
   
   /**
    * Constructs the command.
    *  
    * @param controlBefore the control after which the new control should be added
    * @param control the control to add
    */      
   public AddControlCommand(
      final Control controlBefore,
      final Control control) {

      region = null;
      this.controlBefore = controlBefore;
      this.control = control;
      controlString = control.toLongString();
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      if (region != null) {
         return "Add control " + controlString + " to page " + region;
      }
      else {
         return "Add control " + controlString +
            " before " + controlBefore +
            " in dialog " + controlBefore.getDialog();
      }
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      if (region != null) {
         dialog = region.getPage().getDialog();
         dialog.addControlAtBeginning(region, control);
      }
      else {
         dialog = controlBefore.getDialog();
         dialog.addControlAfter(controlBefore, control);
      }
      
      // If a trigger is being added to a voice UI, then all of the
      // non-trigger controls below the trigger in the same page must
      // be split into its own page within the same dialog.
//      if (control.isVisibleToDeviceType(DeviceType.VOICE) &&
//          (control instanceof Trigger)) {
//         final Page[] pages =
//            DamaskUtils.splitVoicePageAfterTrigger((Trigger)control);
//         voicePageWithTrigger = pages[0];
//         splitVoicePage = pages[1];
//      }
   }

   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   
   // Overrides method in superclass.   
   public void undo() {
      if (splitVoicePage != null) {
         voicePageWithTrigger.merge(splitVoicePage);
      }
      dialog.removeControl(control);
   }
}
