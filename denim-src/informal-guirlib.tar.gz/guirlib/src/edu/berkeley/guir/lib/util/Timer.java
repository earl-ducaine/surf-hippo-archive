//// See bottom of source code for software license.
package edu.berkeley.guir.lib.util;

/**
 * A class for doing stopwatch times.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Apr 09 2002 JIH
 */
public class Timer {

   //===========================================================================
   //===   NONLOCAL INSTANCE VARIABLES   =======================================

   private long    lStartTime   = -1;    // the start time (milliseconds)
   private long    lStopTime    = -1;    // the stop time (milliseconds)
   private long    lElapsedTime = 0;     // the total elapsed time
   private boolean flagRunning  = false; // is the timer running?

   //===   NONLOCAL INSTANCE VARIABLES   =======================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Default constructor.
    */
   public Timer() {
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Get the elapsed time so far. If the timer is running, it does not
    * stop it. If the timer is not running, then it gets the total elapsed
    * time so far.
    *
    * @return    A long representing the elapsed time so far.
    */
   public long getElapsedTime() {
      if (flagRunning == true) {
         return (System.currentTimeMillis() - lStartTime);
      } else {
         return (lElapsedTime);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the start time of the timer.
    *
    * @return Returns the system time (milliseconds) when the Timer was started.
    *         Returns -1 if the Timer has not been started.
    */
   public long getStartTime() {
      return (lStartTime);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the stop time of the timer.
    *
    * @return Returns the system time (milliseconds) when the Timer was stopped.
    *         Returns -1 if the Timer has not been stopped.
    */
   public long getStopTime() {
      return (lStopTime);
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if the Timer is running or not.
    *
    * @return true if the Timer is running, false otherwise.
    */
   public boolean isRunning() {
      return (flagRunning);
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Start the timer.
    */
   public void start() {
      //// 1. Get and record the current time
      lStartTime = System.currentTimeMillis();

      //// 2. Set the running flag
      flagRunning = true;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Stop the timer only if it is already running.
    */
   public void stop() {
      //// 1. Stop the timer
      if (flagRunning == true) {
         lStopTime     = System.currentTimeMillis();
         lElapsedTime += lStopTime - lStartTime;
         flagRunning   = false;
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Completely reset the timer so that it is a new timer.
    */
   public void resetTimer() {
      lElapsedTime = 0;
      lStartTime   = 0;
      lStopTime    = 0;
      flagRunning  = false;
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   TOSTRING   ==========================================================

   /*
    * Convert this object into some form of String.
    *
    * @return a String containing information about this object.
    */
   public String toString() {
      return( "[(Start: "   + getStartTime()   + ")" +
              " (Stop: "    + getStopTime()    + ")" +
              " (Elapsed: " + getElapsedTime() + ")" +
              " (Running: " + flagRunning  + ")]");
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   MAIN    =============================================================
/*
   //
   // Used for self-testing purposes.
   //
   public static void main(String[] argv) throws Exception {

      Timer t1 = new Timer();

      t1.start();

      Timer t2 = new Timer();
      t2.start();

      // this measures the amount of time to create a new object
      // and run the Timer start() method
      t1.stop();
      System.out.println(t1);

      System.out.println();

      System.out.println(t2.getElapsedTime());
      Thread.sleep(1000);

      System.out.println(t2.getElapsedTime());
      Thread.sleep(1000);

      System.out.println(t2.getElapsedTime());
      Thread.sleep(1000);

      System.out.println(t2.getElapsedTime());
      Thread.sleep(1000);

      System.out.println(t2.getElapsedTime());
      Thread.sleep(1000);

      System.out.println(t2.getElapsedTime());
      Thread.sleep(1000);

      System.out.println(t2.getElapsedTime());



      t2.stop();

      // just making sure it really stops
      System.out.println();
      System.out.println(t2);
      System.out.println(t2);
      System.out.println(t2);

      System.out.println();
      System.out.println(t1);


   } // of main
*/
   //===   MAIN    =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
