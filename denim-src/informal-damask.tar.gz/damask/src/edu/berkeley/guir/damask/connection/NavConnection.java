package edu.berkeley.guir.damask.connection;

import java.awt.geom.GeneralPath;
import java.util.Iterator;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.userevent.DamaskUserEvent;
import edu.berkeley.guir.lib.util.StringLib;

/** 
 * A transition representing the flow of the end-user from one element of
 * interaction to another.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2003 James Lin
 *                               Created Transition.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-20-2003
 */
public class NavConnection extends Connection {
   private DamaskUserEvent userEvent;
   private int condition;

   //===========================================================================

   /**
    * Creates a navigational connection which specifies that if the given source
    * receives the given event on the given device type under the given
    * condition, then transition to the given destination.
    */
   public NavConnection(
      final DeviceType deviceType,
      final boolean forAllDevices,
      final Control sourceForDeviceType,
      final DamaskUserEvent userEvent,
      final int condition,
      final ConnectionDest destForDeviceType,
      final GeneralPath generalPathForDeviceType) {

      super(
         deviceType,
         forAllDevices,
         sourceForDeviceType,
         Control.class,
         destForDeviceType,
         ConnectionDest.class,
         generalPathForDeviceType);

      this.userEvent = userEvent;
      this.condition = condition;

      basicSetUserEvent(userEvent);
      basicSetCondition(condition);
   }

   //===========================================================================

   /**
    * Returns the type of event that the user must do on the transition's
    * source for this transition to be activated, from the given device
    * type's perspective.
    */
   public DamaskUserEvent getUserEvent() {
      return userEvent;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the type of event that the user must do on the transition's
    * source for this transition to be activated, given the given device type.
    */
   private void basicSetUserEvent(final DamaskUserEvent userEvent) {
      final DamaskUserEvent oldUserEvent = this.userEvent;
      this.userEvent = userEvent;
      fireUserEventChanged(oldUserEvent, userEvent);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the type of event that the user must do on the transition's
    * source for this transition to be activated, given the given device type.
    */
   public void setUserEvent(final DamaskUserEvent userEvent) {
      basicSetUserEvent(userEvent);
   }

   //===========================================================================

   /**
    * Returns the source of the transition, from the given device type's
    * perspective.
    */
   public Control getSource(DeviceType deviceType) {
      return (Control)getConnectionSource(deviceType);
   }

   //===========================================================================

   /**
    * Returns the destination of the transition.
    */
   public ConnectionDest getDest(DeviceType deviceType) {
      return getConnectionDest(deviceType);
   }

   //===========================================================================

   /**
    * Returns the condition under which this connection is used.
    */
   public int getCondition() {
      return condition;
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the condition under which this connection is used.
    */
   private void basicSetCondition(int condition) {
      final int oldCondition = this.condition;
      this.condition = condition; 
      fireConditionChanged(oldCondition, condition);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the condition under which this connection is used.
    */
   public void setCondition(int condition) {
      basicSetCondition(condition);
   }

   //===========================================================================

   private String transitionInfoToString(DeviceType deviceType) {
      final StringBuffer sb = new StringBuffer();

      sb.append(" [");
      sb.append(getUserEvent());
      sb.append("]: ");
      sb.append(getSource(deviceType).toString());
      sb.append(" -> ");
      sb.append(getDest(deviceType).toString());

      return sb.toString();
   }

   //===========================================================================

   public String toLongString() {
      final StringBuffer sb = new StringBuffer();

      sb.append(toString());
      // For each device, recursively write the containees
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext();) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         sb.append("* " + aDeviceType + " - ");
         sb.append(transitionInfoToString(aDeviceType));
         if (i.hasNext()) {
            sb.append("\n");
         }
      }

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of this page, with the given indent
    * level and including the components that support the given device.
    */
   public String toLongString(int indentLevel, final DeviceType aDeviceType) {
      // 1. Make sure we have a concrete device; "all" is not acceptable here.
      assert aDeviceType != DeviceType.ALL : "Device cannot be ALL";

      final StringBuffer sb = new StringBuffer();

      sb.append(StringLib.spaces(indentLevel * DamaskUtils.INDENT_SPACES));
      sb.append(toString());
      sb.append(transitionInfoToString(aDeviceType));

      return sb.toString();
   }

   //===========================================================================

   public Object clone() {
      final NavConnection clone = (NavConnection)super.clone();

      clone.userEvent =
         userEvent.createCopy(clone.getSource(getOrigSpecifiedDeviceType()));
      
      return clone;
   }
}
