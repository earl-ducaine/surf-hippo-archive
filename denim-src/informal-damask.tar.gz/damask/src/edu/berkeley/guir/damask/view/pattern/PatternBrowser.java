package edu.berkeley.guir.damask.view.pattern;

import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.*;
import java.net.URL;
import java.util.*;
import java.util.List;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.border.*;

import edu.berkeley.guir.damask.Damask;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.pattern.*;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.DamaskDocument.DamaskCanvasGroup;
import edu.berkeley.guir.damask.view.visual.DamaskPhoneRunFrame;
import edu.berkeley.guir.damask.view.voice.VoicePreview;
import edu.umd.cs.piccolox.swing.PScrollPane;

/**
 * A browser for viewing patterns.
 * 
 * <P>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * @author Qing Li
 * @author <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */
public class PatternBrowser extends JFrame {
   private static final String ILLUSTRATION = "Illustration";
   private static final String CONTEXT = "Background";
   private static final String PROBLEM = "Problem";
   private static final String SOLUTION = "Solution";
   private static final String CONSIDER = "Consider These Other Patterns";
   private static final String RELATED = "Related Patterns";
   private static final String CREDITS = "Credits";

   private static final int DEFAULT_WIDTH = 1000;
   private static final int DEFAULT_HEIGHT = 500;
   private static final int SECTION_PADDING = 8;
   private static final int COMPONENT_PADDING = 5;
   private static final int MIN_SEARCH_RESULTS_HEIGHT = 100;
   private static final int MIN_PATTERN_DISPLAY_WIDTH = 300;

   private static final Icon SHOW_ICON;
   private static final Icon HIDE_ICON;
   static {
      final Toolkit toolkit = Toolkit.getDefaultToolkit();
      SHOW_ICON = new ImageIcon(toolkit.getImage(DamaskApp.class
            .getResource("images/pattern/show.png")));
      HIDE_ICON = new ImageIcon(toolkit.getImage(DamaskApp.class
            .getResource("images/pattern/hide.png")));
   }
   
   private static final Logger logger =
      Logger.getLogger(PatternBrowser.class.getName());

   public static final DataFlavor PATTERN_SOLUTION_FLAVOR = new DataFlavor(
         DataFlavor.javaJVMLocalObjectMimeType
               + ";class=edu.berkeley.guir.damask.pattern.PatternSolution",
         "Damask-based pattern solution");

   private static final Map/*<String, String>*/ groupColors =
      new HashMap/*<String, String>*/();
   static {
      groupColors.put("A", "#2E1263");
      groupColors.put("B", "#005E9D");
      groupColors.put("C", "#007E98");
      groupColors.put("D", "#D5847D");
      groupColors.put("E", "#881344");
      groupColors.put("F", "#657376");
      groupColors.put("G", "#9EACAA");
      groupColors.put("H", "#9E481A");
      groupColors.put("I", "#A56E08");
      groupColors.put("J", "#FCAF17");
      groupColors.put("K", "#AA9900");
      groupColors.put("L", "#7A8F1B");
   }
   
   private static final Map/*<String, String>*/ groupNames =
      new HashMap/*<String, String>*/();
   static {
      groupNames.put("A", "Site Genres");
      groupNames.put("B", "Creating a Navigation Framework");
      groupNames.put("C", "Creating a Powerful Homepage");
      groupNames.put("D", "Writing and Managing Content");
      groupNames.put("E", "Building Trust and Credibility");
      groupNames.put("F", "Basic E-Commerce");
      groupNames.put("G", "Advanced E-Commerce");
      groupNames.put("H", "Helping Customers Complete Tasks");
      groupNames.put("I", "Designing Effective Page Layouts");
      groupNames.put("J", "Making Site Search Fast and Relevant");
      groupNames.put("K", "Making Navigation Easy");
      groupNames.put("L", "Speeding Up Your Site");
   }
   
   private Pattern currentPattern = null;
   
   private final PatternsSearcher scanner;
   private final JButton backButton;
   private final JButton forwardButton;
   private final JTextField searchTextField;
   private final JButton showHideSearchResultsButton;
   private final JSplitPane contentSplitPane;
   private final JSplitPane mainSplitPane;
   private final JLabel searchResultsLabel;
   private final JEditorPane searchResultsPane;
   private final JLabel showAllLabel;
   private final JEditorPane showAllPane;
   private final JButton showHidePatternIndexButton;
   private final JScrollPane patternScrollPane;
   private final JLabel nameLabel = new JLabel();
   private Map/* <String, InfoPanel> */infoPanels = new HashMap();
   private Stack backStack = new Stack();
   private Stack forwardStack = new Stack();

   /**
    * Creates a pattern browser, initially displaying the pattern with the
    * specified pattern ID.
    */
   public PatternBrowser(
         final String initialCollectionId, final String initialPatternId) {
      
      scanner = new PatternsSearcher(
         Pattern.class.getResource("PatternList.txt"));

      final Container contentPane = getContentPane();
      contentPane.setLayout(new BorderLayout());

      final ShowHideSearchResultsAction searchResultsAction =
         new ShowHideSearchResultsAction();
      final ShowHidePatternIndexAction patternDisplayAction =
         new ShowHidePatternIndexAction();

      // Lay out the toolbar and search bar
      {
         final JPanel toolBarsArea = new JPanel();
         toolBarsArea.setLayout(new BorderLayout());

         {
            final JToolBar toolbar = new JToolBar();
            toolbar.setFloatable(false);
            backButton = DamaskAppUtils.createBackButton(new BackAction());
            toolbar.add(backButton);
            backButton.setEnabled(false);

            forwardButton = DamaskAppUtils
                  .createForwardButton(new ForwardAction());
            toolbar.add(forwardButton);
            forwardButton.setEnabled(false);

            toolBarsArea.add(toolbar, BorderLayout.NORTH);
         }

         {
            final JPanel searchBar = new JPanel();
            searchBar.setLayout(new BoxLayout(searchBar, BoxLayout.LINE_AXIS));

            showHidePatternIndexButton = new JButton(patternDisplayAction);
            showHidePatternIndexButton.setBorder(new EmptyBorder(
                  COMPONENT_PADDING, COMPONENT_PADDING, COMPONENT_PADDING,
                  COMPONENT_PADDING));
            searchBar.add(showHidePatternIndexButton);

            final JLabel searchLabel = new JLabel("Look for:");
            searchLabel.setBorder(new EmptyBorder(COMPONENT_PADDING,
                  COMPONENT_PADDING, COMPONENT_PADDING, COMPONENT_PADDING));
            searchBar.add(searchLabel);

            searchTextField = new JTextField();
            searchTextField.setBorder(new EmptyBorder(COMPONENT_PADDING,
                  COMPONENT_PADDING, COMPONENT_PADDING, COMPONENT_PADDING));
            searchBar.add(searchTextField);

            searchBar.add(Box.createHorizontalStrut(COMPONENT_PADDING));

            final JButton searchButton = new JButton(new SearchAction());
            searchButton.setBorder(new EmptyBorder(COMPONENT_PADDING,
                  COMPONENT_PADDING, COMPONENT_PADDING, COMPONENT_PADDING));
            searchBar.add(searchButton);

            showHideSearchResultsButton = new JButton(searchResultsAction);
            showHideSearchResultsButton.setBorder(new EmptyBorder(
                  COMPONENT_PADDING, COMPONENT_PADDING, COMPONENT_PADDING,
                  COMPONENT_PADDING));
            searchBar.add(showHideSearchResultsButton);

            toolBarsArea.add(searchBar, BorderLayout.CENTER);
         }
         contentPane.add(toolBarsArea, BorderLayout.NORTH);
      }

      // Second, lay out the search results pane and the contents of the
      // pattern info pane
      {
         final JPanel searchResultsPanel = new JPanel();
         searchResultsPanel.setLayout(new BoxLayout(searchResultsPanel,
               BoxLayout.PAGE_AXIS));
         searchResultsPanel.setMinimumSize(new Dimension(0, 0));
         {
            searchResultsLabel = new JLabel("Search Results");
            searchResultsLabel.setBorder(new EmptyBorder(COMPONENT_PADDING,
                  COMPONENT_PADDING, COMPONENT_PADDING, COMPONENT_PADDING));
            searchResultsLabel.setAlignmentX(0);
            searchResultsPanel.add(searchResultsLabel);

            searchResultsPane = new JEditorPane();
            searchResultsPane.setContentType("text/html");
            searchResultsPane.addHyperlinkListener(new LinkListener(
                  searchResultsPane, this));
            searchResultsPane.setEditable(false);
            final JScrollPane searchResultsScrollPane = new JScrollPane(
                  searchResultsPane);
            searchResultsScrollPane.setAlignmentX(0);
            searchResultsPanel.add(searchResultsScrollPane);
         }

         final JPanel patternPanel = new FlexWidthPanel();
         patternPanel
               .setLayout(new BoxLayout(patternPanel, BoxLayout.PAGE_AXIS));
         {
            nameLabel.setFont(nameLabel.getFont().deriveFont(Font.BOLD, 14));
            nameLabel.setBackground(Color.WHITE);
            final JPanel namePanel = new JPanel();
            namePanel.setBackground(Color.WHITE);
            namePanel.setLayout(new BorderLayout());
            namePanel.add(nameLabel, BorderLayout.WEST);
            namePanel.setBorder(new EmptyBorder(SECTION_PADDING,
                  SECTION_PADDING, SECTION_PADDING, SECTION_PADDING));
            patternPanel.add(namePanel);

            createInfoPanel(patternPanel, ILLUSTRATION);
            createInfoPanel(patternPanel, CONTEXT);
            createInfoPanel(patternPanel, PROBLEM);
            createInfoPanel(patternPanel, SOLUTION);
            createInfoPanel(patternPanel, CONSIDER);
            createInfoPanel(patternPanel, RELATED);
            createInfoPanel(patternPanel, CREDITS);

            patternScrollPane = new JScrollPane(patternPanel);
            patternScrollPane.setWheelScrollingEnabled(true);
            patternScrollPane.setPreferredSize(new Dimension(DEFAULT_WIDTH,
                  DEFAULT_HEIGHT));
         }

         contentSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, true,
               searchResultsPanel, patternScrollPane);
         contentSplitPane
               .addPropertyChangeListener(JSplitPane.DIVIDER_LOCATION_PROPERTY,
                                          searchResultsAction);
         //contentPane.add(contentSplitPane);
      }

      // Third, add a side panel showing all available patterns
      {
         final JPanel showAllPanel = new JPanel();
         showAllPanel
               .setLayout(new BoxLayout(showAllPanel, BoxLayout.PAGE_AXIS));
         showAllPanel.setMinimumSize(new Dimension(0, 0));
         showAllLabel = new JLabel("Pattern Index");
         showAllLabel.setBorder(new EmptyBorder(COMPONENT_PADDING,
               COMPONENT_PADDING, COMPONENT_PADDING, COMPONENT_PADDING));
         showAllLabel.setAlignmentX(0);
         showAllPanel.add(showAllLabel);

         showAllPane = new JEditorPane();
         showAllPane.setContentType("text/html");
         showAllPane.addHyperlinkListener(new LinkListener(showAllPane, this));
         showAllPane.setEditable(false);
         
         final StringBuffer sb = new StringBuffer();
         sb.append("<html>");
         sb.append("<head>");
         sb.append("<style>");
         sb.append("a.val { color: #ffffff; } ");
         sb.append("td { font-family: sans-serif; } ");
         sb.append("</style>");
         sb.append("</head><body>");
         sb.append(
            createPatternsIndex(Pattern.class.getResource("PatternList.txt")));
         sb.append("</body></html>");
         showAllPane.setText(sb.toString());
         
         final JScrollPane showAllScrollPane = new JScrollPane(showAllPane);
         showAllScrollPane.setAlignmentX(0);
         showAllPanel.add(showAllScrollPane);

         //contentPane.add(showAllPanel, BorderLayout.WEST);
         mainSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true,
               showAllPanel, contentSplitPane);

         mainSplitPane
               .addPropertyChangeListener(JSplitPane.DIVIDER_LOCATION_PROPERTY,
                                          patternDisplayAction);
         mainSplitPane.setDividerLocation(MIN_PATTERN_DISPLAY_WIDTH);
         contentPane.add(mainSplitPane);
      }

      // Fill in the pattern info pane with info from initialPatternId
      displayPattern(
         PatternLibrary.getPattern(initialCollectionId, initialPatternId));
      
      addComponentListener(new ComponentHandler());
      
      setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
      validate();
   }

   public void scrollToTop() {
      final JScrollBar verticalBar = patternScrollPane.getVerticalScrollBar();
      verticalBar.setValue(verticalBar.getMinimum());
      patternScrollPane.getViewport().setViewPosition(new Point(0, 0));
   }

   /**
    * Creates an info panel with the specified name and add it to the specified
    * panel.
    */
   private void createInfoPanel(final JPanel panel, final String name) {
      final InfoPanel infoPanel = new InfoPanel(name);
      infoPanels.put(name, infoPanel);
      panel.add(infoPanel);
   }

   /**
    * Returns the info panel with the specified name.
    */
   private InfoPanel getInfoPanel(final String name) {
      return (InfoPanel) infoPanels.get(name);
   }

   /**
    * Displays the current pattern.
    */
   private void displayCurrentPattern() {
      fillPatternInfoPane();

      setTitle(currentPattern.getName() + " - Damask - Pattern Browser");

      backButton.setEnabled(canGoBack());
      forwardButton.setEnabled(canGoForward());

      // Scroll to the top
      final JScrollBar verticalBar = patternScrollPane.getVerticalScrollBar();
      verticalBar.setValue(verticalBar.getMinimum());
   }

   /**
    * Displays the pattern with the specified ID in the browser.
    */
   public void displayPattern(final Pattern pattern) {
      final Cursor oldCursor = getCursor();
      setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
      
      if (currentPattern != null) {
         backStack.push(currentPattern);
      }
      forwardStack.clear();
      currentPattern = pattern;

      displayCurrentPattern();
      
      setCursor(oldCursor);
   }

   /**
    * Returns the pattern being currently displayed in the browser.
    */
   public Pattern getCurrentPattern() {
      return currentPattern;
   }

   /**
    * Displays the pattern that would appear when the user presses the Back
    * button.
    */
   public void goBack() {
      forwardStack.push(currentPattern);
      currentPattern = (Pattern) backStack.pop();

      displayCurrentPattern();
   }

   /**
    * Returns whether Back navigation is possible.
    */
   public boolean canGoBack() {
      return !backStack.isEmpty();
   }

   /**
    * Displays the pattern that would appear when the user presses the Forward
    * button.
    */
   public void goForward() {
      backStack.push(currentPattern);
      currentPattern = (Pattern) forwardStack.pop();

      displayCurrentPattern();
   }

   /**
    * Returns whether Forward navigation is possible.
    */
   public boolean canGoForward() {
      return !forwardStack.isEmpty();
   }

   /**
    * Open the specified URL in the user's default browser.
    */
   public void launchURL(final URL url) {
      try {
         BrowserLauncher.openURL(url.toString());
      }
      catch (IOException ioe) {
         //TODO pop up error dialog
         DamaskAppExceptionHandler.log(ioe);
      }
   }

   /**
    * Fill the contents of the pattern info pane with the info from the current
    * pattern.
    */
   private void fillPatternInfoPane() {
      InfoPanel infoPanel;

      infoPanel = getInfoPanel(ILLUSTRATION);
      infoPanel.clear();
      infoPanel.addImagePanel(currentPattern.getIllustrationURL());
      infoPanel.addHtmlPanel(currentPattern.getIllustrationText());

      infoPanel = getInfoPanel(CONTEXT);
      infoPanel.clear();
      infoPanel.addHtmlPanel(currentPattern.getBackground());

      infoPanel = getInfoPanel(PROBLEM);
      infoPanel.clear();
      infoPanel.addHtmlPanel(currentPattern.getProblem());

      infoPanel = getInfoPanel(SOLUTION);
      infoPanel.clear();
      infoPanel.addHtmlPanel(currentPattern.getSolutionText());
      infoPanel.addImagePanel(currentPattern.getSolutionImageURL());
      infoPanel.addHtmlPanel(currentPattern.getSolutionImageText());

      if (!currentPattern.getSolution().getDialogs().isEmpty()) {
         infoPanel.addSolutionPanel(currentPattern);
      }

      infoPanel = getInfoPanel(CONSIDER);
      infoPanel.clear();
      infoPanel.addHtmlPanel(currentPattern.getRelatedPatternsText());

      infoPanel = getInfoPanel(RELATED);
      infoPanel.clear();
      infoPanel.addHtmlPanel(createRelatedPatternsDiagrams(currentPattern),
                             Color.WHITE,
                             Color.LIGHT_GRAY);

      infoPanel = getInfoPanel(CREDITS);
      infoPanel.clear();
      infoPanel.addHtmlPanel(currentPattern.getCredits());

      // This is last because it helps the scroll bar scroll to the top.
      nameLabel.setText(currentPattern.getName());
   }

   
   /**
    * Takes the specified collection of patterns, and returns a map which
    * maps the group ("A" through "L" plus "") to the patterns that the
    * group contains, in numerical order.
    */
   private static Map/*<String, Set<Pattern>>*/ getCategorizedPatterns(
         final Collection patterns) {
      
      final Map/*<String, Set<Pattern>>*/ result =
         new TreeMap/*<String, Set<Pattern>>*/();
      
      for (Iterator i = patterns.iterator(); i.hasNext(); ) {
         final Pattern pattern = (Pattern)i.next();
         final String group = pattern.getGroup();
         Set/*<Pattern>*/ patternsInGroup = (Set)result.get(group);
         if (patternsInGroup == null) {
            patternsInGroup = new TreeSet/*<Pattern>*/(new Comparator() {
               public int compare(final Object o1, final Object o2) {
                  final int index1 = ((Pattern)o1).getIndexInGroup();
                  final int index2 = ((Pattern)o2).getIndexInGroup();
                  if (index1 < index2) {
                     return -1;
                  }
                  else if (index1 == index2) {
                     return 0;
                  }
                  else {
                     return 1;
                  }
               }
            });
            result.put(group, patternsInGroup);
         }
         patternsInGroup.add(pattern);
      }
      return result;
   }

   
   /**
    * Creates a URL string for a hyperlink for the specified pattern
    * with the specified text.
    */
   public static String createPatternLinkURLString(final Pattern pattern) {
      return
         createPatternLinkURLString(pattern.getCollectionID(), pattern.getID());
   }

   
   /**
    * Creates a URL string for a hyperlink for the specified pattern
    * with the specified text.
    */
   public static String createPatternLinkURLString(
      final String collectionID, final String patternID) {
      
      return "http://damask/" + collectionID + "/" + patternID;
   }
   
   
   /**
    * Returns the pattern referenced by the specified URL.
    */
   public static Pattern getPatternFromURL(final URL url) {
      if (url.getProtocol().equals("http") && url.getHost().equals("damask")) {
         String[] pathParts = url.getPath().split("/");
         return PatternLibrary.getPattern(pathParts[1], pathParts[2]);
      }
      else {
         return null;
      }
   }
   
   /**
    * Creates a diagram that groups the specified collection of patterns by
    * their groups.   
    */
   private String createRelatedPatternsDiagram(
      final Collection/*<Pattern>*/ patterns) {
      
      final StringBuffer sb = new StringBuffer();
      sb.append("<table border=\"0\"><tr>");
      
      final Map/*<String, Set<Pattern>>*/ groupedPatterns =
         getCategorizedPatterns(patterns);

      for (Iterator i = groupedPatterns.keySet().iterator(); i.hasNext(); ) {
         final String group = (String)i.next();

         sb.append("<td bgcolor=\"" + groupColors.get(group) +
                   "\" align=\"center\" valign=\"top\">");
         sb.append("<table border=\"0\" cellpadding=\"10\">");
         
         for (Iterator j = ((Set)groupedPatterns.get(group)).iterator();
              j.hasNext(); ) {
            final Pattern pattern = (Pattern)j.next();
            sb.append(
               "<tr><td><a class=\"val\" href=\"" +
               createPatternLinkURLString(pattern) +
               "\">" + pattern.getName() + "</a></td></tr>");
         }
         sb.append("</table></td>");
      }
      sb.append("</tr></table>");
      return sb.toString();
   }
   

   /**
    * Creates diagrams of the patterns related to the specified pattern.   
    */
   private String createRelatedPatternsDiagrams(final Pattern pattern) {
      final Collection inPatterns = pattern.getInRefs();
      final Collection outPatterns = pattern.getOutRefs();
      
      final StringBuffer sb = new StringBuffer();
      sb.append("<center>");

      if (inPatterns.size() > 0) {
         sb.append("<p>This pattern is <b>used by</b>:");
         sb.append(createRelatedPatternsDiagram(inPatterns));
         sb.append("<br>");
      }

      if (outPatterns.size() > 0) {
         sb.append("<p>This pattern <b>uses</b>:");
         sb.append(createRelatedPatternsDiagram(outPatterns));
      }
      sb.append("</center>");
      return sb.toString();
   }

   
   /**
    * Creates an index of patterns stored in the resource with the specified
    * URL.
    * 
    * @return an HTML fragment containing the index 
    */
   private static String createPatternsIndex(final URL patternsListURL) {
      final StringBuffer sb = new StringBuffer();
      try {
         final Set/*<Pattern>*/ allPatterns = new HashSet/*<Pattern>*/();
         
         final BufferedReader indexReader =
            new BufferedReader(
               new InputStreamReader(patternsListURL.openStream()));
         
         String patternline;
         while ((patternline = indexReader.readLine()) != null) {
            final String[] ids =
               PatternParser.getPatternIDs(
                  Pattern.class.getResource(patternline));
            final Pattern pattern = PatternLibrary.getPattern(ids[0], ids[1]);
            allPatterns.add(pattern);
         }
         
         final Map/*<String, Set<Pattern>>*/ groupedPatterns =
            getCategorizedPatterns(allPatterns);
         
         sb.append("<table border=\"0\" cellpadding=\"5\" width=\"100%\">");
         for (Iterator i = groupedPatterns.keySet().iterator(); i.hasNext(); ) {
            final String group = (String)i.next();

            sb.append("<tr bgcolor=\"" + groupColors.get(group) +
                      "\" align=\"left\" valign=\"top\">");
            sb.append("<td colspan=\"2\"><font color=\"#ffffff\"><b>" +
               groupNames.get(group) + " (" + group +
               ") </b></font></td></tr>");
            
            for (Iterator j = ((Set)groupedPatterns.get(group)).iterator();
                 j.hasNext(); ) {
               final Pattern pattern = (Pattern)j.next();
               sb.append("<tr bgcolor=\"" + groupColors.get(group) +
                      "\" align=\"left\" valign=\"top\">");
               sb.append("<td>&nbsp;&nbsp;&nbsp;</td><td><a class=\"val\" href=\"" +
                         PatternBrowser.createPatternLinkURLString(pattern) +
                         "\">" + pattern.getName() + "</a></td></tr>");
            }
         }
         sb.append("</table>");
      }
      catch (FileNotFoundException fnfe) {
         DamaskAppExceptionHandler.log(fnfe);
      }
      catch (IOException ioe) {
         DamaskAppExceptionHandler.log(ioe);
      }
      return sb.toString();
   }

   /**
    * Listens to window events.
    */
   private class ComponentHandler extends ComponentAdapter {
      public void componentShown(ComponentEvent event) {
         logger.info("Pattern browser visible");
         for (Iterator i = DamaskFrame.getAllDamaskFrames().iterator(); 
              i.hasNext(); ) {
            final DamaskFrame frame = (DamaskFrame)i.next();
            frame.onPatternBrowserVisibleChanged(true);
       
         }
      }
      public void componentHidden(ComponentEvent event) {
         logger.info("Pattern browser not visible");
         for (Iterator i = DamaskFrame.getAllDamaskFrames().iterator(); 
              i.hasNext(); ) {
            final DamaskFrame frame = (DamaskFrame)i.next();
            frame.onPatternBrowserVisibleChanged(false);
         }
      }
   }

   /**
    * The Back action.
    */
   private class BackAction extends AbstractAction {
      public BackAction() {
         super("Back");
         putValue(SHORT_DESCRIPTION, "Go back");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_LEFT));
      }

      public void actionPerformed(ActionEvent e) {
         goBack();
      }
   }

   /**
    * The Forward action.
    */
   private class ForwardAction extends AbstractAction {
      public ForwardAction() {
         super("Forward");
         putValue(SHORT_DESCRIPTION, "Go forward");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_RIGHT));
      }

      public void actionPerformed(ActionEvent e) {
         goForward();
      }
   }

   /**
    * The Search action.
    */
   private class SearchAction extends AbstractAction {
      public SearchAction() {
         super("Search");
         putValue(SHORT_DESCRIPTION, "Search the pattern library");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_S));
      }

      public void actionPerformed(ActionEvent event) {
         final String searchKeyWords = searchTextField.getText();
         final List/* <String> */searchResults = scanner
               .searchPatterns(searchKeyWords);
         searchResultsLabel.setText("Search Results - " + searchKeyWords
               + " - " + searchResults.size() + " matches found");

         final StringBuffer searchResultsBuffer = new StringBuffer();
         for (Iterator i = searchResults.iterator(); i.hasNext();) {
            final String result = (String) i.next();
            searchResultsBuffer.append(result);
            if (i.hasNext()) {
               searchResultsBuffer.append("<br>");
            }
         }

         searchResultsPane.setText(searchResultsBuffer.toString());
         searchResultsPane.setCaretPosition(0);
         if (contentSplitPane.getDividerLocation() < MIN_SEARCH_RESULTS_HEIGHT) {
            contentSplitPane.setDividerLocation(MIN_SEARCH_RESULTS_HEIGHT);
         }
      }
   }

   /**
    * Shows or hides the search results. Also listens to changes in the location
    * of the divider in the content split pane.
    */
   private class ShowHideSearchResultsAction extends AbstractAction implements
         PropertyChangeListener {

      private int lastDividerLocation = MIN_SEARCH_RESULTS_HEIGHT;

      private boolean listenToDividerLocation = true;

      public ShowHideSearchResultsAction() {
         super("Show Results");
         setExpanded(false);
         putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_R));
      }

      private void setExpanded(final boolean expanded) {
         if (expanded) {
            putValue(Action.NAME, "Hide Results");
            putValue(Action.SMALL_ICON, HIDE_ICON);
            putValue(Action.SHORT_DESCRIPTION, "Hide the search results");
         }
         else {
            putValue(Action.NAME, "Show Results");
            putValue(Action.SMALL_ICON, SHOW_ICON);
            putValue(Action.SHORT_DESCRIPTION, "Show the search results");
         }
      }

      // Runs when the component attached to this action is executed.
      public void actionPerformed(ActionEvent event) {
         // If the top panel is not visible, show it.
         if (contentSplitPane.getDividerLocation() <= 1) {
            contentSplitPane.setDividerLocation(Math
                  .max(lastDividerLocation, MIN_SEARCH_RESULTS_HEIGHT));
            setExpanded(true);
         }
         // Otherwise, hide it.
         else {
            listenToDividerLocation = false;
            lastDividerLocation = contentSplitPane.getDividerLocation();
            contentSplitPane.setDividerLocation(0);
            setExpanded(false);
            listenToDividerLocation = true;
         }
      }

      // Runs when the divider in the split pane changes location.
      public void propertyChange(PropertyChangeEvent evt) {
         if (listenToDividerLocation) {
            // Change the name of the action depending on whether the top
            // panel is visible.
            if (contentSplitPane.getDividerLocation() <= 1) {
               setExpanded(false);
            }
            else {
               setExpanded(true);
            }
         }
      }
   }

   /**
    * A panel that, when placed in a JScrollPane, adjusts its width to be the
    * width of the scroll pane.
    */
   private static class FlexWidthPanel extends JPanel implements Scrollable {
      // Exists only to give reasonable defaults to the first three methods.
      private static JTextArea textArea = new JTextArea();

      public Dimension getPreferredScrollableViewportSize() {
         return textArea.getPreferredScrollableViewportSize();
      }

      public int getScrollableUnitIncrement(final Rectangle visibleRect,
            final int orientation, final int direction) {

         return textArea.getScrollableUnitIncrement(visibleRect,
                                                    orientation,
                                                    direction);
      }

      public int getScrollableBlockIncrement(final Rectangle visibleRect,
            final int orientation, final int direction) {

         return textArea.getScrollableBlockIncrement(visibleRect,
                                                     orientation,
                                                     direction);
      }

      // This is the key method
      public boolean getScrollableTracksViewportWidth() {
         return true;
      }

      public boolean getScrollableTracksViewportHeight() {
         return false;
      }
   }

   /**
    * Shows or hides the all pattern display. Listens to changes in the location
    * of the divider in the content split pane.
    */
   private class ShowHidePatternIndexAction extends AbstractAction implements
         PropertyChangeListener {

      private int lastDividerLocation = MIN_PATTERN_DISPLAY_WIDTH;

      private boolean listenToDividerLocation = true;

      public ShowHidePatternIndexAction() {
         super("Show Pattern Index");
         putValue(Action.SHORT_DESCRIPTION, "Show the pattern index");
         putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_I));
      }

      // Runs when the component attached to this action is executed.
      public void actionPerformed(ActionEvent event) {
         // If the top panel is not visible, show it.
         if (mainSplitPane.getDividerLocation() <= 1) {
            mainSplitPane.setDividerLocation(Math
                  .max(lastDividerLocation, MIN_PATTERN_DISPLAY_WIDTH));
            putValue(Action.NAME, "Hide Pattern Index");
            putValue(Action.SHORT_DESCRIPTION, "Hide the pattern index");
         }
         // Otherwise, hide it.
         else {
            listenToDividerLocation = false;
            lastDividerLocation = mainSplitPane.getDividerLocation();
            mainSplitPane.setDividerLocation(0);
            putValue(Action.NAME, "Show Pattern Index");
            putValue(Action.SHORT_DESCRIPTION, "Show the pattern index");
            listenToDividerLocation = true;
         }
      }

      // Runs when the divider in the split pane changes location.
      public void propertyChange(PropertyChangeEvent evt) {
         if (listenToDividerLocation) {
            // Change the name of the action depending on whether the top
            // panel is visible.
            if (mainSplitPane.getDividerLocation() <= 1) {
               putValue(Action.NAME, "Show Pattern Index");
               putValue(Action.SHORT_DESCRIPTION, "Show the pattern index");
            }
            else {
               putValue(Action.NAME, "Hide Pattern Index");
               putValue(Action.SHORT_DESCRIPTION, "Hide the pattern index");
            }
         }
      }
   }

   /**
    * A panel that displays a section of information about a pattern, and has a
    * button that expands or collapses the panel.
    */
   private class InfoPanel extends JPanel {
      private static final int INTERNAL_PADDING = 5;

      private final JPanel contentPanel = new JPanel();

      private final JButton expanderButton;

      /**
       * Constructs an info panel with the specified name and an expand/contract
       * button.
       */
      public InfoPanel(final String name) {
         setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

         expanderButton = new JButton(HIDE_ICON);
         expanderButton.setToolTipText("Hides this panel");

         expanderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
               toggleExpanded();
            }
         });

         final JLabel titleLabel = new JLabel(name);
         titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD));
         final JPanel titlePanel = new JPanel();
         titlePanel.setLayout(new BorderLayout());
         titlePanel.setBorder(new EmptyBorder(INTERNAL_PADDING,
               INTERNAL_PADDING, INTERNAL_PADDING, INTERNAL_PADDING));
         titlePanel.add(titleLabel, BorderLayout.WEST);
         titlePanel.add(expanderButton, BorderLayout.EAST);
         titlePanel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
         titlePanel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent event) {
               toggleExpanded();
            }
         });
         add(titlePanel);

         contentPanel
               .setLayout(new BoxLayout(contentPanel, BoxLayout.PAGE_AXIS));
         add(contentPanel);

         setBorder(new CompoundBorder(new LineBorder(Color.WHITE,
               SECTION_PADDING), new LineBorder(Color.BLACK, 1)));
      }

      /**
       * Expand or contract this info panel.
       */
      private void toggleExpanded() {
         if (contentPanel.isVisible()) {
            contentPanel.setVisible(false);
            expanderButton.setIcon(SHOW_ICON);
            expanderButton.setToolTipText("Shows this panel");
         }
         else {
            contentPanel.setVisible(true);
            expanderButton.setIcon(HIDE_ICON);
            expanderButton.setToolTipText("Hides this panel");
         }
      }

      /**
       * Adds HTML content to this info panel.
       */
      public void addHtmlPanel(final String content) {
         final JEditorPane editorPane = new JEditorPane("text/html",
               "<html><body><br>" + content + "<br></body></html>");
         editorPane.setEditable(false);
         editorPane.addHyperlinkListener(new LinkListener(editorPane,
               PatternBrowser.this));
         editorPane.setBorder(new EmptyBorder(INTERNAL_PADDING,
               INTERNAL_PADDING, INTERNAL_PADDING, INTERNAL_PADDING));

         contentPanel.add(editorPane);
      }

      /**
       * Adds HTML content to this info panel.
       */
      public void addHtmlPanel(final String content,
                               final Color linkColor,
                               final Color visitedLinkColor) {
         
         final StringBuffer sb = new StringBuffer();
         sb.append("<html>");
         sb.append("<head>");
         if ((linkColor != null) || (visitedLinkColor != null)) {
            sb.append("<style>");
            if (linkColor != null) {
               sb.append("a.val { color: #" +
                         Integer.toHexString(linkColor.getRGB() & 0x00FFFFFF) +
                         "; } ");
            }
            if (visitedLinkColor != null) {
               sb.append("a.val:visited { color: #" +
                         Integer.toHexString(visitedLinkColor.getRGB()
                                             & 0x00FFFFFF) +
                         "; }");
            }
            sb.append("</style>");
         }
         sb.append("</head><body>");
         sb.append(content);
         sb.append("</body></html>");

         final JEditorPane editorPane =
            new JEditorPane("text/html", sb.toString());
         
         editorPane.setEditable(false);
         editorPane.addHyperlinkListener(new LinkListener(editorPane,
               PatternBrowser.this));
         editorPane.setBorder(new EmptyBorder(INTERNAL_PADDING,
               INTERNAL_PADDING, INTERNAL_PADDING, INTERNAL_PADDING));

         contentPanel.add(editorPane);
      }

      /**
       * Adds the specified image to this info panel.
       */
      public void addImagePanel(final URL url) {
         addImagePanel(Toolkit.getDefaultToolkit().getImage(url), new JPanel());
      }

      /**
       * Adds the specified image to this info panel.
       */
      private void addImagePanel(final Image image, final JPanel panel) {
         panel.setLayout(new BorderLayout());
         panel.setBackground(Color.WHITE);
         final JLabel imageLabel = new JLabel(new ImageIcon(image));
         panel.add(imageLabel, BorderLayout.WEST);
         panel.setBorder(new EmptyBorder(INTERNAL_PADDING, INTERNAL_PADDING,
               INTERNAL_PADDING, INTERNAL_PADDING));
         contentPanel.add(panel);
      }

      /**
       * Adds the specified Damask-based solution to this info panel.
       */
      public void addSolutionPanel(final Pattern pattern) {
         contentPanel.add(new DmkSolutionPanel(pattern));
      }

      /**
       * Removes all content from this panel.
       */
      public void clear() {
         contentPanel.removeAll();
      }
   }

   /**
    * A panel that displays the Damask-based solution of a pattern, which the
    * user can drag and drop onto his or her Damask design.
    */
   private class DmkSolutionPanel extends JPanel {
      private static final int INTERNAL_PADDING = 5;

      private final PatternSolution solution;
      private final DragSource dragSource;
      private final DragGestureListener dgListener;
      private final DragSourceListener dsListener;

      public DmkSolutionPanel(final Pattern pattern) {
         setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

         solution = pattern.getSolution();
         final DamaskDocument doc = new DamaskDocument(solution, -1);
         final DamaskCanvasGroup canvasGroup = doc.createCanvasGroup();

         // Set up drag-and-drop support
         dragSource = DragSource.getDefaultDragSource();
         dgListener = new DragGestureHandler();
         dsListener = new DragSourceHandler();

         dragSource.createDefaultDragGestureRecognizer(
            this,
            DnDConstants.ACTION_COPY_OR_MOVE,
            dgListener);

         for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
              i.hasNext(); ) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            if (!solution.getDialogs(aDeviceType).isEmpty()) {
               final JPanel devicePanel = new JPanel();
               devicePanel.setLayout(new BorderLayout());
               
               final JPanel devicePanelTop = new JPanel();
               devicePanelTop.setLayout(new BoxLayout(devicePanelTop, BoxLayout.PAGE_AXIS));
               
               final JPanel devicePanelTopBottom = new JPanel();
               devicePanelTopBottom.setLayout(new FlowLayout(FlowLayout.LEADING));
               final JButton runButton =
                  new JButton("Run");
               runButton.setIcon(DamaskToolbar.getToolbarIcon("run.png"));
               runButton.addActionListener(new ActionListener() {
                  public void actionPerformed(ActionEvent e) {
                     final Page homePage = solution.getHomePage(aDeviceType);
                     if (aDeviceType == DeviceType.VOICE) {
                        final VoicePreview voicePreview =
                           new VoicePreview(
                              null,
                              pattern.getName(),
                              homePage.getDialog());
                        voicePreview.go();
                     }
                     else {
                        final JFrame runFrame;
                        if (aDeviceType == DeviceType.SMARTPHONE) {
                           runFrame =
                              new DamaskPhoneRunFrame(
                                 pattern.getName(), homePage);
                        }
                        else {
                           runFrame =
                              new DamaskRunFrame(pattern.getName(), homePage);
                        }
                        runFrame.setVisible(true);
                     }
                     final JFrame runFrame;
                     if (aDeviceType == DeviceType.SMARTPHONE) {
                        runFrame = new DamaskPhoneRunFrame(pattern.getName(), homePage);
                     }
                     else if (aDeviceType == DeviceType.DESKTOP) {
                        runFrame = new DamaskRunFrame(pattern.getName(), homePage);
                     }
                     else {
                        runFrame = null;
                     }
                     if (runFrame != null) {
                        runFrame.setVisible(true);
                     }
                  }
               });
               
               devicePanelTopBottom.add(new JLabel(aDeviceType.toString()));
               devicePanelTopBottom.add(runButton);

               final JLabel dragLabel = new JLabel("<html><b>Drag this label and drop into the main window to add to your design.</b></html>");

               dragLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
               devicePanelTopBottom.setAlignmentX(Component.LEFT_ALIGNMENT);
               
               devicePanelTop.add(dragLabel);
               devicePanelTop.add(devicePanelTopBottom);
               
               devicePanel.add(devicePanelTop, BorderLayout.NORTH);

               final DamaskCanvas canvas =
                  canvasGroup.getCanvas(aDeviceType);
               canvas.setZoomCenteredAtUpperLeft(true);
               canvas.setModeByName(DamaskCanvas.HAND_MODE);
               
               final PScrollPane scrollPane = new PScrollPane(canvas);
               scrollPane.setMinimumSize(new Dimension(800, 800));
               devicePanel.add(scrollPane, BorderLayout.CENTER);
               
               dragSource.createDefaultDragGestureRecognizer(
                  scrollPane,
                  DnDConstants.ACTION_COPY_OR_MOVE,
                  dgListener);

               devicePanel.setBorder(new EmptyBorder(0, 0,
                  INTERNAL_PADDING, 0));

               
               // Add slider
               final JToolBar sliderBar = new JToolBar();
               sliderBar.setFloatable(false);
               sliderBar.setLayout(new BorderLayout());
               final JSlider slider =
                  new JSlider(
                     JSlider.VERTICAL,
                     DamaskCanvas.SITEMAP,
                     DamaskCanvas.BELOW_DETAIL,
                     7);
               slider.setInverted(true);
               sliderBar.add(slider, BorderLayout.CENTER);
               slider.setModel(canvas.getSliderModel());
               if (aDeviceType != DeviceType.SMARTPHONE) {
                  slider.setValue(3);
               }

               final JButton zoomOutButton =
                  new JButton(getRadarIcon("zoom_out.png"));
               zoomOutButton.addActionListener(new ActionListener() {
                  public void actionPerformed(ActionEvent e) {
                     slider.setValue(slider.getValue() - 1);
                  }
               });
               sliderBar.add(zoomOutButton, BorderLayout.NORTH);

               final JButton zoomInButton =
                  new JButton(getRadarIcon("zoom_in.png"));
               zoomInButton.addActionListener(new ActionListener() {
                  public void actionPerformed(ActionEvent e) {
                     slider.setValue(slider.getValue() + 1);
                  }
               });
               sliderBar.add(zoomInButton, BorderLayout.SOUTH);
               devicePanel.add(sliderBar, BorderLayout.WEST);

               devicePanel.setMinimumSize(new Dimension(800, 400));
               
               add(devicePanel);
               final JLabel spacer = new JLabel("    ");
               spacer.setBackground(Color.WHITE);
               add(spacer);
            }
         }
         setMinimumSize(new Dimension(800, 800));
         setPreferredSize(new Dimension(800, 1400));
         setMaximumSize(new Dimension(800, 1400));
         
         setBorder(new EmptyBorder(INTERNAL_PADDING, INTERNAL_PADDING,
               INTERNAL_PADDING, INTERNAL_PADDING));
      }

      /**
       * Gets an image for the radar view. 
       */
      protected ImageIcon getRadarIcon(final String fileName) {
         final Image image =
            Toolkit.getDefaultToolkit().createImage(
               DamaskApp.class.getResource("images/radar/" + fileName));
         return new ImageIcon(image);
      }

      private class DragGestureHandler implements DragGestureListener {
         public void dragGestureRecognized(DragGestureEvent dge) {
            try {
               final Transferable transferable = new DmkSolutionTransferable(
                     solution);
               dge.startDrag(DragSource.DefaultCopyNoDrop,
                             transferable,
                             dsListener);
            }
            catch (InvalidDnDOperationException idoe) {
               DamaskAppExceptionHandler.log(idoe);
            }
         }
      }

      private class DragSourceHandler implements DragSourceListener {
         public void dragEnter(DragSourceDragEvent dsde) {
            final DragSourceContext context = dsde.getDragSourceContext();
            final int myAction = dsde.getDropAction();
            if (myAction != 0) {
               context.setCursor(DragSource.DefaultCopyDrop);
            }
            else {
               context.setCursor(DragSource.DefaultCopyNoDrop);
            }
         }

         public void dragOver(DragSourceDragEvent dsde) {
         }

         public void dropActionChanged(DragSourceDragEvent dsde) {
         }

         public void dragDropEnd(DragSourceDropEvent dsde) {
         }

         public void dragExit(DragSourceEvent dse) {
         }
      }
   }

   private class DmkSolutionTransferable implements Transferable,
         ClipboardOwner {

      private DataFlavor[] flavors = { PATTERN_SOLUTION_FLAVOR };

      private final PatternSolution solution;

      public DmkSolutionTransferable(final PatternSolution solution) {
         this.solution = solution;
      }

      // Overrides method in Transferable.
      public DataFlavor[] getTransferDataFlavors() {
         return flavors;
      }

      // Overrides method in Transferable.
      public boolean isDataFlavorSupported(final DataFlavor flavor) {
         for (int i = 0, n = flavors.length; i < n; i++) {
            if (flavors[i].match(flavor)) {
               return true;
            }
         }
         return false;
      }

      // Overrides method in Transferable.
      public Object getTransferData(final DataFlavor flavor)
            throws UnsupportedFlavorException {

         if (PATTERN_SOLUTION_FLAVOR.match(flavor)) {
            return solution;
         }
         else {
            throw new UnsupportedFlavorException(flavor);
         }
      }

      // Overrides method in ClipboardOwner.
      public void lostOwnership(Clipboard clipboard, Transferable contents) {
      }
   }
}