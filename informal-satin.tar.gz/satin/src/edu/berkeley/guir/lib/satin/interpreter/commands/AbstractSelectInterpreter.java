//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter.commands;

import java.util.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.stroke.*;

/**
 * Abstract base class for selection interpreters.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jun 27 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public abstract class AbstractSelectInterpreter 
   extends InterpreterImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================
   
   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   protected boolean flagShallow     = true;
   protected boolean flagMultiSelect = false;  // false => can select one item
                                               // true  => can select multiple

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public AbstractSelectInterpreter() {
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      //// 1. Set up name and events handled.
      setAcceptMiddleButton(false);
      setAcceptRightButton(false);
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR / MODIFIER METHODS   =======================================

   /**
    * Select deeply, ie objects deep in the scenegraph tree.
    */
   public void setDeep() {
      flagShallow = false;
   } // of setDeep



   /**
    * Select shallowly, ie objects shallow in the scenegraph tree.
    */
   public void setShallow() {
      flagShallow = true;
   } // of setShallow

   //-----------------------------------------------------------------

   /**
    * Set whether multiple objects can be selected. By default is single item
    * select.
    */
   public void setMultiSelect(boolean flag) {
      flagMultiSelect = flag;
   } // of method


   public boolean isMultiSelect() {
      return (flagMultiSelect);
   } // of method

   //===   ACCESSOR / MODIFIER METHODS   =======================================
   //===========================================================================



   //===========================================================================
   //===   SELECT METHODS   ====================================================

   /**
    * Get the possible Graphical Objects that the stroke 
    * could have intersected. Just calls the other getCandidates() method.
    */
   protected GraphicalObjectCollection getCandidates(SingleStrokeEvent evt) {
      return getCandidates(evt.getStroke());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the possible Graphical Objects that the stroke 
    * could have intersected. You probably don't want to override this method.
    */
   protected GraphicalObjectCollection getCandidates(TimedStroke stk) {
      GraphicalObject           gob = getAttachedGraphicalObject();
      GraphicalObjectCollection out = new GraphicalObjectCollectionImpl();

      //// 1. Select or deselect the tapped Graphical Object.
      if (gob instanceof GraphicalObjectGroup) {
         GraphicalObjectGroup gobgrp = (GraphicalObjectGroup) gob;

         //// 1.1. Get shallow.
         if (flagShallow == true) {
            out = gobgrp.getGraphicalObjects(COORD_ABS,
                            stk.getStartPoint2D(COORD_ABS), 
                            ALL, 
                            SHALLOW, 
                            CONTAINS, 
                            DEFAULT_SELECT_THRESHOLD, 
                            null);
         }
         //// 1.2. Get deep.
         else {
            out = gobgrp.getGraphicalObjects(COORD_ABS, 
                            stk.getStartPoint2D(COORD_ABS), 
                            ALL, 
                            DEEP, 
                            CONTAINS, 
                            DEFAULT_SELECT_THRESHOLD, 
                            null);
         }
      }

      //// 2. Filter out things that cannot be selected.
      GraphicalObjectCollection gobcol;
      Iterator                  it;

      gobcol = (GraphicalObjectCollection) out.clone();
      it     = gobcol.getForwardIterator();
      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();
         if (gob.isSelectable() == false) {
            out.remove(gob);
         }
      }

      //// 3. Return the candidates.
      return (out);
   } // of method
   
   //-----------------------------------------------------------------

   /**
    * Given a collection of possible selection candidates, choose the 
    * "right" Graphical Object. By default, chooses the topmost object in 
    * the collection. Override this method to change the selection policy.
    */
   protected GraphicalObject 
   getSelectCandidate(GraphicalObjectCollection gobcol) {
      if (gobcol.numElements() > 0) {
         return GraphicalObjectLib.getTopmostGraphicalObject(gobcol);
      }
      return (null);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Select or deselect the specified Graphical Object.
    *
    * @return Returns whether the object was selected (true) or 
    *         deselected or was null (false).
    */
   protected boolean toggleSelectGraphicalObject(GraphicalObject selgob) {
      boolean flagReturn = false;

      if (selgob != null) {
         if (cmdsubsys.isSelected(selgob)) {
            cmdsubsys.removeSelected(selgob);
         }
         else {
            if (flagMultiSelect == false) {
               cmdsubsys.clearSelected();
            }
            cmdsubsys.addSelected(selgob);
            flagReturn = true;
         }
         selgob.damage(DAMAGE_LATER);
      }

      return (flagReturn);
   } // of method

   //===   SELECT METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
