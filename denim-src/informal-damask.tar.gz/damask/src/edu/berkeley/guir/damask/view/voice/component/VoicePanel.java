package edu.berkeley.guir.damask.view.voice.component;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.event.GroupEvent;
import edu.berkeley.guir.damask.event.GroupListener;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.voice.dialog.Conversation;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * A group that contains other control views and groups.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  11-10-2003 James Lin
 *                               Created Group.
 *                    01-28-2004 James Lin
 *                               Renamed to ComponentGroupView.
 *                    05-31-2004 James Lin
 *                               Renamed to Panel.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 11-10-2003
 */
public class VoicePanel extends VoiceComponent {
   public static final int INITIAL_SIZE = 40;
   
   private static final Color BOUNDARY_COLOR = Color.DARK_GRAY;
   private static final Color BACKGROUND_COLOR = DamaskAppUtils.NO_COLOR;
   private static final Color TEXT_COLOR = Color.DARK_GRAY;
   private static final float TEXT_SIZE = 36.0f;
   private static final Stroke BOUNDARY_STROKE =
      new BasicStroke(
         1,
         BasicStroke.CAP_BUTT,
         BasicStroke.JOIN_MITER,
         1,
         new float[] { 2, 2 },
         0);

   private final GroupListener groupHandler = new GroupHandler();
   private boolean inRunMode = false;

   /**
    * Constructs a panel and associates it with the specified component group. 
    */
   public VoicePanel(final ComponentGroup group) {
      super(group);
      setPaint(BACKGROUND_COLOR);
      setStrokePaint(BOUNDARY_COLOR);
      setStroke(BOUNDARY_STROKE);
      group.addGroupListener(groupHandler);
   }
   
   
   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      final PageRegion region = ((Conversation)getParent()).getRegionModel();
      
      final ComponentGroup group = ((ComponentGroup)getModel());
      final Rectangle2D bounds = group.getBoundsInPageRegion(region);
      if (bounds != null) {
         setBounds(bounds);
         setPathTo(bounds);
      }
      setTransform(group.getTransformInPageRegion(region));
   }


   /**
    * Returns a representation of what a text box looks like by default.
    */
   public static PNode createTempView() {
      final PPath border = new PPath(new Rectangle2D.Double(0, 0, 1, 1));
      border.setStrokePaint(BOUNDARY_COLOR);
      border.setStroke(BOUNDARY_STROKE);
      return border;
   }


   // Overrides method in parent class.
   public Object getEditableContents() {
      return null;
   }


   // Overrides method in parent class.
   public boolean isInRunMode() {
      return inRunMode;
   }


   // Overrides method in parent class.
   public void setInRunMode(boolean flag) {
      inRunMode = flag;
      if (inRunMode) {
         setStrokePaint(null);
         setStroke(null);
      }
      else {
         setStrokePaint(BOUNDARY_COLOR);
         setStroke(BOUNDARY_STROKE);
      }
   }


   /**
    * Handles events from the model object. 
    */
   private class GroupHandler implements GroupListener {
      public void elementBoundsUpdated(GroupEvent e) {
         if (e.getPageRegion() == getForm().getModel()) {
            setBounds(
               e.getComponentGroup().getBoundsInPageRegion(e.getPageRegion()));
         }
      }

      public void elementTransformUpdated(GroupEvent e) {
         if (e.getPageRegion() == getForm().getModel()) {
            final AffineTransform newTransform =
               e.getComponentGroup().getTransformInPageRegion(
                  e.getPageRegion());
            final AffineTransform oldTransform = getTransform();
            if (!oldTransform.equals(newTransform)) {
               setTransform(newTransform);
            }
         }
      }
   }
}
