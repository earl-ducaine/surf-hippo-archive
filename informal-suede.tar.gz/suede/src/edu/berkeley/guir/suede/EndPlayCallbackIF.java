package edu.berkeley.guir.suede;

public interface EndPlayCallbackIF {
  
  public void callmeWhenDonePlaying(/*CardSound cardSound*/);
  
  
}