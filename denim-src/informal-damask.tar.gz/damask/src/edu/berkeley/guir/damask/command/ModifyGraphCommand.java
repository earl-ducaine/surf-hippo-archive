package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.lib.satin.command.Command;

/** 
 * A marker interface signifying that this command modifies the interaction
 * graph.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-20-2003 James Lin
 *                               Created ModifyingCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-20-2003
 */
public interface ModifyGraphCommand extends Command {
}
