//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter;

import java.util.*;
import edu.berkeley.guir.lib.util.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;

/**
 * Basically a collection of Interpreters, used for delegation purposes by
 * a GraphicalObject. A listener class for Interpreters that manipulates and 
 * handles the management of Interpreters. This is the class that will contain 
 * the rules for how multiple Interpreters are handled.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 22 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class DefaultMultiInterpreterImpl 
   extends    InterpreterImpl
   implements MultiInterpreter {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   final static long serialVersionUID = -8406563203951453814L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   //// Our lists of Interpreters
   LinkedList listInterpreters = new LinkedList();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Does nothing.
    */
   public DefaultMultiInterpreterImpl() {
      commonInitializations();
   } // of default constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("DefaultMultiInterpreterImpl");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Attaches the MultiInterpreter and every contained interpreter to
    * the given graphical object.
    *
    * @param gob is the GraphicalObject to attach.
    */
   public GraphicalObject setAttachedGraphicalObject(GraphicalObject gob) {
      super.setAttachedGraphicalObject(gob);

      Iterator    it = this.iterator();
      Interpreter intrp;
      while (it.hasNext()) {
         intrp = (Interpreter) it.next();
         intrp.setAttachedGraphicalObject(gob);
      }
      return (gob);
   } // of setAttachedGraphicalObject

   //-----------------------------------------------------------------

   public Interpreter add(Interpreter intrp) {
      listInterpreters.add(intrp);
      if (getAttachedGraphicalObject() != null) {
         intrp.setAttachedGraphicalObject(getAttachedGraphicalObject());
      }
      return (intrp);
   } // of add

   //-----------------------------------------------------------------

   public Interpreter addToFront(Interpreter intrp) {
      listInterpreters.addFirst(intrp);
      if (getAttachedGraphicalObject() != null) {
         intrp.setAttachedGraphicalObject(getAttachedGraphicalObject());
      }
      return (intrp);
   } // of addToFront

   //-----------------------------------------------------------------

   public Interpreter remove(Interpreter intrp) {
      listInterpreters.remove(intrp);
      return (intrp);
   } // of remove

   //-----------------------------------------------------------------

   public Iterator iterator() {
      return (listInterpreters.iterator());
   } // of get

   //-----------------------------------------------------------------

   public Interpreter get(int index) {
      if (index < 0 || index >= size()) {
         return (null);
      }
      return ((Interpreter) listInterpreters.get(index));
   } // of method

   //-----------------------------------------------------------------

   public boolean contains(Interpreter intrp) {
      return (listInterpreters.contains(intrp));
   } // of method

   //-----------------------------------------------------------------

   public int size() {
      return (listInterpreters.size());
   } // of method

   //-----------------------------------------------------------------

   public void clear() {
      listInterpreters.clear();
   } // of clear

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   INTERPRETER METHODS   ===============================================

   /**
    * Called when a stroke is started. Iterates through the list of contained
    * interpreters, firing the new stroke event, until one of the contained
    * interpreters consumes the event.
    */
   public void handleNewStroke(NewStrokeEvent evt) {
      Iterator    it;
      Interpreter intrp;

      //// 0. Check if enabled first.
      if (isEnabled() == false) {
         return;
      }

      //// 1. Multicast the event to each Interpreter.
      it = this.iterator(); 
      while (it.hasNext() && evt.isConsumed() == false) {
         intrp = (Interpreter) it.next();
         if (intrp.isEnabled() == true && intrp.isEventAccepted(evt) == true) {
            intrp.handleNewStroke(evt);
         }
      }

   } // of handleNewStroke

   //-----------------------------------------------------------------

   /**
    * Called when a stroke is updated. Iterates through the list of contained
    * interpreters, firing the update stroke event, until one of the contained
    * interpreters consumes the event.
    */
   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      Iterator                     it;
      Interpreter intrp;

      //// 0. Check if enabled first.
      if (isEnabled() == false) {
         return;
      }

      //// 1. Multicast the event to each Interpreter.
      it = this.iterator(); 
      while (it.hasNext() && evt.isConsumed() == false) {
         intrp = (Interpreter) it.next();
         if (intrp.isEnabled() == true && intrp.isEventAccepted(evt) == true) {
            intrp.handleUpdateStroke(evt);
         }
      }

   } // of handleUpdateStroke

   //-----------------------------------------------------------------

   /**
    * Called when a stroke is finished. Iterates through the list of contained
    * interpreters, firing the single stroke event, until one of the contained
    * interpreters consumes the event.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      Iterator    it;
      Interpreter intrp;

      //// 0. Check if enabled first.
      if (isEnabled() == false) {
         return;
      }

      //// 1. Multicast the event to each Interpreter.
      it = this.iterator(); 
      while (it.hasNext() && evt.isConsumed() == false) {
         intrp = (Interpreter) it.next();
         if (intrp.isEnabled() == true && intrp.isEventAccepted(evt) == true) {
            intrp.handleSingleStroke(evt);
         }
      }

   } // of handleSingleStroke

   //===   INTERPRETER METHODS   ===============================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   /**
    * Returns a string representation of this MultiInterpreter.
    */
   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 0. Superclass info.
      Iterator     it     = this.iterator();
      strbuf.append(super.toString());

      //// 1. Initial string.
      strbuf.append("\nContained Interpreters:\n");

      //// 2. List of all views.
      while (it.hasNext()) {
         strbuf.append(StringLib.indent(it.next().toString(), 3));
         if (it.hasNext()) {
            strbuf.append("\n\n");
         }
      }

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Clones this MultiInterpreter.
    */
   public Object clone() {
      return (clone(new DefaultMultiInterpreterImpl()));
   } // of method

   //-----------------------------------------------------------------

   protected DefaultMultiInterpreterImpl clone(DefaultMultiInterpreterImpl im) {
      //// 1. Clone chain.
      super.clone(im);

      //// 2.1. Do clone work.
      ////      Deep clone.
      Iterator it = this.listInterpreters.iterator();
      Interpreter intrpTmp;
      while (it.hasNext()) {
         intrpTmp = (Interpreter) it.next();
         im.listInterpreters.add(intrpTmp.clone());
      } 

      //// 2.2. Reset the attached Graphical Object.
      im.setAttachedGraphicalObject(this.getAttachedGraphicalObject());

      //// 3. Return.
      return (im);
   } // of method

   //===   CLONE METHODS   =====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
