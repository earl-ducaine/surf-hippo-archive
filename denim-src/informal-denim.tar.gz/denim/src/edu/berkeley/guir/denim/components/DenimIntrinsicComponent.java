package edu.berkeley.guir.denim.components;

import java.awt.Color;
import java.awt.Polygon;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;
import java.util.StringTokenizer;

import edu.berkeley.guir.denim.ScribbledText;
import edu.berkeley.guir.lib.satin.objects.Style;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

/**
 * A "intrinsic" (built-in) Denim component. Unlike custom components, an
 * intrinsic component can consist of objects other than GraphicalObjects,
 * such as Swing widgets.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-05-1999  James Lin
 *                                Created DenimIntrinsicComponent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 08-05-1999
 */

public abstract class DenimIntrinsicComponent
   extends    DenimComponent
   implements Serializable {

   // event types
   public static final String LEFT_CLICK   = "Left Click";
   public static final String RIGHT_CLICK  = "Right Click";
   public static final String LEFT_2CLICK  = "Left Double Click";
   public static final String RIGHT_2CLICK = "Right Double Click";
   public static final String MOUSE_ENTER  = "Mouse Enter";
   public static final String MOUSE_EXIT   = "Mouse Exit";
   public static final String ANIMATION    = "Animation";
   public static final String TIMER        = "Timer";

   private static final int SQUIGGLE_WIGGLE_WIDTH = 4;
   private static final int SQUIGGLE_GAP_WIDTH = 6;
   private static final int SQUIGGLE_HEIGHT = 6;

   /**
    * Sets up an intrinsic component.
    */
   DenimIntrinsicComponent() {
      super();

      // define the allowed events for intrinsic components
      supportedEvents.add(LEFT_CLICK);
      supportedEvents.add(RIGHT_CLICK);
      supportedEvents.add(LEFT_2CLICK);
      supportedEvents.add(RIGHT_2CLICK);
      supportedEvents.add(MOUSE_ENTER);
      supportedEvents.add(MOUSE_EXIT);
      //supportedEvents.add(ANIMATION);
      supportedEvents.add(TIMER);
   }

   /**
    * Returns whether the two given event types are equal.
    */
   public static boolean compareEventTypes(String evt1, String evt2) {
      if (evt1 == evt2) {
         return true;
      }
      else {
         // Handle the special case of the Timer event (ignore time suffix)
         return (getTimerEventSeconds(evt2) != -1);
      }
   }

   /**
    * Returns, for a timer event, the number of seconds for that
    * event.
    */
   public static int getTimerEventSeconds(String evt) {
      int result = -1;

      StringTokenizer st = new StringTokenizer(evt, ":");
      if (st.countTokens() == 2) {
         try {
            String token = st.nextToken();
            if (token.equals("Timer")) {
               token = st.nextToken();
               result = Integer.parseInt(token);
            }
         }
         catch (NumberFormatException e) {
         }
      }

      return result;
   }

   /**
    * Returns a squiggle of a moderate length. Useful for intrinsic components
    * that are stamped instead of sketched.
    */
   static ScribbledText createSquiggle() {
      return createSquiggle(13);
   }

   /**
    * Returns a squiggle. Useful for intrinsic components that are
    * stamped instead of sketched.
    * 
    * @param numWiggles how many "wiggles" (up and down strokes) the
    *                   squiggle will have
    */
   static ScribbledText createSquiggle(int numWiggles) {
      ScribbledText squiggle =
         new ScribbledText(
            new Rectangle2D.Double(0, 0,
                                   SQUIGGLE_WIGGLE_WIDTH * numWiggles,
                                   SQUIGGLE_HEIGHT));
      squiggle.add(createSquiggleStroke(numWiggles));
      return squiggle;
   }

   /**
    * Returns a squiggle as a stroke.
    * 
    * @param numWiggles how many "wiggles" (up and down strokes) the
    *                   squiggle will have
    */
   private static TimedStroke createSquiggleStroke(int numWiggles) {
      
      TimedStroke squiggle = new TimedStroke();
      int y = SQUIGGLE_HEIGHT;
      
      for (int x = 0; x <= numWiggles; x++) {
         squiggle.addPoint(x * SQUIGGLE_WIGGLE_WIDTH, y);
         if (y == 0) {
            y = SQUIGGLE_HEIGHT;
         }
         else {
            y = 0;
         }
      }
      squiggle.doneAddingPoints();
      
      Style style = squiggle.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setLineWidth(1.0f);
      squiggle.setStyle(style);
      
      return squiggle;
   }
   
   /**
    *  shelley
    * @param myDigit -- a single digit we want to draw 
    * 
    * @return TimedStroke -- returns a single digit number as
    * 								a stroke
    */
   public static TimedStroke createDenimDigit(int myDigit) {
      
      TimedStroke digit;
      
      switch (myDigit) {
//         case 0:
//            int[] xs0 = {0, 4, 4, 0, 0};
//            int[] ys0 = {0, 0, 6, 6, 0};
//            digit = new TimedStroke(new Polygon(xs0, ys0, xs0.length));
//            break;
            
         case 1:
            int[] xs1 = {0, 0};
            int[] ys1 = {0, 6};
            digit = new TimedStroke(new Polygon(xs1, ys1, xs1.length));
            break;
         
         case 2:
            int[] xs2 = {0, 4, 4, 0, 0, 4};
            int[] ys2 = {0, 0, 3, 3, 6, 6};
            digit = new TimedStroke(new Polygon(xs2, ys2, xs2.length));         
            break;
         
         case 3:
            int[] xs3 = {0,4,4,0,4,4,0};
            int[] ys3 = {0,0,3,3,3,6,6};
            digit = new TimedStroke(new Polygon(xs3, ys3, xs3.length));
            break;
         
         case 4:
            int[] xs4 = {0,0,4,4,4};
            int[] ys4 = {0,3,3,0,6};
            digit = new TimedStroke(new Polygon(xs4, ys4, xs4.length));
            break;
            
         case 5:   
            int[] xs5 = {4,0,0,4,4,0};
            int[] ys5 = {0,0,3,3,6,6};
            digit = new TimedStroke(new Polygon(xs5, ys5, xs5.length));
            break;
         
         case 6:
            int[] xs6 = {4,0,0,4,4,0};
            int[] ys6 = {0,0,6,6,3,3};
            digit = new TimedStroke(new Polygon(xs6, ys6, xs6.length));
            break;
         
         case 7:   
            int[] xs7 = {0,4,4};
            int[] ys7 = {0,0,6};
            digit = new TimedStroke(new Polygon(xs7, ys7, xs7.length));
            break;
         
         case 8:   
            int[] xs8 = {0,0,4,4,0,0,4,4};
            int[] ys8 = {3,0,0,3,3,6,6,3};
            digit = new TimedStroke(new Polygon(xs8, ys8, xs8.length));
            break;
            
         case 9:
            int[] xs9 = {4,4,0,0,4};
            int[] ys9 = {6,0,0,3,3};
            digit = new TimedStroke(new Polygon(xs9, ys9, xs9.length));
            break;   
            
//         case 10:
//            int[] xs10 = {0, 0, 2, 6, 6, 2, 2};
//            int[] ys10 = {6, 0, 0, 0, 6, 6, 0};
//            digit = new TimedStroke(new Polygon(xs10, ys10, xs10.length));
//            break;
           
         default:
            digit = new TimedStroke();
            break;
      }
      
      return digit;
      
   }

   /**
    * Returns a scribble which contains squiggles with the specified lengths.
    */
   static ScribbledText createSquiggles(int[] lengths) {
      int numSquiggles = lengths.length;
      int totalWidth = 0;
      for (int i = 0; i < numSquiggles; i++) {
         totalWidth += lengths[i] * SQUIGGLE_WIGGLE_WIDTH + SQUIGGLE_GAP_WIDTH;
      }      
      
      ScribbledText squiggles =
         new ScribbledText(
            new Rectangle2D.Double(0, 0, totalWidth, SQUIGGLE_HEIGHT));
            
      Style style = squiggles.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      squiggles.setStyle(style);

      int x = 0;
      for (int i = 0; i < lengths.length; i++) {
         TimedStroke squiggle = createSquiggleStroke(lengths[i]);
         squiggles.add(squiggle);
         squiggle.moveTo(COORD_REL, x, 0);
         x += SQUIGGLE_WIGGLE_WIDTH * lengths[i] + SQUIGGLE_GAP_WIDTH;
      }
      return squiggles;
   }

   /*
   public Storyboard getStoryboard() {
      return null;
   }
   */

   /**
    * Returns the fact that this is an intrinsic component.
    */
   public final boolean isIntrinsic() {
      return true;
   }
}

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
