//// See bottom of file for software license
package edu.berkeley.guir.lib.util;

/**
 * Utilities for manipulating day of the week.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 11 2004
 */
public class DayOfWeekLib {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    public static final int SUNDAY    = 0;
    public static final int MONDAY    = 1;
    public static final int TUESDAY   = 2;
    public static final int WEDNESDAY = 3;
    public static final int THURSDAY  = 4;
    public static final int FRIDAY    = 5;
    public static final int SATURDAY  = 6;

    //----------------------------------------------------------------

    private static final String[] DAYS_FULL = new String[] {
        "sunday", "monday", "tuesday", "wednesday", 
        "thursday", "friday", "saturday"
    };

    private static final String[] DAYS_SHORT = new String[] {
        "sun", "mon", "tue", "wed", "thu", "fri", "sat"
    };

    //----------------------------------------------------------------

    /**
     * Monday through Friday.
     * Warning: do not modify this array, or there may be unexpected results.
     */
    public static final String[] ARRAY_WEEKDAYS = new String[] {
        "mon", "tue", "wed", "thu", "fri"
    };

    /**
     * Saturday and Sunday.
     * Warning: do not modify this array, or there may be unexpected results.
     */
    public static final String[] ARRAY_WEEKEND = new String[] {
        "sun", "sat"
    };

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    /**
     * Convert the int-array into a String-array.
     * For example, {0} would be {"Sunday"}, while {0,1,2} would be
     * {"Sunday","Monday","Tuesday"}.
     * @param flagUseFullDay is true for full day names, like "Monday", or
     *                       false for short day names, like "Mon"
     */
    public static String[] asStringArray(int[] arrDays, boolean flagUseFullDay){
        String[] strArr = new String[arrDays.length];
        for (int i = 0; i < arrDays.length; i++) {
            if (flagUseFullDay == true) {
                strArr[i] = toFullDay(arrDays[i]);
            }
            else {
                strArr[i] = toShortDay(arrDays[i]);
            }
        }
        return (strArr);
    } // of method

    //--------------------

    /**
     * Convert a String-array into an int-array.
     * For example, {"Sunday"} becomes {1}, and
     * {"Sunday","Monday","Tuesday"} becomes {0,1,2}.
     */
    public static int[] asIntArray(String[] arrDays) {
        int[] arr = new int[arrDays.length];
        for (int i = 0; i < arrDays.length; i++) {
            arr[i] = fromString(arrDays[i]);
        }
        return (arr);
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert the array into a comma-separated String.
     * For example, [0] would be "Sunday", while [0,1,2] would be
     * "Sunday,Monday,Tuesday"
     *
     * @param arrDays is a sorted array of ints, with each int representing
     *                a day.
     * @param flagUseFullDay is true for full day names, like "Monday", or
     *                       false for short day names, like "Mon"
     */
    public static String toCSVDays(int[] arrDays, boolean flagUseFullDay) {
        StringBuffer strbuf = new StringBuffer();
        for (int i = 0; i < arrDays.length; i++) {
            if (i != 0) {
                strbuf.append(",");
            }

            if (flagUseFullDay == true) {
                strbuf.append(toFullDay(arrDays[i]));
            }
            else {
                strbuf.append(toShortDay(arrDays[i]));
            }
        }
        return (strbuf.toString());
    } // of method

    //--------------------

    /**
     * Convert what is selected into a String.
     * For example, [0] would be "Sunday", while [0,1,2] would be
     * "Sunday through Tuesday"
     *
     * @param arrDays is a sorted array of ints, with each int representing
     *                a day.
     * @param strThru is what separates consecutive days. For example, "-"
     *                yields "Sun-Tue" while " thru " yields "Sun thru Tue"
     * @param flagUseFullDay is true for full day names, like "Monday", or
     *                       false for short day names, like "Mon"
     */
    public static String toConsecutiveDays(int[]   arrDays, 
                                           String  strThru,
                                           boolean flagUseFullDay) {

        //// 1. If only one day, then just return it.
        if (arrDays.length == 1) {
            if (flagUseFullDay == true) {
                return (toFullDay(arrDays[0]));
            }
            else {
                return (toShortDay(arrDays[0]));
            }
        }

        //// 2. Go thru consecutive Strings.
        StringBuffer strbuf = new StringBuffer();
        int          start  = 0;
        int          end    = arrDays.length;
        String       strStart;
        String       strEnd;

        while (start < arrDays.length) {
            if (start != 0) {
                strbuf.append(",");
            }
            end    = getIndexOfConsecutiveEnd(arrDays, start);
            strEnd = "";
            if (flagUseFullDay == true) {
                strStart = toFullDay(arrDays[start]);
                if (start + 1 != end) {
                    strEnd = strThru + toFullDay(arrDays[end - 1]);
                }
            }
            else {
                strStart = toShortDay(arrDays[start]);
                if (start + 1 != end) {
                    strEnd = strThru + toShortDay(arrDays[end - 1]);
                }
            }

            strbuf.append(strStart + strEnd);
            start = end;
        }

        //// 3. Return.
        return (strbuf.toString());
    } // of method

    //----------------------------------------------------------------

    /**
     * Figure out the end of a subset of consecutive values.
     * For example, given the array <CODE>[0, 1, 2, 4, 6, 7]</CODE>,
     * then:
     * <PRE>
     *    getIndexOfConsecutiveEnd(arr, 0);   // returns 3, 0-2 consecutive
     *    getIndexOfConsecutiveEnd(arr, 3);   // returns 4, 4   consecutive
     *    getIndexOfConsecutiveEnd(arr, 4);   // returns 7, 6-7 consecutive
     * </PRE>
     */
    private static int getIndexOfConsecutiveEnd(int[] arr, int start) {
        int valAA = arr[start];
        int valBB;

        for (int i = start + 1; i < arr.length; i++) {
            valBB = arr[i];
            if ((valAA + 1) == valBB) {
                valAA = valBB;
                continue;
            }
            else {
                return (i);
            }
        }
        return (arr.length);
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert day of week value into String.
     * <PRE>
     *    toShortDay(DayOfWeekSelector.SUNDAY);   // "Sun"
     *    toShortDay(1);                          // "Mon"
     * </PRE>
     * @throws IllegalArgumentException if unknown day
     */
    public static String toShortDay(int val) {
        switch (val) {
            case SUNDAY:     return ("Sun");
            case MONDAY:     return ("Mon");
            case TUESDAY:    return ("Tue");
            case WEDNESDAY:  return ("Wed");
            case THURSDAY:   return ("Thu");
            case FRIDAY:     return ("Fri");
            case SATURDAY:   return ("Sat");
            default:
                throw new IllegalArgumentException("unknown value: " + val);
        }
    } // of method

    //--------------------

    /**
     * Convert day of week value into String.
     * <PRE>
     *    toFullDay(DayOfWeekSelector.SUNDAY);   // "Sunday"
     *    toFullDay(1);                          // "Monday"
     * </PRE>
     * @throws IllegalArgumentException if unknown day
     */
    public static String toFullDay(int val) {
        switch (val) {
            case SUNDAY:     return ("Sunday");
            case MONDAY:     return ("Monday");
            case TUESDAY:    return ("Tuesday");
            case WEDNESDAY:  return ("Wednesday");
            case THURSDAY:   return ("Thursday");
            case FRIDAY:     return ("Friday");
            case SATURDAY:   return ("Saturday");
            default:
                throw new IllegalArgumentException("unknown value: " + val);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Convert String into an int, for example "Sunday" or "Sun" or "sun"
     * becomes 0, and "Monday" or "Mon" becomes 1.
     * @return 0-6 if a day of the week
     * @throws IllegalArgumentException if unknown day
     */
    public static int fromString(String str) {
        str = str.toLowerCase();
        for (int i = 0; i < DAYS_FULL.length; i++) {
            if (DAYS_FULL[i].equals(str)  == true ||
                DAYS_SHORT[i].equals(str) == true) {
                return (i);
            }
        }
        throw new IllegalArgumentException("unknown value: " + str);
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static void testDays(int[] arrDays) {
        System.out.println(toConsecutiveDays(arrDays, "-", true));

        String[] arr;

        arr = asStringArray(arrDays, true);
        System.out.println(StringLib.toString(arr));

        arr = asStringArray(arrDays, false);
        System.out.println(StringLib.toString(arr));

        System.out.println(new edu.berkeley.guir.lib.util.condition.DayOfWeekCondition(arr));

        System.out.println("----------------");
    } // of method

    //--------------------

    private static void runTestAAA() {
        testDays(new int[] { 0, 1, 2, 3, 4, 5, 6 });
        testDays(new int[] { 0, 2, 4, 6 });
        testDays(new int[] { 1, 2, 4, 5 });
        testDays(new int[] { 0 });
        testDays(new int[] { 0, 1 });
    } // of method

    //--------------------

    private static void runTestBBB() {
        System.out.println(fromString("Sunday"));
        System.out.println(fromString("Sun"));
        System.out.println(fromString("Fri"));
        System.out.println(fromString("Friday"));
        System.out.println(fromString("error"));
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) {
        runTestBBB();
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
