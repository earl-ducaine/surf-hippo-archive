package edu.berkeley.guir.damask.view.visual;

import java.awt.Cursor;

import edu.berkeley.guir.damask.view.DamaskAppMode;
import edu.umd.cs.piccolo.event.PInputEventListener;

/** 
 * An input mode that Damask can be in. This class associates a mode with a
 * set of input event handlers and mouse cursors.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-08-2004 James Lin
 *                               Created DamaskAppMode by converting
 *                               DamaskApp.EventMode.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-08-2004
 */
public class VisualMode extends DamaskAppMode {
   private final PInputEventListener pageHandler;
   private final Cursor pageCursor;
   private final Cursor controlCursor;

   /**
    * Constructs a mode.
    * 
    * @param name              the name of the mode
    * @param eventHandler      the handler of mouse events
    * @param backgroundCursor  the cursor that appears when the mouse is over
    *                           the canvas background
    * @param pageCursor        the cursor that appears when the mouse is over
    *                           a page
    * @param controlCursor     the cursor that appears when the mouse is over
    *                           a control
    */
   public VisualMode(
      final String name,
      final PInputEventListener eventHandler,
      final Cursor backgroundCursor,
      final Cursor pageCursor,
      final Cursor controlCursor) {

      this(
         name,
         eventHandler,
         eventHandler,
         backgroundCursor,
         pageCursor,
         controlCursor);
   }
   

   /**
    * Constructs a mode.
    * 
    * @param name              the name of the mode
    * @param backgroundHandler the handler of mouse events when the mouse is
    *                           over the canvas background
    * @param pageHandler       the handler of mouse events when the mouse is
    *                           over a page
    * @param backgroundCursor  the cursor that appears when the mouse is over
    *                           the canvas background
    * @param pageCursor        the cursor that appears when the mouse is over
    *                           a page
    * @param controlCursor     the cursor that appears when the mouse is over
    *                           a control
    */
   public VisualMode(
      final String name,
      final PInputEventListener backgroundHandler,
      final PInputEventListener pageHandler,
      final Cursor backgroundCursor,
      final Cursor pageCursor,
      final Cursor controlCursor) {

      super(name, backgroundHandler, backgroundCursor);
      this.pageHandler = pageHandler;
      this.pageCursor = pageCursor;
      if (controlCursor == null) {
         this.controlCursor = pageCursor;
      }
      else {
         this.controlCursor = controlCursor;
      }
   }
   
   /**
    * Returns the event listener to use when the mouse is over a page.
    */
   public PInputEventListener getPageHandler() {
      return pageHandler;
   }

   /**
    * Returns the cursor that appears when the mouse is over a page.
    */
   public Cursor getPageCursor() {
      return pageCursor;
   }

   /**
    * Returns the cursor that appears when the mouse is over a control.
    */
   public Cursor getControlCursor() {
      return controlCursor;
   }
   
   public String toString() {
      return "DamaskAppMode:" + getName();
   }
}
