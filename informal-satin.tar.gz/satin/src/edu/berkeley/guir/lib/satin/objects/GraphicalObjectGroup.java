//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import java.awt.*;
import java.awt.geom.*;

/**
 * A collection of Graphical Objects that is part of the interactor tree.
 *
 * <P>
 * Unlike a GraphicalObjectCollection, Graphical Objects will be modified when
 * added, making this Group the parent of the added Graphical Object, as well
 * as modifying the coordinates of the Graphical Object to be relative to the
 * Group boundaries.
 *
 * <P>
 * When a GraphicalObject is added to a group, it retains its relative
 * coordinates if the {@link #KEEP_REL_POS} constant is specified when
 * calling {@link #add(GraphicalObject,int)}. If the {@link #KEEP_ABS_POS} 
 * constant is specified when calling the same method, then the added 
 * GraphicalObject will retain its current absolute position.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Oct 09 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.1.0, Feb 26 2001, JL
 *               * Changed return type of getRelativeLayer() from String to int
 *               * Changed return type of getAbsoluteLayer() from String to
 *                 List of Integers
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3RC1
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public interface GraphicalObjectGroup
   extends GraphicalObject, 
           GraphicalObjectCollection {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   /**
    * When adding a GraphicalObject into this GraphicalObjectGroup, keep the
    * same <B>absolute position</B> the GraphicalObject currently has.
    * That is, once you add a GraphicalObject, it will still appear to be in
    * the same place it currently has on the screen. Another way to think about
    * it is that the GraphicalObejct's absolute position will remain the same
    * before and after adding.
    * <P>
    * See {@link GraphicalObjectImpl} for an explanation of the different
    * coordinate systems.
    */
   public static final int KEEP_ABS_POS = 5;

   /**
    * When adding a GraphicalObject into this GraphicalObjectGroup, keep the
    * same <B>relative position</B> the GraphicalObject currently has.
    * That is, the GraphicalObject's relative position will remain the same
    * before and after adding.
    * <P>
    * See {@link GraphicalObjectImpl} for an explanation of the different
    * coordinate systems.
    */
   public static final int KEEP_REL_POS = 6;

   /**
    * Which of the two policies above we use by default, if unspecified.
    */
   public static final int DEFAULT_POS_POLICY = KEEP_REL_POS;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   COLLECTION METHODS   ================================================

   /**
    * Add a GraphicalObject to the top of this group, specifying the
    * GraphicalObject's position at the same time.
    * 
    * @see   #addToFront(GraphicalObject, int)
    * @param gob is the GraphicalObject to add.
    * @param pos is the GraphicalObject's position, either
    *            {@link #KEEP_ABS_POS} or {@link #KEEP_REL_POS}.
    */
   public GraphicalObject add(GraphicalObject gob, int pos);

   //-----------------------------------------------------------------

   /**
    * Add a GraphicalObject to the bottom of this group, specifying the
    * GraphicalObject's position at the same time.
    *
    * @param gob is the GraphicalObject to add.
    * @param pos is the GraphicalObject's position, either
    *            {@link #KEEP_ABS_POS} or {@link #KEEP_REL_POS}.
    */
   public GraphicalObject addToBack(GraphicalObject gob, int pos);

   //-----------------------------------------------------------------

   /**
    * Add a GraphicalObject to the top of this group, specifying the
    * GraphicalObject's position at the same time.
    *
    * @param gob is the GraphicalObject to add.
    * @param pos is the GraphicalObject's position, either
    *            {@link #KEEP_ABS_POS} or {@link #KEEP_REL_POS}.
    */
   public GraphicalObject addToFront(GraphicalObject gob, int pos);

   //-----------------------------------------------------------------

   /**
    * Add a GraphicalObject to the specified layer of this group, 
    * specifying the GraphicalObject's position at the same time.
    *
    * @param index is the layer to add to. Lower numbers indicate the front
    *              (higher layers).
    * @param gob   is the GraphicalObject to add.
    * @param pos   is the GraphicalObject's position, either
    *              {@link #KEEP_ABS_POS} or {@link #KEEP_REL_POS}.
    */
   public GraphicalObject add(int index, GraphicalObject gob, int pos);

   //===   COLLECTION METHODS   ================================================
   //===========================================================================


   //===========================================================================
   //===   LAYER METHODS   =====================================================

   /**
    * Given a GraphicalObject, return what layer it is in relative to this 
    * Graphical Object Group.
    *
    * @param  gob is the contained Graphical Object to check out.
    * @return the relative layer, or a negative number if the specified
    *         Graphical Object is not contained by this group.
    * @see    GraphicalObject#getRelativeLayer()
    */
   public int getRelativeLayer(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Given a GraphicalObject, set what layer it is in relative to this 
    * Graphical Object Group.
    *
    * @param  gob   is the contained Graphical Object to move.
    * @param  layer is the layer to move to.
    * @see    GraphicalObject#setRelativeLayer(int)
    */
   public void setRelativeLayer(GraphicalObject gob, int layer);

   //-----------------------------------------------------------------

   /**
    * Given a GraphicalObject, return its absolute layer position.
    *
    * @param  gob is the contained Graphical Object to check out.
    * @return a List of Integers representing the absolute layer, or
    *         null if the specified Graphical Object is not contained
    *         by this group.
    * @see    GraphicalObject#getAbsoluteLayer()
    */
   public java.util.List getAbsoluteLayer(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Move the specified GraphicalObject up one layer in this
    * Graphical Object Group. Does nothing if the specified Graphical Object 
    * is not contained by this Graphical Object Group.
    * 
    * @param gob is the Graphical Object to move.
    * @see   GraphicalObject#bringUpALayer()
    */
   public void bringUpALayer(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Move the specified GraphicalObject up N layers in this Group. Tries
    * to move the GraphicalObject as many layers as possible. Does nothing
    * if the specified Graphical Object is not contained by this Graphical
    * Object Group.
    *
    * @param gob is the Graphical Object to move.
    * @param n   is the number of layers to move.
    * @see   GraphicalObject#bringUpNLayers(int)
    */
   public void bringUpNLayers(GraphicalObject gob, int n);

   //-----------------------------------------------------------------

   /**
    * Move the specified GraphicalObject down one layer in this
    * Graphical Object Group. Does nothing if the specified Graphical Object 
    * is not contained by this Graphical Object Group.
    * 
    * @param gob is the Graphical Object to move.
    * @see   GraphicalObject#bringDownALayer()
    */
   public void bringDownALayer(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Move the specified GraphicalObject down N layers in this Group. Tries
    * to move the GraphicalObject as many layers as possible. Does nothing
    * if the specified Graphical Object is not contained by this Graphical
    * Object Group.
    *
    * @param gob is the Graphical Object to move.
    * @param n   is the number of layers to move.
    * @see   GraphicalObject#bringDownNLayers(int)
    */
   public void bringDownNLayers(GraphicalObject gob, int n);

   //-----------------------------------------------------------------

   /**
    * Move the specified Graphical Object to the top layer of this
    * Graphical Object Group. Does nothing if the specified Graphical Object 
    * is not contained by this Graphical Object Group.
    * 
    * @param gob is the Graphical Object to move.
    * @see   GraphicalObject#bringToTopLayer()
    */
   public void bringToTopLayer(GraphicalObject gob);

   //-----------------------------------------------------------------

   /**
    * Move the specified Graphical Object to the bottom layer of this
    * Graphical Object Group. Does nothing if the specified Graphical Object 
    * is not contained by this Graphical Object Group.
    * 
    * @param gob is the Graphical Object to move.
    * @see   GraphicalObject#bringToBottomLayer()
    */
   public void bringToBottomLayer(GraphicalObject gob);

   //===   LAYER METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   GROUP MODIFIER METHODS   ============================================

   /**
    * Remove from this Group all of the GraphicalObjects in the collection.
    */
   public void removeAll(GraphicalObjectCollection gobcol);

   //===   GROUP MODIFIER METHODS   ============================================
   //===========================================================================



   //===========================================================================
   //===   GROUP QUERY METHODS   ===============================================

   /**
    * Get whether this group allows 
    * {@link #getGraphicalObjects(int,Point2D,int,int,int,double,GraphicalObjectCollection)}
    * with depth set {@link SatinConstants#DEEP} to query this group's children.
    */
   public boolean getAllowDeepGet();
   
   /**
    * Set whether this group allows 
    * {@link #getGraphicalObjects(int,Point2D,int,int,int,double,GraphicalObjectCollection)}
    * with depth set {@link SatinConstants#DEEP} to query this group's children.
    */
   public void setAllowDeepGet(boolean flag);
   
   /**
    * Get all Graphical Objects subject to the specified parameters.
    * This version is for optimization or fine-tuning purposes.
    *
    * <P>
    * Really big methods like this one are usually a warning sign, but I really
    * don't see any alternatives.
    *
    * @param cdsys   is the coordinate system.
    * @param pt      is the point to get the Graphical Objects from.
    * @param num     is either {@link SatinConstants#ALL} or 
    *                {@link SatinConstants#FIRST}.
    * @param depth   is either {@link SatinConstants#SHALLOW} or
    *                {@link SatinConstants#DEEP}
    * @param gettype is the algorithm to use to retrieve, either
    *                {@link SatinConstants#INTERSECTS},
    *                {@link SatinConstants#CONTAINEDBY},
    *                {@link SatinConstants#CONTAINS},
    *                {@link SatinConstants#NEAR},
    *                {@link SatinConstants#ABOVE},
    *                {@link SatinConstants#BELOW},
    * @param thresh  is the threshold or halo to retrieve.
    * @param gobcol  is the storage for output. Use null to create new space.
    */
   public GraphicalObjectCollection 
   getGraphicalObjects(int cdsys, Point2D pt, int num, int depth, int gettype, 
                       double thresh, GraphicalObjectCollection gobcol);

   //-----------------------------------------------------------------

   /**
    * @see #getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public GraphicalObjectCollection 
   getGraphicalObjects(int cdsys, double x, double y, int num, int depth, 
            int gettype, double thresh, GraphicalObjectCollection gobcol);

   //-----------------------------------------------------------------

   public GraphicalObjectCollection 
   getGraphicalObjects(int cdsys, Shape s, int num, int depth, int gettype, 
                       double thresh, GraphicalObjectCollection gobcol);

   //-----------------------------------------------------------------

   /**
    * Get all Graphical Objects subject to the specified parameters.
    * This version is for optimization or fine-tuning purposes.
    *
    * <P>
    * Really big methods like this one are usually a warning sign, but I really
    * don't see any alternatives.
    *
    * @param gob     is the Graphical Object whose bounding points to use.
    * @param num     is either {@link SatinConstants#ALL} or 
    *                {@link SatinConstants#FIRST}.
    * @param depth   is either {@link SatinConstants#SHALLOW} or
    *                {@link SatinConstants#DEEP}
    * @param gettype is the algorithm to use to retrieve, either
    *                {@link SatinConstants#INTERSECTS},
    *                {@link SatinConstants#CONTAINEDBY},
    *                {@link SatinConstants#CONTAINS},
    *                {@link SatinConstants#NEAR},
    *                {@link SatinConstants#ABOVE},
    *                {@link SatinConstants#BELOW},
    * @param thresh  is the threshold or halo to retrieve.
    * @param gobcol  is the storage for output. Use null to create new space.
    */
   public GraphicalObjectCollection 
   getGraphicalObjects(GraphicalObject gob, int num, int depth, int gettype, 
                       double thresh, GraphicalObjectCollection gobcol);

   //-----------------------------------------------------------------

   /**
    * @see #getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public GraphicalObjectCollection 
   getGraphicalObjects(int cdsys, Point2D pt, int num, int depth, int gettype);

   //-----------------------------------------------------------------

   /**
    * @see #getGraphicalObjects(int, Point2D, int, int, int, double, GraphicalObjectCollection)
    */
   public GraphicalObjectCollection 
   getGraphicalObjects(int cdsys, double x, double y, int num, int depth, 
            int gettype);

   //-----------------------------------------------------------------

   public GraphicalObjectCollection 
   getGraphicalObjects(int cdsys, Shape s, int num, int depth, int gettype);

   //-----------------------------------------------------------------

   /**
    * @see #getGraphicalObjects(GraphicalObject, int, int, int, double, GraphicalObjectCollection)
    */
   public GraphicalObjectCollection
   getGraphicalObjects(GraphicalObject gob, int num, int depth, int gettype);

   //===   GROUP QUERY METHODS   ===============================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
