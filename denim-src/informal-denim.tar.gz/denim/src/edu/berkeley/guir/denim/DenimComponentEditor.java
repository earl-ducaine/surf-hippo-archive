//// See bottom of source code for software license
package edu.berkeley.guir.denim;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;
import org.w3c.dom.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.*;

import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.io.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.awt.geom.*;

/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 *             Created on May 10, 2004 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class DenimComponentEditor extends DenimWindow 
			implements SatinConstants
{

	JTextField nameField;
	boolean mIsCreate;
	String mOldName;
    DenimSheet sheet;
    DenimCustomComponent component = null;
	
	public DenimComponentEditor(boolean isCreate, String oldName)
	{
		super(true);

		this.addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent evt) {
				DenimComponentEditor.this.getDenimUI().getSheet().damage(DAMAGE_NOW);
			}
			
			public void componentShown(ComponentEvent evt) {
				//mEditors.add(DenimComponentEditor.this);
			}
			
			public void componentHidden(ComponentEvent evt) {
				//mEditors.remove(DenimComponentEditor.this);
                DenimPanel.setTransferStateID(true);
			}
		});

        sheet = this.getDenimUI().getSheet();
		mIsCreate = isCreate;
		mOldName = oldName;
		setLocation(0, 0);
		setSize(800, 600);

		if (isCreate)
			this.setTitle("Denim Component Editor - Create component");
		else
		{
            component =
				(DenimCustomComponent)DenimComponentRegistry.getInstance().getComponent(oldName);
				
			sheet.addToFront(component, GraphicalObjectGroup.KEEP_REL_POS);

			//// 1. Get the selected items.
			Iterator iter = component.getForwardIterator();

			//// 2. Set the selected Graphical Objects to be copied.
			DenimCopyCommand copyCommand = new DenimCopyCommand(iter);
            copyCommand.run();
            
			//cmdqueue.doCommand(copyCommand);

			Point2D tp = new Point2D.Double(300,300);
			try
			{
				sheet.getTransform(COORD_ABS).inverseTransform(tp,tp);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			} 
			//cmdqueue.doCommand(new DenimPasteCommand(pasteDest, tp));
            new DenimPasteCommand(sheet, tp).run();
			sheet.remove(component);

            //this.clearLinks(sheet);
            sheet.damage(DAMAGE_LATER);
			cmdsubsys.addSelected(sheet.getFirst());
            
			this.setTitle("Denim Component Editor - Edit component");
		}

        /*
         * clear clipboard and command queue
         */
        DenimConstants.denimClipboard.clearClipboard();
        cmdqueue.clear();
        
		JPanel pane = new JPanel();
		pane.setLayout(new BorderLayout());

		JPanel top = new JPanel();
		((FlowLayout) top.getLayout()).setAlignment(FlowLayout.LEADING);
		top.add(new JLabel("Name"));
		nameField = new JTextField(oldName);
        if(isCreate==false)
        {
            //nameField.setEditable(false);
        }
		nameField.setPreferredSize(new Dimension(300, 25));
		top.add(nameField);

		JPanel bottom = new JPanel();
		JButton ok = new JButton("Save & Close");
		bottom.add(ok);
		ok.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent evt)
			{
				DenimComponentEditor.this.setVisible(false);
				if (mIsCreate==false)
				{
					// remove old components
					//DenimComponentRegistry.getInstance().unregisterComponent(mOldName);
                    component.update(sheet);
                    
                    
                    DenimComponentRegistry.getInstance().unregisterComponent(component.getName());
                    component.setName(nameField.getText());
                    DenimComponentRegistry.getInstance().registerComponent(component);
                    
                }
                else
                {
    				// add new components
    				DenimCustomComponent newComponent =
    					new DenimCustomComponent(nameField.getText(), null, sheet);
                }                
                
                DenimConstants.denimClipboard.clearClipboard();
                cmdqueue.clear();
			}
		});

		JButton cancel = new JButton("Cancel");
		bottom.add(cancel);
		cancel.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent evt)
			{
                DenimConstants.denimClipboard.clearClipboard();
                cmdqueue.clear();
                
                DenimComponentEditor.this.setVisible(false);
			}
		});

		pane.add(top, BorderLayout.NORTH);
		pane.add(this.getDenimUI(), BorderLayout.CENTER);
		pane.add(bottom, BorderLayout.SOUTH);
		setContentPane(pane);
        
        DenimPanel.setTransferStateID(false);
	}
    
    private void getArrows(GraphicalObjectGroup group, LinkedList toDelete) {
        Iterator iter = group.getForwardIterator();
        while(iter.hasNext())
        {
            GraphicalObject gob = (GraphicalObject)iter.next();
            if(gob instanceof Arrow)
            {
                toDelete.add(gob);
            }
            else if(gob instanceof GraphicalObjectGroup)
            {
                this.getArrows((GraphicalObjectGroup)gob, toDelete);
            }
        }
        
    }

	public void clearLinks(Sheet sh) {

        LinkedList toDelete = new LinkedList();
        this.getArrows(sh, toDelete);

        Iterator iter = toDelete.iterator();
        while(iter.hasNext())
        {
            Arrow arrow = (Arrow)iter.next();
            ArrowSource source = arrow.getSource();
            if(source==null||source.getParentGroup()==null||
                    !(source.getParentGroup() instanceof DenimSketch))
            {
/*                DenimSketch sketch = source.getPanel().getSketch();
                if(source.getPanel()==null||sketch==null)
                    arrow.delete();
                else
                {
                    sketch.add(source, GraphicalObjectGroup.KEEP_REL_POS);
                    source.moveTo(COORD_ABS, )
                }
  */          arrow.delete();
            System.out.println("arrow " + arrow.getUniqueID() + " removed");
            }
        }
    }
    
	public static void exportComponents(String fileName) throws Exception {
		Document doc = new org.apache.xerces.dom.DocumentImpl();
		Element e = doc.createElement("DenimSheet");
		doc.appendChild(e);
		
		Collection registeredComponents = DenimComponentRegistry.getInstance().getComponents();
		Iterator iter = registeredComponents.iterator();
		while (iter.hasNext()) {
		   DenimComponent temp= (DenimComponent) iter.next();
		   if(!temp.isIntrinsic())
			  e.appendChild(DOMUtils.toDOMElement (doc, (DenimCustomComponent) temp, true));
		}	
		SheetDOMWriter writer = new SheetDOMWriter(fileName);
		writer.print(doc);
		writer.close();
	}
	
	public static void importComponents(String fileName, DenimSheet sheet) throws Exception {
		SheetDOMParser parser = new SheetDOMParser();
		Document document = parser.parse(fileName);
		NodeList children = document.getDocumentElement().getChildNodes();
		int len = children.getLength();
		for (int i = 0; i < len; i++) {
		   Element e = (Element)children.item(i);
		   DOMUtils.addCustomComponentFromDOMElement(
				   e, sheet, null);
		}
	}
}

//==============================================================================

/*
Copyright (c) 2003-2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
    must display the following acknowledgement:

        This product includes software developed by the Group for User 
        Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
    derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/