//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.objects.*;
import java.awt.geom.*;

/**
 * Zoom in or out. 
 * <P>
 * Here is a code example for zooming in on the Sheet at the specified point:
 * <CODE>
 * class MenuZoomInListener implements ActionListener {
 *    public void actionPerformed(ActionEvent evt) {
 *       cmdqueue.doCommand(new ZoomCommand(TestSheet.this, 1.2,
 *             cmdsubsys.getAbsoluteLastXLocation(),
 *             cmdsubsys.getAbsoluteLastYLocation()));
 *    } // of actionPerformed
 * } // inner class
 * </CODE>
 *
 * <P>
 * Here is a code example for zooming in on the selected objects at the
 * specified point:
 * <CODE>
 * class MenuZoomSelObjInListener implements ActionListener {
 *    public void actionPerformed(ActionEvent evt) {
 *       GraphicalObjectCollection gobs;
 *       GraphicalObject           gob;
 *       Iterator                  it;
 *
 *       gobs = cmdsubsys.getSelectedGraphicalObjects();
 *       it   = gobs.getForwardIterator();
 *
 *       while (it.hasNext()) {
 *          gob = (GraphicalObject) it.next();
 *          cmdqueue.doCommand(new ZoomCommand(gob, 1.2,
 *             cmdsubsys.getLocalLastXLocation(gob.getParentGroup()),
 *             cmdsubsys.getLocalLastYLocation(gob.getParentGroup())));
 *       }
 *    }
 * }
 * </CODE>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jul 15 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class ZoomCommand
   extends ApplyTransformationCommand {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -5549753840349908802L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTANTS   =========================================================

   /**
    * Scale, using the specified point as the new center (absolute coords) 
    * after scaling.
    * <P>
    * For example, suppose a GraphicalObject has a bounding box with
    * center at absolute coordinates (cx,cy). If you zoom at (x,y), the 
    * absolute Location of (x,y) will be where (cx,cy) was.
    */
   public static final int CENTER_AT = -5;

   /**
    * Scale, keeping the specified point constant (ie same absolute 
    * coordinates) before and after scaling.
    * <P>
    * For example, suppose you are zooming a GraphicalObject at (x,y).
    * The absolute coordinates of (x,y) before and after zooming will be
    * the same.
    */
   public static final int KEEP_CONSTANT = -6;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   float x;
   float y;
   float scale;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create the zoom command, zooming in the center of the GraphicalObject
    * and keeping it constant.
    *
    * @param gob   is the Graphical Object to apply a transformation upon.
    * @param scale is the amount to scale by, at the gob's center.
    */
   public ZoomCommand(GraphicalObject gob, double scale) {
      this(gob, scale, gob.getWidth2D(COORD_REL)/2, gob.getHeight2D(COORD_REL)/2, KEEP_CONSTANT);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create the zoom command, zooming in at the specified coordinate
    * and keeping it constant (ie {@link #KEEP_CONSTANT}).
    *
    * @param gob   is the Graphical Object to apply a transformation upon.
    * @param scale is the amount to scale by, at the gob's center.
    * @param x     is where to center the scale, in relative coordinates
    *              (in gob's parent's coordinate space).
    * @param y     is where to center the scale, in relative coordinates
    *              (in gob's parent's coordinate space).
    */
   public ZoomCommand(GraphicalObject gob, double scale, double x, double y) {
      this(gob, scale, x, y, KEEP_CONSTANT);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create the zoom command.
    *
    * @param gob   is the Graphical Object to apply a transformation upon.
    * @param scale is the amount to scale by.
    * @param x     is where to center the scale, in relative coordinates
    *              (in gob's parent's coordinate space).
    * @param y     is where to center the scale, in relative coordinates
    *              (in gob's parent's coordinate space).
    * @param type  is either {@link #CENTER_AT} or {@link #KEEP_CONSTANT}.
    */
   public 
   ZoomCommand(GraphicalObject gob, double scale, 
                     double x, double y, int type) {

      super(gob, getTransform(gob, scale, x, y, type));
      this.x     = (float) x;
      this.y     = (float) y;
      this.scale = (float) scale;
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   TRANSFORM METHODS   =================================================

   private static AffineTransform 
   getTransform(GraphicalObject gob, double scale, 
                double x, double y, int type) {

      switch (type) {
         case CENTER_AT:
            return (scaleAndCenterAt(gob, scale, x, y));
         case KEEP_CONSTANT:
            return (AffineTransformLib.scaleAndKeepConstant(scale, x, y));
         default:
            throw new RuntimeException("Unknown type value for zoom type");
      }
   } // of getTransform

   //-----------------------------------------------------------------

   /**
    * Scale, using the specified point as the new center (absolute coords) 
    * after scaling.
    */
   private static AffineTransform
   scaleAndCenterAt(GraphicalObject gob, double scale, double x, double y) {

      AffineTransform tx;
      Rectangle2D     rect = gob.getBounds2D(COORD_ABS);

      //// These are numbered backwards since you concatenate backwards
      //// with transforms.

      //// 3. Center at (x,y).
      tx = AffineTransform.getTranslateInstance(rect.getWidth()/2.0,
                                                rect.getHeight()/2.0);
      //// 2. Scale.
      tx.concatenate(AffineTransform.getScaleInstance(scale, scale));

      //// 1. Move the origin to the specified point.
      tx.concatenate(AffineTransform.getTranslateInstance(-x, -y));

      return (tx);
   } // of scaleAndCenterAt

   //===   TRANSFORM METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      return ("zoom (scale: " + scale + " x:" + x + " y:" + y + ")");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
