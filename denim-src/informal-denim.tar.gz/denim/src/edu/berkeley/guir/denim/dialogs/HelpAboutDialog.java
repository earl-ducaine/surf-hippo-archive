package edu.berkeley.guir.denim.dialogs;

import edu.berkeley.guir.denim.*;
import javax.swing.*;
import java.awt.*;

public class HelpAboutDialog
   extends JDialog
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================

   /**
    * Displays the Help About dialog.
    */
   public static void show(Component parentComponent) {
      // Primary text
      StringBuffer msg = new StringBuffer("DENIM\n");
      msg.append(DenimConstants.BUILD_VER + ": ");
      msg.append(BUILD_STR + "\n\n");
      msg.append("For support, please visit http://dub.washington.edu/denim/support/ \n\n");
      msg.append("DUB\n");
      msg.append("University of Washington\n");
      msg.append("http://dub.washington.edu/\n\n");
      msg.append("James Lin, Mark Newman, Jason Hong, James Landay, Yang Li, Marc Ringuette\n\n");
      msg.append("Michael Thomsen, Lisa Chan, Carol Hu, John Brian Kirby, ");
      msg.append("William Lee, Boxin Li, Benson Limketkai, Orna Tarshish, ");
      msg.append("Juan Valencia, David Wu\n");
      
      JTextArea ta = new JTextArea();
      ta.setOpaque(false);
      ta.setText(msg.toString());
      ta.setLineWrap(true);
      ta.setWrapStyleWord(true);
      ta.setEditable(false);
      
      if (!(UIManager.getLookAndFeel() instanceof
          javax.swing.plaf.metal.MetalLookAndFeel)) {
         ta.setFont(new JLabel().getFont());
      }
      
      // License notice

      StringBuffer licenseStrBuf = new StringBuffer("Copyright (c) 2004-2007 Regents of the University of Washington.\n\n");
      
      licenseStrBuf.append("All rights reserved.\n\n");

      licenseStrBuf.append("Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:\n\n");

      licenseStrBuf.append("1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.\n\n");

      licenseStrBuf.append("2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.\n\n");

      licenseStrBuf.append("3. The name of the University may not be used to endorse or promote products derived from this software without specific prior written permission.\n\n");

      licenseStrBuf.append("THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n");
      
      licenseStrBuf.append("//////////////////////////////////////////////////////////////////////////////////////////////////\n\n");
      
      licenseStrBuf.append("Copyright (c) 1999-2003 Regents of the University of California.\n\n");
      
      licenseStrBuf.append("All rights reserved.\n\n");  

      licenseStrBuf.append("Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:\n\n");

      licenseStrBuf.append("1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.\n\n");

      licenseStrBuf.append("2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.\n\n");

      licenseStrBuf.append("3. The name of the University may not be used to endorse or promote products derived from this software without specific prior written permission.\n\n");

      licenseStrBuf.append("THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n\n");


      /*
      licenseStrBuf.append("Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:\n\n");

      licenseStrBuf.append("1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.\n\n");

      licenseStrBuf.append("2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.\n\n");

      licenseStrBuf.append("3. All advertising materials mentioning features or use of this software must display the following acknowledgement:\n\n");

      licenseStrBuf.append("This product includes software developed by the Group for User Interface Research at the University of California at Berkeley.\n\n");

      licenseStrBuf.append("4. The name of the University may not be used to endorse or promote products derived from this software without specific prior written permission.\n\n");

      licenseStrBuf.append("THIS SOFTWARE IS PROVIDED BY THE REGENTS AND ");
      licenseStrBuf.append("CONTRIBUTORS ``AS IS'' AND ANY EXPRESS OR ");
      licenseStrBuf.append("IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED ");
      licenseStrBuf.append("TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND ");
      licenseStrBuf.append("FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT ");
      licenseStrBuf.append("SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY ");
      licenseStrBuf.append("DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR ");
      licenseStrBuf.append("CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, ");
      licenseStrBuf.append("PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF ");
      licenseStrBuf.append("USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) ");
      licenseStrBuf.append("HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER ");
      licenseStrBuf.append("IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING ");
      licenseStrBuf.append("NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE ");
      licenseStrBuf.append("USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY ");
      licenseStrBuf.append("OF SUCH DAMAGE.");
*/
      JTextArea licenseTA = new JTextArea();
      licenseTA.setText(licenseStrBuf.toString());
      licenseTA.setRows(5);
      licenseTA.setLineWrap(true);
      licenseTA.setWrapStyleWord(true);
      licenseTA.setEditable(false);

      JScrollPane licenseScrollPane = new JScrollPane(licenseTA);
      JLabel label = new JLabel("Copyright � 1999-2006 by the Regents of the University of Washington.");
      int preferredWidth = (int)(label.getPreferredSize().width * 1.05);
      int preferredHeight = licenseScrollPane.getPreferredSize().height;
      licenseScrollPane.setPreferredSize(new Dimension(preferredWidth, preferredHeight));

      Object[] array = {ta, licenseScrollPane};

      JOptionPane.showMessageDialog(parentComponent,
                                    array,
                                    "About",
                                    JOptionPane.PLAIN_MESSAGE);
   } // of method
} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/

