package edu.berkeley.guir.denim.lib;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.toolbox.*;
import edu.berkeley.guir.lib.satin.Sheet;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.view.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;

/**
 * A "framed patch," which has window-like behaviors: rectangular,
 * resizable borders, draggable title bars.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-23-2000 James Lin
 *                               Created FramedPatch
 *             1.1.0  08-14-2001 James Lin
 *                               Split into SATIN's FramedPatch and
 *                               DENIM's DenimFramedPatch
 *
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.1.0, 08-14-2001
 */
public class DenimFramedPatch
   extends FramedPatch
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS  ==========================================================

   //===   CONSTANTS  ==========================================================
   //===========================================================================

   //===========================================================================
   //===   INSTANCE VARIABLES ==================================================

   private Tool currentTool;
   private DenimUI ui;

   //===   INSTANCE VARIABLES  =================================================
   //===========================================================================

   //===========================================================================
   //===   INNER CLASSES   =====================================================

   /**
    * Currently not used.
    */
   class FramedPatchComponentView extends SemanticZoomViewImpl {
      public FramedPatchComponentView (GraphicalObject gob) {
         setDisplayRange(0.0,100.0);
         /*
         setDisplayRange(DenimUtils.getAbsScaleFactorAt(gob, SITEMAP_SCALE_FACTOR),
         DenimUtils.getAbsScaleFactorAt(gob, BELOW_DETAIL_SCALE_FACTOR));
         */
      }
      public void render(SatinGraphics g) {
         //System.out.println("Render!!");
         superRender(g);
      }
      public Object clone() {
         return this;
      }
   }

   //===   INNER CLASSES   =====================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Makes a framed patch with no boundary.
    */
   public DenimFramedPatch() {
      super();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Makes a framed patch with the specified boundary.
    */
   public DenimFramedPatch(Rectangle2D rect) {
      super(rect);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Makes a framed patch containing the given patch with the given title.
    */
   public DenimFramedPatch(Patch patch, String title) {
      super(patch, title);
   } // of constructor


   //===   CONSTRUCTORS   ======================================================
   //===========================================================================


   //===========================================================================
   //===   ARROW HANDLING METHODS   ============================================

   /**
    * Returns a set of all outgoing arrows from this framed patch.
    */
   private Set getNavArrows() {
      Set res = new HashSet();

      GraphicalObjectGroup component = (GraphicalObjectGroup)this.get(0);
      Iterator it = component.getForwardIterator();
      while (it.hasNext()) {
         GraphicalObject gob = (GraphicalObject)it.next();
         if (gob instanceof DenimPanel) {
            Set arrows = ((DenimPanel)gob).getNavArrows();
            res.addAll(arrows);
         }
      }

      if (res.isEmpty()) {
         res = null;
      }

      return res;
   }

   //-----------------------------------------------------------------

   /**
    * Displays or removes the arrows coming in and out of this framed patch.
    */
   private void displayArrows(boolean state) {
      Set arrows = getNavArrows();
      if (arrows != null) {
         Iterator it = arrows.iterator();
         while (it.hasNext()) {
            Arrow arrow = (Arrow)it.next();
            arrow.setVisible(state);

            // HACK (miksen) We need to bring the arrow to the top
            // and adjust its placement
            if (state) {
               arrow.bringToTopLayer();
               arrow.onUpdate(arrow.getSource(), null, null, null);
            }
         }
      }
   }

   //-----------------------------------------------------------------

   /**
    * Displays the arrows going out from this FramedPatch.
    */
   public void initArrows() {
      displayArrows(true);
      ((DenimSheet)getSheet()).damage(DAMAGE_LATER);
   }

   //===   ARROW HANDLING METHODS   ============================================
   //===========================================================================


   //===========================================================================
   //===   TITLEBAR METHODS   ==================================================

   public void handleTitleBarNewStroke(NewStrokeEvent evt) {
      super.handleTitleBarNewStroke(evt);

      //// Store the current tool and change the cursor to the arrow
      ui = ((DenimSheet)this.getSheet()).getDenimUI();
      currentTool = ui.getCurrentTool();
      ui.setCurrentTool(null);
      ui.setCursor(Cursor.getDefaultCursor());
   } // of handleTitlebarNewStroke

   //-----------------------------------------------------------------

   public void handleTitleBarUpdateStroke(UpdateStrokeEvent evt) {
      super.handleTitleBarUpdateStroke(evt);

      if (!closePressed) {
         // HACK HACK (miksen)
         // Notify the outgoing arrows of the move
         //
         // We iterate through all childs of the custom component
         // looking for panels, and for each get the outgoing
         // arrows and then send these the message
         // arrow.onUpdate(this, null, null, null);
         // HACK HACK
         Set arrows = getNavArrows();
         if (arrows != null) {
            Iterator arrowsIt = arrows.iterator();
            while (arrowsIt.hasNext()) {
               Arrow arrow = (Arrow)arrowsIt.next();
               arrow.onUpdate(arrow.getSource(), null, null, null);
            }
         }
      }

      evt.setConsumed();
      evt.setShouldRender(false);
   } // of handleTitlebarUpdateStroke

   //-----------------------------------------------------------------

   public void handleTitleBarSingleStroke(SingleStrokeEvent evt) {
      Sheet sheet = getSheet();

      super.handleTitleBarSingleStroke(evt);

      // Set event as consumed, since we already used it.
      evt.setConsumed();
      evt.setShouldRender(false);

      if (closePressed) {
         // Hide the arrows going from this FramedPatch
         displayArrows(false);
      }

      // Completed move: Set the cursor back to the current tool.
      ui.setCurrentTool(currentTool);
      ui.setCursor(Cursor.getDefaultCursor());
      sheet.damage(DAMAGE_LATER);
   } // of handleTitlebarSingleStroke

   //===   TITLEBAR METHODS   ==================================================
   //===========================================================================

} // of class



//==============================================================================

/*
  Copyright (c) 1999-2001 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
