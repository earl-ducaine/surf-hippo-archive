package edu.berkeley.guir.lib.gesture.features;

import java.awt.Rectangle;
import edu.berkeley.guir.lib.gesture.Feature;
import edu.berkeley.guir.lib.gesture.Gesture;

public class LogAspect extends Feature {
  protected final static double RADIANS45 = 45.0 / 180.0 * Math.PI;
  protected final static double ONE_DEGREE = 1.0 / 180.0 * Math.PI;
    
  public LogAspect()
  {
    super();
  }

  public LogAspect(Gesture g)
  {
    super(g);
  }

  public String getName()
  {
    // todo
    return "log(aspect)";
  }
  
  public double getMinValue()
  {
    return Double.MIN_VALUE;
  }
  
  public double getMaxValue()
  {
    return Double.MAX_VALUE;
  }
  
  protected void computeValue()
  {
    Rectangle bounds = gesture.getBounds();
    double boundsAngle = Math.atan2(bounds.height, bounds.width);

    double aspect = Math.abs(boundsAngle - RADIANS45);
    value = Math.log((aspect != 0) ? aspect : ONE_DEGREE);
    valueOk = true;
  }

  public void scale(double factor)
  {
  }
}
