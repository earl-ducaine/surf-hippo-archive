package edu.berkeley.guir.damask.view.visual.event;

import java.awt.event.InputEvent;
import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.Direction;
import edu.berkeley.guir.damask.command.SplitPageCommand;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.nodes.DamaskPPath;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.berkeley.guir.damask.view.visual.dialog.PageRegionView;
import edu.berkeley.guir.damask.view.visual.dialog.PageViewContents;
import edu.umd.cs.piccolo.event.*;

/** 
 * The event handler that handles splitting pages.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-06-2004 James Lin
 *                               Created InsertComponentHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-06-2004
 */
public class SplitEventHandler extends PBasicInputEventHandler {
   private PageViewContents pageViewContents;
   private DamaskPPath splitter = new DamaskPPath();
   
   /**
    * Constructs a handler which will instantiate a component of the specified
    * type.
    * 
    * @param componentViewType a class which is a descendant of
    * {@link edu.berkeley.guir.damask.view.visual.component.ComponentView}
    */
   public SplitEventHandler() {
      setEventFilter(new PInputEventFilter(InputEvent.BUTTON1_MASK));
   }


   /**
    * Updates the temporary view of a component while the mouse is being
    * dragged.
    */
   protected void updateSplitter(final PInputEvent e) {
      if (pageViewContents != null) {
         final Point2D pos = e.getPosition();
         pageViewContents.getRegionView(Direction.CENTER).globalToLocal(pos);

         final Rectangle2D pageViewContentsCenterBounds =
            pageViewContents.getRegionView(Direction.CENTER).getBounds();
         
         splitter.setPathTo(
            new Line2D.Double(
               pageViewContentsCenterBounds.getMinX(), pos.getY(),
               pageViewContentsCenterBounds.getMaxX(), pos.getY()));
      }
   }

   
   // @Override
   public void mouseEntered(final PInputEvent event) {
      final PageViewContents contents =
         (PageViewContents)DamaskAppUtils.getAncestor(
            event.getPickedNode(), PageViewContents.class);
      
      if (pageViewContents != contents) {
         splitter.removeFromParent();
         pageViewContents = contents;
         if (pageViewContents != null) {
            pageViewContents.getRegionView(Direction.CENTER).addChild(
               0, splitter);
         }
      }
      
      updateSplitter(event);
   }

   
   // @Override
   public void mouseMoved(final PInputEvent event) {
      updateSplitter(event);
   }

   
   // @Override
   public void mouseReleased(final PInputEvent event) {
      updateSplitter(event);
      if (pageViewContents != null) {
         // Find the location of the splitter
         final Point2D splitterPos = event.getPosition();
         final PageRegionView centerView = pageViewContents.getRegionView(Direction.CENTER);
         centerView.globalToLocal(splitterPos);
         final double splitterY = splitterPos.getY(); 

         final Rectangle2D pageViewContentsCenterBounds =
            centerView.getBounds();
         
         // If the splitter is in the center region...
         if (pageViewContentsCenterBounds.getMinY() <= splitterY &&
             splitterY <= pageViewContentsCenterBounds.getMaxY()) {
            
            // Get all of the controls below the splitter
            final PageRegion centerRegion = (PageRegion)centerView.getModel();
            final List/*<Control>*/ controlsToSplitAway =
               new ArrayList/*<Control>*/();
            
            for (Iterator i = centerRegion.getControls().iterator();
                 i.hasNext(); ) {
               final Control control = (Control)i.next();
               final Rectangle2D controlBounds =
                  control.getBoundsInParentCoords(centerRegion.getDeviceType());
               if (controlBounds.getY() >= splitterY) {
                  controlsToSplitAway.add(control);
               }
            }

            // Split them away
            final VisualCanvas canvas = (VisualCanvas)event.getComponent();
            canvas.getDocument().getCommandQueue().doCommand(
               canvas,
               new SplitPageCommand(
                  centerRegion.getPage(), controlsToSplitAway, splitterY));
         }
      }
   }
   
   
   /**
    * Clean up anything that the handler left behind before it is disabled.
    */
   public void cleanUp() {
      splitter.removeFromParent();
   }
}
