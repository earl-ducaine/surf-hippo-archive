package edu.berkeley.guir.suede;

public class DesignScriptNodeView extends AbstScriptNodeView
{
    public DesignScriptNodeView(boolean system, AbstScriptNodeModel model) {
       super(system, model);
       setLayout(null);
       model.addRecordListener(m_recordButton);    
    }

   //public void handleMouseReleased (Component c) {}

   public void handleMouseDragged () {
		SuedeModel.copiedScriptNodeObj = this;
		System.out.println ("Copying scriptnode");
   }
}