/*
 * Copyright (C) 2003 by the Regents of the University of California.
 *  
 * Copyright (C) 2002-2003 by University of Maryland, College Park, MD 20742 
 * All rights reserved. 
 * 
 * This code is based on code in Piccolo.
 * 
 * Piccolo was written at the Human-Computer Interaction Laboratory 
 * www.cs.umd.edu/hcil by Jesse Grosjean under the supervision of Ben Bederson. 
 * The Piccolo website is www.cs.umd.edu/hcil/piccolo 
 */
package edu.berkeley.guir.damask.view.event;

import java.awt.geom.Point2D;

import javax.swing.JPopupMenu;

import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.DamaskCanvas;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;

/**
 * Provides interaction for popping up a context menu.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-12-2004 James Lin
 *                               Created PopupMenuEventHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-12-2004
 */
public class PopupMenuEventHandler extends PBasicInputEventHandler {
   private final DamaskCanvas canvas;

   public PopupMenuEventHandler(final DamaskCanvas canvas) {
      this.canvas = canvas;
   }

   public void mousePressed(PInputEvent e) {
      maybeShowPopup(e);
   }

   public void mouseReleased(PInputEvent e) {
      maybeShowPopup(e);
   }

   protected void maybeShowPopup(PInputEvent e) {
      if (e.isPopupTrigger()) {
         final SelectionEventHandler selectionEventHandler =
            canvas.getSelectionEventHandler();
      
         boolean isPickedNodeSelectable; 
         PNode pickedNode =
            DamaskAppUtils.getSelectablePickedNode(
               e,
               selectionEventHandler.getSelectableParents());
         if (pickedNode != null) {
            if (!canvas.getSelectedObjects().contains(pickedNode)) {
               selectionEventHandler.unselectAll(canvas);
               selectionEventHandler.select(pickedNode, canvas);
            }
            isPickedNodeSelectable = true;
         }
         else {
            pickedNode = e.getPath().getPickedNode();
            isPickedNodeSelectable = false;
         }
      
         final Point2D pt = e.getCanvasPosition();
         
         final JPopupMenu popupMenu =
            canvas.getPopupMenu(pickedNode, isPickedNodeSelectable);

         if (popupMenu != null) {
            popupMenu.show(canvas, (int)pt.getX(), (int)pt.getY());
         }
      }
   }
}
