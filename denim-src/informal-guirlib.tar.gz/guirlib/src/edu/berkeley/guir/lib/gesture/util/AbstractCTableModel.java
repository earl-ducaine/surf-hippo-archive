package edu.berkeley.guir.lib.gesture.util;

import javax.swing.table.*;

public abstract class AbstractCTableModel extends AbstractTableModel
implements CTableModel
{
  public AbstractCTableModel()
  {
    super();
  }

  public void setRowName(int rowNumber, Object newName) {}
}
