package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class SBalloon extends javax.swing.JLabel
{
    private static final int WIDTH      = 35;
    private static final int HEIGHT     = 23;
    private static final int BALLOON_0X = 0;
    private static final int BALLOON_0Y = HEIGHT-1;
    private static final int BALLOON_1X = 20;
    private static final int BALLOON_1Y = HEIGHT-12;
    private static final int BALLOON_2X = 7;
    private static final int BALLOON_2Y = HEIGHT-19;
    
    private static final Ellipse2D.Float ELLIPSE = new Ellipse2D.Float(0,0,WIDTH-4,HEIGHT-4);

    private Area            m_balloon   = new Area(ELLIPSE);
    private LinkModel       m_linkModel = null; // this is the response that the balloon represents
    private SingleNodeModel m_nodeModel = null; // this is the node the balloon is embedded in
    
    
    public SBalloon(LinkModel lm, SingleNodeModel nodeModel) {
        m_nodeModel = nodeModel;
        setOpaque(false);   setForeground(AbstLinkView.BALLOON_FG);
        setVisible(true);   setSize(WIDTH,HEIGHT);

        int[] xPoints = new int[3];  int[] yPoints = new int[3];
        xPoints[0] = BALLOON_0X;
        xPoints[1] = BALLOON_1X;
        xPoints[2] = BALLOON_2X;
        yPoints[0] = BALLOON_0Y;
        yPoints[1] = BALLOON_1Y;
        yPoints[2] = BALLOON_2Y;
        
        m_balloon.add(new Area(new Polygon(xPoints, yPoints, 3))); 

        setHorizontalAlignment(CENTER);
        setLinkModel(lm);
    }


    public void paintComponent(Graphics g) {  
        Graphics2D g2d = (Graphics2D)g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setFont(g2d.getFont().deriveFont(Font.BOLD, 13));
    
        g2d.setColor(Color.white);
        g2d.fill(m_balloon);
        
        g2d.setColor(getForeground());
        g2d.draw(m_balloon);
        super.paintComponent(g);
    }
    
    
    public JToolTip createToolTip() {
        JToolTip t = super.createToolTip();
        t.setForeground(getForeground());
        t.setBackground(AbstLinkView.LINK_COLOR);
        return t;
    }
    
    
    public void setLinkModel(LinkModel linkModel) {
        m_linkModel = linkModel;
        setName(m_linkModel.getNodeLabel());
        setText(m_linkModel.getNodeLabel());
        setToolTipText(m_linkModel.getCaption());
        setSize(WIDTH,HEIGHT);
        //System.out.println("updating balloon name and tooltip");
    }
    
    
    public boolean hasLinkModel () {  return (m_linkModel!=null); }
    
    public LinkModel getLinkModel() { return m_linkModel;         }
    
    // this method is used for saving balloons
    // remember: the label is the internal system identifier, e.g. "cl1"
    public String getLinkLabel() { return m_linkModel.getLabel(); }
    
    public void play(SSavableElt node) {
      if (m_linkModel !=null) m_linkModel.playBalloon(node);
    }
    
}