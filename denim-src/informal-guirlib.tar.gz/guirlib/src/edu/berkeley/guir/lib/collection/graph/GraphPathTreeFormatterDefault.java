//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import java.io.Writer;
import edu.berkeley.guir.lib.util.StringLib;

/**
 * Formats a Path Tree to be displayed via text.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Dec 01 1997, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.4/1.0.0, Aug 31 2000, JH
 *               Touched for GUIRLib release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.1.4
 * @version GUIRLib-v1.4-1.0.0, Aug 31 2000
 */
public class GraphPathTreeFormatterDefault
   implements GraphPathTreeFormatter {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   /**
    * Number of spaces to indent per indent level.
    */
   private final int INDENT = 3;

   //===   CONSTANTS   =========================================================
   //===========================================================================





   //===========================================================================
   //===   TRAVERSAL METHODS   =================================================

   /**
    * This method is called before any traversing is done.
    *
    * @param pwriter is the Writer to print out to.
    */
   public void onStart(Writer pwriter) {
   } // of onStart

   //-----------------------------------------------------------------

   /**
    * This method is called when we first traverse to a new node.
    *
    * @param pwriter is the Writer to print out to.
    * @param depth is the current depth we are at relative to the root.
    */
   public void onStartOfNode(Writer pwriter, int depth) {
   } // of onStartNode

   //-----------------------------------------------------------------

   /**
    * This method is called after we have traversed all of the children and
    * siblings of the node.
    *
    * @param pwriter is the Writer to print out to.
    * @param depth is the current depth we are at relative to the root.
    */
   public void onEndOfNode(Writer pwriter, int depth) {
   } // of onEndNode

   //-----------------------------------------------------------------

   /**
    * This method is called after we have traversed the children and before 
    * we start to traverse the siblings of the current node.
    *
    * @param pwriter is the Writer to print out to.
    * @param depth is the current depth we are at relative to the root.
    */
   public void onBacktrack(Writer pwriter, int depth) {
   } // of onBacktrack

   //-----------------------------------------------------------------

   /**
    * This method is called when we reach a leaf node.
    *
    * @param pwriter is the Writer to print out to.
    * @param depth is the current depth we are at relative to the root.
    */
   public void onLeaf(Writer pwriter, Object data, int depth) {
      String strPrefix = StringLib.spaces(INDENT * depth);
      try {
          pwriter.write(StringLib.fold(strPrefix, data.toString()));
          pwriter.write("\n");
      }
      catch (Exception e) {
          e.printStackTrace();
      }
   } // of onLeaf

   //-----------------------------------------------------------------

   /**
    * This method is called just before we start traversing the children.
    *
    * @param pwriter is the Writer to print out to.
    * @param depth is the current depth we are at relative to the root.
    */
   public void onNode(Writer pwriter, Object data, int depth) {
      String strPrefix = StringLib.spaces(INDENT * depth);
      try {
          pwriter.write(StringLib.fold(strPrefix, data.toString()));
          pwriter.write("\n");
      }
      catch (Exception e) {
          e.printStackTrace();
      }
   } // of onNode

   //-----------------------------------------------------------------

   /**
    * This method is called after all traversing is done.
    *
    * @param pwriter is the Writer to print out to.
    */
   public void onFinish(Writer pwriter) {
   } // of onFinish

   //===   TRAVERSAL METHODS   =================================================
   //===========================================================================

} // of interface

//==============================================================================


/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
