package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.util.List;
import javax.swing.text.Position;

public interface Notice {
  /** in ms since the epoch (see System.currentTimeMillis) */
  long getLastDisplayTime();
  void setLastDisplayTime(long time);
  /** display the notice if appropriate to do so */
  void display(SummaryLog log);
  /** display a short version of the notice */
  void displaySummary(SummaryLog log);
  /** return the object(s) that this notice refers to */
  List getObjectList();
  /** a short user-intelligible name */
  String getName();
  Position getPosition();
  void setPosition(Position p);
  /** get a component that displays information about how the designer
      can address the issues the Notice brings up */
  HowToPanel getHowToPanel();
  /** get a tag into the reference manual for a section related to
      this Notice (e.g., "#Similarity") */
  String getReferenceTag();
}
