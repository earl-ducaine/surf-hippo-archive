//// See bottom of source code for software license.
package edu.berkeley.guir.lib.debugging.introspect;

import java.lang.reflect.Field;
import java.util.*;

/**
 * Lots of debugging utilities, including log file output, stream output, 
 * graphical window output, and object introspection.
 * Have an instance in each class you want and use that instance.
 *
 * <P>
 * Definitely not thread-safe.
 *
 * <P>
 * Here is an example of the introspection debugging:
 * <IMG SRC="{@docRoot}/img/debug-introspect.gif">
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
public class Introspect 
   implements IntrospectConstants {


   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   //// Set of objects visited, so we don't go in a loop.
   //// Problem now is concurrent access...
   static HashSet setTraversed = new HashSet();

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * No instances allowed.
    */
   public Introspect() {
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   OBJECT INTROSPECTION METHODS   ======================================

   /**
    * @param f       is the current field in obj's class we are looking at.
    * @param obj     is the current instance we are looking at.
    * @param depth   is the current object depth we are at (starting at 0).
    * @param handler specifies how we handle primitive and object fields.
    */
   private static void 
   parseField(Field f, Object obj, int depth, IntrospectHandler handler) {
      Class clField = f.getType();

      //// 1. See if we should accept the field or not.
      if (handler.acceptField(depth, f, obj) == false) {
         return;
      }

      try {
         //// 2. Handle arrays.
         if (clField.isArray() == true) {
            Object fval = f.get(obj);
            if (fval != null) {
               handler.onArray(depth, f, fval);
            }
            else {
               handler.onNull(depth, f);
            }
         }
         //// 3. Handle objects.
         else if (clField.toString().startsWith("class")) {
            Object fval = f.get(obj);
            if (fval != null) {
               handler.onObject(depth, f, fval);
               if (handler.shouldRecurse(depth, f, fval) == true) {
                  parseObject(fval, depth + 1, handler);
               }
            }
            else {
               handler.onNull(depth, f);
            }
         }
         //// 4. Handle primitives.
         else {
            //// 4.1. Handle chars.
            if (clField == Character.TYPE) {
               handler.onChar(depth, f, f.getChar(obj));
            }
            //// 4.2. Handle booleans.
            else if (clField == Boolean.TYPE) {
               handler.onBoolean(depth, f, f.getBoolean(obj));
            }
            //// 4.3. Handle int.
            else if (clField == Integer.TYPE) {
               handler.onInt(depth, f, f.getInt(obj));
            }
            //// 4.4. Handle long.
            else if (clField == Long.TYPE) {
               handler.onLong(depth, f, f.getLong(obj));
            }
            //// 4.5. Handle float.
            else if (clField == Float.TYPE) {
               handler.onFloat(depth, f, f.getFloat(obj));
            }
            //// 4.6. Handle double.
            else if (clField == Double.TYPE) {
               handler.onDouble(depth, f, f.getDouble(obj));
            }
            //// 4.7. Handle short.
            else if (clField == Short.TYPE) {
               handler.onShort(depth, f, f.getShort(obj));
            }
            //// 4.8. Handle byte.
            else if (clField == Byte.TYPE) {
               handler.onByte(depth, f, f.getByte(obj));
            }
         }
      }
      catch (IllegalAccessException e) {
         handler.onException(depth, f, e);
      }
      catch (Exception e) {
         e.printStackTrace();
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Use introspection to debug an object, using the specified callback.
    */
   public static void parseObject(Object obj, IntrospectHandler handler) {
      //// 1. Clear out the set of traversed objects.
      setTraversed.clear();

      //// 2. Handle the top-level object.
      handler.onRoot(obj);
      parseObject(obj, 1, handler);
   } // of method



   /**
    * Helper method for introspection debugging.
    */
   private static
   void parseObject(Object obj, int depth, IntrospectHandler handler) {
      //// 0. Quick check exit.
      if (obj == null) {
         return;
      }

      //// 1. Quick check to make sure we're not going in circles.
      if (setTraversed.contains(obj) == true) {
         return;
      }
      else {
         setTraversed.add(obj);
      }

      //// 2. Get all the fields.
      List listFields = IntrospectLib.getAllFields(obj.getClass());

      //// 3. Sort the fields in some order.

// XXX

      //// 4. Go thru each of the fields and handle each field.
      Iterator it = listFields.iterator();
      Field    f;
      while (it.hasNext()) {
         f = (Field) it.next();

         //// 4.1. Make the field accessible. This portion requires JDK1.3+
         try {
            f.setAccessible(true);
         }
         catch (SecurityException e) {
            System.err.println(e.toString());
         }
         parseField(f, obj, depth, handler);
      }
   } // of method

   //===   OBJECT INTROSPECTION METHODS   ======================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) {
      Introspect.parseObject("dogs", new PrintIntrospectHandler());
      Introspect.parseObject(new PrintIntrospectHandler(), 
                        new PrintIntrospectHandler());
   } // of method

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class 

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
