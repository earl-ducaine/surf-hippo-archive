package edu.berkeley.guir.denim.components;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.debugging.*;
import java.awt.geom.*;
import java.util.*;
import java.awt.*;

/**
 * An instance of a DENIM {@link DenimHyperlink hyperlink}.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-23-1999  James Lin
 *                                Created DenimHyperlinkInstance
 * 
 *             1.0.1  02-04-2003  Yang Li
 *                    Overrieded addToFront method to make later added strokes blue
 * 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 1.0.1, 02-04-2003
 */
public class DenimHyperlinkInstance
   extends DenimComponentInstance {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -6670058882090179529L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   // displayedState is not used in this class

   private GraphicalObject      contents;  // represents how the hyperlink looks
   private GraphicalObjectGroup parent;
   private Style                origStyle; // if the hyperlink is a timed
                                           // stroke, then this is the stroke's
                                           // original style
   private boolean              hasArrows; // true if the hyperlink has arrows
                                           // coming out of it

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   protected DenimHyperlinkInstance(DenimComponent type) {
      super(type);
   }

   //-----------------------------------------------------------------

   /**
    * Creates a hyperlink from the given graphical object, and puts the
    * new hyperlink in the same place in the "object hierarchy" as the
    * original graphical object.
    *
    * Called only by DenimHyperlink.newInstance()
    */
   DenimHyperlinkInstance(DenimComponent type, GraphicalObject gob) {
      super(type);

      assert type instanceof DenimHyperlink;
      // "DenimHyperlinkInstance can only be created by DenimHyperlink"

      //System.out.println("setcontents: parent is " + DenimUtils.toShortString(gob.getParentGroup()));

      //// 1. Set parent and contents of this link.
      this.contents = gob;
      this.parent = contents.getParentGroup();

      //// 2. Get the bounds and layer of the contents.
      Rectangle2D bounds = contents.getBounds2D(COORD_REL);
      int layer = parent.getRelativeLayer(contents);

      //// 3. Set the hyperlink location.
      ////    First set our bounding points.
      this.setBoundingPoints2D(COORD_REL, bounds);

      //// 4. Delete the new contents from its original parent.
      this.contents.delete();

      //// 5. Add the link to the gob's original parent.
      this.parent.add(this, GraphicalObjectGroup.KEEP_REL_POS);
      this.setRelativeLayer(layer);

      //// 6. Add the gob inside the link.
      this.contents.moveTo(COORD_REL, 0, 0);
      this.add(contents, GraphicalObjectGroup.KEEP_REL_POS);
      this.getContainingPanel().componentInstanceIsAdded(this);

      parent.addWatcher(this);

      commonInit();
   }
   

   //-----------------------------------------------------------------

   /**
    * Creates a hyperlink with the given bounds containing the given
    * graphical object, and adds it to the given parent.
    *
    * Called only by DenimHyperlink.newInstance()
    */
   DenimHyperlinkInstance(DenimComponent type,
                          Rectangle2D bounds,
                          AffineTransform tx,
                          GraphicalObject gob,
                          GraphicalObjectGroup parent) {
      super(type);

      assert type instanceof DenimHyperlink;
      // "DenimHyperlinkInstance can only be created by DenimHyperlink"

      contents = gob;
      this.parent = parent;
      
      setBoundingPoints2D(COORD_LOCAL, bounds);
      this.add(contents, GraphicalObjectGroup.KEEP_REL_POS);
      setTransform(tx);
      parent.add(this, GraphicalObjectGroup.KEEP_REL_POS);

      commonInit();
   }

   //-----------------------------------------------------------------

   /**
    * Performs initializations common to all constructors.
    */
   private void commonInit() {
      if (contents instanceof TimedStroke) {
         origStyle = contents.getStyle();
      }
      else {
         origStyle = null;
      }

      setHasArrows(true);

      //// HACK: watcher method - hack to make it work, since we know the
      //// structure of links
      parent.addWatcher(this);

      displayedState = contents;
      this.getContainingPanel().componentInstanceIsAdded(this);
      
      this.setDrawPatch(false);
      this.setFillPatch(false);
   }
   
   public Color getPrintFill() {
   	   return new Color(240,240,240);
   }


   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object deepClone() {
      return deepClone(new DenimHyperlinkInstance(type));
   }

   //-----------------------------------------------------------------

   public Object deepClone(DenimHyperlinkInstance clone) {
      super.deepClone(clone);

      // We know the contents should be the only object in the clone patch
      clone.contents = (GraphicalObject)(clone.getLast());

      if (clone.contents!=clone.getFirst()) // assumption above is violated
         Debug.println("bug workaround: DenimHyperlinkInstance has multiple contents, using last.");

      return clone;
   }

   //===   CLONE   =============================================================
   //===========================================================================


   private void setHasArrows(boolean hasArrows) {
      //// Set the style of the contents
      this.hasArrows = hasArrows;
      if (contents instanceof TimedStroke) {
         if (hasArrows) {
            contents.getStyleRef().setDrawColor(DEFAULT_LINK_COLOR);
         }
         else {
            contents.setStyle(origStyle);
         }
      }
      else {
         ((DenimHyperlinkContents)contents).setHyperlink(hasArrows);
      }
   }

   /**
    * Should be called when the contents of the hyperlink instance changes.
    */
   private void refresh() {
      setHasArrows(hasArrows);
   }

   //===========================================================================
   //===   ARROW SOURCE METHODS   ==============================================

   public void trackArrow(Arrow arrow) {
      super.trackArrow(arrow);
      setHasArrows(true);
   }

   //-----------------------------------------------------------------

   public void untrackArrow(Arrow arrow) {
      super.untrackArrow(arrow);

      if (getOutgoingArrows().size() == 0) {
         setHasArrows(false);
      }
   }

   //===   ARROW SOURCE METHODS   ==============================================
   //===========================================================================

   /**
    * Gets the graphical object which shows how this link instance looks.
    */
   public GraphicalObject getContents() {
      return contents;
   }

   //-------------------------------------------------------------------------

   /**
    * override add stroke method
    */
   
   public GraphicalObject addToFront(GraphicalObject gob, int pos) {

     if(gob instanceof TimedStroke)
     {
     	gob.getStyleRef().setDrawColor(DenimConstants.DEFAULT_LINK_COLOR);
     }
     
     return super.addToFront(gob, pos);
        
   } // of method
   
   //-------------------------------------------------------------------------
            
   /**
    * Destroys the contents of this link, and makes the given graphical object
    * new the contents of this link.
    *
    * @param gob the new content of the hyperlink instance
    */
   public void setContents(GraphicalObject gob) {
      // Remove the original contents
       
      if (contents != null) {
         contents.delete();
      }

      //System.out.println("set contents: " + DenimUtils.toShortString(gob));

      this.disableNotify();

      //System.out.println("setcontents: parent is null");
      contents = gob;

      //Point2D absPt = this.getLocation2D(COORD_ABS);
      AffineTransform contentsXform = contents.getTransformRef();
      Rectangle2D contentsLocalBds = contents.getBounds2D(COORD_LOCAL);

      add(contents, GraphicalObjectGroup.KEEP_REL_POS);
      contents.moveTo(COORD_REL, 0, 0);

      setBoundingPoints2D(COORD_LOCAL,
         new Rectangle2D.Double
            (0, 0,
             contentsLocalBds.getWidth() * contentsXform.getScaleX(),
             contentsLocalBds.getHeight() * contentsXform.getScaleY()));

      this.enableNotify();
      
      Iterator it = this.getOutgoingArrows().iterator();
      while(it.hasNext())
      {
          Arrow a = (Arrow)it.next();
          a.reanchor();
      }

      refresh();
      //System.out.println("done contents: " + DenimUtils.toShortString(gob));
   }


   //===========================================================================
   //===   WATCH METHODS   =====================================================

   /**
    * Repeat the message. Technically, not 100% correct.
    */
   public void onUpdate(Watchable w, String strProperty,
         Object oldVal, Object newVal) {
      //// eliminate circular references
      removeWatcher(parent);

      Iterator iter = getOutgoingArrows().iterator();
      while (iter.hasNext()) {
         Arrow arrow = (Arrow)iter.next();

         // HACK: call onUpdate() manually. We can pass null for the last
         // three args since they aren't being used. HACK HACK
         arrow.onUpdate(this, null, null, null);
      }
   }

   //-------------------------------------------------------------------------

   public void onDelete(Watchable w) {
      if (w != parent) {
         super.onDelete(w);
      }
   } // of method

   //===   WATCH METHODS   =====================================================
   //===========================================================================

    public void setTransparency(int transparency){

	GraphicalObject gob = getContents();
	if (gob instanceof DenimSketchContents){
	    ((DenimSketchContents)gob).setTransparency(transparency);
	}
    }
    

	 
   //----------------------------------------
   
   /**
    * clear all references hold by this object (In the namespace of this class)
    */
   
   public void deepClear() {
      super.deepClear();
      contents = null;
      parent = null;
      origStyle = null;
   }      
   
   public GraphicalObjectCollection getStates() {
	   return type.empty;
   }
   
   public boolean isHTMLConvertible() {
       return false;
   }

} // of class

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
