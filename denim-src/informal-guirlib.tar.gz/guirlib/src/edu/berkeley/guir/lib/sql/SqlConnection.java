//// See bottom of file for software license
package edu.berkeley.guir.lib.sql;

import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Some common methods for connecting to SQL.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version GUIRLib Dec 31 2003 JIH
 */
public class SqlConnection {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * What JDBC driver to use, currently mysql.
     */
    private static final String JDBC_DRIVER_CLASS = "com.mysql.jdbc.Driver";

    /**
     * Name of the JDBC driver, used in generating the URL.
     */
    private static final String JDBC_DRIVER_NAME  = "mysql";

    //----------------------------------------------------------------

    private static final String DEFAULT_HOST     = "localhost";
    private static final String DEFAULT_USER     = "root";
    private static final String DEFAULT_PASSWORD = "";

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    Connection        con;                          // our jdbc connection
    String            strHost     = DEFAULT_HOST;   // "localhost", "abc.com:80"
    String            strUser     = DEFAULT_USER;
    String            strPassword = DEFAULT_PASSWORD;
    String            strDatabase = "";

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   ACCESSOR / MODIFIER METHODS   ======================================

    /**
     * Set before calling openConnection().
     * Otherwise no effect.
     * @param aHost ex. "localhost" or "abc.com:80"
     */
    public void setHost(String aHost) {
        strHost = aHost;
    } // of method

    public String getHost() {
        return (strHost);
    } // of method

    //----------------------------------------------------------------

    /**
     * Set before calling openConnection().
     * Otherwise no effect.
     * @param aUser is a user, ex. "root"
     */
    public void setUser(String aUser) {
        strUser = aUser;
    } // of method

    public String getUser() {
        return (strUser);
    } // of method

    //----------------------------------------------------------------

    /**
     * Set before calling openConnection().
     * Otherwise no effect.
     * @param aPassword is a password, ex. "" means empty password
     */
    public void setPassword(String aPassword) {
        strPassword = aPassword;
    } // of method

    public String getPassword() {
        return (strPassword);
    } // of method

    //----------------------------------------------------------------

    /**
     * Set what database to use (ie what database at the server to use,
     * similar to the USE sql statement).
     * Set before calling openConnection().
     * Otherwise no effect.
     */
    public void setDatabase(String aDatabase) {
        strDatabase = aDatabase;
    } // of method

    public String getDatabase() {
        return (strDatabase);
    } // of method

    //===   ACCESSOR / MODIFIER METHODS   ======================================
    //==========================================================================




    //==========================================================================
    //===   DATABASE METHODS   =================================================

    /**
     * Only useful after connecting.
     */
    public Connection getConnection() {
        return (con);
    } // of method

    //===   DATABASE METHODS   =================================================
    //==========================================================================




    //==========================================================================
    //===   DATABASE CONNECTION METHODS   ======================================

    /**
     * Connect to the db.
     * Call this before adding data.
     *
     * @throws ClassNotFoundException on cannot find JDBC driver error
     * @throws InstantiationException on cannot instantiate JDBC driver
     * @throws IllegalAccessException
     * @throws SQLException           on other errors (including connect error)
     */
    public void openConnection() 
        throws ClassNotFoundException, 
               InstantiationException, 
               IllegalAccessException,
               ConnectException,
               SQLException {

        //// 1. Load up the JDBC driver.
        Class.forName(JDBC_DRIVER_CLASS).newInstance();

        //// 2. Setup the connection.
        con = DriverManager.getConnection(generateJdbcUrl());

        //// 3. Callback.
        onOpenConnection();
    } // of method

    /**
     * Can override this method to do something after a connection
     * has been established.
     */
    protected void onOpenConnection() {
    } // of method

    //----------------------------------------------------------------

    /**
     * Close our connection to the placelab db.
     * Call this after done adding data.
     *
     * @throws SQLException on disconnect error
     */
    public void closeConnection() 
        throws SQLException {

        con.close();
    } // of method

    /**
     * Can override this method to do something after a connection
     * has been closed.
     */
    protected void onCloseConnection() {
    } // of method

    //----------------------------------------------------------------

    /**
     * Generate the JDBC URL. Internal use only.
     */
    protected String generateJdbcUrl() {
        return (
            "jdbc:"      + JDBC_DRIVER_NAME + 
            "://"        + getHost()        + 
            "/"          + getDatabase()    + 
            "?user="     + getUser()        + 
            "&password=" + getPassword()
        );
    } // of method

    //===   DATABASE CONNECTION METHODS   ======================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2003 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
