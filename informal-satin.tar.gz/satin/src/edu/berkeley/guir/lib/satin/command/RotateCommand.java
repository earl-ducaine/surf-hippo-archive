//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import edu.berkeley.guir.lib.satin.objects.*;
import java.awt.geom.*;

/**
 * Rotate a GraphicalObject.
 * <P>
 * Here is an example of how to rotate (around the specified point) 1 radian 
 * on the Sheet:
 * <CODE>
 * class MenuRotateRightListener implements ActionListener {
 *    public void actionPerformed(ActionEvent evt) {
 *       Point pt = new Point(cmdsubsys.getAbsoluteLastXLocation(),
 *                            cmdsubsys.getAbsoluteLastYLocation());
 *       cmdqueue.doCommand(new RotateCommand(TestSheet.this, 1,
 *             cmdsubsys.getAbsoluteLastXLocation(),
 *             cmdsubsys.getAbsoluteLastYLocation()));
 *    } // of actionPerformed
 * } // inner class
 * </CODE>
 *
 * <P>
 * Here is an example of how to rotate the selected objects (around the
 * specified point) 1 radian:
 * <CODE>
 * class MenuRotateSelObjRightListener implements ActionListener {
 *    public void actionPerformed(ActionEvent evt) {
 *       GraphicalObjectCollection gobs;
 *       GraphicalObject           gob;
 *       Iterator                  it;
 *
 *       gobs = cmdsubsys.getSelectedGraphicalObjects();
 *       it   = gobs.getForwardIterator();
 *
 *       while (it.hasNext()) {
 *          gob = (GraphicalObject) it.next();
 *          cmdqueue.doCommand(new RotateCommand(gob, 1,
 *             cmdsubsys.getLocalLastXLocation(gob.getParentGroup()),
 *             cmdsubsys.getLocalLastYLocation(gob.getParentGroup())));
 *       }
 *    }
 * }
 * </CODE>
 *
 *
 *
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jul 15 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class RotateCommand
   extends ApplyTransformationCommand {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -1771445944312942381L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   float  x;
   float  y;
   float  theta;

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Rotate around the center of the specified GraphicalObject.
    */
   public RotateCommand(GraphicalObject gob, double theta) {
      this(gob, theta, gob.getWidth2D(COORD_REL)/2, 
                       gob.getHeight2D(COORD_REL)/2);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Rotate around the specified point in the specified GraphicalObject's
    * relative coordinate space (ie gob's parent coordinate space).
    *
    * @param gob   is the GraphicalObject to rotate.
    * @param theta is the amount to rotate (in radians).
    * @param x     is the coordinate to rotate around, in relative coordinates
    *              (ie gob's parent's coordinate space).
    * @param y     is the coordinate to rotate around, in relative coordinates
    *              (ie gob's parent's coordinate space).
    */
   public RotateCommand(GraphicalObject gob, double theta, double x, double y) {
      super(gob, AffineTransform.getRotateInstance(theta, x, y));
      this.theta = (float) theta;
      this.x     = (float) x;
      this.y     = (float) y;
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      return ("rotate (rotate: " + theta + " x:" + x + " y:" + y + ")");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================

} // of class RotateCommand

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
