package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that changes the index of a page.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  12-14-2004 James Lin
 *                               Created SetPageIndexCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 12-14-2004
 */
public class SetPageIndexCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final Page page;
   private final int newIndex;
   private int oldIndex;
   
   /**
    * Constructs the command.
    *  
    * @param page the page whose index will be changed
    * @param newIndex the new index of the page
    */      
   public SetPageIndexCommand(
      final Page page,
      final int newIndex) {

      this.page = page;
      this.newIndex = newIndex;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Set index of " + page + " to " + newIndex;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      final Dialog dialog = page.getDialog();
      oldIndex = dialog.indexOf(page);
      dialog.setIndex(newIndex, page);
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      page.getDialog().setIndex(oldIndex, page);
   }
}
