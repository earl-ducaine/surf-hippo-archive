package edu.berkeley.guir.lib.satin.objects;

import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import javax.swing.*;

/**
 * A "framed patch," which has window-like behaviors: rectangular,
 * resizable borders, draggable title bars.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-23-2000 James Lin
 *                               Created FramedPatch
 *             1.1.0  08-13-2001 James Lin
 *                               Split into SATIN and DENIM classes
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 02-23-2000
 */
public class FramedPatch 
   extends PatchImpl {

   //===========================================================================
   //===   CONSTANTS  ==========================================================
   
   private static final int BORDER_THICKNESS = 5;
   private static final int BORDER_INSET = BORDER_THICKNESS / 2;
   private static final int TITLEBAR_HEIGHT = 20;
   private static final int TITLEBAR_CLOSEICON_OFFSET = 5;
   private static final int TITLEBAR_TEXTOFFSET_X = 5;
   private static final int TITLEBAR_TEXTOFFSET_Y = 15;
   
   private static final BasicStroke thinStroke =
      new BasicStroke(1f, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
   
   private static final BasicStroke thickStroke =
      new BasicStroke(BORDER_THICKNESS, BasicStroke.CAP_ROUND,
                      BasicStroke.JOIN_ROUND);

   //===   CONSTANTS  ==========================================================
   //===========================================================================

   //===========================================================================
   //===   INSTANCE VARIABLES ==================================================
   
   private String title;
   private boolean showTitleBar = true;
   private boolean showCloseButton = true;
   private boolean titleIsEditable = false;
   private FontRenderContext fontRenderContext;
   
   private double lastX;
   private double lastY;
   protected boolean closePressed = false;
   protected boolean editableTitlePressed = false;

   //===   INSTANCE VARIABLES  =================================================
   //===========================================================================

   //===========================================================================
   //===   INNER CLASSES   =====================================================
   
   /**
    * Not used. Supposed to be used for semantic zooming, where the framed
    * patch would collapse into its title bar at high zoom levels.
    */
   class FramedPatchIconView extends SemanticZoomViewImpl {
      public FramedPatchIconView (GraphicalObject gob) {
         /*
         setDisplayRange(DenimUtils.getAbsScaleFactorAt(gob, OVERVIEW_SCALE_FACTOR),
         DenimUtils.getAbsScaleFactorAt(gob, SITEMAP_SCALE_FACTOR));
         */
         setDisplayRange(0.0, 100.0);
      }

      public void render(SatinGraphics g) {
         // Calc some constants
         double scale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                          FramedPatch.this.getSheet());
         int patchWidth = (int)getWidth2D(COORD_LOCAL);
         
         // Create a titlebar rectangle
         Style s = new Style();
         s.setDrawColor(new Color(102, 102, 153));
         s.setFillColor(new Color(204, 204, 255));
         s.setDrawStroke(thickStroke);
         g.pushStyle(s);
         g.fillRect(0,0,patchWidth,(int)(TITLEBAR_HEIGHT/scale));
         g.popStyle();

         // Create a titlebar font
         Font origFont = g.getFont();
         Font defaultTitleFont = UIManager.getFont("InternalFrame.font");
         Font titleFont = defaultTitleFont.deriveFont
            (defaultTitleFont.getSize2D() / (float)scale);
         g.setFont(titleFont);
         g.drawString(title, (int)(TITLEBAR_TEXTOFFSET_Y/scale), (int)(TITLEBAR_TEXTOFFSET_Y/scale));
         g.setFont(origFont);
      }
      
      public Object clone() {
         return this;
      }
   }

   
   /**
    * Not used. Supposed to be used for semantic zooming, where different
    * views would be used at different zoom levels.
    */
   class FramedPatchMultiView extends SemanticZoomMultiViewImpl {
      public FramedPatchMultiView (View v1, View v2) {
         add(v1);
         add(v2);
      }
   }
   

   //===   INNER CLASSES   =====================================================
   //===========================================================================

   
   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Makes a framed patch with no boundary.
    */
   public FramedPatch() {
      super();
      title = "";
      commonInit();
   } // of constructor

   //-----------------------------------------------------------------
   
   /**
    * Makes a framed patch with the specified boundary.
    */
   public FramedPatch(Rectangle2D rect) {
      super(rect);
      title = "";
      commonInit();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Makes a framed patch containing the given patch with the given title.
    */
   public FramedPatch(Patch patch, String title) {
      super(new Rectangle2D.Double
         (patch.getBounds2D(COORD_LOCAL).getX() - BORDER_INSET,
          patch.getBounds2D(COORD_LOCAL).getY() - BORDER_INSET,
          patch.getBounds2D(COORD_LOCAL).getWidth() + BORDER_THICKNESS,
          patch.getBounds2D(COORD_LOCAL).getHeight() + BORDER_THICKNESS)); 
      commonInit();
      
      patch.moveTo(COORD_REL, BORDER_INSET, BORDER_INSET);
      this.addToFront(patch, KEEP_REL_POS);
      
      this.title = title;
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInit() {
      this.getStyleRef().setFillColor(new Color(255, 255, 255, 64));
      this.getStyleRef().setDrawColor(new Color(102, 102, 153));
      this.getStyleRef().setDrawStroke(thickStroke);

      /*
      // Create the multiview
      View v = new FramedPatchMultiView (new FramedPatchIconView(content),
      new FramedPatchComponentView(content));
      setView(v);
      */
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================


   //===========================================================================
   //===   REVISED RENDER AND DAMAGE METHODS   =================================
   
   /**
    * Gets the font which is used to render the title.
    */
   protected Font getTitleFont() {
      double scale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                       this.getSheet());
      Font defaultTitleFont = UIManager.getFont("InternalFrame.titleFont");
      if (defaultTitleFont != null) {
         Font titleFont = defaultTitleFont.deriveFont
            (defaultTitleFont.getSize2D() / (float)scale);
         return titleFont;
      }
      else {
         return null;
      }
   }
   
   /**
    * This should become unnecessary once SATIN's sticky mechanism is changed.
    */
   protected void superRender(SatinGraphics g) {
      super.defaultRender(g);
   }

   //-----------------------------------------------------------------
   
   protected void defaultRender(SatinGraphics g) {
      super.defaultRender(g);
      
      if (showTitleBar) {
         // Calc some constants
         double scale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                          this.getSheet());
         int patchWidth = (int)getWidth2D(COORD_LOCAL);
      
         // Create a titlebar rectangle/scale
         Style s = new Style();
         s.setDrawColor(new Color(102, 102, 153));
         s.setFillColor(new Color(204, 204, 255));
         s.setDrawStroke(thickStroke);
         g.pushStyle(s);
         g.fillRect(0,0,patchWidth,(int)(TITLEBAR_HEIGHT/scale));
         g.popStyle();

         if (showCloseButton) {
            // Create a titlebar close icon
            s = new Style();
            s.setFillColor(new Color(180, 180, 180));
            s.setDrawStroke(thickStroke);
            g.pushStyle(s);
            int sideSize = (int)((TITLEBAR_HEIGHT - 2*TITLEBAR_CLOSEICON_OFFSET)/scale);
            int startX = (int)(patchWidth - sideSize - TITLEBAR_CLOSEICON_OFFSET/scale);
            int startY = (int)(TITLEBAR_CLOSEICON_OFFSET/scale);
            //g.fillRect(startX, startY, sideSize, sideSize);
            g.popStyle();

            s.setDrawColor(new Color(0, 0, 0));
            s.setDrawStroke(thinStroke);
            g.pushStyle(s);
            g.draw(new Line2D.Double(startX, startY, (startX+sideSize), (startY+sideSize)));
            g.draw(new Line2D.Double(startX, (startY+sideSize), (startX+sideSize), startY));
            g.popStyle();
         }
      
         // Create a titlebar font
         Font origFont = g.getFont();
         Font titleFont = getTitleFont();
         if (titleFont != null) {
            g.setFont(titleFont);
         }
         fontRenderContext = g.getFontRenderContext();
         //System.out.println("bounding box for " + title + ": " +
         //                   titleFont.getStringBounds(title, fontRenderContext));
         g.drawString(title,
                      (int)(TITLEBAR_TEXTOFFSET_X/scale),
                      (int)(TITLEBAR_TEXTOFFSET_Y/scale));
         g.setFont(origFont);
      }
   }

   //===   REVISED RENDER AND DAMAGE METHODS   =================================
   //===========================================================================

   //===========================================================================
   //===   ACCESSORS   =========================================================
   
   /**
    * Returns whether the title bar should be drawn.
    */
   public boolean getShowTitleBar() {
      return showTitleBar;
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Sets whether the title bar should be drawn.
    */
   public void setShowTitleBar(boolean flag) {
      showTitleBar = flag;
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Returns whether the close button should be drawn.
    */
   public boolean getShowCloseButton() {
      return showCloseButton;
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Sets whether the close button should be drawn.
    */
   public void setShowCloseButton(boolean flag) {
      showCloseButton = flag;
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Returns whether the title can be edited.
    */
   public boolean isTitleEditable() {
      return titleIsEditable;
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Sets whether the close button should be drawn.
    */
   public void setTitleEditable(boolean flag) {
      titleIsEditable = flag;
   }

   //-----------------------------------------------------------------
   
   /**
    * Returns whether the title bar should be drawn.
    */
   public String getTitle() {
      return title;
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Sets whether the title bar should be drawn.
    */
   public void setTitle(String title) {
      this.title = title;
   }
   
   //===   ACCESSORS   =========================================================
   //===========================================================================


   //===========================================================================
   //===   TITLEBAR METHODS   ==================================================

   /**
    * Returns whether the given point in the framed patch's local coordinates
    * is inside the title bar.
    */
   public boolean isInsideTitleBar(Point2D point) {
      if (showTitleBar) {
         double scale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                          this.getSheet());
         int y = (int) point.getY();

         // We only care about one dimension as the titlebar is as wide
         // as the patch
         if (y < TITLEBAR_HEIGHT/scale) {
            return true;
         } else {
            return false;
         }
      }
      else {
         return false;
      }
   }

   //-----------------------------------------------------------------
   
   /**
    * Returns whether the given point in the framed patch's local coordinates
    * is inside the title bar's close button.
    */
   public boolean isInsideTitleBarCloseButton(Point2D point) {
      if (showTitleBar && showCloseButton) {
         double scale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                          this.getSheet());
         int x = (int) point.getX();
         int y = (int) point.getY();

         int patchWidth = (int)getWidth2D(COORD_LOCAL);
         int sideSize = (int)((TITLEBAR_HEIGHT - 2*TITLEBAR_CLOSEICON_OFFSET)/scale);
         int startX = (int)(patchWidth - sideSize - TITLEBAR_CLOSEICON_OFFSET/scale);
         int startY = (int)(TITLEBAR_CLOSEICON_OFFSET/scale);

         return ((startX <= x) && (x <= startX + sideSize) &&
                 (startY <= y) && (y <= startY + sideSize));
      }
      else {
         return false;
      }
   }

   //-----------------------------------------------------------------
   
   /**
    * Returns whether the given point in the framed patch's local coordinates
    * is inside the title bar's text and the text is editable.
    */
   public boolean isInsideEditableTitle(Point2D point) {
      if (isInsideTitleBar(point) && isTitleEditable()) {
         double scale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                          this.getSheet());
         int x = (int)point.getX();
         return (int)(TITLEBAR_TEXTOFFSET_X/scale) <= x &&
                 x <= ((int)(TITLEBAR_TEXTOFFSET_X/scale) + 
                      getTitleFont().getStringBounds(title, fontRenderContext).getWidth());
      }
      else {
         return false;
      }
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Handles a new stroke inside the title bar.
    */
   public void handleTitleBarNewStroke(NewStrokeEvent evt) {
      TimedStroke stk = evt.getStroke();
      Point2D ptPress = stk.getStartPoint2D(COORD_ABS);

      this.bringToTopLayer();
      
      //// Calculate the diff between where we clicked and the
      //// GraphicalObject's top-left corner.
      lastX = ptPress.getX();
      lastY = ptPress.getY();
      
      Point2D localPt = GraphicalObjectLib.absoluteToLocal(this, ptPress);
      closePressed = isInsideTitleBarCloseButton(localPt);
      editableTitlePressed = isInsideEditableTitle(localPt);
      
      //// If the title is clicked, and the title is editable, then pop up
      //// a dialog box to change the title.
      if (editableTitlePressed) {
         Component root = SwingUtilities.getRoot(this.getSheet());
         String newTitle = JOptionPane.showInputDialog
            (root,
             "Enter the new title:",
             "Rename",
             JOptionPane.QUESTION_MESSAGE);
         if (newTitle != null) {
            setTitle(newTitle);
            damage(SatinConstants.DAMAGE_NOW);
         }
      }
      
      evt.setConsumed();
   } // of handleTitleBarNewStroke

   //-----------------------------------------------------------------

   /**
    * Handles a stroke being updated inside the title bar.
    */
   public void handleTitleBarUpdateStroke(UpdateStrokeEvent evt) {
      if (closePressed || editableTitlePressed) {
         // do nothing -- wait for mouse up
      } else {
         // Move this framed patch.
         TimedStroke stk = evt.getStroke();
         Point2D pt = stk.getEndPoint2D(COORD_ABS);
         
         moveBy(COORD_ABS, pt.getX() - lastX, pt.getY() - lastY);
         
         lastX = pt.getX();
         lastY = pt.getY();
      }
      
      evt.setConsumed();
      evt.setShouldRender(false);
   } // of handleTitleBarUpdateStroke

   //-----------------------------------------------------------------

   /**
    * Handles a stroke being completed inside the title bar.
    */
   public void handleTitleBarSingleStroke(SingleStrokeEvent evt) {
      // Set event as consumed, since we already used it.
      evt.setConsumed();
      evt.setShouldRender(false);

      if (closePressed) {
         // If the mouse is still inside the close button then close window
         TimedStroke stk = evt.getStroke();
         Point2D pt = stk.getEndPoint2D(COORD_ABS);
         if (isInsideTitleBarCloseButton(GraphicalObjectLib.absoluteToLocal(this, pt))) {
            getSheet().remove(this);
         }
      }
   } // of handleTitleBarSingleStroke

   //===   TITLEBAR METHODS   ==================================================
   //===========================================================================
   
} // of class



//==============================================================================

/*
  Copyright (c) 2000 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
