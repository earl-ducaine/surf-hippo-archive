package edu.berkeley.guir.damask.connection;

import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;

/** 
 * Represents the endpoint of a connection.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  12-20-2003 James Lin
 *                               Created ConnectionEndpoint
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 12-20-2003
 */
public interface ConnectionEndpoint extends InteractionElement {
   
   /**
    * Returns the page that this endpoint is in, from the given device type's
    * perspective. If the endpoint is a page, then returns itself.
    */
   Page getPage(DeviceType deviceType);
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns the dialog that this endpoint is in.
    */
   Dialog getDialog();
   
   //---------------------------------------------------------------------------
   
   /**
    * Takes a rectangle in the object's local coordinates and returns the
    * rectangle transformed into global coordinates. The original rectangle
    * is untouched.
    */
   Rectangle2D localToGlobal(DeviceType deviceType, Rectangle2D rect);
   
   //---------------------------------------------------------------------------
   
   /**
    * Takes a rectangle in global coordinates and returns the rectangle
    * transformed into the object's local coordinates. The original rectangle
    * is untouched.
    */
   Rectangle2D globalToLocal(DeviceType deviceType, Rectangle2D rect);
}
