//// See bottom of source code for software license

package edu.berkeley.guir.denim.interpreters;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.interpreter.InterpreterImpl;
import edu.berkeley.guir.lib.satin.stroke.*;

/**
 * A special interpreter that provides feedback when no other interpreters
 * are able/willing to handle a stroke
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-08-2001 miksen
 *                    Created FeedbackInterpreter.
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~miksen/">Michael Thomsen</A> (
 *         <A HREF="mailto:miksen@cs.berkeley.edu">miksen@cs.berkeley.edu</A> )
 */
public class FeedbackInterpreter
    extends InterpreterImpl
    implements DenimConstants {

    //===========================================================================
    //===   CLASS VARIABLES   ===================================================

    private GraphicalObjectGroup mySheet;
    private Timer feedbackTimer;

    //===   CLASS VARIABLES   ===================================================
    //===========================================================================



    //===========================================================================
    //===   INSTANCE VARIABLES   ================================================

    private DenimSheet sheet;

    //===   INSTANCE VARIABLES   ================================================
    //===========================================================================



    //===========================================================================
    //===   CONSTRUCTORS   ======================================================

    public FeedbackInterpreter(DenimSheet sheet) {
        super();
        this.sheet = sheet;
        mySheet = sheet;
        commonInitializations();
    } // of constructor

    //-----------------------------------------------------------------

    private void commonInitializations() {
        setName("Feedback Interpreter");
    } // of commonInitializations

    //===   CONSTRUCTORS   ======================================================
    //===========================================================================


    //===========================================================================
    //===   STROKE INTERPRETER METHODS   ========================================

    class FeedbackTimerAction
   implements ActionListener {

   public javax.swing.Timer theTimer;
   public TimedStroke theGestureStroke;
   public TimedStroke theDotStroke;
   public DenimSheet theSheet;
   public int feedbackCount = 4;
   public Color blink1, blink2;

   public FeedbackTimerAction (javax.swing.Timer aTimer,
                TimedStroke aGestureStroke, TimedStroke aDotStroke,
                DenimSheet aSheet, Color color1, Color color2) {
       super();
       theTimer = aTimer;
       theGestureStroke = aGestureStroke;
       theDotStroke = aDotStroke;
       theSheet = aSheet;
       blink1 = color1;
       blink2 = color2;
   }

   public void actionPerformed(ActionEvent aEvt) {
       switch (feedbackCount) {
       case 4:
       case 2:
      theGestureStroke.getStyleRef().setDrawColor(blink2);
      theDotStroke.getStyleRef().setDrawColor(blink2);
      theGestureStroke.damage(DAMAGE_NOW);
      theDotStroke.damage(DAMAGE_NOW);
      feedbackCount = feedbackCount - 1;
      break;
       case 3:
       case 1:
      theGestureStroke.getStyleRef().setDrawColor(blink1);
      theDotStroke.getStyleRef().setDrawColor(blink1);
      theGestureStroke.damage(DAMAGE_NOW);
      theDotStroke.damage(DAMAGE_NOW);
      feedbackCount = feedbackCount - 1;
      break;
       case 0:
      theSheet.remove(theGestureStroke);
      theSheet.remove(theDotStroke);
      theTimer.setRepeats(false);
      break;
       }
   }
    };

    /**
     * Change how the interpreter behaves, depending on the zoom level.
     */
    public void handleSingleStroke(SingleStrokeEvent evt) {
   // We should only do feedback if the current input isn't a tap
   TimedStroke stk = evt.getStroke();
        if (!StrokeLib.isTap(stk)) {
       // Set up the styles for the feedback stroke
       Style feedbackStyle = ((Sheet)mySheet).getRightCurrentStyle();

       final Color blink1 = new Color(255, 0, 0, feedbackStyle.getDrawColor().getAlpha());
       final Color blink2 = feedbackStyle.getDrawColor();
       feedbackStyle.setDrawColor(blink1);

       // Create a feedback stroke showing the input gesture
       TimedStroke feedbackStroke = new TimedStroke(evt.getStroke().getPolygon2D(COORD_ABS));
       feedbackStroke.setStyle(feedbackStyle);
       mySheet.add(feedbackStroke, GraphicalObjectGroup.KEEP_ABS_POS);

       // Create a small circular stroke denoting the beginning
       TimedStroke dotStroke = DenimUtils.getDotFeedbackStroke(evt.getStroke().getStartPoint2D(COORD_ABS));
       mySheet.add(dotStroke, GraphicalObjectGroup.KEEP_ABS_POS);
       dotStroke.setStyle(feedbackStyle);

       // Set a timer to make the feedback blink
       Timer theTimer = new Timer(300, null);
       theTimer.addActionListener(new FeedbackTimerAction(theTimer, feedbackStroke, dotStroke,
                            sheet, blink1, blink2));
       theTimer.start();
   }

    } // of handleSingleStroke

    //===========================================================================
    //===   CLONE   =============================================================

    /**
     * Clones this interpreter.
     */
    public Object clone() {
        return (new FeedbackInterpreter(this.sheet));
    } // of clone

    //===   CLONE   =============================================================
    //===========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 1999-2001 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
