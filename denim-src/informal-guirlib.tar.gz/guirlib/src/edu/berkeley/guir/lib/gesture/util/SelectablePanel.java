package edu.berkeley.guir.lib.gesture.util;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Color;
import java.awt.Point;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.*;
import java.beans.*;
import java.util.*;

/* todo:

- should clicking on a widget deselect it if it's the only selected widget?

*/

/* known bugs:
- if the containee accepts mouse presses (like a JButton), our
  listener never gets the event.  Probably have to override
  processMouseEvent in SelectablePanel (try override in python and
  see?)
 */

/** This class allows its children to be selected.  By default, it
    uses the
    javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION mode.
    WARNING: This widget sets the preferred size of its containees.
    This may prevent them from resizing properly if their contents
    change size.  To fix this, setPreferredSize(null) on containees
    before calling revalidate().
*/
public class SelectablePanel extends JPanel
  implements ListSelectionListener {
  public static String SELECTABLE_PROP = "selectable";
  protected ListSelectionModel selectionModel = null;
  protected PropertyChangeSupport propChangeSupport;
  public static final int DEFAULT_BORDER_WIDTH = 3;
  public static final Border DEFAULT_SELECTED_BORDER = BorderFactory.
    createMatteBorder(DEFAULT_BORDER_WIDTH, DEFAULT_BORDER_WIDTH,
		      DEFAULT_BORDER_WIDTH, DEFAULT_BORDER_WIDTH,
		      Color.black);
  public static final Border DEFAULT_UNSELECTED_BORDER = null;
  protected Border selectedBorder = DEFAULT_SELECTED_BORDER;
  protected Border unselectedBorder = DEFAULT_UNSELECTED_BORDER;
  protected MouseListener selectMouseListener = getMouseListener();
  protected boolean isSelectable = false;
  
  public SelectablePanel()
  {
    super();
    propChangeSupport = new PropertyChangeSupport(this);
    setSelectable(true);
    setSelectionModel(new DefaultListSelectionModel());
    selectionModel.
      setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
  }

  public void setSelectable(boolean on)
  {
    if (on != isSelectable) {
      isSelectable = on;
      if (on) {
	addMouseListener(selectMouseListener);
      }
      else {
	removeMouseListener(selectMouseListener);
      }
      propChangeSupport.firePropertyChange(SELECTABLE_PROP, !on, on);
    }
  }

  public boolean isSelectable()
  {
    return isSelectable;
  }
  
  public ListSelectionModel getSelectionModel()
  {
    return selectionModel;
  }

  public void setSelectionModel(ListSelectionModel model)
  {
    if (model != selectionModel) {
      if (selectionModel != null) {
	selectionModel.removeListSelectionListener(this);
      }
      selectionModel = model;
      if (selectionModel != null) {
	selectionModel.addListSelectionListener(this);
      }
    }
  }

  /** returns the selected widgets (as passed to SelectablePanel in
      add(Component)) */
  public List getSelectedObjects()
  {
    int numComponents = getComponentCount();
    ArrayList list = new ArrayList();
    for (int i = 0; i < numComponents; i++) {
      if (selectionModel.isSelectedIndex(i)) {
	list.add(getContainee(i));
      }
    }
    return list;
  }

  public void setSelectedBorder(Border b)
  {
    //todo: make bound
    selectedBorder = b;
  }

  public Border getSelectedBorder()
  {
    return selectedBorder;
  }
  
  public void setUnselectedBorder(Border b)
  {
    //todo: make bound
    unselectedBorder = b;
  }
  
  public Border getUnselectedBorder()
  {
    return unselectedBorder;
  }
  
  public void selectToChild(Component child)
  {
    int childIndex = awt.getChildIndex(this, child);
    selectionModel.setLeadSelectionIndex(childIndex);
  }

  public void toggleSelection(Component child)
  {
    int childIndex = awt.getChildIndex(this, child);
    if (selectionModel.isSelectedIndex(childIndex)) {
      selectionModel.removeSelectionInterval(childIndex, childIndex);
    }
    else {
      selectionModel.addSelectionInterval(childIndex, childIndex);
    }
  }

  public void setSelection(Component child)
  {
    int childIndex = awt.getChildIndex(this, child);
    //System.out.println("setting child #" + childIndex);
    selectionModel.setSelectionInterval(childIndex, childIndex);
  }

  protected void addImpl(Component comp,
			 Object constraints,
			 int index)
  {
    SingletonContainer container = new SingletonContainer(comp);
    super.addImpl(container, constraints, index);
    // -1 means to add to end, but ListSelectionModel doesn't
    // understand that
    if (index == -1) {
      index = getComponentCount()-1;
    }
    selectionModel.insertIndexInterval(index, 1, true);
  }

  public Component getContainee(int index)
  {
    return ((SingletonContainer) getComponent(index)).getContainee();
  }
  
  protected int getContaineeIndex(Component containee)
  {
    for (int i = 0; i < getComponentCount(); i++) {
      SingletonContainer sc = (SingletonContainer) getComponent(i);
      if (containee == sc.getContainee()) {
	return i;
      }
    }
    return -1;
  }
  
  public void remove(Component comp)
  {
    int index = awt.getChildIndex(this, comp);
    if (index == -1) {
      index = getContaineeIndex(comp);
    }
    remove(index);
  }

  public void remove(int index)
  {
    selectionModel.removeIndexInterval(index, index);
    super.remove(index);
  }

  public void removeAll()
  {
    int componentCount = getComponentCount();
    if (componentCount > 0) {
      selectionModel.removeIndexInterval(0, componentCount-1);
    }
    super.removeAll();
  }
  
  /** to implement ListSelectionListener */
  public void valueChanged(ListSelectionEvent e)
  {
    int maxIndex = Math.min(e.getLastIndex(), getComponentCount()-1);
    /*
    System.out.println("valueChanged: " + e.getLastIndex() + "\t" +
		       (getComponentCount()-1));
    */
    for (int i = e.getFirstIndex(); i <= maxIndex; i++) {
      Component comp = getComponent(i);
      if (comp instanceof JComponent) {
	((JComponent) comp).setBorder(selectionModel.isSelectedIndex(i) ?
				      selectedBorder : unselectedBorder);
	((JComponent) comp).setPreferredSize(null);
      }
    }
    revalidate();
  }

  protected MouseListener getMouseListener()
  {
    return new SelectMouseListener();
  }
  
  protected class SelectMouseListener extends MouseAdapter {
    public SelectMouseListener()
    {
      super();
    }
    
    public void mouseClicked(MouseEvent e)
    {
      /*
      System.out.println("SelectablePanel got " + e.getClickCount() +
			 " mouse click(s) [" +
			 ((Container) e.getComponent()).getComponentCount()
			 + " children]");
      */
      if (e.getClickCount() == 1) {
	Point location = e.getPoint();
	Component child = SelectablePanel.this.getComponentAt(location);
	int modifiers = e.getModifiers() &
	  (InputEvent.SHIFT_MASK | InputEvent.CTRL_MASK | InputEvent.ALT_MASK);
	switch (modifiers) {
	case MouseEvent.SHIFT_MASK:
	  // select range
	  SelectablePanel.this.selectToChild(child);
	  break;
	case MouseEvent.CTRL_MASK:
	  // (de)select individual ones
	  SelectablePanel.this.toggleSelection(child);
	  break;
	case MouseEvent.ALT_MASK:
	  break;
	default:
	  // no modifiers
	  SelectablePanel.this.setSelection(child);
	  break;
	}
      }
    }
  }

  public class SingletonContainer extends JPanel {
    private Component containee;
    
    public SingletonContainer(Component containee)
    {
      super(new BorderLayout());
      setContainee(containee);
    }

    public void setContainee(Component containee)
    {
      SingletonContainer.this.removeAll();
      SingletonContainer.this.add(containee, BorderLayout.CENTER);
      this.containee = containee;
    }

    public Component getContainee()
    {
      return this.getComponent(0);
    }
  }
}
