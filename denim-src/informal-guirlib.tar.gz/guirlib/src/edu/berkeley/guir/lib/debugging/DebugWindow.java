//// See bottom of source code for software license.
package edu.berkeley.guir.lib.debugging;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * A window which allows output for debugging purposes.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 02 2002
 */
public class DebugWindow 
   extends JFrame {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   public static final String PROMPT = "";

   //===   CONSTANTS   =========================================================
   //===========================================================================




   //===========================================================================
   //===   NONLOCAL INSTANCE VARIABLES   =======================================

   private static JTextArea    text   = new JTextArea(50, 90);

   //===   NONLOCAL INSTANCE VARIABLES   =======================================
   //===========================================================================




   //===========================================================================
   //===   INNER CLASS   =======================================================

   /**
    * Listens for when we press the button. Clears the text area.
    */
   class DebugWindowButtonListener implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         clear();
      } // of method
   } // of inner class

   //-----------------------------------------------------------------

   /**
    * Listens for when we close the window. Clears out old text.
    */
   class DebugWindowListener extends WindowAdapter {
      public void windowClosing(WindowEvent evt) {
         clear();
      } // of method

      public void windowClosed(WindowEvent evt) {
         clear();
      } // of method
   } // of inner class

   //===   INNER CLASS   =======================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Default constructor.
    */
   public DebugWindow() {
      this("Application");
      newPrompt();
      text.append("");
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Construct a DebugWindow with the specified frame name.
    *
    * @param strAppName is the name of the frame in the title.
    */
   public DebugWindow(String strAppName) {
      super(strAppName + " Debugging Window");

      //// 1. Setup the debugging window.
      this.setSize(600, 800);
      this.getContentPane().setLayout(new BorderLayout());
      this.getContentPane().add("Center", new JScrollPane(text));
      text.setAutoscrolls(true);
      this.addWindowListener(new DebugWindowListener());

      //// 2. Add a button to clear the screen.
      JButton b = new JButton("Clear Screen");
      this.getContentPane().add("South", b);
      b.addActionListener(new DebugWindowButtonListener());

      //// 3. Set the font to be sans serif monospaced.
      this.setFont(new Font("Monospaced", Font.PLAIN, 12));
      text.setFont(new Font("Monospaced", Font.PLAIN, 12));

      //// 4. Make ourself visible.
      show();
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   private void updatePosition() {
      text.setCaretPosition(text.getText().length());
   } // of updatePosition

   //-----------------------------------------------------------------

   /**
    * Stick a new prompt on the debug window.
    */
   private void newPrompt() {
      text.append("\n" + PROMPT);
   } // of newPrompt

   //-----------------------------------------------------------------

   /**
    * Close the TextWindow.
    */
   public void close() {
      dispose();
   } // of close

   //-----------------------------------------------------------------

   /**
    * Clear the text in the Text Area.
    */
   public void clear() {
      text.setText("");
      updatePosition();
   } // of clear

   //-----------------------------------------------------------------

   /**
    * Add some text in the Text Area.
    *
    * @param obj is the text to add to the Text Area.
    */
   public void print(Object obj) {
      if (isVisible() == true) {
         text.append(obj.toString());
         updatePosition();
      }
   } // of print

   //-----------------------------------------------------------------

   /**
    * Add a blank line.
    */
   public void println() {
      if (isVisible() == true) {
         text.append("\n");
         updatePosition();
      }
   } // of println

   //-----------------------------------------------------------------

   /**
    * Add some text in the Text Area with a newline after it.
    *
    * @param obj is the text to add to the Text Area.
    */
   public void println(Object obj) {
      if (isVisible() == true) {
         text.append(obj.toString() + "\n");
         updatePosition();
      }
   } // of println

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   FINALIZER   =========================================================

   /*
    * Ensure that the Frame cleans up after itself.
    */
   public void finalize() {
      dispose();
   } // of finalize

   //===   FINALIZER   =========================================================
   //===========================================================================




   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) {
      DebugWindow dwnd = new DebugWindow();
   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of Class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
