package edu.berkeley.guir.damask.event;

import java.util.EventListener;

/** 
 * The listener interface for receiving events regarding when a property of
 * a piece of content has changed. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-23-2004 James Lin
 *                               Created ContentListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 04-23-2004
 */
public interface ContentListener extends EventListener {

   /**
    * Invoked when a stroke has been added.
    */
   void strokeAdded(ContentEvent e);

   /**
    * Invoked when a stroke has been removed.
    */
   void strokeRemoved(ContentEvent e);

   /**
    * Invoked when the strokes has been changed.
    */
   void strokesChanged(ContentEvent e);

   /**
    * Invoked when the text has been changed.
    */
   void textChanged(ContentEvent e);

   /**
    * Invoked when the image has been changed.
    */
   void imageChanged(ContentEvent e);
   
   /**
    * Invoked when the preferred display mode of a piece of content is changed.
    */
   void preferredDisplayModeChanged(ContentEvent e);
   
   /**
    * Invoked when the prompt text is synchronized with the text. 
    */
   void promptTextIsSyncedWithText(ContentEvent e);
   
   /**
    * Invoked when the prompt text is unsynchronized with the text. 
    */
   void promptTextIsUnsyncedWithText(ContentEvent e);
}
