package edu.berkeley.guir.suede;

//author: srk
// This interface class has all of the methods that a single prompt or response contains regardless of whether it is a script or a node

public interface ElementViewInter
{
   public String getCaption();
   public boolean isPlaying();
   public boolean isRecording();
   public void setAudioDuration(double seconds);
   public void setCaption(String caption);
   public void setPaused();
   public void setTotalTime(double t);
   public void setCurTime(double t);
   public void setPlayable(boolean b);
   public void setPlaying();
   public void setRecording();
   public void setStopped();
}