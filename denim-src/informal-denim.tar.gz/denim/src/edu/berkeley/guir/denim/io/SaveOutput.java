package edu.berkeley.guir.denim.io;

import java.io.*;
import java.util.Date;

/**
 * Logs stdout and stderr to a file so that they can be inspected later.
 * 
 * Based on:
 * http://developer.java.sun.com/developer/TechTips/1999/tt1021.html#tip2
 * 
 *
 * <PRE>
 * Revisions:  1.0.0  10-01-2001  JL
 *                    Created SaveOutput
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 10-01-2001
 */
public class SaveOutput extends PrintStream {
   static OutputStream logfile;
   static String filename;
   static PrintStream oldStdout;
   static PrintStream oldStderr;

   SaveOutput(PrintStream ps) {
      super(ps);
   }

   // Starts copying stdout and 
   // stderr to the file f.
   public static void start(String f) throws IOException {
      filename = f;
      
      // Save old settings.
      oldStdout = System.out;
      oldStderr = System.err;

      // Create or append to the logfile.
      logfile = new PrintStream(
                   new BufferedOutputStream(new FileOutputStream(f, true)));
      
      // Record the date.
      ((PrintStream)logfile).println();
      ((PrintStream)logfile).println("* * * " + new Date());

      // Start redirecting the output.
      System.setOut(new SaveOutput(System.out));
      System.setErr(new SaveOutput(System.err));
   }

   // Restores the original settings.
   public static void stop() {
      System.setOut(oldStdout);
      System.setErr(oldStderr);
      try {
         logfile.close();
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   // PrintStream override.
   public void write(int b) {
      try {
         logfile.write(b);
         logfile.flush();
      } catch (Exception e) {
         e.printStackTrace();
         setError();
      }
      super.write(b);
   }
   
   // PrintStream override.
   public void write(byte buf[], int off, int len) {
      try {
         logfile.write(buf, off, len);
         logfile.flush();
      } catch (Exception e) {
         e.printStackTrace();
         setError();
      }
      super.write(buf, off, len);
   }
}


//==============================================================================

/*
Copyright (c) 2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
