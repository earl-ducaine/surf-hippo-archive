package edu.berkeley.guir.suede;

import javax.sound.sampled.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

// srk: this is the base model class for all node activity in the top area of the screen; the scripts. 
// The two subclasses are 1) for design mode, and 2) transcripts, created during test mode and also viewed in analysis

public abstract class AbstScriptNodeModel implements SSavableElt { 
  final static boolean USER       = false; // this is a green user node
  final static boolean SYSTEM     = true;  // this is an orange system node
 
  final boolean DEBUG = false;
  final boolean SAMPLINGGRAPH = true;  // turns sampling panel on and off

  protected AbstScriptNodeView m_script;  
  private   String             m_label; //the ID of this node for saving to a file
  private   String             m_caption;  //the text this node contains
  private   int                m_scriptnumber  = 0;
  protected SamplingGraph      m_samplingGraph = new SamplingGraph();
  private   CallWhenFinished   m_cwf           = new CallWhenFinished(m_samplingGraph);  
  protected CardSound          m_cardSound     = new CardSound((EndPlayCallbackIF)m_cwf, (EndRecordCallbackIF)m_cwf);  // this stores the audio
  //private   String             m_groupname     = "";
  private   Vector             m_balloons      = new Vector(); //contains elements of type LinkModel
  private   SSavableElt        m_balloonCallingNode = null; //a node that is asking this link to play audio as part of a balloon
  
  private double m_pauseDuration = 0;
  
  public AbstScriptNodeModel(String label) {    
      m_label       = label;
  }
  

  /*public String             getGroupName()                { return m_groupname; }
  public void               setGroupName(String grp)      { m_groupname = grp;  }*/
  
  public AbstScriptNodeView getView()                     { return m_script;                  }
   
  public boolean            getCardType()                 { return m_script.getCardType();    }
  
  public void               setCardType(boolean cardtype) { m_script.setCardType(cardtype);   }
  
  public int                getScriptNumber () {            return m_scriptnumber;            }
  
  public void               setScriptNumber( int snum ) {   m_scriptnumber = snum;            }
  
  public String             getLabel() {                    return m_label;                   }
    
  public void               setLabel(String label) {        m_label = label;                  }
    
  public int                getX() {                        return m_script.getX();           }
  
  public int                getY() {                        return m_script.getY();           }
  
  //public Point              getLocation() {                 return m_script.getLocation();    }
  
  public Container          getParent() {                   return m_script.getParent();      }
  
  public synchronized AudioInputStream getAudio()          { return m_cardSound.getAudio();   }

  public synchronized void  setAudio(AudioInputStream ais) { m_cardSound.setAudio(ais);   
                                                             setPlayable(ais!=null);          }
  
  public String             save(String path)              { return save(path, m_label + ".wav"); }

  public int                getNumBalloons()               { return m_balloons.size();            }
  
  public boolean isBarged = false;
  
  public void playBalloon(int i)  { 
	  if (!isBarged) {
		((LinkModel)m_balloons.get(i)).playBalloon(this);
		//System.out.println("AbstScriptModel...request to play balloon from link: " + i);
  
	  }
  }
  
  public boolean isStopped() {
        return m_cardSound.isStopped();
  }
 
 
   public synchronized void setCallback( CallbackIF callback) {
      m_cwf.setCallback(callback);
   }
  
 
   public synchronized void setAudioDuration() {
      if(m_cardSound.isAvailable()) 
         m_script.setAudioDuration(getDuration());   
   }
    
    
   public synchronized double getDuration() {
       double duration = m_cardSound.getDuration();
       return duration;
   }
    
    
   public synchronized void setPlayable(boolean b) {
      m_script.setPlayable(b);   
   }


  public String getCaption() {
    m_caption = m_script.getCaption();    
    return m_caption;
  }
    
    
  protected void setCaption (String lbl) {
    m_caption = lbl;
    m_script.setCaption(m_caption);   
  }
  

  public void setPauseDuration(double pause) {
	  m_pauseDuration = pause;
  }
  
  public double getPauseDuration() {
	  return m_pauseDuration;
  }
  
  // this method is called only by SuedeModel
  public void fillAudio(String filename) {
    java.io.File fl = new java.io.File(filename); 
    m_cardSound.createAudioInputStream(fl, true);
    setAudioDuration();
    setPlayable(m_cardSound.isAvailable());
  }
  

  public void setBalloons(Vector ball) { 
     // we need to typecheck the elements of the input Vector -- our m_balloons requires LinkModels
     for (int i=0; i<ball.size(); i++) {
		 if (ball.get(i) instanceof  SBalloon) {
			m_balloons.add(((SBalloon)ball.get(i)).getLinkModel());
		 }
		 else if (ball.get(i) instanceof LinkModel) {
			m_balloons.add((LinkModel)ball.get(i));
		 }
        // else do nothing; someone slipped us a bad element
     }
  }
  
  
  public String save(String path, String externalFileName) {
      
        String r = "";
        r = r + "<cardsmall>";
    
        r = r + "<label>";
        r = r + m_label;
        r = r + "</label>";

        //srk: add scriptID (userID)
        
        //srk: if necessary, add node position within transcript
        
        r = r + "<caption>";
        r = r + getCaption();
        r = r + "</caption>";

        r = r + "<scripttype>";
        r = r + getCardType();
        r = r + "</scripttype>";

        
        r = r + "<scriptnumber>";
        r = r + getScriptNumber();
        r = r + "</scriptnumber>";

        
        // walk through each of the audiostreams associated with this card and write them out
        // anything with filename will be read in.
        if(m_cardSound.isAvailable()) {
          
          r = r + "<filename>";
          r = r + externalFileName;
          r = r + "</filename>";
          //System.out.println("AbstScript...saving: " + externalFileName); //RMV
          m_cardSound.saveToFile(path + externalFileName, AudioFileFormat.Type.WAVE);
        }
       

        // only transcript system prompts can have balloons...
        for (int i = 0; i < m_balloons.size(); i++) {
          r = r + "<balloon>";
          r = r + ((LinkModel)m_balloons.get(i)).getLabel();
          r = r + "</balloon>";
        }
        
        r = r + "</cardsmall>";
        
        m_cardSound.saveToFile(path + externalFileName, AudioFileFormat.Type.WAVE);
      
      return r;
    }
    
    
    public void addPlayListener(PlayButton b) {
      b.addActionListener(new PlayListener()); 
    }
    
    
    public void removePlayListener(PlayButton b) {
       // srk: need to remove all play listeners
       // in practice, this method is never called, but it could be
    }
    
    
    public void addRecordListener(RecordButton b) {
      b.addActionListener(new RecordListener()); 
    }
    
    
    public void callWhenBalloonFinished() {
      m_cwf.callmeWhenDonePlaying(); 
    }
   
   
   public void playAudio(CallbackIF callback) {
      setCallback(callback);
      playAudio();
   }

   
   public synchronized void playAudio() {
      m_script.setPlaying();
      setPauseDuration(m_cardSound.getPauseDuration());
      //print out the duration of the pause for analysis
      //System.out.println("card '" + getCaption() + "' has pause: " + m_pauseDuration);
      
      boolean audioToPlay = m_cardSound.playAudio();
      if (audioToPlay) {
	  if (SAMPLINGGRAPH) {
	      m_samplingGraph.startPlay(m_cardSound);
	  }
      } else { 
	  setStopped();
          // I added this line thinking it would fix things...
          // in test mode prompts w/. audio were stopping the test...
          // with this call in it sometimes works and sometimes throws an exception...
          // Maybe it's thread related? I'll look at it after I redo the model/view code.
          //m_cwf.callmeWhenDonePlaying();
      }
   }
   
   /**
    * The link model calls this on the most recently recorded user transcript node when playing a balloon.
    */
   public synchronized void playBalloonAudio(SSavableElt balloonCallingNode) {
      m_balloonCallingNode = balloonCallingNode;
      playAudio();
   }
   
    public synchronized void recordAudio(boolean isLink, double systNodeDuration) {
      m_script.setRecording();
      m_cardSound.recordAudio(isLink, systNodeDuration);
      if (SAMPLINGGRAPH) m_samplingGraph.startCapture(m_cardSound);
    }
    
    /*public synchronized void recordAudio(boolean isLink, double systNodeDuration, boolean pauseElim) {
	m_script.setRecording();
	m_cardSound.recordAudio(isLink, systNodeDuration, pauseElim);
	if (SAMPLINGGRAPH) m_samplingGraph.startCapture(m_cardSound);
	}*/
    
   public void setStopped() {
       ////1. If there are balloons, do not play them either. we're stopped.
      m_cwf.stopAllAudio();

      ////2. Tell the view we're stopped
      m_script.setStopped();    
      
      ////3. Tell the audio we're stopped. it's okay to call stop*Audio b/c stop causes no problems if it wasn't started
      // (it sets the thread to null. If it wasn't started, it would already be null.)
      m_cardSound.stopPlayingAudio();
      m_cardSound.stopRecordingAudio();
      

      if (SAMPLINGGRAPH) {
	  m_samplingGraph.stop();
      }
      m_script.setStopped();
      m_script.setPlayable(m_cardSound.isAvailable());
   }


   private class PlayListener implements ActionListener {
    
      public void actionPerformed(ActionEvent e) {
         //System.out.println("PlayListener.actionPerformed");
         if (m_script.isPlaying()) {
            setStopped();
         } else {
            if (SAMPLINGGRAPH) 
               m_samplingGraph.startPlay(m_cardSound);
            if (m_cardSound.isAvailable()) {
               m_script.setPlaying();
			   setPauseDuration(m_cardSound.getPauseDuration());
			   //System.out.println("card '" + getCaption() + "' has pause: " + m_pauseDuration);
               m_cardSound.playAudio();            
            } else {
               m_script.setPlaying();    
               m_script.setStopped();     
               m_cwf.callmeWhenDonePlaying();  // make sure we clean up even if there is no audio!!
            }
         }
      }  // end ActionPerformed
       
    }

             
    private class RecordListener implements ActionListener {
    
      public void actionPerformed(ActionEvent e) {
         if (m_script.isRecording()) {
               setStopped();
         }
         else {
            //getCardType returns false if it is a link
            boolean isLink = !getCardType();
            recordAudio(isLink, 0);
         }
      }
    }  // end ActionPerformed
       
    
    
    /**
     *  
     */
    class CallWhenFinished extends AbstCallWhenFinished {

      public CallWhenFinished (SamplingGraph samplingGraph) {
         super(samplingGraph, AbstScriptNodeModel.this);   
      }
      
      public void callmeWhenDonePlaying(/*CardSound cardSound*/) {
         super.callmeWhenDonePlaying(/*cardSound*/);
        
        // if this link is playing its audio as part of a balloon sequence
        if (m_balloonCallingNode != null) {
            m_balloonCallingNode.callWhenBalloonFinished();
            m_balloonCallingNode = null;
        }
      }
      
      public void callmeWhenDoneRecording() {
	  if (DEBUG) { System.out.println("callwhenfinished done recording ... ");}
        setStopped();
        setAudioDuration();
        m_script.setPlayable(true);
      }
      
    }
    
}

