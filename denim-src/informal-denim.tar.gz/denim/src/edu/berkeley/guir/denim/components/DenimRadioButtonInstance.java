package edu.berkeley.guir.denim.components;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.Iterator;
import java.util.Set;

import javax.swing.SwingUtilities;

import edu.berkeley.guir.denim.CaptionedGraphicalObject;
import edu.berkeley.guir.denim.DenimText;
import edu.berkeley.guir.denim.TypedText;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

/**
 * An instance of a radio button in a DENIM design. This is a built-in
 * component.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  02-26-2003  James Lin
 *                                Created DenimRadioButtonInstance
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 02-26-2003
 */

public class DenimRadioButtonInstance
	extends DenimIntrinsicComponentInstance
	implements CaptionedGraphicalObject
{

	//===========================================================================
	//===   CONSTANTS   =========================================================

	private static final int GAP = 8;

	//===   CONSTANTS   =========================================================
	//===========================================================================

	//===========================================================================
	//===   FIELDS   ============================================================

	private TimedStroke radioButtonBorder;
	private Patch selectedCircle;
    private Patch filledCircle; // checked
	private DenimText caption;
	private boolean state;

	// true if radio button was stamped, false if it was sketched
	private boolean createdByStamp;

	//===   FIELDS   ============================================================
	//===========================================================================

	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	/**
	 * Creates an instance of a DENIM radio button. Called only by
	 * DenimRadioButton.newInstance().
	 *
	 * @param type an instance of DenimRadioButton
	 */
	DenimRadioButtonInstance(DenimComponent type)
	{
		super(type);

		assert(
			type
				instanceof DenimRadioButton) : "DenimRadioButtonInstance can only be created by DenimRadioButton";
        init();
	}

	//-----------------------------------------------------------------

	/**
	 * Creates an instance of a DENIM radio button, which will look like the
	 * given border and have the given caption. Assumes that the given border
	 * and caption have the same parent in the scenegraph.
	 *
	 * Called only by DenimRadioButton.newInstance().
	 *
	 * @param border the border of the radio button
	 * @param caption the caption of the radio button
	 */
/*	DenimRadioButtonInstance(
		DenimComponent type,
		TimedStroke newBorder,
		DenimText newCaption)
	{
		super(type);

		assert(
			type
				instanceof DenimRadioButton) : "DenimRadioButtonInstance can only be created by DenimRadioButton";

		this.radioButtonBorder = (TimedStroke) newBorder.deepClone();
		((Patch) displayedState).add(radioButtonBorder, KEEP_ABS_POS);
        
          // igore strokes
          this.setIgnoreStrokes(true);
          ((PatchImpl)displayedState).setIgnoreStrokes(true);

		// Set bounding box to be union of the bounding boxes of border
		// and caption
		Rectangle2D newBounds = new Rectangle2D.Double();
		Rectangle2D.union(
			newBorder.getBounds2D(COORD_REL),
			newCaption.getBounds2D(COORD_REL),
			newBounds);
		this.setBoundingPoints2D(
			COORD_LOCAL,
			new Rectangle2D.Double(
				0,
				0,
				newBounds.getWidth(),
				newBounds.getHeight()));

		displayedState = new PatchImpl(newBounds);

		// Temporarily add the radio button
		newBorder.getParentGroup().add(displayedState, KEEP_REL_POS);

		this.caption = (DenimText) newCaption.deepClone();
		((Patch) displayedState).add(this.caption);

		// Change each object's transform so that its coordinates stay
		// the same
		AffineTransform newTx = displayedState.getInverseTransform(COORD_ABS);
		newTx.concatenate(newCaption.getTransform(COORD_ABS));
		this.caption.setTransform(newTx);

		this.add(displayedState);

		displayedState.delete();

		// Make filled circle, for when the radio button is on
		filledCircle = new PatchImpl(newBorder);
		Style style = filledCircle.getStyle();
		style.setDrawColor(Color.BLACK);
		style.setFillColor(Color.BLACK);
		style.setLineWidth(1.0f);
		filledCircle.setStyle(style);

		// Make selected circle, for when the radio button is being clicked
		selectedCircle = new PatchImpl(newBorder);
		style = filledCircle.getStyle();
		style.setDrawColor(Color.BLACK);
		style.setFillColor(new Color(0, 0, 0, 50));
		style.setLineWidth(1.0f);
		selectedCircle.setStyle(style);

		createdByStamp = false;
        
        state = false;
	}
*/
	//-----------------------------------------------------------------

	DenimRadioButtonInstance(
		DenimComponent type,
		Rectangle2D bounds,
		boolean selected,
		TimedStroke radioButtonBorder,
		DenimText caption,
		boolean createdByStamp)
	{
		super(type);

		this.setBoundingPoints2D(COORD_LOCAL, bounds);
		this.state = selected;
		this.radioButtonBorder = radioButtonBorder;
		this.caption = caption;
		this.createdByStamp = createdByStamp;

		displayedState = new PatchImpl(bounds);
        
          // igore strokes
          this.setIgnoreStrokes(true);
          ((PatchImpl)displayedState).setIgnoreStrokes(true);
          
		Style style = displayedState.getStyle();
		style.setDrawColor(new Color(0, 0, 0, 0));
		style.setFillColor(new Color(0, 0, 0, 0));
		style.setLineWidth(1.0f);
		displayedState.setStyle(style);

		// Make border
		/*style = radioButtonBorder.getStyle();
		style.setDrawColor(Color.BLACK);
		style.setLineWidth(1.0f);
		radioButtonBorder.setStyle(style);*/
        radioButtonBorder.getStyleRef().setDrawColor(Color.BLACK);
        radioButtonBorder.getStyleRef().setLineWidth(1.0f);
		((Patch) displayedState).add(radioButtonBorder, KEEP_REL_POS);

		// Make filled circle, for when the radio button is on
		/*if (createdByStamp)
		{
			filledCircle = new PatchImpl(new Ellipse2D.Double(3.5, 11, 8, 8));
		}
		else
		{
			filledCircle = new PatchImpl(radioButtonBorder);
		}
        */
        Rectangle2D rbox = radioButtonBorder.getBounds2D(COORD_REL);
        filledCircle = new PatchImpl(new Ellipse2D.Double(
                rbox.getMinX()+3.5, rbox.getMinY()+3.5, 8, 8));
        
		style = filledCircle.getStyle();
		style.setDrawColor(Color.BLACK);
		style.setFillColor(Color.BLACK);
		style.setLineWidth(1.0f);
		filledCircle.setStyle(style);

		// Make selected circle, for when the radio button is being clicked
		selectedCircle = new PatchImpl(radioButtonBorder);
		style = selectedCircle.getStyle();
		style.setDrawColor(Color.BLACK);
		style.setFillColor(new Color(0, 0, 0, 50));
		style.setLineWidth(1.0f);
		selectedCircle.setStyle(style);

		// Make caption
		((Patch) displayedState).add(caption, KEEP_REL_POS);

		this.add(displayedState, KEEP_REL_POS);
	}

    
    private void init() 
    {
        Style style = this.getStyle();
        style.setDrawColor(new Color(0, 0, 0, 0));
        style.setFillColor(new Color(0, 0, 0, 0));
        this.setStyle(style);

        this.setBoundingPoints2D(COORD_LOCAL,
            new Rectangle2D.Double(0, 0, 100, 30));

        displayedState = new PatchImpl(new Rectangle2D.Double(0, 0, 100, 30));
        
        // igore strokes
        this.setIgnoreStrokes(true);
        ((PatchImpl)displayedState).setIgnoreStrokes(true);
          
        style = displayedState.getStyle();
        style.setDrawColor(new Color(0, 0, 0, 0));
        style.setFillColor(new Color(0, 0, 0, 0));
        style.setLineWidth(1.0f);
        displayedState.setStyle(style);

        // Make border
        radioButtonBorder =
            new TimedStroke(new Ellipse2D.Double(0, 7.5, 15, 15));
        style = radioButtonBorder.getStyle();
        style.setDrawColor(Color.BLACK);
        style.setLineWidth(1.0f);
        radioButtonBorder.setStyle(style);
        ((Patch) displayedState).add(radioButtonBorder, KEEP_REL_POS);

        // Make selected circle, for when the radio button is being clicked
        selectedCircle = new PatchImpl(radioButtonBorder);
        style = selectedCircle.getStyle();
        style.setDrawColor(Color.BLACK);
        style.setFillColor(new Color(0, 0, 0, 50));
        style.setLineWidth(1.0f);
        selectedCircle.setStyle(style);

        // Make filled circle, for when the radio button is on
        filledCircle = new PatchImpl(new Ellipse2D.Double(3.5, 11, 8, 8));
        style = filledCircle.getStyle();
        style.setDrawColor(Color.BLACK);
        style.setFillColor(Color.BLACK);
        style.setLineWidth(1.0f);
        filledCircle.setStyle(style);
        
        // Make squiggle caption
        DenimText newCaption = DenimIntrinsicComponent.createSquiggle();
        setCaption(newCaption);
        this.add(displayedState, KEEP_REL_POS);
        
        createdByStamp = true;
        state = false;

    }
    
	//===   CONSTRUCTORS   ======================================================
	//===========================================================================

	//===========================================================================
	//===   RADIO BUTTON METHODS   ==============================================

	/**
	 * Returns whether this check box is selected (checked) or not.
	 */
	public boolean getSelected()
	{
		return state;
	}

	//-----------------------------------------------------------------

	/**
	 * Sets whether this check box is selected (checked) or not.
	 */
	public void setSelected(boolean flag)
	{
		if (flag)
		{
			DenimRadioButtonInstanceContainer container =
				(DenimRadioButtonInstanceContainer) this.getParentGroup();
			Set radioButtons = container.getRadioButtons();

			for (Iterator it = radioButtons.iterator(); it.hasNext();)
			{
				DenimRadioButtonInstance radioButton =
					(DenimRadioButtonInstance) it.next();
				if (radioButton != this)
				{
					radioButton.setSelected(false);
					radioButton.damage(DAMAGE_NOW);
				}
			}
			this.add(filledCircle);
		}
		else
		{
			filledCircle.delete();
		}
		state = flag;
		this.damage(DAMAGE_NOW);
	}
	
	private void setSelectedSliently(boolean flag) {
		if (flag)
		{
			this.add(filledCircle);
		}
		else
		{
			filledCircle.delete();
		}
		state = flag;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns whether this radio button was created by a stamp (as opposed
	 * to sketched).
	 */
	public boolean isCreatedByStamp()
	{
		return createdByStamp;
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the border of the radio button itself.
	 */
	public TimedStroke getButtonBorder()
	{
		return radioButtonBorder;
	}

	//===   RADIO BUTTON METHODS   ==============================================
	//===========================================================================

	//===========================================================================
	//===   CAPTION METHODS   ===================================================

	public DenimText getCaption()
	{
		return caption;
	}

	//-----------------------------------------------------------------

	public void setCaption(DenimText newCaption)
	{
		//// 1. Erase the old caption.
		if (caption != null)
		{
			caption.delete();
		}

		//// 2. Add the new caption.
		caption = newCaption;
		((Patch) displayedState).add(caption);

		//// 3. Move the caption so that it is GAP away from the radio button
		////    and that the radio button is vertically centered with the caption.
		Rectangle2D borderBds = radioButtonBorder.getBounds2D(COORD_REL);
		Rectangle2D captionBds = caption.getBounds2D(COORD_REL);
		caption.moveTo(
			COORD_REL,
			borderBds.getMaxX() + GAP,
			(borderBds.getHeight() - captionBds.getHeight()) / 2
				+ borderBds.getMinY());

		//// 4. Calculate union of bounding boxes of the check box and caption
		////    in relative coordinates (which are the same as the local
		////    coordinates of this component).
		double oldHeight = this.getBounds2D(COORD_LOCAL).getHeight();
		Rectangle2D newLocalBds = new Rectangle2D.Double();
		Rectangle2D.union(
			borderBds,
			caption.getBounds2D(COORD_REL),
			newLocalBds);

		//// 5. Change the local bounds of this component to the height and width
		////    of the rectangle calculated in step 4.
		this.setBoundingPoints2D(
			COORD_LOCAL,
			new Rectangle2D.Double(
				0,
				0,
				newLocalBds.getWidth(),
				newLocalBds.getHeight()));
		double newHeight = this.getBounds2D(COORD_LOCAL).getHeight();

		displayedState.setBoundingPoints2D(
			COORD_LOCAL,
			this.getBounds2D(COORD_LOCAL));

		//// 6. Move the radio button so that it's centered vertically.
		double dy = (newHeight - oldHeight) / 2;
		radioButtonBorder.moveBy(COORD_REL, 0, dy);
		selectedCircle.moveBy(COORD_REL, 0, dy);
		filledCircle.moveBy(COORD_REL, 0, dy);

		//// 7. Make sure the caption is centered vertically.
		caption.moveTo(
			COORD_REL,
			caption.getBounds2D(COORD_REL).getMinX(),
			(newHeight - caption.getBounds2D(COORD_REL).getHeight()) / 2);

		//// 8. If this component already has a parent, then move the component
		////    so that the check box does not move on the screen.
		if (this.getParentGroup() != null)
		{
			this.moveBy(
				COORD_REL,
				0,
				(oldHeight - newHeight)
					/ 2
					* getTransform(COORD_REL).getScaleY());
		}
	}

	//===   CAPTION METHODS   ===================================================
	//===========================================================================

	//===========================================================================
	//===   COMPONENT METHODS   =================================================

	public void setTransparency(int transparency)
	{
	}

	//===   COMPONENT METHODS   =================================================
	//===========================================================================

	//===========================================================================
	//===   GRAPHICAL OBJECT METHODS   ==========================================

	public void setParentGroup(GraphicalObjectGroup newParent)
	{
		GraphicalObjectGroup currentParent = getParentGroup();
		if (currentParent instanceof DenimRadioButtonInstanceContainer)
		{
			(
				(
					DenimRadioButtonInstanceContainer) currentParent)
						.removeRadioButton(
				this);
		}

		super.setParentGroup(newParent);

		if (newParent instanceof DenimRadioButtonInstanceContainer)
		{
			((DenimRadioButtonInstanceContainer) newParent).addRadioButton(
				this);
		}
	}

	//===   GRAPHICAL OBJECT METHODS   ==========================================
	//===========================================================================

	//==========================================================================
	//===   MOUSE HANDLING METHODS   ===========================================

	/**
	 * Handles a mouse press. Intended for use during Run mode.
	 */
	public void mousePressed(MouseEvent e)
	{
		this.add(selectedCircle);
		this.damage(DAMAGE_NOW);
	}

	//-----------------------------------------------------------------

	/**
	 * Handles a mouse release. Intended for use during Run mode.
	 */
	public void mouseReleased(MouseEvent e)
	{
		selectedCircle.delete();
		setSelected(true);
	}

	//-----------------------------------------------------------------

	/**
	 * Handles a mouse enter. Intended for use during Run mode.
	 */
	public void mouseEntered(MouseEvent e)
	{
		if (SwingUtilities.isLeftMouseButton(e))
		{
			this.add(selectedCircle);
			this.damage(DAMAGE_NOW);
		}
	}

	//-----------------------------------------------------------------

	/**
	 * Handles a mouse exit. Intended for use during Run mode.
	 */
	public void mouseExited(MouseEvent e)
	{
		if (SwingUtilities.isLeftMouseButton(e))
		{
			selectedCircle.delete();
			this.damage(DAMAGE_NOW);
		}
	}

	//-----------------------------------------------------------------

	/**
	 * Handles a mouse drag. Intended for use during Run mode.
	 */
	public void mouseDragged(MouseEvent e)
	{
	}

	//===   MOUSE HANDLING METHODS   ===========================================
	//==========================================================================

	//===========================================================================
	//===   CLONE METHODS   =====================================================

	/**
	 * Returns a deep clone of this button instance.
	 */
	public Object deepClone()
	{
		return deepClone(new DenimRadioButtonInstance(type));
	}

	//-----------------------------------------------------------------

	/**
	 * Sets the clone parameter to a deep clone of this button instance,
	 * and returns it.
	 */
	public Object deepClone(DenimRadioButtonInstance clone) {
		
		if (state)
		{
			this.disableDamage();
			this.setSelectedSliently(false);
			
			super.deepClone(clone);

			Patch cloneDisplayedState = (Patch) clone.displayedState;

			clone.radioButtonBorder =
				(TimedStroke) cloneDisplayedState.get(
					((Patch) displayedState).indexOf(radioButtonBorder));

			clone.filledCircle = (Patch) filledCircle.deepClone();
			clone.selectedCircle = (Patch) selectedCircle.deepClone();
			clone.caption =
				(DenimText) cloneDisplayedState.get(
					((Patch) displayedState).indexOf(caption));

			clone.state = state;
			clone.createdByStamp = createdByStamp;
			clone.setSelectedSliently(true);
			
			this.setSelectedSliently(true);
			this.enableDamage();
			return clone;
		}
		else
		{
			super.deepClone(clone);

			Patch cloneDisplayedState = (Patch) clone.displayedState;

			clone.radioButtonBorder =
				(TimedStroke) cloneDisplayedState.get(
					((Patch) displayedState).indexOf(radioButtonBorder));

			clone.filledCircle = (Patch) filledCircle.deepClone();
			clone.selectedCircle = (Patch) selectedCircle.deepClone();
			clone.caption =
				(DenimText) cloneDisplayedState.get(
					((Patch) displayedState).indexOf(caption));

			clone.state = state;
			clone.createdByStamp = createdByStamp;

			return clone;

		}
		
	}

	public void setStateIndex(int i)
	{
		if (i == 0)
		{
			this.setSelected(false);
		}
		else
		{
			this.setSelected(true);
		}
	}

	public int getStateIndex()
	{
		if (this.state)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	//===   CLONE METHODS   =====================================================
	//===========================================================================

	public GraphicalObjectCollection getStates() {
		return DenimRadioButton.mStateCollection;
	}
    
   public boolean isHTMLConvertible() {
       if(this.getCaption() instanceof TypedText)
           return true;
       else
           return false;
   }

   
} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
