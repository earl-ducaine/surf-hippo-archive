package edu.berkeley.guir.lib.satin.objects;

import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;
import java.util.List;

/**
 * A straight-line arrow that snaps to points on the graphical object.
 *
 *   A-----P--B--Q-----C
 *   |     |     |     |
 *   |  1  |  2  |  3  |
 *   |     |     |     |
 *   W-----+-----+-----R
 *   |     |     |     |
 *   H  8  |     |  4  D
 *   |     |     |     |
 *   V-----+-----+-----S
 *   |     |     |     |
 *   |  7  |  6  |  5  |
 *   |     |     |     |
 *   G-----U--F--T-----E
 *
 * By default, the arrow will snap to points A-H. The arrows can also be
 * displaced to snap to P-W, which is useful if there are arrows that go back and forth
 * between two graphical objects.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - June 28 2001, SJW
 *               Created.
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~waterson/">Sarah Waterson</A> (
 *         <A HREF="mailto:waterson@cs.berkeley.edu">waterson@cs.berkeley.edu</A> )
 * @since   JDK 1.3
 * @version ?
 */
public class SnappingLineArrow
	extends    LineArrow {


	//===========================================================================
	//===   NONLOCAL VARIABLES   ================================================

	private boolean isDisplaced = false;
    private SnapMap startSnapMap = new SnapMap();
    private SnapMap endSnapMap = new SnapMap();

	//===   NONLOCAL VARIABLES   ================================================
	//===========================================================================



	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	public SnappingLineArrow() {
		super();
	} // of constructor

	//-----------------------------------------------------------------

	public SnappingLineArrow(Point2D ptStart, Point2D ptEnd) {
		super(ptStart, ptEnd);
	} // of constructor

	//-----------------------------------------------------------------

	public SnappingLineArrow(float x1, float y1, float x2, float y2) {
		super(x1, y1, x2, y2);
	} // of constructor

	//-----------------------------------------------------------------

	public SnappingLineArrow(GraphicalObject gobStart, GraphicalObject gobEnd) {
		super(gobStart, gobEnd);
	} // of method


	//===   CONSTRUCTORS   ======================================================
	//===========================================================================



	//===========================================================================
	//===   ARROW METHODS   =====================================================

	/**
	 * Calculates where the start and end points when one or both of the endpoints
	 * are grapical objects
	 */
	protected void calculateGraphicalObjectPoints() {
		if (flagDirty == false) {
			return;
		}

		// instead of just returning where the line crosses the gob, we need to do all
		// sorts of things to calculate where the arrow will snap to.
		//// calculate bounds of graphical object
		////   set up the snapping grid
		//// find the crossing of the start point
		//// map crossing to snapping point on the grid
		//// find the crossing of the end point
		//// map crossing to snapping point on the grid


		Point2D  ptAA      = getStartPoint(COORD_ABS);
		Point2D  ptBB      = getEndPoint(COORD_ABS);
		boolean  flagSetAA = false;
		boolean  flagSetBB = false;

		//// 1.1. Get the bounds of the two graphical object.
		if (gobStart != null) {
			Rectangle2D bdsStart = gobStart.getBounds2D(COORD_ABS);

			// build the snap map for the starting gob
			startSnapMap = new SnapMap(bdsStart);
			if (isDisplaced) {
				startSnapMap.displace(true);
			}

			ptAA       = new Point2D.Float(
										   (float) (bdsStart.getX() + bdsStart.getWidth()  / 2),
										   (float) (bdsStart.getY() + bdsStart.getHeight() / 2));
			flagSetAA  = true;
		}
		if (gobEnd != null) {
			Rectangle2D bdsEnd   = gobEnd.getBounds2D(COORD_ABS);

			// build the snap map for the end gob
			endSnapMap = new SnapMap(bdsEnd);
			if (isDisplaced) {
				endSnapMap.displace(true);
			}

			ptBB       = new Point2D.Float(
										   (float) (bdsEnd.getX()   + bdsEnd.getWidth()  / 2),
										   (float) (bdsEnd.getY()   + bdsEnd.getHeight() / 2));
			flagSetBB  = true;
		}

		//// 1.2. Calculate the line between the two gob center points.
		Line2D      line       = new Line2D.Float(ptAA, ptBB);

		//// 1.3. Calculate intersect points between line and graphical objs.
		////      Use the first item in these lists, or the center points
		////      if the lists are empty.
		if (flagSetAA == true) {
			Polygon2D polyAA = gobStart.getBoundingPoints2D(COORD_ABS);
			List      listAA = GeomLib.calcIntersectPoints(line, polyAA);
			if (listAA.size() > 0) {
				ptStart = (Point2D) listAA.get(0);
			}
			else {
				//System.out.println("center point start");
                                // the above comment was in there because for some reason
                                // the intersection calculation returned an empty list.
                                // At some point, that intersection code should be checked.
				ptStart = ptAA;
			}
			ptStart = startSnapMap.getStartSnapPoint(ptStart);
			GraphicalObjectLib.absoluteToLocal(this, ptStart, ptStart);
		}

		if (flagSetBB == true) {
			Polygon2D polyBB = gobEnd.getBoundingPoints2D(COORD_ABS);
			List      listBB = GeomLib.calcIntersectPoints(line, polyBB);
			if (listBB.size() > 0) {
				ptEnd = (Point2D) listBB.get(0);
			}
			else {
				//System.out.println("center point end");
				ptEnd = ptBB;
			}

			ptEnd = endSnapMap.getEndSnapPoint(ptEnd);
			GraphicalObjectLib.absoluteToLocal(this, ptEnd, ptEnd);
		}

		updateBounds();
		flagDirty = false;
	} // of method

	//-----------------------------------------------------------------


	//===   ARROW METHODS   =====================================================
	//===========================================================================



	//===========================================================================
	//===   DISPLACEMENT   =========================================================

	/**
	 * sets displacement/offset - useful when you have arrows going
	 * back and for between two graphical objects
	 */
	public void setDisplaced(boolean b) {
		isDisplaced = b;
	}

	//===   DISPLACEMENT   =========================================================
	//===========================================================================


	//===========================================================================
	//===   INTERNAL CLASSES   ====================================================

	/**
	 * This class is used to define the snap points for the GOb
	 *
	 *  Here's the grid of letter codes used for snapping:
	 *
	 *   A-----P--B--Q-----C
	 *   |     |     |     |
	 *   |  1  |  2  |  3  |
	 *   |     |     |     |
	 *   W-----+-----+-----R
	 *   |     |     |     |
	 *   H  8  |     |  4  D
	 *   |     |     |     |
	 *   V-----+-----+-----S
	 *   |     |     |     |
	 *   |  7  |  6  |  5  |
	 *   |     |     |     |
	 *   G-----U--F--T-----E
	 *
	 *  Basically, we check to see where the line connecting the two GObs crosses
	 * the grid, and if it is a normal snapping arrow, we snap to pts A-H. If it is
	 * a displaced arrow, we snap to P-W.
	 *
	 */

	class SnapMap {
		Point2D.Float A = new Point2D.Float(0,0);
		Point2D.Float B = new Point2D.Float(0,0);
		Point2D.Float C = new Point2D.Float(0,0);
		Point2D.Float D = new Point2D.Float(0,0);
		Point2D.Float E = new Point2D.Float(0,0);
		Point2D.Float F = new Point2D.Float(0,0);
		Point2D.Float G = new Point2D.Float(0,0);
		Point2D.Float H = new Point2D.Float(0,0);

		Point2D.Float P = new Point2D.Float(0,0);
		Point2D.Float Q = new Point2D.Float(0,0);
		Point2D.Float R = new Point2D.Float(0,0);
		Point2D.Float S = new Point2D.Float(0,0);
		Point2D.Float T = new Point2D.Float(0,0);
		Point2D.Float U = new Point2D.Float(0,0);
		Point2D.Float V = new Point2D.Float(0,0);
		Point2D.Float W = new Point2D.Float(0,0);

		float X = 0;
		float Y = 0;
		float w = 0;
		float h = 0;

		boolean displaced = false;

		public SnapMap() {
			buildMap();
		} // of constructor

		public SnapMap(Rectangle2D bounds) {
			X = (float) bounds.getX();
			Y = (float) bounds.getY();
			w = (float) bounds.getWidth();
			h = (float) bounds.getHeight();
			buildMap();
		} // of constructor

		public void buildMap() {
			A = new Point2D.Float(X, Y);
			B = new Point2D.Float(X+w/2, Y);
			C = new Point2D.Float(X+w, Y);
			D = new Point2D.Float(X+w, Y+h/2);
			E = new Point2D.Float(X+w, Y+h);
			F = new Point2D.Float(X+w/2, Y+h);
			G = new Point2D.Float(X, Y+h);
			H = new Point2D.Float(X, Y+h/2);

			P = new Point2D.Float(X+w/3, Y);
			Q = new Point2D.Float(X+2*w/3, Y);
			R = new Point2D.Float(X+w, Y+h/3);
			S = new Point2D.Float(X+w, Y+2*h/3);
			T = new Point2D.Float(X+2*w/3, Y+h);
			U = new Point2D.Float(X+w/3, Y+h);
			V = new Point2D.Float(X, Y+2*h/3);
			W = new Point2D.Float(X, Y+h/3);

		} // of method


		public Point2D getSnapPoint(Point2D pt2snap) {
			int id = getGridID((float)pt2snap.getX(), (float)pt2snap.getY());
			switch (id) {
			case 1: return (A);
			case 2: return (B);
			case 3: return (C);
			case 4: return (D);
			case 5: return (E);
			case 6: return (F);
			case 7: return (G);
			case 8: return (H);
			}
			return (new Point2D.Float(0,0));
		} // of method

		public Point2D getStartSnapPoint(Point2D pt2snap) {
			if (displaced == false) {
				return getSnapPoint(pt2snap);
			}

			int id = getGridID((float)pt2snap.getX(), (float)pt2snap.getY());
			switch (id) {
			case 1: return (W);
			case 2: return (P);
			case 3: return (Q);
			case 4: return (R);
			case 5: return (S);
			case 6: return (T);
			case 7: return (U);
			case 8: return (V);
			}
			return (new Point2D.Float(0,0));

		} // of mehtod

		public Point2D getEndSnapPoint(Point2D pt2snap) {
			if (displaced == false) {
				return getSnapPoint(pt2snap);
			}

			int id = getGridID((float)pt2snap.getX(), (float)pt2snap.getY());
			switch (id) {
			case 1: return (P);
			case 2: return (Q);
			case 3: return (R);
			case 4: return (S);
			case 5: return (T);
			case 6: return (U);
			case 7: return (V);
			case 8: return (W);
			}
			return (new Point2D.Float(0,0));
		} // of method

		public int getGridID(float x, float y) {
			if ( x < P.getX() ) {
				if ( y < W.getY() )
					return (1);
				else if ( Y < V.getY() )
					return (8);
				else
					return (7);
			}
			else if ( x < Q.getX() ) {
				if ( y < W.getY() )
					return  (2);
				else
					return (6);
			}
			else {
				if ( y < W.getY() )
					return (3);
				else if ( Y < V.getY() )
					return (4);
				else
					return (5);
			}
		}

		public void displace(boolean b) {
			displaced = b;
		}


	} // of class

	//===   INTERNAL CLASSES   ====================================================
	//===========================================================================



	//===========================================================================
	//===   CLONE   =============================================================

	/**
	 * For clone chaining purposes.
	 *
	 * @see GraphicalObjectImpl#clone(GraphicalObjectImpl)
	 */
	protected SnappingLineArrow clone(SnappingLineArrow newArrow) {
		//// 1. First call the superclass clone for clone chaining.
		super.clone(newArrow);

		//// 2. Do work.
		newArrow.ptStart = new Point2D.Float((float) ptStart.getX(),
											 (float) ptStart.getY());
		newArrow.ptEnd   = new Point2D.Float((float) ptEnd.getX(),
											 (float) ptEnd.getY());

		//// 3. Return.
		return (newArrow);
	} // of clone

	//-----------------------------------------------------------------

	/**
	 * For deep-clone chaining. If you override this method in a subclass, be
	 * sure to call this method, just as you would have to for normal clone
	 * chaining.
	 *
	 * @see #clone()
	 * @see #deepClone()
	 */
	protected SnappingLineArrow deepClone(SnappingLineArrow newArrow) {
		//// 1. Defer work to other clone method, since we don't contain
		////    other objects.
		super.clone(newArrow);

		//// 2. Return.
		return (newArrow);
	} // of deepClone

	//===   CLONE   =============================================================
	//===========================================================================



	//===========================================================================
	//===   MAIN   ==============================================================

	/*
	public static void main(String[] argv) {

	} // of main
	*/
	//===   MAIN   ==============================================================
	//===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
