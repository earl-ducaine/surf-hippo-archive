//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import edu.berkeley.guir.lib.satin.remote.*;
import edu.berkeley.guir.lib.satin.*;


/**
 * An implementation of CommandQueue that is branched and thus doesn't
 * prune the history if the user does some thing, undo's it and then
 * does something else.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://guir.berkeley.edu/">Katie Everitt</A> (
 *          <A HREF="mailto:everitt@cs.berkeley.edu">everitt@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 */

public class RemoteBranchedCommandQueue
	extends BranchedCommandQueue implements RemoteCommandQueue{

   private RemoteSocketMgr          m_remoteSocketMgr = null;
   private InOutMgr                 m_saveMgr = null;
   private Sheet                    m_sheet;

	//===========================================================================
	//===   ACTION METHODS   ====================================================

	public RemoteBranchedCommandQueue(Sheet s) {
	   super();
	   m_sheet = s;
	}

	
	/**
	 * Execute the specified command.
	 */
	public synchronized void doCommand(Command cmd) {
      super.doCommand(cmd);

	 

      if (m_remoteSocketMgr != null) {            
            System.out.println("Sending Event");
            m_remoteSocketMgr.postOutgoingEvent(cmd.getWrappedXML());
      }
      
      // This sends the XML string to the save Manager
      if (m_saveMgr != null) {            
            System.out.println("Saving Event");
//            System.out.println(cmd.getWrappedXML()); //ftpo
            m_saveMgr.postOutgoingEvent(cmd.getWrappedXML());
            
      }
      
	}

	public synchronized void doLocalCommand(Command cmd) {
	  // This method does NOT send the event to the remote host
	  // used for commands recieved remotely.
      super.doCommand(cmd);
      
      // This sends the XML string to the save Manager
      if (m_saveMgr != null) {            
            System.out.println("Saving Event");
            m_saveMgr.postOutgoingEvent(cmd.getWrappedXML());
      }
	}


	public void undo() {
      super.undo();
      System.out.println("RemoteQ: NEED TO IMPLEMENT REMOTE UNDO");
	}
	
   
	public void redo() {
      super.redo();
      System.out.println("RemoteQ: NEED TO IMPLEMENT REMOTE REDO");
	}
   

	//Methods from RemoteCommandQueue Interface
	public void setRemoteSocketMgr(RemoteSocketMgr mgr) {
      m_remoteSocketMgr = mgr;
   }
   
   public void setSaveMgr(InOutMgr mgr){
      m_saveMgr = mgr;
   }


   /*
    * When we receive a remote incoming event (e.g. a new note was added), this gets called
    * The xml event is the raw xml that we've received over the wire.
    */
   public void handleRemoteEvent(IOEvent event) {
      System.out.println("BranchedCmdQ: remote event received");      
      m_sheet.addCommandToSheet(event.getXML());       
   }

} // of class

//==============================================================================

/*
  Copyright (c) 2000 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
