package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.connection.Connection;

/** 
 * An event that indicates that a property of a connection has changed.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-11-2003 James Lin
 *                               Created ConnectionEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-11-2003
 */
public class ConnectionEvent extends EventObject {

   private final Type eventType;   
   private final DeviceType deviceType;
   private final Object oldValue;
   private final Object newValue;
   
   //===========================================================================

   public static class Type {
      private final String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type SOURCE_CHANGED =
      new Type("source of connection changed");

   public static final Type DEST_CHANGED =
      new Type("destination of connection changed");

   public static final Type SHAPE_CHANGED =
      new Type("shape of connection changed");

   public static final Type USER_EVENT_CHANGED =
      new Type("user event of connection changed");

   public static final Type CONDITION_CHANGED =
      new Type("condition of connection changed");

   //===========================================================================

   /**
    * Constructs a ConnectionEvent, which gets fired when the source,
    * destination, shape, event type, or condition of a connection is changed.
    */
   public ConnectionEvent(
      final Connection source,
      final Type eventType,
      final DeviceType deviceType,
      final Object oldValue,
      final Object newValue) {

      super(source);
      this.eventType = eventType;
      this.deviceType = deviceType;
      this.oldValue = oldValue;
      this.newValue = newValue;
   }
   
   //===========================================================================

   /**
    * Returns the connection affected by the event.
    */
   public Connection getConnection() {
      return (Connection)source;
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the device type affected by the event.
    */
   public DeviceType getDeviceType() {
      return deviceType;
   }
   
   //===========================================================================
   
   /**
    * Returns the old value of the property being changed.
    */
   public Object getOldValue() {
      return oldValue;
   }
   
   //===========================================================================
   
   /**
    * Returns the new value of the property being changed.
    */
   public Object getNewValue() {
      return newValue;
   }
}
