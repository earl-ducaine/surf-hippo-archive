package edu.berkeley.guir.damask.event;

import java.util.EventListener;

/** 
 * The listener interface for receiving events regarding a change in a control. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-01-2004 James Lin
 *                               Created ControlListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-01-2004
 */
public interface GroupListener extends EventListener {
   
   /**
    * Invoked when an interaction element's bounds has been updated.
    */
   void elementBoundsUpdated(GroupEvent e);
   
   /**
    * Invoked when an interaction element's transform has been updated.
    */
   void elementTransformUpdated(GroupEvent e);
}
