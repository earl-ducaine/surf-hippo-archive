package edu.berkeley.guir.denim.action;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.event.*;

/**
 * Represents an event dispatched by a component instance and "received" by
 * the component instance that contains the component instance that is
 * dispatching.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-21-1999 JL
 *                    Created
 *             1.1.0  09-05-1999 JL
 *                    Moved to package edu.berkeley.guir.denim.action
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.1.0, 09-05-1999
 */
public class DispatchDenimEvent implements DenimAction
{

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -8910308326553290660L;

   //===   CONSTANTS   =========================================================
   //===========================================================================


   private DenimComponentInstance source;
   private DenimEvent event;

   /**
    * Construct the event dispatch.
    *
    * @param s the component instance that is dispatching the event
    * @param e the event being dispatched
    */
   public DispatchDenimEvent(DenimComponentInstance s,
                             DenimEvent e) {
      source = s;
      event = e;
   }

   /**
    * Dispatches this object's event to the event source's containing
    * component instance
    */
   public void run() {
      DenimComponentInstance container =
         source.getContainingComponentInstance();

      assert container != null;
      // "A component instance not within a component is trying to 
      // dispatch a named event"
      
      DenimPanel thePanel = container.getContainingPanel();
      container.handleEvent
         (event,
          thePanel.getCurrentRunTimeCondition());
   }

   public DenimAction copy(DenimComponentInstance newSource) {
      return new DispatchDenimEvent(newSource, event);
   }

   public String toString() {
      String s = "DispatchDenimEvent(";
      s += source.getClass() + ", " + source.getUniqueID() + ": ";
      s += event.getName() + ")";

      return s;
   }
} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
