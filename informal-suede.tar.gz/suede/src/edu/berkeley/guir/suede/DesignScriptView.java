package edu.berkeley.guir.suede;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class DesignScriptView extends AbstScriptView {
	private static final int   BUTTON_WIDTH = 15;
	private static final int[] TRIANGLE_X   = new int[3];
	private static final int[] TRIANGLE_Y   = new int[3];
	/* The big dark gray triangle button the scriptbar
	 */    
	private AddButton   addButton = new AddButton(BUTTON_WIDTH,AbstScriptNodeView.HEIGHT);
	private int         m_scriptnumber;
	//private ScriptNodeResizeListener m_scriptNodeResizeListener = new ScriptNodeResizeListener();

	public DesignScriptView(int scriptnumber, SuedeModel model) { 
	super( "Script " + scriptnumber );
	        
	m_model       = model;
	TRIANGLE_X[0] = 2;
	TRIANGLE_X[1] = BUTTON_WIDTH-2;
	TRIANGLE_X[2] = 2;
	        
	TRIANGLE_Y[0] = 3;
	TRIANGLE_Y[1] = AbstScriptNodeView.HEIGHT/2;
	TRIANGLE_Y[2] = AbstScriptNodeView.HEIGHT-3;
	         
	// Nodes can be added by clicking on the addButton or by clicking on blank space...
	m_contents.add(addButton);
	m_contents.addMouseListener(new AddScriptMouseListener());
	m_scriptnumber = scriptnumber;
		/////////////Hongvan's code///////////////////////////////////////////
		m_contents.addKeyListener(new TabKeyListener());
		/////////////////////////////////////////////////////////////////////
	}


	// add the node, and then put tne triangle "add node" button at the end
	public void addScriptNode( AbstScriptNodeModel s) {
	   m_contents.remove(addButton);
	   super.addScriptNode(s);
	   m_contents.add(addButton);
     
	   // Move scrollbar to end so we can see newly added node
	   scrollToEnd( s, addButton.getWidth() );
       
	   ScriptNodeListener sl = new ScriptNodeListener();
	   AbstScriptNodeView sView = s.getView();
	   sView.addMouseListener(sl);
	   sView.addMouseMotionListener(sl);
	   //sView.addComponentListener(m_scriptNodeResizeListener);
	}
	    
	    
	// clicking on the background of the script area adds a script node
	private class AddScriptMouseListener extends MouseAdapter {
	public void mouseClicked(MouseEvent e) {
		m_model.getScriptModel().addDesignScriptNode((numScriptNodes%2 == 0), m_scriptnumber);
	System.out.println ("Adding card on script!");
	}
	public void mousePressed(MouseEvent e){
		System.out.println ("MousePressed on script!");
	}
	public void mouseReleased(MouseEvent e){
		if (SuedeModel.copiedScriptNodeObj != null){
			DesignScriptNodeModel nodeModel = (DesignScriptNodeModel)SuedeModel.copiedScriptNodeObj.getNodeModel();
			//Only allow dragging to copy b/w different scripts, not on the same script
			if (nodeModel.getScriptNumber() != m_scriptnumber){
				m_model.getScriptModel().addDesignScriptNode(nodeModel, m_scriptnumber);
				SuedeModel.copiedScriptNodeObj = null;
				System.out.println ("Pasting on scriparea");
			}
		}
	}
	}

	
	
	/**
	 * The Add Button is the gray, triangle-shaped button.
	 * When a user presses this button, we create a new script node.
	 */
	private class AddButton extends JButton {
	public AddButton(int width, int height) {
		setSize(width,height);
		setBorderPainted(false);
		setContentAreaFilled(true);
		setFocusPainted(false);
		setForeground(Color.lightGray);
		setBackground(Color.darkGray);
		addActionListener(new ButtonListener());
	}
	        
	        
		public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D)g;
		g2d.fillPolygon(TRIANGLE_X, TRIANGLE_Y, 3);
		}


		// clicking on the triangle button adds a new script node
		private class ButtonListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
				m_model.getScriptModel().addDesignScriptNode((numScriptNodes%2 == 0), m_scriptnumber);
		}
		}


	public Dimension getMinimumSize() {
		//System.out.println("3 DesignScriptView.getMinimumSize"+BUTTON_WIDTH+", "+DesignScriptNodeView.HEIGHT);
		return new Dimension(BUTTON_WIDTH, DesignScriptNodeView.HEIGHT);
	}
		        
	   	
	public Dimension getPreferredSize() {
		//System.out.println("3 DesignScriptView.getPreferredSize //calls getMin");
		return getMinimumSize();
	}

	   	
	public Dimension getMaximumSize() {
		//System.out.println("3 DesignScriptView.getMaximumSize //calls getMin");
		return getMinimumSize();  
	}
	}


	// srk: I think this will eventually allow users to resize script nodes
	/*private class ScriptNodeResizeListener implements ComponentListener {
	public void componentHidden(ComponentEvent e) {}
	public void componentMoved(ComponentEvent e) {}
	public void componentResized(ComponentEvent e) {}
	public void componentShown(ComponentEvent e) {}
	}*/
	  
	  
	// The ScriptNodeListener is used for copying nodes from the script area to the design area
	private class ScriptNodeListener extends MouseAdapter implements MouseMotionListener{
		private SContentPane pane = m_model.getContentPane();
		private JComponent feedback;
		    
		/*
	 * pressing the mouse in design view prepares for copying the node to the design area
	 */
	public void mousePressed(MouseEvent e) {
	if (!(SwingUtilities.isMiddleMouseButton(e))) {
		DesignScriptNodeView source = ((DesignScriptNodeView)e.getSource());
	
		//If it is a system prompt (a promptcard)
		if (source.isSystemPrompt()) {
				feedback = new SFeedbackGroup(0,0);
				((SFeedbackGroup)feedback).setFColor(AbstScriptNodeView.SYSTEM_FILL);
		} else {//a user prompt (a response card)
				feedback = new SFeedbackLink(0,0);
				((SFeedbackLink)feedback).setScript(true);
				((SFeedbackLink)feedback).setFColor(AbstScriptNodeView.RESPONSE_FILL);
		}

		feedback.setSize(pane.getWidth(), pane.getHeight());
		pane.add(feedback, JLayeredPane.DRAG_LAYER);
		feedback.setVisible(false);
	}
	}
    
    
	public void mouseDragged(MouseEvent e) {
		Point p = e.getPoint();
		javax.swing.SwingUtilities.convertPointToScreen(p, e.getComponent());
		javax.swing.SwingUtilities.convertPointFromScreen(p, pane);
		if (!(SwingUtilities.isMiddleMouseButton(e))) {
			if(feedback instanceof SFeedbackGroup) {
				((SFeedbackGroup)feedback).setStart((int)(p.getX()-AbstScriptNodeView.WIDTH/2), (int)(p.getY()-AbstScriptNodeView.HEIGHT/2));
				((SFeedbackGroup)feedback).setFinish((int)(p.getX()+AbstScriptNodeView.WIDTH/2), (int)(p.getY()+AbstScriptNodeView.HEIGHT/2));
			}
			else {
				((SFeedbackLink)feedback).setStart((int)(p.getX()-AbstScriptNodeView.WIDTH/2), (int)(p.getY()-AbstScriptNodeView.HEIGHT/2));
				((SFeedbackLink)feedback).setFinish((int)(p.getX()+AbstScriptNodeView.WIDTH/2), (int)(p.getY()+AbstScriptNodeView.HEIGHT/2));
			}
			feedback.setVisible(true);
			pane.repaint();
		}
	}
    
	public void mouseMoved(MouseEvent e) {}
    
	public void mouseReleased(MouseEvent e) {
		if(feedback!=null)
			pane.remove(feedback);
		Point pt = e.getPoint();
        
		javax.swing.SwingUtilities.convertPointToScreen(pt, e.getComponent());
		javax.swing.SwingUtilities.convertPointFromScreen(pt, pane);
                
		Component target = pane.getComponentAt(pt);
		DesignScriptNodeView source = ((DesignScriptNodeView)e.getSource());

		if (source.isSystemPrompt() && target == pane) {
			  m_model.copyScriptNodeModeltoNode(m_model.addSingleNode(pt), source.getNodeModel());
		} else if (!source.isSystemPrompt()) {
			if (target instanceof AbstNodeView){
			  m_model.copyScriptNodeModeltoLinkModel(m_model.addLink(((AbstNodeView)target).getNodeModel()),
												source.getNodeModel());
			} else if (target == pane) {
			  m_model.copyScriptNodeModeltoLinkModel(m_model.addLink(pt), source.getNodeModel());
			}
		}
		pane.repaint();
	}
  }

	/////////////////////Hongvan's code//////////////////////////////////
  /** 
   * Clicking Tab key or shiftTab key to move back and forth between cards
   * on the script bar
   */
	private class TabKeyListener extends KeyAdapter {
	public void keyPressed(KeyEvent evt) {
			if (evt.getKeyChar() == '\t') {
 
   // Locate target sub-component and tab to next (or prev) component
   for (int i = 0; i < getNumberNodes(); i++)
   {
	 // Found target sub-component
	 if (getNode(i).getView().getTextField() == evt.getComponent())
	 {
	   // Find next or previous component
	   int dir = evt.isShiftDown() ? -1 : 1;
	   int original = i;
	   for (i += dir; i != original; i += dir)
	   {
		 // Handle wrap-around
		 i = (i < 0) ? getNumberNodes() - 1 : i % getNumberNodes();
 
		 // If component can accept focus, request it and return
		 //AbstScriptNodeView focus = getNode(i).getView();
		 JTextField focus = getNode(i).getView().getTextField();
		 if (focus.isRequestFocusEnabled())
		 {
		   focus.requestFocus();
		   System.out.println("tabtabtab");
		   break;
		 }
	   }
	 }
   }
			}
		//m_model.getScriptModel().addDesignScriptNode((numScriptNodes%2 == 0), m_scriptnumber);
	}
		public void keyReleased(KeyEvent e) {
		}
		public void keyTyped(KeyEvent e) {
		}
	}
	 /////////////////////////////////////////////////////////////////////  
}