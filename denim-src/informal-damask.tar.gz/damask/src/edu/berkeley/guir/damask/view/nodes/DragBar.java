package edu.berkeley.guir.damask.view.nodes;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;
import java.util.List;

import javax.imageio.ImageIO;

import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.event.PDragSequenceEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.util.PDimension;

/** 
 * A drag bar for moving pages.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-01-2003 James Lin
 *                               Created DragBar.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-01-2003
 */
public class DragBar extends PPath {
   private final PCamera constraintCamera;
   private final PNode node;
   private int height;
   
   private static final int CORNER_RADIUS = 5;
   private static final Color BORDER_COLOR = Color.LIGHT_GRAY.darker();
   
   /**
    * Constructs a drag bar.
    */
   public DragBar(final PNode node, final PCamera constraintCamera) {
      this.constraintCamera = constraintCamera;

      try {
         final BufferedImage image =
            ImageIO.read(
               DamaskApp.class.getResource("images/page/drag_bar.gif"));
         height = image.getHeight();
         setPaint(
            new TexturePaint(
               image,
               new Rectangle2D.Double(
                  0,
                  0,
                  image.getWidth(),
                  image.getHeight())));
      }
      catch (IOException e) {
         setPaint(new Color(204, 204, 204));
         height = 12;
      }
      this.node = node;
      setPathBounds(0, 0, (float)node.getWidth(), height);
      setStrokePaint(BORDER_COLOR);

      final MouseEventHandler handler = new MouseEventHandler();
      handler.getEventFilter().setMarksAcceptedEventsAsHandled(true);
      addInputEventListener(handler);
   }


   /**
    * Adds the drag bar to the given node, and makes it sticky relative
    * to the given camera.
    */
   public static void addTo(final PNode node, final PCamera camera) {
      final DragBar dragBar = new DragBar(node, camera);
      node.addChild(dragBar);
      StickyTransformManager.setupStickyZ(
         dragBar,
         camera,
         new Point2D.Double(0, dragBar.getHeight()));
   }


   /**
    * Removes the drag bar from the given node.
    */
   public static void removeFrom(PNode node) {
      final List handles = new ArrayList();

      for (Iterator i = node.getChildrenIterator(); i.hasNext();) {
         final PNode each = (PNode)i.next();
         if (each instanceof DragBar) {
            handles.add(each);
         }
      }
      node.removeChildren(handles);
   }


   /**
    * Sets the bounding box of this drag bar to the given position and
    * dimension.
    */
   public void setPathBounds(float x, float y, float w, float h) {
      setPathTo(
         DamaskAppUtils.createHalfRoundRectangle(
            x,
            y,
            w,
            h,
            CORNER_RADIUS,
            CORNER_RADIUS));
   }

   /**
    * Returns the node that this drag bar moves.
    */
   public PNode getNode() {
      return node;
   }


   /**
    * Returns the height of the drag bar as an integer.
    */
   public int getIntHeight() {
      return height;   
   }


   /**
    * Returns the camera that this drag bar "sticks" to. 
    */
   public PCamera getConstraintCamera() {
      return constraintCamera;
   }
      

   /**
    * Listens to mouse and key events in the drag bar.
    */
   private class MouseEventHandler extends PDragSequenceEventHandler {
      public void mouseEntered(final PInputEvent event) {
         event.pushCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
      }
      
      
      public void startDrag(final PInputEvent event) {
         super.startDrag(event);
         
//         if ((node instanceof PageView) && (node.getParent() != null)) {
//				node.getParent().moveToFront();
//				((DialogView)node.getParent()).setPageContentsSelectable(true);
//				DamaskLayer mylayer = ((DialogView)node.getParent()).getLayer();
//				mylayer.updateArrows((DialogView)node.getParent());
//         }
         final PComponent eventComponent = event.getComponent();
         if (eventComponent instanceof DamaskCanvas) {
            ((DamaskCanvas)eventComponent).setWindowBoundsChanging(true);
         }
      }


      public void drag(final PInputEvent event) {
         super.drag(event);
         
         // There was a press, so drag selection
         final PDimension d = event.getCanvasDelta();
         event.getTopCamera().localToView(d);

         final PDimension gDist = new PDimension();

         gDist.setSize(d);
         node.getParent().globalToLocal(d);
         node.offset(d.getWidth(), d.getHeight());
      }


      public void endDrag(final PInputEvent event) {
         super.endDrag(event);
         final PComponent eventComponent = event.getComponent();
         if (eventComponent instanceof DamaskCanvas) {
            ((DamaskCanvas)eventComponent).setWindowBoundsChanging(false);
         }
      }

      
      public void mouseExited(final PInputEvent event) {
         event.popCursor();
      }
   }
}
