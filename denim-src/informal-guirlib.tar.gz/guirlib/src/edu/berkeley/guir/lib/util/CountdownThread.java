//// See bottom of source code for software license.
package edu.berkeley.guir.lib.util;

/**
 * A countdown timer that issues callbacks on specific times.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 18 2004
 */
abstract public class CountdownThread {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * Convenience array for 60 seconds, goes
     * <CODE>60, 50, 40, 30, 20, 10, 5, 4, 3, 2, 1, 0</CODE>
     */
    public static final int[] SECONDS_60 = {
        60, 50, 40, 30, 20, 10, 5, 4, 3, 2, 1, 0
    };

    //--------------------

    /**
     * Convenience array for 30 seconds, goes
     * <CODE>30, 20, 10, 5, 4, 3, 2, 1, 0</CODE>
     */
    public static final int[] SECONDS_30 = {
        30, 20, 10, 5, 4, 3, 2, 1, 0
    };

    //--------------------

    /**
     * Convenience array for 10 seconds, goes
     * <CODE>10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0</CODE>
     */
    public static final int[] SECONDS_10 = {
        10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0
    };

    //--------------------

    /**
     * Convenience array for 5 seconds, goes
     * <CODE>5, 4, 3, 2, 1, 0</CODE>
     */
    public static final int[] SECONDS_5 = {
        5, 4, 3, 2, 1, 0
    };
    //===   CONSTANTS   ========================================================
    //==========================================================================



    //==========================================================================
    //===   INNER CLASS - INTERNAL THREAD   ====================================

    /**
     * Does the grunt work of doing the timing.
     */
    class InternalThread extends DelayedThread {
        public void doTask() {
            //// 1. Issue the callback.
            onTime(timesArr[index++]);

            //// 2. Setup the next delay.
            if (index < timesArr.length) {
                this.setDelay((timesArr[index-1] - timesArr[index])*1000);
            }

        } // of method
    } // of inner class

    //===   INNER CLASS - INTERNAL THREAD   ====================================
    //==========================================================================



    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    int[]         timesArr;
    int           index = 0;
    DelayedThread timerThread;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================



    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Empty constructor.
     */
    public CountdownThread() {
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================



    //==========================================================================
    //===   RUN   ==============================================================

    /**
     * Start the countdown. Calling this again restarts the
     * countdown using the specified array.
     *
     * @param aTimesArr is an int array of descending times for when
     *                  {@link #onTime(int)} should be called. For example,
     *                  <CODE>{60, 50, 40, 30, 20, 10, 5, 4, 3, 2, 1}</CODE>. 
     *                  So it has a total time of 60 seconds, the 60 second 
     *                  callback is issued immediately, and the 50 second 
     *                  callback is issued in 10 seconds, etc.
     */
    public void start(int[] aTimesArr) {
        index       = 0;
        timerThread = new InternalThread();
        timesArr    = aTimesArr;
        timerThread.setDelay(0);
    } // of method

    //--------------------

    /** 
     * Override this method.
     */
    public abstract void onTime(int time);

    //--------------------

    /**
     * Abort the countdown. Ok to call multiple times.
     */
    public void abort() {
        if (timerThread != null) {
            timerThread.abort();
        }
    } // of method

    //===   RUN   ==============================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    private static CountdownThread getTestInstanceAAA() {
        return (
            new CountdownThread() {
                public void onTime(int time) {
                    System.out.println("countdown: " + time);
                }
            }
        );
    } // of method

    //----------------------------------------------------------------

    //// Test 60 seconds
    private static void runTestAAA() {
        CountdownThread t = getTestInstanceAAA();
        t.start(SECONDS_60);
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestAAA();
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
