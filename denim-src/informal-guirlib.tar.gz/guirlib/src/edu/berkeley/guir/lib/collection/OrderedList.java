//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection;

import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.io.Serializable;

/**
 * A linked list with some extra functionality, including:
 * <UL>
 *    <LI>{@link #getForwardIterator()}
 *    <LI>{@link #getReverseIterator()}
 *    <LI>{@link #swap(int, int)}
 *    <LI>{@link #moveTo(int, int)}
 *    <LI>{@link #moveToFront(int)}
 *    <LI>{@link #moveToBack(int)}
 * </UL>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Aug 31 2000 JIH
 */
public class OrderedList 
   implements List, Serializable {

   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   LinkedList list;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   ITERATOR INNER CLASSES   ============================================

   /**
    * Go through the list backwards.
    */
   class ReverseIterator
      implements Iterator {

      //========================================================================

      int index = list.size() - 1;

      //========================================================================

      public boolean hasNext() {
         return (index >= 0);
      } // of hasNext

      //========================================================================

      public Object next() {
         return (list.get(index--));
      } // of next

      //========================================================================

      public void remove() {
         list.remove(index);
      } // of remove
      
      //========================================================================

   } // of inner class ForwardIterator

   //===   ITERATOR INNER CLASSES   ============================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create a new, empty, ordered list.
    */
   public OrderedList() {
      list = new LinkedList();
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NICE METHODS   ======================================================

   /**
    * See if the index is in bounds or not.
    */
   private boolean isInBounds(int xx) {
      if (xx < 0) {
         return (false);
      }
      
      int size = list.size();
      if (xx >= size) {
         return (false);
      }

      return (true);
   } // of isInBounds

   //-----------------------------------------------------------------

   /**
    * See if the indices are in bounds or not.
    */
   private boolean isInBounds(int xx, int yy) {
      if (xx < 0 || yy < 0) {
         return (false);
      }

      int size = list.size();
      if (xx >= size || yy >= size) {
         return (false);
      }

      return (true);
   } // of isInBounds

   //-----------------------------------------------------------------

   /**
    * Get an iterator that goes through the list in forward order.
    *
    * @return an Iterator going through the list in forward order.
    */
   public Iterator getForwardIterator() {
      return (listIterator());
   } // of getForwardIterator

   //-----------------------------------------------------------------

   /**
    * Get an iterator that goes through the list in reverse order.
    * The current implementation is not as efficient as it could be,
    * but unless it ever becomes a bottleneck its just not worth optimizing.
    *
    * @return an Iterator going through the list in reverse order.
    */
   public Iterator getReverseIterator() {
      return (new ReverseIterator());
   } // of getReverseIterator

   //-----------------------------------------------------------------

   public Enumeration elements() {
      return (Collections.enumeration(list));
   } // of elements

   //-----------------------------------------------------------------

   /**
    * Add an item to the front.
    *
    * @param obj is the Object to add.
    */
   public void addToFront(Object obj) {
      add(0, obj);
   } // of addToFront

   //-----------------------------------------------------------------

   /**
    * Same as add(), just here for symmetry.
    *
    * @param obj is the Object to add.
    */
   public void addToBack(Object obj) {
      add(obj);
   } // of addToBack

   //-----------------------------------------------------------------

   /**
    * Swap two elements in the list given positions.
    * Handles boundary conditions by not doing anything if out of bounds.
    *
    * @param xx is the index of one of the items to swap. It is zero-based.
    * @param yy is the index of one of the items to swap. It is zero-based.
    */
   public synchronized void swap(int xx, int yy) {
      //// 1. Do bounds checking first.
      if ( !isInBounds(xx, yy)) {
         return;
      }

      //// 2. Swap the elements.
      Object objX = list.get(xx);
      Object objY = list.get(yy);
      list.set(xx, objY);
      list.set(yy, objX);
   } // of swap

   //-----------------------------------------------------------------

   /**
    * Move an item in the list from one position to another. Items are shifted
    * over to the left as needed. Handles boundary conditions by not doing
    * anything if out of bounds.
    *
    * @param xx is the index of the item to move from. It is zero-based.
    * @param yy is the index of the position to move to. It is zero-based.
    */
   public synchronized void moveTo(int xx, int yy) {
      //// 1. Do bounds checking first.
      if ( !isInBounds(xx, yy)) {
         return;
      }

      //// 2. This is here because add() works by inserting before the
      ////    specified element. Otherwise, get these off-by-one errors.
      if (xx < yy) {
         yy++;
      }

      //// 3. Insert the element.
      Object obj = list.get(xx);
      list.add(yy, obj);

      //// 4. Correct the index for possible displacement.
      if (yy < xx) {
         xx++;
      }
      list.remove(xx);

   } // of move

   //-----------------------------------------------------------------

   /**
    * Move the item at the specified position to the front of the Vector.
    *
    * @param xx is the index of the item to move to the front. It is zero-based.
    */
   public synchronized void moveToFront(int xx) {
      moveTo(xx, 0);
   } // of moveToFront

   //-----------------------------------------------------------------

   /**
    * Move the item at the specified position to the back of the list.
    *
    * @param xx is the index of the item to move to the back. It is zero-based.
    */
   public synchronized void moveToBack(int xx) {
      moveTo(xx, list.size() - 1);
   } // of moveToBack

   //===   NICE METHODS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   LIST METHODS   ======================================================

   /**
    * @see LinkedList#add(int, Object)
    */
   public void add(int index, Object obj) {
      list.add(index, obj);
   } // of add

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#add(Object)
    */
   public boolean add(Object obj) {
      return (list.add(obj));
   } // of add

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#addAll(Collection)
    */
   public boolean addAll(Collection c) {
      return (list.addAll(c));
   } // of addAll

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#addAll(int, Collection)
    */
   public boolean addAll(int index, Collection c) {
      return (list.addAll(index, c));
   } // of addAll

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#clear()
    */
   public void clear() {
      list.clear();
   } // of clear

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#contains(Object)
    */
   public boolean contains(Object obj) {
      return (list.contains(obj));
   } // of contains

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#containsAll(Collection)
    */
   public boolean containsAll(Collection c) {
      return (list.containsAll(c));
   } // of containsAll

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#equals(Object)
    */
   public boolean equals(Object obj) {
      return (list.equals(obj));
   } // of equals

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#get(int)
    */
   public Object get(int index) {
      return (list.get(index));
   } // of get

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#hashCode()
    */
   public int hashCode() {
      return (list.hashCode());
   } // of hashCode

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#indexOf(Object)
    */
   public int indexOf(Object obj) {
      return (list.indexOf(obj));
   } // of indexOf

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#isEmpty()
    */
   public boolean isEmpty() {
      return (list.isEmpty());
   } // of isEmpty

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#iterator()
    */
   public Iterator iterator() {
      return (list.iterator());
   } // of iterator

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#lastIndexOf(Object)
    */
   public int lastIndexOf(Object obj) {
      return (list.lastIndexOf(obj));
   } // of lastIndexOf

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#listIterator()
    */
   public ListIterator listIterator() {
      return (list.listIterator());
   } // of listIterator

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#listIterator(int)
    */
   public ListIterator listIterator(int index) {
      return (list.listIterator(index));
   } // of listIterator

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#remove(int)
    */
   public Object remove(int index) {
      return (list.remove(index));
   } // of remove

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#remove(Object)
    */
   public boolean remove(Object obj) {
      return (list.remove(obj));
   } // of remove

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#removeAll(Collection)
    */
   public boolean removeAll(Collection c) {
      return (list.removeAll(c));
   } // of removeAll

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#retainAll(Collection)
    */
   public boolean retainAll(Collection c) {
      return (list.retainAll(c));
   } // of retainAll

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#set(int, Object)
    */
   public Object set(int index, Object obj) {
      return (list.set(index, obj));
   } // of set

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#size()
    */
   public int size() {
      return (list.size());
   } // of size

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#subList(int, int)
    */
   public List subList(int fromIndex, int toIndex) {
      return (list.subList(fromIndex, toIndex));
   } // of subList

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#toArray()
    */
   public Object[] toArray() {
      return (list.toArray());
   } // of toArray

   //-----------------------------------------------------------------

   /**
    * @see LinkedList#toArray(Object[])
    */
   public Object[] toArray(Object[] a) {
      return (list.toArray(a));
   } // of toArray

   //===   LIST METHODS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Make a shallow copy.
    */
   public Object clone() {
      OrderedList l = new OrderedList();
      l.list = (LinkedList) this.list.clone();

      return (l);
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      StringBuffer strbuf = new StringBuffer();
      Iterator     it     = getForwardIterator();
      Object       obj;

      strbuf.append("[");

      while (it.hasNext()) {
         obj = it.next();
         strbuf.append(obj.toString());
         strbuf.append(", ");
      }

      strbuf.append("]");

      return (strbuf.toString());

   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static void main(String[] argv) {
      OrderedList list = new OrderedList();

      list.add(new Integer(0));
      list.add(new Integer(1));
      list.add(new Integer(2));
      list.add(new Integer(3));

      System.out.println(list);

      list.moveTo(0, 3); // move item 0 to end
      System.out.println(list);
      list.moveTo(0, 0); // no effect
      System.out.println(list);
      list.moveTo(0, 4); // no effect
      System.out.println(list);
      list.moveTo(4, 0); // no effect
      System.out.println(list);

      System.out.println();
      list.moveTo(3, 0);
      System.out.println(list);
      list.moveTo(3, 1);
      System.out.println(list);
      list.moveTo(3, 2);
      System.out.println(list);
      list.moveTo(3, 3); // no effect
      System.out.println(list);

      System.out.println();
      list.moveTo(1, 2);  // move item 1 to slot 2
      System.out.println(list);
      list.moveTo(1, 3);  // move item 1 to slot 3
      System.out.println(list);
      list.moveToBack(0);  // move item 0 to back
      System.out.println(list);
      list.moveToBack(1);  // move item 1 to back
      System.out.println(list);
      list.moveToBack(2);  // move item 2 to back
      System.out.println(list);
      list.moveToBack(3);  // move item 3 to back
      System.out.println(list);
      list.moveToBack(4);  // no effect
      System.out.println(list);

      System.out.println();
      list.moveToFront(0);  // move item 0 to front, no effect
      System.out.println(list);
      list.moveToFront(1);  // move item 1 to front
      System.out.println(list);
      list.moveToFront(2);  // move item 2 to front
      System.out.println(list);
      list.moveToFront(3);  // move item 3 to front
      System.out.println(list);
      list.moveToFront(4);  // no effect
      System.out.println(list);

      System.out.println();

      System.out.println(list);
      list.swap(0, 1);  // move down
      System.out.println(list);
      list.swap(3, 2);  // move up
      System.out.println(list);
      list.swap(3, 4);  // fail to move down
      System.out.println(list);
      list.swap(0, -1);  // fail to move up
      System.out.println(list);

      list.get(12);

   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of Class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
