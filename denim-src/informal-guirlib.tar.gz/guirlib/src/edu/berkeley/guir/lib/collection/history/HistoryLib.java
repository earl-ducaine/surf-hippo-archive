//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.history;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import edu.berkeley.guir.lib.util.filter.DateFilter;
import edu.berkeley.guir.lib.util.filter.Filter;
import edu.berkeley.guir.lib.util.filter.ReverseFilter;
import edu.berkeley.guir.lib.util.filter.StringFilter;

/**
 * Lots of methods for manipulating History. The reason this is
 * here rather than in History is b/c of subclassing issues. A lot
 * of these methods return <CODE>History</CODE> instances, which
 * makes it impossible to have subclasses that return instances
 * of themselves. 
 * <P>
 * The basic way these methods should be used is to get
 * the <CODE>HistoryEvent</CODE> or <CODE>History</CODE> that
 * is desired, and then wrap it up in the appropriate wrapper
 * so that it will have the proper class.
 * <P>
 * This is what happens when you have a programming language that
 * has strict interface API contracts and does not allow covariants.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 20 2003, JH
 */
public class HistoryLib {

    //==========================================================================
    //===   CLASS METHODS AND VARIABLES   ======================================

    public static final DateFormat DEFAULT_DATEFORMAT =
                                 new SimpleDateFormat("yyyy.MM.dd HH:mm:ss z");

    //----------------------------------------------------------------

    static DateFormat df = DEFAULT_DATEFORMAT;

    /**
     */
    public static void setDefaultDateFormat(DateFormat newDateFormat) {
        df = newDateFormat;
    } // of method


    /**
     */
    public static DateFormat getDefaultDateFormat() {
        return (df);
    } // of method

    //===   CLASS METHODS AND VARIABLES   ======================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * No instances allowed.
     */
    private HistoryLib() {
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   HISTORY MERGE METHODS   ============================================

    /**
     * Merge this History with another History. For example,
     * (historyAA <B>or</B> historyBB), does not modify either History.
     * <P>
     * Creates a <I>shallow</I> copy (rather than creating new HistoryEvent
     * instances).
     * <P>
     * O(N + M) operation, where N and M are the sizes of the histories.
     *
     * @param historyAA  is a History object to merge
     * @param historyBB  is a History object to merge
     * @param hOut is the History to merge into
     */
    public static History mergeOr(History historyAA, 
                                  History historyBB,
                                  History hOut) {
        hOut.addAllEvents(historyAA);
        hOut.addAllEvents(historyBB);
        return (hOut);
    } // of method

    //----------------------------------------------------------------

    /**
     * (historyAA - historyBB), does not modify either History.
     * <P>
     * Creates a <I>shallow</I> copy (rather than creating new HistoryEvent
     * instances).
     * <P>
     * O(NM) operation, where N is size of historyAA, M is size of historyBB.
     */
    public static History mergeSubtract(History historyAA, 
                                        History historyBB,
                                        History hOut) {
        Iterator     it   = historyBB.events();
        HistoryEvent evt;

        //// 1. Subtract out whatever is in historyBB.
        while (it.hasNext()) {
            evt = (HistoryEvent) it.next();
            hOut.removeEvent(evt);
        }
        return (hOut);
    } // of method

    //----------------------------------------------------------------

    /**
     * (historyAA <B>and</B> historyBB), does not modify either History.
     * <P>
     * Creates a <I>shallow</I> copy (rather than creating new HistoryEvent
     * instances).
     * <P>
     * O(NM) operation, where N is size of historyAA, M is size of historyBB.
     * @return a new History object.
     */
    public static History mergeAnd(History historyAA, 
                                   History historyBB,
                                   History hOut) {
        Iterator     it   = historyBB.events();
        HistoryEvent evt;

        while (it.hasNext()) {
            evt = (HistoryEvent) it.next();
            if (historyAA.containsEvent(evt) == true) {
                hOut.addEvent(evt);
            }
        }

        return (hOut);
    } // of method

    //===   HISTORY MERGE METHODS   ============================================
    //==========================================================================




    //==========================================================================
    //===   HISTORY FILTER METHODS   ===========================================

    /**
     * Create a filtered History object without modifying the original.
     * @return a new History object (shallow).
     */
    public static History filter(History history, Filter f, History hOut) {
        Iterator     it   = history.events();
        HistoryEvent evt;

        //// 1. Go through each HistoryEvent and see if it is accepted.
        ////    If so, add it to the new History copy.
        while (it.hasNext()) {
            evt = (HistoryEvent) it.next();
            if (f.isAccepted(evt) == true) {
                hOut.addEvent(evt);
            }
        }

        //// 2. Return.
        return (hOut);
    } // of method

    //--------------------

    /**
     *
     */
    public static History filter(History history, Filter f) {
        return (filter(history, f, new HistoryDefaultImpl()));
    } // of method

    //----------------------------------------------------------------

    /**
     * Keep everything between these two dates.
     *
     * @param dStart is the start date. If the start date is null
     *               then keep everything before the end date.
     * @param dEnd   is the end date. If the end date is null,
     *               then keep everything after the start date.
     * @return a new History object (shallow).
     */
    public static History filterByDate(History h, 
                                       Date    dStart, 
                                       Date    dEnd,
                                       History hOut) {

        Filter f = new HistoryEventFilterByField(HistoryEvent.KEY_DATE,
                              new DateFilter(dStart, dEnd, df));
        return ( filter(h, f, hOut));
    } // of method


    /**
     *
     */
    public static History filterByDate(History h, 
                                       Date    dStart, 
                                       Date    dEnd) {
        return (filterByDate(h, dStart, dEnd, new HistoryDefaultImpl()));
    } // of method

    //--------------------

    /**
     * Remove everything after this date.
     * @return a new History object (shallow).
     */
    public static History filterAllAfterDate(History h, 
                                             Date    dEnd,
                                             History hOut) {
        Filter f = new HistoryEventFilterByField(HistoryEvent.KEY_DATE,
                              new DateFilter(null, dEnd, df));
        return ( filter(h, f, hOut));
    } // of method


    /**
     *
     */
    public static History filterAllAfterDate(History h, 
                                             Date    dEnd) {
        return (filterAllAfterDate(h, dEnd, new HistoryDefaultImpl()));
    } // of method

    //--------------------

    /**
     * Remove everything before this date.
     * @return a new History object (shallow).
     */
    public static History filterAllBeforeDate(History h, 
                                              Date    dStart,
                                              History hOut) {

        Filter f = new HistoryEventFilterByField(HistoryEvent.KEY_DATE,
                              new DateFilter(dStart, null, df));
        return ( filter(h, f, hOut));
    } // of method


    /**
     *
     */
    public static History filterAllBeforeDate(History h, 
                                              Date    dStart) {
        return (filterAllBeforeDate(h, dStart, new HistoryDefaultImpl()));
    } // of method

    //----------------------------------------------------------------

    /**
     * Assumes string value.
     * @param strField   is the name of the field to filter by.
     * @param strPattern is the pattern to match
     * @param flagAccept is true if the matched patterns should be kept,
     *                   false if they should be rejected
     * @return a new History object (shallow).
     */
    public static History filterByField(History h,
                                        String  strField, 
                                        String  strPattern,
                                        boolean flagAccept,
                                        History hOut) {

        Filter f = new HistoryEventFilterByField(strField, 
                                                 new StringFilter(strPattern));
        if (flagAccept == false) {
            f = new ReverseFilter(f);
        }
        return (filter(h, f, hOut));
    } // of method

    //--------------------

    /**
     *
     */
    public static History filterByField(History h,
                                        String  strField, 
                                        String  strPattern,
                                        boolean flagAccept) {
        return (filterByField(h, strField, strPattern, 
                        flagAccept, new HistoryDefaultImpl()));
    } // of method

    //===   HISTORY FILTER METHODS   ===========================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
