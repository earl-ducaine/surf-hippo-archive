/*
 * SaveMgr.java
 * Created May 2002
 */

package edu.berkeley.guir.lib.satin.remote;

import edu.berkeley.guir.lib.satin.command.*;

/**
 * @author  Katie Everitt, Robert Lee
 * @version 1.4
 */
public class SaveMgr extends InOutMgr {
   private FileIncomingOpen m_open = null;
   private FileOutgoingSave m_save = null;   

   public SaveMgr(RemoteCommandQueue listener){
      super(listener);      
      //start();
   }
   
   public void OpenFrom(String filename) {
      // we may not want to open the same file we saved to.
      m_open = new FileIncomingOpen(this, filename);
      m_open.start();      
      
   }   
   
   public void SaveTo(String filename) {
      m_save = new FileOutgoingSave(this, filename);
      m_save.start();      
   }
}