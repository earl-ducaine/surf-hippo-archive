package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that removes a component group from a page region.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  05-31-2004 James Lin
 *                               Created RemoveGroupCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 05-31-2004
 */
public class RemoveGroupCommand extends UndoableCommand
   implements ModifyGraphCommand {
   
   private Dialog dialog;
   private final ComponentGroup group;
   private ComponentGroup parentGroup;
   
   /**
    * Constructs the command.
    *  
    * @param control the control to remove
    */      
   public RemoveGroupCommand(final ComponentGroup group) {
      this.group = group;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Remove component group " + group;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      dialog = group.getDialog();
      dialog.removeGroup(group);
      parentGroup = group.getGroup();
      if (parentGroup != null) {
         parentGroup.remove(group);
      }
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      dialog.addGroup(group);
      if (parentGroup != null) {
         parentGroup.add(group);
      }
   }
}
