package edu.berkeley.guir.lib.gesture;

import java.awt.*;
import java.awt.event.*;
import edu.berkeley.guir.lib.gesture.util.CTable;

class ToolTipUpdater extends MouseMotionAdapter
{
  CTable table;

  ToolTipUpdater(CTable table)
  {
    this.table = table;
  }
  
  public void mouseMoved(MouseEvent e)
  {
    Point position = new Point(e.getX(), e.getY());
    int row = table.rowAtPoint(position);
    int col = table.columnAtPoint(position);
    String toolTip;
    if ((row == -1) || (col == -1)) {
      toolTip = null;
    }
    else {
      String rowName = table.getRowName(row);
      String colName = table.getColumnName(col);
      toolTip = rowName + " x " + colName;
    }
    table.setToolTipText(toolTip);
  }
}
