//// See bottom of source code for software license


package edu.berkeley.guir.lib.satin.stroke;

import java.awt.*;
import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.objects.*;
   
/**
 * A stroke that is based off TimedStroke.  The underlying representation of
 * TimedStroke is kept for the gesture interpretor and other interpretors.
 * There are two additional public methods: changeSource and changeDest.
 * These two methods take in a point in local coordinates and transform the
 * GeneralPath by rotating and scaling so that the source or destination of
 * the stroke will lie on that point.  After a stroke is created, the only
 * data saved is in the GeneralPath thePath.  TimedCurvyStroke basically
 * only adds a different rendering of the stroke, leaving as much of
 * TimedStroke intact as possible.
 *
 * <p>There are two properties of the curve stroke that can be changed.  One
 * is the convolution window size (ability to catch corners) through
 * setFilterSize(int k). The other is the THRESHHOLD (tendancy to set control
 * points making a curve smoother or more true to the original) through
 * setThreshhold(float myDegrees).  SetNoKinks and setWithKinks determines
 * whether control points are chosen such that the curve will be
 * respectively C1 continuous or not C1 continuous.
 *
 * <p>StrokeAssembler has the variable CURVYCODE which when true will call
 * TimedCurvyStroke instead of TimedStroke.  When CURVYCODE is false, it
 * will be like TimedCurvyStroke does not exist.
 *
 * <p>There are several stages in adding a point.  Here are the basic steps:
 *
 * <ol>
 * <li>The point gets added into the polygon in TimedStroke
 * <li>The angle is calculated through the method addDirectAngle and placed
 *     in the array directAngle.
 * <li>The angles in direct angle are convoluted through a triangle filter
 *     and placed in the array triangleFilteredAngle.
 * <li>The control points are chosen from triangleFiltered angle and placed
 *     in both the curveDraw array and the GeneralPath thePath.
 * <li>All the arrays are deleted to save memory.
 * </ol>
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions: - July 20 2001, Robert Lee
 * 			      Created class
 * 			  - SATIN-v2.1-2.0.0, Nov 6 2002, YL
 * 				  Modifed damageAroundPoint to enable idle render
 * 				  Fixed the bugs of disappearing arrows
 *            - SATIN-v2.1-2.0.0, Mar 26 2002, YL 
 *               Add hollow selection style in
 * 
 * </PRE>
 *
 * @author Robert Lee (
 *         <A HREF="mailto:roblee@cs.berkeley.edu">roblee@cs.berkeley.edu</A> )
 * @since   JDK 1.3.1
 * @version SATIN-v2.1-2.0.0, Mar 26 2003
 */

public class TimedCurvyStroke
	extends TimedStroke
	implements SatinConstants {

	private static final Color SELECTED_COLOR = new Color(210, 0,0);//145, 145); //pink
	private static final int SELECTED_WIDTH = 6;

	//===========================================================================
	//===   NONLOCAL INSTANCE VARIABLES   =======================================

	private GeneralPath thePath = new GeneralPath(GeneralPath.WIND_EVEN_ODD);

	//===   NONLOCAL INSTANCE VARIABLES   =======================================
	//===========================================================================



	//==========================================================================
	//===   CLASS VARIABLES   ==================================================

	private boolean thisIsALink = false;
	private boolean doNotRender = false;

	// MAX_MOUSE_POINTS can be big because the array gets thrown away
	// after being used.
	private static int MAX_MOUSE_POINTS = 210;
	private boolean drawingLine;
	private float directAngle[ ] = new float[MAX_MOUSE_POINTS];
	private int directAngleSize;

	//triangle Filter variables
	private float triangleFilteredAngle[] = new float[MAX_MOUSE_POINTS];
	private int triangleArraySize;

	// 1.  This variable determines the convolution window.
	private int	triangleFilterSize = 5;
	private int curveDraw[ ] = new int[MAX_MOUSE_POINTS];
	private int curveDrawSize;

	//Finding control points
	private int recentAngleNum;
   
	private boolean isSelectionRenderEnabled = true;

	// 2.  This variable determines the sensitivity of when control points
	//     are added. Degrees is represented in angle degrees, where 360 is
	//     a full circle.
	private float degrees = 70.0f;
	private float THRESHHOLD = degrees * ((float)Math.PI/180.0f);

	// For Kinkless control points.  Keeps track of tangent vectors.
	private boolean endTangentExist = false;
	private float endTangent;
	private boolean noKinks = true;

	// For optimization
	private GeneralPath theEndLine = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
	private boolean lineDone = false;
	private Point2D ptA = new Point2D.Float();
	private Point2D ptB = new Point2D.Float();

	// This variable controls at what degree a bend should be at before it is
	// detected as a corner (in angle).  The angle below and the actual angle
	// of detection differ because a convolution is taken before the
	// comparison.
	private float cornerDegree = 70;

	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	/**
	 * Create an empty TimedCurvyStroke.
	 */
	public TimedCurvyStroke() {
		super();
		initializations();
	}  // of constructor


	public TimedCurvyStroke(Polygon2D p) {

		//// 1. Initializations.
		super();
		initializations();
		TimedPolygon2D tempPoly;
		if (p instanceof TimedPolygon2D) {
			tempPoly = new TimedPolygon2D((TimedPolygon2D) p);
		}
		else {
			tempPoly = new TimedPolygon2D(p);
		}
		int index=0;
		while (index < tempPoly.npoints) {
			addPoint((int)tempPoly.xpoints[index], (int)tempPoly.ypoints[index]);
			index++;
		}
		setLocalBoundingPoints2DRef(poly);
		setHasClosedBoundingPoints(false);
		doneAddingPoints();
	}


	public TimedCurvyStroke(TimedStroke tstk) {
		super();
		initializations();

		// Copy the points from the original stroke.
		TimedPolygon2D tempPoly = tstk.getPolygon2D(COORD_LOCAL);
		for (int index = 0; index < tempPoly.npoints; index++) {
			addPoint((int)tempPoly.xpoints[index], (int)tempPoly.ypoints[index]);
		}
		poly = tempPoly;

		// This is to keep the timing information.
		this.setTransform(tstk.getTransform(COORD_REL));
		setHasClosedBoundingPoints(false);

		// Calculate length
		this.length = tstk.length;
		doneAddingPoints();

		this.setLocalBoundingPoints2DRef(poly);
	}

	/**
	 * This constructor changes a Timedstroke that has been recognized as
	 * regular style into link style, which means it will be smooth and corner
	 * detecting is turned to a minimum.
	 *
	 * @param isLink True will turn corner detecting down.  False is the
	 *               default value.
	 */
	public TimedCurvyStroke(TimedStroke tstk, boolean isLink) {
		this(tstk);

		thisIsALink = isLink;
		if (isLink) {
			cornerDegree = 140;
		}
	}

	public TimedCurvyStroke(TimedCurvyStroke tcstk) {
		super();
		initializations();
		TimedPolygon2D tempPoly = tcstk.getPolygon2D(COORD_LOCAL);
		this.thePath = tcstk.thePath;

		// This is to keep the timing information.
		poly = tempPoly;
		this.setTransform(tcstk.getTransform(COORD_REL));
		setHasClosedBoundingPoints(false);

		// Calculate length.
		this.length = tcstk.length;
		doneAddingPoints();
      
		this.setLocalBoundingPoints2DRef(poly);
	}



	//===   CONSTRUCTORS   ======================================================
	//===========================================================================

	/**
	 * Initialize a lot of variables.  Call this method to begin to "reset"
	 * this object.  The convolution window size and angle threshhold will
	 * not be affected.
	 */
	private void initializations() {
		synchronized (poly) {
			super.clearPoints();
		}
		// -- Reset the path.
		thePath.reset();
		if (lineDone) {
			// -- Create the needed tempoaray arrays.
			directAngle = new float[MAX_MOUSE_POINTS];
			triangleFilteredAngle = new float[MAX_MOUSE_POINTS];
			curveDraw = new int[MAX_MOUSE_POINTS];
		}

		// -- Initialize the variables
		drawingLine = false;
		directAngleSize = 0;
		triangleArraySize = 0;

		curveDrawSize = 0;
		recentAngleNum = -1;

		theEndLine.reset();
		lineDone = false;

		endTangentExist = false;
	}


	/**
	 * Changes the convolution window.  Controls how close corners are
	 * "caught" by control points.  The function will have no effect if a
	 * line is in the process of being drawn.
	 *
	 * @param mySize is the size of the convolution window.
	 */
	public void setFilterSize(int mySize) {
		if (drawingLine == false) {
			triangleFilterSize = mySize;
		}
	}


	/**
	 * Changes the threshhold angle.  Controls the amount of control points
	 * chosen, which effects the smoothness of the curve. The function will
	 * have no effect if a line is in the process of being drawn.
	 *
	 * @param myDegree is the threshhold angle in degrees.
	 */
	public void setThreshhold(float myDegree) {
		if (drawingLine == false) {
			degrees = myDegree;
			THRESHHOLD = degrees*((float)Math.PI/180.0f);
		}
	} // of method

	/**
	 * Changes whether curvy strokes are rendered or not.
	 *
	 * @param var is a boolean when true, will render the stroke as a curvy
	 *        stroke while a false will render the line as a regular timed stroke
	 */

	public void setRenderCurvy(boolean var){
		if(!var){
			doNotRender = true;
		}else{
			doNotRender = false;
		}
	}

	/**
	 * Changes the angle at which a corner is detected.  The difference
	 * between this variable and setThreshhold is that setThreshhold controls
	 * the absolute angle so that a control point will be detected after a
	 * bend is long enough while cornerThreshhold will not detect a corner
	 * if the bend is smooth enough.
	 *
	 * @param myCornerThresh is the corner threshhold angle in degrees.
	 */
	public void setCornerThreshhold(float myCornerThresh){
		cornerDegree = myCornerThresh;
	} // of method


	/**
	 * Sets the curve to choose points so that there will
	 * be no kinks in the curve.
	 */
	public void setNoKinks() {
		noKinks = true;
	} // of method


	/**
	 * Sets the curve to choose points so that there will
	 * be no kinks in the curve.
	 */
	public void setWithKinks() {
		noKinks = false;
	} // of method

	//===========================================================================
	//===   OVERRIDING METHODS   ================================================

	/**
	 * Finishes processing the line
	 * Completes thePath. Deletes temporary arrays.
	 */

	public TimedStroke doneAddingPoints() {
		if (noKinks) {
			findKinklessControlPoints(triangleFilterSize, 1);
		} else {
			findControlPoints(triangleFilterSize, 1);
		}
      
        if(this.getSheet()!=null)
        {
    		if(this.getSheet().isIdleRenderingMode())
    		{
    		 damage(SatinConstants.DAMAGE_IDLE, this);
    		}
    		else
    		{
    			damage(SatinConstants.DAMAGE_LATER, this);	
    		}
        }
        
		drawingLine = false;
		ViewHandler k = getViewHandler();
		Point2D yay  = k.normalizeBoundingPoints();
		if (yay!=null) {
			thePath.transform(AffineTransform.getTranslateInstance(yay.getX(), yay.getY()));
		}

		// No more points may be added.
		// Let garbage collector collect helpful temporary arrays
		// Don't add any more points or face the wrath of null pointer exception.

		lineDone = true;
		directAngle = null;
		triangleFilteredAngle = null;
		curveDraw = null;

		return super.doneAddingPoints();
		//TimedStroke temp = super.doneAddingPoints();
		//changeDest(50, 50);
		//return temp;
	}  // of method




	/**
	 * Simply reinitializes everything
	 */
	public void clearPoints() {
		initializations();
	}
   
	public void enableSelectionRender(boolean b) {
		isSelectionRenderEnabled = b;
	}

	/**
	 * Adds a point to the line.  Remember to use a consistent coordinate system.
	 *
	 * @param myX is x position to add
	 * @param myY is y position to add
	 * @param time is the time of the point
	 */
	public void addPoint(float myX, float myY, long time) {
		//	Stores recently dragged point into the raw point array directPoint[]
		if (pointFilter(myX, myY)) {
			synchronized (poly) {
				poly.addPoint(myX, myY, time);
			}
			if ((curveDrawSize >= curveDraw.length-5) || (directAngleSize >= directAngle.length-5)) {
				expandArrays();
			}
			// Processes the new point
			synchronized (this) {
				if (poly.npoints>1) {
					if (addDirectAngle()) {
						triangleFilter( triangleFilterSize );
					}
				}
			}
			// Update the length.
			updateLength();
			// Will need later although not yet implemented

			damageEnd();
		}
	}

	/**
	 * This method paints the screen with the current line.
	 * It refreshes the complete line.
	 */
    protected void defaultRender(SatinGraphics g) {
        if(widthScalingInvariantDrawing)
        {
            Polygon2D p = (Polygon2D)poly.clone();
            p.transform(g.getTransform());
            try
            {
                g.pushTransform(g.getTransform().createInverse());
                TimedCurvyStroke stk = new TimedCurvyStroke(p);
                g.pushTransform(stk.getTransformRef());
                stk.render(g);
                g.popTransform();
                g.popTransform();
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }
        else
        {
            this.internalDdefaultRender(g);
        }
    }
    
	protected void internalDdefaultRender(SatinGraphics g) {
		//  Gestures will retain original drawing methods
		if (isRightButton() || doNotRender) {
			super.defaultRender(g);
			return;
		}

		if (cmdsubsys.isSelected(this)&&this.isSelectionRenderEnabled) {
			g.setColor(SELECTED_COLOR);
			g.setStroke(new BasicStroke(SELECTED_WIDTH));
			g.draw(thePath);
			g.setStroke(this.getStyleRef().getDrawStroke());
			g.setColor(Color.white);//this.getStyleRef().getDrawColor());
		}

		g.draw(thePath);
		//  This Draws the end of the line if the line is not yet completed.
		//  This is needed because an n convolution does not handle the last n-1
		//  points. Straight line is simply used to connect the points
		if (!lineDone) {
			int lastDrawn;
			if (curveDrawSize == 0) {
				lastDrawn = 0;
			} else {
				lastDrawn = curveDraw[curveDrawSize-1];
			}

			if ( lastDrawn >= poly.npoints-triangleFilterSize ) {
				//do nothing
			} else {
				lastDrawn = poly.npoints - triangleFilterSize;
			}
			theEndLine.reset();
			int currentPointIndex;
			if (curveDrawSize!=0) {
				currentPointIndex = curveDraw[ curveDrawSize-1 ];
			} else {
				currentPointIndex = 0;
			}

			theEndLine.moveTo(poly.xpoints[currentPointIndex],
									poly.ypoints[currentPointIndex]);
			lastDrawn = poly.npoints-1;
			float xpoint = poly.xpoints[lastDrawn];
			float ypoint = poly.ypoints[lastDrawn];
			theEndLine.curveTo(poly.xpoints[currentPointIndex + (lastDrawn-currentPointIndex)/3],
									 poly.ypoints[currentPointIndex + (lastDrawn-currentPointIndex)/3],
									 poly.xpoints[currentPointIndex + 2*(lastDrawn-currentPointIndex)/3],
									 poly.ypoints[currentPointIndex + 2*(lastDrawn-currentPointIndex)/3],
									 xpoint,
									 ypoint );
			g.draw(theEndLine);
		}
	} // of method


	/**
	 * This method does nothing, as the selection feedback (color) is
	 * handled by defaultRender()
	 */
	protected void renderSelected(SatinGraphics g, Rectangle2D rect) {}


	/**
	 * This method damages the end of the stroke to update it
	 */
	private void damageEnd() {
		float minX = 0;
		float maxX = 0;
		float minY = 0;
		float maxY = 0;
		if (!lineDone) {
			int lastDrawn;
			if (curveDrawSize == 0) {
				lastDrawn = 0;
			} else {
				lastDrawn = curveDraw[curveDrawSize-1];
			}

			if ( lastDrawn >= poly.npoints-triangleFilterSize ) {
				//do nothing
			} else {
				lastDrawn = poly.npoints - triangleFilterSize;
			}
			int currentPointIndex;
			if (curveDrawSize!=0 && noKinks) {
				if (curveDrawSize > 4) {
					currentPointIndex = curveDraw[ curveDrawSize-4 ];
				} else {
					currentPointIndex = curveDraw[ curveDrawSize-1 ];
				}
			} else {
				currentPointIndex = 0;
			}
			minX = poly.xpoints[currentPointIndex];
			minY = poly.ypoints[currentPointIndex];
			maxX = poly.xpoints[currentPointIndex];
			maxY = poly.ypoints[currentPointIndex];
			float xpoint;
			float ypoint;
			int currPoint = currentPointIndex+1;
			while (currPoint<poly.npoints) {
				xpoint = poly.xpoints[currPoint];
				ypoint = poly.ypoints[currPoint];
				minX = Math.min(xpoint, minX);
				maxX = Math.max(xpoint, maxX);
				minY = Math.min(ypoint, minY);
				maxY = Math.max(ypoint, maxY);
				if (currPoint<lastDrawn) {
					currPoint = currPoint+5;
				} else {
					currPoint++;
				}
			}
		}


		if (maxX == 0 && maxY == 0 && minX == 0 && minY == 0) {
			//do nothing
		} else {
			ptA.setLocation(minX, minY);
			ptB.setLocation(maxX, maxY);
			txBuffer = getTransform(COORD_ABS, txBuffer);
			txBuffer.transform(ptA, ptA);
			txBuffer.transform(ptB, ptB);

			int width = ((int) getStyleRef().getLineWidth()) + 1;
			damageRect.setRect(ptA.getX(), ptA.getY(),
									 Math.abs(ptB.getX()-ptA.getX())+width+2,
									 Math.abs(ptB.getY()-ptA.getY())+width+2);
            if(this.getSheet()!=null)
            {
    		  if(this.getSheet().isIdleRenderingMode())
    		  {
    			 damage(SatinConstants.DAMAGE_IDLE, damageRect);
    		  }
    		  else
    		  {
    			damage(SatinConstants.DAMAGE_LATER, damageRect);	
    		  }
            }
                           
		}
	} // of method

	//===   OVERRIDING METHODS   ================================================
	//===========================================================================



	//===========================================================================
	//===   CLONE   =============================================================

	/**
	 * Create a duplicate of this stroke.
	 *
	 * @return a duplicated Stroke.
	 */
	public Object clone() {
		TimedCurvyStroke stk = new TimedCurvyStroke(this, thisIsALink);
		clone(stk);
		return(stk);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * For clone chaining purposes.
	 *
	 * @see GraphicalObjectImpl#clone(GraphicalObjectImpl)
	 */
	protected TimedCurvyStroke clone(TimedCurvyStroke stk) {
		//// 1. First call the superclass clone for clone chaining.
		super.clone(stk);
        copyInternal(stk); 
		return (stk);
	} // of clone
    
    private void copyInternal(TimedCurvyStroke stk) {
        
        if(this.thePath!=null)
            stk.thePath = (GeneralPath)thePath.clone();
        
        stk.thisIsALink = this.thisIsALink;
        stk.doNotRender = this.doNotRender;
        stk.drawingLine = this.drawingLine;
        
        if(this.directAngle!=null)
            stk.directAngle = (float[])this.directAngle.clone();
        
        stk.directAngleSize = this.directAngleSize;
        
        if(this.triangleFilteredAngle!=null)
            stk.triangleFilteredAngle = (float[])this.triangleFilteredAngle.clone();
        
        stk.triangleArraySize = this.triangleArraySize;        
        stk.triangleFilterSize = this.triangleFilterSize;
        
        if(this.curveDraw!=null)
            stk.curveDraw = (int[])this.curveDraw.clone();
        
        stk.curveDrawSize = this.curveDrawSize;
        stk.recentAngleNum  = this.recentAngleNum;
        stk.degrees = this.degrees;
        stk.THRESHHOLD = this.THRESHHOLD;
        stk.isSelectionRenderEnabled = this.isSelectionRenderEnabled;
        stk.endTangentExist = this.endTangentExist;
        stk.endTangent = this.endTangent;
        stk.noKinks = this.noKinks;

        if(this.theEndLine!=null)
            stk.theEndLine = (GeneralPath)this.theEndLine.clone();
        
        stk.lineDone = this.lineDone;
        stk.ptA = new Point2D.Float((float)ptA.getX(),(float)ptB.getY());
        stk.ptB = new Point2D.Float((float)ptB.getX(),(float)ptB.getY());
        stk.cornerDegree = this.cornerDegree;
    }

	//-----------------------------------------------------------------

	public Object deepClone() {
		return (this.clone());
	} // of deepClone

	//-----------------------------------------------------------------

	protected Object deepClone(TimedCurvyStroke gobClone) {
		return (clone(gobClone));
	} // of deepClone


	//===   CLONE   =============================================================
	//===========================================================================


	/**
	 * This is a private method to that converts the points in poly to angles
	 * the points make.  The first step of the pipeline.
	 */
	private boolean addDirectAngle() {

		if (poly.npoints<2) {
			return false;
		}
		float diffX = poly.xpoints[poly.npoints-1] - poly.xpoints[poly.npoints-2];
		float diffY = poly.ypoints[poly.npoints-1] - poly.ypoints[poly.npoints-2];
		float initialGuessAngle;
		if (diffX == 0) {
			if (diffY > 0.0) {
				initialGuessAngle = (float)Math.PI*3.0f/2.0f;
			} else if (diffY == 0.0) {
				synchronized (poly) {
					poly.npoints--;
				}
				return false;
			} else {  //diffY<0
				initialGuessAngle = (float)Math.PI/2.0f;
			}
		} else {
			initialGuessAngle = convertMouse2PI( (float)Math.atan(diffY/diffX ), diffX, diffY );
		}

		//putting the initial guess into the array by finding sum/difference of angles
		if (directAngleSize==0) {
			directAngle[0] = initialGuessAngle;
			directAngleSize++;
			return true;
		} else {
			//Finding the angle difference with the previous angle
			float previousAngle = within2PI( directAngle[poly.npoints-3] );
			float angleDiff = initialGuessAngle - previousAngle;
			if ( Math.abs(angleDiff) > Math.abs(initialGuessAngle-(previousAngle+2*Math.PI)) ) {
				angleDiff = initialGuessAngle - (previousAngle+2.0f*(float)Math.PI);
			}
			if ( Math.abs(angleDiff) > Math.abs((initialGuessAngle+2*Math.PI)-previousAngle) ) {
				angleDiff = (initialGuessAngle + 2f*(float)Math.PI) - previousAngle;
			}

			directAngle[ poly.npoints-2 ] = directAngle[poly.npoints-3] + angleDiff;
			directAngleSize++;
			return true;
		}
	} // of method


	/**
	 * This method converts a radian angle to a radian angle within 2PI.
	 */
	private float convert2PI( float radAngle, float diffX, float diffY ) {
		if ( diffY>=0 && diffX >=0 ) {      //quadrant I
			return within2PI(radAngle);
		}
		else if (diffY >=0 && diffX < 0) {  //quadrant II
			return within2PI((float)Math.PI+radAngle);
		}
		else if (diffY < 0 && diffX < 0) {  //quadrant III
			return within2PI((float)Math.PI+radAngle);
		}
		else{                             //quadrant IV
			return within2PI(radAngle);
		}
	} // of method


	/**
	 * This method converts a radian angle to a radian angle within 2PI.
	 * This method uses mouse coordinates.  It really doesn't matter which
	 * convert2PI is used but angles will be more natural when debugging using
	 * this function.
	 */
	private float convertMouse2PI( float radAngle, float diffX, float diffY ) {
		if ( diffY>=0 && diffX >=0 ) {      //quadrant IV
			return within2PI((float)Math.PI*2.0f - radAngle);
		}
		else if (diffY >=0 && diffX < 0) {  //quadrant III
			return within2PI((float)Math.PI-radAngle);
		}
		else if (diffY < 0 && diffX < 0) {  //quadrant II
			return within2PI((float)Math.PI-radAngle);
		}
		else{                             //quadrant I
			return within2PI(0-radAngle);
		}
	} // of method




	/**
	 * This method converts a radian angle to a radian angle within 2PI.
	 */
	private float within2PI( float radAngle ) {
		while (radAngle >= 2*Math.PI) {
			radAngle -= 2*Math.PI;
		}
		while (radAngle < 0) {
			radAngle += 2*Math.PI;
		}
		return radAngle;
	} // of method


	// This basically takes a moving average of directAngle[] and puts the
	// result in triangleFilterAngle[]
	private void triangleFilter(int filterSize) {
		if ( directAngleSize < filterSize ) {
			return;
		}
		int halfFilterSize = (int)Math.ceil((filterSize)/2);
		float convolutionSum = 0;
		float averageMaker=0;
		int counter;
		boolean even = (halfFilterSize==(filterSize/2));
		counter = halfFilterSize;
		convolutionSum = directAngle[directAngleSize - halfFilterSize];
		averageMaker += 1;
		int offset;

		//This is to make even number or odd number widths work
		if (even) {
			offset = 1;
		} else {          //odd
			offset = 0;
			counter--;
		}

		//Values to the left of the middle value
		while (counter>0) {
			convolutionSum += (counter)/((halfFilterSize+offset))*directAngle[directAngleSize-2*halfFilterSize + counter-offset];
			averageMaker += (counter)/((halfFilterSize+offset));
			counter--;
		}

		counter = halfFilterSize-1;

		//Values to the right of the middle value starting from the middle most number
		//towards the right
		while (counter>0) {
			convolutionSum += ((counter))/(halfFilterSize)*directAngle[directAngleSize-counter];
			averageMaker += ((counter))/(halfFilterSize);
			counter--;
		}

		convolutionSum = convolutionSum/averageMaker;
		synchronized (triangleFilteredAngle) {
			triangleFilteredAngle[triangleArraySize] = convolutionSum;
		}
		triangleArraySize++;
		if (noKinks) {
			findKinklessControlPoints(filterSize,0);
		} else {
			findControlPoints(filterSize,0);
		}
	} // of method


	/**
	 * Finds the control points of the line, by using the triangleFilterArray
	 * and finds angles differences that are above the set THRESHHOLD
	 * If choice == 1, it means add the last half-filter data points as
	 *                 control points (for end)
	 *                 This is called when a line is completed
	 *                 (done adding points)
	 * If choice == 0, it means find the next control point if it exists
	 */
	private void findControlPoints(int filterSize, int choice) {
		if (recentAngleNum == -1) {
			recentAngleNum = 0;         // indexes into triangleFilteredAngle array
			synchronized (curveDraw) {
				curveDraw[0] = 0;        // indexes into directPointArray
			}

			curveDrawSize++;
			thePath.moveTo(poly.xpoints[0], poly.ypoints[0]);
			if(choice==1){
				//The line is very short:  Line must be completed
				thePath.lineTo(poly.xpoints[poly.npoints-1], poly.ypoints[poly.npoints-1]);
				curveDraw[1] = poly.npoints-1;
				curveDrawSize++;
			}
			return;
		}

		if (choice == 1) {
			int currentPointIndex = curveDraw[curveDrawSize - 1];
			if (currentPointIndex < poly.npoints-1-filterSize) {
				// Make the nth point from the end the next control point,
				// n being determined by the filterSize
				thePath.curveTo(poly.xpoints[recentAngleNum + ((poly.npoints-1-filterSize)-recentAngleNum)/3],
									 poly.ypoints[recentAngleNum + ((poly.npoints-1-filterSize)-recentAngleNum)/3],
									 poly.xpoints[recentAngleNum + ((poly.npoints-1-filterSize)-recentAngleNum)*2/3],
									 poly.ypoints[recentAngleNum + ((poly.npoints-1-filterSize)-recentAngleNum)*2/3],
									 poly.xpoints[poly.npoints-1-filterSize],
									 poly.ypoints[poly.npoints-1-filterSize]);
				recentAngleNum = triangleArraySize-1;
				currentPointIndex = poly.npoints-1-filterSize;

			}

			//Completes the endline with striaght lines
			while (currentPointIndex < poly.npoints) {
				thePath.lineTo(poly.xpoints[currentPointIndex],
									poly.ypoints[currentPointIndex]);
				currentPointIndex++;
			}
		}
		else if (choice == 0) {
			if (aboveThresh( triangleFilteredAngle[recentAngleNum], triangleFilteredAngle[triangleArraySize-1] ) || cornerDetectedSharp(triangleArraySize-1)) {
				synchronized (curveDraw) {
					curveDraw[curveDrawSize] = recentAngleNum + ((triangleArraySize-1)-recentAngleNum)/3;
					curveDrawSize++;
					curveDraw[curveDrawSize] = recentAngleNum + ((triangleArraySize-1)-recentAngleNum)*2/3;
					curveDrawSize++;
					curveDraw[curveDrawSize] = triangleArraySize-1;
					curveDrawSize++;
				}

				thePath.curveTo(poly.xpoints[curveDraw[curveDrawSize-3]],
									 poly.ypoints[curveDraw[curveDrawSize-3]],
									 poly.xpoints[curveDraw[curveDrawSize-2]],
									 poly.ypoints[curveDraw[curveDrawSize-2]],
									 poly.xpoints[curveDraw[curveDrawSize-1]],
									 poly.ypoints[curveDraw[curveDrawSize-1]]);
				recentAngleNum = triangleArraySize-1;
			}
		}
		else {
			// choice parameter must be 0 or 1
			assert false;
		}
	} // of method



	/**
	 * This method finds the control points of the line. It uses the
	 * triangleFilterArray and finds angles differences that are above the
	 * set THRESHHOLD
	 *
	 * If choice == 1, it means add the last half-filter data points as
	 * control points (for end). This is called when a line is completed
	 * (done adding points).
	 *
	 * If choice == 0, it means find the next control point if it exists
	 */
	private void findKinklessControlPoints(int filterSize, int choice) {
		if (recentAngleNum == -1) {
			recentAngleNum = 0;        // indexes into triangleFilteredAngle array
			synchronized (curveDraw) {
				curveDraw[0] = 0;       // indexes into directPointArray
			}

			curveDrawSize++;
			thePath.moveTo(poly.xpoints[0], poly.ypoints[0]);

			if(choice==1){
				// The line is very short:  Line must be completed.
				thePath.lineTo(poly.xpoints[poly.npoints-1], poly.ypoints[poly.npoints-1]);
				curveDraw[1] = poly.npoints-1;
				curveDrawSize++;
			}
			return;
		}

		if (choice == 1) {
			int currentPointIndex = curveDraw[curveDrawSize - 1];
			if (currentPointIndex < poly.npoints - 1) {
				// Make the end point the next control point,
				float thirdLastXPoint = poly.xpoints[recentAngleNum + ((poly.npoints-1)-recentAngleNum)/3];
				float thirdLastYPoint = poly.ypoints[recentAngleNum + ((poly.npoints-1)-recentAngleNum)/3];
				float secondLastXPoint = poly.xpoints[recentAngleNum + ((poly.npoints-1)-recentAngleNum)*2/3];
				float secondLastYPoint = poly.ypoints[recentAngleNum + ((poly.npoints-1)-recentAngleNum)*2/3];
				float lastXPoint = poly.xpoints[poly.npoints-1];
				float lastYPoint = poly.ypoints[poly.npoints-1];
				float fourthLastXPoint = poly.xpoints[curveDraw[curveDrawSize-1]];
				float fourthLastYPoint = poly.ypoints[curveDraw[curveDrawSize-1]];
				if (endTangentExist) {
					if (!cornerDetectedSharp(recentAngleNum)) {
						AffineTransform matrix = new AffineTransform();
						//find angle of the beginning of the segment.
						float oldDiffX = thirdLastXPoint - fourthLastXPoint;
						float oldDiffY = thirdLastYPoint - fourthLastYPoint;
						float beginTangent = findAngle(oldDiffX, oldDiffY);
						float angleDiff = endTangent - beginTangent;
						angleDiff = -angleDiff;
						//set to end tangent
						//Translate
						matrix.setToTranslation( fourthLastXPoint, fourthLastYPoint);
						//Rotate
						matrix.rotate(angleDiff);
						//Translate back
						matrix.translate(-fourthLastXPoint, -fourthLastYPoint);
						//Apply matrix
						Point2D transformPoint = new Point2D.Float();
						transformPoint.setLocation(thirdLastXPoint, thirdLastYPoint);
						matrix.transform(transformPoint, transformPoint);
						thirdLastXPoint = (float)transformPoint.getX();
						thirdLastYPoint = (float)transformPoint.getY();
					}
				}

				float oldDiffX = lastXPoint - secondLastXPoint;
				float oldDiffY = lastYPoint - secondLastYPoint;
				endTangent = findAngle(oldDiffX, oldDiffY);
				endTangentExist = true;

				thePath.curveTo(thirdLastXPoint,
									 thirdLastYPoint,
									 secondLastXPoint,
									 secondLastYPoint,
									 lastXPoint,
									 lastYPoint);
				recentAngleNum = triangleArraySize-1;
				currentPointIndex = poly.npoints-1;

			}

			//Completes the endline with striaght lines
			while (currentPointIndex < poly.npoints) {
				thePath.lineTo(poly.xpoints[currentPointIndex],
									poly.ypoints[currentPointIndex]);
				currentPointIndex++;
			}
		}
		else if (choice == 0) {  //choice ==0
			if (aboveThresh( triangleFilteredAngle[recentAngleNum], triangleFilteredAngle[triangleArraySize-1] )
				 || cornerDetectedSharp(triangleArraySize-1)) {
				synchronized (curveDraw) {
					curveDraw[curveDrawSize] = recentAngleNum + ((triangleArraySize-1)-recentAngleNum)/3;
					curveDrawSize++;
					curveDraw[curveDrawSize] = recentAngleNum + ((triangleArraySize-1)-recentAngleNum)*2/3;
					curveDrawSize++;
					curveDraw[curveDrawSize] = triangleArraySize-1;
					curveDrawSize++;
				}


				///KINKY POINT CODE
				float lastXPoint = poly.xpoints[curveDraw[curveDrawSize-1]];
				float lastYPoint = poly.ypoints[curveDraw[curveDrawSize-1]];
				float secondLastXPoint = poly.xpoints[curveDraw[curveDrawSize-2]];
				float secondLastYPoint = poly.ypoints[curveDraw[curveDrawSize-2]];
				float thirdLastXPoint = poly.xpoints[curveDraw[curveDrawSize-3]];
				float thirdLastYPoint = poly.ypoints[curveDraw[curveDrawSize-3]];
				float fourthLastXPoint = poly.xpoints[curveDraw[curveDrawSize-4]];
				float fourthLastYPoint = poly.ypoints[curveDraw[curveDrawSize-4]];
				if (endTangentExist) {
					// The next if statement is for corner detection.  If there's a corner,
					// then it won't be smoothed out.
					if (!cornerDetectedSharp(recentAngleNum)) {
						AffineTransform matrix = new AffineTransform();
						//find angle of the beginning of the segment.
						float oldDiffX = thirdLastXPoint - fourthLastXPoint;
						float oldDiffY = thirdLastYPoint - fourthLastYPoint;
						float beginTangent = findAngle(oldDiffX, oldDiffY);
						float angleDiff = endTangent - beginTangent;
						angleDiff = -angleDiff;
						//set to end tangent
						//Translate
						matrix.setToTranslation( fourthLastXPoint, fourthLastYPoint);
						//Rotate
						matrix.rotate(angleDiff);
						//Translate back
						matrix.translate(-fourthLastXPoint, -fourthLastYPoint);
						//Apply matrix
						Point2D transformPoint = new Point2D.Float();
						transformPoint.setLocation(thirdLastXPoint, thirdLastYPoint);
						matrix.transform(transformPoint, transformPoint);
						thirdLastXPoint = (float)transformPoint.getX();
						thirdLastYPoint = (float)transformPoint.getY();
					}
				}

				float oldDiffX = lastXPoint - secondLastXPoint;
				float oldDiffY = lastYPoint - secondLastYPoint;
				endTangent = findAngle(oldDiffX, oldDiffY);
				endTangentExist = true;

				thePath.curveTo(thirdLastXPoint,
									 thirdLastYPoint,
									 secondLastXPoint,
									 secondLastYPoint,
									 lastXPoint,
									 lastYPoint);
				recentAngleNum = triangleArraySize-1;
			}
		}
		else {
			// choice parameter must be 0 or 1
			assert false;
		}
	} // of method


	/**
	 * This function takes in an index pointing to the triangleFilterArray
	 * and determines whether a corner exists at that index.  The function will
	 * return true if such a corner exists, and false otherwise.
	 *
	 * The variable cornerDegree is what the degree difference must
	 * be before it is considered a corner.  The angles are convoluted so
	 * cornerDegree does not reflect the actual corner in degrees.  The variable
	 * previous is the number of points difference the function will detect the
	 * corner over.
	 */
	private boolean cornerDetectedSharp (int triangleFilterIndex) {
		int previous = 5;
		if (triangleFilterIndex<previous) {
			return false;
		}

		float cornerThresh = cornerDegree*(float)Math.PI/180;
		float difference = Math.abs((triangleFilteredAngle[triangleFilterIndex]-triangleFilteredAngle[triangleFilterIndex-previous]));
		if (difference>cornerThresh) {
			return true;
		} else {
			return false;
		}
	}


	/**
	 * This function compares the difference of two angles to see
	 * if it is above a set threshhold, set in the global
	 * variables.
	 */
	private boolean aboveThresh(float angle1, float angle2) {
		float angleDifference;
		angleDifference = Math.abs(angle2-angle1);
		return (angleDifference >= THRESHHOLD);
	}



	/**
	 * This is an optimization method that expands arrays when they
	 * they are full, much like in Polygon2D.
	 */
	private void expandArrays() {
		//Expand directAngle array
		synchronized (directAngle) {
			float[] temp = new float[directAngle.length * 2];
			System.arraycopy(directAngle, 0, temp, 0, directAngle.length);
			directAngle = temp;
		}
		//Expand triangleFilteredAngle array
		synchronized (triangleFilteredAngle) {
			float[] temp = new float[triangleFilteredAngle.length * 2];
			System.arraycopy(triangleFilteredAngle, 0, temp, 0, triangleFilteredAngle.length);
			triangleFilteredAngle = temp;
		}
		//Expand curveDraw array
		synchronized (curveDraw) {
			int[] tempint = new int[curveDraw.length * 2];
			System.arraycopy(curveDraw, 0, tempint, 0, curveDraw.length);
			curveDraw = tempint;
		}
	} // of method


	/**
	 * This method takes in a vector and returns
	 * the absolute angle of that vector.
	 */
	private float findAngle(float vectX, float vectY) {
		float angle;
		if (vectX == 0) {
			if (vectY > 0.0) {
				angle = (float)Math.PI*3.0f/2.0f;
			} else if (vectY == 0.0) {
				angle = 0;
			} else {  //diffY<0
				angle = (float)Math.PI/2.0f;
			}
		} else {
			angle = convertMouse2PI( (float)Math.atan( vectY/vectX ), vectX, vectY );
		}
		return angle;
	}


	/**
	 * The start point is anchored while the end point is adjusted.
	 * This method will transform the whole curve so that the end
	 * point is at the LOCAL coordinates float x, float y.
	 *
	 * @param x is x coordinate of the new ending point in LOCAL coordinates.
	 * @param y is y coordinate of the new ending point in LOCAL coordinates.
	 */
	public void changeDest(float x, float y) {
		Point2D newDestPt = new Point2D.Float();
		Point2D destPt = thePath.getCurrentPoint();
		Point2D sourcePt = new Point2D.Float();

		newDestPt.setLocation(x, y);

		//2.  Get the start and end points
		PathIterator pIt = thePath.getPathIterator(new AffineTransform());
		float temppoints[] = new float[6];
		pIt.currentSegment(temppoints);

		sourcePt.setLocation(temppoints[0], temppoints[1]);
		if (newDestPt.getX()==destPt.getX() && newDestPt.getY()==destPt.getY()) {
			// Nothing needs to be done.
			return;
		}
		scaleRotate(sourcePt, destPt, newDestPt);
		setLocalBoundingPoints2DRef(poly);
	} // of method



	/**
	 * The end point is anchored while the start point is adjusted.
	 * This method will transform the whole curve so that the start
	 * point is at the LOCAL coordinates float x, float y.
	 *
	 * @param x is the x coordinate of the new starting point in LOCAL
	 *        coordinates.
	 * @param y is the y coordinate of the new starting point in LOCAL
	 *        coordinates.
	 */
	public void changeSource(float x, float y) {
		Point2D newSourcePt = new Point2D.Float();
		Point2D destPt = thePath.getCurrentPoint();
		Point2D sourcePt = new Point2D.Float();

		newSourcePt.setLocation(x, y);

		//2.  Get the start and end points
		PathIterator pIt = thePath.getPathIterator(new AffineTransform());
		float temppoints[] = new float[6];
		pIt.currentSegment(temppoints);

		sourcePt.setLocation(temppoints[0], temppoints[1]);
		if (newSourcePt.getX()==sourcePt.getX() && newSourcePt.getY()==sourcePt.getY()) {
			// Nothing needs to be done.
			return;
		}
		scaleRotate(destPt, sourcePt, newSourcePt);
		setLocalBoundingPoints2DRef(poly);
	} // of method


	/**
	 * This method takes in an anchor point and transforms thePath along with
	 * poly through a rotation and scaling so that originalEnd matches newEnd.
	 */
	private void scaleRotate(Point2D anchor, Point2D originalEnd, Point2D newEnd) {
		AffineTransform matrix = new AffineTransform();
		float angleDiff;
		float scale;
		//2.1  Calculate the angle between

		//2.10 Calculate absolute angle of original stroke from start to dest point.
		float oldDiffX = (float)originalEnd.getX() - (float)anchor.getX();
		float oldDiffY = (float)originalEnd.getY() - (float)anchor.getY();
		float angleOrig;
		angleOrig = findAngle(oldDiffX, oldDiffY);

		//2.11 Calculate absolute angle of stroke after rotation from start to dest.
		float newDiffX = (float)newEnd.getX() - (float)anchor.getX();
		float newDiffY = (float)newEnd.getY() - (float)anchor.getY();
		float angleNew = findAngle(newDiffX, newDiffY);

		//2.12 Find the angle difference
		angleDiff = angleOrig - angleNew;

		//2.2 Calculate the scaling factor needed
		float oldMagnitude = oldDiffX*oldDiffX + oldDiffY*oldDiffY;
		float newMagnitude = newDiffX*newDiffX + newDiffY*newDiffY;
		scale = (float)Math.sqrt(newMagnitude/oldMagnitude);

		//2.3 Create transformation matrix
		//2.31 Translate GeneralPath & Polygon2D so start point is at the origin
		float tempX = (float)anchor.getX();
		float tempY = (float)anchor.getY();
		matrix.setToTranslation( tempX, tempY);
		matrix.rotate((float)angleDiff);
		matrix.scale(scale, scale);
		matrix.translate( -tempX, -tempY );
		thePath.transform(matrix);
		poly.transform(matrix);
	}
   
	//----------------------------------------
   
	/**
	 * clear all references hold by this object (In the namespace of this class)
	 */
   
	public void deepClear() {

		super.deepClear();
      
		thePath = null;

		directAngle = null;
		triangleFilteredAngle = null;

		curveDraw = null;

		theEndLine = null;
      
		ptA = null;
		ptB = null;

	}

}// of class


//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
