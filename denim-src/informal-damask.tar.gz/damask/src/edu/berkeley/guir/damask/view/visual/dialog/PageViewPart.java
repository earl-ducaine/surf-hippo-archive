package edu.berkeley.guir.damask.view.visual.dialog;

/** 
 * Marks a class as being within a page.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-01-2003 James Lin
 *                               Created DamaskPagePart
 *                    09-11-2003 James Lin
 *                               Renamed to PageViewPart
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-01-2003
 */
public interface PageViewPart {
   
   /**
    * Returns the page that this object is in.
    */
   PageView getPageView();
}
