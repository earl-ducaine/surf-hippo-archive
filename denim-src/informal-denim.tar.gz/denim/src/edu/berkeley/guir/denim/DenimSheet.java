package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.annotation.*;
import edu.berkeley.guir.lib.awt.image.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.dialogs.*;
import edu.berkeley.guir.denim.interpreters.*;
import edu.berkeley.guir.denim.io.*;
import edu.berkeley.guir.denim.toolbox.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.io.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.interpreter.stroke.*;
import edu.berkeley.guir.lib.satin.interpreter.commands.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.satin.widgets.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.net.*;
import java.nio.channels.FileChannel;
import java.util.*;
import java.util.List;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.swing.*;
import org.w3c.dom.*;
import org.apache.batik.dom.svg.SAXSVGDocumentFactory;
import org.apache.batik.util.XMLResourceDescriptor;

/**
 * The sheet on which the designer sketches the design.
 * 
 * <P>
 * This software is distributed under the <A
 * HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt"> Berkeley Software
 * License </A>.
 * 
 * <PRE>
 * 
 * Revisions: 1.0.0 08-05-1999 JL Created class DenimSheet. 1.1.0 12-08-2002 YL
 * Enabled speeded up dragging 1.1.0 12-28-2002 YL Enabled arrows fading in&out
 * 1.1.0 01-02-2003 YL Overrided sheet's root node to support "draw links
 * passing/crossing other pages, UNDER the pages when zommed closer than
 * storyboard" 1.1.0 01-28-2003 YL if the stroke is started from the sketch of a
 * selected DenimPanel, we think it's sketching instead of dragging when it's
 * zoomed closer than sitemap. 1.1.0 02-04-2003 YL Enabled intermediate storage
 * for denim file and speed up the remote storing 1.1.1 02-12-2003 YL Fixed the
 * bug of collision of Piemenu and setRenderToScreen 1.1.1 03-07-2003 YL Enforce
 * arrow anchored at the right place 1.1.1 04-01-2003 YL Enforce file saving
 * with shell command and exception checks 1.1.1 07-12-2003 YL Added Arrow
 * Cursor Tap selection 1.1.2 10-23-2003 YL Added Content Bounds Computation
 * 2.0.0 08-11-2004 YL Stopped using enforcedReanchor Instead, used reanchor if
 * necessary in the root graphical object Arrow Undoing problems were fixed in
 * DENIM comands
 * 
 * 
 * 
 * </PRE>
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin </A>( <A
 *         HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu </A>)
 * @author <A HREF="http://www.cs.berkeley.edu/~newman/">Mark Newman </A>( <A
 *         HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu </A>)
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong </A>( <A
 *         HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu </A>)
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li </A>( <A
 *         HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu </A>)
 * 
 * 
 * @since JDK 1.2
 * @version Version 2.0.0, 08-11-2004
 */

public class DenimSheet extends Sheet 
    implements ToolContainer, DenimConstants, BackgroundImageContainer {

    //===========================================================================
    //=== CONSTANTS =========================================================

    static final long serialVersionUID = -694126175130832168L;

    //-----------------------------------------------------------------

    static final int PROJECT_MENU_POS = 0;

    static final int PROJECT_MILESTONES_MENU_POS = 2;

    static int draggingActions = 0;
    
    public String backgroundName = null;
    public double imageX  = 0;
    public double imageY = 0;
    public double imageW  = 1;
    public double imageH = 1;

    private static BufferedImage backgroundImage = null;

    // for sketch input
    public SketchPanel sketchInputPanel = null;

    private static float speedFactor = 1.0f;

    private boolean mSimplified = false;

    //   private javax.swing.Timer renderToScreenEnabledTimer;

    private boolean shouldUpdateRadarView = false;

    private java.util.Timer autoSaveTimer = null;

    private boolean mGridOn = true;

    private double hGap = 50;

    private double vGap = 50;
    
    private static HashMap imagename2image = new HashMap();
    
    


    //// Mouse and keyboard replay speed factor, for profiling etc.
    //// Can be changed using ctrl-alt-1 and ctrl-alt-2.

    public static BufferedImage createImage(String absname) {
        String name = new File(absname).getName();
        if(imagename2image.containsKey(name))
        {
            BufferedImage image = (BufferedImage)imagename2image.get(name);
            return image;
        }
        else
        {
            File f = new File(absname);
            String pname = DenimUI.getProjectName();
            
            String dir;
            if(pname==null) // unsaved project
            {
                dir = System.getProperty("java.io.tmpdir");
            }
            else
            {
                dir = new File(pname).getParentFile().getAbsolutePath();
            }
            
            File file = new File(dir + File.separator + f.getName());
            
            try
            {
                if(file.exists()==false)
                {
                    copyFile(f, file);
                }
                
                BufferedImage image = ImageIO.read(file);
                imagename2image.put(name, image);
                
                return image;
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
                return null;
            }
        }
    }
    
    public DenimImage createDenimImage(String absname, double x, double y) {
        String name = new File(absname).getName();
        if(imagename2image.containsKey(name))
        {
            BufferedImage image = (BufferedImage)imagename2image.get(name);
            Rectangle2D rect = new Rectangle2D.Double();
            rect.setFrame(x, y, 70, 70 * image.getHeight()/image.getWidth());
            DenimImage di = new DenimImage(new File(name).getName(), rect);
            return di;
        }
        else
        {
            File f = new File(absname);
            String pname = DenimUI.getProjectName();
            
            String dir;
            if(pname==null) // unsaved project
            {
                dir = System.getProperty("java.io.tmpdir");
            }
            else
            {
                dir = new File(pname).getParentFile().getAbsolutePath();
            }
            
            File file = new File(dir + File.separator + f.getName());
            
            try
            {
                if(file.exists()==false)
                {
                    copyFile(f, file);
                }
                
                BufferedImage image = ImageIO.read(file);
                imagename2image.put(name, image);
                
                Rectangle2D rect = new Rectangle2D.Double();
                rect.setFrame(x, y, 70, 70 * image.getHeight()/image.getWidth());
                DenimImage di = new DenimImage(name, rect);

                return di;
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
                return null;
            }
        }
    }
    
    public void saveImages(String srcdir, String targetdir) {
        String dir = srcdir;
        if(dir==null)
            dir = System.getProperty("java.io.tmpdir");
        
        Iterator it = imagename2image.keySet().iterator();
        while(it.hasNext())
        {
            String filename = (String)it.next();
            String origfile = dir + File.separator + filename;
            String targfile = targetdir + File.separator + filename;
            
            if(new File(targfile).exists()==false)
            {
                try
                {
                    copyFile(origfile, targfile);
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        }
    }
    /*
    public static BufferedImage getImage(String name) {
        return (BufferedImage)imagename2image.get(name);
    }*/
    
    public void clearBackgroundImage() {
        backgroundName = null;
        imageX = 0;
        imageY = 0;
        imageW = 1;
        imageH = 1;
    }
    
    public double getImageX() {
        return this.imageX;
    }
    public double getImageY() {
        return this.imageY;
    }
    
    public double getImageW() {
        return this.imageW;
    }
    
    public double getImageH() {
        return this.imageH;
    }
    
    public static BufferedImage getImage(String fname) {
        
        String dir = null;
        String pname = DenimUI.getProjectName();
        if(pname!=null)
            dir = new File(pname).getParentFile().getAbsolutePath();
        else
            dir = System.getProperty("java.io.tmpdir");
        
        String name = new File(fname).getName();
        if(imagename2image.containsKey(name))
        {
            return (BufferedImage)imagename2image.get(name);
        }
        else
        {
            File file = new File(dir + File.separator + name);
            
            try
            {
                BufferedImage image = ImageIO.read(file);
                imagename2image.put(name, image);
                
                return image;
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
                return null;
            }
        }
    }
    
    public static void copyFile(String src, String dest) throws Exception {
        copyFile(new File(src), new File(dest));
    }

    /**
     * Copy a file
     * @param src source file
     * @param dest dest file
     * @throws FileUtilsException if the copy of the file failed
     */
    public static void copyFile(File src, File dest) throws Exception {

        if (dest.isDirectory()) {
            dest = new File(dest, src.getName());
        }

        FileInputStream fIn = null;
        FileOutputStream fOut = null;
        FileChannel fcIn = null;
        FileChannel fcOut = null;
        try {

            // InputStream
            fIn = new FileInputStream(src);
            fOut = new FileOutputStream(dest);

            // nio channel
            FileChannel sourceFC = fIn.getChannel();
            FileChannel targetFC = fOut.getChannel();

            targetFC.transferFrom(sourceFC, 0, sourceFC.size());
        } catch (Exception e) {
            throw new Exception("Error during copy file : " + src + " -> " + dest, e);
        } finally {
            try {
                fOut.close();
                fIn.close();
                fcOut.close();
                fcIn.close();
            } catch (Exception e) {

            }

        }
    }
      
    
    //===========================================================================
    //=== EVENT LISTENERS ===================================================

    /**
     * Forwards key events it does not understand to the zoom slider.
     */
    class InternalKeyListener extends KeyAdapter {

        public void keyPressed(KeyEvent evt) {
            switch (evt.getKeyCode()) {
            //// Mouse and keyboard replay: Record to file
            case KeyEvent.VK_R:
                if (evt.isAltDown() && evt.isControlDown()) {
                    edu.berkeley.guir.denim.DenimUtils
                            .startRecording("current-denim-recording");
                }
                break;

            //// Mouse and keyboard replay: Stop recording
            case KeyEvent.VK_S:
                if (evt.isAltDown() && evt.isControlDown()) {
                    edu.berkeley.guir.denim.DenimUtils.stopRecording();
                }
                break;

            //// Mouse and keyboard replay: Play last recording
            case KeyEvent.VK_P:
                if (evt.isAltDown() && evt.isControlDown()) {
                    Runnable r = new Runnable() {
                        public void run() {
                            edu.berkeley.guir.denim.DenimUtils.play(
                                    "current-denim-recording", speedFactor);
                        }
                    };
                    Thread t = new Thread(r);
                    t.start();
                }
                break;

            //// Mouse and keyboard replay: Quickplay last recording
            //// (i.e. play without restoring state first)
            case KeyEvent.VK_Q:
                if (evt.isAltDown() && evt.isControlDown()) {
                    // Doesn't replay properly unless it's out of this thread --
                    // Marc
                    Runnable r = new Runnable() {
                        public void run() {
                            edu.berkeley.guir.denim.DenimUtils.replay(
                                    "current-denim-recording", speedFactor);
                        }
                    };
                    Thread t = new Thread(r);
                    t.start();
                }
                break;

            //// Mouse and keyboard replay: decrease delay
            case KeyEvent.VK_1:
                if (evt.isAltDown() && evt.isControlDown()) {
                    speedFactor = speedFactor / 1.2f;
                    System.out.println("Speed factor " + speedFactor);
                }
                break;

            //// Mouse and keyboard replay: increase delay
            case KeyEvent.VK_2:
                if (evt.isAltDown() && evt.isControlDown()) {
                    speedFactor = speedFactor * 1.2f;
                    System.out.println("Speed factor " + speedFactor);
                }
                break;
            } // switch on key

            if (GOBWithFocus == null) {
                slider.processKeyEvent(evt);
            }

        }
    } // of inner class

    //=== EVENT LISTENERS ===================================================
    //===========================================================================

    //=== For flexible render control ==============
    //=== Purpose 1: to eliminate crossing arrows

    public class RootGraphicalObject extends Sheet.SheetGraphicalObjectGroup {

        public GraphicalObjectCollection visiblePanels = new GraphicalObjectCollectionImpl();

        protected void defaultRender(SatinGraphics g) {

            // to deal with undo troubles
            Iterator itarrow = this.getReverseIterator();
            this.disableDamage();
            while (itarrow.hasNext()) {

                GraphicalObject susArrow = (GraphicalObject) itarrow.next();

                // if this arrow is created by undo, enforce the reanchoring
                if (susArrow instanceof Arrow) {
                    Arrow arr = (Arrow) susArrow;

                    //if(arr.hasUndoTrouble())
                    //   arr.enforcedReanchor();

                    if (arr.getOrigSource() != null
                            && (arr.getOrigSource().getBounds2D(COORD_ABS)
                                    .contains(arr.getStartPoint2D(COORD_ABS)) == false || arr
                                    .getDestPanel().getBounds2D(COORD_ABS)
                                    .contains(arr.getEndPoint2D(COORD_ABS)) == false)) {
                        arr.reanchor();
                    }
                }

            }
            this.enableDamage();

            if (mSimplified) {
                super.defaultRender(g);
                return;
            }

            // if not close enough
            if (((DenimSheet) getSheet()).getAbsScale() < (DenimConstants.STORYBOARD_SCALE_FACTOR + DenimConstants.BETWEEN_SITEMAP_STORYBOARD_SCALE_FACTOR) / 2)
            //BETWEEN_STORYBOARD_SKETCH_SCALE_FACTOR)/2)
            {
                super.defaultRender(g);
                return;
            }

            // deal with crossing-page-links
            GraphicalObjectCollectionImpl panels = new GraphicalObjectCollectionImpl();
            GraphicalObjectCollectionImpl strokesOnSheet = new GraphicalObjectCollectionImpl();

            GraphicalObject gob;
            Iterator it = this.getReverseIterator();

            // pick out and render panels and strokes on the sheet
            // and render all gobs
            while (it.hasNext()) {

                gob = (GraphicalObject) it.next();

                if (gob instanceof DenimPanel
                        || (gob instanceof TimedStroke && !(gob instanceof Arrow))) {
                    if (gob instanceof DenimPanel) {
                        panels.add(gob);
                    } else
                        strokesOnSheet.add(gob);

                    continue;
                }

                try {

                    g.pushStyle(gob.getStyleRef());
                    g.pushTransform(gob.getTransformRef());
                    gob.render(g);
                    g.popTransform();
                    g.popStyle();
                } catch (Exception e) {
                    gob.render(g);
                }

            }

            // render all panels and links inside them
            it = panels.getReverseIterator();
            while (it.hasNext()) {
                DenimPanel panel = (DenimPanel) it.next();

                try {
                    g.pushStyle(panel.getStyleRef());
                    g.pushTransform(panel.getTransformRef());
                    panel.render(g);
                    g.popTransform();
                    g.popStyle();
                } catch (Exception e) {
                    panel.render(g);
                }

                if (g.getClipBounds() != null
                        && panel.getBounds2D(COORD_REL).intersects(
                                g.getClipBounds())) {

                    // Calculate label's clip rect
                    Rectangle2D oldClip = g.getClipBounds();
                    Rectangle2D labelrect = null;

                    g.pushTransform(panel.getTransformRef());
                    g.pushTransform(panel.getLabel().getTransformRef());

                    if (g.getClipBounds().intersects(
                            panel.getLabel().getBounds2D(COORD_LOCAL))) {
                        labelrect = new Rectangle2D.Double();
                        Rectangle2D
                                .intersect(g.getClipBounds(), panel.getLabel()
                                        .getBounds2D(COORD_LOCAL), labelrect);
                        g.setClip(labelrect);
                    }

                    g.popTransform();
                    g.popTransform();

                    if (labelrect != null)
                        labelrect = g.getClipBounds();

                    // Calculate sketch's clip rect
                    g.setClip(oldClip);
                    Rectangle2D sketchrect = null;

                    g.pushTransform(panel.getTransformRef());
                    g.pushTransform(panel.getSketch().getTransformRef());

                    Rectangle2D sketchLocalBounds = panel.getSketch()
                            .getBounds2D(COORD_LOCAL);

                    // if the panel has the stack effect (if it's conditional),
                    // then unite the backsketch of this panel also
                    // for simplicity reason, use hardcoded number 3.
                    // we should use a polygon for clip region here, however,
                    // we use a rectangle instead for performance and simplicity
                    // reason
                    if (panel.isStackEffect()) {
                        Rectangle2D.union(sketchLocalBounds,
                                new Rectangle2D.Double(sketchLocalBounds
                                        .getMinX() + 3, sketchLocalBounds
                                        .getMinY() + 3, sketchLocalBounds
                                        .getWidth(), sketchLocalBounds
                                        .getHeight()), sketchLocalBounds);
                    }

                    // get the clip rect of the sketch
                    if (g.getClipBounds().intersects(sketchLocalBounds)) {
                        sketchrect = new Rectangle2D.Double();
                        Rectangle2D.intersect(g.getClipBounds(),
                                sketchLocalBounds, sketchrect);
                        g.setClip(sketchrect);
                    }

                    // bring the clip region up to sheet local level
                    g.popTransform();
                    g.popTransform();

                    if (sketchrect != null)
                        sketchrect = g.getClipBounds();

                    // panel clip shape
                    Polygon2D newClip = new Polygon2D();

                    if (labelrect != null) {
                        newClip.addPoint(labelrect.getMinX(), labelrect
                                .getMinY());
                        newClip.addPoint(labelrect.getMinX(), labelrect
                                .getMaxY());
                    }

                    if (sketchrect != null) {
                        newClip.addPoint(sketchrect.getMinX(), sketchrect
                                .getMinY());
                        newClip.addPoint(sketchrect.getMinX(), sketchrect
                                .getMaxY());
                        newClip.addPoint(sketchrect.getMaxX(), sketchrect
                                .getMaxY());
                        newClip.addPoint(sketchrect.getMaxX(), sketchrect
                                .getMinY());
                    }

                    if (labelrect != null) {
                        newClip.addPoint(labelrect.getMaxX(), labelrect
                                .getMaxY());
                        newClip.addPoint(labelrect.getMaxX(), labelrect
                                .getMinY());
                    }

                    // unite irregular clip area
                    // set the clip region and render arrows
                    if (newClip.npoints > 3) {
                        newClip.setClosed(true);
                        g.setClip(newClip);

                        // render incoming and outgoing arrows of a Label
                        Vector las = panel.getLabelArrow();
                        for (int i = 0; i < las.size(); i++) {
                            Arrow ar = (Arrow) las.get(i);
                            g.pushStyle(ar.getStyleRef());
                            g.pushTransform(ar.getTransformRef());
                            ar.render(g);
                            g.popTransform();
                            g.popStyle();
                        }

                        // render incoming and outgoing arrows of a Sketch
                        Vector sas = panel.getSketchArrow();
                        for (int i = 0; i < sas.size(); i++) {
                            Arrow ar = (Arrow) sas.get(i);

                            // render it only if the arrow is under current
                            // condition or
                            // the arrow is an incoming arrow
                            if (ar.isInCurrentCondition()
                                    || !panel.getNavArrows().contains(ar)) {
                                g.pushStyle(ar.getStyleRef());
                                g.pushTransform(ar.getTransformRef());
                                ar.render(g);
                                g.popTransform();
                                g.popStyle();
                            }
                        }
                    }
                    g.setClip(oldClip);
                }
            }

            // render sheet strokes on top of everything
            it = strokesOnSheet.getReverseIterator();
            while (it.hasNext()) {
                gob = (GraphicalObject) it.next();
                try {
                    g.pushStyle(gob.getStyleRef());
                    g.pushTransform(gob.getTransformRef());
                    gob.render(g);
                    g.popTransform();
                    g.popStyle();
                } catch (Exception e) {
                    gob.render(g);
                }
            }

            if (sketchInputPanel != null) {
                try {
                    g.pushStyle(sketchInputPanel.getStyleRef());
                    g.pushTransform(sketchInputPanel.getTransformRef());
                    sketchInputPanel.render(g);
                    g.popTransform();
                    g.popStyle();
                } catch (Exception e) {
                    sketchInputPanel.render(g);
                }

            }
        }
    }

    //===========================================================================
    //=== INNER CLASS MOUSE LISTENERS =======================================

    /**
     * Keeps track of whether the mouse is inside the sheet or not. This is so
     * we know where to leave a tool when it is dropped.
     */
    class SheetMouseListener extends MouseAdapter {
        public void mouseEntered(MouseEvent e) {
            getDenimUI().setContainerWithTool(DenimSheet.this);
        }

        public void mouseExited(MouseEvent e) {
            getDenimUI().setContainerWithTool(null);
        }
    } // of inner class

    //-----------------------------------------------------------------

    class SheetMouseMotionListener implements MouseMotionListener {
        public void mouseDragged(MouseEvent evt) {
            lastX = evt.getX();
            lastY = evt.getY();
        } // of mouseDragged

        public void mouseMoved(MouseEvent evt) {
            lastX = evt.getX();
            lastY = evt.getY();
        } // of mouseMoved
    } // of inner class

    //=== INNER CLASS MOUSE LISTENERS =======================================
    //===========================================================================

    //===========================================================================
    //=== INNER CLASS CROSSHAIRS ============================================

    /**
     * Crosshairs for the sheet. If the designer zooms in and there are no
     * selected objects, the center of the zoom will be on the crosshairs.
     */
    public class Crosshairs extends PatchImpl {
        public Crosshairs() {
            //// 1. Setup sticky.
            this.setView(new StickyZViewWrapper(this.getView(), 1));

            //// 2. Calculate lines for crosshairs
            int cx = 12;
            int cy = 12;

            TimedStroke left = DenimUtils.makeStrokeFromLine(cx - 3, cy - 3,
                    cx - 12, cy - 12, DEFAULT_CROSSHAIR_COLOR);
            left.setSelectable(false);

            TimedStroke right = DenimUtils.makeStrokeFromLine(cx + 3, cy + 3,
                    cx + 12, cy + 12, DEFAULT_CROSSHAIR_COLOR);
            right.setSelectable(false);

            TimedStroke up = DenimUtils.makeStrokeFromLine(cx + 3, cy - 3,
                    cx + 12, cy - 12, DEFAULT_CROSSHAIR_COLOR);
            up.setSelectable(false);

            TimedStroke down = DenimUtils.makeStrokeFromLine(cx - 3, cy + 3,
                    cx - 12, cy + 12, DEFAULT_CROSSHAIR_COLOR);
            down.setSelectable(false);

            //// 3. This is a patch with no border or fill
            Style style = this.getStyle();
            style.setDrawColor(NO_COLOR);
            style.setFillColor(NO_COLOR);
            this.setStyle(style);

            this.add(left);
            this.add(right);
            this.add(up);
            this.add(down);

            this.setBoundingPoints2D(COORD_REL, new Rectangle(0, 0, 24, 24));
            this.setVisible(false);
            this.setSelectable(false);
        }

        public void delete() {
            //// ignore
        }
    } // of inner class

    //=== INNER CLASS CROSSHAIRS ============================================
    //===========================================================================

    //===========================================================================
    //=== NONLOCAL INSTANCE VARIABLES =======================================

    //          private Map annotatedUids;
    //transient private DistAnnotationInfo annoInfo;
    // Maps reviewer name to a List of their annotations
    //          private Map annotationsMap;

    private int version;

    private DenimUID uid;

    private InetAddress host;

    private SheetAnnotations sheetAnnos;

    //// Our reference to the zoom slider
    transient private ZoomSlider slider;

    //// The interpreters active in DENIM
    transient private MultiInterpreter labelIM;

    transient private ArrowInterpreter arrowInterp;

    transient private ImmediateInkFeedbackInterpreter inkFeedbackInterp;

    transient private MultiInterpreter panelIM;

    transient private EraserInterpreter eraserInterp;

    transient private TypedTextInterpreter textInterp;

    transient private BlankRubberStampInterpreter blankStampInterp;

    transient private RubberStampInterpreter stampInterp;

    transient private HandInterpreter handInterp;

    transient private InkAnnotationInterpreter penAnnoInterp;

    transient private AudioAnnotationInterpreter voiceAnnoInterp;

    transient private GroupInterpreter groupInterp;

    transient private FeedbackInterpreter feedbackInterp;

    //   transient private SelectInterpreter selectInterp;
    transient private DragHoldInterpreter dragholdInterp;

    //   transient private SemanticMoveSelectedInterpreter moveInterp;
    transient private DenimMoveSelectedInterpreter moveInterp;

    //transient private DenimTapSelInterp rightTapSelInterp;

    transient private ResizeInterpreter resizeInterp;

    //// Pie menu variables
    transient private DenimPieMenu pmenu;

    ////
    transient private DenimUI ui;

    transient private Crosshairs crosshairs;

    transient private DenimPanel home;

    transient private int lastX;

    transient private int lastY;

    transient private boolean modifiedFlag;

    //// Used solely for setting the default style
    transient private TimedStroke staticTimedStroke;

    transient private Style defaultStrokeStyle;

    //// stores the URL of annotations subscriber, from which the designer
    //// can access annotations from other people
    transient private URL authorURL;

    //// Listeners for ExportAnnotations and ShareForAnnotations
    //transient private ActionListener shareForAnnotationsListener =
    //                            new PieProjectShareForAnnotationsListener();
    //transient private ActionListener exportAnnotationsListener =
    //                            new PieProjectExportAnnotationsListener();

    //// A table mapping the name of a scenario to a List of DenimPanels
    //// representing the scenario
    transient private Map scenarios;

    transient private List myScenarios;

    //// Gesture feedback variables
    transient private Style feedbackStyle;

    transient private TimedStroke feedbackStroke = null;

    transient private Point2D feedbackLocation;

    transient private Rectangle2D mContentBounds = null;

    private LinkedList focusedPanels = new LinkedList();

    //=== NONLOCAL INSTANCE VARIABLES =======================================
    //===========================================================================

    //===========================================================================
    //=== CONSTRUCTORS ======================================================

    /**
     * Constructs a sheet.
     */
    public DenimSheet(DenimUI ui, boolean simplified) {

        super();
        super.gobs = new RootGraphicalObject();

        mSimplified = simplified;

        Denim.updateSplashWindow(5, "Initializing canvas");

        //// 1. Basic setup
        AffineTransformLib.setApproxScale(true);

        this.ui = ui;
        scenarios = new HashMap();

        setLayout(null);
        setBackground(DEFAULT_BKGRD_COLOR);

        // for rendering performance
        this.setSmoothStrokes(true);
        this.asm.setAngleTolerance(60);
        this.asm.setFilterWindowSize(3);

        //      this.asm.setRenderCurvy(false);

        // enable idle-rendering mode
        setIdleRenderingMode(true);

        crosshairs = new Crosshairs();
        setupCrosshairs();

        sheetAnnos = new SheetAnnotations();
        staticTimedStroke = new TimedStroke();
        defaultStrokeStyle = staticTimedStroke.getClassPropertyStyle();
        setModified(false);

        //annotationsMap = new HashMap();

        //// 2. Set up the interpreters.
        DefaultMultiInterpreterImpl im;
        Interpreter intrp;

        //// 2.1. Setup the ink interpreter.
        //System.out.println("Setting up ink interpreters");

        im = new DefaultMultiInterpreterImpl();
        this.setInkInterpreter(im);
        this.setAddRightButtonStrokes(false);
        this.setAddMiddleButtonStrokes(false);
        this.setDrawMiddleButtonStrokes(false);
        this.setInkOn(false);

        //// 2.1.1. Setup arrow interpreter
        Denim.updateSplashWindow(10, "Initializing arrow handler");
        arrowInterp = new ArrowInterpreter();
        arrowInterp.setAcceptRightButton(false);
        arrowInterp.setEnabled(false);
        im.add(arrowInterp);

        //// 2.1.2. Setup Label interpreter
        Denim.updateSplashWindow(15, "Initializing label handler");
        labelIM = new DefaultMultiInterpreterImpl();
        labelIM.setAcceptMiddleButton(false);
        labelIM.setAcceptRightButton(false);
        LabelInterpreter labelInterp = new LabelInterpreter();
        labelIM.add(new SemanticZoomInterpreterWrapper(labelInterp,
                ZOOM_NOTCH_20, ZOOM_NOTCH_55));
        labelIM.setName("Denim Label Interpreter Mediator");
        labelIM.setEnabled(false);
        im.add(labelIM);

        //// 2.1.3. Setup Panel interpreters
        //panelIM = null;

        Denim.updateSplashWindow(20, "Setting up gestures - may take a while");
        panelIM = new DefaultMultiInterpreterImpl();
        panelIM.setAcceptMiddleButton(false);
        panelIM.setAcceptRightButton(false);
        PanelMediumInterpreter panelMediumInterp = new PanelMediumInterpreter();
        panelIM.add(new SemanticZoomInterpreterWrapper(panelMediumInterp,
                ZOOM_NOTCH_40, ZOOM_NOTCH_80));
        Denim.updateSplashWindow(23, "Initializing page handler");
        PanelLargeInterpreter panelLargeInterp = new PanelLargeInterpreter();
        panelIM.add(new SemanticZoomInterpreterWrapper(panelLargeInterp,
                ZOOM_NOTCH_60 + 0.0000001, ZOOM_NOTCH_80));
        panelIM.setName("Denim Panel Interpreter Mediator");
        panelIM.setEnabled(false);

        im.add(panelIM);

        //// 2.1.4. Setup the interpreters related to the tools
        Denim.updateSplashWindow(25, "Initializing eraser");
        eraserInterp = new EraserInterpreter();
        setupToolInterpreter(eraserInterp);

        //Denim.updateSplashWindow(30, "Initializing");
        //blankStampInterp = new BlankRubberStampInterpreter();
        //setupToolInterpreter(blankStampInterp);

        Denim.updateSplashWindow(30, "Initializing rubber stamps");
        stampInterp = new RubberStampInterpreter();
        setupToolInterpreter(stampInterp);

        Denim.updateSplashWindow(40, "Initializing hand tool");
        handInterp = new HandInterpreter();
        setupToolInterpreter(handInterp);

        Denim.updateSplashWindow(45, "Initializing");
        penAnnoInterp = new InkAnnotationInterpreter();
        setupToolInterpreter(penAnnoInterp);

        //Denim.updateSplashWindow(50, "Initializing");
        //voiceAnnoInterp = new AudioAnnotationInterpreter();
        //setupToolInterpreter(voiceAnnoInterp);

        //// 2.2. Setup the gesture interpreters.
        //System.out.println("Setting up gesture interpreters");
        MultiInterpreter gestures;

        gestures = new DefaultMultiInterpreterImpl();

        //// 2.1.a Setup the interpreter that will determine whether the
        //// designer is dragging the title bar of a framed patch

        // a new interpreter added by Yang Li
        Denim.updateSplashWindow(55, "Initializing");
        /*rightTapSelInterp = new DenimTapSelInterp();
        gestures.add(rightTapSelInterp);
        rightTapSelInterp.setAcceptRightButton(true);
        rightTapSelInterp.setEnabled(true);
        */

        //      Denim.updateSplashWindow(55, "Initializing");
        //      intrp = new FramedPatchTitleBarInterpreter();
        //      intrp.setAcceptRightButton(false);
        //      gestures.add(intrp);

        // a new interpreter added by Yang Li
        Denim.updateSplashWindow(60, "... Setting up resize interpreter");
        resizeInterp = new ResizeInterpreter();
        resizeInterp.setAcceptRightButton(false);
        gestures.add(resizeInterp);

        Denim.updateSplashWindow(65, "Enabling moving objects");
        moveInterp = new DenimMoveSelectedInterpreter();
        moveInterp.setAcceptRightButton(false);
        gestures.add(moveInterp);

        // a new interpreter added by Yang Li
        Denim.updateSplashWindow(69, "... Setting up stroke+hold interpreter");
        dragholdInterp = new DragHoldInterpreter();
        dragholdInterp.setAcceptRightButton(false);
        gestures.add(dragholdInterp);

        Denim.updateSplashWindow(70, "Initializing selection support");
        intrp = new SemanticCircleSelectInterpreter();
        intrp.setAcceptLeftButton(false);
        gestures.add(intrp);

        Denim.updateSplashWindow(75, "Initializing Grouping Pencil");
        this.groupInterp = new GroupInterpreter();
        groupInterp.setAcceptLeftButton(true);
        groupInterp.setAcceptRightButton(false);
        gestures.add(groupInterp);
        groupInterp.setAttachedGraphicalObject(this);
        /*
         * Denim.updateSplashWindow(70, "Initializing selection support");
         * selectInterp = new SelectInterpreter();
         * selectInterp.setAcceptRightButton(false); gestures.add(selectInterp);
         */

        Denim.updateSplashWindow(75, "Initializing typed text support");
        textInterp = new TypedTextInterpreter();
        textInterp.setAcceptLeftButton(false);
        gestures.add(textInterp);

        Denim.updateSplashWindow(80, "Initializing standard gestures");
        intrp = new DenimGestureInterpreter();
        intrp.setAcceptLeftButton(false);
        gestures.add(intrp);

        Denim.updateSplashWindow(85, "Initializing gesture feedback");
        feedbackInterp = new FeedbackInterpreter(this);
        feedbackInterp.setAcceptLeftButton(false);
        gestures.add(feedbackInterp);

        // to intercept all stroke updating requests and give feedback

        if (isIdleRenderingMode()) {
            // for immediate ink feedback
            inkFeedbackInterp = new ImmediateInkFeedbackInterpreter();
            inkFeedbackInterp.setAcceptLeftButton(true);
            inkFeedbackInterp.setAcceptRightButton(true);
            inkFeedbackInterp.setEnabled(true);

            gestures.add(inkFeedbackInterp);
        }

        this.setGestureInterpreter(gestures);

        //// 3. Setup the pie menu
        Denim.updateSplashWindow(90, "Initializing pie menus");
        PieMenu.setDefaultBigRadius(120);
        pmenu = new DenimPieMenu(this, simplified);

        //// 4. Listen for key and mouse events
        Denim.updateSplashWindow(92, "Initializing keyboard and mouse support");
        addKeyListener(new InternalKeyListener());
        addMouseListener(new SheetMouseListener());
        addMouseMotionListener(new SheetMouseMotionListener());
        
        this.addMouseWheelListener(new MouseWheelListener() {
        	public void mouseWheelMoved(MouseWheelEvent e) {
        		int notches = e.getWheelRotation();
        		if (notches < 0) { // up - zoom out
    	    	   
    	       	} 
    	       	else { // down - zoom in
    	           
    	       	}
    	    
   	       		slider.processWheelEvent(notches);
        	}
        });

        //// 5. Setup for annotations.
        Denim.updateSplashWindow(95, "Initializing");
        version = 1;
        uid = null;
        try {
            host = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            host = null;
        }
        String authorURLStr = DenimProperties.get(PROP_AUTHOR_URL);
        if (authorURLStr == null || authorURLStr.equals("")) {
            authorURL = null;
        } else {
            try {
                authorURL = new URL(DenimProperties.get(PROP_AUTHOR_URL));
            } catch (MalformedURLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, DenimProperties
                        .get(PROP_AUTHOR_URL)
                        + " in "
                        + DenimProperties.getFileName()
                        + " is not a valid URL.", "Invalid URL",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        //// 6. Various other initialization

        // Set up the style for the feedback stroke
        feedbackStyle = getRightCurrentStyle();
        final Color feedbackColor = new Color(0, 204, 0, feedbackStyle
                .getDrawColor().getAlpha());
        feedbackStyle.setDrawColor(feedbackColor);

        Denim.updateSplashWindow(98, "Almost done initializing");
        
    } // of default constructor

    //=== CONSTRUCTORS ======================================================
    //===========================================================================

    //===========================================================================
    //=== XXXXX METHODS =====================================================

    public double getAbsScale() {
        return (GraphicalObjectLib.getScaleFactor(COORD_ABS, this.getSheet()));
    } // of method

    //-----------------------------------------------------------------

    public void handleSingleStroke(SingleStrokeEvent evt) {
        //// 0. Initializations.
        TimedStroke stk = evt.getStroke();

        //// 1.1. Ignore strokes that are too short.
        if (stk.getLength2D(COORD_ABS) < 10) {
            return;
        }
        
        stk.getStyleRef().setDrawColor(ImmediateInkFeedbackInterpreter.inkColor);

        //// 1.2. Check the add filter.
        if (addFilter.isEventAccepted(evt)
                && this.getDenimUI().getCurrentTool() != null) {
            //// 2. Just add the stroke.
            MacroCommand cmd = new MacroCommand();
            cmd.addCommand(new InsertCommand(this, stk));
            cmd.addCommand(new SetSheetModifiedCommand(this, true));
            cmdqueue.doCommand(cmd);
        }

    } // of handleSingleStroke

    //-----------------------------------------------------------------

    /**
     * Returns the containing user interface.
     */
    public DenimUI getDenimUI() {
        return ui;
    }

    //-----------------------------------------------------------------

    /**
     * Set this sheet to be the same as the specified sheet. Handy for
     * deserialization. Don't use the passed-in variable after calling this
     * method, as it will be stripped bare.
     * 
     * @param sheet
     *            the Sheet that contains the objects that we want. Don't use
     *            this variable after calling this method, since many of its
     *            variables will be shared and since we move all of the
     *            GraphicalObjects from the passed-in sheet to this sheet.
     */
    public void setSheet(DenimSheet sheet) {
        super.setSheet(sheet);

        //annotationsMap = sheet.annotationsMap;
        sheetAnnos = sheet.getSheetAnnotations();
        uid = sheet.uid;
        //annotatedUids = sheet.annotatedUids;
        host = sheet.host;
        authorURL = sheet.authorURL;
    }

    //-----------------------------------------------------------------

    /**
     * Sets up an interpreter related to a tool, and adds it to the sheet's
     * interpreter mediator.
     */
    private void setupToolInterpreter(Interpreter interp) {
        interp.setAcceptRightButton(false);
        interp.setEnabled(false);
        ((MultiInterpreter) getInkInterpreter()).add(interp);
        // HACK: Want getAttachedGraphicalObject to return Sheet, not its
        // internal GraphicalObjectGroup
        interp.setAttachedGraphicalObject(this);
    }

    //-----------------------------------------------------------------

    /**
     * Returns the version of this design.
     */
    public int getVersion() {
        return version;
    }

    //-----------------------------------------------------------------

    /**
     * Sets the version of this design. Useful for deserialization.
     */
    public void setVersion(int newVersion) {
        version = newVersion;
    }

    //-----------------------------------------------------------------

    /**
     * Returns the UID of this design.
     */
    public DenimUID getUID() {
        return uid;
    }

    //-----------------------------------------------------------------

    /**
     * Sets the UID of this design. Useful for deserialization.
     */
    public void setUID(DenimUID newUID) {
        uid = newUID;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the subscriber URL.
     */
    public URL getAuthorURL() {
        return authorURL;
    }

    //-----------------------------------------------------------------

    /**
     * Sets the subscriber URL.
     */
    public void setAuthorURL(URL newURL) {
        authorURL = newURL;
    }

    //-----------------------------------------------------------------

    public void setFeedbackRefStroke(TimedStroke stk) {
        feedbackStroke = stk;
    }

    //-----------------------------------------------------------------

    public void setFeedbackRefLocation(Point2D p) {
        feedbackLocation = p;
    }

    //-----------------------------------------------------------------

    public BufferedImage getBackgroundImage() {
        return backgroundImage;
    }

    //-----------------------------------------------------------------

    public void setBackgroundImage(BufferedImage bg) {
        backgroundImage = bg;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the zoom slider associated with this sheet. The zoom slider controls
     * the current zoom factor of the sheet.
     */
    ZoomSlider getSlider() {
        return slider;
    }

    //-----------------------------------------------------------------

    /**
     * Sets the zoom slider associated with this sheet. The zoom slider controls
     * the current zoom factor of the sheet.
     */
    void setSlider(ZoomSlider newSlider) {
        slider = newSlider;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the pie menu associated with this sheet.
     */
    DenimPieMenu getPieMenu() {
        return pmenu;
    }

    //-----------------------------------------------------------------

    public boolean isPieMenuVisible() {
        return pmenu.isVisible();
    }

    //-----------------------------------------------------------------

    public void setPieMenuVisible(boolean v) {
        pmenu.setVisible(v);
    }

    //-----------------------------------------------------------------

    /**
     * Gets the home panel of this sheet.
     */
    public DenimPanel getHomePanel() {
        // HACK: Gets the panel with the lowest ID number.
        if(home!=null)
            return home;
        
        Iterator iter = this.getForwardIterator();
        long lowestID = Long.MAX_VALUE;

        while (iter.hasNext()) {
            Object obj = iter.next();
            if (obj instanceof DenimPanel) {
                DenimPanel p = (DenimPanel) obj;
                if (p.getUniqueID() < lowestID) {
                    home = p;
                    lowestID = p.getUniqueID();
                }
            }
        }

        return home;
    }

    //-----------------------------------------------------------------

    /**
     * Sets the home panel of this sheet. You should use command.setHomeCommand
     * instead.
     */
    public void setHomePanel(DenimPanel newHome) {
        if (home != null) {
            home.setHome(false);
        }

        home = newHome;
        home.setHome(true);
    }

    //-----------------------------------------------------------------

    /**
     * Gets the label interpreter.
     */
    public MultiInterpreter getLabelInterpreter() {
        return labelIM;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the arrow interpreter.
     */
    public ArrowInterpreter getArrowInterpreter() {
        return arrowInterp;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the panel interpreter.
     */
    public MultiInterpreter getPanelInterpreter() {
        return panelIM;
    }

    //-----------------------------------------------------------------

    /**
     * should update RadarView
     */

    public boolean shouldUpdateRadarView() {
        return shouldUpdateRadarView;
    }

    //-----------------------------------------------------------------

    public void setShouldUpdateRadarView(boolean b) {
        shouldUpdateRadarView = b;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the eraser interpreter.
     */
    public EraserInterpreter getEraserInterpreter() {
        return eraserInterp;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the blank rubber stamp interpreter.
     */
    public BlankRubberStampInterpreter getBlankRubberStampInterpreter() {
        return blankStampInterp;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the rubber stamp interpreter.
     */
    public RubberStampInterpreter getRubberStampInterpreter() {
        return stampInterp;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the hand interpreter.
     */
    public HandInterpreter getHandInterpreter() {
        return handInterp;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the pen annotation interpreter.
     */
    public InkAnnotationInterpreter getInkAnnotationInterpreter() {
        return penAnnoInterp;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the pen annotation interpreter.
     */

    public ImmediateInkFeedbackInterpreter getIIFInterpreter() {
        return inkFeedbackInterp;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the voice annotation interpreter.
     */
    public AudioAnnotationInterpreter getAudioAnnotationInterpreter() {
        return voiceAnnoInterp;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the select interpreter.
     */
    //   public SelectInterpreter getSelectInterpreter() {
    //      return selectInterp;
    //   }
    public DragHoldInterpreter getSelectInterpreter() {
        return dragholdInterp;
    }

    //-----------------------------------------------------------------

    /**
     * Gets the move selected interpreter.
     */
    public DenimMoveSelectedInterpreter getMoveSelectedInterpreter() {
        return moveInterp;
    }

    //-----------------------------------------------------------------

    // HACK: Ideally, gestures should all be right button driven, but currently
    // move is left drag, so select should also be left tap. This interferes
    // with some of the tools, so this method allows tools to enable or
    // disable gestures driven with the left mouse button.
    public void setEnableLeftButtonGestures(boolean flag) {
        dragholdInterp.setEnabled(flag);
        moveInterp.setEnabled(flag);
        //resizeInterp.setEnabled(flag);
    }

    //-----------------------------------------------------------------

    public void setEnableLeftTapSelection(boolean flag) {
        //arrowCursorTapSelInterp.setEnabled(flag);
    }

    /**
     * Sets whether the sheet should accept ink or not.
     */
    public void setInkOn(boolean flag) {
        setDrawLeftButtonStrokes(flag);
        setAddLeftButtonStrokes(flag);

        setInkOn(this, flag);
    }

    //-----------------------------------------------------------------

    private void setInkOn(GraphicalObject gob, boolean flag) {
        if (gob instanceof Patch) {
            Patch patch = (Patch) gob;
            patch.getInkInterpreter().setEnabled(flag);
            patch.setAddLeftButtonStrokes(flag);
        }

        if (gob instanceof GraphicalObjectGroup) {
            GraphicalObjectGroup gobgrp = (GraphicalObjectGroup) gob;
            int size = gobgrp.numElements();

            for (int i = 0; i < size; i++) {
                setInkOn(gobgrp.get(i), flag);
            }
        }
    }

    //-----------------------------------------------------------------

    /**
     * Sets whether all gesture interpreters can accept the left mouse button or
     * not.
     */
    public void acceptLeftWithAllGestures(boolean flag) {
        // If all gestures can accept the left button, then there should
        // NOT be inking, and vice versa
        setInkOn(!flag);

        if (flag) {
            // Draw strokes as if they were gestures
            setDrawLeftButtonStrokes(true);

            TimedStroke stk = new TimedStroke();
            //Style style = stk.getClassPropertyStyle();

            // TODO: The following commented code doesn't work because Sheet's
            // paintComponent sets the width of all strokes drawn with the
            // left mouse button to 1.
            //AffineTransform tx = getTransformRef();
            //double scale = AffineTransformLib.getScaleFactor(tx);
            //float width = (float) Math.max(5.0 / scale, 1);
            //style.setLineWidth(width);

            //style.setDrawColor(Color.gray);
            //Style feedbackStyle = ((Sheet)mySheet).getRightCurrentStyle();
            //stk.setClassPropertyStyle(style);
            stk.setClassPropertyStyle(getRightCurrentStyle());

            // Enable left button on all gestures
            Iterator it = ((MultiInterpreter) getGestureInterpreter())
                    .iterator();
            while (it.hasNext()) {
                Interpreter interp = (Interpreter) it.next();
                interp.setAcceptLeftButton(true);
            }
        } else {
            // Disable left button for gestures where the right button is
            // enabled
            Iterator it = ((MultiInterpreter) getGestureInterpreter())
                    .iterator();
            while (it.hasNext()) {
                Interpreter interp = (Interpreter) it.next();
                if (interp.isRightButtonAccepted()) {
                    interp.setAcceptLeftButton(false);
                }
            }
        }

        // hack
        this.inkFeedbackInterp.setAcceptLeftButton(true);
    }

    //=================================================================

    /**
     * Called when the user undoes an action by keyboard.
     */
    protected void undoInternal() {
        try {
            cmdqueue.undo();
        } catch (Exception e) {
            Debug.println("Could not undo last command");
        }
    }

    //-----------------------------------------------------------------

    /**
     * Called when the user redoes an action by keyboard.
     */
    protected void redoInternal() {
        try {
            cmdqueue.redo();
        } catch (Exception e) {
            Debug.println("Could not redo last command");
        }
    }

    //-----------------------------------------------------------------

    /**
     * Called when the user pastes by keyboard.
     */
    protected void pasteInternal() {
        pasteAt(new Point(getLastX(), getLastY()));
    }

    //-----------------------------------------------------------------

    /**
     * Called when the user cuts by keyboard.
     */
    protected void cutInternal() {
        Iterator it = cmdsubsys.getSelected();
        cmdqueue.doCommand(new DenimCutCommand(it));
    }

    //-----------------------------------------------------------------

    /**
     * Called when the user copies by keyboard.
     */
    protected void copyInternal() {
        Iterator it = cmdsubsys.getSelected();
        cmdqueue.doCommand(new DenimCopyCommand(it));
    }

    //-----------------------------------------------------------------

    /**
     * Called when the user deletes by keyboard.
     */
    protected void deleteInternal() {
        Iterator it = cmdsubsys.getSelected();
        deleteObjects(it);
    }

    //=================================================================

    /**
     * Returns all of the annotations on this sheet.
     */
    public SheetAnnotations getSheetAnnotations() {
        return sheetAnnos;
    }

    //-----------------------------------------------------------------

    /**
     * Returns whether the sheet has been modified.
     */
    public boolean isModified() {
        return modifiedFlag;
    }

    //-----------------------------------------------------------------

    /**
     * Sets whether the sheet has been modified.
     */
    public void setModified(boolean flag) {
        modifiedFlag = flag;
    }

    //=== XXXXX METHODS =====================================================
    //===========================================================================

    //==========================================================================
    //=== TOOL CONTAINER ===================================================

    public int getLastX() {
        return lastX;
    }

    public int getLastY() {
        return lastY;
    }

    //=== TOOL CONTAINER ===================================================
    //==========================================================================

    //==========================================================================
    //=== KEYBOARD EVENT METHODS =============================================

    //=== KEYBOARD EVENT METHODS =============================================
    //==========================================================================

    //==========================================================================
    //=== SCENARIO METHODS =================================================

    /**
     * Returns a sorted set containing the names of the scenarios.
     */
    public Set getScenarioNames() {
        return null;
        //      return new TreeSet();
    }

    /*
     * // return new TreeSet(scenarios.keySet()); }
     */
    public void setScenario(String name, List panels) {
        scenarios.put(name, panels);
    }

    public void clearScenarios() {
        myScenarios = null;
    }

    public List getScenario(String name) {
        return null;
        // return new LinkedList();
        //return (List)scenarios.get(name);
    }

    public Scenario getScenario(int index) {
        return (Scenario) myScenarios.get(index);
    }

    /*
     * public List deleteScenario(String name) { if (name == null) { return
     * null; } return (List)scenarios.remove(name); }
     */

    public void addScenario(Scenario newScenario) {
        if (myScenarios == null)
            myScenarios = new LinkedList();
        myScenarios.add(newScenario);
    }

    public List getScenarios() {

        //for now set up test data...
        /*
         * myScenarios = new LinkedList(); Scenario toAdd = new
         * Scenario("Scen1", "1:00"); if(getHomePanel() != null) {
         * 
         * for(int i = 0; i < 10; i++) { toAdd.getNodes().add(new
         * Scenario.ScenarioNode(getHomePanel(), "and"));
         *  } }
         * 
         * 
         * myScenarios.add((Object)toAdd);
         */
        //end test data
        if (myScenarios == null)
            myScenarios = new LinkedList();
        return myScenarios;
    }

    public boolean rightAtALevel() {
        double s = this.getAbsScale();

        if (s == ABOVE_OVERVIEW_SCALE_FACTOR || s == OVERVIEW_SCALE_FACTOR
                || BETWEEN_OVERVIEW_SITEMAP_SCALE_FACTOR == s
                || SITEMAP_SCALE_FACTOR == s
                || BETWEEN_SITEMAP_STORYBOARD_SCALE_FACTOR == s
                || STORYBOARD_SCALE_FACTOR == s
                || BETWEEN_STORYBOARD_SKETCH_SCALE_FACTOR == s
                || SKETCH_SCALE_FACTOR == s
                || BETWEEN_SKETCH_DETAIL_SCALE_FACTOR == s
                || DETAIL_SCALE_FACTOR == s || BELOW_DETAIL_SCALE_FACTOR == s)
            return true;
        else
            return false;
    }

    //=== SCENARIO METHODS =================================================
    //==========================================================================

    private void setupForAnnotations(String baseFileName)
            throws UnknownHostException {/*
                                          * DenimUI win = getDenimUI();
                                          * 
                                          * //// If the sheet already has
                                          * annotations, turn those blue
                                          * Debug.println("annotationsMap: " +
                                          * annotationsMap);
                                          * 
                                          * Iterator annoMapKeyIter =
                                          * annotationsMap.keySet().iterator();
                                          * 
                                          * while (annoMapKeyIter.hasNext()) {
                                          * String annoUser =
                                          * (String)annoMapKeyIter.next();
                                          * Debug.println("annoUser: " +
                                          * annoUser);
                                          * 
                                          * GraphicalObjectCollection
                                          * annotations =
                                          * (GraphicalObjectCollection)
                                          * annotationsMap.get(annoUser);
                                          * 
                                          * if (annotations != null &&
                                          * !annoUser.equals(DenimProperties.get(PROP_USER))) {
                                          * Iterator annoIter =
                                          * annotations.getForwardIterator();
                                          * while (annoIter.hasNext()) {
                                          * GraphicalObject gob =
                                          * (GraphicalObject)annoIter.next();
                                          * Debug.println("Changing: " +
                                          * gob.getClass() + ":" +
                                          * gob.getUniqueID()); Style style =
                                          * gob.getStyle();
                                          * style.setDrawColor(DEFAULT_OTHER_ANNO_COLOR);
                                          * gob.setStyle(style); } } }
                                          * 
                                          * //// 2.4. Check if corresponding
                                          * annotations exist. String
                                          * strFileName =
                                          * baseFileName.substring( 0,
                                          * baseFileName.length() - 4) + ".dna";
                                          * 
                                          * if (new File(strFileName).exists()) {
                                          * Map annoTable; ArrayList
                                          * annoObjects; try { FileInputStream
                                          * fistream = new
                                          * FileInputStream(strFileName);
                                          * GZIPInputStream gzistream = new
                                          * GZIPInputStream(fistream);
                                          * ObjectInputStream oistream = new
                                          * ObjectInputStream(gzistream);
                                          * 
                                          * Object obj = oistream.readObject();
                                          * oistream.close();
                                          * 
                                          * annoTable = (Map)obj; annoInfo =
                                          * (DistAnnotationInfo)annoTable.get("info");
                                          * annoObjects =
                                          * (ArrayList)annoTable.get("annotations"); }
                                          * catch (Exception e) {
                                          * e.printStackTrace();
                                          * JOptionPane.showMessageDialog(this,
                                          * "Error while setting up annotations:
                                          * \n" + e.getMessage(), "Denim",
                                          * JOptionPane.ERROR_MESSAGE);
                                          * showSaveFailureDialog(strFileName,
                                          * e.getMessage()); return; }
                                          * 
                                          * //// Add the annotations to the
                                          * sheet Iterator annoObjectsIter =
                                          * annoObjects.iterator();
                                          * GraphicalObjectCollection
                                          * annotations = new
                                          * GraphicalObjectCollectionImpl();
                                          * 
                                          * while (annoObjectsIter.hasNext()) {
                                          * AnnotationObjectWrapper wrapper =
                                          * (AnnotationObjectWrapper)annoObjectsIter.next();
                                          * GraphicalObject gob =
                                          * wrapper.getGraphicalObject();
                                          * GraphicalObjectGroup parent =
                                          * (GraphicalObjectGroup)
                                          * DenimSheet.this.getID(wrapper.getParentID());
                                          * parent.add(gob);
                                          *  // Ignoring the anchor for now...
                                          * 
                                          * annotations.add(gob); }
                                          * 
                                          * annotationsMap.put(DenimProperties.get(PROP_USER),
                                          * annotations); } else { annoInfo =
                                          * new DistAnnotationInfo(); }
                                          */
    }

    //-----------------------------------------------------------------

    private void recursiveDeepClear(GraphicalObjectGroupImpl gog) {

        this.removeAllFocusedPanel();

        Iterator it = gog.getForwardIterator();
        GraphicalObjectCollection toDelete = new GraphicalObjectCollectionImpl();

        while (it.hasNext()) {
            GraphicalObjectImpl go = (GraphicalObjectImpl) it.next();

            if (go instanceof GraphicalObjectGroupImpl) {
                recursiveDeepClear((GraphicalObjectGroupImpl) go);
            } else {
                toDelete.add(go);
            }

            if (!(go instanceof Crosshairs))
                go.deepClear();
        }

        gog.removeAllSilently(toDelete);

    }


    
    //-----------------------------------------------------------------

    public void clear() {

        DenimClipboard.cmdqueue.clear();
        DenimConstants.denimClipboard.clearClipboard();
        
        this.removeAllFocusedPanel();
        
        imagename2image.clear();
        
        clearBackgroundImage();

        //deep clear scenegraph
        try {
            recursiveDeepClear(gobs);
        } catch (java.util.ConcurrentModificationException e) {
            System.out.println(e);
        }

        super.clear();

        setModified(false);
        getDenimUI().setProjectName(null);
        cmdsubsys.clearSelected();
        cmdqueue.clear();
        clearScenarios();
        home = null;

        // to clear references hold by pmenu
        pmenu.clear();
        
        crosshairs = new Crosshairs();
        setupCrosshairs();
    }

    //-----------------------------------------------------------------

    /**
     * Open the given file and load it into Denim.
     */
    public void open(File f) throws org.xml.sax.SAXException,
            java.io.IOException {
        String strFileName;

        try {
            strFileName = f.getCanonicalPath();
        } catch (IOException e) {
            strFileName = f.getAbsolutePath();
        }
        String strOldFileName = strFileName;
        DenimUI ui = getDenimUI();

        //// Set the cursor to the wait cursor and disable the window.
        DenimWindow win = (DenimWindow) SwingUtilities.getRoot(this);
        win.setBusy(true);

        //// 1. Figure out the filename. If the file name as
        //// given exists, then use it. If it does not, then
        //// try appending an extension.

        if (!f.exists()) {
            strFileName = FileLib.addFileNameExtension(strFileName, "dnm");
            f = new File(strFileName);
        }
        if (!f.exists()) {
            FileDialogs
                    .showFindFailureDialog(this, strOldFileName, strFileName);
            return;
        }

        //// 2. Save the current drawing style
        Style currentStyle = staticTimedStroke.getClassPropertyStyle();

        //// 3. Restore the "normal" drawing style
        staticTimedStroke.setClassPropertyStyle(defaultStrokeStyle);

        //// 4. Open the file.
        //if (strFileName.endsWith("dnm")) {
        SheetDOMParser parser = new SheetDOMParser();
        Document document = parser.parse(strFileName);
        DOMUtils.changeDenimSheetFromDOMElement(document.getDocumentElement(),
                this);
        //}
        //else {
        //   CrossPad.open(strFileName, this);
        //}

        //// 5. Restore the drawing style
        staticTimedStroke.setClassPropertyStyle(currentStyle);

        //// 6. Clear out the listeners for the Milestones menu item
        //PieMenu projectMenu =
        //   (PieMenu)pmenu.getSubElements()[PROJECT_MENU_POS];
        //JMenuItem item = projectMenu.getItem(PROJECT_MILESTONES_MENU_POS);

        //item.removeActionListener(shareForAnnotationsListener);
        //item.removeActionListener(exportAnnotationsListener);

        //// 7. If the file's extension is ".dne", then show
        //// only the annotation tools
        /*
         * if (strFileName.substring(strFileName.length() - 4,
         * strFileName.length()). equals(".dne")) {
         * item.setText("Save\nAnnotations");
         * 
         * item.addActionListener(exportAnnotationsListener);
         * ui.setAnnotationOnlyMode(true); setupForAnnotations(strFileName); }
         */
        /*
         * else { item.setText("Share\nto be\nAnnotated...");
         * item.addActionListener(shareForAnnotationsListener);
         * ui.setAnnotationOnlyMode(false); }
         */

        //// 8. Clean up.
        this.readjustArrows();
        ui.setProjectName(strFileName);
        win.setBusy(false);
        //repaint(new Rectangle(0, 0, this.getWidth(), this.getHeight()));

        DenimPanel hp = this.getHomePanel();
        if(hp!=null)
            this.crosshairs.moveTo(COORD_ABS, hp.getLocation2D(COORD_ABS));
        else
            this.crosshairs.moveTo(COORD_ABS, this.getWidth()/2, this.getHeight()/2);
        
        DenimClipboard.cmdqueue.clear();
        DenimConstants.denimClipboard.clearClipboard();
    }

    //-----------------------------------------------------------------

    /*
     * class EnableRenderToScreenAction implements ActionListener {
     * 
     * private javax.swing.Timer theTimer;
     * 
     * public EnableRenderToScreenAction (javax.swing.Timer aTimer) { super();
     * theTimer = aTimer; }
     * 
     * 
     * public void actionPerformed(ActionEvent aEvt) { theTimer.stop();
     * DenimSheet.this.setRenderToScreen(true); } }
     */
    //-----------------------------------------------------------------
    public void save(String strFileName, boolean showProgress)
            throws FileNotFoundException, IOException {
        save(strFileName, false, showProgress);
    }

    //-----------------------------------------------------------------

    private void save(String strFileName, boolean sameUID, boolean showProgress)
            throws FileNotFoundException, IOException {

        //// Set the cursor to the wait cursor.
        DenimWindow win = (DenimWindow) SwingUtilities.getRoot(this);
        win.setBusy(true);

        if (showProgress) {
            DenimProgressDialog dpd = new DenimProgressDialog(win,
                    "Saving ...", false, 30);
            dpd.setVisible(true);
        }

        //// Rename the backup files to make room for the new backup file.
        String fileNameRoot = FileLib.removeFileNameExtension(strFileName);

        for (int i = DenimConstants.NUM_BACKUPS; i >= 1; i--) {
            File backupFile = new File(fileNameRoot + ".bak." + i + ".dnm");
            File newBackupFile = new File(fileNameRoot + ".bak." + (i + 1)
                    + ".dnm");

            if (backupFile.exists() && !newBackupFile.exists()) {
                backupFile.renameTo(newBackupFile);
            }
        }

        //// Make a backup of the saved file.
        File backupFile = new File(fileNameRoot + ".bak.1.dnm");
        File existingFile = new File(strFileName);

        if (existingFile.exists()) {
            existingFile.renameTo(backupFile);
        }

        // I don't know why rename the file in this way

        /*
         * File existingFile = new File(strFileName); if (existingFile.exists()) {
         * File backupFile = new File(fileNameRoot + ".bak.1.dnm");
         * FileInputStream in = new FileInputStream(existingFile);
         * FileOutputStream out = new FileOutputStream(backupFile); int c;
         * 
         * while ((c = in.read()) != -1) { out.write(c); }
         * 
         * in.close(); out.close(); }
         */
        //// Save the design to the file.
        // for remote saving purpose
        File tmpFile = File.createTempFile("denimtmp", "dnm");
        String tmpFileName = tmpFile.getPath();

        //      System.out.println(tmpFileName);

        Document doc = new org.apache.xerces.dom.DocumentImpl();
        if (!sameUID) {
            uid = new DenimUID();
        }

        //this.setRenderToScreen(false);

        // this switch will be turn on by Timer
        //renderToScreenEnabledTimer = new javax.swing.Timer(3000, null);
        //renderToScreenEnabledTimer.addActionListener(new
        // EnableRenderToScreenAction(renderToScreenEnabledTimer));
        //renderToScreenEnabledTimer.start();

        try {
            doc.appendChild(DOMUtils.toDOMElement(doc, this));

            SheetDOMWriter writer = new SheetDOMWriter(tmpFileName);//strFileName);
            writer.print(doc);
            writer.close();

            if (!sameUID) {
                version++;
            }

            //// Delete the oldest backup file, if the maximum number of
            // backups
            //// have been reached.
            new File(fileNameRoot + ".bak." + (DenimConstants.NUM_BACKUPS + 1)
                    + ".dnm").delete();

            // for remote saving purpose
            File realFile = new File(strFileName);
            String fileSavingMessage = new String("Denim cannot save file to ");
            fileSavingMessage += strFileName + ".";
            fileSavingMessage += "\nYour designs have been saved as a tmp file ";
            fileSavingMessage += tmpFileName + ".";
            fileSavingMessage += "\nPlease manually move tmp file ";
            fileSavingMessage += tmpFileName + " to ";
            fileSavingMessage += strFileName + ".";

            if (realFile.exists()) {
                realFile.delete();
            }

            try {
                if (tmpFile.renameTo(realFile) == false) {
                    //JOptionPane.showMessageDialog(this, "File Saving failed!
                    // Trying copy file " + tmpFileName +" to your destination
                    // ...","File Saving",JOptionPane.ERROR_MESSAGE);
                    // renameTo failed. trying move file by command
                    String[] cmdArray = new String[3];

                    if (Denim.getPlatformState() == Denim.runningOnWindows) {
                        cmdArray[0] = new String("move");
                    } else {
                        cmdArray[0] = new String("mv");
                    }

                    cmdArray[1] = tmpFileName;
                    cmdArray[2] = strFileName;

                    try {
                        Process pro = Runtime.getRuntime().exec(cmdArray);
                        int exitValue = pro.waitFor();

                        if (exitValue == 0) {
                            setModified(false);
                        } else {
                            JOptionPane.showMessageDialog(this,
                                    fileSavingMessage, "File Saving Failed",
                                    JOptionPane.ERROR_MESSAGE);
                            throw new java.io.IOException("Destination path "
                                    + strFileName
                                    + " is not accessible to DENIM!");
                        }
                    } catch (java.lang.Exception e) {
                        JOptionPane
                                .showMessageDialog(this, fileSavingMessage,
                                        "File Saving Failed",
                                        JOptionPane.ERROR_MESSAGE);
                        throw new java.io.IOException("Destination path "
                                + strFileName + " is not accessible to DENIM!");
                    }
                } else
                    setModified(false);
            } catch (SecurityException ex) {
                JOptionPane.showMessageDialog(this, fileSavingMessage,
                        "File Saving Failed", JOptionPane.ERROR_MESSAGE);
                throw new java.io.IOException("Destination path " + strFileName
                        + " is not accessible to DENIM!");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "GraphicalObject Error",
                    "File Saving Failed", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }

        //// Enable the window and reset the cursor.
        win.setBusy(false);

    }

    public void insertImage(Point2D pt) {
        //// 0.1. Setup the file chooser.
        JFileChooser chooser = new JFileChooser();

        //// 0.2. Setup the file filter.
        ExtensionFileFilter filter = new ExtensionFileFilter();
        filter.addExtension("jpg");
        filter.addExtension("bmp");
        filter.addExtension("gif");
        filter.addExtension("png");
        filter.setDescription("Images");
        
        chooser.setFileFilter(filter);
        chooser.setMultiSelectionEnabled(false);
        chooser.setDialogTitle("Add Image");

        //// 1. Open up the dialog.
        int returnVal = chooser.showOpenDialog(this);

        //// 2. If the user clicks Open...
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            try {
                this.disableDamage();
                
                Iterator it = this.getReverseIterator();
                while(it.hasNext())
                {
                    GraphicalObject gob = (GraphicalObject)it.next();
                    if(gob instanceof DenimPanel&&gob.getBounds2D(COORD_ABS).contains(pt))
                    {
                        if(((DenimPanel)gob).getSketch().getBounds2D(COORD_ABS).contains(pt))
                        {
                            Point2D dst = new Point2D.Double();
                            ((DenimPanel)gob).getSketch().getTransform(COORD_ABS).inverseTransform(pt, dst);
                            
                            DenimImage di = this.createDenimImage(
                                    chooser.getSelectedFile().getAbsolutePath(), 
                                    cmdsubsys.getAbsoluteLastXLocation(), 
                                    cmdsubsys.getAbsoluteLastYLocation());
                            
                            ((DenimPanel)gob).getSketch().add(di,
                                    GraphicalObjectGroup.KEEP_REL_POS);
                            
                            di.moveTo(COORD_ABS, pt.getX(), pt.getY());
                            
                            cmdsubsys.clearSelected();
                            cmdsubsys.addSelected(di);
                        }
                    }
                }

                this.enableDamage();
                damage(DAMAGE_NOW);
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Cannot open: " + e.getClass());
            }
            
        }
    }

    public void saveSVG(String strFileName) throws FileNotFoundException,
            IOException {
        // HACK: Save sheet's transform and zoom into storyboard view
        this.disableDamage();
        AffineTransform tx = this.getTransform(COORD_REL);

        ZoomSlider slider = this.getDenimUI().getZoomSlider();
        slider.setAnimateZoom(false);
        slider.setValue(50); // Storyboard value
        slider.setAnimateZoom(true);

        Document doc = new org.apache.xerces.dom.DocumentImpl();
        doc.appendChild(SVGUtils.toSVGElement(doc, this));

        SVGDOMWriter writer = new SVGDOMWriter(strFileName);
        writer.print(doc);
        writer.close();

        // Zoom the sheet to the proper scale factor.
        double newScale = AffineTransformLib.getScaleFactor(tx);
        slider.setAnimateZoom(false);
        slider.setValue(DenimUtils.getZoomSliderValue(newScale));
        slider.setAnimateZoom(true);

        //// Pan to the correct location.
        this.setTransform(tx);
        this.enableDamage();
    }

    //===========================================================================
    //=== MISCELLANEOUS =====================================================

    /**
     * Setup the crosshairs patch.
     */
    void setupCrosshairs() {
        if(crosshairs!=null)
            this.add(crosshairs);

        //Debug.println("Added crosshairs: " +
        // crosshairs.getBounds2D(COORD_ABS));
    } // of method

    //-----------------------------------------------------------------

    /**
     * Get the current location of the crosshairs, or null if there are none
     * (visible).
     */
    public Point2D getCrosshairsAbsLocation() {
        if (crosshairs.isVisible()) {
            return crosshairs.getLocation2D(COORD_ABS);
        } else {
            return null;
        }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns whether the crosshairs are visible.
     * 
     * Should be "areCrosshairsVisible", except we want to be Beans compliant,
     * just in case.
     */
    public boolean isCrosshairsVisible() {
        return crosshairs.isVisible();
    } // of method

    //-----------------------------------------------------------------

    /**
     * Sets the visibility of the crosshairs.
     */
    public void setCrosshairsVisible(boolean flag) {
        crosshairs.setVisible(flag);

        // HACK: must damage manually
        Rectangle2D bounds = crosshairs.getBounds2D(COORD_ABS);
        bounds.setRect(bounds.getX(), bounds.getY(), 24, 24);
        this.damage(DAMAGE_NOW, bounds);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Move the crosshairs to the given point (absolute).
     */
    public void setCrosshairsLocation(Point2D p) {
        //// 1. Get the old bounds to damage.
        Rectangle2D oldBounds = crosshairs.getBounds2D(COORD_ABS);

        //Debug.println("Move crosshairs to: " + p);

        p.setLocation(p.getX() - crosshairs.getWidth2D(COORD_ABS) / 2, p.getY()
                - crosshairs.getHeight2D(COORD_ABS) / 2);

        crosshairs.moveTo(COORD_ABS, p);
        crosshairs.setVisible(true);

        // HACK: Currently, Satin doesn't correctly report the absolute bounds
        // for sticky objects, so we must damage manually.
        Rectangle2D newBounds = crosshairs.getBounds2D(COORD_ABS);
        //      this.damage(DAMAGE_LATER,
        //         new Rectangle2D.Double(oldBounds.getX(), oldBounds.getY(), 24, 24),
        //         new Rectangle2D.Double(newBounds.getX(), newBounds.getY(), 24, 24));

        //Debug.println(" now at: " + crosshairs.getBounds2D(COORD_ABS));
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns the panel nearest to the given point in absolute coordinates, if
     * any.
     */
    public DenimPanel getNearestPanel(Point2D p) {
        // GraphicalObject selgob = getShallowGraphicalObject(p);

        GraphicalObject selgob = null;
        GraphicalObjectCollection gobcol = getGraphicalObjects(COORD_ABS, p,
                FIRST, SHALLOW, NEAR);
        if (gobcol.numElements() > 0) {
            selgob = gobcol.get(0);
        }

        if (selgob instanceof DenimPanel) {
            return (DenimPanel) selgob;
        } else {
            return null;
        }
    } // of method
    
    /**
     * Returns the panel nearest to the given point in absolute coordinates, if
     * any.
     */
    public DenimPanel getPanel(Point2D p) {

        GraphicalObject selgob = null;
        GraphicalObjectCollection gobcol = getGraphicalObjects(COORD_ABS, p,
                FIRST, SHALLOW, CONTAINS);
        if (gobcol.numElements() > 0) {
            selgob = gobcol.get(0);
        }

        if (selgob instanceof DenimPanel) {
            return (DenimPanel) selgob;
        } else {
            return null;
        }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Returns the object near the given point in absolute coordinates, if any.
     * 
     * <ul>
     * <li>If the user selects a hyperlink or squiggle and is not in sitemap
     * view or above, returns that object.
     * <li>If the user selects a hyperlink or squiggle and is in sitemap view
     * or above, returns that object's panel.
     * <li>If the user selects a label, returns its panel.
     * <li>If the user selects a sketch, then
     * <ul>
     * <li>if the the user is in sitemap view or above, returns its panel.
     * <li>otherwise, returns the sketch.
     * </ul>
     * </ul>
     */
    public GraphicalObject getNearestObject(Point2D p) {
        GraphicalObject selgob = null;
        GraphicalObjectCollection gobcol;
        boolean insideFramedPatch = false;

        gobcol = this.getGraphicalObjects(COORD_ABS, p, FIRST, SHALLOW,
                CONTAINS);

        if (gobcol.numElements() > 0) {
            selgob = gobcol.get(0);
        }

        if (selgob instanceof FramedPatch) {
            insideFramedPatch = true;
            selgob = ((FramedPatch) selgob).get(0);
            if (selgob instanceof DenimCustomComponent) {
                gobcol = ((DenimCustomComponent) selgob).getGraphicalObjects(
                        COORD_ABS, p, FIRST, SHALLOW, CONTAINS);
                if (gobcol.numElements() > 0) {
                    selgob = gobcol.get(0);
                }
            }
        }
        Debug.println("top level: " + DenimUtils.toShortString(selgob));

        // * If the user selects a hyperlink or squiggle and is not in
        //   sitemap view or above, select it.
        // * If the user selects a hyperlink or squiggle and is in
        //   sitemap view or above, select its panel.
        // * If the user selects a label, select its panel.
        // * If the user selects a sketch, then
        //   - if the the user is in sitemap view or above, select its panel.
        //   - otherwise, select the sketch.
        if (selgob instanceof DenimPanel) {
            DenimPanel panel = (DenimPanel) selgob;
            double scale = GraphicalObjectLib.getScaleFactor(COORD_ABS, this);

            //// If we did have a panel, then the next shallowest
            //// object should either be a label or a sketch.
            gobcol = panel
                    .getGraphicalObjects(COORD_ABS, p, ALL, SHALLOW, NEAR);

            //// Get the object that _strictly_ contains the point
            GraphicalObject startObjChild = null;
            Iterator i = gobcol.getForwardIterator();
            while (i.hasNext()) {
                GraphicalObject iGob = (GraphicalObject) i.next();
                //Debug.println("inspecting: " +
                // DenimUtils.toShortString(iGob));
                if (iGob.getBoundingPoints2D(COORD_ABS).contains(p)) {
                    startObjChild = iGob;
                }
            }

            if (startObjChild instanceof DenimSketch) {
                // if the scale is at least as zoomed in as the storyboard
                if (scale >= INTERPRETER_TRANSITION) {
                    // find shallowest object within sketch *nearest* to
                    // the point
                    gobcol = ((DenimSketch) startObjChild).getGraphicalObjects(
                            COORD_ABS, p, ALL, SHALLOW, CONTAINS);
                    float minDist = Float.POSITIVE_INFINITY;
                    GraphicalObject startObjGrandchild = null;

                    i = gobcol.getForwardIterator();
                    while (i.hasNext()) {
                        GraphicalObject iGob = (GraphicalObject) i.next();

                        // HACK: if object is patch, then point must be
                        // inside of patch
                        if (iGob instanceof Patch) {
                            if (iGob.getBoundingPoints2D(COORD_ABS).contains(p)) {
                                minDist = 0;
                                if (startObjGrandchild == null
                                        || GraphicalObjectLib.compareLayers(
                                                iGob, startObjGrandchild) == -1) {
                                    startObjGrandchild = iGob;
                                }
                            }
                        } else {
                            float distance = iGob
                                    .getBoundingPoints2D(COORD_ABS)
                                    .minDistance(p.getX(), p.getY());

                            if (distance <= minDist) {
                                minDist = distance;
                                if (startObjGrandchild == null
                                        || GraphicalObjectLib.compareLayers(
                                                iGob, startObjGrandchild) == -1) {
                                    startObjGrandchild = iGob;
                                }
                            }
                        }
                    }

                    // If we've found something within the sketch, select that
                    if (startObjGrandchild != null) {
                        selgob = startObjGrandchild;
                    }
                    // Otherwise, select the sketch.
                    else {
                        selgob = startObjChild;
                    }
                }
            }
        } else {
            if (insideFramedPatch) {
                selgob = null;
            }
        }

        return selgob;
    } // of method

    //-----------------------------------------------------------------

    /**
     * <p>
     * Returns the object near the given point in absolute coordinates, if any.
     * 
     * <p>
     * Same as getNearestObject, except:
     * 
     * <li>If the user selects a sketch, then
     * <ul>
     * <li>if the the user is in sitemap view or above, returns its panel.
     * <li>otherwise, returns null.
     * </ul>
     * </ul>
     */
    public GraphicalObject getObjectToSelect(Point2D p) {
        GraphicalObject result = getNearestObject(p);
        if (result instanceof DenimSketch) {
            return null;
        }
        else
        {
            DenimComponentInstance com = this.getDenimComponentInstance(result);
            if(com==null)
                return result;
            else
                return com;
        }
    }

    //-----------------------------------------------------------------

    /**
     * Deletes the given object from the sheet.
     */
    public void deleteObject(GraphicalObject gob) {
        if (gob != null) {
            MacroCommand cmd = new MacroCommand();
            cmd.addCommand(new DenimDeleteCommand(gob));
            cmd.addCommand(new SetSheetModifiedCommand(this, true));
            cmdqueue.doCommand(cmd);
            repaint();
        }
    } // of method

    //-----------------------------------------------------------------

    /**
     * Deletes the objects contained in a GraphicalObjectCollection whose
     * iterator is given.
     */
    public void deleteObjects(Iterator iter) {
        MacroCommand macroCommand = new MacroCommand();
        macroCommand.addCommand(new DenimDeleteCommand(iter));
        macroCommand.addCommand(new SetSheetModifiedCommand(this, true));
        cmdqueue.doCommand(macroCommand);
        repaint();
    } // of method

    //-----------------------------------------------------------------

    /**
     * Pastes the clipboard contents at the given absolute location.
     */
    public void pasteAt(Point2D absPt) {
        GraphicalObjectGroup pasteDest = findPasteDestination(absPt);
        Point2D localPt = new Point2D.Double();
        GraphicalObjectLib.absoluteToLocal(pasteDest, absPt, localPt);
        cmdqueue.doCommand(new DenimPasteCommand(pasteDest, localPt));
        //repaint();
        this.damage(DAMAGE_LATER);
    }

    public GraphicalObjectGroup findPasteDestination(Point2D absPt) {
        // Check the contents of the clipboard. If any one of the
        // contents is a panel or arrow, then paste the contents
        // on to the sheet. Otherwise, paste the contents into
        // the panel at the point.
        GraphicalObjectGroup pasteDest;
        boolean pasteOnSheet = false;
        Iterator clipContentsIt = DenimConstants.denimClipboard.getContents();
        while (clipContentsIt.hasNext()) {
            GraphicalObject gob = (GraphicalObject) clipContentsIt.next();
            if (gob instanceof DenimPanel || gob instanceof Arrow) {
                pasteOnSheet = true;
            }
        }
        if (pasteOnSheet) {
            pasteDest = this;
        } else {
            DenimPanel panel = DenimUtils.findPanel(this, cmdsubsys
                    .getAbsoluteLastLocation());
            if (panel == null) {
                pasteDest = this;
            } else {
                pasteDest = panel.getSketch();
            }
        }
        return pasteDest;
    }

    //-----------------------------------------------------------------

    public void readjustArrows() {
        //Debug.println("Readjusting arrows:");

        readjustArrows(this);
        damage(DAMAGE_NOW);
    }

    //-----------------------------------------------------------------

    private void readjustArrows(GraphicalObjectGroup gobgrp) {
        Iterator it = gobgrp.getForwardIterator();
        this.disableDamage();

        // Readjust arrows
        while (it.hasNext()) {
            Object child = it.next();
            if (child instanceof Arrow) {
                Arrow arrow = (Arrow) child;
                arrow.reanchor();
                arrow.setVisible(true);
                arrow.getStyleRef().setLineWidth(
                        (float) (1.0 / arrow.getTransform(COORD_ABS)
                                .getScaleX()));
            }

            // If the child is a framed patch, then readjust the arrows within
            // the contents of the framed patch.
            else if (child instanceof FramedPatch) {
                readjustArrows((GraphicalObjectGroup) ((FramedPatch) child)
                        .get(0));
            }
            // If the child is a custom component, then readjust the arrows
            // within
            // the custom component.
            else if (child instanceof DenimCustomComponent) {
                readjustArrows((DenimCustomComponent) child);
            }
        }
        this.enableDamage();
    }

    public String getBackgroundName() {
        return this.backgroundName;
    }
    
    //-----------------------------------------------------------------

    public void showArrows(boolean b) {
        Iterator it = this.getForwardIterator();
        this.disableDamage();

        while (it.hasNext()) {
            Object child = it.next();
            if (child instanceof Arrow) {
                Arrow arrow = (Arrow) child;
                arrow.setVisible(b);
            }
        }

        this.enableDamage();
    }
    
    public DenimComponentInstance getDenimComponentInstance(GraphicalObject gob) {
        if(gob==null)
            return null;
        else if(gob instanceof DenimComponentInstance)
            return (DenimComponentInstance)gob;
        else 
            return this.getDenimComponentInstance(gob.getParentGroup());
    }

    public void updateFocusedPanel() {
        
        LinkedList toDelete = new LinkedList();
        Iterator it = focusedPanels.iterator();
        while (it.hasNext()) {
            DenimPanel panel = (DenimPanel) it.next();
            if (!cmdsubsys.isSelected(panel)) {
                toDelete.add(panel);
                panel.getSketch().getRenderCache().setCacheImage(null);
                panel.getSketch().getRenderCache().setCacheInvalide();
            }
        }

        focusedPanels.removeAll(toDelete);

        it = cmdsubsys.getSelected();
        while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject) it.next();
            DenimPanel p = DenimPanel.getPanel(gob);
            if (p != null && !focusedPanels.contains(p)) {
                focusedPanels.add(p);
            }
        }
    }

    public void removeAllFocusedPanel() {
        Iterator it = focusedPanels.iterator();
        while (it.hasNext()) {
            DenimPanel panel = (DenimPanel) it.next();
            panel.getSketch().getRenderCache().setCacheImage(null);
            panel.getSketch().getRenderCache().setCacheInvalide();
        }
        focusedPanels.clear();
    }

    public boolean isFocusedPanel(DenimPanel panel) {
        if (focusedPanels.contains(panel))
            return true;
        else
            return false;
    }

    //-----------------------------------------------------------------

    /**
     * fade out arrows
     */

    public void FadeOutArrows() {

        if (this.getDenimUI().getZoomSlider().isAnimateZoom() == false)
            return;

        Graphics2D sg = (Graphics2D) this.getGraphics();

        //get the offscreenbuffer without arrows
        showArrows(false);
        ZoomSlider.zoomingInstance++;
        this.damage(DAMAGE_LATER);
        ZoomSlider.zoomingInstance--;
        showArrows(true);

        if (backgroundImage == null || backgroundImage.getWidth() != getWidth()
                || backgroundImage.getHeight() != getHeight()) {
            backgroundImage = (BufferedImage) createImage(getWidth(),
                    getHeight());
        }

        if (backgroundImage == null)
            return;

        Graphics2D g = backgroundImage.createGraphics();
        SatinGraphics bg = new SatinGraphics(g);
        //  bg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        // RenderingHints.VALUE_ANTIALIAS_ON);

        for (int i = Arrow.fadingfactors.length - 1; i >= 0; i--) {
            bg.drawImage(getBufferedImage(), 0, 0, this);
            bg.pushStyle(gobs.getStyleRef());
            bg.pushTransform(gobs.getTransformRef());

            Arrow.setFadingFactor((float) Arrow.fadingfactors[i]);

            Iterator it = this.getForwardIterator();
            while (it.hasNext()) {

                Object child = it.next();

                if (child instanceof Arrow) {
                    Arrow arrow = (Arrow) child;
                    bg.pushStyle(arrow.getStyleRef());
                    bg.pushTransform(arrow.getTransformRef());
                    arrow.render(bg);
                    bg.popTransform();
                    bg.popStyle();
                }
            }

            bg.popTransform();
            bg.popStyle();
            sg.drawImage(backgroundImage, 0, 0, this);
        }

        bg.dispose();
        //      showArrows(false);
    }

    //-----------------------------------------------------------------

    /**
     * fade in arrows
     */

    public void FadeInArrows() {

        if (this.getDenimUI().getZoomSlider().isAnimateZoom() == false)
            return;

        Graphics2D sg = (Graphics2D) this.getGraphics();

        if(getWidth()==0||getHeight()==0)
        	return;
        
        if (backgroundImage == null || backgroundImage.getWidth() != getWidth()
                || backgroundImage.getHeight() != getHeight()) {
            backgroundImage = (BufferedImage) createImage(getWidth(),
                    getHeight());
        }

        if (backgroundImage == null)
            return;

        Graphics2D g = backgroundImage.createGraphics();
        SatinGraphics bg = new SatinGraphics(g);

        //  bg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        // RenderingHints.VALUE_ANTIALIAS_ON);

        for (int i = 0; i < Arrow.fadingfactors.length; i++) {
            bg.drawImage(getBufferedImage(), 0, 0, this);

            bg.pushStyle(gobs.getStyleRef());
            bg.pushTransform(gobs.getTransformRef());

            Arrow.setFadingFactor((float) Arrow.fadingfactors[i]);

            Iterator it = this.getForwardIterator();

            while (it.hasNext()) {

                Object child = it.next();
                if (child instanceof Arrow) {
                    Arrow arrow = (Arrow) child;

                    // to deal with undo troubles
                    //if(arrow.hasUndoTrouble())
                    //   arrow.enforcedReanchor();

                    bg.pushStyle(arrow.getStyleRef());
                    bg.pushTransform(arrow.getTransformRef());
                    arrow.render(bg);
                    bg.popTransform();
                    bg.popStyle();
                }
            }

            bg.popTransform();
            bg.popStyle();
            sg.drawImage(backgroundImage, 0, 0, this);
        }

        bg.dispose();

        Graphics2D bufferedImageG = this.getBufferedImage().createGraphics();
        bufferedImageG.drawImage(backgroundImage, 0, 0, this);

        bufferedImageG.dispose();

        // to insure the sheet shows real image of the scene
        if (((DenimSheet) getSheet()).getAbsScale() > (DenimConstants.STORYBOARD_SCALE_FACTOR + DenimConstants.BETWEEN_STORYBOARD_SKETCH_SCALE_FACTOR) / 2) {
            this.damage(DAMAGE_LATER);
        }
    }

    public void onNewStroke(NewStrokeEvent evt) {
        if (autoSaveTimer != null) {
            autoSaveTimer.cancel();
            autoSaveTimer = null;
        }
        super.onNewStroke(evt);
    }

    public void onUpdateStroke(UpdateStrokeEvent evt) {
        super.onUpdateStroke(evt);
    }

    public void onSingleStroke(SingleStrokeEvent evt) {
        super.onSingleStroke(evt);
        if (autoSaveTimer == null && AutoSaver.isAutoSaveEnabled) {
            autoSaveTimer = new java.util.Timer();
            autoSaveTimer.schedule(new AutoSaver(autoSaveTimer, this), 3000);
        }
    }

    //=== MISCELLANEOUS =====================================================
    //===========================================================================

    /**
     * Returns whether a grid is drawn within the sketch.
     */
    /*
     * public boolean isGridOn() { return mGridOn; }
     * 
     * //-----------------------------------------------------------------
     * 
     * public void setGrid(double hg, double vg) { this.hGap = hg; this.vGap =
     * vg; }
     * 
     * //-----------------------------------------------------------------
     * 
     * public double getGridH() { return hGap; }
     * 
     * //-----------------------------------------------------------------
     * 
     * public double getGridV() { return vGap; }
     * 
     * //-----------------------------------------------------------------
     * 
     * public void setGridOn(boolean b) { this.mGridOn = b; }
     */
    //-----------------------------------------------------------------
    /**
     * Draws a horizontal grid within the sketch.
     */
    /*
     * private void drawGrid(Graphics g) {
     * 
     * Graphics2D g2d = (Graphics2D)g;
     * 
     * AffineTransform backtr = (AffineTransform)g2d.getTransform().clone();
     * AffineTransform tr = this.getTransform(COORD_ABS);
     * 
     * try { tr.concatenate(AffineTransform.getScaleInstance( tr.getScaleX(),
     * tr.getScaleY()).createInverse()); } catch(Exception ex) {
     *  }
     * 
     * g2d.setTransform(tr);
     * 
     * g2d.setColor(new Color(100,100,100,80));
     * 
     * Rectangle2D rect = this.getBounds2D(COORD_ABS);
     * 
     * try { Point2D dst1 = new Point2D.Double(); tr.inverseTransform(new
     * Point2D.Double(rect.getMinX(),rect.getMinY()), dst1); Point2D dst2 = new
     * Point2D.Double(); tr.inverseTransform(new
     * Point2D.Double(rect.getMaxX(),rect.getMaxY()), dst2);
     * rect.setFrameFromDiagonal(dst1, dst2); } catch(Exception ex) {
     *  }
     * 
     * 
     * //double pos = rect.getMinY()-6; double pos =
     * (int)(rect.getMinY()/vGap)*vGap;//-6;
     * 
     * while(true) { if(pos>=rect.getMaxY()) break;
     * //g.drawLine((int)rect.getMinX(), (int)pos, // (int)rect.getMaxX(),
     * (int)pos); g2d.draw(new Line2D.Double(rect.getMinX(), pos,
     * rect.getMaxX(), pos)); pos += vGap; }
     * 
     * //pos = rect.getMinX()-6; pos = (int)(rect.getMinX()/hGap)*hGap;//-6;
     * while(true) { if(pos>=rect.getMaxX()) break; // g.drawLine((int)pos,
     * (int)rect.getMinY(), // (int)pos,(int)rect.getMaxY()); g2d.draw(new
     * Line2D.Double(pos, rect.getMinY(),pos,rect.getMaxY())); pos += hGap; }
     * 
     * g2d.setTransform(backtr); }
     */
    //-----------------------------------------------------------------
    public void paintComponent(Graphics g) {
        /*
         * Graphics2D g2 = (Graphics2D)g;
         * g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
         * RenderingHints.VALUE_ANTIALIAS_ON);
         */

        shouldUpdateRadarView = true;

        // Paint all the stuff currently in the sbeet

        super.paintComponent(g);

        //if (isGridOn()) {
        //	drawGrid(g);
        //}

        //// If applicable, paint a feedback gesture
        //// (Note: This gesture is painted here as we don't want it
        //// to move when panning, and StickyWrapper does not work.)

        if (feedbackStroke != null) {
            // Set the style
            graphics.pushStyle(feedbackStyle);

            // Draw gesture and dot using a transform for placement
            AffineTransform tx = new AffineTransform();
            tx.setToTranslation(feedbackLocation.getX(), feedbackLocation
                    .getY());
            graphics.pushTransform(tx);
            graphics.draw(feedbackStroke.getPolygon2D(COORD_ABS));
            TimedStroke dotStroke = DenimUtils
                    .getDotFeedbackStroke(feedbackStroke
                            .getStartPoint2D(COORD_ABS));
            graphics.draw(dotStroke.getPolygon2D(COORD_ABS));
            graphics.popTransform();

            // Reset style
            graphics.popStyle();
        }

        // Tell the UI that the sheet has been painted.
        getDenimUI().sheetPainted(g.getClipBounds());

    }

    //--------------------------------------------------------------------

    public Rectangle2D getContentBounds() {
        return this.mContentBounds;
    }

    //--------------------------------------------------------------------

    public void updateContentBounds() {
        mContentBounds = null;
        Iterator it = gobs.getForwardIterator();
        while (it.hasNext()) {
            GraphicalObjectImpl obj = (GraphicalObjectImpl) it.next();
            if (mContentBounds == null) {
                this.mContentBounds = (Rectangle2D) obj.getBounds2D(COORD_REL);
            } else {
                Rectangle2D.union(this.mContentBounds, (Rectangle2D) obj
                        .getBounds2D(COORD_REL), this.mContentBounds);
            }
        }
    }

} // of class

//==============================================================================

/*
 * Copyright (c) 1999-2001 Regents of the University of California. All rights
 * reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. All advertising materials mentioning features or use of this software must
 * display the following acknowledgement:
 * 
 * This product includes software developed by the Group for User Interface
 * Research at the University of California at Berkeley.
 * 
 * 4. The name of the University may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
