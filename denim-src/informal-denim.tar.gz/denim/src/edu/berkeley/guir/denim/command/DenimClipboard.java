//// See bottom of source code for software license

package edu.berkeley.guir.denim.command;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.debugging.Debug;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.TimedCurvyStroke;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.util.*;

/**
 * A clipboard for the cut, copy, and paste commands. This is just a temporary
 * measure, until we use the actual Java provided clipboard. It's a waste of
 * time to get that working at this stage.
 * 
 * <P>
 * This software is distributed under the <A
 * HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt"> Berkeley Software
 * License </A>.
 * 
 * <PRE>
 * 
 * Revisions: - Feb 14 2001, JL Created class
 *              
 * @version 2.0.0 Aug 11 2004, YL 
 *                  Managing arrows by Denim Clipboard
 *                       - remove all arrows first and regenerte these arrows when pasting.
 *                                
 * 
 * </PRE>
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin </A>( <A
 *         HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu </A>)
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since JDK 1.2
 * @version 2.0.0, Aug 11 2004
 */
public class DenimClipboard extends Clipboard {

    //===========================================================================
    //=== CONSTANTS =========================================================

    //=== CONSTANTS =========================================================
    //===========================================================================

    //===========================================================================
    //=== INSTANCE VARIABLES ================================================

    //=== INSTANCE VARIABLES ================================================
    //===========================================================================

    //===========================================================================
    //=== CLASS METHODS =====================================================

    //=== CLASS METHODS =====================================================
    //===========================================================================

    HashMap contents2arrows;
    GraphicalObjectGroup sourceParent;

    LinkedList deletedArrows;
    //===========================================================================
    //=== CONSTRUCTORS ======================================================

    public DenimClipboard() {
        super();

        contents2arrows = new HashMap();
    } // of default constructor

    //=== CONSTRUCTORS ======================================================
    //===========================================================================

    //===========================================================================
    //=== ACCESSOR METHODS ==================================================

    public GraphicalObjectCollection getContentsCollection() {
        //// 1. Get a copy of the clipboard contents.
        //// It is important to return a copy, since we don't want to mess
        //// around with the originals.
        GraphicalObjectCollection contents = super.getContentsCollection();

        //// 2. Fix arrows in the copied contents so that they point to the
        //// <i>copied</i> sources and destinations.
        //fixCopiedArrows(fromClipboardToPasted);

        //// 3. Turn off notifications and damage.
        Iterator it = contents.getForwardIterator();
        while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject) it.next();
            gob.disableDamage();
            gob.disableNotify();
        }

        return contents;
    }

    //=== ACCESSOR METHODS ==================================================
    //===========================================================================

    //===========================================================================
    //=== MODIFIER METHODS ==================================================

    /**
     * Copies a collection of Graphical Object to the clipboard.
     * 
     * @param it
     *            is the collection of Graphical Objects. Ignores elements
     *            within that are not Graphical Objects.
     */
    public void copyToClipboard(Iterator it) {

        this.contents2arrows.clear();
        
        GraphicalObjectCollection col = new GraphicalObjectCollectionImpl();
        deletedArrows = new LinkedList();
        while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject) it.next();
            if (gob instanceof Arrow) {
                Arrow arrow = (Arrow) gob;
                if (arrow.getOrigSource() instanceof DenimHyperlinkInstance) {
                    DenimHyperlinkInstance link = 
                        (DenimHyperlinkInstance) arrow.getOrigSource();
                    GraphicalObject content = link.getContents();
                    this.contents2arrows.put(content, arrow);
                    
                    sourceParent = arrow.getParentGroup();
                    deletedArrows.add(gob.deepClone());
                    gob.delete();
                }
            } else {
                col.add(gob);
            }
        }

        it = col.getForwardIterator();

        //// 1. Copy the contents to the clipboard without copying DenimHyperlinkInstance
        super.copyToClipboard(it);
        
        this.recoverArrow();

    } // of copyToClipboard

    public void recoverArrow() {
/*        Iterator it = contents2arrows.values().iterator();
        while (it.hasNext()) {
            Arrow gob = (Arrow) it.next();
            sourceParent.addToFront(gob, GraphicalObjectGroup.KEEP_REL_POS);
            gob.getStyleRef().setLineWidth
                ((float)(1.0 /gob.getTransform(COORD_ABS).getScaleX()));
            //gob.initAfterAddToSheet();
            gob.reanchor();
        }*/
        
        Iterator it = deletedArrows.iterator();//contents2arrows.values().iterator();
        
        while(it.hasNext())
        {
            Arrow newarrow = (Arrow)it.next();
           /* Arrow newarrow = new Arrow(arrow,//stk,//new TimedStroke(poly), 
                    arrow.getInputEventType(), arrow.getOutputEventType(), 
                    arrow.getCondition(), arrow.getOrigSource(), (ArrowDest)arrow.getDest());
            */
            sourceParent.addToFront(newarrow, GraphicalObjectGroup.KEEP_REL_POS);
            newarrow.getStyleRef().setLineWidth
                ((float)(1.0 /newarrow.getTransform(COORD_ABS).getScaleX()));
            newarrow.initAfterAddToSheet();
            newarrow.reanchor();
        }
        
        deletedArrows.clear();

    }
    
    /**
     * fix arrows when putting arrows back to sheet
     * ex. paste, undo deleting and cuting. 
     */
    public void fixArrow(GraphicalObjectGroup parent, Vector addedArrows, double deltax, double deltay) {

        if(sourceParent==null||sourceParent.getSheet()==null)
            return;
        
        AffineTransform trans = new AffineTransform();
        
        try {
            AffineTransform xform = sourceParent.getTransform(COORD_ABS);
            xform.preConcatenate(sourceParent.getSheet().getInverseTransform(
                    COORD_ABS));
            
            AffineTransform gobsInvAbsXform;
            gobsInvAbsXform =  parent.getInverseTransform(COORD_ABS);
            gobsInvAbsXform.preConcatenate(parent.getSheet().getTransform(COORD_ABS));
            
            xform.preConcatenate(gobsInvAbsXform);
            
            trans = xform;

        } catch (Exception e) {
            e.printStackTrace();
        }
        
        Iterator it = contents2arrows.keySet().iterator();
        
        while(it.hasNext())
        {
            GraphicalObject content = (GraphicalObject)it.next();
            if(fromOrigToClipboard.containsKey(content))
            {
                Arrow arrow = (Arrow)contents2arrows.get(content);
                GraphicalObject pastedsrc = (GraphicalObject)this.fromClipboardToPasted.get(fromOrigToClipboard.get(content));
                GraphicalObject pasteddst = (GraphicalObject)this.fromClipboardToPasted.get(fromOrigToClipboard.get(arrow.getOrigDest()));
               /* 
                if(pastedsrc==null||pasteddst==null)
                {
                    continue;
                }
                */
                TimedStroke stk = (TimedStroke)arrow.deepClone();
                stk.applyTransform(trans);
                
                Arrow newarrow = new Arrow(stk,//new TimedStroke(poly), 
                        arrow.getInputEventType(), arrow.getOutputEventType(), 
                        arrow.getCondition(), pastedsrc, (ArrowDest)pasteddst);
                
                if(arrow.isGlobal())
                    newarrow.setGlobalDstID(arrow.getGlobalDstID());
                
                parent.addToFront(newarrow, GraphicalObjectGroup.KEEP_REL_POS);
                newarrow.getStyleRef().setLineWidth
                    ((float)(1.0 /newarrow.getTransform(COORD_ABS).getScaleX()));
                newarrow.moveBy(COORD_REL, deltax, deltay);
                newarrow.initAfterAddToSheet();
                newarrow.reanchor();
                
                if(addedArrows!=null)
                    addedArrows.add(newarrow);
            }
        }
    }

} // of class

//==============================================================================

/*
 * Copyright (c) 1999-2001 Regents of the University of California. All rights
 * reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. All advertising materials mentioning features or use of this software must
 * display the following acknowledgement:
 * 
 * This product includes software developed by the Group for User Interface
 * Research at the University of California at Berkeley.
 * 
 * 4. The name of the University may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
