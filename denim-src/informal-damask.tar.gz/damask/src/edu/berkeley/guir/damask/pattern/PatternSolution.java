package edu.berkeley.guir.damask.pattern;

import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.dialog.*;

/** 
 * A solution to a pattern.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-25-2003 James Lin
 *                               Created PatternSolution
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 04-25-2003
 */
public class PatternSolution extends InteractionGraph {
   private final Pattern pattern;
   private Set/*<Component>*/ backgroundMembers;
 
   //===========================================================================
   
   /*
    * Called only by the constructor of Pattern.
    */
   PatternSolution(final Pattern pattern) {
      this.pattern = pattern;
      this.backgroundMembers = new HashSet(); 
   }

   //===========================================================================
   
   /**
    * Returns the pattern for which this object is the solution.
    */
   public Pattern getPattern() {
      return pattern;
   }
   
   //===========================================================================
   
   /**
    * Creates a pattern instance from this solution.
    */
   InteractionSubgraph createPatternInstance(InteractionGraph graph) {
      final PatternSolution clone = (PatternSolution)clone();
      clone.add(clone.getMainPatternInstance());
      
      // Remove the background members from the new instance
      // TODO backgroundMembers should be cloned if pages are new, not merged
      for (Iterator i = clone.backgroundMembers.iterator(); i.hasNext();) {
         final Component backgroundMember = (Component)i.next();
         if (backgroundMember instanceof ComponentGroup) {
            final ComponentGroup backgroundGroup =
               (ComponentGroup)backgroundMember;
            backgroundGroup.getDialog().removeGroup(backgroundGroup);
         }
         else {
            final Control backgroundControl = (Control)backgroundMember;
            backgroundControl.getDialog().removeControl(backgroundControl);
         }
      }
      
      final InteractionSubgraph subgraph = new InteractionSubgraph(clone);
      graph.merge(clone);
      
      
      // Remove any templates that the pages in the pattern instance have.
      for (Iterator i = subgraph.getDialogs().iterator(); i.hasNext(); ) {
         final Dialog dialog = (Dialog)i.next();
         for (Iterator j = dialog.getDeviceTypesVisibleTo().iterator();
              j.hasNext(); ) {
            final DeviceType aDeviceType = (DeviceType)j.next();
            for (Iterator k = dialog.getPages(aDeviceType).iterator();
                 k.hasNext(); ) {
               final Page aPage = (Page)k.next();
               for (Iterator m = new ArrayList(aPage.getTemplates()).iterator(); m.hasNext();){
                  final Page templatePage = (Page)m.next();
                  aPage.removeTemplate(templatePage);
               }
            }
         }
      }
      return subgraph;
   }
   
   //===========================================================================
   
   /**
    * Returns the primary pattern instance represented in this pattern
    * solution.
    */
   protected PatternInstance getMainPatternInstance() {
      final PatternInstance mainPatternInstance = new PatternInstance(pattern);
      
      for (Iterator i = getDialogs().iterator(); i.hasNext(); ) {
         final Dialog dialog = (Dialog)i.next();
         for (Iterator j = dialog.getDeviceTypesVisibleTo().iterator();
            j.hasNext();
            ) {
            final DeviceType deviceType = (DeviceType)j.next();
            for (Iterator k = dialog.getPages(deviceType).iterator();
               k.hasNext();
               ) {
               final Page page = (Page)k.next();
               for (Iterator m = page.getRegions().iterator(); m.hasNext();) {
                  final PageRegion region = (PageRegion)m.next();
                  for (Iterator n = region.getControls().iterator();
                     n.hasNext();
                     ) {
                     final Control control = (Control)n.next();
                     mainPatternInstance.add(control);
                  }
               }
            }
         }
      }
      
      for (Iterator i = getConnections().iterator(); i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         mainPatternInstance.add(connection);
      }
      
      return mainPatternInstance;
   }
   
   //===========================================================================
   
   /**
    * Returns the interaction elements that give context to the solution of
    * this pattern. These interaction elements do not affect the behavior
    * of this pattern.
    */
   public Collection getBackgroundMembers() {
      return Collections.unmodifiableCollection(backgroundMembers);
   }

   //---------------------------------------------------------------------------

   public Object clone() {
      final PatternSolution clone = (PatternSolution)super.clone();

      // Make the background members of the clone point to components
      // in the clone, instead of the original solution.
      clone.backgroundMembers = new HashSet();
      for (Iterator i = backgroundMembers.iterator(); i.hasNext(); ) {
         Component backgroundMember = (Component)i.next();
         
         Component backgroundMemberClone =
            (Component) backgroundMember.getMostRecentCloneIfAlive();
            
         assert backgroundMemberClone != null:
            "clone of background member should still be alive";
         
         clone.backgroundMembers.add(
            backgroundMember.getMostRecentCloneIfAlive());
      }

      return clone;
   }
}
