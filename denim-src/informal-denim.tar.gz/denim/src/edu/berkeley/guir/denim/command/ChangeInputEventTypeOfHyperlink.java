package edu.berkeley.guir.denim.command;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.command.*;
import java.awt.geom.*;

/**
 * Changes input event type of a hyperlink
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:   1.0.0  01-23-2003 YL
 *                     Created class ChangeInputEventTypeOfHyperlink
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 *
 * @since   JDK 1.2
 * @version Version 1.0.0, 01-23-2003
 */

public class ChangeInputEventTypeOfHyperlink 
   extends UndoableCommand {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   private Arrow hyperlink;
   private String oldEvtType;
   private String newEvtType;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Construct the command.
    *
    * @param arrow     the arrow to change
    * @param newevt    the new input event for the arrow
    */
   public ChangeInputEventTypeOfHyperlink(Arrow arrow, String newevt) {
      super();
      this.hyperlink = arrow;
      this.newEvtType = newevt;
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      return ("change input event type of arrow");
   } // of getPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   COMMAND   ===========================================================

   public boolean canRedo() {
      return true;
   } // of method

   //-----------------------------------------------------------------

   public void run() {

     this.oldEvtType = this.hyperlink.getInputEventType();
     this.hyperlink.setInputEventType(this.newEvtType);
     Rectangle2D area = (Rectangle2D)hyperlink.getSource().getBounds2D(COORD_ABS).clone();
     area.setFrame(area.getMinX()-30,area.getMinY()-30,area.getWidth()+60, area.getHeight()+60);
     
     this.hyperlink.getSheet().setRenderToScreen(false);
     this.hyperlink.getSheet().damage(DAMAGE_NOW, area);

     this.hyperlink.getSheet().setRenderToScreen(true);
     this.hyperlink.getSheet().damage(DAMAGE_LATER, area);
     
     this.hyperlink.getSheet().repaint();
      
   } // of method

   //-----------------------------------------------------------------

   public void redo() {
      run();
   } // of method

   //-----------------------------------------------------------------

   public void undo() {
      this.hyperlink.setInputEventType(oldEvtType);
   } // of method

   //===   COMMAND   ===========================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
