package edu.berkeley.guir.damask.event;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.component.ComponentGroup;
import edu.berkeley.guir.damask.dialog.PageRegion;

/** 
 * A source of ControlEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-01-2004 James Lin
 *                               Created ControlEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-01-2004
 */
public class GroupEventSource {
   
   private Vector/*<GroupListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public synchronized void addGroupListener(final GroupListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public synchronized void removeGroupListener(
      final GroupListener listener) {

      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementBoundsUpdated events to listeners.
    */
   public void fireElementBoundsUpdated(
      final ComponentGroup group,
      final PageRegion region) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final GroupEvent event =
         new GroupEvent(
            group,
            GroupEvent.BOUNDS_UPDATED,
            region);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final GroupListener listener =
            (GroupListener)i.next();

         listener.elementBoundsUpdated(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementTransformUpdated events to listeners.
    */
   public void fireElementTransformUpdated(
      final ComponentGroup group,
      final PageRegion region) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final GroupEvent event =
         new GroupEvent(
            group,
            GroupEvent.TRANSFORM_UPDATED,
            region);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final GroupListener listener =
            (GroupListener)i.next();

         listener.elementTransformUpdated(event);
      }
   }
}
