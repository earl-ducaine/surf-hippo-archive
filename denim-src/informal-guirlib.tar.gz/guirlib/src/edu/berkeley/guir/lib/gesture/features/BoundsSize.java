package edu.berkeley.guir.lib.gesture.features;

import java.lang.Math;
import java.awt.Rectangle;
import edu.berkeley.guir.lib.gesture.*;

/**
 * Size of the bounding box
 */
public class BoundsSize extends Feature {
  public final double minValue = 0;
  public final double maxValue = Double.POSITIVE_INFINITY;
  
  public BoundsSize()
  {
    super();
  }

  public BoundsSize(Gesture g)
  {
    super(g);
  }

  protected void computeValue()
  {
    Rectangle bounds = gesture.getBounds();

    value = Math.sqrt((bounds.width * bounds.width) +
		      (bounds.height * bounds.height));
    valueOk = true;
  }

  public String getName()
  {
    return new String("size of bounding box");
  }

  public double getMinValue()
  {
    return minValue;
  }
  
  public double getMaxValue()
  {
    return maxValue;
  }

  public void scale(double factor)
  {
    gesture.normalize();
    TimedPolygon points = gesture.getPointsRef();
    int i;

    for (i = 0; i < points.npoints; i++) {
      points.xpoints[i] *= factor;
      points.ypoints[i] *= factor;
    }
    gesture.setPoints(points);
  }
}
