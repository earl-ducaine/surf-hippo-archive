package edu.berkeley.guir.suede;

import java.awt.*;
//TODO: setSuedeModel, setLocation, setGroupName, getGroupName, getCenter, getSuedeModel()

// srk: models for all design area system prompts (aka nodes) extend this abstract class

public abstract class AbstNodeModel implements Cloneable
{
	protected SuedeModel m_model;
	protected int m_locationX;
	protected int m_locationY;
	protected int width;
	protected int height;
	protected GroupNodeModel m_group = null;
    
    
	public abstract AbstNodeView getView();

	public abstract String getLabel();
    
	public abstract String getCaption();

	public abstract String getGroupName();
    
	public abstract void collapse();
    
	public abstract void consDefault();
    
	public abstract void expand();
    
	public abstract boolean isOperable(Point p);
    
	public int getWidth() {
		return getView().getWidth();   
	}
    
	public int getHeight() {
		return getView().getHeight();
	}
    
	public boolean getDrawBalloon() {
		return getView().getDrawBalloon();   
	}
    
	public String getAsciiName() {
		return getView().getAsciiName();   
	}

	public void removeNode() { 
	}
    
	//CC
	public void setSuedeModel(SuedeModel m) {
		m_model = m;
	}
    
	public SuedeModel getSuedeModel() {
		return m_model;   
	}
    
	public void setLocation(int x, int y) {
		m_locationX = x;
		m_locationY = y;
		getView().setLocation(x, y);
	}
    
    
	public void setGroupName(String name) {}
    
	public Point getCenter() {
		return new Point(m_locationX + getView().getWidth()/2, m_locationY + getView().getHeight()/2);
	}
    
	public int getX() {
		return m_locationX;   
	}
    
	public int getY() {
		return m_locationY;
	}
 
	   ///////////////Hongvan's code/////////////////////////
	 /**
   * Generate a copy of this AbstNodeModel
   * @param - none
   * @return
   *   The return value is a copy of this sequence. Subsequent changes to the
   *   copy will not affect the original, nor vice versa. Note that the return
   *   value must be type cast to a <CODE>AbstNodeModel</CODE> before it can be used.
   **/
   public Object clone()
   {  // Clone a AbstNodeModel object.
	  AbstNodeModel answer;

	  try
	  {
		answer = (AbstNodeModel) super.clone( );
	  }
	  catch (CloneNotSupportedException e)
	  {  // This exception should not occur. But if it does, it would probably
		 // indicate a programming error that made super.clone unavailable.
		 // The most common error would be forgetting the "Implements Cloneable"

		 // clause at the start of this class.
		 throw new RuntimeException
		 ("This class does not implement Cloneable");
	  }

	  //answer.m_nodemodel
	  //answer.data = (double [ ]) data.clone( );

	  return answer;
   }
//////////////////////////////////////////////////////////////////////
	//CC
}