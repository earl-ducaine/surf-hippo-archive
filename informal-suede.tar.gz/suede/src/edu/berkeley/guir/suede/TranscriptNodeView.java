package edu.berkeley.guir.suede;

import java.awt.Font;

public class TranscriptNodeView extends AbstScriptNodeView {

   public TranscriptNodeView(boolean nodeType, TranscriptNodeModel scriptNode) {
      super(nodeType, scriptNode); // this is a system node
      setLayout(null);
   }


   // If, in test mode, the wizard selects time out, we 
   public void setTimeOut() {
      m_text.setFont(m_text.getFont().deriveFont(Font.ITALIC));
      m_text.setText("Time Out");
   }


   public void setDidNotSay() {
      m_text.setFont(m_text.getFont().deriveFont(Font.ITALIC));
      m_text.setText("Not heard");
   }


   public void setSaidWrong() {
      m_text.setFont(m_text.getFont().deriveFont(Font.ITALIC));
      m_text.setText("Not legal");
   }


}
