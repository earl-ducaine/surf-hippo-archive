package edu.berkeley.guir.lib.gesture.util;

import java.util.*;

public class EnumIterator implements Iterator {
  protected Enumeration en;

  public EnumIterator(Enumeration e)
  {
    en = e;
  }

  public Enumeration getEnumeration()
  {
    return en;
  }

  public boolean hasNext()
  {
    return en.hasMoreElements();
  }

  public Object next()
  {
    return en.nextElement();
  }

  /** Not supported, since the underlying Enumeration does not. */
  public void remove()
  {
    throw new UnsupportedOperationException
      ("EnumIterator does not support remove()");
  }
}
