/*
 * Created on May 20, 2004
 *
 */
package edu.berkeley.guir.lib.swing;

import java.util.*;
import javax.swing.*;

/**
 * A numerical slider where settings are logarithmic rather than linear
 * 
 * @author  <A HREF="http://www.cs.berkeley.edu/~srk">Scott Klemmer</A> ( srk(AT)cs.berkeley.edu )
 *
 */
public class LogScaleSlider extends JSlider {
	/**
	 * @param min the minimum value of the slider
	 * @param max the maximum value of the slider
	 * @param value the initial value of the slider
	 * @param steps the number of intermediate slider ticks to display
	 */
	public LogScaleSlider(final int min, final int max, int value, final double steps) {
		super(min, max);
		if (value < min) {
		    System.err.println("Given value: "+value+" is below the min value: "+min);
		    value = min;
		} else if (value > max) {
		    System.err.println("Given value: "+value+" is above the max value: "+max);
		    value = max;
		} 
		super.setValue(logToLinear(value));
		
		final Dictionary labels = new Hashtable();
		//1. Add the min and max labels
		labels.put(new Integer(min), new JLabel(min+""));
		labels.put(new Integer(max), new JLabel(max+""));
		
		//2. Add labels in the middle
		final double logMin = Math.log(min);
		final double logMax = Math.log(max);
		final double logDiff = logMax - logMin;
		int step; double fraction;
		for (int i=0; i<steps; i++) {
			fraction = (i+1.0)/(steps+1.0);
			step =(int)Math.exp(fraction*logDiff + logMin);
			labels.put(new Integer((int)(fraction*(max-min))), new JLabel(step+""));
		}
		
		setLabelTable(labels);
		setPaintLabels(true);
		setEnabled(true);
	}
	
	public int getLogValue() {
		return linearToLog(getValue());
	}
	
	/**
	 * Given a number on the log-scale, returns its linear position along the slider
	 */
	private int logToLinear(final int value) {
		final int min = getMinimum();
		final int max = getMaximum();
		final double logMax = Math.log(max);
		final double logMin = Math.log(min);
		final double logDiff = logMax - logMin;
		double fraction = (Math.log(value) - logMin) / logDiff;
		return (int)(min + fraction*(max-min));
	}
	
	/**
	 * Given a linear number from the slider, returns the log-scaled value
	 */
	private int linearToLog(final int value) {
		final int min = getMinimum();
		final int max = getMaximum();
		final double fraction = ((double)getValue())/(max-min);
		final double logMax = Math.log(max);
		final double logMin = Math.log(min);
		final double logDiff = logMax - logMin;
		return (int)Math.exp(fraction*logDiff + logMin);
	}
}
