package edu.berkeley.guir.denim.components;

import java.awt.*;
import java.awt.Polygon;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.*;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTextArea;

import edu.berkeley.guir.denim.dialogs.*;
import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.awt.geom.Polygon2D;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.image.SatinImageLib;
import edu.berkeley.guir.lib.satin.objects.GraphicalObject;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollection;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectCollectionImpl;
import edu.berkeley.guir.lib.satin.objects.Patch;
import edu.berkeley.guir.lib.satin.objects.PatchImpl;
import edu.berkeley.guir.lib.satin.objects.Style;
import edu.berkeley.guir.lib.satin.stroke.TimedStroke;

/**
 * An instance of a combo box in a DENIM design. This is a built-in component.
 * 
 * <P>
 * This software is distributed under the <A
 * HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt"> Berkeley Software
 * License </A>.
 * 
 * <PRE>
 * 
 * Revisions: 1.0.0 02-26-2003 James Lin Created DenimComboBoxInstance
 * 
 * </PRE>
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin </A>( <A
 *         HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu </A>)
 * @since JDK 1.2
 * @version Version 1.0.0, 02-26-2003
 */

public class DenimComboBoxInstance
   extends DenimIntrinsicComponentInstance
   implements DenimListComponent {

   //===========================================================================
   //=== CONSTANTS =========================================================

   static final long serialVersionUID = 3725842061214852532L;

   private static final int DEFAULT_WIDTH = 100;
   private static final int DEFAULT_HEIGHT = 20;
   private static final int DEFAULT_ARROW_WIDTH = 10;
   private static final int DEFAULT_ARROW_HEIGHT = 5;
   private static final int DEFAULT_ARROW_X = 10;
   private static final int MARGIN_X = 5;
   private static final int MARGIN_Y = 7;

   //=== CONSTANTS =========================================================
   //===========================================================================

   //===========================================================================
   //=== FIELDS ============================================================

   private TimedStroke border;
   private TimedStroke downArrow;
   private boolean downArrowFilled;
   private Patch downArrowPatch;
   private GraphicalObjectCollection items;
   
   //private Patch inverse;
   private boolean createdByStamp;
   private int selectedIndex;
   private GraphicalObject selectedItem;
   
   // For run mode
   private JPopupMenu menu;
   private ActionListener menuActionListener =
      new DenimComboBoxMenuActionListener();

   //=== FIELDS ============================================================
   //===========================================================================

   //===========================================================================
   //=== LISTENERS =========================================================

   class DenimComboBoxMenuActionListener implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         JMenuItem selItem = (JMenuItem)e.getSource();
         int index = DenimComboBoxInstance.this.menu.getComponentIndex(selItem);
         DenimComboBoxInstance.this.setSelectedIndex(index);
         DenimComboBoxInstance.this.damage(DAMAGE_LATER);
         //System.out.println(index);
      }
   }

   //=== LISTENERS =========================================================
   //===========================================================================

   //===========================================================================
   //=== CONSTRUCTORS ======================================================

   /**
    * Create an instance of a DENIM combo box. Called only by
    * DenimComboBox.newInstance().
    * 
    * @param type
    *            an instance of DenimComboBox
    */
   DenimComboBoxInstance(DenimComponent type) {
      super(type);
      TimedStroke newBorder;
      TimedStroke newDownArrow;
    
      newBorder =
         new TimedStroke(
            new Rectangle2D.Double(0, 0, DEFAULT_WIDTH, DEFAULT_HEIGHT));

      int[] xs = { 0, DEFAULT_ARROW_WIDTH, DEFAULT_ARROW_WIDTH / 2, 0};
      int[] ys = { 0, 0, DEFAULT_ARROW_HEIGHT, 0};

      newDownArrow =
         new TimedStroke(new Polygon(xs, ys, xs.length));
      newDownArrow.moveTo(COORD_REL, 80, 7.5);

      // Create items
      items = new GraphicalObjectCollectionImpl();

      int[] item1SquiggleLens = {4, 3, 5};
      int[] item2SquiggleLens = {6, 7};
      int[] item3SquiggleLens = {3, 6, 5};

      items.addToBack(DenimIntrinsicComponent.createSquiggles(item1SquiggleLens));
      items.addToBack(DenimIntrinsicComponent.createSquiggles(item2SquiggleLens));
      items.addToBack(DenimIntrinsicComponent.createSquiggles(item3SquiggleLens));  
      
      init(type, newBorder, newDownArrow, true, true, items, 0);
   }

   //-----------------------------------------------------------------

   /**
    * Create an instance of a DENIM combo box, which will look like the given
    * objects. The combo box will have the same relative coordinates as the
    * given border. Called only by DenimComboBox.newInstance().
    * 
    * @param type
    *            an instance of DenimComboBox
    * @param border
    *            the border of the combo box. Its location will become the
    *            location of the combo box.
    * @param downArrow
    *            the arrow inside the combo box. Its relative location should be
    *            relative to the border.
    * @param items
    *            a collection of graphical objects, each of which represents an
    *            item in the combo box. The items should be in the order they
    *            will appear in the combo box. They should not already have a
    *            parent. The location of each object is ignored.
    */
   DenimComboBoxInstance(DenimComponent type,
                         TimedStroke border,
                         TimedStroke downArrow,
                         GraphicalObjectCollection items) {
      this(type, border, downArrow, false, false, items, 0);
   }

   //-----------------------------------------------------------------

   /**
    * Create an instance of a DENIM combo box, which will look like the given
    * objects. The combo box will have the same relative coordinates as the
    * given border. Called only by DenimComboBox.newInstance().
    * 
    * @param type
    *            an instance of DenimComboBox
    * @param border
    *            the border of the combo box. Its location will become the
    *            location of the combo box.
    * @param downArrow
    *            the arrow inside the combo box. Its relative location should be
    *            relative to the border.
    * @param items
    *            a collection of graphical objects, each of which represents an
    *            item in the combo box. The items should be in the order they
    *            will appear in the combo box. They should not already have a
    *            parent. The location of each object is ignored.
    */
   public DenimComboBoxInstance(DenimComponent type,
                                TimedStroke border,
                                TimedStroke downArrow,
                                boolean downArrowFilled,
                                boolean createdByStamp,
                                GraphicalObjectCollection items,
                                int selectedIndex) {
      super(type);
      init(type, border, downArrow, downArrowFilled, createdByStamp, items,
           selectedIndex);
   }

   //-----------------------------------------------------------------

   /**
    * Perform common initializations.
    */
   private void init(DenimComponent type,
                     TimedStroke border,
                     TimedStroke downArrow,
                     boolean downArrowFilled,
                     boolean createdByStamp,
                     GraphicalObjectCollection its,
                     int selectedIndex) {
      assert (type instanceof DenimComboBox):
         "DenimComboBoxInstance can only be created by DenimComboBox";

      this.border = border;
      this.downArrow = downArrow;
      this.downArrowFilled = downArrowFilled;
      this.createdByStamp = createdByStamp;
      this.items = its;
      this.selectedItem = null;

      this.setBoundingPoints2D(COORD_LOCAL, border);
      this.setHasClosedBoundingPoints(true);
      
      

      Style style = this.getStyle();
      style.setDrawColor(new Color(0, 0, 0, 0));
      style.setFillColor(new Color(0, 0, 0, 0));
      this.setStyle(style);

      // displayedState is a protected variable in DenimComponentInstance.java
      displayedState = new PatchImpl(border);
      displayedState.setHasClosedBoundingPoints(true);
      
      // igore strokes
      this.setIgnoreStrokes(true);
      ((PatchImpl)displayedState).setIgnoreStrokes(true);

      style = displayedState.getStyle();
      style.setDrawColor(Color.BLACK);
      style.setFillColor(Color.WHITE);
      style.setLineWidth(1.0f);
      displayedState.setStyle(style); 

      if (downArrowFilled) {
         downArrowPatch = new PatchImpl(downArrow);
         style = downArrowPatch.getStyle();
         style.setDrawColor(Color.BLACK);
         style.setFillColor(Color.BLACK);
         downArrowPatch.setStyle(style);
         ((Patch)displayedState).add(downArrowPatch);
      }
      else {
         downArrowPatch = null;
         ((Patch)displayedState).add(downArrow);
      }
      
//      if (Denim.getDeviceInfo().getName() == DeviceType.DESKTOP.getName()) {
         
      setSelectedIndex(selectedIndex);
         
//      } else {

//      }

      this.add(displayedState);
   }

   //=== CONSTRUCTORS ======================================================
   //===========================================================================


   //===========================================================================
   //=== COMBO BOX METHODS =================================================

   /**
    * Returns whether this combo box was created by a stamp (as opposed to
    * sketched).
    */
   public boolean isCreatedByStamp() {
      return createdByStamp;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the border of the combo box.
    */
   public TimedStroke getBorder() {
      return border;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the down arrow of the combo box.
    */
   public TimedStroke getDownArrow() {
      return downArrow;
   }

   //-----------------------------------------------------------------

   /**
    * Returns whether the down arrow is filled in.
    */
   public boolean isDownArrowFilled() {
      return downArrowFilled;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the items in this combo box.
    */
   public GraphicalObjectCollection getItems() {
      return items;
   }

   //-----------------------------------------------------------------

   /**
    * Sets the items in this combo box.
    */
   public void setItems(GraphicalObjectCollection items) {
	  updateConditionMap(this.items, items);
      this.items = items;
      refresh();
   }
   
   private void updateConditionMap(GraphicalObjectCollection old, 
   				GraphicalObjectCollection newitems) {
   	   DenimPanel panel = this.getPanel();
   	   ArrayList toDelete = new ArrayList();
   	   Iterator it = panel.getConditionStates().getCols().iterator();
   	   while(it.hasNext())
   	   {
   	   	   Object colHeader = it.next();
   	   	   GraphicalObject obj = (GraphicalObject)panel.getConditionStates().get(this, colHeader);
   	   	   int index = old.indexOf(obj);
   	   	   if(index>=newitems.numElements())
   	   	   {
   	   	   	  index = 0;
   	   	   }
   	   	   panel.getConditionStates().put(
   	   	   				this, colHeader, newitems.get(index));
   	   }
   	   
   }
   
   

   //-----------------------------------------------------------------

   /**
    * Returns the items in this combo box as an array of text strings. If the
    * combo box contains a mixture of typed and handwritten items, then a empty
    * string will be placed in the array instead of a handwritten item.
    * 
    * If the combo box only contains handwritten squiggles, then this method
    * returns an empty array.
    */
   public String[] getItemsAsText() {
      String[] itemsAsText = new String[items.numElements()];
      boolean hasText = false;

      int i = 0;
      Iterator it = items.getForwardIterator();
      while (it.hasNext()) {
         Object obj = it.next();
         if (obj instanceof TypedText) {
            itemsAsText[i] = ((TypedText)obj).getText();
            hasText = true;
         }
         else {
            itemsAsText[i] = "";
         }
         i++;
      }

      if (!hasText) {
         return new String[0];
      }
      else {
         return itemsAsText;
      }
   }

   //-----------------------------------------------------------------

   /**
    * Sets the items in this combo box, in the order specified by the string
    * array.
    */
   public void setItemsAsText(String[] newItems, Font font, Color c) {
      GraphicalObjectCollection newItemsCol =
         new GraphicalObjectCollectionImpl();
      for (int i = 0; i < newItems.length; i++) {
         JTextArea ta = new JTextArea(newItems[i]);
         //ta.setFont(new Font(fontName, Font.PLAIN, fontSize));//TypedText.getFont(TypedText.SMALL_FONT_SIZE));
         ta.setFont(font);
         ta.setForeground(c);
         TypedText txt = new TypedText(ta);
         newItemsCol.addToBack(txt);
      }
      setItems(newItemsCol);
   }

   
   //-----------------------------------------------------------------

   /**
    * Returns the index of the selected item.
    */
   public int getSelectedIndex() {
      return selectedIndex;
   }
   
   //-----------------------------------------------------------------

   /**
    * Returns the index of the selected item.
    */
   public int getSelectedIndex(GraphicalObject value) {
       return this.items.indexOf(value);
   }

   //-----------------------------------------------------------------

   /**
    * Sets the index of the selected item.
    */
   public void setSelectedIndex(int newIndex) {
      selectedIndex = newIndex;
      if (selectedItem != null) {
          selectedItem.delete();
         ((Patch)displayedState).remove(selectedItem);
      }

      selectedItem = (GraphicalObject)items.get(selectedIndex).deepClone();
      ((Patch)displayedState).add(selectedItem);
      selectedItem.moveTo(COORD_REL, MARGIN_X, MARGIN_Y);

      // Make the combo box big enough to hold the item
      Rectangle2D newBounds =
         new Rectangle2D.Double(0, 0,
            selectedItem.getBounds2D(COORD_REL).getWidth() +
               3 * MARGIN_X + downArrow.getBounds2D(COORD_REL).getWidth(),
            selectedItem.getBounds2D(COORD_REL).getHeight() + 2 * MARGIN_Y);

      this.setBoundingPoints2D(COORD_LOCAL, newBounds);
      displayedState.setBoundingPoints2D(COORD_LOCAL, newBounds);

      // Move the arrow
      if (downArrowPatch != null) {
         downArrowPatch.moveTo(COORD_REL,
            newBounds.getMaxX() -
              MARGIN_X -
              downArrowPatch.getBounds2D(COORD_REL).getWidth(),
            (displayedState.getBounds2D(COORD_LOCAL).getHeight() -
              downArrowPatch.getBounds2D(COORD_REL).getHeight()) / 2);
      }
      else {
         downArrow.moveTo(COORD_REL,
            newBounds.getMaxX() -
              MARGIN_X -
              downArrow.getBounds2D(COORD_REL).getWidth(),
            (displayedState.getBounds2D(COORD_LOCAL).getHeight() -
              downArrow.getBounds2D(COORD_REL).getHeight()) / 2);
      }
   }

   //-----------------------------------------------------------------

   private void refresh() {
      setSelectedIndex(getSelectedIndex());
   }

   //=== COMBO BOX METHODS =================================================
   //===========================================================================



   //===========================================================================
   //=== COMPONENT METHODS =================================================

   public void setTransparency(int transparency) {
   }

   //=== COMPONENT METHODS =================================================
   //===========================================================================


   //===========================================================================
   //=== MOUSE HANDLING METHODS ============================================

   /**
    * Handles a mouse press. Intended for use during Run mode.
    */
   public void mousePressed(MouseEvent e) {
      
      if ((menu == null) || !menu.isVisible()) {
         String[] items = getItemsAsText();
         if (items.length == 0) {
            items = new String[] {"Item 1", "Item 2", "Item 3"};
         }
         menu = new JPopupMenu();
         JMenuItem menuItem;

         for (int i = 0; i < items.length; i++) {
            menuItem = new JMenuItem(items[i]);
            menuItem.addActionListener(menuActionListener);
            menu.add(menuItem);
         }
         Point2D pt = this.getLocation2D(COORD_ABS);
         double height = this.getBounds2D(COORD_ABS).getHeight();
         menu.show(this.getSheet(),
                   (int)pt.getX(), (int)(pt.getY() + height + 1));
      }
      
   }

   //=== MOUSE HANDLING METHODS ============================================
   //===========================================================================

   //===========================================================================
   //=== CLONE METHODS =====================================================

   /**
    * Returns a deep clone of this combo box instance.
    */
   public Object deepClone() {
      return deepClone(new DenimComboBoxInstance(type));
   }

   //-----------------------------------------------------------------

   /**
    * Sets the clone parameter to a deep clone of this combo box instance, and
    * returns it.
    */
   public Object deepClone(DenimComboBoxInstance clone) {
      super.deepClone(clone);

      Patch cloneDisplayedState = (Patch)clone.displayedState;

      clone.border = (TimedStroke)border.deepClone();
      clone.downArrowFilled = downArrowFilled;
      if (downArrowFilled) {
         clone.downArrowPatch =
            (Patch)cloneDisplayedState.get(
               ((Patch)displayedState).indexOf(downArrowPatch));
         clone.downArrow = (TimedStroke)this.downArrow.deepClone();
      }
      else {
         clone.downArrowPatch = null;
         clone.downArrow =
            (TimedStroke)cloneDisplayedState.get(
               ((Patch)displayedState).indexOf(downArrow));
      }
      clone.items = (GraphicalObjectCollection)items.deepClone();
      clone.createdByStamp = createdByStamp;
      clone.selectedIndex = this.selectedIndex;
      clone.selectedItem =
         cloneDisplayedState.get(
            ((Patch)displayedState).indexOf(selectedItem));

      for(int i=0; i<clone.getStates().numElements(); i++)
      {
          ((GraphicalObject)clone.getStates().get(i)).setUniqueID(this.getStates().get(i).getUniqueID());
      }
      
      return clone;
   }

   //=== CLONE METHODS =====================================================
   //===========================================================================

   public void setStateIndex(int i) {
   	  this.setSelectedIndex(i);
   }
   
   public int getStateIndex() {
   	  return this.getSelectedIndex();
   }
   
   public GraphicalObjectCollection getStates() {
	  return this.items;
   }
   
   public boolean isHTMLConvertible() {
       if(this.getItems().get(0) instanceof TypedText)
           return true;
       else
           return false;
   }
   
   public Color getPrintDraw() {
       return Color.black;
   }
   
   public Font getFont() {
       GraphicalObject obj = this.getItems().getFirst();
       if(obj instanceof TypedText)
       {
           return ((TypedText)obj).getTextArea().getFont();
       }
       else
       {
           return new Font("SansSerif", Font.PLAIN, TextInsertDialog.SMALL_FONT_SIZE);
       }
   }
   
   public Color getColor() {
       GraphicalObject obj = this.getItems().getFirst();
       if(obj instanceof TypedText)
       {
           Color c = ((TypedText)obj).getTextArea().getForeground();
           if(c==null)
        	   c = Color.black;
           return c;
       }
       else
       {
           return Color.black;
       }
   }
   
} // of class

//==============================================================================

/*
 * Copyright (c) 1999-2003 Regents of the University of California. All rights
 * reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. All advertising materials mentioning features or use of this software must
 * display the following acknowledgement:
 * 
 * This product includes software developed by the Group for User Interface
 * Research at the University of California at Berkeley.
 * 
 * 4. The name of the University may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
