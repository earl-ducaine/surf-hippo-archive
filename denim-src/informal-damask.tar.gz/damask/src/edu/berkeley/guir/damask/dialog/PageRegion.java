package edu.berkeley.guir.damask.dialog;

import java.awt.geom.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.berkeley.guir.lib.util.StringLib;

/** 
 * A region of a page.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-07-2003 James Lin
 *                               Created Layout
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 07-07-2003
 */
public class PageRegion extends AbstractInteractionElement {

   private Page page;
   private final Direction name;
   private int inset;
   private List/*<Control>*/ controls = new ArrayList();
   private Map/*<Control, Double>*/ controlVoiceYDistances =
      new HashMap/*<Control, Double>*/();
   private final Orientation orientation;

   private PageBoundsHandler pageBoundsHandler = new PageBoundsHandler();
   private ElementContainerSource containerEventSource =
      new ElementContainerSource();

   //===========================================================================

   public PageRegion(final Page page, final Direction name) {
      this.page = page;
      this.name = name;
      
      this.inset = getDeviceType().getDefaultInset(name);
      this.orientation = getDeviceType().getOrientation(name);
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Performs initializations after the page containing this region has been
    * initialized. Called by Page.Page().
    */
   protected void initListeners() {
      page.addInteractionElementListener(pageBoundsHandler);
      if ((name == Direction.EAST)
         || (name == Direction.WEST)
         || (name == Direction.CENTER)) {
            
         final PageRegion northRegion = page.getRegion(Direction.NORTH);
         if (northRegion != null) {
            northRegion.addInteractionElementListener(pageBoundsHandler);
         }

         final PageRegion southRegion = page.getRegion(Direction.SOUTH);
         if (southRegion != null) {
            southRegion.addInteractionElementListener(pageBoundsHandler);
         }
      }
   }

   //===========================================================================

   /**
    * Returns the page that this region is in.
    */
   public Page getPage() {
      return page;
   }

   //===========================================================================

   /**
    * Returns the interaction graph that the page region is in, or null if
    * it's not in any graph.
    */
   public InteractionGraph getInteractionGraph() {
      final Page p = getPage();
      if (p != null) {
         return p.getInteractionGraph();
      }
      else {
         return null;
      }
   }

   //===========================================================================

   /**
    * Returns the name of this region.
    */
   public Direction getName() {
      return name;
   }

   //===========================================================================
   
   /**
    * Returns a list of controls contained in this region. 
    */
   public List/*<Control>*/ getControls() {
      return Collections.unmodifiableList(controls);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the specified control to the end of this page region.
    */
   protected final void add(final Control child) {
      add(controls.size(), child);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the specified control to this page region at the specified position.
    */
   protected void add(final int index, final Control child) {
      final PageRegion oldRegion = child.getPageRegion(getDeviceType());
      if (oldRegion != null) {
         oldRegion.remove(child);
      }

      prepareLayoutVoiceControls();

      controls.add(index, child);
      child.setPageRegion(getDeviceType(), this);
      fireElementAdded(index, child);

      layoutVoiceControls();
   }

   //---------------------------------------------------------------------------

   /**
    * Adds child to this page region after insertAfterMe. If insertAfterMe
    * is null, then the methods adds child to the beginning of this page
    * region.
    * 
    * @throws IllegalArgumentException if insertAfterMe is not in this page
    * region
    */
   protected void addAfter(final Control insertAfterMe, final Control child) {
      int index;
      if (insertAfterMe != null) {
         int indexOfInsertAfterMe = controls.indexOf(insertAfterMe);
         if (indexOfInsertAfterMe < 0) {
            throw new IllegalArgumentException(
               insertAfterMe + " is not in " + this);
         }
         index = indexOfInsertAfterMe + 1;
      }
      else {
         index = 0;
      }
      add(index, child);
   }

   //===========================================================================

   /**
    * Removes the specified control from this page region. Called by
    * Dialog.removeControl().
    */
   protected boolean remove(final Control control) {
      control.setPageRegion(getDeviceType(), null);
      final int index = controls.indexOf(control);
      if (index != -1) {
         prepareLayoutVoiceControls();
         controls.remove(control);
         fireElementRemoved(index, control);
         layoutVoiceControls();
         return true;
      }
      else {
         return false;
      }
   }

   //===========================================================================

   /**
    * Returns the control before the specified one in this region's list of
    * controls. 
    */
   public Control getPreviousControl(final Control control) {
      final List/*<Control>*/ controls = getControls();
      if (control == null) {
         if (controls.size() == 0) {
            return null;
         }
         else {
            return (Control)controls.get(controls.size() - 1);
         }
      }
      final int childIndex = controls.indexOf(control);
      if (childIndex == -1) {
         throw new IllegalArgumentException(control + " is not in " + this);
      }
      else if (childIndex > 0) {
         return (Control)controls.get(childIndex - 1);
      }
      else {
         return null;
      }
   }

   //===========================================================================

   /**
    * Returns the control after the specified one in this region's list of
    * controls, or the first control if the specified control is null.
    */
   public Control getNextControl(final Control control) {
      final List/*<Control>*/ controls = getControls();
      if (control == null) {
         if (controls.size() == 0) {
            return null;
         }
         else {
            return (Control)controls.get(0);
         }
      }
      
      final int childIndex = controls.indexOf(control);
      if (childIndex == -1) {
         throw new IllegalArgumentException(control + " is not in " + this);
      }
      else if (childIndex < controls.size() - 1) {
         return (Control)controls.get(childIndex + 1);
      }
      else {
         return null;
      }
   }

   //===========================================================================

   /**
    * Returns a string representation of this component, including the children
    * for <em>all</em> devices.
    */
   public String toLongString() {
      final StringBuffer sb = new StringBuffer();

      // 1. Print myself.
      sb.append(toString());

      // 2. Write the controls.
      String controlsStr = controlsToString(1);
      if (controlsStr.length() != 0) {
         sb.append('\n');
         sb.append(controlsStr);
      }

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of this component, with the given indent
    * level and including the children for the given device.
    */
   public String toLongString(int indentLevel, final DeviceType deviceType) {
      // 1. Make sure we have a concrete device; "all" is not acceptable here.
      assert deviceType != DeviceType.ALL : "Device cannot be ALL";

      final StringBuffer sb = new StringBuffer();

      // 2. Add indent
      sb.append(StringLib.spaces(indentLevel * DamaskUtils.INDENT_SPACES));

      // 3. Print myself.
      sb.append(toString());

      // 4. Write the controls.
      String controlsStr = controlsToString(indentLevel + 1);
      if (controlsStr.length() != 0) {
         sb.append('\n');
         sb.append(controlsStr);
      }

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   private String controlsToString(int indentLevel) {
      final StringBuffer sb = new StringBuffer();

      for (Iterator i = controls.iterator(); i.hasNext();) {
         InteractionElement e = (InteractionElement)i.next();
         sb.append(e.toLongString(indentLevel, getDeviceType()));
         if (i.hasNext()) {
            sb.append("\n");
         }
      }

      return sb.toString();
   }

   //===========================================================================
   
   /**
    * Gets the inset of this region, or
    * {@link edu.berkeley.guir.damask.DeviceType#CENTER_INSET} if this inset is
    * the center.  
    */
   public int getInset() {
      return inset;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets the inset of this region. Has no effect if the inset is the center.
    */
   public void setInset(final int inset) {
      this.inset = inset;
      updateBoundsAndTransform();
   }

   //===========================================================================
   
   /**
    * Returns the orientation of this region.
    */
   public Orientation getOrientation() {
      return orientation;
   }

   //===========================================================================
   
   /**
    * Returns the device type of this region.
    */
   public DeviceType getDeviceType() {
      if (page == null) {
         return null;
      }
      else {
         return page.getDeviceType();
      }
   }

   //---------------------------------------------------------------------------

   public Set/*<DeviceType>*/ getDeviceTypesVisibleTo() {
      final Set/*<DeviceType>*/ deviceTypes = new HashSet();
      final DeviceType deviceType = getDeviceType();
      if (deviceType != null) {
         deviceTypes.add(deviceType);
      }
      return deviceTypes;
   }

   //===========================================================================

   /**
    * Returns the bounds of this region.
    */   
   public Rectangle2D getBounds() {
      return getBounds(getDeviceType());
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the bounds of this page region.
    */
   protected void setBounds(final Rectangle2D bounds) {
      setBounds(getDeviceType(), bounds);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns the transform of this page region.
    */
   public AffineTransform getTransform() {
      return getTransform(getDeviceType());
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the transform of this page region.
    */
   protected void setTransform(final AffineTransform transform) {
      setTransform(getDeviceType(), transform);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Updates the bounds and transform of this page region, depending on the
    * bounds and transforms of the containing page and other page regions. 
    */
   protected void updateBoundsAndTransform() {
      //HACK
      if (page.getBounds() == null) {
         return;
      }
      
      final double width = page.getBounds().getWidth();
      final double height = page.getBounds().getHeight();
      
      if (name == Direction.NORTH) {
         setBounds(new Rectangle2D.Double(0, 0, width, inset));
      }
      else if (name == Direction.SOUTH) {
         setBounds(new Rectangle2D.Double(0, 0, width, inset));
         setTransform(AffineTransform.getTranslateInstance(0, height - inset));
      }
      else {
         final int northInset = page.getRegionInset(Direction.NORTH);
         final int southInset = page.getRegionInset(Direction.SOUTH);

         if (name == Direction.WEST) {
            setBounds(
               new Rectangle2D.Double(
                  0, 0, inset, height - southInset - northInset));
            setTransform(AffineTransform.getTranslateInstance(0, northInset));
         }
         else if (name == Direction.EAST) {
            setBounds(
               new Rectangle2D.Double(
                  0, 0, inset, height - southInset - northInset));
            setTransform(
               AffineTransform.getTranslateInstance(width - inset, northInset));
         }
         else {   // name == Direction.CENTER
            final int eastInset = page.getRegionInset(Direction.EAST);
            final int westInset = page.getRegionInset(Direction.WEST);
            setBounds(
               new Rectangle2D.Double(
                  0,
                  0,
                  width - westInset - eastInset,
                  height - southInset - northInset));
            setTransform(
               AffineTransform.getTranslateInstance(westInset, northInset));
         }
      }
   }

   //===========================================================================
   
   public void prepareLayoutVoiceControls() {
      if (getDeviceType() == DeviceType.VOICE) {
         controlVoiceYDistances.clear();
         Control control = DamaskUtils.getNextControlWithPrompt(this, null);
         Control prevControl = null;
         while (control != null) {
            if (prevControl != null) {
               controlVoiceYDistances.put(
                  control,
                  new Double(
                     control.getBoundsInParentCoords(DeviceType.VOICE).getY() -
                     prevControl.getBoundsInParentCoords(
                        DeviceType.VOICE).getY()));
            }
            else {
               controlVoiceYDistances.put(control, new Double(Double.POSITIVE_INFINITY));
            }
            
            prevControl = control;
            control = DamaskUtils.getNextControlWithPrompt(this, prevControl);
         }
      }
   }
   
   public void layoutVoiceControls() {
      if (getDeviceType() == DeviceType.VOICE) {
         Control control = DamaskUtils.getNextControlWithPrompt(this, null);
         Control prevControl = null;
         while (control != null) {
            if (prevControl != null) {
               final Double oldDyObject =
                  (Double)controlVoiceYDistances.get(control);
               if (oldDyObject != null) {
                  final double oldDy = oldDyObject.doubleValue();
                  final double newDy =
                     control.getBoundsInParentCoords(DeviceType.VOICE).getY() -
                     prevControl.getBoundsInParentCoords(DeviceType.VOICE).getY();
                  if (newDy != oldDy) {
                     final AffineTransform transform =
                        control.getTransform(DeviceType.VOICE);
                     if (oldDy == Double.POSITIVE_INFINITY) {
                        transform.preConcatenate(
                           AffineTransform.getTranslateInstance(0,
                              Response.DEFAULT_LENGTH));
                     }
                     else {
                        transform.preConcatenate(
                           AffineTransform.getTranslateInstance(0,
                              oldDy - newDy));
                     }
                     control.setTransform(DeviceType.VOICE, transform);
                  }
               }
            }
            
            prevControl = control;
            control = DamaskUtils.getNextControlWithPrompt(this, prevControl);
         }
      }
   }
   
   //===========================================================================
   
   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public void addElementContainerListener(
      ElementContainerListener listener) {

      containerEventSource.addElementContainerListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public void removeElementContainerListener(
      ElementContainerListener listener) {

      containerEventSource.removeElementContainerListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementAdded events to listeners.
    */
   private void fireElementAdded(final int index, final InteractionElement e) {
      containerEventSource.fireElementAdded(
         this, getDeviceType(), index, e);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires elementRemoved events to listeners.
    */
   private void fireElementRemoved(final int index, final InteractionElement e){
      containerEventSource.fireElementRemoved(
         this, getDeviceType(), index, e);
   }

   //===========================================================================
   
   public String toString() {
      return page.toString() + " - " + name + " - " + super.toString();
   }

   //===========================================================================

   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      return clone(null, new HashMap());
   }
   
   //===========================================================================

   /**
    * Returns a clone of this object.
    * 
    * @param elementClones a mapping of elements to their clones. Used by
    * Dialog.clone() so that elements that are in different pages but the same
    * dialog will only be cloned once and reused in the pages' clones.
    */
   protected Object clone(final Page clonePage, final Map elementClones) {
      final PageRegion clone = (PageRegion)super.clone();

      clone.page = clonePage;
      clone.controls = new ArrayList();
      clone.containerEventSource = new ElementContainerSource();

      for (Iterator i = controls.iterator(); i.hasNext();) {
         final Control control = (Control)i.next();
         Control controlClone = (Control)elementClones.get(control);
         if (controlClone == null) {
            controlClone = (Control)control.clone();
            elementClones.put(control, controlClone);
         }
         // Store the original control's response lines
         final Map/*<Integer, Line2D>*/ origResponseLines =
            control.getVoiceResponseLines();
         clone.add(controlClone);
         // Set the clone's response lines to the original controls. This
         // step is necessary because Control.setPageRegion() sets the
         // response lines to null.
         for (Iterator m = origResponseLines.keySet().iterator(); m.hasNext();) {
            final Integer condition = (Integer) m.next();
            final Line2D line = (Line2D) origResponseLines.get(condition);
            controlClone.setVoiceResponseLine(condition.intValue(), line);
         }
      }

      return clone;
   }

   //===========================================================================

   private class PageBoundsHandler implements InteractionElementListener {
      public void elementBoundsUpdated(InteractionElementEvent e) {
         updateBoundsAndTransform();
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
         updateBoundsAndTransform();
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }
}
