//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * An abstract tree that has at most two children per node.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0-1.0.0, Nov 25 1997, JH
 *               Created class
 *             - GUIRLib-v1.4-1.0.0, Aug 31 2000, JH
 *               Touched for GUIRLib release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   JDK 1.2
 * @version GUIRLib-v1.4-1.0.0, Aug 31 2000
 */
public class BinaryTree {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    Object     data  = null;    // the data in a node of the tree
    BinaryTree left  = null;    // the left subtree
    BinaryTree right = null;    // the right subtree

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================





    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Default constructor, creates an empty binary tree.
     */
    public BinaryTree() {
    } // of method

    //----------------------------------------------------------------

    /**
     * Creates a binary tree with the specified object at the root.
     *
     * @param data is the value for the root of this BinaryTree.
     */
    public BinaryTree(Object data) {
       setData(data);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Creates a binary tree with the specified object at the root.
     *
     * @param data is the value for the root of this BinaryTree.
     * @param left is the left subtree of this BinaryTree.
     * @param right is the right subtree of this BinaryTree.
     */
    public BinaryTree(Object data, BinaryTree left, BinaryTree right) {
       setData(data);
       setLeft(left);
       setRight(right);
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================





    //==========================================================================
    //===   SUBCLASS METHODS   =================================================

    /**
     * See if the specified Object is in the tree or not. Override this method
     * for functionality.
     *
     * @param     obj is the Object to check for in the tree.
     * @return    true if the Object is in the tree, false otherwise.
     *            Currently returns false always.
     */
    public boolean exists( Object obj ) {
       return (false);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Adds this object to the tree. Override this method for functionality.
     *
     * @param     obj is the Object to add to the tree.
     */
    protected void add( Object obj ) { 
    } // of method

    //-----------------------------------------------------------------

    /**
     * Remove an object from this tree. Override this method for functionality.
     *
     * @param     obj is the Object to remove from the tree.
     */
    protected void remove( Object obj ) { 
    } // of method

    //===   SUBCLASS METHODS   =================================================
    //==========================================================================






    //==========================================================================
    //===   ACCESSOR METHODS   =================================================

    /**
     * Get the number of elements in this tree.
     *
     * @return the number of elements currently in this tree.
     */
    public int getNumberOfElements() {
       int count = 0;

       if (data != null) {
          count++;
       }
       if (left != null) {
          count += left.getNumberOfElements();
       }
       if (right != null) {
          count += right.getNumberOfElements();
       }

       return(count);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Retrieve the data at the root of this tree. <EM>If this object is 
     * modified, there is no guarantee that the BinaryTree will be ordered 
     * consistently!</EM>
     * @return an Object that is the data at the root of this tree.
     */
    protected Object getData() {
       return(data);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Retrieve the left child of this tree.
     * @return the left child of this tree.
     */
    protected BinaryTree getLeft() {
       return (left);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Retrieve the right child of this tree.
     * @return the right child of this tree.
     */
    protected BinaryTree getRight() {
       return (right);
    } // of method

    //===   ACCESSOR METHODS   =================================================
    //==========================================================================






    //==========================================================================
    //===   TRAVERSAL METHODS   ================================================

    /**
     * Get the elements of the tree through an in-order traversal. This only
     * captures the current state of the tree, and will not reflect any
     * changes to the tree made after this method is called.
     * @return an Iterator of elements of this tree in-order.
     */
    public Iterator inOrderTraversal() {
       List list = new LinkedList();
       inOrderToList(this, list);
       return (list.iterator());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Get the elements of the tree through an pre-order traversal. This only
     * captures the current state of the tree, and will not reflect any
     * changes to the tree made after this method is called.
     * @return an Iterator of elements of this tree in-order.
     */
    public Iterator preOrderTraversal() {
       List list = new LinkedList();
       preOrderToList(this, list);
       return (list.iterator());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Get the elements of the tree through an post-order traversal. This only
     * captures the current state of the tree, and will not reflect any
     * changes to the tree made after this method is called.
     * @return an Iterator of elements of this tree in-order.
     */
    public Iterator postOrderTraversal() {
       List list = new LinkedList();
       postOrderToList(this, list);
       return (list.iterator());
    } // of method

    //===   TRAVERSAL METHODS   ================================================
    //==========================================================================





    //==========================================================================
    //===   MODIFIER METHODS   =================================================

    /**
     * Set the left subtree of this BinaryTree.
     *
     * @param left is a BinaryTree that will be the left subtree.
     */
    protected void setLeft(BinaryTree left) {
       this.left = left;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Set the right subtree of this BinaryTree.
     *
     * @param right is a BinaryTree that will be the right subtree.
     */
    protected void setRight(BinaryTree right) {
       this.right = right;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Set the value that this BinaryTree holds.
     *
     * @param obj is the value for the root of this BinaryTree.
     */
    protected void setData(Object obj) {
       this.data = obj;
    } // of method

    //===   MODIFIER METHODS   =================================================
    //==========================================================================






    //==========================================================================
    //===   PRIVATE METHODS   ==================================================

    /**
     * A helper method to perform an in-order traversal on this tree.
     *
     * @param current is the current node.
     * @param list is used to hold the elements. The size of it should be
     *        the number of elements in the tree.
     */
    private void inOrderToList(BinaryTree current, List list) {
       if ( current != null ) {
          inOrderToList( current.getLeft(),  list);
          list.add(current.getData());
          inOrderToList( current.getRight(), list);
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * A helper method to perform an pre-order traversal on this tree.
     *
     * @param current is the current node.
     * @param list is used to hold the elements. The size of it should be
     *        the number of elements in the tree.
     */
    private void preOrderToList(BinaryTree current, List list) {
       if ( current != null ) {
          list.add(current.getData() );
          preOrderToList( current.getLeft(),  list );
          preOrderToList( current.getRight(), list );
       }
    } // of method

    //-----------------------------------------------------------------

    /**
     * A helper method to perform an post-order traversal on this tree.
     *
     * @param current is the current node.
     * @param list is used to hold the elements. The size of it should be
     *        the number of elements in the tree.
     */
    private void postOrderToList(BinaryTree current, List list) {

       if ( current != null ) {
          postOrderToList( current.getLeft(),  list );
          postOrderToList( current.getRight(), list );
          list.add(current.getData() );
       }

    } // of method

    //===   PRIVATE METHODS   ==================================================
    //==========================================================================






    //==========================================================================
    //===   EQUALS   ===========================================================

    public boolean equals(Object obj) {
       if (obj instanceof BinaryTree) {

          BinaryTree temp = (BinaryTree) obj;

          if (data != null && data.equals(temp.data))
             if (left != null && left.equals(temp.left))
                if (right != null && right.equals(temp.right))
                   return (true);
       }
       return (false);
    } // of method

    //===   EQUALS   ===========================================================
    //==========================================================================






    //==========================================================================
    //===   TOSTRING   =========================================================

    /*
     * Return a String with an in-order representation of this tree.
     *
     * @return a String containing information about this object.
     */
    public String toString() {
       StringBuffer strbuf = new StringBuffer("[ ");
       Iterator     it     = inOrderTraversal();

       while (it.hasNext()) {
           strbuf.append(it.next());
           strbuf.append(", ");
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
