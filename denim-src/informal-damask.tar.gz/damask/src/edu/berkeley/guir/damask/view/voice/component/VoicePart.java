package edu.berkeley.guir.damask.view.voice.component;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.InteractionElementView;
import edu.berkeley.guir.damask.view.voice.dialog.Conversation;
import edu.berkeley.guir.damask.view.voice.dialog.Form;

/** 
 * Represents a part of a voice UI, such as a prompt that the computer says or
 * a response that the user says.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-18-2004 James Lin
 *                               Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 */
public abstract class VoicePart extends InteractionElementView {

   /**
    * Creates a voice part with the specified backing model.
    */
   protected VoicePart(final InteractionElement model) {
      super(model);
   }
   
   
   /**
    * Creates a voice part with the specified backing model.
    * 
    * @param model the model for which this view is created
    * @param useDefaultElementListener true if this instance should add
    * an InteractionElementListener that automatically adjusts the bounds
    * and transform of the view by listening to changes in the model
    */
   public VoicePart(final InteractionElement model,
         final boolean useDefaultElementListener) {
      super(model, useDefaultElementListener);
   }

   
   /**
    * Returns the form that this part lives in.
    */
   public Form getForm() {
      final Conversation conversation = getConversation();
      if (conversation == null) {
         return null;
      }
      else {
         return conversation.getForm();
      }
   }

   
   /**
    * Returns the form that this part lives in.
    */
   public Conversation getConversation() {
      return (Conversation)DamaskAppUtils.getAncestor(this,
                                                      Conversation.class);
   }

   
   // @Override
   public DeviceType getDeviceType() {
      final Form form = getForm();
      if (form == null) {
         return null;
      }
      else {
         return form.getDeviceType();
      }
   }
}
