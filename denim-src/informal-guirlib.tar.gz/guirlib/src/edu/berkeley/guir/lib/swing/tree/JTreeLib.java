//// See bottom of file for software license
package edu.berkeley.guir.lib.swing.tree;

import java.util.Enumeration;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

/**
 * Utilities for manipulating Java Swing JTrees.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified July 08 2003, JH
 */
public class JTreeLib {

    //==========================================================================
    //===   UTILITIES   ========================================================

    /**
     * Expand all nodes in a JTree.
     */
    public static void expandTree(JTree tree) {
        TreeModel              model = tree.getModel();
        DefaultMutableTreeNode root  = (DefaultMutableTreeNode) model.getRoot();
        Enumeration            en    = root.breadthFirstEnumeration();
        DefaultMutableTreeNode node;
        TreePath               path;

        //// 1. Expand the path of all leaf nodes.
        while (en.hasMoreElements()) {
            node = (DefaultMutableTreeNode) en.nextElement();
            if (node.isLeaf()) {
                path = new TreePath(node.getPath());
                tree.makeVisible(path);
            }
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the node containing the specified String if it exists
     * (depth of 1 only, applies toString() to the node), or create 
     * and add it if it does not exist.
     */
    public static DefaultMutableTreeNode getOrCreateNode(
                                  DefaultMutableTreeNode parent, String str) {
        //// 1. See if parent already contains a node with the String.
        Enumeration            en = parent.children();
        DefaultMutableTreeNode child;

        while (en.hasMoreElements()) {
            child = (DefaultMutableTreeNode) en.nextElement();
            if (str.equals(child.getUserObject().toString())) {
                return (child);
            }
        }

        //// 2. String was not in any children, so create and add.
        child = new DefaultMutableTreeNode(str);
        parent.add(child);
        return (child);
    } // of method

    //----------------------------------------------------------------

    /**
     * Print out a JTree to stdout.
     */
    public static void print(JTree tree) {
        TreeModel model = tree.getModel();
        Object    root  = model.getRoot();
        printHelper(model, root, 0);
    } // of method

    /**
     * Does the grunt work of printing.
     */
    private static void printHelper(TreeModel model, Object obj, int depth) {
        //// 1. Print the object.
        for (int i = 0; i < depth; i++) {
            System.out.print("   ");
        }
        System.out.println(obj);

        //// 2. Recurse on children.
        int size = model.getChildCount(obj);
        for (int i = 0; i < size; i++) {
            printHelper(model, model.getChild(obj, i), depth + 1);
        }
    } // of method

    /**
     * Print out a DefaultMutableTreeNode to stdout.
     */
    public static void print(DefaultMutableTreeNode root) {
        printHelper(new DefaultTreeModel(root), root, 0);
    } // of method

    //===   UTILITIES   ========================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static void main(String[] argv) {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("root");
        JTree                  tree = new JTree(root);

        System.out.println(tree);
        System.out.println();

        System.out.println(getOrCreateNode(root, "childA"));
        print(tree);
        System.out.println();

        getOrCreateNode(root, "childB");
        print(tree);
        System.out.println();

        getOrCreateNode(root, "childA");
        print(tree);
        System.out.println();
        print(root);
    } // of main

    //===   SELF-TESTING MAIN     ==============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
