package edu.berkeley.guir.damask.view.visual.event;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.visual.component.CheckBox;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * The event handler that handles inserting check boxes into pages.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-21-2003 James Lin
 *                               Created InsertCheckBoxHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-21-2003
 */
public class InsertCheckBoxHandler extends InsertComponentHandler {

   /**
    * Constructs a new button handler. 
    */
   public InsertCheckBoxHandler() {
      super(CheckBox.class);
   }


   // Overrides method in parent class.
   protected Component createNewComponent(
      final DeviceType deviceType,
      final PageRegion region,
      final AffineTransform transform,
      final Rectangle2D bounds) {

      final PNode defaultView = CheckBox.createTempView();
      final PPath captionPath = (PPath)defaultView.getChild(1);

      final Content caption =
         new Content(deviceType, captionPath.getPathReference());
         
      final Rectangle2D captionPathBounds =
         captionPath.getPathReference().getBounds2D();
      final AffineTransform captionPathTransform = captionPath.getTransform();

      caption.setBounds(deviceType, captionPathBounds);
      caption.setTransform(deviceType, captionPathTransform);

      final SelectMany.Item item = new SelectMany.Item(caption);

      final Rectangle2D captionPathBoundsInItemCoords =
         GeomLib.transformRectangle(captionPathTransform, captionPathBounds);

      item.setContentInsets(
         deviceType,
         captionPathBoundsInItemCoords.getY() - bounds.getY(),
         captionPathBoundsInItemCoords.getX() - bounds.getX(),
         bounds.getMaxY() - captionPathBoundsInItemCoords.getMaxY(),
         bounds.getMaxX() - captionPathBoundsInItemCoords.getMaxX());
         
      item.setTransform(region.getDeviceType(), transform);
      item.setBounds(region.getDeviceType(), bounds);
      
      final SelectMany selectMany = new SelectMany(deviceType);
      selectMany.addItem(item);
      
      return selectMany;
   }
}
