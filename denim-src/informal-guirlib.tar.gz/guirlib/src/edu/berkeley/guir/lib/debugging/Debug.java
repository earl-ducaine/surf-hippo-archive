//// See bottom of source code for software license.
package edu.berkeley.guir.lib.debugging;

import java.awt.Polygon;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import edu.berkeley.guir.lib.debugging.introspect.Introspect;
import edu.berkeley.guir.lib.debugging.introspect.PrintIntrospectHandler;
import edu.berkeley.guir.lib.debugging.introspect.JTreeIntrospectHandler;
import edu.berkeley.guir.lib.util.StringLib;

/**
 * Java debugging utilities, including log file output, 
 * stream output, graphical window output, and object introspection.
 * Most of the methods here are static class methods.
 * This class is not thread-safe.
 * <p>
 * Turn on debugging at runtime by setting the appropriate system environment
 * variables. If no debugging output environment variables are set, debugging 
 * is off.
 *
 * <P>
 * <H2>Example Usage</H2>
 * Here is an example of how this class can be used, in a class named MyTest.
 *
 * <CODE>
 * import edu.berkeley.guir.lib.debugging.*;
 *
 * public class MyTest {
 *     public static void testAAA() {
 *         Debug2.println("Running test");
 *     }
 *
 *     public static void main(String[] argv) {
 *         Debug2.println("Starting test");
 *         testAAA();
 *         Debug2.println("Finishing test");
 *     }
 * }
 * </CODE>
 *
 * If you just run the code, nothing happens. You have to run it
 * with some runtime flags to produce output. For example:
 * 
 * <CODE>
 *    java -Dguir.debug.output=true MyTest
 * </CODE>
 *
 * Then the output is:
 *
 * <PRE>
 *  &gt;&gt;&gt; MyTest:main() &lt;&lt;&lt;
 *  Starting test
 *  &gt;&gt;&gt; MyTest:testAAA() &lt;&lt;&lt;
 *  Running test
 *  &gt;&gt;&gt; MyTest:testAAA() &lt;&lt;&lt;
 *  Finishing test
 * </PRE>
 * 
 * <P>
 * <H2>Runtime Flags</H2>
 * You could also run the code with more runtime flags. The three flag types
 * are:
 * <CODE>
 *    java -Dguir.debug.output=true MyTest    // output to stdout
 *    java -Dguir.debug.window=true MyTest    // output to a GUI window
 *    java -Dguir.debug.logerr=true MyTest    // output to a logfile
 * </CODE>
 *
 * <P>
 * <H2>Ignoring Specific Classes and Methods</H2>
 * You can also selectively turn off debugging for specific classes and/or
 * methods. For example:
 *
 * <CODE>
 *   Debug2.addDebugIgnore("Test2", "testAAA"); // ignore method Test2:testAAA()
 *   Debug2.addDebugIgnore("Test2");            // ignore class Test2
 * </CODE>
 *
 * <P>
 * <H2>Displaying Objects</H2>
 * The internal values of Objects can also be displayed. 
 *
 * <CODE>
 * Debug.displayObjectStream("hi there");
 * </CODE>
 *
 * has the following output:
 * <PRE>
 * hi there
 *    private char[] value={h, i,  , t, h, e, r, e, }
 *    private int offset=0
 *    private int count=8
 *    private int hash=588714629
 * </PRE>
 *
 * Objects can also be displayed in an interactive Swing window via:
 * <CODE>
 * Debug.displayObjectTree("hi there");
 * </CODE>
 * 
 *
 * <P>
 * <H2>Debug API Summary</H2>
 * Here is a short list of the most useful methods:
 * <UL>
 *    <LI>{@link #println(String)}
 *    <LI>{@link #getCurrentClassAndMethod()}
 *    <LI>{@link #getCallingClassAndMethod()}
 *    <LI>{@link #displayObjectStream(Object)}
 *    <LI>{@link #displayObjectTree(Object)}
 * </UL>
 *
 * <P>
 * Here is an example of the introspection debugging:
 * <IMG SRC="{@docRoot}/img/debug-introspect.gif">
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @author <A HREF="http://www.francisli.org/">Francis Li</A>
 * @version May 13 2002 JIH
 */
public class Debug {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //// Make sure to change corresponding javadoc comments if you change these!
   private final static String LOGERR_PROPNAME = "guir.debug.logerr";
   private final static String WINDOW_PROPNAME = "guir.debug.window";
   private final static String OUTPUT_PROPNAME = "guir.debug.output";

   
   /**
    * Set the guir.debug.logerr system property to initialize this field. Record
    * debugging messages to the debugging logfile or not? Set to true if you 
    * want a logfile. Default if property not defined is false. Example:
    *
    * <pre>java -Dguir.debug.logerr=true ...</pre>
    */
   public static boolean LOGERR = Boolean.getBoolean(LOGERR_PROPNAME);   

   /**
    * Set the guir.debug.window system property to initialize this field. Send 
    * debugging messages to the TextArea Window or not? Set to true if you 
    * want a debugging window. Default if property not defined is false. 
    * Example:
    *
    * <pre>java -Dguir.debug.window=true ...</pre>
    */
   public static boolean WINDOW = Boolean.getBoolean(WINDOW_PROPNAME);   

   /**
    * Set the guir.debug.output system property to initialize this field. Print 
    * debugging messages to the normal output or not? Set to true if you want
    * output. Default if property not defined is false. Example:
    *
    * <pre>java -Dguir.debug.output=true ...</pre>
    * 
    * This will normally send output to stdout. The output stream can be 
    * redirected with method setOutput().
    */
   public static boolean OUTPUT = Boolean.getBoolean(OUTPUT_PROPNAME);   

   /**
    * If one of guir.debug.output, guir.debug.window, or guir.debug.logerr is
    * not set true, then this is false and turns off debugging output.
    */
   public static boolean ENABLE_DEBUG = LOGERR || WINDOW || OUTPUT;

   //-----------------------------------------------------------------

   public static boolean ON  = true;
   public static boolean OFF = false;

   //===   CONSTANTS   =========================================================
   //===========================================================================





   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   //// Use short names or fully qualified class names?
   static boolean flagUseShortClassNames = true;

   //// is debugging on?
   static boolean flagMode     = true;

   //// Handles to our debugging output.
   static PrintWriter pwriter;
   static DebugWindow debugWnd;
   static LogFile     logFile;

   //-----------------------------------------------------------------

   //// Static initializer. Initialize the output streams.
   static {
      if (ENABLE_DEBUG == true) {
         if (OUTPUT) pwriter  = new PrintWriter(System.out, true);
         if (WINDOW) debugWnd = new DebugWindow();
         if (LOGERR) {
            try {
               logFile  = new LogFile("logfile.txt");
            }
            catch (Exception e) {
               e.printStackTrace();
            }
         }
      }
   } // of static initializer

   //-----------------------------------------------------------------

   //// The last class and method we printed out.
   //// We store it to make sure we don't print it out twice in a row,
   //// because it looks goofy if you do print it out twice. Doh!
   static String strLastHeader = "";
   static String strClassName  = "";
   static String strMethodName = "";

   //// The current stack trace. Called by getDebugMode() when checking
   //// if we should print out.
   static StackTraceElement[] stack;

   //-----------------------------------------------------------------

   //// Map of classes and methods to ignore.
   //// (String -> Boolean.TRUE)
   //// (Fully Qualified Class Name                      -> Boolean.TRUE)
   ////     in this case, ignore everything from this class
   ////
   //// (Fully Qualified Class Name + "-" + method name  -> Boolean.TRUE)
   ////     in this case, ignore this specific method
   ////
   static Map mapDebugIgnore = new HashMap();

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Don't call this, for backwards compatibility.
    * @deprecated Use static methods in Debug instead of constructing a new
    *             Debug instance
    */
   public Debug() {
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Don't call this, for backwards compatibility.
    * @deprecated Use static methods in Debug instead of constructing a new
    *             Debug instance
    */
   public Debug(boolean flag) {
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   DEBUG IGNORE METHODS   ==============================================

   /**
    * Set whether Debug2 should ignore println statements from the 
    * specified class.
    */
   public static final void addDebugIgnore(Class cl) {
       addDebugIgnore(cl.getName());
   } // of method


   public static final void removeDebugIgnore(Class cl) {
       removeDebugIgnore(cl.getName());
   } // of method


   /**
    * Get whether Debug2 should ignore println statements from the 
    * specified class.
    */
   public static final boolean getDebugIgnore(Class cl) {
       return (getDebugIgnore(cl.getName()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set whether Debug2 should ignore println statements from the 
    * specified class.
    *
    * @param strClassName is a fully qualified class name.
    */
   public static final void addDebugIgnore(String strClassName) {
       mapDebugIgnore.put(strClassName, Boolean.TRUE);
   } // of method


   public static final void removeDebugIgnore(String strClassName) {
       mapDebugIgnore.remove(strClassName);
   } // of method


   /**
    * Get whether Debug2 should ignore println statements from the 
    * specified class.
    *
    * @param strClassName is a fully qualified class name.
    */
   public static final boolean getDebugIgnore(String strClassName) {
       return (mapDebugIgnore.containsKey(strClassName));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set whether Debug2 should ignore println statements from the 
    * specified class and method.
    */
   public static final void addDebugIgnore(Class cl, Method method) {
       addDebugIgnore(cl.getName(), method.getName());
   } // of method


   public static final void removeDebugIgnore(Class cl, Method method) {
       removeDebugIgnore(cl.getName(), method.getName());
   } // of method


   /**
    * Get whether Debug2 should ignore println statements from the 
    * specified class and method.
    */
   public static final boolean getDebugIgnore(Class cl, Method method) {
       return (getDebugIgnore(cl.getName(), method.getName()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set whether Debug2 should ignore println statements from the 
    * specified class and method.
    */
   public static final void addDebugIgnore(Class cl, 
                                           String strMethodName) {
       addDebugIgnore(cl.getName(), strMethodName);
   } // of method


   public static final void removeDebugIgnore(Class cl, 
                                              String strMethodName) {
       removeDebugIgnore(cl.getName(), strMethodName);
   } // of method


   /**
    * Get whether Debug2 should ignore println statements from the 
    * specified class and method.
    */
   public static final boolean getDebugIgnore(Class cl, 
                                              String strMethodName) {
       return (getDebugIgnore(cl.getName(), strMethodName));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set whether Debug2 should ignore println statements from the 
    * specified class and method.
    *
    * @param strClassName is a fully qualified class name.
    */
   public static final void addDebugIgnore(String strClassName, 
                                           String strMethodName) {
       mapDebugIgnore.put(strClassName + ":" + strMethodName, Boolean.TRUE);
   } // of method


   public static final void removeDebugIgnore(String strClassName, 
                                              String strMethodName) {
       mapDebugIgnore.remove(strClassName + ":" + strMethodName);
   } // of method


   /**
    * Get whether Debug2 should ignore println statements from the 
    * specified class and method.
    *
    * @param strClassName is a fully qualified class name.
    */
   public static final boolean getDebugIgnore(String strClassName, 
                                              String strMethodName) {
       if (getDebugIgnore(strClassName) == true) {
           return (true);
       }
       else {
           return (mapDebugIgnore.containsKey(strClassName + ":" + 
                                              strMethodName));
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the list of debugging to ignore.
    */
   public static final Iterator getAllDebugIgnore() {
       return (mapDebugIgnore.keySet().iterator());
   } // of method


   /**
    * Print to the stdout.
    */
   public static final void printAllDebugIgnore() {
       //// Lots of potential dangers here, including not printing
       //// out an object in a list b/c it is ignored, or having the
       //// wrong stack trace value if we do a check.
       Iterator it = mapDebugIgnore.keySet().iterator();
       while (it.hasNext()) {
           System.out.println(it.next());
       }
   } // of method

   //===   DEBUG IGNORE METHODS   ==============================================
   //===========================================================================





   //===========================================================================
   //===   ACCESSOR / MODIFIER METHODS   =======================================

   /**
    * Get the name of the current class and method.
    * This method works whether or not debugging is turned on.
    *
    * @return array {file name, class name, method name}
    */
   public static String[] getCurrentClassAndMethod() {
       return (getCallerInfo(getStackTrace(), 2));  // file, class, mthd
                                                    // value is 2 b/c 
                                                    //   1 = this method
                                                    //   2 = method we want
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the name of the class and method that called a method.
    * This method works whether or not debugging is turned on.
    *
    * @return array {file name, class name, method name}
    */
   public static String[] getCallingClassAndMethod() {
       return (getCallerInfo(getStackTrace(), 3));  // file, class, mthd
                                                    // value is 3 b/c 
                                                    //   1 = this method
                                                    //   2 = calling method
                                                    //   3 = method we want
   } // of method

   //-----------------------------------------------------------------

   /**
    * Turn debugging on or off globally.
    */
   public static void setDebugMode(boolean flag) {
      flagMode = flag;
   } // of method

   //-----------------------------------------------------------------

   /**
    * @return true if we should print debugging info for this class 
    *         and method, false otherwise.
    */
   public static final boolean getDebugMode() {
       //// 1. Fast exit.
       if (ENABLE_DEBUG == false) {
           return (false);
       }
       if (flagMode == false) {
           return (false);
       }

       //// 2. Check if we should debug this class.
       ////    Value is 3 because we call an extra method to extract the info.
       String[]        str;
       str           = getCallerInfo(getStackTrace(), 3);  // file, class, mthd
       strClassName  = str[1];
       strMethodName = str[2];

       //// 3. Return our check value.
       return (ENABLE_DEBUG && flagMode && 
                   !getDebugIgnore(strClassName, strMethodName));
   } // of method

   //-----------------------------------------------------------------

   /**
    * An example short class name is <CODE>String</CODE>. An example
    * long class name is <CODE>java.lang.String</CODE>.
    *
    * @param flag is true if short class names are to be used, false if
    *             full package names are to be used.
    */
   public static void setUseShortClassNames(boolean flag) {
      flagUseShortClassNames = flag;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Create a new debug window and do output there.
    */
   public static void setUseWindow(boolean flag) {
      WINDOW = flag;
      if (flag == true) {
         debugWnd = new DebugWindow();
      }
      ENABLE_DEBUG = LOGERR || WINDOW || OUTPUT;
   } // of method

   //-----------------------------------------------------------------

   public static final DebugWindow getDebugWindow() {
      return (debugWnd);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Create a new debug window and do output there.
    */
   public static void getNewDebugWindow(boolean flag) {
      WINDOW = flag;
      if (flag == true) {
         debugWnd = new DebugWindow();
      }
      ENABLE_DEBUG = LOGERR || WINDOW || OUTPUT;
   } // of method

   //===   ACCESSOR / MODIFIER METHODS   =======================================
   //===========================================================================




   //===========================================================================
   //===   EXCEPTION METHODS   =================================================

   /**
    * Print the stack trace right now.
    */
   public static void printStackTrace() {
      if (getDebugMode() == true) {
         println(new RuntimeException("Printing Stack Trace"));
      }
   } // of method

   /**
    * Print the stack trace right now.
    */
   public static void printStackTrace(StackTraceElement[] stack) {
      if (getDebugMode() == true) {
          for (int i = 0; i < stack.length; i++) {
              println(stack[i].getClassName()  + ":" + 
                      stack[i].getMethodName() + ":" + 
                      stack[i].getLineNumber());
          }
      }
   } // of method

   //===   EXCEPTION METHODS   =================================================
   //===========================================================================




   //===========================================================================
   //===   CLASS TOSTRING METHOD  ==============================================

   private static boolean isPrimitive(Class cl) {
       if (cl.isPrimitive() || cl == String.class) {
           return (true);
       }
       return (false);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Check if we should print this field.
    */
   private static boolean shouldPrint(Field f) {
       int val = f.getModifiers();

       //// Don't print out final static fields.
       if (Modifier.isFinal(val) == true && Modifier.isStatic(val)) {
           return (false);
       }

       return (true);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Given a class, use reflection to create a standard String of its values.
    */
   public static String toString(Object obj) {
       StringBuffer strbuf = new StringBuffer();
       Class        cl     = obj.getClass();

       try {
           if (isPrimitive(cl) == false) {

               //// For all fields...
               List    listFields = getAllFields(cl);
               Field[] fields     = new Field[listFields.size()];
               listFields.toArray(fields);

               for (int i = 0; i < fields.length; i++) {
                   if (shouldPrint(fields[i]) == false) {
                       continue;
                   }
                   strbuf.append(fields[i].getName() + " = " + 
                                 fields[i].get(obj)  + "\n");
               }
           }
           else {
               strbuf.append(obj.toString());
           }
       }
       catch (Exception e) {
           strbuf.append(e);
       }

       return (strbuf.toString());
   } // of method

   //===   CLASS TOSTRING METHOD  ==============================================
   //===========================================================================




   //===========================================================================
   //===   CLASS MANIPULATION METHODS   ========================================

   /**
    * Get all fields that belong to this class, traversing up the inheritance
    * chain if necessary.
    */
   private static List getAllFields(Class cl) {
      return (getAllFields(cl, new LinkedList()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Helper method for the method above.
    */
   private static List getAllFields(Class cl, List l) {
      Field[] fields = cl.getDeclaredFields();

      for (int i = 0; i < fields.length; i++) {
         l.add(fields[i]);
      }

      Class parent = cl.getSuperclass();
      if (parent != null && parent.isInterface() == false &&
          parent.isPrimitive() == false) {
         getAllFields(parent, l);
      }

      return (l);
   } // of method

   //===   CLASS MANIPULATION METHODS   ========================================
   //===========================================================================




   //===========================================================================
   //===   OBJECT INTROSPECTION METHODS   ======================================

   /**
    * Use introspection to debug an object, using a JTree as output.
    * Requires privileged access to reflection to work fully.
    */
   public static void displayObjectTree(Object obj) {
      if (getDebugMode() == true) {
         JTreeIntrospectHandler h = new JTreeIntrospectHandler();
         Introspect.parseObject(obj, h);
         h.displayJTree();
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Use introspection to debug an object, using the specified output i/o.
    * Requires privileged access to reflection to work fully.
    */
   public static void displayObjectStream(Object obj, OutputStream out) {
      if (getDebugMode() == true) {
         Introspect.parseObject(obj, new PrintIntrospectHandler(out));
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Use introspection to debug an object, using the specified output i/o.
    * Requires privileged access to reflection to work fully.
    */
   public static void displayObjectStream(Object obj, PrintWriter out) {
      if (getDebugMode() == true) {
         Introspect.parseObject(obj, new PrintIntrospectHandler(out));
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Use introspection to debug an object, using System.out.
    * Requires privileged access to reflection to work fully.
    */
   public static void displayObjectStream(Object obj) {
      if (getDebugMode() == true) {
         Introspect.parseObject(obj, new PrintIntrospectHandler(System.out));
      }
   } // of method

   //===   OBJECT INTROSPECTION METHODS   ======================================
   //===========================================================================




   //===========================================================================
   //===   PRINTLN   ===========================================================

   private static String getHeader() {
       return (">>> " + strClassName + ":" + strMethodName + "() <<<");
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print out a blank line with no headers.
    */
   public static final void println() {
      if (getDebugMode() == true) {
         if (OUTPUT) pwriter.println();
         if (WINDOW) debugWnd.println();
      }
   } // of method

   //-----------------------------------------------------------------

   public static void println(String str) {
      if (getDebugMode() == true) {
         String strHeader = getHeader();

         if (strLastHeader.hashCode() == strHeader.hashCode()) {
            strHeader = "";
            if (LOGERR) logFile.setPrintTime(false);
         }
         else {
            strLastHeader = strHeader;
            strHeader     = strHeader + "\n";
            if (LOGERR) logFile.setPrintTime(true);
         }

         if (WINDOW) {
            String strWin = StringLib.fold("   ", str, Integer.MAX_VALUE);
            debugWnd.println(strHeader + strWin);
         }

         if (OUTPUT) {
            String strOut = StringLib.fold("   ", str, Integer.MAX_VALUE);
            pwriter.println(strHeader + strOut);
         }

         if (LOGERR) {
            String strOut = StringLib.fold("   ", str, Integer.MAX_VALUE);
            logFile.logMessage(strHeader + strOut);
         }

      }
   } // of method

   //-----------------------------------------------------------------

   public static final void println(Throwable e) {
      if (getDebugMode() == true) {
         if (OUTPUT) e.printStackTrace(pwriter);
         if (WINDOW || LOGERR) {
            StringWriter swriter = new StringWriter();
            PrintWriter  pwriter = new PrintWriter(swriter);
            e.printStackTrace(pwriter);
            pwriter.flush();

            if (WINDOW) {
               debugWnd.println(swriter.toString());
            }
            if (LOGERR) {
               logFile.setPrintTime(true);
               logFile.logMessage(swriter.toString());
            }
         }
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print out an error message.
    *
    * @param obj is the Object to print out.
    */
   public static final void println(Object obj) {
      if (getDebugMode() == true) {
         if (obj == null) {
            println("null");
         }
         else {
            println(obj.toString());
         }
      }
   } // of method

   public static final void println(Object[] objArray) {
      if (getDebugMode() == true) {
         println(StringLib.toString(objArray));
      }
   } // of method

   //-----------------------------------------------------------------

   public static final void println(boolean flag) {
      if (getDebugMode() == true) {
         if (flag) {
            println("true");
         }
         else {
            println("false");
         }
      }
   } // of method

   //-----------------------------------------------------------------

   public static final void println(byte b) {
      if (getDebugMode() == true) {
         println(Byte.toString(b));
      }
   } // of method

   public static final void println(byte[] bArray) {
      if (getDebugMode() == true) {
         println(StringLib.toString(bArray));
      }
   } // of method

   //-----------------------------------------------------------------

   public static final void println(short s) {
      if (getDebugMode() == true) {
         println(Short.toString(s));
      }
   } // of method

   public static final void println(short[] sArray) {
      if (getDebugMode() == true) {
         println(StringLib.toString(sArray));
      }
   } // of method

   //-----------------------------------------------------------------

   public static final void println(char ch) {
      if (getDebugMode() == true) {
         println("" + ch);
      }
   } // of method

   public static final void println(char[] chArray) {
      if (getDebugMode() == true) {
         println(StringLib.toString(chArray));
      }
   } // of method

   //-----------------------------------------------------------------

   public static final void println(double d) {
      if (getDebugMode() == true) {
         println(Double.toString(d));
      }
   } // of method

   public static final void println(double[] dArray) {
      if (getDebugMode() == true) {
         println(StringLib.toString(dArray));
      }
   } // of method

   //-----------------------------------------------------------------

   public static final void println(float f) {
      if (getDebugMode() == true) {
         println(Float.toString(f));
      }
   } // of method

   public static final void println(float[] fArray) {
      if (getDebugMode() == true) {
         println(StringLib.toString(fArray));
      }
   } // of method

   //-----------------------------------------------------------------

   public static final void println(int i) {
      if (getDebugMode() == true) {
         println(Integer.toString(i));
      }
   } // of method

   public static final void println(int[] intArray) {
      if (getDebugMode() == true) {
         println(StringLib.toString(intArray));
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * This is because polygon is stoopid.
    * <P>
    * Makes me wonder if there is some programming language model that lets you
    * dynamically, safely, and securely attach methods to predefined classes, 
    * since developers can't always know beforehand what's needed.
    */
   public static final void println(Polygon poly) {
      if (getDebugMode() == true) {
         println(StringLib.toString(poly));
      }
   } // of method

   //===   PRINTLN   ===========================================================
   //===========================================================================




   //===========================================================================
   //===   INTERNAL BEHIND-THE-SCENE METHODS   =================================

   private static final String fixClassName(String strClassName) {
       if (flagUseShortClassNames == true) {
           int index = strClassName.lastIndexOf('.');
           return (strClassName.substring(index + 1));
       }
       return (strClassName);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the current stack trace.
    */
   private static final StackTraceElement[] getStackTrace() {
       Throwable t = new Throwable().fillInStackTrace();
       return (t.getStackTrace());
   } // of method

   //-----------------------------------------------------------------

   private static final void storeStackTrace() {
       Throwable t = new Throwable().fillInStackTrace();
       stack = t.getStackTrace();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Variable back should be the number of StackTraceElements
    * to peel back on, because of the number of method calls used
    * in this debugging class.
    */
   private static String[] getCallerInfo(StackTraceElement[] stack, int back) {
       String[] strClassMethod = new String[3];

       strClassMethod[0] =              stack[back].getFileName();
       strClassMethod[1] = fixClassName(stack[back].getClassName());
       strClassMethod[2] =              stack[back].getMethodName();
       return (strClassMethod);
   } // of method

   //===   INTERNAL BEHIND-THE-SCENE METHODS   =================================
   //===========================================================================



   
   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) {
       displayObjectStream("hi there");
       displayObjectStream(new Integer(4));
       displayObjectStream(new edu.berkeley.guir.lib.awt.geom.Polygon2D());

   }

/*
   public static void main(String[] argv) {
      Debug2.printStackTrace();
      Debug2.println(new Integer(5));
      Debug2.println(new Integer(6));
      Debug2.println(new RuntimeException("hey"));
      Debug2.println(new Integer(2).getClass().getName());

      Debug2.printAllDebugIgnore();
      Debug2.addDebugIgnore("java.lang.String");
      Debug2.addDebugIgnore("java.lang.String", "toString");

      Debug2.printAllDebugIgnore();
      System.out.println(Debug2.getDebugIgnore("java.lang.String"));
      System.out.println(Debug2.getDebugIgnore("java.lang.String", "toString"));
      System.out.println(Debug2.getDebugIgnore("java.lang.Exception"));
   } // of method
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class 

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
