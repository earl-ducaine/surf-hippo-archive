package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.Vector;

/*Constructs the expanded view of a prompt node. Supports automatic rezising as user types in the node's text area
*/
public class SingleExpandedNodeView extends AbstSingleNodeView {
    private static final int BOTTOM_INSET = 2;
    private STextArea m_textArea;
    private Area           m_expandedTextShape;
    private RoundRectangle2D.Float m_expShape;
    
    public SingleExpandedNodeView(SuedeModel model, SingleNodeModel nodeModel, String name, ActionListener al, String caption) {
       super(model, nodeModel);
       setName(name);
       setLayout(null);
       setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);   
       m_expShape = new RoundRectangle2D.Float(0,0,DEFAULT_WIDTH-1,DEFAULT_HEIGHT,ARC, ARC);
       m_expandedTextShape = new Area(m_expShape);
       m_expandedTextShape.subtract(new Area(new Rectangle(DEFAULT_WIDTH, MENU_HEIGHT)));
       AffineTransform trans = new AffineTransform();
       trans.translate(-m_expandedTextShape.getBounds().x, -m_expandedTextShape.getBounds().y);
       m_expandedTextShape.transform(trans);
       m_textArea = new STextArea(m_expandedTextShape);
       m_textArea.setStroke(null);
       m_textArea.setLocation(0, MENU_HEIGHT);
       m_textArea.setStroke(NODE_STROKE);
            
       m_textArea.setLineWrap(true); //this tells the text area to line wrap
       m_textArea.setWrapStyleWord(true); //this tells the text area to wrap at word boundaries, not at character boundaries
       m_textArea.setText(caption);
       add(m_textArea);
     
       m_playButton = new PlayButton(false, NODE_STROKE);
       m_playButton.setBounds(DEFAULT_WIDTH - BUTTON_WIDTH, 1, BUTTON_WIDTH, DEFAULT_HEIGHT/2);
       add(m_playButton);                

       m_recordButton = new RecordButton(Color.black, NODE_STROKE);
       if ( model.getAnalysisMode() )
            m_recordButton.setEnabled( false );
       m_recordButton.setBounds(DEFAULT_WIDTH - 2*BUTTON_WIDTH, 1, BUTTON_WIDTH, DEFAULT_HEIGHT/2);
       add(m_recordButton);
    
       m_slider = new SSlider(NODE_STROKE);
       m_slider.setBounds(BUTTON_WIDTH, 0, DEFAULT_WIDTH - 3*BUTTON_WIDTH, DEFAULT_HEIGHT/2);
       m_slider.setEnabled(false);
       m_slider.setOpaque(false);
       add(m_slider);
            
       Vector balloons = nodeModel.getBalloons();
       for (int i=0; i<balloons.size(); i++)
          add((SBalloon)balloons.get(i));
            
       setAudioDuration(nodeModel.getDuration());

       if (al != null)  m_recordButton.addActionListener(al);    
    }
 
 
    public void setCaption(String s) {
        m_textArea.setText(s);
    }
    
    public String getCaption() {
        return m_textArea.getText();
    }
    
    //determines whether the area the mouse press was in is operable, i.e. whether it 
    //is in the text area. If yes, then returns false. 
    public boolean isOperable(Point p) {
        if ( m_nodemodel.getSuedeModel().getAnalysisMode() )
            return false;
 
        Point temp = new Point(p.x, p.y);
        javax.swing.SwingUtilities.convertPointFromScreen(temp, this);
        return (getComponentAt(temp)!=m_textArea); 
    }
    
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D)(g);
        g2d.setFont(m_textArea.getFont());
        
        int textHeight = m_textArea.getMinimumSize().height + MENU_HEIGHT + BOTTOM_INSET;
        if(textHeight<=DEFAULT_HEIGHT) textHeight = DEFAULT_HEIGHT + m_textArea.getFont().getSize();

        // we only need to update the text area background if it has changed in size
        if (textHeight!=getHeight()) {
            setSize(DEFAULT_WIDTH, textHeight);
            m_expShape = new RoundRectangle2D.Float(0,0,DEFAULT_WIDTH-1,textHeight-1,ARC, ARC);
            m_expandedTextShape = new Area(m_expShape);
            m_expandedTextShape.subtract(new Area(new Rectangle(DEFAULT_WIDTH, MENU_HEIGHT)));
            AffineTransform trans = new AffineTransform();
            trans.translate(-m_expandedTextShape.getBounds().x, -m_expandedTextShape.getBounds().y);
            m_expandedTextShape.transform(trans);
            m_textArea.setShape(m_expandedTextShape);
            m_textArea.setLocation(0, MENU_HEIGHT);
        }
        
        g2d.setColor(NODE_FILL);
        g2d.fill(m_expShape);
        g2d.setColor(NODE_STROKE);
        g2d.setStroke(AbstNodeView.STROKE);
        super.paintComponent(g2d);

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(NODE_STROKE);
        g2d.draw(m_expShape);
        g2d.setFont(g2d.getFont().deriveFont(Font.BOLD, TYPE_SIZE));
        g2d.drawString(getAsciiName(), BUTTON_WIDTH/2 - TYPE_SIZE*0.35f, DEFAULT_HEIGHT/4 + (int)(TYPE_SIZE*0.55f));
      
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g2d.setStroke(PIXEL_STROKE);
        g2d.drawLine(BUTTON_WIDTH,           0, BUTTON_WIDTH,           DEFAULT_HEIGHT/2);
        g2d.drawLine(DEFAULT_WIDTH - 2*BUTTON_WIDTH, 0, DEFAULT_WIDTH - 2*BUTTON_WIDTH, DEFAULT_HEIGHT/2);
        g2d.drawLine(DEFAULT_WIDTH - BUTTON_WIDTH,   0, DEFAULT_WIDTH - BUTTON_WIDTH,   DEFAULT_HEIGHT/2);
    }
    

}