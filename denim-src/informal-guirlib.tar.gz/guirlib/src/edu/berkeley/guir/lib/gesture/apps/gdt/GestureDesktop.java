package edu.berkeley.guir.lib.gesture.apps.gdt;

import javax.swing.*;
import edu.berkeley.guir.lib.gesture.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.util.List;

/** The gdt main "desktop" area that manages multiple views of gesture
    sets, gesture groups, gestures, training/test examples, and error
    messages.  You can use an ItemListener to find out about
    JInternalFrame (de)selections.  You can use a
    ListSelectionListener to find out about selections of widgets
    contained inside the frames GestureDesktop manages. */
public class GestureDesktop extends JDesktopPane
  implements SwingConstants, ItemSelectable, Commander, GestureAcceptor,
	     GDTConstants {
  protected EventListenerList listenerList = new EventListenerList();
  private ActionListener myActionListener = new ActionListener() {
    public void actionPerformed(ActionEvent e)
    {
      showFrame(((GestureObjectDisplay)e.getSource()).getDisplayedObject());
    }
  };
  protected InternalFrameListener ifListener = new MyIFListener();
  
  public GestureDesktop()
  {
    super();
  }

  public void showFrame(GestureObject data)
  {
    showFrame(data, data.getParent().getName());
  }

  public void showFrame(GestureObject data, String parentName)
  {
    GInternalFrame iFrame = GInternalFrame.makeInternalFrame(data,
							     parentName);
    showFrame(iFrame);
  }

  public void showFrame(JInternalFrame iFrame)
  {
    if (iFrame != null) {
      //System.out.println("just made: " + iFrame.getSize());
      add(iFrame);
      //System.out.println("after add: " + iFrame.getSize());
      iFrame.setVisible(true);
      //System.out.println("now visible: " + iFrame.getSize());
      iFrame.setSize(new Dimension(300, 200));
      //System.out.println("packed: " + iFrame.getSize());
      iFrame.addInternalFrameListener(ifListener);
      if (iFrame instanceof GInternalFrame) {
	GInternalFrame gestureIFrame = (GInternalFrame) iFrame;
	GestureObjectDisplay display =
	  gestureIFrame.getGestureObjectDisplay();
	display.addActionListener(myActionListener);
	gestureIFrame.addMenuValidChangeListener(new ChangeListener() {
	  public void stateChanged(ChangeEvent e) {
	    CommandUtil.fireMenuValidChangeEvent(listenerList, e);
	  }
	});
	if (display instanceof GestureContainerPanel) {
	  ((GestureContainerPanel) display).getSelectionModel().
	    addListSelectionListener(new ListSelectionListener() {
	      public void valueChanged(ListSelectionEvent e) {
		fireListSelectionEvent(e);
	      }
	    });
	}
      }
      else {
	iFrame.setClosable(true);
      }
    }
  }

  /** Called when a valid gesture is entered by the user.  This
      routine sends it to the appropriate GestureCategory */
  public boolean gestureDrawn(Gesture g)
  {
    GestureObjectDisplay display = getSelectedGestureObjectDisplay();
    if ((display != null) && display.canAcceptGesture()) {
      return display.gestureDrawn(g);
    }
    else {
      MainFrame mf = (MainFrame) SwingUtilities.
	getAncestorOfClass(MainFrame.class, this);
      mf.recognizeGesture(g);
      return false;
    }
  }

  public boolean canAcceptGesture()
  {
    GestureObjectDisplay display = getSelectedGestureObjectDisplay();
    return (display != null) && display.canAcceptGesture();
  }

  public String getInputGestureTitle()
  {
    GestureObjectDisplay display = getSelectedGestureObjectDisplay();
    if ((display != null) && display.canAcceptGesture()) {
      return display.getInputGestureTitle();
    }
    else {
      return "Draw a gesture to be recognized";
    }
  }
  
  public GestureObjectDisplay getSelectedGestureObjectDisplay()
  {
    JInternalFrame selectedFrame = getSelectedFrame();
    if ((selectedFrame != null) &&
	(selectedFrame instanceof GInternalFrame)) {
      return ((GInternalFrame) selectedFrame).getGestureObjectDisplay();
    }
    else {
      return null;
    }
  }
  
  public void addItemListener(ItemListener l)
  {
    listenerList.add(ItemListener.class, l);
  }
  
  public void removeItemListener(ItemListener l)
  {
    listenerList.remove(ItemListener.class, l);
  }

  /** Provided for compatibility with ItemSelectable.  Returns the
      selected frame.  getSelectedFrame() is probably more useful. */
  public Object[] getSelectedObjects()
  {
    JInternalFrame selection = getSelectedFrame();
    if (selection == null) {
      return null;
    }
    Object[] result = new Object[1];
    result[0] = selection;
    return result;
  }

  /*
  public void setSelectedFrame(JInternalFrame frame)
  {
    System.out.println("sSF: selecting: " + ((frame == null) ? "(null)" :
		       frame.getTitle()));
    JInternalFrame currentSelection = getSelectedFrame();
    System.out.println("sSF: currentSelection: " +
		       ((currentSelection == null) ? "(null)" :
		       currentSelection.getTitle()));
    //if (currentSelection != frame) {
      if (currentSelection != null) {
	//getDesktopManager().deactivateFrame(currentSelection);
	fireItemEvent(currentSelection, ItemEvent.DESELECTED);
      }
      super.setSelectedFrame(frame);
      if (frame != null) {
	//getDesktopManager().activateFrame(frame);
	fireItemEvent(frame, ItemEvent.SELECTED);
      }
      CommandUtil.fireMenuValidChangeEvent(listenerList, new
					   ChangeEvent(this));
      //}
  }
  */

  protected void fireItemEvent(JInternalFrame f, int stateChange)
  {
    ItemEvent event = null;
    Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ItemListener.class) {
	if (event == null)
	  event = new ItemEvent(this, ItemEvent.ITEM_STATE_CHANGED,
				f, stateChange);
	((ItemListener) listeners[i+1]).itemStateChanged(event);
      }
    }
  }

  /** returns the selected gesture objects */
  public List getSelectedGestureObjects()
  {
    GestureObjectDisplay display = getSelectedGestureObjectDisplay();
    if ((display == null) || !(display instanceof GestureContainerPanel)) {
      return null;
    }
    else {
      GestureContainerPanel containerPanel =
	(GestureContainerPanel) display;
      return containerPanel.getSelectedGestureObjects();
    }
  }

  /** returns the selected widgets */
  public List getSelection()
  {
    GestureObjectDisplay display = getSelectedGestureObjectDisplay();
    if ((display == null) || !(display instanceof GestureContainerPanel)) {
      return null;
    }
    else {
      GestureContainerPanel containerPanel =
	(GestureContainerPanel) display;
      return containerPanel.getSelectedObjects();
    }
  }
  
  public void addListSelectionListener(ListSelectionListener listener)
  {
    listenerList.add(ListSelectionListener.class, listener);
  }
  
  public void removeListSelectionListener(ListSelectionListener listener)
  {
    listenerList.remove(ListSelectionListener.class, listener);
  }

  protected void fireListSelectionEvent(ListSelectionEvent event)
  {
    Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ListSelectionListener.class) {
	((ListSelectionListener) listeners[i+1]).valueChanged(event);
      }
    }
  }
  
  public boolean isCommandValid(int id)
  {
    boolean valid;
    JInternalFrame selectedFrame = getSelectedFrame();
    switch (id) {
    default:
      valid = ((selectedFrame != null) &&
	       (selectedFrame instanceof GInternalFrame)) ?
	((GInternalFrame) selectedFrame).isCommandValid(id) : false;
      break;
    }
    return valid;
  }

  public void doCommand(int id)
  {
    JInternalFrame selectedFrame = getSelectedFrame();
    switch (id) {
    default:
      if ((selectedFrame != null) &&
	  (selectedFrame instanceof GInternalFrame)) {
	((GInternalFrame) selectedFrame).doCommand(id);
      }
    }
  }

  public void addMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.add(ChangeListener.class, listener);
  }

  public void removeMenuValidChangeListener(ChangeListener listener)
  {
    listenerList.remove(ChangeListener.class, listener);
  }

  protected class MyIFListener extends InternalFrameAdapter {
    public void internalFrameActivated(InternalFrameEvent e)
    {
      //System.out.println("Frame activated");
      JInternalFrame f = e.getInternalFrame();
      fireItemEvent(f, ItemEvent.SELECTED);
      CommandUtil.
	fireMenuValidChangeEvent(listenerList, new
				 ChangeEvent(GestureDesktop.this));
    }

    public void internalFrameDeactivated(InternalFrameEvent e)
    {
      //System.out.println("Frame deactivated");
      JInternalFrame f = e.getInternalFrame();
      fireItemEvent(f, ItemEvent.DESELECTED);
      CommandUtil.
	fireMenuValidChangeEvent(listenerList, new
				 ChangeEvent(GestureDesktop.this));
    }
  }
}
