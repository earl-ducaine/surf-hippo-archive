package edu.berkeley.guir.damask.view.visual.dialog;

import java.awt.*;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;
import java.util.List;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.nodes.PageRegionViewSizingBorder;
import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.util.PPaintContext;
import edu.umd.cs.piccolox.nodes.PClip;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * The content of a page in Damask.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-01-2003 James Lin
 *                               Created DamaskPageContent.
 *                    09-11-2003 James Lin
 *                               Renamed to PageViewContent.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-01-2003
 */
public class PageViewContents extends PClip implements PageViewPart {
   private static final Paint FOLD_COLOR = new Color(255, 0, 0, 80);
   private static final Stroke FOLD_STROKE =
      new BasicStroke(
         1,
         BasicStroke.CAP_BUTT,
         BasicStroke.JOIN_MITER,
         1,
         new float[] { 5, 5 },
         0);
   
   private boolean inRunMode = false;

   private final Map/*<Direction, PageRegionView>*/ regions = new HashMap();
   
   private int northInset = Integer.MIN_VALUE;
   private int southInset = Integer.MIN_VALUE;
   private int westInset = Integer.MIN_VALUE;
   private int eastInset = Integer.MIN_VALUE;
   private Rectangle2D oldBounds;

   public PageViewContents(final boolean grayOutTemplateElements) {
      // Initialize only after this node has been added to a page.
      addPropertyChangeListener(
         PNode.PROPERTY_PARENT,
         new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
               setInRunMode(getPageView().isInRunMode());
               // Initialize page regions
               for (Iterator i = getRegionNames().iterator(); i.hasNext(); ) {
                  final Direction name = (Direction)i.next();
                  final PageRegion region =
                     ((Page)getPageView().getModel()).getRegion(name);
                  final PageRegionView regionView =
                     new PageRegionView(region, grayOutTemplateElements);
                  
                  regions.put(name, regionView);
                  addChild(regionView);
                  //bounds of content are set in layoutChildren()
               }
            }
         });
   }


   // Overrides method in PageViewPart.
   public PageView getPageView() {
      return (PageView)getParent();
   }
   

   /**
    * Returns the names of the regions within this page.
    * 
    * @return a Set of Directions
    */
   public Set/*<Direction>*/ getRegionNames() {
      return ((Page)getPageView().getModel()).getRegionNames();
   }


   /**
    * Returns the node representing the page region with the given name.
    */   
   public PageRegionView getRegionView(Direction name) {
      return (PageRegionView)regions.get(name);
   }


   /**
    * Returns the regions in this page.
    * 
    * @return a Collection of PageRegionViews
    */   
   public Collection/*<PageRegionView>*/ getRegionViews() {
      return Collections.unmodifiableCollection(regions.values());
   }


   /**
    * Returns whether this page view is in Run mode.
    */
   public boolean isInRunMode() {
      return inRunMode;
   }

   /**
    * Sets whether this page view is in Run mode, when the controls behave
    * as if the user is interacting with them.
    */
   public void setInRunMode(final boolean flag) {
      inRunMode = flag;
      for (Iterator i = getRegionViews().iterator(); i.hasNext(); ) {
         final PageRegionView regionView = (PageRegionView)i.next();
         regionView.setInRunMode(flag);
      }
      repaint();
   }

   /**
    * Adds region resizing borders that stick to the specified camera.
    */
   public void addRegionResizingBorders(final PCamera camera) {
      final PageRegionView centerRegion = getRegionView(Direction.CENTER);
      final PageRegionView northRegion = getRegionView(Direction.NORTH);
      final PageRegionView southRegion = getRegionView(Direction.SOUTH);
      final PageRegionView eastRegion = getRegionView(Direction.EAST);
      final PageRegionView westRegion = getRegionView(Direction.WEST);

      // Size grip for north region
      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createSouthLocator(northRegion),
         camera);

      // Size grip for south region
      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createNorthLocator(southRegion),
         camera);

      // Size grips for west region
      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createEastLocator(westRegion),
         camera);
      
      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createNorthLocator(westRegion),
         camera);
      
      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createSouthLocator(westRegion),
            camera);

      // Size grips for east region
      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createWestLocator(eastRegion),
         camera);

      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createNorthLocator(eastRegion),
         camera);

      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createSouthLocator(eastRegion),
         camera);
      
      // Size grips for center region
      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createNorthLocator(centerRegion), camera);

      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createSouthLocator(centerRegion), camera);
      
      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createWestLocator(centerRegion), camera);

      PageRegionViewSizingBorder.addPageRegionViewSizingBorderTo(
         PBoundsLocator.createEastLocator(centerRegion), camera);
   }


   /**
    * Removes sizing borders from the given node.
    */
   public void removeRegionResizingBorders() {
      final List handles = new ArrayList();

      for (Iterator i = getRegionViews().iterator(); i.hasNext(); ) {
         handles.clear();
         final PageRegionView regionView = (PageRegionView)i.next();
         for (Iterator j = regionView.getChildrenIterator(); j.hasNext(); ) {
            final PNode child = (PNode)j.next();
            if (child instanceof PageRegionViewSizingBorder) {
               handles.add(child);
            }
         }
         regionView.removeChildren(handles);      
      }
   }


   // Overrides method in parent class.
   protected void paint(final PPaintContext paintContext) {
      super.paint(paintContext);
      
      // Draw fold lines if not in Run mode.
      if (!isInRunMode()) {
         final Graphics2D g2 = paintContext.getGraphics();
         final DeviceType deviceType =
            ((Page)getPageView().getModel()).getDeviceType();
         final int width = deviceType.getDefaultWidth();
         final int height = deviceType.getDefaultHeight();
         
         final Paint oldPaint = g2.getPaint();
         final Stroke oldStroke = g2.getStroke();
         g2.setPaint(FOLD_COLOR);
         g2.setStroke(FOLD_STROKE);
         final GeneralPath fold = new GeneralPath();
         fold.moveTo(width, 0);
         fold.lineTo(width, height);
         fold.lineTo(0, height);
         g2.draw(fold);
         g2.setPaint(oldPaint);
         g2.setStroke(oldStroke);
      }
   }


   // Overrides method in parent class.
   protected void layoutChildren() {
      final Set regionNames = getRegionNames();
      boolean insetChanged = false;

      final Rectangle2D newBounds = getBounds();
      final boolean emptyBounds = newBounds.isEmpty();
      final boolean boundsChanged = !newBounds.equals(oldBounds);
      
      final int newNorthInset;
      if (regionNames.contains(Direction.NORTH)) {
         final PageRegionView northRegion = getRegionView(Direction.NORTH);
         newNorthInset = northRegion.getInset();
         if ((northInset != newNorthInset ||
              boundsChanged ||
              northRegion.getPathReference().getBounds2D().isEmpty()) && !emptyBounds) {
            northRegion.setPathTo(
               new Rectangle2D.Double(0, 0, getWidth(), newNorthInset));
         }
      }
      else {
         newNorthInset = 0;
      }
      insetChanged |= (northInset != newNorthInset);

      final int newSouthInset;
      if (regionNames.contains(Direction.SOUTH)) {
         final PageRegionView southRegion = getRegionView(Direction.SOUTH);
         newSouthInset = southRegion.getInset();
         if ((southInset != newSouthInset ||
               boundsChanged ||
             southRegion.getPathReference().getBounds2D().isEmpty()) && !emptyBounds) {
            southRegion.setPathTo(
               new Rectangle2D.Double(0, 0, getWidth(), newSouthInset));
            southRegion.setOffset(0, getHeight() - newSouthInset);
         }
      }
      else {
         newSouthInset = 0;
      }
      insetChanged |= (southInset != newSouthInset);

      final int newEastInset;
      if (regionNames.contains(Direction.EAST)) {
         final PageRegionView eastRegion = getRegionView(Direction.EAST);
         newEastInset = eastRegion.getInset();
         if ((eastInset != newEastInset ||
               boundsChanged ||
             eastRegion.getPathReference().getBounds2D().isEmpty()) && !emptyBounds) {
            eastRegion.setPathTo(
               new Rectangle2D.Double(
                  0,
                  0,
                  newEastInset,
                  getHeight() - newNorthInset - newSouthInset));
            eastRegion.setOffset(getWidth() - newEastInset, newNorthInset);
         }
      }
      else {
         newEastInset = 0;
      }
      insetChanged |= (eastInset != newEastInset);

      final int newWestInset;
      if (regionNames.contains(Direction.WEST)) {
         final PageRegionView westRegion = getRegionView(Direction.WEST);
         newWestInset = westRegion.getInset();
         if ((westInset != newWestInset ||
               boundsChanged ||
             westRegion.getPathReference().getBounds2D().isEmpty()) && !emptyBounds) {
            westRegion.setPathTo(
               new Rectangle2D.Double(
                  0,
                  0,
                  newWestInset,
                  getHeight() - newNorthInset - newSouthInset));
            westRegion.setOffset(0, newNorthInset);
         }
      }
      else {
         newWestInset = 0;
      }
      insetChanged |= (westInset != newWestInset);

      // Layout CENTER region, which always exists
      final PageRegionView centerRegion = getRegionView(Direction.CENTER);
      if ((insetChanged || boundsChanged ||
           centerRegion.getPathReference().getBounds().isEmpty())
          && !emptyBounds) {
         centerRegion.setPathTo(
            new Rectangle2D.Double(
               0,
               0,
               getWidth() - newWestInset - newEastInset,
               getHeight() - newNorthInset - newSouthInset));
         centerRegion.setOffset(newWestInset, newNorthInset);
         
         northInset = newNorthInset;
         southInset = newSouthInset;
         westInset = newWestInset;
         eastInset = newEastInset;
      }
   }
}
