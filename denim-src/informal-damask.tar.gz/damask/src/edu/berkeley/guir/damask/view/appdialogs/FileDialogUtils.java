package edu.berkeley.guir.damask.view.appdialogs;

import java.awt.*;
import java.io.File;
import java.io.FilenameFilter;
import java.util.*;

import javax.imageio.*;
import javax.imageio.spi.ImageReaderSpi;
import javax.imageio.spi.ImageWriterSpi;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;

import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.lib.io.FileLib;

/** 
 * A collection of dialogs related to file handling.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-21-2003 James Lin
 *                               Created FileDialogUtils.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-21-2003
 */
public class FileDialogUtils {
   private static final JFileChooser fileChooser = new JFileChooser();
   private static FileDialog fileDialog;
   private static final FileFilterCreator[] damaskFilterCreators =
      { new FileFilterCreator("Damask Documents", "dmk")};
   private static final FileFilterCreator[] voiceXMLFilterCreators =
      { new FileFilterCreator("VoiceXML", "vxml")};
   private static final FileFilterCreator[] imageOpenFilterCreators;
   private static final FileFilterCreator[] imageSaveFilterCreators;

   static {
      // Initialize file filters for images
      final Map/*<String, String>*/ descriptions =
         new HashMap/*<String, String>*/();
      descriptions.put("image/gif", "GIF Files");
      descriptions.put("image/jpeg", "JPEG Files");
      descriptions.put("image/png", "PNG Files");
      descriptions.put("image/x-png", "PNG Files");
      descriptions.put("image/bmp", "Microsoft Windows Bitmap Files");
      descriptions.put("image/vnd.wap.wbmp", "Wireless Bitmap Files");

      // Setup the file extensions for opening images
      {
         // Maps a graphic type to file extensions
         final Map/*<String, Set<String>>*/ imageExts =
            new TreeMap/*<String, TreeSet<String>>*/();
         final Set/*<String>*/ handledExts = new HashSet/*<String>*/();

         final String types[] = ImageIO.getReaderMIMETypes();
         for (int i = 0, n = types.length; i < n; i++) {
            final String type = types[i];
            String description = (String)descriptions.get(type);
            if (description == null) {
               description = type;
            }
            Set/*<String>*/ exts = (Set)imageExts.get(description);
            if (exts == null) {
               exts = new TreeSet/*<String>*/();
               imageExts.put(description, exts);
            }
            
            for (Iterator readers = ImageIO.getImageReadersByMIMEType(type);
               readers.hasNext();
               ) {
               final ImageReader reader = (ImageReader)readers.next();
               final ImageReaderSpi readerSpi = reader.getOriginatingProvider();
               final String spiExts[] = readerSpi.getFileSuffixes();
               
               for (int j = 0, m = spiExts.length; j < m; j++) {
                  final String ext = spiExts[j].toLowerCase();
                  if (!handledExts.contains(ext)) {
                     handledExts.add(ext);
                     exts.add(ext);
                  }
               }
            }
         }

         imageOpenFilterCreators = new FileFilterCreator[imageExts.size() + 1];
         // The first entry is for the "All Images" filter
         
         final Set/*<String>*/ allImageExts = new TreeSet/*<String>*/();
         int index = 0;
         for (Iterator i = imageExts.keySet().iterator(); i.hasNext(); ) {
            final String description = (String)i.next();
            final Set/*<String>*/ exts = (Set)imageExts.get(description);
            if (!exts.isEmpty()) {
               allImageExts.addAll(exts);
               imageOpenFilterCreators[index + 1] =
                  new FileFilterCreator(description, exts);
            }
            index++;
         }
         
         imageOpenFilterCreators[0] =
            new FileFilterCreator("Image Files", allImageExts);
      }
      
      // Setup the file extensions for saving images
      {
         // Maps a graphic type to file extensions
         final Map/*<String, Set<String>>*/ imageExts =
            new TreeMap/*<String, TreeSet<String>>*/();
         final Set/*<String>*/ handledExts = new HashSet/*<String>*/();

         final String types[] = ImageIO.getWriterMIMETypes();
         for (int i = 0, n = types.length; i < n; i++) {
            final String type = types[i];
            String description = (String)descriptions.get(type);
            if (description == null) {
               description = type;
            }
            Set/*<String>*/ exts = (Set)imageExts.get(description);
            if (exts == null) {
               exts = new TreeSet/*<String>*/();
               imageExts.put(description, exts);
            }
            
            for (Iterator writers = ImageIO.getImageWritersByMIMEType(type);
               writers.hasNext();
               ) {
               final ImageWriter writer = (ImageWriter)writers.next();
               final ImageWriterSpi writerSpi = writer.getOriginatingProvider();
               final String spiExts[] = writerSpi.getFileSuffixes();
               
               for (int j = 0, m = spiExts.length; j < m; j++) {
                  final String ext = spiExts[j].toLowerCase();
                  if (!handledExts.contains(ext)) {
                     handledExts.add(ext);
                     exts.add(ext);
                  }
               }
            }
         }

         imageSaveFilterCreators = new FileFilterCreator[imageExts.size()];
         
         int index = 0;
         for (Iterator i = imageExts.keySet().iterator(); i.hasNext(); ) {
            final String description = (String)i.next();
            final Set/*<String>*/ exts = (Set)imageExts.get(description);
            if (!exts.isEmpty()) {
               imageSaveFilterCreators[index] =
                  new FileFilterCreator(description, exts);
            }
            index++;
         }
      }
   }

   /**
    * Prevents instantiation. 
    */
   private FileDialogUtils() {
   }


   /**
    * Returns the selected file from the specified file chooser, with the
    * appropriate file extension added.
    */
   private static File getSelectedFileWithFilterExtension(
      final JFileChooser fileChooser) {

      final File tempFile = fileChooser.getSelectedFile();
      final FileFilter chosenFileFilter = fileChooser.getFileFilter();
         
      if (chosenFileFilter instanceof StandardFileFilter) {
         final StandardFileFilter chosenStandardFileFilter =
            (StandardFileFilter)chosenFileFilter;
         final String[] exts = chosenStandardFileFilter.getExtensions();
         if (exts.length == 1) {
            return new File(
               FileLib.addFileNameExtension(tempFile, exts[0]));
         }
         else {
            return tempFile;
         }
      }
      else {
         return tempFile;
      }
   }


   /**
    * Prompts the user if he or she wants to open a Damask document.
    * 
    * @return the file to open, or null if the user does not want to open
    */
   public static File showDamaskOpenDialog(final Component parentComponent) {
      return showOpenDialog(parentComponent, damaskFilterCreators);
   }


   /**
    * Prompts the user if he or she wants to open an image.
    * 
    * @return the file to open, or null if the user does not want to open
    */
   public static File showImageOpenDialog(final Component parentComponent) {
      return showOpenDialog(parentComponent, imageOpenFilterCreators);
   }


   /**
    * Prompts the user if he or she wants to open a Damask document.
    * 
    * @return the file to open, or null if the user does not want to open
    */
   public static File showOpenDialog(
      final Component parentComponent,
      final FileFilterCreator[] fileFilterCreators) {
      
      // Use AWT's FileDialog on Mac OS X, since JFileChooser doesn't do a good
      // job rendering file dialogs on that platform
      if (DamaskAppUtils.isMac()) {
         final Frame frame;
         if (parentComponent instanceof Frame) {
            frame = (Frame)parentComponent;
         }
         else {
            frame = (Frame)SwingUtilities.windowForComponent(parentComponent);
         }
         
         fileDialog = new FileDialog(frame, "Open", FileDialog.LOAD);
         if (fileFilterCreators.length > 0) {
            fileDialog.setFilenameFilter(
               fileFilterCreators[0].getFilenameFilter());
         }
         fileDialog.setVisible(true);
         
         if (fileDialog.getFile() == null) {
            return null;
         }
         else {
            String newFileNameStr =
               fileDialog.getDirectory()
                  + File.separator
                  + fileDialog.getFile();
            
            final String[] fileExts = fileFilterCreators[0].getExtensions();
            if (fileExts.length == 1) {
               newFileNameStr =
                  FileLib.addFileNameExtension(newFileNameStr, fileExts[0]);
               }
            return new File(newFileNameStr);
         }
      }
      else {
         fileChooser.setSelectedFile(null);
         fileChooser.setAcceptAllFileFilterUsed(true);
         fileChooser.resetChoosableFileFilters();
         for (int i = 0, n = fileFilterCreators.length; i < n; i++) {
            fileChooser.addChoosableFileFilter(
               fileFilterCreators[i].getFileFilter());
         }
         if (fileFilterCreators.length > 0) {
            fileChooser.setFileFilter(fileFilterCreators[0].getFileFilter());
         }
         
         while (true) {
            final int result = fileChooser.showOpenDialog(parentComponent);
         
            if (result == JFileChooser.APPROVE_OPTION) {
               final File selectedFile =
                  getSelectedFileWithFilterExtension(fileChooser);
               if (selectedFile.exists()) {
                  return selectedFile;
               }
               JOptionPane.showMessageDialog(
                  parentComponent,
                  selectedFile
                     + " does not exist.\n\n"
                     + "Please verify the correct file name was given.",
                  "Damask",
                  JOptionPane.WARNING_MESSAGE);
            }
            else {
               return null;
            }
         }
      }
   }


   /**
    * Prompts the user if he or she wants to save a Damask document.
    * 
    * @return the file to save to, or null if the user does not want to save
    */
   public static File showDamaskSaveDialog(final Component parentComponent) {
      return showSaveDialog(parentComponent, damaskFilterCreators);
   }


   /**
    * Prompts the user if he or she wants to export as VoiceXML.
    * 
    * @return the file to save to, or null if the user does not want to save
    */
   public static File showExportVoiceXMLDialog(final Component parentComponent) {
      return showSaveDialog(parentComponent, voiceXMLFilterCreators);
   }


   /**
    * Prompts the user if he or she wants to save an image.
    * 
    * @return the file to open, or null if the user does not want to save
    */
   public static File showImageSaveDialog(final Component parentComponent) {
      return showSaveDialog(parentComponent, imageSaveFilterCreators);
   }

   
   /**
    * Prompts the user if he or she wants to save the document.
    * 
    * @return the file to save to, or null if the user does not want to save
    */
   public static File showSaveDialog(
      final Component parentComponent,
      final FileFilterCreator[] fileFilterCreators) {
      
      // Use AWT's FileDialog on Mac OS X, since JFileChooser doesn't do a good
      // job rendering file dialogs on that platform
      if (DamaskAppUtils.isMac()) {
         final Frame frame;
         if (parentComponent instanceof Frame) {
            frame = (Frame)parentComponent;
         }
         else {
            frame = (Frame)SwingUtilities.windowForComponent(parentComponent);
         }
         
         fileDialog = new FileDialog(frame, "Save", FileDialog.SAVE);
         if (fileFilterCreators.length > 0) {
            fileDialog.setFilenameFilter(
               fileFilterCreators[0].getFilenameFilter());
         }
         fileDialog.setVisible(true);
         
         // We don't have to ask about overwriting files, since the Mac
         // Save dialog box doesn't allow it.
         
         if (fileDialog.getFile() == null) {
            return null;
         }
         else {
            String newFileNameStr =
               fileDialog.getDirectory()
                  + File.separator
                  + fileDialog.getFile();
            
            final String[] fileExts = fileFilterCreators[0].getExtensions();
            if (fileExts.length == 1) {
               newFileNameStr =
                  FileLib.addFileNameExtension(newFileNameStr, fileExts[0]);
            }
            return new File(newFileNameStr);
         }
      }
      else {
         fileChooser.setSelectedFile(null);
         fileChooser.setAcceptAllFileFilterUsed(false);
         fileChooser.resetChoosableFileFilters();
         for (int i = 0, n = fileFilterCreators.length; i < n; i++) {
            fileChooser.addChoosableFileFilter(
               fileFilterCreators[i].getFileFilter());
         }
         if (fileFilterCreators.length > 0) {
            fileChooser.setFileFilter(fileFilterCreators[0].getFileFilter());
         }
         while (true) {
            final int result = fileChooser.showSaveDialog(parentComponent);
            
            if (result == JFileChooser.APPROVE_OPTION) {
               // If the selected file exists, ask if the user wants to
               // overwrite the file. If he or she does not, then bring up
               // the Save dialog again.
               final File file =
                  getSelectedFileWithFilterExtension(fileChooser);
            
               if (file.exists()) {
                  int overwriteResult =
                     promptToOverwrite(parentComponent, file);
                  if (overwriteResult == JOptionPane.YES_OPTION) {
                     return file;
                  }
               }
               else {
                  return file;
               }
            }
            else {
               return null;
            }
         }
      }
   }
   
   
   /**
    * Prompts the user if he or she wants to save the document.
    */
   public static int promptToSave(
      final Component parentComponent,
      final String fileName) {

      return JOptionPane.showConfirmDialog(
         parentComponent,
         "Do you want to save the changes to " + fileName + "?",
         "Damask",
         JOptionPane.YES_NO_CANCEL_OPTION,
         JOptionPane.WARNING_MESSAGE);
   }

   /**
    * Prompts the user if he or she wants to overwrite an existing file.
    */
   private static int promptToOverwrite(
      final Component parentComponent,
      final File file) {
         
      // You can't set mnemonics on custom options! Aaaarrrrgh!
      final String[] options = new String[2];
      if (DamaskAppUtils.isMac()) {
         options[0] = "Cancel";
         options[1] = "Replace";
      }
      else {
         options[0] = "Yes";
         options[1] = "No";
      }
      
      return JOptionPane.showOptionDialog(
         parentComponent,
         file.getName() + " already exists.\nDo you want to replace it?",
         "Damask",
         JOptionPane.YES_NO_OPTION,
         JOptionPane.WARNING_MESSAGE,
         null,
         options, options[1]);
   }


   /**
    * A class that takes a description and a set of file extensions, and
    * creates a {@see javax.swing.filechooser.FileFilter} and a
    * {@see java.io.FilenameFilter} that filters for the specified
    * extensions and has the specified description.
    */
   public static class FileFilterCreator {
      private final String description;
      private final String[] extensions;
      private final FileFilter fileFilter;
      private final FilenameFilter filenameFilter;

      /**
       * Constructs an instance of this class, which creates a
       * {@see javax.swing.filechooser.FileFilter} and a
       * {@see java.io.FilenameFilter} that filters for the specified
       * extension and has the specified description.
       */
      public FileFilterCreator(String description, String extension) {
         this(description, new String[] {extension});
      }
      
      /**
       * Constructs an instance of this class, which creates a
       * {@see javax.swing.filechooser.FileFilter} and a
       * {@see java.io.FilenameFilter} that filters for the specified
       * extensions and has the specified description.
       */
      public FileFilterCreator(
         String description, Collection/*<String>*/ extensions) {
         this(
            description,
            (String[])extensions.toArray(new String[extensions.size()]));
      }
      

      /**
       * Constructs an instance of this class, which creates a
       * {@see javax.swing.filechooser.FileFilter} and a
       * {@see java.io.FilenameFilter} that filters for the specified
       * extensions and has the specified description.
       */
      public FileFilterCreator(String description, String[] extensions) {
         this.description = description;
         this.extensions = new String[extensions.length];
         System.arraycopy(extensions, 0, this.extensions, 0, extensions.length);
         
         fileFilter = new StandardFileFilter(description, extensions);
         filenameFilter = new StandardFilenameFilter(extensions);
      }
      
      /**
       * Returns the description of the filter.
       */
      public String getDescription() {
         return description;
      }
      
      /**
       * Returns the extensions that the filter accepts.
       */
      public String[] getExtensions() {
         String[] result = new String[extensions.length];
         System.arraycopy(extensions, 0, result, 0, extensions.length);
         return result;
      }
      
      /**
       * Returns a filter for use with a {@see javax.swing.JFileChooser}.
       */
      public FileFilter getFileFilter() {
         return fileFilter;
      }
      
      /**
       * Returns a filter for use with a {@see java.awt.FileDialog}.
       */
      public FilenameFilter getFilenameFilter() {
         return filenameFilter;
      }
      
      public String toString() {
         return super.toString()
            + "("
            + getDescription()
            + " "
            + Arrays.asList(getExtensions()).toString()
            + ")";
      }
   }


   private static class StandardFileFilter extends FileFilter {
      private final String description;
      private final String[] extensions;
      private final String fullDescription;
      
      public StandardFileFilter(final String description, final String[] extensions) {
         this.description = description;
         this.extensions = new String[extensions.length];
         System.arraycopy(extensions, 0, this.extensions, 0, extensions.length);
         
         final StringBuffer fullDescBuffer = new StringBuffer(description);
         fullDescBuffer.append(" (");
         for (int i = 0, n = extensions.length; i < n; i++) {
            fullDescBuffer.append("*.");
            fullDescBuffer.append(extensions[i]);
            if (i != n - 1) {
               fullDescBuffer.append(", ");
            }
         }
         fullDescBuffer.append(")");
         fullDescription = fullDescBuffer.toString();
      }
      
      public boolean accept(File f) {
         if (f.isDirectory()) {
            return true;
         }

         for (int i = 0, n = extensions.length; i < n; i++) {
            if (FileLib
               .getFileNameExtension(f.getAbsolutePath())
               .equalsIgnoreCase(extensions[i])) {
               return true;
            }
         }
         return false;
      }

      public String getDescription() {
         return fullDescription;
      }
      
      /**
       * Returns the extensions that the filter accepts.
       */
      public String[] getExtensions() {
         String[] result = new String[extensions.length];
         System.arraycopy(extensions, 0, result, 0, extensions.length);
         return result;
      }
   }


   private static class StandardFilenameFilter implements FilenameFilter {
      private final String[] extensions;
      
      public StandardFilenameFilter(String[] extensions) {
         this.extensions = new String[extensions.length];
         System.arraycopy(extensions, 0, this.extensions, 0, extensions.length);
      }
      
      public boolean accept(File dir, String name) {
         final String nameLowerCase = name.toLowerCase();
         for (int i = 0, n = extensions.length; i < n; i++) {
            final String extensionLowerCase = extensions[i].toLowerCase();
            if (nameLowerCase.endsWith("." + extensionLowerCase)) {
               return true;
            }
         }
         return false;
      }
   }
}
