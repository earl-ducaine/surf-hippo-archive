package edu.berkeley.guir.damask.io;

import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.*;

import javax.imageio.ImageIO;
import javax.xml.bind.*;
import javax.xml.transform.Source;

import org.apache.commons.codec.binary.Base64;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import edu.berkeley.guir.damask.io.generated.*;
import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;

/**
 * Opens a Damask design from a disk, stream, URL, or DOM tree.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  03-12-2004 James Lin
 *                               Created DamaskMarshaller.
 *                    03-13-2004 Renamed to DamaskReader.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 03-12-2004
 */
public class DamaskReader {

   private static Map/*<Object, edu.berkeley.guir.damask.InteractionElement>*/
      realElements =
      new HashMap/*<Object, edu.berkeley.guir.damask.InteractionElement>*/();
   
   private static Map/*<edu.berkeley.guir.damask.InteractionElement,
                        Map<Integer, Line2D>>*/
      origResponseLines =
         new HashMap/*<edu.berkeley.guir.damask.InteractionElement,
                       Map<Integer, Line2D>>*/();

   private static JAXBContext jc = null;
   private static Unmarshaller unmarshaller = null;
   
   static {
      try {
         jc = JAXBContext.newInstance("edu.berkeley.guir.damask.io.generated");
         unmarshaller = jc.createUnmarshaller();
      }
      catch (JAXBException e) {
         DamaskAppExceptionHandler.log(e);
      }
   }
   
   /**
    * Prevents instantiation.
    */
   private DamaskReader() {
   }


   private static Unmarshaller getUnmarshaller() throws JAXBException {
      return unmarshaller;
   }


   /**
    * Reads the specified file and returns the resulting interaction graph.
    */
   public static edu.berkeley.guir.damask.InteractionGraph open(final File f)
      throws JAXBException {

      final Damask d = (Damask)getUnmarshaller().unmarshal(f);
      return createRealInteractionGraph(d);
   }

   /**
    * Reads the specified file and returns the resulting interaction graph.
    */
   public static edu.berkeley.guir.damask.InteractionGraph open(
      final InputSource source)
      throws JAXBException {

      final Damask d = (Damask)getUnmarshaller().unmarshal(source);
      return createRealInteractionGraph(d);
   }

   /**
    * Reads the specified file and returns the resulting interaction graph.
    */
   public static edu.berkeley.guir.damask.InteractionGraph open(
      final InputStream is)
      throws JAXBException {

      final Damask d = (Damask)getUnmarshaller().unmarshal(is);
      return createRealInteractionGraph(d);
   }

   /**
    * Reads the specified file and returns the resulting interaction graph.
    */
   public static edu.berkeley.guir.damask.InteractionGraph open(
      final Node node)
      throws JAXBException {

      final Damask d = (Damask)getUnmarshaller().unmarshal(node);
      return createRealInteractionGraph(d);
   }

   /**
    * Reads the specified file and returns the resulting interaction graph.
    */
   public static edu.berkeley.guir.damask.InteractionGraph open(
      final Source source)
      throws JAXBException {

      final Damask d = (Damask)getUnmarshaller().unmarshal(source);
      return createRealInteractionGraph(d);
   }

   /**
    * Reads the specified file and returns the resulting interaction graph.
    */
   public static edu.berkeley.guir.damask.InteractionGraph open(final URL url)
      throws JAXBException {

      final Damask d = (Damask)getUnmarshaller().unmarshal(url);
      return createRealInteractionGraph(d);
   }

   /**
    * Reads the specified file and returns the resulting interaction graph.
    */
   public static edu.berkeley.guir.damask.pattern.PatternSolution open(
      final URL url,
      final edu.berkeley.guir.damask.pattern.Pattern realPatternForSolution)
      throws JAXBException {

      final Damask d = (Damask)getUnmarshaller().unmarshal(url);
      return (edu.berkeley.guir.damask.pattern.PatternSolution)
         createRealInteractionGraph(d, realPatternForSolution);
   }


   /**
    * Takes the specified content tree, which the result of unmarshalling XML
    * data, and creates a corresponding interaction graph.
    */
   private static edu.berkeley.guir.damask.InteractionGraph
      createRealInteractionGraph(final Damask damask) {
         
      return createRealInteractionGraph(damask, null);
   }


   /**
    * Takes the specified content tree, which the result of unmarshalling XML
    * data, and creates a corresponding interaction graph.
    */
   private static edu.berkeley.guir.damask.InteractionGraph
      createRealInteractionGraph(
         final Damask damask,
         final edu.berkeley.guir.damask.pattern.Pattern realPatternForSolution) {

      realElements.clear();

      final edu.berkeley.guir.damask.InteractionGraph realGraph;
      if (realPatternForSolution == null) {
         realGraph = new edu.berkeley.guir.damask.InteractionGraph();
      }
      else {
         realGraph = realPatternForSolution.getSolution();
      }

      final Design design = damask.getDesign();

      // Remove the first template. It will be replaced with the templates
      // from the content tree.
      realGraph.removeTemplate(realGraph.getDefaultTemplate());

      // Add templates to the graph
      for (Iterator i = design.getTemplates().getTemplate().iterator();
         i.hasNext();
         ) {
         final Dialog template = (Dialog)i.next();
         realGraph.addTemplate(getRealTemplateDialog(template));
      }

      // Add dialogs to the graph
      for (Iterator i = design.getDialogs().getDialog().iterator();
         i.hasNext();
         ) {
         final Dialog dialog = (Dialog)i.next();
         realGraph.add(getRealDialog(dialog), false);
      }

      // Set the home pages
      for (Iterator i = design.getHomePages().getHomePage().iterator();
         i.hasNext();
         ) {
         final HomePage homePage = (HomePage)i.next();
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            getRealDeviceType(homePage.getDeviceType());

         edu.berkeley.guir.damask.dialog.Page realPage =
            (edu.berkeley.guir.damask.dialog.Page)realElements.get(
               homePage.getPage());

         // realPage might be null because, in getRealDialog(), we ignored
         // voice pages without content
         if (realPage == null) {
            for (Iterator j = realGraph.getDialogs().iterator(); j.hasNext(); ){
               final edu.berkeley.guir.damask.dialog.Dialog realDialog =
                  (edu.berkeley.guir.damask.dialog.Dialog)j.next();
               if (realDialog.isVisibleToDeviceType(realDeviceType)) {
                  realPage = realDialog.getFirstPage(realDeviceType);
               }
            }
         }
         
         realGraph.setHomePage(realDeviceType, realPage);
      }

      // Add connections to the graph
      for (Iterator i = design.getConnections().getConnection().iterator();
         i.hasNext();
         ) {
         final Connection connection = (Connection)i.next();
         final edu.berkeley.guir.damask.connection.Connection realConnection =
            getRealConnection(connection);
         realGraph.add(realConnection);
         
         // Refresh connections so that they originate and end at the right places.
         for (Iterator j = realConnection.getDeviceTypesVisibleTo().iterator(); 
              j.hasNext(); ) {
            final edu.berkeley.guir.damask.DeviceType aRealDeviceType =
               (edu.berkeley.guir.damask.DeviceType)j.next();
            realConnection.refresh(aRealDeviceType);
         }
      }

      // Add pattern instances to the graph
      for (Iterator i =
         design.getPatternInstances().getPatternInstance().iterator();
         i.hasNext();
         ) {
         final PatternInstance patternInstance = (PatternInstance)i.next();

         final edu.berkeley.guir.damask.pattern.Pattern realPattern =
            edu.berkeley.guir.damask.pattern.PatternLibrary.getPattern(
               patternInstance.getCollectionID(),
               patternInstance.getPatternID());

         // Create a pattern instance.
         final edu.berkeley.guir.damask.pattern.PatternInstance
         realPatternInstance =
            new edu.berkeley.guir.damask.pattern.PatternInstance(realPattern);

         // Add the members that are listed in the content tree.
         for (Iterator j = patternInstance.getElementRef().iterator();
            j.hasNext();
            ) {
            final ElementRef ref = (ElementRef)j.next();
            //HACK realElements.get(ref.getRef()) might be null because
            // above we ignored voice pages without content
            if (realElements.get(ref.getRef()) != null) {
               realPatternInstance.add(
                  (edu.berkeley.guir.damask.pattern.PatternInstanceMember)
                  realElements.get(ref.getRef()));
            }
         }
         realGraph.add(realPatternInstance);
      }

      realElements.clear();

      return realGraph;
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and creates a corresponding dialog.
    */
   private static edu.berkeley.guir.damask.dialog.TemplateDialog
      getRealTemplateDialog(final Dialog dialog) {
      
      return (edu.berkeley.guir.damask.dialog.TemplateDialog)
         getRealDialog(dialog, true);
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and creates a corresponding dialog.
    */
   private static edu.berkeley.guir.damask.dialog.Dialog
      getRealDialog(final Dialog dialog) {
   
      return getRealDialog(dialog, false);
   }

   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and creates a corresponding dialog.
    */
   private static edu.berkeley.guir.damask.dialog.Dialog
      getRealDialog(final Dialog dialog, final boolean isTemplate) {

      // If we've created the corresponding real dialog before, then return it.
      edu.berkeley.guir.damask.dialog.Dialog realDialog =
         (edu.berkeley.guir.damask.dialog.Dialog)realElements.get(dialog);
      if (realDialog != null) {
         return realDialog;
      }

      // Count the number of pages per device types in this dialog, and get the
      // initial title of the dialog (which is simply the title of the first
      // page).
      Content pageTitle = null;
      final edu.berkeley.guir.damask.DeviceType realDeviceTypeForDialog;
      final Map/*<edu.berkeley.guir.damask.DeviceType, List<Page>>*/
         pagesPerDeviceType = new HashMap();

      for (Iterator i =
         edu.berkeley.guir.damask.Damask.getSupportedDeviceTypes().iterator();
         i.hasNext(); ) {

         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         pagesPerDeviceType.put(realDeviceType, new ArrayList());
      }

      {
         int index = 0;
         for (Iterator i = dialog.getPages().getPage().iterator();
            i.hasNext();
            ) {
            final Page page = (Page)i.next();
            if (index == 0) {
               pageTitle = page.getTitle().getContent();
            }

            final edu.berkeley.guir.damask.DeviceType realDeviceType =
               getRealDeviceType(page.getDeviceType());

            // HACK ignore voice pages without any content
            if (realDeviceType == edu.berkeley.guir.damask.DeviceType.VOICE) {
               boolean hasContent = false; 
               for (Iterator j = page.getRegions().getRegion().iterator();
                    j.hasNext(); ) {
                  final Region region = (Region)j.next();
                  hasContent |= !region.getControlRef().isEmpty();
               }
               if (hasContent) {
                  ((List)pagesPerDeviceType.get(realDeviceType)).add(page);
               }
            }
            else {
               ((List)pagesPerDeviceType.get(realDeviceType)).add(page);
            }

            index++;
         }

         assert pageTitle != null: "The title of the dialog should not be null";

         // Figure out if this dialog supports only one device type or
         // all device types.
         {
            final Set/*<edu.berkeley.guir.damask.DeviceType>*/
               supportedRealDeviceTypes = new HashSet();

            for (Iterator i = pagesPerDeviceType.keySet().iterator();
               i.hasNext();
               ) {

               final edu.berkeley.guir.damask.DeviceType realDeviceType =
                  (edu.berkeley.guir.damask.DeviceType)i.next();

               final int count =
                  ((List)pagesPerDeviceType.get(realDeviceType)).size();

               if (count != 0) {
                  supportedRealDeviceTypes.add(realDeviceType);
               }
            }

            if (supportedRealDeviceTypes.size() == 1) {
               realDeviceTypeForDialog =
                  (edu.berkeley.guir.damask.DeviceType)supportedRealDeviceTypes
                     .iterator()
                     .next();
            }
            else {
               realDeviceTypeForDialog = edu.berkeley.guir.damask.DeviceType.ALL;
            }
         }
      }

      // Create the real dialog
      if (isTemplate) {
         realDialog =
            new edu.berkeley.guir.damask.dialog.TemplateDialog(
               realDeviceTypeForDialog,
               getRealContent(pageTitle));
      }
      else {
         realDialog =
            new edu.berkeley.guir.damask.dialog.Dialog(
               realDeviceTypeForDialog,
               getRealContent(pageTitle));
      }
      //System.out.println(dialog.getId() + "->" + realDialog.getId());
      realElements.put(dialog, realDialog);

      // Create the real pages within the real dialog (by splitting the pages
      // that already exist within the dialog).
      for (Iterator i = pagesPerDeviceType.keySet().iterator(); i.hasNext();) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         final List pages = (List)pagesPerDeviceType.get(realDeviceType);

         for (Iterator j = pages.iterator(); j.hasNext(); ) {
            final Page page = (Page)j.next();
            final edu.berkeley.guir.damask.dialog.Page realPage =
               realDialog.getLastPage(realDeviceType);

            realElements.put(page, realPage);
            
            // Set the title of the page
            final edu.berkeley.guir.damask.component.Content
               realPageTitleContent =
                  getRealContent(page.getTitle().getContent());
            
            realPage.getTitle().setText(realPageTitleContent.getText());
            
            final BufferedImage realPageTitleContentImage = 
               realPageTitleContent.getImage();
            if (realPageTitleContentImage != null) {
               realPage.getTitle().setImage(realPageTitleContentImage);
            }
            realPage.getTitle().setStrokes(realPageTitleContent.getStrokes());

            // Split the real page if there are any pages left
            if (j.hasNext()) {
               realPage.split(Collections.EMPTY_LIST);
            }
         }
      }

      final Map/*<edu.berkeley.guir.damask.component.Control, AffineTransform>*/
      origVoiceTransforms =
      new HashMap/*<edu.berkeley.guir.damask.component.Control, AffineTransform>*/();
      
      // Set the bounds of the pages, and add the controls to the proper page
      // regions
      for (Iterator i = dialog.getPages().getPage().iterator(); i.hasNext();) {
         final Page page = (Page)i.next();
         final edu.berkeley.guir.damask.dialog.Page realPage =
            (edu.berkeley.guir.damask.dialog.Page)realElements.get(page);

         // realPage might be null because above we ignored voice pages
         // without content
         if (realPage == null) {
            continue;
         }
         
         realPage.setBounds(createRealBounds(page.getBounds()));
         realPage.setTransform(createRealTransform(page.getTransform()));

         for (Iterator j = page.getRegions().getRegion().iterator();
            j.hasNext();
            ) {
            final Region region = (Region)j.next();
            final edu.berkeley.guir.damask.dialog.PageRegion realRegion =
               realPage.getRegion(getRealDirection(region.getName()));
               
            realRegion.setInset(region.getInset().intValue());

            for (Iterator k = region.getControlRef().iterator(); k.hasNext();) {
               final ControlRef controlRef = (ControlRef)k.next();
               final Object control = controlRef.getRef();
               edu.berkeley.guir.damask.component.Control realControl =
                  (edu.berkeley.guir.damask.component.Control)
                  realElements.get(control);

               if (realControl == null) {
                  if (control instanceof Content) {
                     realControl = getRealContent((Content)control);
                  }
                  else if (control instanceof TextInput) {
                     realControl = getRealTextInput((TextInput)control);
                  }
                  else if (control instanceof Trigger) {
                     realControl = getRealTrigger((Trigger)control);
                  }
                  else if (control instanceof SelectOne) {
                     realControl = getRealSelectOne((SelectOne)control);
                  }
                  else if (control instanceof SelectMany) {
                     realControl = getRealSelectMany((SelectMany)control);
                  }
                  else {
                     assert false : "control should be a Control, not "
                        + (control == null ? null : control.getClass());
                  }
                  realElements.put(control, realControl);
                  // Store the voice response lines, since they might be reset
                  // after the control is added to a page region
                  origResponseLines.put(realControl,
                     realControl.getVoiceResponseLines());
                  
                  // Store the voice transform, because the call to 
                  // realDialog.changeControlPageRegion() might change it.
                  if (realControl.isVisibleToDeviceType(
                     edu.berkeley.guir.damask.DeviceType.VOICE)) {
                     origVoiceTransforms.put(realControl,
                        realControl.getTransform(
                           edu.berkeley.guir.damask.DeviceType.VOICE));
                  }
               }
               if (realControl.getDialog() != realDialog) {
                  // Add the control
                  realDialog.addControlAtEnd(realRegion, realControl);
               }
               
               realDialog.changeControlPageRegion(realControl, realRegion);
               
               // Restore the original voice response lines.
               final Map/*<Integer, Line2D>*/ origResponseLinesForControl =
                  (Map)origResponseLines.get(realControl);
               for (Iterator m =
                    origResponseLinesForControl.keySet().iterator();
                    m.hasNext(); ) {
                  final Integer condition = (Integer)m.next();
                  final Line2D line =
                     (Line2D)origResponseLinesForControl.get(condition);
                  realControl.setVoiceResponseLine(condition.intValue(), line);
               }
            }
         }
         
         // Remove the default template from the real page. The proper will
         // be applied from the content tree.
         for (Iterator j = new ArrayList(realPage.getTemplates()).iterator();
              j.hasNext(); ) {
            final edu.berkeley.guir.damask.dialog.Page templatePage =
               (edu.berkeley.guir.damask.dialog.Page)j.next();
            realPage.removeTemplate(templatePage);
         }
         
         // Apply the templates that are stored in the content tree.
         for (Iterator j = page.getTemplateRefs().getTemplateRef().iterator();
            j.hasNext();
            ) {

            final TemplateRef templateRef = (TemplateRef)j.next();
            final Object template = templateRef.getRef();
            edu.berkeley.guir.damask.dialog.Page realTemplatePage =
               (edu.berkeley.guir.damask.dialog.Page)
               realElements.get(template);
            // HACK realTemplatePage might be null because before we ignored
            // voice pages without content
            if (realTemplatePage != null) {
               realPage.addTemplate(realTemplatePage);
            }
         }         
      }

      // Set the states and significances of the controls
      final int numConditions = dialog.getConditionsCount().intValue();
      for (int i = 1; i < numConditions; i++) {
         realDialog.addCondition();
      }
      
      for (Iterator i = realElements.keySet().iterator(); i.hasNext(); ) {
         final Object element = i.next();
         final Object realElement = realElements.get(element);
         final edu.berkeley.guir.damask.component.Control realControl;
         if (realElement instanceof edu.berkeley.guir.damask.component.Control){
            realControl =
               (edu.berkeley.guir.damask.component.Control)realElement;
         }
         else {
            realControl = null;
         }

         if (element instanceof Content) {
            setStatesAndSignificances(
               realControl,
               ((Content)element).getStates(),
               ((Content)element).getSignificances());
         }
         else if (element instanceof TextInput) {
            setStatesAndSignificances(
               realControl,
               ((TextInput)element).getStates(),
               ((TextInput)element).getSignificances());
         }
         else if (element instanceof Trigger) {
            setStatesAndSignificances(
               realControl,
               ((Trigger)element).getStates(),
               ((Trigger)element).getSignificances());
         }
         else if (element instanceof SelectOne) {
            setStatesAndSignificances(
               realControl,
               ((SelectOne)element).getStates(),
               ((SelectOne)element).getSignificances());
         }
         else if (element instanceof SelectMany) {
            setStatesAndSignificances(
               realControl,
               ((SelectMany)element).getStates(),
               ((SelectMany)element).getSignificances());
         }
      }

      // Add real groups to the real dialog.
      for (Iterator i = dialog.getGroups().getGroup().iterator(); i.hasNext();){
         final Group group = (Group)i.next();

         final Map/*<edu.berkeley.guir.damask.dialog.PageRegion, Rectangle2D>*/
            groupBounds = new HashMap();

         final Map/*<edu.berkeley.guir.damask.dialog.PageRegion,
            AffineTransform>*/ groupTransform = new HashMap();

         final edu.berkeley.guir.damask.DeviceType realGroupDeviceType =
            getDeviceTypeAndBoundsAndTransformsForGroup(
               group.getBoundsAndTransformsForGroup(),
               groupBounds,
               groupTransform);

         final edu.berkeley.guir.damask.component.ComponentGroup realGroup =
            new edu.berkeley.guir.damask.component.ComponentGroup(
               realGroupDeviceType);

         for (Iterator j = groupBounds.keySet().iterator(); j.hasNext(); ) {
            final edu.berkeley.guir.damask.dialog.PageRegion realRegion =
               (edu.berkeley.guir.damask.dialog.PageRegion)j.next();
            realGroup.setBoundsInPageRegion(
               realRegion,
               (Rectangle2D)groupBounds.get(realRegion));
         }

         for (Iterator j = groupTransform.keySet().iterator(); j.hasNext(); ) {
            final edu.berkeley.guir.damask.dialog.PageRegion realRegion =
               (edu.berkeley.guir.damask.dialog.PageRegion)j.next();
            realGroup.setTransformInPageRegion(
               realRegion,
               (AffineTransform)groupTransform.get(realRegion));
         }
         
         realDialog.addGroup(realGroup);

         realElements.put(group, realGroup);
      }

      // Add components to the groups.
      for (Iterator i = dialog.getGroups().getGroup().iterator(); i.hasNext();){
         final Group group = (Group)i.next();
         final edu.berkeley.guir.damask.component.ComponentGroup realGroup =
            (edu.berkeley.guir.damask.component.ComponentGroup)realElements
               .get(group);

         for (Iterator j = group.getComponents().getComponentRef().iterator();
            j.hasNext();
            ) {
            final ComponentRef componentRef = (ComponentRef)j.next();
            realGroup.add(
               (edu.berkeley.guir.damask.component.Component)
                  realElements.get(componentRef.getRef()));
         }
      }

      // Save the new real dialog for later use.
      realElements.put(dialog, realDialog);

      // Read the bounds and transforms
      final Map/*<edu.berkeley.guir.damask.DeviceType, Rectangle2D>*/ bounds =
         new HashMap();
      final Map/*<edu.berkeley.guir.damask.DeviceType, AffineTransform>*/
         transform = new HashMap();

      final edu.berkeley.guir.damask.DeviceType realDialogDeviceType =
         getDeviceTypeAndBoundsAndTransforms(
            dialog.getBoundsAndTransforms(),
            bounds,
            transform);

      // Set the bounds and transform of the real dialog.
      setBoundsAndTransforms(realDialog, bounds, transform);
      
      realDialog.setDeviceType(realDialogDeviceType);

      // Reset the voice transforms of controls that might have been changed
      // by a call to realDialog.changeControlPageRegion() above.
      for (Iterator j = origVoiceTransforms.keySet().iterator(); j.hasNext(); ) {
         final edu.berkeley.guir.damask.component.Control realControl =
            (edu.berkeley.guir.damask.component.Control)j.next();
         realControl.setTransform(
            edu.berkeley.guir.damask.DeviceType.VOICE,
            (AffineTransform)origVoiceTransforms.get(realControl));
      }
      
      return realDialog;
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and returns the corresponding content, creating
    * it if necessary.
    */
   private static edu.berkeley.guir.damask.component.Content
      getRealContent(final Content content) {

      // If we've created the corresponding real content before, then return it.
      edu.berkeley.guir.damask.component.Content realContent =
         (edu.berkeley.guir.damask.component.Content)realElements.get(content);
      if (realContent != null) {
         return realContent;
      }

      final Map/*<edu.berkeley.guir.damask.DeviceType, Rectangle2D>*/ bounds =
         new HashMap();
      final Map/*<edu.berkeley.guir.damask.DeviceType, AffineTransform>*/
         transform = new HashMap();

      final edu.berkeley.guir.damask.DeviceType realDeviceType =
         getDeviceTypeAndBoundsAndTransforms(
            content.getBoundsAndTransforms(),
            bounds,
            transform);

      // Create blank real content.
      realContent =
         new edu.berkeley.guir.damask.component.Content(realDeviceType);

      //System.out.println(content.getId() + "->" + realContent.getId());

      // Set the text of the real content.
      final TextContent textContent = content.getTextContent();
      if (textContent != null) {
         realContent.setText(textContent.getText());

         // Set the text sizes of the real content.
         for (Iterator i = textContent.getTextSizes().getTextSize().iterator();
            i.hasNext();
            ) {
            final TextSize textSize = (TextSize)i.next();
            realContent.setTextSize(
               getRealDeviceType(textSize.getDeviceType()),
               textSize.getSize().intValue());
         }
         
         if (textContent.getVoiceText() != null) {
            if (realContent.isVisibleToDeviceType(edu.berkeley.guir.damask.DeviceType.VOICE)) {
               realContent.setPromptTextSyncedWithText(textContent.getVoiceText().equals(realContent.getText()));
               realContent.setVoicePromptText(textContent.getVoiceText());
            }
         }
      }

      // Set the image of the real content.
      final ImageContent imageContent = content.getImageContent();
      if (imageContent != null) {
         if (imageContent.getEncoding().equalsIgnoreCase("base64")) {
            try {
               final String imageDataStr = imageContent.getImageData();
               final byte[] imageData =
                  Base64.decodeBase64(imageDataStr.getBytes());
               final BufferedImage image =
                  ImageIO.read(new ByteArrayInputStream(imageData));
               realContent.setImage(image);
            }
            catch (IOException e) {
               DamaskAppExceptionHandler.log(e);
            }
         }
      }

      // Set the strokes of the real content.
      final Polylines strokesContent = content.getStrokesContent();
      if (strokesContent != null) {
         final List/*<GeneralPath>*/ realStrokes = new ArrayList();
         for (Iterator i = strokesContent.getPolyline().iterator();
            i.hasNext();
            ) {
            final Polyline polyline = (Polyline)i.next();

            final GeneralPath genPath = createGeneralPath(polyline);
            realStrokes.add(genPath);
         }
         realContent.setStrokes(realStrokes);
      }

      // Set the preferred display modes
      for (Iterator i = content.getDisplayModes().getDisplayMode().iterator();
         i.hasNext();
         ) {
         final DisplayMode displayMode = (DisplayMode)i.next();

         final edu.berkeley.guir.damask.component.Content.DisplayMode
            realDisplayMode;

         final String displayModeString = displayMode.getMode();

         if (displayModeString.equalsIgnoreCase("Image")) {
            realDisplayMode = edu.berkeley.guir.damask.component.Content.IMAGE;
         }
         else if (displayModeString.equalsIgnoreCase("Ink")) {
            realDisplayMode = edu.berkeley.guir.damask.component.Content.INK;
         }
         else {
            realDisplayMode = edu.berkeley.guir.damask.component.Content.TEXT;
         }

         realContent.setPreferredDisplayMode(
            getRealDeviceType(displayMode.getDeviceType()),
            realDisplayMode);
      }

      // Set the bounds and transform of the real content.
      setBoundsAndTransforms(realContent, bounds, transform);

      setVoiceViewProperties(realContent, content);
      
      // Save the new real content for later use.
      realElements.put(content, realContent);

      return realContent;
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and returns the corresponding text input,
    * creating it if necessary.
    */
   private static edu.berkeley.guir.damask.component.TextInput
      getRealTextInput(final TextInput textInput) {

      // If we've created the corresponding real content before, then return it.
      edu.berkeley.guir.damask.component.TextInput realTextInput =
         (edu.berkeley.guir.damask.component.TextInput)realElements.get(textInput);
      if (realTextInput != null) {
         return realTextInput;
      }

      final Map/*<edu.berkeley.guir.damask.DeviceType, Rectangle2D>*/ bounds =
         new HashMap();
      final Map/*<edu.berkeley.guir.damask.DeviceType, AffineTransform>*/
         transform = new HashMap();

      final edu.berkeley.guir.damask.DeviceType realDeviceType =
         getDeviceTypeAndBoundsAndTransforms(
            textInput.getBoundsAndTransforms(),
            bounds,
            transform);

      // Create blank real text input.
      realTextInput =
         new edu.berkeley.guir.damask.component.TextInput(realDeviceType);

      // Set the bounds and transform of the real text input.
      setBoundsAndTransforms(realTextInput, bounds, transform);

      // Set the border of the real text input.
      final Borders borders = textInput.getBorders();
      if (borders != null) {
         for (Iterator i = borders.getBorder().iterator(); i.hasNext(); ) {
            final Border border = (Border)i.next();
            realTextInput.setBorder(
               getRealDeviceType(border.getDeviceType()),
               createGeneralPath(border.getPolyline()));
         }
      }

      // Save the new real text input for later use.
      realElements.put(textInput, realTextInput);

      setVoiceViewProperties(realTextInput, textInput);

      return realTextInput;
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and returns a corresponding trigger,
    * creating it if necessary.
    */
   private static edu.berkeley.guir.damask.component.Trigger
      getRealTrigger(final Trigger trigger) {

      // If we've created the corresponding real trigger before, then return
      // it.
      edu.berkeley.guir.damask.component.Trigger realTrigger =
         (edu.berkeley.guir.damask.component.Trigger)realElements.get(trigger);
      if (realTrigger != null) {
         return realTrigger;
      }

      final Map/*<edu.berkeley.guir.damask.DeviceType, Rectangle2D>*/ bounds =
         new HashMap();
      final Map/*<edu.berkeley.guir.damask.DeviceType, AffineTransform>*/
         transform = new HashMap();

      final edu.berkeley.guir.damask.DeviceType realDeviceType =
         getDeviceTypeAndBoundsAndTransforms(
            trigger.getBoundsAndTransforms(),
            bounds,
            transform);

      // Create a real trigger.
      realTrigger =
         new edu.berkeley.guir.damask.component.Trigger(
            realDeviceType,
            getRealContent(trigger.getContent()));

      // Set the bounds and transform of the real trigger.
      setBoundsAndTransforms(realTrigger, bounds, transform);

      // Set the borders of the real trigger.
      final Borders borders = trigger.getBorders();
      if (borders != null) {
         for (Iterator i = borders.getBorder().iterator(); i.hasNext(); ) {
            final Border border = (Border)i.next();
            realTrigger.setBorder(
               getRealDeviceType(border.getDeviceType()),
               createGeneralPath(border.getPolyline()));
         }
      }

      // Set the styles of the real trigger.
      final Styles styles = trigger.getStyles();
      if (styles != null) {
         for (Iterator i = styles.getStyle().iterator(); i.hasNext(); ) {
            final Style style = (Style)i.next();

            final String styleString = style.getName();
            final edu.berkeley.guir.damask.component.Trigger.Style realStyle;

            if (styleString.equalsIgnoreCase("Button")) {
               realStyle = edu.berkeley.guir.damask.component.Trigger.BUTTON;
            }
            else {
               realStyle = edu.berkeley.guir.damask.component.Trigger.HYPERLINK;
            }

            realTrigger.setStyle(
               getRealDeviceType(style.getDeviceType()), realStyle);
         }
      }

      // Save the new real trigger for later use.
      realElements.put(trigger, realTrigger);

      setVoiceViewProperties(realTrigger, trigger);
      
      return realTrigger;
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and returns a corresponding select-one,
    * creating it if necessary.
    */
   private static edu.berkeley.guir.damask.component.SelectOne
      getRealSelectOne(final SelectOne selectOne) {

      // If we've created the corresponding real select-one object before, then
      // return it.
      edu.berkeley.guir.damask.component.SelectOne realSelectOne =
         (edu.berkeley.guir.damask.component.SelectOne)realElements.get(
            selectOne);
      if (realSelectOne != null) {
         return realSelectOne;
      }

      final Map/*<edu.berkeley.guir.damask.DeviceType, Rectangle2D>*/ bounds =
         new HashMap();
      final Map/*<edu.berkeley.guir.damask.DeviceType, AffineTransform>*/
         transform = new HashMap();

      final edu.berkeley.guir.damask.DeviceType realDeviceType =
         getDeviceTypeAndBoundsAndTransforms(
            selectOne.getBoundsAndTransforms(),
            bounds,
            transform);

      // Create a real select-one.
      realSelectOne =
         new edu.berkeley.guir.damask.component.SelectOne(realDeviceType);

      // Set the styles of the real select-one.
      final Styles styles = selectOne.getStyles();
      if (styles != null) {
         for (Iterator i = styles.getStyle().iterator(); i.hasNext(); ) {
            final Style style = (Style)i.next();

            final String styleString = style.getName();
            final edu.berkeley.guir.damask.component.Select.Style realStyle;

            if (styleString.equalsIgnoreCase("Full")) {
               realStyle = edu.berkeley.guir.damask.component.Select.FULL;
            }
            else if (styleString.equalsIgnoreCase("Compact")) {
               realStyle = edu.berkeley.guir.damask.component.Select.COMPACT;
            }
            else {
               realStyle = edu.berkeley.guir.damask.component.Select.MINIMAL;
            }

            realSelectOne.setStyle(
               getRealDeviceType(style.getDeviceType()), realStyle);
         }
      }
      
      // Set the bounds and transform of the real select-one.
      setBoundsAndTransforms(realSelectOne, bounds, transform);

      // Add the items to the real select-one object.
      final Items items = selectOne.getItems();
      if (items != null) {
         for (Iterator i = items.getItem().iterator(); i.hasNext(); ) {
            final Item item = (Item)i.next();

            final Map/*<edu.berkeley.guir.damask.DeviceType, Rectangle2D>*/
               itemBounds = new HashMap();
            final Map/*<edu.berkeley.guir.damask.DeviceType, AffineTransform>*/
               itemTransform = new HashMap();

            getDeviceTypeAndBoundsAndTransforms(
               item.getBoundsAndTransforms(),
               itemBounds,
               itemTransform);

            // Create a real select-one item.
            final edu.berkeley.guir.damask.component.SelectOne.Item realItem =
               new edu.berkeley.guir.damask.component.SelectOne.Item(
                  getRealContent(item.getContent()));

            realElements.put(item, realItem);
            
            // Set the bounds and transform of the real select-one.
            setBoundsAndTransforms(realItem, itemBounds, itemTransform);

            setVoiceViewProperties(realItem, item);

            // Add the real item to the real select-many object.
            realSelectOne.addItem(realItem);
         }
      }

      setVoiceViewProperties(realSelectOne, selectOne);

      // Save the new real select-one object for later use.
      realElements.put(selectOne, realSelectOne);

      return realSelectOne;
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and returns a corresponding select-many,
    * creating it if necessary.
    */
   private static edu.berkeley.guir.damask.component.SelectMany
      getRealSelectMany(final SelectMany selectMany) {

      // If we've created the corresponding real select-many object before,
      // then return it.
      edu.berkeley.guir.damask.component.SelectMany realSelectMany =
         (edu.berkeley.guir.damask.component.SelectMany)realElements.get(
            selectMany);
      if (realSelectMany != null) {
         return realSelectMany;
      }

      final Map/*<edu.berkeley.guir.damask.DeviceType, Rectangle2D>*/ bounds =
         new HashMap();
      final Map/*<edu.berkeley.guir.damask.DeviceType, AffineTransform>*/
         transform = new HashMap();

      final edu.berkeley.guir.damask.DeviceType realDeviceType =
         getDeviceTypeAndBoundsAndTransforms(
            selectMany.getBoundsAndTransforms(),
            bounds,
            transform);

      // Create a real select-many.
      realSelectMany =
         new edu.berkeley.guir.damask.component.SelectMany(realDeviceType);

      // Set the bounds and transform of the real select-many.
      setBoundsAndTransforms(realSelectMany, bounds, transform);

      // Add the items to the real select-many object.
      final Items items = selectMany.getItems();
      if (items != null) {
         for (Iterator i = items.getItem().iterator(); i.hasNext(); ) {
            final Item item = (Item)i.next();

            final Map/*<edu.berkeley.guir.damask.DeviceType, Rectangle2D>*/
               itemBounds = new HashMap();
            final Map/*<edu.berkeley.guir.damask.DeviceType, AffineTransform>*/
               itemTransform = new HashMap();

            getDeviceTypeAndBoundsAndTransforms(
               item.getBoundsAndTransforms(),
               itemBounds,
               itemTransform);

            // Create a real select-many item.
            final edu.berkeley.guir.damask.component.SelectMany.Item realItem =
               new edu.berkeley.guir.damask.component.SelectMany.Item(
                  getRealContent(item.getContent()));

            realElements.put(item, realItem);

            // Set the bounds and transform of the real select-one.
            setBoundsAndTransforms(realItem, itemBounds, itemTransform);

            setVoiceViewProperties(realItem, item);

            // Add the real item to the real select-many object.
            realSelectMany.addItem(realItem);
         }
      }

      // Set the styles of the real select-many.
      final Styles styles = selectMany.getStyles();
      if (styles != null) {
         for (Iterator i = styles.getStyle().iterator(); i.hasNext(); ) {
            final Style style = (Style)i.next();

            final String styleString = style.getName();
            final edu.berkeley.guir.damask.component.Select.Style realStyle;

            if (styleString.equalsIgnoreCase("Full")) {
               realStyle = edu.berkeley.guir.damask.component.Select.FULL;
            }
            else if (styleString.equalsIgnoreCase("Compact")) {
               realStyle = edu.berkeley.guir.damask.component.Select.COMPACT;
            }
            else {
               realStyle = edu.berkeley.guir.damask.component.Select.MINIMAL;
            }

            realSelectMany.setStyle(
               getRealDeviceType(style.getDeviceType()), realStyle);
         }
      }

      // Save the new real select-many object for later use.
      realElements.put(selectMany, realSelectMany);

      setVoiceViewProperties(realSelectMany, selectMany);

      return realSelectMany;
   }


   /**
    * Given the specified states and significances, applies them to the
    * specified control.
    */
   private static void setStatesAndSignificances(
      final edu.berkeley.guir.damask.component.Control realControl,
      final States states,
      final Significances significances) {

      if ((states == null) || (significances == null)) {
         return;
      }

      // First, set the states.
      for (Iterator i = states.getStatesForDialog().iterator(); i.hasNext(); ) {
         final StatesForDialog statesForDialog = (StatesForDialog)i.next();
         final Dialog dialog = (Dialog)statesForDialog.getDialog();
         final edu.berkeley.guir.damask.dialog.Dialog realDialog =
            (edu.berkeley.guir.damask.dialog.Dialog)realElements.get(dialog);

         for (Iterator j = statesForDialog.getStateForCondition().iterator();
            j.hasNext();
            ) {
            final StateForCondition condition = (StateForCondition)j.next();
            final int conditionNum = condition.getConditionNum().intValue();
            
            if (condition.getMultiState() != null) {
               final MultiState multiState = condition.getMultiState();
               final List realStates = new ArrayList();
            
               for (Iterator k = multiState.getState().iterator();k.hasNext();){
                  final Object o = k.next();
                  if (o instanceof StateBooleanState) {
                     realStates.add(
                        Boolean.valueOf(((StateBooleanState)o).isValue()));
                  }
                  else if (o instanceof StateIntegerState) {
                     realStates.add(
                        new Integer(
                           ((StateIntegerState)o).getValue().intValue()));
                  }
                  else if (o instanceof StateStringState) {
                     realStates.add(((StateStringState)o).getValue());
                  }
                  else if (o instanceof StateIDREFState) {
                     realStates.add(
                        realElements.get(((StateIDREFState)o).getValue()));
                  }
                  realControl.setStateForCondition(
                     realDialog,
                     conditionNum,
                     realStates);
               }
            }
            else {
               final Object realState;
               
               if (condition.getIntegerState() != null) {
                  realState =
                     new Integer(
                        condition.getIntegerState().getValue().intValue());
               }
               else if (condition.getStringState() != null) {
                  realState = condition.getStringState().getValue();
               }
               else if (condition.getIDREFState() != null) {
                  realState =
                     realElements.get(condition.getIDREFState().getValue());
               }
               else {
                  realState =
                     Boolean.valueOf(condition/*.isBooleanState()*/.getBooleanState().isValue());
               }
               realControl.setStateForCondition(
                  realDialog,
                  conditionNum,
                  realState);
            }
         }
      }

      // Second, set the significances.
      for (Iterator i = significances.getSignificancesForDialog().iterator();
         i.hasNext();
         ) {
         final SignificancesForDialog sigsForDialog = (SignificancesForDialog)i.next();
         final Dialog dialog = (Dialog)sigsForDialog.getDialog();
         final edu.berkeley.guir.damask.dialog.Dialog realDialog =
            (edu.berkeley.guir.damask.dialog.Dialog)realElements.get(dialog);

         for (Iterator j = sigsForDialog.getSignificance().iterator();
            j.hasNext();
            ) {
            final Significance sig = (Significance)j.next();
            final int conditionNum = sig.getCondition().intValue();
            final boolean sigValue = sig.isValue();
            realControl.setStateSignificantForCondition(
               realDialog,
               conditionNum,
               sigValue);
         }
      }
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and returns a corresponding connection,
    * creating it if necessary.
    */
   private static edu.berkeley.guir.damask.connection.Connection
      getRealConnection(final Connection connection) {

      // If we've created the corresponding real trigger before, then return
      // it.
      edu.berkeley.guir.damask.connection.Connection realConnection =
         (edu.berkeley.guir.damask.connection.Connection)realElements.get(
            connection);
      if (realConnection != null) {
         return realConnection;
      }

      final UserEvent userEvent = connection.getUserEvent();
      final int condition;
      if (connection.getCondition() != null) {
         condition = connection.getCondition().intValue();
      }
      else {
         condition = -1;
      }

      // Read the shapes
      final Map/*<String, Polyline>*/ shapes = new HashMap();
      for (Iterator i = connection.getConnectionShape().iterator();
         i.hasNext();
         ) {
         final ConnectionShape connectionShape = (ConnectionShape)i.next();
         shapes.put(
            connectionShape.getDeviceType(),
            connectionShape.getPolyline());
      }

      // Create the connection
      if (userEvent == null) {
         realConnection =
            new edu.berkeley.guir.damask.connection.OrgConnection(
               getRealDeviceType(connection.getOrigDeviceType()),
               connection.isForAllDeviceTypes(),
               (edu.berkeley.guir.damask.dialog.Page)realElements.get(
                  connection.getSourceForOrigDeviceType()),
               (edu.berkeley.guir.damask.dialog.Page)realElements.get(
                  connection.getDestForOrigDeviceType()),
               createGeneralPath(
                  (Polyline)shapes.get(connection.getOrigDeviceType())));
      }
      else {
         //System.out.println("creating connection: " + connection.getId());
         realConnection =
            new edu.berkeley.guir.damask.connection.NavConnection(
               getRealDeviceType(connection.getOrigDeviceType()),
               connection.isForAllDeviceTypes(),
               (edu.berkeley.guir.damask.component.Control)realElements.get(
                  connection.getSourceForOrigDeviceType()),
               createRealUserEvent(userEvent),
               condition,
               (edu.berkeley.guir.damask.connection.ConnectionDest)
                  realElements.get(connection.getDestForOrigDeviceType()),
               createGeneralPath(
                  (Polyline)shapes.get(connection.getOrigDeviceType())));
      }

      // Set the shapes
      for (Iterator i = shapes.keySet().iterator(); i.hasNext(); ) {
         final String deviceType = (String)i.next();
         final Polyline polyline = (Polyline)shapes.get(deviceType);
         realConnection.setShape(
            getRealDeviceType(deviceType),
            createGeneralPath(polyline));
      }

      // Save the new real connection for later use.
      realElements.put(connection, realConnection);

      return realConnection;
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and creates corresponding general path.
    */
   private static edu.berkeley.guir.damask.userevent.DamaskUserEvent
   createRealUserEvent(final UserEvent event) {
      final Element eventElement = event.getUserEvent();
      if (eventElement instanceof HoverOverEvent) {
         return new edu.berkeley.guir.damask.userevent.HoverOverEvent(
            realElements.get(((HoverOverEvent)eventElement).getSource()));
      }
      else if (eventElement instanceof HoverOffEvent) {
         return new edu.berkeley.guir.damask.userevent.HoverOffEvent(
            realElements.get(((HoverOffEvent)eventElement).getSource()));
      }
      else if (eventElement instanceof InvokeEvent) {
         return new edu.berkeley.guir.damask.userevent.InvokeEvent(
            realElements.get(((InvokeEvent)eventElement).getSource()));
      }
      else if (eventElement instanceof SecondaryInvokeEvent) {
         return new edu.berkeley.guir.damask.userevent.SecondaryInvokeEvent(
            realElements.get(((SecondaryInvokeEvent)eventElement).getSource()));
      }
      else {
         return new edu.berkeley.guir.damask.userevent.SelectEvent(
            realElements.get(((SelectEvent)eventElement).getSource()));
      }
   }


   /**
    * Given a BoundAndTransforms objects within an element, figures out what
    * device type the element supports, and what the bounds and transform is
    * for each of the supported device types.
    *
    * @param BoundsAndTransforms the bounds and transforms for an element
    * @param bounds a map of a (real) device type to a bounding box
    * @param transform a map of a (real) device type to a transform
    * @return the device type of the element
    */
   private static edu.berkeley.guir.damask.DeviceType
   getDeviceTypeAndBoundsAndTransforms(
      final BoundsAndTransforms boundsAndTransforms,
      final Map/*<edu.berkeley.guir.damask.DeviceType, Rectangle2D>*/ bounds,
      final Map/*<edu.berkeley.guir.damask.DeviceType, AffineTransform>*/
         transform) {

      // Figure out which device types this content supports, and get the
      // bounds and transform for each device type.
      for (Iterator i = boundsAndTransforms.getBoundsAndTransform().iterator();
         i.hasNext();
         ) {
         final BoundsAndTransform boundsAndTransform =
            (BoundsAndTransform)i.next();
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            getRealDeviceType(boundsAndTransform.getDeviceType());
         bounds.put(
            realDeviceType,
            createRealBounds(boundsAndTransform.getBounds()));
         transform.put(
            realDeviceType,
            createRealTransform(boundsAndTransform.getTransform()));
      }

      final edu.berkeley.guir.damask.DeviceType realDeviceType;
      if (bounds.size() == 0) {
         realDeviceType = edu.berkeley.guir.damask.DeviceType.VOICE;
      }
      else if (bounds.size() == 1) {
         realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)bounds.keySet()
               .iterator()
               .next();
      }
      else {
         realDeviceType = edu.berkeley.guir.damask.DeviceType.ALL;
      }
      return realDeviceType;
   }


   /**
    * Given a BoundAndTransforms objects within a control, figures out what
    * device type the control supports, and what the bounds and transform is
    * for each of the supported device types.
    *
    * @param BoundsAndTransforms the bounds and transforms for a control
    * @param bounds a map of a (real) device type to a bounding box
    * @param transform a map of a (real) device type to a transform
    * @return the device type of the control
    */
   private static edu.berkeley.guir.damask.DeviceType
   getDeviceTypeAndBoundsAndTransformsForGroup(
      final BoundsAndTransformsForGroup boundsAndTransformsForGroup,
      final Map/*<edu.berkeley.guir.damask.dialog.PageRegion, Rectangle2D>*/ bounds,
      final Map/*<edu.berkeley.guir.damask.dialog.PageRegion, AffineTransform>*/
         transform) {

      final Set/*<edu.berkeley.guir.damask.DeviceType>*/
         supportedRealDeviceTypes = new HashSet();

      // Figure out which device types this content supports, and get the
      // bounds and transform for each device type.
      for (Iterator i =
         boundsAndTransformsForGroup.getBoundsAndTransformInRegion().iterator();
         i.hasNext();
         ) {
         final BoundsAndTransformInRegion boundsAndTransformInRegion =
            (BoundsAndTransformInRegion)i.next();

         final edu.berkeley.guir.damask.dialog.Page realPage =
            (edu.berkeley.guir.damask.dialog.Page)realElements.get(
               boundsAndTransformInRegion.getPage());

         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            realPage.getDeviceType();

         supportedRealDeviceTypes.add(realDeviceType);

         final edu.berkeley.guir.damask.dialog.PageRegion realRegion =
            realPage.getRegion(
               getRealDirection(boundsAndTransformInRegion.getRegion()));

         bounds.put(
            realRegion,
            createRealBounds(boundsAndTransformInRegion.getBounds()));
         transform.put(
            realRegion,
            createRealTransform(boundsAndTransformInRegion.getTransform()));
      }

      final edu.berkeley.guir.damask.DeviceType realDeviceType;
      if (supportedRealDeviceTypes.size() == 1) {
         realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)supportedRealDeviceTypes
               .iterator()
               .next();
      }
      else {
         realDeviceType = edu.berkeley.guir.damask.DeviceType.ALL;
      }
      return realDeviceType;
   }


   /**
    * Sets the bounds and transforms of the specified element, depending on
    * the specified mappings.
    *
    * @param realElement the element whose bounds and transforms will be set
    * @param bounds a map of a (real) device type to a bounding box
    * @param transform a map of a (real) device type to a transform
    */
   private static void setBoundsAndTransforms(
      final edu.berkeley.guir.damask.InteractionElement realElement,
      final Map/*<edu.berkeley.guir.damask.DeviceType, Rectangle2D>*/ bounds,
      final Map/*<edu.berkeley.guir.damask.DeviceType, AffineTransform>*/
         transform) {

      for (Iterator i = bounds.keySet().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         realElement.setBounds(
            realDeviceType,
            (Rectangle2D)bounds.get(realDeviceType));

         realElement.setTransform(
            realDeviceType,
            (AffineTransform)transform.get(realDeviceType));
      }
   }

   private static void setVoiceViewProperties(
      final edu.berkeley.guir.damask.component.Control realControl,
      final Object control) {

      if (!realControl.isVisibleToDeviceType(edu.berkeley.guir.damask.DeviceType.VOICE)) {
         return;
      }
      
      try {
         final VoiceViewProperties voiceProperties =
            (VoiceViewProperties)control
               .getClass()
               .getMethod("getVoiceViewProperties", null)
               .invoke(control, null);
         
         //HACK
         if (voiceProperties == null) {
            return;
         }
         
         final Prompt prompt = voiceProperties.getPrompt();
         if (prompt != null) {
            realControl.setVoicePromptBounds(createRealBounds(prompt.getBounds()));
            if (prompt.getText() != null) {
               realControl.setVoicePromptText(prompt.getText());
            }
         }
         
         //HACK
         if (realControl instanceof edu.berkeley.guir.damask.component.Content) {
            final String origPromptText =
               ((edu.berkeley.guir.damask.component.Content)realControl).getVoicePromptText();
            if (((edu.berkeley.guir.damask.component.Content)realControl).getText().equals("") &&
                  ((origPromptText == null) || (origPromptText.equals("")))) {
               ((edu.berkeley.guir.damask.component.Content)realControl).setText(edu.berkeley.guir.damask.view.voice.component.Response.NULL_DISPLAY_STRING);
            }
         }
         
         final Response response = voiceProperties.getResponse();
         if (response != null) {
            for (Iterator i =
               response.getLines().getResponseLine().iterator(); i.hasNext(); ) {

               final ResponseLine responseLine = (ResponseLine)i.next();
               realControl.setVoiceResponseLine(
                  responseLine.getCondition().intValue(),
                  new Line2D.Double(
                     responseLine.getX1(),
                     responseLine.getY1(),
                     responseLine.getX2(),
                     responseLine.getY2()));
            }

            if (realControl instanceof
                  edu.berkeley.guir.damask.component.SelectMany.Item) {
               final edu.berkeley.guir.damask.component.SelectMany.Item realItem =
                  (edu.berkeley.guir.damask.component.SelectMany.Item)realControl;
               final List/*<String>*/ textList = 
                  new ArrayList/*<String>*/(response.getTexts().getText());
               realItem.setVoiceResponseTextList(textList);
            }
         }
         
         realControl.setTransform(
            edu.berkeley.guir.damask.DeviceType.VOICE,
            createRealTransform(voiceProperties.getTransform()));
      }
      // None of these exceptions should ever happen
      catch (IllegalArgumentException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (SecurityException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (IllegalAccessException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (InvocationTargetException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (NoSuchMethodException e) {
         DamaskAppExceptionHandler.log(e);
      }
   }
   
   
   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and creates corresponding rectangle.
    */
   private static Rectangle2D createRealBounds(final Bounds bounds) {
      return new Rectangle2D.Double(
         bounds.getX(),
         bounds.getY(),
         bounds.getWidth(),
         bounds.getHeight());
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and creates corresponding transform.
    */
   private static AffineTransform createRealTransform(final Transform transform) {
      return new AffineTransform(
         transform.getScaleX(),
         transform.getShearX(),
         transform.getShearY(),
         transform.getScaleY(),
         transform.getTranslateX(),
         transform.getTranslateY());
   }


   /**
    * Takes the string and returns the corresponding device type.
    */
   private static edu.berkeley.guir.damask.DeviceType
      getRealDeviceType(final String deviceTypeString) {

      if (deviceTypeString.equalsIgnoreCase("Desktop")) {
         return edu.berkeley.guir.damask.DeviceType.DESKTOP;
      }
      else if (deviceTypeString.equalsIgnoreCase("Smartphone")) {
         return edu.berkeley.guir.damask.DeviceType.SMARTPHONE;
      }
      else if (deviceTypeString.equalsIgnoreCase("Voice")) {
         return edu.berkeley.guir.damask.DeviceType.VOICE;
      }
      else {
         return edu.berkeley.guir.damask.DeviceType.ALL;
      }
   }


   /**
    * Takes the specified content tree object, which the result of
    * unmarshalling XML data, and creates corresponding general path.
    */
   private static GeneralPath createGeneralPath(final Polyline polyline) {
      final GeneralPath genPath = new GeneralPath();

      final Iterator j = polyline.getPoint().iterator();
      if (j.hasNext()) {
         final Point point = (Point)j.next();
         genPath.moveTo((float)point.getX(), (float)point.getY());
      }
      while (j.hasNext()) {
         final Point point = (Point)j.next();
         genPath.lineTo((float)point.getX(), (float)point.getY());
      }
      return genPath;
   }


   /**
    * Takes the string and returns the corresponding direction.
    */
   private static edu.berkeley.guir.damask.Direction
      getRealDirection(final String directionString) {

      if (directionString.equalsIgnoreCase("North")) {
         return edu.berkeley.guir.damask.Direction.NORTH;
      }
      else if (directionString.equalsIgnoreCase("South")) {
         return edu.berkeley.guir.damask.Direction.SOUTH;
      }
      else if (directionString.equalsIgnoreCase("East")) {
         return edu.berkeley.guir.damask.Direction.EAST;
      }
      else if (directionString.equalsIgnoreCase("West")) {
         return edu.berkeley.guir.damask.Direction.WEST;
      }
      else  {
         return edu.berkeley.guir.damask.Direction.CENTER;
      }
   }
}
