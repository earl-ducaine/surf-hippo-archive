package edu.berkeley.guir.lib.gesture;

import java.util.*;
import edu.berkeley.guir.lib.gesture.util.*;
import java.io.PrintStream;
import edu.berkeley.guir.lib.gesture.features.*;
import java.beans.*;

/**
 * Gesture classifier/recogizer, using Dean Rubine's algorithm, with
 * guidance from Rob Miller's C++ port, which is part of the Amulet package.
 *
 * Note: for performance reasons, the Classifier does <em>not</em>
 * retrain automatically when the underlying GestureSet changes.  It
 * will retrain automatically the next time it needs to (e.g., for
 * classify()).
 *
 * Known bugs: training may take some time, but train() does not check
 * to see if its thread gets interrupted.
 *
 */
public class Classifier {
  /** a Boolean property indicating whether the classifier is trained
      or not */
  public static final String TRAINED_PROP = "trained";
  /** Set on gestures that are misrecognized, with a Result value */
  public static final String MISRECOGNIZED_PROP	= "misrecognized";
  static {
    Properties.setPropertyPersistence(MISRECOGNIZED_PROP, false);
  }
  
  private final static Class[] DEFAULT_FEATURE_CLASSES = {
    InitAngleCosine.class, InitAngleSine.class, BoundsSize.class,
    BoundsAngle.class, EndsDistance.class, EndsAngleCosine.class,
    EndsAngleSine.class, TotalLength.class, TotalAngle.class,
    TotalAbsAngle.class, Sharpness.class
  };
  protected Class[] featureClasses = getDefaultFeatureClasses();
    
  protected static final double EPSILON = 1E-6; // for singular matrix check
  protected GestureSet gestureSet;
  protected double[][] weights;	// [gestureCategory][feature+1]
  protected double[][] meanFeatureValues; // [gestureCategory][feature]
  protected double[][] ccm;
  protected double[][] ccmInv;
  protected GestureCategory dotCategory = null;
  protected boolean trained = false;
  protected BitSet featuresUsed;
  protected List enabledCategories = null;
  protected CollectionListener myCollectionListener =
    new MyCollectionListener();
  protected PropertyChangeListener myPropChangeListener =
    new MyPropChangeListener();
  protected transient PropertyChangeSupport propChangeSupport =
    new PropertyChangeSupport(this);

  public Classifier()
  {
    this(null);
  }

  /**
   * Does not automatically train.
   */
  public Classifier(GestureSet gs)
  {
    setGestureSet(gs);
  }

  public synchronized void setFeatureClasses(Class[] featureClasses)
  {
    if (this.featureClasses != featureClasses) {
      this.featureClasses = featureClasses;
      setTrained(false);
    }
  }

  public Class[] getFeatureClasses()
  {
    return featureClasses;
  }

  public static Class[] getDefaultFeatureClasses()
  {
    return DEFAULT_FEATURE_CLASSES;
  }

  public double[][] getWeights()
  {
    return weights;
  }
  
  /**
   * Does not automatically train.
   */
  public synchronized void setGestureSet(GestureSet gs)
  {
    if (gestureSet != gs) {
      if (gestureSet != null) {
	gestureSet.removeCollectionListener(myCollectionListener);
	gestureSet.removePropertyChangeListener(myPropChangeListener);
      }
      gestureSet = gs;
      if (gestureSet != null) {
	gestureSet.addCollectionListener(myCollectionListener);
	gestureSet.addPropertyChangeListener(myPropChangeListener);
      }
    }
  }

  public GestureSet getGestureSet()
  {
    return gestureSet;
  }
  
  /**
   * Used to return the results of a classification.
   */
  public class Result
  {
    /** the GestureCategory that best fits the example */
    public GestureCategory category;
    /** Estimated accuracy of the classification.  1.0 is the best,
     * 0 is the worst. */
    public double accuracy;
    /** Mahalanobis distance from the example to the mean of the
     * category given by gcIndex. */
    public double distToMean;

    public Result(GestureCategory cat, double acc, double dist)
    {
      category = cat;
      accuracy = acc;
      distToMean = dist;
    }
  }

  /**
   * Features actually used in current classification (null if untrained)
   */
  public BitSet getFeaturesUsed()
  {
    return trained ? featuresUsed : null;
  }

  /* can't easily get an enabled category from an index, so let's try
     not to use this
  double[][] computeCovarianceMatrix(int categoryIndex,
				     double[] meanFeatureVector)
  {
    GestureCategory gestureCategory = (GestureCategory) gestureSet.
      getChild(categoryIndex);
    return computeCovarianceMatrix(gestureCategory, meanFeatureVector);
  }
  */

  protected Feature getFeature(GestureCategory gc, int gIndex, int fIndex)
  {
    return getFeature(gc, gIndex, featureClasses[fIndex]);
  }
  
  protected Feature getFeature(GestureCategory gc, int gIndex,
			       Class featureClass)
  {
    return FeatureFactory.getFeature(featureClass, gc.getChild(gIndex));
  }

  /**
   * Compute and return covariance matrix and fill in the mean feature
   * value array (if provided)
   * (Note: only upper triangular part computed)
   */
  // Maybe this belongs in FeatureFactory.  Oh, well.
  protected double[][]
    computeCovarianceMatrix(GestureCategory gestureCategory,
			    double[] meanFeatureVector)
  {
    List enabledExamples = gestureCategory.getEnabledChildren();
    int numExamples = enabledExamples.size();
    int numFeatures = featureClasses.length;
    double[][] result = new double[numFeatures][numFeatures];
    if (meanFeatureVector == null)
      meanFeatureVector = new double[numFeatures];

    // compute the mean feature vector
    for (int featureNum = 0;
	 featureNum < numFeatures;
	 featureNum++) {
      Class featureClass = featureClasses[featureNum];
      double sum = 0;
      for (Iterator iter = enabledExamples.iterator();
	   iter.hasNext();) {
	Feature feature = FeatureFactory.getFeature(featureClass,
						    (GestureObject)
						    iter.next());
	sum += feature.getValue();
      }
      meanFeatureVector[featureNum] = sum / ((double) numExamples);
    }

    // compute the covariance matrix
    for (int i = 0; i < numFeatures; i++) {
      Class iFC = featureClasses[i];
      for (int j = i; j < numFeatures; j++) {
	Class jFC = featureClasses[j];
	double sum = 0;
	for (Iterator iter = enabledExamples.iterator();
	     iter.hasNext();) {
	  GestureObject example = (GestureObject) iter.next();
	  double fi = FeatureFactory.getFeature(iFC, example).getValue();
	  double fj = FeatureFactory.getFeature(jFC, example).getValue();
	  sum += (fi - meanFeatureVector[i]) * (fj - meanFeatureVector[j]);
	}
	result[i][j] = sum;
      }
    }
    return result;
  }

  protected void setTrained(boolean isTrained)
  {
    if (trained != isTrained) {
      trained = isTrained;
      propChangeSupport.firePropertyChange(TRAINED_PROP,
					   new Boolean(!trained),
					   new Boolean(trained));
    }
  }
  
  public boolean isTrained()
  {
    return trained;
  }

  protected void checkForInterrupt() throws InterruptedException
  {
    if (Thread.interrupted()) {
      throw new InterruptedException("Training interrupted");
    }
  }
  
  /**
   * (Re)trains the current Classifier.
   *
   */
  public synchronized void train()
    throws TrainingException, InterruptedException
  {
    // reset training-related state
    setTrained(false);
    dotCategory = null;
    weights = null;
    ccm = null;
    ccmInv = null;
    featuresUsed = null;

    enabledCategories = gestureSet.getEnabledCategories();
    int numCategories = enabledCategories.size();
    double[][][] covarMatrices = new double[numCategories][][];
    int numFeatures = featureClasses.length;
    meanFeatureValues = new double[numCategories][numFeatures];
    
    // compute all the covariance matrices (and mean feature vectors)
    // and check for dot category
    int gcNum = 0;
    for (Iterator iter = enabledCategories.iterator(); iter.hasNext();
	 gcNum++) {
      GestureCategory gestureCategory = (GestureCategory) iter.next();
      covarMatrices[gcNum] =
	computeCovarianceMatrix(gestureCategory, meanFeatureValues[gcNum]);
      if (gestureCategory.isDot()) {
	if (dotCategory == null) {
	  dotCategory = gestureCategory;
	}
	else {
	  throw new
	    TrainingException("Cannot discriminate the dot-like gestures " +
			      gestureCategory.getName() + " and " +
			      dotCategory.getName());
	}
      }
    }

    checkForInterrupt();
    
    // compute common (average) covariance matrix
    ccm = new double[numFeatures][numFeatures];
    double denominator = -numCategories;
    for (Iterator iter = enabledCategories.iterator(); iter.hasNext();) {
      GestureCategory gestureCategory = (GestureCategory) iter.next();
      denominator += gestureCategory.getEnabledChildren().size();
    }

    if (denominator <= 0)
      throw new TrainingException("Too few examples for set " +
				  gestureSet.getName());

    for (int i = 0; i < numFeatures; i++) {
      for (int j = i; j < numFeatures; j++) {
	double sum = 0;
	gcNum = 0;
	for (Iterator iter = enabledCategories.iterator(); iter.hasNext();
	      gcNum++) {
	  GestureCategory gestureCategory = (GestureCategory) iter.next();
	  sum += covarMatrices[gcNum][i][j];
	}
	sum /= denominator;
	ccm[i][j] = sum;
	ccm[j][i] = sum;
      }
    }

    checkForInterrupt();

    // invert the common covariance matrix
    ccmInv = new double[ccm.length][ccm.length];
    double det = Matrix.myInvert(ccm, ccmInv);
    // check if determinant is (nearly) zero and fix it if it is
    if (Math.abs(det) >= EPSILON) {
      // all features in use
      featuresUsed = new BitSet(numFeatures);
      for (int i = 0; i < numFeatures; i++)
	featuresUsed.set(i);
    }
    else {
      // try to fix it
      if (!fixClassifier(ccm, ccmInv)) {
	throw new
	  TrainingException("Cannot invert common covariance matrix " +
			    "(determinant=" + Double.toString(det) + ")");
      }
    }
    
    checkForInterrupt();

    // compute the weights
    weights = new double[enabledCategories.size()][numFeatures+1];
    gcNum = 0;
    for (Iterator iter = enabledCategories.iterator(); iter.hasNext();
	 gcNum++) {
      GestureCategory gestureCategory = (GestureCategory) iter.next();
      for (int j = 0; j < numFeatures; j++) {
	double sum = 0;
	for (int i = 0; i < numFeatures; i++) {
	  double mfv = meanFeatureValues[gcNum][i];
	  double temp = ccmInv[i][j];
	  sum += temp * mfv;
	}
	weights[gcNum][j+1] = sum;
      }
      // compute weights[0] differently
      double sum = 0;
      for (int i = 0; i < numFeatures; i++) {
	sum += weights[gcNum][i+1] * meanFeatureValues[gcNum][i];
      }
      weights[gcNum][0] = -0.5 * sum;
      // according to amulet code, could add log(priorprob
      // gestureCategory) to weights[gcNum][0]
    }

    checkForInterrupt();

    setTrained(true);
  } // train()

  protected boolean fixClassifier(double[][] ccm, double[][] ccmInv)
  {
    double det;
    double m[][], r[][];
    int numFeatures = featureClasses.length;

    // at start we're not using any
    featuresUsed = new BitSet(numFeatures);
    // add features one-by-one, discarding ones that cause the matrix
    // to be non-invertible
    for (int i = 0; i < numFeatures; i++) {
      featuresUsed.set(i);
      m = Matrix.slice(ccm, featuresUsed, featuresUsed);
      r = new double[m.length][m.length];
      det = Matrix.myInvert(m, r);
      if (Math.abs(det) <= EPSILON)
	featuresUsed.clear(i);
    }

    m = Matrix.slice(ccm, featuresUsed, featuresUsed);
    r = new double[m.length][m.length];
    det = Matrix.myInvert(m, r);
    if (Math.abs(det) <= EPSILON)
      return false;
    Matrix.deSlice(r, 0, featuresUsed, featuresUsed, ccmInv);
    return true;
  }

  /**
   * Determine which GestureCategory the Gesture is most likely a
   * member of, and return an appropriate Result.  Resturns null if
   * no GestureSet has been assigned, or if the GestureSet has no
   * members.
   */
  public synchronized Result classify(Gesture gesture)
    throws TrainingException, InterruptedException
  {
    if (!trained) {
      train();
    }
    return classifyWithoutTraining(gesture);
  }
  
  /** Only call this if you know the GestureSet the classifier is
      using hasn't changed since the last time classify() or train()
      was called.  See classify() for return value information. */
  public synchronized Result classifyWithoutTraining(Gesture gesture)
  {
    if ((gestureSet == null) || (gestureSet.size() == 0))
      return null;

    List enabledCategories = gestureSet.getEnabledCategories();

    // dot check stuff
    if (gesture.size() == 1) {
      if (dotCategory == null)
	return new Result(null, 1, 0);
      for (Iterator iter = enabledCategories.iterator(); iter.hasNext();) {
	GestureCategory gestureCategory = (GestureCategory) iter.next();
	if (gestureCategory == dotCategory)
	  return new Result(gestureCategory, 1, 0);
      }
      return new Result(null, 1, 0);
    }
    
    // Compute discriminant.  Higher disc -> higher probability that
    // it's the right category.
    int numCategories = enabledCategories.size();
    double disc[] = new double[numCategories];
    for (int catIndex = 0; catIndex < numCategories; catIndex++) {
      double sum = weights[catIndex][0];
      for (int featureNum = 0;
	   featureNum < featureClasses.length;
	   featureNum++) {
	Feature feature =
	  FeatureFactory.getFeature(featureClasses[featureNum], gesture);
	sum += weights[catIndex][featureNum+1] * feature.getValue();
      }
      disc[catIndex] = sum;
    }

    int bestGC = -1;
    int i = 0;
    GestureCategory bestCategory = null;
    for (Iterator iter = enabledCategories.iterator(); iter.hasNext();
	 i++) {
      GestureCategory category = (GestureCategory) iter.next();
      if (!category.isDot() &&
	  ((bestCategory == null) || (disc[i] > disc[bestGC]))) {
	bestGC = i;
	bestCategory = category;
      }
    }

    // calculate accuracy
    double denom = 0;
    for (i = 0; i < numCategories; i++) {
      // quick check to avoid computing negligible term
      double d = disc[i] - disc[bestGC];
      if (d > -7.0) {
	denom += Math.exp(d);
      }
    }

    // calculate distance to mean of chosen class
    double distToMean = distanceToCategory(gesture, bestGC);
					    
    return new Result(bestCategory, 1.0/denom, distToMean);
  }

  public List testRecognition(GestureContainer container)
    throws InterruptedException, TrainingException
  {
    return testRecognition(container.iterator());
  }
  
  /** iter should contain Gestures or GestureContainers.  returns the
      misrecognized Gestures.  If all are correctly recognized,
      returns an empty List. */
  public List testRecognition(Iterator iter)
    throws InterruptedException, TrainingException
  {
    return testRecognition(iter, true);
  }
  
  /** iter should contain Gestures or GestureContainers.  returns the
      misrecognized Gestures.  If all are correctly recognized,
      returns an empty List.  If onlyEnabled is true, skip
      GestureObjects that aren't enabled. */
  public List testRecognition(Iterator iter, boolean onlyEnabled)
    throws InterruptedException, TrainingException
  {
    List misrecognizedGestures = new ArrayList();
    for (int i = 0; iter.hasNext(); i++) {
      Object obj = iter.next();
      if ((obj instanceof GestureObject) &&
	  (!onlyEnabled || ((GestureObject) obj).isEnabled())) {
	if (obj instanceof Gesture) {
	  Gesture gesture = (Gesture) obj;
	  if (testRecognition(gesture)) {
	    misrecognizedGestures.add(obj);
	  }
	}
	else if (obj instanceof GestureContainer) {
	  GestureContainer container = (GestureContainer) obj;
	  misrecognizedGestures.addAll(testRecognition(container.iterator()));
	}
      }
      if (Thread.interrupted()) {
	throw new InterruptedException();
      }
    }
    return misrecognizedGestures;
  }

  /** return true iff the gesture was correctly recognized */
  public boolean testRecognition(Gesture gesture)
    throws InterruptedException, TrainingException
  {
    GestureCategory category = (GestureCategory) gesture.getParent();
    if (category == null) {
      throw new IllegalArgumentException("Gesture '" + gesture +
					 "' does not have a parent");
    }
    Result result = classify(gesture);
    /*
    System.out.println("TR:\t" + category.getName() + "\t" +
		       result.category.getName());
    */
    boolean isMisrecognized;
    if (result == null) {
      throw new
	TrainingException("Cannot classify without a training set");
    }
    else if ((result.category == null) ||
	     !Misc.areEqualOrNull(result.category.getName(),
				  category.getName())) {
      // misrecognition
      isMisrecognized = true;
      gesture.setProperty(MISRECOGNIZED_PROP, result);
    }
    else {
      isMisrecognized = false;
      gesture.unsetProperty(MISRECOGNIZED_PROP);
    }
    return isMisrecognized;
  }

  /** Return the square of the distance between the two categories
   *  (which must in the GestureSet).  If the classifier is not
   *  trained, it throws an IllegalStateException. */
  public double categoryDistance(GestureCategory categoryA,
				 GestureCategory categoryB)
  {
    if (!trained) {
      throw new IllegalStateException("Cannot call categoryDistance when classifier isn't trained.");
    }
    synchronized (this) {
      return categoryDistance(enabledCategories.indexOf(categoryA),
			      enabledCategories.indexOf(categoryB));
    }
  }

  /** Return the square of the distance between the two categories. If
   *  the classifier is not trained, it throws an
   *  IllegalStateException.*/
  public double categoryDistance(int categoryA, int categoryB)
  {
    if (!trained) {
      throw new IllegalStateException("Cannot call categoryDistance when classifier isn't trained.");
    }
    if (categoryA == categoryB)
      return 0.0;
    else
      synchronized (this) {
	return MahalanobisDistance(meanFeatureValues[categoryA],
				   meanFeatureValues[categoryB], ccmInv);
      }
  }

  public double distanceToCategory(Gesture gesture,
				   GestureCategory category)
  {
    return distanceToCategory(gesture, enabledCategories.indexOf(category));
  }

  public synchronized double distanceToCategory(Gesture gesture,
						int catIndex)
  {
    return MahalanobisDistance(FeatureFactory.getValues(featureClasses,
							gesture),
			       meanFeatureValues[catIndex]);
  }

  /** Use the weights for the category to get normalized distance of
      the gesture from the category.  This distance is not comparable
      with the mahalanobis distance (I don't think). */
  public double[] getNormalizedDistancesByFeature(Gesture gesture,
						  String categoryName)
  {
    for (Iterator iter = enabledCategories.iterator(); iter.hasNext();) {
      GestureCategory category = (GestureCategory) iter.next();
      if (category.getName().equals(categoryName)) {
	return getNormalizedDistancesByFeature(gesture, category);
      }
    }
    return null;
  }

  /** Use the weights for the category to get normalized distance of
      the gesture from the category.  This distance is not comparable
      with the mahalanobis distance (I don't think). */
  public double[] getNormalizedDistancesByFeature(Gesture gesture,
						  GestureCategory gc)
  {
    return getNormalizedDistancesByFeature(gesture,
					   enabledCategories.indexOf(gc));
  }

  /** Use the weights for the category to get normalized distance of
      the gesture from the category.  This distance is not comparable
      with the mahalanobis distance (I don't think).  categoryIndex is
      the index into the enabled classes that the classifier has. */
  public double[] getNormalizedDistancesByFeature(Gesture gesture,
						  int categoryIndex)
  {
    double[] catFeatureVals = meanFeatureValues[categoryIndex];
    double[] gFeatureVals = FeatureFactory.getValues(featureClasses,
						     gesture);
    int numFeatures = featureClasses.length;

    /*
    System.out.println("getNormalizedDistancesByFeature: ccmInv:");
    Matrix.prettyPrint(ccmInv);

    System.out.println("getNormalizedDistancesByFeature: gFeatureVals:");
    Matrix.prettyPrint(gFeatureVals);
    System.out.println("getNormalizedDistancesByFeature: catFeatureVals:");
    Matrix.prettyPrint(catFeatureVals);
    */
    
    double delta[] = new double[numFeatures];
    for (int i = 0; i < numFeatures; i++) {
      delta[i] = gFeatureVals[i] - catFeatureVals[i];
    }
    /*
    System.out.println("getNormalizedDistancesByFeature: delta:");
    Matrix.prettyPrint(delta);

    System.out.println("getNormalizedDistancesByFeature: intermediate values:");
    */
    double[] dist = new double[numFeatures];
    for (int featureNum = 0; featureNum < numFeatures; featureNum++) {
      dist[featureNum] = delta[featureNum] * weights[categoryIndex][featureNum+1];
    }

    /*
    System.out.println("getNormalizedDistancesByFeature: dist:");
    Matrix.prettyPrint(dist);
    */
    return dist;
  }

  /** Use the current weights to get normalized distances along each
      feature between two categories.  This distance is not comparable
      with the mahalanobis distance (I don't think).  catA and catB
      are indices into the enabled classes that the classifier has. */
  public double[] getDistancesByFeature(int catA, int catB)
  {
    int numFeatures = featureClasses.length;
    double delta[] = new double[numFeatures];
    for (int i = 0; i < numFeatures; i++) {
      delta[i] = meanFeatureValues[catA][i] - meanFeatureValues[catB][i];
    }
    return delta;
  }
  
  /** Returns an unmodifiable List of the categories that were used to
      train the classifier. */
  public synchronized List getTrainingCategories()
  {
    return Collections.unmodifiableList(enabledCategories);
  }
  
  /** Return the square of the distance between the two vectors. */
  public double MahalanobisDistance(double[] v, double[] u)
  {
    return MahalanobisDistance(v, u, ccmInv);
  }

  /** Return the square of the distance between the two vectors, using
   *  the specified dispersion matrix. */
  public static double MahalanobisDistance(double[] v, double[] u,
					   double[][] sigma)
  {
    double[] space;
    double result;

    space = new double[v.length];

    for (int i = 0; i < v.length; i++)
      space[i] = v[i] - u[i];
    result = Matrix.QuadraticForm(space, sigma);

    return result;
  }

  /** Return the index of the largest component of featureVals, using
      the current training weights.  (If all features were weighted
      equally, we'd be in normal Euclidean space and this would simply
      be the largest feature value.) */
  public int findPrincipleComponent(double[] featureVals)
  {
    int numFeatures = featureVals.length;
    double[] v = new double[numFeatures];
    double max = 0;
    int maxIndex = -1;
    for (int i = 0; i < numFeatures; i++) {
      if (i != 0) {
	v[i-1] = 0;
      }
      v[i] = featureVals[i];
      // could call MahalanobixDistance with v and an all-zero vector,
      // but this is more efficient
      double dist = Matrix.QuadraticForm(v, ccmInv);
      if (dist > max) {
	max = dist;
	maxIndex = i;
      }
    }
    return maxIndex;
  }

  public class FeatureDirection {
    public GestureObject a, b;
    public Class featureClass;
    /** -1 if a is < b (for featureClass), 1 if a > b, and 0 if they
        are equal. */
    public int direction;
  }
  
  /** Find the feature class on which catA and catB differ most (based
      on current weights).  catA and catB are the indices of
      categories in the current enabled categories list. */
  public FeatureDirection findPrincipleFeature(int catA, int catB)
  {
    int numFeatures = featureClasses.length;
    double maxDist = 0;
    int maxDistIndex = -1;
    int direction = 0;
    for (int i = 0; i < numFeatures; i++) {
      double delta =
	meanFeatureValues[catA][i] - meanFeatureValues[catB][i];
      double abs = Math.abs(delta);
      if (abs > maxDist) {
	maxDist = abs;
	maxDistIndex = i;
	direction = Misc.sign(delta);
      }
    }
    FeatureDirection result = new FeatureDirection();
    result.featureClass = featureClasses[maxDistIndex];
    result.a = (GestureCategory) enabledCategories.get(catA);
    result.b = (GestureCategory) enabledCategories.get(catB);
    result.direction = direction;
    return result;
  }
  
  
  /** Return the points of the ideal gesture example, given the name of the
      gesture. */
  public TimedPolygon getIdealGesturePoints(String gestureName) {
    // Simply return the points of the first example.
    return getGestureSet().getCategory(gestureName).gestureAt(0).getPoints();
  }
  
  // Does this method really belong in this class?
  /**
   * Classify all examples in a category.  If tally != null, record
   * how each gesture is classified.
   */
  /* todo
  public Result[] classifyExamples(GestureCategory gestureCategory,
				   Vector[] tally)
  {
    if (tally == null)
      throw new NullPointerException("tally must be non-null");
    
    //System.err.print(gestureCategory.getName() + "(" +
    //     gestureCategory.trainingSize() + "):\t");
    int exampleIndex = 0;
    Result[] result = new Result[gestureCategory.trainingSize()];
    for (Iterator iter = gestureCategory.iterator();
	 iter.hasNext();
	 exampleIndex++) {
      //System.err.print(" " + exampleIndex);
      Gesture g = (Gesture) iter.next();
      result[exampleIndex] = classify(g);
      if (result[exampleIndex] != null) {
	int gcIndex = result[exampleIndex].gcIndex;
	//GestureCategory gc = gestureSet.categoryAt(gcIndex);
	//System.err.print(" " + gc.getName());
	if (tally != null) {
	  if (tally[gcIndex] == null)
	    tally[gcIndex] = new Vector();
	  tally[gcIndex].addElement(g);
	}
      }
    }
    //System.err.println();

    return result;
  }
  */

  // Does this method belong in this class?
  /**
   * Return a matrix where A[Ci][Cj] is a Vector of category Ci
   * examples (i.e. Gestures) that are classified as Cj.
   */
  /* todo
  public Vector[][] classificationMatrix(GestureSet exampleSet)
  {
    int targetCategories = gestureSet.trainingSize();
    int exampleCategories = exampleSet.trainingSize();
    Vector[][] result = new Vector[exampleCategories][targetCategories];

    int row = 0;
    for (Enumeration enum = exampleSet.trainingElements();
	 enum.hasMoreElements();
	 row++) {
      GestureCategory gestureCategory =
	(GestureCategory) enum.nextElement();
      classifyExamples(gestureCategory, result[row]);
    }

    return result;
  }
  
  public Vector[][] classificationMatrix()
  {
    return classificationMatrix(gestureSet);
  }
  */

  //
  // debugging methods
  //
  
  public void dumpMFV(PrintStream out)
  {
    int width = FeatureVector.defaultSize();
    // output averages
    for (int gcNum = 0; gcNum < gestureSet.size(); gcNum++) {
      // average
      out.print("V " + width);
      for (int j = 0; j < width; j++) {
	out.print(" " + meanFeatureValues[gcNum][j]);
      }
      out.println();
    }
  }
  
  public void dump(PrintStream out)
  {
    int width = FeatureVector.defaultSize();
    // output averages and weights
    for (int gcNum = 0; gcNum < gestureSet.size(); gcNum++) {
      // average
      out.print("V " + width);
      for (int j = 0; j < width; j++) {
	out.print(" " + meanFeatureValues[gcNum][j]);
      }
      out.println();
      // weight
      out.print("V " + width);
      for (int j = 0; j < width; j++) {
	out.print(" " + weights[gcNum][j+1]);
      }
      out.println();
    }
    // output const parts of weights
    out.print("V " + gestureSet.size());
    for (int gcNum = 0; gcNum < gestureSet.size(); gcNum++) {
      out.print(" " + weights[gcNum][0]);
    }
    out.println();
    // output isDot for each category
    out.print("V " + gestureSet.size());
    for (int gcNum = 0; gcNum < gestureSet.size(); gcNum++) {
      GestureCategory gc = (GestureCategory) gestureSet.getChild(gcNum);
      out.print(" " + (gc.isDot() ? 1 : 0));
    }
    out.println();
    // output inverse of average covariance matrix
    out.println("M " + width + " " + width);
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < width; j++)
	out.print(" " + ccmInv[i][j]);
      out.println();
    }
    // dump a few gestures to make sure the points are getting read in
    // correctly
    Gesture g = (Gesture) ((GestureContainer) gestureSet.getChild(0)).
      getChild(0);
    g.dump(out);
  }

  public void dumpRelativeVariance(PrintStream out)
  {
    int nFeatures = FeatureVector.defaultSize();
    int nClasses = gestureSet.size();
    
    out.print("Relative variance: ");
    for (int i = 0; i < nFeatures; i++) {
      double sum = 0;
      double avg;
      for (int j = 0; j < nClasses; j++) {
	sum += meanFeatureValues[j][i];
      }
      avg = sum / nClasses;
      out.print(Misc.toString(ccm[i][i]/avg, 6) + " ");
    }
    out.println();
  }

  public void addPropertyChangeListener(PropertyChangeListener listener)
  {
    propChangeSupport.addPropertyChangeListener(listener);
  }

  public void addPropertyChangeListener(String propertyName,
					PropertyChangeListener listener)
  {
    propChangeSupport.addPropertyChangeListener(propertyName, listener);
  }

  public void removePropertyChangeListener(PropertyChangeListener listener)
  {
    propChangeSupport.removePropertyChangeListener(listener);
  }

  public void removePropertyChangeListener(String propertyName,
					   PropertyChangeListener listener)
  {
    propChangeSupport.removePropertyChangeListener(propertyName, listener);
  }

  protected class MyCollectionListener implements CollectionListener {
    public void elementChanged(CollectionEvent e)
    {
      /*
      System.out.println("Classifier got element change: " + e);
      */
      setTrained(false);
    }

    public void elementAdded(CollectionEvent e)
    {
      /*
      System.out.println("Classifier got element added: " + e);
      */
      setTrained(false);
    }

    public void elementRemoved(CollectionEvent e)
    {
      /*
      System.out.println("Classifier got element removed: " + e);
      */
      setTrained(false);
    }
  }

  protected class MyPropChangeListener implements PropertyChangeListener {
    public void propertyChange(PropertyChangeEvent e)
    {
      PropertyChangeEvent realEvent = Properties.getRootEvent(e);
      if ((realEvent.getPropertyName() == GestureContainer.CHILDREN_PROP) ||
	  (realEvent.getPropertyName() == GestureObject.ENABLED_PROP)) {
	// meaningful change, will have to retrain the classifier
	setTrained(false);
      }
      /*
      System.out.println("Classifier got prop change: " +
			 realEvent.getPropertyName() + "\t" +
			 realEvent.getOldValue() + "\t" +
			 realEvent.getNewValue());
      */
    }
  }
}
