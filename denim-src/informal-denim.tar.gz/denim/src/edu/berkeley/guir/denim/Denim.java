package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.dialogs.*;
import edu.berkeley.guir.denim.io.SaveOutput;
import edu.berkeley.guir.lib.satin.objects.Style;
import java.awt.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

/** 
 * The Denim application. See the
 * <a href="http://guir.berkeley.edu/projects/denim/">Denim</a> project page
 * for details.
 * <P>
 * <IMG SRC="{@docroot}/img/denim-1.jpg"><BR>
 * <IMG SRC="{@docroot}/img/denim-2.jpg"><BR>
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-11-1999 James Lin
 *                               Created Denim
 *                    08-21-1999 James Lin
 *                               Split Denim into Denim and DenimWindow
 *             1.0.1  03-07-2003 Yang Li
 *                               Added automatic detection for TabletPC platform
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 *
 * @since   JDK 1.2
 * @version Version 1.0.0, 03-07-2003
 */
public class Denim implements DenimConstants {

   private static JProgressBar progressBar;
   private static java.util.List windows = new LinkedList();
   
   public static int runningOnTablet = 0;
   public static int runningOnWindows = 1;
   public static int runningOnMac = 2;
   public static int runningOnOthers = 3;

   // Shelley and Peter
   // The flag indicating a customer's preference -- either webApps or mobilApp
   public static boolean isMobile = false;
   
   private static int platformState = runningOnWindows;
   
   // Shelley and Peter
   // Let the default device be DESKTOP
   //private static DeviceType myDeviceType = DeviceType.SMARTPHONE;
   private static DeviceType myDeviceType = DeviceType.DESKTOP;
   
   // Shelley and Peter
   // The flag indicationg whether a customer is a first time user.
   public static boolean isFirstTimeUser = false;
   
   public static final long startTimeStamp = System.currentTimeMillis();


   static public String autoSaveFileStr = null;
	
   /**
    * Returns the path of the Denim application.
    *
    * This relies on the user starting Denim from Denim's path. So it's
    * not general, but it'll work for now.
    * Then again, Denim is making this assumption everywhere.
    */
   public static String getPath() {
      return System.getProperty("user.dir");
   }

   //-----------------------------------------------------------------
   
   public static int getPlatformState() {
      return Denim.platformState;
   }
   
   // Shelley and Peter
   // return "this" DENIM application type
   public static DeviceType getDeviceInfo() {
      return myDeviceType;
   }
   
   //-----------------------------------------------------------------

   public static void updateSplashWindow(int percent, String message) {
      progressBar.setValue(percent);
      progressBar.setString(message);
   }

   //-----------------------------------------------------------------

   private static JWindow getSplashWindow(Dimension dim) {
      JWindow splash = new JWindow();

      Icon icon = new ImageIcon(Denim.class.getResource("images/newsplash.gif"));
      JLabel iconLabel = new JLabel(icon);

      Container contentPane = splash.getContentPane();

      Insets insets = contentPane.getInsets();
      JLayeredPane layeredPane = new JLayeredPane();
      layeredPane.setPreferredSize
         (new Dimension(icon.getIconWidth(), icon.getIconHeight()));

      splash.setBounds((dim.width - icon.getIconWidth()) / 2,
                       (dim.height - icon.getIconHeight()) / 2,
                       icon.getIconWidth(), icon.getIconHeight());
      iconLabel.setBounds(insets.left,
                          insets.top,
                          icon.getIconWidth(),
                          icon.getIconHeight());
      layeredPane.add(iconLabel, new Integer(0));

      // Put build date in splash screen
      JLabel versionlabel = new JLabel(DenimConstants.BUILD_VER) {
          public void paintComponent(Graphics g) {
              ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
              super.paintComponent(g);
              ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
          }
      };
      versionlabel.setFont(new Font(null, Font.BOLD, 18));
      layeredPane.add(versionlabel, new Integer(1));
      versionlabel.setForeground(Color.black);
      versionlabel.setBackground(Color.white);
      versionlabel.setOpaque(true);
      versionlabel.setBounds(365 - versionlabel.getPreferredSize().width, 74,
              versionlabel.getPreferredSize().width,
              versionlabel.getPreferredSize().height);

      JLabel buildLabel = new JLabel(BUILD_STR) {
          public void paintComponent(Graphics g) {
              ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
              super.paintComponent(g);
              ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
          }
      };
      
      layeredPane.add(buildLabel, new Integer(1));
      buildLabel.setForeground(Color.black);
      buildLabel.setBackground(Color.white);
      buildLabel.setOpaque(true);
      buildLabel.setBounds(365 - buildLabel.getPreferredSize().width, 100,
                           buildLabel.getPreferredSize().width,
                           buildLabel.getPreferredSize().height);
      
      JLabel buildLabel1 = new JLabel("Copyright (c) 2004-2007 by the Regents of the University of Washington.") {
          public void paintComponent(Graphics g) {
              ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
              super.paintComponent(g);
              ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
          }
      };
      
      buildLabel1.setFont(new Font(null, Font.PLAIN, 10));
      layeredPane.add(buildLabel1, new Integer(1));
      buildLabel1.setForeground(Color.black);
      buildLabel1.setBackground(Color.white);
      buildLabel1.setOpaque(true);
      buildLabel1.setBounds(22, 130,
                           buildLabel1.getPreferredSize().width,
                           buildLabel1.getPreferredSize().height);

      
      JLabel buildLabel2 = new JLabel("Copyright (c) 1999-2003 by the Regents of the University of California.") {
          public void paintComponent(Graphics g) {
              ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
              super.paintComponent(g);
              ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
          }
      };
      
      buildLabel2.setFont(new Font(null, Font.PLAIN, 10));
      layeredPane.add(buildLabel2, new Integer(1));
      buildLabel2.setForeground(Color.black);
      buildLabel2.setBackground(Color.white);
      buildLabel2.setOpaque(true);
      buildLabel2.setBounds(22, 145,
                           buildLabel2.getPreferredSize().width,
                           buildLabel2.getPreferredSize().height);

      
      JTextArea buildLabel3 = new JTextArea() {
          public void paintComponent(Graphics g) {
              ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
              super.paintComponent(g);
              ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
          }
      };
      
      buildLabel3.setText("This program is distributed under the Berkeley Software License as" + "\n" + 
      "described in Help About.");
      buildLabel3.setFont(new Font(null, Font.PLAIN, 10));
      layeredPane.add(buildLabel3, new Integer(1));
      buildLabel3.setForeground(Color.black);
      buildLabel3.setBackground(Color.white);
      buildLabel3.setOpaque(true);
      buildLabel3.setBounds(22, 165,
                           buildLabel3.getPreferredSize().width,
                           buildLabel3.getPreferredSize().height);

      // Make sure the user has a name
      String user = DenimUserProperties.get(PROP_USER);
      if (user == null) {
         user = JOptionPane.showInputDialog
            (null,
             "Please enter your name.\nThis will be used for identifying your design documents.",
             "Denim",
             JOptionPane.QUESTION_MESSAGE);
         DenimUserProperties.set(PROP_USER, user);
         DenimUserProperties.save();
      }

      // Put welcome message in splash screen
      JLabel userLabel = new JLabel("Welcome, " + user);
      layeredPane.add(userLabel, new Integer(2));
      userLabel.setForeground(Color.black);
      userLabel.setBackground(Color.white);
      userLabel.setOpaque(true);
      userLabel.setBounds(26, 205,
                          userLabel.getPreferredSize().width,
                          userLabel.getPreferredSize().height);

      // Display Progress bar
      progressBar = new JProgressBar(0, 100);
      if (System.getProperty("os.name").equals("Mac OS X")) {
         progressBar.setBackground(Color.white);
      }
      progressBar.setValue(0);
      progressBar.setString("");
      progressBar.setStringPainted(true);
      progressBar.setOpaque(true);
      progressBar.setBounds(26, 205 + 2*userLabel.getPreferredSize().height,
                            icon.getIconWidth() - 52,
                            progressBar.getPreferredSize().height);
      layeredPane.add(progressBar, new Integer(3));

      contentPane.add(layeredPane);
      return splash;
   }

   //-----------------------------------------------------------------

   /**
    * Returns all of the application windows of DENIM.
    */
   public static java.util.List getWindows() {
      return windows;
   }

   //-----------------------------------------------------------------

   //-----------------------------------------------------------------

   // added by Shelley and Peter 
   /**
    * Asks user to choose one of application types
    */
   public static void showDialog(DenimWindow f) {
      
        //Custom button text
     Object[] options = {"Mobile Phone Applications",
                         "Web Applications"};
     int n = JOptionPane.showOptionDialog(f,
            "What kind of application do u use DENIM for?" +
            "\nNote: This will be the default setting for your future designs",
            "Choose Application Type",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);

     // Shelley and Peter
     if (n == JOptionPane.YES_OPTION) {    // go to mobile design mode  
        isMobile = true;
        System.out.println("yes yes yes.");
        
     } else if (n == JOptionPane.NO_OPTION) {      // go to web design mode
        System.out.println("no no no.");
      
     } else {     // in case users just close the window
        showDialog (f);
        System.out.println("hahahahha.");
     }
   }
   //-----------------------------------------------------------------


   /**
    * Creates and shows a new DENIM window.
    */
   public static DenimWindow createWindow(int x, int y,
                                          int width, int height) {
      // Construct and show the DENIM window
      DenimWindow win = new DenimWindow(false);
      win.addNotify();
      Insets insets = win.getInsets();
      windows.add(win);
      win.initAfterConstruction();
      
      win.setLocation(x, y);
      win.setSize(width /* - insets.left - insets.right*/,
                  height /* - insets.top - insets.bottom*/);
                  
      win.setVisible(true);
      
      // Construct the radar view window and put it in the lower right-
      // hand corner. Show it by default or if the user's preferences
      // say so.
      JDialog radarViewWindow = win.getRadarViewWindow();
      insets = radarViewWindow.getInsets();
      radarViewWindow.setLocation(
         win.getX() + win.getWidth() -
            radarViewWindow.getWidth() - insets.left - insets.right,
         win.getY() + win.getHeight() -
            radarViewWindow.getHeight() - insets.top - insets.bottom);
      
      String showRadarViewStr =
         DenimUserProperties.get(DenimConstants.PROP_IS_RADAR_VIEW_VISIBLE);
      boolean showRadarView;
      
      if (showRadarViewStr == null) {
         showRadarView = true;
      }
      else {
         showRadarView = Boolean.valueOf(showRadarViewStr).booleanValue();
      }
      
      if (showRadarView) {
         radarViewWindow.setVisible(true);
      }
      win.toFront();
      
      
      // Shelley and Peter 
      //if (isFirstTimeUser == false) {
      String user = DenimUserProperties.get(PROP_USER);
      if (user == null) 
      {
         System.out.println("I am in isFirstTimeUser.");
      // create a dialog box
      //  Frame f = new Frame();
        showDialog(win);
        
        // set the flag
        isFirstTimeUser = true;
      }
      

      return win;
      
            
   }

   //-----------------------------------------------------------------

   /**
    * Saves the location and size of the given Denim window, and whether
    * the radar view is visible to user's preferences.
    */
   private static void saveWindowInfo(DenimWindow win) {
      DenimUserProperties.set(
         DenimConstants.PROP_WINDOW_X, Integer.toString(win.getX()));
      DenimUserProperties.set(
         DenimConstants.PROP_WINDOW_Y, Integer.toString(win.getY()));
      DenimUserProperties.set(
         DenimConstants.PROP_WINDOW_WIDTH, Integer.toString(win.getWidth()));
      DenimUserProperties.set(
         DenimConstants.PROP_WINDOW_HEIGHT,
         Integer.toString(win.getHeight()));
      DenimUserProperties.set(
         DenimConstants.PROP_IS_RADAR_VIEW_VISIBLE,
         Boolean.toString(win.getRadarViewWindow().isVisible()));
      
      // options
      DenimUserProperties.set(
      	 DenimConstants.PROP_OPTION_AUTOSAVE,
      	 Boolean.toString(AutoSaver.isAutoSaveEnabled));
      	 
	DenimUserProperties.set(
	   DenimConstants.PROP_OPTION_AUTOSAVE_INTERVAL,
	   Long.toString(AutoSaver.autoSaveInterval));
/*
	DenimUserProperties.set(
	   DenimConstants.PROP_OPTION_PAGE_WIDTH,
	   Integer.toString(DenimSketch.getDefaultSketchWidth()));

	DenimUserProperties.set(
	   DenimConstants.PROP_OPTION_PAGE_HEIGHT,
	   Integer.toString(DenimSketch.getDefaultSketchHeight()));
*/
	DenimUserProperties.set(
	   DenimConstants.PROP_OPTION_GRID,
	   Boolean.toString(DenimSketch.isGridOn()));

	DenimUserProperties.set(
	   DenimConstants.PROP_OPTION_GRID_HGAP,
	   Double.toString(DenimSketch.getGridH()));

	DenimUserProperties.set(
	   DenimConstants.PROP_OPTION_GRID_VGAP,
	   Double.toString(DenimSketch.getGridV()));

    // global fonts
    DenimUserProperties.set(
           DenimConstants.GLOBAL_FONT1,
           TextInsertDialog.globalfont1);
    DenimUserProperties.set(
            DenimConstants.GLOBAL_FONT2,
            TextInsertDialog.globalfont2);
    DenimUserProperties.set(
            DenimConstants.GLOBAL_FONT3,
            TextInsertDialog.globalfont3);    

      DenimUserProperties.save();
   }

   //-----------------------------------------------------------------

   /**
    * Stops keeping track of the given DENIM window.
    */
   public static void removeWindow(DenimWindow win) {
      windows.remove(win);
      if (windows.isEmpty()) {
         // Since the last window was closed, save its location and size to
         // user's prefs. Also save whether the radar view is visible.
         saveWindowInfo(win);
         exit(0);
      }
   }
   



   //-----------------------------------------------------------------

   /**
    * Tries exiting DENIM, first prompting the user to save any
    * unsaved designs.
    */
   public static void tryExit() {
      boolean wantsToQuit = true;
      Iterator it = windows.iterator();
      while (it.hasNext()) {
         DenimWindow win = (DenimWindow)it.next();
         if (win.getDenimUI().getSheet().getPieMenu().promptSaveBeforeExiting()
             == false) {
            wantsToQuit = false; 
            break; 
         }
         if (!it.hasNext()) {
            saveWindowInfo(win);
         }
      }
      if (wantsToQuit) {
         Denim.exit(0);
      }
   }

   //-----------------------------------------------------------------

   /**
    * Quits DENIM.
    */
   public static void exit(int code) {
      SaveOutput.stop();
      System.exit(code);
   }

   //-----------------------------------------------------------------

   public static void main(String[] args) {
      
      // detect Platform
      
      if(System.getProperty("os.name").startsWith("Windows"))
      {
         File file = new File("c:" + File.separator + "tablet.inf");
   
         if(file.exists())
         {
            Denim.platformState = Denim.runningOnTablet;
         }
         else
         {
            Denim.platformState = Denim.runningOnWindows;
         }
      }      
      else if(System.getProperty("os.name").startsWith("Mac"))
      {
         Denim.platformState = Denim.runningOnMac;
      }
      else
      {
         Denim.platformState = Denim.runningOnOthers;
      }
      
	  Denim.autoSaveFileStr = System.getProperty("user.dir");
	  Denim.autoSaveFileStr += "denimautosave.dnm";
		
	  // Log stdout and stderr to file, if possible
      try 
      {
         SaveOutput.start(DenimUserProperties.getUserDirectory() +
                          File.separator + ERRLOG_STR);
      }
      catch (IOException e) 
      {
         System.err.println("Cannot log errors");
         e.printStackTrace();
      }

      // Set the base class of Style to this class, so that when
      // style files are loaded, they are loaded relative to this
      // class.
      Style.setPropertiesBaseLocation(Denim.class);

      // Display the splash window
      Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

      JWindow splash = getSplashWindow(dim);
      splash.setVisible(true);

      // Construct and show the DENIM window
      int x = 0;
      int y = 0;
      int width = dim.width;
      int height = dim.height;
      
      //// If the user's preferences file already has settings
      //// for the window's size and location, use them.
      try {
         String xStr =
            DenimUserProperties.get(DenimConstants.PROP_WINDOW_X);
         String yStr =
            DenimUserProperties.get(DenimConstants.PROP_WINDOW_Y);
      
         if ((xStr != null) && (yStr != null)) {
            x = Integer.parseInt(xStr);
            y = Integer.parseInt(yStr);
         }
      }
      catch (NumberFormatException ex) {
      }
      
      try {
         String widthStr =
            DenimUserProperties.get(DenimConstants.PROP_WINDOW_WIDTH);
         String heightStr =
            DenimUserProperties.get(DenimConstants.PROP_WINDOW_HEIGHT);
      
         if ((widthStr != null) && (heightStr != null)) {
            width = Integer.parseInt(widthStr);
            height = Integer.parseInt(heightStr);
         }
      }
      catch (NumberFormatException ex) {
      }

      DenimWindow win = createWindow(x, y, width, height);
      Denim.updateSplashWindow(100, "Done");

      splash.setVisible(false);

      // If the first argument is a file, open it
      if (args.length == 1) {
         DenimSheet sheet = win.getDenimUI().getSheet();
         try {
            File newFile = new File(args[0]);
            sheet.disableDamage();
            sheet.clear();
            sheet.open(newFile);
            File parentDir = newFile.getAbsoluteFile().getParentFile();
            sheet.getPieMenu().setCurrentProjectDirectory(parentDir);
         }
         catch (Exception e) {
            JOptionPane.showMessageDialog(sheet,
                                          "Cannot open " + args[0] + ": " +
                                          e.getMessage(),
                                          "File failed to open",
                                          JOptionPane.ERROR_MESSAGE);
            win.setBusy(false); // try to continue with no open file.
         }
         sheet.enableDamage();
         
         sheet.getRenderServer().setSceneGraphChanged(true);
         sheet.damage(DAMAGE_LATER);
         sheet.damage(DAMAGE_NOW);
         
      }

      // Load up handlers for Macintosh (ignored for other platforms)
      DenimMacHandlers h = new DenimMacHandlers();

 /*     RadarViewPanel radarView = new RadarViewPanel();
      radarView.setSheet(win.getDenimUI().getSheet());
      radarView.setPreferredSize(new Dimension(200, 200));
      radarView.setBackground(win.getDenimUI().getSheet().getBackground());

      //added by Shen
      JFrame radarViewFrame = new JFrame("Radar View");
      radarViewFrame.setLocation(500, 200);
      radarViewFrame.setSize(200,200);
      radarViewFrame.getContentPane().add(radarView);
      radarViewFrame.setVisible(true);
      win.getDenimUI().setRadarViewFrame(radarViewFrame);
*/
	  /**
	   * loading options
	   */

	  // autosave
	  String str = DenimUserProperties.get(
								DenimConstants.PROP_OPTION_AUTOSAVE);
	  if(str!=null)
	  {
	  	 if(str.trim().equalsIgnoreCase("true"))
	  	 	AutoSaver.isAutoSaveEnabled = true;
	  	 else
			AutoSaver.isAutoSaveEnabled = false;
	  }

	  str = DenimUserProperties.get(
		   DenimConstants.PROP_OPTION_AUTOSAVE_INTERVAL);
	  if(str!=null)
		 AutoSaver.autoSaveInterval = Long.parseLong(str);
	/*
	  // default page size
	  str = DenimUserProperties.get(
				DenimConstants.PROP_OPTION_PAGE_WIDTH); 
	  if(str!=null)
	     DenimSketch.setDefaultSketchWidth(Integer.parseInt(str));
	
	  str = DenimUserProperties.get(
	   			DenimConstants.PROP_OPTION_PAGE_HEIGHT);
	  if(str!=null) 			
	  	 DenimSketch.setDefaultSketchHeight(Integer.parseInt(str));
	*/
	  // grid
	  str = DenimUserProperties.get(
	  			DenimConstants.PROP_OPTION_GRID);
	  if(str!=null)
	  {
	  	  if(str.trim().equalsIgnoreCase("true"))
	  	  	DenimSketch.setGridOn(true);
	  	  else
	  	  	DenimSketch.setGridOn(false);  
	
		  str = DenimUserProperties.get(
		   			DenimConstants.PROP_OPTION_GRID_HGAP);
		  double hgap = Double.parseDouble(str);
		  str = DenimUserProperties.get(
					DenimConstants.PROP_OPTION_GRID_VGAP);  
		  double vgap = Double.parseDouble(str);
		  
		  DenimSketch.setGrid(hgap, vgap);
	  }
	  
	  win.getDenimUI().getSheet().grabFocus();
   }
}

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
