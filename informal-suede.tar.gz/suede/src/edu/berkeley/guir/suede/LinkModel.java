package edu.berkeley.guir.suede;

import javax.sound.sampled.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.awt.*;
import java.util.*;

/*
 *Things that must be changed for model/viewer rewrite:
 *
 * - Make this a subclass of AbstNodeModel.
 * - play, record and save functions are handled by new superclass
 *
 * - remove m_slink variable, and references in init(), setPlayable(), setCaption(), getView(), \
 *      setDesign/AnalysisView(), removeNode(), play(), record, callmeWhenDoneplaying().
 *      - audio methods will be handled in superclass
 *      - Model shouldn't have anything to do with switching between design/analysis.
 *      - BUT: maybe we need a subclass of LinkModel that handles analysis link models (since they hold more data than design links.)
 * - Do we need addBalloonOnwer()?
 * - m_testResponses shouldn't hold TranscriptNodeModels (that class is being removed anyway.) Instead maybe LinkModel class is
 *      for design view and there is a subclass, AnalysisLinkModel that has a vector of regular LinkModels.
 *
 *
 *
 */


/**
 * @com.register ( clsid=0AE46EDD-1FEE-4F57-9169-55B04236443D, typelib=72CBA943-09C6-4D50-B499-8E18FC928942 )
 */
public class LinkModel extends AbstNodeModel implements ActionListener, DocumentListener {
   private static final int     LINK_LENGTH     = 100;
   private static final boolean DEBUG = false;

   protected SuedeModel        m_model;  
   private   String            m_label;        // an internal identifier for the SLinkCard
   private   AbstLinkView      m_slink;
   private   AbstNodeModel     m_cardOrig;     // origin
   private   AbstNodeModel     m_cardDest;     // destination
   private   SContentPane      m_contentPane;
   private   String            m_caption       = ""; // the text the user has entered
   private   Point             m_sourcePt      = new Point();
   private   Point             m_targetPt      = new Point();
   private   CallbackIF        m_callback      = null;
   private   Vector            m_testResponses = new Vector(); //all of the user responses for this link; of type TranscriptNodeModel
   private   LCallWhenFinished m_cwf           = new LCallWhenFinished();  
   private   CardSound         m_cardSound     = new CardSound((EndPlayCallbackIF)m_cwf, (EndRecordCallbackIF)m_cwf);  // this stores the audio
   private   Vector            m_ballOwners    = new Vector();
   private   boolean         m_alreadyhasaudio = true;  // this is a temporary fix to keeping track of whether are off by one in the displays of the multiple test audios.
   private   SSavableElt  m_balloonCallingNode = null; //a node that is asking this link to play audio as part of a balloon

    private double m_pauseDuration = 0;
	
   //New contructor that instantiates based on a visual feedback link's parameters
   public LinkModel(SuedeModel model, SContentPane pane, String label, SFeedbackLink fbl ) {
      Component c = pane.getComponentAt(fbl.getStartX(), fbl.getStartY());
      m_sourcePt = new Point(fbl.getStartX(), fbl.getStartY());
    
      if (c instanceof AbstNodeView) {
         m_cardOrig = ((AbstNodeView)c).getNodeModel();

         if (m_cardOrig.getLabel().equalsIgnoreCase("START")) {
            for (int i = 0; i < model.getNumLinkModels(); i++) {
               LinkModel link = model.getLinkModel(i);
               if (link !=null && link.getDestinationCard() != null &&  
                  (link.getOriginCard()).getLabel().equalsIgnoreCase("START")) {
                  model.deleteLinkModel(link);
               }
            }
         }
      } 
      else {
         m_cardOrig = null;
      }

      c = pane.getComponentAt(fbl.getFinishX(), fbl.getFinishY());    
      m_targetPt = new Point(fbl.getFinishX(), fbl.getFinishY());
      if (c instanceof AbstNodeView) {
         m_cardDest = ((AbstNodeView)c).getNodeModel();
      }
      else {
         m_cardDest = null;
      }
    
      m_label = label;
    
    
      //System.out.println("LinkModel constructor one");
      init(model, pane);
   }
  
   //end new constructor
  
  /**
   * Constructor2
   */
  public LinkModel(SuedeModel model, SContentPane pane, String label, AbstNodeModel orig, 
                                                                       AbstNodeModel dest) {
     m_label = label;
     m_cardOrig = orig;
     m_cardDest = dest;   
    
     if (m_cardDest !=null) {
        m_targetPt = new Point(m_cardDest.getCenter());
     }

     m_sourcePt = (m_cardOrig!=null) ? new Point(m_cardOrig.getCenter()) : 
                                      new Point(m_targetPt.x, m_targetPt.y - LINK_LENGTH);

     //System.out.println("LinkModel constructor two");
     init(model, pane);
  }  
  
  /**
   * Constructor3
   */
  public LinkModel(SuedeModel model, SContentPane pane, String label, AbstNodeModel orig) {
     m_cardOrig = orig;
     m_cardDest = null;  
     m_label = label;

     m_sourcePt = new Point(m_cardOrig.getCenter());
     m_targetPt = new Point(m_sourcePt.x, m_sourcePt.y + LINK_LENGTH);
    
     //System.out.println("LinkModel constructor three");
     init(model, pane);
  }
  
  /**
   * Constructor4
   */
  public LinkModel(SuedeModel model, SContentPane pane, String label, Point p) {
     m_cardOrig = null;
     m_cardDest = null;    
     m_label = label;

     m_sourcePt = new Point(p.x, p.y - LINK_LENGTH/2);
     m_targetPt = new Point(p.x, p.y + LINK_LENGTH/2);
    
     //System.out.println("LinkModel constructor four");
     init(model, pane);
  }    
  
  
  private void init(SuedeModel model, SContentPane pane) {
     m_model = model;   m_contentPane = pane;
     m_slink = new DesignLinkView(m_model, this, pane);
     m_slink.addLinkToPane();
     setPlayable(false);
  }
   
  public void setPlayable(boolean b) {
     //System.out.println("setting playable to: "+b);
     m_slink.setPlayable(b);
  }

  public synchronized boolean hasAudio() { 
     return m_cardSound.isAvailable(); 
  }

  // these three Update methods update the view whenever the text changes
  public void changedUpdate(DocumentEvent e) {
     try { 
        m_caption = e.getDocument().getText(0, e.getDocument().getLength());
     } 
     catch (Exception err) { 
        throw new Error(err.toString()); 
     }
  }
  
  public void insertUpdate(DocumentEvent e) {
     try { 
        m_caption = e.getDocument().getText(0, e.getDocument().getLength());
     } 
     catch (Exception err) { 
        throw new Error(err.toString());
     }
  }
  

  public void removeUpdate(DocumentEvent e) {
     try {
        m_caption = e.getDocument().getText(0, e.getDocument().getLength());
     } 
     catch (Exception err) { 
        throw new Error(err.toString()); 
     }
  }

  public void setOriginCard(AbstNodeModel orig) {
     m_cardOrig = orig;
  }
 

  public void setDestinationCard(AbstNodeModel dest) {
     m_cardDest = dest;
  }
  
  public AbstNodeModel getOriginCard() {
     return m_cardOrig;
  }
  
  public AbstNodeModel getDestinationCard() {
     return m_cardDest;
  }
  
  public AbstLinkView getLinkView() {
     return m_slink; 
  }
  
  public AbstNodeView getView() {
     return null;
  }
  
  public boolean isOperable(Point p) {
     return false;
  }
  
  public void expand() {}
 
  public void consDefault() {}
  
  public void collapse() {}
  
  public String getGroupName() {
     return "";
  }
  
  /**
   * Keeps track of all the balloons that this link is embedded in;
   * If this link is ever deleted, it needs to remove itself 
   * from all of those nodes.
   */
   public void addBalloonOwner(SingleNodeModel nodeModel) {
      m_ballOwners.add(nodeModel);  
   }
  
  
   public void setDrawBalloon(boolean draw) {
      getLinkView().setDrawBalloon(draw);
   }
  
  
  public boolean getDrawBalloon() {
     if (hasSource()) 
        return m_cardOrig.getDrawBalloon();
     return true;
  }
  
  public boolean hasSource() {
     return m_cardOrig!=null; 
  }
  
  public boolean hasTarget() {
    return m_cardDest!=null; 
  }
  
  public Vector getHits() {
     return m_testResponses;
  }
  
  public void addTestResponse(TranscriptNodeModel scriptNode) {
	  m_testResponses.add(scriptNode);
  }
  
  /* updates the pop-up menu with the user's response */
  public void addUserResponse(TranscriptNodeModel scriptNode) {
     getLinkView().addUserResponse(scriptNode.getMenuName(), new PlayMenuListener(scriptNode)); //update the popup menu
  }
  
  
  public double getAverageResponseLength() {
     if (m_testResponses.size()==0) return CardSound.NO_AUDIO;
     
     double totalLength =0;
     for (int i=0; i<m_testResponses.size(); i++) {
        totalLength += ((TranscriptNodeModel)m_testResponses.get(i)).getDuration();
     }

     return totalLength/m_testResponses.size();
  }

  
  // the caption is the user visible name for the link
  // the label is the system name for the link
  
    public String getCaption() {
	return m_caption;
    }
    
    /**
     * Special consideration must be taken for <> so that they can be saved and 
     * loaded properly.
     */
    public String getCleanedCaption() {
	String temp_caption = m_caption;
	
	for (int i = 0; i < temp_caption.length(); i++) {
	    if (temp_caption.charAt(i) == '<') {
		temp_caption = temp_caption.substring(0, i) + "&lt;" + temp_caption.substring(i+1);
		i+=3;
	    }
	    else if (temp_caption.charAt(i) == '>') {
		temp_caption = temp_caption.substring(0, i) + "&gt;" + temp_caption.substring(i+1);
		i+=3;
	    }
	}
	//temp_caption = temp_caption.replace('<', '[');
	//temp_caption = temp_caption.replace('>', ']');
	//System.out.println("GET CLEANED-CAPTION: " + temp_caption);
	
	return temp_caption;
    }
    
  public void setCaption(String caption) {
      //System.out.println("SETCAPTION: " + caption);
      m_caption = caption;
      m_slink.setCaption(caption);
  }
  
  public String getLabel() {
    return m_label;
  }
  
  public void setLabel(String label) {
    m_label = label;
  }
  
  public double getPauseDuration() {
    return m_pauseDuration;
  }
  
  public void setPauseDuration(double pause) {
    m_pauseDuration = pause;
  }
  
  public AbstNodeView getSourceView() {
     if (m_cardOrig == null)
        return null;
     return m_cardOrig.getView(); 
  }
  
  public AbstNodeView getTargetView() {
    return (m_cardDest!=null) ? m_cardDest.getView() : null; 
  }
  
  public String getNodeLabel() {
     if (m_cardOrig != null) {
      //System.out.println("the name that should go inside the card is "+m_cardOrig.getAsciiName());
      return m_cardOrig.getAsciiName();
    } 
    return "";  // if the origin is null return ""
  }
  
  public void setDesignView() {
     if (m_slink instanceof AnalysisLinkView) { // we only need to switch views if it's the wrong view
        m_slink.removeLinkFromPane();
        m_slink = new DesignLinkView(m_model, this, m_contentPane); 
        m_slink.addLinkToPane();
     }
  }
  
  public void setAnalysisView() {
     if (m_slink instanceof DesignLinkView) { // we only need to switch views if it's the wrong view
        m_slink.removeLinkFromPane();
        m_slink = new AnalysisLinkView(m_model, this, m_contentPane); 
        m_slink.addLinkToPane();
        updateTestResponses();
     }
  }
  
  private void updateTestResponses() {
     getLinkView().clearUserResponses();
     for (int i=0; i<m_testResponses.size(); i++) {
        TranscriptNodeModel scriptNode = (TranscriptNodeModel)m_testResponses.get(i);
        getLinkView().addUserResponse(scriptNode.getMenuName(), new PlayMenuListener(scriptNode)); //update the popup menu
     }
  }
  
  // need to do this to get the last added audio as the audio for this
  // link, in case it is used as a bubble
  public synchronized AudioInputStream getAudio() {
     return m_cardSound.getAudio();
  }

  public void setCallback(CallbackIF tocall) {
     m_callback = tocall;
  }
  
  public synchronized void setAudio(AudioInputStream ais) {
     //if(ais!=null)
     //System.out.println("set audio being called with " + ais.toString());
     m_cardSound.setAudio(ais);
     setPlayable(ais!=null);
  }
  
  
  public void fillAudio(String filename) {
     java.io.File fl = new java.io.File(filename);
     if (DEBUG) { System.out.println("can I read this file? " + fl.canRead()); }
     if (fl.canRead()) {
        m_cardSound.createAudioInputStream(fl, true);
     }
     setPlayable(m_cardSound.isAvailable()); 
  }


  public boolean isGlobal() {
    if (m_cardOrig == null) {
      return true;
    }
    return false;
  }
  
  
  public boolean isTerminal() {
     if (m_cardDest == null) {
        return true;
     }
     return false;
  }
  
  
  // delete this object and remove it from any places its a balloon
  public void removeNode() {
     java.awt.Container p = m_slink.getParent();
     m_slink.getArrowhead().getParent().remove(m_slink.getArrowhead());      
     m_slink.getArrowtail().getParent().remove(m_slink.getArrowtail()); 
     m_slink.getParent().remove(m_slink);   
     m_slink = null;
     for (int i =0; i<m_ballOwners.size(); i++) {
		 if ((SingleNodeModel)m_ballOwners.get(i) != null) {
			((SingleNodeModel)m_ballOwners.get(i)).removeBalloon(this);
		 }
     }
     p.repaint();
   }
  
  public void setSx(int x)  { m_sourcePt.x = x; }    
  public void setSy(int y)  { m_sourcePt.y = y; }    
  public void setTx(int x)  { m_targetPt.x = x; }    
  public void setTy(int y)  { m_targetPt.y = y; }
  
  public void setSourcePt(Point p) { m_sourcePt = p;}
  public void setTargetPt(Point p) { m_targetPt = p;}
  
  public Point getSourcePt() { return m_sourcePt; }
  public Point getTargetPt() { return m_targetPt; }
  
  public String save(String path) {
     String r = "";
    
     // note origin and destination are based on the cards themselves
    
     r = r + "<cardlink>";
    
     r = r + "<label>";
     r = r + m_label;
     r = r + "</label>";
    
     r = r + "<cardorig>";
     if (m_cardOrig != null) {
        r = r + m_cardOrig.getLabel();
     } else {
        r = r + "null";
     }    
     r = r + "</cardorig>";
        
     r = r + "<sx>";
     r = r +  m_sourcePt.x;
     r = r + "</sx>";

     r = r + "<sy>";
     r = r + m_sourcePt.y;
     r = r + "</sy>";    
    
     r = r + "<carddest>";
    
     if (m_cardDest != null) {
        r = r + m_cardDest.getLabel();
     } else {
        r = r + "null";
     }    
     r = r + "</carddest>";

     r = r + "<tx>";
     r = r + m_targetPt.x;
     r = r + "</tx>";

     r = r + "<ty>";
     r = r + m_targetPt.y;
     r = r + "</ty>";    
    
     r = r + "<caption>";
     r = r + getCleanedCaption();
     r = r + "</caption>";
	 
	 r = r + "<pause>";
	 r = r + m_cardSound.getPauseDuration();
	 r = r + "</pause>";
    
     r = r + "<filename>";
     r = r + m_label + ".wav";
     r = r + "</filename>";
        
     r = r + "</cardlink>";

     
     // save the audio under the name of this particular link    
     if(m_cardSound.isAvailable()) {
        //System.out.println("saving link: " + m_label); //RMV
        m_cardSound.saveToFile(path + m_label + ".wav", AudioFileFormat.Type.WAVE);
     }
	 
     
     return r;
  }
 
  public void play() {
     if (m_slink.isPlaying()) {
        m_slink.setStopped(); 
        m_cardSound.stopPlayingAudio();       
     } 
     else {
        setPauseDuration(m_cardSound.getPauseDuration());
		//System.out.println("link '" + getCaption() + "' has pause: " + m_pauseDuration); //RMV
        if (m_cardSound.isAvailable()) {
           m_slink.setPlaying();  
           m_cardSound.playAudio();   
        } 
        else {
           m_slink.setPlaying();    
           m_slink.setStopped();
           m_cwf.callmeWhenDonePlaying();  // always call the playing callback.
        }
     }
  }
  
  
  public void playBalloon(SSavableElt balloonCallingNode) {
     m_balloonCallingNode = balloonCallingNode;
     m_slink.setPlaying();    

     if (m_testResponses.size()>0) { // if any test responses have been recorded yet
       // play the most recent response
       ((TranscriptNodeModel)m_testResponses.lastElement()).playBalloonAudio(balloonCallingNode);
     } else if (m_cardSound.isAvailable()) { //if no responses have been recorded, play the design time example response
		 m_cardSound.playAudio();            
     }
  }

  public void record() {
     if (m_slink.isRecording()) {
        m_slink.setStopped();
        m_cardSound.stopRecordingAudio();    
     } else {
        //cardsound.file = null;
        //cardsound.fileName = "untitled";
        m_slink.setRecording();
        m_cardSound.recordAudio(true, 0);
     }
  }
  
  
  public void actionPerformed(ActionEvent e) {
     Object obj = e.getSource();

     if (obj.getClass().toString().compareTo("class edu.berkeley.guir.suede.PlayButton") == 0) {
        play();
     } else if (obj.getClass().toString().compareTo("class edu.berkeley.guir.suede.RecordButton") == 0) {
        record();
     }
  }  
 
  /**
   */
   private class LCallWhenFinished implements EndPlayCallbackIF, EndRecordCallbackIF {
      
      /**
       * goes down and then up when playing out the streams of audio.
       */
      public void callmeWhenDonePlaying(/*CardSound cardSound*/) {
         if (DEBUG) { System.out.println("callwhenfinished done playing ... ");}        
         m_slink.setStopped();        
        
         // if this link is playing its audio as part of a balloon sequence
         if (m_balloonCallingNode != null) {
            m_balloonCallingNode.callWhenBalloonFinished();
            m_balloonCallingNode = null;
         }
      }
      
      public void callmeWhenDoneRecording() {
         if (DEBUG) { System.out.println("callwhenfinished done recording ... ");}
        
         if (m_callback != null) {
            m_callback.callback();
            m_callback = null;
         }
         setPlayable(true); 
      } 
   } // end class LCallWhenFinished


   private class PlayMenuListener implements ActionListener{
      private TranscriptNodeModel m_nodeModel;

      public PlayMenuListener(TranscriptNodeModel m) {
         m_nodeModel = m;
      }
        
      public void actionPerformed (ActionEvent e) {
         //System.out.println("got an action");
		 setPauseDuration(m_cardSound.getPauseDuration());
		 //System.out.println("response '" + getCaption() + "' has pause: " + m_pauseDuration); //RMV
         m_nodeModel.playAudio();
      }
   } // end class PlayMenuListener

}
