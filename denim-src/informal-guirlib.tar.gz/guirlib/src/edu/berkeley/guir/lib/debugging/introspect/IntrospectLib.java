//// See bottom of source code for software license.
package edu.berkeley.guir.lib.debugging.introspect;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.LinkedList;
import java.util.List;

/**
 * Library of utilities for introspection.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
public class IntrospectLib
   implements IntrospectConstants {

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * No instances allowed.
    */
   private IntrospectLib() {
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS MANIPULATION METHODS   ========================================

   /**
    * Get all fields that belong to this class, traversing up the inheritance
    * chain if necessary.
    */
   public static List getAllFields(Class cl) {
      return (getAllFields(cl, new LinkedList()));
   } // of method

   /**
    * Helper method for the method above.
    */
   private static List getAllFields(Class cl, List l) {
      Field[] fields = cl.getDeclaredFields();

      for (int i = 0; i < fields.length; i++) {
         l.add(fields[i]);
      }

      Class parent = cl.getSuperclass();
      if (parent != null && parent.isInterface() == false &&
          parent.isPrimitive() == false) {
         getAllFields(parent, l);
      }

      return (l);
   } // of method

   //===   CLASS MANIPULATION METHODS   ========================================
   //===========================================================================



   //===========================================================================
   //===   CLASS VARIABLES AND METHODS   =======================================

   /**
    * Get a String for modifiers.
    */
   public static String getModString(int mods) {
      String str = Modifier.toString(mods);
      if (str.length() > 0) {
         return (str + " ");
      }
      return (str);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert a field into a human-readable type.
    */
   public static String getTypeString(Class cl) {
      if (cl.isArray() == true) {
         return (getArrayStringName(cl));
      }
      else {
         return (cl.getName());
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert an array class type into a String.
    * Also handles arrays of arrays.
    *
    * <PRE>
    * [Ljava.lang.String;   String[]
    * [Z                    boolean[]
    * [C                    char[]
    * [B                    byte[]
    * [S                    short[]
    * [I                    int[]
    * [J                    long[]
    * [F                    float[]
    * [D                    double[]
    *
    * [[Ljava.lang.String;  String[][]
    * [[I                   int[][]
    * </PRE>
    */
   public static String getArrayStringName(Class type) {
      //// 1. Check if array.
      if (type.isArray() == false) {
         return ("");
      }

      //// 2. Figure out dimensionality and type of array.
      String strType   = type.getName();
      int    arrcount  = 0;
      String strReturn = null;

      for (int i = 0; i < strType.length(); i++) {
         switch(strType.charAt(i)) {
            case '[': arrcount++; break;
            case 'L': strReturn = strType.substring(i+1, strType.length() - 1);
                      break;
            case 'Z': strReturn = "boolean";   break;
            case 'C': strReturn = "char";      break;
            case 'B': strReturn = "byte";      break;
            case 'S': strReturn = "short";     break;
            case 'I': strReturn = "int";       break;
            case 'J': strReturn = "long";      break;
            case 'F': strReturn = "float";     break;
            case 'D': strReturn = "double";    break;
            default : strReturn = "unknown";   break;
         }
         if (strReturn != null) {
            break;
         }
      }

      //// 3. Append the brackets "[]".
      for (int i = 0; i < arrcount; i++) {
         strReturn += "[]";
      }

      return (strReturn);
   } // of method

   //===   CLASS VARIABLES AND METHODS   =======================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
