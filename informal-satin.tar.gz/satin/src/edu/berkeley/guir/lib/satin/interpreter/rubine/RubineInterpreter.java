//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter.rubine;

import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.recognizer.*;
import edu.berkeley.guir.lib.satin.recognizer.rubine.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import java.io.*;
import java.net.*;
import java.text.ParseException;
import java.util.*;

/**
 * Contains Rubine's recognizer. Subclass this to do something useful.
 * This implementation also automatically caches existing recognizers.
 *
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 02 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public abstract class RubineInterpreter
   extends InterpreterImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -8744819975929174646L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   PROPERTIES   ========================================================

   /**
    * The directory of where to load up interpreters from.
    */
   public static final String RUBINE_DATA_DIRECTORY_PROPERTY =
                                               "RUBINE_DATA_DIRECTORY_PROPERTY";

   public static final String RUBINE_DATA_DIRECTORY_DEFAULT =
                                 SATIN_DATA_DIRECTORY_DEFAULT + "interpreters/";

   /**
    * The name of the property that specifies where the Rubine Recognition
    * data is stored on the network.
    */
   public static final String RUBINE_DATA_URL_PROPERTY = "RubineData";

   /**
    * The default value for where the Rubine Recognition data is stored,
    * overridden by whatever value is specified in the properties file.
    * This is a URL.
    */
   public static final String RUBINE_DATA_URL_DEFAULT = "";

   //-----------------------------------------------------------------

   static {
      //// 1. Global init.
      glprops.setProperty(RUBINE_DATA_DIRECTORY_PROPERTY,
                          RUBINE_DATA_DIRECTORY_DEFAULT);
      glprops.setProperty(RUBINE_DATA_URL_PROPERTY,
                          RUBINE_DATA_URL_DEFAULT);

   } // of static init

   //===   PROPERTIES   ========================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   /**
    * Cache existing interpreters, so we don't reload them.
    */
   private static final WeakHashMap cache = new WeakHashMap();

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   // simplify before recog?
             protected boolean          flagSimplify = false;
             
   // name of data file
             protected String           strFileName;
             
   // class which data file is relative to             
             protected Class            baseClass;
             
   // ignore gestures below threshold
             protected double           confidence;

   // reference to the recognizer
   transient protected RubineRecognizer recognizer;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   private RubineInterpreter() {
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Constructor to create a Rubine Interpreter.
    */
   public RubineInterpreter(String strFileName) {
      this(strFileName, null, false);
   } // of constructor

   //-----------------------------------------------------------------
   
   /**
    * Constructs a Rubine interpreter.
    * 
    * @param strFileName  the name of the strokes data file.
    *                     By default looks for this file in the
    *                     data/interpreters data directory, relative
    *                     to the baseClass parameter.
    * 
    * @param baseClass    the class whose location is the basis
    *                     for looking for the strokes data file.
    *                     If null, then strFileName is relative to
    *                     the directory from which the program was launched.
    */
   public RubineInterpreter(String strFileName, Class baseClass) {
      this(strFileName, baseClass, false);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Constructs a Rubine interpreter.
    * 
    * @param strFileName  is the name of the strokes data file.
    *                     By default looks for this file in the
    *                     data/interpreters data directory.
    * @param flagSimplify specifies whether to simplify the strokes before
    *                     trying to recognize them.
    */
   public RubineInterpreter(String strFileName, boolean flagSimplify) {
      this(strFileName, null, flagSimplify);
   }
   
   //-----------------------------------------------------------------

   /**
    * Constructs a Rubine interpreter.
    * 
    * @param strFileName  the name of the strokes data file.
    *                     By default looks for this file in the
    *                     data/interpreters data directory, relative
    *                     to the baseClass parameter.
    * 
    * @param baseClass    the class whose location is the basis
    *                     for looking for the strokes data file.
    *                     If null, then strFileName is relative to
    *                     the directory from which the program was launched.
    * 
    * @param flagSimplify specifies whether to simplify the strokes before
    *                     trying to recognize them.
    */
   public RubineInterpreter(String strFileName, Class baseClass,
                            boolean flagSimplify) {
      //// 0. Initializations.
      this.strFileName = strFileName;

      //// 1. Create a new recognizer.
      recognizer = initializeRecognizer(strFileName, baseClass);

      //// 2. Simplify or not?
      setSimplify(flagSimplify);

      commonInitializations();
   } // of method

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Rubine Interpreter");
      this.confidence  = 0.8;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Pass in a path to Rubine data file, get a RubineRecognizer.
    */
   private RubineRecognizer initializeRecognizer(String str,
                                                 Class baseClass) {

      RubineRecognizer recognizer = null;

      //// 0. Check the cache first.
      recognizer = (RubineRecognizer) cache.get(str);
      if (recognizer != null) {
         //debug.println(
         //     "Retrieving cached copy of Rubine's Recognizer data file " + str);
         return (recognizer);
      }

      //// 1. Boundary case.
      if (str.equals("")) {
         //debug.println("Creating empty Rubine's Recognizer");
         recognizer = new RubineRecognizer();
         cache.put(str, recognizer);
         return (recognizer);
      }

      //// 2. Try to retrieve from disk.
      try {
         String strFileName = (String) 
                           glprops.getProperty(RUBINE_DATA_DIRECTORY_PROPERTY) +
                           str;

         InputStream istream = null;
         if (baseClass != null) {
            istream =
               baseClass.getResourceAsStream(
                  glprops.getProperty(RUBINE_DATA_DIRECTORY_PROPERTY) +
                  str);
         }
         if (istream == null) {
            istream = new FileInputStream(strFileName);
         }
         Reader         rdr  = new InputStreamReader(istream);
         BufferedReader brdr = new BufferedReader(rdr);


         //// 2.1. Create the RubineRecognizer.
         //debug.println("Retrieving Rubine's Recognizer data from disk - " 
         //              + strFileName);
         recognizer = new RubineRecognizer(brdr);
         cache.put(str, recognizer);
         return (recognizer);
      }
      catch (Exception e) {
         Debug.println(e);
      }

      //// 3. Otherwise, retrieve from the network.
      try {
         //// 3.1. Get the properties for where Rubine's data is.
         String      strURL;
         URL         url;
         InputStream istream;
         Reader      rdr;

         strURL = ((String) glprops.getProperty(RUBINE_DATA_URL_PROPERTY))
                      + str;

         url    = new URL(strURL);

         //// 3.2. Start up a Reader opening the file with the Rubine data set.
         //debug.println("Retrieving Rubine's Recognizer data from network instead - " + strURL);
         istream = url.openStream();
         rdr     = new InputStreamReader(istream);

         //// 3.3. Create the RubineRecognizer.
         recognizer = new RubineRecognizer(rdr);
         cache.put(str, recognizer);
         return (recognizer);
      }
      catch (FileNotFoundException e) {
         Debug.println(e);
         Debug.println("Initialization Error - using empty Rubine Recognizer");
         recognizer = new RubineRecognizer();
      }
      catch (ParseException e) {
         Debug.println(e);
         Debug.println("Bad Rubine data file.");
         Debug.println("Initialization Error - using empty Rubine Recognizer");
         recognizer = new RubineRecognizer();
      }
      catch (TrainingException e) {
         Debug.println(e);
         Debug.println("Error in Rubine Recognizer processing data file.");
         Debug.println("Initialization Error - using empty Rubine Recognizer");
         recognizer = new RubineRecognizer();
      }
      catch (IOException e) {
         Debug.println(e);
         Debug.println("Initialization Error - using empty Rubine Recognizer");
         recognizer = new RubineRecognizer();
      }

      return (recognizer);
   } // of method

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   public Recognizer getRecognizer() {
      return (recognizer);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the confidence level for gesture recognition, below which we will
    * ignore. By default, the confidence level is 0.90.
    */
   public double getConfidence() {
      return (confidence);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the name of the strokes data file.
    */
   public String getFileName() {
      return (strFileName);
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Set the confidence level for gesture recognition, below which we will
    * ignore. By default, the confidence level is 0.80.
    */
   public void setConfidence(double val) {
      this.confidence = val;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Simplify the stroke before trying to classify it?
    * Default is no simplification. Simplification sometimes helps recognition.
    *
    * @param flag is true if you do want to simplify, false otherwise.
    */
   public void setSimplify(boolean flag) {
      flagSimplify = flag;
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   /**
    * Currently does nothing.
    */
   public void handleNewStroke(NewStrokeEvent evt) {
   } // of method

   //-----------------------------------------------------------------

   /**
    * Currently does nothing.
    */
   public void handleUpdateStroke(UpdateStrokeEvent evt) {
   } // of method

   //-----------------------------------------------------------------

   /**
    * First classifies the stroke using Rubine's Recognizer, and then 
    * delegates to 
    * {@link #handleSingleStroke(SingleStrokeEvent, Classification)} if the
    * value is above the confidence threshold (as set by
    * {@link #setConfidence(double)}).
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      //// 1. See if we have a recognizer.
      if (recognizer == null) {
         return;
      }

      //// 2. See if the stroke can be classified with a high degree 
      ////    of probability.
      TimedStroke     stk   = evt.getStroke();

      //// 3. Preprocess the stroke.
      stk = preprocessStroke(stk);

      //// 4. Classify the stroke.
      ////    Ignore classifications below a certain threshold.
      Classification  c = recognizer.classify(stk);
      //debug.println(c);

      Double d = (Double) c.getFirstValue();
      if (d.doubleValue() < confidence) {
         return;
      }

      handleSingleStroke(evt, c);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Gives you a chance to modify the stroke before recognizing it.
    * By default returns specified stroke unmodified.
    *
    * @return either a reference to the original stroke or a copy
    *         that has been modified. Don't modify the original stroke.
    */
   protected TimedStroke preprocessStroke(TimedStroke stk) {
      if (flagSimplify == true) {
         Polygon2D poly;
         poly = stk.getPolygon2D(COORD_ABS);
         poly = poly.simplify();
         return (new TimedStroke(poly));
      }
      else {
         return (stk);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Do something given the classification.
    */
   protected abstract void
   handleSingleStroke(SingleStrokeEvent evt, Classification c);

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public RubineInterpreter clone(RubineInterpreter intrp) {
      intrp.strFileName = this.strFileName;
      intrp.baseClass   = this.baseClass;
      intrp.recognizer  = intrp.initializeRecognizer(this.strFileName,
                                                     this.baseClass);
      intrp.commonInitializations();
      return (intrp);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   SERIALIZATION METHODS   =============================================

   private void readObject(ObjectInputStream oistream) 
      throws IOException {

      try {
         oistream.defaultReadObject();
      }
      catch (Exception e) {
         Debug.println(e);
      }
      initializeRecognizer(strFileName, baseClass);
   } // of method

   //-----------------------------------------------------------------

   private void writeObject(ObjectOutputStream oostream) 
      throws IOException {

      oostream.defaultWriteObject();
   } // of method

   //===   SERIALIZATION METHODS   =============================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
