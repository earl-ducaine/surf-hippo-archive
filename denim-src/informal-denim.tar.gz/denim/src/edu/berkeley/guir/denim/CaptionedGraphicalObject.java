package edu.berkeley.guir.denim;

/**
 * Tags a graphical object has having a caption that can be get and
 * set with getCaption() and setCaption().
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-13-2002 James Lin
 *                    Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-13-2002
 */
public interface CaptionedGraphicalObject {

   /**
    * Gets the caption of this graphical object.
    */
   public DenimText getCaption();
   
   /**
    * Sets the caption of this graphical object.
    */
   public void setCaption(DenimText caption);
}
