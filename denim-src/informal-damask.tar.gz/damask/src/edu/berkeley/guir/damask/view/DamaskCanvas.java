package edu.berkeley.guir.damask.view;

import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.pattern.PatternSolution;
import edu.berkeley.guir.damask.view.DamaskDocument.DamaskCanvasGroup;
import edu.berkeley.guir.damask.view.DamaskLayer.DeviceTypeLayer;
import edu.berkeley.guir.damask.view.appdialogs.FileDialogUtils;
import edu.berkeley.guir.damask.view.appevent.*;
import edu.berkeley.guir.damask.view.event.*;
import edu.berkeley.guir.damask.view.nodes.*;
import edu.berkeley.guir.damask.view.pattern.PatternBrowser;
import edu.berkeley.guir.damask.view.pattern.PatternInstanceView;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;
import edu.berkeley.guir.damask.view.visual.component.ComponentView;
import edu.berkeley.guir.damask.view.visual.component.RadioButton;
import edu.berkeley.guir.damask.view.voice.VoiceCanvas;
import edu.berkeley.guir.damask.view.voice.component.*;
import edu.berkeley.guir.lib.collection.Map2D;
import edu.berkeley.guir.lib.io.FileLib;
import edu.berkeley.guir.lib.satin.command.Command;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolo.event.*;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolox.handles.PBoundsHandle;
import edu.umd.cs.piccolox.util.PBoundsLocator;

/** 
 * The canvas in which the designer creates his or her design.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-28-2003 James Lin
 *                               Created DamaskCanvas.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-28-2003
 */
public abstract class DamaskCanvas extends PCanvas {
   private static final Point POINT00 = new Point(0, 0);
   
   // Constants for mode names
   public static final String SELECTION_MODE = "Select/Move";
   public static final String HAND_MODE = "Pan";
   public static final String TO_ALL_DEVICES_MODE = "Change to All Device Types";
   public static final String TO_SINGLE_DEVICE_MODE = "Change to This Device Type";
   
   private static final Logger logger =
      Logger.getLogger(DamaskCanvas.class.getName());

   // General fields
   public static final Map2D/*<DeviceType, DamaskLayer.DeviceTypeLayer, Paint>*/
      BACKGROUND_PAINTS =
         new Map2D/*<DeviceType, DamaskLayer.DeviceTypeLayer, Paint>*/();
   static {
      final Color desktopColor = new Color(250, 240, 220);
      final Color smartphoneColor = new Color(220, 250, 240);
      final Color voiceColor = new Color(220, 220, 250);
      
      BACKGROUND_PAINTS.put(
         DeviceType.DESKTOP, DamaskLayer.DeviceTypeLayer.DEVICE, desktopColor);
      BACKGROUND_PAINTS.put(
         DeviceType.SMARTPHONE, DamaskLayer.DeviceTypeLayer.DEVICE, smartphoneColor);
      BACKGROUND_PAINTS.put(
         DeviceType.VOICE, DamaskLayer.DeviceTypeLayer.DEVICE, voiceColor);
      
      BACKGROUND_PAINTS.put(
         DeviceType.DESKTOP, DamaskLayer.DeviceTypeLayer.ALL,
         new GradientPaint(
            0, 0, desktopColor,
            50, 50, DamaskAppUtils.createDarkerColor(desktopColor, 0.85),
            true));
      BACKGROUND_PAINTS.put(
         DeviceType.SMARTPHONE, DamaskLayer.DeviceTypeLayer.ALL,
         new GradientPaint(
            0, 0, smartphoneColor,
            50, 50, DamaskAppUtils.createDarkerColor(smartphoneColor, 0.85),
            true));
      BACKGROUND_PAINTS.put(
         DeviceType.VOICE, DamaskLayer.DeviceTypeLayer.ALL,
         new GradientPaint(
            0, 0, voiceColor,
            50, 50, DamaskAppUtils.createDarkerColor(voiceColor, 0.85),
            true));
   }

   // Fields related to drag-and-drop support
   private static final int ACCEPTABLE_DROP_ACTIONS =
      DnDConstants.ACTION_COPY | DnDConstants.ACTION_MOVE;
   private final DropTarget dropTarget;

   private final DamaskCanvasGroup group;
   
   // Piccolo event mode and handlers
   private DamaskAppMode appMode = null;
   private PInputEventListener appModeHandler = null;
   private PNode insideNode = null;
   private final SelectionEventHandler selectionEventHandler;
   private final Map/*<String, DamaskAppMode>*/ modes = new HashMap();

   private Collection/*<PNode>*/ objectsToCopy = null;
   
   // Fields related to zooming the camera
   public static final int SITEMAP = 1;
   public static final int STORYBOARD = 3;
   public static final int BETWEEN_STORYBOARD_PAGE = 5;
   public static final int PAGE = 7;
   public static final int BETWEEN_PAGE_DETAIL = 9;
   public static final int DETAIL = 11;
   public static final int BELOW_DETAIL = 13;

   private final BoundedRangeModel sliderModel =
      new DefaultBoundedRangeModel(PAGE, 0, SITEMAP, BELOW_DETAIL);

   private boolean zoomCenteredAtUpperLeft = false;

   // Fields related to firing canvas event sources
   private final CanvasEventSource eventSource = new CanvasEventSource();

   // Fields related to mouse wheel zooming
   private final MouseWheelHandler mouseWheelHandler = new MouseWheelHandler();
   private Point2D zoomCenterMousePosition = null;
   
   // Actions for menu and toolbar items
   private final Action cutAction = new CutAction();
   private final Action copyAction = new CopyAction();
   private final Action pasteAction = new PasteAction();
   private final Action deleteAction = new DeleteAction();
   private final Action changeLayerOfObjectAction = new ChangeLayerOfObjectAction();
   
   private boolean textEditing = false;

   // Pop up menus
   private final JPopupMenu plainPopupMenu = new JPopupMenu();
   
   private final PopupMenuEventHandler popupMenuEventHandler;
   
   // Fields related to windows
   private DamaskWindow currentWindow = null;
   private boolean windowIsManipulated = false;

   // Constructor --------------------------------------------------------
   
   /**
    * Creates the canvas.
    * 
    * @param group the canvas group this canvas belongs to
    * @param deviceType the device type from which perspective to display
    * the document
    */
   public DamaskCanvas(
      final DamaskCanvasGroup group,
      final DeviceType deviceType) {
         
      this(group, deviceType, 1.0);
   }
      
   /**
    * Creates the canvas.
    * 
    * @param group the canvas group this canvas belongs to
    * @param deviceType the device type from which perspective to display
    * the document
    * @param pageTitleScale the scale at which page titles should be drawn 
    */
   public DamaskCanvas(
      final DamaskCanvasGroup group,
      final DeviceType deviceType,
      final double pageTitleScale) {
         
      // Basic setup 
      this.group = group;

      // Replace the default layer and camera in canvas with our own.
      final PRoot root = getRoot();
      {
         final PLayer oldLayer = getLayer();
         final PCamera oldCamera = getCamera();
   
         root.removeChild(oldLayer);
         root.removeChild(oldCamera);
         oldCamera.removeLayer(oldLayer);
      }

      final DamaskCamera camera = new DamaskCamera();
      final DamaskLayer damaskLayer =
         DamaskLayer.create(group.getDocument(), deviceType, pageTitleScale);
         
      setCamera(camera);
      root.addChild(camera);
      root.addChild(damaskLayer);

      // The selection handler only selects items inside pages, so set up
      // the handler so its selectable parents is empty for now. Any page
      // added to the canvas must be added to the handler's list of
      // selectable parents.
      
      // This must be done before the layer is added to the camera.
      selectionEventHandler =
         new SelectionEventHandler(damaskLayer, new ArrayList());
      selectionEventHandler.setEventFilter(
         new PInputEventFilter(InputEvent.BUTTON1_MASK));

      // Set the layer and the background color.
      camera.addLayer(damaskLayer);
      damaskLayer.addLayerListener(new LayerHandler());
      updateBackgroundColor();
      
      // Listen to changes in my slider model
      sliderModel.addChangeListener(new SliderModelHandler());

      // Listen to changes in my own selection
      addCanvasListener(new SelectionChangeHandler());

      // Initialize event handlers
      removeInputEventListener(getPanEventHandler());

      addInputEventListener(mouseWheelHandler);

      modes.put(SELECTION_MODE, getSelectionAppMode());

      modes.put(
         HAND_MODE,
         new DamaskAppMode(
            HAND_MODE,
            new PanningHandEventHandler(),
            
            DamaskAppUtils.createCursor(
               "hand.gif",
               new Point(8, 0),
               "Hand")));

      modes.put(
         TO_ALL_DEVICES_MODE,
         new DamaskAppMode(
            TO_ALL_DEVICES_MODE,
            new PullToAllDeviceTypesEventHandler(),
            null));

      modes.put(
         TO_SINGLE_DEVICE_MODE,
         new DamaskAppMode(
            TO_SINGLE_DEVICE_MODE,
            new PushToSingleDeviceTypeEventHandler(),
            null));

      // Initialize transfer handler, which is used for Cut, Copy, and Paste
      setTransferHandler(new DamaskObjectSelection());

      // Initialize support for dropping pattern solutions from pattern browser.
      dropTarget = new DropTarget(
         this,
         ACCEPTABLE_DROP_ACTIONS,
         new DropTargetHandler(),
         true);

      // Listen for command events from this canvas
      getDocument().getCommandQueue().addCommandListener(new CommandHandler());
      
      // Initialize menu for labels
      setLayout(null);

      // Initialize actions
      cutAction.setEnabled(false);
      copyAction.setEnabled(false);
      deleteAction.setEnabled(false);
      changeLayerOfObjectAction.setEnabled(false);
      
      // Initialize pop up menus
      {
         plainPopupMenu.add(new JMenuItem(cutAction));
         plainPopupMenu.add(new JMenuItem(copyAction));
         plainPopupMenu.add(new JMenuItem(pasteAction));
         plainPopupMenu.add(new JMenuItem(deleteAction));
      }
      
      popupMenuEventHandler = new PopupMenuEventHandler(this); 
      addInputEventListener(popupMenuEventHandler);
   }


   /**
    * Returns the mode to be used when the selection tool is selected.
    */
   public DamaskAppMode getSelectionAppMode() {
      return new DamaskAppMode(
         SELECTION_MODE,
         selectionEventHandler,
         
         null);      
   }
   
   /**
    * Returns a new instance of a concrete subclass of DamaskCanvas,
    * depending on the specified device type.
    */
   public static DamaskCanvas create(
         final DamaskCanvasGroup group,
         final DeviceType deviceType) {

      return create(group, deviceType, 1.0);
   }
   

   /**
    * Returns a new instance of a concrete subclass of DamaskCanvas,
    * depending on the specified device type.
    */
   public static DamaskCanvas create(
         final DamaskCanvasGroup group,
         final DeviceType deviceType,
         final double pageTitleScale) {

      if (deviceType.isVisual()) {
         return new VisualCanvas(group, deviceType, pageTitleScale);
      }
      else {
         return new VoiceCanvas(group, deviceType, pageTitleScale);
      }
   }
   
   // General methods ----------------------------------------------------

   /**
    * Returns the device type of the design that is in this canvas.
    */
   public DeviceType getDeviceType() {
      return ((DamaskLayer)getLayer()).getDeviceType();
   }


   /**
    * Returns the document that is being displayed in this canvas. 
    */
   public DamaskDocument getDocument() {
      return group.getDocument();
   }


   // @Override
   public String toString() {
      return DamaskUtils.toShortString(this) + " (" +
         SwingUtilities.windowForComponent(this) + " - " + 
         getDeviceType() + ")";
   }
   
   // Piccolo event handlers ---------------------------------------------
      
   /**
    * Returns the selection handler of the canvas.
    */
   public SelectionEventHandler getSelectionEventHandler() {
      return selectionEventHandler;
   }

   
   /**
    * Adds the specified mode to the list of possible modes that this canvas
    * has.
    */
   protected void addMode(final DamaskAppMode newMode) {
      modes.put(newMode.getName(), newMode);
   }

   
   /**
    * Returns the current mode of the canvas.
    */
   public DamaskAppMode getMode() {
      return appMode;
   }

   
   /**
    * Called before the mode is actually changed.
    */
   protected void beforeSetModeByName() {
   }

   
   /**
    * Called after the mode is actually changed.
    */
   protected void afterSetModeByName() {
   }

   /**
    * Returns the current mode of the canvas.
    */
   public void setModeByName(final String newModeName) {
      stopTextEditing();
      
      if (appMode != null) {
         beforeSetModeByName();
         setModeEventHandlerEnabled(false);
      }

      selectionEventHandler.unselectAll(this);
      
      appMode = (DamaskAppMode)modes.get(newModeName);
      
      if (appMode != null) {
         afterSetModeByName();
         setModeEventHandlerEnabled(true);
      }
   }

   /**
    * Enables or disables the current mode's event handler. If the event
    * handler is being enabled, then the current handler is chosen depending
    * on whether the mouse cursor is currently over a page, a control, or
    * the background. 
    */
   protected void setModeEventHandlerEnabled(final boolean flag) {
      if (flag) {
         final Cursor cursorToUse;
         appModeHandler = appMode.getDefaultHandler();
         if ((insideNode instanceof PBoundsHandle)
            && !(insideNode instanceof NonResizableHandle)) {
            final PBoundsHandle handle = ((PBoundsHandle)insideNode);
            cursorToUse =
               handle.getCursorFor(
                  ((PBoundsLocator)handle.getLocator()).getSide());
         }
         else {
            cursorToUse = appMode.getDefaultCursor();
         }

         addInputEventListener(appModeHandler);
         setCursor(cursorToUse);
      }
      else {
         removeInputEventListener(appModeHandler);
         setCursor(null);
      }
   }


   /**
    * Sets the proper cursor. 
    */
   public void setProperCursor() {
      setCursor(appMode.getDefaultCursor());
   }

   /**
    * Sets whether text is being edited.
    */
   public void setTextEditing(final boolean flag) {
      textEditing = flag;
   }
   
   /**
    * Returns whether text is being edited.
    */
   public boolean isTextEditing() {
      return textEditing;
   }
   
   /**
    * Stops any text editing in progress.
    */
   public abstract void stopTextEditing();
   

   // Canvas event methods -----------------------------------------------
 
   /**
    * Adds the specified listener to receive canvas events.
    */
   public synchronized void addCanvasListener(final CanvasListener listener) {
      eventSource.addCanvasListener(listener);
   }


   /**
    * Removes the specified listener so that it no longer receives
    * canvas events.
    */
   public synchronized void removeCanvasListener(final CanvasListener listener) {
      eventSource.removeCanvasListener(listener);
   }


   /**
    * Fires selectionChanged events to listeners.
    */
   public void fireSelectionChanged() {
      eventSource.fireSelectionChanged(this);
   }

   
   /**
    * Fires selectedPageChanged events to listeners.
    */
   public void fireSelectedPageChanged() {
      eventSource.fireSelectedPageChanged(this);
   }
   
   // Layer methods ------------------------------------------------------

   public boolean tryExportAsImage(final Window parentWindow) {
      final File newFile = FileDialogUtils.showImageSaveDialog(parentWindow);
      boolean result;
      if (newFile != null) {
         final DamaskLayer damaskLayer = (DamaskLayer)getLayer();
         final TemplatePane templatePane = damaskLayer.getTemplatePane();
         final boolean isTemplatePaneVisible = templatePane.getVisible();
         templatePane.setVisible(false);
         final PBounds b = getLayer().getFullBoundsReference();
         final BufferedImage image =
            (BufferedImage)getLayer().toImage((int) Math.ceil(b.getWidth()), (int) Math.ceil(b.getHeight()), getCamera().getPaint());
         try {
            ImageIO.write(image, FileLib.getFileNameExtension(newFile.getAbsolutePath()), newFile);
            logger.info(this + ": exported image as " + newFile);
            result = true;
         }
         catch (IOException e) {
            JOptionPane.showMessageDialog(
               parentWindow,
               "There is a problem writing "
                  + newFile
                  + ".\n\n"
                  + e.getMessage(),
               "Damask",
               JOptionPane.ERROR_MESSAGE);
            DamaskAppExceptionHandler.log(e);
            result = false;
         }
         templatePane.setVisible(isTemplatePaneVisible);
      }
      else {
         result = false;
      }
      return result;
   }
   
   private void updateBackgroundColor() {
      final DeviceTypeLayer deviceTypeLayer =
         ((DamaskLayer)getLayer()).getDeviceTypeLayer();
      getCamera().setPaint(
         (Paint)BACKGROUND_PAINTS.get(getDeviceType(), deviceTypeLayer));
      
      if (deviceTypeLayer == DamaskLayer.DeviceTypeLayer.ALL) {
         changeLayerOfObjectAction.putValue(Action.NAME, "Move Objects to \"This Device\" Layer");
      }
      else {
         changeLayerOfObjectAction.putValue(Action.NAME, "Move Objects to \"All Devices\" Layer");
      }
   }
   
   /**
    * Handles layer events.  
    */
   private class LayerHandler implements LayerListener {
      public void deviceTypeLayerChanged(LayerEvent e) {
         assert e.getLayer()
            == getLayer() : "should be receiving events from "
               + getLayer()
               + ", not "
               + e.getLayer();
         updateBackgroundColor();
      }
   }   

   // Slider and zooming methods -----------------------------------------

   /**
    * Returns the slider range model for this canvas.
    */
   public BoundedRangeModel getSliderModel() {
      return sliderModel;
   }


   /**
    * Returns the scale factor of the camera, given a slider zoom level.
    */
   public static double scaleFactor(final int zoomLevel) {
      // Derived from empirical values in DENIM
      // scaleFactor(PAGE) must be 1
      return 0.15 * zoomLevel - 0.05;
   }


   /**
    * Returns the nearest zoom level, given a scale factor for the camera.
    */
   public static int getNearestZoomLevel(final double scaleFactor) {
      // Derived from empirical values in DENIM
      // getNearestZoomLevel(1) must be PAGE
      return (int)Math.round((scaleFactor + 0.05) / 0.15);
   }


   /**
    * Sets the zoom level of the canvas's camera to the given zoom level.
    */   
   public void setZoomLevel(final int zoomLevel) {
      sliderModel.setValue(zoomLevel);
   }
   

   /**
    * Returns the position that a zoom action should center on.
    * @return
    */
   protected Point2D getZoomCenterMousePosition() {
      return zoomCenterMousePosition;
   }
   

   /**
    * Returns whether zooming should be centered around the upper left-hand
    * corner.
    */
   public boolean isZoomCenteredAtUpperLeft() {
      return zoomCenteredAtUpperLeft;
   }
   

   /**
    * Sets whether zooming should be centered around the upper left-hand
    * corner.
    */
   public void setZoomCenteredAtUpperLeft(final boolean flag) {
      zoomCenteredAtUpperLeft = flag;
   }
   
   
   /**
    * Called when the slider's model changes.
    */
   protected void sliderModelStateChanged(final ChangeEvent e) {
      final PCamera camera = getCamera();
      final Point2D zoomCenter;
      
      if (zoomCenteredAtUpperLeft) {
         zoomCenter = POINT00; 
      }
      else if (zoomCenterMousePosition == null) {
         // Zoom about the center of the canvas.
         zoomCenter = camera.getViewBounds().getCenter2D();
      }
      else {
         zoomCenter = zoomCenterMousePosition;
      }
      
      camera.scaleViewAboutPoint(
         scaleFactor(sliderModel.getValue()) / camera.getViewScale(),
         zoomCenter.getX(),
         zoomCenter.getY());
      
      logger.info(this + ": Zoom level changed to " + sliderModel.getValue());
   }

   
   /**
    * Listens to the zoom slider's model.
    */
   private class SliderModelHandler implements ChangeListener {
      public void stateChanged(ChangeEvent e) {
         sliderModelStateChanged(e);
      }
   }

   // Mouse wheel methods ------------------------------------------
   
   /**
    * Handles mouse wheel events.
    */
   private class MouseWheelHandler extends PBasicInputEventHandler {
      public void mouseWheelRotated(PInputEvent event) {
         zoomCenterMousePosition = event.getPosition();
         sliderModel.setValue(
            sliderModel.getValue() - event.getWheelRotation());
         zoomCenterMousePosition = null;
      }
   }

   

   // Drag-and-drop methods ----------------------------------------------

   private class DropTargetHandler implements DropTargetListener {
      private DataFlavor[] flavors = { PatternBrowser.PATTERN_SOLUTION_FLAVOR };
      
      public void dragEnter(DropTargetDragEvent dtde) {
      }

      public void dragOver(DropTargetDragEvent dtde) {
      }

      public void dragExit(DropTargetEvent dte) {
      }

      public void dropActionChanged(DropTargetDragEvent dtde) {
      }

      public void drop(DropTargetDropEvent dtde) {
         // Make sure we can handle the type of data that is being dropped.
         DataFlavor flavor = null;
         if (!dtde.isLocalTransfer()) {
            dtde.rejectDrop();
            return;
         }
         else {
            for (int i = 0, n = flavors.length; i < n; i++) {
               if (dtde.isDataFlavorSupported(flavors[i])) {
                  flavor = flavors[i];
                  break;
               }
            }
         }
         
         if (flavor == null) {
            dtde.rejectDrop();
            return;
         }

         if ((dtde.getSourceActions() & ACCEPTABLE_DROP_ACTIONS) == 0) {
            dtde.rejectDrop();
            return;
         }

         Object data = null;
         try {
            dtde.acceptDrop(ACCEPTABLE_DROP_ACTIONS);
            data = dtde.getTransferable().getTransferData(flavor);
            if (data == null) {
               throw new NullPointerException();
            }
            
            // Get the pattern instance being dropped.
            final PatternSolution solution = (PatternSolution)data;

            final Point2D.Double layerDropPt =
               new Point2D.Double(
                  dtde.getLocation().getX(),
                  dtde.getLocation().getY());
            getCamera().localToView(layerDropPt);
            
            final Page dropPage = getDropTarget(layerDropPt);

            // Drop the instance on a page, or on the canvas background.
            final Page dragPage =
               ((Dialog)solution.getDialogs().get(0)).getFirstPage(
                  getDeviceType());

            final Command newCommand;
            
            if (dropPage == null) {
               newCommand =
                  new AddPatternInstanceCommand(
                     getDocument().getGraph(),
                     solution.getPattern(),
                     dragPage,
                     layerDropPt);
            }
            else {
               newCommand =
                  new AddPatternInstanceCommand(
                     getDocument().getGraph(),
                     solution.getPattern(),
                     dragPage,
                     dropPage);
            }
            
            PatternInstanceView.setAutoReshape(false);
            getDocument().getCommandQueue().doCommand(
               DamaskCanvas.this, newCommand);
            PatternInstanceView.reshapeAll();
            PatternInstanceView.setAutoReshape(true);
         }
         catch (Throwable t) {
            DamaskAppExceptionHandler.log(t);
            dtde.dropComplete(false);
         }
      }
   }
   
   
   /**
    * Returns the target of a drag-and-drop action.
    */
   protected abstract Page getDropTarget(final Point2D layerDropPt);

   // Command queue methods ----------------------------------------------

   /**
    * Listens for command events. 
    */
   private class CommandHandler implements CommandListener {
      private void update(CommandEvent e) {
         getRunFromHomeAction().setEnabled(!getDocument().getGraph().getDialogs(
            getDeviceType()).isEmpty());
         
         // If the canvas' window has focus, then pan and zoom the canvas back
         // to where it was when the command was first executed
         if (SwingUtilities.getWindowAncestor(DamaskCanvas.this).isFocused()) {
            if (((DamaskCanvas)e.getCanvas()).getDeviceType() == getDeviceType()) {
               final AffineTransform canvasTransform = e.getCanvasTransform();
               if (!canvasTransform.equals(getCamera().getViewTransform())) {
                  setZoomLevel(getNearestZoomLevel(canvasTransform.getScaleX()));
                  getCamera().setViewTransform(canvasTransform);
               }
            }
         }
      }
      
      public void commandExecuted(CommandEvent e) {
         update(e);
      }

      public void commandUndone(CommandEvent e) {
         update(e);
      }

      public void commandRedone(CommandEvent e) {
         update(e);
      }
   }

   // Page manipulation methods ------------------------------------------
   
   /**
    * Returns what node the cursor is in.
    */
   public PNode getInsideNode() {
      return insideNode;
   }
   
   /**
    * Sets what node the cursor is in.
    */
   public void setInsideNode(final PNode node) {
      if (node == insideNode) {
         return;
      }
      
      setModeEventHandlerEnabled(false);
      insideNode = node;
      setModeEventHandlerEnabled(true);
   }


   /**
    * Returns the currently selected window.
    */
   protected DamaskWindow getCurrentWindow() {
      return currentWindow;
   }
   

   /**
    * Sets whether the drag bar or size grip is currently being dragged. Only
    * called by DragBar and SizeGrip.
    */
   public void setWindowBoundsChanging(final boolean flag) {
      windowIsManipulated = flag;
      
      // If the user has just stopped manipulating the page, then
      // update the transform of the underlying page model.
      if (!flag) {
         // Getting the bounds of the PPath directly results in 0.5 error
         // in both dimensions (because it takes into account the width of the
         // stroke used to draw the PPath), so instead, we get the bounds
         // from the PPath's general path.
         final Rectangle2D currentWindowBounds =
            currentWindow.getPathReference().getBounds2D();
         final AffineTransform currentWindowTransform = currentWindow.getTransform();
         final InteractionElement currentWindowModel = currentWindow.getModel();
         final DeviceType deviceType = getDeviceType();
         
         final MacroCommand command = new ModifyGraphMacroCommand();

         if (!currentWindowModel.getBounds(deviceType).equals(currentWindowBounds)) {
            command.addCommand(
               new SetBoundsCommand(
                  currentWindowModel,
                  deviceType,
                  currentWindowBounds));
         }

         if (!currentWindowModel.getTransform(deviceType).equals(currentWindowTransform)) {
            command.addCommand(
               new SetTransformCommand(
                  currentWindowModel,
                  deviceType,
                  currentWindowTransform));
         }

         if (!command.isEmpty()) {
            getDocument().getCommandQueue().doCommand(this, command);
         }
      }
      
      if (flag) {
         stopTextEditing();         
      }
   }


   /**
    * Returns whether the drag bar or size grip is currently being dragged. 
    */
   public boolean isWindowBoundsChanging() {
      return windowIsManipulated;
   }


   /**
    * Attaches the drag bar and size grip to the given node, removing it
    * from any node it was previously attached to. 
    */
   public void attachHandles(final DamaskWindow window, final PCamera camera) {
      if (window == currentWindow) {
         return;
      }
      
      if (currentWindow != null) {
         SizeGrip.removeFrom(currentWindow);
         DragBar.removeFrom(currentWindow);
      }
      
      currentWindow = window;
      fireSelectedPageChanged();
   
      if (currentWindow != null) {
         SizeGrip.addTo(currentWindow, camera);
         DragBar.addTo(currentWindow, camera);
      }
   }
   

   /**
    * Returns the selected objects in this canvas.
    */
   public Collection/*<PNode>*/ getSelectedObjects() {
      return selectionEventHandler.getSelection();
   }
   
   
   /**
    * Returns the objects that will be copied in a Copy action.
    */
   public Collection/*<PNode>*/ getObjectsToCopy() {
      return objectsToCopy;
   }
   
   
   /**
    * Returns the objects that will be copied in a Copy action.
    */
   protected void setObjectsToCopy(final Collection/*<PNode>*/ objectsToCopy) {
      this.objectsToCopy = objectsToCopy;
   }
   
   
   /**
    * Returns the page region that the contents of the clipboard should
    * be pasted into.
    */
   public abstract PageRegion getPasteTargetPageRegion();
   
   
   /**
    * Returns the page whose view the user is currently interacting with.
    */
   public abstract Page getSelectedPage();

   // Selection change methods ------------------------------------------

   /**
    * Handles changes what objects are selected on this canvas.
    */
   private class SelectionChangeHandler implements CanvasListener {
      public void selectionChanged(CanvasEvent e) {
         assert e.getCanvas() == DamaskCanvas.this :
               "should be receiving events from "
               + DamaskCanvas.this + ", not " + e.getCanvas();

         final Collection/*<PNode>*/ selectedObjects = getSelectedObjects();
          
         final boolean hasSelected = !selectedObjects.isEmpty();
         cutAction.setEnabled(hasSelected);
         copyAction.setEnabled(hasSelected);
         deleteAction.setEnabled(hasSelected);
         changeLayerOfObjectAction.setEnabled(hasSelected);
      }

      public void selectedPageChanged(CanvasEvent e) {
         assert e.getCanvas() == DamaskCanvas.this :
            "should be receiving events from " +
            DamaskCanvas.this + ", not " + e.getCanvas();
      }
   }   

   // Popup menus ----------------------------------------------
   
   /**
    * Returns the event handler for pop-up menus.
    */
   protected PopupMenuEventHandler getPopupMenuEventHandler() {
      return popupMenuEventHandler;
   }
   
   
   /**
    * Returns the proper pop-up context menu, depending on what objects
    * are currently selected.
    */
   public JPopupMenu getPopupMenu(
      final PNode pickedNode,
      final boolean isPickedNodeSelectable) {

      return plainPopupMenu;
   }

   // Menu actions ---------------------------------------------

   /**
    * Returns the action that copies the selected items into the clipboard.
    */
   public Action getCopyAction() {
      return copyAction;
   }

   /**
    * Returns the action that cuts the selected items into the clipboard.
    */
   public Action getCutAction() {
      return cutAction;
   }

   /**
    * Returns the action that deletes the selected items.
    */
   public Action getDeleteAction() {
      return deleteAction;
   }

   /**
    * Returns the action that pastes the contents of the clipboard.
    */
   public Action getPasteAction() {
      return pasteAction;
   }

   /**
    * Returns the action that changes what layer the selected object is in.
    */
   public Action getChangeLayerOfObjectAction() {
      return changeLayerOfObjectAction;
   }

   /**
    * Returns the action that runs the design from the home page.
    */
   public abstract Action getRunFromHomeAction();

   /**
    * Returns the action that runs the design from the selected page.
    */
   public abstract Action getRunFromSelectedPageAction();

   /**
    * Returns the action that copies the selected page into the clipboard.
    */
   public abstract Action getCopyPageAction();

   /**
    * Returns the action that cuts the selected page into the clipboard.
    */
   public abstract Action getCutPageAction();

   /**
    * Returns the action that deletes the selected page.
    */
   public abstract Action getDeletePageAction();

   /**
    * Returns the action that pastes the contents of the clipboard if the
    * contents contain a page.
    */
   public abstract Action getPastePageAction();

   /**
    * Returns the action that sets the home page to the selected page.
    */
   public abstract Action getSetHomePageAction();

   /**
    * Listens for cut actions.
    */
   private class CutAction extends AbstractAction {
      public CutAction() {
         super("Cut");
         putValue(SHORT_DESCRIPTION, "Cuts the selected object into the clipboard");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_T));
         putValue(
            ACCELERATOR_KEY,
            KeyStroke.getKeyStroke(
               'X',
               Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("cut.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("cut.png"));
      }
      
      public void actionPerformed(ActionEvent e) {
         logger.info("Begin cut");
         DamaskCanvas.this.copyAction.actionPerformed(e);
         DamaskCanvas.this.deleteAction.actionPerformed(e);
         logger.info("End cut");
      }
   }


   /**
    * Listens for copy actions.
    */
   private class CopyAction extends AbstractAction {
      public CopyAction() {
         super("Copy");
         putValue(SHORT_DESCRIPTION, "Copies the selected object into the clipboard");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_C));
         putValue(
            ACCELERATOR_KEY,
            KeyStroke.getKeyStroke(
               'C',
               Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("copy.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("copy.png"));
      }
      
      public void actionPerformed(ActionEvent e) {
         logger.info("Begin copy");
         objectsToCopy = getSelectedObjects();
         final TransferHandler handler = getTransferHandler();
         handler.exportToClipboard(
            DamaskCanvas.this,
            Toolkit.getDefaultToolkit().getSystemClipboard(),
            TransferHandler.COPY);
         DamaskCanvas.this.pasteAction.setEnabled(true);
         logger.info("End copy");
      }
   }


   /**
    * Listens for paste actions.
    */
   private class PasteAction extends AbstractAction {
      public PasteAction() {
         super("Paste");
         putValue(SHORT_DESCRIPTION, "Pastes the contents of the clipboard");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_P));
         putValue(
            ACCELERATOR_KEY,
            KeyStroke.getKeyStroke(
               'V',
               Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("paste.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("paste.png"));
      }
      
      public void actionPerformed(ActionEvent e) {
         logger.info("Begin paste");
         final Clipboard clipboard =
            Toolkit.getDefaultToolkit().getSystemClipboard();
         final Transferable clipData = clipboard.getContents(this);
         if (clipData != null) {
            final TransferHandler handler =
               getTransferHandler();
            if (handler
               .canImport(DamaskCanvas.this, clipData.getTransferDataFlavors())) {
               final DamaskLayer layer = (DamaskLayer)getLayer();
               
               layer.clearTrackedNewAdditions();
               layer.startTrackingNewAdditions();
               handler.importData(DamaskCanvas.this, clipData);
               layer.stopTrackingNewAdditions();
               
               selectionEventHandler.unselectAll(DamaskCanvas.this);
               
               for (Iterator i = layer.getTrackedNewAdditions().iterator();
                    i.hasNext(); ) {
                  final WeakReference/*<InteractionElementView>*/ viewRef =
                     (WeakReference)i.next();
                  final InteractionElementView view =
                     (InteractionElementView)viewRef.get();
                  if (view.isSelectable() && (view instanceof ComponentView)) {
                     selectionEventHandler.select(view, DamaskCanvas.this);
                  }
               }
            }
         }
         logger.info("End paste");
      }
   }


   /**
    * Listens for delete actions.
    */
   private class DeleteAction extends AbstractAction {
      public DeleteAction() {
         super("Delete");
         putValue(SHORT_DESCRIPTION, "Deletes the selected object");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_D));
         putValue(
            ACCELERATOR_KEY,
            KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0));
         
         putValue(Action.SMALL_ICON,
            DamaskToolbar.getToolbarIcon("delete.png"));
         putValue(DamaskAppUtils.PROPERTY_DISABLED_ICON,
            DamaskToolbar.getToolbarDisabledIcon("delete.png"));
      }
      
      public void actionPerformed(ActionEvent e) {
         getDocument().getCommandQueue().doCommand(DamaskCanvas.this,
            DamaskAppUtils.createDeleteObjectsCommand(
               DamaskCanvas.this,
               getSelectedObjects()));
      }
   }


   /**
    * Listens for actions that changes the layer of the selected objects.
    */
   private class ChangeLayerOfObjectAction extends AbstractAction {
      public ChangeLayerOfObjectAction() {
         super("Move Objects to \"This Device\" Layer");
         putValue(SHORT_DESCRIPTION, "Changes the layer of the selected objects");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_L));
      }

      public void actionPerformed(ActionEvent e) {
         final Set/*<PNode>*/ pickedNodes =
            new HashSet/*<PNode>*/(getSelectedObjects());

         // Instead of pushing individual radio buttons, we push all of the
         // related radio buttons as a group.
         final Set/*<PNode>*/ nodesToAdd = new HashSet();
         final Set/*<PNode>*/ nodesToRemove = new HashSet();
         for (Iterator i = pickedNodes.iterator(); i.hasNext(); ) {
            final PNode node = (PNode)i.next();
            if (node instanceof RadioButton) {
               nodesToAdd.add(node.getParent());
               nodesToRemove.add(node);
            }
            else if (node instanceof Prompt) {
               nodesToAdd.add(((Prompt)node).getParent());
            }
            else if (node instanceof Response.TextGroup) {
               nodesToAdd.add(((Response.TextGroup)node).getResponse().getParent());
            }
         }
         pickedNodes.addAll(nodesToAdd);
         pickedNodes.removeAll(nodesToRemove);

         
         final DeviceTypeLayer deviceTypeLayer =
            ((DamaskLayer)getLayer()).getDeviceTypeLayer();
         final MacroCommand cmd = new ModifyGraphMacroCommand();
         for (Iterator i = pickedNodes.iterator(); i.hasNext(); ) {
            final PNode node = (PNode)i.next();
            if (node instanceof ComponentView || node instanceof VoiceComponent) {
               final Component component =
                  (Component)((InteractionElementView)node).getModel();
               
               // If we are removing a check box, radio button, drop-down
               // box, list box, or text box, then in the voice version,
               // there might be a trigger placeholder afterwards. We
               // need to remove it.
               if (((component instanceof SelectOne) ||
                    (component instanceof SelectMany.Item) ||
                    (component instanceof TextInput)) &&
                   component.isVisibleToDeviceType(DeviceType.VOICE)) {
                  
                  final Control nextControl =
                     DamaskUtils.getNextLowLevelControl(
                        ((Control)component).getPageRegion(DeviceType.VOICE),
                        (Control)component);
                  
                  if ((nextControl instanceof Trigger) &&
                      !nextControl.isForAllDeviceTypes() &&
                      DamaskCanvas.this.getDeviceType() != DeviceType.VOICE) {
                     cmd.addCommand(
                        new RemoveControlCommand(nextControl));
                  }
               }
               
               if (deviceTypeLayer == DamaskLayer.DeviceTypeLayer.ALL) {
                  cmd.addCommand(
                     new SplitComponentIntoDeviceSpecificVersionsCommand(
                        component, getDeviceType()));
               }
               else {
                  if (component.getDialog().getDeviceType() == DeviceType.ALL) {
                     cmd.addCommand(
                        new ReplaceComponentWithDeviceAllVersionCommand(
                           component));
                  }
               }
            }
         }
         if (!cmd.isEmpty()) {
            getDocument().getCommandQueue().doCommand(DamaskCanvas.this, cmd);
         }
         setEnabled(!getSelectedObjects().isEmpty());
      }
   }
}
