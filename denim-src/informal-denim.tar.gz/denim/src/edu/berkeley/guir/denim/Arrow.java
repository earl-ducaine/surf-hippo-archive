package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.debugging.*;
import java.awt.*;
import java.awt.geom.*; 
import javax.swing.ImageIcon;

/**
 * An arrow in Denim that represents a link between two panels. There are two
 * types of links (and arrows).
 * 
 * Organizational links say that there is a relationship between two panels,
 * but the exact relationship is left vague. They are represented by gray
 * arrows.
 * 
 * Navigational links say that by performing some operation on the source of
 * the arrow, the program will go to the destination of the arrow. They are
 * represented by green arrows.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  2.0.1  06-11-2003 YL
 *                    fixed clone problems
 *             2.0.1  02-16-2003 YL
 *                    Added enforcedReanchor to ensure the start point and 
 * 	                  end point of an arrow are in the right place
 * 
 *             2.0.1  11-06-2002 YL
 *                    Added ArrowProperty to enable interactively modification of event type
 *                      - add left-click, mouse-enter and mouse-exit icons
 *                    Modified DefaultRender to enable fading in&out
 *                    Added method of retrieving source&dest panel
 *                    
 *                    01-02-2003 YL
 *                    Enabled the feature that arrows anchor at edges of labels when leaving a label at
 *                    the edge of pages when entering a page: reanchorStart, reanchorEnd
 * 
 * 			   2.0.0  02-22-2000 JH
 *                    Retrofitted for SATINv2
 *             1.0.0  08-18-1999 MWN
 *                    Created class Arrow
 *  * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~newman/">Mark Newman</A> (
 *          <A HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * 
 * @since   JDK 1.3RC1
 * @version Version 2.0.0, 02-16-2003
 */
public class Arrow extends TimedCurvyStroke 
   implements DenimConstants, Watcher {
     
   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -1994804511520263552L;

   //-----------------------------------------------------------------

   // Types of arrows
   public static final int ORG = 0;
   public static final int NAV = 1;
   
   public static final double[] fadingfactors = new double[6];
   
   private static float fadingFactor = 1;
   
   static {
   	  fadingfactors[0] = 0;
   	  fadingfactors[1] = 0.1;
   	  fadingfactors[2] = 0.4;
   	  fadingfactors[3] = 0.6;
   	  fadingfactors[4] = 0.9;
   	  fadingfactors[5] = 1;
   }
               
   //-----------------------------------------------------------------

   private static final double DEFAULT_ARROWHEAD_ANGLE = Math.PI / 4;
   private static final double DEFAULT_ARROWHEAD_LENGTH = 8.0;
   
   private static final double arrowheadAngle  = DEFAULT_ARROWHEAD_ANGLE;
   private static final double arrowheadLength = DEFAULT_ARROWHEAD_LENGTH;

//   private static Image left1Img = null;
   private static Image exitImg = null;
   private static Image enterImg = null;
   private static Image left2Img = null;
   private static Image right1Img = null;
   private static Image right2Img = null;
   private static Image timerImg = null;
   
   private boolean afterUndoDelete = false;
   
   // whether this arrow is originated from a current condition of a page
   // if a page is not conditional, it has one condition and this always is true.
   //private boolean isInCurrentCondition = true; 
   
   static {
   	
       left2Img = Toolkit.getDefaultToolkit().
                   getImage(Denim.class.getResource("images/eventicons/double-left-click.gif"));
       right1Img = Toolkit.getDefaultToolkit().
                   getImage(Denim.class.getResource("images/eventicons/single-right-click.gif"));
       right2Img = Toolkit.getDefaultToolkit().
                   getImage(Denim.class.getResource("images/eventicons/double-right-click.gif"));
       timerImg = Toolkit.getDefaultToolkit().
                   getImage(Denim.class.getResource("images/eventicons/timer.gif"));
       exitImg = Toolkit.getDefaultToolkit().
                   getImage(Denim.class.getResource("images/eventicons/mouse-exit.gif"));
       enterImg = Toolkit.getDefaultToolkit().
                   getImage(Denim.class.getResource("images/eventicons/mouse-enter.gif"));
//       left1Img = Toolkit.getDefaultToolkit().
//                   getImage(Denim.class.getResource("images/eventicons/single-left-click.gif"));
   }

   //===   CONSTANTS   =========================================================
   //===========================================================================

        /** 
         *        I believe this inner class holds information about "other" arrows
         * because there are 3 instances of arrows.  I assume this from the comments
         * of the calcAlternateArrows function -- Robert
         */
   //===========================================================================
   //===   INNER CLASSES   =====================================================
   
   private class ArrowInfo {
      ArrowSource source;
      ArrowDest   dest;
      
      public ArrowInfo() {
      }
      
      public ArrowInfo(ArrowInfo old) {
         source = old.source;
         dest = old.dest;
      }
      
      public String toString() {
         return "ArrowInfo: source = " + DenimUtils.toShortString(source) +
                "; dest = " + DenimUtils.toShortString(dest);
      }
   }
   
   //===   INNER CLASSES   =====================================================
   //===========================================================================
   

   //===========================================================================
   //===   INNER CLASSES   =====================================================

   
   /**
    * Arrow Property is for input event type of a hyperlink
    */
   
   public class ArrowProperty {

      private Arrow connectedArrow = null;
      private static final int radius = 32;

      private Rectangle2D area = null;

      public ArrowProperty(Arrow arrow) {
         connectedArrow = arrow;
      } // of constructor

      public Rectangle2D getBox() {
         return area;
      }
      
      public void render(SatinGraphics g) {

         Polygon2D poly = connectedArrow.getPolygon2D(COORD_LOCAL);

         String eventType = getInputEventType();

         int x = (int) poly.xpoints[0] + 10;
         int y = (int) poly.ypoints[0];
         int width = radius;
         int height = radius;
         

		 AffineTransform backup = g.getTransform();
		 g.getGraphics().setTransform(AffineTransform.getTranslateInstance(0,0));

		 // get the start point's sensitive left-top corner
         Point2D roundPoint = new Point2D.Double();
         
         double tx = poly.xpoints[0] - radius / 2;
         double ty = poly.ypoints[0] - radius / 2;
            
         backup.transform(new Point2D.Double(tx, ty), roundPoint);
		 // end
		 
         Point2D src = new Point2D.Double(x, y);
         Point2D dst = new Point2D.Double();
         backup.transform(src, dst);
         

         // Determine which icon to draw
         Image eventImg = null;

         if (eventType.equals(DenimIntrinsicComponent.LEFT_CLICK)) {
//            eventImg = left1Img;

            x = (int) (poly.xpoints[0] - width / 2);
            y = (int) (poly.ypoints[0] - height / 2);
            
            src.setLocation(x, y);
	        backup.transform(src, dst);

         }
         else if (eventType.equals(DenimIntrinsicComponent.LEFT_2CLICK)) {
            eventImg = left2Img;
         }
         else if (eventType.equals(DenimIntrinsicComponent.RIGHT_CLICK)) {
            eventImg = right1Img;
         }
         else if (eventType.equals(DenimIntrinsicComponent.RIGHT_2CLICK)) {
            eventImg = right2Img;
         }
         else if (DenimIntrinsicComponent.compareEventTypes(
               DenimIntrinsicComponent.TIMER,
               eventType)) {
            eventImg = timerImg;
         }
         else if (eventType.equals(DenimIntrinsicComponent.MOUSE_EXIT)) {
            eventImg = exitImg;
         }
         else if (eventType.equals(DenimIntrinsicComponent.MOUSE_ENTER)) {
            eventImg = enterImg;
         }
         
         x = (int)dst.getX();
         y = (int)dst.getY();

         
         if (!eventType.equals(DenimIntrinsicComponent.LEFT_CLICK)) {

            // Get width and height of icon
            ImageIcon eventIcon = new ImageIcon(eventImg);

            width = eventIcon.getIconWidth();
            height = eventIcon.getIconHeight();

            g.drawImage(eventImg, x, y, width, height, null);
            
            if (DenimIntrinsicComponent.compareEventTypes(
                  DenimIntrinsicComponent.TIMER,
                  eventType)) {
               Font origFont = g.getFont();
               Font newFont =
                  origFont.deriveFont(origFont.getSize2D());
               g.setFont(newFont);
               g.drawString(eventType.substring(6) + " sec", x + 3, y - 3);
               g.setFont(origFont);
            }
         }


         area = new Rectangle2D.Double(dst.getX(), dst.getY(), width, height);
         
         Rectangle2D.union(area, 
         	new Rectangle2D.Double(roundPoint.getX(),roundPoint.getY(),
            ArrowProperty.radius, ArrowProperty.radius), area);

		 g.getGraphics().setTransform(backup);
		 
      } // render
      

   }
   //===   INNER CLASSES   =====================================================
   //===========================================================================
   

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private static boolean ignoreEndpointMove = false;
   
   private ArrowSource        source;
   private ArrowDest          dest;
   private String             eventType;
   private int                condition;   // the design-time condition
                                           // that the source's panel was in
                                           // when the arrow was created
   private String             outputEvent;

   // The source that the user specified. The real source of the arrow is the
   // user source, converted to a hyperlink instance if it is not already a
   // component instance.
   private GraphicalObject    userSource;
   
   private ArrowSource        origSource;
   private ArrowDest          origDest;
   
   private long                globalDestID;
   
   // for saving purposes
   private TimedStroke        origStroke;
   
   // info about what the arrow looks like in overview
   private ArrowInfo          overviewArrowInfo = new ArrowInfo();
                         
   // info about what the arrow looks like in sitemap view
   private ArrowInfo          sitemapArrowInfo = new ArrowInfo();

   // info about what the arrow looks like in storyboard view and below
   private ArrowInfo          storyboardArrowInfo = new ArrowInfo();
   
   //// relative location of point on source or dest object, between 0 and 1.
   private float              srcX;
   private float              srcY;
   private float              dstX;
   private float              dstY;

   //// Soft state optimization variables
   private Point2D            ptAA = new Point2D.Float();
   private Point2D            ptBB = new Point2D.Float();
   private Rectangle2D        rectAA = new Rectangle2D.Float();
   
   
   // Yang Li
   public ArrowProperty arrowProperty = null;
   
   
   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================
   


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================


   /**
    * Default constructor. Called only by the cloning methods.
    */
   protected Arrow() {
      super();  
      this.enableSelectionRender(false);      
   }
    
   /**
    * Creates an arrow connecting the given source and destination objects,
    * with the same stroke as the given stroke, and the given event type and 
    * output event.
    */
   public Arrow(TimedStroke stk, String eventType, int condition,
                GraphicalObject userSource, ArrowDest dest) {

      this(stk, eventType, DEFAULT_EVENT, condition, userSource, dest);

	   // for arrow property
      arrowProperty = new ArrowProperty(this);
      this.enableSelectionRender(false);
   }


   public Arrow(TimedStroke stk, String eventType, String outputEvent, 
                int condition, GraphicalObject userSource, ArrowDest dest) {

      super(stk);
      //debug.println("User source: " + DenimUtils.toShortString(userSource));

      this.eventType = eventType;
      this.outputEvent = outputEvent;
      this.condition = condition;
      this.userSource = userSource;
      this.dest = dest;
      origDest = dest;
      origStroke = new TimedCurvyStroke(stk, true);
      
      //for Arrow property
      arrowProperty = new ArrowProperty(this);      
      this.enableSelectionRender(false);
   }
   //===   CONSTRUCTORS   ======================================================
   //===========================================================================
   
   public void setGlobalDstID(long id) {
       this.globalDestID = id;
   }
   
   public long getGlobalDstID() {
       return this.globalDestID;
   }
   
   public Rectangle2D getPropertyArea()
   {
   	 return this.arrowProperty.getBox();
   }
   
   /**
    * work in ABS coor
    */
   public boolean closeToPropertyPoint(Point2D p) {

	  if(getPropertyArea()==null)
	  	return false;
	  	
   	  return getPropertyArea().contains(p);

   }


   
   //===========================================================================
   //===   ARROW METHODS   =====================================================
   /**
    * Calculate the relative location of the arrows to the sketch.
    */
   private void calcRelativeEndpoints() {
      Rectangle2D       rect;
      Point2D           pt;

      //// 1. Calculate source
      rect = DenimUtils.getTrueAbsBds(source);
      pt   = getStartPoint2D(COORD_ABS);
      srcX = (float) ((pt.getX() - rect.getX()) / rect.getWidth());
      srcY = (float) ((pt.getY() - rect.getY()) / rect.getHeight());

      // Debugging output.
      /*
      debug.println("calculating relative endpoints for arrow #: " + getUniqueID());
      debug.println("abs start pt: " + pt);
      debug.println("source: " + DenimUtils.toShortString(source));
      debug.println("   parent: " + DenimUtils.toShorterString(source.getParentGroup()));
      debug.println("   abs bds: " + rect);
      debug.println("   rel bds: " + source.getBounds2D(COORD_REL));
      debug.println("   local bds: " + source.getBounds2D(COORD_LOCAL));
      if (source instanceof DenimLabel) {
         DenimLabel label = (DenimLabel)source;
         AffineTransform tx = new AffineTransform();
         debug.println("   sticky transform  : " + ((edu.berkeley.guir.denim.view.LabelViewWrapper) ( ((edu.berkeley.guir.lib.satin.view.SemanticZoomMultiViewImpl)label.getView()).get(0) )).getStickyTransform(tx));
         debug.println("   unsticky local bds: " + label.getUnstickyLocalBounds());
      }
      debug.println("src: " + srcX + ", " + srcY);
      */
                      
      //// 2. Calculate destination
      if (dest != null) {
         rect = DenimUtils.getTrueAbsBds(dest);
         pt   = getEndPoint2D(COORD_ABS);
         dstX = (float) ((pt.getX() - rect.getX()) / rect.getWidth());
         dstY = (float) ((pt.getY() - rect.getY()) / rect.getHeight());
         
         //      Debugging output.
         /*
         debug.println("abs end pt: " + pt);
         debug.println("dest: " + DenimUtils.toShortString(dest));
         debug.println("   parent: " + DenimUtils.toShorterString(dest.getParentGroup()));
         debug.println("   abs bds: " + rect);
         debug.println("   rel bds: " + dest.getBounds2D(COORD_REL));
         debug.println("dst: " + dstX + ", " + dstY);
         */
      }
   }

   /**
    * Sets the current source and destination of the arrow, from the original
    * source and destination and the current zoom level of the arrow's sheet.
    */
   private void calcSourceAndDest() {
      //// 1. Get the zoom level of the containing sheet at which the arrow
      ////    was created.
      double sheetScale =
              GraphicalObjectLib.getScaleFactor(COORD_ABS, this.getSheet());

      //// 2. Readjust the source and destination of the arrow
      if (sheetScale <= OVERVIEW_SCALE_FACTOR + 0.01) {
              source = overviewArrowInfo.source;
         dest = overviewArrowInfo.dest;
      }
      else if (OVERVIEW_SCALE_FACTOR + 0.01 < sheetScale &&
               sheetScale <= SITEMAP_SCALE_FACTOR + 0.01) {
         source = sitemapArrowInfo.source;
         dest = sitemapArrowInfo.dest;
      }
      else {
         source = storyboardArrowInfo.source;
         dest = storyboardArrowInfo.dest;
      }
   }
   
   /**
    * Each "arrow" has three arrows, each corresponding to three different
    * groups of levels: overview, sitemap, and everything else. This method
    * figures out which level the current arrow belongs to, and calculates
    * the other two arrows.
    */
   private void calcAlternateArrows() {
      //debug.println("alternate arrows for " + DenimUtils.toShortString(this));
      //// 1. Figure out which panels the arrow is attached to.
      DenimPanel srcPanel = origSource.getPanel();
      if(origDest==null)
      {
          GraphicalObject gob = ((DenimWindow)Denim.getWindows().get(0)).getDenimUI()
                          .getSheet().getID(this.globalDestID);
          origDest = (ArrowDest)gob;
      }
      
      DenimPanel dstPanel = origDest.getPanel();
      
      //// 2. Calculate the three arrows
      if (origSource instanceof DenimLabel) {
         overviewArrowInfo.source = srcPanel.getSketch();
      }
      else {
         overviewArrowInfo.source = origSource;
      }
      if (origDest instanceof DenimCustomComponent){
                        overviewArrowInfo.dest = origDest;
                        sitemapArrowInfo.dest = origDest;
      }
      else{
                        overviewArrowInfo.dest = dstPanel.getSketch();
                        sitemapArrowInfo.dest = dstPanel.getLabel();
      }

      sitemapArrowInfo.source = srcPanel.getLabel();
      storyboardArrowInfo.source = origSource;
      storyboardArrowInfo.dest = origDest;
   }   
   
   //-----------------------------------------------------------------
   
   /**
    * Called after the arrow has been added to a sheet.
    */
   public void initAfterAddToSheet() {
       
      //debug.println("initAfterAddToSheet");
      // If the user source isn't an arrow source, convert it
      // to a hyperlink instance
      if (!(userSource instanceof ArrowSource)) {
         DenimComponentRegistry reg = DenimComponentRegistry.getInstance();

         DenimHyperlink hyperlinkClass =
            ((DenimHyperlink)(reg.getComponent("DenimHyperlink")));

         //debug.println("User source - before: " + DenimUtils.toShortString(userSource));

         if(!(userSource.getParentGroup() instanceof DenimHyperlinkInstance))
             source =
                 (DenimHyperlinkInstance)hyperlinkClass.newInstance(userSource);
         else
             source = (DenimHyperlinkInstance)userSource.getParentGroup();
         //debug.println("            - after: " + DenimUtils.toShortString(userSource));
      }
      else {
         source = (ArrowSource)userSource;
      }
      origSource = source;
      
      // Decide whether the arrow is an org or nav arrow
      Style style = getStyleRef();
      if (source instanceof DenimComponentInstance) {
         style.setDrawColor(DEFAULT_NAV_ARROW_COLOR);
      }
      else {
         style.setDrawColor(DEFAULT_ORG_ARROW_COLOR);
      }

      calcSourceAndDest();
      calcAlternateArrows();
      calcSourceAndDest();
      calcRelativeEndpoints();
      
      // Have the source and destination track the arrow
      origSource.trackArrow(this);
      source.addWatcher(this);
      if (dest != null && origDest != null) {
         origDest.trackIncomingArrow(this);
         dest.addWatcher(this);
      }
         
      origStroke.setVisible(false);
      getParentGroup().add(origStroke);
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Called only by DOMUtils.addArrowFromDOMElement
    */
   public void initAfterAdd(AffineTransform xform) {
      //debug.println("init after add for " + DenimUtils.toShortString(this));
      
      // The delete undoes the effect of initAfterAddToSheet(), which was
      // automatically called by SATIN when this arrow was added to the
      // sheet.
      origStroke.delete();
      
      setTransform(xform);
      initAfterAddToSheet();
      origStroke.setTransform(xform);
   }

   //-----------------------------------------------------------------

   /**
    * Readjusts the start point of the arrow so that it is correct.
    */
   private void reanchorStartPt() {
       
       if(this.isGlobal())
           return;

      // debug.println("reanchorStartPt");
      //// HACK: If parent is null, bail. This shouldn't need to happen
      //// since the parent is only null if the arrow has been deleted.
      if (getParentGroup() == null || source == null || dest == null) {
         return;
      }

      //// 1. Change the start point of the arrow on screen.
      // Get the new start point in absolute coordinates
      rectAA.setRect(DenimUtils.getTrueAbsBds(source));

	  if(((DenimSheet)getSheet()).getAbsScale()>(DenimConstants.OVERVIEW_SCALE_FACTOR+DenimConstants.BETWEEN_OVERVIEW_SITEMAP_SCALE_FACTOR)/2)
	  {
	
	      if(source instanceof DenimLabel)
	      {
	    	  Rectangle2D sheetBs = this.getSheet().getBounds2D(COORD_ABS);
		     
		      if(sheetBs.intersects(rectAA))
		      {
		      	Rectangle2D.intersect(rectAA, sheetBs, rectAA);
		      }
	      }
	      
	  }
               
      ptAA.setLocation(rectAA.getX() + srcX * rectAA.getWidth(),
                       rectAA.getY() + srcY * rectAA.getHeight());
      
      // Get the new start point in relative coordinates
      GraphicalObjectLib.absoluteToLocal(this.getParentGroup(), ptAA, ptAA);

      // Get the current start point in relative coordinates
      ptBB.setLocation(getStartPoint2D(COORD_REL));
      
      // Move the arrow from the current start point to the new
      // one
      applyTransform(AffineTransform.getTranslateInstance(
                       ptAA.getX() - ptBB.getX(),
                       ptAA.getY() - ptBB.getY()));

      //// 2. Change the start point of the original arrow.
      
      // Get the new start point in absolute coordinates
      rectAA.setRect(DenimUtils.getTrueAbsBds(origSource));

	  if(((DenimSheet)getSheet()).getAbsScale()>(DenimConstants.OVERVIEW_SCALE_FACTOR+DenimConstants.BETWEEN_OVERVIEW_SITEMAP_SCALE_FACTOR)/2)
	  {
	                  
	      if(origSource instanceof DenimLabel)
	      {
	    	  Rectangle2D sheetBs = this.getSheet().getBounds2D(COORD_ABS);
		      
		     
		      if(sheetBs.intersects(rectAA))
		      {
		      	Rectangle2D.intersect(rectAA, sheetBs, rectAA);
		      }
	      }
	  
	  }
	        
      ptAA.setLocation(rectAA.getX() + srcX * rectAA.getWidth(),
                       rectAA.getY() + srcY * rectAA.getHeight());
      
      // Get the new start point in relative coordinates
      if(origStroke.getParentGroup()!=null)
          GraphicalObjectLib.absoluteToLocal(origStroke.getParentGroup(),
                                         ptAA, ptAA);
      else
          System.err.println("parent is null");

      // Get the current start point in relative coordinates
      ptBB.setLocation(origStroke.getStartPoint2D(COORD_REL));
      
      // Move the arrow from the current start point to the new
      // one
      origStroke.applyTransform(AffineTransform.getTranslateInstance(
                       ptAA.getX() - ptBB.getX(),
                       ptAA.getY() - ptBB.getY()));
   }
 
   /**
    * Readjusts the end point of the arrow so that it is correct.
    */
   private void reanchorEndPt() {
       
       if(this.isGlobal())
           return;
       
      // debug.println("reanchorEndPt");
      if (getParentGroup() == null || source == null || dest == null) {
         return;
      }
      

      //// 1. Change the endpoint of the arrow on screen.
 
      rectAA.setRect(DenimUtils.getTrueAbsBds(dest));

      
	  if(((DenimSheet)getSheet()).getAbsScale()>(DenimConstants.OVERVIEW_SCALE_FACTOR+DenimConstants.BETWEEN_OVERVIEW_SITEMAP_SCALE_FACTOR)/2)
	  {
      
	      if(dest instanceof DenimLabel)
	      {
	    	  Rectangle2D sheetBs = this.getSheet().getBounds2D(COORD_ABS);
		      
		     
		      if(sheetBs.intersects(rectAA))
		      {
		      	Rectangle2D.intersect(rectAA, sheetBs, rectAA);
		      }
	      }

	  }

       /*debug.println("dest: abs bounds = " + rectAA);
      debug.println("arrow: abs bounds = " + this.getBounds2D(COORD_ABS));
      debug.println("       rel bounds = " + this.getBounds2D(COORD_REL));
      debug.println("       rel stk = " + this.getPolygon2D(COORD_REL));*/
      
               
      ptAA.setLocation(rectAA.getX() + dstX * rectAA.getWidth(),
                       rectAA.getY() + dstY * rectAA.getHeight());
                       
      this.changePoint(getNumPoints() - 1, ptAA.getX(), ptAA.getY());
      
      //debug.println("new end point: abs = " + ptAA);
      
      //// 2. Change the endpoint of the original arrow.
      rectAA.setRect(DenimUtils.getTrueAbsBds(origDest));

	  if(((DenimSheet)getSheet()).getAbsScale()>(DenimConstants.OVERVIEW_SCALE_FACTOR+DenimConstants.BETWEEN_OVERVIEW_SITEMAP_SCALE_FACTOR)/2)
	  {

	      if(origDest instanceof DenimLabel)
	      {

	    	  Rectangle2D sheetBs = this.getSheet().getBounds2D(COORD_ABS);
		      
		     
		      if(sheetBs.intersects(rectAA))
		      {
		      	Rectangle2D.intersect(rectAA, sheetBs, rectAA);
		      }
	      }

	  }
	  
      ptAA.setLocation(rectAA.getX() + dstX * rectAA.getWidth(),
                       rectAA.getY() + dstY * rectAA.getHeight());
      origStroke.changePoint(origStroke.getNumPoints() - 1,
                             ptAA.getX(), ptAA.getY());
        
   }
   
   
   //-----------------------------------------------------------------
   /**
    * try reanchor first, if it dosen't work, force the ends of the arrow in its nodes
    */

   public void enforcedReanchor() {

      this.getSheet().disableDamage();   	
      
   	  reanchor();

   	  Point2D startT = this.getStartPoint2D(COORD_ABS);
   	  
   	  ArrowSource sp = this.getSource();
   	  
   	  if(!sp.getBounds2D(COORD_ABS).contains(startT))
   	  {
//   	  	System.out.println("startT is in trouble");
        Rectangle2D sheetB = this.getSheet().getBounds2D(COORD_ABS);
        Rectangle2D sourceB = sp.getBounds2D(COORD_ABS);
        Rectangle2D targetB = (Rectangle2D)sourceB.clone();

        if(sourceB.intersects(sheetB))
        {
        	Rectangle2D.intersect(sourceB, sheetB, targetB);
        }

        this.changePoint(0, targetB.getX()+6, targetB.getY()+6);  
        this.setLocalBoundingPoints2DRef(this.getPolygon2D(COORD_LOCAL));

   	  }
   	  
   	  Point2D endT = this.getEndPoint2D(COORD_ABS);
   	  
   	  DenimPanel dp = this.getDestPanel();
   	  
   	  if(!dp.getBounds2D(COORD_ABS).contains(endT))
   	  {
//   	    System.out.println("endT is in trouble");	
        Rectangle2D sheetB = this.getSheet().getBounds2D(COORD_ABS);
        Rectangle2D destB = dp.getBounds2D(COORD_ABS);
        Rectangle2D targetB = (Rectangle2D)destB.clone();

        if(destB.intersects(sheetB))
        {
        	Rectangle2D.intersect(destB, sheetB, targetB);
        }

        this.changePoint(getNumPoints() - 1, targetB.getX()+6, targetB.getY()+6);  
        this.setLocalBoundingPoints2DRef(this.getPolygon2D(COORD_LOCAL));        

   	  }
   	  
      this.getSheet().enableDamage();   	  
      
   }

      
   //-----------------------------------------------------------------
   /**
    * Readjusts the arrow so that the start and end points of the arrow
    * are correct.
    * 
    * This method is needed when the arrow starts or ends in a label.
    * As the user zooms in and out, the label stays sticky, so the
    * coordinates of the arrow's endpoints actually change.
    */
   public void reanchor() {
       
       
       // *****
       if(this.isGlobal()
               ||this.getSheet()==null)
           return;
       
      //debug.println("reanchoring " + DenimUtils.toShortString(this));
      //debug.println("source = " + DenimUtils.toShortString(source));
      //debug.println("dest = " + DenimUtils.toShortString(dest));
      //debug.println("overview = " + overviewArrowInfo);
      //debug.println("sitemap = " + sitemapArrowInfo);
      //debug.println("storyboard = " + storyboardArrowInfo);
      //// HACK: If parent is null, bail. This shouldn't need to happen
      //// since the parent is only null if the arrow has been deleted.
      if (getParentGroup() == null || source == null || dest == null) {
         return;
      }

      //// 1. Since the source and destination of the arrow may change,
      ////    stop watching the original source and destination.
      source.removeWatcher(this);
      dest.removeWatcher(this);
      
      //// 2. Readjust the source and destination of the arrow
      calcSourceAndDest();

      /*if (getStyle().getDrawColor().equals(DEFAULT_NAV_ARROW_COLOR)) {
         debug.println("Nav arrow: " + DenimUtils.toShortString(this));
      }
      else {
         debug.println("Org arrow: " + DenimUtils.toShortString(this));
      }
      debug.println("source: " + DenimUtils.toShortString(source));
      debug.println("  " + source.getBounds2D(COORD_ABS));
      debug.println("dest: " + DenimUtils.toShortString(dest));
      debug.println("  " + dest.getBounds2D(COORD_ABS));*/
      
      //// 3. Readjust the anchor points within the source and destination
      reanchorStartPt();
      reanchorEndPt();
      
      //// 4. If the source and destination don't match the original source
      ////    and destination, then straighten the arrow. Eventually,
      ////    we want to do something more intelligent here, to keep
      ////    the general curviness of the arrow.
      if ((source != origSource) || (dest != origDest)) {
         StrokeLib.straighten(this);
      }
      else {
         this.disableDamage();
         clearPoints();
         int n = origStroke.getNumPoints();
         TimedPolygon2D tpoly =
            new TimedPolygon2D(origStroke.getPolygon2D(COORD_LOCAL));
         for (int i = 0; i < n; i++) {
            this.addPoint(tpoly.xpoints[i], tpoly.ypoints[i], tpoly.times[i]);
         }
         this.enableDamage();
      }
      

      //// 5. Start watching the new source and destination.
      source.addWatcher(this);
      dest.addWatcher(this);
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Returns the type of event that this arrow represents.
    */
   public String getInputEventType() {
      return eventType;
   }
   
   //-----------------------------------------------------------------
   /**
    * Returns the type of output event that this arrow represents.
    */
   public String getOutputEventType() {
      return outputEvent;
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Returns the condition that the arrow's source's panel was in when
    * the arrow was created.
    */
   public int getCondition() {
      return condition;
   }
   
   public void setCondition(int con) {
       condition = con;
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Returns the type of arrow (Arrow.NAV or Arrow.ORG).
    */
   public int getType() {
      Style style = getStyleRef();
      Color color = style.getDrawColor();
      if (color.equals(DEFAULT_ORG_ARROW_COLOR)) {
         return ORG;
      }
      else if (color.equals(DEFAULT_NAV_ARROW_COLOR)) {
         return NAV;
      }
      else {
         assert false; // "Arrow isn't ORG or NAV"
         return -1;
      }
   }

   //-----------------------------------------------------------------
   /**
    * Returns the source of this arrow.
    */
   public ArrowSource getSource() {
      return source;
   }
   
   //-----------------------------------------------------------------
   /**
    * Returns the source panel of this arrow.
    */
	public DenimPanel getSourcePanel() {
		
	  	GraphicalObject obj = source;
	    while(obj!=null&&!(obj instanceof DenimPanel))
	    {
			obj = obj.getParentGroup(); 	
	    }
		return (DenimPanel)obj;
	}   
   
   
   //-----------------------------------------------------------------
   /**
    * Returns the dest panel of this arrow.
    */
	public DenimPanel getDestPanel() {
		
		if(dest instanceof DenimPanel)
			return (DenimPanel)dest;
	
	    if(dest instanceof DenimSketch)
	    	return dest.getPanel();
	    
	    if(dest instanceof DenimLabel)
	    	return dest.getPanel();
	    
	    return ((DenimSketch)dest.getParentGroup()).getPanel();

	}  
	
   //-----------------------------------------------------------------
   /**
    * Returns the destination of this arrow.
    */
   public ArrowDest getDest() {
      return dest;
   }
   
   //-----------------------------------------------------------------
   /**
    * Returns the original source of this arrow.
    */
   public ArrowSource getOrigSource() {
      return origSource;
   }
   
   //-----------------------------------------------------------------
   /**
    * Returns the original destination of this arrow.
    */
   public ArrowDest getOrigDest() {
      return origDest;
   }
   
   //-----------------------------------------------------------------
   /**
    * Returns the original stroke which created the arrow.
    */
   public TimedStroke getOrigStroke() {
      return origStroke;
   }

   //-----------------------------------------------------------------
   /**
    * Returns the original transform of the arrow. Used by DOMUtils.
    */
   public AffineTransform getOrigTransform() {
      return origStroke.getTransform(COORD_REL);
   }
   
   static public double getArrowheadLength() {
      return arrowheadLength;
   }
   
   static public double getArrowheadAngle() {
   	  return arrowheadAngle;
   }
   
   //-----------------------------------------------------------------
   /**
    * Sets the source of this arrow to the given object (or null if the
    * arrow source is unattached).
    */
/*   public void setSource(ArrowSource newSource) {
      if (source != null) {
         source.removeWatcher(this);
         source.untrackArrow(this);
      }
      source = newSource;
      if (source != null) {
         source.addWatcher(this);
         source.trackArrow(this);
      }
      
      Style style = getStyleRef();
      if (source instanceof DenimComponentInstance) {
         style.setDrawColor(DEFAULT_NAV_ARROW_COLOR);
      }
      else {
         style.setDrawColor(DEFAULT_ORG_ARROW_COLOR);
      }
   }
  */ 
   //-----------------------------------------------------------------
   /**
    * Sets the destination of this arrow to the given object (or null if the
    * arrow dangles).
    */
   public void setDest(ArrowDest newDest) {
      if (dest != null) {
         dest.removeWatcher(this);
         dest.untrackIncomingArrow(this);
      }
      dest = newDest;
      if (dest != null) {
         dest.addWatcher(this);
         dest.trackIncomingArrow(this);
      }
   }

   //-----------------------------------------------------------------
   /**
    * only called by DenimClipboard now
    */
   
   public void setUserSource(GraphicalObject newUserSource) {
      userSource = newUserSource;
   }
   
   //-----------------------------------------------------------------
      
   public GraphicalObject getUserSource() {
      return userSource;
   }

   
   //-----------------------------------------------------------------
   /**
    * Sets the original source of this arrow to the given object (or null
    * if the arrow source is unattached). The original source differs from
    * the source in that the source may change depending on zoom level
    * (via semantic zooming), while the original source never changes.
    */
/*   public void setOrigSource(ArrowSource newSource) {
      if (source != null) {
         source.removeWatcher(this);
         source.untrackArrow(this);
      }
      origSource = newSource;
      if (getSheet() != null) {
         calcAlternateArrows();
         reanchor();
      }
   }
  */ 
   //-----------------------------------------------------------------
   /**
    * Sets the original destination of this arrow to the given object (or
    * null if the arrow destination is unattached). The original destination
    * differs from the destination in that the destination may change
    * depending on zoom level (via semantic zooming), while the original
    * destination never changes.
    */
   public void setOrigDest(ArrowDest newDest) {
      if (dest != null) {
         dest.removeWatcher(this);
         dest.untrackIncomingArrow(this);
      }
      origDest = newDest;
      if (getSheet() != null) {
         calcAlternateArrows();
         reanchor();
      }
   }
   
   //-----------------------------------------------------------------
   
   public void setUndoTrouble() {
   	  this.afterUndoDelete = true;
   }   
   
   public boolean hasUndoTrouble() {
   	  return this.afterUndoDelete;
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Renders the arrow in the given transparency.
    */
   protected void defaultRender(SatinGraphics g) {
	  
       if(this.globalDestID!=0)
           return;
       
       if(Arrow.fadingFactor > 0) {
          
         float oldFade = g.getTransparency();

         g.setTransparency(fadingFactor);

		 if(this.getSheet()==null)
		 	return;
		 	
         if (((DenimSheet) getSheet()).getAbsScale()
            > (DenimConstants.OVERVIEW_SCALE_FACTOR
               + DenimConstants.BETWEEN_OVERVIEW_SITEMAP_SCALE_FACTOR)
               / 2
            && RadarViewPanel.isRadarViewRendering() == false) {
            drawArrowheads(g);
         }

         super.defaultRender(g);

         if (((DenimSheet) getSheet()).getAbsScale()
            > (DenimConstants.BETWEEN_SITEMAP_STORYBOARD_SCALE_FACTOR
               + DenimConstants.STORYBOARD_SCALE_FACTOR)
               / 2
            && RadarViewPanel.isRadarViewRendering() == false) {
            this.arrowProperty.render(g);
         }

         g.setTransparency(oldFade);

      }
   }
   //-----------------------------------------------------------------
   
   /**
    * Don't override this method. Instead, add a View to the ViewHandler.
    */
/*   public final void render(SatinGraphics g) {
      //// 0.1. Quick check if we are visible or not.
      ////      Automatically deselect ourself if we are not visible.
      ////      Also, don't render if we are not visible.

      super.render(g);
      
      Rectangle box1 = new Rectangle
      box1 = g.getClipBounds(box1);
	  System.out.println("clip of g " + box1.toString());
	  
	  Rectangle2D box2 = new Rectangle2D.Double();
	  box2 = getBounds2D(COORD_LOCAL, null, box2);
	  System.out.println("clip of arrow " + box2.toString());

   } // of method
*/
   //-----------------------------------------------------------------
   /**
    * Draws the arrowheads and beginning dot for this arrow.
    */
   private void drawArrowheads(SatinGraphics g) {
      Polygon2D poly;
      int [] retpoints = new int[6];
      double scale = 1.0 / 
         GraphicalObjectLib.getScaleFactor(COORD_REL, getParentGroup().getSheet());
      
      //=== 1. Get the stroke points
      poly = this.getPolygon2D(COORD_LOCAL);
      assert poly.npoints >= 2; // "An arrow needs at least two points."
      
      //=== 2. Draw a circle at the beginning of the arrow, to make it stand
      //       out.
      int startCircleRadius = (int)(arrowheadLength * scale);
      g.setColor(getStyle().getDrawColor());
      g.fillOval((int) poly.xpoints[0] - startCircleRadius / 2,
                 (int) poly.ypoints[0] - startCircleRadius / 2,
                 startCircleRadius,
                 startCircleRadius);
      
      //=== 3. If this arrow is not a single-left-click arrow, then draw an icon to show the type
/*      String eventType = getInputEventType();
      if (eventType != DenimIntrinsicComponent.LEFT_CLICK) {
         int x = (int) poly.xpoints[0] + 5;
         int y = (int) poly.ypoints[0];
         int w = (int) scale * 13;
         int h = (int) scale * 18;
         
         if (eventType == DenimIntrinsicComponent.LEFT_2CLICK) {
            g.drawImage(left2Img, x, y, w, h, null);
         }
         else if (eventType == DenimIntrinsicComponent.RIGHT_CLICK) {
            g.drawImage(right1Img, x, y, w, h, null);
         }
         else if (eventType == DenimIntrinsicComponent.RIGHT_2CLICK) {
            g.drawImage(right2Img, x, y, w, h, null);
         }
         else if (DenimIntrinsicComponent.compareEventTypes(DenimIntrinsicComponent.TIMER, eventType)) {
            Font origFont = g.getFont();
            Font newFont = origFont.deriveFont(origFont.getSize2D() *
                                               (float)scale);
            g.setFont(newFont);
            g.drawString(eventType.substring(6) + " sec", x + 3, y - 3);
            g.setFont(origFont);
            //g.drawImage(timerImg, x, y, w, h, null);
         }
      }*/




      //=== 4. Compute the arrowhead parameters
      computeArrowheadParams(poly.xpoints, poly.ypoints, poly.npoints,
                             scale, retpoints);
      
      //=== 5. Draw the arrowheads
      Polygon arrowhead = new Polygon();
      arrowhead.addPoint(retpoints[0], retpoints[1]);
      arrowhead.addPoint(retpoints[2], retpoints[3]);
      arrowhead.addPoint(retpoints[4], retpoints[5]);
      g.fillPolygon(arrowhead);
      
      //TODO: force repaint of the arrowhead region

      //If the arrow has an output event - draw it next to the arrow head.
      String outputEvent = getOutputEventType();
      if (outputEvent != null) {
          g.drawString(outputEvent,
                       ((int) poly.xpoints[poly.npoints - 1]),
                       ((int) poly.ypoints[poly.npoints - 1]));
      }
   }
   
   public boolean isGlobal() {
       return this.globalDestID!=0;
   }

   //-----------------------------------------------------------------
   /**
    * Given arrays of x and y coordinates, computes the endpoints of the
    * two arrowhead line segments and returns them in the array retpoints.
    * 
    * @param xpoints      the x coordinates of the arrow stem (excluding the pre
    *                     and post lines)
    * @param ypoints      the y coordinates of the arrow stem (excluding the pre
    *                     and post lines)
    * @param npoints      the number of points in the arrow stem
    * @param scaleFactor  the factor by which to multiply the arrowhead length                      
    * @param retpoints    must be instantiated outside this method and passed 
    *                     in the return values are [x0, y0, x1, y1, x2, y2] 
    *                     where                                     
    * <ul>
    * <li>(x0,y0) is the end point of the arrow stroke itself
    * <li>(x1,y1) is the end point of the arrowhead segment in the 
    *     clockwise direction        
    * <li>(x2,y2) is the end point of the arrowhead segment in the 
    *     counterclockwise direction
    * </ul>
    */
   public static void computeArrowheadParams(float[] xpoints,
                                              float[] ypoints,
                                              int npoints,
                                              double scaleFactor,
                                              int [] retpoints) {
      
      Point last = new Point();
      Point penult = new Point();
      int x1, x2, y1, y2, x1Offset, x2Offset;
      double m1, m2, b1, b2;
      double th;
      
      //=== 1. Get last two points of the stroke      
      //HACK: currently using the last & 4th to last points to get "best-fit" line for arrow
      last.x = (int) xpoints[npoints - 1];
      last.y = (int) ypoints[npoints - 1];
      if (npoints < 9) {
         penult.x = (int) xpoints[npoints - 2]; 
         penult.y = (int) ypoints[npoints - 2]; 
      }
      else {
         penult.x = (int) xpoints[npoints - 8]; 
         penult.y = (int) ypoints[npoints - 8];      
      }
         
      //=== 2. Get angle of the stroke w.r.t. the x-axis
      th = Math.atan((double)(last.y - penult.y) / (double)(last.x - penult.x));
      if (last.x > penult.x) {
         th = Math.PI + th;
      }
      if (last.x == penult.x) { // handle the case where arrow slope is infinity
         if (last.y > penult.y) {
            th = -Math.PI / 2.0;
         }
         else {
            th = Math.PI / 2.0;
         }
      }
      
      //=== 3. Determine x coordinates of arrowhead endpoints            
      x1Offset = (int) (arrowheadLength * scaleFactor * Math.cos(th + arrowheadAngle));
      x2Offset = (int) (arrowheadLength * scaleFactor * Math.cos(th - arrowheadAngle));
      x1 = last.x + x1Offset;
      x2 = last.x + x2Offset;
           
      //=== 4. Determine linear equations for arrowhead segments
      m1 = Math.tan(th + arrowheadAngle);
      m2 = Math.tan(th - arrowheadAngle);
      b1 = last.y - m1 * last.x;
      b2 = last.y - m2 * last.x;
      
      //=== 5. Get y values
      y1 = (int) (m1 * x1 + b1);
      y2 = (int) (m2 * x2 + b2);

      //=== 6. Handle case where the slope of an arrowhead is (close to) infinity
      if ((x1 == last.x && y1 == last.y) || m1 > 1000000.0 || m1 < -1000000.0) {
         if (last.y > penult.y) {
            y1 = (int) (last.y - arrowheadLength * scaleFactor);
         }
         else {
            y1 = (int) (last.y + arrowheadLength * scaleFactor);
         }
      }
      if ((x2 == last.x && y2 == last.y) || m2 > 1000000.0 || m2 < -1000000.0) {
         if (last.y > penult.y) {
            y2 = (int) (last.y - arrowheadLength * scaleFactor);
         }
         else {
            y2 = (int) (last.y + arrowheadLength * scaleFactor);
         }
      }

      retpoints[0] = last.x;
      retpoints[1] = last.y;
      retpoints[2] = x1;
      retpoints[3] = y1;
      retpoints[4] = x2;
      retpoints[5] = y2;
      
      /*
      debug.println("th (deg)                  = " + th * 180 / Math.PI);
      debug.println("arrowheadAngle (deg)      = " + arrowheadAngle * 180 / Math.PI);
      debug.println("th + arrowheadAngle (deg) = " + (th + arrowheadAngle) * 180 / Math.PI);
      debug.println("  cos(th + arrowheadAngle)= " + Math.cos(th + arrowheadAngle));
      debug.println("th - arrowheadAngle (deg) = " + (th - arrowheadAngle) * 180 / Math.PI);
      debug.println("  cos(th - arrowheadAngle)= " + Math.cos(th - arrowheadAngle));
      debug.println("last = " + last);
      debug.println("  m1     = " + m1);
      debug.println("  x1, y1 = " + x1 + ", " + y1);
      debug.println("  m2     = " + m2);
      debug.println("  x2, y2 = " + x2 + ", " + y2);
      debug.println();
      */
   }
   
   //-----------------------------------------------------------------

   /**
    * Called by the DenimCustomComponent constructor so that it can set the
    * location of panels without affected any attached arrows.
    */
   public static void setIgnoreEndpointMove(boolean flag) {
      ignoreEndpointMove = flag;
   }

   //===   ARROW METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Returns a shallow clone of this arrow.
    */
   public Object clone() {
      Arrow arrow = new Arrow();
      super.clone(arrow);
      arrow.source = source;
      arrow.dest = dest;
      arrow.origSource = origSource;
      arrow.origDest = origDest;
      arrow.storyboardArrowInfo = storyboardArrowInfo;
      arrow.sitemapArrowInfo = sitemapArrowInfo;
      arrow.overviewArrowInfo = overviewArrowInfo;
      arrow.eventType = eventType;
      arrow.outputEvent = outputEvent; 
      arrow.srcX = srcX;
      arrow.srcY = srcY;
      arrow.dstX = dstX;
      arrow.dstY = dstY;
      arrow.origStroke = origStroke;
      
      //blindly added
      arrow.condition = condition;
      arrow.outputEvent = outputEvent;
      arrow.arrowProperty = new ArrowProperty(arrow);
      arrow.arrowProperty.area = this.arrowProperty.area;
      
      arrow.userSource = userSource;      

      
/*   private Point2D            ptAA = new Point2D.Float();
   private Point2D            ptBB = new Point2D.Float();
   private Rectangle2D        rectAA = new Rectangle2D.Float();
  */ 
      

      //debug.println("clone(): " + getUniqueID() + "->" + arrow.getUniqueID());
      return arrow;
   }

   //-----------------------------------------------------------------

   /**
    * Returns a deep clone of this arrow.
    */
   public Object deepClone() {
      return deepClone(new Arrow());
   }
   
   //-----------------------------------------------------------------

   /**
    * Makes the given arrow into a deep clone of this arrow, and returns
    * the given arrow.
    */
   protected Object deepClone(Arrow clone) {
      super.deepClone(clone);
      //debug.println(clone);
      clone.source = source;
      clone.dest = dest;
      clone.origSource = origSource;
      clone.origDest = origDest;
      clone.storyboardArrowInfo = new ArrowInfo(storyboardArrowInfo);
      clone.sitemapArrowInfo = new ArrowInfo(sitemapArrowInfo);
      clone.overviewArrowInfo = new ArrowInfo(overviewArrowInfo);
      clone.eventType = eventType;
      clone.outputEvent = outputEvent;
      clone.srcX = srcX;
      clone.srcY = srcY;
      clone.dstX = dstX;
      clone.dstY = dstY;
      clone.globalDestID = this.globalDestID;
      clone.origStroke = new TimedStroke(origStroke);
      
      //blindly added
      clone.condition = condition;
      clone.outputEvent = outputEvent;
      clone.arrowProperty = new ArrowProperty(clone);
      clone.arrowProperty.area = this.arrowProperty.area;
      
      clone.userSource = userSource;
      
/*   private Point2D            ptAA = new Point2D.Float();
   private Point2D            ptBB = new Point2D.Float();
   private Rectangle2D        rectAA = new Rectangle2D.Float();
  */ 
   

      //debug.println("deepClone(): " + getUniqueID() + "->" + clone.getUniqueID());
      return clone;      
   }

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   WATCHER METHODS   ===================================================
   /**
    * Removes this arrow but does not alter the source of the arrow in
    * any way.
    */
   public void deleteAndDoNotConvertSource() {
      //debug.println("Deleting " + DenimUtils.toShortString(this) + ": [" + DenimUtils.toShortString(origSource) + "->" + DenimUtils.toShortString(origDest));
      //debug.println("User source: " + DenimUtils.toShortString(userSource));
      //debug.println("Orig source: " + DenimUtils.toShortString(origSource));
      
      super.delete();
      
      source.removeWatcher(this);
      dest.removeWatcher(this);
      
      origStroke.delete();
      
      origSource.untrackArrow(this);
      if (origDest != null) {
         origDest.untrackIncomingArrow(this);
      }
   }
   
   /**
    * Sets the type of event that this arrow represents to the given
    * event type.
    */
   public void setInputEventType(String evttype)
   {
      // Make the arrow's source stop listening for the arrow's original
      // event type
      origSource.untrackArrow(this);
      
      // Change the event type
   		((DenimSheet)this.getSheet()).setModified(true);
   		this.eventType = evttype;
         
      // Make the arrow's source start listening for the arrow's original
      // event type
      origSource.trackArrow(this);
   }

   /**
    * Executes when the arrow is deleted. If the source of the arrow is
    * a hyperlink instance and has no arrows when this arrow is removed,
    * then the contents of the link is added directly back into the
    * scenegraph.
    */
   public void delete() {
   	  
      deleteAndDoNotConvertSource();
      
      // If the source of the arrow doesn't have any arrows coming out of it,
      // and if the source the user originally specified is different from
      // the current source of the arrow, then the original source must have
      // been converted, so convert it back to its original form.
      if (origSource instanceof DenimHyperlinkInstance) {
         DenimHyperlinkInstance link = (DenimHyperlinkInstance)origSource;
         //debug.println("- outgoing arrows count: " + link.getOutgoingArrows().size());
         if (link.getOutgoingArrows().isEmpty() && userSource != link) {
            //debug.println("convert back");
            
            GraphicalObjectGroup parent        = link.getParentGroup();
            AffineTransform      origTransform = link.getTransform(COORD_REL);
            int                  origLayer     = link.getRelativeLayer();
            GraphicalObject      contents      = link.getContents();
      
            //// 1. Remove the hyperlink from its parent.
            link.delete();
            
            //// 2. If the contents' original parent wasn't null, then add the
            ////    contents back to the parent in their original location.
            if (parent != null && origLayer != -1) {
               parent.add(origLayer, contents, GraphicalObjectGroup.KEEP_REL_POS);
               // bug fix: don't lose scaling transform inside contents.  --marcr
               origTransform.concatenate(contents.getTransform(COORD_REL));
               contents.setTransform(origTransform);
            }
         }
      }
   }
     
   //-----------------------------------------------------------------
   
   static public void setFadingFactor(float factor) {
      Arrow.fadingFactor = factor;
   }
   
   //-----------------------------------------------------------------
   
   static public float getFadingFactor() {
      return Arrow.fadingFactor;
   }

   //-----------------------------------------------------------------
   
   public void onNotify(Watchable w, Object arg) {
      //// ignore
   }

   //-----------------------------------------------------------------

   public void onUpdate(Watchable w, Object arg) {
      //// ignore
   }

   //-----------------------------------------------------------------
   /**
    * Updates the endpoints of the arrow when the destination changes.
    */   
   public void onUpdate(Watchable w, String strProperty, 
                        Object oldVal, Object newVal) {
           if (!ignoreEndpointMove) {
                        //// 1.0 Disable screen updates
                        this.disableDamage();

              //// 1.1. Debugging.
              //debug.println("onUpdate(): updating arrow #" + getUniqueID());
              //debug.println("source: " + DenimUtils.toShortString(source));
              //debug.println("dest: " + DenimUtils.toShortString(dest));
              //debug.println("was updated: " + DenimUtils.toShortString((GraphicalObject)w));

              //// 1.2. Calculate the source line
              if (w == source) {
                 Debug.println("calling both (source)");
                 reanchorStartPt();
                 reanchorEndPt();
              }

         //// 1.3. Calculate the dest line
         if (w == dest) {
            Debug.println("calling reanchor endpt (dest)");
            reanchorEndPt();
         }
         
         //// 1.4. Straighten the line so it doesn't look weird. Eventually,
         ////      we want to do something more intelligent here, to keep
         ////      the general curviness of the arrow.
         StrokeLib.straighten(this);
         StrokeLib.straighten(origStroke);
         
         //// 1.5 Re-enable screen updates
         this.enableDamage();
      }
   } // of onUpdate

   //-----------------------------------------------------------------

   public void onDelete(Watchable w) {
      //// 1. If either the source or destination object is deleted,
      ////    we are deleted too.
      this.deleteAndDoNotConvertSource();
   } 
   //===   WATCHER METHODS   ===================================================
   //===========================================================================

   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
   public static void main(String args[]) {
      float[] xp        = {100, 110, 120, 130};
      float[] yp        = {100, 110, 120, 140};
      int[]   retpoints = new int[6];
      
      computeArrowheadParams(xp, yp, 4, 1.0, retpoints);
      Debug.println("Arrow head params for: (" + xp[0] + ", " + yp[0] + 
                         "), (" + xp[3] + ", " + yp[3] + ") \n" +
                         "\t first arrowhead pt: (" + retpoints[2] + ", " + retpoints[3] + ") \n" +
                         "\t second arrowhead pt: (" + retpoints[4] + ", " + retpoints[5] + ") \n");
      
      xp[0] = 130;
      xp[3] = 100;
      yp[0] = 140;
      yp[3] = 100;
  
      computeArrowheadParams(xp, yp, 4, 1.0, retpoints);
      Debug.println("Arrow head params for: (" + xp[0] + ", " + yp[0] + 
                         "), (" + xp[3] + ", " + yp[3] + ") \n" +
                         "\t first arrowhead pt: (" + retpoints[2] + ", " + retpoints[3] + ") \n" +
                         "\t second arrowhead pt: (" + retpoints[4] + ", " + retpoints[5] + ") \n");

      xp[0] = 130;
      xp[3] = 100;
      yp[0] = 100;
      yp[3] = 140;
  
      computeArrowheadParams(xp, yp, 4, 1.0, retpoints);
      Debug.println("Arrow head params for: (" + xp[0] + ", " + yp[0] + 
                         "), (" + xp[3] + ", " + yp[3] + ") \n" +
                         "\t first arrowhead pt: (" + retpoints[2] + ", " + retpoints[3] + ") \n" +
                         "\t second arrowhead pt: (" + retpoints[4] + ", " + retpoints[5] + ") \n");
                         
      xp[0] = 100;
      xp[3] = 130;
      yp[0] = 140;
      yp[3] = 100;
  
      computeArrowheadParams(xp, yp, 4, 1.0, retpoints);
      Debug.println("Arrow head params for: (" + xp[0] + ", " + yp[0] + 
                         "), (" + xp[3] + ", " + yp[3] + ") \n" +
                         "\t first arrowhead pt: (" + retpoints[2] + ", " + retpoints[3] + ") \n" +
                         "\t second arrowhead pt: (" + retpoints[4] + ", " + retpoints[5] + ") \n");
     
      
   }
   
   //----------------------------------------
   
   /**
    * clear all references hold by this object (In the namespace of this class)
    */

      
   public void deepClear() {
      super.deepClear();
  
      source = null;
      dest = null;
      eventType = null;
      outputEvent = null;

      userSource = null;
   
      origSource = null;
      origDest = null;
   
      origStroke = null;
   
      overviewArrowInfo = null;
                         
      sitemapArrowInfo = null;

      storyboardArrowInfo = null;
   
      ptAA = null;
      ptBB = null;
      rectAA = null;
      arrowProperty = null;

   }
   /*
   public void setInCurrentCondition(boolean b) {
	  isInCurrentCondition = b;
   }
   */
   public boolean isInCurrentCondition() {
       if(this.getSourcePanel()!=null
               &&
               this.getSourcePanel().getCurrentDesignTimeCondition()
               ==this.condition)
           return true;
       else
           return false;
   	  //return isInCurrentCondition;
   }
   
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
