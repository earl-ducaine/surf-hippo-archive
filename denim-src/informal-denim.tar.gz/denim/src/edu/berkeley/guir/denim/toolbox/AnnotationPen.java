package edu.berkeley.guir.denim.toolbox;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import java.awt.*;


/**
 * An annotation pen, which allows reviewers to mark up a Denim design.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-15-1999 James Lin
 *                               Created AnnotationPen
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 11-15-1999
 */
public class AnnotationPen
   extends Tool
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //static final long serialVersionUID = -7987898834268005604L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   private static TimedStroke staticTimedStroke;
   private static Style       style;
   private static Style[]     otherStyles;
   private static int         lastStyleNum;

   static {
      // Make the default drawing color of the pen red
      staticTimedStroke = new TimedStroke();
      style = staticTimedStroke.getClassPropertyStyle();
      style.setDrawColor(DEFAULT_ANNO_COLOR);

      // Set up styles for annotations by people other than the current user
      int numOtherStyles = DEFAULT_OTHER_ANNO_COLORS.length;
      otherStyles = new Style[numOtherStyles];

      for (int i = 0; i < numOtherStyles; i++) {
         otherStyles[i] = staticTimedStroke.getClassPropertyStyle();
         otherStyles[i].setDrawColor(DEFAULT_OTHER_ANNO_COLORS[i]);
      }
      lastStyleNum = 0;
   }

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates an annotation pen tool to be placed in the toolbox.
    */
   public AnnotationPen() {
      super("pen.gif",
            new Point(0, 15),
            new Point(5, 31),
            new Point(5, 31),
            "Annotation Pen");
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================


   //===========================================================================
   //===   PEN METHODS   =======================================================

   public void firstAddedToContainer() {
      super.firstAddedToContainer();
      DenimSheet sheet = getDenimUI().getSheet();
      enabledInterpreters.add(sheet.getInkAnnotationInterpreter());
   }

   //-----------------------------------------------------------------

   /**
    * Grabs the tool and enables inking the sheet.
    */
   public void grab() {
      super.grab();
      getDenimUI().getSheet().setInkOn(true);

      // Make the annotation pen always draw red
      staticTimedStroke.setClassPropertyStyle(style);
   }

   //-----------------------------------------------------------------

   /**
    * Returns the default style to use for drawing annotations. The style is
    * for an annotation created by the current user.
    */
   public static Style getClassStyle() {
      return style;
   }

   //-----------------------------------------------------------------

   /**
    * Returns another style to use for drawing annotations. The style is for
    * an annotation created by someone other than the current user.
    */
   public static Style getOtherStyle() {
      Style newStyle = otherStyles[lastStyleNum];
      lastStyleNum++;
      if (lastStyleNum >= DEFAULT_OTHER_ANNO_COLORS.length) {
         lastStyleNum = 0;
      }
      return newStyle;
   }

   //===   PEN METHODS   =======================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
