//// See bottom of source code for software license
package edu.berkeley.guir.lib.awt.geom;

import edu.berkeley.guir.lib.util.StringLib;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.FlatteningPathIterator;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.*;

import sun.awt.geom.Crossings;

/**
 * Higher precision polygon. For Java2D purposes.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A>
 * @version Aug 31 2000
 */
public class Polygon2D 
   implements Cloneable, Shape {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   private static final double FLOATING_PT_TOLERANCE = 0.001;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INNER CLASS   =======================================================

   /**
    * From Javasoft source code...
    */
   private class PolygonPathIterator implements PathIterator {
      Polygon2D       poly;
      AffineTransform transform;
      int             index;

      public PolygonPathIterator(Polygon2D p, AffineTransform tx) {
         poly      = p;
         transform = tx;
      }

      public int getWindingRule() {
         return WIND_EVEN_ODD;
      }

      public boolean isDone() {
         if (flagClosed == true) {
            return (index > poly.npoints);
         }
         else {
            return (index >= poly.npoints);
         }
      }

      public void next() {
         index++;
      }

      public int currentSegment(float[] coords) {
         if (index >= poly.npoints) {
            return SEG_CLOSE;
         }
         coords[0] = poly.xpoints[index];
         coords[1] = poly.ypoints[index];
         if (transform != null) {
            transform.transform(coords, 0, coords, 0, 1);
         }
         return (index == 0 ? SEG_MOVETO : SEG_LINETO);
      }

      public int currentSegment(double[] coords) {
         if (index >= poly.npoints) {
            return SEG_CLOSE;
         }
         coords[0] = poly.xpoints[index];
         coords[1] = poly.ypoints[index];
         if (transform != null) {
            transform.transform(coords, 0, coords, 0, 1);
         }
         return (index == 0 ? SEG_MOVETO : SEG_LINETO);
      }
   } // of inner class

   //===   INNER CLASS   =======================================================
   //===========================================================================



   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   //// Cache of simplified polygons.
   //// Weak hash map ensures that things will get garbage collected correctly.
   static WeakHashMap cacheSimplified = new WeakHashMap(5000);

   //===========================================================================

   //// Bounding box variables.
   float       minX    = Float.POSITIVE_INFINITY;
   float       minY    = Float.POSITIVE_INFINITY;
   float       maxX    = Float.NEGATIVE_INFINITY;
   float       maxY    = Float.NEGATIVE_INFINITY;

   //// Polygon point values.
   //// I hate to make it public, but Javasoft already did...
   public int         npoints = 0;
   public float[]     xpoints = new float[35];
   public float[]     ypoints = new float[35];

   //// Closed or not?
   boolean     flagClosed = true;

   //-----------------------------------------------------------------

   //// internal soft-state
   boolean         flagDirty = true;    // is the soft-state up-to-date?
   Rectangle2D     bounds;              // bounds of the current polygon

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public Polygon2D() {
   } // of constructor

   //-----------------------------------------------------------------

   public Polygon2D(Rectangle r) {
      addPoint(r.x,           r.y);
      addPoint(r.x + r.width, r.y);
      addPoint(r.x + r.width, r.y + r.height);
      addPoint(r.x,           r.y + r.height);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a new Polygon2D approximating the specified Shape.
    * Assumes the paths go in straight lines, mostly because that's
    * easier to program.
    */
   public Polygon2D(Shape s) {
      this(s.getPathIterator(null));
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a new Polygon2D approximating the specified PathIterator.
    */
   public Polygon2D(PathIterator it) {
      setToPathIterator(it);
   } // of constructor

   //-----------------------------------------------------------------

   public Polygon2D(int[] xpoints, int[] ypoints, int npoints) {
      for (int i = 0; i < npoints; i++) {
         addPoint(xpoints[i], ypoints[i]);
      }
   } // of constructor

   //-----------------------------------------------------------------

   public Polygon2D(float[] xpoints, float[] ypoints, int npoints) {
      for (int i = 0; i < npoints; i++) {
         addPoint(xpoints[i], ypoints[i]);
      }
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * @param xpoints is the array of x coordinates.
    * @param ypoints is the array of y coordinates.
    * @param start   is the index to start at.
    * @param len     is the total number of array elements to copy.
    */
   public Polygon2D(float[] xpoints, float[] ypoints, int start, int len) {
      for (int i = start; i < start + len; i++) {
         addPoint(xpoints[i], ypoints[i]);
      }
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================





   //===========================================================================
   //===   SHAPE METHODS   =====================================================

   /**
    * Fast check to see if a point is in the bounds. Internal method.
    */
   private boolean isInBoundsInternal(double x, double y) {
      if (x < minX || x > maxX || y < minY || y > maxY) {
         return (false);
      }
      return (true);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Update the soft-state constructive bounding box.
    *
    * Updates only if flagDirty is true. 
    * Assumes minX, minY, maxX, maxY are all correct and up-to-date.
    */
   private void updateInternal() {
      if (flagDirty == true) {
         flagDirty = false;
         if (npoints <= 0) {
            bounds    = null;
         }
         else if (npoints == 1) {
            bounds    = new Rectangle2D.Float(minX, minY, 0, 0);
         }
         else {
            float w   = maxX - minX;
            float h   = maxY - minY;

            //// Near to 0, just set to 0.
            if (w < FLOATING_PT_TOLERANCE) {
               w = 0.0f;
            }
            if (h < FLOATING_PT_TOLERANCE) {
               h = 0.0f;
            }

            bounds    = new Rectangle2D.Float(minX, minY, w, h);
         }
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the cached bounding box.
    */
   private Rectangle2D getBounds2DInternal() {
      updateInternal();
      return (bounds);
   } // of method

   //===========================================================================

   private Crossings getCrossings(double xlo, double ylo,
                                  double xhi, double yhi) {

      Crossings cross = new Crossings.EvenOdd(xlo, ylo, xhi, yhi);
      float lastx = xpoints[npoints - 1];
      float lasty = ypoints[npoints - 1];
      float curx; 
      float cury;

      // Walk the edges of the polygon
      for (int i = 0; i < npoints; i++) {
         curx = xpoints[i];
         cury = ypoints[i];
         if (cross.accumulateLine(lastx, lasty, curx, cury)) {
            return (null);
         }
         lastx = curx;
         lasty = cury;
      }

      return cross;
   } // of method

   //-----------------------------------------------------------------

   public boolean contains(double x, double y) {
      // From Javasoft...

      //// 1. Cheap quick checks. 
      ////    Cannot contain anything if it has 0 or 1 points.
      ////    Also must be contained by bounding box.
      if (npoints <= 2 || isInBoundsInternal(x, y) == false) {
         return (false);
      }

      //// 2. Normal check.
      int hits = 0;

      float lastx = xpoints[npoints - 1];
      float lasty = ypoints[npoints - 1];
      float curx; 
      float cury;

      // Walk the edges of the polygon
      for (int i = 0; i < npoints; lastx = curx, lasty = cury, i++) {
         curx = xpoints[i];
         cury = ypoints[i];

         if (cury == lasty) {
            continue;
         }

         float leftx;
         if (curx < lastx) {
            if (x >= lastx) {
                continue;
            }
            leftx = curx;
         } 
         else {
            if (x >= curx) {
               continue;
            }
            leftx = lastx;
         }

         double test1, test2;
         if (cury < lasty) {
            if (y < cury || y >= lasty) {
               continue;
            }
            if (x < leftx) {
               hits++;
               continue;
            }
            test1 = x - curx;
            test2 = y - cury;
         } 
         else {
            if (y < lasty || y >= cury) {
               continue;
            }
            if (x < leftx) {
               hits++;
               continue;
            }
            test1 = x - lastx;
            test2 = y - lasty;
         }

         if (test1 < (test2 / (lasty - cury) * (lastx - curx))) {
            hits++;
         }
      }

      return ((hits & 1) != 0);

   } // of method

   //-----------------------------------------------------------------

   public boolean contains(double x, double y, double w, double h) {
      //// 1. Cannot contain anything if no points.
      if (npoints <= 0 || !getBounds2DInternal().intersects(x, y, w, h)) {
         return (false);
      }

      //// 2. Normal check.
      Crossings cross = getCrossings(x, y, x+w, y+h);
      return (cross != null && cross.covers(y, y+h));
   } // of method

   //-----------------------------------------------------------------

   public boolean contains(Point2D pt) {
      return (contains(pt.getX(), pt.getY()));
   } // of method

   //-----------------------------------------------------------------

   public boolean contains(Rectangle2D r) {
      return (contains(r.getMinX(),  r.getMinY(), 
                       r.getWidth(), r.getHeight()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * @deprecated should use getBounds2D in SATIN and DENIM instead.
    */
   public Rectangle getBounds() {
      Rectangle2D r = getBounds2DInternal();
      if (r == null) {
//         throw new RuntimeException("Polygon bounds not defined if 0 points");
         return (new Rectangle(0, 0, 0, 0));
      }
      else {
         return (new Rectangle((int) r.getX(),     (int) r.getY(), 
                               (int) r.getWidth(), (int) r.getHeight()));
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * @return null if there are 0 points.
    */
   public Rectangle2D getBounds2D() {
      Rectangle2D r = getBounds2DInternal();
      if (r == null) {
//         throw new RuntimeException("Polygon bounds not defined if 0 points");
         return (new Rectangle2D.Float(0, 0, 0, 0));
      }
      else {
         return (new Rectangle2D.Float(
                         (float) r.getX(),     (float) r.getY(), 
                         (float) r.getWidth(), (float) r.getHeight()));
      }
   } // of method

   //-----------------------------------------------------------------

   public PathIterator getPathIterator(AffineTransform tx) {
      return (new PolygonPathIterator(this, tx));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Does same as other {@link #getPathIterator(AffineTransform)}.
    * Flatness is ignored.
    */
   public PathIterator getPathIterator(AffineTransform tx, double flatness) {
      return (getPathIterator(tx));
   } // of method

   //-----------------------------------------------------------------

   public boolean intersects(double x, double y, double w, double h) {
      // From Javasoft...

      //// 1. Cannot intersect anything if no points.
      if (npoints <= 0 || !getBounds2DInternal().intersects(x, y, w, h)) {
         return (false);
      }

      //// 2. Normal check.
      Crossings cross = getCrossings(x, y, x+w, y+h);
      return (cross == null || !cross.isEmpty());
   } // of method

   //-----------------------------------------------------------------

   public boolean intersects(Rectangle2D r) {
      return (intersects(r.getMinX(),  r.getMinY(), 
                         r.getWidth(), r.getHeight()));
   } // of method

   //===   SHAPE METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   POLYGON METHODS   ===================================================

   public void setToShape(Shape s) {
      setToPathIterator(s.getPathIterator(null));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Clear out the old polygon, set the polygon to be the specified
    * PathIterator.
    *
    * <PRE>
    * 4 = PathIterator.SEG_CLOSE
    * 3 = PathIterator.SEG_CUBICTO
    * 2 = PathIterator.SEG_QUADTO
    * 1 = PathIterator.SEG_LINETO
    * 0 = PathIterator.SEG_MOVETO
    * 1 = PathIterator.WIND_NON_ZERO
    * 0 = PathIterator.WIND_EVEN_ODD
    * </PRE>
    */
   public void setToPathIterator(PathIterator it) {
      npoints   = 0;
      setClosed(false);

      float[]                ptsArray = new float[6];
      int                    segtype;
      FlatteningPathIterator fpi      = new FlatteningPathIterator(it, 1);

      while (fpi.isDone() == false) {
         segtype = fpi.currentSegment(ptsArray);
         switch (segtype) {
            case PathIterator.SEG_CLOSE:
               setClosed(true);
               break;
            default:
               addPoint(ptsArray[0], ptsArray[1]);
         }

         fpi.next();
      }

      updateBounds();
      flagDirty = true;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set this polygon to be the same as the specified one.
    */
   public void setPoly(Polygon2D poly) {
      //// 1. Ensure we have enough space.
      if (this.xpoints.length < poly.xpoints.length) {
         xpoints = new float[poly.xpoints.length];
         ypoints = new float[poly.xpoints.length];
      }

      //// 2. Copy the values over.
      System.arraycopy(poly.xpoints, 0, xpoints, 0, poly.npoints);
      System.arraycopy(poly.ypoints, 0, ypoints, 0, poly.npoints);
      npoints = poly.npoints;

      //// 3. Mark as dirty.
      flagDirty = true;
      updateBounds();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set this polygon to be the same as the specified one.
    */
   public void setPoly(Polygon poly) {
      //// 1. Ensure we have enough space.
      if (this.xpoints.length < poly.xpoints.length) {
         xpoints = new float[poly.xpoints.length];
         ypoints = new float[poly.xpoints.length];
      }

      //// 2. Copy the values over.
      for (int i = 0; i < poly.npoints; i++) {
         xpoints[i] = poly.xpoints[i];
         ypoints[i] = poly.ypoints[i];
      }
      npoints = poly.npoints;

      //// 3. Mark as dirty.
      flagDirty = true;
      updateBounds();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set whether this polygon is a closed polygon or not.
    */
   public void setClosed(boolean flag) {
      flagClosed = flag;
   } // of method

   /**
    * Check whether this polygon is a closed polygon or not.
    */
   public boolean isClosed() {
      return (flagClosed);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the size of the x and y arrays.
    * Points will be dropped if the new length is smaller than the current
    * length.
    */
   private void setArraySize(int newlen) {
      //// 1. Make new arrays of the right size.
      float[] xpointsNew = new float[newlen];
      float[] ypointsNew = new float[newlen];
      boolean flagUpdate = (newlen < npoints);

      //// 2. Copy the data over.
      System.arraycopy(xpoints, 0, xpointsNew, 0, Math.min(npoints, newlen));
      System.arraycopy(ypoints, 0, ypointsNew, 0, Math.min(npoints, newlen));

      xpoints = xpointsNew;
      ypoints = ypointsNew;

      //// 3. Update the bounds if the new length is smaller than before.
      if (flagUpdate == true) {
         flagDirty = true;
         npoints   = newlen;
         updateBounds();
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Trim the size of the array for space purposes.
    * Do this only if you know that the polygon won't be 
    * modified any time soon.
    */
   public void trim() {
      //// 1. Trim the arrays.
      if (npoints > 0 && xpoints.length > npoints) {
         setArraySize(npoints);
      }
   } // of trim

   //-----------------------------------------------------------------

   public void addPoint(Point2D pt) {
      this.addPoint(pt.getX(), pt.getY());
   } // of method

   public void addPoint(double x, double y) {
      //// 1. Grow the array if it is too small.
      if (xpoints.length <= npoints) {
         setArraySize(2*xpoints.length);
      }

      //// 2. Add the point.
      xpoints[npoints] = (float) x;
      ypoints[npoints] = (float) y;
      npoints++;

      //// 3. Update bounds.
      updateBounds(x, y);

      //// 4. Mark as internally dirty.
      flagDirty = true;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Remove all points from this polygon.
    */
   public void clearPoints() {
      npoints = 0;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Translate by a certain amount.
    */
   public void translate(double dx, double dy) {
      //// 1. Shift each of the points over.
      for (int i = 0; i < npoints; i++) {
         xpoints[i] += (float) dx;
         ypoints[i] += (float) dy;
      }

      //// 2. Update the bounds.
      minX += (float) dx;
      minY += (float) dy;
      maxX += (float) dx;
      maxY += (float) dy;

      //// 3. Mark as internally dirty.
      flagDirty = true;
   } // of translate

   //-----------------------------------------------------------------

   /**
    * Update the bounding box.
    */
   private void updateBounds() {
      minX    = Float.POSITIVE_INFINITY;
      minY    = Float.POSITIVE_INFINITY;
      maxX    = Float.NEGATIVE_INFINITY;
      maxY    = Float.NEGATIVE_INFINITY;

      //// 1. Find the overall min and max for X and Y.
      for (int i = 0; i < npoints; i++) {
         updateBounds(xpoints[i], ypoints[i]);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Update the bounding box with a single point.
    */
   private void updateBounds(double x, double y) {
      //// 1.1. Running min and max for X.
      if (x > maxX) {
         maxX = (float) x;
      }
      if (x < minX) {
         minX = (float) x;
      }

      //// 1.2. Running min and max for Y.
      if (y > maxY) {
         maxY = (float) y;
      }
      if (y < minY) {
         minY = (float) y;
      }
   } // of method

   //===   POLYGON METHODS   ===================================================
   //===========================================================================



   //===========================================================================
   //===   POLYGON TRANSFORMATIONS   ===========================================

   /**
    * Get a simpler-to-render polygon that looks like this polygon.
    * Eyeballing some samples, the simplified polygon contains
    * 20-50% of the original number of points.
    */
   public Polygon2D simplify() {
      //// 0.1. Quick check. No point in doing anything if too simple.
      if (npoints < 10) {
         return (this);
      }

      //// 0.2. See if it is already cached.
      Object obj = cacheSimplified.get(xpoints);
      if (obj != null) {
         return ((Polygon2D) obj);
      }

      double[]   dThetaArray = new double[npoints];
      Polygon2D  simplePoly  = new Polygon2D();
      double     thetaOld;
      double     thetaNew;

      //// 1. Calculate the absolute delta of the angle for each point.
      thetaNew       = Math.atan2(xpoints[0], ypoints[0]);
      dThetaArray[0] = Double.MAX_VALUE;
      for (int i = 1; i < dThetaArray.length; i++) {
         thetaOld       = thetaNew;
         thetaNew       = Math.atan2(xpoints[i], ypoints[i]);
         dThetaArray[i] = Math.abs(thetaNew - thetaOld);
      }

      //// 2. Add local minima points.
      for (int i = 0; i < dThetaArray.length; i++) {
         //// 2.1. Always add the first point to the polygon.
         ////      Also, always add the last point to the polygon.
         if (i == 0 || i == dThetaArray.length - 1) {
            simplePoly.addPoint(xpoints[i], ypoints[i]);
         }
         //// 2.2. Normal case.
         else {
            if (dThetaArray[i] <= dThetaArray[i - 1] &&
                dThetaArray[i] <= dThetaArray[i + 1]) {
               simplePoly.addPoint(xpoints[i], ypoints[i]);
            }
         }
      }

      //// 3. Close the polygon.
      simplePoly.setClosed(this.isClosed());

      //// 4. Cache the results.
      cacheSimplified.put(xpoints, simplePoly);

      return (simplePoly);
   } // of simplify

   //-----------------------------------------------------------------

   /**
    * Transform this Polygon2D in place.
    */
   public void transform(AffineTransform tx) {
      //// 1. First, convert the points of the Polygon2D into a floating
      ////    point array.
      float[] fpts = new float[2*npoints];
      int     index;
      
      for (int i = 0; i < npoints; i++) {
         index = 2*i;
         fpts[index]     = xpoints[i];
         fpts[index + 1] = ypoints[i];
      }
      

      //// 2. Transform the array using the convenient method in
      ////    AffineTransform.
      tx.transform(fpts, 0, fpts, 0, npoints);

      //// 3. Convert back to a polygon.
      for (int i = 0; i < fpts.length; i++) {
         if (i % 2 == 0) {
            xpoints[i / 2] = fpts[i];
         }
         else {
            ypoints[i / 2] = fpts[i];
         }
      }

      //// 4. Mark as dirty.
      flagDirty = true;
      updateBounds();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Copy and then transform the new polygon.
    *
    * @return a reference to a new and transformed Polygon.
    */
   public Polygon2D transformCopy(AffineTransform tx) {
      Polygon2D p = (Polygon2D) this.clone();
      p.transform(tx);
      return (p);
   } // of method

   //-----------------------------------------------------------------

   public boolean isNormalized() {
      boolean flagX = Math.abs(minX) < FLOATING_PT_TOLERANCE;
      boolean flagY = Math.abs(minY) < FLOATING_PT_TOLERANCE;
      return (flagX && flagY);
   } // of isNormalized

   //-----------------------------------------------------------------

   /**
    * Force the top-right bounds to be at (0, 0).
    *
    * @return how much we translated.
    */
   public Point2D normalize() {
      Rectangle2D r  = getBounds2D();
      translate((float) -r.getX(), (float) -r.getY());

      flagDirty = true;

      return (new Point2D.Float((float) -r.getX(), (float) -r.getY()));
   } // of normalize

   //-----------------------------------------------------------------

   /**
    * Try to merge the current Polygon2D with the specified Polygon2D.
    * Does nothing if the two do not intersect, or if one of the two
    * is not closed.
    */
   public void paste(Polygon2D p) {
      //// 0. If one of the two is not closed, then do nothing.
      if (this.isClosed() && p.isClosed() == false) {
         return;
      }

      //// 1. If they do not intersect, then do nothing.
      if (this.intersects(p.getBounds2D()) == false) {
         return;
      }

      //// 2. Otherwise, add them together.
      Area areaA = new Area(this);
      Area areaB = new Area(p);
      areaA.add(areaB);

      //// 3. If the merged area is not a closed path, then just stick
      ////    with the original shape.
      if (!areaA.isSingular()) {
         return;
      }

      //// 4. Otherwise, convert the area into a Polygon.
      PathIterator it = areaA.getPathIterator(null);
      setToPathIterator(it);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Cut the specified Polygon2D out of the current Polygon2D.
    * Does nothing if the two do not intersect, or if one of the two
    * is not closed.
    */
   public void cut(Polygon2D p) {
      //// 0. If one of the two is not closed, then do nothing.
      if (this.isClosed() && p.isClosed() == false) {
         return;
      }

      //// 1. If they do not intersect, then do nothing.
      if (this.intersects(p.getBounds2D()) == false) {
         return;
      }

      //// 2. Otherwise, add them together.
      Area areaA = new Area(this);
      Area areaB = new Area(p);
      areaA.subtract(areaB);

      //// 3. If the merged area is not a closed path, then just stick
      ////    with the original shape.
      if (!areaA.isSingular()) {
         return;
      }

      //// 4. Otherwise, convert the area into a Polygon.
      PathIterator it = areaA.getPathIterator(null);
      setToPathIterator(it);
   } // of method

   //===   POLYGON TRANSFORMATIONS   ===========================================
   //===========================================================================



   //===========================================================================
   //===   GEOMETRY METHODS   ==================================================

   /**
    * Calculate the length of the lines in the path.
    */
   public double perimeter() {
      float[]      ptsArray = new float[6];
      PathIterator it       = new PolygonPathIterator(this, null);
      double       len      = 0;
      int          segtype;

      float        origX = 0;    // starting x-point in case we are closed
      float        origY = 0;    // starting y-point in case we are closed
      float        lastX = 0;    // previous x-point
      float        lastY = 0;    // previous y-point


      while (it.isDone() == false) {
         segtype = it.currentSegment(ptsArray);
         switch (segtype) {
            case PathIterator.SEG_MOVETO:
               origX = ptsArray[0];
               origY = ptsArray[1];
               lastX = origX;
               lastY = origY;
               break;
            case PathIterator.SEG_CLOSE:
               len += GeomLib.distance(lastX, lastY, origX, origY);
               break;
            default:
               len += GeomLib.distance(lastX, lastY, ptsArray[0], ptsArray[1]);
               lastX = ptsArray[0];
               lastY = ptsArray[1];
         }

         it.next();
      }

      return (len);

   } // of perimeter

   //-----------------------------------------------------------------

   /**
    * Calculate the minimum distance from all points in the Polygon to
    * the specified point. Make sure that the two are in the same coordinate
    * space.
    * <P>
    * If the polygon is closed, then the distance is 0 if the point is
    * contained.
    *
    * @param  x is the x-coordinate to check from.
    * @param  y is the y-coordinate to check from.
    * @return the distance from (x,y) to the closest point in the Polygon.
    */
   public float minDistance(double x, double y) {

      //// 1. If we are closed, then contained points are 0.
      if (this.isClosed() == true && this.contains(x, y) == true) {
         return (0);
      }

      //// 2. If this polygon only contains one point, then calculate the
      ////    distance between this point and the given point.
      if (npoints == 1) {
         Point2D firstPoint = new Point2D.Double(xpoints[0], ypoints[0]);
         
         return (float)firstPoint.distance(x, y);
      }

      double            minDistance = Float.MAX_VALUE;
      Line2D            line        = new Line2D.Float();
      ShapeLineIterator it;
      double            tmpDistance;

      //// 2. For each line in the polygon...
      it = new ShapeLineIterator(new PolygonPathIterator(this, null));
      while (it.hasNext()) {
         //// 2.1. Get the distance value of the point from this line.
         ////      Update min distance value.
         line        = it.next(line);
         tmpDistance = line.ptSegDist(x, y);
         if (tmpDistance < minDistance) {
            minDistance = tmpDistance;
         }
      }
      
      if(this.isClosed())
      {
      	 Line2D lstLine = new Line2D.Double(
      	 			xpoints[0],ypoints[0],
      	 			xpoints[xpoints.length-1],ypoints[ypoints.length-1]);
      	 double dis = lstLine.ptSegDist(x,y);
      	 if(dis<minDistance)
      	 {
      	 	minDistance = dis;
      	 }
      }
      
      return((float) minDistance);
   } // of minDistance

   //-----------------------------------------------------------------

   /**
    * ratio: 0 to 1.0
    */
   public Point2D getPointFromArcRatio(double ratio) {

       if (npoints == 1||ratio==0) 
       {
           return new Point2D.Double(xpoints[0],ypoints[0]);
       }
       else if(ratio==1)
       {
           return new Point2D.Double(xpoints[npoints-1],ypoints[npoints-1]);
       }
       
       double len = this.getArcLen();
       double targetlen = len * ratio;

       double dissum = 0;
       Point2D p = new Point2D.Double();
       for(int i=0; i<npoints-1; i++)
       {
           double dis = Math.sqrt(Math.pow(xpoints[i]-xpoints[i+1],2)
                   +Math.pow(ypoints[i]-ypoints[i+1],2));
           dissum += dis;
           if(dissum>targetlen)
           {
               double delta = dis - (dissum - targetlen);
               double x = (xpoints[i+1]-xpoints[i])*delta/dis+xpoints[i];
               double y = (ypoints[i+1]-ypoints[i])*delta/dis+ypoints[i];
               p.setLocation(x,y);
               break;
           }
           else if(dissum==targetlen)
           {
               p.setLocation(xpoints[i+1],ypoints[i+1]);
               break;
           }
       }
       return p;
   }
   
   //-----------------------------------------------------------------
   
   public Point2D getClosestPoint(double x, double y) {

      if (npoints == 1) {
         Point2D firstPoint = new Point2D.Double(xpoints[0], ypoints[0]);
         return firstPoint;
      }

      double            minDistance = Float.MAX_VALUE;
      Line2D            closestSeg  = new Line2D.Float();
      Line2D            line        = new Line2D.Float();
      ShapeLineIterator it;
      double            tmpDistance;
      
      it = new ShapeLineIterator(new PolygonPathIterator(this, null));
      while (it.hasNext()) {
         line        = it.next(line);
         tmpDistance = line.ptSegDist(x, y);
         if (tmpDistance < minDistance) {
            minDistance = tmpDistance;
            closestSeg = (Line2D)line.clone();
         }
      }
      
      if(this.isClosed())
      {
         Line2D lstLine = new Line2D.Double(
                    xpoints[0],ypoints[0],
                    xpoints[xpoints.length-1],ypoints[ypoints.length-1]);
         double dis = lstLine.ptSegDist(x,y);
         if(dis<minDistance)
         {
            minDistance = dis;
            closestSeg = (Line2D)lstLine.clone();
         }
      }
      
      double d1 = closestSeg.getP1().distance(x,y);
      if(d1==minDistance)
      {
          return closestSeg.getP1();
      }
      else if(closestSeg.getP2().distance(x,y)==minDistance)
      {
          return closestSeg.getP2();
      }
      else
      {
          double d2 = Math.sqrt(d1*d1-minDistance*minDistance);
          double len = closestSeg.getP1().distance(closestSeg.getP2());
          double ratio = d2/len;
          double mx = closestSeg.getP1().getX() + 
              (closestSeg.getP2().getX() - closestSeg.getP1().getX()) * ratio;
          double my = closestSeg.getP1().getY() + 
              (closestSeg.getP2().getY() - closestSeg.getP1().getY()) * ratio;
          return new Point2D.Double(mx,my);
      }
   } 

   //-----------------------------------------------------------------
   
   public double getArcLen() {
       if (npoints == 1) {
           return 0;
        }

        double arcLen = 0;

        for(int i=0; i<npoints-1; i++)
        {
            arcLen += Math.sqrt(
                    Math.pow(xpoints[i]-xpoints[i+1],2)+
                    Math.pow(ypoints[i]-ypoints[i+1],2));
        }
        
        return arcLen;
   }
   
   //-----------------------------------------------------------------
   
   public double getArcLen(double x, double y) {

       if (npoints == 1) {
          return 0;
       }

       double            minDistance = Float.MAX_VALUE;
       Line2D            closestSeg  = new Line2D.Float();
       Line2D            line        = new Line2D.Float();
       double            tmpDistance;
       double rightArcLen = 0;
       double arcLen = 0;

       for(int i=0; i<npoints-1; i++)
       {
           line = new Line2D.Double(xpoints[i],ypoints[i],
                   xpoints[i+1],ypoints[i+1]);
           tmpDistance = line.ptSegDist(x, y);
           arcLen += line.getP1().distance(line.getP2());
           if (tmpDistance < minDistance) {
               minDistance = tmpDistance;
               closestSeg = (Line2D)line.clone();
               rightArcLen = arcLen;
            }
       }

       double len = closestSeg.getP1().distance(closestSeg.getP2());
       double d1 = closestSeg.getP1().distance(x,y);
       if(d1==minDistance)
       {
           return rightArcLen-len;
       }
       else if(closestSeg.getP2().distance(x,y)==minDistance)
       {
           return rightArcLen;
       }
       else
       {
           double d2 = Math.sqrt(d1*d1-minDistance*minDistance);
           return rightArcLen-len+d2;
       }
    } 

   //-----------------------------------------------------------------
   
   /**
    * Figure out the min distance between two polygons.
    */
   public float minDistance(Polygon p) {
      float min = Float.MAX_VALUE;

      for (int i = 0; i < p.npoints; i++) {
         min = Math.min(min, this.minDistance(p.xpoints[i], p.ypoints[i]));
      }

      return (min);
   } // of minDistance

   //===   GEOMETRY METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      StringBuffer strbuf = new StringBuffer(10*npoints);
      strbuf.append("[");
      for (int i = 0; i < npoints; i++) {
         strbuf.append("(" + xpoints[i] + "," + ypoints[i] + ")");
      }
      strbuf.append("]");
      return (strbuf.toString());
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      Polygon2D ret = new Polygon2D();
      clone(ret);
      return (ret);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Make p the same as the current Polygon.
    * This method is for clone-chaining.
    */
   public Object clone(Polygon2D p) {
      p.minX    = this.minX;
      p.minY    = this.minY;
      p.maxX    = this.maxX;
      p.maxY    = this.maxY;
      p.npoints = this.npoints;

      p.xpoints = new float[this.npoints];
      p.ypoints = new float[this.npoints];

      for (int i = 0; i < this.npoints; i++) {
         p.xpoints[i] = this.xpoints[i];
         p.ypoints[i] = this.ypoints[i];
      }

      p.flagClosed = this.flagClosed;

      return (p);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) {

      Polygon2D paa = new Polygon2D();
      paa.addPoint(0,  0);
      paa.addPoint(10, 0);
      paa.addPoint(10, 10);
      paa.addPoint(0,  10);
      paa.setClosed(true);
      System.out.println(paa);

      Polygon2D pbb = new Polygon2D(paa);
      System.out.println(pbb);


      System.out.println("------------");

      Polygon2D    p1 = new Polygon2D();
      Polygon2D    p2;
      PathIterator it;
      float[]      pts = new float[6];
      int          segtype;

      p1.addPoint(0,  0);
      p1.addPoint(10, 0);
      p1.addPoint(10, 10);
      p1.addPoint(0,  10);
      p1.setClosed(true);

      p2 = (Polygon2D) p1.clone();
      p2.setClosed(false);

      //// closed, goes back to start, five points
      it = p1.getPathIterator(null);
      while (it.isDone() == false) {
         segtype = it.currentSegment(pts);
         System.out.println(StringLib.getSegmentType(segtype) + " " + 
                            pts[0] + " " + pts[1]);
         it.next();
      }

      System.out.println();

      //// open, stops at fourth points
      it = p2.getPathIterator(null);
      while (it.isDone() == false) {
         segtype = it.currentSegment(pts);
         System.out.println(StringLib.getSegmentType(segtype) + " " + 
                            pts[0] + " " + pts[1]);
         it.next();
      }


   } // of main

   //-----------------------------------------------------------------

/*
   public static void output(Polygon2D p) {
      System.out.println(p);
      System.out.println(p.getBounds());
      System.out.println(p.getBounds2D());
   } // of method

   //-----------------------------------------------------------------

   public static void main(String[] argv) {
      Polygon2D p1 = new Polygon2D();
      Polygon2D p2 = new Polygon2D();
      output(p1);

      p1.addPoint(0, 0);
      output(p1);

      p1.addPoint(0, 10);
      output(p1);

      p1.addPoint(10, 10);
      output(p1);

      p1.addPoint(10, 0);
      output(p1);

      System.out.println(p1.contains(new Point2D.Float(0, 0)));   // t
      System.out.println(p1.contains(new Point2D.Float(9, 9)));   // t
      System.out.println(p1.contains(new Point2D.Float(10, 10))); // f
      System.out.println(p1.contains(new Point2D.Float(0, 10)));  // f
      System.out.println(p1.contains(new Point2D.Float(10, 0)));  // f
      System.out.println(p1.contains(new Point2D.Float(12, 2)));  // f
      System.out.println(p1.contains(new Point2D.Float(-1, 0)));  // f
      System.out.println(p1.contains(new Point2D.Float(-1, 5)));  // f

      System.out.println();

      //// Alternative path A
      p1 = new Polygon2D();
      p1.addPoint(0, 0);

      //// Alternative path B
//p1 = new Polygon2D(new Rectangle(0, 0, 10, 10));

      System.out.println();
      System.out.println("== A ==");
      System.out.println("perimeter " + p1.perimeter());

      System.out.println();
      System.out.println("== B ==");
      p1.translate(1, 1);

p1.transform(AffineTransform.getTranslateInstance(10, 10));
output(p1);

p1.transform(AffineTransform.getRotateInstance(Math.PI/4));
output(p1);

System.out.println("perimeter " + p1.perimeter());

      System.out.println();
      output(p1);
      System.out.println(p1.contains(new Point2D.Float(0, 0)));   // f
      System.out.println(p1.contains(new Point2D.Float(9, 9)));   // t
      System.out.println(p1.contains(new Point2D.Float(10, 10))); // t
      System.out.println(p1.contains(new Point2D.Float(0, 10)));  // f
      System.out.println(p1.contains(new Point2D.Float(10, 0)));  // f
      System.out.println(p1.contains(new Point2D.Float(12, 2)));  // f
      System.out.println(p1.contains(new Point2D.Float(-1, 0)));  // f
      System.out.println(p1.contains(new Point2D.Float(-1, 5)));  // f

      System.out.println();
      System.out.println("== C ==");
      System.out.println(p1.xpoints.length);
      System.out.println(p1.ypoints.length);
      output(p1);

      System.out.println();
      System.out.println("== D ==");
      p1.trim();
      System.out.println(p1.xpoints.length);
      System.out.println(p1.ypoints.length);
      output(p1);

      System.out.println();
      System.out.println("== E ==");
      p1.setArraySize(p1.npoints);
      System.out.println(p1.xpoints.length);
      System.out.println(p1.ypoints.length);
      output(p1);

      System.out.println();
      System.out.println("== F ==");
      p1.setArraySize(p1.npoints - 1);
      System.out.println(p1.xpoints.length);
      System.out.println(p1.ypoints.length);
      output(p1);

      System.out.println();
      System.out.println("== CUT AND PASTE ==");
      p1 = new Polygon2D(new Rectangle(0, 0, 10, 10));
      p2 = new Polygon2D(new Rectangle(5, 5, 10, 10));
      p1.paste(p2);
      output(p1);
      System.out.println("perimeter " + p1.perimeter());

      System.out.println();
      p2.translate(1, 1);
      p1.cut(p2);
      output(p1);
      System.out.println("perimeter " + p1.perimeter());

      System.out.println();
      System.out.println("== DIST ==");
      p1 = new Polygon2D(new Rectangle(0, 0, 10, 10));
      System.out.println(p1.minDistance(0, 0));
      System.out.println(p1.minDistance(5, 5));
      System.out.println(p1.minDistance(10, 5));
      System.out.println(p1.minDistance(10, 15));


   } // of method

*/

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/


