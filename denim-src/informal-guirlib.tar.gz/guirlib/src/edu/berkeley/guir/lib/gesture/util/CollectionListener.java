package edu.berkeley.guir.lib.gesture.util;

import java.util.*;

public interface CollectionListener extends EventListener {
  void elementAdded(CollectionEvent e);
  void elementRemoved(CollectionEvent e);
  void elementChanged(CollectionEvent e);
}
