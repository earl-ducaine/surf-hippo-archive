package edu.berkeley.guir.suede;

import java.awt.*;
import javax.swing.*;
import java.util.*;

/**
 * This is the main (navy blue) area for the design graph
 */
public class SContentPane extends JLayeredPane {
	public static final Integer NODE_LAYER      = JLayeredPane.PALETTE_LAYER;
	public static final Integer GROUP_LAYER     = JLayeredPane.DEFAULT_LAYER;
	public static final Integer ARROWHEAD_LAYER = JLayeredPane.MODAL_LAYER;
	    
	private Vector linkList  = new Vector();
	private Vector groupList = new Vector();

	public SContentPane() {
   	setLayout(null);
   	setVisible(true);
   	setOpaque(true);
   	repaint();

	}


	public void add(Component c, Integer layer) {
   	if (c instanceof AbstLinkView) linkList.add(c);
   	
   	super.add(c, layer);
	        
   	if (c instanceof AbstGroupNodeView) groupList.add(c);
	}


	public void remove(Component c) {
   	linkList.remove(c);
   	groupList.remove(c);
   	super.remove(c);
	}

	 
	public void paintComponent(Graphics g) {
   	super.paintComponent(g);
   	Graphics2D g2d = (Graphics2D)g;
   	g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

   	for (int i=0; i<linkList.size(); i++)  
      	((AbstLinkView)(linkList.get(i))).paintLink(g2d);   
	}

	    
	public AbstGroupNodeView getGroupAt(Point p) {
   	for (int i=0; i<groupList.size(); i++) {
      	AbstGroupNodeView node = (AbstGroupNodeView)groupList.get(i);
      	if ((p.x > node.getX())&&(p.x < node.getX()+node.getWidth())&&
            	(p.y > node.getY())&&(p.y < node.getY()+node.getHeight())) return node;
   	}
   	
   	return null;
	}

}    