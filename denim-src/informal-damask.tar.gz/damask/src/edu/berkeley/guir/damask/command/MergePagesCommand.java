package edu.berkeley.guir.damask.command;

import java.awt.geom.*;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.Direction;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.connection.OrgConnection;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that merges a page with the one next to it within the same
 * dialog.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-06-2004 James Lin
 *                               Created MergePagesCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-06-2004
 */
public class MergePagesCommand
   extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final Page page1;
   private Page page2 = null;
   
   private Rectangle2D page1OldBounds;
   private Rectangle2D page2OldBounds;

   private AffineTransform page2OldTransform;
   
   private Rectangle2D page1CenterOldBounds;
   private Rectangle2D page2CenterOldBounds;
   
   private Map/*<OrgConnection, GeneralPath>*/ page2InConnections =
      new HashMap/*<Connection, GeneralPath>*/();
   private Map/*<OrgConnection, GeneralPath>*/ page2OutConnections =
      new HashMap/*<Connection, GeneralPath>*/();
   
   private List/*<Control>*/ page2CenterControls;

   /**
    * Constructs the command.
    *  
    * @param page1 the page that will be merged with the one next to it
    */      
   public MergePagesCommand(final Page page1) {
      this.page1 = page1;
   }

   /**
    * Constructs the command.
    *  
    * @param page1 the page that will be merged with page2
    * @param page2 the page that will be merged into page1
    */      
   public MergePagesCommand(final Page page1, final Page page2) {
      this.page1 = page1;
      this.page2 = page2;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Merge pages " + page1 + " and " + page2;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      if (page2 == null) {
         final Dialog d = page1.getDialog();
         final List/*<Page>*/ pages = d.getPages(page1.getDeviceType());
         final int page2Index = pages.indexOf(page1) + 1;
         if (page2Index >= pages.size()) {
            page2 = null;
         }
         else {
            page2 = (Page)pages.get(page2Index);
         }
      }

      if (page2 != null) {
         // Remeber page 1's original size.  
         page1OldBounds = page1.getBounds();
         page1CenterOldBounds = page1.getRegion(Direction.CENTER).getBounds();
         
         // Remeber page 2's original size and location.  
         page2OldBounds = page2.getBounds();
         page2CenterOldBounds = page2.getRegion(Direction.CENTER).getBounds();
         page2OldTransform = page2.getTransform();
         
         // Remember which connections came from page 2.  
         for (Iterator i = page2.getInConnections().iterator(); i.hasNext(); ) {
            final Connection connection = (Connection)i.next();
            page2InConnections.put(
               connection,
               connection.getShape(page2.getDeviceType()));
         }

         for (Iterator i = page2.getOutConnections().iterator(); i.hasNext(); ){
            final OrgConnection connection = (OrgConnection)i.next();
            page2OutConnections.put(
               connection,
               connection.getShape(page2.getDeviceType()));
         }
         
         // Remember which controls are in page 2.  
         page2CenterControls =
            new ArrayList/*<Control>*/(
               page2.getRegion(Direction.CENTER).getControls());

         // Merge page 2 into page 1.
         page1.merge(page2);
         
         if (page1.getDeviceType() != DeviceType.VOICE) {
            // Make page1 longer by adding the height of page2's center region.
            page1.setBounds(
               new Rectangle2D.Double(
                  page1OldBounds.getX(), page1OldBounds.getY(),
                  Math.max(page1OldBounds.getWidth(), page2OldBounds.getWidth()),
                  page1OldBounds.getHeight() + page2CenterOldBounds.getHeight()));
            
            // Move the controls from page2 down.
            final double page1CenterOldHeight = page1CenterOldBounds.getHeight();
            final DeviceType page2DeviceType = page2.getDeviceType();
            for (Iterator i = page2CenterControls.iterator(); i.hasNext(); ) {
               final Control control = (Control)i.next();
               final AffineTransform transform =
                  control.getTransform(page2DeviceType);
               transform.translate(0, page1CenterOldHeight);
               control.setTransform(page2DeviceType, transform);
            }
         }
      }
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      if (page2 != null) {
         page2 = page1.split(page2CenterControls);
         
         // Restore the connections in page 2
         for (Iterator i = page2InConnections.keySet().iterator();
              i.hasNext();) {
            final Connection connection = (Connection)i.next();
            final GeneralPath shape =
               (GeneralPath)page2InConnections.get(connection);
            connection.adjustDestPage(page2.getDeviceType(), page2);
            connection.setShape(page2.getDeviceType(), shape);
         }
         for (Iterator i = page2OutConnections.keySet().iterator();
              i.hasNext();) {
            final OrgConnection connection = (OrgConnection)i.next();
            final GeneralPath shape =
               (GeneralPath)page2OutConnections.get(connection);
            connection.setSource(page2.getDeviceType(), page2);
            connection.setShape(page2.getDeviceType(), shape);
         }
         
         // Restore the size and location of page1 and page2.
         page1.setBounds(page1OldBounds);
         page2.setBounds(page2OldBounds);
         page2.setTransform(page2OldTransform);
         
         // Move the controls from page2 back up.
         final double page1CenterOldHeight = page1CenterOldBounds.getHeight();
         final DeviceType page2DeviceType = page2.getDeviceType();
         for (Iterator i = page2CenterControls.iterator(); i.hasNext(); ) {
            final Control control = (Control)i.next();
            final AffineTransform transform =
               control.getTransform(page2DeviceType);
            transform.translate(0, -page1CenterOldHeight);
            control.setTransform(page2DeviceType, transform);
         }
      }
   }
}
