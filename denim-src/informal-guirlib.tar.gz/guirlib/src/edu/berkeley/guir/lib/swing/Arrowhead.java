package edu.berkeley.guir.lib.swing;

import java.awt.*;

// this is the arrowhead class

public class Arrowhead extends javax.swing.JComponent
{
    private static final double ALPHA = 17.0*Math.PI/180.0; // the angle of the arrow
    private Polygon m_arrowhead;
    private boolean m_target    = true;
    private int[]   m_xPoints   = new int[3];
    private int[]   m_yPoints   = new int[3];
    private int     m_arrowSize = 20;
    private int     m_tx;
    private int     m_ty;
    private double  m_theta;
    

    public void setArrowhead(Point tar, double theta) { 

        // We only need to update the arrowhead if its parameters have changed
        if ((tar.x!=m_tx)||(tar.y!=m_ty)||(theta!=m_theta)) {
            m_tx = tar.x; m_ty = tar.y; m_theta = theta;
            
            m_xPoints[0] = tar.x; m_yPoints[0] = tar.y;
            m_xPoints[1] = tar.x-(int)(m_arrowSize*Math.cos(theta-ALPHA)); 
            m_yPoints[1] = tar.y-(int)(m_arrowSize*Math.sin(theta-ALPHA));
            m_xPoints[2] = tar.x-(int)(m_arrowSize*Math.cos(theta+ALPHA)); 
            m_yPoints[2] = tar.y-(int)(m_arrowSize*Math.sin(theta+ALPHA));

            m_arrowhead = new Polygon(m_xPoints, m_yPoints, 3); 
            setBounds(m_arrowhead.getBounds());
            setBounds(getX()-1, getY()-1, getWidth()+2, getHeight()+2);
            m_arrowhead.translate(-getX(), -getY());
        }
        
    }

    public void setArrowSize(int size) {
        m_arrowSize = size;
    }

    public int getArrowSize() {
        return m_arrowSize;   
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;
        g2d.setColor(getForeground());
        if (m_target) g2d.fill(m_arrowhead);
        else g2d.draw(m_arrowhead);
    }
    
    public void setTarget(boolean b) {
        m_target = b;
    }

}

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
