package edu.berkeley.guir.lib.gesture.features;

import java.awt.Rectangle;

import edu.berkeley.guir.lib.gesture.Feature;
import edu.berkeley.guir.lib.gesture.Gesture;

public class Aspect extends Feature {
  protected final static double radians45 = 45.0 / 180.0 * Math.PI;
  
  public Aspect()
  {
    super();
  }

  public Aspect(Gesture g)
  {
    super(g);
  }

  public String getName()
  {
    // todo
    return "aspect";
  }
  
  public double getMinValue()
  {
    return Double.MIN_VALUE;
  }
  
  public double getMaxValue()
  {
    return Double.MAX_VALUE;
  }
  
  protected void computeValue()
  {
    Rectangle bounds = gesture.getBounds();
    double boundsAngle = Math.atan2(bounds.height, bounds.width);

    value = Math.abs(boundsAngle - radians45);
    valueOk = true;
  }

  public void scale(double factor)
  {
  }
}
