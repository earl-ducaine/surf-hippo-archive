package edu.berkeley.guir.denim.dialogs;

import java.util.*;
import edu.berkeley.guir.denim.DenimConstants;
import edu.berkeley.guir.denim.DenimUserProperties;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.denim.*;
import javax.swing.*;
import javax.swing.event.*;
import java.beans.*; //Property change stuff
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import java.util.List;

/**
 * Dialog box that asks user to insert typed text.
 *
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-30-2000 William Lee (maintained by James Lin)
 *                    Created TextInsertDialog

 *             1.0.1  06-14-2000 JH
 *                    Added copyright notice, set tabs, etc.
 * 
 *             1.0.2  02-04-2003 YL 
 * 					  Enabled font setting
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * 
 * @since   JDK 1.2
 * @version Version 1.0.2, 02-04-2003
 */
public class TextInsertDialog
   extends JDialog
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //-----------------------------------------------------------------

   private static final int  DEFAULT_WIDTH  = 420;
   private static final int  DEFAULT_HEIGHT = 280;
   
   
   public static final int LARGE_FONT_SIZE = 32;
   public static final int MEDIUM_FONT_SIZE = 24;
   public static final int SMALL_FONT_SIZE = 16;

   private static final String defaultFontFamily;
   public static final List familyList;
   
   public static String globalfont1;
   public static String globalfont2;
   public static String globalfont3;
   
   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   static {
      
      // Get the list of font families on this machine.
      String[] familyArray = null;
      
      try
      {
         familyArray = GraphicsEnvironment.getLocalGraphicsEnvironment().
                     getAvailableFontFamilyNames();
      }
      catch(Exception ex)
      {            
         try
         {
            Font[] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
            familyArray = new String[fonts.length];
            
            for(int i=0; i<fonts.length; i++)
            {
               familyArray[i] = fonts[i].getName();
            }
         }
         catch(Exception e)
         {
            e.printStackTrace();
            if(Denim.getPlatformState()==Denim.runningOnMac)
            {
               JOptionPane.showMessageDialog(null,
                  "Java encountered a fatal NullPointer exception when getting fonts.\n"+
                  "Please rename your \"/System Folder/Fonts\", e.g. as \"/System Folder/Fonts.not\", and reboot your machine.\n"+
                  "\nFor detailed information, please reference DENIM FAQ at http://guir.cs.berkeley.edu/projects/denim/support/FAQ.shtml",
                  "Error", JOptionPane.ERROR_MESSAGE);
               System.exit(1);
            }  
         }
      }
      
      familyList = Arrays.asList(familyArray);

      // If the preferred Denim text font is on this system...
      if (familyList.contains(DenimConstants.DENIM_TEXT_FONT_FAMILY)) {
         // ...then use it
          defaultFontFamily = DenimConstants.DENIM_TEXT_FONT_FAMILY;
      }
      else {
          defaultFontFamily = "SansSerif";
      }

   }
   
   static {
       globalfont1 = DenimUserProperties.get(DenimConstants.GLOBAL_FONT1);
       if (globalfont1==null) {
            globalfont1 = "SansSerif";
        }
       
       globalfont2 = DenimUserProperties.get(DenimConstants.GLOBAL_FONT2);
       if (globalfont2==null) {
           globalfont2 = "SansSerif";
       }
       
       globalfont3 = DenimUserProperties.get(DenimConstants.GLOBAL_FONT3);
       if (globalfont3==null) {
           globalfont3 = "SansSerif";
       }
   }

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================


   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   private String      typedText   = null;

   private static Font lstFont  = new Font(defaultFontFamily, Font.PLAIN, LARGE_FONT_SIZE);
   private static Color lstColor  = Color.BLACK;
   
   private Font currFont  = lstFont;
   private Color currColor  = lstColor;
   
   private JTextArea   textArea    = null;

   private JOptionPane optionPane;

   private String      titleText   = "Text";
   private String      labelText   = "Text:";

   // indicate the dialog box was closed with OK
   private boolean     isOK        = false;
   
   JComboBox colors = new JComboBox();

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================
/*
   public TextInsertDialog(Window win, JTextArea ta, int x, int y,
                           String title, String label) {
      super();
      if(ta!=null)
          currFont = new Font(ta.getFont().getFontName(), ta.getFont().getStyle(), ta.getFont().getSize());
      commonInitializations(ta, x, y, title, label);
   }
*/
   //-----------------------------------------------------------------

   /**
    * Constructs the text insert dialog with the coordinate x, y, and the l
    * as the label string.
    */
   public TextInsertDialog(Frame aFrame, JTextArea ta, int x, int y,
                           String title, String label) {
      super(aFrame, true);
      if(ta!=null)
      {
          currFont = new Font(ta.getFont().getFontName(), ta.getFont().getStyle(), ta.getFont().getSize());
          currColor = ta.getForeground();
      }
      else
      {
          currFont = lstFont;
          currColor = lstColor;
      }
      
      commonInitializations(ta, x, y, title, label);
   }

   //-----------------------------------------------------------------

   /**
    * Constructs the text insert dialog with the coordinate x, y, and the l
    * as the label string.
    */
   public TextInsertDialog(Frame aFrame, String[] items, int x, int y, 
           Color color, Font font,
           String title, String label) {
      
       super(aFrame, true);
      
       currFont = font;
       currColor = color;
      
      textArea = new JTextArea();
      textArea.setFont(currFont);
      textArea.setForeground(currColor);
      String content = "";
      for(int i=0; i<items.length; i++)
      {
          content += items[i];
          content += "\n";
      }
      textArea.setText(content);
      commonInitializations(textArea, x, y, title, label);
   }
   
   //-----------------------------------------------------------------

   private void setSizeAndPosition(int x, int y) {
      // Set the size of this window
      int xbox = x - (DEFAULT_WIDTH/2);
      int ybox = y - DEFAULT_HEIGHT;

      // Make sure the window doesn't go off the screen
      if (xbox < 0) {
         xbox = 0;
      }
      if (ybox < 0) {
         ybox = 0;
      }

      Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
      if (xbox + DEFAULT_WIDTH > screenDim.width) {
         xbox -= (xbox + DEFAULT_WIDTH - screenDim.width);
      }

      if (ybox + DEFAULT_HEIGHT > screenDim.height) {
         ybox -= (ybox + DEFAULT_HEIGHT - screenDim.height);
      }

      Debug.println("Dialog box is created at " + xbox + "," + ybox);
      setBounds(xbox, ybox, DEFAULT_WIDTH, DEFAULT_HEIGHT);
   }

   //-----------------------------------------------------------------

   private void commonInitializations(JTextArea ta, int x, int y,
                                      String title, String label) {
      if (ta == null) {
         textArea = new JTextArea();
      }
      else {
         textArea = cloneTextArea(ta);
      }
      titleText = title;
      labelText = label;

      setTitle(titleText);
      setResizable(false);

      setSizeAndPosition(x, y);

      //// 1. Set up the text box
      final String msgString1 = labelText;
      //textArea = new JTextArea(3,4);
      // depends on the Label or the Phrase, resize the textArea accordingly
      if (labelText.equals("Text for New Label:")) {
         textArea.setRows(1);
         textArea.setColumns(4);
      }
      else {
         textArea.setRows(3);
         textArea.setColumns(4);
      }
      if (ta == null) {
         textArea.setFont(currFont);
         textArea.setForeground(currColor);
      }
      
      textArea.setLineWrap(true);
      textArea.setWrapStyleWord(true);

      final JScrollPane areaScrollPane = new JScrollPane(textArea);
      areaScrollPane.setVerticalScrollBarPolicy
         (JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
      areaScrollPane.setPreferredSize(new Dimension(250, 70));
      //areaScrollPane.setBorder(...create border...);


      //// 2. Set up the font selection radio buttons
      FontSizeListener fontlistener = new FontSizeListener();
      JRadioButton largeButton = new JRadioButton("Title");
      largeButton.setMnemonic(KeyEvent.VK_T);
      largeButton.addActionListener(fontlistener);
      largeButton.setActionCommand("largefont");
      
      
      if (textArea.getFont().getSize() == TextInsertDialog.LARGE_FONT_SIZE) {
         largeButton.setSelected(true);
      }

      JRadioButton mediumButton = new JRadioButton("Heading");
      mediumButton.setMnemonic(KeyEvent.VK_H);
      mediumButton.setActionCommand("mediumfont");
      mediumButton.addActionListener(fontlistener);
      if (textArea.getFont().getSize() == TextInsertDialog.MEDIUM_FONT_SIZE) {
         mediumButton.setSelected(true);
      }

      JRadioButton smallButton = new JRadioButton("Body Text");
      smallButton.setMnemonic(KeyEvent.VK_B);
      smallButton.setActionCommand("smallfont");
      smallButton.addActionListener(fontlistener);
      if (textArea.getFont().getSize() == TextInsertDialog.SMALL_FONT_SIZE) {
         smallButton.setSelected(true);
      }

      ButtonGroup bgrp = new ButtonGroup();
      bgrp.add(largeButton);
      bgrp.add(mediumButton);
      bgrp.add(smallButton);
      JPanel fontSizePanel = new JPanel(new GridLayout(0,1));
      fontSizePanel.setBorder(BorderFactory.createTitledBorder("Text Style"));
      fontSizePanel.add(largeButton);
      fontSizePanel.add(mediumButton);
      fontSizePanel.add(smallButton);
      
      JComboBox fonttype = new JComboBox();
      /*Iterator it = familyList.iterator();
      while(it.hasNext())
      {
          String fn = (String)it.next();
          fonttype.addItem(fn);
      }*/
      fonttype.addItem(globalfont1);
      if(!globalfont2.equals(globalfont1))
          fonttype.addItem(globalfont2);
      if(!globalfont3.equals(globalfont1)&&!globalfont3.equals(globalfont2))
          fonttype.addItem(globalfont3);
      
      fonttype.setSelectedItem(currFont.getFontName());
      fonttype.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
              if(evt.getStateChange()==ItemEvent.SELECTED)
              {
                  currFont = new Font((String)evt.getItem(), 
                          currFont.getStyle(), currFont.getSize());
                  textArea.setFont(getFont());
                  textArea.invalidate();
                  textArea.repaint();
              }
          }
      });
      
      fontSizePanel.add(new JLabel("Font"));
      fontSizePanel.add(fonttype);
      
      fontSizePanel.add(new JLabel("Color"));
      
      colors.addItem("Red");
      colors.addItem("Green");
      colors.addItem("Black");
      
      if(currColor.equals(Color.black))
      {
          colors.setSelectedItem("Black");
      }
      else if(currColor.equals(Color.red))
      {
          colors.setSelectedItem("Red");
      }
      else
      {
          colors.setSelectedItem("Green");
      }
          
      textArea.setForeground(currColor);
      
      colors.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
              if(evt.getStateChange()==ItemEvent.SELECTED)
              {
                  if(((String)evt.getItem()).equalsIgnoreCase("red"))
                  {
                      currColor = Color.RED;
                  }
                  else if(((String)evt.getItem()).equalsIgnoreCase("green"))
                  {
                      currColor = Color.GREEN;
                  }
                  else
                  {
                      currColor = Color.BLACK;
                  }
                  
                  textArea.setForeground(currColor);
                  textArea.invalidate();
                  textArea.repaint();
              }
          }
      });
      
      fontSizePanel.add(colors);

      //// 3. Layout text area and radio buttons
      JPanel inputForm = new JPanel(new BorderLayout());
      inputForm.setPreferredSize(new Dimension(50, 140));
      inputForm.add(areaScrollPane, BorderLayout.CENTER);
      inputForm.add(fontSizePanel, BorderLayout.EAST);

      //// 4. Set up the OK/Cancel buttons
      Object[] array = {msgString1, inputForm};

      optionPane = new JOptionPane(array,
                                   JOptionPane.PLAIN_MESSAGE,
                                   JOptionPane.OK_CANCEL_OPTION,
                                   null,
                                   null,
                                   null);
      setContentPane(optionPane);
      setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

      //// 5. Set up event listeners
      addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent we) {
            /*
             * Instead of directly closing the window,
             * we're going to change the JOptionPane's
             * value property.
             */
            optionPane.setValue(new Integer(JOptionPane.CLOSED_OPTION));
         }
      });

      textArea.getDocument().addDocumentListener(new DocumentListener() {
         public void changedUpdate(DocumentEvent e) {
            optionPane.setValue(new Integer(JOptionPane.OK_OPTION));
         }

         public void insertUpdate(DocumentEvent e) {
         };

         public void removeUpdate(DocumentEvent e) {
         };
      });

      optionPane.addPropertyChangeListener(new PropertyChangeListener() {
         public void propertyChange(PropertyChangeEvent e) {
            /*debug.println("property change: ");
            debug.println("  source  : " + e.getSource().getClass());
            debug.println("  property: " + e.getPropertyName());
            debug.println("    from  : " + e.getOldValue());
            debug.println("    to    : " + e.getNewValue());*/

            String prop = e.getPropertyName();

            if (isVisible()
            && (e.getSource() == optionPane)
            && (prop.equals(JOptionPane.VALUE_PROPERTY) ||
                prop.equals(JOptionPane.INPUT_VALUE_PROPERTY))) {
               Object value = optionPane.getValue();

               if (value == JOptionPane.UNINITIALIZED_VALUE) {
                  //ignore reset
                  return;
               }

               // Reset the JOptionPane's value.
               // If you don't do this, then if the user
               // presses the same button next time, no
               // property change event will be fired.
               optionPane.setValue(JOptionPane.UNINITIALIZED_VALUE);

               if (value instanceof Integer &&
                   ((Integer)value).intValue() == JOptionPane.OK_OPTION) {
                  typedText = textArea.getText();
                  if (typedText.equals("")) {
                     typedText = null;
                  }
                  
                  lstFont = currFont;
                  lstColor = currColor;
                  
                  isOK = true;
                  setVisible(false);
               }
               else { // user closed dialog or clicked cancel
                  typedText = null;
                  textArea.setText("");
                  isOK = false;
                  setVisible(false);
               }
            }
         }
      });
   } // of method

   public JTextArea getTextArea() {
       return textArea;
   }
   
   //-----------------------------------------------------------------

   /**
    * Returns a clone of JTextArea
    */
   public JTextArea cloneTextArea(JTextArea ta) {
      JTextArea newTextArea = new JTextArea();
      newTextArea.setText(ta.getText());
      newTextArea.setFont(ta.getFont());
      return newTextArea;
   }



   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   XXXXX METHODS   =====================================================

   /**
    * Returns the text that the user inputted, or null if the user pressed
    * Cancel.
    */
   public String getValidatedText() {
      return typedText;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the validated text area.
    */
   public JTextArea getValidatedTextArea() {
      return textArea;
   }

 
   
   //-----------------------------------------------------------------

   /**
    * Returns the font that the user has inputted.
    */
   public Font getFont() {
      return currFont;
   }

   //-----------------------------------------------------------------

   /**
    * Returns whether the dialog box was closed with OK.
    */
   public boolean isOK() { 
   	  
      return isOK;
   }

   //-----------------------------------------------------------------

   /**
    * Action listener for the font panel
    */
   class FontSizeListener implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         String cmd = e.getActionCommand();
         if (cmd.equals("largefont")) {
            currFont = new Font(currFont.getFontName(), Font.PLAIN, LARGE_FONT_SIZE);
         }
         else if (cmd.equals("mediumfont")) {
             currFont = new Font(currFont.getFontName(), Font.PLAIN, MEDIUM_FONT_SIZE);
         }
         else if (cmd.equals("smallfont")) {
             currFont = new Font(currFont.getFontName(), Font.PLAIN, SMALL_FONT_SIZE);
         }
         textArea.setFont(currFont);
      }
   }

   //===   XXXXX METHODS   =====================================================
   //===========================================================================



   /**
    * Constructs a TextInsertDialog with the ^ input point x and y.
    * @param x the absolute x coordinate of the ^ inserting point relative to the screen.
    * @param y the absolute y coordinate of the ^ inserting point relative to the screen.
    */
   /*
   public TextInsertDialog(Frame aFrame, JTextArea ta, int x, int y) {
      super(aFrame,true);
      // Set the size of this window
      int xbox = x - (DEFAULT_WIDTH/2);
      int ybox = y - DEFAULT_HEIGHT;
                // make a clone of the text area
      textArea = cloneTextArea(ta);
      debug.println("Dialog box is created at " + xbox + "," + ybox);
      setBounds(xbox, ybox, DEFAULT_WIDTH, DEFAULT_HEIGHT);
      commonInitializations();

   }
   */



} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
