package edu.berkeley.guir.damask.view.appevent;

import java.awt.geom.AffineTransform;
import java.util.EventObject;

import edu.berkeley.guir.lib.satin.command.Command;
import edu.berkeley.guir.lib.satin.command.CommandQueue;
import edu.umd.cs.piccolo.PCanvas;

/** 
 * An event that indicates that a command has been executed in the command
 * queue.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-19-2003 James Lin
 *                               Created ConnectionEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-19-2003
 */
public class CommandEvent extends EventObject {

   private final CommandEvent.Type eventType;   
   private final Command command;
   private final PCanvas canvas;
   private final AffineTransform canvasTransform;
   
   //---------------------------------------------------------------------------

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   

   public static final CommandEvent.Type COMMAND_EXECUTED =
      new CommandEvent.Type("command executed");

   public static final CommandEvent.Type COMMAND_UNDONE =
      new CommandEvent.Type("command undone");

   public static final CommandEvent.Type COMMAND_REDONE =
      new CommandEvent.Type("command redone");

   //---------------------------------------------------------------------------

   /**
    * Constructs a CommandEvent, that indicates that a command has been
    * executed in the command queue.
    */
   public CommandEvent(
      final CommandQueue source,
      final CommandEvent.Type eventType,
      final Command command,
      final PCanvas canvas,
      final AffineTransform canvasTransform) {

      super(source);
      this.eventType = eventType;
      this.command = command;
      this.canvas = canvas;
      this.canvasTransform = canvasTransform;
   }
   

   /**
    * Returns the command queue that is the source of the event.
    */
   public CommandQueue getCommandQueue() {
      return (CommandQueue)source;
   }
   
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   
   /**
    * Returns the command affected by the event.
    */
   public Command getCommand() {
      return command;
   }
   
   
   /**
    * Returns the canvas that was active when this event was fired.
    */
   public PCanvas getCanvas() {
      return canvas;
   }
   
   
   /**
    * Returns the transform that the active canvas had when this event
    * was fired. 
    */
   public AffineTransform getCanvasTransform() {
      return canvasTransform;
   }
}
