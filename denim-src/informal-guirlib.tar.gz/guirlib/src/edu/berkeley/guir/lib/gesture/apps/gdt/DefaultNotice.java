package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Container;

/** Actually an abstract, not a default class.  Subclasses must
    implement displayImpl, displaySummaryImpl, and getName.  They may
    also want to override hasExpired, getHowToPanel, and
    getReferenceTag. */
public abstract class DefaultNotice implements Notice {
  protected long lastDisplayTime;
  protected Position position = null;
  protected ActionListener howToListener;
  protected ActionListener referenceListener;
  protected ActionListener moreInfoListener;
  protected static MutableAttributeSet NAME_STYLE;
  static {
    NAME_STYLE = new SimpleAttributeSet();
    StyleConstants.setBold(NAME_STYLE, true);
  }
  
  public long getLastDisplayTime()
  {
    return lastDisplayTime;
  }

  public void setLastDisplayTime(long time)
  {
    lastDisplayTime = time;
  }

  /** by default, notices never expire */
  public boolean hasExpired()
  {
    return false;
  }

  protected void makeListeners(MainFrame mf)
  {
    if (referenceListener == null) {
      referenceListener = new ReferenceListener(mf);
    }
    if (howToListener == null) {
      howToListener = new HowToListener(mf);
    }
  }
  
  public void display(SummaryLog log)
  {
    makeListeners(log.getMainFrame());

    /*
    log.appendStartIcon();
    log.append(getName() + ": ", NAME_STYLE);
    */
    displayImpl(log);
    if (getHowToPanel() != null) {
      log.append(" ");
      log.appendLink("How do I do this?", howToListener);
    }
    if (getReferenceTag() != null) {
      log.append(" ");
      log.appendLink("Reference manual", referenceListener,
		     "See related information in the reference manual");
    }
    log.append("\n");
  }

  /** update the last display time to the current time */
  public void displaySummary(SummaryLog log)
  {
    MainFrame mf = log.getMainFrame();
    makeListeners(mf);
    log.appendStartIcon();
    log.append(getName() + ": ", NAME_STYLE);
    displaySummaryImpl(log);
    log.append(" ");
    if (moreInfoListener == null) {
      moreInfoListener = new MoreInfoListener(mf);
    }
    log.appendLink("[ More info ]", moreInfoListener);
    log.append("\n");
    setLastDisplayTime(System.currentTimeMillis());
  }
  
  protected abstract void displayImpl(SummaryLog log);
  protected abstract void displaySummaryImpl(SummaryLog log);

  private static final List EMPTY_LIST = new ArrayList();
  public List getObjectList()
  {
    return EMPTY_LIST;
  }

  public abstract String getName();

  public Position getPosition()
  {
    return position;
  }

  public void setPosition(Position p)
  {
    position = p;
  }

  public HowToPanel getHowToPanel()
  {
    return null;
  }

  public String getReferenceTag()
  {
    return null;
  }

  public boolean equals(Object obj)
  {
    if (obj == null) {
      return false;
    }
    else if (obj == this) {
      return true;
    }
    else {
      return (obj.getClass() == getClass()) &&
	(((Notice) obj).getObjectList().equals(getObjectList()));
    }
  }
  
  protected class HowToListener implements ActionListener {
    MainFrame mainFrame;
    
    public HowToListener(MainFrame mf)
    {
      mainFrame = mf;
    }
    
    public void actionPerformed(ActionEvent e)
    {
      /*
      System.out.println("How to link hit");
      */
      HowToManager.getManager().showHowTo(mainFrame, DefaultNotice.this);
    }
  }

  protected class ReferenceListener implements ActionListener {
    MainFrame mainFrame;
    
    public ReferenceListener(MainFrame mf)
    {
      mainFrame = mf;
    }
    
    public void actionPerformed(ActionEvent e)
    {
      ReferenceManager.getManager().showReference(mainFrame,
						  DefaultNotice.this);
    }
  }

  protected class MoreInfoListener implements ActionListener {
    MainFrame mainFrame;
    JInternalFrame infoFrame = null;
    
    public MoreInfoListener(MainFrame mf)
    {
      mainFrame = mf;
    }
    
    public void actionPerformed(ActionEvent e)
    {
      if (infoFrame == null) {
	//System.out.println("DN: making infoFrame");
	infoFrame = new JInternalFrame(DefaultNotice.this.getName());
	Container contents = infoFrame.getContentPane();
	contents.setLayout(new BorderLayout());
	SummaryLog log = new SummaryLog(mainFrame);
	display(log);
	contents.add(log, BorderLayout.CENTER);
      }
      //System.out.println("DN: showing infoFrame");
      mainFrame.getDesktop().showFrame(infoFrame);
    }
  }
}
