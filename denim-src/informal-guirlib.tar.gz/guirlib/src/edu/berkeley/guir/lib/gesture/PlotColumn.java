package edu.berkeley.guir.lib.gesture;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.*;
import java.io.PrintStream;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * the part of FeaturePointGraph that graphs a single feature of a single
 * category
 */
public class PlotColumn extends JPanel
{
  static final int dotRadius = 5;
  static final int columnWidth = dotRadius*4;
  double minValue, maxValue;
  double[] data;
  int dataSize = 0;
  int[] y;
  int[] histogram;

  PlotColumn()
  {
    //super();
    addComponentListener(new ComponentAdapter() {
      public void componentResized(ComponentEvent e)
      {
	computeHistogram();
	repaint();
      }
    });

    addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e)
      {
	System.err.println("PlotColumn hit");
	dumpData(System.err);
      }
    });

    // save having to check for null all the time
    data = new double[1];
    y = new int[1];
    histogram = new int[1];
  }
  
  public PlotColumn(double[] data, double minValue, double maxValue)
  {
    this();
    setData(data, minValue, maxValue);
  }

  private void actuallySetData(double[] d)
  {
    if (data.length < d.length) {
      data = new double[d.length];
    }
    dataSize = d.length;
    System.arraycopy(d, 0, data, 0, d.length);
  }
  
  public void setData(double[] d)
  {
    actuallySetData(d);
    
    computeHistogram();
    repaint();
  }

  public void setData(double[] d, double min, double max)
  {
    actuallySetData(d);
    minValue = min;
    maxValue = max;

    computeHistogram();
    repaint();
  }

  public void setRange(double min, double max)
  {
    if ((minValue != min) || (maxValue != max)) {
      minValue = min;
      maxValue = max;
      computeHistogram();
      repaint();
    }
  }
  
  private void computeHistogram()
  {
    int height = getSize().height;
    double scale = height / (maxValue - minValue);
    int maxy = (int) Math.ceil(maxValue * scale);
    int miny = (int) Math.floor(minValue * scale);
    int length = maxy - miny + 1;
    if (histogram.length < length)
      histogram = new int[length];
    else {
      for (int i = 0; i < length; i++)
	histogram[i] = 0;
    }
    
    if (y.length < dataSize)
      y = new int[dataSize];
    for (int i = 0; i < dataSize; i++) {
      y[i] = (int) Math.round((data[i] - minValue) * scale);
      histogram[y[i]]++;
    }
  }
  
  public void paintComponent(Graphics graphics)
  {
    super.paintComponent(graphics);
    Graphics g = graphics.create();
    // use try...finally to make sure the Graphics is disposed of
    try {
      int height = getSize().height;

      g.translate(columnWidth/2, 0);
      g.setColor(getForeground());
      for (int i = 0; i < dataSize; i++) {
	int radius = dotRadius*2 + histogram[y[i]] - 1;
	g.drawOval(-dotRadius, height - y[i], radius, radius);
      }
    }
    finally {
      g.dispose();
    }
  }

  public Dimension getPreferredSize()
  {
    int height = super.getPreferredSize().height;
    return new Dimension(columnWidth, height);
  }

  void dumpData(PrintStream out)
  {
    out.print("data = {");
    for (int i = 0; i < dataSize; i++) {
      out.print(data[i]);
      if (i < (dataSize-1))
	out.print(", ");
    }
    out.println("}");
  }
  
  public static void main(String[] args)
  {
    double[] foo = {0.0, 1.0, 2.0, 3.0, 5.0, 10.0};

    JFrame f = new JFrame("PlotColumn test");
    /*
    Container contents = f.getContentPane();
    contents.setLayout(new BorderLayout());
    contents.add(new PlotColumn(foo, 0, 10), BorderLayout.CENTER);
    
    contents.addFocusListener(new FocusListener() {
      public void focusGained(FocusEvent e)
      {
	System.err.println("contents entered");
      }
      public void focusLost(FocusEvent e)
      {
	System.err.println("contents exited");
      }  
    });
    */
    f.addMouseListener(new adapter());

    /*
    GridBagLayout gb = new GridBagLayout();
    contents.setLayout(gb);
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.fill = GridBagConstraints.VERTICAL;
    constraints.weighty = 1.0;

    for (int i = 0; i < 5; i++) {
      PlotColumn pc = new PlotColumn(foo, 0, 10);
      pc.setBackground(Color.white);
      pc.setBorder(BorderFactory.createEtchedBorder());
      pc.setPreferredSize(new Dimension(10, 100));
      if (i == 4)
	constraints.gridwidth = GridBagConstraints.REMAINDER;
      contents.add(pc, constraints);
    }
    constraints.weighty = 0.0;
    constraints.gridwidth = 1;
    for (int i = 0; i < 5; i++) {
      JButton button = new JButton("" + i);
      contents.add(button, constraints);
    }
    */
    
    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    };
    f.addWindowListener(l);

    f.pack();
    f.setSize(new Dimension(200,200));
    f.show();
  }
}

class adapter extends MouseAdapter
{
  public adapter()
  {
  }
  
  public void mouseDown(MouseEvent e)
  {
    System.err.println("contents hit");
  }
}
