package edu.berkeley.guir.damask.view.visual.dialog;

import java.awt.Color;
import java.awt.Paint;
import java.util.Iterator;

import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.event.PageEvent;
import edu.berkeley.guir.damask.event.PageListener;
import edu.berkeley.guir.damask.view.DamaskLayer;
import edu.berkeley.guir.damask.view.nodes.DamaskWindow;
import edu.berkeley.guir.damask.view.visual.component.*;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * A page in the Damask user interface. Consists of a title and the page
 * content.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-29-2003 James Lin
 *                               Created DamaskPage
 *                    09-11-2003 James Lin
 *                               Renamed to PageView
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-29-2003
 */
public class PageView extends DamaskWindow {

   private static final Color DEFAULT_TITLE_BAR_PAINT =
      new Color(240, 240, 255); // light blue
   private static final Paint PAGE_COLOR = Color.WHITE;
   private static final Paint DEVICE_PAGE_PAINT_IN_ALL_LAYER =
      new Color(233, 233, 233);
   private int designTimeCondition = 0;
   private PageHandler pageHandler = new PageHandler();
   
   /**
    * Constructs a new view of the given page model.
    */
   public PageView(final Page page) {
      this(page, true);
   }

   /**
    * Constructs a new view of the given page model.
    */
   public PageView(final Page page, final boolean grayOutTemplateElements) {
      super(page, grayOutTemplateElements);
      page.addPageListener(pageHandler);

      setStrokePaint(null);
   }
   

   // @Override
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();

      // Set the states of controls to the those that match condition 0.
      final PageViewContents contents = (PageViewContents)getContents();
      for (Iterator i = contents.getRegionViews().iterator(); i.hasNext();) {
         final PageRegionView regionView = (PageRegionView)i.next();
         for (Iterator j = regionView.getChildrenIterator(); j.hasNext(); ) {
            final ComponentView componentView = (ComponentView)j.next();
            if (componentView instanceof ControlView) {
               final ControlView controlView = (ControlView)componentView;
               final Control control = (Control)controlView.getModel();
               controlView.setState(
                  control.getStateForCondition(control.getDialog(), 0));
            }
         }
      }
      
      if (getParent() instanceof DialogView) {
         setContentsSelectable(
            ((DialogView)getParent()).isContentsSelectable());
      }
   }

   //@Override
   protected PPath createContents() {
      return new PageViewContents(isTemplateElementsGrayedOut());
   }
   
   
   //@Override
   protected Content getTitleContent() {
      return ((Page)getModel()).getTitle();
   }
   
   //@Override
   public void dispose() {
      super.dispose();
      final Page page = (Page)getModel();
      page.removePageListener(pageHandler);
   }


   // @Override
   protected Paint getContentsPaint() {
      return PAGE_COLOR;
   }
   
   // @Override
   protected Paint getDeviceSpecificContentsPaintInAllLayer() {
      return DEVICE_PAGE_PAINT_IN_ALL_LAYER;
   }

   // @Override
   protected Color getTitleColor() {
      return DEFAULT_TITLE_BAR_PAINT;
   }

   
   /**
    * Sets whether this page view is in Run mode, when the controls behave
    * as if the user is interacting with them.
    */
   public void setInRunMode(final boolean flag) {
      super.setInRunMode(flag);
      final PageViewContents contents = (PageViewContents)getContents();
      if (contents != null) {
         contents.setInRunMode(flag);
      }
   }

   
   /**
    * Makes the contents of this page view either selectable or unselectable.
    */ 
   protected void setContentsSelectable(final boolean selectable) {
      final DamaskLayer layer = getLayer();
      if (layer == null) {
         return;
      }
      
      if (selectable) {
         layer.addSelectableParent(getTitleBar());
      }
      else {
         layer.removeSelectableParent(getTitleBar());
      }
      
      for (Iterator j =
           ((PageViewContents)getContents()).getRegionViews().iterator();
         j.hasNext(); ) {
                  
         final PageRegionView prView = (PageRegionView)j.next();
         if (selectable) {
            layer.addSelectableParent(prView); 
         }
         else {
            layer.removeSelectableParent(prView); 
         }

         // Make check boxes and radio buttons within the page
         // selectable                     
         for (Iterator k = prView.getChildrenIterator(); k.hasNext(); ) {
            final PNode node = (PNode)k.next();
            if ((node instanceof CheckBoxGroup)
               || (node instanceof RadioButtonGroup)) {

               if (selectable) {
                  layer.addSelectableParent(node);
               }
               else {
                  layer.removeSelectableParent(node); 
               }
            }
         }
      }
   }

   // Overrides method in parent class.
   // Disabled semantic zooming for now.
//   protected void paint(PPaintContext aPaintContext) {
//      final double s = aPaintContext.getScale();
//      // Paint the contents only if the zoom level is at level 2 or higher
//      if (aPaintContext.getCamera().getComponent() instanceof DamaskCanvas) {
//         contents.setVisible(
//            s > (DamaskCanvas.scaleFactor(1) + DamaskCanvas.scaleFactor(2)) / 2);
//      }
//      super.paint(aPaintContext);
//   }

   /**
    * Returns the current design-time condition of this page view.
    */
   public int getDesignTimeCondition() {
      return designTimeCondition;
   }

   /**
    * Sets the current design-time condition of this page view.
    * 
    * @throws IllegalArgumentException if the specified condition is greater
    * than or equal to the number of conditions of the underlying page model  
    */
   protected void setDesignTimeCondition(final int condition) {
      final Dialog dialog = ((Page)getModel()).getDialog();
      if (condition >= dialog.getNumConditions()) {
         throw new IllegalArgumentException();
      }
      designTimeCondition = condition;

      // Change the state of the control views within this page view to the
      // proper state for the specified condition.
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof PageView) {
            final PageView pageView = (PageView)child;
            for (Iterator j = ((PageViewContents)pageView.getContents()).getRegionViews().iterator();
                 j.hasNext(); ) {
               final PageRegionView regionView = (PageRegionView)j.next();
               for (Iterator k = regionView.getChildrenIterator(); k.hasNext();) {
                  final Object rvChild = k.next();
                  if (rvChild instanceof ControlView) {
                     final ControlView controlView = (ControlView)rvChild;
                     final Control control = (Control)controlView.getModel();
                     controlView.setState(
                        control.getStateForCondition(dialog, condition));
                  }
               }
            }
         }
      }
   }


   /**
    * Called when the device-type layer of a layer is changed. 
    */
   protected void deviceTypeLayerChanged() {
      super.deviceTypeLayerChanged();
      
      final PageViewContents contents = (PageViewContents)getContents();
      for (Iterator j = contents.getChildrenIterator(); j.hasNext(); ) {
         final PNode pageChild = (PNode)j.next();
         if (pageChild instanceof PageRegionView) {
         
            for (Iterator k =
               ((PageRegionView)pageChild).getChildrenIterator();
               k.hasNext();
               ) {
               final PNode regionChild = (PNode)k.next();
               if (regionChild instanceof ComponentView) {
                  ((ComponentView)regionChild).deviceTypeLayerChanged();
               }
            }
         }
      }
   }

   // @Override
   protected Dialog getDialogModel() {
      return ((Page)getModel()).getDialog();
   }

   /**
    * Listens for events from the page model. 
    */   
   private final class PageHandler implements PageListener {
      public void templateAdded(PageEvent e) {
         final Page template = (Page)e.getValue();
         final PageViewContents contents = (PageViewContents)getContents();
         for (Iterator i = contents.getRegionViews().iterator(); i.hasNext();) {
            final PageRegionView regionView = (PageRegionView)i.next();
            regionView.addTemplate(template);
         }
      }

      public void templateRemoved(PageEvent e) {
         final Page template = (Page)e.getValue();
         final PageViewContents contents = (PageViewContents)getContents();
         for (Iterator i = contents.getRegionViews().iterator(); i.hasNext();) {
            final PageRegionView regionView = (PageRegionView)i.next();
            regionView.removeTemplate(template);
         }
      }
   }
}
