package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.awt.BorderLayout;

import javax.swing.*;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;

import edu.berkeley.guir.lib.gesture.GesturePackage;

/** Manages two gesture trees, one for the training set and one for
    the test sets.  It doesn't know anything about selection,
    commands, entering gestures, etc.  It only deals with laying out
    its two underlying GestureTrees. */
public class CompositeGestureTree extends JPanel {
  protected GestureTreeModel model;
  protected GestureTree trainingTree;
  protected GestureTree testTree;
  protected GestureTreeModel trainingTreeModel;
  protected GestureTreeModel testTreeModel;
  protected JComponent selectedWidget;
  protected JScrollPane trainingScroller;
  protected JScrollPane testScroller;
  
  public CompositeGestureTree()
  {
    super(new BorderLayout());

    buildUI();
  }

  protected void buildUI()
  {
    trainingTree = new GestureTree();
    testTree = new GestureTree();
    trainingScroller = new JScrollPane(trainingTree);
    testScroller = new JScrollPane(testTree);
    JSplitPane splitter = new JSplitPane(JSplitPane.VERTICAL_SPLIT, true,
					 trainingScroller, testScroller);
    splitter.setResizeWeight(0.75);
    add(splitter, BorderLayout.CENTER);
  }
  
  /** model must be an instance of GestureTreeModel (or subclass) */
  public void setModel(TreeModel model)
  {
    if ((model != null) && !(model instanceof GestureTreeModel)) {
      throw new
	IllegalArgumentException("Only GestureTreeModel is allowed, not "
				 + model.getClass().getName() +
				 " (" + model + ")");
    }
    this.model = (GestureTreeModel) model;
    updateTrees();
  }

  protected void updateTrees()
  {
    GesturePackage p = model.getGesturePackage();
    trainingTree.setModel(new TrainingTreeModel(p));
    testTree.setModel(new TestTreeModel(p));
  }

  public TreeNode getTestRootNode()
  {
    return testTreeModel.getTestRootNode();
  }

  public TreeNode getTrainingRootNode()
  {
    return trainingTreeModel.getTrainingRootNode();
  }

  public GestureTree getTrainingTree()
  {
    return trainingTree;
  }

  public GestureTree getTestTree()
  {
    return testTree;
  }

  /* seems to have no effect
  public void setPreferredSize(Dimension d)
  {
    super.setPreferredSize(d);
    int trainingHeight = (int) d.getHeight() * 3/4;
    int testHeight = (int) d.getHeight() - trainingHeight;
    int width = (int) d.getWidth();
    trainingScroller.setPreferredSize(new Dimension(width, trainingHeight));
    testScroller.setPreferredSize(new Dimension(width, testHeight));
  }
  */
  
  protected class TrainingTreeModel extends GestureTreeModel {
    public TrainingTreeModel(GesturePackage gPackage)
    {
      super(gPackage);
    }

    protected GestureTreeNode buildTree(GesturePackage gesturePackage)
    {
      trainingRootNode = buildTree(gesturePackage.getTrainingSet());
      return trainingRootNode;
    }
  }

  protected class TestTreeModel extends GestureTreeModel {
    public TestTreeModel(GesturePackage gPackage)
    {
      super(gPackage);
    }

    protected GestureTreeNode buildTree(GesturePackage gesturePackage)
    {
      testRootNode = buildTree(gesturePackage.getTestSets());
      return testRootNode;
    }
  }
}
