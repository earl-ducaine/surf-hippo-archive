package edu.berkeley.guir.suede;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;



/*
 *Things that must be changed for model/viewer rewrite:
 *
 * - remove m_balloons and balloon methods.
 * - have playButton callback call viewer instead of model.
 * - a bunch of code from AbstNodeModel needs to be moved here.
 * - keep a pointer to SuedeModel so that m_nodemodel isn't needed.
 *
 */


/*abstract class for all prompt node views
*/
public abstract class AbstSingleNodeView extends AbstNodeView implements ElementViewInter, Cloneable {
	public static final Color NODE_FILL          = new Color(255,234,166);
	public static final Color NODE_STROKE        = new Color(186,125,0);

	public static final int   DEFAULT_WIDTH      = 160;
	public static final int   DEFAULT_HEIGHT     = 50;
	public static final int   CL_WIDTH           = 100;
	public static final int   CL_HEIGHT          = 25;
	public static final int   BUTTON_WIDTH       = 20;
	public static final int   MENU_HEIGHT        = 25;
	protected final int       TYPE_SIZE          = 13;
	protected final int       TIME_X_INSET       = 65;
	protected final int       TIME_Y_INSET       = 10;  
    
	protected Vector         m_balloons          = new Vector(); //of type SBalloon
	protected PlayButton     m_playButton;
	protected RecordButton   m_recordButton;
	protected SSlider        m_slider;
    
	public abstract void  setCaption(String cap);
    
	public abstract String getCaption();
    
	public abstract boolean isOperable(Point p);
    
	public AbstSingleNodeView (SuedeModel model, SingleNodeModel nodeModel){
		   super(model, nodeModel);
	}
    
    
	public void setPlayable(boolean b) {
		m_playButton.setPlayable(b); 
		if (b) 
			m_playButton.addActionListener((SingleNodeModel)m_nodemodel); 
	}

	//creates a balloon with or without a recorded audio
	public void addBalloon(SBalloon b) {
	   b.setLocation(DEFAULT_WIDTH - 3*BUTTON_WIDTH - 15, 3);
	   m_balloons.add(b);
	   add(b);
	   m_slider.setSize(b.getX() - m_slider.getX(), m_slider.getHeight());
	}


	public void removeBalloon(SBalloon b) {
	   m_balloons.remove(b);
	   if (m_balloons.size()==0) m_slider.setSize(m_slider.getWidth() + b.getWidth(), m_slider.getHeight());
	   remove(b);
	}


	//get the duration of recorded audio, then formats it into a String
	public void setAudioDuration(double seconds) {
		m_slider.setTotalTime(seconds);
		repaint();
	}
    
	 public String getAsciiName() {
		int i =0;
		try {
			i = Integer.parseInt(getName());
		} catch (Exception e) {System.out.println("Not an Integer");}
    
		char[] name = new char[1];
		name[0] = (char)(ASCII_A + i);
		return new String(name);
	}
    
    
	/*public void setPercentage(double p) {
		//System.out.println("This should be updated to:");
		//m_slider.setTime(the time we've been recording for);
        
		if(m_slider!=null)  m_slider.setPercent(p);    
	}*/

  
	public void setTotalTime(double t) {
	   if (m_slider!=null) m_slider.setTotalTime(t);
	}
  
  
	public void setCurTime(double t) {
	   if (m_slider!=null) m_slider.setCurTime(t);
	}
  
  
	// NEED TO FIX THIS AND CHECK THE REST OF THE CODE -- this is inverted! - aks, 6/4/00
	public boolean isPlaying() {
	  return !m_playButton.isSelected();
	}
    
	// NEED TO FIX THIS AND CHECK THE REST OF THE CODE -- this is inverted! - aks, 6/4/00
	public boolean isRecording() {
	  return !m_recordButton.isSelected();
	}
    
    
	public void setStopped() {
	  m_recordButton.setSelected(false);
	  m_playButton.setSelected(false);
	  m_slider.setStopped();
	}
    
    
	public void setRecording() {
	  m_recordButton.setSelected(true);
	  m_playButton.setSelected(false);
	  m_slider.setRecording();
	}
    

	public void setPlaying() {
	  m_recordButton.setSelected(false);
	  m_playButton.setSelected(true);
	}
    
    
	public void setPaused() {
	  m_recordButton.setSelected(false);
	  m_playButton.setSelected(false);
	}
    
	public void handleMouseReleased(Component target) {
		if (target instanceof AbstGroupNodeView) {
		   ((SingleNodeModel)m_nodemodel).setGroup((GroupNodeModel)((AbstGroupNodeView)target).getNodeModel());
		}
		else {
		  ((SingleNodeModel)m_nodemodel).clearGroup();
		}
	}
    
	public void handleMouseClicked (MouseEvent e) {      
	   if (SwingUtilities.isMiddleMouseButton(e)) {
	   if (e.isShiftDown()) {
		   (m_nodemodel.getSuedeModel()).replaceAudioFromFile((SingleNodeModel)m_nodemodel);
	   }
	   else if ( ! (m_nodemodel.getSuedeModel()).getAnalysisMode() ) {
		   (m_nodemodel.getSuedeModel()).deleteCard(this.getNodeModel()); 
	   }
	   }
	}
    
///////////////////////Hongvan's code/////////////////////////
	public void handleMousePressed (MouseEvent e) {
		if (SwingUtilities.isRightMouseButton(e)){
			showPopup(e);
		}
	}
    
	public void showPopup(MouseEvent e) {
		if (e.isPopupTrigger()) {
			newPromptCard.setEnabled(false);
			newResponseCard.setEnabled(false);
			paste.setEnabled(false);
			popup.show(e.getComponent(),e.getX(), e.getY());
	}
	}
    
	/** Copy a prompt card */
	public void handleCopyAction () {
		if ( ! (m_nodemodel.getSuedeModel()).getAnalysisMode() ) {
		//Temporarily let it point to promptCard instead of creating a new clone.   
		//m_nodemodel.getSuedeModel().copiedObj = this;
		SuedeModel.copiedObj = this;
		//m_nodemodel.getSuedeModel().copiedLinkObj = null;
		SuedeModel.copiedLinkObj = null;
		}
	}
    
	public void handleCutAction () {
		SuedeModel suedeModel = m_nodemodel.getSuedeModel();
		if ( ! suedeModel.getAnalysisMode() ) {
			//m_nodemodel.getSuedeModel().copiedLinkObj = null;
			SuedeModel.copiedLinkObj = null;
		   //We have to use clone() here to avoid NullPointerException
		   //occurring with getCaption() function
			//suedeModel.copiedObj = (AbstSingleNodeView)this.clone();
			SuedeModel.copiedObj = (AbstSingleNodeView)this.clone();
			(m_nodemodel.getSuedeModel()).deleteCard(this.getNodeModel());
		}
	}

	 /**
   * Generate a copy of this AbstSingleNodeView.
   * @param - none
   * @return
   *   The return value is a copy of this sequence. Subsequent changes to the
   *   copy will not affect the original, nor vice versa. Note that the return
   *   value must be type cast to a <CODE>AbstSingleNodeView</CODE> before it can be used.
   **/
   public Object clone()
   {  // Clone a AbstSingleNodeView object.
	  AbstSingleNodeView answer;

	  try
	  {
		answer = (AbstSingleNodeView) super.clone( );
	  }
	  catch (CloneNotSupportedException e)
	  {  // This exception should not occur. But if it does, it would probably
		 // indicate a programming error that made super.clone unavailable.
		 // The most common error would be forgetting the "Implements Cloneable"

		 // clause at the start of this class.
		 throw new RuntimeException
		 ("This class does not implement Cloneable");
	  }
	  answer.m_nodemodel = (SingleNodeModel)m_nodemodel.clone();
	  return answer;
   }
//////////////////////////////////////////////////////////////////////
	//{{DECLARE_CONTROLS
	//}}
}
