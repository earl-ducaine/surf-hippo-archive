package edu.berkeley.guir.damask.view.appevent;

import java.awt.geom.AffineTransform;
import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.lib.satin.command.Command;
import edu.berkeley.guir.lib.satin.command.CommandQueue;
import edu.umd.cs.piccolo.PCanvas;

/** 
 * A source of command events.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-19-2003 James Lin
 *                               Created CommandEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 09-19-2003
 */
public class CommandEventSource {
   
   private Vector/*<CommandListener>*/ eventListeners = new Vector();
   

   /**
    * Adds the specified command listener to receive command events from
    * this canvas.
    */
   public synchronized void addCommandListener(CommandListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }


   /**
    * Removes the specified command listener so that it no longer receives
    * command events from this canvas.
    */
   public synchronized void removeCommandListener(
      CommandListener listener) {

      eventListeners.remove(listener);
   }

   
   /**
    * Fires commandExecuted events to listeners.
    */
   public void fireCommandExecuted(
      final CommandQueue commandQueue,
      final Command command,
      final PCanvas canvas,
      final AffineTransform canvasTransform) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final CommandEvent event =
         new CommandEvent(
            commandQueue,
            CommandEvent.COMMAND_EXECUTED,
            command,
            canvas,
            canvasTransform);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final CommandListener listener = (CommandListener)i.next();
         listener.commandExecuted(event);
      }
   }

   
   /**
    * Fires commandUndone events to listeners.
    */
   public void fireCommandUndone(
      final CommandQueue commandQueue,
      final Command command,
      final PCanvas canvas,
      final AffineTransform canvasTransform) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final CommandEvent event =
         new CommandEvent(
            commandQueue,
            CommandEvent.COMMAND_UNDONE,
            command,
            canvas,
            canvasTransform);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final CommandListener listener = (CommandListener)i.next();
         listener.commandUndone(event);
      }
   }

   
   /**
    * Fires commandExecuted events to listeners.
    */
   public void fireCommandRedone(
      final CommandQueue commandQueue,
      final Command command,
      final PCanvas canvas,
      final AffineTransform canvasTransform) {

      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final CommandEvent event =
         new CommandEvent(
            commandQueue,
            CommandEvent.COMMAND_REDONE,
            command,
            canvas,
            canvasTransform);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final CommandListener listener = (CommandListener)i.next();
         listener.commandRedone(event);
      }
   }
}
