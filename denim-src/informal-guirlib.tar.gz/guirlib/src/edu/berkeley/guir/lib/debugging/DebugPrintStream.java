//// See bottom of source code for software license.
package edu.berkeley.guir.lib.debugging;

import java.io.PrintStream;
import java.util.Date;

/**
 * A PrintStream that also prints out debugging messages.
 * Meant to replace System.out, use the System.setOut() method.
 * Very useful for hunting down where a print statement is coming
 * from, or for multiplexing a single stream where multiple classes
 * are printing out.
 * <P>
 * For example:
 * <CODE>
 * System.setOut(new edu.berkeley.guir.lib.debugging.DebugPrintStream());
 * </CODE>
 * <P>
 * Example output:
 * <PRE>
 *  &gt;&gt;&gt; Mon Jan 12 17:52:54 PST 2004
 *  &gt;&gt;&gt; ParserLib.parseByDelimiter(ParserLib.java:222)
 *  [countries, 32.13, -122.35] 3
 *     countries
 *     32.13
 *     -122.35
 *  [countries, 32.13, -122.35] 3
 *     countries
 *     32.13
 *     -122.35
 *
 *
 * </PRE>
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Sep 11 2002, JH
 */
public class DebugPrintStream
    extends PrintStream {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    String  strLastClass      = "";
    String  strLastMethod     = "";
    int     lastLine          = 0;
    boolean flagDate          = true;  // print out date?
    boolean flagFullClassName = false; // full class names?

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================





    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    /**
     * Makes a debugging print stream around System.out.
     */
    public DebugPrintStream() {
        super(System.out);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Makes a debugging print stream around System.out.
     * @param newFlagDate is true if you want the date to be printed 
     *                    (default true).
     */
    public DebugPrintStream(boolean newFlagDate) {
        super(System.out);
        flagDate = newFlagDate;
    } // of method

    //----------------------------------------------------------------

    /**
     * Makes a debugging print stream around System.out.
     * @param newFlagDate is true if you want the date to be printed 
     *                    (default true).
     * @param newFlagFullClassName is true if you want full class names
     *                    (default false)
     */
    public DebugPrintStream(boolean newFlagDate, boolean newFlagFullClassName) {
        super(System.out);
        flagDate          = newFlagDate;
        flagFullClassName = newFlagFullClassName;
    } // of method

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================





    //==========================================================================
    //===   PRINTSTREAM METHODS   ==============================================

    public void print() {
    } // of method

    //----------------------------------------------------------------

    public void print(boolean x) {
        printHeader();
        super.print(x);
    } // of method

    //----------------------------------------------------------------

    public void print(char x) {
        printHeader();
        super.print(x);
    } // of method

    //----------------------------------------------------------------

    public void print(int x) {
        printHeader();
        super.print(x);
    } // of method

    //----------------------------------------------------------------

    public void print(long x) {
        printHeader();
        super.print(x);
    } // of method

    //----------------------------------------------------------------

    public void print(float x) {
        printHeader();
        super.print(x);
    } // of method

    //----------------------------------------------------------------

    public void print(double x) {
        printHeader();
        super.print(x);
    } // of method

    //----------------------------------------------------------------

    public void print(char chArr[]) {
        printHeader();
        super.print(chArr);
    } // of method

    //----------------------------------------------------------------

    public void print(String str) {
        printHeader();
        super.print(str);
    } // of method

    //----------------------------------------------------------------

    public void print(Object obj) {
        printHeader();
        super.print(obj);
    } // of method

    //==========================================================================

    public void println() {
    } // of method

    //----------------------------------------------------------------

    public void println(boolean x) {
        printHeader();
        super.print(x + "\n");
    } // of method

    //----------------------------------------------------------------

    public void println(char x) {
        printHeader();
        super.print(x + "\n");
    } // of method

    //----------------------------------------------------------------

    public void println(int x) {
        printHeader();
        super.print(x + "\n");
    } // of method

    //----------------------------------------------------------------

    public void println(long x) {
        printHeader();
        super.print(x + "\n");
    } // of method

    //----------------------------------------------------------------

    public void println(float x) {
        printHeader();
        super.print(x + "\n");
    } // of method

    //----------------------------------------------------------------

    public void println(double x) {
        printHeader();
        super.print(x + "\n");
    } // of method

    //----------------------------------------------------------------

    public void println(char chArr[]) {
        printHeader();
        super.print(chArr.toString() + "\n");
    } // of method

    //----------------------------------------------------------------

    public void println(String str) {
        printHeader();
        super.print(str + "\n");
    } // of method

    //----------------------------------------------------------------

    public void println(Object obj) {
        printHeader();
        super.print(obj + "\n");
    } // of method

    //==========================================================================

    /**
     * Print out a debugging header.
     */
    private void printHeader() {
        StackTraceElement debugInfo        = getCallingClassAndMethod();
        String            strCallingClass  = debugInfo.getClassName();
        String            strCallingMethod = debugInfo.getMethodName();
        String            strFileName      = debugInfo.getFileName();
        String            strLineNumber    = "" + debugInfo.getLineNumber();
        boolean           flagPrintHeader  = true;

        //// 1. Don't print the header if the class and method
        ////    are the same as the last we printed, and if the
        ////    print statement is contiguous with the last one we did.
//        if (strLastClass.equals(strCallingClass)   &&
//            strLastMethod.equals(strCallingMethod) &&
//            debugInfo.getLineNumber() - lastLine <= 1) {
//            flagPrintHeader = false;
//        }

        if (strLastClass.equals(strCallingClass)   &&
            strLastMethod.equals(strCallingMethod)) {
            flagPrintHeader = false;
        }

        //// 2. If we should print the header...
        if (flagPrintHeader == true) {
            StringBuffer strbuf = new StringBuffer();

            //// 2.1. Add the date.
            if (flagDate == true) {
                strbuf.append("\n>>> ");
                strbuf.append(new Date().toString());
            }

            //// 2.2. Assemble the header.
            strbuf.append("\n>>> ");
            if (flagFullClassName == true) {
                strbuf.append(strCallingClass);
            }
            else {
                int index = strCallingClass.lastIndexOf(".");
                strbuf.append(strCallingClass.substring(index + 1));
            }

            strbuf.append(".");
            strbuf.append(strCallingMethod);
            strbuf.append("(");
            strbuf.append(strFileName);
            strbuf.append(":");
            strbuf.append(strLineNumber);
            strbuf.append(")\n");


            //// 2.3. Print the header.
            super.print(strbuf.toString());
        }

        //// 3. Save the last class and method.
        strLastClass  = strCallingClass;
        strLastMethod = strCallingMethod;
        lastLine      = debugInfo.getLineNumber();

    } // of method

    //===   PRINTSTREAM METHODS   ==============================================
    //==========================================================================





    //==========================================================================
    //===   DEBUG STACK METHODS   ==============================================

    /**
     * Get the name of the class and method that called a method.
     * This method works whether or not debugging is turned on.
     *
     * @return array {file name, class name, method name}
     */
    public static StackTraceElement getCallingClassAndMethod() {
        return (getStackTrace()[4]);  // file, class, mthd
                                      // value is 4 b/c
                                      //   1 = this method
                                      //   2 = print
                                      //   3 = calling method
                                      //   4 = method we want
    } // of method

    //-----------------------------------------------------------------

    /**
     * Get the current stack trace.
     */
    private static final StackTraceElement[] getStackTrace() {
        Throwable t = new Throwable().fillInStackTrace();
        return (t.getStackTrace());
    } // of method

    //===   DEBUG STACK METHODS   ==============================================
    //==========================================================================





    //==========================================================================
    //===   MAIN    ============================================================

    public static void test() {
        System.out.println("hey again");
        System.out.println("hey again2");
    } // of method

    public static void main(String[] argv) {
        System.setOut(new DebugPrintStream());
        System.out.print("print");
        System.out.println("hi there");
        System.out.println("hi there2");
        System.out.println(true);
        System.out.println(5);
        test();
        System.out.println("yo there");
        System.out.println("yo there2");

        System.out.println("yo there3");
    } // of main

    //===   MAIN    ============================================================
    //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
