package edu.berkeley.guir.lib.gesture;

import javax.swing.event.EventListenerList;
import edu.berkeley.guir.lib.gesture.util.CollectionListener;
import edu.berkeley.guir.lib.gesture.util.CollectionEvent;
import edu.berkeley.guir.lib.gesture.util.CollectionAdapter;
import edu.berkeley.guir.lib.gesture.util.Misc;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

/** Provides some basic infrastructure for implementing GestureContainer.
    Subclasses need to implement:
    <ul>
    <li> public Class[] getChildTypes()
    <li> protected List getChildren()
    </ul>
*/
public abstract class AbstractGestureContainer extends DefaultGestureObject
  implements GestureContainer, Cloneable {
  static {
    // children are saved with a separate mechanism, not as a property
    Properties.setPropertyPersistence(CHILDREN_PROP, false);
  }
  
  protected transient EventListenerList listenerList =
    new EventListenerList();
  protected String name = null;
  protected CollectionListener collectionListener =
    new MyCollectionListener();
  protected PropertyChangeListener propChangeListener =
    new MyPropChangeListener();

  public void setName(String n)
  {
    if ((name != n) && (n != null) && !n.equals(name)) {
      String oldValue = name;
      name = (n == null) ? null : n.intern();
      propChangeSupport.firePropertyChange(NAME_PROP, oldValue, name);
    }
  }

  public String getName()
  {
    return name;
  }

  public boolean hasProperty(String prop)
  {
    return NAME_PROP.equals(prop) || super.hasProperty(prop);
  }

  public void setPropertyOnTree(String propName, Object value)
  {
    setProperty(propName, value);
    for (Iterator iter = iterator(); iter.hasNext();) {
      GestureObject child = (GestureObject) iter.next();
      if (child instanceof GestureContainer) {
	((GestureContainer) child).setPropertyOnTree(propName, value);
      }
      else {
	child.setProperty(propName, value);
      }
    }
  }
  
  public void setProperty(String propName, Object value)
  {
    if (NAME_PROP.equals(propName)) {
      setName((String) value);
    }
    else {
      super.setProperty(propName, value);
    }
  }

  public Object getProperty(String propName)
  {
    if (NAME_PROP.equals(propName)) {
      return getName();
    }
    else {
      return super.getProperty(propName);
    }
  }
  
  public void addCollectionListener(CollectionListener l)
  {
    listenerList.add(CollectionListener.class, l);
  }

  public void removeCollectionListener(CollectionListener l)
  {
    listenerList.remove(CollectionListener.class, l);
  }

  protected void fireCollectionEvent(int type, GestureObject element,
				     int startIndex)
  {
    GestureObject[] obj = { element };
    fireCollectionEvent(type, obj, startIndex);
  }
  
  protected void fireCollectionEvent(int type, GestureObject[] elements,
				     int startIndex)
  {
    CollectionEvent event = null;
    Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == CollectionListener.class) {
	if (event == null)
	  event = new CollectionEvent(this, type, elements, startIndex);
	switch (type) {
	case CollectionEvent.ELEMENT_ADDED:
	  /*
	  System.out.println("Firing add to " + this + " to listener " + listeners[i+1]);
	  */
	  ((CollectionListener)listeners[i+1]).elementAdded(event);
	  break;
	case CollectionEvent.ELEMENT_REMOVED:
	  ((CollectionListener)listeners[i+1]).elementRemoved(event);
	  break;
	case CollectionEvent.ELEMENT_CHANGED:
	  ((CollectionListener)listeners[i+1]).elementChanged(event);
	  break;
	}
      }
    }
  }

  public Object clone()
  {
    AbstractGestureContainer result = (AbstractGestureContainer)
      super.clone();
    result.listenerList = new EventListenerList();
    result.collectionListener = new MyCollectionListener();
    return result;
  }

  /** Set the parent pointers in the children to point to this (e.g.,
      while cloning) */
  protected void fixParents()
  {
    int i = 0;
    for (Iterator iter = iterator(); iter.hasNext(); i++) {
      GestureObject child = (GestureObject) iter.next();
      child.setParent(this);
    }
  }
  
  public boolean isChildType(Class type)
  {
    Class[] validTypes = getChildTypes();

    boolean result = false;
    for (int i = 0; (i < validTypes.length) && !result; i++) {
      if (validTypes[i].isAssignableFrom(type)) {
	result = true;
      }
    }
    return result;
  }

  public GestureObject getChild(String name)
  {
    GestureObject result = null;
    for (Iterator iter = iterator(); iter.hasNext() && (result == null);) {
      GestureObject child = (GestureObject) iter.next();
      if (child instanceof GestureContainer) {
	String childName = ((GestureContainer) child).getName();
	if (((childName != null) && (childName.equals(name))) ||
	    (name == childName)) {
	  result = child;
	}
      }
    }
    return result;
  }
  
  /** Append an integer to startingName to make it different from all
      children */
  public String getUniqueName(String startingName)
  {
    String result = startingName;
    for (int i = 1; getChild(result) != null; i++) {
      result = startingName + " " + i;
    }
    return result;
  }

  abstract protected List getChildren();

  public void add(GestureObject obj)
  {
    if (isChildType(obj.getClass())) {
      List members = getChildren();
      if (!members.contains(obj)) {
	/*
	System.out.println("AGC.add: adding " + obj + " to " + this);
	*/
	members.add(obj);
	obj.setParent(this);
	if (obj instanceof GestureContainer) {
	  ((GestureContainer) obj).
	    addCollectionListener(collectionListener);
	}
	obj.addPropertyChangeListener(propChangeListener);
	fireCollectionEvent(CollectionEvent.ELEMENT_ADDED, obj, -1);
	propChangeSupport.firePropertyChange(CHILDREN_PROP, null, obj);
      }
    }
    else {
      throw new
	IllegalArgumentException("Objects of type " +
				 obj.getClass().getName() +
				 " cannot be added to " + this + " [" +
				 this.getClass().getName() + "].");
    }
  }

  public GestureObject getChild(int i)
  {
    return (GestureObject) getChildren().get(i);
  }

  public void remove(GestureObject obj)
  {
    if (obj != null) {
      if (obj instanceof GestureContainer) {
	((GestureContainer) obj).
	  removeCollectionListener(collectionListener);
      }
      List members = getChildren();
      int index = members.indexOf(obj);
      members.remove(index);
      obj.setParent(null);
      fireCollectionEvent(CollectionEvent.ELEMENT_REMOVED, obj, index);
      propChangeSupport.firePropertyChange(CHILDREN_PROP, obj, null);
    }
  }
  
  public int size()
  {
    return getChildren().size();
  }
  
  public boolean contains(GestureObject obj)
  {
    return getChildren().contains(obj);
  }
  
  public int indexOf(GestureObject obj)
  {
    return getChildren().indexOf(obj);
  }

  public Iterator iterator()
  {
    return getChildren().iterator();
  }

  /** Return the children that are enabled.  Changes to the returned
      list will not affect this AbstractGestureContainer, but the
      children are not copied. */
  public List getEnabledChildren()
  {
    return (List) Misc.accept(getChildren(), new Misc.Acceptor() {
      public boolean accept(Object obj) {
	GestureObject g = (GestureObject) obj;
	return g.isEnabled();
      }
    });
  }

  protected class MyCollectionListener extends CollectionAdapter {
    public void elementChanged(CollectionEvent e)
    {
      GestureObject source = (GestureObject) e.getSource();
      /*
      System.out.println("elementChanged in " + source + "\t" +
			 e.getStartIndex());
      */
      fireCollectionEvent(CollectionEvent.ELEMENT_CHANGED, source,
			  indexOf(source));
    }
  }

  protected class MyPropChangeListener implements PropertyChangeListener {
    public void propertyChange(PropertyChangeEvent e)
    {
      /*
      System.out.println(AbstractGestureContainer.this +
			 ":\tproperty change in " + e.getSource() + "\t" +
			 e.getPropertyName());
      */
      PropertyChangeEvent newE = new
	PropertyChangeEvent(AbstractGestureContainer.this,
			    CHILD_CHANGE_PROP, null, e);
      newE.setPropagationId(e.getPropagationId());
      propChangeSupport.firePropertyChange(newE);
    }
  }

  // debugging

  /*
  public void validateParents()
  {
    Iterator children = iterator();
    for (int i = 0; children.hasNext(); i++) {
      Object obj = children.next();
      if (obj instanceof Gesture) {
	Gesture gesture = (Gesture) obj;
	if (gesture.getParent() == null) {
	  System.out.println("\tNo parent for gesture #" + i + " of " +
			     this);
	}
      }
      else if (obj instanceof GestureContainer) {
	GestureContainer container = (GestureContainer) obj;
	if (container.getParent() == null) {
	  System.out.println("\tNo parent for child " + container.getName() +
			     " of " + this);
	}
	((AbstractGestureContainer) container).validateParents();
      }
    }
  }
  */

  /** Find an ancestor GestureContainer of class type, or null if
      there is none.  type must be a subclass of GestureContainer. */
  public static GestureContainer findAncestorOfClass(GestureObject obj,
						     Class type)
  {
    if (obj == null) {
      return null;
    }
    if (!GestureContainer.class.isAssignableFrom(type)) {
      throw new IllegalArgumentException
	("Argument 'type' must be a subclass of GestureContainer");
    }
    if (type.isInstance(obj)) {
      return (GestureContainer) obj;
    }
    GestureContainer result;
    for (result = obj.getParent();
	 !(type.isInstance(result));
	 result = result.getParent())
      ;
    return result;
  }

  /** Returns an unmodifiable list of the children of container */
  public static List getChildList(GestureContainer container)
  {
    if (container instanceof AbstractGestureContainer) {
      return Collections.
	unmodifiableList(((AbstractGestureContainer) container).
			 getChildren());
    }
    else {
      return Collections.
	unmodifiableList(Misc.mapcar(container.iterator(),
				     Misc.IDENTITY_OPERATOR));
    }
  }
}
