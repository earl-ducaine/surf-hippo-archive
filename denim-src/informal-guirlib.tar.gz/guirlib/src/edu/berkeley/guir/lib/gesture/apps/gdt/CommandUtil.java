package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.util.Collection;
import java.util.Iterator;
import javax.swing.event.EventListenerList;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class CommandUtil {
  static boolean isCommandValid(int id, Collection commanders)
  {
    return findAcceptor(id, commanders) != null;
  }

  static Commander findAcceptor(int id, Collection commanders)
  {
    for (Iterator iter = commanders.iterator(); iter.hasNext();) {
      Commander cmdr = (Commander) iter.next();
      if (cmdr.isCommandValid(id)) {
	return cmdr;
      } 
    }
    return null;
  }

  /** Do the command on the first commander that allows it */
  static void doCommand(int id, Collection commanders)
  {
    Commander cmdr = findAcceptor(id, commanders);
    if (cmdr != null) {
      cmdr.doCommand(id);
    }
  }

  static void fireMenuValidChangeEvent(EventListenerList listenerList,
				       ChangeEvent e)
  {
    Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length-2; i>= 0; i-= 2) {
      if (listeners[i] == ChangeListener.class) {
	((ChangeListener)listeners[i+1]).stateChanged(e);
      }
    }
  }
}
