//// See bottom of file for software license
package edu.berkeley.guir.lib.collection;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * A 2-way map, fast indexing for key-value and value-key.
 * Assumes there is a 1-to-1 mapping (otherwise this class won't work).
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Jul 31 2002 JIH
 */
public final class IndexedMap 
    implements Map {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    HashMap mapForward = new HashMap();   // key   - value
    HashMap mapReverse = new HashMap();   // value - key

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Create an empty map.
     */
    public IndexedMap() {
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Create an IndexedMap from a regular map (ie do reverse-indexing).
     */
    public IndexedMap(Map m) {
        putAll(m);
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   MAP OPERATIONS   ===================================================

    public int size() {
        return (mapForward.size());
    } // of method

    //----------------------------------------------------------------

    public boolean isEmpty() {
        return (mapForward.isEmpty());
    } // of method

    //----------------------------------------------------------------

    public boolean containsKey(Object key) {
        return (mapForward.containsKey(key));
    } // of method

    public boolean containsValue(Object value) {
        return (mapReverse.containsKey(value));
    } // of method

    //----------------------------------------------------------------

    public Object get(Object key) {
        return (mapForward.get(key));
    } // of method

    //----------------------------------------------------------------

    public Object put(Object key, Object value) {
        mapForward.put(key, value);
        mapReverse.put(value, key);
        return (value);
    } // of method

    //----------------------------------------------------------------

    public Object remove(Object key) {
        Object obj = mapForward.remove(key);
        mapReverse.remove(obj);
        return (obj);
    } // of method

    //----------------------------------------------------------------

    public void putAll(Map t) {
        Iterator it = t.keySet().iterator();
        Object   key;
        Object   val;

        while (it.hasNext()) {
            key = it.next();
            val = t.get(key);
            put(key, val);
        }
    } // of method

    //----------------------------------------------------------------

    public void clear() {
        mapForward.clear();
        mapReverse.clear();
    } // of method

    //----------------------------------------------------------------

    public Set keySet() {
        return (mapForward.keySet());
    } // of method

    public Collection values() {
        return (mapForward.values());
    } // of method

    public Set entrySet() {
        return (mapForward.entrySet());
    } // of method

    //----------------------------------------------------------------

    public boolean equals(Object o) {
        //// 1. Quick check.
        if (o instanceof IndexedMap == false) {
            return (false);
        }

        //// 2. Check if the contained maps are the same.
        IndexedMap mapAA = this;
        IndexedMap mapBB = (IndexedMap) o;

        return (mapAA.mapForward.equals(mapBB.mapForward) &&
                mapAA.mapReverse.equals(mapBB.mapReverse));
    } // of method

    //===   MAP OPERATIONS   ===================================================
    //==========================================================================




    //==========================================================================
    //===   INDEXED OPERATIONS   ===============================================

    /**
     * Given a value, get its key.
     */
    public Object getKey(Object val) {
        return (mapReverse.get(val));
    } // of method

    //===   INDEXED OPERATIONS   ===============================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        return (mapForward.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN ==================================================

    public static void main(String[] argv) {
        IndexedMap map = new IndexedMap();

        map.put("A", "aardvark");
        map.put("B", "bear");
        map.put("C", "cut");
        map.put("D", "dog");
        map.put("E", "elephant");

        System.out.println("-----------");
        System.out.println(map);

        System.out.println();
        System.out.println("-----------");
        System.out.println(map.getKey("aardvark"));
        System.out.println(map.getKey("A"));
    } // of method

    //===   SELF-TESTING MAIN ==================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
