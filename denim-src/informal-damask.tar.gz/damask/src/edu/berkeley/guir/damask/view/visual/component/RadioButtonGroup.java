package edu.berkeley.guir.damask.view.visual.component;

import java.util.*;

import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.component.SelectOne;
import edu.berkeley.guir.damask.event.ElementContainerEvent;
import edu.berkeley.guir.damask.event.ElementContainerListener;
import edu.umd.cs.piccolo.PNode;

/** 
 * An invisible group that contains radio buttons.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  12-16-2003 James Lin
 *                               Created RadioButtonGroup.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 12-16-2003
 */
public class RadioButtonGroup extends ControlView {
   
   private final RadioButtonHandler radioButtonHandler =
      new RadioButtonHandler();
   private final Map/*<SelectOne.Item, RadioButton>*/ views =
      new HashMap()/*<SelectOne.Item, RadioButton>*/;
   private SelectOne.Item selectedItem;
   private boolean childrenSelectable = true;
      
   
   /**
    * Constructs a radio button group and associates it with the specified
    * select-one object. 
    */
   public RadioButtonGroup(final SelectOne selectOne) {
      super(selectOne);
      selectOne.addElementContainerListener(radioButtonHandler);
      super.setSelectable(false);
   }
   
   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      for (Iterator i = ((SelectOne)getModel()).getItems().iterator();
         i.hasNext();
         ) {

         final SelectOne.Item selectOneItem = (SelectOne.Item)i.next();
         final RadioButton radioButton = new RadioButton(selectOneItem);
         
         addChild(radioButton);
         radioButton.setInRunMode(isInRunMode());
         views.put(selectOneItem, radioButton);
      }
   }
   
   
   // Overrides method in parent class.
   public void dispose() {
      super.dispose();
      ((SelectOne)getModel()).removeElementContainerListener(
         radioButtonHandler);
   }


   // Overrides method in parent class.
   public void setInRunMode(boolean flag) {
      super.setInRunMode(flag);
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final RadioButton radioButton = (RadioButton)i.next();
         radioButton.setInRunMode(flag);
      }
   }


   // Overrides method in parent class.
   public void setSelectable(boolean flag) {
      childrenSelectable = flag;
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof RadioButton) {
            ((RadioButton)child).setSelectable(flag);
         }
      }
   }


   // Overrides method in ancestor class.
   public void setPickable(boolean flag) {
      super.setPickable(flag);
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         child.setPickable(flag);
      }
   }


   /**
    * Returns the selected item in this group.
    * 
    * @return an instance of {@link edu.berkeley.guir.damask.component.SelectOne.Item}
    */
   public Object getState() {
      return selectedItem;
   }


   /**
    * Selects the specified radio button in this group, and unselects the
    * others.
    * 
    * @param state an instance of {@link edu.berkeley.guir.damask.component.SelectOne.Item} representing the selected item
    */
   public void setState(final Object state) {
      selectedItem = (SelectOne.Item)state;
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final RadioButton radioButton = (RadioButton)i.next();
         if (state == radioButton.getModel()) {
            radioButton.setChecked(true);
         }
         else {
            radioButton.setChecked(false);
         }
      }
   }


   // Overrides abstract method in parent class.
   public Object getEditableContents() {
      return getContent();
   }

   /**
    * Returns the content of this component view, which is always null.
    */
   public Label getContent() {
      return null;
   }


   /** 
    * Handles element container events.
    */
   public class RadioButtonHandler implements ElementContainerListener {
      public void elementAdded(ElementContainerEvent e) {
         final SelectOne.Item selectOneItem = (SelectOne.Item)e.getElement();
         final RadioButton radioButton = new RadioButton(selectOneItem);

         addChild(radioButton);
         radioButton.setInRunMode(isInRunMode());
         radioButton.setSelectable(childrenSelectable);
         radioButton.setPickable(getPickable());
         views.put(selectOneItem, radioButton);
      }

      public void elementRemoved(ElementContainerEvent e) {
         final InteractionElement element = e.getElement();
         final PNode elementView = (PNode)views.get(element);

         assert elementView
            instanceof RadioButton : "elementView must be a radio button, not "
               + elementView;

         elementView.removeFromParent();
         views.remove(element);
      }
   }
}
