package edu.berkeley.guir.lib.gesture.apps.gdt;

import java.beans.*;
import edu.berkeley.guir.lib.gesture.GestureObject;
import java.awt.Component;

public class EnableListener implements PropertyChangeListener {
  Component display;

  public EnableListener(Component display)
  {
    this.display = display;
  }
  
  public void propertyChange(PropertyChangeEvent e)
  {
    if (GestureObject.ENABLED_PROP == e.getPropertyName()) {
      display.setBackground(((GestureObject) e.getSource()).isEnabled() ?
			    GestureObjectDisplay.ENABLED_BACKGROUND :
			    GestureObjectDisplay.DISABLED_BACKGROUND);
    }
  }
}
