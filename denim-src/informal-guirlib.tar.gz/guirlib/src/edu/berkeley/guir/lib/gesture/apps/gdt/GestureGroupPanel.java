package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.*;
import javax.swing.*;
import java.awt.datatransfer.Transferable;

public class GestureGroupPanel extends GestureContainerPanel {
  public GestureGroupPanel()
  {
    this(null);
  }

  public GestureGroupPanel(GestureGroup gg)
  {
    this(null, null);
  }
  
  public GestureGroupPanel(GestureGroup gg, JScrollPane scrollPane)
  {
    super(gg, scrollPane);
  }

  public void setGestureGroup(GestureGroup gg)
  {
    setGestureContainer(gg);
  }

  public void setGestureContainer(GestureContainer gestureGroup)
  {
    if ((gestureGroup != null) && !(gestureGroup instanceof GestureGroup)) {
      throw new
	IllegalArgumentException("Only GestureGroup is allowed, not "
				 + gestureGroup.getClass().getName() +
				 "(" + gestureGroup + ")");
    }
    super.setGestureContainer(gestureGroup);
  }

  public GestureGroup getGestureGroup()
  {
    return (GestureGroup) getGestureContainer();
  }

  protected boolean canPaste(Transferable t)
  {
    boolean result =
      t.isDataFlavorSupported(GestureFlavorFactory.
			      GESTURE_CATEGORY_COLLECTION_FLAVOR) ||
      t.isDataFlavorSupported(GestureFlavorFactory.GESTURE_CATEGORY_FLAVOR);
    return result;
  }
  
  public boolean gestureDrawn(Gesture gesture)
  {
    // todo: recognize gesture and display result
    return false;
  }

  public boolean isCommandValid(int id)
  {
    boolean valid;
    switch (id) {
    case NEW_GESTURE_ACTION:
      valid = true;
      break;
    default:
      valid = super.isCommandValid(id);
      break;
    }
    return valid;
  }

  public void doCommand(int id)
  {
    switch (id) {
    case NEW_GESTURE_ACTION:
      getGestureGroup().
	add(new GestureCategory(Gensym.next(GESTURE_CATEGORY_PREFIX)));
      break;
    default:
      super.doCommand(id);
      break;
    }
  }
}
