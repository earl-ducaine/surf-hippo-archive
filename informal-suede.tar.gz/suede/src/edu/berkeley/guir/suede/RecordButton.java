package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.geom.*;

public class RecordButton extends javax.swing.JToggleButton
{
    private Color recordColor;
    private Color pauseColor;

    public RecordButton(Color record, Color pause) {
        setBorderPainted(false);
        setContentAreaFilled(false);
        setFocusPainted(false);
        setIcon(new RecordIcon());
        setSelectedIcon(new PauseIcon());
        recordColor = record;
        pauseColor = pause;
    }


    public void setPauseColor(Color pColor) {
       pauseColor = pColor; 
    }


    public class RecordIcon implements javax.swing.Icon {
        public void paintIcon(Component c, Graphics g, int x, int y) {  
            Graphics2D g2d = (Graphics2D)g;
            g2d.setColor(recordColor);
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Ellipse2D oval = new Ellipse2D.Float(getWidth()/2 - getHeight()*0.23f, getHeight()*0.27f, 
                                                 getHeight()*0.46f, getHeight()*0.46f);
            g2d.fill(oval);
        }
        
        public int getIconHeight() {  return HEIGHT;  }

        public int getIconWidth()  {  return WIDTH;   }

    }
    
    public class PauseIcon implements javax.swing.Icon {
        public void paintIcon(Component c, Graphics g, int x, int y) {  
            Graphics2D g2d = (Graphics2D)g;
            g2d.setColor(pauseColor);
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            g2d.fill(new Rectangle((int)(getWidth()*0.5f - getHeight()*0.21f + 0.5f), 
                                   (int)(getHeight()*0.32f),
                                   (int)(getHeight()*0.12f + 0.5f), 
                                   (int)(getHeight()*0.49f)));

            g2d.fill(new Rectangle((int)(getWidth()*0.5f + getHeight()*0.04f + 0.5f), 
                                   (int)(getHeight()*0.32f),
                                   (int)(getHeight()*0.12f + 0.5f), 
                                   (int)(getHeight()*0.49f)));
        }
        
        public int getIconHeight() {  return HEIGHT;  }

        public int getIconWidth()  {  return WIDTH;   }

    }
    
}