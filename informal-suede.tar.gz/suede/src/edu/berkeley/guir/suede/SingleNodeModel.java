package edu.berkeley.guir.suede;

import java.awt.event.*;
import javax.sound.sampled.*;
import java.awt.*;
import java.util.*;


/*
 *Things that must be changed for model/viewer rewrite:
 *
 * - Overall: Currently, outside code interacts with the model, which interacts with the view.
 * -            Instead, outside code should interact with the view, and the view interacts with the model.
 *
 * - remove m_node
 * - update constructor. Have code that creates model also create viewer.
 * - remove isOperable() and setPlayable(). Change calling code.
 * - remove m_node from add/removeBalloon(). View shouldn't have to worry about that.
 * - move all group and expand/collapse functionality to viewer.
 * - remove m_node references in get and set methods.
 * - move some or all of save functionality to viewer.
 * - remove m_node references from play and record methods. 
 * - move actionPeformed() to viewer.
 *
 * - Maybe move play and record functions up to AbstNodeModel so that LinkModel can share them.
 *   Alternative is to make a subclass below AbstNodeModel which contains audio functions,
 *   then have LinkModel and SingleNodeModel extend this.

 *  //////Hongvann's changes////////////////////
 *  Make SingleNodeModel implement Cloneable to creat a copy of this object
 *  for the purpose of copy/cut/paste
 */


public class SingleNodeModel extends AbstNodeModel implements ActionListener, SSavableElt {
 
	private SuedeModel m_model;

	private String m_caption    = "";       
	private AbstSingleNodeView m_node  = null;        
  
	private final boolean DEBUG         = false;   // turns debugging on and off
	private final boolean BARGING       = false;  // turns barging on and off
	private final boolean SAMPLINGGRAPH = true;   // turns sampling panel on and off
	private       boolean checkBARGING  = false;  // used internally as a mode for checking barging state
    
   
	private CallbackIF       m_callback      = null;
	private SamplingGraph    m_samplingGraph = new SamplingGraph();
	private CallWhenFinished m_cwf           = new CallWhenFinished(m_samplingGraph);
	private CardSound        m_cardSound     = new CardSound((EndPlayCallbackIF)m_cwf, (EndRecordCallbackIF)m_cwf);
	private int              m_numberofhits  = 0;
    
	private int m_centerX;
	private int m_centerY;
	private GroupNodeModel m_group = null;
	private String m_groupname;
	private String m_name;
    
	private Vector m_balloons = new Vector(); // Vector of SBalloon
	//length of audio recorded by user for this node, set to 0 by default 
	private double m_duration = 0.0;
    
    
	public SingleNodeModel(SuedeModel model, SContentPane pane, String label) { 
	  m_model = model;
	  // the four params are Model, NodeModel, ActionListener, Label
	  m_node = new SingleDefaultNodeView(model, this, label, this, "");
	  m_samplingGraph.setElement(m_node);
	  m_node.setPlayable(false);
	  setLabel(label);
	  setGroupName("");
	  if (pane!=null) pane.add(m_node, SContentPane.NODE_LAYER);
	}
    

	public boolean isOperable(Point p)    { return m_node.isOperable(p);              }
    
	public void    setPlayable(boolean b) { m_node.setPlayable(b);                    }
    
	public int     getNumBalloons()       { return m_balloons.size();                 }
  
	public void    playBalloon(int i)     { ((SBalloon)m_balloons.get(i)).play(this); }
    
	public Vector  getBalloons()          { return m_balloons;                        }
    
   
	public void addBalloon(LinkModel lm) {
	   //System.out.println("addBalloon..."+ lm.getCaption());
	   setCaption(getCaption() + " {" + lm.getCaption() +"}");
	   SBalloon b = new SBalloon(lm, this);
	   m_balloons.add(b);
	   //System.out.println("m_balloons.size() is "+m_balloons.size());
	   m_node.addBalloon(b);
	   lm.addBalloonOwner(this); //tell the link model that it's a balloon for this node. This is used in case the link is deleted.
	}
    
	//same as above except used when loading a balloon (no need to set caption twice)
	public void loadBalloon(LinkModel lm) {
	   //System.out.println("loadBalloon..."+ lm.getCaption());
	   SBalloon b = new SBalloon(lm, this);
	   m_balloons.add(b);
	   m_node.addBalloon(b);
	   lm.addBalloonOwner(this); //tell the link model that it's a balloon for this node. This is used in case the link is deleted.
	}
    
    
	// if a link model is deleted, it is necessary to get rid of the balloon
	public void removeBalloon(LinkModel linkModel) {
	  for (int i=0; i<m_balloons.size(); i++) {
		 if (((SBalloon)m_balloons.get(i)).getLinkModel()==linkModel) {
			m_node.removeBalloon((SBalloon)m_balloons.remove(i));
			
			// remove the balloon's caption as well
			String balloonCaption = "{"+linkModel.getCaption()+"}";
			String begCaption = getCaption().substring(0, getCaption().indexOf(balloonCaption));
			String endCaption = getCaption().substring(getCaption().indexOf(balloonCaption)+balloonCaption.length());
			setCaption(begCaption+endCaption); 
		 }
	  }
	}
    
    
 
	public synchronized void setAudioDuration() {
		if(m_cardSound.isAvailable()) {
			m_duration = m_cardSound.getDuration();
			((AbstSingleNodeView)m_node).setAudioDuration(m_duration); 
		}
	}
    
	//collapses the view when this node's group is called to collapse
	public void collapseInGroup() {
		String s = getCaption();
		String name = m_node.getName();
		SContentPane pane = m_model.getContentPane();
		pane.remove(m_node);
		m_node = new SingleSuperCollapsedNodeView(m_model, this, name, this, s);
		m_node.setLocation(m_locationX, m_locationY);
		pane.add(m_node, SContentPane.NODE_LAYER);
		m_node.setPlayable(m_cardSound.isAvailable());
	}
    
	/*general method to collapse a prompt node.
	  Gesture up on a default view collapses the node.
	  Gesture up on an expanded view returns it to default.
	  Gesture up on an already-collapsed node doesn't do anything
	*/
	public void collapse() {
		String s = getCaption();
		String name = m_node.getName();
		SContentPane pane = m_model.getContentPane();
		pane.remove(m_node);
		if(m_node instanceof SingleDefaultNodeView) {
			m_node = new SingleCollapsedNodeView(m_model, this, name, this, s);
		}
		else if(m_node instanceof SingleCollapsedNodeView && m_group!=null) {
			m_node = new SingleSuperCollapsedNodeView(m_model, this, name, this, s);   
		}
		else if(m_node instanceof SingleExpandedNodeView) {
			m_node = new SingleDefaultNodeView(m_model, this, name, this, s);     

		}
		else {}
		 m_node.setLocation(m_locationX, m_locationY);
		 pane.add(m_node, SContentPane.NODE_LAYER);
		 m_node.setPlayable(m_cardSound.isAvailable());
		 //resizes the group that contains this node
		 if(m_group!=null)
			m_group.resize();
       
	}
    
    
	//expands the view when this node's group is called to expande
	public void expandInGroup() {
		String s = getCaption();
		String name = m_node.getName();
		SContentPane pane = m_model.getContentPane();
		pane.remove(m_node);
		m_node = new SingleDefaultNodeView(m_model, this, name, this, s);
		if(m_duration!=0.0) m_node.setAudioDuration(m_duration);
		m_node.setLocation(m_locationX, m_locationY);
		pane.add(m_node, SContentPane.NODE_LAYER);
		m_node.setPlayable(m_cardSound.isAvailable());
	}
    
	/*general method to expand a prompt node.
	  Gesture down on a default view expands the node.
	  Gesture down on an already-expanded view does nothing.
	  Gesture down on an collapsed view returns it to default.
	*/
	public void expand() {
		String s = getCaption();
		String name = m_node.getName();
		SContentPane pane = m_model.getContentPane();
		pane.remove(m_node);
		if(m_node instanceof SingleDefaultNodeView && m_group==null) {
			m_node = new SingleExpandedNodeView(m_model, this, name, this, s);
		}
		else if(m_node instanceof SingleSuperCollapsedNodeView) {
			m_node = new SingleCollapsedNodeView(m_model, this, name, this, s);
		}
		else if(m_node instanceof SingleCollapsedNodeView) {
			m_node = new SingleDefaultNodeView(m_model, this, name, this, s);
		}
		else {}
		m_node.setLocation(m_locationX, m_locationY);
		pane.add(m_node, SContentPane.NODE_LAYER);
		m_node.setPlayable(m_cardSound.isAvailable());
		if(m_group!=null)
			m_group.resize();
	}
    
	/*Construct the default view for a prompt node. 
	  if the node is outside of groups, it constructs the default view.
	  if the node is inside a group, it constructs the collapsed view
	*/
	public void consDefault() {
		String s = getCaption();
		String name = m_node.getName();
		SContentPane pane = m_model.getContentPane();
		pane.remove(m_node);
		if(m_group!=null) {
			m_node = new SingleCollapsedNodeView(m_model, this, name, this, s);   
		}
		else {
			m_node = new SingleDefaultNodeView(m_model, this, name, this, s);
		}
		m_node.setLocation(m_locationX, m_locationY);
		pane.add(m_node, SContentPane.NODE_LAYER);
		m_node.setPlayable(m_cardSound.isAvailable());
	}
    
	public GroupNodeModel getGroup() {
		return m_group;
	}   
  
	public boolean setGroup (GroupNodeModel group) {
		if(group!=null) {
			if(group != m_group) {
				if(m_group!=null)
					m_group.removeFromGroup(this);
				m_group = group;
				consDefault();
				m_group.addToGroup(this);
			}
			else {
				Point p = m_group.getLocationForComponent(m_node);  
				setLocation(p.x, p.y);
			}
			return true;
		}
		return false;
               
	}
    
	public void clearGroup() {
		if(m_group!=null) {
			m_group.removeFromGroup(this);
			m_group = null;
			consDefault();
		}
  
	}
    
   public int getNumberOfHits() {
	 return m_numberofhits;
   }
  
   public void setNumberOfHits(int numberofhits) {
	 m_numberofhits = numberofhits;     
  }
   
   public void incrementNumberOfHits() {
	m_numberofhits++;
  }
  
	public String getGroupName() { return m_groupname;        }
    
	public void setGroupName(String lbl) { 
		m_groupname = lbl;
       
	}
    
	public String getLabel() {
	  return m_name;
	}
    
	public void setLabel(String label) {  
	  m_name = label;
	  m_node.setName(label);      
	}

	public String getCaption() {
	m_caption = m_node.getCaption();
	return m_caption;
	}
    
	public String getCleanedCaption() {
	String temp_caption = m_node.getCaption();
	m_caption = m_node.getCaption();
	  
	for (int i = 0; i < temp_caption.length(); i++) {
		if (temp_caption.charAt(i) == '<') {
		temp_caption = temp_caption.substring(0, i) + "&lt;" + temp_caption.substring(i+1);
		i+=3;
		}
		else if (temp_caption.charAt(i) == '>') {
		temp_caption = temp_caption.substring(0, i) + "&gt;" + temp_caption.substring(i+1);
		i+=3;
	  }
	}
	
	//System.out.println("GET CLEANED CAPTION: " + temp_caption);
	return temp_caption;
	}
    
	public void setCaption (String lbl) {      
	m_caption = lbl;
	m_node.setCaption(m_caption);
	}
      
	public void setCenter(int x, int y) {
	  m_centerX = x;
	  m_centerY = y;
	  m_node.setCenter(x,y);   
	}
      
	public Point getLocation() {
		return m_node.getLocation();  
	}
    
	public AbstNodeView getView() {
		return m_node;
	}
    
	public void removeNode() {
	  if(m_group!=null) {
		m_group.removeFromGroup(this); 
	  }
	  java.awt.Container p = m_node.getParent();
	  m_node.getParent().remove(m_node);   
	  m_node = null;
	  p.repaint();
	}
  
    
	/*
	 * pass back the audio that is stored internally for this card, for the current stream
	*/
	public synchronized AudioInputStream getAudio() {
	  return m_cardSound.getAudio();
	}
    
   
	/*
	 * assign this card the correct audio.
	 */
	public synchronized void setAudio(AudioInputStream ais) {      
	  m_cardSound.setAudio(ais);
	  setAudioDuration();
	  setPlayable(ais!=null);
	}



   public synchronized double getDuration() {
	  return m_cardSound.getDuration();  
   }


	  public void fillAudio(String filename) {
        
		if(filename.indexOf("NO_AUDIO")==-1) {
			java.io.File file = new java.io.File(filename);
			m_cardSound.createAudioInputStream(file, true);
			setAudioDuration();
			setPlayable(m_cardSound.isAvailable());
 
		}
	  }


	public String save(String path) {
	  return save(path, m_node.getName() + ".wav");      
	}
  
      
	public String save(String path, String externalFileName) {
      
		String r = "";
		r = r + "<card>";
    
		r = r + "<label>";
		r = r + m_node.getName();
		r = r + "</label>";
        
		r = r + "<ux>";
		r = r +  m_node.getX();
		r = r + "</ux>";

		r = r + "<uy>";
		r = r + m_node.getY();
		r = r + "</uy>";


		r = r + "<caption>";
		r = r + getCleanedCaption();
		r = r + "</caption>";

		//this takes care of the case where a balloon with no audio exists
		/*if(m_cardSound.getNumberStreams()<=0 && m_balloon!=null) {
			r = r + "<filename>"+path + m_balloon.getLinkModel().getLabel()+ ".wav"+ "NO_AUDIO"+"</filename>";
		}
		// walk through each of the audiostreams associated with this card and write them out
		// anything with filename will be read in.
		for (int i = 0; i < m_cardSound.getNumberStreams(); i++) {
          
		  r = r + "<filename>";
		  m_cardSound.setCurrentStreamNumber(i);
		  LinkModel bubbleslink = m_model.lookupLinkModelByAudioPtr(m_cardSound.getAudioPtr());
		  if (bubbleslink != null) {  // we've actually got a bubble here            
			// save the name of the bubble audio file instead
			// double check this when deleting is implemented, we need the bubble to exist
			r = r + path + bubbleslink.getLabel() + ".wav";
		  } 
		  else {
			r = r + path + externalFileName + i;
			m_cardSound.saveToFile(path + externalFileName + i, AudioFileFormat.Type.WAVE);
		  }
		  r = r + "</filename>";
		}*/

		// walk through each of the audiostreams associated with this card and write them out
		// anything with filename will be read in.
		if(m_cardSound.isAvailable()) {
		  //System.out.println("saving card: " + externalFileName); //RMV
		  r = r + "<filename>";
		  r = r + externalFileName;
		  r = r + "</filename>";
		  m_cardSound.saveToFile(path + externalFileName, AudioFileFormat.Type.WAVE);
		}
        
        
		// only transcript system prompts can have balloons...
		//System.out.println("m_balloons.size() is "+m_balloons.size());
		for (int i = 0; i < m_balloons.size(); i++) {
		  r = r + "<balloon>";
		  r = r + ((SBalloon)m_balloons.get(i)).getLinkLabel();
		  r = r + "</balloon>";
		}

		r = r + "<groupname>";
		r = r + getGroupName();
		r = r + "</groupname>";
        
		r = r + "</card>";
        
	  return r;
	}
    

    
	public void play() {
      
	  if (DEBUG) { System.out.println("playing or stopping..."); }
      
	  if (m_node.isPlaying()) {
        
		setStopped();
		m_cardSound.stopPlayingAudio();
	  } else {

		if (SAMPLINGGRAPH) m_samplingGraph.startPlay(m_cardSound);

		if (m_cardSound.isAvailable()) {
		  m_node.setPlaying();  
		  m_cardSound.playAudio();            
		} else {
		  m_node.setPlaying();    
		  m_node.setStopped();     
		  m_cwf.callmeWhenDonePlaying(/*m_cardSound*/);
		}
	  }      
	}
    
    
	public void record() {
	   if (DEBUG) { System.out.println("recording or stopping..."); }
	   if (m_node.isRecording()) {
		m_node.setStopped();
		m_cardSound.stopRecordingAudio();      
		if (SAMPLINGGRAPH) { m_samplingGraph.stop(); }
		//System.out.println("stopping");
       
	  } else {
		m_node.setRecording();
		m_cardSound.recordAudio(false, 0);  
		//System.out.println("recording");
		if (SAMPLINGGRAPH) { m_samplingGraph.startCapture(m_cardSound); }
	  }
	}
    
    
	// this is called after all balloon audio is played, telling the UI to display itself in stopped mode
	public synchronized void setStopped() {
	  m_node.setStopped();
	  if (SAMPLINGGRAPH) { m_samplingGraph.stop(); m_node.setStopped(); }
	}
    
    
	 public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
     
       
		if (obj.getClass().toString().compareTo("class edu.berkeley.guir.suede.PlayButton") == 0) {
		  play();
		} else if (obj.getClass().toString().compareTo("class edu.berkeley.guir.suede.RecordButton") == 0) {
		  record();
		}
	}  // end ActionPerformed
    
  
	public void callWhenBalloonFinished() {
	  m_cwf.callmeWhenDonePlaying(); 
	}
    
    
  
  /**
	 *  
	 */
	private class CallWhenFinished extends AbstCallWhenFinished {
      
	   public CallWhenFinished (SamplingGraph samplingGraph) {
		  super(samplingGraph, SingleNodeModel.this);   
	   }
      
      
	  public void callmeWhenDoneRecording() {
		if (DEBUG) { System.out.println("callwhenfinished, endrecordcallbackif, done recording ... ");}  
		//obtains the length in seconds of the recorded audio, which is then dispayed next to the slide bar on the node view
		 if(m_cardSound.isAvailable()) {
			m_duration = m_cardSound.getDuration();
		//System.out.println("duration="+m_duration);
			m_node.setAudioDuration(m_duration);
			m_node.setPlayable(true);
		 }
	  }
      
	}  // end class CallWhenFinished
    
	///////////////Hongvan's code/////////////////////////
	 /**
   * Generate a copy of this SingleNodeModel.
   * @param - none
   * @return
   *   The return value is a copy of this sequence. Subsequent changes to the
   *   copy will not affect the original, nor vice versa. Note that the return
   *   value must be type cast to a <CODE>SingleNodeModel</CODE> before it can be used.
   **/
  /**public Object clone()
   {  // Clone a SingleNodeModel object.
	  SingleNodeModel answer;

	 // try
	 // {
		answer = (SingleNodeModel) super.clone( );
	 // }
	 /* catch (CloneNotSupportedException e)
	  {  // This exception should not occur. But if it does, it would probably
		 // indicate a programming error that made super.clone unavailable.
		 // The most common error would be forgetting the "Implements Cloneable"

		 // clause at the start of this class.
		 throw new RuntimeException
		 ("This class does not implement Cloneable");
	  }*/

	  //answer.data = (double [ ]) data.clone( );

	  //return answer;
   //}
//////////////////////////////////////////////////////////////////////
    
}
