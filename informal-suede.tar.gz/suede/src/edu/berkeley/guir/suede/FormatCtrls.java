package edu.berkeley.guir.suede;

import javax.sound.sampled.*;
import java.util.Vector;

    /**
     * Controls for the AudioFormat.
     */
    public class FormatCtrls {

        private int m_encoding         = 0;
        private int m_samplerate       = 4;
        private int m_samplesizeinbits = 1;
        private int m_sign             = 0;
        private int m_endian           = 1;
        private int m_channels         = 1;
        
        private Vector groups          = new Vector();
        private Vector encodingGroup   = new Vector();
        private Vector sampleRateGroup = new Vector();
        private Vector sampleSizeInBitsGroup = new Vector();
        private Vector signGroup       = new Vector();
        private Vector channelsGroup   = new Vector();
        private Vector endianGroup     = new Vector();
            

        public FormatCtrls() {
            
            encodingGroup.addElement("linear");
            encodingGroup.addElement("ulaw");
            encodingGroup.addElement("alaw");
            groups.addElement(encodingGroup);
            
            sampleRateGroup.addElement("8000");
            sampleRateGroup.addElement("11025");
            sampleRateGroup.addElement("16000");
            sampleRateGroup.addElement("22050");
            sampleRateGroup.addElement("44100");
            groups.addElement(sampleRateGroup);
            
            sampleSizeInBitsGroup.addElement("8");
            sampleSizeInBitsGroup.addElement("16");
            groups.addElement(sampleSizeInBitsGroup);
            
            signGroup.addElement("signed");
            signGroup.addElement("unsigned");
            groups.addElement(signGroup);
            
            endianGroup.addElement("little endian");
            endianGroup.addElement("big endian");
            groups.addElement(endianGroup);
            
            channelsGroup.addElement("mono");
            channelsGroup.addElement("stereo");
            groups.addElement(channelsGroup);
        }
    
        
        public synchronized AudioFormat getFormat() {

            Vector v = new Vector(groups.size());
            v.add(encodingGroup.elementAt(m_encoding));  // linear
            v.add(sampleRateGroup.elementAt(m_samplerate));  // 44k
            v.add(sampleSizeInBitsGroup.elementAt(m_samplesizeinbits));  // 16
            v.add(signGroup.elementAt(m_sign)); // signed
            v.add(endianGroup.elementAt(m_endian)); // big endian
            v.add(channelsGroup.elementAt(m_channels)); // stereo
            

            AudioFormat.Encoding encoding = AudioFormat.Encoding.ULAW;
			
            String encString = (String) v.get(0);
			
			
            float rate = Float.valueOf((String) v.get(1)).floatValue();
            int sampleSize = Integer.valueOf((String) v.get(2)).intValue();
            String signedString = (String) v.get(3);
            boolean bigEndian = ((String) v.get(4)).startsWith("big");
            int channels = ((String) v.get(5)).equals("mono") ? 1 : 2;

            if (encString.equals("linear")) {
                if (signedString.equals("signed")) {
                    encoding = AudioFormat.Encoding.PCM_SIGNED;
                } else {
                    encoding = AudioFormat.Encoding.PCM_UNSIGNED;
                }
            } else if (encString.equals("alaw")) {
                encoding = AudioFormat.Encoding.ALAW;
            }
            return new AudioFormat(encoding, rate, sampleSize, 
                          channels, (sampleSize/8)*channels, rate, bigEndian);
        }


        public synchronized void setFormat(AudioFormat format) {
           AudioFormat.Encoding type = format.getEncoding();
           if (type == AudioFormat.Encoding.ULAW) {
              m_encoding = 1;
           } else if (type == AudioFormat.Encoding.ALAW) {
              m_encoding = 2;
           } else if (type == AudioFormat.Encoding.PCM_SIGNED) {
              m_encoding = 0;
              m_sign = 0;
           } else if (type == AudioFormat.Encoding.PCM_UNSIGNED) {
              m_encoding = 0;
              m_sign = 1;
           }
           float rate = format.getFrameRate();
           if (rate == 8000) {
              m_samplerate = 0;
           } else if (rate == 11025) {
              m_samplerate = 1;
           } else if (rate == 16000) {
              m_samplerate = 2;
           } else if (rate == 22050) {
              m_samplerate = 3;
           } else if (rate == 44100) {
              m_samplerate = 4;
           }

           switch (format.getSampleSizeInBits()) {
              case 8  : m_samplesizeinbits = 0; break;
              case 16 : m_samplesizeinbits = 1; break;
            }
           if (format.isBigEndian()) {
              m_endian = 1;
           } else { 
              m_endian = 0;
           }
           if (format.getChannels() == 1) {
              m_channels = 0;
           } else { 
              m_channels = 1;
           }
        }
    } // End class FormatCtrls
