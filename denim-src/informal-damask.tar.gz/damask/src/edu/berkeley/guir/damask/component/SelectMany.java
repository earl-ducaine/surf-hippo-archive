package edu.berkeley.guir.damask.component;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.visual.component.CheckBox;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.collection.Map2D;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * A select many control, which represents a list of choices that can be
 * made by the end user, and more than one choice can be selected at a time.
 * This can be rendered as a set of check boxes or a multi-select list box. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  04-30-2003 James Lin
 *                               Created SelectMany
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 04-30-2003
 */
public class SelectMany extends Select {

   /**
    * Constructs a select-many control.
    * 
    * @param deviceType the device type that this control supports. Can be
    * DeviceType.ALL.
    */
   public SelectMany(final DeviceType deviceType) {
      super(deviceType);
      if (isVisibleToDeviceType(DeviceType.VOICE)) {
         setStyle(DeviceType.VOICE, FULL);
      }
   }

   /**
    * Constructs a select-one control, copying properties from the specified
    * select-one control.
    * 
    * @param selectOne the existing select-one control whose properties will
    * be copied
    * @param deviceType the device type that this control supports. Can be
    * DeviceType.ALL.
    */
   public SelectMany(final SelectMany selectMany, final DeviceType deviceType) {
      super(selectMany, deviceType);
      
      for (Iterator i = selectMany.getItems().iterator(); i.hasNext(); ) {
         final SelectMany.Item item = (SelectMany.Item)i.next();
         final SelectMany.Item newItem = new SelectMany.Item(item, deviceType); 
         addItem(newItem);
         replaceStates(item, newItem);
      }
   }

   // Overrides method in Control class.
   public Object getDefaultState() {
      return Collections.EMPTY_SET;
   }


   // Overrides method in parent class.
   public Component createCopy(DeviceType deviceType) {
      return new SelectMany(this, deviceType);
   }

   
   /**
    * Replaces any state that is equal to item with newItem.
    */ 
   private void replaceStates(
      final SelectMany.Item oldItem, final SelectMany.Item newItem) {

      for (Iterator i = getDialogsWithState().iterator(); i.hasNext(); ) {
         final Dialog dialog = (Dialog)i.next();
         for (int cond = 0, n = dialog.getNumConditions(); cond < n; cond++) {
            final Set/*<SelectMany.Item>*/ state = 
               (Set/*<SelectMany.Item>*/)
                  getStateForCondition(dialog, cond);
            final boolean wasRemoved = state.remove(oldItem);
            if (wasRemoved) {
               state.add(newItem);
            }
         }
      }
   }


   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      final SelectMany clone = (SelectMany)super.clone();
      
      for (Iterator i = clone.getItems().iterator(); i.hasNext(); ) {
         final SelectMany.Item newItem = (SelectMany.Item)i.next();
         final SelectMany.Item oldItem =
            (SelectMany.Item)newItem.getCloneSourceIfAlive(); 
         clone.replaceStates(oldItem, newItem);
      }
      
      return clone;
   }

   // @Override
   protected void autoPositionForVoice() {
   }
   
   // @Override
   protected void setupVoiceResponses() {
      for (Iterator i = getItems().iterator(); i.hasNext(); ) {
         final SelectMany.Item item = (SelectMany.Item)i.next();
         item.setupVoiceResponses();
      }
   }

   // @Override
   public void addItem(final int index, final Select.Item item) {
      super.addItem(index, item);
      
      if (item.isVisibleToDeviceType(DeviceType.VOICE)) {
         final PageRegion voiceRegion = getPageRegion(DeviceType.VOICE);
         if (voiceRegion != null) {
            final Control prevControl =
               DamaskUtils.getPreviousLowLevelControl(voiceRegion, item);
            
            if (prevControl != null) {
               prevControl.setupVoiceResponses();
            }
            item.setupVoiceResponses();
            
            final Control nextControl =
               DamaskUtils.getNextLowLevelControl(voiceRegion, item);
            if (nextControl instanceof Trigger) {
               ((Trigger)nextControl).updateVoiceResponseText();
            }
         }
      }
   }
   
   
   /**
    * Removes the item at the specified position in this control.
    * 
    * @return the item that was removed
    */
   public Select.Item removeItem(final int index) {
      final Item item = (Item)getItems().get(index);
      final Control prevVoiceControl;
      final Control nextVoiceControl;
      if (item.isVisibleToDeviceType(DeviceType.VOICE)) {
         final PageRegion voiceRegion = getPageRegion(DeviceType.VOICE);
         if (voiceRegion != null) {
            prevVoiceControl =
               DamaskUtils.getPreviousLowLevelControl(voiceRegion, item);
            nextVoiceControl =
               DamaskUtils.getNextLowLevelControl(voiceRegion, item);
         }
         else {
            prevVoiceControl = null;
            nextVoiceControl = null;
         }
      }
      else {
         prevVoiceControl = null;
         nextVoiceControl = null;
      }
         
      super.removeItem(index);
      
      if (prevVoiceControl != null) {
         prevVoiceControl.setupVoiceResponses();
      }
      if (nextVoiceControl instanceof Trigger) {
         ((Trigger)nextVoiceControl).updateVoiceResponseText();
      }
      
      return item;
   }
   
   //===========================================================================
   
   public static class Item extends Select.Item {
      private static final Map2D/*<DeviceType, Style, Inset>*/ defaultInsets =
         new Map2D/*<DeviceType, Style, Inset>*/();
      
      private final ControlVoiceListener contentVoiceHandler = new ContentHandler();

      // Initialize default insets
      static {
         final Insets2D visualFullInsets;
         {
            final PNode defaultView = CheckBox.createTempView();
            final Rectangle2D bounds = defaultView.getBounds();
            final PPath captionPath = (PPath)defaultView.getChild(1);

            final Rectangle2D captionPathBounds =
               captionPath.getPathReference().getBounds2D();
            final AffineTransform captionPathTransform = captionPath.getTransform();

            final Rectangle2D captionPathBoundsInItemCoords =
               GeomLib.transformRectangle(captionPathTransform, captionPathBounds);

            visualFullInsets =
               new Insets2D(
                  captionPathBoundsInItemCoords.getY() - bounds.getY(),
                  captionPathBoundsInItemCoords.getX() - bounds.getX(),
                  bounds.getMaxY() - captionPathBoundsInItemCoords.getMaxY(),
                  bounds.getMaxX() - captionPathBoundsInItemCoords.getMaxX());
         }
         
         final Insets2D emptyInsets = new Insets2D(0, 0, 0, 0);
         
         for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
              i.hasNext(); ) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            for (Iterator j = Select.getSupportedStyles().iterator();
                 j.hasNext(); ) {
               final Style aStyle = (Style)j.next();
               defaultInsets.put(aDeviceType, aStyle, emptyInsets);
            }
         }
         
         defaultInsets.put(DeviceType.DESKTOP, FULL, visualFullInsets);
         defaultInsets.put(DeviceType.SMARTPHONE, FULL, visualFullInsets);
      }
      
      private final List/*<String>*/ responseText = new ArrayList/*<String>*/();

      
      public Item(Content content) {
         super(content);
         init();
      }

      public Item(final Item item, final DeviceType deviceType) {
         super(item, deviceType);
         init();
      }

      private void init() {
         if (isVisibleToDeviceType(DeviceType.VOICE)) {
            updateVoicePromptText();
            responseText.add("Yes");
            responseText.add("No");
            setVoiceResponseTextList(responseText);
            
            getContent().addControlVoiceListener(contentVoiceHandler);
         }
      }

      // @Override
      public void dispose() {
         if (isVisibleToDeviceType(DeviceType.VOICE)) {
            getContent().removeControlVoiceListener(contentVoiceHandler);
         }
      }
      
      // @Override
      public Component createCopy(final DeviceType deviceType) {
         return new Item(this, deviceType);
      }
      
      // @Override
      public Insets2D getDefaultInsets(
         final DeviceType deviceType, final Style style) {
         
         return (Insets2D)defaultInsets.get(deviceType, style);
      }

      // @Override
      protected void autoPositionForVoice() {
         getContent().setTextSize(
            DeviceType.VOICE, DeviceType.VOICE.getDefaultFontSize());
         setVoicePromptBounds(
            DamaskAppUtils.getRenderedTextBounds(
               getContent().getVoicePromptText(),
               DeviceType.VOICE.getDefaultFontSize()));
         placeVoicePromptUnderPreviousPrompt();
      }
      
      // @Override
      protected void setupVoiceResponses() {
         setupVoiceResponsesForControlWithPromptAndResponse();
      }

      // @Override
      protected void updateVoiceDisplayProperties() {
         setVoicePromptBounds(
            DamaskAppUtils.getRenderedTextBounds(
               getContent().getVoicePromptText(), DeviceType.VOICE.getDefaultFontSize()));
      }
      
      
      protected void updateVoicePromptText() {
         setVoicePromptText(getContent().getVoicePromptText());
      }
      
      
      /**
       * Sets the text at the specified index in the balloon of the voice response
       * view of this control.
       */
      public void setVoiceResponseText(final int index, final String text) {
         super.setVoiceResponseText(index, text);
      }
      
      
      /**
       * Returns the text in the balloon of the voice response view of this
       * control.
       */
      public void setVoiceResponseTextList(final List/*<String>*/ textList) {
         super.setVoiceResponseTextList(textList);
      }

      //===========================================================================

      /**
       * Handles events from the content within this trigger. 
       */
      private class ContentHandler implements ControlVoiceListener {

         // @Override
         public void promptTextChanged(ControlVoiceEvent e) {
            if (e.getControl() == getContent()) {
               updateVoicePromptText();
               updateVoiceDisplayProperties();
            }
         }

         // @Override
         public void promptBoundsChanged(ControlVoiceEvent e) {
         }

         // @Override
         public void responseSourceChanged(ControlVoiceEvent e) {
         }

         // @Override
         public void responseDestChanged(ControlVoiceEvent e) {
         }

         // @Override
         public void responseLineChanged(ControlVoiceEvent e) {
         }

         // @Override
         public void responseTextChanged(ControlVoiceEvent e) {
         }
      }
   }
}
