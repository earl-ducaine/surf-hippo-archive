//// See bottom of code for software license.
package edu.berkeley.guir.lib.awt;

import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JFrame;

class Hack 
   extends JFrame {

   public Hack() {
   }

   public static void main(String[] argv) {
      JFrame app = new JFrame();
      app.setSize(300, 300);
//      NewListener lstnr = new NewListener();
//      app.addMouseListener((MouseListener) lstnr);
//      app.addMouseMotionListener((MouseMotionListener) lstnr);
      
      Toolkit    tk = Toolkit.getDefaultToolkit();
      EventQueue q  = tk.getSystemEventQueue();
      q.push(new HackedEventQueue());

      app.show();
   } // of main

   static class OldListener
      implements MouseListener, MouseMotionListener {

      public void mouseClicked(MouseEvent evt) {
         if (evt.isMetaDown()) {
            System.out.println("right mouse button clicked");
         }
         System.out.println("left mouse button clicked");
      }

      public void mouseEntered(MouseEvent evt) {
         System.out.println("mouseEntered");
      }

      public void mouseExited(MouseEvent evt) {
         System.out.println("mouseExited");
      }

      public void mousePressed(MouseEvent evt) {
         if (evt.isMetaDown()) {
            System.out.println("right mouse button pressed");
         }
         System.out.println("left mouse button pressed");
      }

      public void mouseReleased(MouseEvent evt) {
         if (evt.isMetaDown()) {
            System.out.println("right mouse button released");
         }
         System.out.println("left mouse button released");
      }

      public void mouseDragged(MouseEvent evt) {
         if (evt.isMetaDown()) {
            System.out.println("dragging with right mouse button");
         }
         System.out.println("dragging with left mouse button");
      }

      public void mouseMoved(MouseEvent evt) {
      }

   }





   static class NewListener
      implements MouseListener, MouseMotionListener {

      boolean flagRightDown = false;
      
      public void mouseClicked(MouseEvent evt) {
         if (evt.isMetaDown()) {
            System.out.println("right mouse button clicked");
            flagRightDown = false;
         }
	 else {
   	    if (flagRightDown == false) {
               System.out.println("left mouse button clicked");
	    }
	 }
      }

      public void mouseEntered(MouseEvent evt) {
         System.out.println("mouseEntered");
      }

      public void mouseExited(MouseEvent evt) {
         System.out.println("mouseExited");
      }

      public void mousePressed(MouseEvent evt) {
         if (evt.isMetaDown()) {
            System.out.println("right mouse button pressed");
	    flagRightDown = true;
         }
	 else {
	    if (flagRightDown == false) {
               System.out.println("left mouse button pressed");
	    }
	 }
      }

      public void mouseReleased(MouseEvent evt) {
         if (evt.isMetaDown()) {
            System.out.println("right mouse button released");
	    flagRightDown = false;
         }
	 else {
            if (flagRightDown == false) {
               System.out.println("left mouse button released");
   	    }
	 }
      }

      public void mouseDragged(MouseEvent evt) {
         if (evt.isMetaDown()) {
            System.out.println("dragging with right mouse button");
         }
         else {
            if (flagRightDown == false) {
               System.out.println("dragging with left mouse button");
      	    }
	 }
      }

      public void mouseMoved(MouseEvent evt) {
      }

   }
}

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
