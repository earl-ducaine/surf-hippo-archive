package edu.berkeley.guir.denim.annotation;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import java.util.*;

/**
 * Keeps track of the annotations attached to a sheet and who created them.
 *
 * <PRE>
 * Revisions:  1.0.0  12-02-1999 JL
 *                    Created class SheetAnnotations.
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version Version 1.0.0, 12-02-1999
 */
public class SheetAnnotations implements DenimConstants {

   // maps reviewer to a map of anchor to annotation
   private Map annotationsByReviewer;
   private int currentVersion;
   private Set audioAnnotations;  // completely redundant

   static private DenimUID WORKING_UID =
      new DenimUID(new java.rmi.server.UID((short)1));

   /**
    * Constructs an instance of SheetAnnotations.
    */
   public SheetAnnotations() {
      currentVersion = 1;
      annotationsByReviewer = new HashMap();
      annotationsByReviewer.put(DenimUserProperties.get(PROP_USER), new HashMap());
      audioAnnotations = new HashSet();
   }

   /**
    * Returns the current version of the annotations. The version changes
    * each time the sheet is saved.
    */
   public int getVersion() {
      return currentVersion;
   }

   /**
    * Sets the version of the annotations to the given number.
    */
   public void setVersion(int newVersion) {
      currentVersion = newVersion;
   }

   /**
    * Increments the version of the annotations.
    */
   public void incrVersion() {
      currentVersion++;
   }

   /**
    * Returns all of the annotations, indexed by reviewer, then anchor.
    */
   public Map getAnnotations() {
      return annotationsByReviewer;
   }

   /**
    * Returns a map of annotations. The map maps a graphical object to its
    * attached annotations.
    */
   public Map getAnnotationsByReviewer(String reviewer) {
      return (Map)annotationsByReviewer.get(reviewer);
   }


   /**
    * Returns a map of annotations. The map maps a graphical object to its
    * attached annotations.
    */
   public Map getCurrentUsersAnnotations() {
      return getAnnotationsByReviewer(DenimUserProperties.get(PROP_USER));
   }

   /**
    * Returns a list of annotations attached to the given graphical object.
    */
   public List getAnnotationsWithAnchor(String reviewer, GraphicalObject gob) {
      Map currentAnnos = getAnnotationsByReviewer(reviewer);
      if (currentAnnos == null) {
         currentAnnos = new HashMap();
         annotationsByReviewer.put(reviewer, currentAnnos);
      }

      List annosForGob = (List)currentAnnos.get(gob);
      if (annosForGob == null) {
         annosForGob = new ArrayList();
         currentAnnos.put(gob, annosForGob);
      }
      return annosForGob;
   }

   /**
    * Returns a list of annotations attached to the given object that the
    * current user created.
    */
   public List getCurrentUsersAnnotationsWithAnchor(GraphicalObject gob) {
      return getAnnotationsWithAnchor(DenimUserProperties.get(PROP_USER), gob);
   }

   /**
    * Attaches the given annotation stroke written by the given reviewer
    * to the given graphical object.
    */
   public void addInkAnnotationStroke(String reviewer, GraphicalObject gob,
                                      TimedStroke stk) {
      List annosList = getAnnotationsWithAnchor(reviewer, gob);
      boolean mustAdd = false;
      Object firstElement = null;

      if (annosList.size() == 0) {
         mustAdd = true;
      }
      else {
         firstElement = annosList.get(0);
         if (!(firstElement instanceof InkAnnotation)) {
            mustAdd = true;
         }
      }

      if (mustAdd) {
         firstElement = new InkAnnotation(gob);
         annosList.add(0, firstElement);
      }

      ((InkAnnotation)firstElement).add(stk);
   }

   /**
    * Attaches the given annotation stroke written by the <i>current user</i>
    * to the given graphical object.
    */
   public void addInkAnnotationStroke(GraphicalObject gob, TimedStroke stk) {
      addInkAnnotationStroke(DenimUserProperties.get(PROP_USER), gob, stk);
   }

   /**
    * Adds a whole bunch of ink annotations to the current sheet.
    */
   public void addInkAnnotation(String reviewer, InkAnnotation penAnno) {
      getAnnotationsWithAnchor(reviewer, penAnno.getAnchor()).add(0, penAnno);
   }

   /**
    * Attaches the given audio annotation created by the given reviewer.
    */
   public void addAudioAnnotation(String reviewer, AudioAnnotation audioAnno) {
      getAnnotationsWithAnchor(reviewer, audioAnno.getAnchor()).add(audioAnno);
      audioAnnotations.add(audioAnno);
   }

   /**
    * Attaches the given audio annotation created by the <i>current user</i>.
    */
   public void addAudioAnnotation(AudioAnnotation audioAnno) {
      addAudioAnnotation(DenimUserProperties.get(PROP_USER), audioAnno);
   }

   /**
    * Returns all of the audio annotations.
    */
   public Set getAllAudioAnnotations() {
      return audioAnnotations;
   }

   /**
    * Returns a string representation of all of the annotations.
    */
   public String toString() {
      Iterator i = annotationsByReviewer.keySet().iterator();
      String s = "";

      while (i.hasNext()) {
         String reviewer = (String)i.next();
         s += reviewer + ":\n";
         if (reviewer.equals(DenimUserProperties.get(PROP_USER))) {
            s += "  Version = " + currentVersion;
         }
         Iterator j =
            ((Map)annotationsByReviewer.get(reviewer)).keySet().iterator();
         while (j.hasNext()) {
            GraphicalObject anchor = (GraphicalObject)j.next();
            s += "  " + anchor.getClass() + ":" + anchor.getUniqueID() + "\n";
            Iterator k =
               ((List)((Map)annotationsByReviewer.get(reviewer)).get(anchor)).iterator();
            s += "    [";
            while (k.hasNext()) {
               Object anno = k.next();
               s += anno.getClass();
               if (k.hasNext()) {
                  s += ", ";
               }
               else {
                  s += "]\n";
               }
            }
         }
      }

      return s;
   }

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
