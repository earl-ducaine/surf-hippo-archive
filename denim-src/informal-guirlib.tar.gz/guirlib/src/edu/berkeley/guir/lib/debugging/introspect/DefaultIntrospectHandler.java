//// See bottom of source code for software license.
package edu.berkeley.guir.lib.debugging.introspect;

import java.lang.reflect.Field;

/**
 * Default handler for introspection debugging. See 
 * {@link Introspect#parseObject(Object, IntrospectHandler)}.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
public abstract class DefaultIntrospectHandler 
   extends IntrospectHandler {

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public DefaultIntrospectHandler() {
      super();
   } // of constructor

   //-----------------------------------------------------------------

   public DefaultIntrospectHandler(IntrospectFilter f) {
      super(f);
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   INTROSPECTION TOSTRING METHODS   ====================================

   /**
    * Convert value to String.
    */
   protected String toString(boolean val) {
      return ("" + val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert value to String.
    */
   protected String toString(char val) {
      return ("" + val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert value to String.
    */
   protected String toString(short val) {
      return ("" + val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert value to String.
    */
   protected String toString(byte val) {
      return ("" + val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert value to String.
    */
   protected String toString(int val) {
      return ("" + val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert value to String.
    */
   protected String toString(long val) {
      return ("" + val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert value to String.
    */
   protected String toString(float val) {
      return ("" + val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert value to String.
    */
   protected String toString(double val) {
      return ("" + val);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Convert value to String.
    */
   protected String toString(Object val) {
      return ("" + val);
   } // of method

   //-----------------------------------------------------------------

   protected String toString(boolean[] arr) {
      StringBuffer strbuf = new StringBuffer(7*arr.length + 2);
      strbuf.append("{");
      for (int i = 0; i < arr.length; i++) {
         strbuf.append(toString(arr[i]) + ", ");
      }
      strbuf.append("}");
      return (strbuf.toString());
   } // of method

   //-----------------------------------------------------------------

   protected String toString(char[] arr) {
      StringBuffer strbuf = new StringBuffer(3*arr.length + 2);
      strbuf.append("{");
      for (int i = 0; i < arr.length; i++) {
         strbuf.append(toString(arr[i]) + ", ");
      }
      strbuf.append("}");
      return (strbuf.toString());
   } // of method

   //-----------------------------------------------------------------

   protected String toString(short[] arr) {
      StringBuffer strbuf = new StringBuffer(4*arr.length + 2);
      strbuf.append("{");
      for (int i = 0; i < arr.length; i++) {
         strbuf.append(toString(arr[i]) + ", ");
      }
      strbuf.append("}");
      return (strbuf.toString());
   } // of method

   //-----------------------------------------------------------------

   protected String toString(byte[] arr) {
      StringBuffer strbuf = new StringBuffer(5*arr.length + 2);
      strbuf.append("{");
      for (int i = 0; i < arr.length; i++) {
         strbuf.append(toString(arr[i]) + ", ");
      }
      strbuf.append("}");
      return (strbuf.toString());
   } // of method

   //-----------------------------------------------------------------

   protected String toString(int[] arr) {
      StringBuffer strbuf = new StringBuffer(7*arr.length + 2);
      strbuf.append("{");
      for (int i = 0; i < arr.length; i++) {
         strbuf.append(toString(arr[i]) + ", ");
      }
      strbuf.append("}");
      return (strbuf.toString());
   } // of method

   //-----------------------------------------------------------------

   protected String toString(long[] arr) {
      StringBuffer strbuf = new StringBuffer(9*arr.length + 2);
      strbuf.append("{");
      for (int i = 0; i < arr.length; i++) {
         strbuf.append(toString(arr[i]) + ", ");
      }
      strbuf.append("}");
      return (strbuf.toString());
   } // of method

   //-----------------------------------------------------------------

   protected String toString(float[] arr) {
      StringBuffer strbuf = new StringBuffer(9*arr.length + 2);
      strbuf.append("{");
      for (int i = 0; i < arr.length; i++) {
         strbuf.append(toString(arr[i]) + ", ");
      }
      strbuf.append("}");
      return (strbuf.toString());
   } // of method

   //-----------------------------------------------------------------

   protected String toString(double[] arr) {
      StringBuffer strbuf = new StringBuffer(11*arr.length + 2);
      strbuf.append("{");
      for (int i = 0; i < arr.length; i++) {
         strbuf.append(toString(arr[i]) + ", ");
      }
      strbuf.append("}");
      return (strbuf.toString());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Handles multi-dimensional arrays too.
    */
   protected String toString(Object[] arr) {
      StringBuffer strbuf = new StringBuffer(15*arr.length + 2);
      strbuf.append("{");
      for (int i = 0; i < arr.length; i++) {

         if (arr[i] != null && arr[i].getClass().isArray() == true) {
            Class cl = arr[i].getClass();
            if (cl == CL_BOOLEAN_ARR) {
               strbuf.append(toString((boolean[]) arr[i]));
            }
            else if (cl == CL_CHAR_ARR) {
               strbuf.append(toString((char[]) arr[i]));
            }
            else if (cl == CL_BYTE_ARR) {
               strbuf.append(toString((byte[]) arr[i]));
            }
            else if (cl == CL_SHORT_ARR) {
               strbuf.append(toString((short[]) arr[i]));
            }
            else if (cl == CL_INT_ARR) {
               strbuf.append(toString((int[]) arr[i]));
            }
            else if (cl == CL_LONG_ARR) {
               strbuf.append(toString((long[]) arr[i]));
            }
            else if (cl == CL_FLOAT_ARR) {
               strbuf.append(toString((float[]) arr[i]));
            }
            else if (cl == CL_DOUBLE_ARR) {
               strbuf.append(toString((double[]) arr[i]));
            }
            else {
               strbuf.append(toString((Object[]) arr[i]));
            }
         }
         else {
            strbuf.append(toString(arr[i]));
         }
         strbuf.append(", ");
      }
      strbuf.append("}");
      return (strbuf.toString());
   } // of method

   //===   INTROSPECTION TOSTRING METHODS   ====================================
   //===========================================================================




   //===========================================================================
   //===   INTROSPECTION ARRAY METHODS   =======================================

   protected void onBooleanArr(int depth, Field f, boolean[] arr) {
      output(depth, f, toString(arr));
   } // of method

   //-----------------------------------------------------------------

   protected void onCharArr(int depth, Field f, char[] arr) {
      output(depth, f, toString(arr));
   } // of method

   //-----------------------------------------------------------------

   protected void onShortArr(int depth, Field f, short[] arr) {
      output(depth, f, toString(arr));
   } // of method

   //-----------------------------------------------------------------

   protected void onByteArr(int depth, Field f, byte[] arr) {
      output(depth, f, toString(arr));
   } // of method

   //-----------------------------------------------------------------

   protected void onIntArr(int depth, Field f, int[] arr) {
      output(depth, f, toString(arr));
   } // of method

   //-----------------------------------------------------------------

   protected void onLongArr(int depth, Field f, long[] arr) {
      output(depth, f, toString(arr));
   } // of method

   //-----------------------------------------------------------------

   protected void onFloatArr(int depth, Field f, float[] arr) {
      output(depth, f, toString(arr));
   } // of method

   //-----------------------------------------------------------------

   protected void onDoubleArr(int depth, Field f, double[] arr) {
      output(depth, f, toString(arr));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Multidimensional arrays are sent here too.
    */
   protected void onObjectArr(int depth, Field f, Object[] arr) {
      output(depth, f, toString(arr));
   } // of method

   //===   INTROSPECTION ARRAY METHODS   =======================================
   //===========================================================================



   //===========================================================================
   //===   INTROSPECTION CALLBACK METHODS   ====================================

   /**
    * All of the output is redirected here.
    */
   protected abstract void output(int depth, Field f, String strVal);

   //-----------------------------------------------------------------

   public void onRoot(Object obj) {
      output(0, null, obj.toString());
   } // of method

   public void onObject(int depth, Field f, Object obj) {
      output(depth, f, obj.toString());
   } // of method

   public void onArray(int depth, Field f, Object arr) {
      Class cl = arr.getClass();

      if (cl == CL_BOOLEAN_ARR) {
         onBooleanArr(depth, f, (boolean[]) arr);
      }
      else if (cl == CL_CHAR_ARR) {
         onCharArr(depth, f, (char[]) arr);
      }
      else if (cl == CL_BYTE_ARR) {
         onByteArr(depth, f, (byte[]) arr);
      }
      else if (cl == CL_SHORT_ARR) {
         onShortArr(depth, f, (short[]) arr);
      }
      else if (cl == CL_INT_ARR) {
         onIntArr(depth, f, (int[]) arr);
      }
      else if (cl == CL_LONG_ARR) {
         onLongArr(depth, f, (long[]) arr);
      }
      else if (cl == CL_FLOAT_ARR) {
         onFloatArr(depth, f, (float[]) arr);
      }
      else if (cl == CL_DOUBLE_ARR) {
         onDoubleArr(depth, f, (double[]) arr);
      }
      else {
         onObjectArr(depth, f, (Object[]) arr);
      }

   } // of method

   public void onNull(int depth, Field f) {
      output(depth, f, "null");
   } // of method

   //-----------------------------------------------------------------

   public void onBoolean(int depth, Field f, boolean val) {
      output(depth, f, "" + val);
   } // of method

   public void onChar(int depth, Field f, char val) {
      output(depth, f, "" + val);
   } // of method

   public void onInt(int depth, Field f, int val) {
      output(depth, f, "" + val);
   } // of method

   public void onLong(int depth, Field f, long val) {
      output(depth, f, "" + val);
   } // of method

   public void onFloat(int depth, Field f, float val) {
      output(depth, f, "" + val);
   } // of method

   public void onDouble(int depth, Field f, double val) {
      output(depth, f, "" + val);
   } // of method

   public void onShort(int depth, Field f, short val) {
      output(depth, f, "" + val);
   } // of method

   public void onByte(int depth, Field f, byte val) {
      output(depth, f, "" + val);
   } // of method

   //===   INTROSPECTION CALLBACK METHODS   ====================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
