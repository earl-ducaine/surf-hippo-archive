package edu.berkeley.guir.lib.satin.widgets;

// Filename:  SatinExceptionDialog.java
// Author:    marcr
// Original Author:  Barry Mosher (from a magazine)
//
// Purpose:  warn the user when an Error or RuntimeException is thrown,
// rather than merely allowing it to be reported to the console where
// the user can't usually see it.  Displays a message advising the user to 
// restart the program, and (if details are expanded) a stack trace.
// 

import java.awt.*;
import java.awt.event.*;
import java.awt.print.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;
import javax.swing.*;
import javax.swing.border.*;

/**
 * Displays an exception/throwable in a dialog.
 *
 * @author Barry Mosher (orig), marcr (SATIN version)
 * @see ChainedException
 */
public class SatinExceptionDialog extends JDialog {
   
   public static final String
      DEFAULT_TITLE = "Exception Caught!";
   public static final String
      MESSAGE_LABEL = "Message:";
   public static final String
      NULL_EXCEPTION_MSG =
         "No exception given (null)";
   public static final String
      CLOSE_BUTTON_CAPTION = "Close";
   public static final String
      SHOW_DETAILS_BUTTON_CAPTION = "Show Details";
   public static final String
      HIDE_DETAILS_BUTTON_CAPTION = "Hide Details";
   public static final String
      DETAILS_BORDER_TITLE = "Details:";
   public static final String
      SAVE_BUTTON_CAPTION = "Save To File";
   public static final String
      PRINT_BUTTON_CAPTION = "Print";
   public static final String
      SAVE_TO_FILE_DIALOG_TITLE =
         "Save Stack Trace(s) To File";

   public static final int
      PREFERRED_WIDTH = 500;
   public static final int
      PREFERRED_NO_DETAILS_HEIGHT = 200;
   public static final int
      PREFERRED_DETAILS_HEIGHT = 500;

   protected JButton _showDetailsBtn;
   protected JPanel _bottomPanel;
   protected boolean _isShowingDetails = false;
   protected JTextArea _detailsTextArea;
   protected JScrollPane _detailsScrollPane;


   /**
    * Constructs a non-modal dialog without a
    * specified <code>Frame</code> owner.
    *
    * @param pEx the exception/throwable to be
    *    displayed.
    */
   public SatinExceptionDialog(Throwable pEx) {
      super();
      setTitle(DEFAULT_TITLE);
      initGui(pEx);
   }


   /**
    * Constructs a non-modal dialog with the
    * specified <code>Dialog</code> as its owner.
    *
    * @param pOwner the owner of this dialog.
    * @param pEx the exception/throwable to be
    *    displayed.
    */
   public SatinExceptionDialog(Dialog pOwner,
                          Throwable pEx) {
      super(pOwner,DEFAULT_TITLE);
      initGui(pEx);
   }


   /**
    * Constructs a dialog, with the specified
    * <code>Dialog</code> as its owner.
    *
    * @param pOwner the owner of this dialog.
    * @param pEx the exception/throwable to be
    *    displayed.
    * @param pModal true for a modal dialog, false
    *    for one that allows others windows to be
    *    active at the same time.
    */
   public SatinExceptionDialog(Dialog pOwner,
                          Throwable pEx,
                          boolean pModal) {
      super(pOwner,DEFAULT_TITLE,pModal);
      initGui(pEx);
   }


   /**
    * Constructs a non-modal dialog, with the
    * specified <code>Dialog</code> as its owner.
    *
    * @param pOwner the owner of this dialog.
    * @param pEx the exception/throwable to be
    *    displayed.
    * @param pTitle the title for this dialog.
    */
   public SatinExceptionDialog(Dialog pOwner,
                          Throwable pEx,
                          String pTitle) {
      super(pOwner,pTitle);
      initGui(pEx);
   }


   /**
    * Constructs a non-modal dialog without a title,
    * with the specified <code>Dialog</code> as its
    * owner.
    *
    * @param pOwner the owner of this dialog.
    * @param pEx the exception/throwable to be
    *    displayed.
    * @param pTitle the title for this dialog.
    * @param pModal true for a modal dialog, false
    *    for one that allows others windows to be
    *    active at the same time.
    */
   public SatinExceptionDialog(Dialog pOwner,
                          Throwable pEx,
                          String pTitle,
                          boolean pModal) {
      super(pOwner,pTitle,pModal);
      initGui(pEx);
   }


   /**
    * Constructs a non-modal dialog with the
    * specified <code>Frame</code> as its owner.
    *
    * @param pOwner the owner of this dialog.
    * @param pEx the exception/throwable to be
    *    displayed.
    */
   public SatinExceptionDialog(Frame pOwner,
                          Throwable pEx) {
      super(pOwner,DEFAULT_TITLE);
      initGui(pEx);
   }


   /**
    * Constructs a dialog, with the specified
    * <code>Frame</code> as its owner.
    *
    * @param pOwner the owner of this dialog.
    * @param pEx the exception/throwable to be
    *    displayed.
    * @param pModal true for a modal dialog, false
    *    for one that allows others windows to be
    *    active at the same time.
    */
   public SatinExceptionDialog(Frame pOwner, Throwable pEx,
                          boolean pModal) {
      super(pOwner,DEFAULT_TITLE,pModal);
      initGui(pEx);
   }


   /**
    * Constructs a non-modal dialog, with the
    * specified <code>Frame</code> as its owner.
    *
    * @param pOwner the owner of this dialog.
    * @param pEx the exception/throwable to be
    *    displayed.
    * @param pTitle the title for this dialog.
    */
   public SatinExceptionDialog(Frame pOwner, Throwable pEx,
                          String pTitle) {
      super(pOwner,pTitle);
      initGui(pEx);
   }


   /**
    * Constructs a non-modal dialog without a title,
    * with the specified <code>Frame</code> as its
    * owner.
    *
    * @param pOwner the owner of this dialog.
    * @param pEx the exception/throwable to be
    *    displayed.
    * @param pTitle the title for this dialog.
    * @param pModal true for a modal dialog, false for
    *    one that allows others windows to be active
    *    at the same time.
    */
   public SatinExceptionDialog(Frame pOwner, Throwable pEx,
                          String pTitle,
                          boolean pModal) {
      super(pOwner,pTitle,pModal);
      initGui(pEx);
   }


   /**
    * Creates GUI components and registers for their
    *    events.
    *
    * @param pEx the exception to be displayed.
    */
   protected void initGui(Throwable pEx)
   {
      setSize(new Dimension(
         PREFERRED_WIDTH,
         PREFERRED_NO_DETAILS_HEIGHT));
      Container contentPane = getContentPane();
      contentPane.setLayout(new BorderLayout());

      // Top Panel (contains the msg panel and top
      // button panel)
      JPanel topPanel =
         new JPanel(new BorderLayout());

      // Msg Panel
      JPanel msgPanel =
         new JPanel(new BorderLayout(10,5));
      msgPanel.add(new JLabel(MESSAGE_LABEL),
                   BorderLayout.WEST);
      String exMsg;
      exMsg = "WARNING!  Caught a run-time error that may cause more problems.  \n"
        + "It is advisable to exit and restart the program before continuing.  \n"
        + "If you have unsaved work, you should probably try to save it first.\n"
        + "If this problem re-occurs and you have trouble working around it, \n" 
        + "please consider passing the error details along to the developers.";
      
/*      if (pEx == null) {
         exMsg = NULL_EXCEPTION_MSG;
      } else {
         exMsg = pEx.getLocalizedMessage();
      }
*/
//      JTextArea _msgTextArea = new JTextArea(7/*rows*/,100/*cols*/);
//      _msgTextArea.setText(exMsg);
      JTextArea _msgTextArea = new JTextArea(exMsg);

      JScrollPane _msgScrollPane = new JScrollPane();
      _msgScrollPane.getViewport().add(
         _msgTextArea);
      msgPanel.add(_msgScrollPane,
         BorderLayout.CENTER);

      // Top Button Panel
      JPanel topBtnPanel = new JPanel(
         new FlowLayout(FlowLayout.RIGHT));
      JButton closeBtn = new JButton(
         CLOSE_BUTTON_CAPTION);
      _showDetailsBtn = new JButton(
         SHOW_DETAILS_BUTTON_CAPTION);
      topBtnPanel.add(closeBtn);
      topBtnPanel.add(_showDetailsBtn);

      topPanel.add(msgPanel,BorderLayout.NORTH);
      topPanel.add(topBtnPanel,BorderLayout.CENTER);
      contentPane.add(topPanel,BorderLayout.NORTH);

      // Bottom Panel (contains the details window,
      // and bottom button panel)
      _bottomPanel = new JPanel(new BorderLayout());

      // Detail Panel
      JPanel detailPanel =
         new JPanel(new BorderLayout());
      detailPanel.setBorder(new TitledBorder(
         DETAILS_BORDER_TITLE));
      _detailsTextArea = new JTextArea();
      _detailsTextArea.setTabSize(2);
      _detailsScrollPane = new JScrollPane();
      _detailsScrollPane.getViewport().add(
         _detailsTextArea);
      detailPanel.add(_detailsScrollPane,
                      BorderLayout.CENTER);

      // Bottom Button Panel
      JPanel bottomBtnPanel = new JPanel(
         new FlowLayout(FlowLayout.RIGHT));
      JButton saveToFileBtn = new JButton(
         SAVE_BUTTON_CAPTION);
      JButton printBtn = new JButton(
         PRINT_BUTTON_CAPTION);
      bottomBtnPanel.add(saveToFileBtn);
      bottomBtnPanel.add(printBtn);

      _bottomPanel.add(detailPanel,
                       BorderLayout.CENTER);
      _bottomPanel.add(bottomBtnPanel,
                       BorderLayout.SOUTH);

      // Populate the Details Panel with stack traces.
      StringWriter stringWriter = new StringWriter();
      PrintWriter printWriter =
         new PrintWriter(stringWriter);
      pEx.printStackTrace(printWriter);
      try {
         printWriter.close();
         stringWriter.close();
      } catch (IOException ex) {
         // Not important - ignore.
      }
      _detailsTextArea.setText(
         stringWriter.toString());

      // Register Listeners
      closeBtn.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            dispose();
         }
      });
      _showDetailsBtn.addActionListener(
         new ActionListener() {
            public void actionPerformed(
               ActionEvent e) {
               showDetails(!_isShowingDetails);
            }
         }
      );
      saveToFileBtn.addActionListener(
         new ActionListener() {
            public void actionPerformed(
               ActionEvent e) {
                  saveDetailsToFile();
            }
         }
      );
      printBtn.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            // do the printing in a background thread.
            new PrintThread(
               _detailsTextArea.getText()).start();
         }
      });

      centerDialog();
   }


   /**
    * Shows/hides the details (bottom) part of the
    * dialog.
    *
    * @param pShowDetails indicates whether the
    * details part of the dialog should be shown,
    * or hidden.
    */
   public void showDetails(boolean pShowDetails)
   {
      if (pShowDetails == _isShowingDetails) {
         return;
      }
      Dimension oldSize = getSize();
      int newHeight;

      Dimension screenSize =
         Toolkit.getDefaultToolkit().getScreenSize();

      Container contentPane = getContentPane();
      if (pShowDetails) {
         contentPane.add(_bottomPanel,
                         BorderLayout.CENTER);
         _showDetailsBtn.setText(
            HIDE_DETAILS_BUTTON_CAPTION);

         _detailsScrollPane.getViewport().
            setViewPosition(new Point(0,0));

         if (PREFERRED_DETAILS_HEIGHT >
             screenSize.height) {
            newHeight = screenSize.height;
         } else {
            newHeight = PREFERRED_DETAILS_HEIGHT;
         }
      } else {
         contentPane.remove(_bottomPanel);
         _showDetailsBtn.setText(
            SHOW_DETAILS_BUTTON_CAPTION);

         newHeight = PREFERRED_NO_DETAILS_HEIGHT;
      }
      _isShowingDetails = pShowDetails;

      setSize(new Dimension(oldSize.width,newHeight));
      Point location = getLocationOnScreen();
      if (location.getY() + newHeight >
          screenSize.height) {
         centerDialog();
      }

      this.validate();
   }


   /**
    * Centers this dialog on the screen.
    */
   public void centerDialog()
   {
      Dimension screenSize =
         Toolkit.getDefaultToolkit().getScreenSize();
      Dimension dialogSize = getSize();
      int remainderWidth =
         screenSize.width - dialogSize.width;
      int remainderHeight =
         screenSize.height - dialogSize.height;
      setLocation(new Point(remainderWidth/2,
                            remainderHeight/2));
   }


   /**
    * Opens a file dialog to allow the user to save the
    * contents of the details panel to a file.
    */
   public void saveDetailsToFile()
   {
      Frame frame = getParentFrame(this.getOwner());
      FileDialog fileDialog = new FileDialog(frame,
         SAVE_TO_FILE_DIALOG_TITLE,FileDialog.SAVE);

      fileDialog.show();

      String filename = fileDialog.getFile();
      if (filename != null) {

         String directory = fileDialog.getDirectory();
         try {
            FileWriter fileWriter =
               new FileWriter(directory+filename);
            fileWriter.write(
               _detailsTextArea.getText());
            fileWriter.close();
         } catch (IOException ex) {
            showInternalException(ex);
         }
      }
   }


   /**
    * Returns the owner <code>Frame</code> of the
    * given component, or null if there is no owner
    * <code>Frame</code>.
    *
    * @param pSibling component for which we want
    * the parent <code>Frame</code>.
    *
    * @return the owner <code>Frame</code> of the
    * given component, or null if there is no owner
    * <code>Frame</code>.
    */
   private Frame getParentFrame(Window pSibling)
   {
      Window current = pSibling;
      while ((current != null) &&
             !(current instanceof Frame)) {
         current = current.getOwner();
      }
      return (Frame)current;
   }



   /**
    * Prints a multi-line string in a background
    * thread.
    */
   private class PrintThread extends Thread
   {

      private String _exceptionDetails;


      /**
       * Constructs a instance for printing the given
       * string.
       *
       * @param pExceptionDetails the string to be
       *    printed.
       */
      public PrintThread(String pExceptionDetails)
      {
         _exceptionDetails = pExceptionDetails;
      }


      /**
       * Prints the <code>_details</code> string given
       * in the constructor. The string will be broken
       * into multiple lines at line feeds, and
       * may span multiple pages.
       */
      public void run()
      {
         PrinterJob printerJob =
            PrinterJob.getPrinterJob();
         Book book = new Book();
         PagePrinter pagePrinter =
            new PagePrinter(_exceptionDetails);
         PageFormat pageFormat =
            printerJob.pageDialog(
            printerJob.defaultPage());

         int numPages =
            pagePrinter.calculatePageCount(
            pageFormat);
         book.append(pagePrinter,pageFormat,
            numPages);
         printerJob.setPageable(book);

         if (printerJob.printDialog()) {
            try {
               printerJob.print();
            } catch (final PrinterException ex) {
               // Pop-up the exception dialog in the
               // GUI event thread (we're in a
               // background thread).
               SwingUtilities.invokeLater(
                  new Runnable() {
                     public void run() {
                        showInternalException(ex);
                     }
                  }
               );
            }
         }

      }

   } // end of PrintThread class.



   private class PagePrinter implements Printable
   {
      private String _exceptionDetails;
      private ArrayList _pages;
      PageFormat _currentPageFormat;
      Font _font = new Font("TimesRoman",
                            Font.PLAIN,12);

      /**
       * Constructs an instance for printing the
       * exception details on a page-by-page basis.
       *
       * @param pExceptionDetails the exception
       *    details to be printed.
       */
      public PagePrinter(String pExceptionDetails)
      {
         _exceptionDetails = pExceptionDetails;
      }


      /**
       * Returns the number of pages required to print
       * the exception details.
       *
       * @param pPageFormat page format to be used for
       *    printing.
       */
      public int calculatePageCount(
         PageFormat pPageFormat)
      {
         ArrayList pages = repaginate(pPageFormat);
         return pages.size();
      }


      /**
       * Indicates whether or not a page exists for
       * printing.
       * <p>
       * Assumes that only one <code>PageFormat</code>
       * will be used, invoking the repagination only
       * the first time.
       *
       * @param pGraphics printer graphics context.
       * @param pPageFormat page format for this page
       * (assumed to be the same for all pages).
       * @param pPageIndex page number.
       *
       * @return Printable.PAGE_EXISTS if page number
       *    exists, otherwise
       * Printable.NO_SUCH_PAGE.
       */
      public int print(Graphics pGraphics,
                       PageFormat pPageFormat,
                       int pPageIndex)
         throws PrinterException
      {
         if (_currentPageFormat != pPageFormat) {
            _currentPageFormat = pPageFormat;
            _pages = repaginate(pPageFormat);
         }
         if (pPageIndex >= _pages.size()) {
            return Printable.NO_SUCH_PAGE;
         }
         pGraphics.setFont(_font);
         pGraphics.setColor(Color.black);
         renderPage(pGraphics,pPageFormat,pPageIndex);

         return Printable.PAGE_EXISTS;
      }


      /**
       * Calculates the pagination based.  Creates an
       * <code>ArrayList</code> of <code>String
       * </code>s (one for each line) for each page.
       *
       * @param pPageFormat page format to be used for
       * all pages.
       *
       * @return list of pages (each page is an <code>
       *    ArrayList</code> of <code>String</code>s).
       */
      private ArrayList repaginate(
         PageFormat pPageFormat)
      {
         int maxPageHeight =
            (int)pPageFormat.getImageableHeight();
         int lineHeight = _font.getSize();
         ArrayList pageList = new ArrayList();

         ArrayList currentPage = new ArrayList();
         int currentPageHeight = 0;

           StringTokenizer tokenizer =
               new StringTokenizer(
               _exceptionDetails,"\n");
           while (tokenizer.hasMoreTokens()) {
            String line = tokenizer.nextToken();
            if (currentPageHeight + lineHeight >
                maxPageHeight) {
               // need new page
               pageList.add(currentPage);
               currentPage = new ArrayList();
               currentPageHeight = 0;
            }
            currentPage.add(line);
            currentPageHeight += lineHeight;
         }
         pageList.add(currentPage);

         return pageList;
      }


      /**
       * Renders the specified page number to the
       * given graphics context.
       *
       * @param pGraphics printer graphics context.
       * @param pPageFormat page format.
       * @param pPageIndex page number.
       */
      private void renderPage(Graphics pGraphics,
                              PageFormat pPageFormat,
                              int pPageIndex)
      {
         int xOrigin =
            (int)pPageFormat.getImageableX();
         int yOrigin =
            (int)pPageFormat.getImageableY();
         int yOffset = _font.getSize();

         ArrayList pageLines = (ArrayList)
            _pages.get(pPageIndex);
         Iterator it = pageLines.iterator();
         while (it.hasNext()) {
            String line = (String)it.next();
            pGraphics.drawString(line,xOrigin,
               yOffset + yOrigin);
            yOffset += _font.getSize();
         }
      }

   } // end of PagePrinter class.


   /**
    * Opens another instance of <code>SatinExceptionDialog
    * </code> for an exception thrown within this
    * class (e.g. during save-to-file, or printing).
    * <p>
    * To avoid infinite loops, only invoke this method
    * for user driven events, and only if the user
    * will not be forced into repeating the
    * action.
    */
   private void showInternalException(Throwable pEx)
   {
      SatinExceptionDialog exceptionDialog;
      if (this.getOwner() instanceof Dialog) {
         exceptionDialog = new SatinExceptionDialog(
            (Dialog)this.getOwner(),pEx,true);
      } else if (this.getOwner() instanceof Frame) {
         exceptionDialog = new SatinExceptionDialog(
            (Frame)this.getOwner(),pEx,true);
      } else {
         exceptionDialog = new SatinExceptionDialog(
            (Frame)null,pEx,true);
      }
      exceptionDialog.show();
   }

}