package edu.berkeley.guir.damask.command;

import java.util.*;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.*;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.lib.satin.command.*;

/** 
 * A command that takes a component that is for one device type and replaces
 * it with a component that is the same but for all device types.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-17-2004 James Lin
 *                               Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-17-2004
 */
public class ReplaceComponentWithDeviceAllVersionCommand extends UndoableCommand
implements ModifyGraphCommand {
   
   private final Command realCommand;
   private final Component component;

   public ReplaceComponentWithDeviceAllVersionCommand(final Component component) {
      this.component = component; 
      if (component instanceof Control) {
         realCommand = new ReplaceControlWithDeviceAllVersionCommand(
               (Control) component);
      }
      else {
         realCommand = new ReplaceGroupWithDeviceAllVersionCommand(
               (ComponentGroup) component);
      }
   }


   // Overrides method in superclass.
   public String getPresentationName() {
      return "Change device-specific " + component + " into device-all";
   }
   

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      realCommand.execute();
   }
   

   // Overrides method in superclass.   
   public void redo() {
      realCommand.redo();
   }

   // Overrides method in superclass.   
   public void undo() {
      realCommand.undo();
   }

   
   private static class ReplaceControlWithDeviceAllVersionCommand extends
         ModifyGraphMacroCommand {

      private Control newControl;
      
      private ReplaceControlWithDeviceAllVersionCommand(final Control control) {
         // if dialog.devicetype <> ALL, pop up error message, return
         DamaskUtils.checkValidArgument(
            control.getDialog().getDeviceType() == DeviceType.ALL,
            "The dialog of "
               + control
               + ", "
               + control.getDialog()
               + ", must be ALL, not "
               + control.getDialog().getDeviceType());

         final DeviceType origControlDeviceType = control.getDeviceType();
         if (origControlDeviceType == DeviceType.ALL) {
            return;
         }

         // for each outgoing connection
         for (Iterator i = control.getOutConnections().iterator(); i.hasNext(); ) {
            // if connection.dest.devicetype <> ALL, pop up error message, return
            final Connection connection = (Connection)i.next();
            final ConnectionDest dest =
               connection.getConnectionDest(origControlDeviceType);
            if (dest instanceof Page) {
               final Page destPage = (Page)dest;
               if (destPage.getDialog().getDeviceType() != DeviceType.ALL) {
                  throw new IllegalArgumentException(
                     "The destination of "
                        + connection
                        + ", "
                        + connection.getConnectionDest(origControlDeviceType)
                        + ", must be ALL, not "
                        + control.getDialog().getDeviceType());
               }
            }
            // remove connection, save info
            addCommand(new RemoveConnectionCommand(connection, false));
         }
            
         // create a new control
         newControl = (Control)control.createCopy(DeviceType.ALL);

         // add the new control
         final PageRegion targetRegion =
            control.getPageRegion(origControlDeviceType);
         
         ComponentGroup targetGroup = control.getGroup();
         if ((targetGroup != null)
            && (targetGroup.getDeviceType() != DeviceType.ALL)) {
            targetGroup = null;
         }
                  
         DamaskUtils.addCommandsForAddingComponentToMacroCommand(
            this,
            newControl,
            targetRegion,
            targetGroup,
            false,
            false);

         // remove the control
         DamaskUtils.addCommandsForRemovingControlToMacroCommand(this, control);
         
         // for each original outgoing connection info,
         // create new connection with new device type
         for (Iterator i = control.getOutConnections().iterator(); i.hasNext(); ) {
            final NavConnection connection = (NavConnection)i.next();
            addCommand(
               new AddConnectionCommand(
                  origControlDeviceType,
                  true,
                  newControl,
                  connection.getUserEvent(),
                  connection.getCondition(),
                  connection.getConnectionDest(origControlDeviceType),
                  connection.getShape(origControlDeviceType)));
         }
      }
      
      
      /**
       * Returns the new control that is created by this command.
       */
      public Control getNewControl() {
         return newControl;
      }
   }
   
   private static class ReplaceGroupWithDeviceAllVersionCommand extends
         UndoableCommand implements ModifyGraphCommand {
      
      private final ComponentGroup group;
      private final MacroCommand replaceControlCommands = new MacroCommand();
      private final MacroCommand addControlCommands = new MacroCommand();
      private final MacroCommand replaceGroupCommands = new MacroCommand();
      
      private final Map/*<Control, Control>*/ newControls =
         new HashMap/*<Control, Control>*/();
      
      public ReplaceGroupWithDeviceAllVersionCommand(final ComponentGroup group) {
         this.group = group;
      }

      private void replaceControlsInGroupWithDeviceAllVersion(
         final ComponentGroup group) {
            
         final Dialog dialog = group.getDialog();
   
         // if dialog.devicetype <> ALL, pop up error message, return
         DamaskUtils.checkValidArgument(
            dialog.getDeviceType() == DeviceType.ALL,
            "The dialog of "
               + group
               + ", "
               + dialog
               + ", must be ALL, not "
               + dialog.getDeviceType());
   
         for (Iterator i = group.getChildren().iterator(); i.hasNext(); ) {
            final Component child = (Component)i.next();
            if (child instanceof Control) {
               final Control childControl = (Control)child;
               final ReplaceControlWithDeviceAllVersionCommand replaceCommand =
                  new ReplaceControlWithDeviceAllVersionCommand(childControl);
               newControls.put(childControl, replaceCommand.getNewControl());
               replaceControlCommands.addCommand(replaceCommand);
            }
            else {
               replaceControlsInGroupWithDeviceAllVersion((ComponentGroup)child);
            }
         }
      }

      
      private ComponentGroup addControlsToNewGroup(final ComponentGroup group) {
         final Dialog dialog = group.getDialog();
   
         // if dialog.devicetype <> ALL, pop up error message, return
         DamaskUtils.checkValidArgument(
            dialog.getDeviceType() == DeviceType.ALL,
            "The dialog of "
               + group
               + ", "
               + dialog
               + ", must be ALL, not "
               + dialog.getDeviceType());
   
         final ComponentGroup newGroup = (ComponentGroup) group
               .createCopy(DeviceType.ALL);
   
         // for each component in group:
         for (Iterator i = group.getChildren().iterator(); i.hasNext(); ) {
            final Component child = (Component)i.next();
            if (child instanceof Control) {
               final Control newChildControl = (Control)newControls.get(child);
               
               // This "add" is solely for calculating the bounds of newGroup
               // for all device types
               newGroup.add(newChildControl);
            }
            else {
               final ComponentGroup childGroup = (ComponentGroup)child;
               final ComponentGroup newChildGroup =
                  addControlsToNewGroup(childGroup);
               
               // This "add" is solely for calculating the bounds of newGroup
               // for all device types
               newGroup.add(newChildGroup);
            }
         }
   
         return newGroup;
      }

      
      private void replaceGroupWithDeviceAllVersion(
         final ComponentGroup newGroup) {
            
         final DeviceType origGroupDeviceType = group.getDeviceType();
         
         final PageRegion targetRegion = (PageRegion) group
               .getPageRegions(origGroupDeviceType).iterator().next();

         DamaskUtils.addCommandsForAddingComponentToMacroCommand(replaceGroupCommands,
                                                           newGroup,
                                                           targetRegion,
                                                           group.getGroup(),
                                                           false,
                                                           false);

         // for each component in group:
         for (Iterator i = newGroup.getChildren().iterator(); i.hasNext(); ) {
            final Component newChild = (Component)i.next();
            if (newChild instanceof Control) {
               
               // This "add" is so that we can undo it later
               addControlCommands.addCommand(
                  new AddComponentToGroupCommand(newGroup, newChild));
            }
            else {
               replaceGroupWithDeviceAllVersion((ComponentGroup)newChild);
               
               // This "add" is so that we can undo it later
               addControlCommands.addCommand(
                  new AddComponentToGroupCommand(newGroup, newChild));
            }
         }
   
         replaceGroupCommands.addCommand(new RemoveGroupCommand(group));
      }

      // Overrides method in superclass.   
      public String getPresentationName() {
         return "Add control to page";
      }

      // Overrides method in superclass.   
      public boolean canRedo() {
         return true;
      }

      // Overrides method in superclass.   
      public void run() {
         if (group.getDeviceType() == DeviceType.ALL) {
            return;
         }
         
         // 1. Go through the controls contained in the group and its
         //    descendant groups, and replace those with device-all
         //    versions.
         replaceControlsInGroupWithDeviceAllVersion(group);
         replaceControlCommands.execute();
         
         // 2. Go through the group and its descendant groups, and replace
         //    them with device-all versions.
         final ComponentGroup newGroup = addControlsToNewGroup(group);
         replaceGroupWithDeviceAllVersion(newGroup);
         replaceGroupCommands.execute();
         
         // 3. Add the new device-all controls to the new device-all groups.
         addControlCommands.execute();
      }
      

      // Overrides method in superclass.   
      public void redo() {
         replaceControlCommands.redo();
         replaceGroupCommands.redo();
         addControlCommands.redo();
      }

      // Overrides method in superclass.   
      public void undo() {
         addControlCommands.undo();
         replaceGroupCommands.undo();
         replaceControlCommands.undo();
      }
   }
}
