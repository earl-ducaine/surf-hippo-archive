//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.graphics;

import java.awt.*;
import java.awt.RenderingHints.Key;
import java.awt.geom.*;
import java.awt.font.*;
import java.awt.image.*;
import java.awt.image.renderable.*;
import java.text.*;
import java.util.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.collection.*;

/**
 * The Satin Graphics context, an extension of Graphics2D. Has some additional 
 * capabilities, such as drawing with Styles, and a stack of Transforms.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Apr 15 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - Add Issuer, Aug 15 2003, YL
 *               
 
 * </PRE>
 * 
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 15 2003
 */
public class SatinGraphics 
   extends    Graphics2D 
   implements GraphicsConstants {

   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================




   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   Graphics2D             g;              // our Graphics context to delegate to

   NonlockingStack        stackStyle;     // stack o' Styles
   NonlockingStack        stackTransform; // stack o' Transform matrices
   Style                  currentStyle;   // the current drawing Style
                                          //    do not modify, as this is a ref

   Color                  fillColor;      // part of current Style, fill color
                                          //    before transparency is applied
   Color                  drawColor;      // part of current Style, draw color
                                          //    before transparency is applied
   Color                  bkgrdColor;     // the background color
   Color                  fontColor;      // color for fonts

   Color                  tFillColor;     // cached translucent version
   Color                  tDrawColor;     // cached translucent version
   Color                  tFontColor;     // cached translucent version

   float                  transparency;   // overall transparency of graphics
   TranslucentImageFilter tfilter;        // image translucency filter

   GraphicsXQuality       delegate;       // points to one of the four below
   GraphicsXQuality       g_highest;      // highest quality
   GraphicsXQuality       g_high;         // high quality
   GraphicsXQuality       g_medium;       // medium quality
   GraphicsXQuality       g_low;          // low quality
   GraphicsXQuality       g_lowest;       // low quality

   Font                   currentFont;    // ref to current font
   String                 strCurrentFontName;
   
   Object 					  mIssuer;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Be sure the call setGraphics() before using.
    */
   public SatinGraphics() {
      //// 1. Initialize the graphics values.
      currentStyle     = new Style();
      
      //// 2. Initialize the stacks.
      stackStyle     = new NonlockingStack();
      stackTransform = new NonlockingStack();

      //// 3. Initialize the graphics.
      // Usher in the age of the neon spaceman PIII
      g_highest = new GraphicsHighestQuality(); //highest is anti-aliased
      g_high    = new GraphicsHighestQuality();
      g_medium  = new GraphicsHighestQuality();
      g_low     = new GraphicsHighestQuality();
      g_lowest  = new GraphicsMediumQuality(); //medium is not anti-aliased
      delegate  = g_highest;

      // Man, these were for back when we had PII's
      /*g_highest = new GraphicsHighestQuality();
      g_high    = new GraphicsHighQuality();
      g_medium  = new GraphicsMediumQuality();
      g_low     = new GraphicsLowQuality();
      g_lowest  = new GraphicsLowestQuality();
      delegate  = g_highest;*/

      // Medium is better for screen shots; otherwise highest is best
      /*g_highest = new GraphicsMediumQuality();
      g_high    = new GraphicsMediumQuality();
      g_medium  = new GraphicsMediumQuality();
      g_low     = new GraphicsMediumQuality();
      g_lowest  = new GraphicsMediumQuality();
      delegate  = g_highest;*/

      //// 4. Other initializations.
      transparency   = 1.0f;
      tfilter        = new TranslucentImageFilter(1.0);
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Create a wrapper around the specified Graphics2D object.
    *
    * @param newG is the Graphics2D object we will delegate to.
    */
   public SatinGraphics(Graphics2D newG) {
      this();
      setGraphics(newG);
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Set the quality / speed level of rendering. Be sure to call this BEFORE
    * calling {@link #setGraphics(Graphics2D)}.
    * Use one of the following values as the parameter for quality:
    * <UL>
    *    <LI>{@link GraphicsConstants#HIGHEST_QUALITY}
    *    <LI>{@link GraphicsConstants#HIGH_QUALITY}
    *    <LI>{@link GraphicsConstants#MEDIUM_QUALITY}
    *    <LI>{@link GraphicsConstants#LOW_QUALITY}
    *    <LI>{@link GraphicsConstants#LOWEST_QUALITY}
    * </UL>
    */
   public final void setRenderQuality(int value) {
      switch (value) {
         case HIGHEST_QUALITY: delegate = g_highest; break;
         case HIGH_QUALITY:    delegate = g_high;    break;
         case MEDIUM_QUALITY:  delegate = g_medium;  break;
         case LOW_QUALITY:     delegate = g_low;     break;
         case LOWEST_QUALITY:  delegate = g_lowest;  break;
         default: 
           throw new IllegalArgumentException("What the heck did you pass in?");
      }
   } // of setRenderQuality

   //-----------------------------------------------------------------

   public final void setGraphics(Graphics2D newG) {
       setGraphics(newG, false);
   } // of method



   /**
    * Set the graphics context to draw with.
    *
    * @param newG is the graphics context to set to.
    */
    public final void setGraphics(Graphics2D newG, boolean keepAntialiasHint) {
      g = newG;
      setGraphicsStyle(currentStyle);

      //// 1. Assign the same value to the delegate.
      Object antialiasHint = newG.getRenderingHint(RenderingHints.KEY_ANTIALIASING); 
      delegate.setGraphics(g);
      g.setRenderingHints(delegate.getHints());
      if (keepAntialiasHint) g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, antialiasHint);

      //// 2. Save the default transform, so ignoreTransform() can be
      ////    called correctly.
      setDefaultTransform(g.getTransform());

      //// 3. Set the background color if it doesn't exist.
      if (bkgrdColor == null) {
         bkgrdColor = g.getBackground();
      }

      //// 4. Get the current font name, for optimization purposes later.
      currentFont        = newG.getFont();
      if (currentFont != null) {
          strCurrentFontName = currentFont.getName();
      }
      else {
          strCurrentFontName = "";
      }
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Get the current Graphics context.
    *
    * @return the current Graphics context.
    */
   public final Graphics2D getGraphics() {
      return (g);
   } // of getGraphics

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   STYLE METHODS   =====================================================

   /**
    * Push a new Style onto the Stack for this Graphics to use.
    *
    * @see    #getStyle()
    * @see    #popStyle()
    * @param s is the Style to use.
    */
   public final void pushStyle(Style s) {
      stackStyle.push(currentStyle);
      currentStyle = s;
      setGraphicsStyle(currentStyle);
   } // of pushStyle

   //-----------------------------------------------------------------

   /**
    * Pop a Style off the Stack, restoring the previous Style.
    *
    * @see    #getStyle()
    * @see    #pushStyle(edu.berkeley.guir.lib.satin.objects.Style)
    */
   public final void popStyle() {
      currentStyle = (Style) stackStyle.pop();
      setGraphicsStyle(currentStyle);
   } // of popStyle

   //-----------------------------------------------------------------

   /**
    * Set the Graphics parameters to use the specified Style.
    *
    * @param s is the Style to use.
    */
   private final void setGraphicsStyle(Style s) {
      //// 1. Set the new state.
      setStroke(s.getDrawStroke());
      setFont(s.getDrawFont());

      //// 2. Cannot set the color directly, since we have different colors,
      ////    including the DrawColor and the FillColor.
      fillColor  = s.getFillColor();
      drawColor  = s.getDrawColor();
      fontColor  = s.getFontColor();

      //// 3. Set the transparent colors.
      tFillColor = GraphicsLib.makeTransparent(fillColor, transparency);
      tDrawColor = GraphicsLib.makeTransparent(drawColor, transparency);
      tFontColor = GraphicsLib.makeTransparent(fontColor, transparency);
   } // of setGraphicsStyle

   //-----------------------------------------------------------------

   /**
    * Get the current drawing Style. This is a copy, not a reference to the
    * original.
    *
    * @see    #popStyle()
    * @see    #pushStyle(Style)
    * @return the Style that this SatinGraphics context will draw with.
    */
   public final Style getStyle() {
      return ((Style) currentStyle.clone());
   } // of getStyle

   //-----------------------------------------------------------------

   /**
    * Set the overall transparency of all things drawn in this Graphics context.
    *
    * @param val is a value between 0 and 1, 0 meaning fully transparent and
    *        1 meaning fully solid.
    */
   public final void setTransparency(float val) {
      if (val < 0 || val > 1) {
         throw new IllegalArgumentException("Invalid value for transparency");
      }

      //// 1. Set the transparency value.
      transparency = val;

      //// 2. Set the image filter's transparency value.
      tfilter.setAlpha(val);

      //// 3. Set the transparent colors.
      tFillColor = GraphicsLib.makeTransparent(fillColor, transparency);
      tDrawColor = GraphicsLib.makeTransparent(drawColor, transparency);
      tFontColor = GraphicsLib.makeTransparent(fontColor, transparency);
   } // of setTransparency

   //-----------------------------------------------------------------

   /**
    * Get the current transparency value.
    */
   public final float getTransparency() {
      return (transparency);
   } // of method

   //===   STYLE METHODS   =====================================================
   //===========================================================================




   //===========================================================================
   //===   ORIGIN METHODS   ====================================================

   /**
    * Specify where the origin of the graphics should be relative to.
    * What it really does is create an AffineTransform that represents
    * a translation, and just calls pushTransform(). 
    *
    * @see   #getOrigin()
    * @see   #popOrigin()
    * @see   #pushTransform(java.awt.geom.AffineTransform)
    * @param x is the origin's new x-position.
    * @param y is the origin's new y-position.
    */
   public final void pushOrigin(int x, int y) {
      AffineTransform tx = new AffineTransform();
      tx.translate(x, y);
      pushTransform(tx);
   } // of pushOrigin

   //-----------------------------------------------------------------

   /**
    * Specify where the origin of the graphics should be relative to.
    * This is cascaded with all of the previous pushOrigin() values.
    *
    * @see   #getOrigin()
    * @see   #popOrigin()
    * @see   #pushOrigin(int, int)
    * @param pt is the new origin.
    */
   public final void pushOrigin(Point pt) {
      pushOrigin(pt.x, pt.y);
   } // of pushOrigin

   //-----------------------------------------------------------------

   /**
    * Go back to the previous origin coordinates.
    *
    * @see   #getOrigin()
    * @see   #pushOrigin(java.awt.Point)
    * @see   #pushOrigin(int, int)
    */
   public final void popOrigin() {
      popTransform();
   } // of popOrigin

   //-----------------------------------------------------------------

   /**
    * Get where the current origin is. This is a copy, not a reference to
    * anything important.
    *
    * @see    #popOrigin()
    * @see    #pushOrigin(java.awt.Point)
    * @see    #pushOrigin(int, int)
    * @return a Point representing the coordinates of the current origin.
    */
   public final Point getOrigin() {
      return (getTranslation(getTransform()));
   } // of getOrigin

   //-----------------------------------------------------------------

   /**
    * Given an AffineTransform, get the (x,y) translation.
    */
   private final Point getTranslation(AffineTransform tx) {
      return (new Point((int) tx.getTranslateX(), (int) tx.getTranslateY()));
   } // of getTranslation

   //===   ORIGIN METHODS   ====================================================
   //===========================================================================




   //===========================================================================
   //===   TRANSFORM METHODS   =================================================

   AffineTransform txOldTransform;
   AffineTransform txDefaultTransform;
   NonlockingStack undo = new NonlockingStack();

   //-----------------------------------------------------------------

   /**
    * Clear out all transforms.
    */
   public final void clearAllTransforms() {
      stackTransform.clear();
      g.setTransform(g.getDeviceConfiguration().getDefaultTransform());
   } // of clearAllTransforms

   //-----------------------------------------------------------------

   /**
    * Set the transform that will be used when ignoreTransforms() is called.
    * This needs to be called every time the Sheet gets a new Graphics context,
    * because each Graphics context has its own default transform. Right now,
    * this is automatically called every time setGraphics() is called.
    */
   public final void setDefaultTransform(AffineTransform tx) {
      txDefaultTransform = tx;
   } // of setDefaultTransform

   //-----------------------------------------------------------------

   /**
    * Temporarily ignore the current transform, restoring it to the 
    * default transform. Additional transforms can be used once this
    * method is called, but they will all be thrown away once 
    * {@link #dontIgnoreTransforms()} is called.
    * <P>
    * This method is useful for Sticky views, like
    * {@link edu.berkeley.guir.lib.satin.view.StickyViewWrapper} and
    * {@link edu.berkeley.guir.lib.satin.view.StickyZViewWrapper}.
    * <P>
    * <B>Be sure to call {@link #dontIgnoreTransforms()} before you push or 
    * pop any transforms from the stack</B>. Really bad things [tm] will happen 
    * if you don't.
    */
   public final void ignoreTransforms() {
      //// 1. Save the old transform.
      txOldTransform = g.getTransform();

      //// 2. Set the new transform.
      g.setTransform(txDefaultTransform);
   } // of ignoreTransforms

   //-----------------------------------------------------------------

   /**
    * Restore the current transforms. <B>Do not call this unless 
    * {@link #ignoreTransforms()} has been called earlier</B>.
    */
   public final void dontIgnoreTransforms() {
      //// 1. Restore the old transform.
      g.setTransform(txOldTransform);
   } // of dontIgnoreTransforms

   //-----------------------------------------------------------------

   /**
    * Apply a new transform to this SatinGraphics context.
    *
    * @see   #popTransform()
    * @param tx is the AffineTransform to apply.
    */
   public final void pushTransform(AffineTransform tx) {
      //// 1. This is a faster implementation that stores the actual
      ////    transform instead of storing each relative operation.
      stackTransform.push(g.getTransform());
      g.transform(tx);
   } // of pushTransform

   /**
    * Undo the last transform.
    *
    * @see   #pushTransform(java.awt.geom.AffineTransform)
    */
   public final void popTransform() {
      //// 1. This is a faster implementation that stores the actual
      ////    transform instead of storing each relative operation.
      AffineTransform tx = (AffineTransform) stackTransform.pop();
      g.setTransform(tx);
   } // of popTransform

   //===   TRANSFORM METHODS   =================================================
   //===========================================================================
   



   //===========================================================================
   //===   NEW GRAPHICS METHODS   ==============================================

   /**
    * Shift an object to have new coordinates. For example, most objects are
    * drawn using the specified (x,y) coordinates as the top-left corner. Let's
    * say you want to use the specified (x,y) coordinates as the center. This
    * method does this transformation, returning an (x,y) coordinate that says
    * where you should draw.
    *
    * <P>
    * Suppose you have a Rectangle, and you want to draw it such that
    * it is centered at (0,0). Just call 
    * calculateNewPosition(rect, SatinGraphics.CENTER) to figure out where
    * the top-left corner of the Rectangle should be drawn. Pretty neat, eh?
    *
    * @param  shape is some shape to draw. 
    * @param  pos   specifies where to shift the drawing to 
    *               ({@link GraphicsConstants#CENTER}, 
    *                {@link GraphicsConstants#TOP_LEFT}, etc).
    * @return a Point containing where to draw the object's top-left corner.
    */
   public static Point calculateNewPosition(Shape shape, int pos) {

      Point     pt;
      Rectangle rect = shape.getBounds();
      int       x    = rect.x;
      int       y    = rect.y;
      int       w    = rect.width;
      int       h    = rect.height;

      switch (pos) {
         case TOP_LEFT    : pt = new Point(x,       y);       break;
         case TOP         : pt = new Point(x - w/2, y);       break;
         case TOP_RIGHT   : pt = new Point(x - w,   y);       break;
         case LEFT        : pt = new Point(x,       y - h/2); break;
         case CENTER      : pt = new Point(x - w/2, y - h/2); break;
         case RIGHT       : pt = new Point(x - w,   y - h/2); break;
         case BOTTOM_LEFT : pt = new Point(x,       y - h);   break;
         case BOTTOM      : pt = new Point(x - w/2, y - h);   break;
         case BOTTOM_RIGHT: pt = new Point(x - w,   y - h);   break;
         default:
            throw new IllegalArgumentException("Unknown position value " + pos);
      }

      return (pt);

   }  // of calculateNewPosition

   //-----------------------------------------------------------------

   /**
    * Calculate how much a Shape should be translated along x- and y- such
    * that the specified position of the Shape will be at the specified (x,y)
    * coordinate.
    * <P>
    * For example, say you already have a circle, and want to draw this
    * circle with (0,0) as its center. Just call
    * calculateTranslation(circle, 0, 0, CENTER) to figure out how much
    * the shape should be translated. 
    *
    * @param  shape is the Shape to determine how much to move. Make sure
    *               that the coordinates of shape are in the same coordinate
    *               system as x and y below.
    * @param  x     is the x-coordinate to move it to.
    * @param  y     is the y-coordinate to move it to.
    * @param  pos   is the position that x and y represent
    *               ({@link GraphicsConstants#CENTER}, 
    *                {@link GraphicsConstants#TOP_LEFT}, etc).
    * @return a Point containing the amount to translate along x and y.
    */
   public static Point 
   calculateTranslation(Shape shape, int x, int y, int pos) {
      Point     newLoc    = calculateNewPosition(shape, pos);
      Rectangle oldBounds = shape.getBounds();

      return (new Point(newLoc.x - oldBounds.x, newLoc.y - oldBounds.y));
   } // of calculateTranslation

   //-----------------------------------------------------------------

   /**
    * Draw a String at the specified coordinates, and qualifying what the
    * coordinates are supposed to be. 
    *
    * <P>
    * For example, if you want to draw a String with its top-right corner
    * at position (100,200), just call drawString(str, 100, 200, 
    * SatinGraphics.TOP_RIGHT).
    *
    * @param x   is the x-coordinate of where to draw.
    * @param y   is the y-coordinate of where to draw (it actually does not
    *            matter that y is usually the bottom and not the top 
    *            coordinate, since we are specifying where to draw anyway).
    * @param pos specifies what (x,y) are relative to the bounding box
    *               ({@link GraphicsConstants#CENTER}, 
    *                {@link GraphicsConstants#TOP_LEFT}, etc).
    */
   public void drawString(String str, int x, int y, int pos) {
      //// 0. Just get info on the current font.
      FontMetrics fmetric     = getFontMetrics();

      //// 1. Calculate the bounding box of the String.
      Rectangle rect;
      rect = GraphicsLib.calculateBoundingBox(str, getFont(), x, y, pos);

      //// 2. Shift the y-coordinate around, since drawString() uses the
      ////    bottom-left corner, not the top-right corner like every
      ////    other standard. Duh...
      rect.y += fmetric.getHeight();

      //// 3. Let's draw the String now.
      drawString(str, rect.x, rect.y);
   } // of drawString

   //-----------------------------------------------------------------

   /**
    * This is a convenience method, since Java doesn't let you just draw
    * Rectangles. Pretty silly, right?
    */
   public void drawRect(Rectangle rect) {
      drawRect(rect.x, rect.y, rect.width, rect.height);
   } // of drawRect

   //-----------------------------------------------------------------

   /**
    * Draw a Rectangle, and qualify what the coordinates are supposed to be. 
    *
    * <P>
    * For example, let's suppose you have a Rectangle. You can draw
    * this Rectangle normally. However, this method lets you shift it around
    * a little. If you specify position BOTTOM_RIGHT, then the Rectangle
    * is translated such that it's bottom-right corner is now where it's 
    * top-left corner used to be. Basically, any position you specify will 
    * translate the Rectangle such that the position will be 
    * translated to where the top-left corner is.
    *
    * @param rect is the Rectangle to draw.
    * @param pos  specifies what (x,y) are relative to the bounding box
    *               ({@link GraphicsConstants#CENTER}, 
    *                {@link GraphicsConstants#TOP_LEFT}, etc).
    */
   public void drawRect(Rectangle rect, int pos) {
      drawRect(rect.x, rect.y, rect.width, rect.height, pos);
   } // of drawRect

   //-----------------------------------------------------------------

   /**
    * @see   #drawRect(java.awt.Rectangle, int)
    * @param x      is the left side of the rectangle.
    * @param y      is the top of the rectangle.
    * @param width  is the width of the rectangle to draw.
    * @param height is the height of the rectangle to draw.
    * @param pos    specifies what (x,y) are relative to the bounding box
    *               ({@link GraphicsConstants#CENTER}, 
    *                {@link GraphicsConstants#TOP_LEFT}, etc).
    */
   public void drawRect(int x, int y, int width, int height, int pos) {
      Rectangle rect = new Rectangle(x, y, width, height);
      Point pt = calculateNewPosition(rect, pos);
      drawRect(pt.x, pt.y, rect.width, rect.height);
   } // of drawRect

   //-----------------------------------------------------------------

   /**
    * Fills the Rectangle.
    *
    * @see   #drawRect(java.awt.Rectangle, int)
    * @param rect is the Rectangle to draw.
    * @param pos  specifies what (x,y) are relative to the bounding box
    *               ({@link GraphicsConstants#CENTER}, 
    *                {@link GraphicsConstants#TOP_LEFT}, etc).
    */
   public void fillRect(Rectangle rect, int pos) {
      fillRect(rect.x, rect.y, rect.width, rect.height, pos);
   } // of fillRect

   //-----------------------------------------------------------------

   /**
    * Fills the Rectangle.
    *
    * @see   #drawRect(java.awt.Rectangle, int)
    * @param x      is the left side of the rectangle.
    * @param y      is the top of the rectangle.
    * @param width  is the width of the rectangle to draw.
    * @param height is the height of the rectangle to draw.
    * @param pos    specifies what (x,y) are relative to the bounding box
    *               ({@link GraphicsConstants#CENTER}, 
    *                {@link GraphicsConstants#TOP_LEFT}, etc).
    */
   public void fillRect(int x, int y, int width, int height, int pos) {
      Rectangle rect = new Rectangle(x, y, width, height);
      Point pt = calculateNewPosition(rect, pos);
      fillRect(pt.x, pt.y, rect.width, rect.height);
   } // of fillRect

   //===   NEW GRAPHICS METHODS   ==============================================
   //===========================================================================




   //===========================================================================
   //===   DELEGATION GRAPHICS - MISC METHODS   ================================

   public final void dispose() {
      g.dispose();
   } // of dispose

   //-----------------------------------------------------------------

   public final void finalize() {
      g.finalize();
   } // of finalize

   //-----------------------------------------------------------------

   public boolean hitClip(int x, int y, int width, int height) {
      return(g.hitClip(x, y, width, height));
   } // of hitClip

   //-----------------------------------------------------------------

   public Graphics create() {
      return (g.create());
   } // of create

   //-----------------------------------------------------------------

   public Graphics create(int x, int y, int width, int height) {
      return (g.create(x, y, width, height));
   } // of create

   //-----------------------------------------------------------------

   public final void copyArea(int x, int y, int width, int height,
                                  int dx, int dy) {
      g.copyArea(x, y, width, height, dx, dy);
   } // of copyArea

   //-----------------------------------------------------------------

   /**
    * @see java.awt.Graphics2D#addRenderingHints(java.util.Map)
    */
   public final void addRenderingHints(Map hints) {
      g.addRenderingHints(hints);
   } // of addRenderingHints

   //===   DELEGATION GRAPHICS - MISC METHODS   ================================
   //===========================================================================




   //===========================================================================
   //===   DELEGATION GRAPHICS - MODIFIER METHODS   ============================

   /**
    * Sets the current style to use the specified Color. 
    * You should note that this color will automatically be popped
    * off the stack when the current GraphicalObject is done drawing.
    * <P>
    * Also automatically applies transparency.
    */
   public final void setColor(Color c) {
      Color cc = GraphicsLib.makeTransparent(c, transparency);

      tFillColor = cc;
      tDrawColor = cc;
      tFontColor = cc;
      
      g.setColor(cc);
   } // of setColor

   //-----------------------------------------------------------------

   /**
    * Sets the current style to use the specified Color. 
    * You should note that this Font will automatically be popped
    * off the stack when the current GraphicalObject is done drawing.
    */
   public final void setFont(Font font) {
      //// 1.1. Optimization purposes, fonts seem to be expensive.
      ////    First check if the references are the same.
      if (font == currentFont) {
          return;
      }

      //// 1.2. Now check if the font names are the same.
      String strNewFontName = null;
      if (currentFont != null) {
          strNewFontName = font.getFontName();

          if (strNewFontName.equals(strCurrentFontName) == true) {
              return;
          }
      }

      //// 2. Ok, not same, so set the font.
      if (strNewFontName == null) {
          strNewFontName = font.getFontName();
      }
      currentFont        = font;
      strCurrentFontName = strNewFontName;
      g.setFont(font);
   } // of setFont

   //-----------------------------------------------------------------

   public final void setPaintMode() {
      g.setPaintMode();
   } // of setPaintMode

   //-----------------------------------------------------------------

   public final void setXORMode(Color c1) {
      g.setXORMode(c1);
   } // of setXORMode

   //-----------------------------------------------------------------

   public final void setClip(int x, int y, int width, int height) {
      g.setClip(x, y, width, height);
   } // of setClip

   //-----------------------------------------------------------------

   public final void setClip(Shape clip) {
      g.setClip(clip);
   } // of setClip

   //-----------------------------------------------------------------

   public final void clipRect(int x, int y, int width, int height) {
      g.clipRect(x, y, width, height);
   } // of clipRect

   //===   DELEGATION GRAPHICS - MODIFIER METHODS   ============================
   //===========================================================================




   //===========================================================================
   //===   DELEGATION GRAPHICS - ACCESSOR METHODS   ============================

   public Color getColor() {
      return (g.getColor());
   } // of getColor

   //-----------------------------------------------------------------

   public Font getFont() {
      return (g.getFont());
   } // of getFont

   //-----------------------------------------------------------------

   public FontMetrics getFontMetrics() {
      return (g.getFontMetrics());
   } // of getFontMetrics

   //-----------------------------------------------------------------

   public FontMetrics getFontMetrics(Font f) {
      return (g.getFontMetrics(f));
   } // of getFontMetrics

   //-----------------------------------------------------------------

   public Rectangle getClipBounds() {
      return (g.getClipBounds());
   } // of getClipBounds

   //-----------------------------------------------------------------

   public Shape getClip() {
      return (g.getClip());
   } // of getClip

   //-----------------------------------------------------------------

   /**
    * @deprecated
    */
   public Rectangle getClipRect() {
      return (g.getClipRect());
   } // of getClipRect

   //-----------------------------------------------------------------

   public Rectangle getClipBounds(Rectangle r) {
      return (g.getClipBounds(r));
   } // of getClipBounds

   //===   DELEGATION GRAPHICS - ACCESSOR METHODS   ============================
   //===========================================================================




   //===========================================================================
   //===   DELEGATION GRAPHICS - DRAWING METHODS   =============================

   public final void drawLine(int x1, int y1, int x2, int y2) {
      g.setColor(tDrawColor);
      delegate.drawLine(x1, y1, x2, y2);
   } // of drawLine

   //-----------------------------------------------------------------

   public final void fillRect(int x, int y, int width, int height) {
      g.setColor(tFillColor);
      delegate.fillRect(x, y, width, height);
   } // of fillRect

   //-----------------------------------------------------------------

   public final void drawRect(int x, int y, int width, int height) {
      g.setColor(tDrawColor);
      delegate.drawRect(x, y, width, height);
   } // of drawRect

   //-----------------------------------------------------------------

   public final void clearRect(int x, int y, int width, int height) {
      // g.setBackground(getBackground());
      delegate.clearRect(x, y, width, height);
   } // of clearRect

   //-----------------------------------------------------------------

   public final void drawRoundRect(int x, int y, int width, int height,
                                       int arcWidth, int arcHeight) {
      g.setColor(tDrawColor);
      delegate.drawRoundRect(x, y, width, height, arcWidth, arcHeight);
   } // of drawRoundRect

   //-----------------------------------------------------------------

   public final void fillRoundRect(int x, int y, int width, int height,
                                       int arcWidth, int arcHeight) {
      g.setColor(tFillColor);
      delegate.fillRoundRect(x, y, width, height, arcWidth, arcHeight);
   } // of fillRoundRect

   //-----------------------------------------------------------------

   public final void drawOval(int x, int y, int width, int height) {
      g.setColor(tDrawColor);
      delegate.drawOval(x, y, width, height);
   } // of drawOval

   //-----------------------------------------------------------------

   public final void fillOval(int x, int y, int width, int height) {
      g.setColor(tFillColor);
      delegate.fillOval(x, y, width, height);
   } // of fillOval

   //-----------------------------------------------------------------

   public final void drawArc(int x, int y, int width, int height,
                                 int startAngle, int arcAngle) {
      g.setColor(tDrawColor);
      delegate.drawArc(x, y, width, height, startAngle, arcAngle);
   } // of drawArc

   //-----------------------------------------------------------------

   public final void fillArc(int x, int y, int width, int height,
                                 int startAngle, int arcAngle) {
      g.setColor(tFillColor);
      delegate.fillArc(x, y, width, height, startAngle, arcAngle);
   } // of fillArc

   //-----------------------------------------------------------------

   public final void drawPolyline(int xPoints[], int yPoints[], int nPoints) {
      g.setColor(tDrawColor);
      delegate.drawPolyline(xPoints, yPoints, nPoints);
   } // of drawPolyline

   //-----------------------------------------------------------------

   public final void drawPolygon(int xPoints[], int yPoints[], int nPoints) {
      g.setColor(tDrawColor);
      delegate.drawPolygon(xPoints, yPoints, nPoints);
   } // of drawPolygon

   //-----------------------------------------------------------------

   public final void drawPolygon(Polygon p) {
      g.setColor(tDrawColor);
      delegate.drawPolygon(p);
   } // of drawPolygon

   //-----------------------------------------------------------------

   public final void fillPolygon(int xPoints[], int yPoints[], int nPoints) {
      g.setColor(tFillColor);
      delegate.fillPolygon(xPoints, yPoints, nPoints);
   } // of fillPolygon

   //-----------------------------------------------------------------

   public final void fillPolygon(Polygon p) {
      g.setColor(tFillColor);
      delegate.fillPolygon(p);
   } // of fillPolygon

   //-----------------------------------------------------------------

   public final void drawString(String str, int x, int y) {
      g.setColor(tFontColor);
      delegate.drawString(str, x, y);
   } // of drawString

   //-----------------------------------------------------------------

   public final void drawChars(char[] data, int offset, int length, 
                               int x, int y) {
      g.setColor(tFontColor);
      delegate.drawChars(data, offset, length, x, y);
   } // of drawChars

   //-----------------------------------------------------------------

   public final void drawBytes(byte[] data, int offset, int length, 
                               int x, int y) {
      g.setColor(tDrawColor);
      delegate.drawBytes(data, offset, length, x, y);
   } // of drawBytes

   //-----------------------------------------------------------------

   public boolean drawImage(Image img, int x, int y, ImageObserver observer) {
      g.setColor(tDrawColor);
      return (delegate.drawImage(img, x, y, observer));
   } // of drawImage

   //-----------------------------------------------------------------

   public boolean drawImage(Image img, int x, int y,
                            int width, int height, ImageObserver observer) {
      g.setColor(tDrawColor);
      return (delegate.drawImage(img, x, y, width, height, observer));
   } // of drawImage

   //-----------------------------------------------------------------

   public boolean drawImage(Image img, int x, int y, 
                            Color bgcolor, ImageObserver observer) {
      g.setColor(tDrawColor);
      return (delegate.drawImage(img, x, y, bgcolor, observer));
   } // of drawImage

   //-----------------------------------------------------------------

   public boolean drawImage(Image img, int x, int y,
                                      int width, int height, 
                                      Color bgcolor, ImageObserver observer) {

      g.setColor(tDrawColor);
      return (delegate.drawImage(img, x, y, width, height, bgcolor, observer));
   } // of drawImage

   //-----------------------------------------------------------------

   public boolean drawImage(Image img,
                                      int dx1, int dy1, int dx2, int dy2,
                                      int sx1, int sy1, int sx2, int sy2,
                                      ImageObserver observer) {

      g.setColor(tDrawColor);
      return (delegate.drawImage(img, dx1, dy1, dx2, dy2, 
                          sx1, sy1, sx2, sy2, observer));
   } // of drawImage

   //-----------------------------------------------------------------

   public boolean drawImage(Image img,
                            int dx1, int dy1, int dx2, int dy2,
                            int sx1, int sy1, int sx2, int sy2,
                            Color bgcolor, ImageObserver observer) {

      g.setColor(tDrawColor);
      return (delegate.drawImage(img, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, 
                          bgcolor, observer));
   } // of drawImage


   //===   DELEGATION GRAPHICS - DRAWING METHODS   =============================
   //===========================================================================





   
   //===========================================================================
   //===   DELEGATION GRAPHICS2D - MISC METHODS   ==============================

   public FontRenderContext getFontRenderContext() {
      return (g.getFontRenderContext());
   } // of getFontRenderContext

   //-----------------------------------------------------------------

   public boolean hit(Rectangle rect, Shape s, boolean onStroke) {
      return (g.hit(rect, s, onStroke));
   } // of hit

   //-----------------------------------------------------------------

   public GraphicsConfiguration getDeviceConfiguration() {
      return (g.getDeviceConfiguration());
   } // of getDeviceConfiguration

   //-----------------------------------------------------------------

   public final void setRenderingHint(Key hintKey, Object hintValue) {
      g.setRenderingHint(hintKey, hintValue);
   } // of setRenderingHint

   //-----------------------------------------------------------------

   public Object getRenderingHint(Key hintKey) {
      return (g.getRenderingHint(hintKey));
   } // of getRenderingHint

   //-----------------------------------------------------------------

   public final void setRenderingHints(Map hints) {
      g.setRenderingHints(hints);
   } // of setRenderingHints

   //-----------------------------------------------------------------

   public RenderingHints getRenderingHints() {
      return (g.getRenderingHints());
   } // of getRenderingHints

   //===   DELEGATION GRAPHICS2D - MISC METHODS   ==============================
   //===========================================================================




   //===========================================================================
   //===   DELEGATION GRAPHICS2D - ACCESSOR METHODS   ==========================

   public Color getBackground() {
      return (bkgrdColor);
   } // of getBackground

   //-----------------------------------------------------------------

   public Stroke getStroke() {
      return (g.getStroke());
   } // of getStroke

   //-----------------------------------------------------------------

   public AffineTransform getTransform() {
      return (g.getTransform());
   } // of getTransform

   //-----------------------------------------------------------------

   public Paint getPaint() {
      return (g.getPaint());
   } // of getPaint

   //-----------------------------------------------------------------

   public Composite getComposite() {
      return (g.getComposite());
   } // of getComposite

   //===   DELEGATION GRAPHICS2D - ACCESSOR METHODS   ==========================
   //===========================================================================




   //===========================================================================
   //===   DELEGATION GRAPHICS2D - MODIFIER METHODS   ==========================

   /**
    * Sets the current style to use the specified Stroke. 
    * You should note that this Stroke will automatically be popped
    * off the stack when the current GraphicalObject is done drawing.
    *
    * @param  s is a BasicStroke, not a Stroke (which is rather useless as
    *           currently defined).
    * @throws ClassCastException if s is not a BasicStroke.
    */
   public final void setStroke(Stroke s) {
      g.setStroke(s);
   } // of setStroke

   //-----------------------------------------------------------------

   /**
    * Sets the current transform to the specified AffineTransform. 
    * You should note that this AffineTransform will automatically be popped
    * off the stack when the current GraphicalObject is done drawing.
    *
    * <P>
    * Please note that it is inherently dangerous to call this unless you know
    * the original AffineTransform that came with this graphics context, as
    * well as the AffineTransform to convert between virtual and screen
    * coordinates (We save this value in <CODE>txDefaultTransform</CODE>, but 
    * don't mess around with it unless you have to). 
    *
    * <P>
    * Instead of calling this method, you probably want to use 
    * {@link #transform(AffineTransform)} instead, which just applies a 
    * transform to the current transform.
    */
   public final void setTransform(AffineTransform Tx) {
      g.setTransform(Tx);
   } // of setTransform

   //-----------------------------------------------------------------

   /**
    * Applies the specified transformation.
    * You should note that the resulting AffineTransform will automatically 
    * be popped off the stack when the current GraphicalObject is done drawing.
    */
   public final void translate(int x, int y) {
      g.translate(x, y);
   } // of translate

   //-----------------------------------------------------------------

   /**
    * Applies the specified transformation.
    * You should note that the resulting AffineTransform will automatically 
    * be popped off the stack when the current GraphicalObject is done drawing.
    */
   public final void translate(double tx, double ty) {
      g.translate(tx, ty);
   } // of translate

   //-----------------------------------------------------------------

   /**
    * Applies the specified transformation.
    * You should note that the resulting AffineTransform will automatically 
    * be popped off the stack when the current GraphicalObject is done drawing.
    */
   public final void rotate(double theta) {
      g.rotate(theta);
   } // of rotate

   //-----------------------------------------------------------------

   /**
    * Applies the specified transformation.
    * You should note that the resulting AffineTransform will automatically 
    * be popped off the stack when the current GraphicalObject is done drawing.
    */
   public final void rotate(double theta, double x, double y) {
      g.rotate(theta, x, y);
   } // of rotate

   //-----------------------------------------------------------------

   /**
    * Applies the specified transformation.
    * You should note that the resulting AffineTransform will automatically 
    * be popped off the stack when the current GraphicalObject is done drawing.
    */
   public final void scale(double sx, double sy) {
      g.scale(sx, sy);
   } // of scale

   //-----------------------------------------------------------------

   /**
    * Applies the specified transformation.
    * You should note that the resulting AffineTransform will automatically 
    * be popped off the stack when the current GraphicalObject is done drawing.
    */
   public final void shear(double shx, double shy) {
      g.shear(shx, shy);
   } // of shear

   //-----------------------------------------------------------------

   /**
    * Applies the specified transformation.
    * You should note that the resulting AffineTransform will automatically 
    * be popped off the stack when the current GraphicalObject is done drawing.
    */
   public final void transform(AffineTransform Tx) {
      g.transform(Tx);
   } // of transform

   //-----------------------------------------------------------------

   public final void clip(Shape s) {
      g.clip(s);
   } // of clip

   //-----------------------------------------------------------------

   public final void setComposite(Composite comp) {
      g.setComposite(comp);
   } // of setComposite

   //-----------------------------------------------------------------

   public final void setPaint(Paint paint) {
      g.setPaint(paint);
   } // of setPaint

   //-----------------------------------------------------------------

   public final void setBackground(Color color) {
      bkgrdColor = color;
      if (g != null) {
         g.setBackground(color);
      }
   } // of setBackground

   //===   DELEGATION GRAPHICS2D - MODIFIER METHODS   ==========================
   //===========================================================================




   //===========================================================================
   //===   DELEGATION GRAPHICS2D - DRAWING METHODS   ===========================

   //  Must add to implement curvy lines
   public final void draw(GeneralPath thePath){
       g.setColor(tDrawColor);
       g.draw(thePath);
   }

   public final void draw(Shape s) {
      g.setColor(tDrawColor);
      delegate.draw(s);
   } // of draw

   //-----------------------------------------------------------------

   public final void draw3DRect(int x, int y, int width, 
                                int height, boolean raised) {
      g.setColor(tDrawColor);
      delegate.draw3DRect(x, y, width, height, raised);
   } // of draw3DRect

   //-----------------------------------------------------------------

   public final void drawGlyphVector(GlyphVector gv, float x, float y) {
      g.setColor(tDrawColor);
      delegate.drawGlyphVector(gv, x, y);
   } // of drawGlyphVector

   //-----------------------------------------------------------------

   public final void fill3DRect(int x, int y, int width, int height,
                           boolean raised) {
      g.setColor(tFillColor);
      delegate.fill3DRect(x, y, width, height, raised);
   } // of fill3DRect

   //-----------------------------------------------------------------

   public boolean drawImage(Image img, AffineTransform xform,
                                      ImageObserver obs) {
      g.setColor(tDrawColor);
      return (delegate.drawImage(img, xform, obs));
   } // of drawImage

   //-----------------------------------------------------------------

   /**
    * Transparency not implemented for this method yet.
    */
   public final void drawImage(BufferedImage img, BufferedImageOp op,
                         int x, int y) {
      g.setColor(tDrawColor);
      delegate.drawImage(img, op, x, y);
   } // of drawImage

   //-----------------------------------------------------------------

   public final void drawRenderedImage(RenderedImage img, 
                                       AffineTransform xform) {
      g.setColor(tDrawColor);
      delegate.drawRenderedImage(img, xform);
   } // of drawRenderedImage

   //-----------------------------------------------------------------

   public final void drawRenderableImage(RenderableImage img, 
                                         AffineTransform xform) {
      g.setColor(tDrawColor);
      delegate.drawRenderableImage(img, xform);
   } // of drawRenderableImage

   //-----------------------------------------------------------------

   public final void drawString(String s, float x, float y) {
      g.setColor(tFontColor);
      delegate.drawString(s, x, y);
   } // of drawString

   //-----------------------------------------------------------------

   public final void drawString(AttributedCharacterIterator iterator, 
                                int x, int y) {
      g.setColor(tFontColor);
      delegate.drawString(iterator, x, y);
   } // of drawString

   //-----------------------------------------------------------------

   public final void drawString(AttributedCharacterIterator iterator,
                                    float x, float y) {
      g.setColor(tFontColor);
      delegate.drawString(iterator, x, y);
   } // of drawString



   /**
    * Render a String respecting tokens such as newlines.
    * The string will be centered at the point passed in.
    *
    * @param str     is the String to render.
    * @param xx      is the origin for the angle and radius.
    * @param yy      is the origin for the angle and radius.
    */
   public void renderString(String str, int xx, int yy) {
      //// 1. Compute the width of the string.
      FontMetrics fmetric = getFontMetrics(getFont()); // current font metrics
      float       width;                               // width is variable
      float       height  = fmetric.getHeight()*0.75f; // height is constant, 
                                                       // the 0.8 is to tighten 
                                                       // leading

      //// 2. Tokenize the String, in case it has newlines and such.
      StringTokenizer strtok = new StringTokenizer(str, "\r\n\t");
      int             offset = 0;
      String          token;

      //// 3. Draw each token so that it is centered at pt.x and pt.y.
      yy = yy - (int) (((float) (strtok.countTokens() - 1) / 2) * height);
      while (strtok.hasMoreTokens()) {
         token = strtok.nextToken();
         width = fmetric.stringWidth(token);
         // Uncomment this only if using JDK1.4.
         // in 1.4, Y is a special case since it's 
         // extra-wide even though it says it isn't.
         /*if(token.equals("Y")) {
            drawString(token, (int) (xx - 0.7*width),
                              (int) (yy + 0.8*height) + offset);
         } else {*/
            drawString(token, (int) (xx - 0.5*width), 
                            (int) (yy + 0.8*height) + offset);
            //}
         offset += height;
      }

   } // of method

	public void renderStackedString(String str, int xx, int yy) {
      //// 1. Compute the width of the string.
      FontMetrics fmetric = getFontMetrics(getFont()); // current font metrics
      float       width;                               // width is variable
      float       height  = fmetric.getHeight()*0.75f; // height is constant, 
                                                       // the 0.8 is to 
                                                       // tighten leading

      //// 2. Tokenize the String, in case it has newlines and such.
      StringTokenizer strtok = new StringTokenizer(str, "\r\n\t");
      int             offset = 0;
      String          token;

      //// 3. Draw each token so that it is centered at pt.x and pt.y.
      yy = yy - (int) (((float) str.length() / 2) * height);
      while (strtok.hasMoreTokens()) {
         token = strtok.nextToken();
         width = fmetric.stringWidth(token);
         for (int i = 0; i < token.length(); i++) {
         	char hold[] = {'a'};
         	hold[0] = token.charAt(i);
         	String holder = new String(hold);
         	renderString(holder, xx, (int)(yy + 0.8*height + offset));
         	offset += height;
         }
      }

   } // of method

   //-----------------------------------------------------------------

   public final void fill(Shape s) {
      g.setColor(tFillColor);
      delegate.fill(s);
   } // of fill

   //===   DELEGATION GRAPHICS2D - DRAWING METHODS   ===========================
   //===========================================================================


   public void setIssuer(Object obj) {
   	mIssuer = obj;
   }
   
   public Object getIssuer() {
   	return mIssuer;
   }


   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      return(g.toString() + "\n" + stackTransform.toString());
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================




   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static final void main(String[] argv) {
      SatinGraphics g = new SatinGraphics();

      System.out.println(g.getOrigin());
      g.pushOrigin(new Point(3, 4));
      System.out.println(g.getOrigin());
      g.pushOrigin(new Point(5, 6));
      System.out.println(g.getOrigin());

   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class SatinGraphics

//===   SatinGraphics.java   ===================================================
//==============================================================================


/*

From experimentation, the Swing double buffer works well enough for what we
currently need.

   //===========================================================================
   //===   DOUBLE BUFFERING METHODS   ==========================================

   boolean flagUseDoubleBuffer = false;
   int     buf_x;
   int     buf_y;

   //===========================================================================

   public final void useDoubleBuffer() {
      flagUseDoubleBuffer = true;
   } // of useDoubleBuffer

   //===========================================================================

   public final void drawDoubleBuffer() {

      flagUseDoubleBuffer = false;
   } // of drawDoubleBuffer

   //===========================================================================

   public Point getDrawImagePosition() {
      return (new Point(buf_x, buf_y));
   } // of getDrawImagePosition

   //===========================================================================

   public BufferedImage getDoubleBufferImage() {
   } // of getDoubleBufferImage

   //===   DOUBLE BUFFERING METHODS   ==========================================
   //===========================================================================
*/


   //-----------------------------------------------------------------


   //// These are older implementations of pushTransform() and popTransform().
   //// These versions stored relative transforms, and would apply transforms
   //// and inverses. The newer version just stores the current transform,
   //// and can pop transforms off the stack without having to do an extra
   //// createInverse() operation.

   /**
    * Apply a new transform to this SatinGraphics context.
    *
    * @see   #popTransform()
    * @param tx is the AffineTransform to apply.
    */
/*
   public final void pushTransform(AffineTransform tx) {
      //// 1. Push the transform onto the stack.
      stackTransform.push(tx);

      //// 2. Apply the transform.
      g.transform(tx);
   } // of pushTransform
*/
   //-----------------------------------------------------------------

   /**
    * Undo the last transform.
    *
    * @see   #pushTransform(java.awt.geom.AffineTransform)
    */
/*
   public final void popTransform() {
      //// 1. Pop the last transform from the stack.
      AffineTransform tx = (AffineTransform) stackTransform.pop();
      AffineTransform inverse;

      //// 2. Invert the matrix. Unfortunately, nobody can be
      ////    told what the matrix is.
      try {
         inverse = tx.createInverse();
      }
      catch (Exception e) {
         debug.println("Could not invert matrix - serious error");
         inverse = new AffineTransform();
      }

      //// 2. Apply the transform.
      g.transform(inverse);
   } // of popTransform
*/


/*
   //// getTransform is already defined in Graphics2D.
   public AffineTransform getTransform() {
      AffineTransform tx = (AffineTransform) stackTransform.peek();
      return ((AffineTransform) tx.clone());
   } // of getTransform
*/



//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
