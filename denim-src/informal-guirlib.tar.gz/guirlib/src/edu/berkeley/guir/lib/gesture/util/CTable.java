// Chris's entension of JTable
//
// Inspired by the RowHeaderExample by Nobuo Tamemasa.
//
// known problems:
// - Doesn't enable/disable row header when table row selection is
//   enabled/disabled
// - Dragging on the list of row headers doesn't scroll the table.  (I
// - can't figure out a good way to catch list scrolling events.)
//

package edu.berkeley.guir.lib.gesture.util;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.*;
import java.lang.reflect.*;

public class CTable extends JTable {
  protected JList rowHeader;
  protected ListModel rowHeaderModel;
  
  // duplicate most of JTable's constructors for convenience
  
  public CTable()
  {
    this(null, null, null);
  }

  public CTable(int numRows, int numColumns)
  {
    super(numRows, numColumns);
    initUI();
  }

  public CTable(CTableModel dm)
  {
    super(dm);
    initUI();
  }

  public CTable(CTableModel dm, TableColumnModel cm)
  {
    super(dm, cm);
    initUI();
  }

  public CTable(CTableModel dm, TableColumnModel cm, ListSelectionModel sm)
  {
    super(dm, cm, sm);
    initUI();
  }

  protected void initUI()
  {
    buildRowHeaders();
  }
  
  protected TableModel createDefaultDataModel() {
    return new DefaultCTableModel();
  }

  protected void buildRowHeaders()
  {
    if (rowHeader == null) {
      rowHeaderModel = new AbstractListModel() {
	public int getSize() {
	  return (getModel() == null) ? 0 : getModel().getRowCount();
	}
	public Object getElementAt(int index) {
	  CTableModel dm = (CTableModel) getModel();
	  if (dm == null)
	    return null;
	  return dm.getRowName(index);
	}
      };

      rowHeader = new JList(rowHeaderModel);
      rowHeader.setSelectionModel(getSelectionModel());
      rowHeader.setFixedCellWidth(50);
      JTableHeader columnHeader = getTableHeader();
      rowHeader.setForeground(columnHeader.getForeground());
      rowHeader.setBackground(columnHeader.getBackground());
      rowHeader.setFont(columnHeader.getFont());
      
      rowHeader.setFixedCellHeight(getRowHeight() +
				   getRowMargin() /*+
				   getIntercellSpacing().height*/
				   );
      rowHeader.setCellRenderer(new RowHeaderRenderer());

      columnHeader.addPropertyChangeListener(new PropertyChangeListener() {
	public void propertyChange(PropertyChangeEvent event) {
	  try {
	    PropertyDescriptor propDesc =
	      new PropertyDescriptor(event.getPropertyName(), JList.class);
	    Method writeMethod = propDesc.getWriteMethod();
	    Object[] params = { event.getNewValue() };
	    writeMethod.invoke(rowHeader, params);
	  }
	  catch (Exception e) {
	    /* fail silently
	    System.err.println("Couldn't forward prop change for prop '" +
			       event.getPropertyName() + "':" + e);
			       */
	  }
	}
      });
    }
  }
  
  protected void configureEnclosingScrollPane()
  {
    super.configureEnclosingScrollPane();
    Container parent = getParent();
    if (parent instanceof JViewport) {
      Container grandParent = parent.getParent();
      if (grandParent instanceof JScrollPane) {
	JScrollPane scrollPane = (JScrollPane) grandParent;
	// Make certain we are the viewPort's view and not, for
	// example, the rowHeaderView of the scrollPane -
	// an implementor of fixed columns might do this.
	JViewport viewport = scrollPane.getViewport();
	if (viewport == null || viewport.getView() != this) {
	  return;
	}
	scrollPane.setRowHeaderView(rowHeader);
      }
    }
  }

  // convenience methods

  public String getRowName(int row)
  {
    return ((CTableModel) getModel()).getRowName(row);
  }
  
  class RowHeaderRenderer implements ListCellRenderer {

    Border border;
    Color foreground;
    Color background;
    Font font;
    
    RowHeaderRenderer() {
      JTableHeader header = CTable.this.getTableHeader();
      border = UIManager.getBorder("TableHeader.cellBorder");
      foreground = header.getForeground();
      background = header.getBackground();
      font = header.getFont();
    }
    
    public Component getListCellRendererComponent( JList list, 
						   Object value,
						   int index,
						   boolean isSelected,
						   boolean cellHasFocus) {
      Component result;
      if (value instanceof Component) {
	result = (Component) value;
      }
      else {
	JLabel label = new JLabel((value == null) ? "" : value.toString());
	label.setOpaque(true);
	label.setHorizontalAlignment(SwingConstants.CENTER);
	label.setForeground(foreground);
	label.setBackground(background);
	label.setBorder(border);
	label.setFont(font);
	result = label;
      }
      return result;
    }
  }

  public static void main(String[] args)
  {
    CTableModel tm = new DefaultCTableModel(5, 5);
    CTable t = new CTable(tm);
    JFrame f = new JFrame("CTable test");

    for (int i = 0; i < 5; i++) {
      tm.setRowName(i, "#" + i);
    }

    f.getContentPane().add(new JScrollPane(t));

    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });

    f.pack();
    f.show();
  }
}
