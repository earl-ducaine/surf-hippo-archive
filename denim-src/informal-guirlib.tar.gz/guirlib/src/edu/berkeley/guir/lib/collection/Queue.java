//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * A queue, can be either fixed-size or dynamically resizable.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Apr 09 2002 JIH
 */
public class Queue {

   //===========================================================================
   //===   INNER CLASSES   =====================================================

   public static class EmptyException extends RuntimeException {
   } // of inner class

   public static class FullException extends RuntimeException {
   } // of inner class

   //===   INNER CLASSES   =====================================================
   //===========================================================================




   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   private static int     defaultMaxLen        = 10;    // default maxlen
   private static boolean defaultFlagResizable = true;  // resizable?

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================




   //===========================================================================
   //===   FACTORY METHODS   ===================================================

   /**
    * Set the default maximum length.
    */
   public static void setDefaultMaxLen(int newMaxLen) {
       // assert newMaxLen >= 0;
       defaultMaxLen = newMaxLen;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set whether new instances of the queue are resizable or not.
    */
   public static void setDefaultResizable(boolean flag) {
       defaultFlagResizable = flag;
   } // of method

   //===   FACTORY METHODS   ===================================================
   //===========================================================================




   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   List    listElements  = new LinkedList();
   int     maxlen        = defaultMaxLen;
   boolean flagResizable = defaultFlagResizable;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructor to create a new queue. 
    */
   public Queue() {
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Constructor to create a fixed size queue.
    *
    * @param newMaxLen is the max length of the queue.
    */
   public Queue(int newMaxLen) {
       maxlen        = newMaxLen;
       flagResizable = false;
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   QUEUE ACCESSOR / MODIFIER METHODS   =================================

   public boolean isResizable() {
       return (flagResizable);
   } // of method


   public boolean isFixed() {
       return (!flagResizable);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Change the maximum length if and only if this is a fixed size queue.
    */
   public void setMaxLen(int newMaxLen) {
       if (isFixed() == true) {
           maxlen = newMaxLen;
       }
   } // of method


   /**
    * Get the maximum length for this queue. 
    *
    * @return the length, or Integer.MAX_VALUE if dynamically resizable.
    */
   public int getMaxLen() {
       if (isFixed() == true) {
           return (maxlen);
       }
       else {
           return (Integer.MAX_VALUE);
       }
   } // of method

   //-----------------------------------------------------------------

   public int size() {
      return (listElements.size());
   } // of method

   //-----------------------------------------------------------------

   public void clear() {
       listElements.clear();
   } // of method

   //-----------------------------------------------------------------

   /**
    * @throws FullException if the Queue is fixed size and is full.
    *         FullException extends RuntimeException. Avoid this 
    *         exception by checking isFull() first. 
    */
   public void enqueue( Object obj ) {
      if (isFull() == true) {
          throw new FullException();
      }
      listElements.add(obj);
   } // of method

   //-----------------------------------------------------------------

   /**
    * @throws EmptyException if the Queue is empty.
    *         EmptyException extends RuntimeException. Avoid this
    *         exception by checking isEmpty() first.
    */
   public Object dequeue() {
      if (isEmpty() == true) {
          throw new EmptyException();
      }
      return (listElements.remove(0));
   } // of method

   //-----------------------------------------------------------------

   public Object peek() {
      if (isEmpty() == true) {
         return (null);
      }
      return (listElements.get(0));
   } // of method

   //-----------------------------------------------------------------

   public boolean isEmpty() {
      return (listElements.size() <= 0);
   } // of method


   public boolean isFull() {
       if (isFixed() == true) {
           return (size() >= getMaxLen());
       }
       return (false);
   } // of method

   //===   QUEUE ACCESSOR / MODIFIER METHODS   =================================
   //===========================================================================




   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   public String toString() {
      StringBuffer strbuf = new StringBuffer("[");
      Iterator     it     = listElements.iterator();

      while (it.hasNext()) {
          strbuf.append(it.next().toString() + ", ");
      }

      strbuf.append("]");
      return (strbuf.toString());
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================




   //===========================================================================
   //===   MAIN   ==============================================================
/*
   public static void main(String[] argv) throws Exception {

      //// self-testing purposes
      Queue q = new Queue(3);

      q.enqueue(new Character('a'));
      q.enqueue(new Character('b'));
      q.enqueue(new Character('c'));
      System.out.println("q is     " + q);
      System.out.println("capacity " + q.getMaxLen());
      System.out.println("size is  " + q.size());
      System.out.println("full?    " + q.isFull());
      System.out.println("empty?   " + q.isEmpty());

      try {
      q.enqueue(new Character('d'));  // queue should resize here to capacity 6
                                      // queue now contains [a b c d]
      }
      catch (Exception e) {
          e.printStackTrace();
      }



      System.out.println("q is     " + q);
      System.out.println("capacity " + q.getMaxLen());
      System.out.println("size     " + q.size());
      System.out.println("full?    " + q.isFull());
      System.out.println("empty?   " + q.isEmpty());

      try {
          System.out.println(q.dequeue());
          System.out.println(q.dequeue());
          System.out.println(q.dequeue());
          System.out.println(q.dequeue()); // queue is now empty
      }
      catch (Exception e) {
          e.printStackTrace();
      }

      System.out.println("q is     " + q);
      System.out.println("capacity " + q.getMaxLen());
      System.out.println("size is  " + q.size());
      System.out.println("full?    " + q.isFull());
      System.out.println("empty?   " + q.isEmpty());

      System.out.println("-----");

      q = new Queue();

      q.enqueue(new Character('a'));
      q.enqueue(new Character('b'));
      q.enqueue(new Character('c'));
      q.enqueue(new Character('d'));
      q.enqueue(new Character('e'));

      System.out.println(q.dequeue()); // queue is now [b c d e]
      System.out.println();
      q.enqueue(new Character('f'));
      q.enqueue(new Character('g'));   // queue is now [b c d e f g]
      q.enqueue(new Character('h'));   // forces a resize
                                       // queue should be [b c d e f g h]
      System.out.println(q);
      System.out.println("capacity " + q.getMaxLen());
      System.out.println("size is  " + q.size());
      System.out.println("full?    " + q.isFull());
      System.out.println("empty?   " + q.isEmpty());

      q.clear();

      System.out.println("q is     " + q);
      System.out.println("capacity " + q.getMaxLen());
      System.out.println("size is  " + q.size());
      System.out.println("full?    " + q.isFull());
      System.out.println("empty?   " + q.isEmpty());

   } // of main
*/
   //===   MAIN   ==============================================================
   //===========================================================================

} // of Class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
