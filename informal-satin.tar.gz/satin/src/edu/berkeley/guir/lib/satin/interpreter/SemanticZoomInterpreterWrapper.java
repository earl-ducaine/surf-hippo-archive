//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter;

import edu.berkeley.guir.lib.util.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;

/**
 * Makes an interpreter work on certain scales only.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 30 1999, MN
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3RC1
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class SemanticZoomInterpreterWrapper
   extends InterpreterWrapper {

   //===========================================================================
   //===   CONSTANTS   =========================================================

           static final long serialVersionUID = -4734902309482390174L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private double startScale = 0;
   private double endScale   = Double.MAX_VALUE;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================
   


   //===========================================================================
   //===   CONSTRUCTOR   =======================================================
   
   /**
    * Empty constructor, does nothing.
    */
   public SemanticZoomInterpreterWrapper() {
      commonInitializations();
   } // of default constructor
   
   //-----------------------------------------------------------------

   /**
    *
    */
   public SemanticZoomInterpreterWrapper(Interpreter newintrp, 
                                         double startSc, double endSc) {
      setRange(startSc, endSc);
      setInterpreter(newintrp);
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Wrap an interpreter. By default, this semantic zoom wrapper is active
    * from zoom scale 0 to infinity.
    */
   public SemanticZoomInterpreterWrapper(Interpreter newintrp) {
      setInterpreter(newintrp);
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * A copy constructor, deep.
    */
   public SemanticZoomInterpreterWrapper(SemanticZoomInterpreterWrapper w) {
      this.setInterpreter((Interpreter) w.getInterpreter().clone());
      this.setRange(w.getStartScale(), w.getEndScale());
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Semantic Zoom Interpreter");
   } // of method

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   public void setRange(double start, double end) {
      this.startScale = start;
      this.endScale   = end;
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   public double getStartScale() {
      return (startScale);
   } // of method

   //-----------------------------------------------------------------

   public double getEndScale() {
      return (endScale);
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if we are currently enabled AND in a valid zoom range.
    */
   public boolean isEnabled() {
      double curscale = getAbsoluteScaleFactor();

      if (super.isEnabled() &&
          getStartScale() <= curscale && curscale <= getEndScale()) {
         return (true);
      }
      return (false);
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   STROKE METHODS   ====================================================

   protected double getAbsoluteScaleFactor() {
      return(GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                              getAttachedGraphicalObject()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Active if and only if we are in the right scale range.
    */
   public void handleNewStroke(NewStrokeEvent evt) {
      double curscale = getAbsoluteScaleFactor();
      if (getStartScale() <= curscale && curscale <= getEndScale()) {
         getInterpreter().handleNewStroke(evt);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Active if and only if we are in the right scale range.
    */
   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      double curscale = getAbsoluteScaleFactor();
      if (getStartScale() <= curscale && curscale <= getEndScale()) {
         getInterpreter().handleUpdateStroke(evt);
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Active if and only if we are in the right scale range.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      double curscale = getAbsoluteScaleFactor();
      if (getStartScale() <= curscale && curscale <= getEndScale()) {
         getInterpreter().handleSingleStroke(evt);
      }
   } // of method

   //===   STROKE METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new SemanticZoomInterpreterWrapper()));
   } // of method

   //-----------------------------------------------------------------

   protected SemanticZoomInterpreterWrapper
   clone(SemanticZoomInterpreterWrapper iw) {
      //// 1. Clone chain.
      super.clone(iw);

      //// 2. Do clone work.
      iw.startScale = this.startScale;
      iw.endScale   = this.endScale;

      //// 3. Return.
      return (iw);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 1. Append data.
      strbuf.append(super.toString());
      strbuf.append("\nContained Interpreter\n:");
      strbuf.append(StringLib.indent(getInterpreter().toString(), 3));

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
