package edu.berkeley.guir.lib.gesture.apps;

/*
 * prints delta x, y, and t at each point in each gesture
 * prints all dxs first, then all dys, then all dts, one line per gesture
 * each line begins with the name of the gesture class and the number
 * of output dxs, dys, or dts on that line.
 */

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.util.Misc;
import java.io.File;
import java.io.PrintStream;
import java.util.*;

public class coords {
  public final int SIGFIGS = 10;
  
  void printdx(PrintStream out, Gesture gesture)
  {
    TimedPolygon points = gesture.getPoints();

    out.print("\t" + (points.npoints-1));
    for (int i = 2; i < points.npoints; i++) {
      double dx = points.xpoints[i] - points.xpoints[i-1];
      out.print("\t" + Misc.toString(dx, SIGFIGS));
    }
  }

  void printdy(PrintStream out, Gesture gesture)
  {
    TimedPolygon points = gesture.getPoints();
    
    out.print("\t" + (points.npoints-1));
    for (int i = 2; i < points.npoints; i++) {
      double dy = points.ypoints[i] - points.ypoints[i-1];
      out.print("\t" + Misc.toString(dy, SIGFIGS));
    }
  }

  void printdt(PrintStream out, Gesture gesture)
  {
    TimedPolygon points = gesture.getPoints();
    
    out.print("\t" + (points.npoints-1));
    for (int i = 2; i < points.npoints; i++) {
      double dt = points.times[i] - points.times[i-1];
      out.print("\t" + Misc.toString(dt, SIGFIGS));
    }
  }

  public static void main(String[] argv)
  {
    if (argv.length != 1) {
      System.err.println("gav: usage: java coords gesturesetfile");
      System.exit(-1);
    }

    GestureSetFrame frame =
      new GestureSetFrame("coords", false);

    frame.openFile(new File(argv[0]));

    GestureSet gs = frame.getGestureSetDisplay().getGestureSet();
    coords dummy = new coords();
    dummy.printGSDeltas(System.out, gs);
    System.exit(0);
  }

  void printGSDeltas(PrintStream out, GestureSet gs)
  {
    List categories = gs.getCategories();
    Iterator it;
    
    for (it = categories.iterator(); it.hasNext();) {
      GestureCategory gc = (GestureCategory)it.next();
      Gesture g = gc.gestureAt(0);
      out.print(gc.getName());
      printdx(out, g);
      out.println();
    }
    for (it = categories.iterator(); it.hasNext();) {
      GestureCategory gc = (GestureCategory)it.next();
      Gesture g = gc.gestureAt(0);
      out.print(gc.getName());
      printdy(out, g);
      out.println();
    }
    for (it = categories.iterator(); it.hasNext();) {
      GestureCategory gc = (GestureCategory)it.next();
      Gesture g = gc.gestureAt(0);
      out.print(gc.getName());
      printdt(out, g);
      out.println();
    }
  }
}
