package edu.berkeley.guir.damask.command;

import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionGraph;
import edu.berkeley.guir.damask.dialog.*;

/**
 * A command that removes a template from a graph.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-07-2004 James Lin
 *                               Created CreatePageCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-07-2004
 */
public class RemoveTemplateCommand
   extends RemoveDialogCommand
   implements ModifyGraphCommand {

   private final InteractionGraph graph;   
   private final TemplateDialog template;

   private final Map/*<Page, List<Page>>*/ pagesWithTemplate = new HashMap();

   /**
    * Constructs the command.
    *  
    * @param dialog the dialog to remove
    */      
   public RemoveTemplateCommand(final TemplateDialog template) {
      super(template);
      this.graph = template.getInteractionGraph();
      this.template = template;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Remove template " + template;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   
   // Overrides method in superclass.   
   public void run() {
      saveConnections();

      pagesWithTemplate.clear();

      // If any page has the specified template as a template, save
      // those pages for undo. The templates will be removed from those
      // pages in InteractionGraph.removeTemplate().
      for (Iterator i = graph.getDialogs().iterator(); i.hasNext();) {
         final Dialog dialog = (Dialog)i.next();
         for (Iterator j = dialog.getDeviceTypesVisibleTo().iterator();
            j.hasNext();
            ) {
            final DeviceType deviceType = (DeviceType)j.next();
            for (Iterator k = dialog.getPages(deviceType).iterator();
               k.hasNext();
               ) {
               final Page page = (Page)k.next();
               for (Iterator m = page.getTemplates().iterator();
                  m.hasNext();
                  ) {
                  final Page pageTemplate = (Page)m.next();
                  if (pageTemplate.getDialog() == template) {
                     List/*<Page>*/ removedTemplates =
                        (List)pagesWithTemplate.get(page);
                     if (removedTemplates == null) {
                        removedTemplates = new ArrayList();
                        pagesWithTemplate.put(page, removedTemplates); 
                     }
                     removedTemplates.add(pageTemplate);
                  }
               }
            }
         }
      }

      graph.removeTemplate(template);
   }


   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      graph.addTemplate(template);
      restoreConnections();
      
      // Restore pages that had this template.
      for (Iterator i = pagesWithTemplate.keySet().iterator(); i.hasNext(); ) {
         final Page page = (Page)i.next();
         final List/*<Page>*/ templates = (List)pagesWithTemplate.get(page);
         for (Iterator j = templates.iterator(); j.hasNext(); ) {
            final Page template = (Page)j.next();
            page.addTemplate(template);
         }
      }
   }
}
