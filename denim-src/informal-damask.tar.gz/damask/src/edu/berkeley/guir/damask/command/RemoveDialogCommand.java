package edu.berkeley.guir.damask.command;

import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.*;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that removes a dialog and its pages from a graph.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-07-2004 James Lin
 *                               Created CreatePageCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-07-2004
 */
public class RemoveDialogCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final InteractionGraph graph;   
   private final Dialog dialog;
   private final Map/*<DeviceType, Page>*/ oldHomePages =
      new HashMap/*<DeviceType, Page>*/();

   private final Set/*<ConnectionInfo>*/ connectionInfos = new HashSet();
   private final Map/*<Trigger, Content>*/ origInNavConnectionTriggers =
      new HashMap();

   /**
    * Constructs the command.
    *  
    * @param dialog the dialog to remove
    */      
   public RemoveDialogCommand(final Dialog dialog) {
      this.graph = dialog.getInteractionGraph();
      this.dialog = dialog;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Remove dialog " + dialog;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }


   /**
    * Saves info on connections to and from the dialog to be removed,
    * to be used in undo.
    */
   protected void saveConnections() {
      connectionInfos.clear();
      origInNavConnectionTriggers.clear();
      
      final Set/*<Connection>*/ connections = new HashSet();
      
      for (Iterator i = dialog.getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType deviceType = (DeviceType)i.next();
         for (Iterator j = dialog.getPages(deviceType).iterator();
            j.hasNext(); ) {
               
            final Page page = (Page)j.next();
      
            for (Iterator k = page.getInConnections().iterator();
               k.hasNext(); ) {
            
               final Connection connection = (Connection)k.next();
               connections.add(connection);
               connectionInfos.add(new ConnectionInfo(connection));
               
               // Keep track of the source of the connection if it's a hyperlink
               if (connection instanceof NavConnection) {
                  final Control source =
                     (Control)connection.getConnectionSource(deviceType);
                  if (source instanceof Trigger) {
                     final Trigger trigger = (Trigger)source;
                     if (trigger.getStyle(deviceType) == Trigger.HYPERLINK) {
                        origInNavConnectionTriggers.put(trigger, null);
                     }
                  }
               }
            }
      
            for (Iterator k = page.getOutConnections().iterator();
               k.hasNext(); ) {
            
               final OrgConnection connection = (OrgConnection)k.next();
               connections.add(connection);
               connectionInfos.add(new ConnectionInfo(connection));
            }
            
            for (Iterator k = page.getRegions().iterator(); k.hasNext(); ) {
               final PageRegion region = (PageRegion)k.next();
               for (Iterator m = region.getControls().iterator(); m.hasNext();){
                  final Control control = (Control)m.next();
      
                  for (Iterator n = control.getInConnections().iterator();
                     n.hasNext(); ) {
            
                     final NavConnection connection = (NavConnection)n.next();
                     connections.add(connection);
                     connectionInfos.add(new ConnectionInfo(connection));
                  }
      
                  for (Iterator n = control.getOutConnections().iterator();
                     n.hasNext(); ) {
            
                     final NavConnection connection = (NavConnection)n.next();
                     connections.add(connection);
                     connectionInfos.add(new ConnectionInfo(connection));
                  }
               }
            }
         }
      }
      
      // Remove the connections
      for (Iterator i = connections.iterator(); i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         connection.getInteractionGraph().remove(connection);
         connection.dispose();
      }
      
      // Convert orphaned links to labels
      for (Iterator i = origInNavConnectionTriggers.keySet().iterator();
         i.hasNext();
         ) {
         final Trigger source = (Trigger)i.next();
         final Content sourceContent = (Content)source.getContent().clone();
         origInNavConnectionTriggers.put(source, sourceContent);
      
         for (Iterator j = source.getDeviceTypesVisibleTo().iterator();
            j.hasNext();
            ) {
      
            final DeviceType aDeviceType = (DeviceType)j.next();
      
            sourceContent.setBounds(aDeviceType, source.getBounds(aDeviceType));
            sourceContent.setTransform(
               aDeviceType,
               source.getTransform(aDeviceType));
         }
      
         source.getDialog().addControlAfter(
            source,
            sourceContent);
         source.getDialog().removeControl(source);
      }
   }
   

   /**
    * Restores the connections and links that were saved in saveConnections().
    */
   protected void restoreConnections() {
      // Convert labels that were links back to links.
      for (Iterator i = origInNavConnectionTriggers.keySet().iterator();
         i.hasNext();
         ) {
         final Trigger source = (Trigger)i.next();
         final Content sourceContent =
            (Content)origInNavConnectionTriggers.get(source);
      
         sourceContent.getDialog().addControlAfter(
            sourceContent,
            source);
         sourceContent.getDialog().removeControl(sourceContent);
      }
      
      // Restore connections that were originally to and from this dialog.
      for (Iterator i = connectionInfos.iterator(); i.hasNext(); ) {
         final ConnectionInfo connectionInfo = (ConnectionInfo)i.next();
         final Connection connection = connectionInfo.createConnection();
         graph.add(connection);
      }
   }

   
   // Overrides method in superclass.   
   public void run() {
      saveConnections();
      
      for (Iterator i = Damask.getSupportedDeviceTypes().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         final Page homePage = graph.getHomePage(aDeviceType);
         if (homePage != null && homePage.getDialog() == dialog) {
            oldHomePages.put(aDeviceType, homePage);
         }
      }
      
      graph.remove(dialog);
   }


   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      graph.add(dialog);
      restoreConnections();
      
      for (Iterator i = Damask.getSupportedDeviceTypes().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         final Page oldHomePage = (Page)oldHomePages.get(aDeviceType);
         if (oldHomePage != null) {
            graph.setHomePage(aDeviceType, oldHomePage);
         }
      }
   }
}
