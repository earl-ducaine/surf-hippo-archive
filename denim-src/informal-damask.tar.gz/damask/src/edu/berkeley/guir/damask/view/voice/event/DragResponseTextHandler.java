package edu.berkeley.guir.damask.view.voice.event;

import java.awt.event.InputEvent;
import java.awt.geom.*;

import edu.berkeley.guir.damask.command.SetVoiceResponseLineCommand;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.DamaskCanvas;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.*;
import edu.umd.cs.piccolo.util.PDimension;

/** 
 * The event handler that handles moving a response if both ends are not
 * anchored.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  12-24-2004 James Lin
 *                               Created DragResponseTextHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 12-24-2004
 */
public class DragResponseTextHandler extends PDragSequenceEventHandler {
   
   private Point2D origStartPt = null;
   private Point2D origEndPt = null;
   private Point2D startDragPt = null;
   private Line2D line = new Line2D.Double();
   
   private Response.TextGroup textGroup = null;
   private Response response = null;
   
   /**
    * Constructs a handler which will instantiate a component of the specified
    * type.
    * 
    * @param componentViewType a class which is a descendant of
    * {@link edu.berkeley.guir.damask.view.visual.component.ComponentView}
    */
   public DragResponseTextHandler() {
      setEventFilter(new PInputEventFilter(InputEvent.BUTTON1_MASK));
   }

   
   /**
    * Returns whether the associated response can be dragged.
    */
   private boolean shouldDrag() {
      return !(textGroup == null ||
               response.getSource() != null ||
               response.getDest() != null);
   }

   private void updateLine(PInputEvent e) {
      final Point2D dragPt = e.getPositionRelativeTo(response);
      final Dimension2D delta =
         new PDimension(
            dragPt.getX() - startDragPt.getX(),
            dragPt.getY() - startDragPt.getY());
      final Point2D newStartPt =
         new Point2D.Double(
            origStartPt.getX() + delta.getWidth(),
            origStartPt.getY() + delta.getHeight());
      final Point2D newEndPt =
         new Point2D.Double(
            origEndPt.getX() + delta.getWidth(),
            origEndPt.getY() + delta.getHeight());
         
      line.setLine(newStartPt, newEndPt);
      response.updateArrow(line);
   }

   
   // @Override
   public void startDrag(PInputEvent e) {
      super.startDrag(e);
      
      ((DamaskCanvas)e.getComponent()).stopTextEditing();
      
      final PNode startNode = e.getPickedNode(); 
      textGroup =
         (Response.TextGroup)DamaskAppUtils.getAncestor(
            startNode, Response.TextGroup.class);
      if (textGroup == null) {
         response = null;
      }
      else {
         response = textGroup.getResponse();
      }
      
      if (!shouldDrag()) {
         return;
      }
      
      startDragPt = e.getPositionRelativeTo(response);
      
      origStartPt =
         response.globalToLocal(
            response.getStartHotSpot().localToGlobal(
               response.getStartHotSpot().getBounds().getCenter2D()));
      
      origEndPt =
         response.globalToLocal(
            response.getEndHotSpot().localToGlobal(
               response.getEndHotSpot().getBounds().getCenter2D()));
   }


   // @Override
   public void drag(final PInputEvent e) {
      super.drag(e);
      if (!shouldDrag()) {
         return;
      }
      
      updateLine(e);
   }

   // @Override
   public void endDrag(final PInputEvent e) {
      super.endDrag(e);
      if (!shouldDrag()) {
         return;
      }
      updateLine(e);

      final DamaskCanvas canvas = (DamaskCanvas)e.getComponent();

      canvas.getDocument().getCommandQueue().doCommand(
         canvas, new SetVoiceResponseLineCommand(
            (Control)response.getModel(),
            response.getForm().getDesignTimeCondition(),
            line));
   }  
}
