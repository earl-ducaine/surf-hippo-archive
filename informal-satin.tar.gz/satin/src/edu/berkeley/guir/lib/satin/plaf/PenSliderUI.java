//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.plaf;

import javax.swing.*;
import javax.swing.plaf.metal.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

/**
 * A Pen Look-and-Feel that has the following features:
 * <UL>
 *    <LI>A larger thumb value, making it easier to hit it.
 *    <LI>Direct set, where the value of the slider is set by the location
 *        of the mouse, instead of being scrolled. This is particularly
 *        effective if you also call {@link JSlider#setMajorTickSpacing(int)}, 
 *        and {@link JSlider#setSnapToTicks(boolean)}, making the thumb snap 
 *        to the value nearest to where you clicked.
 *    <LI>Fixes keyboard access for sliders with major ticks, which lets you 
 *        use the arrow keys, as well as the PageUp and PageDown keys, to 
 *        correctly adjust slider values. The current Swing implementation does
 *        not do this correctly.
 * </UL>
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 25 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class PenSliderUI 
   extends MetalSliderUI {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   JSlider             slider;
   SliderMouseListener mlstnr;
   SliderKeyListener   klstnr;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   KEY LISTENER INNER CLASS   ==========================================

   /**
    * Currently not used...
    */
   class SliderKeyListener implements KeyListener {

      public void keyPressed(KeyEvent evt) {
         //// 1. Figure out which direction to go - increasing or decreasing.
         int val = 1;
         if (slider.getInverted() == true) {
            val = -1;
         }

         switch (evt.getKeyCode()) {
            case KeyEvent.VK_UP:         
            case KeyEvent.VK_RIGHT:      
            case KeyEvent.VK_PAGE_UP:    scroll(val);  break;

            case KeyEvent.VK_DOWN:       
            case KeyEvent.VK_LEFT:       
            case KeyEvent.VK_PAGE_DOWN:  scroll(-val); break;
         }
      } // of keyPressed

      public void keyReleased(KeyEvent evt) {
      } // of keyReleased

      public void keyTyped(KeyEvent evt) {
      } // of keyTyped

   } // of SliderKeyListener 

   //===   KEY LISTENER INNER CLASS   ==========================================
   //===========================================================================



   //===========================================================================
   //===   MOUSE LISTENER INNER CLASS   ========================================

   /**
    * Listens to mouse events on slider and sets the slider value to wherever
    * you dragged or pressed.
    */
   class SliderMouseListener implements MouseListener, MouseMotionListener {

      private void calculatePercentage(MouseEvent evt) {
         int       min    = slider.getMinimum();
         int       max    = slider.getMaximum();
         Rectangle bounds = slider.getBounds();
         double    percent;

         slider.setValueIsAdjusting(true);

         if (slider.getOrientation() == JSlider.VERTICAL) {
            int y1 = bounds.y;
            int y2 = bounds.y + bounds.height;
            percent = ((double) (evt.getY() - y1)) / (y2 - y1);
         }
         else {
            int x1 = bounds.x;
            int x2 = bounds.x + bounds.width;
            percent = 1 - ((double) (evt.getX() - x1)) / (x2 - x1);
         }

         if (slider.getInverted() == false) {
            percent = 1 - percent;
         }

         slider.setValueIsAdjusting(false);

         slider.setValue((int) (percent * (max - min)));
      } // of calculatePercentage

      //--------------------------------------------------------------

      /**
       * Pens can never do click correctly...
       */
      public void mouseReleased(MouseEvent evt) { 
         calculatePercentage(evt);
      } // of mouseReleased

      //--------------------------------------------------------------

      public void mouseEntered(MouseEvent evt)  { }
      public void mouseExited(MouseEvent evt)   { }
      public void mouseMoved(MouseEvent evt)    { }
      public void mouseClicked(MouseEvent evt)  { }
      public void mousePressed(MouseEvent evt)  { }
      public void mouseDragged(MouseEvent evt)  { }

   } // of SliderMouseListener 

   //===   MOUSE LISTENER INNER CLASS   ========================================
   //===========================================================================



   //===========================================================================
   //===   LOOK-AND-FEEL METHODS   =============================================

   /**
    * @param direction is positive if scrolling is increasing the value.
    */
   private void scroll(int direction) {
      int oldValue = slider.getValue();
      int delta    = 0;

      if (slider.getSnapToTicks()) {
         delta = slider.getMajorTickSpacing();
      }
      else {
         delta = slider.getMinorTickSpacing();
      }

      if (direction < 0) {
         delta *= -1;
      }

      slider.setValue(oldValue + delta);
   } // of scroll

   //===========================================================================

   public void installUI(JComponent c) {
      super.installUI(c);

      mlstnr = new SliderMouseListener();
      klstnr = new SliderKeyListener();

      slider = (JSlider) c;
      slider.addMouseListener(mlstnr);
      slider.addMouseMotionListener(mlstnr);
   } // of installUI

   //-----------------------------------------------------------------

   public void uninstallUI(JComponent c) {
      super.uninstallUI(c);

      slider.removeMouseListener(mlstnr);
      slider.removeMouseMotionListener(mlstnr);
   } // of uninstallUI

   //===========================================================================

   public void paintThumb(Graphics g) {
      Graphics2D graphics = (Graphics2D) g;

      graphics.translate( thumbRect.x, thumbRect.y );
      graphics.transform(AffineTransform.getScaleInstance(2, 2));

      if ( slider.getOrientation() == JSlider.HORIZONTAL ) {
         horizThumbIcon.paintIcon(slider, g, 1, 0);
      }
      else {
         vertThumbIcon.paintIcon(slider, g, 0, 1);
      }

      graphics.transform(AffineTransform.getScaleInstance(0.5, 0.5));
      graphics.translate( -thumbRect.x, -thumbRect.y );
   } // of paintThumb

   //===========================================================================

   protected Dimension getThumbSize() {
      Dimension size = super.getThumbSize();
      size.width  = 2*size.width  + 2;
      size.height = 2*size.height + 2;
      return (size);
   } // of getThumbSize

   //===   LOOK-AND-FEEL METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================

   public static void main(String[] argv) throws Exception {
      JFrame  f      = new JFrame();
      JPanel  p      = new JPanel();
      JSlider slider;

      slider = new JSlider();
      p.add(slider);
      slider.setUI(new PenSliderUI());
      slider.setPaintTicks(true);
      slider.setInverted(true);

      slider = new JSlider();
      p.add(slider);
      slider.setUI(new PenSliderUI());
      slider.setOrientation(JSlider.VERTICAL);
      slider.setSnapToTicks(true);
      slider.setMajorTickSpacing(25);
      slider.setPaintTicks(true);
      slider.setInverted(true);

      f.getContentPane().add(p);

      f.setSize(300, 300);
      f.setVisible(true);
   } // of main

   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
