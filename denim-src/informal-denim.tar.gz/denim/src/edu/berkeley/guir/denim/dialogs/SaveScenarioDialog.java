 package edu.berkeley.guir.denim.dialogs;

import edu.berkeley.guir.denim.*;
import javax.swing.*;
import javax.swing.text.*;
import java.beans.*; //Property change stuff
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * Dialog box that asks user to insert typed text.
 *
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  05-08-1999 Benson Limketkai
 *                               Created SaveScenarioDialog
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 04-30-1999
 */
public class SaveScenarioDialog extends JDialog {
   private JOptionPane     optionPane;
   private String          typedText = null;

   private static final int DEFAULT_WIDTH = 420;
   private static final int DEFAULT_HEIGHT = 200;

   //------------------------------------------------------------------

   public SaveScenarioDialog(Frame parent, DenimSheet sheet) {
      super(parent, true);
      commonInitializations(sheet.getScenarioNames());
   }

   //------------------------------------------------------------------

   private void commonInitializations(Set scenarioNames) {
      setResizable(false);
      setBounds(320, 480, DEFAULT_WIDTH, DEFAULT_HEIGHT);
      setTitle("Save Scenario");

      final JList listArea = new JList(scenarioNames.toArray());
      final JScrollPane areaScrollPane = new JScrollPane(listArea);
      areaScrollPane.setVerticalScrollBarPolicy
         (JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
      areaScrollPane.setHorizontalScrollBarPolicy
         (JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      areaScrollPane.setPreferredSize(new Dimension(250, 100));

      //        final JTextArea textPanel = new JTextArea("Untitled", 1, 20);
      final JTextField textPanel = new JTextField("Untitled", 20);
      KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
      Keymap map = textPanel.getKeymap();
      map.removeKeyStrokeBinding(enter);

      JLabel saveAsLabel = new JLabel("Save As:");

      JPanel inputForm = new JPanel(new BorderLayout());
      inputForm.setPreferredSize(new Dimension(50, 100));
      inputForm.add(areaScrollPane, BorderLayout.CENTER);

      GridBagLayout gridbag = new GridBagLayout();
      GridBagConstraints c = new GridBagConstraints();
      JPanel p = new JPanel(gridbag);

      c.fill = GridBagConstraints.HORIZONTAL;
      c.weightx=1.0;
      gridbag.setConstraints(saveAsLabel, c);
      p.add(saveAsLabel);
      c.gridwidth = GridBagConstraints.REMAINDER;
      c.weightx=1.5;
      gridbag.setConstraints(textPanel, c);
      p.add(textPanel);

      inputForm.add(p, BorderLayout.SOUTH);
      Object[] array = {"Existing Scenarios:", inputForm};

      final String btnString1 = "Save";
      final String btnString2 = "Cancel";
      Object[] options = {btnString1, btnString2};

      optionPane = new JOptionPane(array,
                                   JOptionPane.QUESTION_MESSAGE,
                                   JOptionPane.YES_NO_OPTION,
                                   null,
                                   options,
                                   options[0]);
      setContentPane(optionPane);
      setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
      addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent we) {
         /*
         * Instead of directly closing the window,
         * we're going to change the JOptionPane's
         * value property.
         */
         optionPane.setValue(new Integer(JOptionPane.CLOSED_OPTION));
         }
         });

      MouseListener mouseListener = new MouseAdapter() {
         public void mouseClicked(MouseEvent e) {
            if (e.getClickCount() == 2) {
               typedText = (String)listArea.getSelectedValue();
               textPanel.setText(typedText);
            }
         }
      };

      listArea.addMouseListener(mouseListener);

      optionPane.addPropertyChangeListener(new PropertyChangeListener() {
         public void propertyChange(PropertyChangeEvent e) {
            String prop = e.getPropertyName();

            if (isVisible()
            && (e.getSource() == optionPane)
            && (prop.equals(JOptionPane.VALUE_PROPERTY) ||
            prop.equals(JOptionPane.INPUT_VALUE_PROPERTY))) {
               Object value = optionPane.getValue();

               if (value == JOptionPane.UNINITIALIZED_VALUE) {
                  //ignore reset
                  return;
               }

               // Reset the JOptionPane's value.
               // If you don't do this, then if the user
               // presses the same button next time, no
               // property change event will be fired.
               optionPane.setValue(JOptionPane.UNINITIALIZED_VALUE);

               if (value.equals(btnString1)) {
                  typedText = textPanel.getText();
                  setVisible(false);
               }
               else { // user closed dialog or clicked cancel
                  typedText = null;
                  setVisible(false);
               }
            }
         }
      });
   }

   //------------------------------------------------------------------

   public String getText() {
      return typedText;
   }
}

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
