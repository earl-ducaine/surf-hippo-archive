package edu.berkeley.guir.lib.gesture.features;

import edu.berkeley.guir.lib.gesture.Feature;
import edu.berkeley.guir.lib.gesture.Gesture;

public class Density2 extends Feature {
  public Density2()
  {
    super();
  }

  public Density2(Gesture g)
  {
    super(g);
  }

  public String getName()
  {
    // todo
    return "density2 (length/bounding box diagonal)";
  }
  
  public double getMinValue()
  {
    return Double.MIN_VALUE;
  }
  
  public double getMaxValue()
  {
    return Double.MAX_VALUE;
  }
  
  protected void computeValue()
  {
    double totalLength = new TotalLength(gesture).getValue();
    double boundsSize = new BoundsSize(gesture).getValue();

    value = totalLength / boundsSize;
    valueOk = true;
  }

  public void scale(double factor)
  {
  }
}
