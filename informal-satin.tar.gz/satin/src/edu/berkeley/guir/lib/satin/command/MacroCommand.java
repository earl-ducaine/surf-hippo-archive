//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import java.util.*;

/**
 * A collection of commands.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 12 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class MacroCommand
   extends CommandImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 5051203481188186715L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private List vecCommands = new ArrayList();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructor.
    */
   public MacroCommand() {
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MACRO COMMANDS   ====================================================

   /**
    * Add a command to this macro.
    *
    * @param cmd is the Command to add.
    */
   public void addCommand(Command cmd) {
      vecCommands.add(cmd);
   } // of addCommand

   //===========================================================================

   /**
    * Remove a command from this macro.
    *
    * @param cmd is the Command to remove.
    */
   public void removeCommand(Command cmd) {
      vecCommands.remove(cmd);
   } // of removeCommand

   //===========================================================================

   /**
    * Clear all commands from this macro.
    */
   public void clearCommands() {
      vecCommands.clear();
   } // of clearCommands

   //===   MACRO COMMANDS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   NAME ACCESSOR METHODS   =============================================

   public String getPresentationName() {
      //// 1. Concatenate all of the other presentation names.
      StringBuffer strbuf = new StringBuffer();
      Command      cmd;

      strbuf.append("[");
      for (Iterator i = vecCommands.iterator(); i.hasNext(); ) {
         cmd = (Command) i.next();
         strbuf.append(cmd.getPresentationName() + ", ");
      }
      strbuf.append("]");

      //// 2. Append and return.
      return ("Macro Command " + strbuf.toString());
   } // of getPresentationName

   //===========================================================================

   public String getRedoPresentationName() {
      //// 1. Concatenate all of the other presentation names.
      StringBuffer strbuf = new StringBuffer();
      Command      cmd;

      strbuf.append("[");
      for (Iterator i = vecCommands.iterator(); i.hasNext(); ) {
         cmd = (Command) i.next();
         strbuf.append(cmd.getRedoPresentationName() + ", ");
      }
      strbuf.append("]");

      //// 2. Append and return.
      return ("Redo Macro Command " + strbuf.toString());
   } // of getRedoPresentationName

   //===========================================================================

   public String getUndoPresentationName() {
      //// 1. Concatenate all of the other presentation names.
      StringBuffer strbuf = new StringBuffer();
      Command      cmd;

      strbuf.append("[");
      for (Iterator i = vecCommands.iterator(); i.hasNext(); ) {
         cmd = (Command) i.next();
         strbuf.append(cmd.getUndoPresentationName() + ", ");
      }
      strbuf.append("]");

      //// 2. Append and return.
      return ("Undo Macro Command " + strbuf.toString());
   } // of getUndoPresentationName

   //===   NAME ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   STATUS ACCESSOR METHODS   ===========================================

   public boolean canRedo() {
      return (true);
   } // of canRedo

   //===========================================================================

   public boolean canUndo() {
      return (true);
   } // of canUndo

   //===========================================================================

   public boolean isSignificant() {
      return (true);
   } // of isSignificant

   //===========================================================================

   /**
    * Returns true if this macro command contains no commands.
    */
   public boolean isEmpty() {
      return vecCommands.isEmpty();
   }

   //===   STATUS ACCESSOR METHODS   ===========================================
   //===========================================================================



   //===========================================================================
   //===   ACTION METHODS   ====================================================

   public void run() {
      //// 1. Iterate across all commands in order and execute them.
      for (Iterator i = vecCommands.iterator(); i.hasNext(); ) {
         Command cmd = (Command) i.next();
         cmd.execute();
      }
   } // of run

   //===========================================================================

   public void redo() {
      //// 1. Iterate across all commands in order and execute them.
      for (Iterator i = vecCommands.iterator(); i.hasNext(); ) {
         Command cmd = (Command) i.next();
         cmd.redo();
      }
   } // of redo

   //===========================================================================

   public void undo() {
      //// 1. Iterate across all commands in reverse order and undo them.
      int size = vecCommands.size();
      for (ListIterator i = vecCommands.listIterator(size); i.hasPrevious(); ) {
         Command cmd = (Command) i.previous();
         cmd.undo();
      }
   } // of undo

   //===========================================================================

   public void die() {
   } // of die

   //===   ACTION METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
