package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.toolbox.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.plaf.*;
import edu.berkeley.guir.lib.satin.widgets.ExtensionFileFilter;
import edu.berkeley.guir.lib.debugging.*;
import java.util.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

import javax.swing.*;
import javax.swing.event.*;

/**
 * The zoom slider on the left hand side of the DENIM window. Due to Java
 * Swing's architecture, the zoom slider also listens to all keyboard presses.
 *
 * <PRE>
 * Revisions:  2.0.3  05-15-2003 YL
 *                    Disable Animation when running on Mac
 *             2.0.3  12-17-2002 YL
 *                    Introduced zoomingInstance for Speeding up zooming
 *                    Enable fading out&in of arrows before&after zooming
 * 			   2.0.2  07-17-2000 JH
 *                    Dragging of zoom slider now ignored properly.
 *             2.0.1  07-10-2000 JH
 *                    Moved the F1-Help key code to here
 *             2.0.0  03-25-2000 JH
 *                    Fixed the most-zoomed-out levels to find the center
 *                       of all objects and zoom there (to fix "desert fog")
 *                    Switched from equation-based zoom level to
 *                       constant-based lookup.
 *             1.1.0  03-14-2000 JH
 *                    Fixed the automatic GOb recentering behavior
 *                    Added recenter behavior by tapping on the elevator
 *                    Fixed the automatic deselect on zoom-in behavior
 *             1.0.0  08-05-1999 JL
 *                    Created
 * 
 * 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * 
 * @since   JDK 1.2
 * @version Version 2.0.3, 05-15-2003
 */
public class ZoomSlider
   extends    JSlider
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID   = 1520980991944002749L;
   private static final int   NUMFRAMES = 8;

   //===   CONSTANTS   =========================================================
   //===========================================================================

   public static int zoomingInstance = 0;

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   //// True if Denim animates the zoom
   private boolean    flagAnimateZoom = true;


   //// Zoom values
   private Hashtable  labelTable;

   //// Labels on the zoom slider
   private JLabel     topLabel;
   private JLabel     sitemapLabel;
   private JLabel     storyboardLabel;
   private JLabel     sketchLabel;
   private JLabel     magLabel;
   private JLabel     tickLabel;

   //// Reference to the sheet we are attached to
   private DenimSheet sheet;

   //// slider inner class variables
   private int     lastSliderValue;
   private boolean flagCenterTo = false;
   private int     x;
   private int     y;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs the zoom slider. The parameters are the same as for
    * {@link javax.swing.JSlider}'s constructor.
    */
   public ZoomSlider(int orientation, int min, int max, int value) {
      super(orientation, min, max, value);

      Icon topLabelIcon         = null;
      Icon sitemapLabelIcon     = null;
      Icon storyboardLabelIcon  = null;
      Icon sketchLabelIcon      = null;
      Icon magLabelIcon         = null;
      Icon tickIcon             = null;


      //// try the local disk first...
      try {
         String baseFile = "images/slider/";

         topLabelIcon        = new ImageIcon(Denim.class.getResource
               (baseFile + "topLabel.gif"));
         sitemapLabelIcon    = new ImageIcon(Denim.class.getResource
               (baseFile + "sitemapLabel.gif"));
         storyboardLabelIcon = new ImageIcon(Denim.class.getResource
               (baseFile + "storyboardLabel.gif"));
         sketchLabelIcon     = new ImageIcon(Denim.class.getResource
               (baseFile + "sketchLabel.gif"));
         magLabelIcon        = new ImageIcon(Denim.class.getResource
               (baseFile + "magLabel.gif"));
         tickIcon            = new ImageIcon(Denim.class.getResource
               (baseFile + "tick.gif"));
      }
      catch (Exception e) {
         Debug.println(e);
      }

      //// try the network now...
      try {
         URL topLabelIconURL;
         URL sitemapLabelIconURL;
         URL storyboardLabelIconURL;
         URL sketchLabelIconURL;
         URL magLabelIconURL;
         URL tickIconURL;
         String baseURL =
                "http://guir.berkeley.edu/projects/denim/icons/slider/";

         if (topLabelIcon == null) {
            topLabelIconURL        = new URL(baseURL + "topLabel.gif");
            topLabelIcon           = new ImageIcon(topLabelIconURL);
            Debug.println("loading icon from web - " + topLabelIconURL);
         }

         if (sitemapLabelIcon == null) {
            sitemapLabelIconURL    = new URL(baseURL + "sitemapLabel.gif");
            sitemapLabelIcon       = new ImageIcon(sitemapLabelIconURL);
            Debug.println("loading icon from web - " + sitemapLabelIconURL);
         }

         if (storyboardLabelIcon == null) {
            storyboardLabelIconURL = new URL(baseURL + "storyboardLabel.gif");
            storyboardLabelIcon    = new ImageIcon(storyboardLabelIconURL);
            Debug.println("loading icon from web - " + storyboardLabelIconURL);
         }

         if (sketchLabelIcon == null) {
            sketchLabelIconURL     = new URL(baseURL + "sketchLabel.gif");
            sketchLabelIcon        = new ImageIcon(sketchLabelIconURL);
            Debug.println("loading icon from web - " + sketchLabelIconURL);
         }

         if (magLabelIcon == null) {
            magLabelIconURL        = new URL(baseURL + "magLabel.gif");
            magLabelIcon           = new ImageIcon(magLabelIconURL);
            Debug.println("loading icon from web - " + magLabelIconURL);
         }

         if (tickIcon == null) {
            tickIconURL            = new URL(baseURL + "tick.gif");
            tickIcon               = new ImageIcon(tickIconURL);
            Debug.println("loading icon from web - " + tickIconURL);
         }
      }
      catch (Exception e) {
         Debug.println(e);
      }

      //// load up the labels...
      topLabel               = new JLabel(topLabelIcon);
      sitemapLabel           = new JLabel(sitemapLabelIcon);
      storyboardLabel        = new JLabel(storyboardLabelIcon);
      sketchLabel            = new JLabel(sketchLabelIcon);
      magLabel               = new JLabel(magLabelIcon);
      tickLabel              = new JLabel(tickIcon);


      labelTable = new Hashtable();

      labelTable.put(new Integer(10),  topLabel);
      labelTable.put(new Integer(30),  sitemapLabel);
      labelTable.put(new Integer(50),  storyboardLabel);
      labelTable.put(new Integer(70),  sketchLabel);
      labelTable.put(new Integer(90),  magLabel);

      labelTable.put(new Integer(0),   tickLabel);
      labelTable.put(new Integer(20),  tickLabel);
      labelTable.put(new Integer(40),  tickLabel);
      labelTable.put(new Integer(60),  tickLabel);
      labelTable.put(new Integer(80),  tickLabel);
      labelTable.put(new Integer(100), tickLabel);

      this.setLabelTable(labelTable);
      this.setPaintTicks(false);
      this.setPaintLabels(true);
      this.setSnapToTicks(true);
      this.setMajorTickSpacing(10);
      this.setInverted(true);

      this.addChangeListener(new ZoomChangeListener());

      // Set the UI for the slider only if the current look and feel is Metal
      if (UIManager.getLookAndFeel() instanceof
          javax.swing.plaf.metal.MetalLookAndFeel) {
         this.setUI(new PenSliderUI());
      }

      this.setBackground(ZOOM_SLIDER_BACKGROUND_COLOR);

      this.addKeyListener(new DenimKeyListener());
      
      if(Denim.getPlatformState()==Denim.runningOnMac)
      {
         this.flagAnimateZoom = false;
      }
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR / MODIFIER METHODS   =======================================

   /**
    * Sets the sheet that the zoom slider affects to the given sheet.
    */
   public void setSheetReference(DenimSheet sh) {
      Debug.println("Sheet reference has been set.");
      sheet     = sh;
      sh.setSlider(this);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Increases the value of the slider by one zoom level.
    */
   public void zoomIn() {
      setValue(getValue() + 2*getMajorTickSpacing());
   } // of method
   

   //-----------------------------------------------------------------

   /**
    * Increases the value of the slider by one zoom level, and remembers
    * where the sheet was centered to in absolute coordinates.
    */
   public void zoomIn(int x, int y) {
      flagCenterTo = true;
      this.x      = x;
      this.y      = y;
      setValue(getValue() + 2*getMajorTickSpacing());
      flagCenterTo = false;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Decreases the value of the slider by one zoom level.
    */
   public void zoomOut() {
      setValue(getValue() - 2*getMajorTickSpacing());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Decreases the value of the slider by one zoom level, and remembers
    * where the sheet was centered to in absolute coordinates.
    */
   public void zoomOut(int x, int y) {
      flagCenterTo = true;
      this.x      = x;
      this.y      = y;
      setValue(getValue() - 2*getMajorTickSpacing());
      flagCenterTo = false;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Runs changing the zoom level is finished.
    */
   private void afterZoom(int oldSliderValue) {
      if(ZoomSlider.zoomingInstance>0)
  		 ZoomSlider.zoomingInstance--;
  		 
/*      if ((oldSliderValue <= 10 && getValue() > 10)
          ||
          ((oldSliderValue == 20 || oldSliderValue == 30) &&
           getValue() != 20 && getValue() != 30)
          ||
          (oldSliderValue >= 40)
          ) {
      }
      
  */
      sheet.readjustArrows();
      
      // after zooming, fade in arrows
      sheet.FadeInArrows();
      
   }

   //-----------------------------------------------------------------

   /**
    * Gets the scale factor of the sheet associated with the slider.
    */
   public double getScaleFactor() {
      return (GraphicalObjectLib.getScaleFactor(COORD_REL, sheet));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Sets whether zooming in and out of the sheet is animated.
    */
   public void setAnimateZoom(boolean flag) {
   
      if(Denim.getPlatformState()==Denim.runningOnMac)
      {
         this.flagAnimateZoom = false;
      }
      else
         flagAnimateZoom = flag;
   
   }

   //-----------------------------------------------------------------

   /**
    * Returns whether zooming in and out of the sheet is animated.
    */
   public boolean isAnimateZoom() {
      return flagAnimateZoom;
   }

   //===   ACCESSOR / MODIFIER METHODS   =======================================
   //===========================================================================



   //===========================================================================
   //===   EVENT METHODS   =====================================================

   /**
    * Just makes it public.
    */
   public void processKeyEvent(KeyEvent evt) {
      super.processKeyEvent(evt);
   } // of method

   //===   EVENT METHODS   =====================================================
   //===========================================================================

   public void processWheelEvent(int notch) {
	   this.setValue(this.getValue() - notch * 10);
   }

   //===========================================================================
   //===   ZOOM CHANGE LISTENER INNER CLASS   ==================================

   /**
    * Handles any change to the slider.
    */
   class ZoomChangeListener implements ChangeListener {

      //--------------------------------------------------------------

      /**
       * Returns the point where we will zoom in on.
       */
      public Point2D getZoomCenter() {
         GraphicalObjectCollection gobcol;
         Rectangle2D               r;
         Point2D                   pt;

         //double currScaleFactor;
         //currScaleFactor = sheet.getAbsScale();
         //currScaleFactor = GraphicalObjectLib.getScaleFactor(COORD_REL, sheet);

         //// 1.2.1. If crosshairs are visible, zoom in on it...
         Point2D crosshairsAbsLocation = sheet.getCrosshairsAbsLocation();
         if (sheet.isCrosshairsVisible() && crosshairsAbsLocation != null) {
            pt = new Point2D.Float();
            pt.setLocation(crosshairsAbsLocation.getX(),
                           crosshairsAbsLocation.getY());
            return (pt);
         }

         //// 1.2.2. ...but if there are any selected objects, zoom in
         ////        on their center instead...
         gobcol = cmdsubsys.getSelectedCollection();
         if (gobcol.numElements() > 0) {
            pt = DenimUtils.getCollectionCenter(gobcol.getForwardIterator());
            if (pt != null) {
               return (pt);
            }
         }

         //// 1.2.3. ...if neither of those are the case, then we either
         ////        zoom in on the center of all graphical objects if
         ////        we are zoomed out, or zoom in on the center of the
         ////        sheet if we are zoomed in.
         //// If zoomed out zoom in on center of mass...
         /*if (currScaleFactor < STORYBOARD_SCALE_FACTOR) {
            pt = getCollectionCenter(sheet.getForwardIterator());
            if (pt != null) {
               return (pt);
            }
         }*/
         //// ...otherwise just zoom in on the sheet.
         r  = sheet.getBounds2D(COORD_ABS);
         pt = new Point2D.Float();
         pt.setLocation(r.getX() + r.getWidth()  / 2.0,
                        r.getY() + r.getHeight() / 2.0);
         return (pt);

      } // of method

      //--------------------------------------------------------------

      public void stateChanged(ChangeEvent evt) {
         int    sliderValue;
         double scaleFactor;
         double currScaleFactor;
         double desiredScaleFactor;
         int    realLastSliderValue;
         
         ZoomSlider.this.sheet.setRenderToScreen(true);
         
         //// 0.1. Don't do anything if the slider is being dragged.
         if (ZoomSlider.this.getValueIsAdjusting()) {
            return;
         }

         //// 0.2. Avoid divide-by-zero.
         sliderValue = ZoomSlider.this.getValue();
         if (sliderValue < 1) {
            sliderValue = 1;
         }

         //// 0.3. Compare with last slider value. The reason for this is that
         ////      there is a bug with how sliders fire off properties when
         ////      the major ticks are set. Two ChangeEvents are sent, instead
         ////      of two. When the PenSliderUI is attached, four events are
         ////      sent. Since we only want one, we will ignore values that
         ////      don't do anything.
         if (lastSliderValue == sliderValue) {
            return;
         }
         else {
            realLastSliderValue = lastSliderValue;
            lastSliderValue = sliderValue;
         }


         //// 1. Calculate the target scale.
         //// desired scale factors given slider values, roughly:
         ////      slider = 90, factor = 2.0
         ////      slider = 70, factor = 1.0
         ////      slider = 50, factor = 0.25
         ////      slider = 30, factor = 0.01
         ////      slider = 10, factor = 0.005 (or so...)
         //// a decent approximation? (2x - 40)^2 / 10,000
         ////      slider = 90, factor = 1.96
         ////      slider = 70, factor = 1.0
         ////      slider = 50, factor = 0.36 (below 40, switch to x/250)
         ////      slider = 30, factor = 0.12
         ////      slider = 10, factor = 0.04
         if (sliderValue >= 100) {
            desiredScaleFactor = ZOOM_NOTCH_100;
         }
         else if (sliderValue >= 90) {
            desiredScaleFactor = ZOOM_NOTCH_90;
         }
         else if (sliderValue >= 80) {
            desiredScaleFactor = ZOOM_NOTCH_80;
         }
         else if (sliderValue >= 70) {
            desiredScaleFactor = ZOOM_NOTCH_70;
         }
         else if (sliderValue >= 60) {
            desiredScaleFactor = ZOOM_NOTCH_60;
         }
         else if (sliderValue >= 50) {
            desiredScaleFactor = ZOOM_NOTCH_50;
         }
         else if (sliderValue >= 40) {
            desiredScaleFactor = ZOOM_NOTCH_40;
         }
         else if (sliderValue >= 30) {
            desiredScaleFactor = ZOOM_NOTCH_30;
         }
         else if (sliderValue >= 20) {
            desiredScaleFactor = ZOOM_NOTCH_20;
         }
         else if (sliderValue >= 10) {
            sheet.setCrosshairsVisible(false);
            desiredScaleFactor = ZOOM_NOTCH_10;
         }
         else {
            sheet.setCrosshairsVisible(false);
            desiredScaleFactor = ZOOM_NOTCH_0;
         }


         //// 1.1. Invert the current scale factor so that all scalings are
         ////      absolute based on slider values
         currScaleFactor = GraphicalObjectLib.getScaleFactor(COORD_REL, sheet);
         scaleFactor     = desiredScaleFactor * (1.0 / currScaleFactor);

         //// 2. Figure out whether to just zoom-in-and-center or just zoom
         AffineTransform txToApply;
         if (!flagCenterTo) {
            Point2D pt = getZoomCenter();
            x = (int) pt.getX();
            y = (int) pt.getY();
         }
         txToApply = AffineTransformLib.scaleAndCenterAt(scaleFactor, x, y,
                                                sheet.getBounds2D(COORD_ABS));

		 // fade out arrows just before zooming
         sheet.FadeOutArrows();
         
         //// 3. Animate or jump to new zoom factor
         
         if (ZoomSlider.this.flagAnimateZoom) {
            AffineTransform[] txArray;
            txArray = AffineTransformLib.animateSlowInSlowOut(txToApply,
               NUMFRAMES);
               

            SwingUtilities.invokeLater(
               new Animation(sheet, txArray, desiredScaleFactor,
                             realLastSliderValue));
         }
         else {
            sheet.applyTransform(txToApply);
            ZoomSlider.this.afterZoom(realLastSliderValue);
         }

         boolean flagClear        = false;
         boolean flagClearShallow = false;

         //// 3.1. Zooming out, clear out selected deep objects...
         if (desiredScaleFactor < ZOOM_NOTCH_45) {
            flagClear        = true;
            flagClearShallow = false;
         }
         //// 3.2. Zooming in, clear out selected shallow objects...
         else if (desiredScaleFactor > ZOOM_NOTCH_45) {
            flagClear        = true;
            flagClearShallow = true;
         }

         //// 3.3. Unselect out the right objects...
         if (flagClear) {
            Iterator        it   = cmdsubsys.getSelected();
            LinkedList      list = new LinkedList();
            GraphicalObject gob;
            while (it.hasNext()) {
               gob = (GraphicalObject) it.next();

               //// Clear out shallow objects
               if (flagClearShallow == true) {
                  if (gob instanceof DenimPanel) {
                     list.add(gob);
                  }
               }
               //// Clear out deep objects
               else {
                  if (!(gob instanceof DenimPanel)) {
                     list.add(gob);
                  }
               }
            }

            //// here to avoid comodification checks
            it = list.iterator();
            while (it.hasNext()) {
               cmdsubsys.removeSelected((GraphicalObject) it.next());
            }

         }
      } // of stateChanged
   } // of inner class

   //===   ZOOM CHANGE LISTENER INNER CLASS   ==================================
   //===========================================================================



   //===========================================================================
   //===   ANIMATION INNER CLASS   =============================================

   /**
    * Animates the sheet between its old zoom level and its new one.
    */
   public class Animation implements Runnable {

      GraphicalObject   gob;
      AffineTransform[] txArray;
      double            desiredScaleFactor;
      int               lastSliderValue;
      


      public Animation(GraphicalObject gob, AffineTransform[] txArray,
                       double desiredScaleFactor, int lastSliderValue) {
         this.gob     = gob;
         this.txArray = txArray;
         this.desiredScaleFactor = desiredScaleFactor;
         this.lastSliderValue = lastSliderValue;
         ZoomSlider.zoomingInstance++;
      }

      public void run() {
      	
//         Sheet.sheetInstance.enableRealtimeRender(); 
//         Sheet.sheetInstance.setFlushSpeed(0.2);                            
//         sheet.FadeOutArrows();
         GraphicalObjectLib.animate(gob, txArray);
         ZoomSlider.this.afterZoom(lastSliderValue);

         if(ZoomSlider.zoomingInstance>0)
    		 ZoomSlider.zoomingInstance--;
    		 
//         Sheet.sheetInstance.disableRealtimeRender();
      }
   } // of inner class

   //===   ANIMATION INNER CLASS   =============================================
   //===========================================================================



   //===========================================================================
   //===   HYPERLINK LISTENER INNER CLASS   ====================================

   /**
    * Listen for hyperlink clicks.
    */
   class InternalHyperlinkListener implements HyperlinkListener {
      JEditorPane web;

      public InternalHyperlinkListener(JEditorPane pane) {
         web = pane;
      } // of constructor

      public void hyperlinkUpdate(HyperlinkEvent evt) {
         try {
            if (evt.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
               web.setPage(evt.getURL());
            }
         }
         catch (Exception e) {
            e.printStackTrace();
         }
      } // of method
   } // of inner class

   //===   HYPERLINK LISTENER INNER CLASS   ====================================
   //===========================================================================



   //===========================================================================
   //===   KEY LISTENER INNER CLASS   ==========================================

   /**
    * Handles all key events from the DENIM window. Ideally, DenimWindow would
    * handle this instead.
    */
   public class DenimKeyListener implements KeyListener {
      public void keyPressed(KeyEvent evt) {
         //// show help window (F1 or Cmd+?)
         if ((evt.getKeyCode() == KeyEvent.VK_F1) || 
             ((evt.getKeyChar() == '?') && (evt.isMetaDown()))) {
               sheet.getDenimUI().showHelpWindow();
         }
         
         //// grab and/or drop tool
         //// unless the pie menu is showing, in which case hide
         //// the pie menu
         else if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) {
            if (sheet.getPieMenu().isShowing()) {
               sheet.getPieMenu().setVisible(false);
            }
            else {
               DenimUI ui = sheet.getDenimUI();
               Container container = (Container)ui.getContainerWithTool();
                  //Debug.println("keyPressed: deep = " + deep.getClass());

               if (container != null)
               {

                  // If the designer is using a tool, then...
                  if (ui.getCurrentTool() != null) {
                     int lastX = ((ToolContainer)container).getLastX();
                     int lastY = ((ToolContainer)container).getLastY();

                     // If the designer is holding the tool over another tool,
                     // drop the tool, and grab the other tool
                     if (container instanceof Tool) {
                        ui.getCurrentTool().drop(
                           container.getParent(),
                           SwingUtilities.convertPoint(container,
                                                       lastX,
                                                       lastY,
                                                       container.getParent()));
                        ((Tool)container).grab();
                     }

                     // Otherwise, just drop the tool
                     else {
                        ui.getCurrentTool().drop(container,
                                                  new Point(lastX, lastY));
                     }
                  }

                  // If the designer pressed the space bar while over a tool,
                  // grab it
                  else if (container instanceof Tool) {
                     ((Tool)container).grab();
                  }
               }
            }
         }
         
         //// toggle pie menu
         else if (evt.getKeyCode() == KeyEvent.VK_SPACE) {
            if (sheet.getPieMenu().isShowing()) {
               sheet.getPieMenu().setVisible(false);
            }
            else {
               sheet.getPieMenu().showAtCursor();
            }
         }
         else if (evt.getKeyCode() == KeyEvent.VK_S) {
             
        	 if(evt.isControlDown())
        	 {
        		 sheet.getPieMenu().saveSheet();
        	 }
         }
         else if (evt.getKeyCode() == KeyEvent.VK_O) {
             
        	 if(evt.isControlDown())
        	 {
                 //// 0.1. Setup the file chooser.
                 JFileChooser chooser = new JFileChooser(sheet.getPieMenu().currentProjectDirectory);

                 //// 0.2. Setup the file filter.
                 ExtensionFileFilter filter = new ExtensionFileFilter();
                 filter.addExtension("dnm");
                 //filter.addExtension("dne");
                 filter.setDescription("Denim Design Files");
                 chooser.setFileFilter(filter);
                 chooser.setMultiSelectionEnabled(false);
                 chooser.setDialogTitle("Open");

                 //// 1. Open up the dialog.
                 int returnVal = chooser.showOpenDialog(sheet);

                 //// 2. If the user clicks Open...
                 if (returnVal == JFileChooser.APPROVE_OPTION) {
                	 sheet.getPieMenu().currentProjectDirectory = chooser.getCurrentDirectory();

                	 sheet.getPieMenu().tryOpen(chooser.getSelectedFile());
                 } 
        	 }
          }
         
         //sheet.damage(DAMAGE_LATER);
      } // of keyPressed


      public void keyTyped(KeyEvent evt) {
      } // of keyTyped

      public void keyReleased(KeyEvent evt) {
      } // of keyReleased

   } // of inner class DenimKeyListener

   //===   KEY LISTENER INNER CLASS   ==========================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
