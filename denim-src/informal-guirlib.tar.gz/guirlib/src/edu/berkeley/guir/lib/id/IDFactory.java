//// See bottom of file for software license
package edu.berkeley.guir.lib.id;

import java.util.Random;

/**
 * Generates likely to be unique IDs.
 *
 * <P>
 * Currently, this is a temporary implementation, just does a "good enough" 
 * job, though this should definitely be fixed in the future.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Jun 22 2002
 * @see GUID for a more reliable version (but it also uses RMI, which
 *           may or may not be available on your JVM)
 */
public class IDFactory {

// Should see what ever happened to:
// http://hegel.ittc.ukans.edu/topics/internet/internet-drafts/draft-l/draft-leach-uuids-guids-01.txt

    //==========================================================================
    //===   CONSTANTS   ========================================================

    private static String PAD = "0000000000000000";

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   CLASS VARIABLES   ==================================================

    static Random rand    = new Random();
    static long   session = Math.abs(rand.nextLong() + rand.nextLong());
    static long   counter = Math.abs(rand.nextLong() + rand.nextLong());

    //===   CLASS VARIABLES   ==================================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * No instances allowed.
     */
    private IDFactory() {
    } // of method

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   UID METHODS   ======================================================

    /**
     * Pad the String with 0's so that it has length 16.
     * 16 because of length of 64 bits in hex string.
     */
    private static String padToLength16(String str) {
        if (str.length() >= 16) {
            return (str);
        }
        else {
            return (PAD.substring(str.length()) + str);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Produces a unique ID with 32 chars. Currently not 100% reliable, 
     * just good enough.
     * <P>
     * These IDs should only be used as names, not for capabilities or
     * authentication. These IDs are also somewhat guessable, given
     * that we simply increment a counter.
     */
    public static synchronized String createIncrementingUID() {
        if (counter == Long.MAX_VALUE) {
            session++;
            counter = 0;
        }
        return ("" + padToLength16(Long.toHexString(session)) + 
                     padToLength16(Long.toHexString(counter++)));
    } // of method

    //--------------------

    /**
     * Produces a unique ID with <I>len</I> chars. Currently not 100% 
     * reliable, just good enough. These IDs should only be used as names, 
     * not for capabilities or authentication.
     * @param len is between 1 and 32. 
     */
    public static synchronized String createIncrementingUID(int len) {
        //// 0. Error checking.
        if (len < 1 || len > 32) {
            throw new IllegalArgumentException(len + " is out of range");
        }

        //// 1. Create a unique ID.
        String str = createIncrementingUID();

        //// 2. Slice off the bits we don't care about.
        return (str.substring(32 - len));
    } // of method

    //----------------------------------------------------------------

    /**
     * Generate a hard-to-guess mostly unique ID 32 chars long.
     * This ID can be used as a cookie value to the client.
     */
    public static String createRandomUID() {
        return (createRandomUID(32));
    } // of method

    //--------------------

    /**
     * Generate a hard-to-guess mostly unique ID <CODE>len</CODE> chars long.
     * This ID can be used as a cookie value to the client.
     */
    public static String createRandomUID(int len) {
        String str = "";     // the uid to return
        int    val;

        if (len <= 0) {
            throw new IllegalArgumentException();
        }

        while (str.length() < len) {
            val  = Math.abs(rand.nextInt() + rand.nextInt()); // harder to guess
            str += Math.abs(val);
        }

        return (str.substring(0, len));
    } // of method

    //===   UID METHODS   ======================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    //// Test incrementing UID
    private static void runTestAAA() {
        System.out.println(createIncrementingUID());
        System.out.println(createIncrementingUID());
        System.out.println(createIncrementingUID());
        System.out.println(createIncrementingUID());
        System.out.println(createIncrementingUID());
        System.out.println(createIncrementingUID());
        System.out.println(createIncrementingUID());
        System.out.println(createIncrementingUID());
        System.out.println(createIncrementingUID());
        System.out.println(createIncrementingUID());


        System.out.println(padToLength16("" + 12L) + "-" + 
                           padToLength16("" + 136L));
    } // of method

    //--------------------

    //// Test random UID
    private static void runTestBBB() {
        System.out.println(createRandomUID());
        System.out.println(createRandomUID());
        System.out.println(createRandomUID());
        System.out.println(createRandomUID());
        System.out.println(createRandomUID());
        System.out.println(createRandomUID());
        System.out.println(createRandomUID());
        System.out.println(createRandomUID());
        System.out.println(createRandomUID(16));
        System.out.println(createRandomUID(16));
        System.out.println(createRandomUID(16));
        System.out.println(createRandomUID(16));
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) {
        runTestAAA();
        System.out.println();
        System.out.println();
        runTestBBB();
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
