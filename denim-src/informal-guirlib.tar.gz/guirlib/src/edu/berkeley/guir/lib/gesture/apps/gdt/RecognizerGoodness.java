package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.GestureSet;
import java.util.*;

/** Computes how good the gesture set is for the recognizer */
public class RecognizerGoodness {
  protected GestureSet gestureSet;
  
  public RecognizerGoodness(GestureSet gs)
  {
    gestureSet = gs;
  }

  /** How good the set currently is.  Higher is better. */
  public double getGoodness()
  {
    Map noticeSummary = NoticeHandler.getNoticeSummary(gestureSet);
    Set noticeSet;
    double result = 0;
    Class c;
    
    c = MisrecognitionNotice.class;
    if (noticeSummary.containsKey(c)) {
      noticeSet = (Set) noticeSummary.get(c);
      result -= countGestures(noticeSet);
    }

    c = OutlierNotice.class;
    if (noticeSummary.containsKey(c)) {
      noticeSet = (Set) noticeSummary.get(c);
      result -= countGestures(noticeSet) * 5;
    }

    c = OutlyingGestureNotice.class;
    if (noticeSummary.containsKey(c)) {
      noticeSet = (Set) noticeSummary.get(c);
      result -= countGestures(noticeSet);
    }
    
    c = RecognizerSimilarityNotice.class;
    if (noticeSummary.containsKey(c)) {
      noticeSet = (Set) noticeSummary.get(c);
      result -= countGestures(noticeSet) * 5;
    }
    
    return result + 1000;
  }

  /** return how many gesture objects are affected by all notices on
      the list */
  protected int countGestures(Collection noticeList)
  {
    int result = 0;
    for (Iterator iter = noticeList.iterator(); iter.hasNext();) {
      Notice notice = (Notice) iter.next();
      result += notice.getObjectList().size();
    }
    return result;
  }
}
