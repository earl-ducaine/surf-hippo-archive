package edu.berkeley.guir.damask.view.visual.event;

import java.awt.geom.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.component.TextInput;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.visual.component.TextBox;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * The event handler that handles inserting text boxes into pages.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-12-2003 James Lin
 *                               Created InsertTextBoxHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 11-12-2003
 */
public class InsertTextBoxHandler extends InsertComponentHandler {

   /**
    * Constructs a new text box handler. 
    */
   public InsertTextBoxHandler() {
      super(TextBox.class);
   }


   // Overrides method in parent class.
   protected Component createNewComponent(
      final DeviceType deviceType,
      final PageRegion region,
      final AffineTransform transform,
      final Rectangle2D bounds) {

      final PNode textBoxTempView = TextBox.createTempView();
      final GeneralPath textBoxTempViewBorder =
         ((PPath)textBoxTempView).getPathReference();
         
      final TextInput textInput = new TextInput(deviceType);
      textInput.setBorder(deviceType, textBoxTempViewBorder);
         
      textInput.setTransform(region.getDeviceType(), transform);
      textInput.setBounds(region.getDeviceType(), bounds);
      
      return textInput;
   }
}
