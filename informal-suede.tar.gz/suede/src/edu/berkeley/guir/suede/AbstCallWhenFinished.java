package edu.berkeley.guir.suede;

public abstract class AbstCallWhenFinished implements EndPlayCallbackIF, EndRecordCallbackIF {
   private static final boolean DEBUG = true;   // turns debugging on and off
   private CallbackIF    m_callback   = null;
   private int           m_curBalloon = 0;
   private SSavableElt   m_node       = null;
   private SamplingGraph m_samplingGraph;
   private boolean       m_stopped = false; //if playing is stopped, stop all audio. do not pass go


   public AbstCallWhenFinished(SamplingGraph samplingGraph, SSavableElt node) {
      m_samplingGraph = samplingGraph;
      m_node = node;
   }


   public synchronized void setCallback(CallbackIF callback) {
      m_callback = callback;
      m_curBalloon = 0;
   }


   /**
    * Call this to stop the playing of all audio, including any associated balloons.
    */
   public void stopAllAudio() {
      m_stopped = true;  
   }
   

   public void callmeWhenDonePlaying(/*CardSound cardSound*/) {
      if (!playMoreAudio()) { // there are no (or no more) balloons to be played
         // at the end the StreamNumber is set to the total number of streams!          
         m_node.setStopped();
          
         // always call the callback regardless of any audio being available
         if (m_callback != null) {
            m_callback.callback();
            m_callback = null;
         }
      }
   }
      
   public boolean playMoreAudio() {
      ////1. If we've either played all the balloons or stopAllAudio() has been called 
      ////   (e.g., when the user clicks the stop button) then we're done
      if ((m_curBalloon >= m_node.getNumBalloons())||(m_stopped)) {
         m_curBalloon = 0; // no more to play, reset for next time
         m_stopped = false; //reset for next time
         return false;
      }

      ////2. Else, play the next stream in the list.
      m_node.playBalloon(m_curBalloon);
      m_curBalloon++;
      return true;
   }
      
}