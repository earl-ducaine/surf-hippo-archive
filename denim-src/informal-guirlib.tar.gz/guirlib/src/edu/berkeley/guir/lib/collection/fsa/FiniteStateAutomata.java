//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.fsa;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * A Finite State Automata. Example code below.
 * <PRE>
 *      FiniteStateAutomata fsa = new FiniteStateAutomata();
 *
 *      fsa.addTransition("A", "B", "1");  // in "A", on input "1" go to "B"
 *      fsa.addTransition("A", "C", "2");  // in "A", on input "2" go to "C"
 *      fsa.addTransition("A", "D", "3");
 *      fsa.addDefaultTransition("A", "D"); 
 *
 *      //// Execute specified action when entering "B" from "A"
 *      fsa.addOnEnterAction("A", "B", new Action.Console("A", "B"));
 *
 *      //// Default action to execute when entering "B" from any state.
 *      fsa.addOnEnterDefaultAction("B", new Action.Console("all", "B"));
 *
 *      fsa.addTransition("B", "A", "A");
 *      fsa.addTransition("B", "C", "C");
 *      fsa.addTransition("B", "D", "D");
 *      fsa.addTimeoutTransition("B", "A", 5000);
 *
 *      fsa.addTransition("C", "A", "A");
 *      fsa.addTransition("C", "B", "B");
 *      fsa.addTransition("C", "D", "D");
 *
 *      fsa.addTransition("D", "A", "A");
 *      fsa.addTransition("D", "B", "B");
 *      fsa.addTransition("D", "C", "C");
 *
 *      fsa.addTransition("E", "A", "1");
 *      fsa.addTransition("E", "A", "2");
 *      fsa.addTransition("E", "A", "3");
 *
 *      fsa.setStartState("A");
 * </PRE>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Mar 09 2003 JIH
 */
public class FiniteStateAutomata {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    private static final boolean DEBUG = false;

    //----------------------------------------------------------------

    public static final String INITIAL_STATE = "<start>";

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   INNER CLASS - ACTION LISTENER   ====================================

    /**
     * Executes actions.
     */
    class ActionListener
        implements StateTransitionListener {

        public void onEnterState(FiniteStateAutomata fsa,
                                 String              strFrom,
                                 String              strCurrent) {
            getState(strCurrent).getOnEnterAction(strFrom).doAction(
                                                    FiniteStateAutomata.this);
        } // of method


        public void onExitState(FiniteStateAutomata fsa,
                                String              strCurrent,
                                String              strTo) {
            getState(strCurrent).getOnExitAction(strTo).doAction(
                                                    FiniteStateAutomata.this);
        } // of method
    } // of inner class

    //===   INNER CLASS - ACTION LISTENER   ====================================
    //==========================================================================




    //==========================================================================
    //===   INNER CLASS - TIMEOUT THREAD   =====================================

    Object monitor = new Object();

    //----------------------------------------------------------------

    class TimeoutThread 
        extends Thread {

        long    timeout     = -1;
        boolean flagExecute;

        public void setTimeout(long millis) {
            synchronized (monitor) {
                t.interrupt();
                flagExecute = true;
                timeout      = millis;
            }
        } // of method


        public void cancel() {
            flagExecute = false;
            t.interrupt();
        } // of method


        public void run() {
            while (flagContinue == true) {
                flagExecute = true;

                synchronized (monitor) {
                    try {
                        if (timeout < 0) {
                            monitor.wait();
                        }
                        else {
                            // System.out.println("waiting " + timeout);
                            monitor.wait(timeout);
                            if (flagExecute == true) {
                                onTimeout();
                            }
                        }
                    }
                    catch (Exception e) {
                        // System.out.println("interrupted");
                        // ignore
                    }
                }
            }
        } // of method
    } // of inner class

    //===   INNER CLASS - TIMEOUT THREAD   =====================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    //// (String strStateName, State state)
    Map           mapStates        = new LinkedHashMap();
    TimeoutThread t                = new TimeoutThread();
    State         startState;
    State         currentState;
    List          listListeners    = new LinkedList(); 
    String        strLastInput;
    boolean       flagContinue     = true;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    public FiniteStateAutomata() {
        t.start();
        addStateTransitionListener(new ActionListener());
    } // of constructor

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================




    //==========================================================================
    //===   LISTENER METHODS   =================================================

    public void addStateTransitionListener(StateTransitionListener l) {
        listListeners.add(l);
    } // of method

    public void removeStateTransitionListener(StateTransitionListener l) {
        listListeners.remove(l);
    } // of method

    public void clearStateTransitionListeners() {
        listListeners.clear();
    } // of method

    //----------------------------------------------------------------

    /**
     * Notify listeners.
     */
    protected void fireOnEnter(String strFrom, String strCurrent) {
        Iterator                it = listListeners.iterator();
        StateTransitionListener lstnr;

        while (it.hasNext()) {
            lstnr = (StateTransitionListener) it.next();
            lstnr.onEnterState(this, strFrom, strCurrent);
        }
    } // of method


    /**
     * Notify listeners.
     */
    protected void fireOnExit(String strCurrent, String strTo) {
        Iterator                it = listListeners.iterator();
        StateTransitionListener lstnr;

        while (it.hasNext()) {
            lstnr = (StateTransitionListener) it.next();
            lstnr.onExitState(this, strCurrent, strTo);
        }
    } // of method

    //===   LISTENER METHODS   =================================================
    //==========================================================================




    //==========================================================================
    //===   STATE MACHINE SETUP METHODS   ======================================

    /**
     * Given a name, get a state.
     */
    protected State getState(String strStateName) {
        return ((State) mapStates.get(strStateName));
    } // of method


    /**
     * Given a name, get a state, or create it if it doesn't exist.
     */
    protected State getOrCreateState(String strStateName) {
        State s = getState(strStateName);
        if (s == null) {
            s = new State(strStateName);
            mapStates.put(strStateName, s);
            s.setFiniteStateAutomata(this);
        }
        return (s);
    } // of method

    //----------------------------------------------------------------

    /**
     * Set the name of the start state.
     * Creates the start state if it doesn't exist.
     */
    public void setStartState(String str) {
        startState   = getOrCreateState(str);
    } // of method

    protected State getStartState() {
        return (startState);
    } // of method

    //----------------------------------------------------------------

    /**
     * Explicitly create the named state. 
     * All of the addTransition() and addAction() methods implicitly
     * create the states for you, so you don't actually have to call this.
     */
    public void addState(String strStateAA) {
        State sAA = getOrCreateState(strStateAA);
    } // of method

    //----------------------------------------------------------------

    /**
     * Add a transition between two states.
     * Create the states on the fly if they don't already exist.
     */
    public void addTransition(String strStateAA, 
                              String strStateBB, 
                              String strInput) {

        State sAA = getOrCreateState(strStateAA);
        State sBB = getOrCreateState(strStateBB);
        sAA.addTransition(strInput, strStateBB);
    } // of method


    /**
     * Convenience method, adds the transition and an action.
     * @param action is a onExit() action.
     */
    public void addTransition(String strStateAA, 
                              String strStateBB, 
                              String strInput,
                              Action action) {

        addTransition(strStateAA, strStateBB, strInput);
        addOnExitAction(strStateAA, strStateBB, action);
    } // of method

    //----------------------------------------------------------------

    /**
     * Add a timeout transition between two states.
     * Create the states on the fly if they don't already exist.
     */
    public void addTimeoutTransition(String strStateAA,
                                     String strStateBB,
                                     int    millis) {

        State sAA = getOrCreateState(strStateAA);
        State sBB = getOrCreateState(strStateBB);
        sAA.setTimeoutTransition(strStateBB, millis);
    } // of method

    //----------------------------------------------------------------

    /**
     * Add a default transition between two states if we don't understand
     * the input.
     * Create the states on the fly if they don't already exist.
     */
    public void addDefaultTransition(String strStateAA, String strStateBB) {
        State sAA = getOrCreateState(strStateAA);
        State sBB = getOrCreateState(strStateBB);
        sAA.setDefaultTransition(strStateBB);
    } // of method

    //----------------------------------------------------------------

    public void addTimeoutAction(String strState, Action action) {
        State sAA = getOrCreateState(strState);
        sAA.addTimeoutAction(action);
    } // of method

    //----------------------------------------------------------------

    /**
     * Add an action when we enter into a state (strEnterInto) from
     * a specific state (strFrom).
     */
    public void addOnEnterAction(String strFrom,
                                 String strEnterInto,
                                 Action action) {

        State sEnterInto = getOrCreateState(strEnterInto);
        sEnterInto.addOnEnterAction(strFrom, action);
    } // of method

    /**
     * Set the action executed right before we enter strStateAA.
     */
    public void addOnEnterDefaultAction(String strStateAA, Action action) {
        State sAA = getOrCreateState(strStateAA);
        sAA.addOnEnterDefaultAction(action);
    } // of method

    //----------------------------------------------------------------

    /**
     * Add an action when we exit from a state (strExitFrom) to
     * a specific state (strTo).
     */
    public void addOnExitAction(String strExitFrom,
                                String strTo,
                                Action action) {

        State sExitFrom = getOrCreateState(strExitFrom);
        sExitFrom.addOnExitAction(strTo, action);
    } // of method

    /**
     * Set the action executed right before we exit strStateAA.
     */
    public void addOnExitDefaultAction(String strStateAA, Action action) {
        State sAA = getOrCreateState(strStateAA);
        sAA.addOnExitDefaultAction(action);
    } // of method

    //===   STATE MACHINE SETUP METHODS   ======================================
    //==========================================================================




    //==========================================================================
    //===   STATE TRANSITION METHODS   =========================================

    /**
     * Set the name of the current state.
     * Stop the automata with stop(), reset with reset().
     * @throws IllegalArgumentException if state does not exist.
     */
    public void setCurrentState(String strNextState) {
        //// 1. Cancel the timeout.
        t.cancel();

        if (flagContinue == false) {
            return;
        }

        //// 2.1. Setup the state transition.
        State  lastState    = currentState;
        State  nextState    = getState(strNextState);
        String strLastState;
        Action action;

        if (lastState == null) {
            strLastState = null;
        }
        else {
            strLastState = lastState.getName();
        }

        //// 2.2. Error checking.
        if (nextState == null) {
            throw new IllegalArgumentException("Cannot transition to: " +
                                               strNextState);
        }

        //// 3. Fire onExit().
        if (strLastState != null && strNextState != null) {
            fireOnExit(strLastState, strNextState);
        }

        //// 4. Set the current state.
        currentState = nextState;

        //// 5. Fire onEnter().
        if (strLastState != null) {
            fireOnEnter(strLastState, currentState.getName());
        }

        //// 6. Setup timer.
        t.setTimeout(currentState.getTimeout());
    } // of method


    protected State getCurrentState() {
        if (currentState == null) {
            reset();
        }
        return (currentState);
    } // of method

    //----------------------------------------------------------------

    /**
     * Called when a state times out.
     */
    protected void onTimeout() {
        if (flagContinue == false) {
            return;
        }

        if (DEBUG == true) {
            System.out.println("timeout from: " + currentState + 
                               " to: " + currentState.getTimeoutTransition());
        }
        Action action = currentState.getTimeoutAction();
        action.doAction(this);
        setCurrentState(currentState.getTimeoutTransition());
    } // of method

    //----------------------------------------------------------------

    /**
     * Done doing setup, ready to start!
     */
    public void startAutomata() {
        reset();
    } // of method

    /**
     * Set the current state to the start state.
     * Call stop() to stop it.
     */
    public void reset() {
        flagContinue = true;
        if (t.isAlive() == false) {
            t.start();
        }
        setCurrentState(startState.getName());
    } // of method

    //----------------------------------------------------------------

    /**
     * Stop the automata. Call reset() to start over.
     */
    public void stop() {
        flagContinue = false;
        t.cancel();
    } // of method

    //----------------------------------------------------------------

    /**
     * Handle some input, do some state transitions.
     * If no current state, goes to start state.
     *
     * @throws IllegalStateException if no start state specified.
     */
    public void handleInput(String strInput) {
        if (startState == null) {
            throw new IllegalStateException("Start state not specified");
        }

        strLastInput = strInput;
        getCurrentState().handleInput(strInput);
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the last input to this automata.
     */
    public String getLastInput() {
        return (strLastInput);
    } // of method

    //===   STATE TRANSITION METHODS   =========================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        StringBuffer strbuf = new StringBuffer();
        Iterator     it     = mapStates.keySet().iterator();
        String       strKey;

        strbuf.append("Start State: " + startState.getName() + "\n\n");

        while (it.hasNext()) {
            strKey = (String) it.next();
            strbuf.append(mapStates.get(strKey).toString());
            strbuf.append("\n\n");
        }

        return (strbuf.toString());
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================




    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    /**
     * Throw manual System.in input into the FiniteStateAutomata to test it.
     */
    public static void testInteractive(FiniteStateAutomata fsa) 
        throws IOException {

        System.out.println(fsa);

        BufferedReader      rdr = new BufferedReader(
                                        new InputStreamReader(System.in));
        String              str;

        fsa.addStateTransitionListener(StateTransitionListener.CONSOLE);

        fsa.reset();

        while ((str = rdr.readLine()) != null) {
            fsa.handleInput(str);
            System.out.println();
        }
    } // of method

    //----------------------------------------------------------------

    public static FiniteStateAutomata getTestInstanceAAA() {
        FiniteStateAutomata fsa = new FiniteStateAutomata();

        fsa.addTransition("A", "B", "1");  // in "A", on input "1" go to "B"
        fsa.addTransition("A", "C", "2");  // in "A", on input "2" go to "C"
        fsa.addTransition("A", "D", "3");
        fsa.addDefaultTransition("A", "D"); 

        //// Execute specified action when entering "B" from "A"
        fsa.addOnEnterAction("A", "B", new Action.Console("A", "B"));

        //// Default action to execute when entering "B" from any state.
        fsa.addOnEnterDefaultAction("B", new Action.Console("all", "B"));

        fsa.addTransition("B", "A", "A");
        fsa.addTransition("B", "C", "C");
        fsa.addTransition("B", "D", "D");
        fsa.addTimeoutTransition("B", "A", 5000);

        fsa.addTransition("C", "A", "A");
        fsa.addTransition("C", "B", "B");
        fsa.addTransition("C", "D", "D");

        fsa.addTransition("D", "A", "A");
        fsa.addTransition("D", "B", "B");
        fsa.addTransition("D", "C", "C");

        fsa.addTransition("E", "A", "1");
        fsa.addTransition("E", "A", "2");
        fsa.addTransition("E", "A", "3");

        fsa.setStartState("A");
        return (fsa);
    } // of method

    //----------------------------------------------------------------

    public static FiniteStateAutomata getTestInstanceBBB() {
        FiniteStateAutomata fsa = new FiniteStateAutomata();

        //// Initial state.
        fsa.addState("start");
        fsa.setStartState("start");
        fsa.addTimeoutTransition("start", "RequestInitial", 1000);
        fsa.addOnEnterDefaultAction("RequestInitial",
               new Action.Console("SendInitialRequest"));

        //// Waits for initial response
        fsa.addTransition("RequestInitial", "RequestPreference", "1");
        fsa.addTransition("RequestInitial", "RequestPreference", "2");
        fsa.addTransition("RequestInitial", "RequestPreference", "3");
        fsa.addTransition("RequestInitial", "RequestPreference", "4");
        fsa.addTransition("RequestInitial", "MoreInfo",          "5");
        fsa.addOnEnterAction("RequestInitial", "RequestPreference",
                        new Action.Console("SendPreferenceAction"));
        fsa.addOnEnterAction("RequestInitial", "MoreInfo",
                        new Action.Console("SendMoreInfoAction"));


        //// Waits for preference response
        fsa.addTimeoutTransition("RequestPreference", "ProcessPreference",
                                 15000);

        //// Displays more info

        //// Set preference

        return (fsa);
    } // of method

    //----------------------------------------------------------------

    private static void runTestAAA() throws Exception {
        testInteractive(getTestInstanceAAA());
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        testInteractive(getTestInstanceBBB());
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
