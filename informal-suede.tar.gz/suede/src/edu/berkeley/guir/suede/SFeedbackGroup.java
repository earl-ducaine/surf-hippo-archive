package edu.berkeley.guir.suede;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class SFeedbackGroup extends JComponent{
    
    private int startX;
    private int startY;
    private int finishX;
    private int finishY;
    private Color fColor;
  
    public SFeedbackGroup (int x, int y) {
        setLocation(x, y);
        setOpaque(false);
    }
    
    public void setStart(int x, int y) {
        startX = x;
        startY = y;
    }
    
    public void setFinish(int x, int y) {
        finishX = x;
        finishY = y;
    }
   
   public Rectangle getFBounds() {
        return new Rectangle(startX, startY, Math.abs(finishX-startX)-1, Math.abs(finishY-startY)-1);
   }
   
   public void setFColor(Color c) {
        fColor = c;
   }
   
   public int getStartX() {
        return startX;
   }
   
   public int getStartY() {
        return startY;
   }
   
   public int getFinishX() {
        return finishX;
   }
   
   public int getFinishY() {
        return finishY;
   }
   
    public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Graphics2D g2d = (Graphics2D)g;
      g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      g2d.setColor(fColor);
      
      g2d.draw(new RoundRectangle2D.Float(startX, startY, Math.abs(finishX-startX)-1, Math.abs(finishY-startY)-1, 
               AbstGroupNodeView.ARC, AbstGroupNodeView.ARC));
    }
    
}