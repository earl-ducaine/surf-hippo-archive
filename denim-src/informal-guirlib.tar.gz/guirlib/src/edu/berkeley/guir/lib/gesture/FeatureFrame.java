package edu.berkeley.guir.lib.gesture;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * Very simple display of feature values.  Allows user to "scale"
 * the feature values.  Some features can scale better than others.
 */
public class FeatureFrame extends JFrame {
  Gesture gesture;
  
  FeatureFrame(Gesture g)
  {
    super("Feature values");
    gesture = g;
    buildUI();
  }

  private void buildUI()
  {
    // list of features
    Box featureHolder = new Box(BoxLayout.Y_AXIS);
    FeatureVector fv = new FeatureVector(gesture);
    Feature[] features = fv.getFeatures();

    for (int i = 0; i < features.length; i++) {
      addFeature(featureHolder, features[i]);
    }

    //addFeature(featureHolder, new FBoundsSize(gesture));
    getContentPane().add(featureHolder, "Center");

    JButton dismiss = new JButton("Close");
    ActionListener dismissListener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	dispose();
      }
    };
    dismiss.addActionListener(dismissListener);
    getContentPane().add(dismiss, "South");
    setResizable(false);
    pack();
    show();
  }

  private void addFeature(Container c, Feature f)
  {
    Box b = new Box(BoxLayout.X_AXIS);
    b.add(new JLabel(f.getName() + " "));
    b.add(Box.createGlue());
    b.add(new FeatureDisplay(f));
    final JTextField multiplier = new JTextField("1.0");
    JButton button = new JButton("Change");
    final Feature dummy = f;
    ActionListener buttonListener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	double factor = Double.valueOf(multiplier.getText()).doubleValue();
	dummy.scale(factor);
      }
    };
    button.addActionListener(buttonListener);
    
    b.add(multiplier);
    multiplier.setColumns(10);
    b.add(button);
    c.add(b);
  }
}
