//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import java.util.*;
import edu.berkeley.guir.lib.debugging.*;


/**
 * An implementation of CommandQueue that is branched and thus doesn't
 * prune the history if the user does some thing, undo's it and then
 * does something else.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~miksen/">Michael Thomsen</A> (
 *          <A HREF="mailto:miksen@cs.berkeley.edu">miksen@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 */

public class BranchedCommandQueue
	extends javax.swing.undo.UndoManager
	implements CommandQueue {

	private BranchedCommandQueueNode historyRoot;
	private BranchedCommandQueueNode currentNode;
	private BranchedCommandQueueNode lastAddedNode;

	private static int counter = 1;

	//===========================================================================
	//===   ACTION METHODS   ====================================================

	public BranchedCommandQueue() {
		super();
		clear();
	}

	/**
	 * Clear all of the commands in the queue.
	 */
	public synchronized void clear() {
		historyRoot = new BranchedCommandQueueNode(null, null, null, 0);
		historyRoot.setVisited();
		currentNode = historyRoot;
		lastAddedNode = historyRoot;
	}

	/**
	 * Execute the specified command.
	 */
	public synchronized void doCommand(Command cmd) {
		int id = counter;
		counter = counter +1;
		BranchedCommandQueueNode newNode = currentNode.createChild(cmd, lastAddedNode, id);
		lastAddedNode = newNode;
		currentNode = newNode;
		cmd.execute();
	}


	public void undo() {
		if (currentNode.isRoot()) {
			// Can't undo!
			System.out.println("can't undo!");
		} else {
			BranchedCommandQueueNode node = currentNode;
			currentNode = currentNode.getParent();
			Command cmd = node.getCommand();
			cmd.undo();
		}
	}
   
	public void redo() {
		if (currentNode.isLeaf()) {
			// Can't redo!
			System.out.println("can't redo!");
		} else {
			currentNode = currentNode.getFirstChild();
			Command cmd = currentNode.getCommand();
			if (cmd != null) {
				cmd.redo();
			} else {
				System.out.println("cmd null");
			}
		}
	}
   
	/**
	 * Return a the last issued command.
	 */
	public synchronized Command getLastCommand() {
		return (Command)currentNode.getCommand();
	}
	
	/**
	 * Return the node for the last issued command.
	 */
	public synchronized BranchedCommandQueueNode getLastNode() {
		return currentNode;
	}
	
	/**
	 * Undo or redo to a given command.
	 */
	public synchronized void jumpTo(BranchedCommandQueueNode node) {
		System.out.println("------------ jumpTo:");
		//node.dump(2, false);

		// Get the paths up to the least common ancestor (LCA) of the
		// current node and the given node, and down to the given node
		// from that LCA
	   LinkedList paths[] = currentNode.getCommonAncestorPaths(node);
		LinkedList upPath = paths[0];
      LinkedList downPath = paths[1];

		if (upPath != null || downPath != null) {
			// Undo commands on the way up
			if (upPath != null) {
				Iterator it = upPath.iterator();
				while (it.hasNext()) {
					BranchedCommandQueueNode nextNode = (BranchedCommandQueueNode) it.next();
					System.out.println("Undoing: ");
					//nextNode.dump(2, false);
					nextNode.getCommand().undo();
				}
			}

			// Redo commands on the way down
			if (downPath != null) {
				Iterator it = downPath.iterator();
				while (it.hasNext()) {
					BranchedCommandQueueNode nextNode = (BranchedCommandQueueNode) it.next();
					System.out.println("Redoing: ");
					//nextNode.dump(2, false);
					nextNode.getCommand().redo();
				}
			}

			// Adjust current node now that we have jumped
			currentNode = node;
		} else {
			Debug.println("Error in BranchedCommandQueue.jumpTo: no LCA was found!");
		}
		Debug.println("------------ jumpTo done");
	}
   
   
	/**
	 * Get an iterator over the current branch in the history
	 */
	public Iterator currentBranchIterator() {
		LinkedList nodes = new LinkedList();

		BranchedCommandQueueNode next = currentNode;
		while (next != null) {
			nodes.addFirst(next);
			next = next.getParent();
		}
	
		// remove the first node (root node)
		nodes.removeFirst();
		
		return nodes.iterator();
	}


   public Iterator getIteratorFromParentToChild(BranchedCommandQueueNode parent, BranchedCommandQueueNode child) {
		LinkedList path = parent.getPathToChild(child);
		if (path !=null) {
			path.addFirst(parent);
			return path.iterator();
   	} else {
   		System.out.println("ERROR: No valid path from "+parent.getId()+", to child "+child.getId()+". Are they in the same branch?");
   		return null;	
   	}
   }
   
   
   public synchronized Iterator getChronologicalIterator(BranchedCommandQueueNode currentBranchNode) {
		// If currentBranchNode is null, then just use currentNode as the marker node
		if (currentBranchNode == null) {
			currentBranchNode = currentNode;
		}

   	// Build list of nodes, and reset marking
   	LinkedList nodes = new LinkedList();
		BranchedCommandQueueNode current = historyRoot.getNext();
		while (current != null) {
			nodes.addFirst(current);
			current.clearMarkings();
			current = current.getNext();
		}

   	// Mark (to set the state of isFirstInBranch and isLastInBranch
   	BranchedCommandQueueNode newestUncolored = markBranch(nodes.iterator(), currentBranchNode);
   	while (newestUncolored != null) {
			newestUncolored = markBranch(nodes.iterator(), currentBranchNode);
		}
		
		// Return iterator to properly marked nodes	
   	// Build list of nodes
   	nodes = new LinkedList();
		current = historyRoot.getNext();
		while (current != null) {
			nodes.add(current);
			current = current.getNext();
		}
		
		// Take away the outer parenthesis
		if ( ! nodes.isEmpty() ) {
			((BranchedCommandQueueNode)nodes.getFirst()).unsetIsFirstInBranch();
			((BranchedCommandQueueNode)nodes.getLast()).unsetIsLastInBranch();
		}
		
   	return nodes.iterator();
   }
   
   
   private BranchedCommandQueueNode markBranch(Iterator it, BranchedCommandQueueNode currentBranchNode) {
   	// 1. Find newest uncolored node
   	BranchedCommandQueueNode newestUncolored = null;
   	boolean cont = true;
   	while (it.hasNext() && cont) {
   		BranchedCommandQueueNode node = (BranchedCommandQueueNode)(it.next());
   		if (! node.isVisited()) {
				newestUncolored = node;
   			newestUncolored.setIsLastInBranch();
   			cont = false;
   		}
   	}
		
		if (newestUncolored != null) {
			// 2. Color all parents of the node that aren't colored, and
			// set inCurrentBranch on all nodes if we find
			// currentBranchNode along the path
			BranchedCommandQueueNode current = newestUncolored;
			boolean markInCurrentBranch = false;
			cont = true;
			while (!(current==null) && cont) {
				// Mark the node as visited
				current.setVisited();
				
				// Check if we should start marking inCurrentBranch
				if (current == currentBranchNode) {
					markInCurrentBranch = true;
				}
				// Mark in current branch if it has been set
				if (markInCurrentBranch) {
					current.setInCurrentBranch();
				}

				// If the parent has been marked, stop marking and set
				// isFirstInBranch. If not continue up along the parent
				// chain
				if (current.getParent().isVisited()) {
					current.setIsFirstInBranch();
					cont = false;
				} else {
					current = current.getParent();
				}
			}
		}

		return newestUncolored;
   }
   
	/**
	 * Dump this queue textually
	 */
	public void dump() {
		System.out.println("All commands (in tree order):");
		historyRoot.dump(2,true);
		System.out.println("All commands (in chronological order):");
		dumpChronologically();
		System.out.println("Current command:");
		currentNode.dump(2,false);
	}
   
	public void dumpChronologically() {
		System.out.print("  ");
		
		StringBuffer currentBranch = new StringBuffer();
		Iterator it = getChronologicalIterator(null);
		while (it.hasNext()) {
			BranchedCommandQueueNode node = (BranchedCommandQueueNode) it.next();
			if (node.isFirstInBranch()) {
				System.out.print("( ");
			}

			System.out.print(node.getId() + " ");

			if (node.isLastInBranch()) {
				System.out.print(") ");
			}

			if (node.isInCurrentBranch()) {
				currentBranch.append(node.getId() + " ");
			}
		}

		System.out.println("\nCurrent branch:\n  " + currentBranch);
	}

} // of class

//==============================================================================

/*
  Copyright (c) 2000 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
