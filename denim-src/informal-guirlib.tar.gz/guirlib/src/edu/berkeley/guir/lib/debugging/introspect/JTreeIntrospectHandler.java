//// See bottom of source code for software license.
package edu.berkeley.guir.lib.debugging.introspect;

import java.lang.reflect.Field;
import java.util.Enumeration;
import java.util.Stack;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;

import edu.berkeley.guir.lib.debugging.Debug;

/**
 * Introspect an object's values in a JTree. See 
 * {@link Introspect#parseObject(Object, IntrospectHandler)}.
 * <P>
 * Here is an example of the introspection debugging:
 * <IMG SRC="{@docRoot}/img/debug-introspect.gif">
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
public class JTreeIntrospectHandler 
   extends DefaultIntrospectHandler {

   //===========================================================================
   //===   INNER CLASS LISTENER   ==============================================

   /**
    * Listen for when items are selected in the tree.
    */
   class InternalTreeSelectionListener 
      implements TreeSelectionListener {

      public void valueChanged(TreeSelectionEvent evt) {
         DefaultMutableTreeNode node;
         node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();

         if (node == null) {
            return;
         }

         DebugInfo d = (DebugInfo) node.getUserObject();
         if (d.obj != null) {
            Debug.displayObjectTree(d.obj);
         }
      } // of method
   } // of inner class

   //===========================================================================

   /**
    * Listen for when the tree will expand or collapse.
    * Dynamically debug the object when expanded, or garbage collect when
    * collapsed.
    */
   class InternalTreeWillExpandListener
      implements TreeWillExpandListener {

      public void treeWillExpand(TreeExpansionEvent e) {
          TreePath               p   = e.getPath();
          DefaultMutableTreeNode node;
          DebugInfo              dinf;
          
          node = (DefaultMutableTreeNode) p.getLastPathComponent();
          dinf = (DebugInfo) node.getUserObject();

          //// 1. Expand the node on the object.
          ////    First, remove the blank object.
          node.removeAllChildren();

          //// 2. Now debug the object.
          JTreeIntrospectHandler h = new JTreeIntrospectHandler();
          Introspect.parseObject(dinf.obj, h);

          //// 3.
          DefaultMutableTreeNode newTopNode = h.getTopNode();
          Enumeration            en         = newTopNode.children();
          while (en.hasMoreElements()) {
             node.add((MutableTreeNode) en.nextElement());
          }

      } // of method

      public void treeWillCollapse(TreeExpansionEvent e) {
          TreePath               p = e.getPath();
          DefaultMutableTreeNode node;
          DebugInfo              dinf;

          node = (DefaultMutableTreeNode) p.getLastPathComponent();
          dinf = (DebugInfo) node.getUserObject();

          //// 1. Garbage collect the node.
          node.removeAllChildren();

          //// 2. Reinsert a blank object.
          node.add(new DefaultMutableTreeNode());
      } // of method

   } // of inner class

   //===========================================================================

   /**
    * A single unit of debugging info.
    */
   class DebugInfo {
      String strName;
      Object obj;

      public DebugInfo(String newStrName, Object newObj) {
         strName = newStrName;
         obj     = newObj;
      } // of constructor

      public DebugInfo(int mods, String type, String name, String val,
                       Object newObj) {
         strName = "<html><font color=\"#0000ff\">" +
                   IntrospectLib.getModString(mods) + 
                   "</font><font color=\"#009900\">" + type + "</font> " + 
                   "<b>" + name + "</b> = " + val + "</html>";
         obj = newObj;
      } // of constructor

      public DebugInfo(Field f, String val, Object newObj) {
         //// 1.1. Normal case
         if (f != null) {
            strName = "<html><font color=\"#0000ff\">" +
                      IntrospectLib.getModString(f.getModifiers()) + 
                      "</font><font color=\"#009900\">" + 
                      IntrospectLib.getTypeString(f.getType()) + "</font> " + 
                      "<b>" + f.getName() + "</b> = " + val + "</html>";
         }
         //// 1.2. Only called on root
         else {
            strName = "<html><font color=\"#009900\">" + 
                       newObj.getClass() + "</font> " + " = " + val + "</html>";
         }
         obj = newObj;
      } // of constructor
      
      public String toString() {
         return (strName);
      } // of method
   } // of inner class

   //===   INNER CLASS LISTENER   ==============================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   protected String toString(Object obj) {
      if (obj == null) {
         return ("<I>null</I>");
      }
      else {
         return (super.toString(obj));
      }
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   JTree                  tree;
   Stack                  stackTreeNodes = new Stack();
   int                    lastDepth      = 0;
   DefaultMutableTreeNode topNode;
   DefaultMutableTreeNode currentNode;
   DefaultMutableTreeNode lastNode;
   JFrame                 currentFrame;
   Object                 root;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates an empty object.
    */
   public JTreeIntrospectHandler() {
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   TREE METHODS   ======================================================

   /**
    * Get a reference to the JTree.
    */
   public JTree getJTree() {
      tree = new JTree(topNode);
      tree.addTreeSelectionListener(new InternalTreeSelectionListener());
      tree.addTreeWillExpandListener(new InternalTreeWillExpandListener());
      tree.getSelectionModel().setSelectionMode(
         TreeSelectionModel.SINGLE_TREE_SELECTION);
      tree.putClientProperty("JTree.lineStyle", "Angled");
      return (tree);
   } // of method

   //-----------------------------------------------------------------

   private DefaultMutableTreeNode getTopNode() {
      return (topNode);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Just display the tree.
    */
   public void displayJTree() {
      String[]    strInfo  = Debug.getCurrentClassAndMethod();
      JTree       tree     = getJTree();
      JFrame      frame    = new JFrame(root.getClass() + " - called in " + 
                                        strInfo[1] + "." + strInfo[2] + "()");
      JScrollPane treeView = new JScrollPane(tree);

      frame.getContentPane().add(treeView);
      frame.pack();
      frame.setVisible(true);

      currentFrame = frame;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the tree node that corresponds to the specified depth.
    */
   private void getCurrentTreeNode(int depth) {
      //// 1.1. Go deeper, so push.
      if (depth > lastDepth) {
         //// 1.1.1. Initial case when first adding root node.
         if (currentNode == null) {
            currentNode = lastNode;
         }
         //// 1.1.2. Normal case when adding other nodes.
         else {
            stackTreeNodes.push(currentNode);
            currentNode.add(lastNode);
            currentNode = lastNode;
         }
      }
      //// 1.2. Go shallow, so pop one or more off.
      else if (depth < lastDepth) {
         try {
            for (int i = depth; i < lastDepth; i++) {
               currentNode = (DefaultMutableTreeNode) stackTreeNodes.pop();
            }
         }
         catch (Exception e) {
            System.err.println("oops, empty stack");
         }
      }

      //// 2. Set the current depth
      lastDepth = depth;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a node at the specified depth.
    */
   private void addNode(int depth, DebugInfo d) {
      //// 1. Just starting out.
      ////    Create the top-level node.
      if (depth == 0) {
         root        = d.obj;
         topNode     = new DefaultMutableTreeNode(d);
         currentNode = null;
         lastNode    = topNode;
         lastDepth   = 0;
         return;
      }

      //// 2. Add to the current node.
      DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(d);

      getCurrentTreeNode(depth);
      currentNode.add(newNode);

      //// 3. Just in case we recurse down.
      lastNode = newNode;
   } // of method

   //===   TREE METHODS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   INTROSPECTION CALLBACK METHODS   ====================================

   /**
    * All primitives get redirected here.
    */
   protected void output(int depth, Field f, String str) {
      addNode(depth, new DebugInfo(f, str, null));
   } // of method

   //-----------------------------------------------------------------

   public void onRoot(Object obj) {
      onObject(0, null, obj);
   } // of method

   public void onObject(int depth, Field f, Object obj) {
      //// 1. Add the object into the tree.
      addNode(depth, new DebugInfo(f, obj.toString(), obj));

      //// 2. Add a marker to mark it as an object.
      ////    The debug info will be blank, but have a reference
      ////    to the debug object.
      addNode(depth + 1, new DebugInfo("", obj));

   } // of method

   //-----------------------------------------------------------------

   /**
    * Don't recurse unless it is on the initial object (depth 0).
    */
   public boolean shouldRecurse(int depth, int mods, Class type, Object obj) {
      if (depth <= 0) {
         return (true);
      }
      return (false);
   } // of method

   //===   INTROSPECTION CALLBACK METHODS   ====================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
