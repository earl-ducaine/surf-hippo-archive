package edu.berkeley.guir.lib.swing;

import java.awt.geom.*;
import java.awt.*;

//this is the arrowtail class that allows users to move the tail of a link
//supposed to provide visual feedback at mouseover.

public class Arrowtail extends javax.swing.JComponent {
    public  static final int DIAMETER = 10;
    
    private boolean m_source;
    
    public Arrowtail(){
        setSize(DIAMETER+2, DIAMETER+2);
        setVisible(true);
        setOpaque(false);
    }
    
    
    public void setCenter (int x, int y) {
        if ((x - getWidth()/2)!=getX() || ((y - getHeight()/2)!=getY())) 
            setLocation(x - getWidth()/2, y - getHeight()/2);
    }
    

    public void paintComponent(Graphics g){
        Graphics2D g2d = (Graphics2D)g;
        g2d.setColor(getForeground());   

        if(!m_source)
            g2d.draw(new Ellipse2D.Double(1, 1, DIAMETER, DIAMETER));
        else
            g2d.fill(new Ellipse2D.Double(1, 1, DIAMETER, DIAMETER));
    }
    
    public void setSource(boolean b) {
        m_source = b;
    }
    
}

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
