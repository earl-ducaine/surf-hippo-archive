package edu.berkeley.guir.damask.view;

import java.awt.*;
import java.net.URL;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.berkeley.guir.damask.Damask;
import edu.berkeley.guir.damask.view.appevent.CanvasEvent;
import edu.berkeley.guir.damask.view.appevent.CanvasListener;
import edu.berkeley.guir.damask.view.visual.VisualCanvas;

/** 
 * The toolbox in Damask.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-28-2003 James Lin
 *                               Created Toolbox
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-28-2003
 */
public class DamaskToolbar extends JToolBar {
   private DamaskFrame currentFrame = null;
   private DamaskCanvas currentCanvas = null;
   
   private final CanvasListener canvasHandler = new CanvasHandler();
   private final ChangeListener canvasChangeHandler =
      new CanvasChangeHandler();

   private JButton cutButton = new JButton();
   private JButton copyButton = new JButton();
   private JButton pasteButton = new JButton();
   private JButton deleteButton = new JButton();
   
   private JButton groupButton = new JButton();
   private JButton ungroupButton = new JButton();
   
   private JButton changeLayerOfObjectButton = new JButton(); 
   
   private JButton runButton = new JButton();
   private JButton runFromHomeButton = new JButton();
   
   public static class OutputModality {
      private String name;

      public static final OutputModality VISUAL = new OutputModality("Visual");
      public static final OutputModality VOICE = new OutputModality("Voice");

      private OutputModality (String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   private OutputModality currentModality;
   private final Map/*<OutputModality, List<JButton>>*/
      outputSpecificTools =
      new HashMap/*<OutputModality, List<JButton>>*/(); 
   private static final int FIRST_OUTPUT_SPECIFIC_TOOL_INDEX = 16;

   private static final String PLATFORM_NAME;
   static {
      if (DamaskAppUtils.isUsingSystemLookAndFeel()) {
         if (DamaskAppUtils.isMac()) {
            PLATFORM_NAME = "mac";
         }
         else if (DamaskAppUtils.isWindows()) {
            if (DamaskAppUtils.isWindowsXP()) {
               PLATFORM_NAME = "win_xp";
            }
            else {
               PLATFORM_NAME = "win";
            }
         }
         else {
            PLATFORM_NAME = "java";
         }
      }
      else {
         PLATFORM_NAME = "java";
      }
   }
   
   /**
    * Constructs the toolbox.
    */
   public DamaskToolbar() {
      super(SwingConstants.HORIZONTAL);
      setFloatable(false);
   }
   
   
   /**
    * Adds a button with the given action to the toolbox.
    */
   private void setupButton(final JButton button) {
      final Action action = button.getAction();
      if (action.getValue(Action.SMALL_ICON) == null) {
         button.setText((String)action.getValue(Action.NAME));
      }
      else {
         button.setText("");
         button.setMaximumSize(
            new Dimension(button.getMaximumSize().width, Integer.MAX_VALUE));
      }
      if (action != null) {
         button.setDisabledIcon(
            (Icon)action.getValue(DamaskAppUtils.PROPERTY_DISABLED_ICON));
      }
      button.setHorizontalAlignment(SwingConstants.LEFT);
   }
   
   
   /**
    * Adds the specified button to the toolbox.
    */
   private void addButton(final JButton newButton) {
      addButton(newButton, getComponentCount());
   }
   
   
   /**
    * Adds the specified button to the toolbox at the specified index.
    */
   private void addButton(final JButton newButton, final int index) {
      add(newButton, index);
   }

   
   /**
    * Adds the specified list of buttons to the toolbox. If the list contains
    * a null entry, then a separator will be added at that position.
    */
   private void addButtons(final List/*<JButton>*/ newButtons, int index) {
      for (Iterator i = newButtons.iterator(); i.hasNext(); ) {
         final JButton newButton = (JButton)i.next();
         if (newButton == null) {
            addSeparator(index);
         }
         else {
            addButton(newButton, index);
            setupButton(newButton);
         }
         index++;
      }
   }

   
   /**
    * Adds a separator at the specified index.
    */
   private void addSeparator(int index) {
      final JToolBar.Separator s = new JToolBar.Separator(null);
      if (getOrientation() == VERTICAL) {
         s.setOrientation(JSeparator.HORIZONTAL);
      }
      else {
         s.setOrientation(JSeparator.VERTICAL);
      }
      add(s, index);
   }


   /**
    * Initializes the toolbox after it has been added to a frame.
    */
   public void initialize() {
      // Initialize the buttons for desktop and smartphone
      final List/*<JButton>*/ visualButtons =
         new ArrayList/*<JButton>*/();
      outputSpecificTools.put(OutputModality.VISUAL, visualButtons);
      
      visualButtons.add(groupButton);
      visualButtons.add(ungroupButton);

      // Initialize the buttons for voice
      final List/*<JButton>*/ voiceButtons =
         new ArrayList/*<JButton>*/();
      outputSpecificTools.put(OutputModality.VOICE, voiceButtons);
      
      // Add the global buttons
      final DamaskFrame frame = (DamaskFrame)SwingUtilities.getRoot(this);

      final JButton newButton = new JButton(frame.getNewAction());
      addButton(newButton);
      setupButton(newButton);
            
      final JButton openButton = new JButton(frame.getOpenAction());
      addButton(openButton);
      setupButton(openButton);
            
      final JButton saveButton = new JButton(frame.getSaveAction());
      addButton(saveButton);
      setupButton(saveButton);
      
      addSeparator();
      
      addButton(cutButton);
      addButton(copyButton);
      addButton(pasteButton);
      addButton(deleteButton);
            
      addSeparator();
      
      final JButton undoButton = new JButton(frame.getUndoAction());
      addButton(undoButton);
      setupButton(undoButton);
      
      final JButton redoButton = new JButton(frame.getRedoAction());
      addButton(redoButton);
      setupButton(redoButton);

      addSeparator();
      addButton(changeLayerOfObjectButton);

      changeLayerOfObjectButton.setVisible(Damask.PATTERNS_AND_LAYERS);

      addSeparator();
      addButton(runFromHomeButton);
      addButton(runButton);
      
      // Add the canvas-specific buttons
      setCurrentFrame(frame);
      
      currentModality = OutputModality.VISUAL;
   }
   
   
   /**
    * Returns the image icon with the given file name.
    */
   public static ImageIcon getToolbarIcon(final String fileName) {
      final Image image =
         Toolkit.getDefaultToolkit().createImage(
            DamaskApp.class.getResource(
               "images/toolbar/" + PLATFORM_NAME + "/normal/" + fileName));
      return new ImageIcon(image);
   }
   
   
   /**
    * Returns the disabled image icon with the given file name.
    */
   public static ImageIcon getToolbarDisabledIcon(final String fileName) {
      final URL disabledIconURL =
         DamaskApp.class.getResource(
            "images/toolbar/" + PLATFORM_NAME + "/disabled/" + fileName);
      if (disabledIconURL == null) {
         return null;
      }
      else {
         final Image image =
            Toolkit.getDefaultToolkit().createImage(disabledIconURL);
         return new ImageIcon(image);
      }
   }


   /**
    * Returns the currently active frame.
    */
   private DamaskFrame getCurrentFrame() {
      return currentFrame;
   }


   /**
    * Sets the currently active frame.
    */
   private void setCurrentFrame(DamaskFrame currentFrame) {
      if (currentFrame != null) {
         currentFrame.removeCanvasChangeListener(canvasChangeHandler);
      }
      this.currentFrame = currentFrame;
      if (currentFrame != null) {
         setCurrentCanvas(currentFrame.getCurrentCanvas());
         currentFrame.addCanvasChangeListener(canvasChangeHandler);
      }
   }


   /**
    * Sets the currently active canvas.
    */
   private void setCurrentCanvas(final DamaskCanvas canvas) {
      if (currentCanvas != null) {
         currentCanvas.removeCanvasListener(canvasHandler);
      }
      currentCanvas = canvas;
      if (currentCanvas != null) {
         currentCanvas.addCanvasListener(canvasHandler);
         updateDeviceTypeSpecificTools();
      }
   }
   
   
   /**
    * Adds or removes tools depending on the current canvas' output modality.
    */
   private void updateDeviceTypeSpecificTools() {
      // Remove the old output-specific tools.
      while (getComponentAtIndex(FIRST_OUTPUT_SPECIFIC_TOOL_INDEX) != null) {
         remove(FIRST_OUTPUT_SPECIFIC_TOOL_INDEX);
      }

      cutButton.setAction(currentCanvas.getCutAction());
      setupButton(cutButton);
      
      copyButton.setAction(currentCanvas.getCopyAction());
      setupButton(copyButton);
      
      pasteButton.setAction(currentCanvas.getPasteAction());
      setupButton(pasteButton);

      deleteButton.setAction(currentCanvas.getDeleteAction());
      setupButton(deleteButton);

      runFromHomeButton.setAction(currentCanvas.getRunFromHomeAction());
      setupButton(runFromHomeButton);
      
      runButton.setAction(currentCanvas.getRunFromSelectedPageAction());
      setupButton(runButton);
      
      changeLayerOfObjectButton.setAction(currentCanvas.getChangeLayerOfObjectAction());
      
      if (currentCanvas.getDeviceType().isVisual()) {
         currentModality = OutputModality.VISUAL;
         groupButton.setAction(
            ((VisualCanvas)currentCanvas).getGroupStrokesAction());
         ungroupButton.setAction(
            ((VisualCanvas)currentCanvas).getUngroupStrokesAction());
      }
      else {
         currentModality = OutputModality.VOICE;
      }
      
      // Add the new output-specific tools.
      final List/*<JButton>*/ newButtons =
         (List)outputSpecificTools.get(currentModality);
      if (!newButtons.isEmpty()) {
         addSeparator(FIRST_OUTPUT_SPECIFIC_TOOL_INDEX);
         addButtons(newButtons, FIRST_OUTPUT_SPECIFIC_TOOL_INDEX + 1);
      }
      
      repaint();
   }
   
   /**
    * Listens to canvas change events. 
    */
   private class CanvasChangeHandler implements ChangeListener {
      public void stateChanged(ChangeEvent e) {
         setCurrentCanvas(getCurrentFrame().getCurrentCanvas());
      }
   }


   /**
    * Handles canvas events.  
    */
   private class CanvasHandler implements CanvasListener {
      public void selectionChanged(CanvasEvent e) {
         assert e.getCanvas()
            == currentCanvas : "should be receiving events from "
               + currentCanvas
               + ", not "
               + e.getCanvas();
      }

      public void selectedPageChanged(CanvasEvent e) {
      }
   }   
}
