package edu.berkeley.guir.damask.component;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.dialog.*;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.util.StringLib;

/** 
 * A group of components, which live within a dialog.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2003 James Lin
 *                               Created ComponentGroup.
 *             1.1.0  12-18-2003 James Lin
 *                               ComponentGroup is no longer a ConnectionDest.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 03-20-2003
 */
public class ComponentGroup extends Component {

   private Set components = new HashSet();
   private Map/*<PageRegion, Rectangle2D>*/ boundsInPageRegion =
      new HashMap();
   private Map/*<PageRegion, AffineTransform>*/ transformInPageRegion =
      new HashMap();
   
   private Dialog dialog = null;

   private ElementContainerSource containerEventSource =
      new ElementContainerSource();
   private GroupEventSource groupEventSource = new GroupEventSource();

   //===========================================================================

   /**
    * Constructs a component group.
    * 
    * @param deviceType the device type that this component group supports.
    * Can be DeviceType.ALL.
    */
   public ComponentGroup(final DeviceType deviceType) {
      super(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Constructs a component group, copying the properties of the specified
    * group, but not the specified group's children.
    * 
    * @param group the group whose properties to copy into this new group 
    * @param deviceType the device type that this component group supports.
    * Can be DeviceType.ALL.
    */
   public ComponentGroup(
      final ComponentGroup group,
      final DeviceType deviceType) {

      super(group, deviceType);

      for (Iterator i = group.getPageRegions(deviceType).iterator();
            i.hasNext();) {
         final PageRegion region = (PageRegion)i.next();
         setBoundsInPageRegion(region, group.getBoundsInPageRegion(region));
         setTransformInPageRegion(region,
                                  group.getTransformInPageRegion(region));
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Frees up any resources associated with this object.
    */
   public void dispose() {
      super.dispose();

      // Remove any components contained within this group.
      for (Iterator i = components.iterator(); i.hasNext(); ) {
         Component c = (Component)i.next();
         remove(c);
      }
   }

   //===========================================================================

   protected void autoPosition() {
      final Map/*<PageRegion, Rectangle2D>*/ newBoundsForRegion =
         new HashMap/*<PageRegion, Rectangle2D>*/();

      // Figure out for which region bounds have already been defined.
      // This is the region in which the user originally created the group.
      PageRegion userSpecRegion = null;
      int numSpecedDevices = 0;
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         final Set/*<PageRegion>*/ regions = getPageRegions(aDeviceType); 
         if (!regions.isEmpty()) {
            userSpecRegion = (PageRegion)regions.iterator().next();
            numSpecedDevices++;
         }
      }
      if (numSpecedDevices == getDeviceTypesVisibleTo().size()) {
         return;
      }
      
      // Figure out which control is above this group physically.
      final Control controlBefore = dialog.getControlBefore(
         userSpecRegion,
         getDeviceType(),
         getTransformInPageRegion(userSpecRegion),
         getBoundsInPageRegion(userSpecRegion));
      
      // For device types where the new group is not being manually
      // added by the designer...
      for (Iterator i = getDeviceTypesVisibleTo().iterator();
         i.hasNext(); ) {
      
         final DeviceType aDeviceType = (DeviceType)i.next();

         // If the group already has bounds for this device type, then
         // they do not need to be changed
         if (!getPageRegions(aDeviceType).isEmpty()) {
            continue;
         }
         
         // If there are no children for this device type, then simply
         // set the bounds to be the default size
         final Set children = getChildren(aDeviceType);
         if (children.isEmpty()) {
            final PageRegion aRegion =
               DamaskUtils.getCorrespondingRegion(
                  userSpecRegion, controlBefore, aDeviceType);
            
            final double groupX;
            final double groupY;
            
            
            if (controlBefore == null) {
               groupX = 0;
               groupY = 0;
            }
            else {
               final Rectangle2D controlBeforeBounds =
                  controlBefore.getBoundsInParentCoords(aDeviceType);
               groupX = controlBeforeBounds.getX();
               groupY = controlBeforeBounds.getY();
            }
            newBoundsForRegion.put(
               aRegion,
               new Rectangle2D.Double(groupX, groupY,
                                      aDeviceType.getGroupDefaultWidth(),
                                      aDeviceType.getGroupDefaultHeight()));
         }
         else {
            // Otherwise, make the bounds the union of the bounds of the
            // contained components
            for (Iterator j = children.iterator(); j.hasNext(); ) {
               final Component child = (Component)j.next();
               if (child instanceof Control) {
                  final Control childControl = (Control)child;
                  final Rectangle2D childControlBounds =
                     childControl.getBoundsInParentCoords(aDeviceType);
                  final PageRegion regionForChild =
                     childControl.getPageRegion(aDeviceType); 
                  Rectangle2D bounds =
                     (Rectangle2D)newBoundsForRegion.get(regionForChild);
                  if (bounds == null) {
                     bounds = childControlBounds;
                  }
                  else {
                     Rectangle2D.union(bounds, childControlBounds, bounds);
                  }
                  newBoundsForRegion.put(regionForChild, bounds);
               }
               else {
                  final ComponentGroup childGroup = (ComponentGroup)child;
                  for (Iterator k = childGroup
                        .getPageRegions(aDeviceType).iterator(); k.hasNext();) {
                     final PageRegion regionForChild = (PageRegion)k.next();
                     final Rectangle2D childGroupBounds =
                        GeomLib.transformRectangle(
                           childGroup.getTransformInPageRegion(regionForChild),
                           childGroup.getBoundsInPageRegion(regionForChild));
                     Rectangle2D bounds =
                        (Rectangle2D)newBoundsForRegion.get(regionForChild);
                     if (bounds == null) {
                        bounds = childGroupBounds;
                     }
                     else {
                        Rectangle2D.union(bounds, childGroupBounds, bounds);
                     }
                     newBoundsForRegion.put(regionForChild, bounds);
                  }
               }
            }
         }
      }
            
      for (Iterator i = newBoundsForRegion.keySet().iterator(); i.hasNext();) {
         final PageRegion region = (PageRegion)i.next();
         setBoundsInPageRegion(
            region, (Rectangle2D) newBoundsForRegion.get(region));
         setTransformInPageRegion(region, new AffineTransform());
      }
   }

   //===========================================================================

   /**
    * Returns the components contained by this component group with the
    * given device. 
    */
   public Set/*<Component>*/ getChildren() {
      return new HashSet(components);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns the components contained by this component group with the
    * given device. 
    */
   public Set/*<Component>*/ getChildren(final DeviceType deviceType) {
      final Set result = new HashSet();
      for (Iterator i = components.iterator(); i.hasNext(); ) {
         final Component component = (Component)i.next();
         if (component.isVisibleToDeviceType(deviceType)) {
            result.add(component);
         }
      }
      return result;
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the given component to this group. The device type of this group and
    * the component being added should be compatible, i.e., they should be
    * the same or the device type of this group should be DeviceType.ALL.
    * 
    * <p>If the specified component is a member of another group, it will be 
    * removed from that group first.
    */
   public void add(final Component child) {
      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(child.getDeviceType()),
         child + " with device type " + child.getDeviceType()
            + " cannot be added to "
            + this + " with device type " + getDeviceType());
            
      final ComponentGroup oldGroup = child.getGroup();
      if (oldGroup != null) {
         oldGroup.remove(child);
      }
      components.add(child);
      child.setGroup(this);
      
      for (Iterator i = child.getDeviceTypesVisibleTo().iterator();
         i.hasNext(); ) {
         
         final DeviceType aDeviceType = (DeviceType)i.next();
         fireElementAdded(
            aDeviceType,
            ElementContainerEvent.UNKNOWN_INDEX,
            child);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given component from this group for the given device.
    */
   public boolean remove(final Component child) {
      final boolean wasRemoved = components.remove(child);
      
      if (wasRemoved) {
         child.setGroup(null);
         for (Iterator i = child.getDeviceTypesVisibleTo().iterator();
            i.hasNext(); ) {
         
            final DeviceType aDeviceType = (DeviceType)i.next();
            fireElementRemoved(
               aDeviceType,
               ElementContainerEvent.UNKNOWN_INDEX,
               child);
         }
      }
      return wasRemoved;
   }

   //===========================================================================

   /**
    * Returns the number of items in this group, from the given device type's
    * perspective.
    */
   public int size(final DeviceType deviceType) {
      return getChildren(deviceType).size();
   }
   
   //===========================================================================
   
   public Dialog getDialog() {
      return dialog;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the dialog that this group is in. Called only by Dialog.addGroup().
    */
   public void setDialog(final Dialog dialog) {
      this.dialog = dialog;
      autoPosition();
   }

   //===========================================================================

   /**
    * Returns the interaction graph that the component group is in, or null
    * if it's not in any graph.
    */
   public InteractionGraph getInteractionGraph() {
      Dialog d = getDialog();
      if (d != null) {
         return d.getInteractionGraph();
      }
      else {
         return null;
      }
   }

   //===========================================================================
   
   /**
    * Returns the page regions that this group is in.
    */
   public Set/*<PageRegion>*/ getPageRegions() {
      return new HashSet/*<PageRegion>*/(boundsInPageRegion.keySet());
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the page regions that this group is in for the specified
    * device type. The page regions are returned in the order that their
    * corresponding pages have within their dialog, unless deviceType is
    * DeviceType.ALL.
    */
   public Set/*<PageRegion>*/ getPageRegions(final DeviceType deviceType) {
      if (deviceType == DeviceType.ALL) {
         return getPageRegions();
      }
      
      final Set/*<PageRegion>*/ result =
         new TreeSet/*<PageRegion>*/(new PageRegionComparator());
      
      for (Iterator i = boundsInPageRegion.keySet().iterator(); i.hasNext(); ) {
         final PageRegion region = (PageRegion)i.next();
         if (region.getDeviceType() == deviceType) {
            result.add(region);
         }
      }
      return result;
   }
   
   //===========================================================================
   
   /**
    * Returns the bounds of this group within the specified page region.
    * (A group can be split across multiple pages within the same dialog.)
    */
   public Rectangle2D getBoundsInPageRegion(final PageRegion pageRegion) {
      final Rectangle2D bounds =
         (Rectangle2D)boundsInPageRegion.get(pageRegion);
      if (bounds == null) {
         return null; 
      }
      else {
         return (Rectangle2D)bounds.clone();
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets the bounds of this group within the specified page region.
    * (A group can be split across multiple pages within the same dialog.)
    */
   public void setBoundsInPageRegion(
      final PageRegion pageRegion,
      final Rectangle2D bounds) {

      if (bounds == null) {
         boundsInPageRegion.remove(pageRegion);
      }
      else {
         boundsInPageRegion.put(pageRegion, bounds);
      }
      fireElementBoundsUpdated(pageRegion);
   }

   //---------------------------------------------------------------------------
   
   public Rectangle2D getBounds(final DeviceType deviceType) {
      throw new UnsupportedOperationException("Use getBoundsInPageRegion()");
   }
   
   //---------------------------------------------------------------------------
   
   public void setBounds(
      final DeviceType deviceType,
      final Rectangle2D newBounds) {

      throw new UnsupportedOperationException("Use setBoundsInPageRegion()");
   }

   //===========================================================================
   
   /**
    * Returns the transform of this group within the specified page region.
    * (A group can be split across multiple pages within the same dialog.)
    */
   public AffineTransform getTransformInPageRegion(final PageRegion pageRegion){
      final AffineTransform transform =
         (AffineTransform)transformInPageRegion.get(pageRegion);
      if (transform == null) {
         return null;
      }
      else {
         return (AffineTransform)transform.clone();
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets the transform of this group within the specified page region.
    * (A group can be split across multiple pages within the same dialog.)
    */
   public void setTransformInPageRegion(
      final PageRegion pageRegion,
      final AffineTransform transform) {

      if (transform == null) {
         transformInPageRegion.remove(pageRegion);
      }
      else {
         transformInPageRegion.put(pageRegion, transform);
      }
      fireElementTransformUpdated(pageRegion);
   }

   //---------------------------------------------------------------------------

   public AffineTransform getTransform(DeviceType deviceType) {
      throw new UnsupportedOperationException("Use getTransformInPageRegion()");
   }

   //---------------------------------------------------------------------------

   public void setTransform(
      DeviceType deviceType,
      AffineTransform newTransform) {

      throw new UnsupportedOperationException("Use setTransformInPageRegion()");
   }

   //===========================================================================
   
   /**
    * Adds the specified group listener to receive group events from
    * this group.
    */
   public void addGroupListener(GroupListener listener) {
      groupEventSource.addGroupListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified group listener so that it no longer receives
    * group events from this group.
    */
   public void removeGroupListener(GroupListener listener) {
      groupEventSource.removeGroupListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementAdded events to listeners.
    */
   private void fireElementAdded(
      final DeviceType deviceType,
      final int index,
      final InteractionElement e) {

      containerEventSource.fireElementAdded(this, deviceType, index, e);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires elementRemoved events to listeners.
    */
   private void fireElementRemoved(
      final DeviceType deviceType,
      final int index,
      final InteractionElement e) {

      containerEventSource.fireElementRemoved(this, deviceType, index, e);
   }
   
   //---------------------------------------------------------------------------
   
   protected void fireElementTransformUpdated(final PageRegion region) {
      groupEventSource.fireElementTransformUpdated(this, region);
   }

   //===========================================================================
   
   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public void addElementContainerListener(
      ElementContainerListener listener) {

      containerEventSource.addElementContainerListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public void removeElementContainerListener(
      ElementContainerListener listener) {

      containerEventSource.removeElementContainerListener(listener);
   }
   
   //---------------------------------------------------------------------------
   
   private void fireElementBoundsUpdated(final PageRegion region) {
      groupEventSource.fireElementBoundsUpdated(this, region);
   }
   
   //===========================================================================
   
   public Component createCopy(final DeviceType deviceType) {
      return new ComponentGroup(this, deviceType);
   }
   
   //===========================================================================
   
   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      return clone(new HashMap());
   }
   
   //===========================================================================

   /**
    * Returns a clone of this object.
    * 
    * @param elementClones a mapping of elements to their clones. Used by
    * Dialog.clone() so that elements that are in different pages but the same
    * dialog will only be cloned once and reused in the pages' clones.
    */
   public Object clone(final Map elementClones) {
      final ComponentGroup clone = (ComponentGroup)super.clone();

      clone.boundsInPageRegion = new HashMap(boundsInPageRegion);
      clone.transformInPageRegion = new HashMap(transformInPageRegion);
      clone.containerEventSource = new ElementContainerSource();
      clone.groupEventSource = new GroupEventSource();
      
      clone.components = new HashSet/*<ComponentGroup>*/();
      
      for (Iterator i = components.iterator(); i.hasNext();) {
         
         // If clones of the components in the original group have been
         // passed in, then the clone of the group should contain the clones
         // of the components. Otherwise, it should contain nothing.
         final Component component = (Component)i.next();
         if (component instanceof ComponentGroup) {
            clone.components.add(((ComponentGroup) component)
                  .clone(elementClones));
         }
         else {
            final Control control = (Control)component;
            final Control controlClone = (Control)elementClones.get(control);
            if (controlClone != null) {
               clone.components.add(controlClone);
            }
         }
      }

      return clone;
   }

   //===========================================================================

   /**
    * Returns a string representation of this component, including the children
    * for <em>all</em> devices.
    */
   public String toLongString() {
      final StringBuffer sb = new StringBuffer();

      // 1. Print myself.
      sb.append(toString());
      sb.append('\n');

      // 2. For each device, recursively write the children
      sb.append(components.toString());

      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of this component, with the given indent
    * level and including the children for the given device.
    */
   public String toLongString(int indentLevel, final DeviceType deviceType) {
      // 1. Make sure we have a concrete device; "all" is not acceptable here.
      assert deviceType != DeviceType.ALL : "Device cannot be ALL";

      final StringBuffer sb = new StringBuffer();

      // 2. Add indent
      sb.append(StringLib.spaces(indentLevel * DamaskUtils.INDENT_SPACES));

      // 3. Print myself.
      sb.append(toString());
      sb.append('\n');

      // 4. Recursively write the children
      sb.append(StringLib.spaces((indentLevel + 1) * DamaskUtils.INDENT_SPACES));
      sb.append(components.toString());

      return sb.toString();
   }

   //---------------------------------------------------------------------------

//   /**
//    * Returns a string representation of the components in this group (from the
//    * given device's perspective) that are in the given set, with the given
//    * indent level.
//    * 
//    * @param indentLevel the indent level to output the strings at
//    * @param deviceType the type of device whose perspective we are using to
//    * get the components (the components that this group contains depend on
//    * which device type we are using to look at the group)
//    * @param setMembership a map that maps an item to whether it is a member
//    * of a set
//    */
//   protected String toString(
//      int indentLevel,
//      final DeviceType deviceType,
//      Map setMembership) {
//         
//      // 1. Make sure we have a concrete device; "all" is not acceptable here.
//      assert deviceType != DeviceType.ALL : "Device cannot be ALL";
//
//      final StringBuffer sb = new StringBuffer();
//
//      // 2. Add indent
//      sb.append(StringLib.spaces(indentLevel * DamaskUtils.INDENT_SPACES));
//
//      // 3. Print myself.
//      sb.append(toShortString());
//      sb.append('\n');
//
//      // 4. Recursively write the children
//      sb.append(
//         components.toString(indentLevel + 1, deviceType, setMembership));
//
//      return sb.toString();
//   }

   //===========================================================================
   
   /**
    * A comparator used to sort the page regions that this group is in.
    */
   private static class PageRegionComparator implements Comparator {
      private int getPageNumber(final PageRegion region) {
         final Page page = region.getPage();
         return page.getDialog().getPages(page.getDeviceType()).indexOf(page);
      }
      
      public int compare(Object o1, Object o2) {
         if (!(o1 instanceof PageRegion)) {
            throw new ClassCastException(
               "o1 must be of type PageRegion, not "
                  + (o1 == null ? null : o1.getClass()));
         }
         if (!(o2 instanceof PageRegion)) {
            throw new ClassCastException(
               "o2 must be of type PageRegion, not "
                  + (o2 == null ? null : o2.getClass()));
         }

         final int p1 = getPageNumber((PageRegion)o1);
         final int p2 = getPageNumber((PageRegion)o2);
         
         if (p1 < p2) {
            return -1;
         }
         else if (p1 == p2) {
            return 0;
         }
         else {
            return 1;
         }
      }
   }
}
