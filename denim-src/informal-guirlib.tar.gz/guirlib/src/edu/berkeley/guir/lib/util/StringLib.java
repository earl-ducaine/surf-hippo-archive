//// See bottom of source code for software license.
package edu.berkeley.guir.lib.util;

import java.awt.BasicStroke;
import java.awt.Component;
import java.awt.Polygon;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Rectangle2D;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import javax.swing.SwingUtilities;

/**
 * Various String utilities and routines for manipulating Strings, as well as
 * laying them out and rendering them on screen.
 *
 * <P>
 * Basically, everytime I needed a String utility that didn't exist, I went
 * ahead and wrote it up, placing it in here. There's lots of stuff here.
 *
 * <P>
 * The methods here can be roughly grouped into six categories:
 * <UL>
 *    <LI><B>Layout</B> - Handle the rows and columns of a String, fold a 
 *        String along a max number of columns.
 *    <LI><B>Predicates</B> - See if the String <B>is</B> something, like 
 *        a decimal number.
 *    <LI><B>Escape Sequence</B> - Transform a String with escape sequences 
 *        into a String with visible escape sequences, and vice versa.
 *    <LI><B>Counting</B> - Count the number of occurrences of a character 
 *         or String.
 *    <LI><B>String Creation</B> - Creating common Strings.
 *    <LI><B>String Manipulation</B> - Miscellaneous methods for 
 *        manipulating Strings.
 *    <LI><B>Object toString() output</B> - Printing out more useful
 *        information about an object than the standard toString() provided in
 *        the object.
 * </UL>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Jan 07 2004 JIH
 */
final public class StringLib {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * Get the system specific End Of Line
     */
    private final static String EOLN = System.getProperty("line.separator");

    /**
     * The maximum number of characters per line.
     */
    public static int DEFAULT_FOLD_LENGTH = 80;

    /**
     * 81 space characters.
     */
    public static String SPACES = "                                                                                                                                                                                                                                                  ";

    //===   CONSTANTS   ========================================================
    //==========================================================================



    //==========================================================================
    //===   CLASS VARIABLES   ==================================================

    /**
     * What characters to fold lines on. Currently whitespace only.
     */
    private static String foldTokens = " \n\t\r";

    /**
     * How many spaces to fold on.
     */
    private static int    foldLength = DEFAULT_FOLD_LENGTH;

    //===   CLASS VARIABLES   ==================================================
    //==========================================================================



    //==========================================================================
    //===   CLASS METHODS   ====================================================

    /**
     * Set the tokens to fold text on.
     * For example, specifying "\n\t" means that lines are wrapped
     * on those tokens.
     *
     * @param tokens is a String containing each of the characters to fold on.
     */
    public static void setFoldTokens(String tokens) {
       foldTokens = tokens;
    } // of method

    //-----------------------------------------------------------------

    /**
     * Set the number of spaces to fold on.
     * The fold length specifies how long Strings can be before they
     * are wrapped to the next line.
     *
     * @param val is the number of spaces to fold on.
     */
    public static void setFoldLength(int val) {
       // fold length must be positive
       assert val > 0; 
       foldLength = val;
    } // of method

    //===   CLASS METHODS   ====================================================
    //==========================================================================



    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * No instances allowed.
     */
    private StringLib() {
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================



    //==========================================================================
    //===   BLANK   ============================================================

    /**
     * Get an empty String of the specified length.
     * For example, blank(3) = "   " and blank(1) = " ".
     */
    public static String blank(int len) {
        if (len <= 0) {
            return ("");
        }
        else {
            return (SPACES.substring(SPACES.length() - len));
        }
    } // of method

    //===   BLANK   ============================================================
    //==========================================================================



    //==========================================================================
    //===   COMMA-SEPARATED VALUE   ============================================

    /**
     * Convert to a comma-separated value format,
     * quoting things correctly. By default, skips over null
     * values, leaving them blank.
     * @see edu.berkeley.guir.lib.util.ParserLib#parseCSV(String)
     */
    public static String toCSV(String[] strtoks) {
        StringBuffer strbuf = new StringBuffer();
        for (int i = 0; i < strtoks.length; i++) {
            if (i > 0) {
                strbuf.append(",");
            }
            if (strtoks[i] == null) {
                continue;
            }

            if (strtoks[i].indexOf(',') >= 0) {
                strbuf.append("\"");
                strbuf.append(strtoks[i]);
                strbuf.append("\"");
            }
            else {
                strbuf.append(strtoks[i]);
            }
        }
        return (strbuf.toString());
    } // of method

    //----------------------------------------------------------------

    public static String toCSV(Iterator it) {
        StringBuffer strbuf = new StringBuffer();
        String       str;

        while (it.hasNext()) {
            str = (String) it.next();

            if (str == null) {
                continue;
            }
            if (str.indexOf(',') >= 0) {
                strbuf.append("\"");
                strbuf.append(str);
                strbuf.append("\"");
            }
            else {
                strbuf.append(str);
            }
            if (it.hasNext()) {
                strbuf.append(",");
            }
        }
        return (strbuf.toString());
    } // of method

    //----------------------------------------------------------------

    public static String toCSV(List list) {
        return (toCSV(list.iterator()));
    } // of method

    //===   COMMA-SEPARATED VALUE   ============================================
    //==========================================================================



    //==========================================================================
    //===   STRING LAYOUT METHODS   ============================================

    /**
     * Pad this String with spaces at the front so that it is at least the 
     * specified length. For example, 
     * <UL>
     *    <LI>padAtFront("the", 5) = "  the"
     *    <LI>padAtFront("the", 2) = "the"
     * </UL>
     */
    public static String padAtFront(String str, int len) {
       return (blank(len - str.length()) + str);
    } // of method

    //--------------------

    /**
     * Pad this String with spaces at the end so that it is at least 
     * the specified length.
     * <UL>
     *    <LI>padAtEnd("the", 5) = "the  "
     *    <LI>padAtEnd("the", 2) = "the"
     * </UL>
     */
    public static String padAtEnd(String str, int len) {
       return (str + blank(len - str.length()));
    } // of method

    //-----------------------------------------------------------------

    /**
     * Count the number of rows this String fills up, based on where the
     * carriage returns '\n' are. (It also does the last row correctly, if 
     * it has a '\n' or not).
     * <UL>
     *    <LI>getNumRows("hi") = 1
     *    <LI>getNumRows("hi\nthere") = 2
     *    <LI>getNumRows("hi\nthere\n") = 2
     *    <LI>getNumRows("hi\nthere\neveryone") = 3
     * </UL>
     *
     * @see    #getNumRows(java.lang.String, int)
     * @param  str is the String whose rows we will count.
     * @return the number of rows this String will take to layout.
     */
    public static int getNumRows(String str) {
       //// 1. This should work whether CR is '\n' or '\r\n' 
       ////    since there is always a '\n' no matter what.
       int count = countNumOfChar('\n', str);
       if (str.charAt(str.length() - 1) != '\n') {
          count++;
       }
       return (count);
    } // of method

    //--------------------

    /**
     * Count the number of rows this String fills up, taking into account 
     * that it may have a column limit (ie max num of chars per line).
     *
     * @see    #getNumRows(java.lang.String)
     * @param  str     is the String whose rows we will count.
     * @param  numCols is the number of columns (chars / row) to layout on.
     * @return the number of rows this String will take to layout.
     */
    public static int getNumRows(String str, int numCols) {
       //// 1. Fold the String first.
       String strTmp = fold("", str, numCols);

       //// 2. Now count the number of rows.
       return (getNumRows(strTmp));
    } // of method

    //-----------------------------------------------------------------

    /**
     * After laying out the String into rows, count the number of characters
     * in the longest line. 
     *
     * @param  str     is the String whose max columns we will count.
     * @param  eoln    specifies what the end-of-line is. Should be either
     *                 "\n" or "\r\n".
     * @return the number of characters in the longest row.
     */
    public static int getMaxNumCols(String str, String eoln) {
       StringTokenizer strtok = new StringTokenizer(str, eoln);
       String          strTmp;
       int             maxlen = 0;

       while (strtok.hasMoreTokens()) {
          strTmp = strtok.nextToken();
          if (strTmp.length() > maxlen) {
             maxlen = strTmp.length();
          }
       }

       return (maxlen);
    } // of method

    //--------------------

    /**
     * After laying out the String into rows, count the number of characters 
     * in the longest line. Calls the other getMaxNumCols() after folding the
     * String according to the numCols.
     *
     * @see    #getMaxNumCols(java.lang.String, java.lang.String)
     * @param  str     is the String whose max columns we will count.
     * @param  eoln    specifies what the end-of-line is. Should be either
     *                 "\n" or "\r\n".
     * @param  numCols is the number of columns (chars / row) to layout on.
     * @return the number of characters in the longest row.
     */
    public static int getMaxNumCols(String str, String eoln, int numCols) {
       //// 1. Fold the String first.
       String strTmp = fold("", str, eoln, numCols);

       //// 2. Now count the max number of cols.
       return (getMaxNumCols(strTmp, eoln));
    } // of method

    //--------------------

    /**
     * After laying out the String into rows, count the number of characters 
     * in the longest line. Calls the other getMaxNumCols() using the system
     * specific line separator.
     * <UL>
     *    <LI>getMaxNumCols("hi") = 2   // "hi" is length 2
     *    <LI>getMaxNumCols("hi\nthere") = 5  // "there" is longer than "hi"
     *    <LI>getMaxNumCols("hi\nthere\n") = 5
     *    <LI>getMaxNumCols("hi\nthere\neveryone") = 8
     * </UL>
     *
     * @see    #getMaxNumCols(java.lang.String, java.lang.String)
     * @param  str is the String whose max columns we will count.
     * @return the number of characters in the longest row.
     */
    public static int getMaxNumCols(String str) {
       return (getMaxNumCols(str, EOLN));
    } // of method

    //--------------------

    /**
     * After laying out the String into rows, count the number of characters 
     * in the longest line. Calls the other getMaxNumCols() using the system
     * specific line separator.
     *
     * @see    #getMaxNumCols(java.lang.String, java.lang.String)
     * @param  str     is the String whose max columns we will count.
     * @param  numCols is the number of columns (chars / row) to layout on.
     * @return the number of characters in the longest row.
     */
    public static int getMaxNumCols(String str, int numCols) {
       return (getMaxNumCols(str, EOLN, numCols));
    } // of method

    //----------------------------------------------------------------

    /**
     * @see   #setFoldTokens(java.lang.String)
     * @see   #fold(java.lang.String, java.lang.String, java.lang.String, int)
     * @param obj1 is the description line.
     * @param obj2 is the text to fold.
     */
    public static String fold(Object obj1, Object obj2) {
       return (fold(obj1.toString(), obj2.toString()));
    } // of method

    //--------------------

    /**
     * See fold(). Uses a blank String as the prefix, and the system specific
     * line separator as end of line..
     * <P>
     * Examples:
     * <PRE>
     *
     * fold("hi there everyone does this work?", 5) =
     * hi
     * there
     * everyone
     * does
     * this
     * work?
     * 
     * fold("hi there everyone does this work?", 10) =
     * hi there
     * everyone
     * does this
     * work?
     * 
     * fold("hi there everyone does this work?", 25) =
     * hi there everyone does
     * this work?
     *
     *
     * </PRE>
     *
     * @see   #setFoldTokens(java.lang.String)
     * @see   #setFoldLength(int)
     * @see   #fold(java.lang.String, java.lang.String, java.lang.String, int)
     * @param strText is the text to fold.
     * @param numCols is the max number of characters per line.
     */
    public static String fold(String strText, int numCols) {
       return (fold("", strText, EOLN, numCols));
    } // of method

    //--------------------

    /**
     * See fold(). Uses the system specific line separator and the default 
     * fold length.
     *
     * @see   #setFoldTokens(java.lang.String)
     * @see   #setFoldLength(int)
     * @see   #fold(java.lang.String, java.lang.String, java.lang.String, int)
     * @param strPrefix is the description line to prepend to every new line.
     * @param strText   is the text to fold.
     * @param numCols   is the max number of characters per line.
     */
    public static String fold(String strPrefix, String strText, int numCols) {
       return (fold(strPrefix, strText, EOLN, numCols));
    } // of method

    //--------------------

    /**
     * See fold(). Uses the system specific line separator and the default fold
     * length.
     *
     * @see   #setFoldTokens(java.lang.String)
     * @see   #setFoldLength(int)
     * @see   #fold(java.lang.String, java.lang.String, java.lang.String, int)
     * @param strPrefix is the description line to prepend to every new line.
     * @param strText is the text to fold.
     */
    public static String fold(String strPrefix, String strText) {
       return (fold(strPrefix, strText, EOLN, foldLength));
    } // of method

    //--------------------

    /**
     * Fold the text around to the next line correctly. For example, given
     * a prefix of "Estragon: " and text "Would you like a radish? It would
     * help pass the time." the output would look something like:
     *
     * <P>
     * <PRE>
     *    Estragon: Would you like a radish? It would help
     *              pass the time.
     * </PRE>
     *
     * @see   #setFoldTokens(java.lang.String)
     * @param strPrefix is the description line to prepend to every new line.
     * @param strText   is the text to fold.
     * @param eoln      is the end-of-line character to append.
     * @param numCols   is the max number of characters per line.
     */
    public static String fold(String strPrefix, String strText, 
                              String eoln, int numCols) {

       StringBuffer strbuf     = new StringBuffer();
       int          currentLen = strPrefix.length();
       String       spaces     = blank(strPrefix.length());
       boolean      flagStart  = true;

       //// 0. Initialize.
       strbuf.append(strPrefix);

       //// 1. Initialize the tokenizer.
       StringTokenizer strtok = 
             new StringTokenizer(strText, foldTokens, true);

       //// 2. Go through all of the tokens.
       while (strtok.hasMoreTokens()) {
          String strAppend = strtok.nextToken();
          int    appendLen = strAppend.length();

          //// 2.1. flagStart is used to ensure we do not fold on the first
          ////      token, since it's pointless to do so.
          if ((flagStart == false) &&
              (currentLen + appendLen > numCols) || 
              (strAppend.endsWith("\r"))         ||
              (strAppend.endsWith("\n"))) {

             strbuf.append(eoln + spaces + strAppend.trim());
             currentLen = spaces.length() + appendLen;
             flagStart  = true;
          }
          else {
             strbuf.append(strAppend);
             currentLen += appendLen;
             flagStart   = false;
          }
       }

       return (strbuf.toString());
    } // of method

    //----------------------------------------------------------------

    /**
     * Align text in a String into two columns. For example, we can convert:
     * <PRE>
     *    Date: 08/02/1999
     *    Name: John
     *    Occupation: Programmer
     *    Address: blah
     * </PRE>
     * ...into...
     * <PRE>
     *          Date: 08/02/1999
     *          Name: John
     *    Occupation: Programmer
     *       Address: blah
     * </PRE>
     *
     * @param ch is the char to parse and split on.
     */
    public static final String alignRight(String str, char ch) {
       //// 1. Delegate to another formatting method.
       return (alignRight( ParserLib.parseAsMap(str, ch), "" + ch, ""));
    } // of method

    //--------------------

    /**
     * Align text in a String into two columns. For example, we can convert:
     * <PRE>
     *    Date: 08/02/1999
     *    Name: John
     *    Occupation: Programmer
     *    Address: blah
     * </PRE>
     * ...into...
     * <PRE>
     *    Date:       08/02/1999
     *    Name:       John
     *    Occupation: Programmer
     *    Address:    blah
     * </PRE>
     *
     * @param ch is the char to parse and split on.
     */
    public static final String alignLeft(String str, char ch) {
       //// 1. Delegate to another formatting method.
       return (alignLeft( ParserLib.parseAsMap(str, ch), "" + ch, ""));
    } // of method

    //----------------------------------------------------------------

    /**
     * @see #alignLeft(Map, String, String)
     */
    public static final String alignLeft(Map map) {
        return ( alignLeft(map, ":", "") );
    } // of method

    //--------------------

    /**
     * Given a map, create a String representation with all of the
     * values lined up. For example:
     * <PRE>
     *    temp:     90
     *    humidity: 14%
     *    smog:     78
     * </PRE>
     *
     * @param map  is the map contain key-value pairs.
     * @param pre  is what to append after the key, ex. ":" or "=\""
     * @param post is what to append after the value, ex. "" or "\""
     */
    public static final String alignLeft(Map map, String pre, String post) {
        return ( align(map, new LinkedList(map.keySet()), pre, post, 1) );
    } // of method

    //--------------------

    /**
     * @param map      is the map contain key-value pairs.
     * @param listKeys is the keys in the order to be printed.
     * @param pre      is what to append after the key, ex. ":" or "=\""
     * @param post     is what to append after the value, ex. "" or "\""
     */
    public static String alignLeft(Map    map, 
                                   List   listKeys, 
                                   String pre, 
                                   String post) {
        return ( align(map, listKeys, pre, post, 1) );
    } // of method

    //-----------------------------------------------------------------

    /**
     * @see #alignRight(Map, String, String)
     */
    public static String alignRight(Map map) {
        return ( alignRight(map, "=", "") );
    } // of method

    //--------------------

    /**
     * Given a map, create a String representation with all of the
     * '=' signs lined up. For example:
     * <PRE>
     *        temp=90
     *    humidity=14%
     *        smog=78
     * </PRE>
     */
    public static String alignRight(Map map, String pre, String post) {
        return ( align(map, new LinkedList(map.keySet()), pre, post, 0) );
    } // of method

    //--------------------

    /**
     * @param map      is the map contain key-value pairs.
     * @param listKeys is the keys in the order to be printed.
     * @param pre      is what to append after the key, ex. ":" or "=\""
     * @param post     is what to append after the value, ex. "" or "\""
     */
    public static String alignRight(Map    map, 
                                    List   listKeys, 
                                    String pre, 
                                    String post) {
        return ( align(map, listKeys, pre, post, 0) );
    } // of method

    //-----------------------------------------------------------------

    /**
     * @param map  is the map contain key-value pairs
     * @param alignType 0 means align left, 1 means align center
     * @param pre  is what to append after the key, ex. ":" or "=\""
     * @param post is what to append after the value, ex. "" or "\""
     */
    private static String align(Map    map, 
                                List   listKeys,
                                String pre, 
                                String post, 
                                int    alignType) {

        //// 1. Figure out the longest key name.
        int      maxlen  = 0;
        int      numKeys = 0;
        Iterator it      = listKeys.iterator();
        Object   objKey;
        Object   objVal;
        Map      mapCopy = new LinkedHashMap();

        while (it.hasNext()) {
            objKey = it.next();
            objVal = map.get(objKey);

            //// 1.1. Ignore null values.
            if (objVal != null) {
                mapCopy.put(objKey, objVal);
                maxlen = Math.max(maxlen, objKey.toString().length());
                numKeys++;
            }
        }


        //// 2. Now start assembling the Strings, in the format of
        ////    key=val. Also pad, so that the = match up in the Strings.
        StringBuffer strbuf = new StringBuffer();
        int          paddingNeeded;

        it = mapCopy.keySet().iterator();
        while (it.hasNext()) {
            numKeys--;

            //// 2.1. Assemble a single key=value pair.
            ////      Ignore no-value keys.
            objKey        = it.next();
            objVal        = map.get(objKey);
            if (objVal == null) {
                continue;
            }
            paddingNeeded = maxlen - objKey.toString().length();

            //// 2.2.1. Align right...
            if (alignType == 0) {
                strbuf.append(blank(paddingNeeded));
                strbuf.append(objKey);
                strbuf.append(pre);
                strbuf.append(objVal);
                strbuf.append(post);
            }
            //// 2.2.2. Align left...
            else if (alignType == 1) {
                strbuf.append(objKey);
                strbuf.append(pre);
                strbuf.append(blank(paddingNeeded + 1));
                strbuf.append(objVal);
                strbuf.append(post);
            }

            //// 2.2. Don't append "\n" to the last value.
            if (numKeys > 0) {
                strbuf.append("\n");
            }
        }

        return (strbuf.toString());
    } // of method

    //===   STRING LAYOUT METHODS   ============================================
    //==========================================================================



    //==========================================================================
    //===   PREDICATE FUNCTIONS   ==============================================

    /**
     * See if a given String contains any of the specified characters.
     *
     * @param str is the String to look through.
     * @param strChars is the set of characters to look for in str.
     */
    public static boolean containsChars(String str, String strChars) {
       return(containsChars(str, strChars.toCharArray()));
    } // of method

    //--------------------

    /**
     * See if a given String contains any of the specified characters.
     *
     * @param str is the String to look through.
     * @param chars is the set of characters to look for in str.
     */
    public static boolean containsChars(String str, char[] chars) {
       char compare;
       for (int i = 0; i < str.length(); i++) {
          compare = str.charAt(i);
          for (int j = 0; j < chars.length; j++) {
             if (compare == chars[j]) {
                return (true);
             }
          }
       }
       return (false);
    } // of method

    //-----------------------------------------------------------------

    /**
     * See if a given String is a decimal number or not.
     *
     * @param  str is the String to check.
     * @return true if the String is a decimal number, false otherwise.
     */
    public boolean isDecimalNumber(String str) {
       for (int i = 0; i < str.length(); i++) {
          if ( !Character.isDigit(str.charAt(i))) {
             return (false);
          }
       }
       return (true);
    } // of method

    //===   PREDICATE FUNCTIONS   ==============================================
    //==========================================================================



    //==========================================================================
    //===   ESCAPE SEQUENCE METHODS   ==========================================

    /**
     * Given a String literally containing escape sequences (including unicode
     * ones), convert it into a String with the interpreted escape sequences 
     * in place.
     *
     * <P>
     * For example, given the String "\r\n" which has 4 characters, convert it
     * into a String containing the interpreted meanings of '\r' and '\n' with 
     * 2 characters.
     *
     * @param str is the String containing the escape sequences to interpret.
     */
    public static String interpretString(String str) {
       StringBuffer strbuf = new StringBuffer();
       char         ch;

       for (int i = 0; i < str.length(); i++) {
          ch = str.charAt(i);

          //// 1. An escape sequence.
          if (ch == '\\') {
             //// 1.1. Unicode escape sequence.
             if (str.charAt(i+1) == 'u') {
                ch = interpretEscapeSequence(str.substring(i, i+6));
                i += 5; // add the length of the string to the counter
             }
             //// 1.2. Ordinary escape sequence.
             else {
                ch = interpretEscapeSequence(str.substring(i, i+2));
                i += 1; // add the length of the string to the counter
             }
          }

          //// 2. Add the character to the String.
          strbuf.append(ch);
       }

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Given a String containing an escape sequence, interpret what it is.
     *
     * @param  str is a String containing an escape sequence.
     * @return the character represented by the escape sequence.
     */
    public static char interpretEscapeSequence(String str) {
       if (str.length() >= 2 && str.charAt(0) == '\\') {
          switch (str.charAt(1)) {
             case 'b' :  return('\b');
             case 't' :  return('\t');
             case 'n' :  return('\n');
             case 'f' :  return('\f');
             case 'r' :  return('\r');
             case '"' :  return('\"');
             case '\'':  return('\'');
             case '\\':  return('\\');
             case 'u' :  try {
                           String strRest = str.substring(2);
                           int    val     = Integer.parseInt(strRest, 16);
                           if (val < 65535) {
                              return((char) val);
                           }
                        }
                        catch (Exception e) {
                        }
          } // of switch
       }
       return((char)0);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Convert all non-printing characters in the specified String into their 
     * escape sequence equivalents.
     *
     * @param  str is the String that might contain some escape characters.
     * @return a String with special characters replaced by escape sequence
     *         equivalents.
     */
    public static String reverseInterpretString(String str) {
       StringBuffer strbuf = new StringBuffer();

       for (int i = 0; i < str.length(); i++) {
          strbuf.append(reverseInterpretEscapeSequence(str.charAt(i)));
       }

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Convert non-printing characters into their escape sequence equivalents.
     *
     * @param  b is a byte that might be an escape sequence character.
     * @return a String containing the character or its escape sequence.
     */
    public static String reverseInterpretEscapeSequence(byte b) {
       return (reverseInterpretEscapeSequence((char) b));
    } // of method

    //-----------------------------------------------------------------

    /**
     * Convert non-printing characters into their escape sequence equivalents.
     *
     * @param  ch is the character that might be an escape sequence character.
     * @return a String containing the character or its escape sequence.
     */
    public static String reverseInterpretEscapeSequence(char ch) {
       switch (ch) {
          case '\b': return("\\b");
          case '\t': return("\\t");
          case '\n': return("\\n");
          case '\f': return("\\f");
          case '\r': return("\\r");
       } // of switch
       return("" + ch);
    } // of method

    //===   ESCAPE SEQUENCE METHODS   ==========================================
    //==========================================================================



    //==========================================================================
    //===   COUNTING METHODS   =================================================

    /**
     * Count the number of occurrences of a character in a String.
     *
     * @param  chSearch is the character to search for.
     * @param  strLine is the String to search through.
     * @return The number of times the character was found in the String.
     */
    public static int countNumOfChar(char chSearch, String strLine) {
       int iNumOccurrences = 0;
       int iStartIndex     = 0;

       iStartIndex = strLine.indexOf(chSearch, 0);

       while (iStartIndex != -1) {
          iNumOccurrences++;
          iStartIndex = strLine.indexOf(chSearch, iStartIndex + 1);
       }

       return(iNumOccurrences);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Count the number of occurrences of a String in a String.
     *
     * @param  strSearch is the String to search for.
     * @param  strLine is the String to search through.
     * @return The number of times the character was found in the String.
     */
    public static int countNumOfString(String strSearch, String strLine) {
       int iNumOccurrences = 0;
       int iStartIndex     = 0;

       iStartIndex = strLine.indexOf(strSearch, 0);

       while (iStartIndex != -1) {
          iNumOccurrences++;
          iStartIndex = strLine.indexOf(strSearch, iStartIndex + 1);
       }

       return(iNumOccurrences);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Given a collection, figure out the longest String length.
     * Treats null as String length 0 or length 4 (depending on parameter
     * flagNullIsZero).
     *
     * @param col            is the collection to iterate over
     *                       Can contain any Objects, we just use toString().
     * @param flagNullIsZero is true if null has string length 0.
     *                       Otherwise, we treat it as string length 4.
     */
    public static int calcLongestStringLen(Collection col,
                                           boolean    flagNullIsZero) {
        Iterator it     = col.iterator();
        int      maxLen = 0;
        Object   obj;

        while (it.hasNext()) {
            obj = it.next();
            if (obj == null) {
                if (flagNullIsZero == true) {
                    continue;
                }
                else {
                    obj = "null";
                }
            }
            maxLen = Math.max(maxLen, obj.toString().length());
        }
        return (maxLen);
    } // of method

    //===   COUNTING METHODS   =================================================
    //==========================================================================




    //==========================================================================
    //===   STRING CREATION METHODS   ==========================================

    /**
     * Generate a String of the specified length, consisting of numbers.
     * For example, generateString(15) = "012345678901234"
     */
    public static String generateString(int len) {
        StringBuffer strbuf = new StringBuffer();
        for (int i = 0; i < len; i++) {
            strbuf.append("" + i % 10);
        }
        return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Repeat the character 80 times and return it as a String.
     */
    public static String getBarredLine(char ch) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();

       for (int i = 0; i < 80; i++) {
          strbuf.append(ch);
       }

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Given a String like "example" and a char like '=', return
     * <PRE>
     * ===   example   =========...
     * </PRE>
     *
     * where the line is exactly 80 chars long.
     */
    public static String getBarredLine(String strText, char ch) {
       StringBuffer strbuf = new StringBuffer();
       int          len    = 0;

       //// 1. Add the first three chars.
       for (len = 0; len < 3; len++) {
          strbuf.append(ch);
       }

       //// 2. Add three spaces.
       strbuf.append("   ");
       len += 3;

       //// 3. Add in the string.
       strbuf.append(strText);
       len += strText.length();

       //// 4. Add three spaces.
       strbuf.append("   ");
       len += 3;

       //// 5. Add in the rest until it hits 80 chars.
       while (len < 80) {
          strbuf.append(ch);
          len++;
       }

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Return a String full of spaces, up to 80.
     *
     * @param len is the number of spaces to return.
     */
    public static String spaces(int len) {
       return (SPACES.substring(0, len));
    } // of method

    //-----------------------------------------------------------------
    
    /**
     * Join an array of Strings into one String.
     */
    public static String join(String[] strings) {
       return join(strings, " ");
    }
    
    //-----------------------------------------------------------------
    
    /**
     * Join an collection of Strings into one String.
     */
    public static String join(Collection strings) {
       return join(strings, " ");
    }
    
    //-----------------------------------------------------------------
    
    /**
     * Join an array of Strings into one String, separated by the
     * specified character.
     */
    public static String join(String[] strings, String delimiter) {
       final StringBuffer sb = new StringBuffer();
       for (int i = 0, n = strings.length; i < n; i++) {
          sb.append(strings[i]);
          sb.append(delimiter);
       }
       return sb.toString();
    }

    //-----------------------------------------------------------------
    
    /**
     * Join an collection of Strings into one String, separated by the
     * specified character.
     */
    public static String join(Collection strings, String delimiter) {
       final StringBuffer sb = new StringBuffer();
       for (Iterator i = strings.iterator(); i.hasNext(); ) {
          final String s = (String)i.next();
          sb.append(s);
          sb.append(delimiter);
       }
       return sb.toString();
    }

    //===   STRING CREATION METHODS   ==========================================
    //==========================================================================




    //==========================================================================
    //===   STRING MANIPULATION METHODS   ======================================

    /**
     * Remove all characters from a String starting from the first location
     * of one character to the first location of another character.
     *
     * @param  chFrom is the character to start deleting from.
     * @param  chTo   is the character to end deleting.
     * @param  strLine is the String to remove characters from.
     * @return A String with characters removed, unmodified if the delimiting
     *         characters do not exist in the String.
     */
    public static String removeSubstring(char   chFrom, 
                                         char   chTo, 
                                         String strLine) {

       int iStartIndex;
       int iEndIndex;

       //// Find the start and end indices
       iStartIndex = strLine.indexOf(chFrom);
       iEndIndex   = strLine.indexOf(chTo, iStartIndex + 1);

       //// Now remove all characters between these indices
       if (iStartIndex == -1 || iEndIndex == -1)
          return(strLine);

       return(strLine.substring(0, iStartIndex) + 
              strLine.substring(iEndIndex + 1));
    } // of method

    //-----------------------------------------------------------------

    /**
     * Given a String, find all instances of the specified substring and replace
     * it with the specified String.
     *
     * @param str        is the String to search through.
     * @param strSearch  is the non-empty String to search for.
     * @param strReplace is the String to replace strSearch with.
     * @deprecated use {@link String#replaceAll(String,String)} in JDK1.4
     */
    public static String replaceSubstring(String str, 
                                          String strSearch, 
                                          String strReplace) {

       if (strSearch.equals("") == true) {
          return (str);
       }

       int start = 0;
       int end   = str.indexOf(strSearch);

       if (end >= 0) {
          int len = strSearch.length();
          StringBuffer strbuf = new StringBuffer(2*len);
          while (end >= 0) {
             strbuf.append(str.substring(start, end) + strReplace);
             start = end + len;
             end = str.indexOf(strSearch, start);
          }
          strbuf.append(str.substring(start));
          return (strbuf.toString());
       }

       return (str);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Indent a String the specified number of spaces.
     * For example:
     * <UL>
     *    <LI>indent("hi", 3) = "   hi"
     *    <LI>indent("hi\nthere", 3) = "   hi\n   there" (indents all '\n')
     *    <LI>indent("hi\nthere\n", 3) = "   hi\n   there\n" (doesn't append to
     *        final '\n')
     * </UL>
     *
     * @param str       is the String to indent.
     * @param numSpaces is the number of spaces to indent.
     */
    public static String indent(String str, int numSpaces) {
        //// 1. Replace all newlines and indent.
        String strReplace = "\n" + blank(numSpaces);
        str = str.replaceAll("\n", strReplace);
        str = blank(numSpaces) + str;

        //// 2. Make sure we don't end with strReplace.
        if (str.endsWith(strReplace) == true) {
            str  = str.substring(0, str.length() - strReplace.length());
            str += "\n";
        }

        return (str);
    } // of method

    //===   STRING MANIPULATION METHODS   ======================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING METHODS   =================================================

    /**
     * Convert a String to a byte array.
     */
    public static byte[] toByteArray(String str)
        throws IOException {

        ByteArrayOutputStream bostream = new ByteArrayOutputStream();
        OutputStreamWriter    wtr      = new OutputStreamWriter(bostream);
        wtr.write(str);
        wtr.flush();
        return (bostream.toByteArray());
    } // of method

    //-----------------------------------------------------------------

    public static final String toString(Object obj) {
       return (obj.toString());
    } // of method

    //-----------------------------------------------------------------

    public static final String toString(MouseEvent evt) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("MouseEvent[");
       switch (evt.getID()) {
          case MouseEvent.MOUSE_CLICKED:  strbuf.append("MOUSE_CLICKED,  ");
                                          break;
          case MouseEvent.MOUSE_DRAGGED:  strbuf.append("MOUSE_DRAGGED,  ");
                                          break;
          case MouseEvent.MOUSE_ENTERED:  strbuf.append("MOUSE_ENTERED,  ");
                                          break;
          case MouseEvent.MOUSE_EXITED:   strbuf.append("MOUSE_EXITED,   ");
                                          break;
          case MouseEvent.MOUSE_MOVED:    strbuf.append("MOUSE_MOVED,    ");
                                          break;
          case MouseEvent.MOUSE_PRESSED:  strbuf.append("MOUSE_PRESSED,  ");
                                          break;
          case MouseEvent.MOUSE_RELEASED: strbuf.append("MOUSE_RELEASED, ");
                                          break;
       }

       if (SwingUtilities.isLeftMouseButton(evt)) {
          strbuf.append("L");
       }
       else {
          strbuf.append(" ");
       }

       if (SwingUtilities.isMiddleMouseButton(evt)) {
          strbuf.append("M");
       }
       else {
          strbuf.append(" ");
       }

       if (SwingUtilities.isRightMouseButton(evt)) {
          strbuf.append("R ");
       }
       else {
          strbuf.append("  ");
       }

       strbuf.append("(" + evt.getX() + "," + evt.getY() + ")");
       strbuf.append(" on " + ((Component) evt.getSource()).getName());

       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this Iterator into something suitable for printing.
     */
    public static final String toString(Iterator it) {
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       while (it.hasNext()) {
          strbuf.append(it.next() + ", ");
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this Enumeration into something suitable for printing.
     */
    public static final String toString(Enumeration en) {
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       while (en.hasMoreElements()) {
          strbuf.append(en.nextElement() + ", ");
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this array into something suitable for printing.
     */
    public static final String toString(Object[] array) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       for (int i = 0; i < array.length; i++) {
          if (array[i] != null) {
             strbuf.append(array[i].toString() + ", ");
          }
          else {
             strbuf.append("null, ");
          }
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this array into something suitable for printing.
     */
    public static final String toString(boolean[] array) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       for (int i = 0; i < array.length; i++) {
          if (array[i] == true) {
             strbuf.append("T");
          }
          else {
             strbuf.append("F");
          }
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this array into something suitable for printing.
     */
    public static final String toString(char[] array) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       for (int i = 0; i < array.length; i++) {
          strbuf.append(array[i]);
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this array into something suitable for printing.
     */
    public static final String toString(byte[] array) {
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       for (int i = 0; i < array.length; i++) {
          strbuf.append(array[i] + ", ");
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this array into something suitable for printing.
     */
    public static final String toString(short[] array) {
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       for (int i = 0; i < array.length; i++) {
          strbuf.append(array[i] + ", ");
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this array into something suitable for printing.
     */
    public static final String toString(int[] array) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       for (int i = 0; i < array.length; i++) {
          strbuf.append(array[i] + ", ");
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this array into something suitable for printing.
     */
    public static final String toString(long[] array) {
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       for (int i = 0; i < array.length; i++) {
          strbuf.append(array[i] + ", ");
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this array into something suitable for printing.
     */
    public static final String toString(float[] array) {
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       for (int i = 0; i < array.length; i++) {
          strbuf.append(array[i] + ", ");
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Turn this array into something suitable for printing.
     */
    public static final String toString(double[] array) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       for (int i = 0; i < array.length; i++) {
          strbuf.append(array[i] + ", ");
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Print out a Rectangle decently.
     */
    public static final String toString(Rectangle2D rect) {
       double x1 = rect.getX();
       double y1 = rect.getY();
       double w  = rect.getWidth();
       double h  = rect.getHeight();
       double x2 = x1 + w;
       double y2 = y1 + h;

       return ("[x1=" + x1 + " y1=" + y1 + 
               " x2=" + x2 + " y2=" + y2 + 
               " w="  + w  + " h="  + h  + "]");
    } // of method

    //-----------------------------------------------------------------

    /**
     * This is because polygon is stupid.
     */
    public static final String toString(Polygon poly) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       for (int i = 0; i < poly.npoints; i++) {
          strbuf.append("(" + poly.xpoints[i] + "," + poly.ypoints[i] + ")");
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Print out an ellipse.
     */
    public static final String toString(Ellipse2D ellipse) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();

       strbuf.append(ellipse.toString() + " " + ellipse.getBounds());

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * Given a segment type (in {@link PathIterator}, return a String with the
     * kind of segment.
     */
    public static String getSegmentType(int val) {
       switch (val) {
          case PathIterator.SEG_CLOSE:   return("SEG_CLOSE  ");
          case PathIterator.SEG_CUBICTO: return("SEG_CUBICTO");
          case PathIterator.SEG_LINETO:  return("SEG_LINETO ");
          case PathIterator.SEG_MOVETO:  return("SEG_MOVETO ");
          case PathIterator.SEG_QUADTO:  return("SEG_QUADTO ");
       }
       return ("unknown");
    } // of method

    //---------------------------------------------------------------------

    /**
     * Convert a path iterator into a human readable string.
     */
    public static final String toString(PathIterator it) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();
       float[]      f      = new float[6];

       while (!it.isDone()) {
          strbuf.append(getSegmentType(it.currentSegment(f)));
          strbuf.append(" ");
          strbuf.append(toString(f));
          strbuf.append("\n");
          it.next();
       }

       return (strbuf.toString());
    } // of method

    //-----------------------------------------------------------------

    /**
     * For BasicStroke.
     */
    private static String getJoinString(BasicStroke bstk) {
       switch (bstk.getLineJoin()) {
          case BasicStroke.JOIN_MITER: return ("Miter");
          case BasicStroke.JOIN_ROUND: return ("Round");
          case BasicStroke.JOIN_BEVEL: return ("Bevel");
          default: return ("Unknown");
       }
    } // of method

    //---------------------------------------------------------------------

    /**
     * For BasicStroke.
     */
    private static String getCapString(BasicStroke bstk) {
       switch (bstk.getEndCap()) {
          case BasicStroke.CAP_BUTT:   return ("Butt");
          case BasicStroke.CAP_ROUND:  return ("Round");
          case BasicStroke.CAP_SQUARE: return ("Square");
          default: return ("Unknown");
       }
    } // of method

    //---------------------------------------------------------------------

    /**
     * Convert a BasicStroke object into a String.
     */
    public static final String toString(BasicStroke bstk) {
       //// A. Get soft-state.
       StringBuffer strbuf = new StringBuffer();

       strbuf.append("[");
       strbuf.append("LineWidth: "  + bstk.getLineWidth()  + ", ");
       strbuf.append("EndCap: "     + getCapString(bstk)   + ", ");
       strbuf.append("LineJoin: "   + getJoinString(bstk)  + ", ");
       strbuf.append("MiterLimit: " + bstk.getMiterLimit() + ", ");
       strbuf.append("DashPhase: "  + bstk.getDashPhase()  + ", ");
       if (bstk.getDashArray() != null) {
          strbuf.append("DashArray: "  + toString(bstk.getDashArray()));
       }
       strbuf.append("]");

       return (strbuf.toString());
    } // of method

    //===   TOSTRING METHODS   =================================================
    //==========================================================================




    //==========================================================================
    //===   SELF TESTING MAIN   ================================================

    public static void main(String[] argv) {
        System.out.println(toCSV(new String[] {"a", "b", "c,d", ""}));
        List list = new LinkedList();
        list.add("");
        list.add("washington,dc");
        list.add("a");
        list.add("");
        list.add("");
        System.out.println(toCSV(list));
    } // of main



/*
   public static void main(String[] argv) throws Exception {
      System.out.println('"');
      System.out.println('\"');

      String str = "\\\"";
      System.out.println(str);
      System.out.println(interpretEscapeSequence(str));

      System.out.println((int) '"');
      System.out.println((int) '\"');
   } // of main
*/
/*
   public static void main1(String[] argv) throws Exception {
      System.out.println(replaceSubstring("", "dog", "cat"));
      System.out.println(replaceSubstring("", "", "cat"));
      System.out.println(replaceSubstring("dog", "", "cat"));
      System.out.println(replaceSubstring("dog", "dog", "cat"));
      System.out.println(replaceSubstring("dog", "dog", ""));

      System.out.println(toString(new Rectangle2D.Float(10, 20, 30, 40)));
   } // of main
*/

/*
   public static void main2(String[] argv) throws Exception {
      System.out.println("[" + padAtFront("dog:", 5)   + "]");
      System.out.println("[" + padAtFront("high:", 5)  + "]");
      System.out.println("[" + padAtFront("fiver:", 5) + "]");
      System.out.println("[" + padAtFront("", 5)       + "]");

      System.out.println("[" + padAtEnd("dog:", 5)   + "]");
      System.out.println("[" + padAtEnd("high:", 5)  + "]");
      System.out.println("[" + padAtEnd("fiver:", 5) + "]");
      System.out.println("[" + padAtEnd("", 5)       + "]");
   } // of main
*/

/*
   public static void main3(String[] argv) throws Exception {
      System.out.println("the dog");
      System.out.println(indent("the dog", 5));
      System.out.println(indent("the dog\nis here or there \nto stay", 5));
      System.out.println(indent("the dog\nis here or there \nto stay\n", 5));

      System.out.println(getMaxNumCols("the dog"));
      System.out.println(getMaxNumCols("the longest\nis here"));
      System.out.println(getMaxNumCols("the dog\nis here or there \nto stay"));
      System.out.println(getMaxNumCols("the dog\nis here or there \nto stay\n"));
      System.out.println(getMaxNumCols("\nto be or not to be\nto stay\n"));
      System.out.println(getMaxNumCols("\nto be or not to be \n  \n\n"));

      System.out.println(getMaxNumCols("the dog", 4));
      System.out.println(getMaxNumCols("the dogz\nis here", 4));
      System.out.println(getMaxNumCols("the dog\nissy here\nto stay", 4));
      System.out.println(getMaxNumCols("the dog\nis here\nto stay\n", 4));

      System.out.println(getNumRows("the dog"));
      System.out.println(getNumRows("the dog\nis here"));
      System.out.println(getNumRows("the dog\nis here\nto stay"));
      System.out.println(getNumRows("the dog\nis here\nto stay\n"));

      System.out.println(getNumRows("abcdef"));
      System.out.println(getNumRows(fold("", "abcdef")));
      System.out.println(getNumRows("the dog", 4));
      System.out.println(getNumRows("the dog\nis here", 4));
      System.out.println(getNumRows("the dog\nis here\nto stay", 4));
      System.out.println(getNumRows("the dog\nis here\nto stay\n", 4));


      System.out.println(indent("abc\ndef", 3));
      System.out.println(indent("abc\ndef\n", 5));
   } // of main
*/

/*
   public static void main3(String[] argv) throws Exception {
      String str = "Date: 08/02/1999\nName: John\nOccupation: Programmer\nAddress: blah\n";
      System.out.println(align(str, ':'));
      System.out.println();


      byte[]  bArray  = {(byte) 5, (byte) 7, (byte) 9};
      int[]   iArray  = {1, 2, 3, 4, 5};
      short[] sArray  = {(short) 1, (short) 2, (short) 3, (short) 4, (short) 5};
      char[]  chArray = {'a', 'b', 'c', 'd', 'e'};

      System.out.println(toString(bArray));
      System.out.println(toString(iArray));
      System.out.println(toString(sArray));
      System.out.println(toString(chArray));
   } // of main
*/


/*
   public static void main4(String[] argv) throws Exception {
      char[] buf = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};
      String str = new String(buf, "ASCII");
      System.out.println(str);

      buf = str.getBytes("ASCII");
      for (int i = 0; i < buf.length; i++) {
         System.out.print((char) buf[i]);
      }

      System.out.println();
      System.out.println(getBarredLine("hi there", '='));
      System.out.println(getBarredLine("text", '='));
      System.out.println(getBarredLine("another really long test", '='));


      System.out.println();
      System.out.println(reverseInterpretString("hi there\nthis bytes\r\n"));

      System.out.println(interpretString("abc\\b"));
      System.out.println(interpretString("abc\\b\\b"));
      System.out.println(interpretString("abc\\tabc"));
      System.out.println(interpretString("abc\\nabc"));
      System.out.println(interpretString("abc\\u0041bc"));
      System.out.println(interpretString("abc\\u0042bc"));
      System.out.println(interpretString("abc\\u0043bc"));
      System.out.println(interpretString("abc\\u0065bc"));
   } // of main
*/
    //===   SELF TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
