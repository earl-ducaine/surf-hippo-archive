package edu.berkeley.guir.lib.gesture.util;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class FlowScrollPanel extends JPanel implements Scrollable {
  private FlowLayout layout = new FlowLayout();
  private JScrollPane scroller;
  
  public FlowScrollPanel()
  {
    this(null);
  }

  public FlowScrollPanel(JScrollPane scrollPane)
  {
    super();
    super.setLayout(layout);
    setScroller(scrollPane);
  }

  public void setScroller(JScrollPane scrollPane)
  {
    if (scroller != scrollPane) {
      scroller = scrollPane;
      if (scroller != null) {
	scroller.getViewport().setView(this);
      }
      scroller.addComponentListener(new ComponentAdapter() {
	public void componentResized(ComponentEvent e) {
	  scroller.getViewport().setViewSize(getSize());
	  scroller.invalidate();
	  scroller.validate();
	  doLayout();
	}
      });
    }
  }

  public Dimension getPreferredSize() {
    if (scroller == null) {
      Dimension result = super.getPreferredSize();
      return result;
    }
    else {
      Insets insets = getInsets();
      int hgap = layout.getHgap();
      int vgap = layout.getVgap();
      JScrollBar vsb = scroller.getVerticalScrollBar();
      if (vsb == null) {
	vsb = scroller.createVerticalScrollBar();
      }
      int scrollerWidth = scroller.getSize().width -
	(insets.left + insets.right + hgap*2) - vsb.getSize().width /*-2*/;
      // the -2 is a voodoo constant.  I don't know why it's needed, but
      // it is.  (I suspect that this routine and FlowLayout compute
      // required sizes in a subtly different way.)
      // No longer needed with Swing 1.1 (I think).
      int nmembers = getComponentCount();
      int x = 0, y = insets.top + vgap;
      int rowh = 0;
      int maxRowWidth = scrollerWidth;

      for (int i = 0 ; i < nmembers ; i++) {
	Component m = getComponent(i);
	if (m.isVisible()) {
	  Dimension d = m.getPreferredSize();
	  if ((x == 0) || ((x + d.width) <= scrollerWidth)) {
	    if (x > 0) {
	      x += hgap;
	    }
	    x += d.width;
	    rowh = Math.max(rowh, d.height);
	  } else {
	    if (x > maxRowWidth)
	      maxRowWidth = x + hgap;
	    x = d.width;
	    y += vgap + rowh;
	    rowh = d.height;
	  }
	}
      }
      if (x > maxRowWidth)
	maxRowWidth = x + 2 * hgap + insets.left + insets.right;
      y += vgap + rowh + insets.bottom;
      return new Dimension(maxRowWidth, y);
    }
  }

  public void setLayout(LayoutManager l)
  {
    if (l instanceof FlowLayout) {
      layout = (FlowLayout) l;
      super.setLayout(l);
    }
    else
      throw new
	AWTError("FlowScrollPane can have only FlowLayout, not " + l);
  }

  //
  // Scrollable methods
  //
  
  public Dimension getPreferredScrollableViewportSize()
  {
    return getPreferredSize();
  }

  /**
   * Returns height of a row
   */
  public int getScrollableUnitIncrement(Rectangle visibleRect,
					int orientation,
					int direction)
  {
    Dimension prefSize = layout.preferredLayoutSize(this);
    return prefSize.height;
  }

  /**
   * returns the height of the visible rect (so it scrolls by one
   * screenfull).
   */
  public int getScrollableBlockIncrement(Rectangle visibleRect,
					 int orientation,
					 int direction)
  {
    return visibleRect.height;
  }

  public boolean getScrollableTracksViewportWidth()
  {
    return true;
  }

  public boolean getScrollableTracksViewportHeight()
  {
    return false;
  }

  //
  // Test
  //

  static int buttonCount = 0;
  
  public static void main(String[] args)
  {
    final JFrame frame = new JFrame("FlowScrollPanel test");
    Container contents = frame.getContentPane();
    final FlowScrollPanel panel = new FlowScrollPanel();
    JScrollPane scrollPane = new JScrollPane(panel);
    panel.setScroller(scrollPane);
    panel.setBackground(Color.white);
    scrollPane.setBackground(Color.yellow);
    contents.setLayout(new BorderLayout());
    contents.add(scrollPane, BorderLayout.CENTER);

    JPanel controlPanel = new JPanel();
    JButton button = new JButton("add");
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	addButton(panel);
	frame.pack();
      }
    });
    controlPanel.add(button);
    controlPanel.setBackground(Color.blue);

    JMenuBar menuBar = new JMenuBar();
    JMenu menu = new JMenu("File");
    JMenuItem item = new JMenuItem("Quit");
    item.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	System.exit(0);
      }
    });
    menu.add(item);
    menuBar.add(menu);
    
    frame.setJMenuBar(menuBar);

    contents.add(controlPanel, BorderLayout.SOUTH);
    
    addButton(panel);
    addButton(panel);
    addButton(panel);

    HystericResizer hr = new HystericResizer();
    frame.getRootPane().addComponentListener(hr);

    frame.pack();
    frame.show();
  }

  static void addButton(final JComponent parent)
  {
    buttonCount++;
    final JButton b = new JButton("Button " + buttonCount);
    parent.add(b);
    b.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	parent.remove(b);
	edu.berkeley.guir.lib.gesture.util.awt.getWindow(parent).pack();
      }
    });
  }
}
