package edu.berkeley.guir.damask.view.voice.component;

import java.awt.Paint;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.util.*;

import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.event.ContentEvent;
import edu.berkeley.guir.damask.event.ContentListener;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.nodes.DamaskPPath;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;


/**
 * A button that determines whether the voice text syncs
 * with the desktop/smartphone text.
 */
public class SyncButton extends DamaskPPath {
   private DamaskPPath leftArrowNode;
   private DamaskPPath rightArrowNode;
   private boolean sync = true;
   private final List/*<Content>*/ contentsToHandle;
   private ContentListener contentHandler = new ContentHandler();
   private final Paint onPaint;
   private final Paint offPaint;
   
   public SyncButton(final Rectangle2D bounds,
                     final List/*<Content>*/ contentsToHandle,
                     final Paint onPaint,
                     final Paint offPaint) {
      this.contentsToHandle = new ArrayList/*<Content>*/(contentsToHandle);
      this.onPaint = onPaint;
      this.offPaint = offPaint;
      
      setPathTo(bounds);
      final float syncButtonWidth = (float)getWidth();
      
      final GeneralPath leftArrow = new GeneralPath();
      leftArrow.moveTo(syncButtonWidth - 4, 0);
      leftArrow.lineTo(0, 0);
      leftArrow.moveTo(3, -3);
      leftArrow.lineTo(0, 0);
      leftArrow.lineTo(3, 3);
      leftArrowNode = new DamaskPPath(leftArrow);
      leftArrowNode.setPickable(false);
      addChild(leftArrowNode);
      
      final GeneralPath rightArrow = new GeneralPath();
      rightArrow.moveTo(0, 0);
      rightArrow.lineTo(syncButtonWidth - 4, 0);
      rightArrow.moveTo(syncButtonWidth - 7, -3);
      rightArrow.lineTo(syncButtonWidth - 4, 0);
      rightArrow.lineTo(syncButtonWidth - 7, 3);
      rightArrowNode = new DamaskPPath(rightArrow);
      rightArrowNode.setPickable(false);
      addChild(rightArrowNode);

      for (Iterator i = contentsToHandle.iterator(); i.hasNext(); ) {
         final Content content = (Content)i.next();
         setSyncStatus(content.isPromptTextSyncedWithText());
      }
      
      setPaint(DamaskAppUtils.NO_COLOR);
      setStrokePaint(DamaskAppUtils.NO_COLOR);
      addInputEventListener(new SyncButtonHandler());
      
      for (Iterator i = contentsToHandle.iterator(); i.hasNext(); ) {
         final Content content = (Content)i.next();
         content.addContentEventListener(contentHandler);
      }
   }
   
   public void dispose() {
      for (Iterator i = contentsToHandle.iterator(); i.hasNext(); ) {
         final Content content = (Content)i.next();
         content.removeContentEventListener(contentHandler);
      }
   }
   
   protected void layoutChildren() {
      final float syncButtonHeight = (float)getHeight();
      leftArrowNode.setOffset(
         getX() + 2,
         getY() + syncButtonHeight/2 - leftArrowNode.getHeight() - 2);
      rightArrowNode.setOffset(
         getX() + 2,
         getY() + syncButtonHeight/2 + 2);
   }
   
   
   public boolean getSyncStatus() {
      return sync;
   }
   
   public void setSyncStatus(final boolean flag) {
      sync = flag;
      final Paint arrowPaint;
      if (sync) {
         arrowPaint = onPaint;
      }
      else {
         arrowPaint = offPaint;
      }
      leftArrowNode.setStrokePaint(arrowPaint);
      rightArrowNode.setStrokePaint(arrowPaint);
   }
   
   /**
    * The event handler for the sync text button. 
    */
   private class SyncButtonHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         final boolean newSyncStatus = !getSyncStatus();
         for (Iterator i = contentsToHandle.iterator(); i.hasNext(); ) {
            final Content content = (Content)i.next();
            content.setPromptTextSyncedWithText(newSyncStatus);
         }
      }
   }
   
   private class ContentHandler implements ContentListener {

      // @Override
      public void strokeAdded(ContentEvent e) {
      }

      // @Override
      public void strokeRemoved(ContentEvent e) {
      }

      // @Override
      public void strokesChanged(ContentEvent e) {
      }

      // @Override
      public void textChanged(ContentEvent e) {
      }

      // @Override
      public void imageChanged(ContentEvent e) {
      }

      // @Override
      public void preferredDisplayModeChanged(ContentEvent e) {
      }

      // @Override
      public void promptTextIsSyncedWithText(ContentEvent e) {
         setSyncStatus(true);
      }

      // @Override
      public void promptTextIsUnsyncedWithText(ContentEvent e) {
         setSyncStatus(false);
      }
   }
}