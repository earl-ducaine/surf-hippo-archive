package edu.berkeley.guir.damask.view.voice.event;

import java.awt.Color;
import java.awt.event.InputEvent;
import java.awt.geom.*;
import java.util.Iterator;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.command.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.ConnectionDest;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.userevent.InvokeEvent;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.nodes.DamaskPPath;
import edu.berkeley.guir.damask.view.nodes.DamaskWindowTitle;
import edu.berkeley.guir.damask.view.voice.component.Prompt;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.berkeley.guir.damask.view.voice.dialog.Form;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.*;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * The event handler that handles dragging from or clicking in a prompt.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-09-2004 James Lin
 *                               Created DragFromPromptHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 11-09-2004
 */
public class DragFromPromptHandler extends PDragSequenceEventHandler {
   private DamaskPPath linePath = new DamaskPPath();
   private Line2D line = new Line2D.Double();
   
   private Prompt startPrompt = null;
   private PPath startFormContents = null;
   
   private final Prompt.TextHandler promptTextHandler =
      new Prompt.TextHandler();
   
   /**
    * Constructs a handler which will instantiate a component of the specified
    * type.
    * 
    * @param componentViewType a class which is a descendant of
    * {@link edu.berkeley.guir.damask.view.visual.component.ComponentView}
    */
   public DragFromPromptHandler() {
      setEventFilter(new PInputEventFilter(InputEvent.BUTTON1_MASK));
   }


   // @Override
   public void startDrag(PInputEvent e) {
      super.startDrag(e);
      
      ((DamaskCanvas)e.getComponent()).stopTextEditing();
      
      final PNode startNode = e.getPickedNode(); 
      startPrompt = (Prompt)DamaskAppUtils.getAncestor(startNode, Prompt.class);
      startFormContents = startPrompt.getForm().getContents();
      
      line.setLine(
         startFormContents.globalToLocal(
            startPrompt.localToGlobal(startPrompt.getBounds().getCenter2D())),
         e.getPositionRelativeTo(startFormContents));
      linePath.setPathTo(line);
      linePath.setStrokePaint(Color.BLACK);
      startFormContents.addChild(linePath);
   }

   // @Override
   public void drag(final PInputEvent e) {
      super.drag(e);
      line.setLine(line.getP1(), e.getPositionRelativeTo(startFormContents));
      linePath.setPathTo(line);
   }

   // @Override
   public void endDrag(final PInputEvent e) {
      super.endDrag(e);
      line.setLine(line.getP1(), e.getPositionRelativeTo(startFormContents));
      linePath.setPathTo(line);
      startFormContents.removeChild(linePath);

      final DamaskCanvas canvas = (DamaskCanvas)e.getComponent();
      final DeviceType canvasDeviceType = canvas.getDeviceType();
      
      final Point2D ptCameraCoords = e.getPositionRelativeTo(e.getCamera());
      final PNode endNode =
         e.getCamera()
          .pick(ptCameraCoords.getX(), ptCameraCoords.getY(), 1)
          .getPickedNode();

      final int startFormCondition =
         startPrompt.getForm().getDesignTimeCondition();

      final DeviceType deviceTypeForNewElement =
         ((DamaskLayer)canvas.getLayer()).getDeviceTypeForNewElement();
      
      System.out.println("endNode: " + endNode);
      
      if (endNode == startPrompt) {
         // edit the caption of startPrompt
         promptTextHandler.startEditing(e, startPrompt);
      }
      else if ((endNode instanceof Prompt) ||
               (endNode instanceof Response.HotSpot) ||
               (endNode instanceof DamaskWindowTitle) ||
               (endNode.getParent() instanceof DamaskWindowTitle) ||
               (endNode instanceof Form.Contents)) {
         final MacroCommand cmd = new ModifyGraphMacroCommand();

         final Content triggerContent =
            new Content(deviceTypeForNewElement, Response.NULL_DISPLAY_STRING);
         final Trigger trigger =
            new Trigger(deviceTypeForNewElement, triggerContent);
         
         for (Iterator i = deviceTypeForNewElement.getSpecificDeviceTypes().iterator(); i.hasNext(); ) {
            final DeviceType aDeviceType = (DeviceType)i.next();
            if (aDeviceType != DeviceType.VOICE) {
               final Rectangle2D aDeviceBounds =
                  DamaskAppUtils.getRenderedTextBounds(
                     Response.NULL_DISPLAY_STRING, aDeviceType.getDefaultFontSize());
               triggerContent.setBounds(aDeviceType, aDeviceBounds);
               trigger.setBounds(aDeviceType, aDeviceBounds);
               final AffineTransform newTransform =
                  trigger.getTransform(DeviceType.VOICE);
               newTransform.translate(line.getX1(), line.getY1());
               trigger.setTransform(aDeviceType, newTransform);
            }
         }
         
         cmd.addCommand(
            new AddControlCommand(
               (Control) startPrompt.getModel(),
               trigger));

         ConnectionDest connectionDest = null;
         
         if (endNode instanceof Prompt) {
            connectionDest = (Control)((Prompt)endNode).getModel();
         }
         else if ((endNode instanceof Response.HotSpot)) {
            final Response response =
               (Response)DamaskAppUtils.getAncestor(endNode, Response.class);
            connectionDest = (Control)response.getModel();
         }
         else if ((endNode instanceof Form.Contents) ||
               (endNode instanceof DamaskWindowTitle) ||
               (endNode.getParent() instanceof DamaskWindowTitle)) {
            final Form endForm =
               (Form)DamaskAppUtils.getAncestor(endNode, Form.class);
            if (startPrompt.getForm() != endForm) {
               connectionDest = 
                  ((Dialog)endForm.getModel()).getFirstPage(canvasDeviceType);
            }
         }
         
         if (connectionDest != null) {
            final boolean connectionDestIsForAllDeviceTypes;
            if (connectionDest instanceof Control) {
               connectionDestIsForAllDeviceTypes =
                  ((Control)connectionDest).isForAllDeviceTypes();
            }
            else {
               connectionDestIsForAllDeviceTypes =
                  ((Page)connectionDest).getDialog().getDeviceType() ==
                     DeviceType.ALL;
            }
            cmd.addCommand(
               new AddConnectionCommand(
                  canvasDeviceType,
                  deviceTypeForNewElement == DeviceType.ALL &&
                     connectionDestIsForAllDeviceTypes,
                  trigger,
                  new InvokeEvent(trigger),
                  startFormCondition,
                  connectionDest,
                  new GeneralPath(line)));
         }
         if (!cmd.isEmpty()) {
            canvas.getDocument().getCommandQueue().doCommand(
               canvas, cmd);
            if (connectionDest == null) {
               trigger.setVoiceResponseLine(startFormCondition, line);
            }
         }
      }
   }  
}
