//// See bottom of source code for software license

package edu.berkeley.guir.denim.dialogs;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.objects.*;
import javax.swing.*;
import javax.swing.event.*;
import java.beans.*; //Property change stuff
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.List;

/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Aug 7, 2004 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class ReplaceToolbar extends JDialog implements SatinConstants {
    
    JButton sketch, type, ok, cancel;
    JPanel manager;

    Point2D pos;
    DenimSheet sheet;
    
    DenimIntrinsicComponentInstance instance = null;
    
    public ReplaceToolbar(Frame win, DenimIntrinsicComponentInstance com) {
        
        super(win, "Choose Input Method", false);
        
        manager = new JPanel();
        this.getContentPane().add(manager, BorderLayout.CENTER);
        
        sheet = (DenimSheet)com.getSheet();
        instance = com;
        pos = new Point2D.Double(
                com.getBounds2D(COORD_ABS).getMinX(),
                com.getBounds2D(COORD_ABS).getMaxY());
        int x = (int) pos.getX() + win.getX();
        int y = (int) pos.getY() + win.getY();
        this.setBounds(x, y, 260,80);
      
        sketch = new JButton("Sketch");
        sketch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                if(sketch.getText().equalsIgnoreCase("Sketch"))
                {
                    manager.remove(type);
                    sketch.setText("Replace");
                    ReplaceToolbar.this.setTitle("Replace Sketch");
                    
                    Rectangle2D rect = new Rectangle2D.Double(
                            0, 0, 
                            sheet.getBounds2D(COORD_ABS).getWidth(),
                            sheet.getBounds2D(COORD_ABS).getHeight());
                    try
                    {
                        GeomLib.transformRectangle(sheet.getTransform(COORD_ABS).createInverse(),
                                rect, rect);
                        sheet.sketchInputPanel = new SketchPanel(rect);
                        sheet.addToFront(sheet.sketchInputPanel, GraphicalObjectGroup.KEEP_ABS_POS);
                        sheet.sketchInputPanel.moveTo(COORD_ABS, 0,0);
                    }
                    catch(Exception ex)
                    {
                        ex.printStackTrace();
                    }
                }
                else // ok 
                {
                    ScribbledText text = ScribbledText.createScribbledText(instance.getParentGroup(),
                            (GraphicalObjectCollection)sheet.sketchInputPanel.getGraphicalObjects().clone());
                    
                    if(instance instanceof DenimRadioButtonInstance)
                    {
                        ((DenimRadioButtonInstance)instance).setCaption(text);
                    }
                    else if(instance instanceof DenimCheckBoxInstance)
                    {
                        ((DenimCheckBoxInstance)instance).setCaption(text);
                    }
                    else if(instance instanceof DenimButtonInstance)
                    {
                        ((DenimButtonInstance)instance).setCaption(text);
                    }
                    
                    sheet.remove(sheet.sketchInputPanel);
                    sheet.sketchInputPanel.delete();
                    sheet.sketchInputPanel = null;
                    ReplaceToolbar.this.setVisible(false);
                    ReplaceToolbar.this.dispose();                    
                }
            }
        });
        type = new JButton("Type");
        type.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                ReplaceToolbar.this.setVisible(false);
                ReplaceToolbar.this.dispose();
                
                TypedTextHandler handler = new TypedTextHandler(
                        pos, sheet);
                handler.run();
            }
        });

        cancel = new JButton("Cancel");
        cancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                if(sheet.sketchInputPanel!=null)
                {
                    sheet.remove(sheet.sketchInputPanel);
                    sheet.sketchInputPanel.delete();
                    sheet.sketchInputPanel = null;
                }
                ReplaceToolbar.this.setVisible(false);
                ReplaceToolbar.this.dispose();
            }
        });

        manager.add(sketch);
        manager.add(type);
        manager.add(cancel);
    }
}



//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
    must display the following acknowledgement:

        This product includes software developed by the Group for User 
        Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
    derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/