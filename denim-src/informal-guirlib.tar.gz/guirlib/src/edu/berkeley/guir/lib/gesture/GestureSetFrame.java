package edu.berkeley.guir.lib.gesture;

import java.lang.System;
import java.text.ParseException;
import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import edu.berkeley.guir.lib.gesture.util.*;

/**
 *
 * Displays a gesture set (i.e., set of gesture classes) and allows
 * for training and classification (i.e., recognition) of gestures.
 * Also has menu options for displaying various visualizations and
 * debugging information.
 *
 */

public class GestureSetFrame extends JFrame
implements ItemListener, Observer {

  /** These are in addition to the Rubine features */
  /*
  public static final Class[] humanFeatures = {
    Curviness2.class,
    AnglePerDistance.class,
    Density1.class,
    Density2.class,
    Curviness.class,
    Open2.class,
    LogArea.class,
    Consistency.class,
    LogAspect.class
  };
  */

  double cliqueDist = 8;
  public static Icon foobarIcon = new ImageIcon("check.gif");
  final String version = "gdt 1.0";
  final int TESTS_PER_CATEGORY = 5;
  private JLabel statusWindow;
  private JScrollPane gestureSetScroller;
  protected GestureSetDisplay gestureSetDisplay;
  private JLabel resultLabel;
  private JSplitPane splitPane;
  static Font resultFont = new Font("Serif", Font.BOLD, 36);
  Classifier classifier;
  JMenuItem deleteMenuItem, cutMenuItem, copyMenuItem, pasteMenuItem,
    saveItem, openSelectionMenuItem,
    testSaveMenuItem, testStopMenuItem, testShowMenuItem;
  GestureCategory clipboard;
  TypedFile gestureSetFile = null;
  boolean autoSaveOn = true;
  // constants for saveLevel
  final int SAVED = 2;
  final int AUTOSAVED = 1;
  final int NOT_SAVED = 0;
  int saveLevel = SAVED;
  final String experimentSaveDir = "data" + File.pathSeparator
    + "experiment";
  /** The last directory where a file was opened or saved. */
  String lastDirectory = null;
  boolean isTrained = false;  // has category changed since last training?
  boolean authorsVisible = false;
  boolean experimentMode;
  // Test variables
  boolean testMode = false;
  /** Index into testCases of the current test case */
  int testTally;
  /** Number of test cases that were correctly recognized */
  int testsCorrect;
  /** Indexes into the GestureSet of GestureCategories, shuffled
      randomly for the test */
  int[] testCases;
  /** Set of gestures input during the test. */
  GestureSet testGestures;
  /** Results generated during the test (same size as testCases) */
  Classifier.Result[] testResults;
  /** testConfusionMatrix[i][j] is a Vector of Gestures that are
   *  supposed to be from Category i that were categorized as being in
   *  Category j. */
  Vector[][] testConfusionMatrix;
  /** Counts how many times in a row the current test case has been given */
  int sameTest;
  int testSaveLevel = SAVED;

  public GestureSetFrame()
  {
    this("Gesture set");
  }

  public GestureSetFrame(String name)
  {
    this(name, false);
  }
       
  public GestureSetFrame(String name, boolean experimenting)
  {
    super(name);
    experimentMode = experimenting;
    initFrame();
  }
       
  /**
   * Set up frame contents */
  protected void initFrame()
  {
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e)
      { askToSave(); }
    });
    
    JPanel contents = new JPanel();
    contents.setLayout(new BorderLayout(5, 5));
    getContentPane().setLayout(new BorderLayout(5, 5));

    JPanel top = new JPanel(new BorderLayout(5, 5));
    
    // make menu bar
    JMenuBar menuBar = constructMenuBar();
    getRootPane().setJMenuBar(menuBar);

    // make gesture category display
    gestureSetDisplay = new GestureSetDisplay(experimentMode);
    gestureSetDisplay.setAuthorsVisible(authorsVisible);
    gestureSetDisplay.getGestureSet().addObserver(this);
    gestureSetDisplay.addItemListener(this);
    
    gestureSetScroller = new JScrollPane(gestureSetDisplay);
    gestureSetScroller.setMinimumSize(new Dimension(0, 0));
    gestureSetDisplay.setScroller(gestureSetScroller);
    top.add(gestureSetScroller, BorderLayout.CENTER);
      
    // make status panel
    JPanel statusPanel = new JPanel();
    statusPanel.setForeground(Color.blue);
    statusPanel.setLayout(new BorderLayout(5,5));
    statusWindow = new JLabel();
    message("Welcome to GDT!");
    statusPanel.add(statusWindow, BorderLayout.CENTER);
    Blinker blinker = new Blinker();
    blinker.setPreferredSize(new Dimension(15, 15));
    blinker.setBorder(BorderFactory.createEmptyBorder(2, 2, 8, 4));
    statusPanel.add(blinker, BorderLayout.EAST);
    top.add(statusPanel, BorderLayout.SOUTH);

    // make test panel
    JPanel testPanel = new JPanel(new BorderLayout(5, 5));
    GestureInteractor testInteractor = new GestureInteractor();
    testInteractor.addChangeListener(new ClassifyHandler());
    testInteractor.setBorder(BorderFactory.createLoweredBevelBorder());
    testPanel.add(testInteractor, BorderLayout.CENTER);
    JLabel testLabel = new JLabel("Draw gesture to be recognized below");
    testPanel.add(testLabel, BorderLayout.NORTH);
    /*
    resultLabel = new JLabel("");
    resultLabel.setFont(resultFont);
    resultLabel.setPreferredSize(new Dimension(30, 30));
    testPanel.add(resultLabel, BorderLayout.WEST);
    */
    
    // put it together in a splitpane
    splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
			       true,
			       top, testPanel);
    //split.setOneTouchExpandable(true);
    contents.add(splitPane, BorderLayout.CENTER);

    // Make what the user says go
    HystericResizer hr = new HystericResizer();
    getRootPane().addComponentListener(hr);

    // set reasonable initial size
    contents.setPreferredSize(new Dimension(500, 500));

    getContentPane().add(contents, BorderLayout.CENTER);
  }

  /** This is a gross hack to get the initial placement of the divider
   *  where I want it.  I should figure out the Right Way someday. */
  public void setDividerLocation(double percent)
  {
    splitPane.setDividerLocation(0.50);
  }

  /**
   * Create the menu bar
   */
  protected JMenuBar constructMenuBar()
  {
    JMenuBar mb = new JMenuBar();

    mb.add(constructFileMenu());
    mb.add(constructEditMenu());
    
    if (!experimentMode) {
      mb.add(constructViewMenu());
    }

    mb.add(constructClassMenu());
    mb.add(constructSetMenu());
    mb.add(constructTestMenu());
    
    if (!experimentMode) {
      mb.add(constructDebugMenu());
    }
    
    return mb;
  }

  protected JMenu constructFileMenu()
  {
    JMenu fileMenu = new JMenu("File");

    JMenuItem openItem = new JMenuItem("Open");
    ActionListener openListener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	String directory = (lastDirectory != null) ? lastDirectory :
	  (experimentMode ? experimentSaveDir : "data");
	JFileChooser fileChooser = new JFileChooser(directory);
	int returnVal =
	  fileChooser.showOpenDialog(statusWindow.getTopLevelAncestor());
	switch (returnVal) {
	case JFileChooser.APPROVE_OPTION:
	  openFile(fileChooser.getSelectedFile());
	  break;
	case JFileChooser.CANCEL_OPTION:
	  message("Open cancelled", 10);
	  break;
	default:
	  System.err.println("Bogosity from JFileChooser");
	  break;
	}
      }
    };
    openItem.addActionListener(openListener);
    openItem.setAccelerator(KeyStroke.
			    getKeyStroke(KeyEvent.VK_O,
					 Event.ALT_MASK | Event.META_MASK));

    fileMenu.add(openItem);

    saveItem = new JMenuItem("Save");
    ActionListener saveListener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	saveFile(null);
      }
    };
    saveItem.addActionListener(saveListener);
    saveItem.setEnabled(false);
    saveItem.setAccelerator(KeyStroke.
			    getKeyStroke(KeyEvent.VK_S,
					 Event.ALT_MASK | Event.META_MASK));

    fileMenu.add(saveItem);
    
    JMenuItem saveAsItem = new JMenuItem("Save As...");
    ActionListener saveAsListener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	TypedFile f = askForSaveFile();
	if (f != null) {
	  if (f.exists()) {
	    int reply = JOptionPane.
	      showConfirmDialog(GestureSetFrame.this,
				"File exists.  Overwrite it?",
				"gdt: Overwrite file?",
				JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE);
	    switch (reply) {
	    case JOptionPane.YES_OPTION:
	      break;
	    case JOptionPane.NO_OPTION:
	      message("Save cancelled");
	      return;
	    default:
	      message("Bogosity in GestureSetFrame");
	      return;
	    }
	  }
	  saveFile(f);
	}
	else {
	  message("Save cancelled");
	}
      }
    };
    saveAsItem.addActionListener(saveAsListener);
    fileMenu.add(saveAsItem);

    JMenuItem exit = new JMenuItem("Quit");
    ActionListener exitListener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	askToSave();
	System.exit(0);
      }
    };
    exit.addActionListener(exitListener);
    exit.setAccelerator(KeyStroke.
			getKeyStroke(KeyEvent.VK_Q,
				     Event.ALT_MASK | Event.META_MASK));

    fileMenu.add(exit);

    return fileMenu;
  }

  protected JMenu constructEditMenu()
  {
    JMenu menu;
    JMenuItem item;
    ActionListener listener;

    menu = new JMenu("Edit");
    item = new JMenuItem("Delete");
    deleteMenuItem = item;
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
	{
	  String selectionName = gestureSetDisplay.getSelection().getName();
	  int confirmDelete = JOptionPane.
	    showConfirmDialog(GestureSetFrame.this, "Really delete class '" +
			      selectionName + "'?",
			      "gdt: confirm delete class",
			      JOptionPane.YES_NO_OPTION,
			      JOptionPane.QUESTION_MESSAGE);
	  switch (confirmDelete) {
	  case JOptionPane.YES_OPTION:
	    deleteSelection();
	    break;
	  case JOptionPane.NO_OPTION:
	    message("Delete cancelled");
	    break;
	  default:
	    message("WARNING: bogosity in GestureSetFrame");
	    return;
	}
      }
    };
    item.addActionListener(listener);
    item.setEnabled(false);
    menu.add(item);
    item = new JMenuItem("Cut");
    cutMenuItem = item;
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	setClipboard();
	deleteSelection();
      }
    };
    item.addActionListener(listener);
    item.setEnabled(false);
    menu.add(item);
    item = new JMenuItem("Copy");
    copyMenuItem = item;
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	copyClipboard();
      }
    };
    item.addActionListener(listener);
    item.setEnabled(false);
    menu.add(item);
    item = new JMenuItem("Paste");
    pasteMenuItem = item;
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	gestureSetDisplay.getGestureSet().
	  add((GestureCategory) getClipboard().clone());
      }
    };
    item.addActionListener(listener);
    item.setEnabled(false);
    menu.add(item);

    return menu;
  }

  protected JMenu constructViewMenu()
  {
    JMenu menu;
    ActionListener listener;

    menu = new JMenu("View");
    final JCheckBoxMenuItem cbItem = new JCheckBoxMenuItem("Author");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
	{
	  authorsVisible = cbItem.getState();
	  gestureSetDisplay.setAuthorsVisible(authorsVisible);
	}
    };
    if (!authorsVisible)
      cbItem.setState(false);
    cbItem.addActionListener(listener);
    menu.add(cbItem);

    return menu;
  }

  protected JMenu constructClassMenu()
  {
    JMenu menu;
    JMenuItem item;
    ActionListener listener;

    menu = new JMenu("Class");
    item = new JMenuItem("New");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	final GestureSetFrame gsFrame = GestureSetFrame.this;
	gsFrame.doAutoSave(null);
	GestureSet gs = gestureSetDisplay.getGestureSet();
	String newName = null;
	if ((gs != null) && (gs.size() > 0)) {
	  String lastName = ((GestureContainer) gs.getChild(gs.size()-1)).
	  getName();
	  if ((lastName != null) && (lastName.length() == 1))
	    newName = new Character((char) (lastName.charAt(0) + 1)).
	      toString();
	}
	GestureCategory gc = new GestureCategory(newName);
	gc.setAuthor(gs.getAuthor());
	addCategory(gc);
	GestureCategoryFrame gcFrame =
	  gestureSetDisplay.showCategoryFrame(gc);
	// arrange for autosave when this window is closed
	gcFrame.addWindowListener(new WindowAdapter() {
	  public void windowClosing(WindowEvent we)
	  {
	    gsFrame.doAutoSave(null);
	  }
	});
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    openSelectionMenuItem = new JMenuItem("Open selection");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	gestureSetDisplay.
	  showCategoryFrame(gestureSetDisplay.getSelection());
      }
    };
    openSelectionMenuItem.addActionListener(listener);
    openSelectionMenuItem.setEnabled(false);
    menu.add(openSelectionMenuItem);

    return menu;
  }

  protected JMenu constructSetMenu()
  {
    JMenu menu;
    JMenuItem item;
    ActionListener listener;
    
    menu = new JMenu("Set");

    item = new JMenuItem("Distance matrix");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	if (!train())
	  message("Cannot build distance matrix unless training succeeds");
	else {
	  JFrame f = new DistanceMatrix(classifier);
	  f.pack();
	  f.show();
	}
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    /* todo
    item = new JMenuItem("Human DM");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	GestureSet gs = gestureSetDisplay.getGestureSet();
	Double[][] dist =
	  HumanCoords.allDistances(gs);
	JFrame f = new DistanceMatrix(gs, dist, HumanCoords.maxDistance);
	f.pack();
	f.show();
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    */

    /* todo
    item = new JMenuItem("Classification matrix");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	if (!train()) {
	  message("Cannot build classification matrix unless training succeeds");
	}
	else {
	  Vector[][] m = classifier.classificationMatrix();
	  JFrame f = new ClassificationMatrix(m, gestureSetDisplay);
	  f.pack();
	  f.show();
	}
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    */
    
    item = new JMenuItem("Feature graph");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	boolean trainingFailed = false;
	
	if (classifier == null) {
	  classifier = new Classifier(gestureSetDisplay.getGestureSet());
	  try {
	    classifier.train();
	  }
	  catch (TrainingException exception) {
	    trainingFailed = true;
	  }
	  catch (InterruptedException exception) {
	    trainingFailed = true;
	  }
	}
	FPGraphFrame f =
	  new FPGraphFrame(classifier);
	f.enableWeights(!trainingFailed);
	f.pack();
	f.setSize(new Dimension(800, 400));
	f.show();
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    item = new JMenuItem("Change author");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	setAuthorDialog();
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    item = new JMenuItem("Train");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	train();
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    if (!experimentMode) {
      item = new JMenuItem("Star plots");
      listener = new ActionListener() {
	public void actionPerformed(ActionEvent e)
	  {
	    if (!train()) {
	      message("Cannot make star plots unless training succeeds");
	    }
	    else {
	      GSStarPlotFrame gsspf =
		new GSStarPlotFrame(classifier);
	      gsspf.show();
	    }
	  }
      };
      item.addActionListener(listener);
      menu.add(item);

      item = new JMenuItem("Weight table");
      listener = new ActionListener() {
	public void actionPerformed(ActionEvent e)
	  {
	    if (!train()) {
	      message("Cannot build weight table unless training succeeds");
	    }
	    else {
	      JFrame f = new WeightTable(classifier);
	      f.pack();
	      f.show();
	    }
	  }
      };
      item.addActionListener(listener);
      menu.add(item);

      /*
      item = new JMenuItem("Enable examples");
      listener = new ActionListener() {
	public void actionPerformed(ActionEvent e)
	  {
	    gestureSetDisplay.getGestureSet().setExamplesEnabled(true);
	  }
      };
      item.addActionListener(listener);
      menu.add(item);
      */
    }

    return menu;
  }
  
  protected JMenu constructTestMenu()
  {
    JMenu menu;
    JMenuItem item;
    ActionListener listener;

    menu = new JMenu("Test");
    JMenuItem testStartMenuItem = new JMenuItem("Start");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	startTest();
      }
    };
    testStartMenuItem.addActionListener(listener);
    menu.add(testStartMenuItem);

    testStopMenuItem = new JMenuItem("Stop");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	stopTest();
      }
    };
    testStopMenuItem.addActionListener(listener);
    testStopMenuItem.setEnabled(false);
    menu.add(testStopMenuItem);

    testSaveMenuItem = new JMenuItem("Save results");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	GestureSetFrame foo = GestureSetFrame.this;
	foo.saveTest();
      }
    };
    testSaveMenuItem.addActionListener(listener);
    testSaveMenuItem.setEnabled(false);
    menu.add(testSaveMenuItem);

    testShowMenuItem = new JMenuItem("Show results");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	showTestResults();
      }
    };
    testShowMenuItem.addActionListener(listener);
    testShowMenuItem.setEnabled(false);
    menu.add(testShowMenuItem);

    item = new JMenuItem("New test set");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	TestSetFrame f = new TestSetFrame(GestureSetFrame.this);
	f.pack();
	f.show();
      }
    };
    item.addActionListener(listener);
    menu.add(item);

    return menu;
  }
  
  protected JMenu constructDebugMenu()
  {
    JMenu menu;
    JMenuItem item;
    ActionListener listener;

    menu = new JMenu("Debug");
    item = new JMenuItem("Dump cliques");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
	{
	  try {
	    if (classifier == null)
	      classifier =
		new Classifier(gestureSetDisplay.getGestureSet());
	    CliqueList cl = new CliqueList(classifier, cliqueDist);
	    cl.printCliques(System.out);
	  }
	  catch (TrainingException exception) {
	    message("Cannot show clique list unless training succeeds");
	  }
	  catch (InterruptedException exception) {
	    message("Training was interrupted, cannot show clique list");
	  }
	}
    };
    item.addActionListener(listener);
    menu.add(item);
    item = new JMenuItem("Category info");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
	{
	  gestureSetDisplay.getGestureSet().dumpNames(System.out);
	}
    };
    item.addActionListener(listener);
    menu.add(item);
    item = new JMenuItem("Covariance matrix");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
	{
	  if (classifier != null) {
	    Matrix.prettyPrint(classifier.ccm);
	  }
	}
    };
    item.addActionListener(listener);
    menu.add(item);
    item = new JMenuItem("Relative variance");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
	{
	  if (classifier != null) {
	    classifier.dumpRelativeVariance(System.out);
	  }
	}
    };
    item.addActionListener(listener);
    menu.add(item);
    item = new JMenuItem("GSD Position");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
	{
	  Rectangle r = gestureSetDisplay.getBounds();
	  Dimension ps = gestureSetDisplay.getLayout().
	    preferredLayoutSize(gestureSetDisplay.getParent());
	  message(r.width + "x" + r.height + "+" + r.x + "+" + r.y +
		  "  Pref: " + ps.width + "x" + ps.height);
	}
    };
    item.addActionListener(listener);
    menu.add(item);

    return menu;
  }
  
  void addCategory(GestureCategory category)
  {
    GestureSet gestureSet = gestureSetDisplay.getGestureSet();
    if (gestureSet == null) {
      System.err.println("gdt: Bogosity in GestureSetFrame.addCategory. This should never happen");
      gestureSet = new GestureSet();
      gestureSetDisplay.setGestureSet(gestureSet);
      gestureSet.addObserver(this);
    }
    gestureSet.add(category);
  }
  
  transient Thread messageThread = null;
  public void message(String msg)
  {
    message(msg, 5 * 60 * 1000);
  }
  
  /**
   * Display message in status window.  Arrange for it to go away
   * after a while.  (Probably should be in its own class so it can
   * be used in other Frames.  Maybe later.)
   * Delay is in milliseconds.  If delay is 0, message never
   * automatically disappears.
   */
  public void message(String msg, int delay)
  {
    final int delaytime = delay;
    
    if (messageThread != null) {
      messageThread.interrupt();
    }
    statusWindow.setText(msg);
    statusWindow.paintImmediately(getBounds());
    if (delaytime > 0) {
      messageThread = new Thread() {
	public void run() {
	  try {
	    sleep(delaytime);
	  }
	  catch (InterruptedException e) {}
	  statusWindow.setText("");
	}
      };
      messageThread.setDaemon(true);
      messageThread.setName("message thread"); // for debugging
      messageThread.start();
    }
  }

  /**
   * Return true if training was successful, false if not
   */
  boolean train()
  {
    boolean success = true;
    
    GestureSet gs = gestureSetDisplay.getGestureSet();
    if (gs == null) {
      message("No gestures to train");
      success = false;
    }
    else if (isTrained) {
      message("Already trained.");
    }
    else {
      message("Beginning training...");
      try {
	if (classifier == null)
	  classifier = new Classifier(gestureSetDisplay.getGestureSet());
	else
	  classifier.train();
	isTrained = true;
	message("Training done");
      }
      catch (TrainingException exception) {
	success = false;
	final JDialog dialog = new JDialog(GestureSetFrame.this,
					   "Training Error");
	JTextArea ta =
	  new JTextArea(new String("The following error occurred while traiing this gesture set:" + exception.getMessage()));
	dialog.getContentPane().add(ta, BorderLayout.CENTER);
	JButton closeButton = new JButton("Ok");
	ActionListener l = new ActionListener() {
	  public void actionPerformed(ActionEvent e)
	    {
	      dialog.dispose();
	    }
	};
	closeButton.addActionListener(l);
	dialog.getContentPane().add(closeButton, BorderLayout.SOUTH);
	dialog.pack();
	dialog.show();
	message("Error during training");
      }
      catch (InterruptedException exception) {
	message("Training was interrupted");
      }
    }
    return success;
  }

  TypedFile askForSaveFile()
  {
    String directory = (lastDirectory != null) ? lastDirectory :
      (experimentMode ? experimentSaveDir : "data");
    JFileChooser fileChooser = new JFileChooser(directory);
    JPanel panel = new JPanel();
    panel.add(new JLabel("File type"));
    JComboBox fileType = new JComboBox();
    // first one added is the default
    fileType.addItem("ASCII");
    fileType.addItem("Binary");
    panel.add(fileType);
    
    panel.setMaximumSize(panel.getPreferredSize());
    fileChooser.setAccessory(panel);
    
    int returnVal =
      fileChooser.showSaveDialog(statusWindow.getTopLevelAncestor());
    switch (returnVal) {
    case JFileChooser.APPROVE_OPTION:
      return new TypedFile(fileChooser.getSelectedFile(),
			   (String) fileType.getSelectedItem());
    case JFileChooser.CANCEL_OPTION:
      message("Save cancelled", 10);
      break;
    default:
      System.err.println("Bogosity from JFileChooser");
      break;
    }
    return null;
  }
  
  /**
   * If f has an autosaved file that's newer, the user is prompted whether
   * to use it.
   */
  public void openFile(File f)
  {
    lastDirectory = f.getParent();
    File asFile = autoSaveFile(f);
    boolean usingAutosave = false;
    try {
      if (asFile.exists() && (asFile.lastModified() > f.lastModified())) {
	int useAutosave = JOptionPane.
	  showConfirmDialog(this, "Autosave file exists for '" + f.getName() +
			    "'.  Use autosave file?",
			    "gdt: Use Autosave File?",
			    JOptionPane.YES_NO_CANCEL_OPTION,
			    JOptionPane.QUESTION_MESSAGE);
	switch (useAutosave) {
	case JOptionPane.YES_OPTION:
	  // load autosave file instead
	  f = asFile;
	  setFile(openActualFile(f));
	  setSaveLevel(AUTOSAVED);
	  break;
	case JOptionPane.NO_OPTION:
	  message("Autosave disabled until file saved");
	  autoSaveOn = false;
	  setFile(openActualFile(f));
	  saveItem.setEnabled(true);
	  setSaveLevel(SAVED);
	  break;
	case JOptionPane.CANCEL_OPTION:
	  return;
	default:
	  message("WARNING: bogosity in GestureSetFrame.openFile");
	  return;
	}
      }
      else {
	setFile(openActualFile(f));
	saveItem.setEnabled(true);
	setSaveLevel(SAVED);
      }
    }
    catch (ClassNotFoundException e) {
      message("Cannot find required class while reading file '"+ f +
	      "': " + e);
    }
    catch (InvalidClassException e) {
      message("Problem with a class while reading file '"+ f + "': " + e);
    }
    catch (StreamCorruptedException e) {
      message("The stream for file '" + f + "' is corrupted");	      
    }
    catch (ObjectStreamException e) {
      message("Expected an object but got primitive data while reading file '"+
	      f + "': " + e);
    }
    catch (IOException e) {
      message("I/O error reading file '"+ f + "': " + e);
    }
    catch (ParseException e) {
      message("Error parsing file '" + f +"': " + e);
    }
    catch (UnknownClassException e) {
      message("Error reading file '" + f +"': " + e);
    }
  }

  TypedFile openActualFile(File f) throws IOException, ParseException,
    UnknownClassException, ClassNotFoundException
  {
    final int OK = 0, NON_BINARY = 1, ERROR = 2;
    TypedFile openedFile = null;
    try { // first try binary format
      ObjectInputStream p = new ObjectInputStream(new FileInputStream(f));
      try { // make sure file gets closed
	String v = (String) p.readObject();
	if (!version.equals(v)) {
	  message("Error while reading file '"+ f + "': expected version '" +
		  version + "' but got version '" + v + "'");
	}
	Object obj = p.readObject();
	if (obj instanceof GestureSet) {
	  GestureSet gestureSet = (GestureSet) obj;
	  gestureSetDisplay.setGestureSet(gestureSet);
	  gestureSet.addObserver(this);
	  classifier = null;
	  isTrained = false;
	}
	else if (obj instanceof GestureCategory) {
	  addCategory((GestureCategory) obj);
	}
	else {
	  throw new UnknownClassException("Unknown object type '" +
					   obj.getClass().getName() +
					   "'");
	}
      }
      finally {
	p.close();
      }
      stopTest();
      openedFile = new TypedFile(f, "binary");
    }
    catch (ClassNotFoundException e) {
      throw new ClassNotFoundException("Cannot find required class while reading file '"+
				       f + "': " + e);
    }
    catch (InvalidClassException e) {
      throw new InvalidClassException("Problem with a class while reading file '"+
				      f + "': " + e);
    }
    catch (StreamCorruptedException e) {
      // not a binary file, so try ASCII later
    }
    catch (ObjectStreamException e) {
      throw new IOException("Expected an object but got primitive data while reading file '"+
			    f + "': " + e);
    }
    catch (IOException e) {
      throw new IOException("I/O error reading file '"+
			    f + "': " + e);
    }

    if (openedFile == null) {
      // wasn't a binary file, so try ASCII
      FileReader reader = new FileReader(f);
      try {
	GestureSet gestureSet = GestureSet.read(reader);
	gestureSetDisplay.setGestureSet(gestureSet);
	gestureSet.addObserver(this);
	classifier = null;
	isTrained = false;
	openedFile = new TypedFile(f, "ASCII");
      }
      finally {
	reader.close();
      }
    }
    return openedFile;
  }

  public void saveFile(TypedFile f)
  {
    saveFile(f, false);
  }
  
  void saveFile(TypedFile f, boolean isAutosave)
  {
    if (f == null) {
      if (gestureSetFile == null) {
	f = askForSaveFile();
	if (f == null) {
	  message("Save cancelled");
	  return;
	}
      }
      else {
	f = gestureSetFile;
      }
    }
    lastDirectory = f.getParent();
    try {
      String type = f.getType();
      if (type.equals("ASCII")) {
	message("Saving as ASCII...");
	FileWriter writer = new FileWriter(f);
	try {
	  gestureSetDisplay.getGestureSet().write(writer);
	}
	finally {
	  writer.close();
	}
      }
      else if (type.equals("binary")) {
	message("Saving as binary...");
	FileOutputStream ostream = new FileOutputStream(f);
	ObjectOutputStream objStream = new ObjectOutputStream(ostream);
	objStream.writeObject(version);
	objStream.writeObject(gestureSetDisplay.getGestureSet());
	objStream.flush();
	ostream.close();
      }
      else {
	message("Bogosity: bad file type '" + type +
		"'. Save aborted. (Try 'Save As'.)");
      }
      if (isAutosave) {
	setSaveLevel(AUTOSAVED);
      }
      else {
	setFile(f);
	autoSaveOn = true;
	setSaveLevel(SAVED);
      }
      message("File saved", 10);
    }
    catch (IOException exception) {
      message("I/O Error saving file " + f + ": " + exception);
    }
  }

  TypedFile autoSaveFile(TypedFile f)
  {
    return new TypedFile(new File(f.getParent(), "#" + f.getName() + "#"),
			 f.getType());
  }
  
  File autoSaveFile(File f)
  {
    return new File(f.getParent(), "#" + f.getName() + "#");
  }
  
  void doAutoSave(TypedFile f)
  {
    if (autoSaveOn && (saveLevel < AUTOSAVED)) {
      if (f == null) {
	if (gestureSetFile == null) {
	  // can't autosave if no file has been chosen
	  return;
	}
	f = gestureSetFile;
      }

      message("Autosaving...");
      saveFile(autoSaveFile(f), true);
      message("Done autosaving");
    }
  }
  
  /**
   * As of Swing 0.7, this doesn't work, but I'll leave it in anyway.  */
  class myFilenameFilter implements FilenameFilter
  {
    public boolean accept(File dir, String name)
    {
      return name.endsWith(".gs");
    }
  }

  /**
   * This is what gets invoked when a gesture to be classified is entered.
   */
  class ClassifyHandler implements ChangeListener
  {
    public void stateChanged(ChangeEvent e)
    {
      if (train()) {
	GestureInteractor interactor = (GestureInteractor) e.getSource();
	Gesture gesture = (Gesture) interactor.getGesture().clone();
	Classifier.Result result = classifier.
	  classifyWithoutTraining(gesture);
	String name;
	GestureSet gestureSet = gestureSetDisplay.getGestureSet();
	if (result == null) {
	  name = "?";
	  message("Unrecognized");
	}
	else {
	  name = result.category.getName();
	  message("Category: " + name +
		  " Accuracy: " + Misc.toString(result.accuracy, 4) +
		  " Distance to Mean: " + result.distToMean);
	  /* todo
	  GestureCategoryThumbnail gct =
	    gestureSetDisplay.getGestureCategoryThumbnail(result.category);
	  gestureSetDisplay.setSelection(gct);
	  gestureSetDisplay.scrollRectToVisible(gct.getBounds());
	  */
	}
	/*
	resultLabel.setText(name);
	resultLabel.setPreferredSize(awt.getTextSize(resultLabel, name));
	*/
	if (testMode) {
	  handleTestCase((Gesture) gesture.clone(), result);
	}
      }
      else {
	message("Training failed.  Can't do recognition");
      }
    }
  }

  //
  // Test methods
  //
  
  private void handleTestCase(Gesture gesture, Classifier.Result result)
  {
    /* todo
    gesture.normalize();
    
    int nominalGcIndex = testCases[testTally];
    ((GestureContainer) testGestures.getChild(nominalGcIndex)).
      add(gesture);
    testResults[testTally] = result;

    if (result != null) {
      if (testConfusionMatrix[nominalGcIndex][result.gcIndex] == null) {
	testConfusionMatrix[nominalGcIndex][result.gcIndex] = new Vector();
      }
      testConfusionMatrix[nominalGcIndex][result.gcIndex].
	addElement(gesture);
      if (nominalGcIndex == result.gcIndex)
	testsCorrect++;
    }
    
    testTally++;
    if (testTally < testCases.length) {
      // test not done
      showTestCase();
    }
    else {
      // done
      showTestResults();
      testSaveMenuItem.setEnabled(true);
      testShowMenuItem.setEnabled(true);
      stopTest();
    }
    */
  }

  void showTestResults()
  {
    int percentCorrect = (int) Math.round((double) testsCorrect * 100.0 /
					  (double) testCases.length);
    message("Test done. " + percentCorrect + "% (" + testsCorrect +
	    "/" + testCases.length + ") correct." , 0);

    TestSetFrame tsFrame = new TestSetFrame(this);
    tsFrame.gestureSetDisplay.setGestureSet(testGestures);
    tsFrame.pack();
    tsFrame.show();

    ClassificationMatrix cm =
      /*
      new ClassificationMatrix(testConfusionMatrix,
			       gestureSetDisplay.getGestureSet());
			       */
      new ClassificationMatrix(testConfusionMatrix,
			       tsFrame.gestureSetDisplay);
    cm.setTitle("Test results");
    cm.pack();
    cm.show();
  }
  
  void showTestCase()
  {
    int gcIndex = testCases[testTally];
    String name = ((GestureContainer) gestureSetDisplay.getGestureSet().
		   getChild(gcIndex)).getName();
    GestureCategoryThumbnail gct =
      gestureSetDisplay.getGestureCategoryThumbnail(gcIndex);
    gestureSetDisplay.setSelection(gct);
    gestureSetDisplay.scrollRectToVisible(gct.getBounds());
    String timeString;
    if ((testTally > 0) && (gcIndex == testCases[testTally-1])) {
      sameTest++;
      timeString = " (" + Misc.ordinal(sameTest) + " time)";
    }
    else {
      sameTest = 1;
      timeString = "";
    }
    message("Draw the '" + name + "' gesture" + timeString, 0);
  }

  void startTest()
  {
    if (!testMode && (testSaveLevel != SAVED)) {
      int reply = JOptionPane.
	showConfirmDialog(this, "Test results have not been saved." +
			  " Save them now?",
			  "gdt: Save Test Results?",
			  JOptionPane.YES_NO_OPTION,
			  JOptionPane.QUESTION_MESSAGE);
      switch (reply) {
      case JOptionPane.YES_OPTION:
	saveTest();
	break;
      case JOptionPane.NO_OPTION:
	break;
      default:
	message("Bogosity in GestureSetFrame.askToSave");
	break;
      }
    }
    testMode = true;
    resetTestState();
    testStopMenuItem.setEnabled(true);
    testSaveMenuItem.setEnabled(false);
    testShowMenuItem.setEnabled(false);
    gestureSetDisplay.setSelection(null);
    showTestCase();
  }

  /** Reset all the members related to tests. */
  void resetTestState()
  {
    if (testMode) {
      GestureSet gestureSet = gestureSetDisplay.getGestureSet();
      final int numCategories = gestureSet.size();
      final int numTestCases = numCategories * TESTS_PER_CATEGORY;
      
      testSaveLevel = NOT_SAVED;
      sameTest = 1;
      testTally = 0;
      testsCorrect = 0;
      testConfusionMatrix = new Vector[numCategories][numCategories];
      testResults = new Classifier.Result[numTestCases];
      testGestures = new GestureSet();

      // fill out the test cases and randomize them
      // Also put in empty classes in testGestures
      int tally = 0;
      testCases = new int[numTestCases];
      for (int gcIndex = 0; gcIndex < numCategories; gcIndex++) {
	for (int i = 0; i < TESTS_PER_CATEGORY; i++, tally++) {
	  testCases[tally] = gcIndex;
	}
	testGestures.
	  add(new GestureCategory(((GestureContainer) gestureSet.
				   getChild(gcIndex)).getName()));
      }
      Misc.shuffle(testCases);
    }
  }

  void stopTest()
  {
    testMode = false;
    testStopMenuItem.setEnabled(false);
    gestureSetDisplay.setSelection(null);
  }

  void saveTest()
  {
    FileDialog fileChooser =
      new FileDialog((Frame) statusWindow.getTopLevelAncestor(),
		     "Save Test", FileDialog.SAVE);
    fileChooser.
      setDirectory(experimentMode ? experimentSaveDir : "data");
    fileChooser.show();
    String baseName = fileChooser.getFile();
    if (baseName != null) {
      String dirName = fileChooser.getDirectory();
      File f = new File(dirName, baseName);
      GestureSet gs = gestureSetDisplay.getGestureSet();
      try {
	FileWriter writer = new FileWriter(f);
	// todo: fix this
	for (int row = 0; row < testConfusionMatrix.length; row++) {
	  writer.write(((GestureContainer) gs.getChild(row)).getName());
	  Vector[] currentRow = testConfusionMatrix[row];
	  for (int col = 0; col < currentRow.length; col++) {
	    int size;
	    if (currentRow[col] == null)
	      size = 0;
	    else
	      size = currentRow[col].size();
	    writer.write("\t" + size);
	  }
	  writer.write("\n");
	}
	writer.close();
      }
      catch (IOException exception) {
	message("Error saving test results to '" + f + "': " + exception);
	return;
      }
      // Now save the actual examples
      f = new File(dirName, baseName + "-ex.gs");
      try {
	ObjectOutputStream objStream =
	  new ObjectOutputStream(new FileOutputStream(f));
	objStream.writeObject(version);
	objStream.writeObject(testGestures);
	objStream.close();
      }
      catch (IOException exception) {
	message("Error saving test examples to '" + f + "': " + exception);
	return;
      }
      testSaveLevel = SAVED;
    }
    else {
      message("Test save cancelled");
    }
  }
  
  //
  // clipboard & editing functions
  //

  void setClipboard()
  {
    clipboard = gestureSetDisplay.getSelection();
    pasteMenuItem.setEnabled(true);
  }

  void copyClipboard()
  {
    clipboard = (GestureCategory)
      gestureSetDisplay.getSelection().clone();
    pasteMenuItem.setEnabled(true);
  }

  GestureCategory getClipboard()
  {
    return clipboard;
  }

  void deleteSelection()
  {
    gestureSetDisplay.getGestureSet().
      remove(gestureSetDisplay.getSelection());
    openSelectionMenuItem.setEnabled(false);
    deleteMenuItem.setEnabled(false);
    cutMenuItem.setEnabled(false);
    copyMenuItem.setEnabled(false);
  }
  
  /**
   * Invoked when a GestureCategoryThumbnail is (de)selected in the
   * GestureSetDisplay.
   */
  public void itemStateChanged(ItemEvent e)
  {
    // note: assumes that only one thing can be selected at a time
    int state = e.getStateChange();
    if (state == ItemEvent.SELECTED) {
      openSelectionMenuItem.setEnabled(true);
      deleteMenuItem.setEnabled(true);
      cutMenuItem.setEnabled(true);
      copyMenuItem.setEnabled(true);
    }
    else if (state == ItemEvent.DESELECTED) {
      openSelectionMenuItem.setEnabled(false);
      deleteMenuItem.setEnabled(false);
      cutMenuItem.setEnabled(false);
      copyMenuItem.setEnabled(false);
    }
    else {
      System.err.println("GestureSetFrame: Unknown item state " + state);
    }
  }

  private void setFile(TypedFile f)
  {
    gestureSetFile = f;
    saveItem.setEnabled(true);
    updateTitle();
  }

  void setSaveLevel(int newLevel)
  {
    if (newLevel != saveLevel) {
      saveLevel = newLevel;
      updateTitle();
      if ((saveLevel == SAVED) && (gestureSetFile != null)) {
	saveItem.setEnabled(false);
	// remove auto-save file if it exists
	File asFile = autoSaveFile(gestureSetFile);
	if (asFile.exists())
	  asFile.delete();
      }
      if ((saveLevel != SAVED) && (gestureSetFile != null)) {
	saveItem.setEnabled(true);
      }
    }
  }

  void updateTitle()
  {
    String name;
    
    if (gestureSetFile == null) {
      name = "(unnamed)";
    }
    else {
      name = gestureSetFile.getName();
    }
    String authorName = gestureSetDisplay.getGestureSet().getAuthor();
    if (authorName == null) {
      authorName = "nobody";
    }
    String title = "gdt: " + name + " [" + authorName + "]";

    if (saveLevel != SAVED)
      title = title + " (*)";
    setTitle(title);
  }
  
  public void update(Observable o, Object arg)
  {
    if ((o != null) && (o instanceof GestureSet)) {
      // something has changed
      isTrained = false;
      setSaveLevel(NOT_SAVED);
      updateTitle();
    }
  }

  void askToSave()
  {
    if (saveLevel != SAVED) {
      int reply = JOptionPane.
	showConfirmDialog(this, "This file has not been saved." +
			  " Save it now?",
			  "gdt: Save File?",
			  JOptionPane.YES_NO_OPTION,
			  JOptionPane.QUESTION_MESSAGE);
      switch (reply) {
      case JOptionPane.YES_OPTION:
	saveFile(null);
	break;
      case JOptionPane.NO_OPTION:
	break;
      default:
	// would use message(), but program is probably exiting now
	System.err.println("Bogosity in GestureSetFrame.askToSave");
	break;
      }
    }
  }

  public void setAuthor(String name)
  {
    gestureSetDisplay.getGestureSet().setAuthor(name);
  }

  void setAuthorDialog()
  {
    GestureSet gs = gestureSetDisplay.getGestureSet();
    Box widgets = new Box(BoxLayout.Y_AXIS);
    
    widgets.add(new JLabel("Enter the author name for this gesture set"));
    String oldAuthor = gs.getAuthor();
    JTextField authorField = new JTextField(oldAuthor);
    widgets.add(authorField);
    JCheckBox recurse = new JCheckBox("Set author recursively", false);
    widgets.add(recurse);

    /*		       
    JOptionPane optionPane = new JOptionPane(widgets,
					     JOptionPane.QUESTION_MESSAGE,
					     JOptionPane.OK_CANCEL_OPTION);

    JDialog dialog = optionPane.createDialog(this,
					     "Change GestureSet Author");
    dialog.show();
    */

    int dialogResult = JOptionPane.
      showOptionDialog(this, widgets, "Change GestureSet author",
		       JOptionPane.OK_CANCEL_OPTION,
		       JOptionPane.QUESTION_MESSAGE,
		       null, null, null);
    switch (dialogResult) {
    case JOptionPane.OK_OPTION:
      String author = authorField.getText();
      if (!author.equals(oldAuthor)) {
	gs.setAuthor(author);
	if (recurse.isSelected()) {
	  for (Iterator catIter = gs.iterator();
	       catIter.hasNext();) {
	    GestureCategory category = (GestureCategory)
	      catIter.next();
	    category.setAuthor(author);
	    for (Iterator gIter = category.iterator();
		 gIter.hasNext();) {
	      Gesture gesture = (Gesture) gIter.next();
	      gesture.setAuthor(author);
	    }
	  }
	}
      }
      break;
    case JOptionPane.CANCEL_OPTION:
    case JOptionPane.CLOSED_OPTION:
      break;
    default:
      System.err.println("Warning: bogus return value " + dialogResult +
			 " from JOptionPane in GestureSetFrame");
    }
  }

  public TypedFile makeTypedFile(File f, String type)
  {
    return new TypedFile(f, type);
  }
  
  public class TypedFile extends File {
    String type;
    
    TypedFile(File f, String type)
    {
      super(f.getAbsolutePath());
      setType(type);
    }

    void setType(String t)
    {
      type = t.intern();
    }

    String getType()
    {
      return type;
    }
  }

  public class UnknownClassException extends Exception
  {
    public UnknownClassException()
    {
      super();
    }

    public UnknownClassException(String detail)
    {
      super(detail);
    }
  }

  public GestureSetDisplay getGestureSetDisplay()
  {
    return gestureSetDisplay;
  }
}
