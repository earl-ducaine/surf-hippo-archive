package edu.berkeley.guir.suede.help;

import javax.swing. *;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.*;
import java.io.*;

public class Contents extends JFrame {

    /** Initializes the Form */
    public Contents() {
        super("Help - All");
        initComponents ();
        setSize(1000,700);
    }
 private void initComponents() {
     /*Create Backward and Forward buttons*/
    BackWdButton = new JButton("BackWard");
    ForWdButton = new JButton("ForWard");
    ButtonPanel = new JPanel();
    ButtonPanel.add(BackWdButton);
    ButtonPanel.add(ForWdButton);
    
    /*Creat TabbedPane on the left*/
    TabbedPane = new JTabbedPane();
    Ctp = new ContentsTabPane();
    Itp = new IndexTabPane();
    Stp = new SearchTabPane();
    TabbedPane.addTab("Contents", Ctp); 
    TabbedPane.addTab("Index", Itp);
    TabbedPane.addTab("Search", Stp);
    
    /*Create Text Area on the right*/
    RightTextArea = new JTextArea();
    RightTextArea.setFont(new Font("Serif", Font.PLAIN, 17));
    
    /*Create a SplitPane containing TabbedPane and TextArea as
     the left and right components*/
    SplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, 
                            new JScrollPane(TabbedPane), 
                            new JScrollPane(RightTextArea));
    SplitPane.setDividerLocation(250);
    SplitPane.setContinuousLayout(true);
    
    /*Add buttons and SplitPane to the main container.*/
    Container contentPane = getContentPane();
    contentPane.setLayout(new BorderLayout());
    contentPane.add(ButtonPanel, BorderLayout.NORTH);
    contentPane.add(SplitPane, BorderLayout.CENTER);
    
    Ctp.FileTree.addTreeSelectionListener(new TreeSelectionListener() {
        public void valueChanged(TreeSelectionEvent e) {
                TreePath path = e.getNewLeadSelectionPath();
                
                if (path != null) {
                    Object Last = path.getLastPathComponent(); 
                    
                    if (Ctp.treeModel.isLeaf(Last)) {
                        FileInputStream fis = null;
                        String str = null;
                        String filename = "";
                        try {
                            filename = ((FileNode)Last).toDirectoryName();
                            fis = new FileInputStream (filename);
                            int size = fis.available ();
                            byte[] bytes = new byte [size];
                            fis.read (bytes);
                            str = new String (bytes);
                        } catch (IOException e1) {
                        } finally {
                            try {
                                fis.close ();
                                } catch (IOException e2) {
                                }
                        }
                       RightTextArea.setText (str);
                    }
                }
        }
    });
 }
 
 private JButton BackWdButton;
 private JButton ForWdButton;
 private JPanel ButtonPanel;
 private JSplitPane SplitPane;
 private JTabbedPane TabbedPane;
 private ContentsTabPane Ctp;
 private IndexTabPane Itp;
 private SearchTabPane Stp;
 private JTextArea RightTextArea;
}
    