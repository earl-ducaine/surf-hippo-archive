package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that applies a template to a page.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-20-2004 James Lin
 *                               Created ApplyTemplateToPageCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-20-2004
 */
public class ApplyTemplateToPageCommand
   extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final Page page;
   private final Page template;

   /**
    * Constructs the command.
    *  
    * @param graph the interaction graph that the template should be added to
    * @param template the template to add
    */      
   public ApplyTemplateToPageCommand(
      final Page page,
      final Page template) {

      this.page = page;
      this.template = template;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Apply template " + template.toLongString() + " to " + page.toLongString();
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      page.addTemplate(template);
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      page.removeTemplate(template);
   }
}
