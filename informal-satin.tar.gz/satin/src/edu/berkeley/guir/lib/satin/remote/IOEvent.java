/*
 * IOEvent.java
 * Created on Nov 8, 2001
 */

package edu.berkeley.guir.lib.satin.remote;

/**
 * @author  Scott Klemmer, Katie Everitt
 * @version 1.4
 *
 * Encapsulation of an command in xml (string) format
 * contains the port that it came from
 * can translate itself into a SATIN Command 
 */

public class IOEvent {
   private String m_xml;
   private int    m_port;

   public IOEvent(String xml){
      m_xml = xml;
      m_port = -1;
   }
   
   /** Creates new IOEvent */
   public IOEvent(String xml, int port) {
      m_xml = xml;
      m_port = port;
   }
   
   public String getXML()  {  return m_xml;   }   
   public int    getPort() {  return m_port;  }
   
}

