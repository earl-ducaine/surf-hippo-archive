package edu.berkeley.guir.suede;

public class TranscriptNodeModel extends AbstScriptNodeModel {
    private static final int STD_RESP = 0;
    private static final int TIME_OUT = 1;
    private static final int BARGE_IN = 2;
    private static final int DID_NOT_SAY = 3;
    private static final int SAID_WRONG = 4;
   
    private int    m_responseType = STD_RESP;
    private String m_userID;
   
    // only one of these two will be used
    private LinkModel       m_linkModel   = null;
    private SingleNodeModel m_promptModel = null;


    // This constructor is for system audio
    public TranscriptNodeModel(String label, SingleNodeModel promptModel, int userID) {
	super(label);
	setScriptNumber( userID ); // sets the script number and the userID
	m_promptModel = promptModel;
	m_script      = new TranscriptNodeView(AbstScriptNodeModel.SYSTEM, this);
	m_samplingGraph.setElement(m_script);
	setPlayable(true);
	setCaption(promptModel.getCaption());
	setAudio(promptModel.getAudio());
	setAudioDuration();
	setBalloons(promptModel.getBalloons());
    }

    // This constructor is for user audio loaded from a file
    public TranscriptNodeModel(String label, String audiofilename, int userID) {
	super(label);
	setScriptNumber( userID );
	m_script      = new TranscriptNodeView(AbstScriptNodeModel.SYSTEM, this);
	m_samplingGraph.setElement(m_script);
	setPlayable(true);
	setCaption(label);
	fillAudio(audiofilename);
    }



    // when we create a user transcript node, we don't know yet which link it represents
    // we are recording the audio for it, so we pass that in
    public TranscriptNodeModel(String label, int userID) {
	super(label);
	setScriptNumber( userID );
	m_script    = new TranscriptNodeView(AbstScriptNodeModel.USER, this);
	m_samplingGraph.setElement(m_script);
	setPlayable(true);
    }
 
  
    // This constructor is for user audio loaded from a linkmodel
    public TranscriptNodeModel(String label, LinkModel linkModel, int userID) {
	this(label, userID);
	setCaption(linkModel.getCaption());
	setAudio(linkModel.getAudio());
    }


    public void setTimeOut() {
	m_responseType = TIME_OUT;
	((TranscriptNodeView)m_script).setTimeOut();   
    }


    public void setDidNotSay() {
	m_responseType = DID_NOT_SAY;
	((TranscriptNodeView)m_script).setDidNotSay();   
    }


    public void setSaidWrong() {
	m_responseType = SAID_WRONG;
	((TranscriptNodeView)m_script).setSaidWrong();   
    }

   
    public void updateTranscriptWithLink(LinkModel link) {
	if (link != null) {        
	    setCaption(link.getCaption());
	    //setAudioAndAdd(link.getAudio());        
	    m_linkModel = link;      
	} 
    }
  
  
    public synchronized void stopRecordingAudio() {
	m_cardSound.stopRecordingAudio();
    }
  
    public String getMenuName() {
	return "User: "+m_userID+" ("+((int)(10*getDuration()))/10+" sec.)";
    }

    // Added to fix a bug in loading transcripts where user ID wasn't loaded.
    public void setScriptNumber( int n ) {
	super.setScriptNumber( n );
	m_userID = String.valueOf( n );
    }
  
    public String getUserId() {
	return m_userID;
    }
  
}
