package edu.berkeley.guir.lib.satin.interpreter.commands;

import edu.berkeley.guir.lib.satin.SatinConstants;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.objects.*;
import java.awt.geom.Point2D;

/**
 * An interpreter that detects whether the endpoint of the current
 * stroke is over the title bar of a framed patch. If it is, it forwards
 * the stroke to the title bar.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  12-27-2000 James Lin
 *                               Created FramedPatch
 *             1.2.0  08-13-2001 James Lin
 *                               Moved to Satin
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 12-27-2000
 */
public class FramedPatchTitleBarInterpreter
    extends InterpreterImpl
    implements SatinConstants {
      
    private FramedPatch currentPatch = null;
    
    //--------------------------------------------------------------------------
    
    public FramedPatchTitleBarInterpreter() {
       super();
    }

    //--------------------------------------------------------------------------
    
    public void handleNewStroke(NewStrokeEvent evt) {
       Point2D endPt = evt.getStroke().getEndPoint2D(COORD_ABS);
       
       currentPatch = null;
       
       GraphicalObjectCollection gobcol;
       GraphicalObject gob = null;
       GraphicalObjectGroup gobgrp = (GraphicalObjectGroup)getAttachedGraphicalObject();
       
       // Find out if the user tapped on a FramedPatch
       gobcol = gobgrp.getGraphicalObjects
          (COORD_ABS, endPt, FIRST, SHALLOW, CONTAINS);
       if (!gobcol.isEmpty()) {
          gob = gobcol.get(0);
       }
       
       if (gob instanceof FramedPatch) {
          // Find out if the user tapped on the FramedPatch's title bar
          FramedPatch thePatch = (FramedPatch)gob;
          if (thePatch.isInsideTitleBar(GraphicalObjectLib.absoluteToLocal(gob, endPt))) {
             currentPatch = thePatch;
             currentPatch.handleTitleBarNewStroke(evt);
          }
       }
    }
    
    //--------------------------------------------------------------------------

    public void handleUpdateStroke(UpdateStrokeEvent evt) {
       if (currentPatch != null) {
          currentPatch.handleTitleBarUpdateStroke(evt);
       }
    }

    //--------------------------------------------------------------------------

    public void handleSingleStroke(SingleStrokeEvent evt) {
       if (currentPatch != null) {
          currentPatch.handleTitleBarSingleStroke(evt);
       }
    }
    
    //--------------------------------------------------------------------------

    public Object clone() {
       return new FramedPatchTitleBarInterpreter();
    }
}

//==============================================================================

/*
  Copyright (c) 2000 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
