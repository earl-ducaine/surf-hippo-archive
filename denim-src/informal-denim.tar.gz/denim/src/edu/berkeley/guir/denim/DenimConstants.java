package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.command.*;
import java.awt.*;
import java.io.File;
import edu.berkeley.guir.lib.satin.*;

/**
 * Global constants for DENIM.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-18-1999 MWN
 *                    Created interface DenimConstants
 *             1.1.0  12-28-2002 YL
 *                  Added activeFrameColor
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~newman/">Mark Newman</A> (
 *          <A HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 *
 * @since   JDK 1.2
 * @version Version 1.0.0, 12-28-2002
 */
public interface DenimConstants
   extends SatinConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   // The build number to put in the splash screen and Help About
   public static final String BUILD_STR             = "build: 2007.07.03";
   
   public static final String BUILD_VER             = "Version 2.1";


   // The name of the file to write stdout and stderr to
   public static final String ERRLOG_STR            = "denim_err.log";

   //---------------------------------------------------------------------

   // The number of backup files to keep around.
   public static final int NUM_BACKUPS              = 10;

   //---------------------------------------------------------------------

   public static final DenimClipboard denimClipboard = new DenimClipboard();


	// move to Sketch class
   //public static final int DEFAULT_SKETCH_WIDTH     = 450;
   //public static final int DEFAULT_SKETCH_HEIGHT    = 550;
   //public static final int DEFAULT_SKETCH_WIDTH     = 700;
   //public static final int DEFAULT_SKETCH_HEIGHT    = 900;
   public static final int DEFAULT_GUTTER_WIDTH     = 50;
   public static final int DEFAULT_GUTTER_HEIGHT    = 50;
   public static final int DEFAULT_TEXT_WIDTH       = 100;
   public static final int DEFAULT_TEXT_HEIGHT      = 30;

   public static final String DEFAULT_EVENT     = null;

   //---------------------------------------------------------------------

   /**
    * Arrows must be at least this value in one dimension
    */
   public static final int MIN_ARROW_DIMENSION      = 20;

   //---------------------------------------------------------------------

   public static final int DEFAULT_TOOL_SPACING     = 10;
   public static final int DEFAULT_TOOLBOX_CUSHION  = 15;

   //---------------------------------------------------------------------


   /**
    * Colors and other style settings
    */

   public static final int DEFAULT_TRANSPARENCY       = 255;
   public static final int LOW_TRANSPARENCY           = 50;

   public static final Color NO_COLOR                 = new Color(0, 0, 0, 0);
   public static final Color DEFAULT_NAV_ARROW_COLOR  = new Color(0, 153, 0);
   public static final Color DEFAULT_ORG_ARROW_COLOR  = new Color(128, 128, 128);
   public static final Color DEFAULT_LINK_COLOR       = new Color(0, 0, 255);
   public static final Color DEFAULT_BKGRD_COLOR      = new Color(226, 226, 199);
   public static final Color DEFAULT_CROSSHAIR_COLOR  = DEFAULT_BKGRD_COLOR.darker();
   public static final Color DEFAULT_COMPONENT_COLOR  = DEFAULT_BKGRD_COLOR.darker();
   public static final Color AUDIO_ICON_OUTLINE_COLOR = Color.black;
   public static final Color DEFAULT_HOME_COLOR       = Color.cyan;
   public static final Color DENIM_SCRIBBLED_BG_COLOR = new Color(0, 0, 0, 12);
   public static final float DEFAULT_HOME_WIDTH       = 4.0f;
   public static final float DEFAULT_BORDER_WIDTH     = .001f;
   public static final float ACTIVE_BORDER_WIDTH      = 1f;

   public static final Color DEFAULT_ANNO_COLOR       = Color.red;

   public static final Color[] DEFAULT_OTHER_ANNO_COLORS = { Color.blue,
                                                      Color.green.darker(),
                                                      Color.magenta,
                                                      Color.orange,
                                                      Color.darkGray,
                                                      Color.gray };
                                                      
   public static final Color DEFAULT_GROUP_COLOR          = Color.lightGray;
   public static final float[] DEFAULT_GROUP_DASH_ARRAY   = new float[] {2, 3.5f};
   
   public static final Color DEFAULT_SCRIBBLE_BACKGROUND_COLOR = new Color(0, 0, 0, 20);
   
   public static final Color ZOOM_SLIDER_BACKGROUND_COLOR = new Color(202, 181, 155);
   public static final Color TOOLS_AREA_BACKGROUND_COLOR = new Color(128, 64, 0);
   public static final Color MENU_BUTTON_BACKGROUND_COLOR = new Color(225, 213, 198);

   //---------------------------------------------------------------------

   //=== The absolute scale factors corresponding to different values of
   //=== the zoom slider
   public static final double ZOOM_NOTCH_0    = 0.04;
   public static final double ZOOM_NOTCH_10   = 0.07;
   public static final double ZOOM_NOTCH_20   = 0.10;
   public static final double ZOOM_NOTCH_30   = 0.13;
   public static final double ZOOM_NOTCH_40   = 0.16;
   public static final double ZOOM_NOTCH_50   = 0.36;
   public static final double ZOOM_NOTCH_60   = 0.64;
   public static final double ZOOM_NOTCH_70   = 1.0;
   public static final double ZOOM_NOTCH_80   = 1.25;
   public static final double ZOOM_NOTCH_90   = 1.50;
   public static final double ZOOM_NOTCH_100  = 1.85;

   public static final double ZOOM_NOTCH_5    = (ZOOM_NOTCH_0 + ZOOM_NOTCH_10) / 2;
   public static final double ZOOM_NOTCH_15   = (ZOOM_NOTCH_10 + ZOOM_NOTCH_20) / 2;
   public static final double ZOOM_NOTCH_25   = (ZOOM_NOTCH_20 + ZOOM_NOTCH_30) / 2;
   public static final double ZOOM_NOTCH_35   = (ZOOM_NOTCH_30 + ZOOM_NOTCH_40) / 2;
   public static final double ZOOM_NOTCH_45   = (ZOOM_NOTCH_40 + ZOOM_NOTCH_50) / 2;
   public static final double ZOOM_NOTCH_55   = (ZOOM_NOTCH_50 + ZOOM_NOTCH_60) / 2;
   public static final double ZOOM_NOTCH_65   = (ZOOM_NOTCH_60 + ZOOM_NOTCH_70) / 2;
   public static final double ZOOM_NOTCH_75   = (ZOOM_NOTCH_70 + ZOOM_NOTCH_80) / 2;
   public static final double ZOOM_NOTCH_85   = (ZOOM_NOTCH_80 + ZOOM_NOTCH_90) / 2;
   public static final double ZOOM_NOTCH_95   = (ZOOM_NOTCH_90 + ZOOM_NOTCH_100) / 2;

   public static final double ABOVE_OVERVIEW_SCALE_FACTOR             = ZOOM_NOTCH_0;
   public static final double OVERVIEW_SCALE_FACTOR                   = ZOOM_NOTCH_10;
   public static final double BETWEEN_OVERVIEW_SITEMAP_SCALE_FACTOR   = ZOOM_NOTCH_20;
   public static final double SITEMAP_SCALE_FACTOR                    = ZOOM_NOTCH_30;
   public static final double BETWEEN_SITEMAP_STORYBOARD_SCALE_FACTOR = ZOOM_NOTCH_40;
   public static final double STORYBOARD_SCALE_FACTOR                 = ZOOM_NOTCH_50;
   public static final double BETWEEN_STORYBOARD_SKETCH_SCALE_FACTOR  = ZOOM_NOTCH_60;
   public static final double SKETCH_SCALE_FACTOR                     = ZOOM_NOTCH_70;
   public static final double BETWEEN_SKETCH_DETAIL_SCALE_FACTOR      = ZOOM_NOTCH_80;
   public static final double DETAIL_SCALE_FACTOR                     = ZOOM_NOTCH_90;
   public static final double BELOW_DETAIL_SCALE_FACTOR               = ZOOM_NOTCH_100;
   

   //---------------------------------------------------------------------

   /**
    * This is the transition for interpreters to select deep and shallow.
    * Anything greater than this value selects deep, anything less than
    * this value selects shallow.
    */
   public static final double INTERPRETER_TRANSITION   = ZOOM_NOTCH_45;

   /**
    * The location of all of the data and properties files.
    */
   public static final String DENIM_DATADIRECTORY = "data" +
                                                    File.separatorChar;

   public static final String DENIM_DTDS_URL =
                        "http://guir.berkeley.edu/projects/denim/ddoc/";

   //---------------------------------------------------------------------

   /**
    * The name of Denim's properties file. Assumed to be in the current
    * directory, from which Denim is started (via the java interpreter).
    */
   public static final String DENIM_PROPERTIES_FILENAME = "denim.properties";

   public static final String PROP_USER                 = "user";

   public static final String PROP_WINDOW_X             = "windowX";
   public static final String PROP_WINDOW_Y             = "windowY";
   public static final String PROP_WINDOW_WIDTH         = "windowWidth";
   public static final String PROP_WINDOW_HEIGHT        = "windowHeight";
   public static final String PROP_IS_RADAR_VIEW_VISIBLE = "isRadarViewVisible";

   public static final String PROP_AUTHOR_URL           = "author_url";

   public static final String PROP_REVIEWER_URL         = "reviewer_url";

   //public static final String PROP_OPTION_PAGE_WIDTH       = "option_page_width";
   //public static final String PROP_OPTION_PAGE_HEIGHT      = "option_page_height";
   public static final String PROP_OPTION_AUTOSAVE         = "option_autosave";
   public static final String PROP_OPTION_AUTOSAVE_INTERVAL= "option_autosave_interval";
   public static final String PROP_OPTION_GRID             = "option_grid";
   public static final String PROP_OPTION_GRID_HGAP        = "option_grid_hgap";
   public static final String PROP_OPTION_GRID_VGAP        = "option_grid_vgap";
   
   public static final String GLOBAL_FONT1        = "global_font1";
   public static final String GLOBAL_FONT2        = "global_font2";
   public static final String GLOBAL_FONT3        = "global_font3";
   
   //----------------------------------------------------------------------

   public static final String DENIM_TEXT_FONT_FAMILY = "Comic Sans MS";
   
   /*-------------------------------------------------------------
    * Temporal Image
    */
    
   public static final Color activeFrameColor = Color.blue;

   //===   CONSTANTS   =========================================================
   //===========================================================================

} // of interface

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
