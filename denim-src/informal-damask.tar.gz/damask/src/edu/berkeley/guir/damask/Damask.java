package edu.berkeley.guir.damask;

import java.util.*;

import edu.berkeley.guir.damask.view.DamaskApp;

/** 
 * The Damask application. See the
 * <a href="http://guir.berkeley.edu/projects/damask/">Damask</a> project page
 * for details.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-18-2003 James Lin
 *                               Created Damask
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 03-18-2003
 */

public class Damask {
   public static final boolean PATTERNS_AND_LAYERS = true;
   
   private static final DeviceType[] SUPPORTED_DEVICE_TYPES =
      { DeviceType.DESKTOP, DeviceType.SMARTPHONE, DeviceType.VOICE };


   /**
    * Returns a collection of devices that is supported by Damask. 
    */
   public static Collection getSupportedDeviceTypes() {
      return Collections.unmodifiableCollection(
         Arrays.asList(SUPPORTED_DEVICE_TYPES));
   }
   
   
   public static void main(String[] args) {
      DamaskApp.main(args);
   }
//      final InteractionGraph graph = new InteractionGraph();
//
//      final JFrame frame = new JFrame("Damask Model");
//      frame.getContentPane().add(new JScrollPane(new DamaskStateTree(graph)));
//      frame.pack();
//      frame.show();
//
//      // Fill in 1st dialog
//      final Dialog dialog = new Dialog(new Content("Dialog 1"));
//      graph.add(dialog);
//      
//      final TextInput textField = new TextInput();
//      dialog.addToAll(Direction.CENTER, textField);
//
//      final Page pcPage = dialog.getFirstPage(DeviceType.DESKTOP);
//      final PageRegion pcCenterRegion = pcPage.getRegion(Direction.CENTER);
//      final Content pcOnlyLabel = new Content("PC only label");
//      pcCenterRegion.add(null, pcOnlyLabel);
//
//      final Trigger trig = new Trigger();
//      dialog.addToAll(textField, trig);
//
//      final Trigger trig2 = new Trigger(new Content("after PC only label"));
//      dialog.addToAll(pcOnlyLabel, trig2);
//
//
//      // Fill in 2nd dialog
//      final Dialog dialog2 = new Dialog(new Content("Dialog 2"));
//      graph.add(dialog2);
//
//      final Page pcPage2 = dialog2.getFirstPage(DeviceType.DESKTOP);
//
//      dialog2.addToAll(Direction.CENTER, new Content("Label 2"));
//
//      final Content label = new Content("Blah");
//      dialog2.getFirstPage(DeviceType.SMARTPHONE).getRegion(
//         Direction.CENTER).add(
//         label);
//      dialog2.getFirstPage(DeviceType.VOICE).getRegion(Direction.CENTER).add(
//         label);
//
//      // Add a connection from PC page 2 to page 1
//      OrgConnection a = new OrgConnection(DeviceType.DESKTOP, pcPage2, pcPage);
//      graph.add(a);
//      assert pcPage.getOutConnections(DeviceType.DESKTOP).contains(a);
//      assert pcPage2.getInConnections(DeviceType.DESKTOP).contains(a);
//
//      // Add a connection from a button in PC page 1 to page 2
//      NavConnection t =
//         new NavConnection(
//            DeviceType.DESKTOP,
//            HoverOverEvent.class,
//            trig,
//            0,
//            pcPage2);
//      graph.add(t);
//      assert trig.getOutConnections(DeviceType.DESKTOP).contains(t);
//      assert pcPage2.getInConnections(DeviceType.DESKTOP).contains(t);
//
//      // Setup a pattern
//      final Pattern pattern = new Pattern();
//      pattern.setName("Woohoo");
//      
//      final PatternSolution solution = pattern.getSolution();
//
//      final JFrame patternFrame = new JFrame("Pattern Solution - Woohoo");
//      patternFrame.getContentPane().add(
//         new JScrollPane(new DamaskStateTree(solution)));
//      patternFrame.pack();
//      patternFrame.show();
//
//      final PatternInstance instance = new PatternInstance(pattern);
//      
//      final Dialog dialogP1 = new Dialog(new Label("Pattern Dialog 1"));
//      solution.add(dialogP1);
//      
//      final Trigger trigP1 = new Trigger(new Label("Pattern trigger"));
//      dialogP1.addToAll(Direction.CENTER, trigP1);
//      instance.add(trigP1);
//
//      final Label labelP1 = new Label("Logo");
//      dialogP1.addToAll(Direction.NORTHWEST, labelP1);
//      instance.add(labelP1);
//
//      final Label labelP2 = new Label("Banner");
//      dialogP1.addToAll(Direction.EAST, labelP2);
//      instance.add(labelP2);
//
//      final Dialog dialogP2 = new Dialog(new Label("Pattern Dialog 2"));
//      solution.add(dialogP2);
//
//      final SelectMany checkBoxesP2 = new SelectMany();
//      dialogP2.addToAll(Direction.CENTER, checkBoxesP2);
//      instance.add(checkBoxesP2);
//
//      NavConnection ncP1 =
//         new NavConnection(
//            DeviceType.DESKTOP,
//            InvokeEvent.class,
//            trigP1,
//            0,
//            dialogP2.getFirstPage(DeviceType.DESKTOP));
//
//      assert trigP1.getOutConnections(DeviceType.DESKTOP).contains(ncP1);
//      assert dialogP2
//         .getFirstPage(DeviceType.DESKTOP)
//         .getInConnections(DeviceType.DESKTOP)
//         .contains(ncP1);
//
//      ncP1.addDeviceType(
//         DeviceType.SMARTPHONE,
//         InvokeEvent.class,
//         trigP1,
//         0,
//         dialogP2.getFirstPage(DeviceType.SMARTPHONE));
//      
//      assert trigP1.getOutConnections(DeviceType.SMARTPHONE).contains(ncP1);
//      assert dialogP2
//         .getFirstPage(DeviceType.SMARTPHONE)
//         .getInConnections(DeviceType.SMARTPHONE)
//         .contains(ncP1);
//
//      instance.add(ncP1);
//      solution.add(ncP1);
//      
//      solution.setMainPatternInstance(instance);
//
//      System.out.println("Graph:");
//      System.out.println(graph.toLongString());
//      System.out.println();
//      System.out.println("Pattern solution:");
//      System.out.println(pattern.getSolution().toLongString());
//
//      // Pause
//      System.out.print("?");
//      BufferedReader input =
//         new BufferedReader(new InputStreamReader(System.in), 1);
//      try {
//         input.readLine();
//      }
//      catch (IOException e) {
//      }
//      
//      // Instantiate pattern and merge with main design
//      graph.mergePatternInstance(
//         pattern,
//         dialogP1.getFirstPage(DeviceType.DESKTOP),
//         pcPage);
//      System.out.println("Graph after pattern merge:");
//      System.out.println(graph.toLongString());
//   }
}
