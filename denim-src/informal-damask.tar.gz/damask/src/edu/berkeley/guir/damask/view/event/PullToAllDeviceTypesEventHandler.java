package edu.berkeley.guir.damask.view.event;

import java.awt.event.InputEvent;
import java.util.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.command.ModifyGraphMacroCommand;
import edu.berkeley.guir.damask.command.ReplaceComponentWithDeviceAllVersionCommand;
import edu.berkeley.guir.damask.component.Component;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.DamaskCanvas;
import edu.berkeley.guir.damask.view.visual.component.ComponentView;
import edu.berkeley.guir.damask.view.visual.component.RadioButton;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PDragSequenceEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;

/** 
 * The event handler that handles the Pull to All Devices tool.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  06-17-2004 James Lin
 *                               Created PullToAllDeviceTypesEventHandler
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 06-17-2004
 */
public class PullToAllDeviceTypesEventHandler
   extends PDragSequenceEventHandler {

   public PullToAllDeviceTypesEventHandler() {
      getEventFilter().setAndMask(InputEvent.BUTTON1_MASK);
   }

   public void startDrag(PInputEvent e) {
      super.startDrag(e);
      pull(e);
   }

   public void drag(PInputEvent e) {
      super.drag(e);
      pull(e);
   }

   /**
    * Pulls the object underneath the point from the This Device Type layer to
    * the All Device Types layer.
    */
   private void pull(PInputEvent e) {
      final DamaskCanvas currentCanvas = (DamaskCanvas)e.getComponent();
      final Set/*<PNode>*/ pickedNodes =
         new HashSet(DamaskAppUtils.getPickedNodes(currentCanvas, e.getPosition()));

      // Instead of pushing individual radio buttons, we push all of the
      // related radio buttons as a group.
      final Set/*<PNode>*/ nodesToAdd = new HashSet();
      final Set/*<PNode>*/ nodesToRemove = new HashSet();
      for (Iterator i = pickedNodes.iterator(); i.hasNext(); ) {
         final PNode node = (PNode)i.next();
         if (node instanceof RadioButton) {
            nodesToAdd.add(node.getParent());
            nodesToRemove.add(node);
         }
      }
      pickedNodes.addAll(nodesToAdd);
      pickedNodes.removeAll(nodesToRemove);

      final MacroCommand cmd = new ModifyGraphMacroCommand();
      for (Iterator i = pickedNodes.iterator(); i.hasNext(); ) {
         final PNode node = (PNode)i.next();
         if (node instanceof ComponentView) {
            final Component component =
               (Component) ((ComponentView)node).getModel();
            if (component.getDialog().getDeviceType() == DeviceType.ALL) {
               cmd.addCommand(
                  new ReplaceComponentWithDeviceAllVersionCommand(component));
            }
         }
      }
      currentCanvas.getDocument().getCommandQueue().doCommand(currentCanvas,
                                                              cmd);
   }
}
