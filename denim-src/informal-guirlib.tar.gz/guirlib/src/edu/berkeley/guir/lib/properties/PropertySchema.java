package edu.berkeley.guir.lib.properties;

import java.beans.*;

/**
 * Specifies a single schema for a property in the FlexProperties class.
 * <P>
 * There are three methods you may want to override:
 * <UL>
 *    <LI>{@link #acceptValue(Object, Object)}
 *    <LI>{@link #onIllegalArgumentException(IllegalArgumentException, Object,
 *        Object)}
 *    <LI>{@link #onPropertyVetoException(PropertyVetoException,Object,Object)}
 * </UL>
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0-1.0.0, Jun 02 2000, JH
 *               Created class
 *             - GUIRLib-v1.5/1.0.0, Apr 09 2002, JIH
 *               Updated for JDK1.4 with assertions, general cleanup
 *               and removal of cruftiness.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3
 * @version GUIRLib-v1.5/1.0.0, Apr 09 2002 JIH
 */
public class PropertySchema 
   implements PropertyConstants {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   String strPropertyName  = "UnnamedProperty";
   int    propertyType     = PROPERTY_SIMPLE;

   //// specify how to fire - clone list first or just fire
   ////    necessary for those that delete

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTOR   =======================================================

   public PropertySchema(String newPropertyName) {
      setPropertyName(newPropertyName);
   } // of method

   //-----------------------------------------------------------------

   public PropertySchema(String newPropertyName, int propertyType) {
      setPropertyName(newPropertyName);
      setPropertyType(propertyType);
   } // of method

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================




   //===========================================================================
   //===   TYPE CHECKING METHODS   =============================================

   /**
    * Check if this value acceptable for this property.
    * An IllegalArgumentException will be thrown automatically if this fails.
    *
    * <P>
    * Override this method to specify valid types and values.
    */
   public boolean acceptValue(Object oldVal, Object newVal) {
      return (true);
   } // of method

   //===   TYPE CHECKING METHODS   =============================================
   //===========================================================================




   //===========================================================================
   //===   EXCEPTION HANDLING METHODS   ========================================

   /**
    * Occurs if {@link #acceptValue(Object, Object)} fails.
    * The current value of the property will still be oldVal.
    * Default behavior is to print exception to System.err.
    * <P>
    * Override this method to a new behavior for exception handling.
    *
    * @param e      is the exception thrown.
    * @param oldVal is the original and current value.
    * @param newVal is the proposed value that caused the exception.
    */
   public void onIllegalArgumentException(IllegalArgumentException e, 
                                          Object oldVal, Object newVal) {
      System.err.println(e);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Occurs if one of the veto change listeners throws a hissy fit.
    * The current value of the property will still be oldVal.
    * Default behavior is to print exception to System.err.
    * <P>
    * Override this method to a new behavior for exception handling.
    *
    * @param e      is the exception thrown.
    * @param oldVal is the original and current value.
    * @param newVal is the proposed value that caused the exception.
    */
   public void onPropertyVetoException(PropertyVetoException e,
                                       Object oldVal, Object newVal) {
      System.err.println(e);
   } // of method

   //===   EXCEPTION HANDLING METHODS   ========================================
   //===========================================================================




   //===========================================================================
   //===   ACCESSOR / MODIFIER METHODS   =======================================

   public void setPropertyName(String newPropertyName) {
      strPropertyName = newPropertyName;
   } // of method

   /**
    * Get the name of this property.
    */
   public String getPropertyName() {
      return (strPropertyName);
   } // of method

   //-----------------------------------------------------------------

   public void setPropertyType(int type) {
      switch (type) {
         case PROPERTY_SIMPLE:
         case PROPERTY_BOUND:
         case PROPERTY_CONSTRAINED:
         case PROPERTY_INDEXED:
            propertyType = type;
            break;
         default:
            throw new IllegalArgumentException("Invalid property type value");
      }
   } // of method

   public int getPropertyType() {
      return (propertyType);
   } // of method

   //-----------------------------------------------------------------

   public void setSimpleProperty() {
      propertyType = PROPERTY_SIMPLE;
   } // of method

   public boolean isSimpleProperty() {
      return (propertyType == PROPERTY_SIMPLE);
   } // of method

   //-----------------------------------------------------------------

   public void setBoundProperty() {
      propertyType = PROPERTY_BOUND;
   } // of method

   public boolean isBoundProperty() {
      return (propertyType == PROPERTY_BOUND);
   } // of method

   //-----------------------------------------------------------------

   public void setConstrainedProperty() {
      propertyType = PROPERTY_CONSTRAINED;
   } // of method

   public boolean isConstrainedProperty() {
      return (propertyType == PROPERTY_CONSTRAINED);
   } // of method

   //-----------------------------------------------------------------

   public void setIndexedProperty() {
      propertyType = PROPERTY_INDEXED;
   } // of method

   public boolean isIndexedProperty() {
      return (propertyType == PROPERTY_INDEXED);
   } // of method

   //===   ACCESSOR / MODIFIER METHODS   =======================================
   //===========================================================================




   //===========================================================================
   //===   TOSTRING   ==========================================================

   private static String toString(int propertyType) {
      switch (propertyType) {
         case PROPERTY_SIMPLE:      return ("Simple");
         case PROPERTY_BOUND:       return ("Bound");
         case PROPERTY_CONSTRAINED: return ("Constrained");
         case PROPERTY_INDEXED:     return ("Indexed");
         default:
            throw new IllegalArgumentException("Invalid property type value");
      } // of case
   } // of method

   /**
    * Get a String version of this schema.
    */
   public String toString() {
      StringBuffer strbuf = new StringBuffer();

      strbuf.append("[Type: " + toString(propertyType) + "] ");
      strbuf.append("[Name: " + strPropertyName + "]");

      return (strbuf.toString());
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
