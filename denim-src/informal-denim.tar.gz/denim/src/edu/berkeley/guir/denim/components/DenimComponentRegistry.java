package edu.berkeley.guir.denim.components;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.toolbox.*;
import edu.berkeley.guir.lib.debugging.*;
import java.util.*;
import javax.swing.*;
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Stores all of the components available for the designer to use. Any
 * components created by the designer are also stored here.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-05-1999  James Lin
 *                                Created DenimComponentRegistry
 *             1.0.1  01-06-2004  Yang Li
 *                                Leaving new customcomponentstamp as the current cursor
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version Version 1.0.0, 01-06-2004
 */
public class DenimComponentRegistry
	implements DenimConstants, java.io.Serializable
{

	//===========================================================================
	//===   CONSTANTS   =========================================================

	//===   CONSTANTS   =========================================================
	//===========================================================================

	//===========================================================================
	//===   NONLOCAL VARIABLES   ================================================

	static private DenimComponentRegistry instance = null;

	//-----------------------------------------------------------------

	private HashMap registry;
	private int componentCounter;
	
	class RenameComponent extends JDialog {
		JTextField tf;
		JLabel warning = new JLabel("Input component name");
		final int width = 390;
		final int height = 140;
		
		public RenameComponent(String oldName) {
			super(((DenimWindow)Denim.getWindows().get(0)), "Rename the new component", true);
			
		
			this.setResizable(false);
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			
			double w = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
			double h = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
			this.setBounds((int)((w-width)/2), (int)((h-height)/2),
								width, height);
								
			tf = new JTextField(oldName);
			tf.setPreferredSize(new Dimension(370,26));
			JPanel top = new JPanel();
			((FlowLayout)top.getLayout()).setAlignment(FlowLayout.LEADING);
			
			top.add(warning);
			this.getContentPane().add(top, BorderLayout.NORTH);
			
			JPanel middle = new JPanel();
			((FlowLayout)middle.getLayout()).setAlignment(FlowLayout.LEADING);
			middle.add(tf);
			this.getContentPane().add(middle, BorderLayout.CENTER);
			
			JPanel btm = new JPanel();
			tf.addKeyListener(new KeyAdapter() {
				public void keyPressed(KeyEvent evt) {
					warning.setForeground(Color.black);
					warning.setText("Input component name");
				}
			});

			JButton ok = new JButton("OK");
			btm.add(ok);
			ok.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					if(tf.getText().equals(""))
					{
						warning.setForeground(Color.red);
						warning.setText("The name cannot be empty.");
					}
					else if(DenimComponentRegistry.getInstance()
							.registry.containsKey(tf.getText()))
					{
						warning.setForeground(Color.red);
						warning.setText(tf.getText() + " has been used. Please choose another name.");
					}
					else
					{
						RenameComponent.this.setVisible(false);
					}
				}
			});
			
			this.getContentPane().add(btm, BorderLayout.SOUTH);
		}
	}

	//===   NONLOCAL VARIABLES   ================================================
	//===========================================================================

	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	/**
	 * Called by getInstance() to construct an instance of the
	 * registry. Keeping it private insures that only one instance of the
	 * registry in created.
	 */
	private DenimComponentRegistry()
	{
		registry = new LinkedHashMap();
		// LinkedHashMap preserves add order in iterator!
		componentCounter = 0;

		// Initialize with intrinsic components
		registerComponent(new DenimHyperlink()); // Doesn't show in toolbox
		registerComponent(new DenimCheckBox());
		registerComponent(new DenimRadioButton());
		registerComponent(new DenimButton());
		registerComponent(new DenimTextField());
		registerComponent(new DenimListBox());
		registerComponent(new DenimComboBox());
	}

    public void reset()
    {
        System.err.println("Resetting component registry ...");
        
        /**
         * clear all lists of instances
         */
        Iterator it = registry.values().iterator();
        LinkedList cstKeys = new LinkedList();
        while(it.hasNext())
        {
            DenimComponent co = (DenimComponent)it.next();
            co.instances.clear();
            if(co instanceof DenimCustomComponent)
            {
                cstKeys.add(co.getName());
            }
        }
        
        /**
         * clear custom components
         */
        it = cstKeys.iterator();
        while(it.hasNext())
        {
            String key = (String)it.next();
            this.unregisterComponent(key);
        }
    }
    
	//===   CONSTRUCTORS   ======================================================
	//===========================================================================

	//===========================================================================
	//===   XXXXX METHODS   =====================================================

	/**
	 * Loads custom components that were defined in a previous session from
	 * the settings file and registers them.
	 */
	private void registerCustomComponents()
	{
	}

	//-----------------------------------------------------------------

	/**
	 * Accesses the component registry.
	 */
	static public DenimComponentRegistry getInstance()
	{
		if (instance == null)
		{
			instance = new DenimComponentRegistry();
			instance.registerCustomComponents();
		}
		return instance;
	}

	//-----------------------------------------------------------------

	/**
	 * Adds the given component to the registry.
	 */
	public DenimComponent registerComponent(DenimComponent newComponent)
	{
		componentCounter++;
		Debug.println(newComponent.getName());
		if (newComponent.getName() == null
			|| newComponent.getName().equals(""))
		{
			newComponent.setName("Component" + componentCounter);
		}

		// Note: when the built-in components are added, no windows exist,
		// so this loop is not executed.  Built-in components are positioned
		// explicitly in ToolsArea.java ...
		if (newComponent.getRubberStamp() != null)
		{
			AbstractList windowList = (AbstractList) Denim.getWindows();
			for (int i = 0; i < windowList.size(); i++)
			{
				DenimWindow window = (DenimWindow) windowList.get(i);
				DenimUI ui = window.getDenimUI();

				ToolsArea toolsArea = ui.getToolbox().getToolsArea();

				RubberStamp stamp = newComponent.getRubberStamp();
				stamp.setLocation(350, 10); // fix this cheesy hack!
				toolsArea.add(stamp);
				toolsArea.repaint();
				stamp.setVisible(true);

				if (ui.getCurrentTool() instanceof BlankRubberStamp)
				{
					ui.getCurrentTool().drop(
						ui.getToolbox().getToolsArea(),
						((BlankRubberStamp) ui.getCurrentTool()).getLstPos());
					stamp.grab();
				}

				//stamp.activate();
			}
		}
	
		if(registry.containsKey(newComponent.getName()))
		{
			Object[] options = { "Rename", "Replace", "Skip" };
			int result = JOptionPane.showOptionDialog(null, 
					newComponent.getName() +" has been used by another component.\n",
					"Warning", 
					JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
					null, options, options[0]);
			
			if(result==0)
			{
				RenameComponent rc = new RenameComponent(newComponent.getName());
				rc.setVisible(true);
				newComponent.setName(rc.tf.getText());
				return (DenimComponent)
					(registry.put(newComponent.getName(), newComponent));				
			}
			else if(result==1)
			{
				return (DenimComponent)
					(registry.put(newComponent.getName(), newComponent));				
			}
			else
			{
				return null;
			}
		}
		else
		{		
			return (DenimComponent)
				(registry.put(newComponent.getName(), newComponent));
		}
	}

	//-----------------------------------------------------------------

	/**
	 * Returns the component with the given name.
	 */
	public DenimComponent getComponent(String name)
	{
		return (DenimComponent) (registry.get(name));
	}

	//-----------------------------------------------------------------

	/**
	 * Removes the component with the given name from the registry.
	 */
	public DenimComponent unregisterComponent(String name)
	{
        componentCounter--;
        System.err.println("A component removed.");
		return (DenimComponent) (registry.remove(name));
	}

	//-----------------------------------------------------------------

	/**
	 * Returns a set of the names of all of the components in the registry.
	 */
	public Set getComponentNames()
	{
		return registry.keySet();
	}

	//-----------------------------------------------------------------

	/**
	 * Returns all of the components in the registry.
	 */
	public Collection getComponents()
	{
		return registry.values();
	}
    
    //-----------------------------------------------------------------

    /**
     * Returns all of the components in the registry.
     */
    public Collection getCustomComponents()
    {
        LinkedList list = new LinkedList();
        Iterator it = registry.values().iterator();
        while(it.hasNext())
        {
            DenimComponent dc = (DenimComponent)it.next();
            if(dc instanceof DenimCustomComponent)
            {
                list.add(dc);
            }
        }
        return list;
    }

    
    //-----------------------------------------------------------------

    /**
     * Returns all of the components in the registry.
     */
    public Collection getCustomComponentNames()
    {
        LinkedList list = new LinkedList();
        Iterator it = registry.values().iterator();
        while(it.hasNext())
        {
            DenimComponent dc = (DenimComponent)it.next();
            if(dc instanceof DenimCustomComponent)
            {
                list.add(dc.getName());
            }
        }
        return list;
    }
    
    public boolean hasCustomComponents()
    {
        if(registry.values().size()>7)
        {
            return true;
        }
        return false;
    }
    
	//===   XXXXX METHODS   =====================================================
	//===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
