package edu.berkeley.guir.denim.toolbox;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.*;
import java.awt.*;
import javax.swing.*;

/**
 * A rubber stamp, which allows designers to "stamp" components into their
 * sketches on the sheet.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-19-1999 James Lin
 *                               Created RubberStamp
 *                    07-26-1999 James Lin
 *                               Moved to ...toolbox package
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 07-26-1999
 */
public class RubberStamp
   extends Tool {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -7987898834268005604L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private DenimComponent component;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates a rubber stamp which looks like the given icon and, when
    * tapped, will insert an instance of the given component.
    */
   public RubberStamp(String iconFileName, DenimComponent component) {
      super(iconFileName,
            new Point(7, 15),
            new Point(15, 31),
            new Point(15, 31),
            component.getName());
      this.component = component;
      setSize(45, 32);  // HACK
      
      if (component instanceof DenimButton) {
         this.setToolTipText("Push Button");
      }
      else if (component instanceof DenimCheckBox) {
         this.setToolTipText("Check Box");
      }
      else if (component instanceof DenimComboBox) {
         this.setToolTipText("Combo Box");  
      }
      else if (component instanceof DenimListBox) {
         this.setToolTipText("List Box");  
      }
      else if (component instanceof DenimRadioButton) {
         this.setToolTipText("Radio Button");  
      }
      else if (component instanceof DenimTextField) {
         this.setToolTipText("Text Field");  
      }
      
   }

   //-----------------------------------------------------------------

   /**
    * Creates a rubber stamp with a label that contains the given name. This
    * is used for custom components.
    *
    * <p>Ideally, we want the rubber stamp of a component to have a thumbnail
    * of the first panel of the component, by default. While we try to figure
    * out how to do that in Java, this method will suffice.
    */
   public RubberStamp(Icon icon, DenimCustomComponent component) {
      this("small_stamp.gif", (DenimComponent)component);
      setName(component.getName());
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   XXXXX METHODS   =====================================================

   public void firstAddedToContainer() {
      super.firstAddedToContainer();
      DenimSheet sheet = getDenimUI().getSheet();
      enabledInterpreters.add(sheet.getRubberStampInterpreter());
      sheet.setInkOn(false);
   }

   //-----------------------------------------------------------------

   /**
    * Sets the name of the rubber stamp. Should be called only by
    * DenimCustomComponent.setName()
    */
   public void setName(String newName) {
      setText("<html><center><font color=\"black\"><small>" + newName + "</small></font></center></html>");
      setHorizontalAlignment(JLabel.CENTER);
      setVerticalTextPosition(JLabel.TOP);
      setHorizontalTextPosition(JLabel.CENTER);
      setIconTextGap(0);
   }

   //-----------------------------------------------------------------

   /**
    * Returns the component associated with the rubber stamp.
    */
   public DenimComponent getComponentType() {
      return component;
   }

   //-----------------------------------------------------------------

   /**
    * Grabs the tool and disables inking the sheet.
    */
   public void grab() {
      super.grab();

      DenimSheet sheet = getDenimUI().getSheet();

      sheet.setInkOn(false);

      // Tells the rubber stamp interpreter what type of component it should
      // insert.
      sheet.getRubberStampInterpreter().setComponentType(component);

      // HACK: will be unnecessary when "real" move gesture is implemented
      sheet.setEnableLeftButtonGestures(false);
   }

   //===   XXXXX METHODS   =====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
