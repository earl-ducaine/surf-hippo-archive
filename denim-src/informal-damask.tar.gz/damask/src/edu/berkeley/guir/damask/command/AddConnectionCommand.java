package edu.berkeley.guir.damask.command;

import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.connection.*;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.userevent.DamaskUserEvent;
import edu.berkeley.guir.damask.view.DamaskAppUtils;
import edu.berkeley.guir.damask.view.voice.component.Response;
import edu.berkeley.guir.lib.collection.Map2D;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that adds a connection to an interaction graph.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  10-22-2003 James Lin
 *                               Created AddConnectionCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 10-22-2003
 */
public class AddConnectionCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final DeviceType deviceType;
   private final boolean addToAllDeviceTypes;
   private final DamaskUserEvent userEvent;
   private InteractionGraph graph;
   private final ConnectionSource source;
   private final int condition;
   private final ConnectionDest dest;
   private final GeneralPath generalPathForDeviceType;
   private Connection connection;
   private ConnectionInfo newConnectionInfo;
   private Page voicePageWithTrigger = null;
   private Page splitVoicePage = null;

   private final Set/*<ConnectionInfo>*/ removedConnections = new HashSet();
   private final Map2D/*<Connection, DeviceType, GeneralPath>*/
      changedShapeConnections = new Map2D();
   private Trigger sourceTrigger = null;
   private Content voiceContentBeforeSourceTrigger = null;

   //===========================================================================

   /**
    * Constructs the command. If the source is Content, it will be converted
    * to a Trigger when the command is executed.
    * 
    * @param deviceType the device type of the connection
    * @param addToAllDeviceTypes true if the connection should be added to
    *         all device types
    * @param graph the graph to add the connection to
    * @param source the source of the connection
    * @param dest the destination of the connection
    * @param generalPathForDeviceType the shape of the connection for the
    *         specified device type
    */
   public AddConnectionCommand(
      final DeviceType deviceType,
      final boolean addToAllDeviceTypes,
      final ConnectionSource source,
      final DamaskUserEvent userEvent,
      final int condition,
      final ConnectionDest dest,
      final GeneralPath generalPathForDeviceType) {

      this.deviceType = deviceType;
      this.addToAllDeviceTypes = addToAllDeviceTypes;
      this.userEvent = userEvent;
      this.source = source;
      this.condition = condition;
      this.dest = dest;
      this.generalPathForDeviceType = generalPathForDeviceType;
   }

   //---------------------------------------------------------------------------

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Add connection: " +
         source + "->" + dest +
         ", origDeviceType=" + deviceType +
         ", forAll=" + addToAllDeviceTypes + 
         ", userEvent=" + userEvent +
         ", condition=" + condition +
         ", path=" + Arrays.asList(
            DamaskAppUtils.getEndPoints(generalPathForDeviceType));
   }

   //---------------------------------------------------------------------------

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   //===========================================================================

   /**
    * Removes the specified connection and saves it so that it can be
    * restored in undo.
    */
   private void removeConnectionAndSaveInfo(final Connection connection) {
      removedConnections.add(new ConnectionInfo(connection));
      connection.getInteractionGraph().remove(connection);
      connection.dispose();
   }

   //---------------------------------------------------------------------------

   /**
    * Changes the shape of the specified connection for the specified device
    * type, and saves the old shape so that it can be restored in undo.
    */
   private void changeConnectionShape(
      final Connection connection,
      final DeviceType deviceType,
      final GeneralPath path) {

      changedShapeConnections.put(
         connection,
         deviceType,
         connection.getShape(deviceType));
      connection.setShape(deviceType, path);
   }

   //---------------------------------------------------------------------------

   /**
    * Restores the original shape of the specified connection for the
    * specified device type.
    */
   private void restoreConnectionShape(
      final Connection connection,
      final DeviceType deviceType) {

      final GeneralPath origShape =
         (GeneralPath)changedShapeConnections.get(connection, deviceType);

      if (origShape != null) {
         connection.setShape(deviceType, origShape);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Returns the connections whose shapes need to be restored in undo.
    */
   private Set getConnectionsForShapeRestoration() {
      return changedShapeConnections.getRows();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns the types of devices for which connections need their shapes to
    * be restored in undo.
    */
   private Set getDeviceTypesForShapeRestoration() {
      return changedShapeConnections.getCols();
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the default shape of the connection for all device types except
    * the passed-in one.
    */
   private void setDefaultConnectionShapes(final Connection connection) {
      for (Iterator i = connection.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {

         final DeviceType aDeviceType = (DeviceType)i.next();
         
         if ((aDeviceType != deviceType) && (aDeviceType != DeviceType.VOICE)) {
            //TODO make smarter than just going between upper-left corners
            final ConnectionSource sourceForADeviceType =
               connection.getConnectionSource(aDeviceType);

            final Rectangle2D boundsForSourceForADeviceType =
               sourceForADeviceType.localToGlobal(
                  aDeviceType,
                  sourceForADeviceType.getBounds(aDeviceType));

            final ConnectionDest destForADeviceType =
               connection.getConnectionDest(aDeviceType);

            final Rectangle2D boundsForDestForADeviceType =
               destForADeviceType.localToGlobal(
                  aDeviceType,
                  destForADeviceType.getBounds(aDeviceType));

            final GeneralPath aGeneralPath = new GeneralPath();

            aGeneralPath.moveTo(
               (float)boundsForSourceForADeviceType.getX(),
               (float)boundsForSourceForADeviceType.getY());

            aGeneralPath.lineTo(
               (float)boundsForDestForADeviceType.getX(),
               (float)boundsForDestForADeviceType.getY());

            connection.setShape(aDeviceType, aGeneralPath);
         }
      }
   }

   //===========================================================================
   
   /**
    * Replaces the specified content with a trigger that contains a copy
    * of that content.
    */
   private void replaceContentWithTrigger(final Content sourceControl) {
      if (sourceTrigger == null) {
         sourceTrigger =
            new Trigger(
               sourceControl.getDeviceType(),
               (Content)sourceControl.clone());
      }
      sourceTrigger.setStyle(sourceControl.getDeviceType(), Trigger.HYPERLINK);

      for (Iterator i = sourceControl.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {

         final DeviceType aDeviceType = (DeviceType)i.next();

         if (aDeviceType != DeviceType.VOICE) {
            sourceTrigger.setBounds(
               aDeviceType,
               sourceControl.getBounds(aDeviceType));
            sourceTrigger.setTransform(
               aDeviceType,
               sourceControl.getTransform(aDeviceType));
            sourceTrigger.getContent().setTransform(
               aDeviceType,
               new AffineTransform());
         }
      }

      final Dialog dialog = sourceControl.getDialog();

      // Add voice prompt for trigger if necessary
      if (sourceTrigger.isVisibleToDeviceType(DeviceType.VOICE)) {
         final Control prevControlWithPrompt =
            DamaskUtils.getPreviousControlWithPrompt(
               sourceControl.getPageRegion(DeviceType.VOICE), sourceControl);
         if (prevControlWithPrompt == null) {
            voiceContentBeforeSourceTrigger = new Content(
               DeviceType.VOICE, Response.NULL_DISPLAY_STRING);
            dialog.addControlAfter(
               sourceControl, voiceContentBeforeSourceTrigger);
            voiceContentBeforeSourceTrigger.setTransform(
               DeviceType.VOICE, sourceControl.getTransform(DeviceType.VOICE));
         }
      }      
      
      // Replace the control with the trigger
      if (voiceContentBeforeSourceTrigger != null) {
         dialog.addControlAfter(voiceContentBeforeSourceTrigger, sourceTrigger);
      }
      else {
         dialog.addControlAfter(sourceControl, sourceTrigger);
      }
      dialog.removeControl(sourceControl);
   }
   
   //===========================================================================

   /**
    * Returns an organizational connection between the specified pages with
    * the specified device type, or null if none exist. 
    */
   protected OrgConnection getOrgConnection(
      final Page sourcePage,
      final Page destPage,
      final boolean isForAllDeviceTypes) {

      OrgConnection result = null;

      for (Iterator i = sourcePage.getOutConnections().iterator();
         i.hasNext();
         ) {

         final OrgConnection outConnection = (OrgConnection)i.next();

         if (outConnection.getDest(destPage.getDeviceType()) == destPage) {
            if (isForAllDeviceTypes == outConnection.isForAllDeviceTypes()) {
               result = outConnection;
               break;
            }
         }
      }

      return result;
   }

   //---------------------------------------------------------------------------

   /**
    * Returns whether there is already a navigational connection between
    * the specified pages, for the specified device type (which can be
    * DeviceType.ALL).
    */
   protected boolean navConnectionExists(
      final Page sourcePage,
      final Page destPage,
      final boolean isForAllDeviceTypes) {

      DamaskUtils.checkValidArgument(
         sourcePage.getDeviceType() == destPage.getDeviceType(),
         "source and dest pages must be the same device type");
      final DeviceType aDeviceType = sourcePage.getDeviceType();

      for (Iterator i = graph.getConnections(deviceType).iterator();
         i.hasNext();
         ) {

         final Connection connection = (Connection)i.next();
         if (connection instanceof NavConnection) {
            if ((connection
               .getConnectionSource(aDeviceType)
               .getPage(aDeviceType)
               == sourcePage)
               && (connection.getConnectionDest(aDeviceType).getPage(aDeviceType)
                  == destPage)
               && (connection.isForAllDeviceTypes() == isForAllDeviceTypes)) {
               return true;
            }
         }
      }
      return false;
   }

   //===========================================================================

   /**
    * Returns whether this command should be executed.
    */
   public boolean shouldRun() {
      DamaskUtils.checkValidArgument(
         source.getInteractionGraph() == dest.getInteractionGraph(),
         "source and dest of new connection must be in the same graph");
      graph = source.getInteractionGraph();
      
      // If the connection to be created is an organization connection...
      if ((source instanceof Page) && (dest instanceof Page)) {
         final Dialog sourceDialog = ((Page)source).getDialog();
         final Dialog destDialog = ((Page)dest).getDialog();
         if (addToAllDeviceTypes) {
            // Don't add if this connection is for all devices but
            // the source and dest are not.
            if ((sourceDialog.getDeviceType() != DeviceType.ALL)
               || (destDialog.getDeviceType() != DeviceType.ALL)) {
               return false;
            }
            return !navConnectionExists((Page)source, (Page)dest, true);
         }
         else {
            // Don't add if there is already an org connection between
            // source and dest for all device types.
            if (getOrgConnection((Page)source, (Page)dest, true) != null) {
               return false;
            }

            // Don't add if there is already an nav connection between
            // source and dest pages.
            if (navConnectionExists((Page)source, (Page)dest, true)) {
               return false;
            }
            if (navConnectionExists((Page)source, (Page)dest, false)) {
               return false;
            }

            return true;
         }
      }
      // Otherwise, if it's a navigational connection...
      else {
         if (addToAllDeviceTypes) {
            // Don't add if this connection is for all devices but
            // the source and dest are not.
            final Control sourceControl = (Control)source;
            if (sourceControl.getDeviceType() != DeviceType.ALL) {
               return false;
            }
            if (dest instanceof Page) {
               if (((Page)dest).getDialog().getDeviceType()
                  != DeviceType.ALL) {
                  return false;
               }
            }
            else { // dest instanceof Control
               if (((Control)dest).getDeviceType() != DeviceType.ALL) {
                  return false;
               }
            }
            return true;
         }
         else {
            final Control sourceControl = (Control)source;
            if (sourceControl.getDeviceType() == DeviceType.ALL) {
               return false;
            }
            // Don't add if there is already a nav connection between
            // source and dest for all device types.
            final NavConnection existingConnection =
               ((Control)source).getOutConnection(
                  deviceType,
                  addToAllDeviceTypes,
                  userEvent,
                  condition);

            if (existingConnection != null) {
               if (existingConnection.isForAllDeviceTypes()) {
                  return false;
               }
            }
            return true;
         }
      }
   }

   //===========================================================================

   /**
    * Adds an organizational connection for all device types.
    */
   private void addOrgConnectionForAllDevices() {
      final Page sourcePage = (Page)source;
      final Page destPage = (Page)dest;

      // Make sure the passed-in device type matches the source's and
      // destination's.
      DamaskUtils.checkValidArgument(
         sourcePage.getDialog().getDeviceType() == DeviceType.ALL,
         "The dialog of the source page "
            + sourcePage
            + " should support all device types, not just "
            + sourcePage.getDialog().getDeviceType());

      DamaskUtils.checkValidArgument(
         destPage.getDialog().getDeviceType() == DeviceType.ALL,
         "The dialog of the source page "
            + destPage
            + " should support all device types, not just "
            + destPage.getDialog().getDeviceType());

      // If there is already an organizational connection between the
      // source and destination for all devices, then simply change the
      // shape for the passed-in device type, and don't add a new connection.
      final OrgConnection existingConnection =
         getOrgConnection(sourcePage, destPage, addToAllDeviceTypes);
      if (existingConnection != null) {
         changeConnectionShape(
            existingConnection,
            deviceType,
            generalPathForDeviceType);
         return;
      }

      // NOTE: If there is already a navigational connection between the
      // source and destination for all devices, then don't add a new
      // connection. (This should have already been taken care of
      // by checking the result of shouldRun() before executing this
      // command.)

      // Create the connection.
      connection =
         new OrgConnection(
            deviceType,
            addToAllDeviceTypes,
            sourcePage,
            destPage,
            generalPathForDeviceType);

      // Change the shape of the connection for the device types other than
      // the passed-in one.
      setDefaultConnectionShapes(connection);

      // If there is already an organizational connection between the
      // source and destination for a device type, then remove it, but use
      // its shape in the new connection.
      for (Iterator i = connection.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {

         final DeviceType aDeviceType = (DeviceType)i.next();
         final Page sourcePageForADeviceType =
            (Page)connection.getConnectionSource(aDeviceType);
         final Page destPageForADeviceType =
            (Page)connection.getConnectionDest(aDeviceType);

         final Set /*<Connection>*/
         sourcePageForADeviceTypeOutConnections =
            new HashSet(sourcePageForADeviceType.getOutConnections());

         for (Iterator j = sourcePageForADeviceTypeOutConnections.iterator();
            j.hasNext();
            ) {

            final OrgConnection outConnection = (OrgConnection)j.next();

            if ((outConnection.getDest(aDeviceType) == destPageForADeviceType)
               && !outConnection.isForAllDeviceTypes()) {

               connection.setShape(
                  aDeviceType,
                  outConnection.getShape(aDeviceType));

               removeConnectionAndSaveInfo(outConnection);

               break;
            }
         }
      }

      // Add the new connection.      
      graph.add(connection);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds an organizational connection for one device type.
    */
   private void addOrgConnectionForOneDevice() {
      final Page sourcePage = (Page)source;
      final Page destPage = (Page)dest;

      // Make sure the passed-in device type matches the source's and
      // destination's.
      DamaskUtils.checkValidArgument(
         sourcePage.getDeviceType() == deviceType,
         "The device type of this command "
            + deviceType
            + " must match the device type of the source "
            + source
            + ", which is "
            + sourcePage.getDeviceType());

      DamaskUtils.checkValidArgument(
         destPage.getDeviceType() == deviceType,
         "The device type of this command "
            + deviceType
            + " must match the device type of the destination "
            + dest
            + ", which is "
            + destPage.getDeviceType());

      // NOTE: If there is already an organizational connection between the
      // source and destination for all devices, then don't add a new
      // connection. (This should have already been taken care of
      // by checking the result of shouldRun() before executing this
      // command.)

      // If there is already an organizational connection between the
      // source and destination for this device, then change the shape
      // of that connection, and don't add a new connection.
      final OrgConnection existingConnection =
         getOrgConnection(sourcePage, destPage, addToAllDeviceTypes);
      if (existingConnection != null) {
         changeConnectionShape(
            existingConnection,
            deviceType,
            generalPathForDeviceType);
         return;
      }

      // NOTE: If there is already a navigation connection between the
      // source and destination pages, then don't add a new connection.
      // (This should have already been taken care of by checking the
      // result of shouldRun() before executing this command.)

      // Create and add the new connection.
      connection =
         new OrgConnection(
            deviceType,
            addToAllDeviceTypes,
            sourcePage,
            destPage,
            generalPathForDeviceType);

      graph.add(connection);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds a navigational connection for all device types.
    */
   private void addNavConnectionForAllDevices() {
      final Control sourceControl = (Control)source;

      final Control destControl;
      if (dest instanceof Control) {
         destControl = (Control)dest;
      }
      else {
         destControl = null;
      }
      final Page destPage = dest.getPage(deviceType);

      // Make sure the passed-in device type matches the source's and
      // destination's.
      DamaskUtils.checkValidArgument(
         sourceControl.getDeviceType() == DeviceType.ALL,
         "The device type of this command "
            + deviceType
            + " must match the device type of the source "
            + sourceControl
            + ", which is "
            + sourceControl.getDeviceType());

      if (destControl == null) {
         DamaskUtils.checkValidArgument(
            destPage.getDialog().getDeviceType() == DeviceType.ALL,
            "The device type of the destination "
               + dest
               + " must be DeviceType.ALL, not "
               + destPage.getDialog().getDeviceType());
      }
      else {
         DamaskUtils.checkValidArgument(
            destControl.getDeviceType() == DeviceType.ALL,
            "The device type of the destination "
               + dest
               + " must be DeviceType.ALL, not "
               + destControl.getDeviceType());
      }

      // If there is already a navigational connection between the
      // source and destination for all devices, then simply change the
      // shape for the passed-in device type, and don't add a new connection.
      {
         final NavConnection existingConnection =
            sourceControl.getOutConnection(
               deviceType, userEvent, condition);
         if ((existingConnection != null)
            && (existingConnection.getDest(deviceType) == dest)
            && existingConnection.isForAllDeviceTypes()) {
            changeConnectionShape(
               existingConnection,
               deviceType,
               generalPathForDeviceType);
            return;
         }
      }

      // If there is already an organizational connection between the
      // source and destination's pages for all device types, then remove it.
      {
         final OrgConnection existingConnection =
            getOrgConnection(
               source.getPage(deviceType),
               dest.getPage(deviceType),
               true);
         if (existingConnection != null) {
            removeConnectionAndSaveInfo(existingConnection);
         }
      }

      final Map/*<DeviceType, GeneralPath>*/ existingPaths = new HashMap();

      // For each device type...
      for (Iterator i = sourceControl.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {

         final DeviceType aDeviceType = (DeviceType)i.next();

         // If there is already an organizational connection between the
         // source and destination's pages for this device type, then remove it.
         {
            final OrgConnection existingConnection =
               getOrgConnection(
                  source.getDialog().getFirstPage(aDeviceType),
                  dest.getDialog().getFirstPage(aDeviceType),
                  false);
            if (existingConnection != null) {
               removeConnectionAndSaveInfo(existingConnection);
            }
         }

         // If there is already a navigational connection from the
         // source for this device type, then remove it. If the connection
         // goes to the same destination, the save the shape for the
         // new connection.
         {
            final NavConnection existingConnection =
               sourceControl.getOutConnection(
                  deviceType,
                  addToAllDeviceTypes,
                  userEvent,
                  condition);
            if ((existingConnection != null)
               && existingConnection.isForAllDeviceTypes()) {
               if (existingConnection.getDest(deviceType) == dest) {
                  existingPaths.put(
                     aDeviceType,
                     existingConnection.getShape(aDeviceType));
               }

               removeConnectionAndSaveInfo(existingConnection);
            }
         }
      }

      // If the source is content, convert it into a trigger.         
      if (sourceControl instanceof Content) {
         replaceContentWithTrigger((Content)sourceControl);
      }

      // Create and add the connection.
      connection =
         new NavConnection(
            deviceType,
            addToAllDeviceTypes,
            (sourceTrigger == null) ? sourceControl : sourceTrigger,
            (sourceTrigger == null) ? userEvent : userEvent.createCopy(sourceTrigger),
            condition,
            dest,
            generalPathForDeviceType);

      graph.add(connection);

      // Change the shape of the connection for the device types other than
      // the passed-in one.
      setDefaultConnectionShapes(connection);

      // Use the shapes from existing connections, if appropriate.
      for (Iterator i = existingPaths.keySet().iterator(); i.hasNext();) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         connection.setShape(
            aDeviceType,
            (GeneralPath)existingPaths.get(aDeviceType));
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Adds a navigational connection for one device type.
    */
   private void addNavConnectionForOneDevice() {
      final Control sourceControl = (Control)source;

      final Control destControl;
      if (dest instanceof Control) {
         destControl = (Control)dest;
      }
      else {
         destControl = null;
      }
      final Page destPage = dest.getPage(deviceType);

      // Make sure the passed-in device type matches the source's and
      // destination's.
      {
         final DeviceType sourceDeviceType = sourceControl.getDeviceType();
         final DeviceType destDeviceType;
         if (destControl == null) {
            destDeviceType = destPage.getDeviceType();
         }
         else {
            destDeviceType = destControl.getDeviceType();
         }

         DamaskUtils.checkValidArgument(
            (sourceDeviceType == DeviceType.ALL)
               || (sourceDeviceType == deviceType),
            "The device type of this command "
               + deviceType
               + " must be compatible with the device type of the source "
               + sourceControl
               + ", which is "
               + sourceControl.getDeviceType());

         DamaskUtils.checkValidArgument(
            (destDeviceType == DeviceType.ALL)
               || (destDeviceType == deviceType),
            "The device type of this command "
               + deviceType
               + " must be compatible with the device type of the destination "
               + dest
               + ", which is "
               + destDeviceType);
      }

      // If there is already an organizational connection between the
      // source and destination's pages for this device type, then remove it.
      {
         final OrgConnection existingConnection =
            getOrgConnection(
               source.getDialog().getFirstPage(deviceType),
               dest.getDialog().getFirstPage(deviceType),
               false);
         if (existingConnection != null) {
            removeConnectionAndSaveInfo(existingConnection);
         }
      }

      // If there is already a navigational connection from the
      // source for this device type...
      {
         final NavConnection existingConnection =
            sourceControl.getOutConnection(
               deviceType,
               addToAllDeviceTypes,
               userEvent,
               condition);
         if ((existingConnection != null)
            && !existingConnection.isForAllDeviceTypes()) {
            // If destination is the same, then simply change the shape
            // and don't add a new connection.
            if (existingConnection.getDest(deviceType) == dest) {
               changeConnectionShape(
                  existingConnection,
                  deviceType,
                  generalPathForDeviceType);
               return;
            }
            // If destination is not the same, then remove it.               
            else {
               removeConnectionAndSaveInfo(existingConnection);
            }
         }
      }

      // If the source is content, convert it into a trigger.         
      if (sourceControl instanceof Content) {
         replaceContentWithTrigger((Content)sourceControl);
      }

      // Create and add the connection.
      connection =
         new NavConnection(
            deviceType,
            addToAllDeviceTypes,
            (sourceTrigger == null) ? sourceControl : sourceTrigger,
            (sourceTrigger == null) ? userEvent : userEvent.createCopy(sourceTrigger),
            condition,
            dest,
            generalPathForDeviceType);

      graph.add(connection);

      // Change the shape of the connection for the device types other than
      // the passed-in one.
      setDefaultConnectionShapes(connection);
   }

   //===========================================================================

   // Overrides method in superclass.   
   public void run() {
      DamaskUtils.checkValidArgument(
         source.getInteractionGraph() == dest.getInteractionGraph(),
         "source and dest of new connection must be in the same graph");

      graph = source.getInteractionGraph();
      connection = null;
      removedConnections.clear();
      changedShapeConnections.clear();

      // If the source and destination are pages, then create an
      // organizational connection.
      if (source instanceof Page) {
         if (addToAllDeviceTypes) {
            addOrgConnectionForAllDevices();
         }
         else {
            addOrgConnectionForOneDevice();
         }
      }
      // Otherwise, create a navigational connection.
      else {
         if (addToAllDeviceTypes) {
            addNavConnectionForAllDevices();
         }
         else {
            addNavConnectionForOneDevice();
         }
      }
      if (connection != null) {
         newConnectionInfo = new ConnectionInfo(connection);
      }
      else {
         newConnectionInfo = null;
      }
   }

   //---------------------------------------------------------------------------

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   //---------------------------------------------------------------------------

   // Overrides method in superclass.   
   public void undo() {
      // Remove and disable the connection.
      // The original connection might have been erased in subsequent
      // AddConnectionCommands and RemoveConnectionCommands, so search
      // the graph for a connection with the same characteristics as the
      // original, and remove that one.
      if (newConnectionInfo != null) {
         final Connection connectionToRemove =
            newConnectionInfo.findConnection(graph);
         graph.remove(connectionToRemove);
         connectionToRemove.dispose();
      }

      // For any device type where content was replaced with a trigger,
      // restore the original content.
      if (sourceTrigger != null) {
         final Content sourceContent = (Content)source;
         sourceTrigger.getDialog().addControlAfter(
            sourceTrigger,
            sourceContent);
         sourceTrigger.getDialog().removeControl(sourceTrigger);
         if (splitVoicePage != null) {
            voicePageWithTrigger.merge(splitVoicePage);
         }
      }

      // If a voice placeholder was added, remove it
      if (voiceContentBeforeSourceTrigger !=  null) {
         voiceContentBeforeSourceTrigger.getDialog().removeControl(
            voiceContentBeforeSourceTrigger);
      }
      
      // For any device type where a connection was replaced, restore
      // the original connection.
      for (Iterator i = removedConnections.iterator(); i.hasNext();) {
         final ConnectionInfo removedConnectionInfo = (ConnectionInfo)i.next();
         final Connection restoredConnection =
            removedConnectionInfo.createConnection();
         graph.add(restoredConnection);
      }

      // For any device type where the shape of a connection changed,
      // restore the original shape.
      for (Iterator i = getConnectionsForShapeRestoration().iterator();
         i.hasNext();
         ) {
         final Connection restoredConnection = (Connection)i.next();

         for (Iterator j = getDeviceTypesForShapeRestoration().iterator();
            j.hasNext();
            ) {

            final DeviceType aDeviceType = (DeviceType)j.next();

            restoreConnectionShape(restoredConnection, aDeviceType);
         }
      }
   }
}
