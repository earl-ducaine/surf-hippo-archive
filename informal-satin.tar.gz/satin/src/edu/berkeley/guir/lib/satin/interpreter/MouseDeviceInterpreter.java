package edu.berkeley.guir.lib.satin.interpreter;

import java.awt.*;
import java.awt.event.*;

/**
 * A class that uses mouse motion to interpret whether the user is using a mouse or a pen
 * NOTE: The mouseMoved method doesn't do anything, and there's no timer yet
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~srk/">Scott Klemmer</A> (
 *         <A HREF="mailto:srk@cs.berkeley.edu">srk@cs.berkeley.edu</A> )
 */
public class MouseDeviceInterpreter implements MouseMotionListener{
   private boolean   m_bIsPenCursor;
	private int       m_mouseTimeout = 10000; // Time after mouse motion before reverting to pen cursor
   private Cursor    m_mouseCursor;
   private Cursor    m_penCursor;
   private Component m_component;
   

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public MouseDeviceInterpreter(Cursor mouseCursor, Cursor penCursor, boolean startWithPen) {
      m_mouseCursor = mouseCursor;
      m_penCursor   = penCursor;
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   public void setMouseTimeout(int milliseconds) {
      m_mouseTimeout = milliseconds;  
   }
   
   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   public void mouseDragged(MouseEvent e) {}
   
   public void mouseMoved(MouseEvent e) {
      m_component = e.getComponent();
      if (m_bIsPenCursor) m_component.setCursor(m_mouseCursor);
      m_bIsPenCursor = false;
      //timer.restart(); //set the time since mouse motion to 0
   }
   
   private void timeoutCallback() {
      m_component.setCursor(m_penCursor);      
      m_bIsPenCursor = true;
   }

   
   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (new MouseDeviceInterpreter(m_mouseCursor, m_penCursor, m_bIsPenCursor));
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2000 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/