package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import edu.berkeley.guir.lib.gesture.features.Aspect;
import edu.berkeley.guir.lib.gesture.util.Misc;
import java.util.*;

/** MainFrame was getting too big, so all the analyzers that run in
    the background are defined here. */
public class Analyzers
{
  protected MainFrame mainFrame;
  protected boolean analyzersEnabled = true;
  
  public Analyzers(MainFrame mf)
  {
    mainFrame = mf;
  }

  public void addBackgroundTasks()
  {
    TaskManager manager = TaskManager.getTaskManager(mainFrame);
    manager.addTask(new NameClashTester(mainFrame));
    manager.addTask(new TrainingExampleTester(mainFrame));
    manager.addTask(new RecognizerSimilarityTester(mainFrame));
    manager.addTask(new HumanSimilarityTester(mainFrame));
    manager.addTask(new OutlyingGestureTester(mainFrame));
    manager.start();
  }

  public void restartTasks()
  {
    if (analyzersEnabled) {
      TaskManager manager = TaskManager.getTaskManager(mainFrame);
      manager.removeAllTasks();
      addBackgroundTasks();
    }
  }

  public void setAnalysisEnabled(boolean on)
  {
    if (analyzersEnabled != on) {
      analyzersEnabled = on;
      if (on) {
	System.out.println("Analyzers: starting tasks");
	restartTasks();
      }
      else {
	System.out.println("Analyzers: stopping tasks");
	TaskManager manager = TaskManager.getTaskManager(mainFrame);
	manager.removeAllTasks();
      }
    }
  }
  
  /** make sure all categories are uniquely named */
  public static class NameClashTester implements TaskManager.NoticeTask {
    private MainFrame mainFrame;
    private Map names;
    
    public NameClashTester(MainFrame mf)
    {
      mainFrame = mf;
      names = new HashMap();
    }

    public Set computeNotices() throws InterruptedException
    {
      GesturePackage pkg = mainFrame.getGesturePackage();
      Set result = new HashSet();
      names.clear();
      //System.out.println("Checking training set");
      testCollection(pkg.getTrainingSet());
      for (Iterator iter = pkg.getTestSets().iterator(); iter.hasNext();) {
	names.clear();
	GestureContainer collection = (GestureContainer) iter.next();
	//System.out.println("Checking test set " + collection.getName());
	result.addAll(testCollection(collection));
      }
      return result;
    }

    public Set testCollection(GestureContainer collection)
      throws InterruptedException
    {
      Set result = new HashSet();
      for (Iterator iter = collection.iterator(); iter.hasNext();) {
	GestureObject gestureObject = (GestureObject) iter.next();
	if (gestureObject instanceof GestureCategory) {
	  String name = ((GestureCategory) gestureObject).getName();
	  //System.out.println("Checking category " + name);
	  if (names.containsKey(name)) {
	    result.add
	      (new DuplicateNameNotice((GestureCategory) gestureObject,
				       (GestureCategory) names.get(name)));
	  }
	  else {
	    names.put(name, gestureObject);
	  }
	}
	else if (gestureObject instanceof GestureContainer) {
	  result.addAll(testCollection((GestureContainer) gestureObject));
	}
	if (Thread.currentThread().isInterrupted()) {
	  throw new InterruptedException();
	}
      }
      return result;
    }
  }

  public static class TrainingExampleTester implements TaskManager.NoticeTask {
    private MainFrame mainFrame;
    private List misrecogGestures = null;

    public TrainingExampleTester(MainFrame mf)
    {
      mainFrame = mf;
    }
    
    public Set computeNotices() throws InterruptedException
    {
      Set result = new HashSet();
      Classifier classifier = mainFrame.getClassifier();
      GesturePackage pkg = mainFrame.getGesturePackage();
      if ((classifier != null) && (pkg != null)) {
	GestureSet trainingSet = pkg.getTrainingSet();
	if (trainingSet != null) {
	  misrecogGestures = null;
	  try {
	    misrecogGestures = classifier.testRecognition(trainingSet);
	    if (misrecogGestures.size() > 0) {
	      result.add(new MisrecognitionNotice(mainFrame,
						  misrecogGestures));
	    }
	  }
	  catch (TrainingException e) {
	    return result;
	  }
	}
      }
      return result;
    }
  }

  public static class HumanSimilarityTester
    implements TaskManager.NoticeTask {
    /** this number was determined to be optimal by logistic
        regression, based on experimental data, and should not be
        changed. */
    private final double DIST_THRESHOLD = 0.3487;
    /** the square of the distance below which to issue a warning */
    private final double DISTANCE_SQ_THRESHOLD =
      DIST_THRESHOLD * DIST_THRESHOLD;
    private MainFrame mainFrame;

    public HumanSimilarityTester(MainFrame mf)
    {
      mainFrame = mf;
    }
    
    public Set computeNotices() throws InterruptedException
    {
      Set result = new HashSet();
      GesturePackage pkg = mainFrame.getGesturePackage();
      if (pkg != null) {
	GestureSet trainingSet = pkg.getTrainingSet();
	if (trainingSet != null) {
	  List trainingCategories = trainingSet.getEnabledCategories();
	  int numCats = trainingCategories.size();
	  for (int i = 0; i < numCats; i++) {
	    GestureCategory catA = (GestureCategory)
	      trainingCategories.get(i);
	    for (int j = 0; j < i; j++) {
	      GestureCategory catB = (GestureCategory)
		trainingCategories.get(j);
	      HumanCoords.DistanceInfo distInfo =
		HumanCoords.getDistanceInfo(catA, catB);
	      Class principleFeature = null;
	      int direction = 0;
	      if (distInfo.distanceSq <= DISTANCE_SQ_THRESHOLD) {
		principleFeature = distInfo.featureClass;
		direction = distInfo.direction;
	      }
	      else if (HumanSimilarity.areVerySimilar(catA, catB)) {
		// really LogAspect, but for the user, Aspect is better
		principleFeature = Aspect.class;
		double a = FeatureFactory.getFeatureValue(principleFeature,
							  catA);
		double b = FeatureFactory.getFeatureValue(principleFeature,
							  catB);
		direction = Misc.sign(a - b);
	      }
	      if (principleFeature != null) {
		// too close
		result.add(new HumanSimilarityNotice(mainFrame, catA, catB,
						     principleFeature,
						     direction));
	      }
	      if (Thread.interrupted()) {
		throw new InterruptedException();
	      }
	    }
	  }
	}
      }
      return result;
    }
  }

  /** Test all training examples in all categories to see if any are
      too far away from the centroid of their category.  Too far is
      determined by numSigmas. */
  public static class OutlyingGestureTester
    implements TaskManager.NoticeTask {
    /** The number of standard deviations (or sigmas) away from the
        mean that a gesture has to be to be consider an outlier.  It
        used to be 5, but that seemed to flag outliers too often. */
    public double numSigmas = 10.0;
    private MainFrame mainFrame;

    public OutlyingGestureTester(MainFrame mf)
    {
      mainFrame = mf;
    }
    
    public Set computeNotices() throws InterruptedException
    {
      Set result = new HashSet();
      GesturePackage pkg = mainFrame.getGesturePackage();
      Classifier classifier = mainFrame.getClassifier();
      if ((pkg != null) && (classifier != null)) {
	try {
	  classifier.train();
	}
	catch (TrainingException e) {
	  return result;
	}
	GestureSet trainingSet = pkg.getTrainingSet();
	List outlyingExamples = new ArrayList();
	if (trainingSet != null) {
	  List trainingCategories = trainingSet.getEnabledCategories();
	  int numCats = trainingCategories.size();
	  for (int catIndex = 0; catIndex < numCats; catIndex++) {
	    GestureCategory category = (GestureCategory)
	      trainingCategories.get(catIndex);
	    int numGestures = category.size();
	    for (int gIndex = 0; gIndex < numGestures; gIndex++) {
	      Gesture g = (Gesture) category.getChild(gIndex);
	      if (g.isEnabled()) {
		double stdev = computeStdev(classifier, category,
					    catIndex, gIndex);
		double dist =
		  Math.sqrt(classifier.distanceToCategory(g, catIndex));
		if (dist > (stdev * numSigmas)) {
		  outlyingExamples.add(g);
		}
	      }
	    }
	  }
	}
	if (outlyingExamples.size() > 0) {
	  result.add(new OutlyingGestureNotice(mainFrame,
					       outlyingExamples));
	}
      }
      return result;
    }

    /** Compute the standard deviation of distances of gestures in
        category catIndex from the category centroid, except that
        centroid computation omits gestureIndex.  catIndex is the
        index into the list of enabled categories that classifier
        maintains. gestureIndex is the raw index into the category
        (irrespective of what gestures are enabled). */
    protected double computeStdev(Classifier classifier,
				  GestureCategory category, int catIndex,
				  int gestureIndex)
    {
      // basic formula:
      //	      / n * sum(x^2) - sum(x)^2\
      // stdev = sqrt |------------------------|
      //	      \       n * (n-1)        /
      
      int numGestures = category.size();
      double sum = 0;
      double sumsq = 0; // sum of squares
      for (int i = 0; i < numGestures; i++) {
	if (i != gestureIndex) {
	  Gesture g = (Gesture) category.getChild(i);
	  if (g.isEnabled()) {
	    double distSq = classifier.distanceToCategory(g, catIndex);
	    sum += Math.sqrt(distSq);
	    sumsq += distSq;
	  }
	}
      }
      int n = numGestures-1; // since we're leaving one out
      double stdev = Math.sqrt((n * sumsq - sum*sum) / (n * (n-1)));
      return stdev;
    }
  }
}
