package edu.berkeley.guir.lib.gesture;

import java.util.*;
import java.io.*;

/**
 * An array of Features (Vector of FeatureVectors).  Stores the
 * Features corresponding to the Gestures in a GestureCategory.
 */
public class FeatureArray extends Observable
implements Serializable, Observer {
  private Vector featureVectors;
  private GestureCategory gestureCategory;
  private Class[] featureClasses;

  public FeatureArray()
  {
    super();
    featureClasses = FeatureVector.defaultFeatureClasses;
    featureVectors = new Vector();
  }

  public FeatureArray(GestureCategory gc)
  {
    super();
    try {
      init(gc, FeatureVector.defaultFeatureClasses);
    }
    catch (IllegalAccessException e) {
      System.err.println("FeatureArray: problem accessing default feature classes.  (This should never happen.)");
    }
    catch (InstantiationException e) {
      System.err.println("FeatureArray: problem instantiating default features.  (This should never happen.)");
    }
    gc.addObserver(this);
  }

  public FeatureArray(GestureCategory gc, Class[] featureClasses)
       throws IllegalAccessException, InstantiationException
  {
    super();
    init(gc, featureClasses);
  }

  private void init(GestureCategory gc, Class[] featureClasses)
       throws IllegalAccessException, InstantiationException
  {
    this.featureClasses = featureClasses;
    gestureCategory = gc;
    buildArray();
    gc.addObserver(this);
  }
  
  private void buildArray()
       throws IllegalAccessException, InstantiationException
  {
    /* todo
    if (gestureCategory != null) {
      featureVectors = new Vector();
      for (Enumeration e = gestureCategory.elements();
	   e.hasMoreElements(); ) {
	Gesture g = (Gesture) e.nextElement();
	FeatureVector fv = new FeatureVector(g, featureClasses);
	add(fv);
      }
    }
    */
  }
  
  public void add(FeatureVector fv)
  {
    featureVectors.addElement(fv);
    fv.addObserver(this);
    setChanged();
    notifyObservers(fv);
  }

  public FeatureVector elementAt(int i)
  {
    return (FeatureVector) featureVectors.elementAt(i);
  }

  public void removeElementAt(int i)
  {
    FeatureVector fv = elementAt(i);
    fv.deleteObserver(this);

    featureVectors.removeElementAt(i);
    setChanged();
    notifyObservers(fv);
  }

  public Feature getFeature(int vectorNum, int featureNum)
  {
    FeatureVector fv = elementAt(vectorNum);
    return fv.getFeatures()[featureNum];
  }
  
  public int size()
  {
    return featureVectors.size();
  }

  public Enumeration elements()
  {
    return featureVectors.elements();
  }

  public void update(Observable featureVector, Object arg)
  {
    try {
      buildArray();
    }
    catch (IllegalAccessException e) {
      System.err.println("FeatureArray.update: problem accessing default feature classes.  (This should never happen.)");
    }
    catch (InstantiationException e) {
      System.err.println("FeatureArray.update: problem instantiating default features.  (This should never happen.)");
    }
    setChanged();
    notifyObservers(featureVector);
  }

  public double maxFeatureValue(int featureNum)
  {
    double max = Double.NEGATIVE_INFINITY;

    if (size() > 0) {
      Feature dummy = getFeature(0, featureNum);
      if (dummy.getMaxValue() == Double.POSITIVE_INFINITY) {
	// look and see what the current max value is
	for (int exampleNum = 0;
	     exampleNum < size();
	     exampleNum++) {
	  Feature f = getFeature(exampleNum, featureNum);
	  double newVal = f.getValue();
	  if (newVal > max)
	    max = newVal;
	}
      }
      else
	max = dummy.getMaxValue();
    }
    return max;
  }

  public double minFeatureValue(int featureNum)
  {
    double min = Double.POSITIVE_INFINITY;

    if (size() > 0) {
      Feature dummy = getFeature(0, featureNum);
      if (dummy.getMinValue() == Double.NEGATIVE_INFINITY) {
	// look and see what the current min value is
	for (int exampleNum = 0;
	     exampleNum < size();
	     exampleNum++) {
	  Feature f = getFeature(exampleNum, featureNum);
	  double newVal = f.getValue();
	  if (newVal < min)
	    min = newVal;
	}
      }
      else
	min = dummy.getMinValue();
    }
    return min;
  }

  public double meanFeatureValue(int featureNum)
  {
    double mean = 0;

    if (size() > 0) {
      int numExamples = size();
      for (int exampleNum = 0;
	   exampleNum < numExamples;
	   exampleNum++) {
	Feature f = getFeature(exampleNum, featureNum);
	mean += f.getValue();
      }
      mean /= numExamples;
    }
    return mean;
  }

  public String featureName(int featureNum)
  {
    String result;
    
    if (size() > 0) {
      Feature dummy = getFeature(0, featureNum);
      result = dummy.getName();
    }
    else {
      result = null;
    }

    return result;
  }
}
