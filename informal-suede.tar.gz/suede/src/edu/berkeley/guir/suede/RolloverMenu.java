package edu.berkeley.guir.suede;

import javax.swing.*;
import java.awt.*;
//import java.awt.event.*;
import javax.swing.event.*;

public class RolloverMenu extends JMenu {
    private static final int SPACE = 16;
    
    private Color bg;
    private Color fg;
    private Color roll;
    
    public RolloverMenu(String s, Color b, Color f, Color r) {
        super(s);
        bg =b;   fg = f;  roll = r;
        setVisible(true);   setOpaque(true);
        setBackground(bg);  setForeground(fg);
        setFocusPainted(false);
        setContentAreaFilled(true);
        setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, fg));
        //addMouseListener(new RollListener());
		addMenuDragMouseListener(new RollListener());
    }
            
    public int setXHeight(int x, int h) {
        this.setBounds(x,0,getIdealWidth(), h);
        return x+getIdealWidth();
    }
    
    //public int getIdealHeight() { return getPreferredSize().height + SPACE; }
    public int getIdealWidth() { return getPreferredSize().width + SPACE;   }
            
//    private class RollListener implements MouseListener {
//        public void mouseClicked(MouseEvent e) {}
//        public void mouseExited(MouseEvent e)  { setBackground(bg); }
//        public void mouseEntered(MouseEvent e) { setBackground(roll); }
//        public void mousePressed(MouseEvent e) { setBackground(roll); }
//        public void mouseReleased(MouseEvent e){}
//    }
//HV Oct 1703
	private class RollListener implements MenuDragMouseListener {
		public void menuDragMouseDragged(MenuDragMouseEvent e){ setBackground(roll);}
		public void menuDragMouseEntered(MenuDragMouseEvent e){ setBackground(roll); }
		public void menuDragMouseExited(MenuDragMouseEvent e){ setBackground(bg);}
		public void menuDragMouseReleased(MenuDragMouseEvent e){}		
		}
}



