package edu.berkeley.guir.lib.gesture;

import edu.berkeley.guir.lib.gesture.util.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.border.Border;

/**
 * Displays distances between (the means of) each GestureCategory.
 */
public class DistanceMatrix extends JFrame implements Observer
{
  /**
   * distance[i][j] is the distance between the means of Categories
   * i and j.  It is symmetric.
   */
  Double[][] distance;
  double maxDistance = 0;
  Classifier classifier;
  GestureSet gestureSet;
  CTable table;
  double threshold;
  boolean markedOld = false;
  
  public DistanceMatrix(Classifier classifier)
  {
    super("Distance Matrix");
    this.classifier = classifier;
    gestureSet = classifier.getGestureSet();
    gestureSet.addObserver(this);
    computeDistances();
    buildUI();
  }

  public DistanceMatrix(GestureSet gs, Double[][] distance)
  {
    this(gs, distance, Double.MAX_VALUE);
  }
  
  public DistanceMatrix(GestureSet gs, Double[][] distance,
			double maxDistance)
  {
    super("Distance Matrix");
    this.classifier = null;
    gestureSet = gs;
    gestureSet.addObserver(this);
    this.distance = distance;
    threshold = maxDistance;
    this.maxDistance = maxDistance;
    buildUI();
  }

  private void computeDistances()
  {
    /* todo
    GestureSet gestureSet = classifier.getGestureSet();
    int numCategories = gestureSet.trainingSize();
    
    distance = new Double[numCategories][numCategories];
    
    for (int row = 0; row < numCategories; row++) {
      for (int column = row; column < numCategories; column++) {
	double dist = Math.sqrt(classifier.CategoryDistance(row, column));
	Double Dist = new Double(dist);
	distance[row][column] = Dist;
	distance[column][row] = Dist;
	if (dist > maxDistance)
	  maxDistance = dist;
      }
    }
    threshold = maxDistance;
    */
  }
  
  private void buildUI()
  {
    Container contents = getContentPane();
    contents.setLayout(new BorderLayout());

    // make table
    CTableModel dataModel = new AbstractCTableModel() {
      public int getColumnCount() { return distance.length; }
      public int getRowCount() { return distance[0].length; }
      public Object getValueAt(int r, int c)
      {
	return distance[r][c];
      }
      public Class getColumnClass(int c)
      {
	return Double.class;
      }
      public String getColumnName(int c)
      {
	return ((GestureContainer) gestureSet.getChild(c)).getName();
      }
      public String getRowName(int row)
      {
	return getColumnName(row);
      }
    };

    table = new CTable(dataModel);
    new ColorRenderer(table);
    table.setRowSelectionAllowed(false);
    table.setColumnSelectionAllowed(false);
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    if (classifier != null) {
      table.addMouseListener(new MyMouseListener());
    }
    table.addMouseMotionListener(new ToolTipUpdater(table));
    // this is a hack; really should figure out how big the column
    // needs to be and set it to that
    TableColumnModel tcm = table.getColumnModel();
    for (int i = 0; i < dataModel.getColumnCount(); i++) {
      TableColumn column = tcm.getColumn(i);
      column.setWidth(column.getWidth()/2);
    }
     
    JScrollPane scrollPane = new JScrollPane(table);

    contents.add(scrollPane, BorderLayout.CENTER);

    int max = (int) Math.ceil(maxDistance);
    final JSlider slider = new JSlider(JSlider.VERTICAL, 0,
				 max, max);
    slider.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e)
      {
	threshold = slider.getValue();
	table.repaint();
      }  
    });
    
    JPanel sliderPanel = new JPanel(new BorderLayout());
    sliderPanel.add(slider, BorderLayout.CENTER);
    sliderPanel.add(new JLabel("Threshold"), BorderLayout.NORTH);
    
    contents.add(sliderPanel, BorderLayout.EAST);

    // make menu bar
    JMenu menu;
    JMenuItem item;
    ActionListener listener;
    JMenuBar menuBar = new JMenuBar();

    menu = new JMenu("Table");
    item = new JMenuItem("Dump distances");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	int oldSigFigs = Matrix.sigFigs;
	Matrix.sigFigs = 3;
	Matrix.prettyPrint(distance);
	Matrix.sigFigs = oldSigFigs;
      }
    };
    item.addActionListener(listener);
    menu.add(item);
    item = new JMenuItem("Close");
    listener = new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
	DistanceMatrix.this.dispose();
      }
    };
    item.addActionListener(listener);
    menu.addSeparator(); // before close
    menu.add(item);
    // add more Graph items here
    menuBar.add(menu);

    getRootPane().setJMenuBar(menuBar);
  }

  class ColorRenderer implements TableCellRenderer
  {
    Border headerBorder = BorderFactory.createEtchedBorder();
    TableCellRenderer stringRenderer;
    TableCellRenderer objectRenderer;

    /**
     * Installs itself in table, too
     */
    ColorRenderer(JTable table)
    {
      stringRenderer = table.getDefaultRenderer(String.class);
      objectRenderer = table.getDefaultRenderer(Object.class);
      table.setDefaultRenderer(Double.class, this);
      table.setDefaultRenderer(String.class, this);
    }
    
    public Component getTableCellRendererComponent(JTable table,
						   Object value,
						   boolean isSelected,
						   boolean hasFocus,
						   int row,
						   int column)
    {
      // I don't know why value would be null, but I think sometimes
      // it is.
      if (value == null) {
	Component defaultComponent = objectRenderer.
	  getTableCellRendererComponent(table, value, isSelected, hasFocus,
					row, column);
	defaultComponent.setBackground(Color.white);
	return defaultComponent;
      }

      String valString;
      double x = 0;
      if (value instanceof String) {
	valString = (String) value;
      }
      else {
	x = ((Double) value).doubleValue();
	valString = Misc.toString(x, 2);
      }
      
      Component defaultComponent =
	stringRenderer.getTableCellRendererComponent(table,
						     valString,
						     isSelected, hasFocus,
						     row, column);
      if (column == row) {
	defaultComponent.setBackground(Color.yellow);
      }
      else if (x > threshold) {
	defaultComponent.setBackground(Color.darkGray);
      }       
      else {
	defaultComponent.setBackground(Color.white);
      }
      return defaultComponent;
    }
  }

  public void update(Observable o, Object arg)
  {
    if (!markedOld) {
      setTitle(getTitle() + " - OLD");
      markedOld = true;
    }
  }
       
  class MyMouseListener extends MouseAdapter
  {
    public void mousePressed(MouseEvent e)
    {
      Point p = e.getPoint();
      int row = table.rowAtPoint(p);
      int column = table.columnAtPoint(p);
      if ((column >= 0)) {
	FPGraphFrame fpgFrame = new
	  FPGraphFrame(classifier);
	BitSet categoryMask = new BitSet();
	categoryMask.set(row);
	categoryMask.set(column);
	fpgFrame.setCategoryMask(categoryMask);

	// set a reasonable initial size
	/*
	FeaturePointGraph fpg = fpgFrame.getGraph();
	fpg.setPreferredSize(new Dimension(400, 300));
	*/
	fpgFrame.pack();
	fpgFrame.show();
      }
    }
  }
}
