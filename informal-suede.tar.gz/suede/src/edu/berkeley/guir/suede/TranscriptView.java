package edu.berkeley.guir.suede;

public class TranscriptView extends AbstScriptView
{    
    
    TranscriptView() {
        super(null);
    }
    
    TranscriptView( int userID ) {
        super( "User " + userID );
    }
    
    
    // Move scrollbar to end so we can see newly added node
    public void addScriptNode( AbstScriptNodeModel s ) {
        super.addScriptNode( s );
        scrollToEnd( s, 0 );
    }
    
    /*private Vector m_transcriptcards = new Vector();
    
    public Vector getTranscriptCards() {
      return m_transcriptcards;
    }
    
    public void refresh() {
        m_transcriptcards = new Vector();
        numScriptNodes = 0;
    }
    
    // these two methods exist because of a naughty hack that puts nodes into the script area
    public void addScriptNode(SingleNodeModel s) {
      addScriptNode(s.getView());      
      m_transcriptcards.add(s.getView());
    }
    
    public void addScriptNode(LinkModel s) {
      addScriptNode(s.getView());
      m_transcriptcards.add(s.getView());
    }
    
    public void addScriptNode(JComponent s) {
        s.setLocation(numScriptNodes*ScriptNodeView.WIDTH,0);
        add(s);
        numScriptNodes++;    
        
        revalidate();
        getParent().repaint();        
    }
    
    
    public void deleteLastLinkNode(LinkModel slc) {
      remove(slc.getView());
      revalidate();
      m_transcriptcards.remove(slc.getView());
      numScriptNodes--;
      getParent().repaint();        
    }*/

}