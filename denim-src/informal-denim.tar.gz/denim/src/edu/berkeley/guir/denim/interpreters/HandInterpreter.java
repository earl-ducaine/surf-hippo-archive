package edu.berkeley.guir.denim.interpreters;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import java.awt.*;
import java.awt.geom.*;


/**
 * Pans the attached container.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-30-1999 JL
 *                    Created class HandInterpreter.
 * 			   1.0.1  12-16-2002 YL
 * 					  Added variable to check whether it's panning
 * </PRE>
 *
 * @see    edu.berkeley.guir.denim.toolbox.Hand
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 *
 * @since   JDK 1.2.2
 * @version Version 1.0.1, 12-16-2002
 */
public class HandInterpreter
   extends DefaultInterpreterImpl
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -7643165059746165900L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   private Point2D oldP;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Constructs a hand interpreter.
    */
   public HandInterpreter() {
      super();
      commonInitializations();
   }

   //-----------------------------------------------------------------

   /**
    * Constructs a hand interpreter where the previous absolute location of
    * the hand tool is the given point.
    */
   protected HandInterpreter(Point p) {
      oldP = p;
      commonInitializations();
   }

   //-----------------------------------------------------------------

   /**
    * Constructs a hand interpreter as a copy of the given interpreter.
    */
   public HandInterpreter(HandInterpreter intrp) {
      this();
      oldP = intrp.oldP;
   }

   //-----------------------------------------------------------------

   /**
    * Perform initializations common to all constructors.
    */
   private void commonInitializations() {
      setName("Denim Hand Interpreter");
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   /**
    * Called when the user first taps with the hand tool. Keep track of where
    * the hand tool is.
    */
   public void handleNewStroke(NewStrokeEvent evt) {
      oldP = evt.getStroke().getStartPoint2D(COORD_ABS);
      evt.setConsumed();
      this.getAttachedGraphicalObject().getSheet().setSheetPanning(true);
   }

   //-----------------------------------------------------------------

   /**
    * Pan the canvas as the user drags the hand tool.
    */
   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      GraphicalObjectGroup sheet = (GraphicalObjectGroup) getAttachedGraphicalObject().getSheet();
      TimedStroke stk = evt.getStroke();
      Point2D p = stk.getEndPoint2D(COORD_ABS);

      AffineTransform tx = new AffineTransform();
      tx.translate(p.getX() - oldP.getX(), p.getY() - oldP.getY());
      sheet.applyTransform(tx);
      
      ((DenimSheet)sheet).setModified(true);

      oldP = p;
      evt.setConsumed();
   }

   //-----------------------------------------------------------------

   /**
    * Finish panning.
    */
   public void handleSingleStroke(SingleStrokeEvent evt) {
      //// 1. Force a final, higher quality image rendering.
      this.getAttachedGraphicalObject().getSheet().setSheetPanning(false);
      ((DenimSheet)this.getAttachedGraphicalObject().getSheet()).readjustArrows();
   }

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      return (new HandInterpreter(this));
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
