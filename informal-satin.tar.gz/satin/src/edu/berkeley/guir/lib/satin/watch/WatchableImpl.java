//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.watch;

import edu.berkeley.guir.lib.collection.*;
import java.util.*;

/**
 * This is a sample implementation of Watchable. It is designed to be used as a
 * delegate class. That is, if you want to implement the Watchable interface 
 * but don't want to implement the methods, you can have a WatchableImpl object
 * contained within and just delegate the Watchable methods to this object.
 *
 * <P>
 * This class is intended to be a delegate, and is not really intended to 
 * be subclassed. Calling any of the normal notify methods causes
 * RuntimeExceptions to be thrown, just to let you know you shouldn't be using
 * this class this way.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Mar 08 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class WatchableImpl
   implements Watchable {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 4604130210793179861L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   STRATEGY INNER CLASSES   ============================================

   /**
    * These classes implement the Strategy pattern. Basically, this lets us
    * abstract out which method is actually called. It's similar to a pointer
    * to a function. Much safer, much easier to extend.
    */
   static abstract class NotifyStrategy {
      public abstract void runNotify(Watcher watcher);
   } // of inner class NotifyStrategy

   //===========================================================================

   final class NotifyGenericStrategy
      extends NotifyStrategy {

      Watchable w;
      Object    arg;

      //------------------------------------------------------------------

      public NotifyGenericStrategy(Watchable w, Object arg) {
         this.w   = w;
         this.arg = arg;
      } // of constructor

      //------------------------------------------------------------------

      public void runNotify(Watcher watcher) {
         watcher.onNotify(w, arg);
      } // of runNotify

   } // of inner class NotifyGenericStrategy

   //===========================================================================

   final class NotifyUpdateSingleStrategy
      extends NotifyStrategy {

      Watchable w;
      Object    arg;

      //------------------------------------------------------------------

      public NotifyUpdateSingleStrategy(Watchable w, Object arg) {
         this.w   = w;
         this.arg = arg;
      } // of constructor

      //------------------------------------------------------------------

      public void runNotify(Watcher watcher) {
         watcher.onUpdate(w, arg);
      } // of runNotify

   } // of inner class NotifyUpdateSingleStrategy

   //===========================================================================

   final class NotifyUpdateMultiStrategy
      extends NotifyStrategy {

      Watchable w;
      String    strProperty;
      Object    oldVal;
      Object    newVal;

      //------------------------------------------------------------------

      public NotifyUpdateMultiStrategy(Watchable w, String strProperty,
            Object oldVal, Object newVal) {
         this.w           = w;
         this.strProperty = strProperty;
         this.oldVal      = oldVal;
         this.newVal      = newVal;
      } // of NotifyUpdateMultiStrategy
      
      //------------------------------------------------------------------

      public void runNotify(Watcher watcher) {
         //// 1. No update notifications if same value.
         if ((oldVal == newVal) || (oldVal.equals(newVal))) {
            return;
         }

         //// 2. Notify update.
         watcher.onUpdate(w, strProperty, oldVal, newVal);
      } // of runNotify

      //------------------------------------------------------------------

   } // of inner class NotifyUpdateMultiStrategy

   //===========================================================================

   final class NotifyDeleteStrategy
      extends NotifyStrategy {

      Watchable w;

      //------------------------------------------------------------------

      public NotifyDeleteStrategy(Watchable w) {
         this.w = w;
      } // of constructor

      //------------------------------------------------------------------

      public void runNotify(Watcher watcher) {
         watcher.onDelete(w);
      } // of runNotify

   } // of inner class NotifyDeleteStrategy

   //===   STRATEGY INNER CLASSES   ============================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   //// Set of objects we notify.
   //// Must be a weak reference set in order to allow potential garbage 
   ////    collection of the watchers, ie if no one else is pointing to them
   ////    except for us.
   WeakHashSet   watchers     = new WeakHashSet();

   //// if == 0, then enabled. if > 0, disabled.
   transient int enabledCount = 0; 

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   LISTENER METHODS   ==================================================

   public Watcher addWatcher(Watcher w) {
      watchers.add(w);
      return (w);
   } // of addWatcher

   //-----------------------------------------------------------------

   public int countWatchers() {
      return(watchers.size());
   } // of countWatchers

   //-----------------------------------------------------------------

   public Watcher removeWatcher(Watcher w) {
      watchers.remove(w);
      return (w);
   } // of removeWatcher

   //-----------------------------------------------------------------

   public void clearWatchers() {
      watchers.clear();
   } // of clearWatchers

   //===   LISTENER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   GENERIC NOTIFICATION METHODS   ======================================

   public void disableNotify() {
      enabledCount++;
   } // of disableNotify

   //-----------------------------------------------------------------

   public void enableNotify() {
      enabledCount--;
      if (enabledCount < 0) {
         throw new RuntimeException(
            "Error - unbalanced number of disable/enable notify calls made");
      }
   } // of enableNotify

   //-----------------------------------------------------------------

   public boolean hasNotifyEnabled() {
      return (enabledCount <= 0);
   } // of hasNotifyEnabled

   //-----------------------------------------------------------------

   /**
    * This is a generic method for doing notifications. Just pass it a
    * NotifyStrategy object, which contains the notification to run, and 
    * just let the NotifyStrategy call the correct notification on all of 
    * the Watchers.
    * <P>
    * Note that we simply use an iterator over the set of watchers. This means
    * that you should not delete any of the watchers on the callback.
    * Otherwise, you will get an iteration ConcurrentModification exception.
    * If this is the case, use notifyModify() instead.
    */
   private void notify(NotifyStrategy strategy) {
      //// 0. Check if enabled. If not, exit.
      if (hasNotifyEnabled() == false) {
         return;
      }

      //// 1. Initializations. 
      Iterator  it = watchers.iterator();
      Watcher   w;

      while (it.hasNext()) {
         w = (Watcher) it.next();
         strategy.runNotify(w);
      } 
   } // of notifyWatchers

   //-----------------------------------------------------------------

   /**
    * A generic method for doing notifications. Unlike notify() above,
    * notifyModify is safe for doing modifications on the watchers set during
    * notification. For example, deleting causes the watchers set to be changed
    * during iteration, causing a ConcurrentModification exception. We overcome
    * this by simply cloning the watchers set and iterating over that.
    * <P>
    * Note that this is relatively expensive, since we have to clone. Use this
    * sparingly.
    */
   private void notifyModify(NotifyStrategy strategy) {
      //// 0. Check if enabled. If not, exit.
      if (hasNotifyEnabled() == false) {
         return;
      }

      //// 1. Initializations. Shallow cloning the list of notifications is 
      ////    necessary. Otherwise, when deleting, will delete the current
      ////    Watcher off of the list, causing every-other notification error.
      WeakHashSet hashTmp = (WeakHashSet) watchers.clone();
      Iterator    it      = hashTmp.iterator();
      Watcher     w;

      while (it.hasNext()) {
         w = (Watcher) it.next();
         strategy.runNotify(w);
      } 
   } // of notifyModify

   //===   GENERIC NOTIFICATION METHODS   ======================================
   //===========================================================================



   //===========================================================================
   //===   NOTIFY   ============================================================

   /**
    * Throws an exception. This method should not be called. Use one of the
    * other notifyWatchers() methods, specifying the object using this
    * implementation as the Watchable.
    */
   public void notifyWatchers() {
      throw new RuntimeException("Call one of the other notifyWatchers() methods instead");
   } // of notifyWatchers

   //-----------------------------------------------------------------

   /**
    * Throws an exception. This method should not be called. Use one of the
    * other notifyWatchers() methods, specifying the object using this
    * implementation as the Watchable.
    */
   public void notifyWatchers(Object arg) {
      throw new RuntimeException("Call one of the other notifyWatchers() methods instead");
   } // of notifyWatchers

   //-----------------------------------------------------------------

   public void notifyWatchers(Watchable watchable) {
      notifyWatchers(watchable, null);
   } // of notifyWatchers

   //-----------------------------------------------------------------

   /**
    * This is a convenience method if this class is used in a delegation
    * fashion. This lets you set who the Watchable object really is.
    *
    * @see   Watchable#notifyWatchers()
    * @param watchable is the Watchable object that will be passed to 
    *        the Watcher on the callback.
    * @param arg is the generic argument.
    */
   public void notifyWatchers(Watchable watchable, Object arg) {
      notify(new NotifyGenericStrategy(watchable, arg));
   } // of notifyWatchers

   //===   NOTIFY   ============================================================
   //===========================================================================



   //===========================================================================
   //===   NOTIFY UPDATE   =====================================================

   /**
    * Throws an exception. This method should not be called. Use one of the
    * other notifyWatchers() methods, specifying the object using this
    * implementation as the Watchable.
    */
   public void notifyWatchersUpdate(Object arg) {
      throw new RuntimeException("Call one of the other notifyWatchersUpdate() methods instead");
   } // of notifyWatchersUpdate

   //-----------------------------------------------------------------

   /**
    * Throws an exception. This method should not be called. Use one of the
    * other notifyWatchers() methods, specifying the object using this
    * implementation as the Watchable.
    */
   public void notifyWatchersUpdate(String strProperty, 
         Object oldVal, Object newVal) {
      throw new RuntimeException("Call one of the other notifyWatchersUpdate() methods instead");
   } // of notifyWatchersUpdate

   //-----------------------------------------------------------------

   /**
    * This is a convenience method if this class is used in a delegation
    * fashion. This lets you set who the Watchable object really is.
    * Sends a null argument.
    *
    * @see   Watchable#notifyWatchersUpdate(Object)
    * @param watchable is the Watchable object that will be passed to 
    *        the Watcher on the callback.
    */
   public void notifyWatchersUpdate(Watchable watchable) {
      notify(new NotifyUpdateSingleStrategy(watchable, null));
   } // of notifyWatchersUpdate

   //-----------------------------------------------------------------

   /**
    * This is a convenience method if this class is used in a delegation
    * fashion. This lets you set who the Watchable object really is.
    * 
    * @param watchable is the Watchable object that will be passed to 
    *        the Watcher on the callback.
    * @param arg is the argument to send.
    */
   public void notifyWatchersUpdate(Watchable watchable, Object arg) {
      notify(new NotifyUpdateSingleStrategy(watchable, arg));
   } // of notifyWatchersUpdate

   //-----------------------------------------------------------------

   /**
    * This is a convenience method if this class is used in a delegation
    * fashion. This lets you set who the Watchable object really is.
    *
    * @see   Watchable#notifyWatchersUpdate(String, Object, Object)
    * @param watchable   is the Watchable object that will be passed to 
    *                    the Watcher on the callback.
    * @param strProperty is the agreed-upon name of the property.
    * @param oldVal      is the old value of the property.
    * @param newVal      is the new value of the property.
    */
   public void notifyWatchersUpdate(Watchable watchable, String strProperty,
         Object oldVal, Object newVal) {
      notify(new NotifyUpdateMultiStrategy(watchable, strProperty, oldVal, newVal));
   } // of notifyWatchersUpdate

   //===   NOTIFY UPDATE   =====================================================
   //===========================================================================



   //===========================================================================
   //===   DELETE   ============================================================

   /**
    * Throws an exception. This method should not be called. Use one of the
    * other notifyWatchers() methods, specifying the object using this
    * implementation as the Watchable.
    */
   public void notifyWatchersDelete() {
      throw new RuntimeException("Call the other notifyWatchersDelete() method instead");
   } // of notifyWatchersUpdate

   //-----------------------------------------------------------------

   /**
    * This is a convenience method if this class is used in a delegation
    * fashion. This lets you set who the Watchable object really is.
    *
    * @see   Watchable#notifyWatchersDelete()
    * @param watchable is the Watchable object that will be passed to 
    *        the Watcher on the callback.
    */
   public void notifyWatchersDelete(Watchable watchable) {
      notifyModify(new NotifyDeleteStrategy(watchable));
   } // of notifyWatchersDelete

   //===   DELETE   ============================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      StringBuffer strbuf = new StringBuffer();
      Object       obj;

      Iterator it = watchers.iterator();
      while (it.hasNext()) {
         obj = it.next();
         strbuf.append(obj.hashCode());
         strbuf.append(", ");
      }

      return (strbuf.toString());
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE METHODS   =====================================================

   public Object clone() {
      WatchableImpl w = new WatchableImpl();
      w.watchers = (WeakHashSet) this.watchers.clone();
      return (w);
   } // of clone

   //===   CLONE METHODS   =====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/

