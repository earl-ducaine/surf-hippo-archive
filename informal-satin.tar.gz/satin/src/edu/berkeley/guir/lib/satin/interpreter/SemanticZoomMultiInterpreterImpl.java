//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter;

import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.event.*;

/**
 * Selects among several interpreters, and wraps each interpreter so that it
 * is active only between programmer-specified zoom levels.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 30 1999, MN
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3RC1
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class SemanticZoomMultiInterpreterImpl
   extends DefaultMultiInterpreterImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

           static final long  serialVersionUID = -2702309482530574358L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INNER CLASSES   =====================================================

   /**
    * Optimized version of wrapper.
    */
   class Wrapper extends SemanticZoomInterpreterWrapper {

      public Wrapper(Interpreter intrp) {
         super(intrp);
      } // of constructor

      /**
       * Just calculate the scale once and use it for all interpreters
       * contained by this MultiInterpreter.
       */
      protected double getAbsoluteScaleFactor() {
         return (curscale);
      } // of method
   } // of inner class

   //===   INNER CLASSES   =====================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   double curscale;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Default constructor, does nothing.
    */
   public SemanticZoomMultiInterpreterImpl() {
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   public Interpreter add(Interpreter intrp) {
      return (super.add(new Wrapper(intrp)));
   } // of method

   //-----------------------------------------------------------------

   public Interpreter remove(Interpreter intrp) {
      return (super.remove(new Wrapper(intrp)));
   } // of method

   //-----------------------------------------------------------------

   public void clearInterpreters() {
      super.clear();
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   STROKE METHODS   ====================================================

   public void handleNewStroke(NewStrokeEvent evt) {
      //// 1. Calculate the scale once and reuse it.
      curscale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                getAttachedGraphicalObject());

      //// 2. Let the default MultiInterpreter handle it.
      super.handleNewStroke(evt);
   } // of method

   //-----------------------------------------------------------------

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      //// 1. Calculate the scale once and reuse it.
      curscale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                getAttachedGraphicalObject());

      //// 2. Let the default MultiInterpreter handle it.
      super.handleUpdateStroke(evt);
   } // of method

   //-----------------------------------------------------------------

   public void handleSingleStroke(SingleStrokeEvent evt) {
      //// 1. Calculate the scale once and reuse it.
      curscale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                                                getAttachedGraphicalObject());

      //// 2. Let the default MultiInterpreter handle it.
      super.handleSingleStroke(evt);
   } // of method

   //===   STROKE METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new SemanticZoomMultiInterpreterImpl()));
   } // of method

   //-----------------------------------------------------------------

   protected SemanticZoomMultiInterpreterImpl 
   clone(SemanticZoomMultiInterpreterImpl im) {
      //// 1. Clone chain.
      super.clone(im);

      //// 2. Do clone work.
      im.curscale = this.curscale;

      //// 3. Return.
      return (im);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
