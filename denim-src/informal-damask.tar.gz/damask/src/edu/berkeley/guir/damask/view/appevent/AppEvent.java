package edu.berkeley.guir.damask.view.appevent;

import java.util.EventObject;

import edu.berkeley.guir.damask.view.DamaskApp;

/** 
 * An event that indicates that the canvas has been changed.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-11-2004 James Lin
 *                               Created CanvasEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-11-2004
 */
public class AppEvent extends EventObject {

   private final Type eventType;   
   
   //---------------------------------------------------------------------------

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   

   public static final Type CURRENT_FRAME_CHANGED = new Type("current frame changed");

   //---------------------------------------------------------------------------

   /**
    * Constructs a AppEvent.
    */
   public AppEvent(final DamaskApp source, final Type eventType) {
      super(source);
      this.eventType = eventType;
   }
   

   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
}
