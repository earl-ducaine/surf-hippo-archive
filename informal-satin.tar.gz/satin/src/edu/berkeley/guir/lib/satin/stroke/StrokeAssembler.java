//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.stroke;

import java.io.Serializable;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.SwingUtilities;
import java.util.*;
import edu.berkeley.guir.lib.awt.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.watch.*;
 
/**
 * Accumulates mouse events and creates Stroke objects. 
 * Through an ingenious hack [tm], this StrokeAssembler is always the last
 * MouseListener to receive an event. Furthermore, it ignores consumed events
 * (ie {@link AWTEvent#consume()}). So, if you get mouse events and don't
 * want others to use the event, then just consume it.
 *
 * <P>
 * There should only be one instance of this class per Sheet.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Oct 09 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.0.1, Oct 30 2000, JH
 *               Fixed some problems with auto-pan
 *               Fixed a bug with bounds (auto-pan at wrong places)
 *               Modified auto-pan to work only if pen moved outside sheet bds
 * 			   - SATIN-v2.1-2.0.0, Nov 21 2002, YL
 * 				 Enabled event dispatching cache
 *             - SATIN-v2.1-2.0.0, Jan 27 2003, YL
 *               Fixed the bugs of multi-button-type which could accidently trigger strange behaviros
 *             - SATIN-v2.1-2.0.0, Feb 27 2003, YL
 *               Added methods to access TimedCurvyStroke's smooth degree
 *             - SATIN-v2.1-2.0.0, March 12 2003, YL
 *               Lock mouse pressed to keep the completeness of a stroke
 *             - SATIN-v2.1-2.0.0, April 2 2003, YL
 *               Added RIGHT_TOLERANCE to autoscroll to fix the bug of auto-pan 
 *               when there is no space at the right edge of sheet.
 * 				 
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version SATIN-v2.1-2.0.0, April 2, 2003
 */

public class StrokeAssembler
	implements SatinConstants,
				  Serializable, 
				  Cloneable, 
				  MouseListener, 
				  MouseMotionListener,
				  Watcher {
            	
	//===========================================================================
	//===   CONSTANTS   =========================================================

	private final static int TOP             = 20;
	private final static int BOTTOM          = 21;
	private final static int LEFT            = 22;
	private final static int RIGHT           = 23;
	private final static int TOP_RIGHT       = 24;
	private final static int TOP_LEFT        = 25;
	private final static int BOTTOM_RIGHT    = 26;
	private final static int BOTTOM_LEFT     = 27;
	private final static int RIGHT_TOLERANCE = 3;

	//-----------------------------------------------------------------

	private final static int DEFAULT_SCROLL_THRESH_X = 30;
	private final static int DEFAULT_SCROLL_THRESH_Y = 30;

	/** Number of msec to wait between scrolls. */
	private final static int DEFAULT_SCROLL_DELAY       = 10;

	/** Multiplier for DEFAULT_SCROLL_DELAY to wait before first scroll. */
	private final static int DEFAULT_INITIAL_SCROLL_DELAY_COUNT = 20;
   
	// If there are two MouseRelease events within the following number of
	// milliseconds, the second MouseRelease is ignored.
	private final static long DEFAULT_MIN_TIME_BETWEEN_RELEASE = 85;
   
	private long startTime = 0;
	private StringBuffer intervalBuf = new StringBuffer(1000);

	//===   CONSTANTS   =========================================================
	//===========================================================================



	//===========================================================================
	//===   NONLOCAL VARIABLES   ================================================

	// are we scrolling or not?
	private boolean                flagScrolling;      
   
	// should we create strokes?
	private boolean                flagEnabled;
   
	// original mouse position
	private int                    oldX;
	private int                    oldY;               

	// avoid mutltiple button types for a single event
	private int                    oldButtonType;
	private boolean                isLocked = false;
   
	 // current stroke we are drawing
	private TimedCurvyStroke       currentCurvyStroke;
	private TimedStroke            currentStroke;
   
	// sheet the StrokeAssembler is in
	private Sheet                  parent;
   
	// by default accepts all mouse events
	private BasicStrokeEventFilter filter;             
   
	// the last time the mouse button was released
	private long                   lastReleaseTime = 0;

	// should we render strokes using TimedCurvyStroke (as opposed to
	// TimedStroke)?
	private boolean                flagRenderCurvy = true;

	// to control the smooth degree 
	private float angleTolerance = 70;
	private int   windowSize = 5;
	private float cornerDegree = 70;   
   
	// buffer for cached dispatching
	Vector dispatchingPath = new Vector();
   
	//-----------------------------------------------------------------

	//// Soft-state optimization variables
	AffineTransform parentTx;        // the parent's transform
	AffineTransform inverseTx;       // cached inverse of the transform above

	//-----------------------------------------------------------------

	//// Flags for scrolling
	boolean flagAutoScrollingEnabled = true;  // allow auto-scrolling or not?
	boolean flagUseDefaultScrollThreshX;      // can scroll on X on this stroke
	boolean flagUseDefaultScrollThreshY;      // can scroll on Y on this stroke


	//// Other variables for scrolling
	int             delayCount     = 0;
	Rectangle       rect           = new Rectangle();
	AffineTransform scrollTx       = new AffineTransform();
	int             scrollThreshX  = 0;
	int             scrollThreshY  = 0;
	MouseEvent      repeatEvent;
	MouseEvent      ignoreEvent;
	EventQueue      queue = Toolkit.getDefaultToolkit().getSystemEventQueue();

	//===   NONLOCAL VARIABLES   ================================================
	//===========================================================================



	//===========================================================================
	//===   CONSTRUCTORS   ======================================================

	/**
	 * Constructor. Automatically makes ourself a mouse Interpreter and mouse
	 * motion Interpreter for the parent.
	 *
	 * @param parent is the Sheet component that holds this object.
	 */
	public StrokeAssembler(Sheet parent) {
		//// 1. Set the parent.
		this.parent      = parent;
		this.flagEnabled = true;

		//// 2. Setup ourselves as a MouseListener and MouseMotionListener
		parent.addMouseListener(this);
		parent.addMouseMotionListener(this);

		//// 3. Add ourself as a watcher, so we can get updates when
		////    the transform changes.
		parent.addWatcher(this);

		//// 4. Other initializations.
		parentTx  = new AffineTransform();
		inverseTx = new AffineTransform();
		filter    = new BasicStrokeEventFilter();
      
	} // of default constructor

	//===   CONSTRUCTORS   ======================================================
	//===========================================================================



	//===========================================================================
	//===   ENABLED METHODS   ===================================================

	/**
	 * Set whether we should be creating strokes or not.
	 */
	public void setEnabled(boolean flag) {
		flagEnabled = flag;
	} // of setEnabled


	/**
	 * Check whether we are creating strokes or not.
	 */
	public boolean isEnabled() {
		return (flagEnabled);
	} // of isEnabled

	//-----------------------------------------------------------------

	public boolean isLeftButtonAccepted() {
		return (filter.isLeftButtonAccepted());
	} // of isLeftButtonAccepted


	public boolean isMiddleButtonAccepted() {
		return (filter.isMiddleButtonAccepted());
	} // of isMiddleButtonAccepted


	public boolean isRightButtonAccepted() {
		return (filter.isRightButtonAccepted());
	} // of isRightButtonAccepted

	//-----------------------------------------------------------------

	public void setAcceptLeftButton(boolean flag) {
		filter.setAcceptLeftButton(flag);
	} // of setAcceptLeftButton


	public void setAcceptMiddleButton(boolean flag) {
		filter.setAcceptMiddleButton(flag);
	} // of setAcceptMiddleButton


	public void setAcceptRightButton(boolean flag) {
		filter.setAcceptRightButton(flag);
	} // of setAcceptRightButton

	//-----------------------------------------------------------------

	/**
	 * Set whether auto scroll when drawing is enabled or not.
	 */
	public void setAutoScroll(boolean flag) {
		flagAutoScrollingEnabled = flag;
	} // of setAutoScroll

	//===   ENABLED METHODS   ===================================================
	//===========================================================================



	//===========================================================================
	//===   RENDERING SETTINGS METHODS  =========================================
   
	/**
	 * Return true if strokes are drawn using TimedCurvyStroke (as opposed to
	 * TimedStroke).
	 */
	public boolean getRenderCurvy() {
		return flagRenderCurvy;
	}

	//-----------------------------------------------------------------
   
	/**
	 * Sets whether strokes are drawn using TimedCurvyStroke or TimedStroke.
	 * 
	 * @param flag true if strokes are to be drawn using TimedCurvyStroke
	 */
	public void setRenderCurvy(boolean flag) {
		flagRenderCurvy = flag;
	}
   
	//===   RENDERING SETTINGS METHODS  =========================================
	//===========================================================================

	//===========================================================================
	//===   PARENTAL METHODS  ===================================================

	private AffineTransform getInverseTransform() {
		if (parentTx.equals(parent.getTransformRef()) == false) {
			parentTx  = parent.getTransform(COORD_REL);
			inverseTx = parent.getInverseTransform(COORD_REL);
		}
		return (inverseTx);
	} // of getInverseTransform

	//===   PARENTAL METHODS  ===================================================
	//===========================================================================



	//===========================================================================
	//===   SCROLLING METHODS   =================================================

	/**
	 * Scrolling initialization info.
	 */
	private void initScroll(TimedStroke stk) {
		//// 1. Update our copy of our parent Sheet's bounds.
		parent.getBounds(rect);
		int     dTop      = oldY - rect.y;
		int     dBottom   = rect.y + rect.height - oldY;
		int     dLeft     = oldX - rect.x;
		int     dRight    = rect.x + rect.width - oldX;

		//// 2. If we start far enough away, scrolling is enabled.
		if (dLeft  < DEFAULT_SCROLL_THRESH_X || 
			 dRight < DEFAULT_SCROLL_THRESH_X) {
			flagUseDefaultScrollThreshX = false;
		} 
		else {
			flagUseDefaultScrollThreshX = true;
		}
   
		if (dTop    < DEFAULT_SCROLL_THRESH_Y || 
			 dBottom < DEFAULT_SCROLL_THRESH_Y) {
			flagUseDefaultScrollThreshY = false;
		}
		else {
			flagUseDefaultScrollThreshY = true;
		}
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Check whether we should scroll or not.
	 * Not implemented yet.
	 */
	private boolean shouldScroll(TimedStroke stk) {
		return (false);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Get the direction and magnitude of scroll we should do.
	 * Not implemented yet.
	 */
	private void getScrollDirection(TimedStroke stk) {
	} // of method

	//===   SCROLLING METHODS   =================================================
	//===========================================================================



	//===========================================================================
	//===   MOUSE METHODS   =====================================================

	/**
	 * Calculate the distance squared between two mouse events.
	 */
	private float distSquared(MouseEvent evtAA, MouseEvent evtBB) {
		if (evtAA == null || evtBB == null) {
			return (0);
		}

		float dx = evtAA.getX() - evtBB.getX();
		float dy = evtAA.getY() - evtBB.getY();
		return (dx*dx + dy*dy);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * See if we should accept this mouse event as part of a stroke.
	 */
	private final boolean acceptMouseEvent(MouseEvent evt) {
		//// 0. Check if consumed. If so, abort.
		if (evt.isConsumed() == true) {
			return (false);
		}

		//// 1. Check left mouse button.
		if (filter.isLeftButtonAccepted() == true && 
			 SwingUtilities.isLeftMouseButton(evt)) {
			return (true);
		}

		//// 2. Check middle mouse button.
		if (filter.isMiddleButtonAccepted() == true && 
			 SwingUtilities.isMiddleMouseButton(evt)) {
			return (true);
		}

		//// 3. Check right mouse button.
		if (filter.isRightButtonAccepted() == true && 
			 SwingUtilities.isRightMouseButton(evt)) {
			return (true);
		}
      
		if (//System.getProperty("os.name").equals("Mac OS X") &&
			 filter.isRightButtonAccepted() &&
			 //SwingUtilities.isLeftMouseButton(evt) &&
			 evt.isControlDown()) {
			return (true);
		}

		return (false);
	} // of acceptMouseEvent

	//-----------------------------------------------------------------

	/**
	 * Set what buttons activated the creation of a stroke.
	 */
	private void setButtonInStroke(TimedStroke stk, MouseEvent evt) {
/*		//// 1. If we are running on Mac OS X, then...
		if (System.getProperty("os.name").equals("Mac OS X")) {
			//// 1.1. Check Ctrl+mouse button--same as right mouse button
			if (filter.isRightButtonAccepted() &&
				 SwingUtilities.isLeftMouseButton(evt) &&
				 evt.isControlDown()) {
				stk.setRightButton(true);
			}
			//// 1.2. Check for mouse button--same as left mouse button
			else if (filter.isLeftButtonAccepted() && 
						SwingUtilities.isLeftMouseButton(evt)) {
				stk.setLeftButton(true);
			}
		}
		else {
*/
            if (//filter.isRightButtonAccepted() &&
                    // SwingUtilities.isLeftMouseButton(evt) &&
                 evt.isControlDown()) 
            {
                if(filter.isRightButtonAccepted())
                    stk.setRightButton(true);
            }
            else
            {
    
                //// 2.1. Check left mouse button.
    			if (filter.isLeftButtonAccepted() == true && 
    				 SwingUtilities.isLeftMouseButton(evt)) {
    				stk.setLeftButton(true);
    			}
    
    			//// 2.2. Check middle mouse button.
    			if (filter.isMiddleButtonAccepted() == true && 
    				 SwingUtilities.isMiddleMouseButton(evt)) {
    				stk.setMiddleButton(true);
    			}
    
    			//// 2.3. Check right mouse button.
    			if (filter.isRightButtonAccepted() == true && 
    				 SwingUtilities.isRightMouseButton(evt)) {
    				stk.setRightButton(true);
    			}
            }
	} // of setButtonInStroke

	//-----------------------------------------------------------------

	public final void mouseClicked(MouseEvent evt) { } // of mouseClicked
	public final void mouseEntered(MouseEvent evt) { } // of mouseEntered
	public final void mouseExited(MouseEvent evt)  { } // of mouseExited
   
	//-----------------------------------------------------------------
      
	public final void mouseMoved(MouseEvent evt)   {
      
		if(this.isLocked&&System.getProperty("os.name").equals("Mac OS X"))
		{
			this.fickMouseDragged(evt);
		}
      
	} // of mouseMoved

	//-----------------------------------------------------------------
   

	/**
	 * Handle mouse button first pressed. Creates a new Stroke object with
	 * initial position at start position.
	 */
	public final void mousePressed(MouseEvent evt) {
      
		parent.setRenderToScreen(true);
      
		if(isLocked)
		{
			//mouseDragged(evt);
			//return;
			MouseEvent releaseEvt = 
				new MouseEvent((Component)evt.getSource(), MouseEvent.MOUSE_RELEASED,
					evt.getWhen(), evt.getModifiers(), evt.getX(), evt.getY(),
					evt.getClickCount(), evt.isPopupTrigger(), oldButtonType);

			mouseReleased(releaseEvt);
			isLocked = false;
		}
      
		//// 0.1. Enabled check.
		if (isEnabled() == false) {
			return;
		}

		//// 0.2. Do we accept this mouse button?
		if (acceptMouseEvent(evt) == false) {
			return;
		}

		//// 1. Create a new Stroke.
		flagScrolling = false;
		if (flagRenderCurvy) {
			 currentCurvyStroke = new TimedCurvyStroke();
			 currentCurvyStroke.setThreshhold(angleTolerance);
			 currentCurvyStroke.setFilterSize(windowSize);
			 currentCurvyStroke.setCornerThreshhold(cornerDegree);
		}
		else {
			 currentStroke = new TimedStroke();
		}

		//// 2. Apply the transform of the Sheet to the point before adding it.
		oldX = evt.getX();
		oldY = evt.getY();
		EventUtil.applyTransform(evt, getInverseTransform());
		if (flagRenderCurvy) {
			 currentCurvyStroke.addPoint(evt.getX(), evt.getY());
		}
		else {
			 currentStroke.addPoint(evt.getX(), evt.getY());
		}

		//// 3. Set what buttons are activated in the stroke.
		if (flagRenderCurvy) {
			 setButtonInStroke(currentCurvyStroke, evt);
		}
		else {
			 setButtonInStroke(currentStroke, evt);
		}
      	

		//// 4. Dispatch the Stroke to the parent.
		NewStrokeEvent stkevt;
		if (flagRenderCurvy) {
			 stkevt = new NewStrokeEvent(parent, currentCurvyStroke);
		}
		else {
			 stkevt = new NewStrokeEvent(parent, currentStroke);
		}

	  // if this event is locked, the event type could not be modified any more utile it's released
/*      if(this.isLocked)
		{
			if(evt.getButton()!=oldButtonType)
			{
				stkevt.getStroke().setLeftButton(false);
				stkevt.getStroke().setMiddleButton(false);
				stkevt.getStroke().setRightButton(false);
            
				switch (oldButtonType)
				{
					case MouseEvent.BUTTON1: stkevt.getStroke().setLeftButton(true);
													  break;
					case MouseEvent.BUTTON2: stkevt.getStroke().setMiddleButton(true);
													  break;
					case MouseEvent.BUTTON3: stkevt.getStroke().setRightButton(true);
													  break;
				}
			}
		}

		if(isLocked==false)      
		  oldButtonType = evt.getButton();  
   
		if(isLocked==false)
		{
			if(stkevt.isLeftButton())
			{
				oldButtonType = MouseEvent.BUTTON1;
			}
			else if(stkevt.isMiddleButton())
			{
				oldButtonType = MouseEvent.BUTTON2;
			}
			else
			{
				oldButtonType = MouseEvent.BUTTON3;
			}
		}
           
		isLocked = true;
*/

		if(stkevt.isLeftButton())
		{
			oldButtonType = MouseEvent.BUTTON1;
		}
		else if(stkevt.isMiddleButton())
		{
			oldButtonType = MouseEvent.BUTTON2;
		}
		else
		{
			oldButtonType = MouseEvent.BUTTON3;
		}
           
		isLocked = true;

		stkevt.setMouseEvent(evt);
      
		//clear dispatching cache
		dispatchingPath.clear();
      
		stkevt.setDispatchingCache(dispatchingPath);
      
		parent.onNewStroke(stkevt);

		//// 5. Restore the mouse event in case there are other listeners.
		EventUtil.setPosition(evt, oldX, oldY);

		//// 6. Initialize scrolling info.
		if (flagRenderCurvy) {
			initScroll(currentCurvyStroke);
		}
		else {
			initScroll(currentStroke);
		}
	} // of mousePressed

	//-----------------------------------------------------------------
   
	public final void fickMouseDragged(MouseEvent moveEvt) {

		MouseEvent evt = 
			new MouseEvent((Component)moveEvt.getSource(), MouseEvent.MOUSE_DRAGGED,
				moveEvt.getWhen(), moveEvt.getModifiers(), moveEvt.getX(), moveEvt.getY(),
				moveEvt.getClickCount(), moveEvt.isPopupTrigger(), oldButtonType);

		//// 0.5. If we are scrolling, need to break beyond a certain threshold
		////      in order for the mouse to take control again. This is to make
		////      it easy for pens to work.
		if (repeatEvent != evt) {
			if (flagScrolling == false) {
				ignoreEvent = repeatEvent;
				delayCount  = 0;
			}
			else if (distSquared(evt, repeatEvent) > 50) {
				flagScrolling = false;
				ignoreEvent   = repeatEvent;
				delayCount    = 0;
			}
			else if (repeatEvent != null) {
				repeatEvent = evt;
				delayCount  = DEFAULT_INITIAL_SCROLL_DELAY_COUNT;
			}
		}

		//// 1. Add the point.
		oldX = evt.getX();
		oldY = evt.getY();
		EventUtil.applyTransform(evt, getInverseTransform());
		if (flagRenderCurvy) {
			 currentCurvyStroke.addPoint(evt.getX(), evt.getY());
		}
		else {
			 currentStroke.addPoint(evt.getX(), evt.getY());
		}

		//// 2. Do the auto-scrolling.
		boolean flagApply = false;


		if (flagAutoScrollingEnabled == true) {
			//// Just want height and width really
			parent.getBounds(rect);
			rect.x = 0;
			rect.y = 0;

			//// 2.1. Calculate how close we are to the edge of the canvas.
			int     dTop      = oldY - rect.y;
			int     dBottom   = rect.y + rect.height - oldY;
			int     dLeft     = oldX - rect.x;
			int     dRight    = rect.x + rect.width - oldX;

			//// 2.2. Set the scroll thresholds.
			if (flagUseDefaultScrollThreshX == true) {
				scrollThreshX = DEFAULT_SCROLL_THRESH_X;
			}
			else {
				scrollThreshX = 0;
			}
			if (flagUseDefaultScrollThreshY == true) {
				scrollThreshY = DEFAULT_SCROLL_THRESH_Y;
			}
			else {
				scrollThreshY = 0;
			}

			scrollThreshX = 0;
			scrollThreshY = 0;

			//// 2.2. See if we should auto-scroll.
			if (flagUseDefaultScrollThreshX || flagUseDefaultScrollThreshY) {
				if (dLeft   <= scrollThreshX ||
					 dRight  <= scrollThreshX + RIGHT_TOLERANCE ||
					 dTop    <= scrollThreshY ||
					 dBottom <= scrollThreshY) {
				  flagApply = true;
				}
			}

			//// 2.3. Apply a transform if we have one.
			////      Ignore the first one, because we want 
			////      a delay before scrolling.
			if (flagApply == true && 
				 delayCount >= DEFAULT_INITIAL_SCROLL_DELAY_COUNT) {

				Point2D ptDir;
				if (flagRenderCurvy) {
					ptDir = StrokeLib.computeApproxDirection(COORD_REL,
																		  currentCurvyStroke);
				}
				else {
					ptDir = StrokeLib.computeApproxDirection(COORD_REL,
																		  currentStroke);
				}
               
				scrollTx.setToIdentity();
				scrollTx.translate(-ptDir.getX() * DEFAULT_SCROLL_THRESH_X,
										 -ptDir.getY() * DEFAULT_SCROLL_THRESH_Y);
				parent.applyTransform(scrollTx);
			}
		}


		//// 3. Set what buttons are activated in the stroke.
		if (flagRenderCurvy) {
			setButtonInStroke(currentCurvyStroke, evt);
		}
		else {
			setButtonInStroke(currentStroke, evt);
		}

		//// 4. Dispatch the Stroke to the parent.
		UpdateStrokeEvent stkevt;
		if (flagRenderCurvy) {
			stkevt = new UpdateStrokeEvent(parent, currentCurvyStroke);
		} else {
			stkevt = new UpdateStrokeEvent(parent, currentStroke);
		}

		stkevt.setMouseEvent(evt);

		stkevt.setDispatchingCache(dispatchingPath);
 
		if(isLocked)
		{
			if(evt.getButton()!=oldButtonType)
			{
				stkevt.getStroke().setLeftButton(false);
				stkevt.getStroke().setMiddleButton(false);
				stkevt.getStroke().setRightButton(false);
            
				switch (oldButtonType)
				{
					case MouseEvent.BUTTON1: stkevt.getStroke().setLeftButton(true);
													  break;
					case MouseEvent.BUTTON2: stkevt.getStroke().setMiddleButton(true);
													  break;
					case MouseEvent.BUTTON3: stkevt.getStroke().setRightButton(true);
													  break;
				}
			}
		}
      
		parent.onUpdateStroke(stkevt);

		//// 5. Restore the mouse event in case there are other listeners.
		EventUtil.setPosition(evt, oldX, oldY);

		//// 6. Put the event back into the event queue for scrolling.
		////    Put a delay in, or otherwise it will go scroll for too long.
		if (flagApply == true) {
			AWTEvent   e1    = queue.peekEvent(MouseEvent.MOUSE_RELEASED);
			if (e1 == null) {
				try {
					Thread.sleep(DEFAULT_SCROLL_DELAY);
					delayCount++;
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				repeatEvent   = evt;
				queue.postEvent(evt);
				flagScrolling = true;
			}
		}

	}
   
	//-----------------------------------------------------------------

	/**
	 * Handle mouse dragged with button down. Adds current position to 
	 * existing Stroke object before sending updates to any Progressive
	 * Interpreters.
	 */
	public final void mouseDragged(MouseEvent evt) {

		//// 0.1. Enabled check.
		if (isEnabled() == false) {
			return;
		}

		//// 0.2. Ignore bogus events.
		if (flagRenderCurvy) {
			if (currentCurvyStroke == null) {
				return;
			}
		}
		else {
			if (currentStroke == null){
				return;
			}
		}
      
		//// 0.3. Do we accept this mouse button?
		if (acceptMouseEvent(evt) == false) {
			return;
		}

		//// 0.4. Check if a new drag event was received.
		////      If so, ignore old drag event, don't want to process 
		////      repeating drag events.
		if (evt == ignoreEvent) {
			return;
		}

		//// 0.5. If we are scrolling, need to break beyond a certain threshold
		////      in order for the mouse to take control again. This is to make
		////      it easy for pens to work.
		if (repeatEvent != evt) {
			if (flagScrolling == false) {
				ignoreEvent = repeatEvent;
				delayCount  = 0;
			}
			else if (distSquared(evt, repeatEvent) > 50) {
				flagScrolling = false;
				ignoreEvent   = repeatEvent;
				delayCount    = 0;
			}
			else if (repeatEvent != null) {
				repeatEvent = evt;
				delayCount  = DEFAULT_INITIAL_SCROLL_DELAY_COUNT;
			}
		}

		//// 1. Add the point.
		oldX = evt.getX();
		oldY = evt.getY();
		EventUtil.applyTransform(evt, getInverseTransform());
		if (flagRenderCurvy) {
			 currentCurvyStroke.addPoint(evt.getX(), evt.getY());
		}
		else {
			 currentStroke.addPoint(evt.getX(), evt.getY());
		}

		//// 2. Do the auto-scrolling.
		boolean flagApply = false;


		if (flagAutoScrollingEnabled == true) {
			//// Just want height and width really
			parent.getBounds(rect);
			rect.x = 0;
			rect.y = 0;

			//// 2.1. Calculate how close we are to the edge of the canvas.
			int     dTop      = oldY - rect.y;
			int     dBottom   = rect.y + rect.height - oldY;
			int     dLeft     = oldX - rect.x;
			int     dRight    = rect.x + rect.width - oldX;

			//// 2.2. Set the scroll thresholds.
			if (flagUseDefaultScrollThreshX == true) {
				scrollThreshX = DEFAULT_SCROLL_THRESH_X;
			}
			else {
				scrollThreshX = 0;
			}
			if (flagUseDefaultScrollThreshY == true) {
				scrollThreshY = DEFAULT_SCROLL_THRESH_Y;
			}
			else {
				scrollThreshY = 0;
			}

			scrollThreshX = 0;
			scrollThreshY = 0;

			//// 2.2. See if we should auto-scroll.
			if (flagUseDefaultScrollThreshX || flagUseDefaultScrollThreshY) {
				if (dLeft   <= scrollThreshX ||
					 dRight  <= scrollThreshX + RIGHT_TOLERANCE ||
					 dTop    <= scrollThreshY ||
					 dBottom <= scrollThreshY) {
				  flagApply = true;
				}
			}

			//// 2.3. Apply a transform if we have one.
			////      Ignore the first one, because we want 
			////      a delay before scrolling.
			if (flagApply == true && 
				 delayCount >= DEFAULT_INITIAL_SCROLL_DELAY_COUNT) {

				Point2D ptDir;
				if (flagRenderCurvy) {
					ptDir = StrokeLib.computeApproxDirection(COORD_REL,
																		  currentCurvyStroke);
				}
				else {
					ptDir = StrokeLib.computeApproxDirection(COORD_REL,
																		  currentStroke);
				}
            	
				scrollTx.setToIdentity();
				scrollTx.translate(-ptDir.getX() * DEFAULT_SCROLL_THRESH_X,
										 -ptDir.getY() * DEFAULT_SCROLL_THRESH_Y);
				parent.applyTransform(scrollTx);
			}
		}


		//// 3. Set what buttons are activated in the stroke.
		if (flagRenderCurvy) {
			setButtonInStroke(currentCurvyStroke, evt);
		}
		else {
			setButtonInStroke(currentStroke, evt);
		}
        
        

		//// 4. Dispatch the Stroke to the parent.
		UpdateStrokeEvent stkevt;
        
		if (flagRenderCurvy) {
			stkevt = new UpdateStrokeEvent(parent, currentCurvyStroke);
		} else {
			stkevt = new UpdateStrokeEvent(parent, currentStroke);
		}

		stkevt.setMouseEvent(evt);

		stkevt.setDispatchingCache(dispatchingPath);
 
 
		if(isLocked)
		{
			if(evt.getButton()!=oldButtonType)
			{
				stkevt.getStroke().setLeftButton(false);
				stkevt.getStroke().setMiddleButton(false);
				stkevt.getStroke().setRightButton(false);
            
				switch (oldButtonType)
				{
					case MouseEvent.BUTTON1: stkevt.getStroke().setLeftButton(true);
													  break;
					case MouseEvent.BUTTON2: stkevt.getStroke().setMiddleButton(true);
													  break;
					case MouseEvent.BUTTON3: stkevt.getStroke().setRightButton(true);
													  break;
				}
			}
		}
      
		parent.onUpdateStroke(stkevt);

		//// 5. Restore the mouse event in case there are other listeners.
		EventUtil.setPosition(evt, oldX, oldY);

		//// 6. Put the event back into the event queue for scrolling.
		////    Put a delay in, or otherwise it will go scroll for too long.
		if (flagApply == true) {
			AWTEvent   e1    = queue.peekEvent(MouseEvent.MOUSE_RELEASED);
			if (e1 == null) {
				try {
					Thread.sleep(DEFAULT_SCROLL_DELAY);
					delayCount++;
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				repeatEvent   = evt;
				queue.postEvent(evt);
				flagScrolling = true;
			}
		}

	} // of mouseDragged

	//-----------------------------------------------------------------

	/**
	 * Handle release of mouse button. Adds final position to existing 
	 * Stroke object before sending updates to any Full-Stroke Interpreters.
	 */
	public void mouseReleased(MouseEvent evt) {

		//// 0.1. Enabled check.
		if (isEnabled() == false) {
			parent.setRenderToScreen(true);
			return;
		}

		//// 0.2. Ignore bogus events.
		if (flagRenderCurvy) {
			if (currentCurvyStroke == null) {
				parent.setRenderToScreen(true);
				return;
			}
		}
		else {
			if (currentStroke == null) {
				parent.setRenderToScreen(true);
				return;
			}
		}

		//// 0.3. Do we accept this mouse button?
		if (acceptMouseEvent(evt) == false) {
			parent.setRenderToScreen(true);
			return;
		}

		//// 0.4. If there isn't enough time between this release and the
		////      previous release, ignore this release
		if (evt.getWhen() < lastReleaseTime + DEFAULT_MIN_TIME_BETWEEN_RELEASE) {
			Debug.println("Mouse release ignored: interval = " + (evt.getWhen() - lastReleaseTime) + " ms");
			parent.setRenderToScreen(true);         
			return;
		}
      
		//// 0.5. Turn scrolling off.
		flagScrolling = false;

		//// 1. Record the time of this release
		lastReleaseTime = evt.getWhen();
      
		//// 2. Add the point.
		oldX = evt.getX();
		oldY = evt.getY();
		EventUtil.applyTransform(evt, getInverseTransform());
		if (flagRenderCurvy) {
			currentCurvyStroke.addPoint(evt.getX(), evt.getY());
			currentCurvyStroke.doneAddingPoints();
		}
		else {
			currentStroke.addPoint(evt.getX(), evt.getY());
			currentStroke.doneAddingPoints();
		}


		//// 3. Set what buttons are activated in the stroke.
		if (flagRenderCurvy) {
			setButtonInStroke(currentCurvyStroke, evt);
		}
		else {
			setButtonInStroke(currentStroke, evt);
		}

		//// 4. Dispatch the Stroke to the parent.
		SingleStrokeEvent stkevt;
		if (flagRenderCurvy) {
			stkevt = new SingleStrokeEvent(parent, currentCurvyStroke);
		}
		else {
			stkevt = new SingleStrokeEvent(parent, currentStroke);
		}

		stkevt.setMouseEvent(evt);
      
		stkevt.setDispatchingCache(dispatchingPath);

		if(isLocked)
		{
			if(evt.getButton()!=oldButtonType)
			{
				stkevt.getStroke().setLeftButton(false);
				stkevt.getStroke().setMiddleButton(false);
				stkevt.getStroke().setRightButton(false);
            
				switch (oldButtonType)
				{
					case MouseEvent.BUTTON1: stkevt.getStroke().setLeftButton(true);
													  break;
					case MouseEvent.BUTTON2: stkevt.getStroke().setMiddleButton(true);
													  break;
					case MouseEvent.BUTTON3: stkevt.getStroke().setRightButton(true);
													  break;
				}
			}
		  
			isLocked = false;
		}
      	  
        
		parent.onSingleStroke(stkevt);

		//// 5. Restore the mouse event in case there are other listeners.
		EventUtil.setPosition(evt, oldX, oldY);
		if (flagRenderCurvy) {
			currentCurvyStroke = null;
		}
		else {
			currentStroke = null;
		}

		//// 6. Now here's an interesting hack [tm].
		////    We need to make StrokeAssembler the LAST listener that responds
		////    to mouse events, so that other listeners can consume the event
		////    first. Fortunately, this hack works, and does not resend the
		////    MouseEvent again to the StrokeAssembler.
		parent.removeMouseListener(this);
		parent.removeMouseMotionListener(this);
		parent.addMouseListener(this);
		parent.addMouseMotionListener(this);
      
		//clear dispatching cache
		dispatchingPath.clear();

		parent.setRenderToScreen(true);
      
	} // of mouseReleased
    
    
    public void reset() {
        //// 0.5. Turn scrolling off.
        flagScrolling = false;
        isLocked = false;
        if (flagRenderCurvy) {
            currentCurvyStroke = null;
        }
        else {
            currentStroke = null;
        }
        parent.removeMouseListener(this);
        parent.removeMouseMotionListener(this);
        parent.addMouseListener(this);
        parent.addMouseMotionListener(this);
    
        //clear dispatching cache
        dispatchingPath.clear();
        parent.setRenderToScreen(true);
    }
    
    

	//===   MOUSE METHODS   =====================================================
	//===========================================================================

	//===========================================================================
	//===   SMOOTH METHODS   ===================================================

	public void setAngleTolerance(float at) {
		  angleTolerance = at;
	}
   
	//-----------------------------------------------------------------
   
	public void setFilterWindowSize(int ws) {
		  windowSize = ws;
	}
   
	//-----------------------------------------------------------------
   
	public void setCornerDegree(float cd) {
		  cornerDegree = cd;
	}

	//===   SMOOTH METHODS   =====================================================
	//===========================================================================


	//===========================================================================
	//===   WATCHER METHODS   ===================================================

	public void onNotify(Watchable w, Object arg) {
		//// ignore
	} // of onNotify

	//-----------------------------------------------------------------

	public void onUpdate(Watchable w, Object arg) {
		//// ignore
	} // of onUpdate

	//-----------------------------------------------------------------

	/**
	 * Update on transforms by the Sheet, so we can apply strokes correctly.
	 */
	public void onUpdate(Watchable w, String strProperty, 
			Object oldVal, Object newVal) {
	} // of onUpdate

	//-----------------------------------------------------------------

	public void onRepaint(GraphicalObject gob) {
		//// ignore
	} // of onRepaint

	//-----------------------------------------------------------------

	public void onRepaint(Rectangle rect) {
		//// ignore
	} // of onRepaint

	//-----------------------------------------------------------------

	public void onDelete(Watchable w) {
		//// ignore
	} // of onDelete

	//===   WATCHER METHODS   ===================================================
	//===========================================================================



	//===========================================================================
	//===   CLONE   =============================================================

	public Object clone() {
		throw new RuntimeException("StrokeAssembler should not be cloned...");
	} // of clone

	//===   CLONE   =============================================================
	//===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User 
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
