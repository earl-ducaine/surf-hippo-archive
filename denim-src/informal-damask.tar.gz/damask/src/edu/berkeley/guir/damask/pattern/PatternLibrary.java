package edu.berkeley.guir.damask.pattern;

import java.io.*;
import java.net.URL;

import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;
import edu.berkeley.guir.damask.view.pattern.PatternParser;
import edu.berkeley.guir.lib.collection.Map2D;

/** 
 * The library of patterns in Damask.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  03-14-2004 James Lin
 *                               Created PatternLibrary.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 03-14-2004
 */
public class PatternLibrary {
   
   private static final Map2D/*<String, String, Object (Pattern or URL)>*/
      library = new Map2D();
   
   static {
      try {
         final URL patternsListURL =
            Pattern.class.getResource("PatternList.txt");
         final BufferedReader indexReader =
            new BufferedReader(
               new InputStreamReader(patternsListURL.openStream()));
         String patternline;
         while ((patternline = indexReader.readLine()) != null) {
            PatternLibrary.addPattern(Pattern.class.getResource(patternline));
         }
      }
      catch (IOException e) {
         // This should not happen.
         DamaskAppExceptionHandler.log(e);
      }
   }

   /**
    * Prevents instantiation.
    */
   private PatternLibrary() {
   }
   
   /**
    * Adds the specified pattern to the library.
    */
   public static void addPattern(final Pattern pattern) {
      library.put(pattern.getCollectionID(), pattern.getID(), pattern);
   }
   
   /**
    * Adds the pattern with the specified URL to the library.
    */
   public static void addPattern(final URL patternURL) {
      final String ids[] = PatternParser.getPatternIDs(patternURL);
      library.put(ids[0], ids[1], patternURL);
   }
   
   /**
    * Removes the specified pattern from the library.
    */
   public static void removePattern(final Pattern pattern) {
      library.put(pattern.getCollectionID(), pattern.getID(), null);
   }

   /**
    * Returns the pattern with the specified collection ID and ID. If the
    * pattern is not yet in the library, then it will be created from the
    * specified URL and added to the library, before being returned.
    */
   public static Pattern getPattern(
      final String collectionID,
      final String patternID) {

      final Object result = library.get(collectionID, patternID);
      if (result instanceof URL) {
         final Pattern pattern =
            new Pattern(collectionID, patternID, (URL)result);
         addPattern(pattern);
         return pattern;
      }
      else {
         return (Pattern)result;
      }
   }
}
