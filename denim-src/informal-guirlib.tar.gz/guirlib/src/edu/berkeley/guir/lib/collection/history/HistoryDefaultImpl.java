//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.history;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * A collection of HistoryEvents.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Jan 30 2004
 */
public class HistoryDefaultImpl 
    implements History {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    /**
     * Default comparator is to compare by date.
     */
    public static final Comparator DEFAULT_COMPARATOR = 
                                            new HistoryEventDateComparator();

    //----------------------------------------------------------------

    public static final int ORDER_FIRST = 15;  // go in ascending order
    public static final int ORDER_LAST  = 19;  // go in descending order

    //===   CONSTANTS   ========================================================
    //==========================================================================



    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    SortedSet setEvents;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================



    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Empty constructor.
     * Automatically sorts by date by default, from old to new.
     */
    public HistoryDefaultImpl() {
        this(DEFAULT_COMPARATOR);
    } // of constructor

    //--------------------

    /**
     * Copy constructor, shallow copy.
     * Automatically sorts by date by default, from old to new.
     * @param col is a Collection of HistoryEvents
     */
    public HistoryDefaultImpl(Collection col) {
        this(col, DEFAULT_COMPARATOR);
    } // of constructor

    //--------------------

    /**
     * Copy constructor, shallow copy.
     * Automatically sorts by date by default, from old to new.
     */
    public HistoryDefaultImpl(History h) {
        this(h, DEFAULT_COMPARATOR);
    } // of constructor

    //--------------------

    /**
     * Use the specified Comparator to sort as we go.
     * @see HistoryEventComparatorByField
     */
    public HistoryDefaultImpl(Reader rdr, HistoryEventParser parser) 
        throws IOException {

        this(rdr, parser, DEFAULT_COMPARATOR);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Use the specified Comparator to sort as we go.
     * @see HistoryEventComparatorByField
     */
    public HistoryDefaultImpl(Comparator c) {
        setEvents = new TreeSet(c);
    } // of constructor

    //--------------------

    /**
     * Copy constructor, shallow copy.
     * Use the specified Comparator to sort as we go.
     * @param col is a Collection of HistoryEvents
     */
    public HistoryDefaultImpl(Collection col, Comparator c) {
        this(c);
        this.addAllEvents(col.iterator());
    } // of constructor

    //--------------------

    /**
     * Copy constructor, shallow copy.
     * Use the specified Comparator to sort as we go.
     */
    public HistoryDefaultImpl(History h, Comparator c) {
        this(c);
        this.addAllEvents(h);
    } // of constructor

    //--------------------

    /**
     * Use the specified Comparator to sort as we go.
     */
    public HistoryDefaultImpl(Reader rdr, HistoryEventParser p, Comparator c) 
        throws IOException {

        this(c);

        List      listEvents = p.parse(rdr);
        Iterator  it         = listEvents.iterator();

        while (it.hasNext()) {
            addEvent((HistoryEvent) it.next());
        }
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    /**
     * Add a single event.
     * <P>
     * Note that a HistoryEvent might not appear if the
     * Comparator value for this History returns 0 (ie the specified
     * event is equal to another already in here). A common example
     * of this is creating two HistoryEvents such that they have the
     * same time. The Comparator says the two are equal, so only
     * one is actually inserted.
     */
    public void addEvent(HistoryEvent evt) {
       setEvents.add(evt);
    } // of method

    //--------------------

    /**
     * Add all events.
     */
    public void addAllEvents(History history) {
        addAllEvents(history.events());
    } // of method

    //--------------------

    /**
     * @param events is a List of HistoryEvent instances.
     */
    public void addAllEvents(Collection events) {
        addAllEvents(events.iterator());
    } // of method

    //--------------------

    /**
     * @param it is an Iterator of HistoryEvent instances to add.
     */
    public void addAllEvents(Iterator it) {
        HistoryEvent evt;

        while (it.hasNext()) {
            evt = (HistoryEvent) it.next();
            this.addEvent(evt);
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Remove a specific event.
     */
    public void removeEvent(HistoryEvent evt) {
       setEvents.remove(evt);
    } // of method

    //--------------------

    /**
     * Remove the index'th event.
     * Not efficient, O(N) implementation.
     */
    public void removeEvent(int index) {
       setEvents.remove(getEvent(index));
    } // of method

    //----------------------------------------------------------------

    /**
     * Clear out all events.
     */
    public void clearEvents() {
        setEvents.clear();
    } // of method

    //----------------------------------------------------------------

    /**
     */
    public boolean containsEvent(HistoryEvent evt) {
       return (setEvents.contains(evt));
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the index'th event.
     * Not efficient, O(N) implementation.
     */
    public HistoryEvent getEvent(int index) {
        Iterator     it    = events();
        int          count = 0;
        HistoryEvent evt;

        while (it.hasNext()) {
            evt = (HistoryEvent) it.next();
            if (count == index) {
                return (evt);
            }
            count++;
        }
        throw new IndexOutOfBoundsException();
    } // of method

    //----------------------------------------------------------------

    /**
     * @return the number of HistoryEvent objects contained
     */
    public int size() {
       return (setEvents.size());
    } // of method

    //----------------------------------------------------------------

    /**
     * @return an Iterator of HistoryEvent objects. There is no
     *         guaranteed order, sort first if desired.
     */
    public Iterator events() {
        return (events(true));
    } // of method

    //--------------------

    /**
     * @param flagForward is true if want to go in regular forward order,
     *                    false to go in reverse order.
     */
    public Iterator events(boolean flagForward) {
        if (flagForward == true) {
            return (setEvents.iterator());
        }
        else {
            List list = new LinkedList(setEvents);
            Collections.reverse(list);
            return (list.iterator());
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Get a copy of the History as a list.
     */
    public List asList() {
        return (new LinkedList(setEvents));
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================



    //==========================================================================
    //===   COMMON QUERY METHODS   =============================================

    /**
     * Gets the first entry, which depends on how things are sorted.
     * By default, this returns the oldest.
     */
    public HistoryEvent getFirstEntry() {
        return (HistoryEvent) (setEvents.first());
    } // of method

    //--------------------

    /**
     * Gets the last entry, which depends on how things are sorted.
     * By default, this returns the newest.
     */
    public HistoryEvent getLastEntry() {
        return (HistoryEvent) (setEvents.last());
    } // of method

    //----------------------------------------------------------------

    /**
     * Get the first HistoryEvent that matches the specified field.
     * @param flagForward is true if we should go in forward order,
     *                      false if in reverse order.
     */
    public HistoryEvent getByField(boolean flagForward, 
                                   String  strField, 
                                   String  strVal) {

        //// 1. Go thru the events in the specified order.
        Iterator     it = events(flagForward);
        HistoryEvent evt;
        String       strEvtVal;

        //// 2. Find the first event that matches the field and value.
        while (it.hasNext()) {
            evt       = (HistoryEvent) it.next();
            strEvtVal = evt.getValue(strField);
            if (strEvtVal != null && strEvtVal.equals(strVal)) {
                return (evt);
            }
        }

        //// 3. Return.
        return (null);
    } // of method

    //===   COMMON QUERY METHODS   =============================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING METHODS   =================================================

    /**
     * Specifies how a HistoryEvent is printed out.
     */
    public String toString(HistoryEvent evt) {
        return (evt.toString());
    } // of method

    //----------------------------------------------------------------

    public String toString() {
        StringBuffer strbuf = new StringBuffer();
        Iterator     it     = events();

        //// 1. Add each one to the StringBuffer.
        while (it.hasNext()) {
            strbuf.append(toString( (HistoryEvent) it.next() ));
            strbuf.append("\n");
        }

        //// 2. Return.
        return (strbuf.toString());
    } // of method

    //----------------------------------------------------------------

    /**
     * Write out the data to a Writer. Useful, for example, 
     * in sending out to a ZIPStream for compression.
     * <P>
     * Does not <CODE>close()</CODE> the stream, you should do
     * that yourself.
     */
    public void toWriter(Writer wtr) 
        throws IOException {

        Iterator it = events();

        //// 1. Write each one out...
        while (it.hasNext()) {
            wtr.write(toString( (HistoryEvent) it.next() ));
            wtr.write("\n");
        }
    } // of method

    //===   TOSTRING METHODS   =================================================
    //==========================================================================



    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static History getTestInstanceAAA() {
        History hist = new HistoryDefaultImpl();

        hist.addEvent(HistoryEvent.getTestInstanceAAA());
        hist.addEvent(HistoryEvent.getTestInstanceBBB());
        hist.addEvent(HistoryEvent.getTestInstanceCCC());
        hist.addEvent(HistoryEvent.getTestInstanceDDD());
        hist.addEvent(HistoryEvent.getTestInstanceEEE());
        hist.addEvent(HistoryEvent.getTestInstanceFFF());
        hist.addEvent(HistoryEvent.getTestInstanceGGG());
        hist.addEvent(HistoryEvent.getTestInstanceHHH());
        hist.addEvent(HistoryEvent.getTestInstanceIII());
        hist.addEvent(HistoryEvent.getTestInstanceJJJ());
        hist.addEvent(HistoryEvent.getTestInstanceKKK());
        hist.addEvent(HistoryEvent.getTestInstanceLLL());
        return (hist);
    } // of method

    //----------------------------------------------------------------

    //// Test adding and printing
    private static void runTestAAA() {
        History hist = getTestInstanceAAA();

        System.out.println(hist);
        System.out.println();
        System.out.println(hist.getFirstEntry());
        System.out.println();
        System.out.println(hist.getLastEntry());
    } // of method

    //--------------------

    //// Test reverse iterator
    private static void runTestBBB() {
        History  hist = getTestInstanceAAA();
        Iterator it   = hist.events(false);

        System.out.println(hist);
        System.out.println();
        System.out.println();

        while (it.hasNext()) {
            System.out.println(it.next());
        }
    } // of method

    //----------------------------------------------------------------

    public static void main(String[] argv) throws Exception {
        runTestBBB();
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================


// summarize()
// update the Confab LogHistory as well
// add to write out to stream method (ie toWriter)

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
