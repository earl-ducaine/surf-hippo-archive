package edu.berkeley.guir.damask.dialog;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.lib.util.StringLib;

/** 
 * A dialog, which represents a high-level unit of interaction, such as a web
 * page, a cell phone screen, or a voice prompt.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-04-2003 James Lin
 *                               Split Dialog from Page.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 06-04-2003
 */
public class Dialog extends AbstractInteractionElement {
   
   /* TODO a "refresh" method that reorders the items in a group, depending
    * on its visual layout. Maybe.
    */
   private InteractionGraph graph;
   private DeviceDependentContainer pages = new DeviceDependentContainer();
   private DeviceType deviceType;  // would be final, except for clone
   private List/*<ComponentGroup>*/ groups = new ArrayList();

   private int numConditions = 0;
   
   // which condition the dialog is initially in when it is first rendered
   private int initialCondition = 0;   
   
   private ElementContainerSource containerEventSource =
      new ElementContainerSource();
   private DialogEventSource dialogEventSource =
      new DialogEventSource();

   //===========================================================================

   /**
    * Creates a dialog with the specified page title, for the specified 
    * device type (which can be DeviceType.ALL).
    */   
   public Dialog(final DeviceType deviceType, final Content pageTitle) {
      graph = null;
      this.deviceType = deviceType;

      // Create pages for each device.
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         Page page = new Page(aDeviceType, this, pageTitle);
         basicAdd(page);
      }

      setBounds(deviceType, new Rectangle2D.Double(0, 0, 0, 0));
      setTransform(deviceType, new AffineTransform());

      if (isVisibleToDeviceType(DeviceType.VOICE)) {
         setBounds(
            DeviceType.VOICE,
            new Rectangle2D.Double(
               0,
               0,
               DeviceType.VOICE.getDefaultWidth(),
               DeviceType.VOICE.getDefaultHeight()));
      }
      
      // Add one condition
      addCondition();
   }

   //===========================================================================

   /**
    * Creates a dialog with the specified page title, for the specified 
    * device type (which can be DeviceType.ALL).
    */   
   public Dialog(final Dialog oldDialog, final DeviceType deviceType) {
      graph = null;
      copy(oldDialog, deviceType, false);

      setBounds(deviceType, new Rectangle2D.Double(0, 0, 0, 0));
      setTransform(deviceType, new AffineTransform());
      
      if (isVisibleToDeviceType(DeviceType.VOICE)) {
         setBounds(
            DeviceType.VOICE,
            new Rectangle2D.Double(
               0,
               0,
               DeviceType.VOICE.getDefaultWidth(),
               DeviceType.VOICE.getDefaultHeight()));
         if (oldDialog.isVisibleToDeviceType(DeviceType.VOICE)) {
            setTransform(
               DeviceType.VOICE, oldDialog.getTransform(DeviceType.VOICE));
         }
         else {
            final Iterator i = oldDialog.getDeviceTypesVisibleTo().iterator();
            if (i.hasNext()) {
               final DeviceType aDeviceType = (DeviceType)i.next();
               setTransform(
                  DeviceType.VOICE,
                  oldDialog.getFirstPage(aDeviceType).getTransform());
            }
         }
      }
   }
   
   //===========================================================================
   
   /**
    * Frees up any resources associated with this dialog.
    */
   public void dispose() {
      for (Iterator i = pages.getDeviceTypes().iterator(); i.hasNext(); ) {
         final DeviceType deviceType = (DeviceType)i.next();
         for (Iterator j =
            new ArrayList(pages.getContainees(deviceType)).iterator();
            j.hasNext(); ) {
            
            final Page p = (Page)j.next();
            remove(p);
         }
      }
      graph = null;
      pages.clear();
   }
   
   //===========================================================================
   
   /**
    * Returns the interaction graph that the dialog is in, or null if it's not
    * in any graph.
    */
   public InteractionGraph getInteractionGraph() {
      return graph;
   }
   
   //---------------------------------------------------------------------------

   /**
    * Sets the interaction graph that the dialog is in. Called only by
    * InteractionGraph.add(Dialog).
    */
   public void setInteractionGraph(InteractionGraph graph) {
      this.graph = graph;
   }
   
   //===========================================================================
   
   /**
    * Returns the type of devices that this dialog deals with. May be
    * DeviceType.ALL.
    */
   public DeviceType getDeviceType() {
      return deviceType;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the type of devices that this dialog deals with. May be
    * DeviceType.ALL.
    */
   public void setDeviceType(final DeviceType deviceType) {
      this.deviceType = deviceType;
   }
   
   //===========================================================================
   
   /**
    * Returns the types of devices that this dialog deals with.
    */
   public Set/*<DeviceType>*/ getDeviceTypesVisibleTo() {
      return pages.getDeviceTypes();
   }

   //===========================================================================

   /**
    * Returns the nth page for the given device type in this dialog, or null
    * if this dialog does not support the given device type.
    */
   public Page getPage(final DeviceType aDeviceType, final int index) {
      aDeviceType.verifyTypeIsNotAll();
      if (isEnabled(aDeviceType)) {
         List pagesForDevice = pages.getContainees(aDeviceType);
         return (Page)(pagesForDevice.get(index));
      }
      else {
         return null;
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the first page for the given device type in this dialog, or null
    * if this dialog does not support the given device type..
    */
   public Page getFirstPage(final DeviceType deviceType) {
      return getPage(deviceType, 0);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the last page for the given device in this dialog, or null
    * if this dialog does not support the given device type.
    */
   public Page getLastPage(DeviceType deviceType) {
      return getPage(deviceType, getPages(deviceType).size() - 1);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns all of the pages that are for the given device in this dialog,
    * or an empty list if this dialog does not support the given device type. 
    */
   public List/*<Page>*/ getPages(DeviceType deviceType) {
      return pages.getContainees(deviceType);
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Adds the given page to this dialog.
    */
   private final void basicAdd(Page page) {
      basicAdd(pages.size(page.getDeviceType()), page);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the given page to this dialog at the given position.
    */
   private void basicAdd(int index, Page page) {
      DamaskUtils.checkValidArgument(
         page.getDialog() == this,
         page + "'s dialog should be " + page.getDialog());
      pages.add(page.getDeviceType(), index, page);
      fireElementAdded(index, page);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the given page to this dialog.
    */
   protected void add(Page page) {
      add(pages.size(page.getDeviceType()), page); 
   }
   
   //---------------------------------------------------------------------------

   /**
    * Adds the given page to this dialog to the given position in the list.
    * Used only by Page.split() and setIndex().
    */
   protected void add(int index, Page page) {
      basicAdd(index, page);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given page from this dialog. Used only by remove()
    * and setIndex().
    */
   protected boolean removeWithoutDispose(Page page) {
      final int index = pages.indexOf(page.getDeviceType(), page);
      if (index != -1) {
         pages.remove(page.getDeviceType(), page);
         fireElementRemoved(index, page);
         return true;
      }
      else {
         return false;
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the given page from this dialog. Used only by dispose(),
    * Page.merge().
    */
   protected boolean remove(Page page) {
      final boolean wasRemoved = removeWithoutDispose(page);
      if (wasRemoved) {
         page.dispose();
      }
      return wasRemoved;
   }

   //===========================================================================
   
   /**
    * Sets the index of the specified page to the specified number.
    */
   public void setIndex(final int newIndex, final Page page) {
      removeWithoutDispose(page);
      page.setDialog(this);
      add(newIndex, page);
   }

   //===========================================================================

   /**
    * Returns the index of the given page, or -1 if the page is not in this
    * dialog.
    */
   public int indexOf(Page page) {
      return pages.indexOf(page.getDeviceType(), page);
   }

   //===========================================================================

   /**
    * Merges the pages of the given dialog with this dialog, splitting pages
    * in this dialog if necessary to accomodate the merged pages.
    */
   public void merge(final Dialog dialog2) {
      // For each device type...
      final Set/*<Connection>*/ dialog2ControlConnections =
         new HashSet/*<Connection>*/();
      final Set/*<Control>*/ dialog2Controls = new HashSet/*<Control>*/();
      final Map/*<PageRegion, List<Control>>*/
         dialog1ControlsByRegion = new HashMap/*<PageRegion, List<Control>>*/();
      
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext();) {
         final DeviceType deviceType = (DeviceType)i.next();

         // Make sure this dialog and dialog2 have the same number of pages.
         final int d2NumPages = dialog2.getPages(deviceType).size(); 
         if (d2NumPages > 1) {
            final int d1NumPages = getPages(deviceType).size();
            
            if (d1NumPages < d2NumPages) {
               for (int j = d1NumPages; j < d2NumPages; j++) {
                  getLastPage(deviceType).split(Collections.EMPTY_LIST);
               }
            }
         }
         
         // For each region in the first page of dialog2, move the controls
         // to the end of the corresponding region in the first page of this
         // dialog.
         for (Iterator j1 = getPages(deviceType).iterator(),
                       j2 = dialog2.getPages(deviceType).iterator();
              j1.hasNext(); ) {
            final Page p1 = (Page)j1.next();
            final Page p2 = (Page)j2.next();
            
            for (Iterator k = p1.getRegions().iterator(); k.hasNext(); ) {
               final PageRegion p1Region = (PageRegion)k.next();
               final PageRegion p2Region = p2.getRegion(p1Region.getName());
            
               final List p2RegionControls = new ArrayList(p2Region.getControls());
            
               for (Iterator m = p2RegionControls.iterator(); m.hasNext();) {
                  final Control c = (Control)m.next();
                  dialog2ControlConnections.addAll(c.getInConnections());
                  dialog2ControlConnections.addAll(c.getOutConnections());
                  
                  dialog2Controls.add(c);
                  
                  List/*<Control>*/ p1RegionControls =
                     (List)dialog1ControlsByRegion.get(p1Region);
                  if (p1RegionControls == null) {
                     p1RegionControls = new ArrayList/*<Control>*/();
                     dialog1ControlsByRegion.put(p1Region, p1RegionControls);
                  }
                  p1RegionControls.add(c);
               }
            }
         }
      }
      
      for (Iterator i = dialog2Controls.iterator(); i.hasNext(); ) {
         final Control c = (Control)i.next();
         c.getDialog().removeControl(c);
      }
      
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext();) {
         final DeviceType deviceType = (DeviceType)i.next();
         
         // For each region in the first page of dialog2, move the controls
         // to the end of the corresponding region in the first page of this
         // dialog.
         for (Iterator j = getPages(deviceType).iterator(); j.hasNext(); ) {
            final Page p = (Page)j.next();
            for (Iterator k = p.getRegions().iterator(); k.hasNext(); ) {
               final PageRegion region = (PageRegion)k.next();
               final List/*<Control>*/ newControls =
                  (List)dialog1ControlsByRegion.get(region);
               if (newControls != null) {
                  for (Iterator m = newControls.iterator(); m.hasNext(); ) {
                     final Control c = (Control)m.next();
                     region.add(c);
                  }
               }
            }
         }
      }
      
      
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext();) {
         final DeviceType deviceType = (DeviceType)i.next();

         // Add the connections to and from dialog2's pages to the
         // corresponding pages in this dialog.
         for (Iterator j = getPages(deviceType).iterator(),
                       k = dialog2.getPages(deviceType).iterator();
            j.hasNext();
            ) {

            final Page d1Page = (Page)j.next();
            final Page d2Page = (Page)k.next();
            
            d1Page.takeConnections(d2Page);
         }
      }
      
      // Delete dialog2.
      dialog2.getInteractionGraph().remove(dialog2);
   }

   //===========================================================================

   /**
    * Returns whether this dialog is enabled for the specified device type.
    */
   public boolean isEnabled(final DeviceType deviceType) {
      return ((deviceType == this.deviceType)
              || (this.deviceType == DeviceType.ALL));
   }

   //===========================================================================

   /**
    * Adds the specified control into the specified page region as the first
    * control. If the control being added is for all device types, then this
    * method also adds the control to the region with the same name as the
    * specified page region in the first page of this dialog for all device
    * types.
    */
   public final void addControlAtBeginning(
      final PageRegion region,
      final Control controlToAdd) {
      
      addControl(region, true, controlToAdd);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Adds the specified control into the specified page region as the last
    * control. If the control being added is for all device types, then this
    * method also adds the control to the region with the same name as the
    * specified page region in the last page of this dialog for all device
    * types.
    */
   public final void addControlAtEnd(
      final PageRegion region,
      final Control controlToAdd) {
      
      addControl(region, false, controlToAdd);
   }

   //---------------------------------------------------------------------------

   /**
    * Adds the specified control into the specified page region. If the control
    * being added is for all device types, then this method also adds the
    * control to the region with the same name as the specified page region
    * in the last page of this dialog for all device types.
    */
   protected void addControl(
      final PageRegion region,
      final boolean trueIfFirstFalseIfLast,
      final Control controlToAdd) {

      DamaskUtils.checkValidArgument(region.getPage().getDialog() == this,
                                     region + " must be within " + this);
      if (trueIfFirstFalseIfLast) {
         region.add(0, controlToAdd);
      }
      else {
         region.add(controlToAdd);
      }
      
      for (Iterator i = controlToAdd.getDeviceTypesVisibleTo().iterator();
         i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         if (aDeviceType != region.getDeviceType()) {
            final PageRegion aRegion =
               getPageRegionToAddTo(
                  region, trueIfFirstFalseIfLast, aDeviceType);
            if (trueIfFirstFalseIfLast) {
               aRegion.add(0, controlToAdd);
            }
            else {
               aRegion.add(controlToAdd);
            }
         }
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the page region that a control should be added to for the
    * specified device type, if it is added after the specified control.
    */
   public PageRegion getPageRegionToAddTo(
      final PageRegion region,
      final boolean trueIfFirstFalseIfLast,
      final DeviceType aDeviceType) {

      DamaskUtils.checkValidArgument(region.getPage().getDialog() == this,
                                     region + " must be within " + this);
      
      final PageRegion aRegion;
      final Direction aRegionName =
         aDeviceType == DeviceType.VOICE ? Direction.CENTER : region.getName();
      if (trueIfFirstFalseIfLast) {
         aRegion = getFirstPage(aDeviceType).getRegion(aRegionName);
      }
      else {
         aRegion = getLastPage(aDeviceType).getRegion(aRegionName);
      }
      return aRegion;
   }
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified control into the specified page regions. The device
    * types of the page regions must exactly match the device types supported
    * by the control.
    * 
    * @param  regions  a map of a region to what index the specified control
    *                   should have in that region
    * @param  controlToAdd  the control to add
    */
   public void addControl(
      final Map/*<PageRegion, Integer>*/ regions,
      final Control controlToAdd) {

      // Make sure the regions' device types match the controls.
      final Set/*<DeviceType>*/ deviceTypesForControl =
         new HashSet/*<DeviceType>*/(controlToAdd.getDeviceTypesVisibleTo());
      boolean match = true;
      for (Iterator i = regions.keySet().iterator(); i.hasNext(); ) {
         final PageRegion region = (PageRegion)i.next();
         match &= deviceTypesForControl.remove(region.getDeviceType());
      }
      match &= deviceTypesForControl.isEmpty();
      DamaskUtils.checkValidArgument(
         match,
         "device types of regions does not match those of " + controlToAdd);

      for (Iterator i = regions.keySet().iterator(); i.hasNext(); ) {
         final PageRegion region = (PageRegion)i.next();
         final int index = ((Integer)regions.get(region)).intValue();
         region.add(index, controlToAdd);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Adds controlToAdd to insertAfterMe's page after insertAfterMe. If
    * controlToAdd supports all devices, then controlToAdd will be added for all
    * devices. If insertAfterMe is not visible for a device type, then
    * controlToAdd is added after the first control that is visible to that
    * device type after insertAfterMe.
    */
   public void addControlAfter(
      final Control insertAfterMe,
      final Control controlToAdd) {

      DamaskUtils.checkValidArgument(
         insertAfterMe.getDialog() == this,
         insertAfterMe + " is not in " + this);

      for (Iterator i = controlToAdd.getDeviceTypesVisibleTo().iterator();
         i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         final PageRegion regionToAddTo =
            getPageRegionToAddTo(insertAfterMe, aDeviceType);
         
         if (insertAfterMe.isVisibleToDeviceType(aDeviceType)) {
            regionToAddTo.addAfter(insertAfterMe, controlToAdd);
         }
         // If insertAfterMe is not visible for this device, then
         // add controlToAdd after the first control that is visible
         // to that device type after insertAfterMe.
         else {
            regionToAddTo.add(controlToAdd);
         }
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the page region that a control should be added to for the
    * specified device type, if it is added after the specified control.
    */
   public PageRegion getPageRegionToAddTo(
      final Control insertAfterMe, final DeviceType aDeviceType) {

      DamaskUtils.checkValidArgument(
         insertAfterMe.getDialog() == this,
         insertAfterMe + " is not in " + this);
      
      aDeviceType.verifyTypeIsNotAll();

      final DeviceType aVisibleDeviceTypeForinsertAfterMe =
         (DeviceType)insertAfterMe.getDeviceTypesVisibleTo().iterator().next();
      
      if (insertAfterMe.isVisibleToDeviceType(aDeviceType)) {
         final PageRegion region = insertAfterMe.getPageRegion(aDeviceType);
         return region;
      }
      // If insertAfterMe is not visible for this device, then
      // add controlToAdd after the first control that is visible
      // to that device type after insertAfterMe.
      else {
         final PageRegion aRegionForInsertAfterMe =
            insertAfterMe.getPageRegion(aVisibleDeviceTypeForinsertAfterMe);
         for (Iterator j =
            aRegionForInsertAfterMe.getControls().iterator(); j.hasNext();){
            final Control newInsertAfterMe = (Control)j.next();
            if (newInsertAfterMe.isVisibleToDeviceType(aDeviceType)) {
               return getLastPage(aDeviceType).getRegion(Direction.CENTER);
            }
         }
         return getLastPage(aDeviceType).getRegion(
            aRegionForInsertAfterMe.getName());
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the control from all pages in this dialog.
    * 
    * @return the list of device types that this control was removed from
    */
   public Collection removeControl(final Control control) {
      final Set devicesRemoved = new HashSet();
      for (Iterator i = Damask.getSupportedDeviceTypes().iterator(); i.hasNext(); ) {
         final DeviceType deviceType = (DeviceType)i.next();
         final PageRegion region = control.getPageRegion(deviceType);
         if (region != null) {
            region.remove(control);
            devicesRemoved.add(deviceType);
         }
      }
      return devicesRemoved;
   }

   //---------------------------------------------------------------------------
   
   /**
    * <p>Changes the page region of the specified control to the specified region,
    * for the specified region's device type.</p>
    * 
    * <p>The specified region cannot be null and must be within this dialog.</p>
    * 
    * <p>The control should already be visible to the specified region's
    * device type.</p>
    */
   public void changeControlPageRegion(final Control control,
      final PageRegion region) {
      
      DamaskUtils.checkValidArgument(region != null,
         "region parameter cannot be null");
      
      DamaskUtils.checkValidArgument(region.getPage().getDialog() == this,
         "region parameter " + region + " must be in this dialog, " + this);
      
      DamaskUtils.checkValidArgument(
         control.isVisibleToDeviceType(
            region.getDeviceType()),
            control + " must be visible to " + region.getDeviceType());
      
      control.getPageRegion(region.getDeviceType()).remove(control);
      region.add(control);
   }
   
   //---------------------------------------------------------------------------
   
   public Control getControlBefore(
         final PageRegion region,
         final DeviceType newControlDeviceType,
         final AffineTransform newControlTransform,
         final Rectangle2D newControlBounds) {
      
      final DeviceType regionDeviceType = region.getDeviceType();
      Control controlBefore = DamaskUtils.getControlBefore(
         regionDeviceType,
         region.getControls().iterator(),
         newControlDeviceType,
         newControlTransform,
         newControlBounds);
      
      // If the control before is null, but there are other previous pages
      // within this dialog, then find the "last" control within the
      // same region in the previousmost non-empty page. (We only check
      // if the region is the center region, since that is the only region
      // that can be different across split pages.)
      if ((controlBefore == null) && (region.getName() == Direction.CENTER)) {
         final Page page = region.getPage();
         final Dialog dialog = page.getDialog(); 
         for (int i = dialog.indexOf(page) - 1; i >= 0; i--) {
            final Page aPrevPage = dialog.getPage(regionDeviceType, i);
            final List/*<Control>*/ controls =
               DamaskUtils.getControlsInPositionOrder(
                  aPrevPage.getRegion(Direction.CENTER),
                  newControlDeviceType);
            if (!controls.isEmpty()) {
               controlBefore = (Control)controls.get(controls.size() - 1);
               break;
            }
         }
      }
      
      return controlBefore;
   }

   //===========================================================================
   
   /**
    * Adds the specified component group to this dialog.
    */
   public void addGroup(final ComponentGroup group) {
      groups.add(group);
      group.setDialog(this);
      fireElementAdded(group);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Removes the specified component group from this dialog.
    */
   public boolean removeGroup(final ComponentGroup group) {
      boolean wasDeleted = groups.remove(group);
      if (wasDeleted) { 
         group.setDialog(null);
         fireElementRemoved(group);
      }
      return wasDeleted;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns a list of component groups in this dialog.
    */
   public List/*<ComponentGroup>*/ getGroups() {
      return Collections.unmodifiableList(groups);
   }

   //===========================================================================
   
   /**
    * Returns what state the dialog is in, if the specified controls are in
    * the specified states, or -1 if the given controls and states do not
    * match any condition. The controls and states are in the given map.
    */
   public int getCondition(final Map/*<Control, Object>*/ controlStates) {
      // If there is only condition, return it.
      if (numConditions == 1) {
         return 0;
      }
      
      int result = -1;

      // For each condition...
      for (int condition = 0; condition < numConditions; condition++) {
         boolean match = true;
         for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
            final DeviceType deviceType = (DeviceType)i.next();
            for (Iterator j = getPages(deviceType).iterator(); j.hasNext(); ) {
               final Page page = (Page)j.next();
               for (Iterator k = page.getRegions().iterator(); k.hasNext(); ) {
                  final PageRegion region = (PageRegion)k.next();
                  for (Iterator m = region.getControls().iterator(); m.hasNext(); ) {
                     final Control control = (Control)m.next();
                     if (control.isStateSignificantForCondition(this, condition)) {
                        if (!control.getStateForCondition(this, condition)
                           .equals(controlStates.get(control))) {
                              
                           match = false;
                           break;
                        }
                     }
                  }
               }
            }
         }
         if (match) {
            result = condition;
            break;
         }
      }
      return result;
   }
   //---------------------------------------------------------------------------
   
   /**
    * Adds a condition to this page.
    */
   public void addCondition() {
      basicAddCondition(-1);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Adds a condition to this page at the specified index.
    */
   public void addCondition(final int index) {
      basicAddCondition(index);
   }

   //---------------------------------------------------------------------------
   
   private void basicAddCondition(final int index) {
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType deviceType = (DeviceType)i.next();
         for (Iterator j = getPages(deviceType).iterator(); j.hasNext(); ) {
            final Page page = (Page)j.next();
            for (Iterator k = page.getRegions().iterator(); k.hasNext(); ) {
               final PageRegion region = (PageRegion)k.next();
               for (Iterator m = region.getControls().iterator(); m.hasNext(); ) {
                  final Control control = (Control)m.next();
                  if (index == -1) {
                     control.addCondition(this);
                  }
                  else {
                     control.addCondition(this, index);
                  }
               }
            }
         }
      }
      numConditions++;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Removes the specified condition from this page.
    */
   public void removeCondition(final int index) {
      for (Iterator i = getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType deviceType = (DeviceType)i.next();
         for (Iterator j = getPages(deviceType).iterator(); j.hasNext(); ) {
            final Page page = (Page)j.next();
            for (Iterator k = page.getRegions().iterator(); k.hasNext(); ) {
               final PageRegion region = (PageRegion)k.next();
               for (Iterator m = region.getControls().iterator(); m.hasNext(); ) {
                  final Control control = (Control)m.next();
                  control.removeCondition(this, index);
               }
            }
         }
      }
      numConditions--;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the number of possible conditions that this page has.
    */
   public int getNumConditions() {
      return numConditions;
   }

   //---------------------------------------------------------------------------
   
   /**
    * Returns the condition that this dialog is initially in when it is first
    * rendered.
    */
   public int getInitialCondition() {
      return initialCondition;
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns the condition that this dialog is initially in when it is first
    * rendered.
    */
   public void setInitialCondition(final int condition) {
      DamaskUtils.checkValidArgument(
         (0 <= condition) && (condition < numConditions),
         "Initial condition must be from 0 up to but not including the number of conditions");
      initialCondition = condition;
      fireInitialConditionChanged(initialCondition);
   }
   
   //===========================================================================
   
   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public void addElementContainerListener(
      ElementContainerListener listener) {

      containerEventSource.addElementContainerListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public void removeElementContainerListener(
      ElementContainerListener listener) {

      containerEventSource.removeElementContainerListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementAdded events to listeners.
    */
   private void fireElementAdded(final int index, final Page p) {
      containerEventSource.fireElementAdded(this, p.getDeviceType(), index, p);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires elementRemoved events to listeners.
    */
   private void fireElementRemoved(final int index, final Page p) {
      containerEventSource.fireElementRemoved(
         this, p.getDeviceType(), index, p);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires elementAdded events to listeners.
    */
   private void fireElementAdded(final ComponentGroup group) {
      containerEventSource.fireElementAdded(
         this,
         DeviceType.ALL,
         ElementContainerEvent.UNKNOWN_INDEX,
         group);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires elementRemoved events to listeners.
    */
   private void fireElementRemoved(final ComponentGroup group) {
      containerEventSource.fireElementRemoved(
         this, DeviceType.ALL, ElementContainerEvent.UNKNOWN_INDEX, group);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires elementRemoved events to listeners.
    */
   private void fireInitialConditionChanged(final int newInitialCondition) {
      dialogEventSource.fireInitialConditionChanged(this, newInitialCondition);
   }
   
   //===========================================================================

   /**
    * Returns a clone of this object.
    */
   public Object clone() {
      final Dialog clone = (Dialog)super.clone();
      
      clone.containerEventSource = new ElementContainerSource();
      clone.dialogEventSource = new DialogEventSource();
      clone.pages = new DeviceDependentContainer();
      clone.groups = new ArrayList/*<ComponentGroup>*/();
      clone.numConditions = 0;
      
      clone.copy(this, deviceType, true);
      
      return clone;
   }
   
   //===========================================================================
   
   private void copy(final Dialog oldDialog, final DeviceType deviceType,
      final boolean toClone) {
      
      this.deviceType = deviceType;

      final Map/*<Component, Component>*/ copies =
         new HashMap/*<Component, Component>*/();
      
      // Add conditions
      for (int i = 0, n = oldDialog.getNumConditions(); i < n; i++) {
         addCondition();
      }
      setInitialCondition(oldDialog.getInitialCondition());
      
      // Copy the controls and page titles in the old dialog.
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         List/*<Page>*/ oldPages = oldDialog.getPages(aDeviceType);
         if (oldPages.isEmpty()) {
            oldPages = oldDialog.getPages(oldDialog.getDeviceType());
         }
         for (Iterator j = oldPages.iterator(); j.hasNext(); ) {
            final Page oldPage = (Page)j.next();
            
            // Copy the page titles
            final Content oldTitle = oldPage.getTitle();
            if (!copies.containsKey(oldTitle)) {
               final Content titleCopy;
               if (toClone) {
                  titleCopy = (Content)oldTitle.clone();
               }
               else {
                  titleCopy = (Content)oldTitle.createCopy(deviceType);
               }
               copies.put(oldTitle, titleCopy);
            }
            
            // Copy the controls
            for (Iterator k = oldPage.getRegions().iterator(); k.hasNext(); ) {
               final PageRegion oldRegion = (PageRegion)k.next();
               for (Iterator m = oldRegion.getControls().iterator();
                    m.hasNext(); ) {
                  final Control oldControl = (Control)m.next();
                  if (!copies.containsKey(oldControl)) {
                     final Control copy;
                     if (toClone) {
                        copy = (Control)oldControl.clone();
                     }
                     else {
                        copy = (Control)oldControl.createCopy(deviceType);
                     }
                     copies.put(oldControl, copy);
                  }
               }
            }
         }
      }
      
      // Create pages for each device.
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator();
         i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         List/*<Page>*/ oldPages = oldDialog.getPages(aDeviceType);
         if (oldPages.isEmpty()) {
            oldPages = oldDialog.getPages(oldDialog.getDeviceType());
         }
         for (Iterator j = oldPages.iterator(); j.hasNext(); ) {
            final Page oldPage = (Page)j.next();
            final Page newPage;
            if (toClone) {
               newPage = (Page)oldPage.clone(this, copies);
               newPage.setDialog(this);
            }
            else {
               newPage = new Page(aDeviceType, this, oldPage, copies);
            }
            basicAdd(newPage);
         }
         setBounds(aDeviceType, oldDialog.getBounds(aDeviceType));
         setTransform(aDeviceType, oldDialog.getTransform(aDeviceType));
      }

      // Copy the groups
      for (Iterator i = oldDialog.getGroups().iterator(); i.hasNext(); ) {
         final ComponentGroup oldGroup = (ComponentGroup)i.next();
         final ComponentGroup newGroup =
            (ComponentGroup)oldGroup.createCopy(deviceType);
         addGroup(newGroup);
         copies.put(oldGroup, newGroup);
      }

      for (Iterator i = oldDialog.getGroups().iterator(); i.hasNext(); ) {
         final ComponentGroup oldGroup = (ComponentGroup)i.next();
         final ComponentGroup newGroup =
            (ComponentGroup)oldGroup.createCopy(deviceType);
         for (Iterator j = oldGroup.getChildren().iterator(); j.hasNext(); ) {
            final Component oldChild = (Component)j.next();
            newGroup.add((Component)copies.get(oldChild));
         }
      }
   }
   
   //===========================================================================
   
   /**
    * Returns a string representation of this dialog, including the pages
    * for <em>all</em> devices.
    */
   public String toLongString() {
      final StringBuffer sb = new StringBuffer();
      
      sb.append(toString() + ":\n");
      sb.append(pages.toLongString());
      
      return sb.toString();
   }

   //---------------------------------------------------------------------------

   /**
    * Returns a string representation of this dialog, with the given indent
    * level and including the pages that support the given device.
    */
   public String toLongString(int indentLevel, final DeviceType deviceType) {
      // 1. Make sure we have a concrete device; "all" is not acceptable here.
      assert deviceType != DeviceType.ALL: "Device cannot be ALL";

      final StringBuffer sb = new StringBuffer();
      
      sb.append(StringLib.spaces(indentLevel * DamaskUtils.INDENT_SPACES));
      sb.append(toString());
      sb.append("\n");
      sb.append(pages.toString(indentLevel + 1, deviceType));

      return sb.toString();
   }

}
