package edu.berkeley.guir.damask.command;

import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that sets the voice prompt of a piece of content.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  01-04-2004 James Lin
 *                               Created EditContentCommand.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 01-04-2004
 */
public class SetVoicePromptTextCommand extends UndoableCommand
implements ModifyGraphCommand {

   private String oldText;
   private final String newText;
   private final Content content;
   
   /**
    * Constructs the command.
    *  
    * @param content the content to edit
    * @param newText the new text of the content
    */      
   public SetVoicePromptTextCommand(
      final Content content, final String newText) {
      
      this.content = content;
      this.newText = newText;
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Set voice prompt of content " + content + " to " + newText;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }

   // Overrides method in superclass.   
   public void run() {
      oldText = content.getVoicePromptText();
      content.setVoicePromptText(newText);
   }

   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      content.setVoicePromptText(oldText);
   }
}
