package edu.berkeley.guir.damask.view.voice.component;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.view.voice.ResponseInternalDest;
import edu.berkeley.guir.damask.view.voice.ResponseSource;

/** 
 * A view of a piece of content.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  mm-dd-yyyy James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public class VoiceContent extends VoiceControl
implements ResponseSource, ResponseInternalDest {

   /**
    * Constructs a view of the specified content.
    */
   public VoiceContent(final Content content) {
      super(content);
   }

   
   // @Override
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      final Prompt newPrompt = new Prompt(this);
      setPrompt(newPrompt);
   }


   // @Override
   public Point2D getAnchorPt() {
      return getPrompt().getBounds().getCenter2D();
   }


   // @Override
   public Rectangle2D getSourceBounds() {
      return getPrompt().getBounds();
   }


   // @Override
   public Rectangle2D getDestBounds() {
      return getPrompt().getBounds();
   }
}
