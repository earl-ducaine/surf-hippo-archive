//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection.graph;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.io.Serializable;

/**
 * A single Node in a Graph, as well as the adjacency list of inlinks
 * (what other Nodes are connected to this Node) and outlinks (what other
 * Nodes can we get to from this Node).
 * <P>
 * The inlink weight is the negative of the actual outlink weight. For
 * example, if the weight from A to B were 1, then from B to A is -1.
 * <P>
 * Assumes a simple Graph (one that does not have multiple edges between 
 * two nodes).
 * <P>
 * Also assumes that no two Nodes will have the same name. 
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - GUIRLib-v1.0/1.0.0, Nov 24 1997, JH
 *               Created class
 *             - GUIRLib-v1.0/1.1.0, Feb 24 2000, JH
 *               Updated for JDK1.3RC1 to use the Collections
 *             - GUIRLib-v1.4/1.1.1, Oct 07 2000, JH
 *               Changed addInLink() and addOutLink() from package to protected
 *             - GUIRLib-v1.5/1.2.0, Nov 22 2002, JH
 *               Modified for lazy instantiation of Maps
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A>)
 * @since   1.3RC1
 * @version GUIRLib-v1.5/1.2.0, Nov 22 2002
 */
public class GraphNode 
   implements Serializable, Cloneable {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //// An optimization, so that adjacent Nodes without a specified weight will
   //// point to the same object instead of multiple objects being created.
   //// This should be safe since Float objects cannot have their internal
   //// value modified.
   private final static Float DEFAULT_INLINK_WEIGHT = 
         new Float(-GraphConst.DEFAULT_WEIGHT);
   private final static Float DEFAULT_OUTLINK_WEIGHT = 
         new Float(GraphConst.DEFAULT_WEIGHT);

   //// 100% load factor on the hashtable, we need to save space!
   private final static float LOAD_FACTOR = 1.0f;

   //-----------------------------------------------------------------

   /**
    * A parser for GraphNodes.
    */
   public static final GraphNodeParser PARSER = 
                                             new GraphNodeParserDefaultImpl();

   //===   CONSTANTS   =========================================================
   //===========================================================================





   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   /**
    * The initial number of edges in the adjacency list.
    */
   private static int iNumEdges = GraphConst.DEFAULT_NUMBER_EDGES;

   /**
    * Print out the links or not in toString()?
    */
   private static boolean flagPrintLinks = true;

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================





   //===========================================================================
   //===   CLASS METHODS   =====================================================

   /**
    * Sets the default number of edges in the adjacency list of each Node.
    *
    * @param numEdges is the number of edges, and must be greater than the
    *        default number of edges. If it is less, then it will revert to
    *        the default number of edges. Ignores negative values.
    */
   public static void setDefaultNumberOfEdges(int numEdges) {
      if (iNumEdges > GraphConst.DEFAULT_NUMBER_EDGES) {
         iNumEdges = numEdges;
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Set the flag for whether or not method toString() should print out the
    * inlinks and outlinks for this Node.
    *
    * @param flag is true if the links should be printed, false otherwise.
    */
   public static void setPrintLinks(boolean flag) {
      flagPrintLinks = flag;
   } // of method

   //===   CLASS METHODS   =====================================================
   //===========================================================================





   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   /**
    * The name of this Node.
    */
   private String strName;

   /**
    * The Nodes you can get to from this Node.
    * The key for this map is the String name of the Node, and it
    * refers to the weight (Float) of the edge.
    * Lazily instantiated.
    */
   private HashMap mapOutlinks = null;

   /**
    * The Nodes that have edges to this Node.
    * The key for this map is the String name of the Node, and it
    * refers to the weight (Float) of the edge.
    * Lazily instantiated.
    */
   private HashMap mapInlinks = null;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================





   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates a new and empty Node. Used in the clone() method.
    */
   protected GraphNode() {
      //// 1. Use an empty name.
      this.strName = "";
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Create a new Node with the specified name.
    *
    * @param strName is the name of the Node to create an Adjacency list.
    */
   public GraphNode(String strName) {
      //// 1. Internalize the String name into Java's VM (hopefully saving
      ////    memory on duplicate String names).
      this.strName = strName.intern();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create the outlinks lazily.
    */
   private void initOutlinks() {
       if (mapOutlinks == null) {
           mapOutlinks = new HashMap(iNumEdges, LOAD_FACTOR);
       }
   } // of method


   /**
    * Create the inlinks lazily.
    */
   private void initInlinks() {
       if (mapInlinks == null) {
           mapInlinks = new HashMap(iNumEdges, LOAD_FACTOR);
       }
   } // of method

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================






   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Get the name of the source node.
    *
    * @return The source Node.
    */
   public String getName() {
       return (strName);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get an Iteration of the names of the Nodes you can get to from this 
    * Node (that is, the Nodes connected by outlinks from this Node).
    *
    * @return An Iterator of Strings containing the node names 
    *         connected by outgoing edges.
    */
   public Iterator getOutlinks() {
       //// 1.1. If no outlinks...
       if (mapOutlinks == null) {
           return (Collections.EMPTY_LIST.iterator());
       }
       //// 1.2. Otherwise return all outlinks.
       else {
           return(mapOutlinks.keySet().iterator());
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get an Iteration of the names of the Nodes that can get to this Node
    * (that is, the Nodes connected by inlinks into this Node).
    *
    * @return An Iterator of Strings containing the node names 
    *         connected by incoming edges.
    */
   public Iterator getInlinks() {
       //// 1.1. If no inlinks...
       if (mapInlinks == null) {
           return (Collections.EMPTY_LIST.iterator());
       }
       //// 1.2. Otherwise return all inlinks.
       else {
           return(mapInlinks.keySet().iterator());
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the number of edges that come out of this Node.
    *
    * @return An int containing the out degree of this Node.
    */
   public int getOutDegree() {
       //// 1.1. If no outlinks...
       if (mapOutlinks == null) {
           return (0);
       }
       //// 1.2. Otherwise return the size.
       else {
           return (mapOutlinks.size());
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the number of edges that come into this Node.
    *
    * @return An int containing the in degree of this Node.
    */
   public int getInDegree() {
       //// 1.1. If no inlinks...
       if (mapInlinks == null) {
           return (0);
       }
       //// 1.2. Otherwise return the size.
       else {
           return (mapInlinks.size());
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if the given node is adjacent to the source Node by an out link.
    *
    * @param strName is the name of the Node to check if it is connected.
    */
   public boolean hasOutlinkTo(String strName) {
       //// 1.1. If no outlinks...
       if (mapOutlinks == null) {
           return (false);
       }
       //// 1.2. Otherwise see if we contain it.
       else {
           return (mapOutlinks.containsKey(strName));
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if the given node is adjacent to the source Node by an out link.
    *
    * @param strName is the name of the Node to check if it is connected.
    */
   public boolean hasInlinkFrom(String strName) {
       //// 1.1. If no inlinks...
       if (mapInlinks == null) {
           return (false);
       }
       //// 1.2. Otherwise see if we contain it.
       else {
           return (mapInlinks.containsKey(strName));
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Return the weight of a Node connected by an out link. Use method 
    * hasOutlinkTo() first to see if the two Nodes are adjacent.
    *
    * @param  strName is the name of the Node to check for adjacency.
    * @return a float containing the weight between this Node and the
    *         specified Node, or NaN (not a number) if the two are not
    *         adjacent. 
    */
   public float getOutlinkWeight(String strName) {
       //// 1.1. If no outlinks...
       if (mapOutlinks == null) {
           return (Float.NaN);
       }

       //// 1.2. Otherwise see if there is an edge and a weight.
       Float weight = (Float) mapOutlinks.get(strName);
       if (weight == null) {
           return (Float.NaN);
       }
       else {
           return (weight.floatValue());
       }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Return the weight of a Node connected by an in link. Use method 
    * hasInlinkFrom() first to see if the two Nodes are adjacent.
    *
    * <P>
    * The inlink weight is the negative of the actual outlink weight. For
    * example, if the weight from A to B were 1, then from B to A is -1.
    *
    *
    * @param  strName is the name of the Node to check for adjacency.
    * @return a float containing the weight between this Node and the
    *         specified Node, or NaN (not a number) if the two are not
    *         adjacent. 
    */
   public float getInlinkWeight(String strName) {
       //// 1.1. If no inlinks...
       if (mapInlinks == null) {
           return (Float.NaN);
       }

       //// 1.2. Otherwise see if there is an edge and a weight.
       Float weight = (Float) mapInlinks.get(strName);
       if (weight == null) {
           return (Float.NaN);
       }
       else {
           return (weight.floatValue());
       }
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================






   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Set the name for this Node.
    *
    * @param strName is the name of the Node to set to.
    */
   public void setName(String strName) {
       this.strName = strName;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a Node connected to this Node by an out link. If the Node is already 
    * in here, it will be overwritten.
    *
    * <P>
    * The weight of the edge is defaulted to GraphConst.DEFAULT_WEIGHT.
    * Use this method if you don't really care about the weight of the edge.
    *
    * @param strNodeToName is the name of the adjacent Node.
    * @see   GraphConst
    */
   protected void addOutlink(String strNodeToName) {
       initOutlinks();
       mapOutlinks.put(strNodeToName.intern(), DEFAULT_OUTLINK_WEIGHT);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a Node connected to this Node by an out link. If the Node is already 
    * in here, it will be overwritten.
    *
    * @param strNodeToName is the adjacent Node to add.
    * @param weight        is the weight of this edge. weight can be negative.
    */
   protected void addOutlink(String strNodeToName, float weight) {
       initOutlinks();
       mapOutlinks.put(strNodeToName.intern(), new Float(weight));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a Node connected to this Node by an in link. If the Node is already 
    * in here, it will be overwritten.
    *
    * <P>
    * The weight of the edge is defaulted to GraphConst.DEFAULT_WEIGHT.
    * Use this method if you don't really care about the weight of the edge.
    *
    * @param strNodeToName is the name of the adjacent Node.
    * @see   GraphConst
    */
   protected void addInlink(String strNodeToName) {
       initInlinks();
       mapInlinks.put(strNodeToName.intern(), DEFAULT_INLINK_WEIGHT);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Add a Node connected to this Node by an in link. If the Node is already 
    * in here, it will be overwritten.
    *
    * <P>
    * The weight of this inlink should be the negative of the outlink. For
    * example, if the weight from A to B were 1, then from B to A is -1.
    *
    * @param strNodeToName is the adjacent Node to add.
    * @param weight        is the weight of this edge. weight can be negative.
    */
   protected void addInlink(String strNodeToName, float weight) {
       initInlinks();
       mapInlinks.put(strNodeToName.intern(), new Float(weight));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Remove a connection from the specified Node to this Node. If the Node 
    * was in the Adjacency list, it will be removed. If it was not in the 
    * Adjacency list, there will be no effect.
    *
    * @param strName is the name of the Node to remove.
    */
   void removeInlink(String strName) {
       //// 1.1. If no inlinks, ignore the call.
       if (mapInlinks == null) {
           return;
       }
       //// 1.2. Remove it.
       mapInlinks.remove(strName);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Remove a connection from this Node to the specified Node. If the Node 
    * was in the Adjacency list, it will be removed. If it was not in the 
    * Adjacency list, there will be no effect.
    *
    * @param strName is the name of the Node to remove.
    */
   void removeOutlink(String strName) {
       //// 1.1. If no outlinks, ignore the call.
       if (mapOutlinks == null) {
           return;
       }
       //// 1.2. Remove it.
       mapOutlinks.remove(strName);
   } // of method

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================






   //===========================================================================
   //===   TOSTRING   ==========================================================

   /**
    * Convert this object into some form of String.
    *
    * @return a String containing information about this object.
    */
   public String toString() {
      StringBuffer strbuf     = new StringBuffer();
      Iterator     itOut      = getOutlinks();
      Iterator     itIn       = getInlinks();
      Object       key;

      //// 1. Add the name of the source Node.
      strbuf.append(strName + "\n");

      //// 2. Print out the links or not? See setPrintLinks()
      if (flagPrintLinks == true) {

         //// 2.1. Enumerate over all of the outlinks and get the weights too
         strbuf.append(" " + getOutDegree() + " outlinks\n");
         while (itOut.hasNext()) {
            key = itOut.next();
            strbuf.append(" ( ");
            strbuf.append(getOutlinkWeight((String) key));
            strbuf.append(" ");
            strbuf.append(key);
            strbuf.append(" )\n");
         }

         //// 2.2. Enumerate over all of the inlinks and get the weights too
         strbuf.append(" " + getInDegree() + " inlinks\n");
         while (itIn.hasNext()) {
            key = itIn.next();
            strbuf.append(" ( ");
            strbuf.append(getInlinkWeight((String) key));
            strbuf.append(" ");
            strbuf.append(key);
            strbuf.append(" )\n");
         }
      }

      return (strbuf.toString());
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================






   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * Clones this Node.
    *
    * @return a Node object that has the same values as this Node object.
    */
   public Object clone() {
      //// 1. Create an empty Node.
      GraphNode cloned = new GraphNode();

      //// 2. Copy the name of the Node and internalize the String name.
      if (this.strName != null) {
         cloned.strName = this.strName.intern();
      }

      //// 3. Copy the outlinks and the inlinks.
      cloned.mapOutlinks = (HashMap) this.mapOutlinks.clone();
      cloned.mapInlinks  = (HashMap) this.mapInlinks.clone();

      //// 4. Return it.
      return(cloned);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================






   //===========================================================================
   //===   EQUALS   ============================================================

   /*
    * This method checks if a given object is the "same" as this one.
    * In this case, returns true if the source nodes are the same.
    *
    * @param obj is the Object to check for equality.
    */
   public boolean equals(Object obj) {
      if (obj instanceof GraphNode) {
         GraphNode temp = (GraphNode) obj;

         //// Check if the internals of _temp_ matches the internals
         //// of _this_ object
         if (strName.equals(temp.getName()))
            return (true);
      }

      return(false);
   } // of method

   //===   EQUALS   ============================================================
   //===========================================================================

   



   
   //===========================================================================
   //===   MAIN    =============================================================
/*
   //
   // Used for self-testing purposes.
   //
   public static void main(String[] argv) {

      Node a = new Node("AnNode");
      a.addInlink("First");
      a.addInlink("Second", 2);
      a.addInlink("Third", 3);
      a.addInlink("Second", 4);
      System.out.println(a);
      System.out.println();

      //// Test the cloning procedure
      Node b = (Node) a.clone();
      System.out.println(b);
      System.out.println();

      System.out.println(a == b);
      System.out.println(a.equals(b));

      a.removeInlink("First");
      System.out.println(a);
      System.out.println();

      System.out.println(b);
      System.out.println();


      a.removeInlink("Fourth");
      System.out.println(a);
      System.out.println();

      a.removeInlink("First");
      System.out.println(a);
      System.out.println();

      a.removeInlink("Third");
      System.out.println(a);
      System.out.println();

      a.removeInlink("Second");
      System.out.println(a);
      System.out.println();

      a.removeInlink("Fourth");
      System.out.println(a);
      System.out.println();

      a.addInlink("First");
      System.out.println(a);
      System.out.println();

   } // of main
*/
   //===   MAIN    =============================================================
   //===========================================================================

} // of Class Node

//==============================================================================

/*
Copyright (c) 2002 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
