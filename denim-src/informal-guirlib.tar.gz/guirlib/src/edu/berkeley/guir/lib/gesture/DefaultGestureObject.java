package edu.berkeley.guir.lib.gesture;

import java.beans.*;
import java.util.Observable;
import java.util.HashMap;
import java.util.Map;
import edu.berkeley.guir.lib.gesture.util.TokenReader;
import java.io.Writer;
import java.io.IOException;
import edu.berkeley.guir.lib.gesture.Properties;
import java.text.ParseException;

/** A default implementation of a GestureObject. */
public class DefaultGestureObject extends Observable
  implements GestureObject, Cloneable {
  protected String author = null;
  protected transient GestureContainer parent = null;
  protected Map properties = new HashMap();
  protected transient PropertyChangeSupport propChangeSupport =
    new PropertyChangeSupport(this);
  
  public DefaultGestureObject()
  {
    super();
  }

  public void setAuthor(String a)
  {
    if ((author != a) && (a != null) && !a.equals(author)) {
      String oldValue = author;
      author = (a == null) ? null : a.intern();
      propChangeSupport.firePropertyChange(AUTHOR_PROP, oldValue, author);
    }
  }
  
  public String getAuthor()
  {
    return author;
  }

  public void setParent(GestureContainer p)
  {
    if (p != parent) {
      GestureContainer oldValue = parent;
      parent = p;
      propChangeSupport.firePropertyChange(PARENT_PROP, oldValue, parent);
    }
  }
  
  public GestureContainer getParent()
  {
    return parent;
  }

  public void setEnabled(boolean on)
  {
    setProperty(ENABLED_PROP, new Boolean(on));
  }
  
  public boolean isEnabled()
  {
    return !hasProperty(ENABLED_PROP) ||
      ((Boolean) getProperty(ENABLED_PROP)).booleanValue();
  }

  public boolean hasProperty(String name)
  {
    return AUTHOR_PROP.equals(name) ||
      PARENT_PROP.equals(name) ||
      properties.containsKey(name);
  }
  
  public void setProperty(String name, Object value)
  {
    if (AUTHOR_PROP.equals(name)) {
      setAuthor((String) value);
    }
    else if (PARENT_PROP.equals(name)) {
      setParent((GestureContainer) value);
    }
    else {
      boolean preExisting = hasProperty(name);
      Object oldValue;
      if (preExisting) {
	oldValue = properties.get(name);
	if (oldValue == value) {
	  return;
	}
      }
      else {
	oldValue = null;
      }
      properties.put(name, value);
      propChangeSupport.firePropertyChange(name, oldValue, value);
    }
  }

  public void unsetProperty(String name)
  {
    if (AUTHOR_PROP.equals(name) || ENABLED_PROP.equals(name)
	|| PARENT_PROP.equals(name)) {
      throw new
	IllegalArgumentException("Cannot remove predefined property '" +
				 name + "'");
    }
    if (hasProperty(name)) {
      Object oldValue = getProperty(name);
      properties.remove(name);
      propChangeSupport.firePropertyChange(name, oldValue, null);
    }
  }
  
  public Object getProperty(String name)
  {
    if (AUTHOR_PROP.equals(name)) {
      return getAuthor();
    }
    else if (PARENT_PROP.equals(name)) {
      return getParent();
    }
    else {
      return properties.get(name);
    }
  }

  /** Deep-copies properties.  Note that a clone does not have a
      parent (since the parent doesn't have the clone as a child). */
  public Object clone()
  {
    try {
      // this will copy the scalar fields
      DefaultGestureObject result = (DefaultGestureObject) super.clone();
      // need to use the deepCopy from Properties so we only copy
      // persistent props
      result.properties = Properties.deepCopy(properties);
      result.propChangeSupport = new PropertyChangeSupport(result);
      result.parent = null;
      return result;
    }
    catch (CloneNotSupportedException e) {
      return null;
    }
  }

  public void readProperties(TokenReader reader)
    throws IOException, ParseException
  {
    properties = Properties.readProperties(reader);
  }
  
  public void writeProperties(Writer writer)
    throws IOException
  {
    Properties.writeProperties(writer, properties);
  }

  public void addPropertyChangeListener(PropertyChangeListener listener)
  {
    propChangeSupport.addPropertyChangeListener(listener);
  }

  public void addPropertyChangeListener(String propertyName,
					PropertyChangeListener listener)
  {
    propChangeSupport.addPropertyChangeListener(propertyName, listener);
  }

  public void removePropertyChangeListener(PropertyChangeListener listener)
  {
    propChangeSupport.removePropertyChangeListener(listener);
  }

  public void removePropertyChangeListener(String propertyName,
					   PropertyChangeListener listener)
  {
    propChangeSupport.removePropertyChangeListener(propertyName, listener);
  }
}
