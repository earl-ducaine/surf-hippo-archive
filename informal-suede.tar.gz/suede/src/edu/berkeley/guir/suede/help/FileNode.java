package edu.berkeley.guir.suede.help;

import java.io.File;
import javax.swing.tree.*;

class FileNode extends DefaultMutableTreeNode {
	private boolean explored = false;

	public FileNode(File file) 	{ 
		setUserObject(new SelectableFile(file)); 
	}
	public boolean getAllowsChildren() { return isDirectory(); }
	public boolean isLeaf() 	{ return !isDirectory(); }

	public File getFile() { 
		SelectableFile sf = (SelectableFile)getUserObject(); 
		return sf.getFile();
	}
	public boolean isSelected() {
		SelectableFile sf = (SelectableFile)getUserObject(); 
		return sf.isSelected();
	}
	public void setSelected(boolean b) {
		SelectableFile sf = (SelectableFile)getUserObject(); 
		sf.setSelected(b);
	}
	public boolean isDirectory() {
		File file = getFile();
		return file.isDirectory();
	}
	public String toString() {
		File file = getFile();
		String filename = file.toString();
		int index = filename.lastIndexOf("\\");

		return (index != -1 && index != filename.length()-1) ? 
                        filename.substring(index+1) : 
                        filename;
	}
        
        public String toDirectoryName() {
            File file = getFile();
            return file.toString();
        }
        
	public void explore() 		{ explore(false); }
	public boolean isExplored() { return explored; }

	public void explore(boolean force) {
		if(!isExplored() || force) {
			File file = getFile();
			File[] children = file.listFiles();

			for(int i=0; i < children.length; ++i) 
				add(new FileNode(children[i]));

			explored = true;
		}
	}
}