//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import edu.berkeley.guir.lib.satin.*;

/**
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jun 20 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.0.0, May,29 2003  YL
 *               deepClone hack can't work sometimes, i.e. on Mac
 *               Solved it by creating new components from scratch
 * 
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 *
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, May,29 2003
 */
public class GObJComponentWrapper
   extends GraphicalObjectImpl implements SatinConstants {

   //===========================================================================
   //===   CLASS METHODS AND VARIABLES   =======================================

   static final long serialVersionUID = 7308133840977774017L;
 
   //===   CLASS METHODS AND VARIABLES   =======================================
   //===========================================================================
 

   //===========================================================================
   //===   CONSISTENCY LISTENER INNER CLASS   ==================================

   class ConsistencyListener
      extends ComponentAdapter {

      public void componentMoved(ComponentEvent evt) {
         Rectangle rect = component.getBounds();
         setBoundingPoints2D(COORD_REL, rect);
      } // of componentMoved

      public void componentResized(ComponentEvent evt) {
         Rectangle rect = component.getBounds();
         setBoundingPoints2D(COORD_REL, rect);
      } // of componentMoved

   } // of ConsistencyListener
   
   //===   CONSISTENCY LISTENER INNER CLASS   ==================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   JComponent        component;
   ComponentListener lstnr;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public GObJComponentWrapper(JComponent newComponent) {
      setComponent(newComponent);
      /*
      if (component != null) {
         addKeyListener(new InternalKeyListener());
      }
      */
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   COMPONENT ACCESSOR METHODS   ========================================

   /**
    * Returns the JComponent in this wrapper
    */
   public JComponent getComponent() {
      return (component);
   } // of getComponent


   //=================================================================
   
   /**
    * Set the JComponent inside this wrapper
    */
   public void setComponent(JComponent comp) {
      if (comp == null) {
         return;
      }
      //// 1. Clear out old component dependencies.
      if (component != null) {
         component.removeComponentListener(lstnr);
      }

      //// 2. Set the component.
      component = comp;

      //// 2.1. If the component is a JTextArea, clip the bounds so that
      ////      it just fits the text.
      Dimension dim        = comp.getSize();
      int       compWidth  = dim.width;
      int       compHeight = dim.height;

      if (comp instanceof JTextArea) {
         String text = ((JTextArea)comp).getText();
         int width = 0;
         int height = 0;
         JLabel label = new JLabel();
         label.setFont(comp.getFont());
         
         //// 2.2. If the text has \n, make an HTML text and replace
         ////      all \n with <br>
         if (text.indexOf('\n') != -1) {
            StringTokenizer tok = new StringTokenizer(text, "\n\r\f");
            while (tok.hasMoreTokens()) {
               label.setText(tok.nextToken());
               Dimension size = label.getPreferredSize();
               if (size.width > width) {
                  width = size.width;
               }
               height += size.height;
            }
         }
         else {
            label.setText(text);
            width = label.getPreferredSize().width;
            height = label.getPreferredSize().height;
         }
         compWidth = (int)(width * 1.1);
         compHeight = (int)(height * 1.1);
      }
      else if (comp instanceof JLabel) {
         compWidth = (int)(comp.getPreferredSize().width * 1.1);
         compHeight = (int)(comp.getPreferredSize().height * 1.1);
      }
      
      //// 3. Set the size.
      component.setBounds(0, 0, compWidth, compHeight);
      setBoundingPoints2D(COORD_REL, component.getBounds());
      lstnr = new ConsistencyListener();
      component.addComponentListener(lstnr);
   } // of setComponent

   //===   COMPONENT ACCESSOR METHODS   ========================================
   //===========================================================================


   //===========================================================================
   //===   GRAPHICALOBJECT METHODS   ===========================================
   
   public void initAfterAddToSheet() {
      super.initAfterAddToSheet();
      getSheet().addToSwingWrapper(this);
   }
   
   //=================================================================
   
   public void delete() {
      getSheet().deleteFromSwingWrapper(this);
      super.delete();
   }
   
   //===   GRAPHICALOBJECT METHODS   ===========================================
   //===========================================================================

   
   //===========================================================================
   //===   DISPATCHING METHODS   ===============================================

   public void handleMouseEvent(MouseEvent oldEvt) {
      Debug.println("mouse event for " + component.toString() + " " + component.getX() + " " + component.getY());
      Debug.println("mouse event for " + oldEvt.paramString());

      int newX, newY;
      newX = oldEvt.getX()-component.getX();
      newY = oldEvt.getY()-component.getY();

      Component deepComponent = component.findComponentAt(newX,newY);

      //// get the coordinate location right
      Point p1 = component.getLocationOnScreen();
      Point p2 = deepComponent.getLocationOnScreen();

      newX -= p2.x-p1.x;
      newY -= p2.y-p1.y;
      
      Debug.println("mouse event for " + deepComponent.toString());

      MouseEvent mouseEvt;
      //// make sure we go all the way down the hierarchy
      mouseEvt = new MouseEvent(deepComponent, MouseEvent.MOUSE_PRESSED,
      oldEvt.getWhen(), oldEvt.getModifiers(), newX, newY,
      oldEvt.getClickCount(), oldEvt.isPopupTrigger());

      Debug.println("mouse event for " + mouseEvt.paramString());
      //cmdsubsys.postEvent(mouseEvt);
      deepComponent.dispatchEvent(mouseEvt);

      mouseEvt = new MouseEvent(deepComponent, MouseEvent.MOUSE_RELEASED,
      oldEvt.getWhen(), oldEvt.getModifiers(), newX, newY,
      oldEvt.getClickCount(), oldEvt.isPopupTrigger());
      Debug.println("mouse event for " + mouseEvt.paramString());
      //cmdsubsys.postEvent(mouseEvt);
      deepComponent.dispatchEvent(mouseEvt);


      mouseEvt = new MouseEvent(deepComponent, MouseEvent.MOUSE_CLICKED,
      oldEvt.getWhen(), oldEvt.getModifiers(), newX, newY,
      oldEvt.getClickCount(), oldEvt.isPopupTrigger());
      Debug.println("mouse event for " + mouseEvt.paramString());
      //cmdsubsys.postEvent(mouseEvt);
      deepComponent.dispatchEvent(mouseEvt);




      /*MouseEvent mouseEvt = new MouseEvent(component, oldEvt.getID(),
      oldEvt.getWhen(), oldEvt.getModifiers(), oldEvt.getX(), oldEvt.getY(),
      oldEvt.getClickCount(), oldEvt.isPopupTrigger());
      */
      //FocusEvent focusEvt = new FocusEvent(component, FocusEvent.FOCUS_GAINED);



      //component.dispatchEvent(focusEvt);
      //component.dispatchEvent(mouseEvt);

      //cmdsubsys.postEvent(mouseEvt);
      //cmdsubsys.postEvent(focusEvt);

      damage(DAMAGE_LATER);
   } // of handleMouseEvent

   //===========================================================================

   public void handleNewStroke(NewStrokeEvent evt) {
      handleMouseEvent((MouseEvent) evt.getMouseEvent());
   } // of handleNewStroke

   //===========================================================================

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      handleMouseEvent((MouseEvent) evt.getMouseEvent());
   } // of handleUpdateStroke

   //===========================================================================

   public void handleSingleStroke(SingleStrokeEvent evt) {
      handleMouseEvent((MouseEvent) evt.getMouseEvent());
      evt.setConsumed();
   } // of handleSingleStroke

   //===   DISPATCHING METHODS   ===============================================
   //===========================================================================


   //===========================================================================
   //===   KEY LISTENER METHODS   ==============================================
   
   public void keyEventDispatcher(KeyEvent evt) {

      Debug.println("key event for " + component.toString());

      component.dispatchEvent(evt);
      //this.damage(SatinConstants.DAMAGE_NOW);
   }
   
   //===   KEY LISTENER METHODS   ==============================================
   //===========================================================================

   //===========================================================================
   //===   RENDERING   =========================================================

   protected void defaultRender(SatinGraphics g) {
      //// 1. Paint the component.
      component.paint(g);
      component.update(g);
   } // of defaultRender

   //===   RENDERING   =========================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toDebugString() {
      //// A. Acquire soft-state.
      StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

      //// 1. Append data.
      strbuf.append(super.toDebugString() + "\n");
      strbuf.append("Component:      " + component.toString());

      //// B. Release soft-state.
      String str = strbuf.toString();
      poolStrbuf.releaseObject(strbuf);

      return (str);
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================


   //===========================================================================
   //===   CLONE   =============================================================
   
   public Object clone() {
      return deepClone(new GObJComponentWrapper(null));
   }
   
   //=================================================================
   
   protected Object deepClone(GObJComponentWrapper cloneTarget) {
      //1. Clone all of the state in the current GraphicalObject into the passed 
      //GraphicalObject
      super.deepClone(cloneTarget);
      
      if(component instanceof JTextArea)
      {
         return cloneTarget;
      }
      
      //2.clone the Jcomponent.  This is a serialization hack.
      try {
         ByteArrayOutputStream out = new ByteArrayOutputStream();
         ObjectOutput os = new ObjectOutputStream(out);
         os.writeObject(component);
         os.flush();
         out.close();
         
         ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
         ObjectInputStream is = new ObjectInputStream(in);
         cloneTarget.component = (JComponent)is.readObject();
         in.close();
         
         /*
         FileOutputStream out = new FileOutputStream("tmp");
         ObjectOutput os = new ObjectOutputStream(out);
         os.writeObject(component);
         os.flush();
         out.close();
         
         FileInputStream in = new FileInputStream("tmp");
         ObjectInputStream is = new ObjectInputStream(in);
         cloneTarget.component = (JComponent)is.readObject();
         in.close();
         */
      }catch (Exception exp) {
         System.out.println("Serialization hack for GobJComponentWrapper::deepClone failed -- "+exp.toString());
         if(component instanceof JTextField)
         {
            System.out.println("create a new JTextField instead");
            JTextField newtext = new JTextField();
            newtext.setBounds(0,0,100,30);
            newtext.setBorder(BorderFactory.createTitledBorder(""));
            newtext.setVisible(true);
            cloneTarget.component = newtext;
         }
      }
      return (cloneTarget);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

   
   //===========================================================================
   //===   SELF-TESTING MAIN   =================================================
/*
   public static void main(String[] argv) {
   } // of main
*/
   //===   SELF-TESTING MAIN   =================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
