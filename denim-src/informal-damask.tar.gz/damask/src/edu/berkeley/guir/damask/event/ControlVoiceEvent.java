package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.component.Control;

/** 
 * An event that indicates a change to a control.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-01-2004 James Lin
 *                               Created ControlEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-01-2004
 */
public class ControlVoiceEvent extends EventObject {
   public static final int ALL_CONDITIONS = -1;
   
   private final Type eventType;
   private final int condition;
   
   //===========================================================================

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type PROMPT_TEXT_CHANGED =
      new Type("text of prompt changed");
   public static final Type PROMPT_BOUNDS_CHANGED =
      new Type("bounds of prompt changed");
   public static final Type RESPONSE_SOURCE_CHANGED =
      new Type("source of response changed");
   public static final Type RESPONSE_DEST_CHANGED =
      new Type("destination of response changed");
   public static final Type RESPONSE_LINE_CHANGED =
      new Type("line of response changed");
   public static final Type RESPONSE_TEXT_CHANGED =
      new Type("text of response changed");

   //===========================================================================

   /**
    * Constructs a ControlVoiceEvent.
    * 
    * @param source the control that is affected
    */
   public ControlVoiceEvent(
      final InteractionElement source,
      final Type eventType,
      final int condition) {

      super(source);
      this.eventType = eventType;
      this.condition = condition;
   }
   
   //===========================================================================

   /**
    * Returns the originator of the event.
    * 
    * @return the Control object that originated the event, or
    * null if the object is not a Control.
    */
   public Control getControl() {
      if (source instanceof Control) {
         return (Control)source;
      }
      else {
         return null;
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the condition that this event is for.
    */
   public int getCondition() {
      return condition;
   }
}
