/*
 * Created on Sep 13, 2003
 */
package edu.berkeley.guir.lib.util;

import java.util.*;

/**
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.</p>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~srk">Scott Klemmer</a> ( srk(AT)cs.berkeley.edu )
 */
public class ListHashMap extends HashMap {
	private final SetList keys = new SetList();

	public Set keySet() {
		return keys;
	}

	/**
	 * @return the key at position index
	 */
	public Object getKey(final int index) {
		return keys.get(index);
	}

	/**
	 * @return the value at position index
	 */
	public Object getValue(final int index) {
		return super.get(keys.get(index));
	}

	/**
	 * puts the (key, value) pair in the table, and appends the key to the end of the list
	 */
	public Object put(final Object key, final Object value) {
		//1. If the key exists in the set, remove it
		keys.remove(key);

		//2. Re-add at the end
		keys.add(key);
		return super.put(key, value);
	}

	/**
	 * puts the (key, value) pair in the table, and adds the key to the specified index
	 */
	public Object putAt(final int index, final Object key, final Object value) {
		//1. If the key exists in the set, remove it
		keys.remove(key);

		//2. Re-add at the beginning
		keys.add(index, key);
		return super.put(key, value);
	}

	public Object remove(final Object key) {
		keys.remove(key);
		return super.remove(key);
	}

	public int size() {
		return keys.size();
	}

	/**
	 * Searches for the first occurence of the given argument, testing 
	 * for equality using the <tt>equals</tt> method. 
	 *
	 * @param   key   a key in the map.
	 * @return  the index of the key in this map; returns <tt>-1</tt> if the
	 * object is not found.
	 * @see     Object#equals(Object)
	 */
	public int indexOf(final Object key) {
		return keys.indexOf(key);
	}
	
	public class SetList extends ArrayList implements Set {}
}
