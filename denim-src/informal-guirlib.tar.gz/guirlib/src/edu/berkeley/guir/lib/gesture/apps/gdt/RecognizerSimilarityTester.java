package edu.berkeley.guir.lib.gesture.apps.gdt;

import edu.berkeley.guir.lib.gesture.*;
import java.util.*;

public class RecognizerSimilarityTester implements TaskManager.NoticeTask {
  /** the distance below which to issue a warning */
  private static final double DISTANCE_THRESHOLD = 8.0;
  /** the square of the distance below which to issue a warning */
  private static final double DISTANCE_SQ_THRESHOLD =
    DISTANCE_THRESHOLD * DISTANCE_THRESHOLD;
  private MainFrame mainFrame;

  public RecognizerSimilarityTester(MainFrame mf)
  {
    mainFrame = mf;
  }
  
  public Set computeNotices() throws InterruptedException
  {
    Set result = new HashSet();
    Classifier classifier = mainFrame.getClassifier();
    GesturePackage pkg = mainFrame.getGesturePackage();
    if ((classifier != null) && (pkg != null)) {
      GestureSet trainingSet = pkg.getTrainingSet();
      if (trainingSet != null) {
	try {
	  classifier.train();
	}
	catch (TrainingException e) {
	  return result;
	}
	List trainingCategories = classifier.getTrainingCategories();
	int numCats = trainingCategories.size();
	for (int i = 0; i < numCats; i++) {
	  GestureCategory catA = null;
	  for (int j = 0; j < i; j++) {
	    double dist = classifier.categoryDistance(i, j);
	    if (dist <= DISTANCE_SQ_THRESHOLD) {
	      if (catA == null) {
		catA = (GestureCategory) trainingCategories.get(i);
	      }
	      GestureCategory catB = (GestureCategory)
		trainingCategories.get(j);
	      List outliers =
		findOutlierCategories(trainingCategories, i, j, dist);
	      if (outliers.size() > 0) {
		result.add(new OutlierNotice(mainFrame, outliers,
					     catA, catB));
	      }
	      else {
		Classifier.FeatureDirection fd =
		  classifier.findPrincipleFeature(i, j);
		result.add(new RecognizerSimilarityNotice(mainFrame,
							  catA, catB,
							  fd.featureClass,
							  fd.direction)); 
	      }
	    }
	    if (Thread.interrupted()) {
	      throw new InterruptedException();
	    }
	  }
	}
      }
    }
    return result;
  }

  public List findOutlierCategories(List originalCategories,
				    int indexA, int indexB,
				    double oldDistance)
    throws InterruptedException
  {
    List result = new ArrayList();
    GestureSet trainingSet = new ShadowGestureSet(originalCategories);
    int numCategories = originalCategories.size();
    GestureCategory catA = (GestureCategory) originalCategories.get(indexA);
    GestureCategory catB = (GestureCategory) originalCategories.get(indexB);
    for (int i = 0; i < numCategories; i++) {
      if ((i != indexA) && (i != indexB)) {
	GestureCategory possibleOutlier = (GestureCategory)
	  originalCategories.get(i);
	trainingSet.remove(possibleOutlier);
	try {
	  Classifier classifier = new Classifier(trainingSet);
	  try {
	    classifier.train();
	  }
	  catch (TrainingException e) {
	    // can't train, so move on to next candidate outlier
	    continue;
	  }
	  // check new distance
	  double newDistance = classifier.categoryDistance(catA, catB);
	  // could just check new distance vs. threshold, but don't
	  // want to flag something as an outlier if it only improves
	  // the distance by a small amount
	  if ((newDistance > DISTANCE_SQ_THRESHOLD) &&
	      (newDistance > 2 * oldDistance)){
	    /*
	    System.out.println("RST: " + catA + "\t" + catB + "\t" +
			       oldDistance + "\t" + newDistance);
	    */
	    result.add(possibleOutlier);
	  }
	}
	finally {
	  trainingSet.add(possibleOutlier);
	}
	if (Thread.interrupted()) {
	  throw new InterruptedException();
	}      
      }
    }
    return result;
  }
}

