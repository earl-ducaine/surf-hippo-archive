package edu.berkeley.guir.lib.gesture.util;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Blink on and off at a set rate. */
public class Blinker extends JComponent implements ActionListener {
  protected Color onColor = Color.green;
  protected Color offColor = Color.black;
  private boolean isOn = false;
  private Timer timer;
  
  public Blinker()
  {
    timer = new Timer(2000, this);
    timer.start();
  }

  public Color getOnColor()
  {
    return onColor;
  }
  
  public void setOnColor(Color color)
  {
    if (onColor != color) {
      onColor = color;
      if (isOn) {
	repaint();
      }
    }
  }

  public Color getOffColor()
  {
    return offColor;
  }
  
  public void setOffColor(Color color)
  {
    if (offColor != color) {
      offColor = color;
      if (!isOn) {
	repaint();
      }
    }
  }

  public boolean isOn()
  {
    return isOn;
  }

  public void setOn(boolean on)
  {
    if (on != isOn) {
      isOn = on;
      repaint();
    }
  }

  public void toggle()
  {
    setOn(!isOn());
  }

  public void actionPerformed(ActionEvent e)
  {
    toggle();
  }

  protected void paintComponent(Graphics oldGraphics)
  {
    Graphics g = oldGraphics.create();
    g.setColor(isOn ? onColor : offColor);
    Dimension size = awt.sizeWithInsets(g, this);
    
    g.fillOval(0, 0, size.width, size.height);
  }
}
