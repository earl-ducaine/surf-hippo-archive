package edu.berkeley.guir.suede;

import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.*;

/*
 * This is the view for a single script node in design view
 * this class is extended to provide different functionality in test and analysis modes with TranscriptNodeView
 */
public abstract class AbstScriptNodeView extends javax.swing.JPanel implements ElementViewInter {
	public    static final int    WIDTH           = 160;
	public    static final int    HEIGHT          = 50;

	public    static final Color  SYSTEM_FILL     = new Color(255,234,166);
	public    static final Color  RESPONSE_FILL   = new Color(205,255,191);
	private   static final Color  SYSTEM_STROKE   = new Color(186,125,0);
	private   static final Color  RESPONSE_STROKE = new Color(19,142,52);
	private   static final int    BUTTON_WIDTH    = 20;
	    
	private   boolean             m_system; // whether this is a system prompt or a user prompt
	private   PlayButton          m_playButton;
	protected RecordButton        m_recordButton;
	private   SSlider             m_slider;
	private   AbstScriptNodeModel m_nodeModel;
	protected JTextField          m_text       = new JTextField();
	private   boolean             m_isPlayable = false;
	    
	//HV Oct1703
	private   ScriptNodeMouseListener  mouseListener = new ScriptNodeMouseListener();
	    
	public AbstScriptNodeView(boolean sys, AbstScriptNodeModel model) {
	setLayout(null);
	setSize(getPreferredSize());
	setCardType(sys);

	m_nodeModel = model;

		m_playButton = new PlayButton(false, getForeground());
	m_playButton.setBounds(getWidth() - BUTTON_WIDTH, HEIGHT/2, BUTTON_WIDTH, HEIGHT/2);
	add(m_playButton);
	        
	m_recordButton = new RecordButton(Color.black, getForeground());
	m_recordButton.setBounds(getWidth() - 2*BUTTON_WIDTH, HEIGHT/2, BUTTON_WIDTH, HEIGHT/2);
	add(m_recordButton);
	        
	m_slider = new SSlider(getForeground()); // this will be either system or response stroke color
	m_slider.setBounds(0, HEIGHT/2, getWidth() - 2*BUTTON_WIDTH, HEIGHT/2);
	add(m_slider);

	m_text.setBounds(AbstNodeView.STROKE_WIDTH, AbstNodeView.STROKE_WIDTH, 
					   getWidth() - 2*AbstNodeView.STROKE_WIDTH, HEIGHT/2 - AbstNodeView.STROKE_WIDTH);
		m_text.setBorder(new LineBorder(Color.white, 3));
		m_text.setText("");
		add(m_text);
		setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
		
	//HV Oct1703
	addMouseListener(mouseListener);
	addMouseMotionListener(mouseListener); 
	}
    

	public void setPlayable(boolean b) {
	   m_playButton.setPlayable(b);
	   if (!b && m_isPlayable) m_nodeModel.removePlayListener(m_playButton);
	   if (b && !m_isPlayable) m_nodeModel.addPlayListener(m_playButton);
	   m_isPlayable = b;
	}


	public void setAudioDuration(double seconds) {
		setTotalTime(seconds);
		repaint();
	}
    
    
	public Dimension getMinimumSize() {
		return new Dimension(WIDTH, HEIGHT);
	}
    
    
	public Dimension getPreferredSize() {
		return getMinimumSize();
	}
    
    
	public Dimension getMaximumSize() {
		return getMinimumSize();
	}
    
    
	public boolean getCardType() {
		return m_system;
	}
  
  
  public void setCardType(boolean cardtype) {
	m_system = cardtype;
	setBackground((m_system) ? SYSTEM_FILL   : RESPONSE_FILL  );
	setForeground((m_system) ? SYSTEM_STROKE : RESPONSE_STROKE);
	setBorder(new LineBorder(getForeground(), AbstNodeView.STROKE_WIDTH));
	if (m_slider!=null) m_slider.setActiveColor(getForeground());
	if (m_playButton!=null) m_playButton.setPauseColor(getForeground());
	if (m_recordButton!=null) m_recordButton.setPauseColor(getForeground());
	repaint();
  }
    
    
   /*public void setPercentage(double p) {
	 m_slider.setPercent(p);    
   }*/
   
   
   public void setTotalTime(double t) {
	  m_slider.setTotalTime(t);
   }
   
   
   public void setCurTime(double t) {
	   m_slider.setCurTime(t);  
   }
    
    
	// clickPlay is called by the test system
	/*public void clickPlay() {
		m_playButton.doClick(); 
	}
    
    
	public void clickRecord() {
		m_recordButton.doClick(); 
	}*/
    
    
	public boolean isPlaying() {
	  return !m_playButton.isSelected();
	}
    
	public boolean isRecording() {
	  return !m_recordButton.isSelected();
	}
    
	public void setStopped() {
	  m_recordButton.setSelected(false);
	  m_playButton.setSelected(false);
	  m_slider.setStopped();
	}
    
	public void setRecording() {
	  m_recordButton.setSelected(true);
	  m_playButton.setSelected(false);
	  m_slider.setRecording();
	}
    
	public void setPlaying() {
	  m_recordButton.setSelected(false);
	  m_playButton.setSelected(true);
	}
    
	public void setPaused() {
	  m_recordButton.setSelected(false);
	  m_playButton.setSelected(false);
	}
    
	public String getCaption() {
	  return m_text.getText();
	}
    
	public void setCaption(String caption) {
	  m_text.setText(caption);      
	}
    
	public boolean isSystemPrompt() {
		return m_system;   
	}
    
    
	public AbstScriptNodeModel getNodeModel() {
		return m_nodeModel;   
	}
    
    
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(getForeground());
		g.drawLine(getWidth() - 2*BUTTON_WIDTH, HEIGHT/2,getWidth() - 2*BUTTON_WIDTH, HEIGHT);
		g.drawLine(getWidth() - BUTTON_WIDTH, HEIGHT/2,getWidth() - BUTTON_WIDTH, HEIGHT);
		g.drawLine(0, HEIGHT/2, WIDTH, HEIGHT/2);
        
	}
    
	////////////////////////Hongvan's code////////////////////////////////
	public JTextField getTextField() {
		return m_text;
	}
	//HV Oct1703
//	left for subclasses to handle
	//public void handleMouseReleased () {}

   // left for subclasses to handle
   public void handleMouseDragged () {}
 
//   public void handleMousePressed (MouseEvent e){
//   }
   
	public class ScriptNodeMouseListener extends MouseAdapter implements MouseMotionListener {
		//private boolean mouseExited = false;
		//private boolean linkGesture = false;
		//private boolean drag_motion = false;
		//private JComponent feedback;
		//private boolean opAllowed = true;

		public void mouseClicked(MouseEvent e) {//doing nothing
		}
    
    
//		public void mousePressed(MouseEvent e){
//		  Point p = e.getPoint();
//		  //SContentPane pane = getParent();
//		  Container pane = getParent();
//		  javax.swing.SwingUtilities.convertPointToScreen(p, e.getComponent());
//		  //opAllowed = m_nodeModel.isOperable(p);
//		  javax.swing.SwingUtilities.convertPointFromScreen(p, pane);
//		  //mouseDownPoint = p;
//		  //pressLocationX    = AbstNodeView.this.getX();
//		  //pressLocationY    = AbstNodeView.this.getY();
//		  //mouseExited       = false;
//		  if (SwingUtilities.isLeftMouseButton(e)) {
//			handleMousePressed(e);
//		  } 
//		}//end of mousePressed

		public void mouseReleased(MouseEvent e){
		/*	SContentPane pane = (m_nodemodel.getSuedeModel()).getContentPane();
			if (feedback!=null)
				pane.remove(feedback);
			Point p = e.getPoint();
			javax.swing.SwingUtilities.convertPointToScreen(p, e.getComponent());
			javax.swing.SwingUtilities.convertPointFromScreen(p, pane);
			Component target = pane.getComponentAt(p);
			if(opAllowed) {
				if ((mouseExited)&&(SwingUtilities.isLeftMouseButton(e))
					&& ((Math.sqrt((p.y-mouseDownPoint.y)*(p.y-mouseDownPoint.y)
					+(p.x-mouseDownPoint.x)*(p.x-mouseDownPoint.x)))>=LINK_THRESHOLD)) {
					if ((target instanceof AbstNodeView) && !(target instanceof StartNodeView)) {
						AbstNodeView targetNode = (AbstNodeView)target;
						(m_nodemodel.getSuedeModel()).addLink((SFeedbackLink)feedback);
               
					} else  {            
						if (!(m_nodemodel instanceof StartNodeModel)) {
							(m_nodemodel.getSuedeModel()).addLink((SFeedbackLink)feedback);
						}
              
					}
					pane.repaint();
				}
				else if(SwingUtilities.isLeftMouseButton(e)) {
					if((p.y-mouseDownPoint.y)>RESIZE_THRESHOLD) {
						m_nodemodel.expand();
					}
					else if((p.y - mouseDownPoint.y)<-RESIZE_THRESHOLD) {
						m_nodemodel.collapse();
					}
					else {}
					pane.repaint();
				}
				//handling pop up menu for copy/cut/paste
				else if (SwingUtilities.isRightMouseButton(e) && mouseExited == false) {
					mouseEvent = e;
					//HV Oct1703
					if (!drag_motion)
						handleMousePressed (e);
					else {//pop up menu won't be shown	
						drag_motion = false;
					}
				}
				else  {
					target = pane.getGroupAt(p);
					//pane.add(SAbstractNodeView.this, SContentPane.NODE_LAYER);
					handleMouseReleased(target);
				}
			}*/
		}
    
		public void mouseDragged(MouseEvent e) {
			if (SwingUtilities.isLeftMouseButton(e)) {
				handleMouseDragged();
			}
		}//end of mouseDragged
//			SuedeModel.copiedScriptNodeObj = this;
//			/** Copy a prompt card */
//				public void handleCopyAction () {
//					if ( ! (m_nodemodel.getSuedeModel()).getAnalysisMode() ) {
//					//Temporarily let it point to promptCard instead of creating a new clone.   
//					//m_nodemodel.getSuedeModel().copiedObj = this;
//					SuedeModel.copiedObj = this;
//					//m_nodemodel.getSuedeModel().copiedLinkObj = null;
//					SuedeModel.copiedLinkObj = null;
//					}
//				}
//			Point p = e.getPoint();
//			Container pane = getParent();
//			javax.swing.SwingUtilities.convertPointToScreen(p, e.getComponent());
//			javax.swing.SwingUtilities.convertPointFromScreen(p, pane);
//			if (SwingUtilities.isLeftMouseButton(e)) {
//				drag_motion = true;	
//				handleMouseDragged();
//				pane.repaint();
//			}
//			else
//				drag_motion = false;
//		}//end of mouseDragged
		
		public void mouseMoved(MouseEvent e) {}   
	  }//end of class ScriptNodeMouseListener   
}
