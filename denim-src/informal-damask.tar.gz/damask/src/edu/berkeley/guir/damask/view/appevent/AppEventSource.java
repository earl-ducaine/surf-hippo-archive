package edu.berkeley.guir.damask.view.appevent;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.view.DamaskApp;

/** 
 * A source of global app events.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-11-2004 James Lin
 *                               Created AppEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 05-31-2004
 */
public class AppEventSource {
   
   private Vector/*<AppListener>*/ eventListeners = new Vector();


   /**
    * Adds the specified listener to receive global app events.
    */
   public synchronized void addAppListener(final AppListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }


   /**
    * Removes the specified listener so that it no longer receives
    * global app events.
    */
   public synchronized void removeAppListener(final AppListener listener) {
      eventListeners.remove(listener);
   }

   
   /**
    * Fires currentFrameChanged events to listeners.
    */
   public void fireCurrentFrameChanged(final DamaskApp source) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final AppEvent event =
         new AppEvent(source, AppEvent.CURRENT_FRAME_CHANGED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final AppListener listener = (AppListener)i.next();
         listener.currentFrameChanged(event);
      }
   }
}
