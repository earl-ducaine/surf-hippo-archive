package edu.berkeley.guir.lib.satin.objects;

import java.awt.geom.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.graphics.*;

/**
 * A straight-line arrow that is zoom invariant.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v2.1-1.0.0, Dec 02 2000, JH
 *               Created.
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Dec 02 2000
 */
public class StickyLineArrow
   extends LineArrow {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   Style stickyStyle = new Style();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public StickyLineArrow() {
      super();
   } // of constructor
   
   //-----------------------------------------------------------------

   public StickyLineArrow(Point2D ptStart, Point2D ptEnd) {
      super(ptStart, ptEnd);
   } // of constructor

   //-----------------------------------------------------------------

   public StickyLineArrow(float x1, float y1, float x2, float y2) {
      super(x1, y1, x2, y2);
   } // of constructor

   //-----------------------------------------------------------------

   public StickyLineArrow(GraphicalObject gobStart, GraphicalObject gobEnd) {
      super(gobStart, gobEnd);
   } // of method

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   STICKY STYLE METHODS   ==============================================

   /**
    * Called just before a style is retrieved, so that the values can be
    * updated on demand.
    */
   protected void updateStyle() {
      //// 1. Calculate zoom factor.
      AffineTransform tx       = getTransform(COORD_ABS);
      double          curScale = AffineTransformLib.getScaleFactor(tx);

      //// 2. Calculate new values and set the style.
      Style s = super.getStyleRef();

      //// 2.1. This is bad programming form, but I can't quite figure 
      ////      out why stickyStyle would ever be null.
      if (stickyStyle == null) {
         stickyStyle = new Style();
      }

      s.setLineWidth((float) (stickyStyle.getLineWidth() / curScale));

      //// 3. Set the arrow color to be the fill color.
      s.setFillColor(stickyStyle.getFillColor());
      s.setDrawColor(stickyStyle.getFillColor());
   } // of method

   //-----------------------------------------------------------------

   public Style getStickyStyleRef() {
      return (stickyStyle);
   } // of method

   /**
    * Overrided to set the sticky style.
    */
   public Style setStyle(Style newStyle) {
      stickyStyle = newStyle;
      return (newStyle);
   } // of method

   /**
    * Gets a copy of the current style, soft state depending on zoom.
    */
   public Style getStyle() {
      updateStyle();
      return (super.getStyle());
   } // of method

   /**
    * Gets the current style, soft state depending on zoom.
    */
   public Style getStyleRef() {
      updateStyle();
      return (super.getStyleRef());
   } // of method

   //===   STICKY STYLE METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   ARROW METHODS   =====================================================

   /**
    * Update the angle for the arrow head.
    */
   protected void updateArrowHeadAngle() {

      //// 1. Figure out arrow head angle.
      super.updateArrowHeadAngle();

      //// 2. Calculate zoom factor and inversely scale 
      ////    to keep things invariant.
      AffineTransform tx       = getTransform(COORD_ABS);
      double          curScale = AffineTransformLib.getScaleFactor(tx);
      float           dstScale = 1 + 0.1f*getStickyStyleRef().getLineWidth();

      txArrowHead.scale(dstScale / curScale, dstScale / curScale);

   } // of method


   protected void updateBounds() {
       clearPoints();
       addPoint(ptStart);
       addPoint(ptEnd);

      setArrowHeadVector(ptEnd.getX() - ptStart.getX(), 
                         ptEnd.getY() - ptStart.getY());

      updateArrowHeadAngle();
   } // of method

   //===   ARROW METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   RENDERING   =========================================================

   protected void defaultRender(SatinGraphics g) {
      updateStyle();
      updateArrowHeadAngle();

      super.defaultRender(g);
   } // of defaultRender

   //===   RENDERING   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
    * For clone chaining purposes.
    *
    * @see GraphicalObjectImpl#clone(GraphicalObjectImpl)
    */
   protected StickyLineArrow clone(StickyLineArrow newArrow) {
      //// 1. First call the superclass clone for clone chaining.
      super.clone(newArrow);

      //// 2. Do work.

      //// 3. Return.
      return (newArrow);
   } // of clone

   //-----------------------------------------------------------------

   /**
    * For deep-clone chaining. If you override this method in a subclass, be
    * sure to call this method, just as you would have to for normal clone
    * chaining.
    *
    * @see #clone()
    * @see #deepClone()
    */
   protected StickyLineArrow deepClone(StickyLineArrow newArrow) {
      //// 1. Defer work to other clone method, since we don't contain
      ////    other objects.
      super.clone(newArrow);

      //// 2. Return.
      return (newArrow);
   } // of deepClone

   //===   CLONE   =============================================================
   //===========================================================================



   //===========================================================================
   //===   MAIN   ==============================================================

   public static void main(String[] argv) {
   } // of main

   //===   MAIN   ==============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/


