//// See bottom of source code for software license.
package edu.berkeley.guir.lib.metrics;

import edu.berkeley.guir.lib.util.Timer;

/**
 * Utilities to help run regression tests.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Aug 31 2000
 */
public class Regression {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   static Timer timer = new Timer();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   RUN   ===============================================================

   public static void run(ActionItem item, int iterations) {
      long[] times = new long[iterations];


      System.out.println();
      System.out.println(item.getName() + " (" + iterations + "x)");
      item.init();
      for (int i = 0; i < iterations; i++) {
         timer.resetTimer();
         timer.start();
         item.doit();
         timer.stop();
         times[i] = timer.getElapsedTime();
      }
      item.cleanup();

      long  sum = 0;
      long  min = Long.MAX_VALUE;
      long  max = Long.MIN_VALUE;
      float average;
      for (int i = 0; i < times.length; i++) {
         sum += times[i];
         if (times[i] > max) {
            max = times[i];
         }
         if (times[i] < min) {
            min = times[i];
         }
      }
      average = sum / (float) times.length;

      System.out.println("   Iterations: " + iterations);
      System.out.println("   Total time: " + sum);
      System.out.println("   Unit time:  " + average);
      System.out.println("   Min time:   " + min);
      System.out.println("   Max time:   " + max);

   }

   //===   RUN   ===============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
