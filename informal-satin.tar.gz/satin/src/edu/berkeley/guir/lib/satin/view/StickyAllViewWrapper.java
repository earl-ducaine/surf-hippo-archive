//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.view;

import java.awt.geom.*;
import edu.berkeley.guir.lib.satin.graphics.*;

/**
 * Wraps up views to stick to a certain location.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Feb 28 2000, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3RC1
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class StickyAllViewWrapper 
   extends StickyViewWrapper {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 2772309582093858853L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   double x;                    // x-position to appear at.
   double y;                    // y-position to appear at.

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public StickyAllViewWrapper() {
      commonInitializations();
   } // of method

   //-----------------------------------------------------------------

   /**
    * Wrap a view into a sticky wrapper, making it appear in the same place
    * despite any kind of transformation.
    */
   public StickyAllViewWrapper(View v) {
      super(v);
      setView(v);
      commonInitializations();
   } // of default constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Sticky All Wrapper");
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   protected AffineTransform getStickyTransform(AffineTransform txTmp) {
      //// 1. Calculate the current translation.
      getAttachedGraphicalObject().getInverseTransform(COORD_ABS, txTmp);
      txTmp.translate(x, y);
      return (txTmp);
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Set the absolute location where this view will appear.
    */
   public void setLocation(double x, double y) {
      this.x = x;
      this.y = y;
   } // of setLocation

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   RENDERING   =========================================================

   public void render(SatinGraphics g) {
      //// A. Acquire soft-state.
      AffineTransform txTmp = (AffineTransform) poolTx.getObject();

      //// 1. Modify the absolute transform to be vanilla.
      g.ignoreTransforms();

      //// 2. Go to where we want to be sticky.
      txTmp.setToTranslation(x, y);
      g.transform(txTmp);

      //// 3. Render.
      v.render(g);

      //// B. Release soft-state.
      poolTx.releaseObject(txTmp);

      //// 4. Restore the absolute transform.
      g.dontIgnoreTransforms();
   } // of render

   //===   RENDERING   =========================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (clone(new StickyAllViewWrapper()));
   } // of method

   //-----------------------------------------------------------------

   protected StickyAllViewWrapper clone(StickyAllViewWrapper vw) {
      //// 1. Clone chain.
      super.clone(vw);

      //// 2. Do clone work.
      vw.x = this.x;
      vw.y = this.y;

      //// 3. Return.
      return (vw);
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
