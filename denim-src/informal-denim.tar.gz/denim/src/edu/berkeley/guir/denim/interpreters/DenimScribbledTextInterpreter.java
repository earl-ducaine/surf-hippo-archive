package edu.berkeley.guir.denim.interpreters;

import java.awt.geom.*;
import edu.berkeley.guir.denim.components.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.satin.Sheet;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.interpreter.stroke.ImmediateInkFeedbackInterpreter;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;

import edu.berkeley.guir.lib.satin.event.*;

/**
 * <p>An interpreter that determines whether strokes belong to scribbled
 * text.</p>
 *
 * <p>The criteria for belonging in a phrase are:</p>
 * <ul>
 * <li>below the minimum height to be "letter-like"
 * <li>not long and straight
 * <li>not crossing the boundaries of a sketch
 * </ul>
 *
 * <p>When a "phraseworthy" stroke is found, either</p>
 * <ul>
 * <li>a new piece of scribbled text is created
 * <li>if it is near enough to an existing phrase,
 *     and more or less horizontally aligned with it
 *     it is added to the existing phrase (not implemented yet)
 * <li>it can also be vertically aligned with it, if it
 *     is near enough in time to the original creation of
 *     the phrase (not implemented yet)
 * </ul>
 *
 * <p>In the current version, only the most recently created scribbled text
 * can be added to.</p>
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  before 08-29-1999 MWN
 *                    Created
 *             1.0.1  08-29-1999 MWN
 *                    Added additional tests to distinguish phrases from arrows
 *             1.0.2  06-22-2000 JH
 *                    Removed dead code
 *             2.0.0  10-19-2000 JL
 *                    Renamed ScribbledTextInterpreter
 *             2.1.0  10-18-2001 JL and Scott Klemmer
 *                    Split into SATIN class and DENIM-specific class
 * 			   2.1.1  11-08-2002 YL
 * 					  Enabled idle rendering
 * 			   2.1.1  01-06-2003 YL
 * 					  Supported active feedback
 * 
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~newman/">Mark Newman</A> (
 *         <A HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * 
 * @since   JDK 1.2
 * @version Version 2.0.0, 01-06-2003
 */
public class DenimScribbledTextInterpreter
   extends ScribbledTextInterpreter {

   //===========================================================================

   private static List instances = new ArrayList();

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================

   //===========================================================================

   /**
    * Creates a scribbled text interpreter.
    */
   public DenimScribbledTextInterpreter() {
      super();
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Creates a scribbled text interpreter.
    */
   public DenimScribbledTextInterpreter(DenimScribbledTextInterpreter intrp) {
      //// 1. Since this interpreter is stateless, we can do this safely.
      this();
   } // of constructor
   
   //-----------------------------------------------------------------

   /**
    * Performs initializations common to constructors.
    */
   private void commonInitializations() {
      setName("Denim Scribble Interpreter");

      //// Have the class keep track of this instance
      instances.add(this);
      
      if (DenimSketch.getPrototypeScribbleInterpreter() != null) {
         setEnabledLocally(DenimSketch.getPrototypeScribbleInterpreter().isEnabled());
      }
   }

   //-----------------------------------------------------------------

   protected void finalize() throws Throwable {
      //// Have the class forget about this instance
      instances.remove(instances.indexOf(this));
      super.finalize();
   }

   //===========================================================================

   protected void doCreateNewScribbleCommand(GraphicalObjectGroup parent,
                                             TimedStroke stk) {
                                           
      ScribbledText newScribble = new ScribbledText();
      newScribble.setCouldBeCaption(true);
      // newScribble.setBaselineY((int)stk.getBounds2D(COORD_ABS).getMaxY());

      MacroCommand cmd = new MacroCommand();
      cmd.addCommand(new CreateNewScribbleCommand(parent,
                                                  newScribble,
                                                  stk));
      cmd.addCommand
         (new SetSheetModifiedCommand((DenimSheet)parent.getSheet(),
                                       true));
      cmdqueue.doCommand(cmd);
      
      // Shelley
      if (this.getAttachedGraphicalObject() instanceof DenimListBoxInstance) {
         DenimListBoxInstance listBox = (DenimListBoxInstance) this.getAttachedGraphicalObject();
         listBox.addItem(newScribble);
      }

   }

   //===========================================================================

   /**
    * Enables or disables <i>all</i> instances of DenimScribbledTextInterpreter.
    */
   public void setEnabled(boolean flag) {
      setAllEnabled(flag);
   }

   //-----------------------------------------------------------------

   /**
    * Enables or disables <i>all</i> instances of DenimScribbledTextInterpreter.
    */   
   public static void setAllEnabled(boolean flag) {
      for (Iterator it = instances.iterator(); it.hasNext(); ) {
         ((DenimScribbledTextInterpreter)it.next()).setEnabledLocally(flag);
      }
   }

   //-----------------------------------------------------------------

   private void setEnabledLocally(boolean flag) {
      super.setEnabled(flag);
   }

   //===========================================================================
   //===   IDEALLY UNNECESSARY METHODS   =======================================

   protected Point2D getLocalToAbs(GraphicalObject gob, Point2D pt) {
      return DenimUtils.trueLocalToAbs(gob, pt);
   }

   //-----------------------------------------------------------------

   protected Point2D getAbsToLocal(GraphicalObject gob, Point2D pt) {
      return DenimUtils.trueAbsToLocal(gob, pt);
   }

   //-----------------------------------------------------------------

   protected Rectangle2D getLocalToAbs(GraphicalObject gob,
                                       Rectangle2D rect) {
      return DenimUtils.trueLocalToAbs(gob, rect);
   }

   //-----------------------------------------------------------------

   protected Rectangle2D getAbsToLocal(GraphicalObject gob,
                                       Rectangle2D rect) {
      return DenimUtils.trueAbsToLocal(gob, rect);
   }
   

   public void handleSingleStroke(SingleStrokeEvent evt) {
      final DenimSheet sheet =
         (DenimSheet)getAttachedGraphicalObject().getSheet();
      
      if (!sheet.isRenderToScreen()) {
         return;
      }

      if (sheet.getDenimUI().getCurrentTool() == null)
         return;

      if (this.getAttachedGraphicalObject() instanceof DenimSketch) {
         if (!((DenimSketch)this.getAttachedGraphicalObject())
            .isSketchRendered()) {
            evt.setConsumed(true);
            ((DenimSketch)this.getAttachedGraphicalObject()).damage(DAMAGE_NOW);
            return;
         }
      }
   
      TimedStroke thisStk = evt.getStroke();
      
      thisStk.getStyleRef().setDrawColor(ImmediateInkFeedbackInterpreter.inkColor);

      //// 0.1. If the stroke is too short, then ignore.
      if (thisStk.getLength2D(COORD_ABS) < MIN_SCRIBBLE_STK_LEN) {
         return;
      }

      //// 0.2. Disable any damage from occurring on the sheet, so
      ////      that it doesn't look like it's gone beserk.
      parent = (GraphicalObjectGroup) this.getAttachedGraphicalObject();
      parent.disableDamage();
   
      //// 1. If stroke belongs with current phrase, add it.
      if (isRightSize(thisStk)
         && belongsWithScribble(thisStk, this.getCurrentScribble())) {

         cmdqueue.doCommand(
            new AddStrokeToScribbleCommand(this.getCurrentScribble(), thisStk));

         evt.setConsumed(true);

         ((ScribbledText)this.getCurrentScribble()).activeFeedback();
      }
  /*
      if (isRightSize(thisStk)) {
          DenimComponentInstance gob = this.findComponentInstance(
                  (DenimSketch)this.getAttachedGraphicalObject(), thisStk);
          if(gob==null)
          {
              if(belongsWithScribble(thisStk, this.getCurrentScribble())) {

                  cmdqueue.doCommand(
                     new AddStrokeToScribbleCommand(this.getCurrentScribble(), thisStk));

                  evt.setConsumed(true);

                  ((ScribbledText)this.getCurrentScribble()).activeFeedback();
              }              
          }
          else
          {
              ScribbledText caption = null;
              if(gob instanceof DenimButtonInstance)
              {
                  caption = (ScribbledText)((DenimButtonInstance)gob).getCaption();
              }
              else if(gob instanceof DenimRadioButtonInstance)
              {
                  caption = (ScribbledText)((DenimRadioButtonInstance)gob).getCaption();
              }
              else if(gob instanceof DenimCheckBoxInstance) 
              {
                  caption = (ScribbledText)((DenimCheckBoxInstance)gob).getCaption();
              }
              
              cmdqueue.doCommand(
                      new AddStrokeToScribbleCommand(caption, thisStk));

              evt.setConsumed(true);
              caption.activeFeedback();
              
              //// 3. Re-enable the damage.
              parent.enableDamage();

              if (Sheet.isIdleRenderingMode()) {
                 gob.damage(DAMAGE_IDLE);
              }
              else {
                 gob.damage(DAMAGE_LATER);
              }
              
              return;
          }
      }
  */
      //// 2. If stroke is phraseworthy, but doesn't belong with the 
      ////    current phrase, start a new phrase.
      else if (isRightSize(thisStk)) {

         doCreateNewScribbleCommand(parent, thisStk);
         evt.setConsumed(true);

         ((ScribbledText)thisStk.getParentGroup()).activeFeedback();

      }

      //// 3. Re-enable the damage.
      parent.enableDamage();

      if (sheet.isIdleRenderingMode()) {
         if (getCurrentScribble() != null) {
            getCurrentScribble().damage(DAMAGE_IDLE);
         }
      }
      else {
         if (getCurrentScribble() != null) {
            getCurrentScribble().damage(DAMAGE_LATER);
         }
      }
      
      sheet.setModified(true);
   }
   
   //===========================================================================

   /**
    * Clones this interpreter.
    */
   public Object clone() {
      return (new DenimScribbledTextInterpreter(this));
   } // of clone

   //===   IDEALLY UNNECESSARY METHODS   =======================================
   //===========================================================================
}

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
