package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.connection.ConnectionDest;

/** 
 * An event that indicates a change to a control.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-19-2004 James Lin
 *                               Created ControlEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-19-2004
 */
public class ConnectionDestEvent extends EventObject {
   
   private Type eventType;
   private Connection connection;
   
   //===========================================================================

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type IN_CONNECTION_ADDED =
      new Type("incoming connection added");
   public static final Type IN_CONNECTION_REMOVED =
      new Type("incoming connection removed");

   //===========================================================================

   /**
    * Constructs a ControlEvent.
    * 
    * @param source the control that is affected
    */
   public ConnectionDestEvent(
      final ConnectionDest source,
      final Type eventType,
      final Connection connection) {

      super(source);
      this.eventType = eventType;
      this.connection = connection;
   }
   
   //===========================================================================

   /**
    * Returns the originator of the event.
    * 
    * @return the ConnectionDest object that originated the event, or
    * null if the object is not a ConnectionDest.
    */
   public ConnectionDest getConnectionDest() {
      if (source instanceof ConnectionDest) {
         return (ConnectionDest)source;
      }
      else {
         return null;
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the connection associated with this event.
    */
   public Connection getConnection() {
      return connection;
   }
}
