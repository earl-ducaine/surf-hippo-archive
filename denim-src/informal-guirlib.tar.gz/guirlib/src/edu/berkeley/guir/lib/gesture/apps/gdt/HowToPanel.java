package edu.berkeley.guir.lib.gesture.apps.gdt;

import javax.swing.JPanel;
import java.awt.BorderLayout;

/** A JPanel with a BorderLayout (by default) and that stores the
    MainFrame it's associated with. */
public class HowToPanel extends JPanel {
  protected MainFrame mainFrame;

  public HowToPanel()
  {
    this(null);
  }
  
  public HowToPanel(MainFrame mf)
  {
    super(new BorderLayout());
    setMainFrame(mf);
  }

  public void setMainFrame(MainFrame mf)
  {
    mainFrame = mf;
  }
  
  public MainFrame getMainFrame()
  {
    return mainFrame;
  }
}
