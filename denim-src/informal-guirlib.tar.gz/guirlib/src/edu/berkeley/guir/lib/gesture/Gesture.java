package edu.berkeley.guir.lib.gesture;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import edu.berkeley.guir.lib.gesture.util.TokenReader;
import edu.berkeley.guir.lib.util.DateLib;

public class Gesture extends DefaultGestureObject
  implements Serializable, Cloneable {
  // todo: probably want to implement the AWT Shape inteface when it's
  // finalized in a later release (> 1.2) (may want to subclass
  // java.awt.geom.GeneralPath)
  /** Throw out pixels closer together than the square root of this
   * distance (in pixels). */
  public static final String CREATION_DATE_PROP = "creation date";
  public static final String POINTS_PROP = "points";
  static final int filterThreshold = 4*4;
  static final long serialVersionUID = -783808682935248803L;
  /** Init lastx, lasty so the first point will be sure to be far
    * enough away from them not to be filtered out. */
  protected int lastx = Integer.MIN_VALUE, lasty = Integer.MIN_VALUE;
  // properties

  protected TimedPolygon points;
  protected boolean normalized = false;
  protected boolean enabled;
  protected Date creationDate;
  
  public Gesture()
  {
    this(null);
  }

  public Gesture(Gesture g)
  {
    super();

    if (g == null) {
      points = new TimedPolygon();
    }
    else {
      points = new TimedPolygon(g.points);
    }
    enabled = true;
    creationDate = new Date(System.currentTimeMillis());
  }
  
  /**
   * Filters out points that are too close together
   */
  public void addPoint(int x, int y)
  {
    int dx = lastx - x;
    int dy = lasty - y;
    int distSq = dx*dx + dy*dy;
    if (distSq > filterThreshold) {
      points.addPoint(x, y);
      lastx = x;
      lasty = y;
      if ((x < 0) || (y < 0)) {
	normalized = false;
      }
      propChangeSupport.firePropertyChange(POINTS_PROP,
					   null, new Point(x, y));
      setChanged();
      notifyObservers(new Point(x, y));
    }
  }
  
  /**
   * Return a copy of the points of the polygon
   * (copy instead of ref so points can't be changed).  To change
   * the points, use setPoints (or addPoint).
   */
  public TimedPolygon getPoints()
  {
    return new TimedPolygon(points);
  }



  /**
   * For optimization purposes only.
   * Used for calculating features.
   */
  public TimedPolygon getPointsRef() {
      return (points);
  } // of method


  /**
   * This does not change the creation date.
   */
  public void setPoints(TimedPolygon p)
  {
    //System.out.println("Setting points for " + this + " to " + p);
    if (p != points) {
      TimedPolygon oldValue = points;
      points = p;
      // it might really be normalized, but it's not worth checking
      normalized = false;
      if (points.npoints > 0) {
	lastx = points.xpoints[points.npoints-1];
	lasty = points.ypoints[points.npoints-1];
      }
      else {
	lastx = Integer.MIN_VALUE;
	lasty = Integer.MIN_VALUE;
      }
      propChangeSupport.firePropertyChange(POINTS_PROP, oldValue, points);
      setChanged();
      notifyObservers(points);
    }
  }

  public void clearPoints()
  {
    TimedPolygon oldValue = points;
    setPoints(new TimedPolygon());
    propChangeSupport.firePropertyChange(POINTS_PROP, oldValue, points);
  }

  /** getBounds for Polygon returns an internal cached Rectangle,
      whose modification can create havoc.  This method returns a copy
      that may be freely modified. */
  public Rectangle getBounds()
  {
    return (Rectangle) points.getBounds().clone();
  }

  public boolean isEnabled()
  {
    return enabled;
  }

  public void setEnabled(Boolean e)
  {
    setEnabled(e.booleanValue());
  }
  
  public void setEnabled(boolean e)
  {
    if (e != enabled) {
      enabled = e;
      propChangeSupport.firePropertyChange(ENABLED_PROP, !enabled, enabled);
      setChanged();
      notifyObservers(new Boolean(enabled));
    }
  }
  
  /**
   * Move the corner of the gesture to the origin
   */
  public void normalize()
  {
    if (!normalized) {
      TimedPolygon oldPoints = points;
      normalized = true;
      Rectangle bounds = points.getBounds();
      points.translate(-bounds.x, -bounds.y);
      propChangeSupport.firePropertyChange(POINTS_PROP, oldPoints, points);
      setChanged();
      notifyObservers(points);
    }
  }

  public int size()
  {
    return points.npoints;
  }

  public boolean hasProperty(String name)
  {
    if ((name == CREATION_DATE_PROP) || (name == POINTS_PROP) ||
	(name == ENABLED_PROP)) {
      return true;
    }
    else {
      return super.hasProperty(name);
    }
  }

  public void setProperty(String name, Object value)
  {
    if (name == CREATION_DATE_PROP) {
      setCreationDate((Date) value);
    }
    else if (name == POINTS_PROP) {
      setPoints((TimedPolygon) value);
    }
    else if (name == ENABLED_PROP) {
      setEnabled(((Boolean) value).booleanValue());
    }
    else {
      super.setProperty(name, value);
    }
  }

  public Object getProperty(String name)
  {
    if (name == CREATION_DATE_PROP) {
      return getCreationDate();
    }
    else if (name == POINTS_PROP) {
      return getPoints();
    }
    else if (name == ENABLED_PROP) {
      return new Boolean(isEnabled());
    }
    else {
      return super.getProperty(name);
    }
  }
  
  public Object clone()
  {
    // this will copy the scalar fields
    Gesture g = (Gesture) super.clone();
    g.points = (TimedPolygon) points.clone();
    g.creationDate = (Date) creationDate.clone();
    return g;
  }

  /** For debugging.  Print out all points of the Gesture. */
  public void dump(PrintStream out)
  {
    for (int i = 0; i < points.npoints; i++) {
      out.print(points.xpoints[i] + ", " + points.ypoints[i] + " ");
    }
    out.println();
  }

  public void printTiming(PrintStream out)
  {
    final int ncols = 4;

    for (int i = 0; i < points.npoints; i++) {
      out.print("" + points.times[i]);
      if ((i % ncols) == (ncols-1)) {
	out.println();
      }
      else {
	out.print("\t");
      }
    }
    out.println();
  }
  
  /**
   * Creation date is set automatically, so normally this should not need
   * to be called from other classes.
   */
  public void setCreationDate(Date d)
  {
    if (creationDate != d) {
      Date oldValue = creationDate;
      creationDate = d;
      propChangeSupport.firePropertyChange(CREATION_DATE_PROP,
					   oldValue, creationDate);
      setChanged();
      notifyObservers(creationDate);
    }
  }

  public Date getCreationDate()
  {
    return creationDate;
  }

  // I/O

  public void write(Writer writer) throws IOException
  {
    if (author != null) {
      writer.write("author\t" + author + "\n");
    }
    writer.write("normalized\t" + normalized + "\n");
    if (creationDate != null) {
      writer.write("creationDate\t" + DateLib.DateToISO(creationDate) +
		   "\n");
    }
    writer.write("points\t" + points.npoints + "\n");
    for (int i = 0; i < points.npoints; i++) {
      writer.write("\t" + points.xpoints[i] + "\t" + points.ypoints[i] +
		   "\t" + points.times[i] + "\n");
    }
    writer.write("endgesture\n");
  }
  
  public static Gesture read(Reader reader) throws IOException,
    ParseException
  {
    return read(new TokenReader(reader));
  }
  
  public static Gesture read(TokenReader r) throws IOException,
    ParseException
  {
    Gesture result = new Gesture();
    
    boolean done = false;

    while (!done) {
      String token;
      try {
	token = r.readToken().intern();
	if (token == "author") {
	  result.author = r.readLine();
	  result.author.trim();
	}
	else if (token == "normalized") {
	  result.normalized = r.readBoolean();
	}
	else if (token == "creationDate") {
	  String dateStr = r.readLine();
	  // try new format (i.e., ISO) first
	  try {
	    result.creationDate = DateLib.ISOToDate(dateStr);
	  }
	  catch (IllegalArgumentException e) {
	    // try the old, SimpleDateFormat, format
	    SimpleDateFormat dateFormat = new SimpleDateFormat();
	    try {
	      result.creationDate = dateFormat.parse(dateStr);
	    }
	    catch (ParseException e2) {
	      System.err.println("WARNING: Could not parse date string '" +
				 dateStr + "'.  Setting to null...");
	      result.creationDate = null;
	    }
	  }
	}
	else if (token == "points") {
	  try {
	    int numPoints = r.readInt();
	    TimedPolygon poly = new TimedPolygon();
	    
	    for (int i = 0; i < numPoints; i++) {
	      int x, y;
	      long t;
	      x = r.readInt();
	      y = r.readInt();
	      t = r.readLong();
	      poly.addPoint(x, y, t);
	    }
	    result.points = poly;
	  }
	  catch (NumberFormatException e) {
	    throw new IOException("bad argument for points (" + e + ")");
	  }
	}
	else if (token == "endgesture") {
	  done = true;
	}
      }
      catch (EOFException e) {
	done = true;
      }
    }
    //System.err.println("Read gesture with " + result.getPoints().npoints +
    //" points");
    return result;
  }

  public String toString()
  {
    return super.toString() + "/" + points.toString();
  }
}
