package edu.berkeley.guir.damask.connection;

import java.awt.Shape;
import java.awt.geom.*;
import java.util.*;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.damask.pattern.PatternInstanceMember;
import edu.berkeley.guir.damask.userevent.DamaskUserEvent;
import edu.berkeley.guir.damask.view.DamaskAppUtils;

/** 
 * A connection, which either represents the flow of the end-user from one
 * element of interaction to another, or an association between two elements. 
 * This is as opposed to components, which represent how elements of 
 * interaction with which the end-user directly interacts.
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2003 James Lin
 *                               Created Connection.
 *             1.1.0  10-15-2003 James Lin
 *                               Merged AbstractPatternInstanceMember into
 *                               Connection, since Connection was the only
 *                               subclass.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.1.0, 10-15-2003
 */
public abstract class Connection extends AbstractInteractionElement
implements PatternInstanceMember {
   private Map/*<DeviceType, ConnectionSource>*/ sources = new HashMap();
   private Map/*<DeviceType, ConnectionDest>*/ dests = new HashMap();

   private Map/*<DeviceType, Page>*/ sourcePages = new HashMap();
   private Map/*<DeviceType, Page>*/ destPages = new HashMap();
   
   private Map/*<DeviceType, double[2]>*/ sourceLocFracs = new HashMap();
   private Map/*<DeviceType, double[2]>*/ destLocFracs = new HashMap();
//   private Map/*<DeviceType, Point2D>*/ sourceLocPoints = new HashMap();
//   private Map/*<DeviceType, Point2D>*/ destLocPoints = new HashMap();
   private Map/*<DeviceType, GeneralPath>*/ paths = new HashMap();
   private Set/*<PatternInstance>*/ patternInstances = new HashSet();
   private InteractionGraph graph;
   
   private final Class sourceClass;
   private final Class destClass;
   
   private final DeviceType userSpecDeviceType;
   private final boolean forAllDevices;

   private InteractionElementListener endpointListener = new EndpointListener();
   private ControlHandler controlHandler = new ControlHandler();
   private ConnectionEventSource connectionEventSource =
      new ConnectionEventSource();
      
   //===========================================================================
   
   protected Connection(
      final DeviceType userSpecDeviceType,
      final boolean forAllDevices,
      final ConnectionSource sourceForUserSpecDeviceType,
      final Class sourceClass,
      final ConnectionDest destForUserSpecDeviceType,
      final Class destClass,
      final GeneralPath shapeForUserSpecDeviceType) {

      userSpecDeviceType.verifyTypeIsNotAll();
         
      this.sourceClass = sourceClass;
      this.destClass = destClass;
      this.userSpecDeviceType = userSpecDeviceType;
      this.forAllDevices = forAllDevices;

      // recalculateShape can be called as soon as basicSetConnectionSource
      // and basicSetConnectionDest are called, so prefill sourceLocFracs
      // and destLocFracs with dummy numbers to avoid null-pointer exceptions
      // in recalculateShape
      sourceLocFracs.put(userSpecDeviceType, new double[] {0.5, 0.5});
      destLocFracs.put(userSpecDeviceType, new double[] {0.5, 0.5});
      
      // Set the source, destination, and shape for the passed-in device type.
      sources.put(userSpecDeviceType, null);
      dests.put(userSpecDeviceType, null);

      basicSetShape(userSpecDeviceType, shapeForUserSpecDeviceType);

      basicSetConnectionSource(userSpecDeviceType, sourceForUserSpecDeviceType);
      recalculateStartPointLocFrac(userSpecDeviceType);

      basicSetConnectionDest(userSpecDeviceType, destForUserSpecDeviceType);
      recalculateEndPointLocFrac(userSpecDeviceType);
      
      // If the connection is for all device types, then figure out the source,
      // destination, and shape for the other device types.
      if (forAllDevices) {
         for (Iterator i = Damask.getSupportedDeviceTypes().iterator();
            i.hasNext(); ) {

            final DeviceType aDeviceType = (DeviceType)i.next();
      
            if (!userSpecDeviceType.equals(aDeviceType)) {
               sources.put(aDeviceType, null);
               dests.put(aDeviceType, null);

               final ConnectionSource sourceForThisDeviceType;
               final ConnectionDest destForThisDeviceType;
            
               // If the source and destination for the passed-in device type
               // are pages, then get the page for this device type from the
               // same dialog.
               if (sourceForUserSpecDeviceType instanceof Page) {
                  sourceForThisDeviceType =
                     ((Page)sourceForUserSpecDeviceType).getDialog().getFirstPage(
                        aDeviceType);
               }
               else {
                  sourceForThisDeviceType = sourceForUserSpecDeviceType;
               }
            
               if (destForUserSpecDeviceType instanceof Page) {
                  destForThisDeviceType =
                     ((Page)destForUserSpecDeviceType).getDialog().getFirstPage(
                        aDeviceType);
               }
               else {
                  destForThisDeviceType = destForUserSpecDeviceType;
               }
            
               // Create a default shape for the connection.
//               final GeneralPath shapeForThisDeviceType = new GeneralPath();
               //TODO make smarter than just going between upper-left corners

//               final Rectangle2D boundsForSourceForThisDeviceType =
//                  sourceForThisDeviceType.localToGlobal(
//                     aDeviceType,
//                     sourceForThisDeviceType.getBounds(aDeviceType));
//
//               final Rectangle2D boundsForDestForThisDeviceType =
//                  destForThisDeviceType.localToGlobal(
//                     aDeviceType,
//                     destForThisDeviceType.getBounds(aDeviceType));
//
//               shapeForThisDeviceType.moveTo(
//                  (float)boundsForSourceForThisDeviceType.getX(),
//                  (float)boundsForSourceForThisDeviceType.getY());
//
//               shapeForThisDeviceType.lineTo(
//                  (float)boundsForDestForThisDeviceType.getX(),
//                  (float)boundsForDestForThisDeviceType.getY());

//               basicSetShape(aDeviceType, shapeForThisDeviceType);
               
               sourceLocFracs.put(
                  aDeviceType,
                  new double[] {
                     getSourceXAsWidthFraction(userSpecDeviceType),
                     getSourceYAsHeightFraction(userSpecDeviceType)}
                  );
               destLocFracs.put(
                  aDeviceType,
                  new double[] {
                     getDestXAsWidthFraction(userSpecDeviceType),
                     getDestYAsHeightFraction(userSpecDeviceType)}
                  );
               
               basicSetConnectionSource(aDeviceType, sourceForThisDeviceType);
               basicSetConnectionDest(aDeviceType, destForThisDeviceType);
               recalculateShape(aDeviceType);
            }
         }
      }
   }
   
   //---------------------------------------------------------------------------
   
   /**
    * Frees up any resources associated with this object.
    */   
   public void dispose() {
      setInteractionGraph(null);
      final Set deviceTypes = new HashSet(getDeviceTypesVisibleTo());
      for (Iterator i = deviceTypes.iterator(); i.hasNext(); ) {
         final DeviceType deviceType = (DeviceType)i.next();

         basicSetConnectionSource(deviceType, null);
         basicSetConnectionDest(deviceType, null);

         sources.remove(deviceType);
         dests.remove(deviceType);
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the interaction graph that the dialog is in, or null if it's not
    * in any graph.
    */
   public InteractionGraph getInteractionGraph() {
      return graph;
   }
   
   //---------------------------------------------------------------------------

   /**
    * Sets the interaction graph that the dialog is in. Called only by
    * InteractionGraph.add(Dialog).
    */
   public void setInteractionGraph(InteractionGraph graph) {
      this.graph = graph;
   }
   
   //===========================================================================
   
   /**
    * Returns whether this connection supports the given device type.
    */
   public boolean isVisibleToDeviceType(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      
      return sources.containsKey(deviceType);
   }
   
   //---------------------------------------------------------------------------

   /**
    * Returns the device types that this connection deals with.
    */
   public Set getDeviceTypesVisibleTo() {
      return Collections.unmodifiableSet(sources.keySet());
   }
   
   //---------------------------------------------------------------------------

   /**
    * Returns whether this connection is available to all device types.
    */
   public boolean isForAllDeviceTypes() {
      return forAllDevices;
   }
   
   //---------------------------------------------------------------------------

   /**
    * Returns the device type that this connection was originally
    * constructed with.
    */
   public DeviceType getOrigSpecifiedDeviceType() {
      return userSpecDeviceType;
   }

   //===========================================================================
   
   /**
    * Throws an UnsupportedOperationException if the given device type has
    * not yet been added to this connection.
    */
   protected void verifyDeviceTypeIsValid(final DeviceType deviceType) {
      DamaskUtils.checkValidArgument(
         isVisibleToDeviceType(deviceType),
         deviceType.toString()
            + " has not been added to connection "
            + toString());
   }
   
   //===========================================================================
   
   /**
    * Returns the source of this connection.
    */
   public ConnectionSource getConnectionSource(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      return (ConnectionSource)sources.get(deviceType);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets the source of this connection. Called by the constructor.
    */
   private final void basicSetConnectionSource(
      final DeviceType deviceType,
      final ConnectionSource newSource) {
         
      verifyDeviceTypeIsValid(deviceType);

      DamaskUtils.checkValidArgument(
         sourceClass.isInstance(newSource) || (newSource == null),
         newSource + " must be an instance of " + sourceClass + " or null");
         
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator(); i.hasNext(); ) {
         DeviceType aDeviceType = (DeviceType)i.next();
         
         // Stop listening to the old source and its page.
         ConnectionSource oldSource =
            (ConnectionSource) sources.get(aDeviceType);
            
         if (oldSource != null) {
            oldSource.removeOutConnection(this);
            oldSource.removeInteractionElementListener(endpointListener);

            if (oldSource instanceof Control) {
               ((Control)oldSource).addControlListener(controlHandler);
            }

            final Page oldSourcePage = (Page)sourcePages.remove(aDeviceType);
            if (oldSourcePage != null && oldSource != oldSourcePage) {
               oldSourcePage.removeInteractionElementListener(endpointListener);
            }
         }

         // Store the new source.
         sources.put(aDeviceType, newSource);
//         sourceLocPoints.put(aDeviceType, startPoint);
         
         // Start listening to the new source and its page.
         if (newSource != null) {
            newSource.addOutConnection(this);
            newSource.addInteractionElementListener(endpointListener);
            
            if (newSource instanceof Control) {
               ((Control)newSource).addControlListener(controlHandler);
            }

            final Page newSourcePage = newSource.getPage(aDeviceType);
            if (newSourcePage != null && newSource != newSourcePage) {
               sourcePages.put(aDeviceType, newSourcePage);
               newSourcePage.addInteractionElementListener(endpointListener);
            }
         }
         
         fireSourceChanged(aDeviceType, oldSource, newSource);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets the source of this connection.
    */
   protected void setConnectionSource(
      final DeviceType deviceType,
      final ConnectionSource newSource) {

      deviceType.verifyTypeIsNotAll();
      basicSetConnectionSource(deviceType, newSource);
      recalculateShape(deviceType);
   }

   //===========================================================================
   
   /**
    * Returns the destination of this connection.
    */
   public ConnectionDest getConnectionDest(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      
      return (ConnectionDest)dests.get(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the destination of this connection. Called by the constructor.
    */
   private final void basicSetConnectionDest(
      final DeviceType deviceType,
      final ConnectionDest newDest) {

      verifyDeviceTypeIsValid(deviceType);

      DamaskUtils.checkValidArgument(
         destClass.isInstance(newDest) || (newDest == null),
         newDest + " must be an instance of " + destClass + " or null");
         
      for (Iterator i = deviceType.getSpecificDeviceTypes().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         
         // Stop listening to the old destination and its page.
         final ConnectionDest oldDest =
            (ConnectionDest) dests.get(aDeviceType);
         if (oldDest != null) {
            oldDest.removeInConnection(this);
            oldDest.removeInteractionElementListener(endpointListener);

            if (oldDest instanceof Control) {
               ((Control)oldDest).removeControlListener(controlHandler);
            }

            final Page oldDestPage = (Page)destPages.remove(aDeviceType);
            if (oldDestPage != null && oldDest != oldDestPage) {
               oldDestPage.removeInteractionElementListener(endpointListener);
            }
         }
         
         // Store the new destination.
         dests.put(aDeviceType, newDest);
         
         // Start listening to the new destination and its page.
         if (newDest != null) {
            newDest.addInConnection(this);
            newDest.addInteractionElementListener(endpointListener);

            if (newDest instanceof Control) {
               ((Control)newDest).addControlListener(controlHandler);
            }

            final Page newDestPage = newDest.getPage(aDeviceType);
            if (newDestPage != null && newDest != newDestPage) {
               destPages.put(aDeviceType, newDestPage);
               newDestPage.addInteractionElementListener(endpointListener);
            }
         }
         fireDestChanged(aDeviceType, oldDest, newDest);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Sets the destination of this connection.
    */
   protected void setConnectionDest(
      final DeviceType deviceType,
      final ConnectionDest newDest) {

      deviceType.verifyTypeIsNotAll();
      basicSetConnectionDest(deviceType, newDest);
      recalculateShape(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the destination of the connection to the specified page.
    */
   public void adjustDestPage(final DeviceType deviceType, final Page newDest) {
      final ConnectionDest oldDest = getConnectionDest(deviceType);
      if (!(oldDest instanceof Page)) {
         throw new UnsupportedOperationException(
            "The destination of " + this + " for " + deviceType +
            " must be a page, not " + oldDest);
      }
      
      if (oldDest == newDest) {
         return;
      }
      
      DamaskUtils.checkValidArgument(
         newDest.getDeviceType() == deviceType,
         "The device type of the new destination, " +
         newDest + " (" + newDest.getDeviceType() +
         ") must be the same as the deviceType parameter (" + deviceType);
      
      setConnectionDest(deviceType, newDest);
   }

   //===========================================================================
   
   /**
    * Recalculates the start point of this connection as a fraction of the
    * width and height of the bounds of the source.
    */
   private void recalculateStartPointLocFrac(final DeviceType aDeviceType) {
      final ConnectionSource source =
         (ConnectionSource)sources.get(aDeviceType);

      // Find the start point (which is in global coordinates).
      final Point2D startPoint =
         DamaskAppUtils.getFirstPoint(getShape(aDeviceType));
      
      // Calculate the source's bounds in global coordinates.
      final Rectangle2D sourceGlobalBds =
         source.localToGlobal(aDeviceType, source.getBounds(aDeviceType));
      
      // Calculate the coordinates of the endpoint in terms of the
      // percentage of the width and height of the source region.
      final double pctWidth =
         (startPoint.getX() - sourceGlobalBds.getX())
            / sourceGlobalBds.getWidth();
      final double pctHeight =
         (startPoint.getY() - sourceGlobalBds.getY())
            / sourceGlobalBds.getHeight();
      
      sourceLocFracs.put(aDeviceType, new double[] {pctWidth, pctHeight});
   }
   
   //---------------------------------------------------------------------------

   /**
    * Recalculates the end point of this connection as a fraction of the
    * width and height of the bounds of the destination.
    */
   private void recalculateEndPointLocFrac(final DeviceType aDeviceType) {
      final ConnectionDest dest = (ConnectionDest)dests.get(aDeviceType);

      // Find the endpoint (which is in global coordinates).
      final Point2D endPoint = DamaskAppUtils.getLastPoint(getShape(aDeviceType));

      // Calculate the destination's bounds in global coordinates.
      final Rectangle2D destGlobalBds =
         dest.localToGlobal(aDeviceType, dest.getBounds(aDeviceType));

      // Calculate the coordinates of the endpoint in terms of the
      // percentage of the width and height of the destination region.
      final double pctWidth =
         (endPoint.getX() - destGlobalBds.getX()) / destGlobalBds.getWidth();
      final double pctHeight =
         (endPoint.getY() - destGlobalBds.getY()) / destGlobalBds.getHeight();

      destLocFracs.put(aDeviceType, new double[] { pctWidth, pctHeight });
      //destLocPoints.put(aDeviceType, endPoint);
   }

   //---------------------------------------------------------------------------

   /**
    * Returns the x-coordinate of the start point of this connection, from
    * the specified device type's perspective, as a fraction of the width
    * of the bounds of the source.
    */
   public double getSourceXAsWidthFraction(final DeviceType deviceType) {
      return ((double[])sourceLocFracs.get(deviceType))[0];
   }

   /**
    * Returns the y-coordinate of the start point of this connection, from
    * the specified device type's perspective, as a fraction of the height
    * of the bounds of the source.
    */
   public double getSourceYAsHeightFraction(final DeviceType deviceType) {
      return ((double[])sourceLocFracs.get(deviceType))[1];
   }

   /**
    * Returns the x-coordinate of the end point of this connection, from
    * the specified device type's perspective, as a fraction of the width
    * of the bounds of the destination.
    */
   public double getDestXAsWidthFraction(final DeviceType deviceType) {
      return ((double[])destLocFracs.get(deviceType))[0];
   }

   /**
    * Returns the y-coordinate of the end point of this connection, from
    * the specified device type's perspective, as a fraction of the height
    * of the bounds of the destination.
    */
   public double getDestYAsHeightFraction(final DeviceType deviceType) {
      return ((double[])destLocFracs.get(deviceType))[1];
   }

   //===========================================================================

   /**
    * Returns the shape of this connection.
    */
   public GeneralPath getShape(final DeviceType deviceType) {
      deviceType.verifyTypeIsNotAll();
      return (GeneralPath)paths.get(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the shape of this connection. Called by the constructor.
    */
   private final void basicSetShape(
      final DeviceType deviceType,
      final GeneralPath newShape) {

      verifyDeviceTypeIsValid(deviceType);

      Collection deviceTypes = deviceType.getSpecificDeviceTypes();

      for (Iterator i = deviceTypes.iterator(); i.hasNext();) {
         DeviceType aDeviceType = (DeviceType)i.next();
         
         final GeneralPath oldShape = (GeneralPath)paths.get(aDeviceType);
         paths.put(aDeviceType, newShape);
         fireShapeChanged(aDeviceType, oldShape, newShape);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Sets the shape of this connection.
    */
   public void setShape(
      final DeviceType deviceType,
      final GeneralPath newShape) {

      basicSetShape(deviceType, newShape);
      recalculateStartPointLocFrac(deviceType);
      recalculateEndPointLocFrac(deviceType);
   }

   //---------------------------------------------------------------------------

   /**
    * Recalculates the shape of this connection for the specified device type,
    * depending on the location of the source and destination.
    */
   private void recalculateShape(final DeviceType deviceType) {
      // Calculate new start point for connection
      final ConnectionSource source = getConnectionSource(deviceType);         
      //HACK
      if (source.getBounds(deviceType) == null) {
         return;
      }

      final Rectangle2D sourceGlobalBds =
         source.localToGlobal(deviceType, source.getBounds(deviceType));
      
      final double[] sourceFracs =
         (double[])sourceLocFracs.get(deviceType);

      final double newStartPointX =
         sourceFracs[0] * sourceGlobalBds.getWidth()
            + sourceGlobalBds.getX();
      final double newStartPointY =
         sourceFracs[1] * sourceGlobalBds.getHeight()
            + sourceGlobalBds.getY();
      
//      final Point2D newStartPoint =
//         new Point2D.Double(
//            sourcePercents[0] * sourceGlobalBds.getWidth()
//               + sourceGlobalBds.getX(),
//            sourcePercents[1] * sourceGlobalBds.getHeight()
//               + sourceGlobalBds.getY());

      // Calculate new end point for connection
      final ConnectionDest dest = getConnectionDest(deviceType);
      //HACK
      if (dest.getBounds(deviceType) == null) {
         return;
      }

      final Rectangle2D destGlobalBds =
         dest.localToGlobal(deviceType, dest.getBounds(deviceType));
      
      final double[] destFracs =
         (double[])destLocFracs.get(deviceType);

      final double newEndPointX =
         destFracs[0] * destGlobalBds.getWidth() + destGlobalBds.getX();
      final double newEndPointY =
         destFracs[1] * destGlobalBds.getHeight() + destGlobalBds.getY();

//      final Point2D newEndPoint =
//         new Point2D.Double(
//            destPercents[0] * destGlobalBds.getWidth()
//               + destGlobalBds.getX(),
//            destPercents[1] * destGlobalBds.getHeight()
//               + destGlobalBds.getY());

      // Create and store a line between the endpoints
      final GeneralPath oldGenPath = (GeneralPath)paths.get(deviceType);
      
      final GeneralPath newGenPath = new GeneralPath();
      newGenPath.moveTo((float)newStartPointX, (float)newStartPointY);
      newGenPath.lineTo((float)newEndPointX, (float)newEndPointY);
      paths.put(deviceType, newGenPath);
      
//      // Create rectangle with old endpoints
//      final Point2D oldStartPoint = (Point2D)sourceLocPoints.get(deviceType);
//      final Point2D oldEndPoint = (Point2D)destLocPoints.get(deviceType);
//      final Rectangle2D oldArrowPoints =
//         new Rectangle2D.Double(
//            oldStartPoint.getX(), oldStartPoint.getY(),
//            0, 0);
//      oldArrowPoints.add(oldEndPoint);
//      
//      // Create rectangle with new endpoints
//      final Rectangle2D newArrowPoints =
//         new Rectangle2D.Double(
//            newStartPoint.getX(), newStartPoint.getY(),
//            0, 0);
//      newArrowPoints.add(newEndPoint);
//      
//      // Calculate the scale and translate factors necessary to transform
//      // from 
//      final double dx = newArrowPoints.getX() - oldArrowPoints.getX();
//      final double dy = newArrowPoints.getY() - oldArrowPoints.getY();
//      
//      final double dwRatio =
//         newArrowPoints.getWidth() / oldArrowPoints.getWidth();
//      final double dhRatio =
//         newArrowPoints.getHeight() / oldArrowPoints.getHeight();
//      
//      // The translate and scale operations are done in reverse order,
//      // because the methods concatenate instead of preconcatenate.
//      final AffineTransform transform = new AffineTransform();
//      transform.translate(newArrowPoints.getX(), newArrowPoints.getY());
//      transform.scale(dwRatio, dhRatio);
//      transform.translate(-oldArrowPoints.getX(), -oldArrowPoints.getY());
//
//      System.out.println(oldArrowPoints);
//      System.out.println(newArrowPoints);
//      
//      System.out.println(((GeneralPath)paths.get(deviceType)).getBounds());
//      ((GeneralPath)paths.get(deviceType)).transform(transform);
//      System.out.println(((GeneralPath)paths.get(deviceType)).getBounds());
//      System.out.println();
//      
//      // Update the new endpoints
//      sourceLocPoints.put(deviceType, newStartPoint);
//      destLocPoints.put(deviceType, newEndPoint);
      
      fireShapeChanged(deviceType, oldGenPath, newGenPath);
   }

   //===========================================================================
   
   /**
    * Refreshes the connection, forcing events to be fired.
    */
   public void refresh(final DeviceType aDeviceType) {
      recalculateShape(aDeviceType);
      setConnectionSource(aDeviceType, getConnectionSource(aDeviceType));
      setConnectionDest(aDeviceType, getConnectionDest(aDeviceType));
   }
   
   //===========================================================================
   
   public Collection/*<PatternInstance>*/ getPatternInstanceMemberships() {
      return Collections.unmodifiableCollection(patternInstances);
   }
   
   //---------------------------------------------------------------------------

   public void addToPatternInstance(final PatternInstance pi) {
      patternInstances.add(pi);
   }
   
   //---------------------------------------------------------------------------

   public boolean removeFromPatternInstance(final PatternInstance pi) {
      return patternInstances.remove(pi);
   }

   //===========================================================================

   /**
    * Adds the specified connection listener to receive connection events from
    * this connection.
    */
   public void addConnectionListener(final ConnectionListener listener) {
      connectionEventSource.addConnectionListener(listener);
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified connection listener so that it no longer receives
    * connection events from this connection.
    */
   public void removeConnectionListener(final ConnectionListener listener) {
      connectionEventSource.removeConnectionListener(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires sourceChanged events to listeners.
    */
   protected void fireSourceChanged(
      final DeviceType deviceType,
      final ConnectionSource oldSource,
      final ConnectionSource newSource) {

      connectionEventSource.fireSourceChanged(
         this,
         deviceType,
         oldSource,
         newSource);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires destChanged events to listeners.
    */
   protected void fireDestChanged(
      final DeviceType deviceType,
      final ConnectionDest oldDest,
      final ConnectionDest newDest) {

      connectionEventSource.fireDestChanged(this, deviceType, oldDest, newDest);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires shapeChanged events to listeners.
    */
   protected void fireShapeChanged(
      final DeviceType deviceType,
      final Shape oldShape,
      final Shape newShape) {

      connectionEventSource.fireShapeChanged(
         this,
         deviceType,
         oldShape,
         newShape);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires userEventClass events to listeners.
    */
   protected void fireUserEventChanged(
      final DamaskUserEvent oldEvent,
      final DamaskUserEvent newEvent) {

      connectionEventSource.fireUserEventChanged(
         this,
         oldEvent,
         newEvent);
   }

   //---------------------------------------------------------------------------

   /**
    * Fires eventClassChanged events to listeners.
    */
   protected void fireConditionChanged(
      final int oldCondition,
      final int newCondition) {
      connectionEventSource.fireConditionChanged(
         this,
         oldCondition,
         newCondition);
   }
   
   //===========================================================================

   /**
    * Clones this connection, using the most recent clones of this connection's
    * endpoints as the new endpoints of the clone. This should be called right
    * after the endpoints of the connection have been cloned.
    */   
   public Object clone() {
      final Connection clone = (Connection)super.clone();

      clone.patternInstances = new HashSet(); 

      clone.sources = new HashMap();
      for (Iterator i = sources.keySet().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();

         clone.sources.put(aDeviceType, null);
         clone.basicSetConnectionSource(
            aDeviceType,
            (ConnectionSource) ((ConnectionSource)sources.get(aDeviceType))
               .getMostRecentCloneIfAlive());
      }
      
      clone.dests = new HashMap();
      for (Iterator i = dests.keySet().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         
         clone.dests.put(aDeviceType, null);
         clone.basicSetConnectionDest(
            aDeviceType,
            (ConnectionDest) ((ConnectionDest)dests.get(aDeviceType))
               .getMostRecentCloneIfAlive());
      }
      
      clone.paths = new HashMap();
      for (Iterator i = paths.keySet().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         
         clone.basicSetShape(
            aDeviceType,
            (GeneralPath) ((GeneralPath)paths.get(aDeviceType)).clone());
      }

      clone.patternInstances = new HashSet();
      
      clone.endpointListener = new EndpointListener();
      clone.connectionEventSource = new ConnectionEventSource();
   
      return clone;
   }
   
   //===========================================================================
   
   public String toString() {
      return super.toString() + ": " + getConnectionSource(userSpecDeviceType) + " -> " + getConnectionDest(userSpecDeviceType);
   }

   //===========================================================================
   
   /**
    * Listens to changes in the endpoints of the connection. 
    */
   private class EndpointListener implements InteractionElementListener {
      public void elementBoundsUpdated(InteractionElementEvent e) {
         if (isVisibleToDeviceType(e.getDeviceType())) {
            recalculateShape(e.getDeviceType());
         }
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
         if (isVisibleToDeviceType(e.getDeviceType())) {
            recalculateShape(e.getDeviceType());
         }
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }

   //===========================================================================
   
   /**
    * Handles events from the source and destination of the arrow's model if
    * they are controls.
    */ 
   private class ControlHandler implements ControlListener {
      // @Override
      public void controlStateChanged(ControlEvent e) {
      }

      // @Override
      public void controlSignificanceChanged(ControlEvent e) {
      }

      // @Override
      public void pageRegionChanged(ControlEvent e) {
         final DeviceType deviceType = e.getDeviceType();
         final Control control = e.getControl();
         final PageRegion pageRegion = control.getPageRegion(deviceType);
         
         if (control == getConnectionSource(deviceType)) {
            final Page oldSourcePage = (Page)sourcePages.remove(deviceType);
            if (oldSourcePage != null) {
               oldSourcePage.removeInteractionElementListener(endpointListener);
            }
            
            if (pageRegion != null) {
               final Page newSourcePage = pageRegion.getPage();
               sourcePages.put(deviceType, newSourcePage);
               newSourcePage.addInteractionElementListener(endpointListener);
            }
         }
         
         if (control == getConnectionDest(deviceType)) {
            final Page oldDestPage = (Page)destPages.remove(deviceType);
            if (oldDestPage != null) {
               oldDestPage.removeInteractionElementListener(endpointListener);
            }
            
            if (pageRegion != null) {
               final Page newDestPage = pageRegion.getPage();
               destPages.put(deviceType, newDestPage);
               newDestPage.addInteractionElementListener(endpointListener);
            }
         }
      }
   }
}
