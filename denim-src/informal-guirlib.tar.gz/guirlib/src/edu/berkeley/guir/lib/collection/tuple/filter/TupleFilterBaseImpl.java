//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tuple.filter;

import edu.berkeley.guir.lib.collection.tuple.Tuple;
import edu.berkeley.guir.lib.util.filter.Filter;
import edu.berkeley.guir.lib.util.filter.FilterBaseImpl;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Basic filter for Tuples.
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 20 2003, JH
 * @see edu.berkeley.guir.lib.util.filter.Filter
 * @see edu.berkeley.guir.lib.util.filter.FilterBaseImpl
 * @see edu.berkeley.guir.lib.util.filter.AndMultiFilter
 * @see edu.berkeley.guir.lib.util.filter.OrMultiFilter
 * @see edu.berkeley.guir.lib.util.filter.NotFilter
 * @see edu.berkeley.guir.lib.util.filter.DateFilter
 * @see edu.berkeley.guir.lib.util.filter.StringFilter
 */
abstract public class TupleFilterBaseImpl
    extends    FilterBaseImpl
    implements Filter, TupleFilter {

    //==========================================================================
    //===   FILTER METHODS   ===================================================

    /**
     * Implement this method.
     * @param obj should be a Tuple.
     */
    abstract public boolean isAccepted(final Object obj);

    //----------------------------------------------------------------

    /**
     * By default, calls isAccepted() to see what tuples are accepted.
     * Returns a new list of filtered tuples.
     */
    public List keepAccepted(final List listTuples) {
        Iterator it           = listTuples.iterator();
        List     listFiltered = new LinkedList();
        Tuple    t;

        while (it.hasNext()) {
            t = (Tuple) it.next();
            if (isAccepted(t)) {
                listFiltered.add(t);
            }
        }
        return (listFiltered);
    } // of method

    //===   FILTER METHODS   ===================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
