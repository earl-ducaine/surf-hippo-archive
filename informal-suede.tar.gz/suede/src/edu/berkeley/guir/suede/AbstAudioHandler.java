package edu.berkeley.guir.suede;

import javax.sound.sampled.*;

public abstract class AbstAudioHandler implements Runnable {
   protected DataLine line;
   protected Thread   thread;
   protected String   errStr;
        
   public void start() {
      errStr = null;
      thread = new Thread(this);
      thread.setName("AudioHandler");
      thread.start();
   } 


   public void stop() {
     /* System.out.println( "In AbstAudioHandler.stop(), and line is " + line );
       if ( line != null ) 
        line.stop();
      */
      thread = null;
   }
        
        
   protected synchronized void shutDown(String message) {
      if ((errStr = message) != null)
         System.err.println(errStr);

      if (thread != null)
         thread = null;
   }

        
   abstract public void run();
        
   public synchronized boolean isLineOpen() {
      if (line==null) return false;
      return line.isOpen();
   }
   
   public synchronized boolean isLineValid() {
      return (line != null);
   }
   
   public synchronized boolean isLineActive() {
      if (line==null) return false;
      return line.isActive();  
   }

   public synchronized long getMilliseconds() {
     if (line==null) return 0;
     return (long)(line.getMicrosecondPosition() / 1000);
   }

}