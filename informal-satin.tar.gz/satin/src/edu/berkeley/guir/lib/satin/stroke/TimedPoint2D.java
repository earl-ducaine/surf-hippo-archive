package edu.berkeley.guir.lib.satin.stroke;

public final class TimedPoint2D {
   public float x;
   public float y;
   public long time;
}

