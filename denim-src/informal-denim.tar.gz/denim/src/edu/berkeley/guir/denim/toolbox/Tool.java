package edu.berkeley.guir.denim.toolbox;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/**
 * A tool, used by the designer to pan, sketch on, or stamp in the 
 * sketches on the sheet. This class only encapsulates the generic behavior
 * of a tool. Specific tools are available for instantiation.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-12-1999 James Lin
 *                               Created Tool
 *                    07-26-1999 James Lin
 *                               Moved to ...toolbox package
 *                    07-27-1999 James Lin
 *                               Made abstract
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version Version 1.0.0, 07-26-1999
 */
public abstract class Tool
   extends JLabel
   implements MouseListener, MouseMotionListener, ToolContainer {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================
   
   protected String              name;
   protected Cursor              toolCursor;
   protected String cursorDir;
   protected Point               hotSpot;
   protected boolean             isPickedUp;
   protected MultiInterpreter    enabledInterpreters;
   private   int                 lastX;
   private   int                 lastY;
   private   DenimUI             ui;

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================

   

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================
   
   /**
    * Creates a tool with the specified image and hot spot.
    * 
    * @param cursorFile  the name of the file containing the cursor image
    * @param hotSpot the location of the hot spot (the point within the icon
    *                which is considered to be the tool's location). (0,0)
    *                is the upper-left hand corner of the icon.
    * @param name    the name of the tool (you know when this may become
    *                handy)
    * 
    */
   public Tool(String cursorFile, Point hotSpot16,
               Point hotSpot32,
               Point hotSpot64,
               String name) {
      super();
      
      Toolkit tk = Toolkit.getDefaultToolkit();
      Dimension bestSize = tk.getBestCursorSize(32, 32);
      
      if (bestSize.width >= 64 && bestSize.height >= 64) {
         cursorDir = "64x64/";
         this.hotSpot = hotSpot64;
      }
      else if (bestSize.width >= 32 && bestSize.height >= 32) {
         cursorDir = "32x32/";
         this.hotSpot = hotSpot32;
      }
      else {
         cursorDir = "16x16/";
         this.hotSpot = hotSpot16;
      }

      Image image = Toolkit.getDefaultToolkit().
         createImage(Denim.class.
            getResource("images/cursors/" + cursorDir + cursorFile));

      this.toolCursor = tk.createCustomCursor(image, hotSpot, name);
      this.setIcon(new ImageIcon(image));
      this.setBounds(0, 0, image.getWidth(null), image.getHeight(null));

      this.name = name;
      this.enabledInterpreters = new DefaultMultiInterpreterImpl();
      this.ui = null;
      
      // Let the tool receive events      
      this.activate();
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   
   //===========================================================================
   //===   TOOL METHODS   ======================================================

   /**
    * Called when the tool is first added to a container.
    */
   public void firstAddedToContainer() {
      ui = ((DenimWindow)SwingUtilities.getRoot(this)).getDenimUI();
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Grabs the tool.
    */
   public void grab() {
      deactivate();
      
      // Makes the label invisible, since the tool will now be represented
      // by a cursor
      super.setVisible(false);
      
      DenimUI ui = getDenimUI();
      DenimSheet sheet = ui.getSheet();
      sheet.bufferUpcomingRender(100);
      getParent().remove(this);
      sheet.setCursor(toolCursor);
      ui.getToolbox().getToolsArea().setCursor(toolCursor);
      ui.setCurrentTool(this);

      // Do not allow all gesture interpreters to accept the left button
      sheet.acceptLeftWithAllGestures(false);
      
      // Disable all of the sheet's ink interpreters 
      MultiInterpreter im = (MultiInterpreter)sheet.getInkInterpreter();
      Iterator i = im.iterator();
      while (i.hasNext()) {
         Interpreter intr = ((Interpreter)i.next());
         //System.out.println("Disabling: " + intr.getClass() + ":" + intr.getName());
         intr.setEnabled(false);
      }
      
      // Disable the sketch's ink interpreters
      //
      // This assumes that for all interpreters within the sketch's prototype
      // ink interpreter, calling setEnabled() will enable or disable *all*
      // instances of that interpreter.
      im = DenimSketch.getPrototypeInkInterpreter();
      i = im.iterator();
      while (i.hasNext()) {
         Interpreter intr = ((Interpreter)i.next());
         //System.out.println("Disabling: " + intr.getClass() + ":" + intr.getName());
         intr.setEnabled(false);
      }
      
      // Now, enable only the interpreters in enabledInterpreters
      i = enabledInterpreters.iterator();
      while (i.hasNext()) {
         Interpreter intr = ((Interpreter)i.next());
         //System.out.println("Enabling: " + intr.getClass() + ":" + intr.getName());
         
         //extra check, just to make sure that intr is not null
         if (intr != null) {
            intr.setEnabled(true);
         }
      }
      sheet.damage(SatinConstants.DAMAGE_LATER);
      sheet.flushRenderRequests();
   }
   
   //-----------------------------------------------------------------

   /**
    * Drops the tool in the specified container.
    */
   public void drop(Container c, Point p) {
      DenimUI ui = getDenimUI();
      DenimSheet sheet = ui.getSheet();
      ui.setCurrentTool(null);
      sheet.setCursor(DenimUtils.getDefaultCursor());
      ui.getToolbox().getToolsArea().setCursor(DenimUtils.getDefaultCursor());
      
      // Disable all of the sheet's ink interpreters 
      MultiInterpreter im = (MultiInterpreter)sheet.getInkInterpreter();
      Iterator i = im.iterator();
      while (i.hasNext()) {
         Interpreter intr = ((Interpreter)i.next());
         //System.out.println("Disabling: " + intr.getClass() + ":" + intr.getName());
         intr.setEnabled(false);
      }
      
      // Disable inking of sheet
      sheet.setInkOn(false);
      
      // HACK: Enable left button gestures
      sheet.setEnableLeftButtonGestures(true);
      
      // Allow all gesture interpreters to accept the left button
      sheet.acceptLeftWithAllGestures(false);
      
      c.add(this);
      int newX = p.x;
      int newY = p.y;
      
      if (newX < DenimConstants.DEFAULT_TOOLBOX_CUSHION) {
         newX = DenimConstants.DEFAULT_TOOLBOX_CUSHION;
      }
      if (newX > getParent().getWidth() -
                 DenimConstants.DEFAULT_TOOLBOX_CUSHION) {
         newX = getParent().getWidth() -
                DenimConstants.DEFAULT_TOOLBOX_CUSHION;
      }
      if (newY < DenimConstants.DEFAULT_TOOLBOX_CUSHION) {
         newY = DenimConstants.DEFAULT_TOOLBOX_CUSHION;
      }
      if (newY > getParent().getHeight() -
                 DenimConstants.DEFAULT_TOOLBOX_CUSHION) {
         newY = getParent().getHeight() - 
                DenimConstants.DEFAULT_TOOLBOX_CUSHION;
      }
      
      setLocation(newX - hotSpot.x, newY - hotSpot.y);
      super.setVisible(true);
      activate();
   }
   
   //-----------------------------------------------------------------

   /**
    * Makes the tool responsible for handling mouse events.
    */
   private void activate() {
      addMouseListener(this);
      isPickedUp = false;
   }
   
   //-----------------------------------------------------------------

   /**
    * Makes the tool ignore any mouse events.
    */
   private void deactivate() {
      removeMouseListener(this);
      isPickedUp = true;
   }
   
   //-----------------------------------------------------------------

   /**
    * Returns the standard system cursor used by the tool. If the tool
    * uses a special cursor, then returns null.
    */
   public Cursor getToolCursor() {
      return toolCursor;
   }

   //-----------------------------------------------------------------
   /**
    * Returns the name of the tool.
    */
   public String getName() {
      return name;  
   }
   
   //-----------------------------------------------------------------
   
   /**
    * Sets the visibility of the tool. When the tool is invisible, the
    * default mouse cursor is shown.
    */
   public void setVisible(boolean flag) {
      if (isPickedUp) {
         // If we want the tool to be visible, change the cursor to the
         // tool's cursor
         if (flag) {
            getDenimUI().setCursor(toolCursor);
         }
         // Otherwise, set the mouse cursor to the blank one.
         else {
            getDenimUI().setCursor(DenimUtils.getBlankCursor());
         }
      }
      else {
         super.setVisible(flag);
      }
   }

   //-----------------------------------------------------------------

   /**
    * Returns the containing DENIM user interface.
    */
   protected DenimUI getDenimUI() {
      return ui;
   }
   
   //===   TOOL METHODS   ======================================================
   //===========================================================================


   
   //==========================================================================
   //===   TOOL CONTAINER   ===================================================

   public int getLastX() {
      return lastX;
   }
   
   //-----------------------------------------------------------------

   public int getLastY() {
      return lastY;
   }

   //===   TOOL CONTAINER   ===================================================
   //==========================================================================

   
   //==========================================================================
   //===   MOUSE LISTENER   ===================================================
   
   /**
    * Called when the designer presses on the tool with the mouse button.
    * This should only be called when the designer picks up a tool from
    * the sheet or tools area of the toolbox.
    */
   public void mousePressed(MouseEvent e) {
      DenimUI mainWindow = getDenimUI();
         
      //System.out.println("Tool.mousePressed:");
         
      // If tool is tapped in toolbox, or if tool is tapped in sheet
      // then pick it up
      if (SwingUtilities.isLeftMouseButton(e)) {
         Tool currentTool = mainWindow.getCurrentTool();
         if (currentTool != null) {
            Container parent = getParent();
            Point parentPt =
               SwingUtilities.convertPoint(Tool.this, e.getPoint(), parent);
            currentTool.drop(parent, parentPt);
         }
         grab();
      }
   }

   //-----------------------------------------------------------------

   public void mouseEntered(MouseEvent e) {
      // Tell the DENIM UI to keep track of the fact that the mouse
      // cursor is within this tool.
      
      getDenimUI().setContainerWithTool(Tool.this);
   }

   //-----------------------------------------------------------------

   public void mouseExited(MouseEvent e) {
      // Tell the DENIM UI to keep track of the fact that the mouse
      // cursor is NOT within this tool.
      getDenimUI().setContainerWithTool(null);
   }
   
   //-----------------------------------------------------------------

   public void mouseClicked(MouseEvent e) {}
   
   public void mouseReleased(MouseEvent e) {}

   //-----------------------------------------------------------------

   public void mouseDragged(MouseEvent evt) { 
      // Keep track of the mouse cursor position. Needed for ToolContainer.
      lastX = evt.getX();
      lastY = evt.getY();
   } // of mouseDragged

   //-----------------------------------------------------------------

   public void mouseMoved(MouseEvent evt) { 
      // Keep track of the mouse cursor position. Needed for ToolContainer.
      lastX = evt.getX();
      lastY = evt.getY();
   } // of mouseMoved
   
   //===   MOUSE LISTENER   ===================================================
   //==========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
