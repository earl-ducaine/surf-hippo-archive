//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.command;

import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.debugging.*;
import java.io.Serializable;
import java.awt.geom.*;
import java.util.*;

/**
 * A clipboard for the cut, copy, and paste commands.
 * This is just a temporary measure, until we use the actual Java provided
 * clipboard. It's a waste of time to get that working at this stage.
 * <P>
 * There are two ways to use this. There is a universal clipboard that can be
 * retrieved via class method getClipboard(). Alternatively, individual
 * clipboards can be created via the constructor.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Jun 22 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.2-1.0.0, Aug 11 2004, YL
 *               copyToClipboard: parentAbsXforms = new AffineTransform if parent is null.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author  <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *          <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version SATIN-v2.2-1.0.0, Aug 11 2004
 */
public class Clipboard 
   implements Serializable, 
              SatinConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = -8681551454772904393L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NON-LOCAL VARIABLES   ===============================================

   /**
    * The clipboard contents
    */
   protected GraphicalObjectCollection gobcol;
   
   /**
    * The absolute transforms of the clipboard contents (in the same order
    * as the contents), not including the sheet's transform
    */
   protected List parentAbsXforms;
   
   //// The following two aren't used in Clipboard, but are here in case
   //// a subclass of Clipboard wants to use the information.
   
   /**
    * A map mapping the graphical object originally cut or copied to the
    * to its copy in the clipboard.
    */
   protected Map fromOrigToClipboard;
   
   /**
    * A map mapping an object in the clipboard to its copy when getContents()
    * is called.
    */
   protected Map fromClipboardToPasted;

   //===   NON-LOCAL VARIABLES   ===============================================
   //===========================================================================



   //===========================================================================
   //===   CLASS METHODS   =====================================================

   //===   CLASS METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public Clipboard() {
      gobcol = new GraphicalObjectCollectionImpl();
      parentAbsXforms = new LinkedList();
      fromOrigToClipboard = new HashMap();
      fromClipboardToPasted = new HashMap();
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   
   private void mapOrigToClone(Map origToClone, GraphicalObject orig,
                               GraphicalObject clone) {
      origToClone.put(orig, clone);
      if (orig instanceof GraphicalObjectGroup) {
         GraphicalObjectGroup origGrp = (GraphicalObjectGroup)orig;
         GraphicalObjectGroup cloneGrp = (GraphicalObjectGroup)clone;
         
         Iterator origIt = origGrp.getForwardIterator();
         Iterator cloneIt = cloneGrp.getForwardIterator();
         while (origIt.hasNext()) {
            GraphicalObject origChild = (GraphicalObject)origIt.next();
            GraphicalObject cloneChild = (GraphicalObject)cloneIt.next();
            
            mapOrigToClone(origToClone, origChild, cloneChild);
         }
      }
   }

   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Gets a collection of copies of GraphicalObjects in the clipboard. Keep 
    * in mind that some of these GraphicalObjects may be groups.
    *
    * @return a collection of GraphicalObjects in the clipboard.
    */
   public GraphicalObjectCollection getContentsCollection() {
      //// 1. Return a copy of the clipboard contents.
      ////    It is important to return a copy, since we don't want to mess
      ////    around with the originals.
      GraphicalObjectCollection gobcolClone;
      gobcolClone = (GraphicalObjectCollection) gobcol.deepClone();

      // Something is wrong with GraphicalObjectCollection.deepClone()
      assert gobcol.numElements() == gobcolClone.numElements();
      
      //// 2. Store the mapping from clipboard objects to their clones
      fromClipboardToPasted.clear();
      Iterator origIt = gobcol.getForwardIterator();
      Iterator cloneIt = gobcolClone.getForwardIterator();
      while (origIt.hasNext()) {
         GraphicalObject gob = (GraphicalObject)origIt.next();
         GraphicalObject gobClone = (GraphicalObject)cloneIt.next();
         mapOrigToClone(fromClipboardToPasted, gob, gobClone);
      }

      return (gobcolClone);
   }
   
   /**
    * Gets an Iterator over copies of GraphicalObjects in the clipboard. Keep 
    * in mind that some of these GraphicalObjects may be groups.
    *
    * @return an Iterator over GraphicalObjects in the clipboard.
    */
   public Iterator getContents() {
      //// 1. Return an iterator.
      return (getContentsCollection().getForwardIterator());
   } // of getContents

   //-----------------------------------------------------------------
   
   /**
    * Returns a copy of a list of the absolute transforms of the original
    * parents of the graphical objects in the clipboard. (The transforms do
    * not include the transforms of the graphical objects' sheets.) The
    * order of this list corresponds to the order of objects in getContents().
    */
   public Iterator getParentAbsXforms() {
      //// 1. Return an iterator to a copy of the transforms.
      ////    It is important to return a copy, since we don't want to mess
      ////    around with the originals.
      List copy = new LinkedList();
      Iterator it = parentAbsXforms.iterator();
      while (it.hasNext()) {
         AffineTransform xform = (AffineTransform)it.next();
         copy.add(new AffineTransform(xform));
      }
      
      return copy.iterator();
   } // of getContents

   
   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   MODIFIER METHODS   ==================================================

   /**
    * Places a copy of the specified GraphicalObject on the clipboard. 
    *
    * @param gob is the Graphical Object to copy to the clipboard.
    */
   public void copyToClipboard(GraphicalObject gob) {
      try {
         //// 1. Clone the graphical object to put into the clipboard.
         GraphicalObject gobTmp = (GraphicalObject) gob.deepClone();
         //debug.println("To clipboard: " +
         //                   edu.berkeley.guir.denim.DenimUtils.toShortString(gob) + "->" +
         //                   edu.berkeley.guir.denim.DenimUtils.toShortString(gobTmp));

         //// 2. Store the mapping from the object to its clone.
         mapOrigToClone(fromOrigToClipboard, gob, gobTmp);
         
         //// 3. Add the clone to the clipboard.
         gobcol.addToBack(gobTmp);
         gobTmp.removeWatcher(gobcol);
         
         //// 4. Store the absolute transform (without the sheet's transform)
         ////    of the object's parent.
         if (gob.getParentGroup() != null) {
            AffineTransform xform = gob.getParentGroup().getTransform(COORD_ABS);
            xform.preConcatenate(gob.getSheet().getInverseTransform(COORD_ABS));
            parentAbsXforms.add(xform);
         }
         else {
            parentAbsXforms.add(new AffineTransform());//null);
         }
      }
      catch (Exception e) {
         Debug.println("Argh, matey! Ye have a GraphicalObject clone error!");
         Debug.println(e);
      }
   } // of copyToClipboard

   //-----------------------------------------------------------------

   /**
    * Copies a collection of Graphical Object to the clipboard.
    *
    * @param it is the collection of Graphical Objects. Ignores elements
    *        within that are not Graphical Objects.
    */
   public void copyToClipboard(Iterator it) {
      Object          obj;

      //// 1. Copy the contents.
      while (it.hasNext()) {
         obj = it.next();
         if (obj instanceof GraphicalObject) {
            copyToClipboard((GraphicalObject) obj);
         }
      } 
   } // of copyToClipboard

   //-----------------------------------------------------------------

   /**
    * Removes an item from the clipboard.
    *
    * @param gob is the Graphical Object to remove from the clipboard.
    */
   public void removeFromClipboard(GraphicalObject gob) {
      gobcol.remove(gob);
   } // of removeFromClipboard

   //-----------------------------------------------------------------

   /**
    * Clears the contents of the clipboard.
    */
   public void clearClipboard() {
      gobcol.clear();
      parentAbsXforms.clear();
      fromOrigToClipboard.clear();
      fromClipboardToPasted.clear();
   } // of clearClipboard

   //-----------------------------------------------------------------

   /**
    * Sets the clipboard contents to the specified collection of Graphical
    * Objects, erasing whatever was there before. This is just like 
    * copyToClipboard() except that it replaces anything that was there.
    *
    * @param it is the collection of Graphical Objects. Ignores elements
    *        within that are not Graphical Objects.
    */
   public void setContents(Iterator it) {
      //// 1. Clear the clipboard first.
      clearClipboard();

      //// 2. Copy the contents.
      copyToClipboard(it);
   } // of setContents

   //===   MODIFIER METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      return (gobcol.toString());
   } // of toString

   //===   TOSTRING   ==========================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
