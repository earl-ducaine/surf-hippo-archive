package edu.berkeley.guir.damask.view;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.Logger;

/** 
 * Handles any uncaught exceptions 
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  mm-dd-yyyy James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public class DamaskAppExceptionHandler {
   private static final Logger logger =
      Logger.getLogger(DamaskAppExceptionHandler.class.getName());

   public void handle(Throwable thrown) {
      log(thrown);
   }

   public static void log(Throwable thrown) {
      final StringWriter stringWriter = new StringWriter();
      final PrintWriter printWriter = new PrintWriter(stringWriter);
      thrown.printStackTrace(printWriter);
      logger.severe(stringWriter.toString());
   }
}
