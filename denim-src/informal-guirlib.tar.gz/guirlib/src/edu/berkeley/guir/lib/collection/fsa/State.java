//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.fsa;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * 
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Mar 09 2003 JIH
 */
class State {

    //==========================================================================
    //===   CONSTANTS   ========================================================

    public static final String ALL_TRANSITION     = "all-input";
    public static final String DEFAULT_TRANSITION = "unknown-input";
    public static final String TIMEOUT_TRANSITION = "timeout-input";

    //----------------------------------------------------------------

    private static final boolean DEBUG = true;

    //===   CONSTANTS   ========================================================
    //==========================================================================




    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    FiniteStateAutomata fsa;

    //----------------------------------------------------------------

    String   strName           = "unnamed";
    int      timeout           = Integer.MAX_VALUE;
    Map      mapTransitions    = new HashMap(); // input          -> next state
    Map      mapOnEnterActions = new HashMap(); // previous state -> action
    Map      mapOnExitActions  = new HashMap(); // next state     -> action

    Action   timeoutAction     = Action.EMPTY;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    public State(String newName) {
        strName = newName;
        commonInit();
    } // of constructor

    //----------------------------------------------------------------

    /**
     * @param millis is the number of milliseconds to wait before timeout.
     */
    public State(String newName, int millis) {
        strName = newName;
        timeout = millis;
        commonInit();
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Put an empty transition in for unknown input.
     */
    private void commonInit() {
        mapTransitions.put(DEFAULT_TRANSITION, strName);
        mapTransitions.put(TIMEOUT_TRANSITION, strName);
    } // of method

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================




    //==========================================================================
    //===   ACCESSOR / MODIFIER METHODS   ======================================

    public String getName() {
        return (strName);
    } // of method

    //----------------------------------------------------------------

    /**
     * @param timeout in millis
     */
    public int getTimeout() {
        return (timeout);
    } // of method


    /**
     * For setting timeout separately. 
     */
    public void setTimeout(int millis) {
        timeout = millis;
    } // of method

    //===   ACCESSOR / MODIFIER METHODS   ======================================
    //==========================================================================




    //==========================================================================
    //===   STATE METHODS   ====================================================

    /**
     * Get the FiniteStateAutomata that this State is part of.
     */
    public FiniteStateAutomata getFiniteStateAutomata() {
        return (fsa);
    } // of method

    /**
     * Automatically called when this State instance is added
     * to a FiniteStateAutomata.
     */
    public void setFiniteStateAutomata(FiniteStateAutomata newFsa) {
        fsa = newFsa;
    } // of method

    //----------------------------------------------------------------

    /**
     * Associate a transition with some input.
     * Right now only works with exact matches.
     */
    public void addTransition(String strInput, String strNextState) {
        mapTransitions.put(strInput, strNextState);
    } // of method

    //----------------------------------------------------------------

    /**
     * Do what happens on unknown input.
     * If undefined, default is to stay in the current state.
     */
    public void setDefaultTransition(String strNextState) {
        mapTransitions.put(DEFAULT_TRANSITION, strNextState);
    } // of method

    //----------------------------------------------------------------

    /**
     * Do the specified transition on timeout.
     */
    public void setTimeoutTransition(String strNextState) {
        mapTransitions.put(TIMEOUT_TRANSITION, strNextState);
    } // of method


    /**
     * Set the timeout and the next state.
     */
    public void setTimeoutTransition(String strNextState, int millis) {
        setTimeout(millis);
        setTimeoutTransition(strNextState);
    } // of method

    //----------------------------------------------------------------

    public String getTransition(String strInput) {
        String strNextState = (String) mapTransitions.get(strInput);
        if (strNextState == null) {
            strNextState = getDefaultTransition();
        }
        return (strNextState);
    } // of method


    /**
     * Get the transition associated with unknown input.
     */
    public String getDefaultTransition() {
        return ((String) mapTransitions.get(DEFAULT_TRANSITION));
    } // of method


    /**
     * Get the transition associated with timeout.
     */
    public String getTimeoutTransition() {
        return ((String) mapTransitions.get(TIMEOUT_TRANSITION));
    } // of method

    //----------------------------------------------------------------

    /**
     * Execute any associated action and then do the state transition.
     */
    public void handleInput(String strInput) {
        String strNextState = getTransition(strInput);
        getFiniteStateAutomata().setCurrentState(strNextState);
    } // of method

    //===   STATE METHODS   ====================================================
    //==========================================================================




    //==========================================================================
    //===   STATE TRANSITION ACTION METHODS   ==================================

    public void addOnEnterAction(String strPrevState, Action action) {
        mapOnEnterActions.put(strPrevState, action);
    } // of method

    public void addOnEnterDefaultAction(Action action) {
        mapOnEnterActions.put(ALL_TRANSITION, action);
    } // of method

    /**
     * Get the action that takes place when we enter this state from
     * strPrevState.
     */
    public Action getOnEnterAction(String strPrevState) {
        Action action = (Action) mapOnEnterActions.get(strPrevState);
        if (action == null) {
            action = (Action) mapOnEnterActions.get(ALL_TRANSITION);
        }
        if (action == null) {
            action = Action.EMPTY;
        }
        return (action);
    } // of method

    //----------------------------------------------------------------

    public void addOnExitAction(String strPrevState, Action action) {
        mapOnExitActions.put(strPrevState, action);
    } // of method

    public void addOnExitDefaultAction(Action action) {
        mapOnExitActions.put(ALL_TRANSITION, action);
    } // of method

    /**
     * Get the action that takes place when we enter this state from
     * strPrevState.
     */
    public Action getOnExitAction(String strPrevState) {
        Action action = (Action) mapOnExitActions.get(strPrevState);
        if (action == null) {
            action = (Action) mapOnExitActions.get(ALL_TRANSITION);
        }
        if (action == null) {
            action = Action.EMPTY;
        }
        return (action);
    } // of method

    //----------------------------------------------------------------

    public void addTimeoutAction(Action action) {
        timeoutAction = action;
    } // of method

    /**
     * Executed *before* onEnter() or onExit()
     */
    public Action getTimeoutAction() {
        return (timeoutAction);
    } // of method

    //===   STATE TRANSITION ACTION METHODS   ==================================
    //==========================================================================




    //==========================================================================
    //===   TOSTRING   =========================================================

    public String toString() {
        StringBuffer strbuf = new StringBuffer();
        Iterator     it;
        List         listKeys;
        String       strInput;
        String       strState;


        //// 1. Copy simple values over.
        strbuf.append("name: " + getName());
        if (getTimeout() != Integer.MAX_VALUE) {
            strbuf.append("\ntimeout: " + getTimeout());
        }
        strbuf.append("\ntransitions (input -> next-state):");


        //// 2.1. Get all keys except for special cases.
        listKeys = new LinkedList(mapTransitions.keySet());
        listKeys.remove(ALL_TRANSITION);
        listKeys.remove(DEFAULT_TRANSITION);
        listKeys.remove(TIMEOUT_TRANSITION);


        //// 2.2. Append all transitions.
        it = listKeys.iterator();
        while (it.hasNext()) {
            strInput = (String) it.next();
            strbuf.append("\n");
            strbuf.append(toString(strInput));
        }

        //// 2.3. Append the timeout transition.
        strInput = TIMEOUT_TRANSITION;
        if (mapTransitions.get(strInput) != null) {
            strbuf.append("\n");
            strbuf.append(toString(strInput));
        }

        //// 2.4. Append the default transition.
        strInput = DEFAULT_TRANSITION;
        if (mapTransitions.get(strInput) != null) {
            strbuf.append("\n");
            strbuf.append(toString(strInput));
        }

        //// 3. Append the onEnter() actions.
        listKeys = new LinkedList(mapOnEnterActions.keySet());
        listKeys.remove(ALL_TRANSITION);
        it = listKeys.iterator();

        strbuf.append("\nonEnter() (state -> action)");
        while (it.hasNext()) {
            strbuf.append("\n   ");
            strState = (String) it.next();
            strbuf.append(strState);
            strbuf.append(" -> ");
            strbuf.append(mapOnEnterActions.get(strState));
        }

        strState = ALL_TRANSITION;
        if (mapOnEnterActions.get(strState) != null) {
            strbuf.append("\n   ");
            strbuf.append(strState);
            strbuf.append(" -> ");
            strbuf.append(mapOnEnterActions.get(strState));
        }

        //// 4. Append the onExit() actions.
        listKeys = new LinkedList(mapOnExitActions.keySet());
        listKeys.remove(ALL_TRANSITION);
        it = listKeys.iterator();

        strbuf.append("\nonExit() (state -> action)");
        while (it.hasNext()) {
            strbuf.append("\n   ");
            strState = (String) it.next();
            strbuf.append(strState);
            strbuf.append(" -> ");
            strbuf.append(mapOnExitActions.get(strState));
        }

        strState = ALL_TRANSITION;
        if (mapOnExitActions.get(strState) != null) {
            strbuf.append("\n   ");
            strbuf.append(strState);
            strbuf.append(" -> ");
            strbuf.append(mapOnExitActions.get(strState));
        }


        //// Return.
        return (strbuf.toString());
    } // of method

    //----------------------------------------------------------------

    /**
     */
    protected String toString(String strInput) {
        String strNextState = (String) mapTransitions.get(strInput);
        Action action       = getOnExitAction(strNextState);
        String strAction;

        if (action == null) {
            strAction = "";
        }
        else {
            strAction = " (Action: " + action.getName() + ")";
        }
        return ("   " + strInput + " -> " + strNextState + strAction);
    } // of method

    //===   TOSTRING   =========================================================
    //==========================================================================





    //==========================================================================
    //===   SELF-TESTING MAIN   ================================================

    public static void main(String[] argv) throws Exception {
    } // of main

    //===   SELF-TESTING MAIN   ================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
