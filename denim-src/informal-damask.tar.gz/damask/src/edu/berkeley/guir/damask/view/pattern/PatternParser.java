package edu.berkeley.guir.damask.view.pattern;

import java.io.IOException;
import java.net.URL;
import java.util.*;

import javax.xml.bind.JAXBException;

import org.jdom.*;
import org.jdom.input.SAXBuilder;

import edu.berkeley.guir.damask.io.DamaskReader;
import edu.berkeley.guir.damask.pattern.Pattern;
import edu.berkeley.guir.damask.pattern.PatternLibrary;
import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;

/**
 * Parses a pattern file in PLML format into an instance of
 * {@link edu.berkeley.guir.damask.pattern.Pattern}.
 *  
 * <P>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * @author Qing Li
 * @author <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */
public class PatternParser {
   private static final Namespace HTML_NAMESPACE =
      Namespace.getNamespace("html", "http://www.w3.org/1999/xhtml");
   private static final Namespace DEFAULT_NAMESPACE =
      Namespace.getNamespace("", "http://www.hcipatterns.org");
   
   /**
    * Prevents instantiation.
    */
   private PatternParser() {}
   
   /**
    * Parses the pattern file with the specified URL, and returns a Pattern
    * instance.
    */
   public static Pattern parse(final URL patternURL) {
      final Pattern pattern = new Pattern();
      parseInto(patternURL, pattern);
      return pattern;
   }


   /**
    * Parses the pattern file with the specified URL, and fills in the
    * specified Pattern instance with information from that URL.
    */
   public static void parseInto(final URL patternURL, final Pattern pattern) {
      final SAXBuilder builder = new SAXBuilder();
      try {
         final Document doc = builder.build(patternURL);
         final Element root = doc.getRootElement();
         fillInPattern(root, pattern);
      }
      catch (JDOMException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (IOException e) {
         DamaskAppExceptionHandler.log(e);
      }
   }


   /**
    * Returns the collection ID and pattern ID of the pattern described by the
    * specified URL. This has lower overhead than calling parse().
    * 
    * @return an array of Strings. This first one is the collection ID,
    * and the second one is the pattern ID.
    */
   public static String[] getPatternIDs(final URL patternURL) {
      final SAXBuilder builder = new SAXBuilder();
      try {
         final Document doc = builder.build(patternURL);
         final Element root = doc.getRootElement();
         
         final String[] result = new String[2];
         result[0] = root.getAttributeValue("collectionID");
         result[1] = root.getAttributeValue("patternID");
         
         return result;
      }
      catch (JDOMException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (IOException e) {
         DamaskAppExceptionHandler.log(e);
      }
      return new String[] {};
   }


   /**
    * Parses the name of the pattern described by the specified URL. This has
    * lower overhead than calling parse().
    */
   public static String getPatternName(final URL patternURL) {
      final SAXBuilder builder = new SAXBuilder();
      try {
         final Document doc = builder.build(patternURL);
         final Element root = doc.getRootElement();
         return root.getChildText("name", DEFAULT_NAMESPACE);
      }
      catch (JDOMException e) {
         DamaskAppExceptionHandler.log(e);
      }
      catch (IOException e) {
         DamaskAppExceptionHandler.log(e);
      }
      return null;
   }

   
   /**
    * Fills in the specified pattern with information from the DOM with the
    * specified root element.
    */
   private static void fillInPattern(final Element root, final Pattern pattern) {
      pattern.setID(root.getAttributeValue("patternID"));
      pattern.setCollectionID(root.getAttributeValue("collectionID"));

      pattern.setName(root.getChildText("name", DEFAULT_NAMESPACE));
      
      {
         final Element element = root.getChild("illustration", DEFAULT_NAMESPACE);
         pattern.setIllustrationText(convertDOMElementToHTML(element, null));
         pattern.setIllustrationURL(getFirstImageURL(element));
      }
      
      pattern.setProblem(convertDOMElementToHTML(root.getChild("problem", DEFAULT_NAMESPACE), null));
      
      {
         final List/*<Pattern>*/ inPatterns = new ArrayList/*<Pattern>*/();
         pattern.setBackground(
            convertDOMElementToHTML(root.getChild("context", DEFAULT_NAMESPACE), inPatterns));
         
         for (Iterator i = inPatterns.iterator(); i.hasNext(); ) {
            final Pattern inPattern = (Pattern)i.next();
            pattern.addInRef(inPattern);
         }
      }
      
      pattern.setSolutionText(
         convertDOMElementToHTML(root.getChild("solution", DEFAULT_NAMESPACE), null));
      
      {
         final Element element = root.getChild("diagram", DEFAULT_NAMESPACE);
         pattern.setSolutionImageText(convertDOMElementToHTML(element, null));
         pattern.setSolutionImageURL(getFirstImageURL(element));
      }
      
      {
         final Element implementation =
            root.getChild("implementation", DEFAULT_NAMESPACE);
         if (implementation != null) {
            final Element anchor =
               implementation.getChild("a", HTML_NAMESPACE);
            final String dmkBaseFileName =
               anchor.getAttributeValue("href");
            try {
               final URL patternSolutionURL =
                  Pattern.class.getResource(dmkBaseFileName);
               if (patternSolutionURL != null) {
                  pattern.setSolution(
                     DamaskReader.open(patternSolutionURL, pattern));
               }
            }
            catch (JAXBException e1) {
               DamaskAppExceptionHandler.log(e1);
            }
         }
      }
      
      {
         final List/*<Pattern>*/ outPatterns = new ArrayList/*<Pattern>*/();
         pattern.setRelatedPatternsText(
            convertDOMElementToHTML(
               root.getChild("related-patterns", DEFAULT_NAMESPACE), outPatterns));
         
         for (Iterator i = outPatterns.iterator(); i.hasNext(); ) {
            final Pattern outPattern = (Pattern)i.next();
            pattern.addOutRef(outPattern);
         }
      }
      
      pattern.setCredits(
         convertDOMElementToHTML(
            root.getChild("management", DEFAULT_NAMESPACE)
                .getChild("credits", DEFAULT_NAMESPACE), null));
   }

   
   /**
    * Returns the URL of the image referenced in the first <html:img> tag
    * under the specified element (by depth-first search).
    */
   private static URL getFirstImageURL(final Element element) {
      if (element.getName().equals("img")) {
         return Pattern.class.getResource(element.getAttributeValue("src"));
      }
      else {
         URL url = null;
         for (Iterator i = element.getChildren().iterator(); i.hasNext(); ) {
            final Element child = (Element)i.next(); 
            url = getFirstImageURL(child);
            if (url != null) {
               break;
            }
         }
         return url;
      }
   }
   
   
   /**
    * Returns the contents of the specified element as HTML, and adds links
    * to patterns within the element to the specified list.
    * 
    * <p>If patternLinks is null, then no links will be added.
    */
   private static String convertDOMElementToHTML(
         final Element element, final List/*<Pattern>*/ patternLinks) {

      final StringBuffer sb = new StringBuffer();
      
      for (Iterator i = element.getContent().iterator(); i.hasNext(); ) {
         final Object obj = i.next();
         if (obj instanceof Text) {
            sb.append(((Text)obj).getText());
         }
         else if (obj instanceof Element) {
            final Element elem = (Element) obj;
            final String tag = elem.getName();
            if (tag.equals("a")) {
               sb.append("<a class=\"val\" href=\"" + elem.getAttributeValue("href") + "\">");
               sb.append(elem.getText() + "</a>");
            }
            else if (tag.equals("pattern-link")) {
               final String patternName = elem.getText();
               final String patternID = elem.getAttributeValue("patternID");
               final String collectionID = elem.getAttributeValue("collectionID");
               
               sb.append(
                  "<a class=\"val\" href=\"" +
                  PatternBrowser.createPatternLinkURLString(
                     collectionID, patternID) +
                  "\">" + patternName + "</a>");
                     
               if (patternLinks != null) {
                  patternLinks.add(
                     PatternLibrary.getPattern(collectionID, patternID));
               }
            }
            else {
               sb.append(convertDOMElementToHTML(elem, patternLinks));
            }
         }
      }
      return sb.toString().trim();
   }
}