//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.event;

import edu.berkeley.guir.lib.awt.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.objects.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;

/**
 * An abstract class representing an event signalling a stroke has 
 * been completed.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Oct 29 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * 			   - SATIN-v2.1-2.0.0, Nov 21, 2002, YL
 * 				 Add event dispatching cache
 * 				 
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Nov 21, 2002
 */
public abstract class StrokeEvent
   extends    SatinEvent 
   implements SatinConstants {

   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   MouseEvent      evt; 
   int             evtX;
   int             evtY;

   TimedStroke     stroke;
   AffineTransform strokeTx;

   boolean         flagDirty = false;

   // event dispatching cache    
   Vector dispatchingPath = new Vector();

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Create a new StrokeEvent object.
    *
    * @param source is the object creating this StrokeEvent.
    */
   public StrokeEvent(Object source) {
      super(source);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a new StrokeEvent object.
    *
    * @param source is the object creating this StrokeEvent.
    */
   public StrokeEvent(Object source, TimedStroke stroke) {
      this(source);
      this.stroke   = stroke;
      this.strokeTx = stroke.getTransform(COORD_REL);
   } // of constructor

   //-----------------------------------------------------------------

   /**
    * Create a new StrokeEvent object.
    *
    * @param source is the object creating this StrokeEvent.
    * @param evt    is an associated AWT Event.
    */
   public StrokeEvent(Object source, TimedStroke stroke, MouseEvent evt) {
      this(source, stroke);
      this.evt    = evt;
      this.evtX   = evt.getX();
      this.evtY   = evt.getY();
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   //===========================================================================
   //===   EVENT DISPATCH CACHE METHODS   ==================================================

   /**
    * set the dispatching cache by a path in scenegraph
    * @param path
    */
   
   public void setDispatchingCache(Vector path) {
   		dispatchingPath = path;
   }

   //-----------------------------------------------------------------
      
   public GraphicalObject getNextDispatchee(GraphicalObject obj) {

   		int index = dispatchingPath.indexOf(obj)+1;

   		if(index>=dispatchingPath.size())
   			return null;
   			
   		return (GraphicalObject)dispatchingPath.get(index);
   }

   //-----------------------------------------------------------------
      
   public void appendDispatchee(GraphicalObject obj) {

   		if(dispatchingPath.contains(obj))
   		{
			return;   			
   		}
   		
   		dispatchingPath.add(obj);
   		
   }

   //-----------------------------------------------------------------
      
   public void removeDispatchee(GraphicalObject obj) {

   	   int index = dispatchingPath.indexOf(obj);

   	   for(int i=dispatchingPath.size()-1; i>=index; i--)
   	   {
   	      dispatchingPath.remove(i);
   	   }
  		
   }

   //-----------------------------------------------------------------
      
   public int indexofDispatchee(GraphicalObject obj) {
   		return dispatchingPath.indexOf(obj);
   }
   
   //-----------------------------------------------------------------
   
   public void clearDispatchingCache() {
   		dispatchingPath.clear();
   }

   //===   EVENT DISPATCH CACHE METHODS   ======================================
   //===========================================================================


   //===========================================================================
   //===   CALLBACK METHODS   ==================================================

   /**
    * Make sure that we get the correct transformed version of the stroke.
    */
   private void clean() {
      if (flagDirty == true) {
         stroke.setTransform(strokeTx);
         stroke.applyTransform(tx);
         flagDirty = false;
      }
   } // of method

   //-----------------------------------------------------------------

   /**
    * Apply the transform to the stroke and to the event.
    */
   protected void onApplyTransform(AffineTransform newTx) {
      clean();

      stroke.applyTransform(newTx);
      EventUtil.applyTransform(evt, tx);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Apply the transform to the stroke and to the event.
    */
   protected void onSetTransform(AffineTransform newTx) {
      //// 1. Transform the stroke.
      stroke.setTransform(strokeTx);
      stroke.applyTransform(newTx);

      //// 2. Transform the mouse event.
      EventUtil.setPosition(evt, evtX, evtY);
      EventUtil.applyTransform(evt, tx);
   } // of method

   //===   CALLBACK METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR METHODS   ==================================================

   /**
    * Does the stroke use the left button? Only registers as left button
    * if neither middle and right are down too.
    */
   public boolean isLeftButton() {
      return (stroke.isLeftButton() && 
              !(stroke.isMiddleButton() || stroke.isRightButton()));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Does the stroke use the middle button?
    */
   public boolean isMiddleButton() {
      return (stroke.isMiddleButton());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Does the stroke use the right button?
    */
   public boolean isRightButton() {
      return (stroke.isRightButton());
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a reference to the Stroke object this event represents, after the
    * transformations have been applied (ie in relative coordinate, relative to
    * the last GraphicalObject that handled this event).
    *
    * @return a TimedStroke object.
    */
   public TimedStroke getStroke() {
      clean();
      return(stroke);
   } // of method


   public void setStroke(TimedStroke stk) {
      this.stroke   = stk;
      this.strokeTx = stroke.getTransform(COORD_REL);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a reference to the Stroke object this event represents, before the
    * transformations have been applied (ie in absolute coordinates).
    * <P>
    * This method is needed since, when adding, GraphicalObjectGroup converts
    * the object to add into its own coordinate system, so using getStroke()
    * applies the transform twice.
    *
    * @return a TimedStroke object.
    */
   public TimedStroke getUntransformedStroke() {
      stroke.setTransform(strokeTx);
      return (stroke);
   } // of method

   //===   ACCESSOR METHODS   ==================================================
   //===========================================================================



   //===========================================================================
   //===   MOUSE METHODS   =====================================================

   /**
    * Get a reference to the corresponding mouse event, after the 
    * transformations have been applied (ie in relative coordinates, relative 
    * to the last GraphicalObject that handled this event).
    */
   public MouseEvent getMouseEvent() {
      return (evt);
   } // of method

   //-----------------------------------------------------------------

   public void setMouseEvent(MouseEvent newEvt) {
      evt = newEvt;
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get a reference to the corresponding mouse event, before the 
    * transformations have been applied (ie in absolute coordinates).
    */
   public MouseEvent getUntransformedMouseEvnet() {
      EventUtil.setPosition(evt, evtX, evtY);
      return (evt);
   } // of method

   //===   MOUSE METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      StringBuffer strbuf = new StringBuffer();
      strbuf.append(getClass() + "\n");
      strbuf.append("Transform: " + getTransform() + "\n");
      strbuf.append("Stroke:    " + stroke         + "\n");
      strbuf.append("Stroke Tx: " + strokeTx);
      return (strbuf.toString());
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
