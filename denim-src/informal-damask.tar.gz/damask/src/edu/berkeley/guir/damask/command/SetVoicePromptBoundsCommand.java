package edu.berkeley.guir.damask.command;

import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/** 
 * A command that changes the bounds of a voice prompt in a control.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-16-2004 James Lin
 *                               Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-16-2004
 */
public class SetVoicePromptBoundsCommand
   extends UndoableCommand
   implements ModifyGraphCommand {

   private final Control control;
   
   private final Rectangle2D newVoicePromptBounds;
   private final Rectangle2D oldVoicePromptBounds;

   /**
    * Constructs the command.
    * 
    * @param element the element whose bounds is to be updated
    * @param newBounds the new bounds of the element
    */
   public SetVoicePromptBoundsCommand(
      final Control control,
      final Rectangle2D newVoicePromptBounds) {
         
      this.control = control;
      this.newVoicePromptBounds = newVoicePromptBounds;
      oldVoicePromptBounds = control.getVoicePromptBounds();
   }


   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Set bounds of voice prompt of " + control +
         ": " + oldVoicePromptBounds + "->" + newVoicePromptBounds;
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      control.setVoicePromptBounds(newVoicePromptBounds);
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      control.setVoicePromptBounds(oldVoicePromptBounds);
   }
}
