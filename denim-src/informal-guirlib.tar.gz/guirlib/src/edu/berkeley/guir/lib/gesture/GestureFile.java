package edu.berkeley.guir.lib.gesture;

import java.io.*;
import java.text.ParseException;
import edu.berkeley.guir.lib.gesture.util.ExtensionFileFilter;
import javax.swing.filechooser.FileFilter;

/** An abstraction for reading & writing files containing GesturePackages */
public class GestureFile {
  public final String VERSION = "gdt 2.0";
  /** unknown file type */
  public final int UNKNOWN = -1;
  /** the file was in ASCII format (deprecated) */
  public final int ASCII = 0;
  /** the file was in binary format (deprecated) */
  public final int BINARY = 1;
  /** the file was in package format (also ASCII) */
  public final int PACKAGE = 2;

  protected GesturePackage gesturePackage;
  protected File file;
  protected int fileType = UNKNOWN;
  protected boolean autoSaveWasRead = false;
  protected boolean useAutoSave = true;

  public GestureFile(File f, GesturePackage gp)
  {
    file = f;
    gesturePackage = gp;
  }
  
  public GestureFile(File f)
  {
    this(f, null);
  }

  public void setGesturePackage(GesturePackage gp)
  {
    gesturePackage = gp;
  }

  public GesturePackage getGesturePackage()
  {
    return gesturePackage;
  }
  
  public void setUseAutosave(boolean useIt)
  {
    useAutoSave = useIt;
  }

  public boolean isUseAutosave()
  {
    return useAutoSave;
  }

  /** Write the gesturePackage to its file.  Overwrites any existing
      file. */
  public void write()
    throws IOException
  {
    Writer writer = new FileWriter(file);
    writer.write(VERSION + "\n");
    gesturePackage.write(writer);
  }

  public void writeAutoSave()
    throws IOException
  {
    Writer writer = new FileWriter(getAutoSaveFile());
    writer.write(VERSION + "\n");
    gesturePackage.write(writer);
  }
  
  /** Read the gesture set from the file.  If useAutoSave is true,
      reads autosave file if it exists and is newer.
   * @throws ClassNotFoundException indicates a problem with deserialization
   * @throws InvalidClassException indicates a problem with deserialization
   * @throws InvalidObjectException indicates a problem with deserialization
   * @throws ParseException probably a problem with ill-formed numbers
   */
  public void read()
  throws ClassNotFoundException, InvalidClassException,
	 InvalidObjectException, IOException, FileNotFoundException,
	 ParseException
  {
    File inputFile;
    boolean readBinaryFile = false;
    
    if (useAutoSave && doesNewerAutoSaveExist()) {
      inputFile = getAutoSaveFile();
      autoSaveWasRead = true;
    }
    else {
      inputFile = file;
      autoSaveWasRead = false;
    }

    GestureSet gestureSet = null;
    
    if (!inputFile.exists()) {
      throw new FileNotFoundException();
    }
    try { // first try binary format
      ObjectInputStream p =
	new ObjectInputStream(new FileInputStream(inputFile));
      try { // make sure file gets closed
	String v = (String) p.readObject();
	// todo: do something with version?
	Object obj = p.readObject();
	if (obj instanceof GestureSet) {
	  gestureSet = (GestureSet) obj;
	}
	else if (obj instanceof GestureCategory) {
	  if (gestureSet == null) {
	    gestureSet = new GestureSet();
	  }
	  gestureSet.add((GestureCategory) obj);
	}
	else {
	  throw new InvalidClassException("Unknown object type '" +
					  obj.getClass().getName() +
					  "'");
	}
	readBinaryFile = true;
	fileType = BINARY;
      }
      finally {
	p.close();
      }
    }
    catch (ClassNotFoundException e) {
      throw new ClassNotFoundException("Cannot find required class while reading file '"+
				       inputFile + "': " + e);
    }
    catch (InvalidClassException e) {
      throw new InvalidClassException("Problem with a class while reading file '"+
				      inputFile + "': " + e);
    }
    catch (StreamCorruptedException e) {
      // not a binary file, so try ASCII later
    }
    catch (ObjectStreamException e) {
      throw new InvalidObjectException("Expected an object but got primitive data while reading file '"+
				       inputFile + "': " + e);
    }
    catch (IOException e) {
      throw new IOException("I/O error reading file '"+
			    inputFile + "': " + e);
    }

    /*
    if (!readBinaryFile) {
      // wasn't a binary file, so try ASCII gesture set
      FileReader reader = new FileReader(inputFile);
      try {
	gestureSet = GestureSet.read(reader);
	fileType = ASCII;
      }
      finally {
	reader.close();
      }
    }
    */
    
    if (gestureSet == null) {
      FileReader reader = new FileReader(inputFile);
      BufferedReader br = new BufferedReader(reader);
      try {
	// still haven't read it, so try package format
	String v = br.readLine();
	if (canReadVersion(v)) {
	  gesturePackage = GesturePackage.read(br);
	  fileType = PACKAGE;
	}
	else {
	  // maybe it's an old GestureSet file
	  FileReader setReader = new FileReader(inputFile);
	  try {
	    gestureSet = GestureSet.read(setReader);
	    fileType = ASCII;
	  }
	  finally {
	    setReader.close();
	  }
	}
      }
      finally {
	reader.close();
      }
    }
    if (gestureSet != null) {
      gesturePackage = new GesturePackage(gestureSet);
      String packageName = gestureSet.getName();
      if (packageName == null) {
	String noDirectory = inputFile.getName();
	int extIndex = noDirectory.lastIndexOf('.');
	packageName = noDirectory.substring(0, extIndex);
      }
      gesturePackage.setName(packageName);

      gestureSet.setName("Training");
      gesturePackage.getTestSets().setName("Test");
    }
  }

  public boolean canReadVersion(String versionString)
  {
    return VERSION.equals(versionString);
  }
  
  static public File getAutoSaveFile(File f)
  {
    return new File(f.getParent(), "#" + f.getName() + "#");
  }

  public File getAutoSaveFile()
  {
    return getAutoSaveFile(file);
  }

  public boolean doesAutoSaveExist()
  {
    return getAutoSaveFile().exists();
  }

  public boolean doesNewerAutoSaveExist()
  {
    File asFile = getAutoSaveFile();
    return (asFile.exists() && asFile.lastModified() > file.lastModified());
  }

  public File getFile()
  {
    return file;
  }

  public boolean wasAutoSaveRead()
  {
    return autoSaveWasRead;
  }
  
  private static String[] validExtensions = {"gs", "gsa", "gp"};
  private static ExtensionFileFilter fileFilter = new
    ExtensionFileFilter(validExtensions, "Gesture files");
  public static FileFilter getFileFilter()
  {
    return fileFilter;
  }
  
  public class UnsupportedVersionException extends IOException {
    public UnsupportedVersionException()
    {
      super();
    }

    public UnsupportedVersionException(String details)
    {
      super(details);
    }
  }
}
