package edu.berkeley.guir.denim;

import edu.berkeley.guir.lib.satin.interpreter.stroke.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.io.*;
import edu.berkeley.guir.denim.dialogs.*;
import edu.berkeley.guir.denim.toolbox.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.io.*;
import edu.berkeley.guir.lib.satin.Sheet;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.widgets.*;

import java.awt.*;
import java.awt.geom.*;
import java.io.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;

import java.awt.print.*;

/**
 * The main pie menu for DENIM.
 * 
 * <P>
 * This software is distributed under the <A
 * HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt"> Berkeley Software
 * License </A>.
 * 
 * <PRE>
 * 
 * Revisions: 1.0.0 07-20-2000 JL Created class DenimPieMenu by separating it
 * from DenimSheet. 1.0.1 11-22-2002 YL Made it work with customized double
 * buffer Shared the triggering facility with the piemenu of Event type
 * 
 * </PRE>
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin </A>( <A
 *         HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu </A>)
 * @author <A HREF="http://www.cs.berkeley.edu/~newman/">Mark Newman </A>( <A
 *         HREF="mailto:newman@cs.berkeley.edu">newman@cs.berkeley.edu </A>)
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong </A>( <A
 *         HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu </A>)
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li </A>( <A
 *         HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu </A>)
 * 
 * @since JDK 1.2
 * @version Version 1.0.0, 11-22-2002
 */

class DenimPieMenu extends PieMenu implements DenimConstants {

    private static final int CONTEXT_MENU_POS = 4;

    private DenimSheet sheet;

    private JMenuItem projectRunMenuItem;

    private JMenuItem editUndoMenuItem;

    private JMenuItem editRedoMenuItem;

    private JMenuItem editTextMenuItem;

    private JMenuItem viewRadarViewMenuItem;

    private JMenuItem insertTextMenuItem;
    
    private JMenuItem insertImageMenuItem;

    private JMenuItem insertPageMenuItem;

    private JMenuItem insertComponentMenuItem;

    private JMenuItem expportItem;

    private JMenuItem createItem;

    private JMenuItem editItem;

    private JMenuItem deleteItem;

    private JMenuItem importItem;

    private EventTypePieMenu arrowItem;

    //private JMenuItem insertImageMenuItem;
    File currentProjectDirectory;

    private DenimPanel panelToRun;

    private TypedTextHandler textHandler;

    private JMenuItem componentRunItem;

    private JMenuItem linkto = null;

    private GraphicalObject linkSrc = null;

    // Shelley
    // The flag indicating a customer's preference -- either webApps or mobilApp
    //private boolean isMobile = false;

    // Keeps track of what component the pie menu was opened on.
    // We're not using this information currently, but we will eventually.
    private Component invoker;

    //===========================================================================
    //=== INNER CLASSES =====================================================

    /**
     * A piemenu that allows the user to select the event type for an arrow
     * (opened when the mouse is hold still at a destination point)
     */

    class EventTypePieMenu extends PieMenu implements DenimConstants {

        private DenimSheet sheet;

        private Arrow arrow;

        private Set hyperlinkEvents = null;

        EventTypePieMenu(DenimSheet sheet, Arrow ar) {
            super("Arrow");

            DenimComponentRegistry reg = DenimComponentRegistry.getInstance();
            DenimHyperlink hyperlink = ((DenimHyperlink) (reg
                    .getComponent("DenimHyperlink")));
            hyperlinkEvents = hyperlink.getEvents();

            this.sheet = sheet;
            arrow = ar;
            this.addPopupMenuListener(new MenuListener());

            JMenuItem item;
            Iterator it = hyperlinkEvents.iterator();
            while (it.hasNext()) {
                String str = (String) it.next();
                item = this.add(formatString(str));
                item.addActionListener(new SelectionListener(this, str));
            }

        }

        String formatString(String longString) {
            StringBuffer res = new StringBuffer();
            StringTokenizer st = new StringTokenizer(longString, " ");
            while (st.hasMoreTokens()) {
                res.append(st.nextToken() + "\n");
            }

            return new String(res);
        }

        class SelectionListener implements ActionListener {
            EventTypePieMenu pieMenu;

            String eventType;

            public SelectionListener(EventTypePieMenu pieMenu, String eventType) {
                super();
                this.pieMenu = pieMenu;
                this.eventType = eventType;
            }

            public void actionPerformed(ActionEvent evt) {
                
                boolean valid = true;
                
                if (eventType == DenimIntrinsicComponent.TIMER) {
                    // This is a Timer event:
                    // We should prompt the user for the delay
                    String message = "Please enter the Timer delay (in seconds)";
                    int delay = -1;
                    //while (delay == -1) {
                        String delayStr = JOptionPane.showInputDialog(null,
                                message, "Denim", JOptionPane.QUESTION_MESSAGE);
                        // if (JOptionPane.getValue() != null)
                        delay = parseTime(delayStr);
                    //}

                    // Encode the delay info the eventType
                    // (e.g. Timer:75 for a timer with a 75 seconds delay)
                    if(delay!=-1)
                        eventType = eventType + ":" + delay;
                    else
                        valid = false;
                }

                if(valid)
                    cmdqueue.doCommand(new ChangeInputEventTypeOfHyperlink(
                        pieMenu.arrow, eventType));

            }

            // Parse the string bdeimeString as seconds
            // Returns -1 if timeString cannot be parsed
            public int parseTime(String timeString) {
                int result = -1;

                try {
                    result = Integer.parseInt(timeString);
                } catch (NumberFormatException e) {
                }

                return result;
            }

        }

        class MenuListener implements PopupMenuListener {
            public void popupMenuCanceled(PopupMenuEvent evt) {
            }

            public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
            }

            public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
            }
        }

        void showAtCursor() {
            if (!isShowing()) {
                showNow(sheet, sheet.getLastX(), sheet.getLastY());
            }
        }
    }

    //=== INNER CLASSES =====================================================
    //===========================================================================

    //-----------------------------------------------------------------

    DenimPieMenu(DenimSheet sheet, boolean simplified) {
        super();

        this.sheet = sheet;
        currentProjectDirectory = null;

        if (simplified)
            this.addPopupMenuListener(new SimplifiedPopupCallback());
        else
            this.addPopupMenuListener(new PopupMenuCallback());

        init(simplified);

        this.addPieMenuTo(sheet);
        PieMenu.setAllTapOpen();
        //PieMenu.setAllTapHoldOpen();

        this.setVisible(false);
    }

    private void init(boolean simplified) {

        JMenuItem item;
        boolean isMacOSX = System.getProperty("os.name").equals("Mac OS X");

        if (simplified == false) {

            PieMenu pieProject = new PieMenu("File");
            pieProject.setBigRadius(pieProject.getBigRadius()+15);

            item = pieProject.add("Save");
            item.addActionListener(new PieProjectSaveListener());

            item = pieProject.add("Open...");
            item.addActionListener(new PieProjectOpenListener());

            PieMenu pieComponent = new PieMenu("Component");

            expportItem = pieComponent.add("Export");
            expportItem
                    .addActionListener(new PieProjectComponentShareListener());
            createItem = pieComponent.add("Create");
            createItem.addActionListener(new PieProjectComponentNewListener());
            editItem = pieComponent.add("Edit");
            editItem.addActionListener(new PieProjectComponentEditListener());
            deleteItem = pieComponent.add("Delete");
            deleteItem
                    .addActionListener(new PieProjectComponentDeleteListener());
            item = pieComponent.add("");
            item.setEnabled(false);
            importItem = pieComponent.add("Import");
            importItem
                    .addActionListener(new PieProjectComponentImportListener());

            item = pieProject.add("New");
            item.addActionListener(new PieProjectNewListener());

            //			item = pieProject.add("");
            //			item.setEnabled(false);
            
            item = pieProject.add("Print...");
            
            pieProject.add(pieComponent);
            
            //item = pieProject.add("");
            item.addActionListener(new PieProjectPrintListener());
            //item.setEnabled(false);

            if (isMacOSX) {
                item = pieProject.add("");
                item.setEnabled(false);
            } else {
                item = pieProject.add("Exit");
                item.addActionListener(new PieProjectQuitListener());
            }

            projectRunMenuItem = pieProject.add("Run");
            projectRunMenuItem.addActionListener(new PieProjectRunListener());

            item = pieProject.add("Save\nAs...");
            item.addActionListener(new PieProjectExportListener());

            PieMenu pieEdit = new PieMenu("Edit");
            item = pieEdit.add("Copy");
            item.addActionListener(new PieEditCopyListener());

            item = pieEdit.add("Cut");
            item.addActionListener(new PieEditCutListener());

            editRedoMenuItem = pieEdit.add("Redo");
            editRedoMenuItem.addActionListener(new PieEditRedoListener());

            editUndoMenuItem = pieEdit.add("Undo");
            editUndoMenuItem.addActionListener(new PieEditUndoListener());

            item = pieEdit.add("");
            item.setEnabled(false);

            editTextMenuItem = pieEdit.add("Text...");
            editTextMenuItem.addActionListener(new PieEditTextListener());

            //item = pieEdit.add("Find...");
            //			 item = pieEdit.add("");
            //			 item.addActionListener(new PieEditFindListener());
            //			 item.setEnabled(false);

            //item = pieEdit.add("Replace...");
            item = pieEdit.add("");
            item.addActionListener(new PieEditReplaceListener());
            item.setEnabled(false);

            item = pieEdit.add("Options");
            item.addActionListener(new PieOptionsListener());
            //item.setEnabled(false);
            
            PieMenu colorEdit = new PieMenu("Ink");
            pieEdit.add(colorEdit);
            item = colorEdit.add("Red");
            
            item.addActionListener(new PieEditColorListener());
            
            item = colorEdit.add("Green");
            
            item.addActionListener(new PieEditColorListener());
            
            item = colorEdit.add("Black");
            item.addActionListener(new PieEditColorListener());
            
            item = pieEdit.add("Delete");
            item.addActionListener(new PieEditDeleteListener());

            item = pieEdit.add("Paste");
            item.addActionListener(new PieEditPasteListener());

            PieMenu pieView = new PieMenu("View");
            item = pieView.add("Move to Center\nof Design");
            item.addActionListener(new PieViewCenterListener());

            item = pieView.add("Zoom In\n& Center");
            item.addActionListener(new PieViewZoomInListener());

            viewRadarViewMenuItem = pieView.add("Hide\nRadar View");
            viewRadarViewMenuItem
                    .addActionListener(new PieViewRadarViewListener());

            //item = pieView.add("Scenarios");
            //item.addActionListener(new PieProjectScenariosListener());
            //item.setEnabled(true);

            //item = pieView.add("");
            //item.setEnabled(false);

            item = pieView.add("Zoom Out\n& Center");
            item.addActionListener(new PieViewZoomOutListener());

            PieMenu pieInsert = new PieMenu("Insert");
            insertComponentMenuItem = pieInsert.add("Component...");
            insertComponentMenuItem
                    .addActionListener(new PieComponentFindListener());

            insertTextMenuItem = pieInsert.add("Text...");
            insertTextMenuItem.addActionListener(new PieInsertTextListener());

            insertPageMenuItem = pieInsert.add("Page...");
            insertPageMenuItem.addActionListener(new PieInsertPageListener());

            insertImageMenuItem = pieInsert.add("Image...");
            insertImageMenuItem.addActionListener(new PieInsertImageListener());

            //insertImageMenuItem = pieInsert.add("Image...");
            //insertImageMenuItem.addActionListener(new
            // PieInsertImageListener());

            PieMenu pieContext = new PieMenu("Context");
            pieContext.setEnabled(false);

            PieMenu pieHelp = new PieMenu("Help");

            item = pieHelp.add("Contents");
            item.addActionListener(new PieHelpContentsListener());

            if (!isMacOSX) {
                item = pieHelp.add("About");
                item.addActionListener(new PieHelpAboutListener());
            }

            PieMenu pieApp = null;
            if (isMacOSX) {
                pieApp = new PieMenu("Denim");

                item = pieApp.add("About");
                item.addActionListener(new PieHelpAboutListener());

                item = pieApp.add("Quit");
                item.addActionListener(new PieProjectQuitListener());
            }

            this.add(pieProject);
            this.add(pieEdit);
            this.add(pieView);
            this.add(pieInsert);

            item = this.add("");
            item.setEnabled(false);
            //this.add(pieContext);

            this.add(pieHelp);

            if (isMacOSX) {
                item = this.add("");
                item.setEnabled(false);

                this.add(pieApp);
            }
        } else {
            componentRunItem = this.add("Run");
            componentRunItem.addActionListener(new PieProjectRunListener());

            linkto = this.add("Add\nGlobal Link");
            linkto.addActionListener(new PieLinktoListener());

            PieMenu pieEdit = new PieMenu("Edit");
            item = pieEdit.add("Copy");
            item.addActionListener(new PieEditCopyListener());

            item = pieEdit.add("Cut");
            item.addActionListener(new PieEditCutListener());

            editRedoMenuItem = pieEdit.add("Redo");
            editRedoMenuItem.addActionListener(new PieEditRedoListener());

            editUndoMenuItem = pieEdit.add("Undo");
            editUndoMenuItem.addActionListener(new PieEditUndoListener());

            item = pieEdit.add("");
            item.setEnabled(false);

            editTextMenuItem = pieEdit.add("Text...");
            editTextMenuItem.addActionListener(new PieEditTextListener());

            item = pieEdit.add("");
            item.addActionListener(new PieEditReplaceListener());
            item.setEnabled(false);

            item = pieEdit.add("Delete");
            item.addActionListener(new PieEditDeleteListener());

            item = pieEdit.add("Paste");
            item.addActionListener(new PieEditPasteListener());

            PieMenu pieView = new PieMenu("View");
            item = pieView.add("Move to Center\nof Design");
            item.addActionListener(new PieViewCenterListener());

            item = pieView.add("Zoom In\n& Center");
            item.addActionListener(new PieViewZoomInListener());

            item = pieView.add("Zoom Out\n& Center");
            item.addActionListener(new PieViewZoomOutListener());

            PieMenu pieInsert = new PieMenu("Insert");

            insertTextMenuItem = pieInsert.add("Text...");
            insertTextMenuItem.addActionListener(new PieInsertTextListener());

            insertPageMenuItem = pieInsert.add("Page...");
            insertPageMenuItem.addActionListener(new PieInsertPageListener());
            
            insertImageMenuItem = pieInsert.add("Image...");
            insertImageMenuItem.addActionListener(new PieInsertImageListener());

            //insertImageMenuItem = pieInsert.add("Image...");
            //insertImageMenuItem.addActionListener(new
            // PieInsertImageListener());

            //PieMenu pieContext = new PieMenu("Context");
            //pieContext.setEnabled(false);

            arrowItem = new EventTypePieMenu(sheet, null);

            this.add(pieEdit);
            this.add(pieView);
            this.add(pieInsert);
            //this.add(pieContext);
            this.add(arrowItem);
        }
    }

    //-----------------------------------------------------------------

    void setCurrentProjectDirectory(File newProjectDirectory) {
        currentProjectDirectory = newProjectDirectory;
    }

    //-----------------------------------------------------------------

    private DenimWindow getWindow() {
        return (DenimWindow) SwingUtilities.getRoot(sheet);
    }

    /**
     * get the arrow which its event type contains p
     */

    private Arrow getTargetArrow(Point2D p) {

        try
        {
            Iterator it = sheet.getForwardIterator();
    
            while (it.hasNext()) {
    
                GraphicalObject gob = (GraphicalObject) it.next();
                if (gob instanceof Arrow) {
                    Arrow ar = (Arrow) gob;
    
                    if (((GraphicalObjectImpl) ar.getSource())
                            .getLatestRenderTime() >= sheet.getRenderServer()
                            .getLatestRenderTimeStamp()) {
                        if (ar.closeToPropertyPoint(p)) {
                            return ar;
                        }
                    }
    
                }
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
        return null;
    }

    /**
     * Show pie menu of event type
     * 
     * @param x
     *            is the x-coordinate in the invoker's coordinate space.
     * @param y
     *            is the y-coordinate in the invoker's coordinate space.
     */

    private boolean showEventPieMenu(int x, int y) {

        Arrow arrow = getTargetArrow(new Point2D.Double(x, y));

        if (arrow == null)
            return false;

        EventTypePieMenu eventTypePieMenu = new EventTypePieMenu(sheet, arrow);

        //      sheet.setRenderToScreen(false);
        eventTypePieMenu.showAtCursor();
        //      sheet.setRenderToScreen(true);

        return true;

    }

    /**
     * Show the pie menu.
     * 
     * @param invoker
     *            is the Component to show the pie menu in.
     * @param x
     *            is the x-coordinate in the invoker's coordinate space.
     * @param y
     *            is the y-coordinate in the invoker's coordinate space.
     */
    public void show(Component invoker, int x, int y) {
        this.invoker = invoker;
        super.show(invoker, x, y);
    } // of method

    //-----------------------------------------------------------------

    /**
     * Show the pie menu without delay.
     * 
     * @param invoker
     *            is the Component to show the pie menu in.
     * @param x
     *            is the x-coordinate in the invoker's coordinate space.
     * @param y
     *            is the y-coordinate in the invoker's coordinate space.
     */
    public void showNow(Component invoker, int x, int y) {

        /**
         * To see if we should trigger a piemenu for event type of hyperlink if
         * not, trigger Denim's piemenu.
         */

        if (showEventPieMenu(x, y)) {
            return;
        }

        this.invoker = invoker;
        super.showNow(invoker, x, y);
    }

    //-----------------------------------------------------------------

    /**
     * Ack, quick hack to make the space bar show the pie menu.
     */
    void showAtCursor() {

        if (!isShowing()) {
            showNow(sheet, sheet.getLastX(), sheet.getLastY());
        }
    } // of showPieMenu

    //-----------------------------------------------------------------

    void showInCenter() {
        if (!isShowing()) {
            Rectangle bounds = sheet.getBounds();

            showNow(sheet, (int) (bounds.x + bounds.width / 2),
                    (int) (bounds.y + bounds.height / 2));
        }
    } // of showPieMenu

    //-----------------------------------------------------------------
    class PieProjectComponentImportListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
            //// 0.1. Setup the file chooser.
            JFileChooser chooser = new JFileChooser(currentProjectDirectory);

            //// 0.2. Setup the file filter.
            ExtensionFileFilter filter = new ExtensionFileFilter();
            filter.addExtension("dnl");
            filter.setDescription("Custom Component File");
            chooser.setFileFilter(filter);
            chooser.setMultiSelectionEnabled(false);
            chooser.setDialogTitle("Import Custom Components");

            //// 1. Open up the dialog.
            int returnVal = chooser.showOpenDialog(sheet);

            //// 2. If the user clicks Open...
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                currentProjectDirectory = chooser.getCurrentDirectory();
                try {
                    DenimComponentEditor.importComponents(chooser
                            .getSelectedFile().getAbsolutePath(), sheet);
                    JOptionPane.showMessageDialog(sheet,
                            "Successfully imported components from\n"
                                    + chooser.getSelectedFile().toString(),
                            "Import Custom Components",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(sheet,
                            "Failed to import components from\n"
                                    + chooser.getSelectedFile().toString(),
                            "Import Custom Components",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        } // of actionPerformed
    }

    class PieProjectComponentShareListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
            String strFileName;

            JFileChooser chooser = new JFileChooser(currentProjectDirectory);
            chooser.setDialogTitle("Export Custom Components");
            chooser.setMultiSelectionEnabled(false);

            ExtensionFileFilter dnlFilter = new ExtensionFileFilter();
            dnlFilter.addExtension("dnl");
            dnlFilter.setDescription("Custom Component File");
            chooser.setFileFilter(dnlFilter);

            do {
                //// 1. Open up the dialog.
                int returnVal = chooser.showSaveDialog(sheet);
                if (returnVal != JFileChooser.APPROVE_OPTION) {
                    return;
                }

                //// 2. Get the selected file.
                currentProjectDirectory = chooser.getCurrentDirectory();
                File selectedFile = chooser.getSelectedFile();
                strFileName = selectedFile.getAbsolutePath();

                if (chooser.getFileFilter() == dnlFilter) {
                    strFileName = FileLib.addFileNameExtension(strFileName,
                            "dnl");
                }

                //// 3.1. If the file already exists...
                File tstFile = new File(strFileName);
                if (tstFile.exists()) {
                    //// 3.1.1. Ask the user if he wants to overwrite the file.
                    int option = JOptionPane.showConfirmDialog(sheet,
                            strFileName + " already exists.\n"
                                    + "Do you want to replace it?", "Denim",
                            JOptionPane.YES_NO_CANCEL_OPTION,
                            JOptionPane.WARNING_MESSAGE);

                    if (option == JOptionPane.YES_OPTION) {
                        //// 3.1.2. If yes, then break out of loop and save.
                        break;
                    } else if (option == JOptionPane.CANCEL_OPTION) {
                        //// 3.1.3. If cancel, there's nothing to be done, so
                        // just
                        //// return
                        return;
                    }
                }
                //// 3.2. If the file doesn't already exist, then break out of
                // loop
                //// and save.
                else {
                    break;
                }
            } while (true);

            //// Set the cursor to the wait cursor.
            getWindow().setBusy(true);

            try {
                DenimComponentEditor.exportComponents(strFileName);
                JOptionPane.showMessageDialog(sheet,
                        "Successfully exported components to\n" + strFileName,
                        "Export Custom Components",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                //// 5. Failure, show the failure dialog.
                e.printStackTrace();
                Debug.println("Cannot save: " + e.getClass());
                FileDialogs.showSaveFailureDialog(sheet, strFileName, e
                        .getMessage());
                JOptionPane.showMessageDialog(sheet,
                        "Failed to export components to\n" + strFileName,
                        "Export Custom Components", JOptionPane.ERROR_MESSAGE);
            }

            //// Enable the window.
            getWindow().setBusy(false);

        } // of actionPerformed
    }

    class PieProjectComponentNewListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            GraphicalObjectCollection gobcol = (GraphicalObjectCollection) cmdsubsys
                    .getSelectedCollection().clone();

            cmdsubsys.clearSelected();

            DenimComponentEditor win = new DenimComponentEditor(true,
                    "componentname");
            win.addNotify();
            win.initAfterConstruction();

            /*
             * sheet.getSlider().setValue(70);
             * 
             * Arrow.setIgnoreEndpointMove(true);
             * 
             * Iterator iter = gobcol.getForwardIterator();
             * cmdqueue.doCommand(new DenimCutCommand(iter));
             * 
             * 
             * cmdqueue.doCommand(new
             * DenimPasteCommand(win.getDenimUI().getSheet()));
             * 
             * Arrow.setIgnoreEndpointMove(false);
             */

            win.setVisible(true);
            win.toFront();
        }
    }

    class PieProjectNewListener implements ActionListener {

        //-----------------------------------------------------------------

        // Shelley and Peter
        /**
         * Asks user to choose one of application types
         */
        /*
         * public void showDialog(DenimSheet f) {
         * 
         * Object[] options = {"Mobile Phone Applications", "Web Applications"};
         * int n = JOptionPane.showOptionDialog(f, "What kind of application do
         * you use DENIM for?", "Choose Application Type",
         * JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null,
         * options, options[0]);
         * 
         * if (n == JOptionPane.YES_OPTION) {
         *  // go to mobile design mode
         * Denim.setDeviceInfo(DeviceType.SMARTPHONE); System.out.println("yes
         * yes yes.");
         *  } else if (n == JOptionPane.NO_OPTION) {
         *  // go to web design mode Denim.setDeviceInfo(DeviceType.DESKTOP);
         * System.out.println("no no no.");
         *  } else {
         *  // in case users just close the window showDialog (f);
         * System.out.println("hahahahha."); } }
         */
        //-----------------------------------------------------------------
        public void actionPerformed(ActionEvent evt) {

            // Shelley and Peter
            //         showDialog(sheet);

            if (sheet.isModified()) {
                int option = FileDialogs.showPromptForSaveDialog(sheet);
                if (option == JOptionPane.CANCEL_OPTION) {
                    return;
                } else if (option == JOptionPane.YES_OPTION) {
                    saveSheet();

                    // If the sheet is still modified, then the save action was
                    // cancelled. Therefore, cancel the entire operation.
                    if (sheet.isModified()) {
                        return;
                    }
                }
            }
            sheet.clear();
            /**
             * reset component registry
             */
            DenimComponentRegistry.getInstance().reset();
        } // of actionPerformed

    } // of PieProjectNewListener

    //-----------------------------------------------------------------

    /**
     * Tries opening the given DENIM file. If the current design has not been
     * saved, first asks if the designer wants to save the file.
     */
    public void tryOpen(File f) {
        /// If the sheet has been modified, ask if it should be saved
        if (sheet.isModified()) {
            int option = FileDialogs.showPromptForSaveDialog(sheet);
            if (option == JOptionPane.CANCEL_OPTION) {
                return;
            } else if (option == JOptionPane.YES_OPTION) {
                saveSheet();

                // If the sheet is still modified, then the save action was
                // cancelled. Therefore, cancel the entire operation.
                if (sheet.isModified()) {
                    return;
                }
            }
        }
        
        sheet.clear();
        /**
         * reset component registry
         */
        DenimComponentRegistry.getInstance().reset();
        
        String path = null;

        DenimProgressDialog dpd = new DenimProgressDialog(getWindow(),
                "Loading ...", true, f.length());
        dpd.setVisible(true);

        //// Set the cursor to the wait cursor, and disable the window.
        getWindow().setBusy(true);

        try {
            //// 2. Get the selected files.
            sheet.disableDamage();
            path = f.getAbsolutePath();
            sheet.open(f);

            sheet.setModified(false);

            File parentDir = f.getAbsoluteFile().getParentFile();
            setCurrentProjectDirectory(parentDir);

            //// Load up associated annotations
            /*
             * InputSource xmlInput;
             * 
             * getDenimUI().setCursor(waitCursor); try { if
             * (path.substring(path.length() - 4).equals(".dnm")) { //// Get
             * published annotations for this file Map postData = new HashMap();
             * postData.put("action", "get_annos"); postData.put("designUID",
             * getUID().toString());
             * 
             * java.util.List results = DenimUtils.postToURL(getAuthorURL(),
             * postData);
             * 
             * Debug.println("Results of getting annotations from reviewer:" +
             * getAuthorURL());
             * 
             * String xmlStr = "";
             * 
             * Iterator i = results.iterator(); while (i.hasNext()) { xmlStr +=
             * (String)i.next(); } Debug.println("About to parse: " + xmlStr);
             * 
             * if (results.size() == 0 || xmlStr.equals(" <nothing/>")) {
             * xmlInput = null; } else { xmlInput = new InputSource(new
             * StringReader(xmlStr)); } } else { // extension is .dne //// Get
             * the associated local annotations for this file, //// if any
             * String annosFileName = getDenimUI().getProjectName().substring(
             * 0, getDenimUI().getProjectName().length() - 4) + ".dna"; File af =
             * new File(annosFileName); if (af.exists()) { xmlInput = new
             * InputSource(annosFileName); } else { xmlInput = null; }
             * Debug.println("Finding " + annosFileName + "..."); }
             * 
             * //// If there are any annotations associated with this file, ////
             * load them up if (xmlInput != null) { SheetDOMParser parser = new
             * SheetDOMParser(); Debug.println("Parsing..."); Document document =
             * parser.parse(xmlInput); Debug.println("Adding annotations...");
             * DOMUtils.addSheetAnnotationsFromDOMElement(
             * document.getDocumentElement(), DenimSheet.this, false);
             * Debug.println("Done."); } Debug.println("Annotations: " +
             * getSheetAnnotations()); } catch (Exception e) {
             * e.printStackTrace(); String msg = "Annotations unavailable";
             * 
             * if (e.getMessage() == null) { msg += "."; } else { msg += ": " +
             * e.getMessage(); }
             * 
             * JOptionPane.showMessageDialog(DenimSheet.this, msg, "Annotations
             * unavailable", JOptionPane.ERROR_MESSAGE); }
             */
        } catch (Exception e) {
            //// 2.3. Failure, show the failure dialog.
            e.printStackTrace();
            FileDialogs.showOpenFailureDialog(sheet, path, e.getClass() + ": "
                    + e.getMessage());
        }
        //// Enable the window.
        getWindow().setBusy(false);
        sheet.enableDamage();

        DenimPieMenu.this.sheet.getRenderServer().setSceneGraphChanged(true);

        DenimPieMenu.this.sheet.damage(DAMAGE_LATER);
        DenimPieMenu.this.sheet.damage(DAMAGE_NOW);
    }

    //-----------------------------------------------------------------

    class PieProjectOpenListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            //// 0.1. Setup the file chooser.
            JFileChooser chooser = new JFileChooser(currentProjectDirectory);

            //// 0.2. Setup the file filter.
            ExtensionFileFilter filter = new ExtensionFileFilter();
            filter.addExtension("dnm");
            //filter.addExtension("dne");
            filter.setDescription("Denim Design Files");
            chooser.setFileFilter(filter);
            chooser.setMultiSelectionEnabled(false);
            chooser.setDialogTitle("Open");

            //// 1. Open up the dialog.
            int returnVal = chooser.showOpenDialog(sheet);

            //// 2. If the user clicks Open...
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                currentProjectDirectory = chooser.getCurrentDirectory();

                DenimPieMenu.this.tryOpen(chooser.getSelectedFile());
            }
        } // of actionPerformed
    } // of PieProjectOpenListener

    //-----------------------------------------------------------------

    class PieProjectMilestonesListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Debug.println("Activating " + evt.getActionCommand());
        } // of actionPerformed

    } // of PieProjectMilestonesListener

    //-----------------------------------------------------------------

    class PieProjectVariationsListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Debug.println("Activating " + evt.getActionCommand());
        } // of actionPerformed

    } // of PieProjectVariationsListener

    //-----------------------------------------------------------------

    class PieProjectScenariosListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Window parentWin = (Window) SwingUtilities.getRoot(sheet);
            ScenarioManagerDialog manager = new ScenarioManagerDialog(
                    (Frame) parentWin, sheet);
            Rectangle tR = parentWin.getBounds();
            manager.setLocation((tR.x + tR.width) - manager.getWidth(), 0);

            manager.setVisible(true);
            Debug.println("Activating " + evt.getActionCommand());
        } // of actionPerformed

    } // of PieProjectScenariossListener

    //-----------------------------------------------------------------

    /**
     * Save the sheet asssociated with the pie menu. If save is unsuccessful,
     * pop up an error message box.
     */
    private void saveSheetAs() {
        String strFileName;

        //// 0.1. Setup the file chooser.
        JFileChooser chooser = new JFileChooser(currentProjectDirectory);
        chooser.setDialogTitle("Save As");
        chooser.setMultiSelectionEnabled(false);

        //// 0.2. Setup the file filter.
        ExtensionFileFilter htmlFilter = new ExtensionFileFilter();
        htmlFilter.addExtension("html");
        htmlFilter.setDescription("Export to Web");
        chooser.setFileFilter(htmlFilter);

        ExtensionFileFilter svgFilter = new ExtensionFileFilter();
        svgFilter.addExtension("svg");
        svgFilter.setDescription("Export to SVG");
        // disable SVG feature for now
        //		chooser.addChoosableFileFilter(svgFilter);

        ExtensionFileFilter dnmFilter = new ExtensionFileFilter();
        dnmFilter.addExtension("dnm");
        dnmFilter.setDescription("Denim Design Files");
        chooser.addChoosableFileFilter(dnmFilter);

        do {
            //// 1. Open up the dialog.
            int returnVal = chooser.showSaveDialog(sheet);
            if (returnVal != JFileChooser.APPROVE_OPTION) {
                return;
            }

            //// 2. Get the selected file.
            currentProjectDirectory = chooser.getCurrentDirectory();
            File selectedFile = chooser.getSelectedFile();
            //Debug.println("Exporting: " + selectedFile);
            strFileName = selectedFile.getAbsolutePath();

            if (chooser.getFileFilter() == htmlFilter) {
                strFileName = FileLib.addFileNameExtension(strFileName, "html");
            } else if (chooser.getFileFilter() == svgFilter) {
                strFileName = FileLib.addFileNameExtension(strFileName, "svg");
            } else {
                strFileName = FileLib.addFileNameExtension(strFileName, "dnm");
            }

            //// 3.1. If the file already exists...
            File tstFile = new File(strFileName);
            if (tstFile.exists()) {
                //// 3.1.1. Ask the user if he wants to overwrite the file.
                int option = JOptionPane.showConfirmDialog(sheet, strFileName
                        + " already exists.\n" + "Do you want to replace it?",
                        "Denim", JOptionPane.YES_NO_CANCEL_OPTION,
                        JOptionPane.WARNING_MESSAGE);

                if (option == JOptionPane.YES_OPTION) {
                    //// 3.1.2. If yes, then break out of loop and save.
                    break;
                } else if (option == JOptionPane.CANCEL_OPTION) {
                    //// 3.1.3. If cancel, there's nothing to be done, so just
                    //// return
                    return;
                }
            }
            //// 3.2. If the file doesn't already exist, then break out of loop
            //// and save.
            else {
                break;
            }
        } while (true);

        //// Set the cursor to the wait cursor.
        getWindow().setBusy(true);

        try {
            // 4.1. If user selects HTML option:
            //      Save the scenarios title page in newly created directory
            //      (name is specified by user); create a folder within that
            //      directory which contains all relevant HTML and GIF files.
            //
            
            String srcdir = DenimUI.getProjectName();
            if(srcdir!=null)
                srcdir = new File(srcdir).getParentFile().getAbsolutePath(); 
            
            if (chooser.getFileFilter() == htmlFilter) {
                
                HtmlExport htmlExporter = new HtmlExport(sheet, strFileName);
                htmlExporter.export();

            } else if (chooser.getFileFilter() == svgFilter) {
                sheet.saveSVG(strFileName);
            }
            else {
                /*
                String fname = new File(strFileName).getName();
                fname = fname.substring(0, fname.length()-4);
                chooser.getCurrentDirectory().getAbsolutePath() + File.separator + fname;
                */
                sheet.saveImages(
                        srcdir, 
                        chooser.getCurrentDirectory().getAbsolutePath());
                
                sheet.save(strFileName, true);
                sheet.getDenimUI().setProjectName(strFileName);
            }
        } catch (Exception e) {
            //// 5. Failure, show the failure dialog.
            e.printStackTrace();
            Debug.println("Cannot save: " + e.getClass());
            FileDialogs.showSaveFailureDialog(sheet, strFileName, e
                    .getMessage());
        }

        //// Enable the window.
        getWindow().setBusy(false);
    }

    //-----------------------------------------------------------------

    class PieProjectExportListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
            saveSheetAs();
        } // of actionPerformed
    } // of PieProjectExportListener

    //-----------------------------------------------------------------

    /**
     * Save the sheet asssociated with the pie menu. If save is unsuccessful,
     * pop up an error message box.
     */
    void saveSheet() {
        String strFileName = null;
        try {
            strFileName = DenimUI.getProjectName();
            if (strFileName == null) {
                saveSheetAs();
            } else {
                sheet.save(strFileName, true);
            }
        } catch (Exception e) {
            //// 2.4. Failure, show the failure dialog.
            e.printStackTrace();
            Debug.println("Cannot save: " + e.getClass());
            FileDialogs.showSaveFailureDialog(sheet, strFileName, e
                    .getMessage());
            sheet.getDenimUI().setCursor(Cursor.getDefaultCursor());
        }
    }

    //-----------------------------------------------------------------

    class PieProjectSaveListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
            saveSheet();
        } // of actionPerformed
    } // of PieProjectSaveListener

    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    /*
     * class PieProjectShareForAnnotationsListener implements ActionListener {
     * public void actionPerformed(ActionEvent evt) { DenimUI win =
     * sheet.getDenimUI(); String strFileName; boolean justSaved = false;
     * 
     * //// If the user has not saved the file, then ask him or her to. if
     * (win.getProjectName() == null) { (new
     * PieProjectExportListener()).actionPerformed(null); Debug.println("cool");
     * justSaved = true; }
     * 
     * //// If the user <i>still </i> hasn't saved the file, cancel. if
     * (win.getProjectName() == null) { return; }
     * 
     * //// Since the project has been successfully saved, we can assume ////
     * that the file has an extension of ".dnm". Strip the extension //// and
     * tack on the version number and ".dne" extension. strFileName =
     * win.getProjectName().substring( 0, win.getProjectName().length() - 4) +
     * "." + version + ".dne";
     * 
     * try { save(strFileName, justSaved); Object[] options = { "OK" };
     * JOptionPane.showOptionDialog(null, "You can now share " + strFileName + "
     * to be annotated.", "Denim", JOptionPane.DEFAULT_OPTION,
     * JOptionPane.INFORMATION_MESSAGE, null, options, options[0]); } catch
     * (Exception e) { //// 2.4. Failure, show the failure dialog.
     * System.err.println("Cannot share to be annotated: " + e.getClass());
     * e.printStackTrace(); JOptionPane.showMessageDialog(DenimSheet.this,
     * win.getProjectName() + " cannot be shared to be annotated.", "Cannot
     * share for annotations", JOptionPane.ERROR_MESSAGE); } } // of
     * actionPerformed } // of PieProjectExportAnnotationsListener
     * 
     * //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     * 
     * 
     * class PieProjectExportAnnotationsListener implements ActionListener {
     * public void actionPerformed(ActionEvent evt) { DenimUI win =
     * getDenimUI();
     * 
     * win.setCursor(waitCursor); getSheetAnnotations().incrVersion();
     * Debug.println("Annotations: " + getSheetAnnotations());
     * 
     * //// Save the annotations in a .dna file. Document doc = new
     * com.ibm.xml.dom.DocumentImpl(); doc.appendChild(DOMUtils.toDOMElement(
     * doc, getSheetAnnotations(), false));
     * 
     * String strFileName = win.getProjectName().substring( 0,
     * win.getProjectName().length() - 4) + ".dna";
     * 
     * Debug.println("Exporting: " + strFileName);
     * 
     * try { SheetDOMWriter writer = new SheetDOMWriter(strFileName);
     * writer.print(doc); writer.close(); } catch (FileNotFoundException e) {
     * getSheetAnnotations().setVersion(getSheetAnnotations().getVersion() - 1);
     * e.printStackTrace(); FileDialogs.showSaveFailureDialog(strFileName,
     * e.getMessage()); } catch (IOException e) {
     * getSheetAnnotations().setVersion(getSheetAnnotations().getVersion() - 1);
     * e.printStackTrace(); JOptionPane.showMessageDialog(DenimSheet.this, "I/O
     * Exception: " + e.getMessage(), "File failed to save",
     * JOptionPane.ERROR_MESSAGE); }
     * 
     * try { //// Save the annotations into the annotations publisher
     * SheetDOMWriter writer = new SheetDOMWriter(new StringWriter());
     * writer.print(doc); String xmlStr = writer.toString(); writer.close();
     * 
     * Map postData = new HashMap(); postData.put("action", "update_annos");
     * postData.put("designUID", getUID().toString()); postData.put("reviewer",
     * DenimUserProperties.get(PROP_USER)); postData.put("annotations", xmlStr);
     * 
     * DenimUtils.postToURL(new URL(DenimProperties.get(PROP_REVIEWER_URL)),
     * postData);
     * 
     * //// Notify the subscriber that the annotations have been updated
     * postData.remove("annotations"); postData.put("reviewerURL",
     * DenimProperties.get(PROP_REVIEWER_URL));
     * DenimUtils.postToURL(getAuthorURL(), postData); } catch
     * (MalformedURLException e) { e.printStackTrace();
     * JOptionPane.showMessageDialog(DenimSheet.this, PROP_REVIEWER_URL + " is
     * not a valid URL", "Invalid URL", JOptionPane.ERROR_MESSAGE); } catch
     * (IOException e) { e.printStackTrace();
     * JOptionPane.showMessageDialog(DenimSheet.this, "I/O Exception: " +
     * e.getMessage(), "File failed to save", JOptionPane.ERROR_MESSAGE); }
     * 
     * 
     * //// Wrap up win.setCursor(Cursor.getDefaultCursor());
     * 
     *  /* DenimUI win = getDenimUI(); // Drop the tool before saving. This
     * avoids a serialization // error which should not be happening regardless.
     * Whatever. Tool currentTool = win.getCurrentTool();
     * 
     * if (currentTool != null) {
     * currentTool.drop(win.getToolbox().getToolsArea(), new Point(0, 0)); }
     * 
     * win.setCursor(waitCursor);
     * 
     * //// 2.2. Collect the current user's annotations from the sheet; ////
     * they will be saved separately ArrayList annoObjects = new ArrayList();
     * 
     * GraphicalObjectCollection annotations = (GraphicalObjectCollection)
     * annotationsMap.get(DenimProperties.get(PROP_USER));
     * 
     * if (annotations != null) { Iterator annoIter =
     * annotations.getForwardIterator(); while (annoIter.hasNext()) {
     * GraphicalObject gob = (GraphicalObject)annoIter.next();
     * AnnotationObjectWrapper wrapper = new AnnotationObjectWrapper(gob, null);
     * annoObjects.add(wrapper); } }
     * 
     * //// 2.3. Save the version along with the annotations Map annoTable = new
     * HashMap(); annoTable.put("info", annoInfo); annoTable.put("annotations",
     * annoObjects);
     * 
     * //// 2.4. Save the annotations. String strFileName =
     * win.getProjectName().substring( 0, win.getProjectName().length() - 4) +
     * ".dna";
     * 
     * try { FileOutputStream fostream = new FileOutputStream(strFileName);
     * GZIPOutputStream gzostream = new GZIPOutputStream(fostream);
     * ObjectOutputStream oostream = new ObjectOutputStream(gzostream);
     * 
     * oostream.writeObject(annoTable); oostream.flush(); oostream.close();
     * 
     * annoInfo.incrVersion(); } catch (Exception e) { e.printStackTrace();
     * showSaveFailureDialog(strFileName, e.getMessage()); }
     */
    //// 2.4 TODO: Send message back to machine of original designer
    //// 2.5 Restore the annotations
    /*
     * keyIter = annotationsMap.keySet().iterator(); int i = 0;
     * 
     * while (keyIter.hasNext()) { Object key = keyIter.next();
     * GraphicalObjectCollection annotations =
     * (GraphicalObjectCollection)annotationsMap.get(key);
     * 
     * Iterator annoIter = annotations.getForwardIterator(); while
     * (annoIter.hasNext()) { GraphicalObject gob =
     * (GraphicalObject)annoIter.next(); GraphicalObjectGroup parent =
     * (GraphicalObjectGroup)parents.get(i); i++; parent.add(gob);
     * Debug.println("Adding " + gob.getUniqueID() + " to " +
     * parent.getUniqueID()); } }
     */
    /*
     * win.setCursor(Cursor.getDefaultCursor());
     * 
     * //// Restore the current tool. if (currentTool != null) {
     * currentTool.grab(); }
     */
    /*
     * } // of actionPerformed } // of PieProjectExportAnnotationsListener
     */

    //-----------------------------------------------------------------
    class PieProjectPrintListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            //sheet.getSlider().
            DenimPrinter printer = new DenimPrinter(sheet);
            printer.setVisible(true);
            if (printer.shouldPrint) {
                printer.doPrint();
            }
        } // of actionPerformed
    } // of PieProjectPrintListener

    //-----------------------------------------------------------------

    class PieProjectRunListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            assert panelToRun != null; // "Cannot find panel to run"
            sheet.getDenimUI().startRunMode(panelToRun);
        } // of actionPerformed

    } // of PieProjectRunListener

    //-----------------------------------------------------------------

    class PieInsertImageListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            // Insert image right where we clicked
            Point2D pt = new Point2D.Double(sheet.getLastX(), sheet.getLastY());
            sheet.insertImage(pt);
        } // of actionPerformed

    } // of PieInsertImageListener

    //-----------------------------------------------------------------

    /**
     * Prompts the user whether he wants to save his design. Returns true if the
     * application should quit.
     */
    public boolean promptSaveBeforeExiting() {
        if (sheet.isModified()) {
            int option = FileDialogs.showPromptForSaveDialog(sheet);
            if (option == JOptionPane.CANCEL_OPTION) {
                return false;
            } else if (option == JOptionPane.YES_OPTION) {
                saveSheet();

                // If the sheet is still modified, then the save action was
                // cancelled. Therefore, cancel the entire operation.
                if (sheet.isModified()) {
                    return false;
                }
            }
        }
        return true;
    }

    //-----------------------------------------------------------------

    class PieProjectQuitListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Denim.tryExit();
        } // of actionPerformed

    } // of PieProjectQuitListener

    //-----------------------------------------------------------------

    class PieEditUndoListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            try {
                cmdqueue.undo();
                //sheet.repaint();
                DenimPieMenu.this.sheet.damage(DAMAGE_LATER);
            } catch (Exception e) {
                Debug.println("Cannot undo last command");
            }
        } // of actionPerformed

    } // of PieEditUndoListener

    //-----------------------------------------------------------------

    class PieEditRedoListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            try {
                cmdqueue.redo();
                //            sheet.repaint();
                DenimPieMenu.this.sheet.damage(DAMAGE_LATER);
            } catch (Exception e) {
                Debug.println("Cannot redo last command");
            }
        } // of actionPerformed

    } // of PieEditRedoListener

    //-----------------------------------------------------------------

    class PieEditCutListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Iterator iter;
            DenimCutCommand cutCommand;

            //// 1. Get the selected items.
            iter = cmdsubsys.getSelected();

            //// 1.5. If nothing selected, try to select what's right below
            if (!(iter.hasNext())) {
                cmdqueue.doCommand(new SelectShallowCommand(sheet, cmdsubsys
                        .getAbsoluteLastXLocation(), cmdsubsys
                        .getAbsoluteLastYLocation()));
                iter = cmdsubsys.getSelected();
            }

            //// 2. Set the selected Graphical Objects to be copied.
            cutCommand = new DenimCutCommand(iter);
            cmdqueue.doCommand(cutCommand);

            repaint();
        } // of actionPerformed

    } // of PieEditCutListener

    //-----------------------------------------------------------------

    class PieEditCopyListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Iterator iter;
            DenimCopyCommand copyCommand;

            //// 1. Get the selected items.
            iter = cmdsubsys.getSelected();

            //// 1.5. If nothing selected, try to select what's right below
            if (!(iter.hasNext())) {
                cmdqueue.doCommand(new SelectShallowCommand(sheet, cmdsubsys
                        .getAbsoluteLastXLocation(), cmdsubsys
                        .getAbsoluteLastYLocation()));
                iter = cmdsubsys.getSelected();
            }
            //// 2. Set the selected Graphical Objects to be copied.
            copyCommand = new DenimCopyCommand(iter);
            cmdqueue.doCommand(copyCommand);

            repaint();

        } // of actionPerformed

    } // of PieEditCopyListener

    //-----------------------------------------------------------------

    class PieEditPasteListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            sheet.pasteAt(cmdsubsys.getAbsoluteLastLocation());
        } // of actionPerformed

    } // of PieEditPasteListener
    

    //-----------------------------------------------------------------

    class PieEditColorListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            JMenuItem item = (JMenuItem)evt.getSource();
            if(item.getText().equals("Red"))
            {
                ImmediateInkFeedbackInterpreter.inkColor = Color.RED;
            }
            else if(item.getText().equals("Green"))
            {
                ImmediateInkFeedbackInterpreter.inkColor = Color.GREEN;
            }
            else
            {
                ImmediateInkFeedbackInterpreter.inkColor = Color.BLACK;
            }
            
        } // of actionPerformed

    } // of PieEditPasteListener

    //-----------------------------------------------------------------

    class PieEditDeleteListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Iterator iter;

            //// 1. Get the selected items.
            iter = cmdsubsys.getSelected();

            //// 2. If there are selected items, then delete them.
            if (iter.hasNext()) {
                sheet.deleteObjects(iter);
            }
            //// Else, delete the nearest object.
            else {
                sheet.deleteObject(sheet.getObjectToSelect(new Point(cmdsubsys
                        .getAbsoluteLastXLocation(), cmdsubsys
                        .getAbsoluteLastYLocation())));
            }
        } // of actionPerformed

    } // of PieEditDeleteListener

    //-----------------------------------------------------------------

    class PieEditFindListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Debug.println("Activating " + evt.getActionCommand());
        } // of actionPerformed

    } // of PieEditFindListener

    //-----------------------------------------------------------------

    class PieEditReplaceListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Debug.println("Activating " + evt.getActionCommand());
        } // of actionPerformed

    } // of PieEditReplaceListener

    class PieComponentFindListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
            DenimComlibDlg com = new DenimComlibDlg(
                    (DenimWindow) (SwingUtilities.getRoot(sheet)));
            com.setVisible(true);
        }

    } // of PieEditReplaceListener

    class PieProjectComponentEditListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
            EditComponentDlg dcd = new EditComponentDlg(
                    (DenimWindow) SwingUtilities.getRoot(sheet));
            dcd.setVisible(true);
        }
    }

    class PieProjectComponentDeleteListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
            DeleteComponentDlg dcd = new DeleteComponentDlg(
                    (DenimWindow) SwingUtilities.getRoot(sheet));
            dcd.setVisible(true);
        }
    }

    //-----------------------------------------------------------------

    class PieEditGroupListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Debug.println("Activating " + evt.getActionCommand());
        } // of actionPerformed

    } // of PieEditGroupListener

    //-----------------------------------------------------------------

    class PieEditUngroupListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Debug.println("Activating " + evt.getActionCommand());
        } // of actionPerformed

    } // of PieEditGroupListener

    //-----------------------------------------------------------------

    class PieEditTextListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            DenimPieMenu.this.textHandler.run();
        }

    }

    //-----------------------------------------------------------------

    class PieInsertTextListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            DenimPieMenu.this.textHandler.run();
        }

    }

    //-----------------------------------------------------------------

    class PieLinktoListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
            DenimWindow parentWin = (DenimWindow) SwingUtilities.getRoot(sheet);
            ShowPageTitleDlg dlg = new ShowPageTitleDlg(
                    parentWin,
                    ((DenimWindow)Denim.getWindows().get(0)).getDenimUI().getSheet(),
                    linkSrc,
                    panelToRun);
            dlg.setVisible(true);
        }
    }

    //-----------------------------------------------------------------

    class PieInsertPageListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            DenimPieMenu.this.textHandler.run();
        }

    }

    //-----------------------------------------------------------------
    /*
     * class PieInsertConditionListener implements ActionListener {
     * 
     * public void actionPerformed(ActionEvent evt) {
     * DenimUtils.findPanel(sheet, cmdsubsys.getAbsoluteLastLocation());
     * Debug.println("Activating " + evt.getActionCommand()); }
     *  }
     */
    //-----------------------------------------------------------------
    class PieOptionsListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            DenimWindow parentWin = (DenimWindow) SwingUtilities.getRoot(sheet);
            DenimOptions prefs = new DenimOptions(parentWin, new Dimension(
                    DenimSketch.getDefaultSketchWidth(), DenimSketch
                            .getDefaultSketchHeight()),
                    AutoSaver.isAutoSaveEnabled, AutoSaver.autoSaveInterval,
                    DenimSketch.isGridOn(), DenimSketch.getGridH(), DenimSketch
                            .getGridV());
            prefs.setVisible(true);
        }
    }

    //-----------------------------------------------------------------

    class PieComponentEditListener implements ActionListener {
        public void actionPerformed(ActionEvent evt) {
            DenimUI ui = sheet.getDenimUI();
            String componentName = ((RubberStamp) (ui.getCurrentTool()))
                    .getComponentType().getName();
            Debug.println("Showing <" + componentName + ">");
            ui.showComponent(DenimComponentRegistry.getInstance().getComponent(
                    componentName), cmdsubsys.getAbsoluteLastXLocation(),
                    cmdsubsys.getAbsoluteLastYLocation());

        } // of actionPerformed

    } // of PieComponentEditListener

    //-----------------------------------------------------------------

    class PieViewCenterListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            Point2D designCenter = DenimUtils
                    .getCollectionCenter(DenimPieMenu.this.sheet
                            .getForwardIterator());

            if (designCenter == null)
                return;

            AffineTransform tx = AffineTransformLib.scaleAndCenterAt(1,
                    designCenter.getX(), designCenter.getY(),
                    DenimPieMenu.this.sheet.getBounds());
            AffineTransform[] txArray = AffineTransformLib
                    .animateSlowInSlowOut(tx, 10);

            GraphicalObjectLib.animate(sheet, txArray);

        } // of actionPerformed
    }

    //-----------------------------------------------------------------

    class PieViewZoomInListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            sheet.getSlider().zoomIn(cmdsubsys.getAbsoluteLastXLocation(),
                    cmdsubsys.getAbsoluteLastYLocation());
        } // of actionPerformed

    } // of PieViewZoomInListener

    //-----------------------------------------------------------------

    class PieViewZoomOutListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            sheet.getSlider().zoomOut(cmdsubsys.getAbsoluteLastXLocation(),
                    cmdsubsys.getAbsoluteLastYLocation());
        } // of actionPerformed

    } // of PieViewZoomOutListener

    //-----------------------------------------------------------------

    class PieViewRadarViewListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            JDialog radarViewWindow = ((DenimWindow) SwingUtilities
                    .getRoot(sheet)).getRadarViewWindow();
            radarViewWindow.setVisible(!radarViewWindow.isVisible());
        } // of actionPerformed

    } // of PieViewZoomOutListener

    //-----------------------------------------------------------------

    class PieHelpContentsListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            sheet.getDenimUI().showHelpWindow(evt);
        } // of actionPerformed

    } // of PieEditCutListener

    //-----------------------------------------------------------------

    class PieHelpAboutListener implements ActionListener {

        public void actionPerformed(ActionEvent evt) {
            HelpAboutDialog.show(sheet.getDenimUI());
        } // of actionPerformed

    } // of PieEditCutListener

    //-----------------------------------------------------------------

    class SimplifiedPopupCallback extends PopupMenuCallback {

        public void popupMenuWillBecomeVisible(PopupMenuEvent evt) {
            //// 2. If the pie menu is opened over an arrow, show it instead of
            //// a grayed out "Context" menu.

            Arrow arrow = getTargetArrow(new Point2D.Double(sheet.getLastX(),
                    sheet.getLastY()));
            if (arrow != null) {
                arrowItem.arrow = arrow;
                arrowItem.setEnabled(true);
            } else {
                arrow = null;
                arrowItem.setEnabled(false);
            }

            /*
             * DenimPieMenu.this.remove(CONTEXT_MENU_POS);
             * 
             * if (arrow != null) { DenimPieMenu.this.add( new
             * EventTypePieMenu(sheet, arrow), CONTEXT_MENU_POS); } else {
             * DenimPieMenu.this.add("", CONTEXT_MENU_POS); }
             * 
             * //// 2. If the pie menu is opened over an object that has a
             * context //// menu, show it instead of a grayed out "Context"
             * menu. try { DenimPieMenu.this.remove(CONTEXT_MENU_POS);
             * 
             * //// 2.1. Get the nearest object. GraphicalObject gob =
             * sheet.getNearestObject( new Point2D.Float(sheet.getLastX(),
             * sheet.getLastY()));
             * 
             * //// 2.2. If the nearest object or any of its ancestors has a
             * //// context menu, show it. if (!(gob instanceof
             * ContextMenuSource) && gob instanceof GraphicalObjectGroup) {
             * while (gob != null && !(gob instanceof ContextMenuSource)) { gob =
             * gob.getParentGroup(); } }
             * 
             * if (gob instanceof ContextMenuSource) { DenimPieMenu.this.add(
             * ((ContextMenuSource) gob).getContextMenu(), CONTEXT_MENU_POS); }
             * //// 2.3. Otherwise, show a grayed-out Context menu. else {
             * PieMenu pieContext = new PieMenu("Context");
             * pieContext.setEnabled(false); DenimPieMenu.this.add(pieContext,
             * CONTEXT_MENU_POS); } } catch (Exception e) { // ignore }
             */
            //// 3. Find the panel to run if Run is chosen.
            panelToRun = sheet.getNearestPanel(new Point2D.Float(sheet
                    .getLastX(), sheet.getLastY()));

            if (panelToRun != null) {
                componentRunItem.setEnabled(true);
            } else {
                // Find the first panel that was created, and have the Run
                // window start there. Eventually, we want to replace this
                // with starting from the "home page."
                Iterator it = sheet.getReverseIterator();
                while (it.hasNext()) {
                    Object obj = it.next();
                    if (obj instanceof DenimPanel) {
                        panelToRun = (DenimPanel) obj;
                        componentRunItem.setEnabled(true);
                        break;
                    }
                }
                if (panelToRun == null) {
                    componentRunItem.setEnabled(false);
                }
            }

            if (panelToRun != null) {
                linkSrc = DenimPieMenu.this.getLinkSrcAt(new Point2D.Double(
                        sheet.getLastX(), sheet.getLastY()), panelToRun
                        .getSketch());
                if (linkSrc != null)
                    linkto.setEnabled(true);
                else
                    linkto.setEnabled(false);
            }

            //// 4. Enable Edit->Text, Insert->Text, or Insert->Page
            //// appropriately.
            textHandler = new TypedTextHandler(new Point2D.Float(sheet
                    .getLastX(), sheet.getLastY()), sheet);

            TypedTextHandler.ActionType textHandlerAction = textHandler
                    .getAction();

            insertPageMenuItem.setEnabled(false);
            insertTextMenuItem.setEnabled(false);
            editTextMenuItem.setEnabled(false);
            insertImageMenuItem.setEnabled(false);
            
            if(sheet.getPanel(new Point2D.Float(sheet
                    .getLastX(), sheet.getLastY()))!=null)
                insertImageMenuItem.setEnabled(true);

            if (textHandlerAction instanceof TypedTextHandler.TextPanelCreator) {
                insertPageMenuItem.setEnabled(true);
            } else if (textHandlerAction instanceof TypedTextHandler.TextCreator) {
                insertTextMenuItem.setEnabled(true);
            } else if (textHandlerAction instanceof TypedTextHandler.TextEditor) {
                editTextMenuItem.setEnabled(true);
            } else if (textHandlerAction instanceof TypedTextHandler.ScribbleConverter) {
                editTextMenuItem.setEnabled(true);
            }

            //// 5. If the next action is not undoable or redoable, disable
            //// the appropriate commands.
            try {
                editUndoMenuItem.setEnabled(cmdqueue.canUndo());
                editRedoMenuItem.setEnabled(cmdqueue.canRedo());
            }
            //// HACK: This exception is thrown when the user does File->New,
            //// then tries opening the pie menu.
            catch (ArrayIndexOutOfBoundsException e) {
                editUndoMenuItem.setEnabled(false);
                editRedoMenuItem.setEnabled(false);
            }
        }
    }

    //-----------------------------------------------------------------
    /**
     * Used to listen to any submenus we have opened.
     */
    class PopupMenuCallback implements PopupMenuListener, Serializable {

        public void popupMenuCanceled(PopupMenuEvent evt) {
        }

        public void popupMenuWillBecomeInvisible(PopupMenuEvent evt) {
        }

        public void popupMenuWillBecomeVisible(PopupMenuEvent evt) {
            // 1. Find the panel to run if File->Run is chosen.
            panelToRun = sheet.getNearestPanel(new Point2D.Float(sheet
                    .getLastX(), sheet.getLastY()));

            if (panelToRun != null) {
                projectRunMenuItem.setEnabled(true);
            } else {
                // Find the first panel that was created, and have the Run
                // window start there. Eventually, we want to replace this
                // with starting from the "home page."
                Iterator it = sheet.getReverseIterator();
                while (it.hasNext()) {
                    Object obj = it.next();
                    if (obj instanceof DenimPanel) {
                        panelToRun = (DenimPanel) obj;
                        projectRunMenuItem.setEnabled(true);
                        break;
                    }
                }
                if (panelToRun == null) {
                    projectRunMenuItem.setEnabled(false);
                }
            }

            // 2. Enable Edit->Text, Insert->Text, or Insert->Page
            //    appropriately.
            textHandler = new TypedTextHandler(new Point2D.Float(sheet
                    .getLastX(), sheet.getLastY()), sheet);

            TypedTextHandler.ActionType textHandlerAction = textHandler
                    .getAction();

            insertPageMenuItem.setEnabled(false);
            insertImageMenuItem.setEnabled(false);
            insertTextMenuItem.setEnabled(false);
            insertComponentMenuItem.setEnabled(false);
            editTextMenuItem.setEnabled(false);
            
            if(sheet.getPanel(new Point2D.Float(sheet
                    .getLastX(), sheet.getLastY()))!=null)
                insertImageMenuItem.setEnabled(true);

            if (DenimUtils.findPanel(sheet, new Point2D.Float(sheet.getLastX(),
                    sheet.getLastY())) != null) {
                if (DenimComponentRegistry.getInstance().hasCustomComponents())
                    insertComponentMenuItem.setEnabled(true);
            }

            expportItem.setEnabled(false);
            editItem.setEnabled(false);
            deleteItem.setEnabled(false);

            if (DenimComponentRegistry.getInstance().hasCustomComponents()) {
                expportItem.setEnabled(true);
                editItem.setEnabled(true);
                deleteItem.setEnabled(true);
            }

            if (textHandlerAction instanceof TypedTextHandler.TextPanelCreator) {
                insertPageMenuItem.setEnabled(true);
            } else if (textHandlerAction instanceof TypedTextHandler.TextCreator) {
                insertTextMenuItem.setEnabled(true);
            } else if (textHandlerAction instanceof TypedTextHandler.TextEditor) {
                editTextMenuItem.setEnabled(true);
            } else if (textHandlerAction instanceof TypedTextHandler.ScribbleConverter) {
                editTextMenuItem.setEnabled(true);
            }

            // 3. If the next action is not undoable or redoable, disable
            //    the appropriate commands.
            try {
                editUndoMenuItem.setEnabled(cmdqueue.canUndo());
                editRedoMenuItem.setEnabled(cmdqueue.canRedo());
            }
            //// HACK: This exception is thrown when the user does File->New,
            //// then tries opening the pie menu.
            catch (ArrayIndexOutOfBoundsException e) {
                editUndoMenuItem.setEnabled(false);
                editRedoMenuItem.setEnabled(false);
            }

            // 4. Adjust the text of View->(Show/Hide) Radar View appropriately
            JDialog radarViewWindow = ((DenimWindow) SwingUtilities
                    .getRoot(sheet)).getRadarViewWindow();
            if (radarViewWindow.isVisible()) {
                DenimPieMenu.this.viewRadarViewMenuItem
                        .setText("Hide\nRadar View");
            } else {
                DenimPieMenu.this.viewRadarViewMenuItem
                        .setText("Show\nRadar View");
            }

            // 5. Enable SVG Import menu appropriately.
            GraphicalObject gob = null;
            /*
             * insertImageMenuItem.setEnabled(false);
             * 
             * GraphicalObject gob = null; Point2D pt = new
             * Point2D.Float(sheet.getLastX(), sheet.getLastY());
             * 
             * GraphicalObjectCollection gobcol = new
             * GraphicalObjectCollectionImpl();
             * 
             * //// Get all deep graphical objects near the point within 0
             * points. sheet.getGraphicalObjects( COORD_ABS, pt, ALL, DEEP,
             * NEAR, 1, gobcol); Iterator iter = gobcol.getForwardIterator();
             * 
             * while (iter.hasNext()) { gob = (GraphicalObject) iter.next();
             * 
             * while (!(gob instanceof DenimSketch) && gob != null) { gob =
             * gob.getParentGroup(); }
             * 
             * if (gob instanceof DenimSketch)
             * insertImageMenuItem.setEnabled(true); if (gob instanceof
             * DenimSheet) insertImageMenuItem.setEnabled(false); if (gob
             * instanceof DenimLabel) insertImageMenuItem.setEnabled(false); }
             */

            /**
             * 6. deal with context menus
             */

            // 6.1. If the pie menu is opened over an arrow, show it instead of
            //    a grayed out "Context" menu.
            Arrow arrow = getTargetArrow(new Point2D.Double(sheet.getLastX(),
                    sheet.getLastY()));

            try
            {
                DenimPieMenu.this.remove(CONTEXT_MENU_POS);
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }

            // event menu
            if (arrow != null && arrow.getType()==Arrow.NAV &&
            		arrow.getSource() instanceof DenimHyperlinkInstance) {
                DenimPieMenu.this.add(new EventTypePieMenu(sheet, arrow),
                        CONTEXT_MENU_POS);
                return;
            } else {

                if (panelToRun != null) {
                    linkSrc = DenimPieMenu.this.getLinkSrcAt(
                            new Point2D.Double(sheet.getLastX(), sheet
                                    .getLastY()), panelToRun.getSketch());
                    if (linkSrc != null) {
                        DenimPieMenu.this.add("Link To", CONTEXT_MENU_POS)
                                .addActionListener(new PieLinktoListener());
                        return;
                    }
                }

                //// 6.3. Otherwise, show a grayed-out Context menu.
                PieMenu pieContext = new PieMenu("Context");
                pieContext.setEnabled(false);
                DenimPieMenu.this.add(pieContext, CONTEXT_MENU_POS);
            }

            // 6.2. If the pie menu is opened over an object that has a context
            //    menu, show it instead of a grayed out "Context" menu.

            try {
                //// 2.1. Get the nearest object.
            	Point2D pt = new Point2D.Float(
                        sheet.getLastX(), sheet.getLastY());
            	
                gob = sheet.getNearestObject(pt);
                
                // deal with radiobuttons, checkboxes etc contained by a denim group
                if(gob instanceof DenimGroup)
                {
                	DenimGroup grp = (DenimGroup)gob;
                	GraphicalObjectCollection col = grp.getGraphicalObjects(COORD_ABS, pt, GraphicalObjectGroup.FIRST, GraphicalObjectGroup.SHALLOW, GraphicalObjectGroup.CONTAINS);
                	if(col.isEmpty()==false)
                		gob = col.getFirst();
                }

                //// 2.2. If the nearest object or any of its ancestors has a
                //// context menu, show it.
                if (!(gob instanceof ContextMenuSource)
                        && gob instanceof GraphicalObjectGroup) {
                    while (gob != null && !(gob instanceof ContextMenuSource)) {
                        gob = gob.getParentGroup();
                    }
                }

                try
                {
                    DenimPieMenu.this.remove(CONTEXT_MENU_POS);
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }

                if (gob instanceof ContextMenuSource) {
                    DenimPieMenu.this.add(((ContextMenuSource) gob)
                            .getContextMenu(), CONTEXT_MENU_POS);
                    return;
                } else {
                    //// 6.3. Otherwise, show a grayed-out Context menu.
                    PieMenu pieContext = new PieMenu("Context");
                    pieContext.setEnabled(false);
                    DenimPieMenu.this.add(pieContext, CONTEXT_MENU_POS);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    } // of PopupMenuCallback

    private GraphicalObject getLinkSrcAt(Point2D pt, DenimSketch sketch) {
        GraphicalObjectCollection gobcol = new GraphicalObjectCollectionImpl();
        Iterator it = sketch.getReverseIterator();
        while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject) it.next();
            if (gob instanceof TypedText||
                    gob instanceof ScribbledText||
                    gob instanceof DenimHyperlinkInstance||
                    gob instanceof DenimButtonInstance)
            {
                if(gob.getBounds2D(COORD_ABS).contains(pt))
                {
                    gobcol.add(gob);    
                }
            }
        }

        if(gobcol.isEmpty())
        {
            it = sketch.getReverseIterator();
            while (it.hasNext()) {
                GraphicalObject gob = (GraphicalObject) it.next();
                if (gob instanceof TimedStroke)
                {
                    if(gob.getBounds2D(COORD_ABS).contains(pt))
                    {
                        gobcol.add(gob);    
                    }
                }
            }
            
            if(gobcol.isEmpty())
                return null;
            else
                return GraphicalObjectLib.getTopmostGraphicalObject(gobcol);    
        }
        else
            return GraphicalObjectLib.getTopmostGraphicalObject(gobcol);
    } // of method

/*    public GraphicalObject getLinkSrcAt(Point2D startPoint,
            DenimSketch sketch) {

        GraphicalObject startAnchor = null;
        GraphicalObject startObjChild = sketch;
        GraphicalObject startObjGrandchild;

        //// 3.2.1. But ignore groups containing components first.
        GraphicalObject startObjNotGroup = startObjChild;
        do {
            GraphicalObjectGroup maybeGroupParent = (GraphicalObjectGroup) startObjNotGroup;

            startObjNotGroup = DenimUtils
                    .getTopmostComponentContainingAbsPt(maybeGroupParent,
                            startPoint);

        } while (startObjNotGroup instanceof DenimGroup
                && !((DenimGroup) startObjNotGroup)
                        .getShouldGroupContainedAnchors());

        if (startObjNotGroup != null) {
            startObjGrandchild = DenimUtils
                    .getNearestComponentAtAbsPtExcept(startObjNotGroup
                            .getParentGroup(), startPoint, Arrow.class);
        } else
            startObjGrandchild = null;

        //// 3.2.2. If the arrow originates from within the sketch
        // directly...
        if (startObjGrandchild == null
                || startObjGrandchild instanceof Arrow) {
            startAnchor = startObjChild;
        }
        //// 3.2.3. ...otherwise if the object is not already a
        //// component instance, make it a hyperlink.
        else {
            startAnchor = startObjGrandchild;
        }

        return startAnchor;
    } // of method
*/
    //-----------------------------------------------------------------

    public void clear() {
        panelToRun = null;
    }

    //=== PIE MENU STUFF ====================================================
    //===========================================================================

}