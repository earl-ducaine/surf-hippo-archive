//// See bottom of file for software license
package edu.berkeley.guir.lib.swing.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 06 2004
 */
public class SimpleRow
    implements Row {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    List    list                           = new ArrayList();
    boolean flagIgnoreForWidthCalculations = false;

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Row with one item.
     */
    public SimpleRow(Object objAA) {
        list.add(objAA);
    } // of constructor

    //--------------------

    /**
     * @param flag is true to ignore this row for width calculations,
     *             default is false.
     */
    public SimpleRow(boolean flag, Object objAA) {
        this(objAA);
        setIgnoreForWidthCalculations(flag);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Row with two items.
     */
    public SimpleRow(Object objAA, Object objBB) {
        list.add(objAA);
        list.add(objBB);
    } // of constructor

    //--------------------

    /**
     * @param flag is true to ignore this row for width calculations,
     *             default is false.
     */
    public SimpleRow(boolean flag, Object objAA, Object objBB) {
        this(objAA, objBB);
        setIgnoreForWidthCalculations(flag);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Row with three items.
     */
    public SimpleRow(Object objAA, Object objBB, Object objCC) {
        list.add(objAA);
        list.add(objBB);
        list.add(objCC);
    } // of constructor

    //--------------------

    /**
     * @param flag is true to ignore this row for width calculations,
     *             default is false.
     */
    public SimpleRow(boolean flag, Object objAA, Object objBB, Object objCC) {
        this(objAA, objBB, objCC);
        setIgnoreForWidthCalculations(flag);
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Row with four items.
     */
    public SimpleRow(Object objAA, Object objBB, 
                     Object objCC, Object objDD) {
        list.add(objAA);
        list.add(objBB);
        list.add(objCC);
        list.add(objDD);
    } // of constructor

    //--------------------

    /**
     * @param flag is true to ignore this row for width calculations,
     *             default is false.
     */
    public SimpleRow(boolean flag, Object objAA, Object objBB, 
                     Object objCC, Object objDD) {
        this(objAA, objBB, objCC, objDD);
        setIgnoreForWidthCalculations(flag);
    } // of constructor

    //----------------------------------------------------------------

    public SimpleRow(Object[] arr) {
        for (int i = 0; i < arr.length; i++) {
            list.add(arr[i]);
        }
    } // of constructor

    //--------------------

    /**
     * @param flag is true to ignore this row for width calculations,
     *             default is false.
     */
    public SimpleRow(boolean flag, Object[] arr) {
        this(arr);
        setIgnoreForWidthCalculations(flag);
    } // of constructor

    //----------------------------------------------------------------

    public SimpleRow(List aList) {
        list = new ArrayList(aList);
    } // of constructor

    //--------------------

    /**
     * @param flag is true to ignore this row for width calculations,
     *             default is false.
     */
    public SimpleRow(boolean flag, List aList) {
        this(aList);
        setIgnoreForWidthCalculations(flag);
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================




    //==========================================================================
    //===   ROW METHODS   ======================================================

    /**
     * Return the element at that index, or "" if out of bounds.
     */
    public Object get(int index) {
        if (index < list.size()) {
            return (list.get(index));
        }
        else {
            return ("");
        }
    } // of method

    //----------------------------------------------------------------

    public int numCols() {
        return (list.size());
    } // of method

    //----------------------------------------------------------------

    public String toString() {
        Iterator     it     = list.iterator();
        StringBuffer strbuf = new StringBuffer();

        while (it.hasNext()) {
            strbuf.append(it.next());
            strbuf.append(" ");
        }

        return (strbuf.toString());
    } // of method

    //----------------------------------------------------------------

    public void setIgnoreForWidthCalculations(boolean flag) {
        flagIgnoreForWidthCalculations = flag;
    } // of method

    //--------------------

    public boolean isIgnoredForWidthCalculations() {
        return (flagIgnoreForWidthCalculations);
    } // of method

    //===   ROW METHODS   ======================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
