//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.graphics;

import edu.berkeley.guir.lib.awt.geom.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.font.*;
import java.awt.image.*;
import java.awt.image.renderable.*;
import java.text.*;

/**
 * Render lowest quality images.
 * <UL>
 *    <LI>Only outlines are drawn, even for filled objects.
 *    <LI>Polygons are drawn as bounding boxes only.
 *    <LI>No images are rendered, only outlines.
 *    <LI>All rendering hints are set for speed.
 * </UL>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 19 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class GraphicsLowestQuality 
   extends GraphicsLowQuality {

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public GraphicsLowestQuality() {
      //// 1. Hints for lowest quality, fastest speed.
      hints = new HintsHashMap();
      hints.put(RenderingHints.KEY_ALPHA_INTERPOLATION,
            RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
      hints.put(RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_OFF);
      hints.put(RenderingHints.KEY_COLOR_RENDERING,
            RenderingHints.VALUE_COLOR_RENDER_SPEED);
      hints.put(RenderingHints.KEY_DITHERING,
            RenderingHints.VALUE_DITHER_DISABLE);
      hints.put(RenderingHints.KEY_RENDERING,
            RenderingHints.VALUE_RENDER_SPEED);
      hints.put(RenderingHints.KEY_TEXT_ANTIALIASING,
            RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
      hints.put(RenderingHints.KEY_FRACTIONALMETRICS,
            RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
      hints.put(RenderingHints.KEY_INTERPOLATION,
            RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   DELEGATION GRAPHICS - DRAWING METHODS   =============================

   /**
    * Only draws bounds, no fill.
    */
   public void fillRect(int x, int y, int width, int height) {
      g.drawRect(x, y, width, height);
   } // of fillRect

   //-----------------------------------------------------------------

   /**
    * Only draws bounds, no fill.
    */
   public void fillRoundRect(int x, int y, int width, int height,
                                       int arcWidth, int arcHeight) {
      g.drawRoundRect(x, y, width, height, arcWidth, arcHeight);
   } // of fillRoundRect

   //-----------------------------------------------------------------

   /**
    * Only draws bounds, no fill.
    */
   public void fillOval(int x, int y, int width, int height) {
      g.drawOval(x, y, width, height);
   } // of fillOval

   //-----------------------------------------------------------------

   /**
    * Only draws bounds, no fill.
    */
   public void fillArc(int x, int y, int width, int height,
                                 int startAngle, int arcAngle) {
      g.drawArc(x, y, width, height, startAngle, arcAngle);
   } // of fillArc

   //-----------------------------------------------------------------

   /**
    * Only draws bounding box, no polygon, no fill.
    */
   public void fillPolygon(int xPoints[], int yPoints[], int nPoints) {
      drawPolygon(new Polygon(xPoints, yPoints, nPoints));
   } // of fillPolygon

   //-----------------------------------------------------------------

   /**
    * Only draws bounding box, no polygon, no fill.
    */
   public void fillPolygon(Polygon p) {
      g.draw(p.getBounds());
   } // of fillPolygon

   //-----------------------------------------------------------------

   public void drawString(String str, int x, int y) {
      g.drawString(str, x, y);
   } // of drawString

   //-----------------------------------------------------------------

   public void drawChars(char[] data, int offset, int length, 
                               int x, int y) {
      g.drawChars(data, offset, length, x, y);
   } // of drawChars

   //-----------------------------------------------------------------

   public void drawBytes(byte[] data, int offset, int length, 
                               int x, int y) {
      g.drawBytes(data, offset, length, x, y);
   } // of drawBytes

   //-----------------------------------------------------------------

   /**
    * Only draws bounds, no fill.
    */
   public boolean drawImage(Image img, int x, int y, 
                                  ImageObserver observer) {
      g.drawRect(x, y, img.getWidth(null), img.getHeight(null));
      return (true);
   } // of drawImage

   //-----------------------------------------------------------------

   /**
    * Draw outline of image.
    */
   public boolean drawImage(Image img, int x, int y,
                            int width, int height, ImageObserver observer) {
      g.drawRect(x, y, width, height);
      return (true);
   } // of drawImage

   //-----------------------------------------------------------------

   /**
    * Draw outline of image.
    */
   public boolean drawImage(Image img, int x, int y, 
                            Color bgcolor, ImageObserver observer) {
      g.drawRect(x, y, img.getWidth(null), img.getHeight(null));
      return (true);
   } // of drawImage

   //-----------------------------------------------------------------

   /**
    * Draw outline of image.
    */
   public boolean drawImage(Image img, int x, int y,
                                      int width, int height, 
                                      Color bgcolor, ImageObserver observer) {
      g.drawRect(x, y, width, height);
      return (true);
   } // of drawImage

   //-----------------------------------------------------------------

   /**
    * Draw outline of image.
    */
   public boolean drawImage(Image img,
                                      int dx1, int dy1, int dx2, int dy2,
                                      int sx1, int sy1, int sx2, int sy2,
                                      ImageObserver observer) {
      g.drawRect(dx1, dy1, dx2 - dx1, dy2 - dy1);
      return (true);
   } // of drawImage

   //-----------------------------------------------------------------

   /**
    * Draw outline of image.
    */
   public boolean drawImage(Image img,
                            int dx1, int dy1, int dx2, int dy2,
                            int sx1, int sy1, int sx2, int sy2,
                            Color bgcolor, ImageObserver observer) {
      g.drawRect(dx1, dy1, dx2 - dx1, dy2 - dy1);
      return (true);
   } // of drawImage


   //===   DELEGATION GRAPHICS - DRAWING METHODS   =============================
   //===========================================================================



   //===========================================================================
   //===   DELEGATION GRAPHICS2D - DRAWING METHODS   ===========================

   public void draw(Shape s) {
      g.draw(s);
   } // of draw

   //-----------------------------------------------------------------

   public void draw3DRect(int x, int y, int width, 
                                int height, boolean raised) {
      g.draw3DRect(x, y, width, height, raised);
   } // of draw3DRect

   //-----------------------------------------------------------------

   public void drawGlyphVector(GlyphVector gv, float x, float y) {
      g.drawGlyphVector(gv, x, y);
   } // of drawGlyphVector

   //-----------------------------------------------------------------

   /**
    * Draw outline of image.
    */
   public void fill3DRect(int x, int y, int width, int height,
                           boolean raised) {
      g.draw3DRect(x, y, width, height, raised);
   } // of fill3DRect

   //-----------------------------------------------------------------

   /**
    * Draw outline of image.
    */
   public boolean drawImage(Image img, AffineTransform xform,
                                      ImageObserver obs) {
      Rectangle2D rect = 
         new Rectangle2D.Double(0, 0, img.getWidth(null), img.getHeight(null));
      GeomLib.transformRectangle(xform, rect, rect);
      g.draw(rect);
      return (true);
   } // of drawImage

   //-----------------------------------------------------------------

   /**
    * Draw outline of image.
    */
   public void drawImage(BufferedImage img, BufferedImageOp op,
                         int x, int y) {
      g.drawRect(x, y, img.getWidth(), img.getHeight());
   } // of drawImage

   //-----------------------------------------------------------------

   public void drawRenderedImage(RenderedImage img, 
                                       AffineTransform xform) {
      Rectangle2D rect = 
         new Rectangle2D.Double(0, 0, img.getWidth(), img.getHeight());
      GeomLib.transformRectangle(xform, rect, rect);
      g.draw(rect);
   } // of drawRenderedImage

   //-----------------------------------------------------------------

   public void drawRenderableImage(RenderableImage img, 
                                         AffineTransform xform) {
      g.drawRenderableImage(img, xform);
   } // of drawRenderableImage

   //-----------------------------------------------------------------

   public void drawString(String s, float x, float y) {
      g.drawString(s, x, y);
   } // of drawString

   //-----------------------------------------------------------------

   public void drawString(AttributedCharacterIterator iterator, 
                                int x, int y) {
      g.drawString(iterator, x, y);
   } // of drawString

   //-----------------------------------------------------------------

   public void drawString(AttributedCharacterIterator iterator,
                                    float x, float y) {
      g.drawString(iterator, x, y);
   } // of drawString

   //-----------------------------------------------------------------

   /**
    * Draw outline of shape, no fill.
    */
   public void fill(Shape s) {
      g.draw(s);
   } // of fill

   //===   DELEGATION GRAPHICS2D - DRAWING METHODS   ===========================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
