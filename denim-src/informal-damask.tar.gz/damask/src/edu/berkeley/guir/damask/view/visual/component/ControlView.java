package edu.berkeley.guir.damask.view.visual.component;

import java.awt.Color;
import java.util.Iterator;
import java.util.List;

import edu.berkeley.guir.damask.component.Control;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.event.ControlEvent;
import edu.berkeley.guir.damask.event.ControlListener;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.DamaskDocument.DamaskCanvasGroup;
import edu.berkeley.guir.damask.view.visual.dialog.PageView;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.*;

/** 
 * A view of a Damask control.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  12-31-2003 James Lin
 *                               Created ControlView.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 12-31-2003
 */
public abstract class ControlView extends ComponentView {
   private static final Color ROLLOVER_COLOR = new Color(0, 102, 0);
   private static final Color ROLLOVER_COLOR_OTHER_LAYER =
      new Color(0, 102, 0, DamaskLayer.OTHER_LAYER_ALPHA);
   
   private boolean inRunMode;
   private PInputEventListener runModeEventHandler;
   private final PInputEventListener designModeEventHandler =
      new DesignModeEventHandler(this);
   private final ControlListener controlHandler = new ControlHandler();

   /**
    * Initializes a view of the specified control, which does not react
    * to any events during run mode and automatically adjusts the bounds
    * and transform of the view by listening to changes in the model
    */
   public ControlView(final Control control) {
      this(control, null, true);
   }


   /**
    * Initializes a view of the specified control, which does not react
    * to any events during run mode.
    * 
    * @param control the control for which this view is created
    * @param useDefaultElementListener true if this instance should add
    * an InteractionElementListener that automatically adjusts the bounds
    * and transform of the view by listening to changes in the model
    */
   public ControlView(
      final Control control,
      final boolean useDefaultElementListener) {

      this(control, null, useDefaultElementListener);
   }

   /**
    * Initializes a view of the specified component, which uses the specified
    * event handler to handle events during run mode and automatically adjusts
    * the bounds and transform of the view by listening to changes in the model

    * @param control the control for which this view is created
    * @param runModeEventHandler the event handler to handle events during
    * run mode, or null if event should be ignored
    */
   public ControlView(
      final Control control,
      final PInputEventListener runModeEventHandler) {

      this(control, runModeEventHandler, true);
   }


   /**
    * Initializes a view of the specified control, which uses the specified
    * event handler to handle events during run mode.
    * 
    * @param control the control for which this view is created
    * @param runModeEventHandler the event handler to handle events during
    * run mode, or null if event should be ignored
    * @param useDefaultElementListener true if this instance should add
    * an InteractionElementListener that automatically adjusts the bounds
    * and transform of the view by listening to changes in the model
    */
   public ControlView(
      final Control control,
      final PInputEventListener runModeEventHandler,
      final boolean useDefaultElementListener) {
      
      super(control, useDefaultElementListener);

      this.runModeEventHandler = runModeEventHandler;
      control.addControlListener(controlHandler);

      setPaint(new Color(0, 0, 0, 0));
      setStrokePaint(new Color(0, 0, 0, 0));
      
      inRunMode = false;
      addInputEventListener(designModeEventHandler);
   }
   
   // Overrides method in parent class.
   public void dispose() {
      super.dispose();
      removeInputEventListener(runModeEventHandler);
      ((Control)getModel()).removeControlListener(controlHandler);
   }


   /**
    * Returns the state of this component view.
    */
   public abstract Object getState();
      
   /**
    * Sets the state of this component view.
    */
   public abstract void setState(final Object state);


   /**
    * Returns whether this component view is in Run mode.
    */
   public boolean isInRunMode() {
      return inRunMode;
   }

   /**
    * Sets whether this component view is in Run mode, when the controls behave
    * as if the user is interacting with them.
    */
   public void setInRunMode(final boolean flag) {
      if (inRunMode == flag) {
         return;
      }

      inRunMode = flag;
      if (inRunMode) {
         removeInputEventListener(designModeEventHandler);
         if (runModeEventHandler != null) {
            addInputEventListener(runModeEventHandler);
         }
      }
      else {
         if (runModeEventHandler != null) {
            removeInputEventListener(runModeEventHandler);
         }
         addInputEventListener(designModeEventHandler);
      }
   }
   
   
   private class ControlHandler implements ControlListener {
      public void controlStateChanged(ControlEvent e) {
         assert e.getControl() == getModel():
            "should not be listening to events from " + e.getControl();

         final PageView pageView = getPageView();
         final Dialog pageDialog = ((Page)(pageView.getModel())).getDialog();
         final Dialog controlDialog = e.getControl().getDialog();
         final int condition;
         if (pageDialog == controlDialog) {
            condition = pageView.getDesignTimeCondition();
         }
         else {
            // Control is actually in a template -- use condition from template
            condition = controlDialog.getInitialCondition();
         }
         
         setState(
            e.getControl().getStateForCondition(controlDialog, condition));
      }

      public void controlSignificanceChanged(ControlEvent e) {
         assert e.getControl() == getModel():
            "should not be listening to events from " + e.getControl();
         //TODO deal with significance
      }

      // @Override
      public void pageRegionChanged(ControlEvent e) {
      }
   }

   
   /**
    * The event handler for a control view while designing.
    */
   private static class DesignModeEventHandler extends PBasicInputEventHandler {
      private ControlView controlView;
      
      public DesignModeEventHandler(final ControlView controlView) {
         this.controlView = controlView;
      }
      
      private void changeNodeColor(
         final PInputEvent event,
         final boolean isPush) {

         if (!(event.getComponent() instanceof DamaskCanvas)) {
            return;
         }

         final PNode node = event.getPickedNode();
         
         if (!(node instanceof InteractionElementView)) {
            return;
         }
         
         final InteractionElementView elementView =
            (InteractionElementView)node;

         final DamaskDocument doc =
            ((DamaskCanvas)event.getComponent()).getDocument();
            
         for (Iterator i = doc.getCanvasGroups().iterator();
            i.hasNext();
            ) {
               
            final DamaskCanvasGroup group = (DamaskCanvasGroup)i.next();
            for (Iterator j = group.getCanvases().iterator(); j.hasNext();) {
               final DamaskCanvas canvas = (DamaskCanvas)j.next();
               final DamaskLayer layer = (DamaskLayer)canvas.getLayer();
               final List/*<InteractionElementView>*/
                  views = layer.getViews(elementView.getModel());

               for (Iterator k = views.iterator(); k.hasNext(); ) {
                  final InteractionElementView aView =
                     (InteractionElementView)k.next();
                     
                  if (isPush) {
                     if (aView.isSelectable()) {
                        DamaskAppUtils.pushInternalColor(aView, ROLLOVER_COLOR);
                     }
                     else {
                        DamaskAppUtils.pushInternalColor(aView, ROLLOVER_COLOR_OTHER_LAYER);
                     }
                  }
                  else {
                     DamaskAppUtils.popInternalColor(aView);
                     if (controlView.getLayer() != null) {
                        // Because the device type layer might have changed
                        // between roll over and off, call
                        // deviceTypeLayerChanged() to make sure the control
                        // view's appearance is correct.
                        controlView.deviceTypeLayerChanged();
                     }
                  }
               }
            }
         }
      }
      
      public void mouseEntered(PInputEvent event) {
         if (event.getPickedNode() == controlView) {
            changeNodeColor(event, true);
         }
      }

      public void mouseExited(PInputEvent event) {
         if (event.getPickedNode() == controlView) {
            changeNodeColor(event, false);
         }
      }
   }
}
