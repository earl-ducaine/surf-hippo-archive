//// See bottom of source code for software license

package edu.berkeley.guir.denim.dialogs;

import javax.swing.*;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.File;
import java.util.Iterator;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.objects.GraphicalObject;
import edu.berkeley.guir.lib.satin.objects.GraphicalObjectGroup;
import edu.berkeley.guir.lib.satin.widgets.ExtensionFileFilter;

/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Nov 19, 2003 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class DenimOptions extends JDialog 
				implements SatinConstants {
	
	DenimWindow mWin = null;
	
	private Dimension mPageSize = null;
	private boolean mAutosave;
	private long mInterval;
	private boolean mIsGrid;
	
	static final int width = 500;
    static final int height = 410;
    
    static final int xgap = 10;
    static final int ygap = 20;
    
    static final Color selectorColor = Color.gray;
    static final double selectorsize = 10; 
    
	JTextField mMinutes;
	JTextField mPageWidth;
	JTextField mPageHeight;
	
	JCheckBox isAutoSave;
    JComboBox fonttype1, fonttype2, fonttype3;
    
	double mHGap;
	double mVGap;
	
	JCheckBox isGridOn;
	JTextField hGap;
	JTextField vGap;
    
    String imageName = null;
    Rectangle2D imageRect = null;
    Rectangle2D deviceRect = null;
    Rectangle2D normalizedImageRect = null;
    
    public final static int topleft = 0;
    public final static int left = 1;
    public final static int bottomleft = 2;
    public final static int topright = 3;
    public final static int right = 4;
    public final static int bottomright = 5;
    public final static int topmiddle = 6;
    public final static int bottommiddle = 7;
    
    public final static int nowhere = -1;
    
	class Grid extends JPanel {
		public Grid() {
			setLayout(new GridLayout(3,1));

			isGridOn = new JCheckBox("Grid on");
			isGridOn.setSelected(mIsGrid);
			
			isGridOn.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent evt) {
					if(isGridOn.isSelected())
					{
						hGap.setEnabled(true);
						vGap.setEnabled(true);
					}
					else
					{
						hGap.setEnabled(false);
						vGap.setEnabled(false);
					}
				}
			});

			this.add(isGridOn);
			
			JPanel wp = new JPanel();
			((FlowLayout)wp.getLayout()).setAlignment(FlowLayout.LEFT);
			wp.add(new JLabel("Horizontal spacing: "));
			String str = new String();
			str += mHGap;
			hGap = new JTextField(str);
			hGap.setPreferredSize(new Dimension(100, 26));
			hGap.setEnabled(mIsGrid);
			wp.add(hGap);
			this.add(wp);

			JPanel hp = new JPanel();
			((FlowLayout)hp.getLayout()).setAlignment(FlowLayout.LEFT);
			hp.add(new JLabel("Vertical spacing:     "));
			str = new String();
			str += mVGap;
			vGap = new JTextField(str);
			vGap.setPreferredSize(new Dimension(100, 26));
			vGap.setEnabled(mIsGrid);
			hp.add(vGap);
			this.add(hp);
		}
	}
	
	class Save extends JPanel {
		public Save() {
			((FlowLayout)this.getLayout()).setAlignment(FlowLayout.LEFT);
			isAutoSave = new JCheckBox("Save automatically every");
			isAutoSave.setSelected(mAutosave);
			this.add(isAutoSave);
			String str = new String();
			str += mInterval;
			mMinutes = new JTextField(str);
			mMinutes.setPreferredSize(new Dimension(100, 26));
			this.add(mMinutes);
			this.add(new JLabel("minutes"));
		}
	}
    
    class Fonts extends JPanel {
        public Fonts() {
            BoxLayout layout = new BoxLayout(this, BoxLayout.Y_AXIS);
            this.setLayout(layout);
            
            JPanel row1 = new JPanel();
            this.add(row1);
            
            ((FlowLayout)row1.getLayout()).setAlignment(FlowLayout.LEFT);
            row1.add(new JLabel("Font #1 "));
            fonttype1 = new JComboBox();
            Iterator it = TextInsertDialog.familyList.iterator();
            while(it.hasNext())
            {
                String fn = (String)it.next();
                fonttype1.addItem(fn);
            }
            fonttype1.setSelectedItem(TextInsertDialog.globalfont1);
            row1.add(fonttype1);
            
            JPanel row2 = new JPanel();
            this.add(row2);
            
            ((FlowLayout)row2.getLayout()).setAlignment(FlowLayout.LEFT);
            row2.add(new JLabel("Font #2 "));
            fonttype2 = new JComboBox();
            it = TextInsertDialog.familyList.iterator();
            while(it.hasNext())
            {
                String fn = (String)it.next();
                fonttype2.addItem(fn);
            }
            fonttype2.setSelectedItem(TextInsertDialog.globalfont2);
            row2.add(fonttype2);
            
            JPanel row3 = new JPanel();
            this.add(row3);
            ((FlowLayout)row3.getLayout()).setAlignment(FlowLayout.LEFT);
            row3.add(new JLabel("Font #3 "));
            fonttype3 = new JComboBox();
            it = TextInsertDialog.familyList.iterator();
            while(it.hasNext())
            {
                String fn = (String)it.next();
                fonttype3.addItem(fn);
            }
            fonttype3.setSelectedItem(TextInsertDialog.globalfont3);
            row3.add(fonttype3);
        }
    }
	
	class PageSize extends JPanel {
        
        ImageCanvas imageCanvas;
        
		public PageSize() {
            
            this.setLayout(new BorderLayout());
            
            JPanel content = new JPanel();
			//content.setLayout(new GridLayout(2,1));
            ((FlowLayout)content.getLayout()).setAlignment(FlowLayout.LEADING);

			JPanel wp = new JPanel();
			((FlowLayout)wp.getLayout()).setAlignment(FlowLayout.LEFT);
			wp.add(new JLabel("Width "));
			String str = new String();
			str += (int)mPageSize.getWidth();
			mPageWidth = new JTextField(str);
			mPageWidth.setPreferredSize(new Dimension(100, 26));
			wp.add(mPageWidth);
            mPageWidth.addKeyListener(new KeyAdapter() {
                public void keyPressed(KeyEvent evt) {
                    if(evt.getKeyChar()=='\n')
                    {
                        deviceRect = null;
                        imageRect = null;
                        imageCanvas.repaint();
                    }
                }
            });

			JPanel hp = new JPanel();
			((FlowLayout)hp.getLayout()).setAlignment(FlowLayout.LEFT);
			hp.add(new JLabel("Height"));
			str = new String();
			str += (int)mPageSize.getHeight();
			mPageHeight = new JTextField(str);
			mPageHeight.setPreferredSize(new Dimension(100, 26));
			hp.add(mPageHeight);
            mPageHeight.addKeyListener(new KeyAdapter() {
                public void keyPressed(KeyEvent evt) {
                    if(evt.getKeyChar()=='\n')
                    {
                        deviceRect = null;
                        imageRect = null;
                        imageCanvas.repaint();
                    }
                }
            });
            
			content.add(wp);
			content.add(hp);
            
            this.add(content, BorderLayout.NORTH);
            
            imageCanvas = new ImageCanvas();
            this.add(imageCanvas, BorderLayout.CENTER);
            
            JButton clearimage = new JButton("Clear Image");
            clearimage.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    imageName = null;
                    imageRect = null;
                    imageCanvas.repaint();
                }
            });
            JPanel btm = new JPanel();
            btm.add(clearimage);
            this.add(btm, BorderLayout.SOUTH);
		} 
	}
    
    class ImageCanvas extends JPanel {
       
        Point lstPos = null;
        int selector = nowhere;
        
        public ImageCanvas() {
            //this.setBackground(Color.white);
            this.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent evt) {
                    insertImage();
                    repaint();
                }
            });
            
            this.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent evt) {
                    if(imageName!=null)
                    {
                        lstPos = evt.getPoint();
                        selector = getSelector(evt.getPoint());
                    }
                }
            });
            
            this.addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent evt) {

                    if(imageName!=null)
                    {
                        double dx = evt.getX() - lstPos.getX();
                        double dy = evt.getY() - lstPos.getY();
    
                        lstPos = evt.getPoint();
                       
                        switch(selector)
                        {
                        case topleft:
                           imageRect.setFrame(imageRect.getMinX() + dx,
                                   imageRect.getMinY() + dy,
                                   imageRect.getWidth()-dx, 
                                   imageRect.getHeight()-dy);
                            break;
                        case topmiddle:
                           imageRect.setFrame(imageRect.getMinX(),
                                   imageRect.getMinY() + dy,
                                   imageRect.getWidth(), 
                                   imageRect.getHeight()-dy);
                            break;
                        case topright:
                            imageRect.setFrame(imageRect.getMinX(),
                                    imageRect.getMinY() + dy,
                                    imageRect.getWidth()+dx, 
                                    imageRect.getHeight()-dy);
                            break;
                        case left:
                            imageRect.setFrame(imageRect.getMinX() + dx,
                                    imageRect.getMinY(),
                                    imageRect.getWidth()-dx, 
                                    imageRect.getHeight());
                            break;
                        case right:
                            imageRect.setFrame(imageRect.getMinX(),
                                    imageRect.getMinY(),
                                    imageRect.getWidth()+dx, 
                                    imageRect.getHeight());
                            break;
                        case bottomleft: 
                            imageRect.setFrame(imageRect.getMinX() + dx,
                                    imageRect.getMinY(),
                                    imageRect.getWidth()-dx, 
                                    imageRect.getHeight()+dy);
                            break;
                        case bottommiddle: 
                            imageRect.setFrame(imageRect.getMinX(),
                                    imageRect.getMinY(),
                                    imageRect.getWidth(), 
                                    imageRect.getHeight()+dy);
                            break;
                        case bottomright: 
                            imageRect.setFrame(imageRect.getMinX(),
                                    imageRect.getMinY(),
                                    imageRect.getWidth()+dx, 
                                    imageRect.getHeight()+dy);
                            break;
                        }
                        
                        repaint();
                    }
                }
            });
        }
        
        
        public int getSelector(Point2D p){
            
            Rectangle2D bbx = imageRect;
            
            if(p.distance(bbx.getMinX(),bbx.getMinY())<selectorsize/2)
                return topleft;
            if(p.distance(bbx.getCenterX(),bbx.getMinY())<selectorsize/2)
                return topmiddle;
            if(p.distance(bbx.getMaxX(),bbx.getMinY())<selectorsize/2)
                return topright;
            if(p.distance(bbx.getMinX(),bbx.getCenterY())<selectorsize/2)
                return left;
            if(p.distance(bbx.getMaxX(),bbx.getCenterY())<selectorsize/2)
                return right;
            if(p.distance(bbx.getMinX(),bbx.getMaxY())<selectorsize/2)
                return bottomleft;
            if(p.distance(bbx.getCenterX(),bbx.getMaxY())<selectorsize/2)
                return bottommiddle;
            if(p.distance(bbx.getMaxX(),bbx.getMaxY())<selectorsize/2)
                return bottomright;
            
            return nowhere;
        }
        
        public void insertImage() {
            //// 0.1. Setup the file chooser.
            JFileChooser chooser = new JFileChooser();

            //// 0.2. Setup the file filter.
            ExtensionFileFilter filter = new ExtensionFileFilter();
            filter.addExtension("jpg");
            filter.addExtension("bmp");
            filter.addExtension("gif");
            filter.addExtension("png");
            filter.setDescription("Images");
            
            chooser.setFileFilter(filter);
            chooser.setMultiSelectionEnabled(false);
            chooser.setDialogTitle("Add Image");

            //// 1. Open up the dialog.
            int returnVal = chooser.showOpenDialog(this);

            //// 2. If the user clicks Open...
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                try {
                    imageName = chooser.getSelectedFile().getAbsolutePath();
                    DenimSheet.createImage(imageName);
                    imageName = new File(imageName).getName();
                    imageRect = null;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            
            if(deviceRect==null)
            {
                deviceRect = new Rectangle2D.Double();
                double xratio = (this.getWidth()-xgap*2)/Double.parseDouble(mPageWidth.getText());
                double yratio = (this.getHeight()-ygap*2)/Double.parseDouble(mPageHeight.getText());
                
                double ratio = xratio>yratio?yratio:xratio;
                
                double w = ratio*Double.parseDouble(mPageWidth.getText());
                double h = ratio*Double.parseDouble(mPageHeight.getText());
                
                deviceRect.setFrame((this.getWidth()-w)/2,
                        (this.getHeight()-h)/2,
                        w, h);
                
            }
            
            Graphics2D g2d = (Graphics2D)g;
            g2d.setColor(Color.black);
            g2d.drawString("Click on the page thumbnail to add or replace a background image", 10, 10);
            
            g2d.setColor(Color.white);
            g2d.fill(deviceRect);
            g2d.setColor(Color.black);
            g2d.draw(deviceRect);
            
            if(imageName!=null)
            {
                BufferedImage image = DenimSheet.getImage(imageName);
                
                if(imageRect==null)
                {
                    imageRect = new Rectangle2D.Double();
                    
                    if(normalizedImageRect!=null)
                    {
                        imageRect.setFrame(
                                deviceRect.getMinX() + deviceRect.getWidth()*normalizedImageRect.getX(), 
                                deviceRect.getMinY() + deviceRect.getHeight()*normalizedImageRect.getY(), 
                                deviceRect.getWidth()*normalizedImageRect.getWidth(), 
                                deviceRect.getHeight()*normalizedImageRect.getHeight());
                    }
                    else
                    {
                        double xratio = deviceRect.getWidth()/image.getWidth();
                        double yratio = deviceRect.getHeight()/image.getHeight();
                        
                        double ratio = xratio>yratio?yratio:xratio;
                        
                        double w = ratio*image.getWidth();
                        double h = ratio*image.getHeight();
                        
                        imageRect.setFrame(
                                deviceRect.getMinX()+(deviceRect.getWidth()-w)/2,
                                deviceRect.getMinY()+(deviceRect.getHeight()-h)/2,
                                w, h);
                    }
                }
                
                //System.err.println(imageRect.toString());
                
                g2d.drawImage(image, 
                        (int)imageRect.getMinX(),
                        (int)imageRect.getMinY(),
                        (int)imageRect.getWidth(),
                        (int)imageRect.getHeight(),
                        null);
                
                this.renderSelected(g2d);
            }
        }
        
        public void renderSelected(Graphics2D g2d) {
            Rectangle2D rect = new Rectangle2D.Double();
            Rectangle2D range = imageRect;//(Rectangle2D)new Rectangle2D.Double(0,0,this.getWidth(),this.getHeight());
            
            g2d.setStroke(new BasicStroke(1));
            g2d.setColor(Color.lightGray);
            g2d.draw(range);
            
            g2d.setColor(selectorColor);
           
            //topleft
            rect.setRect(
                    range.getMinX()-selectorsize/2, range.getMinY()-selectorsize/2,
                    selectorsize, selectorsize);
            g2d.fill(rect);
            
            //topmiddle
            rect.setRect(
                    range.getCenterX()-selectorsize/2, range.getMinY()-selectorsize/2,
                    selectorsize, selectorsize);
            g2d.fill(rect);
            
            //topright
            rect.setRect(
                    range.getMaxX()-selectorsize/2, range.getMinY()-selectorsize/2,
                    selectorsize, selectorsize);
            g2d.fill(rect);
            
            //left
            rect.setRect(
                    range.getMinX()-selectorsize/2, range.getCenterY()-selectorsize/2,
                    selectorsize, selectorsize);
            g2d.fill(rect);
            
            //right
            rect.setRect(
                    range.getMaxX()-selectorsize/2, range.getCenterY()-selectorsize/2,
                    selectorsize, selectorsize);
            g2d.fill(rect);
            
            //bottomleft
            rect.setRect(
                    range.getMinX()-selectorsize/2, range.getMaxY()-selectorsize/2,
                    selectorsize, selectorsize);
            g2d.fill(rect);
            
            //bottommiddle
            rect.setRect(
                    range.getCenterX()-selectorsize/2, range.getMaxY()-selectorsize/2,
                    selectorsize, selectorsize);
            g2d.fill(rect);
            
            //bottomright
            rect.setRect(
                    range.getMaxX()-selectorsize/2, range.getMaxY()-selectorsize/2,
                    selectorsize, selectorsize);
            g2d.fill(rect);
        }
    }
	
	public DenimOptions(DenimWindow win, Dimension size, boolean autosave, long interval, boolean isGrid, double hgap, double vgap) {
		super(win, "Options", true);
		
		mWin = win;
		mVGap = vgap;
		mHGap = hgap;
		
		this.setResizable(true);
		double w = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double h = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setBounds((int)((w-width)/2), (int)((h-height)/2),
							width, height);
		this.mIsGrid = isGrid;
									
		mPageSize = (Dimension)size.clone();
		mAutosave = autosave;
		mInterval = (long)((double)interval/60000f);
		JTabbedPane pane = new JTabbedPane(JTabbedPane.TOP);
		this.getContentPane().add(pane, BorderLayout.CENTER);
		pane.addTab("Default Page Size & Background", new PageSize());
		pane.addTab("Auto Save", new Save());
		pane.addTab("Grid", new Grid());
        pane.addTab("Fonts", new Fonts());
        
		JButton ok = new JButton("OK");
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				int w = Integer.parseInt(mPageWidth.getText().trim());
				int h = Integer.parseInt(mPageHeight.getText().trim()); 
				int minutes = Integer.parseInt(mMinutes.getText().trim());
				DenimSketch.setDefaultSketchWidth(w);
				DenimSketch.setDefaultSketchHeight(h);
				AutoSaver.autoSaveInterval = minutes*60000;
				AutoSaver.isAutoSaveEnabled = isAutoSave.isSelected();
                
                TextInsertDialog.globalfont1 = (String)DenimOptions.this.fonttype1.getSelectedItem();
                TextInsertDialog.globalfont2 = (String)DenimOptions.this.fonttype2.getSelectedItem();
                TextInsertDialog.globalfont3 = (String)DenimOptions.this.fonttype3.getSelectedItem();
                
				DenimSheet sheet = mWin.getDenimUI().getSheet();
                sheet.backgroundName = imageName;
                
                if(sheet.backgroundName!=null)
                {
                    double r = imageRect.getMinX() - deviceRect.getMinX();
                    
                    if(r<0)
                        r = 0;
                    sheet.imageX = r/deviceRect.getWidth();
    
                    r = imageRect.getMinY() - deviceRect.getMinY();
                    if(r<0)
                        r = 0;
                    sheet.imageY = r/deviceRect.getHeight();
    
                    r = imageRect.getWidth()/deviceRect.getWidth();
                    if(r>1)
                        r = 1;
                    sheet.imageW = r;
    
                    r = imageRect.getHeight()/deviceRect.getHeight();
                    if(r>1)
                        r = 1;
                    sheet.imageH = r;
                }
                
				DenimSketch.setGridOn(isGridOn.isSelected());
				mVGap = Double.parseDouble(vGap.getText().trim());
				mHGap = Double.parseDouble(hGap.getText().trim()); 
				DenimSketch.setGrid(mVGap, mHGap);
				sheet.damage(DAMAGE_NOW);
				DenimOptions.this.setVisible(false);
				DenimOptions.this.dispose();
				
			}
		});

		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				DenimOptions.this.setVisible(false);
				DenimOptions.this.dispose();
			}
		});
		
		JPanel btns = new JPanel();
		this.getContentPane().add(btns, BorderLayout.SOUTH);
		btns.add(ok);
		btns.add(cancel);
        
        DenimSheet sheet = mWin.getDenimUI().getSheet();
        imageName = sheet.backgroundName;
        
        if(imageName!=null)
        {
            normalizedImageRect = new Rectangle2D.Double(
                sheet.imageX, sheet.imageY,
                sheet.imageW, sheet.imageH);
        }
	}
}


//==============================================================================

/*
Copyright (c) 2003 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User 
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/