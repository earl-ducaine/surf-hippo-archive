//// See bottom of source code for software license.
package edu.berkeley.guir.lib.collection;

import java.awt.geom.Point2D;
import java.io.StringWriter;
import java.io.PrintWriter;

/**
 * An ObjectPool is a way of reusing objects, in order to avoid garbage
 * collection. Essentially, the ObjectPool gives you an instance of the class
 * you need when requested. When you are done, just notify the ObjectPool that
 * you are no longer using this object, and it will be returned to the
 * ObjectPool.
 *
 * <P>
 * This implementation is not thread-safe. Use 
 * {@link #synchronizedObjectPool(ObjectPool)} for this purpose.
 * instead.
 *
 * <P>
 * To use this ObjectPool implementation, you just need to subclass and
 * override the {@link #createObject()} method to create an empty version of
 * the object you want.
 *
 * <P>
 * <B>Note:</B> I'm having doubts about the effectiveness of using the
 * ObjectPool in newer versions of JDK. I ran some regression tests with and
 * without ObjectPool, and in most of the cases <I>not</I> using ObjectPool
 * actually won. It may be just this implementation, or it might be that
 * HotSpot really is winning out.
 *
 * <P>
 * At any rate, this class is only kept for backwards compatibility
 * purposes. If you really need an Object pool, check out Apache
 * Jakarta's, at <A HREF="http://jakarta.apache.org/commons/pool/">
 * http://jakarta.apache.org/commons/pool/</A>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Apr 09 2002 JIH
 * @deprecated
 */
public abstract class ObjectPool {

   //===========================================================================
   //===   INNER CLASSES   =====================================================

   public static class EmptyException extends RuntimeException {
   } // of inner class

   public static class FullException extends RuntimeException {
   } // of inner class

   //===========================================================================

   class ObjectPoolElement {
      Object   obj       = null;
      boolean  flagAvail = true;
   } // of inner class

   //===========================================================================

   /**
    * If you want to switch back to Java's garbage collection, this version of
    * Object Pool just allocates new objects. Useful for debugging.
    */
   static class AllocatingObjectPool
      extends ObjectPool {

      ObjectPool p;

      //--------------------------------------------------------------

      public AllocatingObjectPool(ObjectPool p) {
         this.p = p;
      } // of constructor

      //--------------------------------------------------------------

      protected Object createObject() {
         return (p.createObject());
      } // of method

      //--------------------------------------------------------------

      public int getAvailable() {
         return (p.getAvailable());
      } // of getAvailable

      //--------------------------------------------------------------

      public int getCapacity() {
         return (p.getCapacity());
      } // of method

      //--------------------------------------------------------------

      /** 
       * Creates a new object instead of getting one from a pool.
       * Useful for if you want to switch back to Java garbage collection
       * without rewriting your code.
       */
      public Object getObject() {
         return (createObject());
      } // of method

      //--------------------------------------------------------------

      /** 
       * Does nothing. 
       */
      public void releaseObject(Object obj) {
      } // of releaseObject

      //--------------------------------------------------------------

      public boolean isTaken(Object obj) {
         return (false);
      } // of method

      //--------------------------------------------------------------

      public boolean isFree(Object obj) {
         return (true);
      } // of method

      //--------------------------------------------------------------

      public void reset() {
      } // of reset

      //--------------------------------------------------------------

      public void reinitialize() {
      } // of reinitialize
   } // of inner class

   //===========================================================================

   /**
    * Synchronized version of Object Pool.
    */
   static class SynchronizedObjectPool 
      extends ObjectPool {

      ObjectPool p;

      //--------------------------------------------------------------

      public SynchronizedObjectPool(ObjectPool p) {
         this.p = p;
      } // of constructor

      //--------------------------------------------------------------

      protected synchronized Object createObject() {
         return (p.createObject());
      } // of method

      //--------------------------------------------------------------

      public synchronized int getAvailable() {
         return (p.getAvailable());
      } // of getAvailable

      //--------------------------------------------------------------

      public synchronized int getCapacity() {
         return (p.getCapacity());
      } // of method

      //--------------------------------------------------------------

      public synchronized Object getObject() {
         return (this.getObject());
      } // of getObject

      //--------------------------------------------------------------

      public synchronized void releaseObject(Object obj) {
         p.releaseObject(obj);
      } // of releaseObject

      //--------------------------------------------------------------

      public synchronized boolean isTaken(Object obj) {
         return (p.isTaken(obj));
      } // of method

      //--------------------------------------------------------------

      public synchronized boolean isFree(Object obj) {
         return (p.isFree(obj));
      } // of method

      //--------------------------------------------------------------

      public synchronized void reset() {
         p.reset();
      } // of reset

      //--------------------------------------------------------------

      public synchronized void reinitialize() {
         p.reinitialize();
      } // of reinitialize
   } // of inner class

   //===   INNER CLASSES   =====================================================
   //===========================================================================




   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   ObjectPoolElement[] pool;
   int                 capacity;
   int                 numAvailable;
   int                 lastFreeIndex;

   //// debugging
          String[]      debugStacks;
   static StringWriter  strWtr = new StringWriter(2048);
   static PrintWriter   pWtr   = new PrintWriter(strWtr, true);

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================




   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
    * Creates a pool of objects. 
    */
   public ObjectPool() {
      this(10);
   } // of default constructor

   //-----------------------------------------------------------------

   /**
    * Creates a pool of size <CODE>capacity</CODE> objects.
    */
   public ObjectPool(int newCapacity) {
      this.capacity      = newCapacity;
      this.pool          = new ObjectPoolElement[newCapacity];
      this.numAvailable  = newCapacity;
      this.lastFreeIndex = 0;
      reinitialize();
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   UTILITY METHODS   ===================================================

   /**
    * Get a synchronized object pool.
    */
   public static ObjectPool synchronizedObjectPool(ObjectPool p) {
      return (new SynchronizedObjectPool(p));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get an object pool that isn't really an object pool, but allocates
    * new objects. Useful for debugging purposes.
    */
   public static ObjectPool allocatingObjectPool(ObjectPool p) {
      return (new AllocatingObjectPool(p));
   } // of method

   //-----------------------------------------------------------------

   /**
    * Print what method requested what object from the pool.
    * Must compile with debug flag in order for this to work.
    */
   public void printDebugStacks() {
       // xxx deleted
   } // of method

   //===   UTILITY METHODS   ===================================================
   //===========================================================================




   //===========================================================================
   //===   POOL METHODS   ======================================================

   /**
    * Override this method so that it creates the Object you want in the pool.
    */
   protected abstract Object createObject();

   //-----------------------------------------------------------------

   /**
    * Get the number of available objects.
    */
   public int getAvailable() {
      return (numAvailable);
   } // of getAvailable

   //-----------------------------------------------------------------

   /**
    * Get the total capacity of the pool.
    */
   public int getCapacity() {
      return (capacity);
   } // of getCapacity

   //-----------------------------------------------------------------

   /**
    * Get an object. 
    * <P>
    * Usage Notes:
    * <UL>
    *    <LI>It is generally a good idea to override this method
    *        and to re-initialize the object before returning it.
    * </UL>
    * <P>
    * Also, be sure not to assign the reference that you get!!!
    * If you do, then you cannot release the object (and will get
    * memory leaks).
    *
    * @throws EmptyException (a RuntimeException) if empty.
    */
   public Object getObject() 
      throws EmptyException {

      //// 1. Check if any objects available.
      if (numAvailable <= 0) {
         printDebugStacks();
         reset();
         throw new EmptyException();
      }

      //// 2. At this point, there must be a free object.
      ////    Just mark it as taken. 
      ////
      ////    This is about as fast as I can get it.
      boolean flagFound = false;
      int     i;

      for (i = lastFreeIndex; i < pool.length && !flagFound; i++) {
         if (pool[i].flagAvail == true) {
            flagFound = true;
            break;
         }
      }
      if (flagFound == false) {
         for (i = 0; i < lastFreeIndex && !flagFound; i++) {
            if (pool[i].flagAvail == true) {
               flagFound = true;
               break;
            }
         }
      }

      //// 3. If we have found one, then get and return it.
      if (flagFound == true) {
         pool[i].flagAvail = false;
         numAvailable--;
         lastFreeIndex = (i + 1) % pool.length;

         return (pool[i].obj);
      }

      return (null);
   } // of getObject

   //-----------------------------------------------------------------

   /**
    * Mark this object as released. If this object does not belong to the pool,
    * then ignore.
    * <P>
    * Override this method to clear out the object's values first, if you want.
    * Be sure to call super correctly. For example, if you have an Object Pool
    * of LinkedList objects, then in your subclass:
    *
    * <CODE>
    * public void releaseObject(Object obj) {
    *    LinkedList list = (LinkedList) obj;
    *    list.clear();
    *    super.releaseObject(obj);
    * } // of releaseObject
    * </CODE>
    *
    * @param  obj is the Object to release back into the pool.
    * @throws RuntimeException if we don't own the object. Useful for
    *         detecting errors.
    */
   public void releaseObject(Object obj) {
      //// 1.1. Go through each element until we find the corresponding
      ////      object in the pool.
      int index = getIndex(obj);
      if (index >= 0) {
         pool[index].flagAvail = true;
         numAvailable++;
      }
      //// 1.2. Error, an object was not released.
      else {
         if (obj != null) {
            System.err.println(obj);
            System.err.println(
                 new RuntimeException("Object Pool does not own this object."));
            System.err.println("HashCode:"  + obj.hashCode());
            System.err.println(this.toString());
            throw new RuntimeException("Object Pool does not own this object.");
         }
      }
   } // of releaseObject

   //-----------------------------------------------------------------

   /**
    * Get the index in the pool of this object.
    *
    * @return the index, or -1 if it does not exist.
    */
   private final int getIndex(Object obj) {
      //// This is about as fast as I can get it.

      for (int i = lastFreeIndex - 1; i >= 0; i--) {
         if (pool[i].obj == obj) {
            return (i);
         }
      }
      for (int i = pool.length - 1; i >= lastFreeIndex; i--) {
         if (pool[i].obj == obj) {
            return (i);
         }
      }
      return (-1);
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if an object is taken.
    *
    * @return true if the object is taken, false if not or if it does not
    *         belong to this pool.
    */
   public boolean isTaken(Object obj) {
      int index = getIndex(obj);
      if (index >= 0) {
         return (pool[index].flagAvail == false);
      }
      return (false);
   } // of method

   //-----------------------------------------------------------------

   /**
    * See if an object is free.
    *
    * @return true if the object is free, false if not or if it does not
    *         belong to this pool.
    */
   public boolean isFree(Object obj) {
      int index = getIndex(obj);
      if (index >= 0) {
         return (pool[index].flagAvail == true);
      }
      return (false);
   } // of method

   //-----------------------------------------------------------------

   public boolean ownsObject(Object obj) {
      return (getIndex(obj) >= 0);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Reset each element in the pool as available.
    */
   public void reset() {
      for (int i = 0; i < pool.length; i++) {
         pool[i].flagAvail = true;
      }
      this.lastFreeIndex = 0;
      this.numAvailable  = pool.length;
   } // of reset

   //-----------------------------------------------------------------

   /**
    * Clear out all of the objects in the pool and create new ones.
    */
   public void reinitialize() {
      //// 1. Clear out the debug stack.
      // deleted

      //// 2. Create the objects in the pool.
      for (int i = 0; i < capacity; i++) {
         pool[i]           = new ObjectPoolElement();
         pool[i].obj       = createObject();
         pool[i].flagAvail = true;
      }
      this.lastFreeIndex = 0;
      this.numAvailable  = pool.length;
   } // of reinitialize

   //===   POOL METHODS   ======================================================
   //===========================================================================




   //===========================================================================
   //===   TOSTRING   ==========================================================

   public String toString() {
      StringBuffer strbuf = new StringBuffer();

      strbuf.append(  "Capacity:  " + getCapacity());
      strbuf.append("\nAvailable: [");
      for (int i = 0; i < pool.length; i++) {
         if (pool[i].flagAvail == true) {
            strbuf.append(pool[i].obj.hashCode() + ", ");
         }
      }
      strbuf.append("]");


      strbuf.append("\nTaken:     [");
      for (int i = 0; i < pool.length; i++) {
         if (pool[i].flagAvail == false) {
            strbuf.append(pool[i].obj.hashCode() + ", ");
         }
      }
      strbuf.append("]");

      return (strbuf.toString());
   } // of method

   //===   TOSTRING   ==========================================================
   //===========================================================================




   //===========================================================================
   //===   SELF TESTING MAIN   =================================================

   static int size       = 30;
   static int iterations = 1000000;

   static final class UniquePoint2D extends Point2D.Float {
      static int counter = 0;
             int val     = counter++;
      public int hashCode() {
         return (val);
      } // of method
   } // of inner class

   static final class ObjectPoolPoint2D extends ObjectPool {
      public ObjectPoolPoint2D() {
         super(size);
      } // of constructor

      public Object createObject() {
         return (new UniquePoint2D());
      } // of method

      public Object getObject() {
         Point2D pt = (Point2D) super.getObject();
         pt.setLocation(0, 0);
         return (pt);
      } // of method
   } // of inner class

   public static void main(String[] argv) {
      long       start    = 0;
      long       end      = 0;
      long       g_start  = 0;
      long       g_end    = 0;
      long       g_sum    = 0;
      long       r_start  = 0;
      long       r_end    = 0;
      long       r_sum    = 0;
      Object     obj;
      ObjectPool pool = new ObjectPoolPoint2D();

      for (int i = 0; i < iterations; i++) {
         g_start = System.currentTimeMillis();
         obj = pool.getObject();
         g_end   = System.currentTimeMillis();

         r_start = System.currentTimeMillis();
         pool.releaseObject(obj);
         r_end   = System.currentTimeMillis();

         g_sum += (g_end - g_start);
         r_sum += (r_end - r_start);
      }

      System.out.println(pool);

      System.out.println();
      System.out.println("obj pool");
      System.out.println("total time:     " + (g_sum + r_sum));
      System.out.println("unit time:      " + ((double) (g_sum + r_sum) / iterations));
      System.out.println("get time:       " + g_sum);
      System.out.println("get unit time:  " + ((double) g_sum / iterations));
      System.out.println("rel time:       " + r_sum);
      System.out.println("rel unit time:  " + ((double) r_sum / iterations));

      System.gc();
      start = System.currentTimeMillis();
      for (int i = 0; i < iterations; i++) {
         obj = pool.createObject();
      }
      System.gc();
      end = System.currentTimeMillis();

      System.out.println();
      System.out.println("create new");
      System.out.println("total time: " + (end - start));
      System.out.println("unit time:  " + ((double)(end - start) / iterations));
   } // of method

   //===   SELF TESTING MAIN   =================================================
   //===========================================================================

} // of class ObjectPool

//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
