package edu.berkeley.guir.lib.satin.objects;

import java.awt.*;
import java.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.satin.graphics.*;

/**
 * A wrapper for graphical objects to make them sticky. Experimental, as an
 * alternative to sticky views.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v2.1-1.0.0, Aug 24 2000, JH
 *               Created
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.3
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public abstract class StickyGraphicalObjectWrapper
   extends GraphicalObjectWrapper {

   //===========================================================================
   //===   CONSTANTS   =========================================================


   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   AffineTransform txSticky      = new AffineTransform(); // to make us sticky
   boolean         flagUseSticky = true;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTOR   =======================================================

   /**
    * Create an empty proxy.
    */
   public StickyGraphicalObjectWrapper() {
      id = GraphicalObjectLib.getUniqueID();
   } // of method

   /**
    * Create a proxy pointing to the specified Graphical Object.
    */
   public StickyGraphicalObjectWrapper(GraphicalObject gob) {
      this();
      setGraphicalObject(gob);
   } // of method

   //===   CONSTRUCTOR   =======================================================
   //===========================================================================



   //===========================================================================
   //===   TRANSFORM METHODS   =================================================

   /**
    *
    */
   public void applyTransform(AffineTransform newTx) {
      //// A. Acquire soft state.
      AffineTransform txTmp = (AffineTransform) poolTx.getObject();

      //// 1. Update the sticky transform.
      updateStickyTransform();

      //// 2. Calculate the passthrough.
      GeomLib.calcPassthrough(newTx, txSticky, txTmp);
      gob.applyTransform(txTmp);

      //// B. Release.
      poolTx.releaseObject(txTmp);
   } // of method


   /**
    * 
    */
   public void setTransform(AffineTransform newTx) {
      //// A. Acquire soft state.
      AffineTransform txTmp = (AffineTransform) poolTx.getObject();

      //// 1. Update the sticky transform.
      updateStickyTransform();

      //// 2. Calculate the passthrough.
      GeomLib.calcPassthrough(newTx, txSticky, txTmp);
      gob.setTransform(txTmp);

      //// B. Release.
      poolTx.releaseObject(txTmp);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Does not return a reference, b/c it doesn't make sense 
    * in the sticky case.
    */
   public AffineTransform getTransformRef() {
      return (getTransform(COORD_REL));
   } // of method


   /**
    * Concatenates the sticky and the proxied transforms.
    */
   public AffineTransform getTransform(int cdsys) {
      return (getTransform(cdsys, null));
   } // of method


   /**
    * Concatenates the sticky and the proxied transforms.
    */
   public AffineTransform getTransform(int cdsys, AffineTransform outTx) {
      updateStickyTransform();

      if (outTx == null) {
         outTx = new AffineTransform();
      }

      switch (cdsys) {
         case COORD_LOCAL:
            outTx.setToIdentity();
            break;

         case COORD_REL:
            outTx.setTransform(txSticky);
            outTx.concatenate(gob.getTransformRef());
            break;

         case COORD_ABS:
            outTx.setTransform(txSticky);
            outTx.concatenate(gob.getTransformRef());
            GraphicalObject gob = this;

            //// 1. Use preConcatenate() for optimization purposes, since
            ////    we don't want to make copies of transforms unnecessarily.
            ////    Just be sure to evaluate from left-to-right.
            while ((gob = gob.getParentGroup()) != null) {
               outTx.preConcatenate(gob.getTransformRef());
            }

            break;

         default:
            throw new RuntimeException("Invalid coordinate system value");
      }

      return (outTx);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Concatenates the sticky and the proxied transforms.
    */
   public AffineTransform getInverseTransform(int cdsys) {
      return (getInverseTransform(cdsys, null));
   } // of method


   /**
    * Concatenates the sticky and the proxied transforms.
    */
   public AffineTransform getInverseTransform(int cdsys, 
                                              AffineTransform outTx) {
      //// 1. Allocate storage if necessary.
      if (outTx == null) {
         outTx = new AffineTransform();
      }

      //// 2. Get the transform and invert it.
      outTx = getTransform(cdsys, outTx);
      try {
         outTx.setTransform(outTx.createInverse());
      }
      catch (Exception e) {
         Debug.println("This should never really happen");
      }

      //// 3. Return the transform.
      return (outTx);
   } // of method

   //===   TRANSFORM METHODS   =================================================
   //===========================================================================



   //===========================================================================
   //===   VIEW ACCESSOR METHODS   =============================================

   /**
    * Get the sticky location.
    */
   public Point2D getLocation2D(int cdsys) {
      return (getLocation2D(cdsys, null, null));
   } // of method


   /**
    * Get the sticky location.
    */
   public Point2D getLocation2D(int cdsys, AffineTransform tx, Point2D pt) {
      //// Implementation Note:
      ////    This code is duplicated at GraphicalObjectImpl.java
      ////    Changes to this code should be mirrored there.
      ////    Yes I know that copying and pasting code is bad, but that's 
      ////    what you get when you don't have multiple inheritance.

      //// A. Acquire soft-state objects.
      Rectangle2D tmpRect = (Rectangle2D) poolRects.getObject();

      //// 1. Get an updated copy of the bounds (transformed).
      tmpRect = getBounds2D(cdsys, tx, tmpRect);

      //// 2. Create storage if none was specified.
      if (pt == null) {
         pt = new Point2D.Float();
      }

      //// 3. Transform.
      if (tx != null) {
         tx.transform(pt, pt);
      }

      //// 4. Update the point location and return it.
      pt.setLocation(tmpRect.getX(), tmpRect.getY());

      //// B. Release soft-state objects.
      poolRects.releaseObject(tmpRect);

      return (pt);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the sticky bounds.
    */
   public Rectangle2D getBounds2D(int cdsys) {
      return (getBounds2D(cdsys, null, null));
   } // of method


   /**
    * Get the sticky bounds.
    */
   public Rectangle2D getBounds2D(int cdsys, AffineTransform tx, 
                                  Rectangle2D rect) {
      //// Implementation Note:
      ////    This code is duplicated at GraphicalObjectImpl.java
      ////    Changes to this code should be mirrored there.
      ////    Yes I know that copying and pasting code is bad, but that's 
      ////    what you get when you don't have multiple inheritance.

      //// A. Acquire soft-state objects.
      Polygon2D tmpPoly = (Polygon2D) poolPolys.getObject();

      //// 1. Get an updated copy of the bounding points (transformed).
      tmpPoly = getBoundingPoints2D(cdsys, tx, tmpPoly);

      //// 2. Create storage if none was specified.
      if (rect == null) {
         rect = new Rectangle2D.Float();
      }

      //// 3. Transform.
      if (tx != null) {
         tmpPoly.transform(tx);
      }

      //// 4. Update the rectangle and return it.
      rect.setRect(tmpPoly.getBounds2D());

      //// B. Release soft-state objects.
      poolPolys.releaseObject(tmpPoly);

      return (rect);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the sticky bounding points.
    */
   public Polygon2D getBoundingPoints2D(int cdsys) {
      return (getBoundingPoints2D(cdsys, null, null));
   } // of method


   /**
    * Get the sticky bounding points.
    */
   public Polygon2D getBoundingPoints2D(int cdsys, AffineTransform tx, 
                                        Polygon2D poly) {
      //// A. Acquire soft state.
      AffineTransform txTmp = (AffineTransform) poolTx.getObject();

      //// 1. Create storage if none was specified.
      if (poly == null) {
         poly = new Polygon2D();
      }

      //// 2. 
      gob.getBoundingPoints2D(cdsys, null, poly);

      switch (cdsys) {
         case COORD_LOCAL:
            txTmp = txSticky;
            poly.transform(txTmp);
            break;

         case COORD_REL:
         case COORD_ABS:
            getTransform(cdsys, txTmp);
            poly.transform(txTmp);
            break;

         default:
            throw new RuntimeException("Invalid coordinate system value");
      }

      //// 2. Apply the transform.
      if (tx != null) {
         poly.transform(tx);
      }

      //// B. Release.
      poolTx.releaseObject(txTmp);

      //// 3. Return the polygon.
      return (poly);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the sticky width.
    */
   public float getWidth2D(int cdsys) {
      return (float) (getBounds2D(cdsys)).getWidth();
   } // of method


   /**
    * Get the sticky height.
    */
   public float getHeight2D(int cdsys) {
      return (float) (getBounds2D(cdsys)).getHeight();
   } // of method

   //===   VIEW ACCESSOR METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   VIEW MODIFIER METHODS   =============================================

// XXX

   /**
    * Moves to the specified (x,y) location in the sticky space.
    */
   public void moveTo(int cdsys, double x, double y) {
      //// 1. Update the sticky transform.
      updateStickyTransform();

      gob.moveTo(cdsys, x, y);
   } // of method

   /**
    * Moves to the specified (x,y) location in the sticky space.
    */
   public void moveTo(int cdsys, Point2D pt) {
      //// 1. Update the sticky transform.
      updateStickyTransform();

      gob.moveTo(cdsys, pt);
   } // of method

   /**
    * Moves by the specified (x,y) offset in the sticky space.
    */
   public void moveBy(int cdsys, double dx, double dy) {
      //// 1. Update the sticky transform.
      updateStickyTransform();

      gob.moveBy(cdsys, dx, dy);
   } // of method

   /**
    * Moves by the specified (x,y) offset in the sticky space.
    */
   public void moveBy(int cdsys, Point2D pt) {
      //// 1. Update the sticky transform.
      updateStickyTransform();

      gob.moveBy(cdsys, pt);
   } // of method

   /**
    * Sets to the specified shape in the sticky space.
    */
   public void setBoundingPoints2D(int cdsys, Shape s) {
      //// 1. Update the sticky transform.
      updateStickyTransform();

      gob.setBoundingPoints2D(cdsys, s);
   } // of method


   /**
    * Render the Graphical Object after applying the sticky transform, 
    * as determined by getStickyTransform.
    */
   public void render(SatinGraphics g) {
      gob.render(g);
   } // of method

   //===   VIEW MODIFIER METHODS   =============================================
   //===========================================================================



   //===========================================================================
   //===   STICKY METHODS   ====================================================

   private AffineTransform updateStickyTransform() {
      if (flagUseSticky == true) {
         getStickyTransform(txSticky);
      }
      else {
         txSticky.setToIdentity();
      }
      return (txSticky);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Get the transform that makes us sticky.
    *
    * @param tx is the storage space.
    */
   protected abstract AffineTransform getStickyTransform(AffineTransform tx);

   //-----------------------------------------------------------------

   /**
    * Get the transform as if this object weren't around.
    */
   protected AffineTransform getUnstickyTransform(int cdsys, 
                                                  AffineTransform tx) {
      //// 1. Temporarily ignore sticky.
      flagUseSticky = false;

      //// 2. Get the transform.
      getTransform(cdsys, tx);

      //// 3. Use sticky again.
      flagUseSticky = true;

      //// 4. Return.
      return (tx);
   } // of method

   //===   STICKY METHODS   ====================================================
   //===========================================================================



   //===========================================================================
   //===   CLONE METHODS   =====================================================

   /**
    * Done on proxy, not on proxied object.
    */
   protected StickyGraphicalObjectWrapper 
   clone(StickyGraphicalObjectWrapper c) {
      //// 1. We only have soft state, so just forward up.
      super.clone(c);
      return (c);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Done on proxy, not on proxied object.
    */
   protected StickyGraphicalObjectWrapper
   deepClone(StickyGraphicalObjectWrapper c) {
      //// 1. We only have soft state, so just forward up.
      super.deepClone(c);
      return (c);
   } // of method

   //===   CLONE METHODS   =====================================================
   //===========================================================================

} // of interface 

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES { LOSS OF USE, DATA, OR PROFITS { OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
