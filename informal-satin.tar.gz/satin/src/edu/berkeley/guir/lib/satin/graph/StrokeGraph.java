//// See bottom of file for software license

package edu.berkeley.guir.lib.satin.graph;

import java.awt.geom.*;
import java.util.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.stroke.*;

/**
 * A graph (or subgraph) of segmented strokes.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - lycra-v0.1/1.0.0, Mar 28 2002, JH
 *               Created 
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.4
 * @version lycra-v0.1/1.0.0, Mar 28 2002
 */
public class StrokeGraph {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    List        listStrokes     = new LinkedList();  // list of TimedStrokes
    List        listConnections = new LinkedList();  // list of Connections

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================




    //==========================================================================
    //===   CONSTRUCTOR   ======================================================

    /**
     * Does nothing special.
     */
    public StrokeGraph() {
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Copy constructor.
     *
     * @param g is the graph to copy into this new instance.
     */
    public StrokeGraph(StrokeGraph g) {
        //// 1. First, iterate over the list of Strokes, creating
        ////    new TimedStrokes. Required because we want a deep copy,
        ////    not a shallow copy.
        ////
        ////    At the same time, create a mapping between the old stroke
        ////    and the new one, for when we create the connections.
        ////
        Map         mapStrokes = new HashMap();   // (old stk) -> (new stk)
        Iterator    it;
        TimedStroke stkOld;
        TimedStroke stkNew;

        it = g.listStrokes.iterator();
        while (it.hasNext()) {
            stkOld = (TimedStroke) it.next();
            stkNew = new TimedStroke(stkOld);
            mapStrokes.put(stkOld, stkNew);
            addStroke(stkNew);
        }

        //// 2. Now recreate the connections.
        Connection  connOld;     // the original connection in graph g
        Connection  connNew;     // new cloned connection
        TimedStroke stkAAOld;
        TimedStroke stkBBOld;
        TimedStroke stkAANew;
        TimedStroke stkBBNew;

        it = g.listConnections.iterator();
        while (it.hasNext()) {
            connOld  = (Connection) it.next();
            stkAAOld = connOld.getStrokeAA();
            stkBBOld = connOld.getStrokeBB();

            stkAANew = (TimedStroke) mapStrokes.get(stkAAOld);
            stkBBNew = (TimedStroke) mapStrokes.get(stkBBOld);

            assert stkAANew != null;
            assert stkBBNew != null;

            connNew  = new Connection(stkAANew, stkBBNew);
            addConnection(connNew);
        }

    } // of constructor

    //===   CONSTRUCTOR   ======================================================
    //==========================================================================




    //==========================================================================
    //===   GRAPH OPERATIONS    ================================================

    /**
     * Get the bounding box of the strokes in this graph.
     * O(n) operation, goes through all strokes.
     */
    public Rectangle2D getBounds2D() {
        Iterator    it     = strokes();
        Rectangle2D gbds   = null;
        Rectangle2D newbds = null;
        TimedStroke stk;

        while (it.hasNext()) {
            stk    = (TimedStroke) it.next();
            newbds = stk.getBounds2D(SatinConstants.COORD_REL);

            if (gbds == null) {
                gbds = newbds;
            }
            else {
                Rectangle2D.union(gbds, newbds, gbds);
            }
        }

        return (gbds);
    } // of method

    //===   GRAPH OPERATIONS    ================================================
    //==========================================================================




    //==========================================================================
    //===   GRAPH OPERATIONS    ================================================

    /**
     * Add the reference.
     */
    public void addStroke(TimedStroke stk) {
       Rectangle2D newbds = stk.getBounds2D(SatinConstants.COORD_REL);
       listStrokes.add(stk);
    } // of method

    //----------------------------------------------------------------

    public void addConnection(TimedStroke stkAA, TimedStroke stkBB) {
       listConnections.add(new Connection(stkAA, stkBB));
    } // of method

    public void addConnection(Connection conn) {
       listConnections.add(conn);
    } // of method

    //===   GRAPH OPERATIONS    ================================================
    //==========================================================================




    //==========================================================================
    //===   COLLECTION OPERATIONS   ============================================

    /**
     * Get an iterator over the strokes.
     *
     * @return an Iterator of TimedStroke objects.
     */
    public Iterator strokes() {
       return (listStrokes.iterator());
    } // of method

    //----------------------------------------------------------------

    /**
     * Get an iterator over the connections.
     * 
     * @return an Iterator of Connection objects.
     */
    public Iterator connections() {
       return (listConnections.iterator());
    } // of method

    //===   COLLECTION OPERATIONS   ============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2002 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
