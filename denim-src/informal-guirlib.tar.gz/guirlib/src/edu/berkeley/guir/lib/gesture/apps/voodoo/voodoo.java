package edu.berkeley.guir.lib.gesture.apps.voodoo;

import edu.berkeley.guir.lib.gesture.*;
import java.lang.System;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Font;
import java.awt.Color;
import java.io.File;

/**
 * Show gestures and color parts of them straight or curvy.  The
 * purpose is to choose the right voodoo constants for straightness or
 * curviness.
 */
public class voodoo {
  public static void main(String argv[])
  {
    setDefaults();
    GestureSetFrame frame;

    boolean experiment = false;
    
    int i;
    for (i = 0; (i < argv.length) && (argv[i].charAt(i) == '-'); i++) {
      if (argv[i].equals("-e")) {
	experiment = true;
      }
      else {
	System.err.println("voodoo: Unknown option: " + argv[i]);
	System.err.println("voodoo: usage: voodoo [-e] [gesturefile]");
      }
    }

    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    };

    GestureDisplay.setPointsDisplayClass(VGesturePointsDisplay.class);
    frame = new GestureSetFrame("voodoo", experiment);
    frame.addWindowListener(l);
    // Guess that the current user is the author
    frame.setAuthor(System.getProperty("user.name"));

    if (i < argv.length) {
      frame.openFile(new File(argv[i]));
    }

    frame.pack();
    frame.setDividerLocation(0.8);
    frame.show();

    VFrame vframe = new VFrame();
    vframe.show();
  }

  static void setDefaults()
  {
    Font bigFont = new Font("Serif", Font.PLAIN, 18);
    Font smallFont = new Font("Serif", Font.PLAIN, 14);
    UIManager.put("Label.font", bigFont);
    // I don't know why I need to set the foreground color of labels.
    // You'd think that they would be black by default, but under
    // Swing 1.0.3 they're lavendar.
    UIManager.put("TitledBorder.titleColor", Color.black);
    UIManager.put("Label.foreground", Color.black);
    UIManager.put("MenuItem.font", bigFont);
    UIManager.put("Menu.font", bigFont);
    UIManager.put("Button.font", bigFont);
    UIManager.put("ToggleButton.font", bigFont);
    UIManager.put("TextPane.font", bigFont);
  }
}
