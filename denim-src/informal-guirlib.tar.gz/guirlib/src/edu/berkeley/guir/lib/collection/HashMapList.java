//// See bottom of file for software license
package edu.berkeley.guir.lib.collection;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * A Map that, for each key, contains a List of objects.
 * <P>
 * Example usage:
 * <PRE>
 *      HashMapList m = new HashMapList();
 *      m.put("A", "Alphabet");
 *      m.put("A", "Antwerp");
 *      m.put("A", "Aardvark");
 *      m.put("B", "Beach");
 *      m.put("B", "Bust");
 *      m.put("C", "Cookie");
 *
 *      System.out.println("--- Test 0 - starting HashMapList");
 *      System.out.println(m);
 *
 *      System.out.println("--- Test 1 - add 'D', 'Dog'");
 *      m.put("D", "Dog");
 *      System.out.println(m);
 *
 *      System.out.println();
 *      System.out.println("--- Test 2 - remove 'A'");
 *      m.removeKey("A");
 *      System.out.println(m);
 *
 *      System.out.println();
 *      System.out.println("--- Test 3 - remove again (should be no effect)");
 *      m.removeKey("A");
 *      System.out.println(m);
 *
 *      System.out.println();
 *      System.out.println("--- Test 4 - get (returns a List)");
 *      System.out.println(m.get("D"));
 *
 *      System.out.println();
 *      System.out.println("--- Test 5 - add 'F', 'Fox'");
 *      m.put("F", "Fox");
 *      System.out.println(m);
 *
 *      System.out.println();
 *      System.out.println("--- Test 6 - add again");
 *      m.put("F", "Fox");
 *      System.out.println(m);
 *
 *      System.out.println();
 *      System.out.println("--- Test 7 - clone");
 *      System.out.println(new HashMapList(m));
 *
 *      System.out.println();
 *      System.out.println("--- Test 8 - clear");
 *      m.clear();
 *      System.out.println(m);
 * </PRE>
 * Here is the output:
 * <PRE>
 *  {A=[Alphabet, Antwerp, Aardvark], C=[Cookie], B=[Beach, Bust]}
 *  --- Test 1 - add 'D', 'Dog'
 *  {D=[Dog], A=[Alphabet, Antwerp, Aardvark], C=[Cookie], B=[Beach, Bust]}
 *
 *  --- Test 2 - remove 'A'
 *  {D=[Dog], C=[Cookie], B=[Beach, Bust]}
 *
 *  --- Test 3 - remove again (should be no effect)
 *  {D=[Dog], C=[Cookie], B=[Beach, Bust]}
 *
 *  --- Test 4 - get (returns a List)
 *  [Dog]
 *
 *  --- Test 5 - add 'F', 'Fox'
 *  {D=[Dog], F=[Fox], C=[Cookie], B=[Beach, Bust]}
 *
 *  --- Test 6 - add again
 *  {D=[Dog], F=[Fox, Fox], C=[Cookie], B=[Beach, Bust]}
 *
 *  --- Test 7 - clone
 *  {D=[Dog], F=[Fox, Fox], C=[Cookie], B=[Beach, Bust]}
 *
 *  --- Test 8 - clear
 *  {}
 * </PRE>
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Jul 31 2002 JIH
 */
public class HashMapList 
    extends HashMapCollection {

    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * Empty constructor.
     */
    public HashMapList() {
    } // of constructor

    //----------------------------------------------------------------

    /**
     * Copy constructor
     */
    public HashMapList(HashMapList m) {
        super(m);
    } // of copy constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================





    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    protected Collection getNewCollectionInstance() {
        return (new LinkedList());
    } // of method

    //----------------------------------------------------------------

    protected Collection getNewCollectionInstance(Collection c) {
        return (new LinkedList(c));
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================





    //==========================================================================
    //===   REGRESSION TESTS   =================================================

    public static HashMapList getTestInstanceAAA() {
        return (new HashMapList());
    } // of method

    //----------------------------------------------------------------

    public static HashMapList getTestInstanceBBB() {
        HashMapList m = new HashMapList();

        m.put("A", "Alphabet");
        m.put("A", "Antwerp");
        m.put("A", "Aardvark");
        m.put("B", "Beach");
        m.put("B", "Bust");
        m.put("C", "Cookie");

        return (m);
    } // of method

    //==========================================================================

    /**
     * Print out a few.
     */
    private static void runTestAAA() {
        System.out.println(getTestInstanceAAA());
        System.out.println("----------");
        System.out.println(getTestInstanceBBB());
        System.out.println("----------");
    } // of method

    //----------------------------------------------------------------

    /**
     * Test simple case.
     */
    private static void runTestBBB() {
        HashMapList m = getTestInstanceBBB();
        System.out.println(m);

        System.out.println("--- Test 1 - add 'D', 'Dog'");
        m.put("D", "Dog");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 2 - remove 'A'");
        m.removeKey("A");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 3 - remove again (should be no effect)");
        m.removeKey("A");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 4 - get (returns a List)");
        System.out.println(m.get("D"));

        System.out.println();
        System.out.println("--- Test 5 - add 'F', 'Fox'");
        m.put("F", "Fox");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 6 - add again");
        m.put("F", "Fox");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 7 - clone");
        System.out.println(new HashMapList(m));

        System.out.println();
        System.out.println("--- Test 8 - clear");
        m.clear();
        System.out.println(m);
    } // of method

    //----------------------------------------------------------------

    private static void runTestCCC() {
        HashMapList m = new HashMapList();
        m.put("A", "Alphabet");
        m.put("A", "Antwerp");
        m.put("A", "Aardvark");
        m.put("B", "Beach");
        m.put("B", "Bust");
        m.put("C", "Cookie");

        System.out.println("--- Test 0 - starting HashMapList");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 1 - add 'D', 'Dog'");
        m.put("D", "Dog");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 2 - remove 'A'");
        m.removeKey("A");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 3 - remove again (should be no effect)");
        m.removeKey("A");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 4 - add 'F', 'Fox'");
        m.put("F", "Fox");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 5 - add again");
        m.put("F", "Fox");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 6 - try to add 'C', 'Cat' to a copy");
        List list = (List) m.get("C");
        list.add("Cat");
        System.out.println(m);

        System.out.println();
        System.out.println("--- Test 7 - clone");
        System.out.println(new HashMapList(m));

        System.out.println();
        System.out.println("--- Test 8 - clear");
        m.clear();
        System.out.println(m);
    } // of method

    //==========================================================================

    public static void main(String[] argv) {
        runTestCCC();
    } // of main

    //===   REGRESSION TESTS   =================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
