package edu.berkeley.guir.damask.view.voice.dialog;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.command.SetPageIndexCommand;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.nodes.DamaskPPath;
import edu.berkeley.guir.damask.view.nodes.DamaskWindow;
import edu.berkeley.guir.damask.view.voice.VoiceCanvas;
import edu.berkeley.guir.damask.view.voice.component.*;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.*;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.util.PBounds;
import edu.umd.cs.piccolo.util.PPaintContext;

/**
 * Represents a form which groups together related prompts and responses.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  07-18-2004 James Lin
 *                               Created.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 */
public class Form extends DamaskWindow {
   private static final Color DEFAULT_TITLE_BAR_PAINT =
      new Color(140, 140, 255, 100); // light blue
   private final Paint CONTENTS_PAINT = new Color(255, 255, 255, 100); 
   private final DialogHandler dialogHandler = new DialogHandler();
   private int designTimeCondition = 0;
   private boolean contentsSelectable = true;
   
   /**
    * Creates a form based on the specified dialog.
    */
   public Form(final Dialog dialog) {
      super(dialog);
      dialog.addElementContainerListener(dialogHandler);
      addInputEventListener(new BasicInputEventHandler());
   }

   
   // @Override
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      for (Iterator i =
         ((Dialog)getModel()).getPages(getDeviceType()).iterator();
         i.hasNext();
         ) {

         final Page p = (Page)i.next();
         getContents().addChild(new Conversation(p));
      }
      
      setContentsSelectable(true);
   }


   // @Override
   protected PPath createContents() {
      return new Contents();
   }

   
   //@Override
   protected Content getTitleContent() {
      return ((Dialog)getModel()).getFirstPage(getDeviceType()).getTitle();
   }
   
   // @Override
   public DeviceType getDeviceType() {
      final DamaskLayer layer = getLayer();
      if (layer != null) {
         return layer.getDeviceType();
      }
      else {
         return null;
      }
   }

   
   // @Override
   public void dispose() {
      super.dispose();
      ((Dialog)getModel()).removeElementContainerListener(dialogHandler);
   }


   // @Override
   protected Paint getContentsPaint() {
      return CONTENTS_PAINT;
   }
   
   // @Override
   protected Paint getDeviceSpecificContentsPaintInAllLayer() {
      return CONTENTS_PAINT;
   }

   // @Override
   protected Color getTitleColor() {
      return DEFAULT_TITLE_BAR_PAINT;
   }

   
   /**
    * Makes the prompts and responses within this form either
    * selectable or unselectable.
    */ 
   public void setContentsSelectable(final boolean selectable) {
      contentsSelectable = selectable; 
      final DamaskLayer layer = getLayer();
      for (Iterator i = getContents().getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof Conversation) {
            for (Iterator j = child.getChildrenIterator(); j.hasNext(); ) {
               final PNode grandchild = (PNode)j.next();
               if (grandchild instanceof VoiceControl) {
                  final VoiceControl voiceControl = (VoiceControl)grandchild;
                  if (selectable) {
                     layer.addSelectableParent(voiceControl);
                     for (int k = 0,
                          n = ((Dialog)getModel()).getNumConditions();
                          k < n;
                          k++) {
                        if (voiceControl.getResponse(k) != null) {
                           layer.addSelectableParent(voiceControl.getResponse(k));
                        }
                     }
                  }
                  else {
                     layer.removeSelectableParent(voiceControl);
                     for (int k = 0,
                           n = ((Dialog)getModel()).getNumConditions();
                           k < n;
                           k++) {
                         if (voiceControl.getResponse(k) != null) {
                            layer.removeSelectableParent(voiceControl.getResponse(k));
                         }
                      }
                  }
               }
            }
         }
      }
   }
   
   /**
    * Returns whether the prompts and responses within this form
    * selectable or not.
    */ 
   public boolean isContentsSelectable() {
      return contentsSelectable;
   }

   /**
    * Returns the current design-time condition of this page view.
    */
   public int getDesignTimeCondition() {
      return designTimeCondition;
   }

   /**
    * Sets the current design-time condition of this page view.
    * 
    * @throws IllegalArgumentException if the specified condition is greater
    * than or equal to the number of conditions of the underlying page model  
    */
   public void setDesignTimeCondition(final int condition) {
      final Dialog dialog = (Dialog)getModel();
      if (condition >= dialog.getNumConditions()) {
         throw new IllegalArgumentException();
      }
      designTimeCondition = condition;
   }
   
   /**
    * Called when the device-type layer of a layer is changed. 
    */
   public void deviceTypeLayerChanged() {
      super.deviceTypeLayerChanged();

      for (Iterator i = getContents().getChildrenIterator(); i.hasNext(); ) {
         final PNode dialogChild = (PNode)i.next();
         if (dialogChild instanceof Conversation) {
            ((Conversation)dialogChild).deviceTypeLayerChanged();
         }
      }
   }

   // @Override
   protected Dialog getDialogModel() {
      return (Dialog)getModel();
   }
   
   
   /**
    * Returns the point where incoming arrows anchor themselves to this form.
    */
   protected Point2D getAnchorPt() {
      final Rectangle2D formBounds = getBounds();
      return new Point2D.Double(
         formBounds.getCenterX(), formBounds.getMinY() + 1);
   }
   
   
   /**
    * The contents of the form (without the title bar)
    */
   public class Contents extends PPath {
      private static final int HOTSPOT_RADIUS = 10;
      private DamaskPPath arrowToFirstPrompt = new DamaskPPath();
      private HotSpot firstPromptHotSpot =
         new HotSpot(
            new Ellipse2D.Double(0, 0, HOTSPOT_RADIUS * 2, HOTSPOT_RADIUS * 2));
      private boolean endPointBeingDragged = false;
      
      
      public Contents() {
         addChild(arrowToFirstPrompt);
         arrowToFirstPrompt.setPickable(false);
         
         // Make the arrowhead of the arrow pointing to the first prompt
         // draggable
         firstPromptHotSpot.setPaint(DamaskAppUtils.NO_COLOR);
         firstPromptHotSpot.setStrokePaint(DamaskAppUtils.NO_COLOR);
         addChild(firstPromptHotSpot);
      }
      
      public Form getForm() {
         return (Form)getParent();
      }
      
      public void setEndPointBeingDragged(final boolean flag) {
         endPointBeingDragged = flag;
      }
      
      public boolean isEndPointBeingDragged() {
         return endPointBeingDragged;
      }
    
      /**
       * Changes the end point of the arrow to the specified point. Only
       * used when the end point is being dragged.
       */
      public void setArrowEndPoint(final Point2D endPt) {
         final Point2D anchorPt = Form.this.getAnchorPt();
         Form.this.localToGlobal(anchorPt);
         globalToLocal(anchorPt);

         arrowToFirstPrompt.setPathTo(
            new Line2D.Double(anchorPt, endPt));
         arrowToFirstPrompt.setVisible(true);
         firstPromptHotSpot.setOffset(
            endPt.getX() - HOTSPOT_RADIUS,
            endPt.getY() - HOTSPOT_RADIUS);
         firstPromptHotSpot.setVisible(true);
      }
      
      //@Override
      public void layoutChildren() {
         if (endPointBeingDragged) {
            return;
         }
         
         firstPromptHotSpot.setVisible(false);
         // Draw an arrow from the top center of the contents to the first
         // prompt or response in the form.
         Conversation firstConversation = null;
         final PBounds bounds = getBounds();
         for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
            final PNode child = (PNode)i.next();
            if (child instanceof Conversation) {
               if (firstConversation == null) {
                  firstConversation = (Conversation)child;
               }
               for (Iterator j = child.getChildrenIterator(); j.hasNext(); ) {
                  final PNode view = (PNode)j.next();
                  final PBounds viewBounds = view.getFullBounds();
                  child.localToGlobal(viewBounds);
                  globalToLocal(viewBounds);
                  view.setVisible(bounds.intersects(viewBounds));
               }
            }
         }

         if (firstConversation != null) {
            VoiceControl firstControl = null;
            for (Iterator i = firstConversation.getChildrenIterator();
                 i.hasNext(); ) {
               final PNode child = (PNode)i.next();
               if (child instanceof VoiceControl) {
                  firstControl = (VoiceControl)child;
                  break;
               }
            }
            if (firstControl != null) {
               final Point2D anchorPt = Form.this.getAnchorPt();
               Form.this.localToGlobal(anchorPt);
               globalToLocal(anchorPt);

               final Point2D endPt;
               final Prompt firstPrompt = firstControl.getPrompt();
               if (firstPrompt != null) {
                  final PBounds promptBounds = firstPrompt.getBounds();
                  firstPrompt.localToGlobal(promptBounds);
                  globalToLocal(promptBounds);
                  final Point2D centerPt = promptBounds.getCenter2D();
                  
                  final List/*<Point2D>*/ intersectPts =
                     GeomLib.calcIntersectPoints(
                        new Line2D.Double(anchorPt, centerPt), promptBounds);
                  if (intersectPts.isEmpty()) {
                     endPt = centerPt;
                  }
                  else {
                     endPt = (Point2D)intersectPts.get(0);
                  }
               }
               else {
                  final Response firstResponse =
                     firstControl.getResponse(getDesignTimeCondition());
                  if (firstResponse != null) {
                     final Response.HotSpot hotSpot =
                        firstResponse.getStartHotSpot();
                     endPt = hotSpot.getBounds().getCenter2D();
                     hotSpot.localToGlobal(endPt);
                     globalToLocal(endPt);
                  }
                  else {
                     endPt = null;
                  }
               }
               if (endPt != null) {
                  setArrowEndPoint(endPt);
               }
               else {
                  arrowToFirstPrompt.setVisible(false);
               }
            }
         }
      }

      // Overrides method in parent class.
      protected void paint(PPaintContext paintContext) {
         super.paint(paintContext);
         if (arrowToFirstPrompt.getVisible() && !arrowToFirstPrompt.getBounds().isEmpty()) {
            DamaskAppUtils.drawArrowheads(arrowToFirstPrompt, paintContext);     
         }
      }
   }

   /**
    * The start or end point of the response. 
    */
   public static class HotSpot extends PPath {
      public HotSpot() {
         super();
         addInputEventListener(new DragHotSpotHandler());
      }
      
      public HotSpot(Shape aShape) {
         super(aShape);
         addInputEventListener(new DragHotSpotHandler());
      }
      
      public HotSpot(Shape aShape, Stroke aStroke) {
         super(aShape, aStroke);
         addInputEventListener(new DragHotSpotHandler());
      }
      
      /**
       * Returns the conversation that this hot spot belongs to.
       */
      public Contents getContents() {
         return (Contents)getParent();
      }
      
      /** 
       * The event handler that handles moving the endpoints of a response.
       */
      public class DragHotSpotHandler extends PDragSequenceEventHandler {
         private HotSpot hotSpot = null;
         private Form.Contents contents = null;
         
         /**
          * Constructs a handler which will instantiate a component of the specified
          * type.
          * 
          * @param componentViewType a class which is a descendant of
          * {@link edu.berkeley.guir.damask.view.visual.component.ComponentView}
          */
         public DragHotSpotHandler() {
            setEventFilter(new PInputEventFilter(InputEvent.BUTTON1_MASK));
         }


         private void updateLine(PInputEvent e) {
            contents.setArrowEndPoint(e.getPositionRelativeTo(contents));
         }

         
         // @Override
         public void startDrag(PInputEvent e) {
            super.startDrag(e);
            
            ((DamaskCanvas)e.getComponent()).stopTextEditing();
            
            final PNode startNode = e.getPickedNode(); 
            hotSpot =
               (HotSpot)DamaskAppUtils.getAncestor(startNode, HotSpot.class);
            if (hotSpot == null) {
               return;
            }
            contents = hotSpot.getContents();
            contents.setEndPointBeingDragged(true);
         }


         // @Override
         public void drag(final PInputEvent e) {
            super.drag(e);
            if (hotSpot == null) {
               return;
            }
            updateLine(e);
         }

         // @Override
         public void endDrag(final PInputEvent e) {
            super.endDrag(e);
            if (hotSpot == null) {
               return;
            }
            updateLine(e);
            contents.setEndPointBeingDragged(false);

            // Find out what's underneath the hot spot just moved
            final boolean origHotSpotPickable = hotSpot.getPickable();
            hotSpot.setPickable(false);

            final DamaskCanvas canvas = (DamaskCanvas)e.getComponent();
            
            final Point2D ptCameraCoords =
               e.getPositionRelativeTo(e.getCamera());
            final PNode endNode =
               e.getCamera()
                .pick(ptCameraCoords.getX(), ptCameraCoords.getY(), 1)
                .getPickedNode();

            hotSpot.setPickable(origHotSpotPickable);
            
            if (endNode instanceof Prompt) {
               final Prompt endPrompt = (Prompt)endNode;
               if (endPrompt.getForm() == contents.getForm()) {
                  final Conversation conversation = endPrompt.getConversation();
                  final Page newFirstPage = (Page)conversation.getModel();
                  canvas.getDocument().getCommandQueue().doCommand(
                     canvas, new SetPageIndexCommand(newFirstPage, 0));
               }
            }
         }  
      }
   }
   
   /**
    * Listens for events from the dialog's model. 
    */
   private final class DialogHandler
      implements
         ElementContainerListener,
         InteractionElementListener {

      public void elementAdded(ElementContainerEvent e) {
         if (e.getElement() instanceof Page) {
            final Page p = (Page)e.getElement();
            if (p.getDeviceType() == getDeviceType()) {
               getContents().addChild(
                  p.getDialog().indexOf(p), new Conversation(p));
            }
         }
      }

      public void elementRemoved(ElementContainerEvent e) {
         if (e.getElement() instanceof Page) {
            final Page p = (Page)e.getElement();
            if (p.getDeviceType() == getDeviceType()) {
               for (Iterator i = new ArrayList/*<PNode>*/(
                       getContents().getChildrenReference()).iterator();
                    i.hasNext(); ) {
                  final PNode n = (PNode)i.next();
                  if (n instanceof Conversation) {
                     final Conversation c = (Conversation)n;
                     if (c.getModel() == p) {
                        getContents().removeChild(c);
                        c.dispose();
                     }
                  }
               }
            }
         }
      }

      public void elementBoundsUpdated(InteractionElementEvent e) {
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }
   }


   /**
    * Listens to mouse and key events in the canvas's main camera.
    */
   private class BasicInputEventHandler extends PBasicInputEventHandler {
      public void mousePressed(PInputEvent event) {
         if (event.getComponent() instanceof VoiceCanvas) {
            updateHandles(event);
         }
      }
      
      private void updateHandles(PInputEvent event) {
         if (event.getComponent() instanceof VoiceCanvas) {
            ((VoiceCanvas)event.getComponent()).attachHandles(
               Form.this, event.getCamera());
         }
      }
   }
}
