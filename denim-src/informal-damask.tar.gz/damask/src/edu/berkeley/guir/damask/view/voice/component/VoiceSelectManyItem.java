package edu.berkeley.guir.damask.view.voice.component;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import edu.berkeley.guir.damask.component.SelectMany;
import edu.berkeley.guir.damask.view.voice.ResponseInternalDest;
import edu.berkeley.guir.damask.view.voice.ResponseSource;

/** 
 *A view of an item within a select-many control.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  08-15-2004 James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public class VoiceSelectManyItem extends VoiceControl
implements ResponseSource, ResponseInternalDest {

   /**
    * Constructs a view of the specified select-many item.
    */
   public VoiceSelectManyItem(final SelectMany.Item model) {
      super(model);
   }

   
   // @Override
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      final Prompt newPrompt = new Prompt(this);
      setPrompt(newPrompt);
      
      setResponse(
         0,
         new Response(
            this,
            (ResponseInternalDest)
               getConversation().getNextVoiceControlWithPrompt(this)));
   }


   // @Override
   public Point2D getAnchorPt() {
      return getPrompt().getBounds().getCenter2D();
   }


   // @Override
   public Rectangle2D getSourceBounds() {
      return getPrompt().getBounds();
   }


   // @Override
   public Rectangle2D getDestBounds() {
      return getPrompt().getBounds();
   }
}
