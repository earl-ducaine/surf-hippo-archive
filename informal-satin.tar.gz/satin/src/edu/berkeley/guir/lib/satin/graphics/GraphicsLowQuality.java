//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.graphics;

import edu.berkeley.guir.lib.awt.geom.*;
import java.awt.*;

/**
 * Render low quality images.
 * <UL>
 *    <LI>Filled objects drawn normally.
 *    <LI>Polygons are drawn simplified.
 *    <LI>Images are rendered normally.
 *    <LI>All rendering hints are set for speed.
 * </UL>
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 19 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *          <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class GraphicsLowQuality 
   extends GraphicsMediumQuality {

   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public GraphicsLowQuality() {
      //// 1. Hints for Lowest quality, fastest speed.
      hints = new HintsHashMap();
      hints.put(RenderingHints.KEY_ALPHA_INTERPOLATION,
            RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
      hints.put(RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_OFF);
      hints.put(RenderingHints.KEY_COLOR_RENDERING,
            RenderingHints.VALUE_COLOR_RENDER_SPEED);
      hints.put(RenderingHints.KEY_DITHERING,
            RenderingHints.VALUE_DITHER_DISABLE);
      hints.put(RenderingHints.KEY_RENDERING,
            RenderingHints.VALUE_RENDER_SPEED);
      hints.put(RenderingHints.KEY_TEXT_ANTIALIASING,
            RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
      hints.put(RenderingHints.KEY_FRACTIONALMETRICS,
            RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
      hints.put(RenderingHints.KEY_INTERPOLATION,
            RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
   } // of default constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   PERFORMANCE MODIFICATIONS   =========================================

   /**
    * Does polygon simplification on {@link Polygon2D}.
    * Otherwise just normal.
    */
   public void draw(Shape s) {
      if (s instanceof Polygon2D) {
         Polygon2D p = (Polygon2D) s;

         //// Barely draw if it is far away
         if (AffineTransformLib.getScaleFactor(getTransform()) < 0.1) {
            drawLine((int) p.xpoints[0],
                     (int) p.ypoints[0], 
                     (int) p.xpoints[p.npoints - 1], 
                     (int) p.ypoints[p.npoints - 1]);
            return;
         }
         //// Just simplify it
         else {
            s = p.simplify();
         }
      }
      super.draw(s);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Does polygon simplification on {@link Polygon2D}.
    * Otherwise just normal.
    */
   public void fill(Shape s) {
      if (s instanceof Polygon2D) {
         s = ((Polygon2D) s).simplify();
      }
      super.fill(s);
   } // of method

   //===   PERFORMANCE MODIFICATIONS   =========================================
   //===========================================================================



   //===========================================================================
   //===   DELEGATION GRAPHICS - DRAWING METHODS   =============================

   public void drawPolyline(int xPoints[], int yPoints[], int nPoints) {
      Polygon p = GeomLib.simplify(xPoints, yPoints, nPoints);
      g.drawPolyline(p.xpoints, p.ypoints, p.npoints);
   } // of drawPolyline

   //-----------------------------------------------------------------

   public void drawPolygon(int xPoints[], int yPoints[], int nPoints) {
      Polygon p = GeomLib.simplify(xPoints, yPoints, nPoints);
      g.drawPolygon(p.xpoints, p.ypoints, p.npoints);
   } // of drawPolygon

   //-----------------------------------------------------------------

   public void drawPolygon(Polygon p) {
      g.drawPolygon(GeomLib.simplify(p.xpoints, p.ypoints, p.npoints));
   } // of drawPolygon

   //-----------------------------------------------------------------

   public void fillPolygon(int xPoints[], int yPoints[], int nPoints) {
      Polygon p = GeomLib.simplify(xPoints, yPoints, nPoints);
      g.fillPolygon(p.xpoints, p.ypoints, p.npoints);
   } // of fillPolygon

   //-----------------------------------------------------------------

   public void fillPolygon(Polygon p) {
      g.fillPolygon(GeomLib.simplify(p.xpoints, p.ypoints, p.npoints));
   } // of drawPolygon

   //===   DELEGATION GRAPHICS - DRAWING METHODS   =============================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
