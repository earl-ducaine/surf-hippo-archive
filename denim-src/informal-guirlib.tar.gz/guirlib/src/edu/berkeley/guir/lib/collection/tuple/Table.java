//// See bottom of file for software license
package edu.berkeley.guir.lib.collection.tuple;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * A table of tuples, somewhat similar (but by no means as full-featured)
 * as a database table.
 *
 * <P>
 * For example, can get all Tuples with a specified attribute value.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Last modified Jan 08 2004 JIH
 */
public class Table {

    //==========================================================================
    //===   INSTANCE VARIABLES   ===============================================

    List listTuples = new LinkedList();

    //===   INSTANCE VARIABLES   ===============================================
    //==========================================================================



    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    public Table() {
    } // of constructor

    //----------------------------------------------------------------

    public Table(List listTuples) {
        addAll(listTuples);
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================



    //==========================================================================
    //===   COLLECTION METHODS   ===============================================

    public void add(Tuple t) {
        listTuples.add(t);
    } // of method

    /**
     * @param list is a list of Tuples
     */
    public void addAll(List list) {
        listTuples.addAll(list);
    } // of method

    //----------------------------------------------------------------

    /**
     * Get all tuples with the specified attribute value.
     */
    public List get(String strAttribute, String strVal) {
        List     listReturn = new LinkedList();
        Iterator it         = listTuples.iterator();
        Tuple    t;

        while (it.hasNext()) {
            t = (Tuple) it.next();
            if (t.getAttribute(strAttribute).equals(strVal)) {
                listReturn.add(t);
            }
        }

        return (listReturn);
    } // of method

    /**
     * Get the first matching tuple.
     */
    public Tuple getFirst(String strAttribute, String strVal) {
        List list = get(strAttribute, strVal);
        if (list.size() > 0) {
            return (Tuple) (list.get(0));
        }
        return (null);
    } // of method

    /**
     * Get the specified attribute (strOutAttribute) of the first matching 
     * Tuple where strQueryAttribute equals strVal.
     * @return null if no tuples found, "" if no value, String otherwise.
     */
    public String getFirstValue(String strQueryAttribute, 
                                String strVal,
                                String strOutAttribute) {
        Tuple t = getFirst(strQueryAttribute, strVal);
        if (t == null) {
            return (null);
        }
        return (t.getAttribute(strOutAttribute));
    } // of method

    //----------------------------------------------------------------

    public void clear() {
        listTuples.clear();
    } // of method

    //----------------------------------------------------------------

    public void remove(Tuple t) {
        listTuples.remove(t);
    } // of method

    /**
     * @param list is a list of Tuples
     */
    public void removeAll(List list) {
        listTuples.removeAll(list);
    } // of method

    //----------------------------------------------------------------

    public Iterator iterator() {
        return (listTuples.iterator());
    } // of method

    //===   COLLECTION METHODS   ===============================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
