package edu.berkeley.guir.lib.satin.widgets;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * A popup menu. There is a persistent JButton widget that, when pressed, pops up a Pie Menu.
 * It's just like a normal linear pop-up menu, except that it pops up a pie menu. The pie
 * menu will be centered at the menu location, unless it would fall off the screen, in which
 * case it centers as closely as possible.
 * 
 * @author  <A HREF="http://www.cs.berkeley.edu/~srk/">Scott Klemmer</A> (
 *          <A HREF="mailto:srk@cs.berkeley.edu">srk@cs.berkeley.edu</A> )
 */

public class PopupPieMenu extends PenButton {
   private PieMenu m_pieMenu = new PieMenu();
   private Icon myIcon = new PieMenuIcon(super.getPreferredSize().height/2);
	/**
	 * A pie icon
	 */
	private class PieMenuIcon implements Icon {
		private static final int SPACE = 10;
		private int m_size;
			
		PieMenuIcon (int size) {
			m_size = size;
		}
			
		public int getIconHeight() { return m_size; }
		public int getIconWidth()  { return m_size + SPACE; }
		
		public void paintIcon( Component c, Graphics g, int x, int y ) {
			x +=(SPACE-1);
			Graphics2D g2d = (Graphics2D)g;
	      g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

			g.setColor(Color.gray);
			g2d.fillArc(x, y, m_size, m_size, 45, 90);
			
			g.setColor(Color.black);
			g2d.drawOval(x, y, m_size, m_size);
		}
	}

   
   /**
   * pops up a pie menu that (should) do the same thing as the current 'filter' thing.		
   * does View All only.
   */
   public PopupPieMenu(String[] filterStrings, int startIndex) {
      
      super(filterStrings[startIndex]);      
		super.setIcon(myIcon);
		super.setHorizontalTextPosition(super.LEFT);

	   // Gets the string names for all the filters, and stick the names in an array
	   
      m_pieMenu.addPieMenuTo(this);
	   PieMenu.setAllInitialDelay(0);
	   m_pieMenu.setAcceptLeftButton(true);
	   m_pieMenu.setLineNorth(true);
	   PieMenu.setAllTapOpen();
	   PieMenu.setAllClipping(true);
   }


   public JMenuItem add(String s) {
      JMenuItem j = m_pieMenu.add(s);
      //j.setIcon(myIcon);
      //j.setHorizontalTextPosition(SwingConstants.LEFT);
      //j.setVerticalTextPosition(SwingConstants.BOTTOM);
      j.addActionListener(new PopupActionListener(s));
      return j;
   }

   public void setSelectedItem(String s) {
      setText(s);      
   }


	/**
	 *  This class is a small extension to action listener that stores 
	 *  the appropriate filter name as a member variable.
	 */
   private class PopupActionListener implements ActionListener {
		private String m_filterName;
	
		PopupActionListener (String s) {
			m_filterName = s;
		}

      public void actionPerformed(ActionEvent e) {
         setText(m_filterName);
      }
	}
	
	
}

