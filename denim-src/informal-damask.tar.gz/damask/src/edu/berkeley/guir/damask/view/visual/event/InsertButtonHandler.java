package edu.berkeley.guir.damask.view.visual.event;

import java.awt.geom.*;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.component.*;
import edu.berkeley.guir.damask.dialog.PageRegion;
import edu.berkeley.guir.damask.view.visual.component.Button;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;

/** 
 * The event handler that handles inserting buttons into pages.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-21-2003 James Lin
 *                               Created InsertButtonHandler.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-21-2003
 */
public class InsertButtonHandler extends InsertComponentHandler {

   /**
    * Constructs a new button handler. 
    */
   public InsertButtonHandler() {
      super(Button.class);
   }

   // Overrides method in parent class.
   protected Component createNewComponent(
      final DeviceType deviceType,
      final PageRegion region,
      final AffineTransform transform,
      final Rectangle2D bounds) {

      final PNode buttonDefaultView = Button.createTempView();
      final GeneralPath buttonDefaultViewBorder =
         ((PPath)buttonDefaultView).getPathReference();
      final PPath buttonDefaultViewContentsPath =
         (PPath)buttonDefaultView.getChild(0);
      final GeneralPath buttonDefaultViewContents =
         buttonDefaultViewContentsPath.getPathReference();
         
      final Content buttonContents =
         new Content(deviceType, buttonDefaultViewContents);

      buttonContents.setBounds(
         deviceType,
         buttonDefaultViewContents.getBounds2D());
      buttonContents.setTransform(
         deviceType,
         buttonDefaultViewContentsPath.getTransform());
         
      final Trigger trigger = new Trigger(deviceType, buttonContents);
      trigger.setStyle(deviceType, Trigger.BUTTON);
      
      final DeviceType regionDeviceType = region.getDeviceType();
      
      trigger.setBorder(regionDeviceType, buttonDefaultViewBorder);
      trigger.setTransform(regionDeviceType, transform);
      trigger.setBounds(regionDeviceType, bounds);
      
      return trigger;
   }
}
