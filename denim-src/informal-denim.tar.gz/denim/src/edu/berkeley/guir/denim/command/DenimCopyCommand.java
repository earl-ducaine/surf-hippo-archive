//// See bottom of source code for software license

package edu.berkeley.guir.denim.command;

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.DenimHyperlinkInstance;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.command.*;
import java.util.*;

/**
 * Copies a Denim Object to the clipboard.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - Feb 13 2001, JL
 *               Created class
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2
 * @version SATIN-v2.1-1.0.0, Aug 11 2000
 */
public class DenimCopyCommand
   extends CopyCommand {

   //===========================================================================
   //===   CLASS VARIABLES   ===================================================

   static {
      setClipboard(DenimConstants.denimClipboard);
   }

   //===   CLASS VARIABLES   ===================================================
   //===========================================================================


   //===========================================================================
   //===   INSTANCE VARIABLES   ================================================

   //===   INSTANCE VARIABLES   ================================================
   //===========================================================================


   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public DenimCopyCommand() {
      super();
   } // of constructor

   //-----------------------------------------------------------------

   public DenimCopyCommand(GraphicalObject gob) {
      super(gob);
   } // of constructor

   //-----------------------------------------------------------------

   public DenimCopyCommand(Iterator it) {
      //super(it);
       while (it.hasNext()) {
           Object obj = it.next();
           if (obj instanceof GraphicalObject) {
              addGraphicalObject((GraphicalObject) obj);
              addArrowsWithin((GraphicalObject) obj);
           }
        }
   } // of constructor

   //-----------------------------------------------------------------

   public DenimCopyCommand(Vector gobs) {
      super(gobs);
   } // of constructor

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================

   public void run() {
       super.run();
       //DenimConstants.denimClipboard.recoverArrow();

   } // of copyToClipboard
   
   /**
    * Add all of the arrows that start from or end in a graphical object
    * to the list of objects to be cut. Do not add it to the list
    * to be copied to the clipboard.
    */
   protected void addArrowsWithin(GraphicalObject gob) {
      Set allArrows = new HashSet();
      Iterator it;

      //debug.println("add arrows: inspecting " + DenimUtils.toShortString(gob));

      // Get all arrows going out of this gob.
      if (gob instanceof ArrowSource) {
         allArrows.addAll(((ArrowSource)gob).getOutgoingArrows());
      }

      // Get all arrows coming into this gob.
      if (gob instanceof ArrowDest) {
         allArrows.addAll(((ArrowDest)gob).getIncomingArrows());
      }

      // Add the arrows to the table of objects to be copied
      it = allArrows.iterator();
      while (it.hasNext()) {
         Arrow arrow = (Arrow)(it.next());
         super.addGraphicalObject(arrow);
      }

      // If this gob is a group, find all arrows from objects within this
      // group
      if (gob instanceof GraphicalObjectGroup) {
         GraphicalObjectGroup gobgrp = (GraphicalObjectGroup)gob;
         it = gobgrp.getForwardIterator();
         while (it.hasNext()) {
            addArrowsWithin((GraphicalObject)it.next());
         }
      }
   }
   


   //===========================================================================
   //===   ACTION METHODS   ====================================================

   //===   ACTION METHODS   ====================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 1999-2001 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
