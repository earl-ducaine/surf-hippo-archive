//// See bottom of file for software license
package edu.berkeley.guir.lib.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.Reader;
import java.net.URL;
import edu.berkeley.guir.lib.io.IOLib;

/**
 * Library for loading up resources, whether from file system
 * or jar file. Provides a level of indirection that unifies
 * both of these approaches.
 *
 * <P>
 * Example usage:
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A>
 * @version Feb 14 2004 JH
 */
public class ResourceLib {

    //==========================================================================
    //===   CONSTRUCTORS   =====================================================

    /**
     * No instances allowed.
     */
    private ResourceLib() {
    } // of constructor

    //===   CONSTRUCTORS   =====================================================
    //==========================================================================



    //==========================================================================
    //===   RESOURCE METHODS   =================================================

    /**
     * @param strFile is something like
     *                "edu/berkeley/guir/confab/gui/access/icon/on.gif".
     * @return a relative path, ex. "icon/on.gif", or null on an error.
     */
    private static String clipPath(Class cl, String strFile) {
        //// 1. Get the full class, ex. "edu.berkeley.guir.lib.util.ResourceLib"
        ////    Clip to "edu.berkeley.guir.lib.util."
        String strPath = cl.getName();
        int    index   = strPath.lastIndexOf(".");
        strPath = strPath.substring(0, index + 1);

        //// 2. Clip the length of the path.
        ////    Conveniently, "edu.berkeley.guir.lib.util." is the same length
        ////    as            "edu/berkeley/guir/lib/util/"
        if (strFile.length() >= strPath.length()) {
            return (strFile.substring(strPath.length()));
        }
        return (null);
    } // of method

    //--------------------

    private static File toFile(String strPath, String strFile) {
        return (new File(strPath, strFile));
    } // of method

    //--------------------

    /**
     * Transform the specified File into a file URL.
     */
    private static String toFileUrl(File f) 
        throws IOException {
        return ("file:/" + f.getCanonicalPath());
    } // of method


    /**
     * Transform the specified String into a file URL.
     */
    private static String toFileUrl(String strPath, String strFile) {
        //// 1. Make sure there is a "/" between the two Strings
        if (strPath.endsWith("/") == false &&
            strFile.startsWith("/") == false) {
            strPath = strPath + "/";
        }

        //// 2. Return.
        return ("file:/" + strPath + strFile);
    } // of method

    //----------------------------------------------------------------

    /**
     * Try to get a resource as a URL.
     * @param cl is the Class loading the resource. This is important to
     *           specify correctly, since we use relative paths based on
     *           where this Class is.
     * @param strFile is the name of the resource, either full or short.
     *                A full name is something like
     *                <CODE>"edu/berkeley/guir/lib/util/resource.txt"</CODE> or
     *                <CODE>"edu/berkeley/guir/lib/util/icons/icon1.gif"</CODE>,
     *                while a short one would be
     *                <CODE>"resource.txt"</CODE> or
     *                <CODE>"icons/icon1.gif"</CODE>.
     *                Short paths are relative to the class <CODE>cl</CODE>,
     *                so if the class were 
     *                <CODE>"edu.berkeley.guir.lib.util.ResourceLib"</CODE>,
     *                then the short paths are relative to 
     *                <CODE>"edu/berkeley/guir/lib/util/"</CODE>.
     *                MAKE SURE YOU USE "/" AND NOT <@link File#separator} or
     *                {@link File#separatorChar}, OR YOU WILL GET NULL POINTERS.
     * @return a URL, or null if it cannot be found.
     */
    public static URL getResourceAsUrl(Class cl, String strFile) {
        URL url;

        //// 1.1. Try to load the resource as is.
        url = cl.getResource(strFile);

        //// 1.2. If the url was not found, then try the short path.
        if (url == null) {
            url = cl.getResource(clipPath(cl, strFile));
        }

        //// 2.1. Try to load via the ClassLoader...
        if (url != null) {
            return (url);
        }
        //// 2.2. ...otherwise try to load via the file system.
        else {
            File f = toFile(System.getProperty("user.dir"), strFile);
            if (f.exists() == false) {
                return (null);
            }
            else {
                try {
                    return (new URL(toFileUrl(f)));
                }
                catch (Exception e) {
                    return (null);
                }
            }
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Try to load a resource as a InputStream.
     *
     * @param cl is the Class loading the resource. This is important to
     *           specify correctly, since we use relative paths based on
     *           where this Class is.
     * @param strFile is the name of the resource, either full or short.
     *                A full name is something like
     *                <CODE>"edu/berkeley/guir/lib/util/resource.txt"</CODE> or
     *                <CODE>"edu/berkeley/guir/lib/util/icons/icon1.gif"</CODE>,
     *                while a short one would be
     *                <CODE>"resource.txt"</CODE> or
     *                <CODE>"icons/icon1.gif"</CODE>.
     *                Short paths are relative to the class <CODE>cl</CODE>,
     *                so if the class were 
     *                <CODE>"edu.berkeley.guir.lib.util.ResourceLib"</CODE>,
     *                then the short paths are relative to 
     *                <CODE>"edu/berkeley/guir/lib/util/"</CODE>.
     *                MAKE SURE YOU USE "/" AND NOT <@link File#separator} or
     *                {@link File#separatorChar}, OR YOU WILL GET NULL POINTERS.
     * @return an InputStream to the resource, or null if it could not be found
     * @see #getResourceAsUrl(Class,String)
     */
    public static InputStream getResourceAsStream(Class cl, String strFile) {
        InputStream istream;

        //// 1.1. Try to load the resource as is.
        istream = cl.getResourceAsStream(strFile);

        //// 1.2. If the url was not found, then try the short path.
        if (istream == null) {
            istream = cl.getResourceAsStream(clipPath(cl, strFile));
        }

        //// 2.1. Try to load via the ClassLoader...
        if (istream != null) {
            return (istream);
        }
        //// 2.2. ...otherwise try to load via the file system.
        else {
            File f = toFile(System.getProperty("user.dir"), strFile);
            if (f.exists() == false) {
                return (null);
            }
            else {
                try {
                    return (new FileInputStream(f));
                }
                catch (Exception e) {
                    return (null);
                }
            }
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Try to load a resource as a Reader.
     *
     * @param cl is the Class loading the resource. This is important to
     *           specify correctly, since we use relative paths based on
     *           where this Class is.
     * @param strFile is the name of the resource, either full or short.
     *                A full name is something like
     *                <CODE>"edu/berkeley/guir/lib/util/resource.txt"</CODE> or
     *                <CODE>"edu/berkeley/guir/lib/util/icons/icon1.gif"</CODE>,
     *                while a short one would be
     *                <CODE>"resource.txt"</CODE> or
     *                <CODE>"icons/icon1.gif"</CODE>.
     *                Short paths are relative to the class <CODE>cl</CODE>,
     *                so if the class were 
     *                <CODE>"edu.berkeley.guir.lib.util.ResourceLib"</CODE>,
     *                then the short paths are relative to 
     *                <CODE>"edu/berkeley/guir/lib/util/"</CODE>.
     *                MAKE SURE YOU USE "/" AND NOT <@link File#separator} or
     *                {@link File#separatorChar}, OR YOU WILL GET NULL POINTERS.
     * @return a Reader to the resource, or null if it could not be found
     * @see #getResourceAsUrl(Class,String)
     */
    public static Reader getResourceAsReader(Class cl, String strFile) {
        InputStream istream = getResourceAsStream(cl, strFile);
        if (istream == null) {
            return (null);
        }
        else {
            return (new InputStreamReader(istream));
        }
    } // of method

    //----------------------------------------------------------------

    /**
     * Try to load and read in a resource as a String.
     * Loads it up as a Reader and then reads all the data in as a String.
     *
     * @param cl is the Class loading the resource. This is important to
     *           specify correctly, since we use relative paths based on
     *           where this Class is.
     * @param strFile is the name of the resource, either full or short.
     *                A full name is something like
     *                <CODE>"edu/berkeley/guir/lib/util/resource.txt"</CODE> or
     *                <CODE>"edu/berkeley/guir/lib/util/icons/icon1.gif"</CODE>,
     *                while a short one would be
     *                <CODE>"resource.txt"</CODE> or
     *                <CODE>"icons/icon1.gif"</CODE>.
     *                Short paths are relative to the class <CODE>cl</CODE>,
     *                so if the class were 
     *                <CODE>"edu.berkeley.guir.lib.util.ResourceLib"</CODE>,
     *                then the short paths are relative to 
     *                <CODE>"edu/berkeley/guir/lib/util/"</CODE>.
     *                MAKE SURE YOU USE "/" AND NOT <@link File#separator} or
     *                {@link File#separatorChar}, OR YOU WILL GET NULL POINTERS.
     * @see #getResourceAsUrl(Class,String)
     * @return null on error, String otherwise.
     */
    public static String getResourceAsString(Class cl, String strFile) {
        StringBuffer strbuf;
        Reader       rdr;

        try {
            rdr    = getResourceAsReader(cl, strFile);
            strbuf = IOLib.readAll(rdr);
            return (strbuf.toString());
        }
        catch (Exception e) {
            e.printStackTrace();
            return (null);
        }
    } // of method

    //===   RESOURCE METHODS   =================================================
    //==========================================================================

} // of class

//==============================================================================

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User 
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products 
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
