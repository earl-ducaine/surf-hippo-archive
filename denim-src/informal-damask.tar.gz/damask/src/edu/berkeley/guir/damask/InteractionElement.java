package edu.berkeley.guir.damask;

import java.awt.geom.*;
import java.util.Set;

import edu.berkeley.guir.damask.event.InteractionElementListener;
import edu.berkeley.guir.lib.id.GUID;

/** 
 * An element of interaction. This includes pages, components, and pattern
 * instances.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  03-20-2003 James Lin
 *                               Created InteractionElement.
 * Revisions:  1.1.0  06-12-2003 James Lin
 *                               Separated interface from implementation.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.1.0, 06-12-2003
 */
public interface InteractionElement extends Cloneable {

   /**
    * Returns the ID of this element.
    */
   public GUID getId();
   
   //===========================================================================
   
   /**
    * Returns the interaction graph that the page is in, or null if it's not
    * in any graph.
    */
   public InteractionGraph getInteractionGraph();
   

   //===========================================================================

   /**
    * Adds the specified element listener to receive events from this element.
    */
   public void addInteractionElementListener(
      final InteractionElementListener listener);

   //---------------------------------------------------------------------------

   /**
    * Removes the specified element listener so that it no longer receives
    * events from this element.
    */
   public void removeInteractionElementListener(
      final InteractionElementListener listener);

   //===========================================================================
   
   /**
    * Returns all of the device types that this element is visible to. 
    */
   Set/*<DeviceType>*/ getDeviceTypesVisibleTo();

   //---------------------------------------------------------------------------
   
   /**
    * Returns whether this this element is visible to the given device type. 
    */
   boolean isVisibleToDeviceType(DeviceType deviceType);

   //===========================================================================
   
   /**
    * Returns the local bounds of this element, from the specified device type's
    * perspective.
    */
   public Rectangle2D getBounds(final DeviceType deviceType);
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the local bounds of this element, from the specified device type's
    * perspective.
    */
   public void setBounds(
      final DeviceType deviceType,
      final Rectangle2D newBounds);

   //---------------------------------------------------------------------------
   
   /**
    * Returns the local bounds of this element in the parent's coordinate
    * system, from the specified device type's perspective.
    */
   public Rectangle2D getBoundsInParentCoords(final DeviceType deviceType);
      
   //===========================================================================
   
   /**
    * Returns the location of this element, from the specified device type's
    * perspective.
    */
   public Point2D getLocation(final DeviceType deviceType);
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the location of this element, from the specified device type's
    * perspective.
    */
   public void setLocation(
      final DeviceType deviceType,
      final Point2D newLocation);
   
   //---------------------------------------------------------------------------
   
   /**
    * Returns a copy of the transform of this element, from the specified
    * device type's perspective.
    */
   public AffineTransform getTransform(final DeviceType deviceType);
   
   //---------------------------------------------------------------------------
   
   /**
    * Sets the transform of this element, from the specified device type's
    * perspective.
    */
   public void setTransform(
      final DeviceType deviceType,
      final AffineTransform newBounds);
      
   //===========================================================================
   
   /**
    * Returns the object that was cloned to create this object, if this
    * object was created via a call to clone(). Returns null if this object
    * was not created by a clone, or if the original object has been
    * garbage collected.
    */
   public InteractionElement getCloneSourceIfAlive();
   
   //===========================================================================
   
   /**
    * Returns the object that was most recently cloned from this object,
    * or null if there has been no clones created or if the clone has been
    * garbage collected.
    */
   public InteractionElement getMostRecentCloneIfAlive();
   
   //===========================================================================
   
   /**
    * Returns a verbose string representation of this element.
    */
   public String toLongString();

   //---------------------------------------------------------------------------
   
   /**
    * Returns a verbose string representation of this element, with the given
    * indent level and according to the given device type's perspective.
    */
   public String toLongString(int indentLevel, final DeviceType deviceType);
      
   //===========================================================================
   
   public Object clone();
   
}
