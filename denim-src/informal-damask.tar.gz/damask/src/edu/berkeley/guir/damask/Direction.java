package edu.berkeley.guir.damask;

import java.util.*;

/**
 * An enumerated type describing directions.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-04-2003 James Lin
 *                               Moved from PageRegion.Name.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-04-2003
 */
public class Direction {
   private String name;

   public static final Direction CENTER = new Direction("Center");
   public static final Direction NORTH = new Direction("North");
   public static final Direction SOUTH = new Direction("South");
   public static final Direction EAST = new Direction("East");
   public static final Direction WEST = new Direction("West");
   public static final Direction NORTHWEST = new Direction("Northwest");
   public static final Direction NORTHEAST = new Direction("Northeast");
   public static final Direction SOUTHWEST = new Direction("Southwest");
   public static final Direction SOUTHEAST = new Direction("Southeast");

   private static final Direction[] PRIVATE_VALUES =
      {
         Direction.NORTHWEST,
         Direction.NORTH,
         Direction.NORTHEAST,
         Direction.WEST,
         Direction.CENTER,
         Direction.EAST,
         Direction.SOUTHWEST,
         Direction.SOUTH,
         Direction.SOUTHEAST };


   private Direction(String name) {
      this.name = name;
   }


   public String toString() {
      return name;
   }

   
   /**
    * Returns a list of values for directions, such as CENTER and NORTH.
    */
   public static final List getValues() {
      return Collections.unmodifiableList(
         Arrays.asList(Direction.PRIVATE_VALUES));
   }
}