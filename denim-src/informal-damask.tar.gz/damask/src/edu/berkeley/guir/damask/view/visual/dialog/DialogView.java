package edu.berkeley.guir.damask.view.visual.dialog;

import java.util.ArrayList;
import java.util.Iterator;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.view.DamaskLayer;
import edu.berkeley.guir.damask.view.InteractionElementView;
import edu.umd.cs.piccolo.PNode;

/**
 * A view of a dialog, which contains one or more pages.
 * 
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.</p>
 *
 * <PRE>
 * Revisions:  1.0.0  09-11-2003 James Lin
 *                               Created DialogView.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-11-2003
 */
public class DialogView extends InteractionElementView {
   private final DialogHandler dialogListener = new DialogHandler();
   private int designTimeCondition = 0;
   private boolean pageContentsSelectable = false;

   /**
    * Constructs a new view of the given dialog, from the given device type's
    * perspective.
    */
   public DialogView(final Dialog dialog) {
      super(dialog);

      // Listen for the dialog's events               
      dialog.addElementContainerListener(dialogListener);
      dialog.addInteractionElementListener(dialogListener);
   }

   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();
      
      // Add pages to the dialog's node in the tree
      for (Iterator i =
         ((Dialog)getModel()).getPages(getDeviceType()).iterator();
         i.hasNext();
         ) {

         final Page p = (Page)i.next();
         addChild(new PageView(p));
      }
   }


   /**
    * Frees up any resources associated with this dialog.
    */
   public void dispose() {
      super.dispose();

      final Dialog dialog = (Dialog)getModel();
      dialog.removeElementContainerListener(dialogListener);
      dialog.removeInteractionElementListener(dialogListener);
   }


   // Overrides method in parent class.
   public DeviceType getDeviceType() {
      final DamaskLayer layer = getLayer();
      if (layer != null) {
         return layer.getDeviceType();
      }
      else {
         return null;
      }
   }

   /**
    * Returns whether the contents of the page views within this dialog view
    * are selectable or unselectable.
    */ 
   public boolean isContentsSelectable() {
      return pageContentsSelectable;
   }

   /**
    * Makes the contents of the page views within this dialog view either
    * selectable or unselectable.
    */ 
   public void setContentsSelectable(final boolean selectable) {
      pageContentsSelectable = selectable;
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PageView pView = (PageView)i.next();
         pView.setContentsSelectable(selectable);
      }
   }

   /**
    * Returns the current design-time condition of this dialog view.
    */
   public int getDesignTimeCondition() {
      return designTimeCondition;
   }

   /**
    * Sets the current design-time condition of this dialog view.
    * 
    * @throws IllegalArgumentException if the specified condition is greater
    * than or equal to the number of conditions of the underlying page model  
    */
   private void setDesignTimeCondition(final int condition) {
      final Dialog dialog = (Dialog)getModel();
      if (condition >= dialog.getNumConditions()) {
         throw new IllegalArgumentException();
      }
      designTimeCondition = condition;

      // Change the state of the control views within this page view to the
      // proper state for the specified condition.
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode child = (PNode)i.next();
         if (child instanceof PageView) {
            final PageView pageView = (PageView)child;
            pageView.setDesignTimeCondition(condition);
         }
      }
   }


   /**
    * Called when the device-type layer of a layer is changed. 
    */
   public void deviceTypeLayerChanged() {
      for (Iterator i = getChildrenIterator(); i.hasNext(); ) {
         final PNode dialogChild = (PNode)i.next();
         if (dialogChild instanceof PageView) {
            ((PageView)dialogChild).deviceTypeLayerChanged();
         }
      }
   }

   /**
    * Listens for events from the dialog's model. 
    */
   private final class DialogHandler
      implements
         ElementContainerListener,
         DialogListener,
         InteractionElementListener {

      public void elementAdded(ElementContainerEvent e) {
         if (e.getElement() instanceof Page) {
            final Page p = (Page)e.getElement();
            if (p.getDeviceType() == getDeviceType()) {
               addChild(new PageView(p));
            }
         }
      }

      public void elementRemoved(ElementContainerEvent e) {
         if (e.getElement() instanceof Page) {
            final Page p = (Page)e.getElement();
            if (p.getDeviceType() == getDeviceType()) {
               for (Iterator i =
                    new ArrayList/*<PNode>*/(getChildrenReference()).iterator();
                    i.hasNext(); ) {
                  final PNode n = (PNode)i.next();
                  if (n instanceof PageView) {
                     final PageView pageView = (PageView)n;
                     if (pageView.getModel() == p) {
                        removeChild(pageView);
                        pageView.dispose();
                     }
                  }
               }
            }
         }
      }

      public void elementBoundsUpdated(InteractionElementEvent e) {
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }

      public void initialConditionChanged(DialogEvent e) {
         setDesignTimeCondition(((Integer)e.getValue()).intValue());
      }
   }
}
