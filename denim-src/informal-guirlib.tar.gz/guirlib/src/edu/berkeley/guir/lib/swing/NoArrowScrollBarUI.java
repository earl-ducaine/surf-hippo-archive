package edu.berkeley.guir.lib.swing;

import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.JScrollBar;
import java.awt.Insets;
import java.awt.Dimension;


/**
 * A ScrollBarUI which doesn't have arrows
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 *
 * @author  Katie Everitt (
 *          <A HREF="mailto:everitt@cs.berkeley.edu">everitt@cs.berkeley.edu</A> )
 * @since   JDK 1.3.1
 * Oct 9 2001
 */

// is a ScrollBarUI, which is a ComponentUI
public class NoArrowScrollBarUI extends BasicScrollBarUI {


	public void installDefaults(){

	super.installDefaults();
	scrollbar.remove(incrButton);
	scrollbar.remove(decrButton);

	}


	/* Hides the dark highlight when you click on the side of a scrollbar */
	protected void configureScrollBarColors()
	{
		super.configureScrollBarColors();
		trackHighlightColor = trackColor;
    }


	/*protected void layoutHScrollbar(JScrollBar sb) {
		super.layoutHScrollbar(sb);
		Insets sbInsets = sb.getInsets();
        Dimension sbSize = sb.getSize();
        int sbInsetsW = sbInsets.left + sbInsets.right;
        int sbInsetsH = sbInsets.top + sbInsets.bottom;
        float trackW = sbSize.width - sbInsetsW;
        float trackH = sbSize.height - sbInsetsH;
 		trackRect.setBounds(sbInsets.left, sbInsets.top, (int)trackW, (int)trackH);

        float min = sb.getMinimum();
        float extent = sb.getVisibleAmount();
        float range = sb.getMaximum() - min;
        float value = sb.getValue();

        int thumbW = (range <= 0)
	    ? getMaximumThumbSize().width : (int)(trackW * (extent / range));
        thumbW = Math.max(thumbW, getMinimumThumbSize().width);
        thumbW = Math.min(thumbW, getMaximumThumbSize().width);

	int thumbX = sbInsets.right - thumbW;
	if (sb.getValue() < (sb.getMaximum() - sb.getVisibleAmount())) {
	    float thumbRange = trackW - thumbW;
	    thumbX = (int)(0.5f + (thumbRange * ((value - min) / (range - extent))));
	}

	// Make sure the thumb fits between the buttons.  Note
	// that setting the thumbs bounds causes a repaint.
	//
	if (thumbW >= (int)trackW) {
	    setThumbBounds(0, 0, 0, 0);
	}
	else {
	    if (thumbX + thumbW > trackW) {
		thumbX = (int)trackW- thumbW;
	    }
	    if (thumbX  < sbInsets.left) {
		thumbX = sbInsets.left + 1;
	    }
	    setThumbBounds(thumbX, sbInsets.top, thumbW, (int)trackH);
	}


	} */



	protected void layoutHScrollbar(JScrollBar sb)
	    {
	        Dimension sbSize = sb.getSize();
	        Insets sbInsets = sb.getInsets();

		/* Height and top edge of the buttons and thumb.
		 */
		int itemH = sbSize.height - (sbInsets.top + sbInsets.bottom);
		int itemY = sbInsets.top;

	        /* Nominal locations of the buttons, assuming their preferred
		 * size will fit.
		 */
	        int decrButtonW = 0; //decrButton.getPreferredSize().width;  *** THE CHANGE IS HERE ***
	        int decrButtonX = sbInsets.left;

	        int incrButtonW = 0; //incrButton.getPreferredSize().width;  *** AND HERE ***
	        int incrButtonX = sbSize.width - (sbInsets.right + incrButtonW);

	        /* The thumb must fit within the width left over after we
		 * subtract the preferredSize of the buttons and the insets.
		 */
	        int sbInsetsW = sbInsets.left + sbInsets.right;
	        int sbButtonsW = decrButtonW + incrButtonW;
	        float trackW = sbSize.width - (sbInsetsW + sbButtonsW);

	        /* Compute the width and origin of the thumb.  Enforce
		 * the thumbs min/max dimensions.  The case where the thumb
		 * is at the right edge is handled specially to avoid numerical
		 * problems in computing thumbX.  If the thumb doesn't
		 * fit in the track (trackH) we'll hide it later.
		 */
	        float min = sb.getMinimum();
	        float extent = sb.getVisibleAmount();
	        float range = sb.getMaximum() - min;
	        float value = sb.getValue();

	        int thumbW = (range <= 0)
		    ? getMaximumThumbSize().width : (int)(trackW * (extent / range));
	        thumbW = Math.max(thumbW, getMinimumThumbSize().width);
	        thumbW = Math.min(thumbW, getMaximumThumbSize().width);

		int thumbX = incrButtonX - thumbW;
		if (sb.getValue() < (sb.getMaximum() - sb.getVisibleAmount())) {
		    float thumbRange = trackW - thumbW;
		    thumbX = (int)(0.5f + (thumbRange * ((value - min) / (range - extent))));
		    thumbX +=  decrButtonX + decrButtonW;
		}

	        /* If the buttons don't fit, allocate half of the available
	         * space to each and move the right one (incrButton) over.
	         */
	        int sbAvailButtonW = (sbSize.width - sbInsetsW);
	        if (sbAvailButtonW < sbButtonsW) {
	            incrButtonW = decrButtonW = sbAvailButtonW / 2;
	            incrButtonX = sbSize.width - (sbInsets.right + incrButtonW);
	        }

	        decrButton.setBounds(decrButtonX, itemY, decrButtonW, itemH);
	        incrButton.setBounds(incrButtonX, itemY, incrButtonW, itemH);

		/* Update the trackRect field.
		 */
		int itrackX = decrButtonX + decrButtonW;
		int itrackW = incrButtonX - itrackX;
		trackRect.setBounds(itrackX, itemY, itrackW, itemH);

		/* Make sure the thumb fits between the buttons.  Note
		 * that setting the thumbs bounds causes a repaint.
		 */
		if (thumbW >= (int)trackW) {
		    setThumbBounds(0, 0, 0, 0);
		}
		else {
		    if (thumbX + thumbW > incrButtonX) {
			thumbX = incrButtonX - thumbW;
		    }
		    if (thumbX  < decrButtonX + decrButtonW) {
			thumbX = decrButtonX + decrButtonW + 1;
		    }
		    setThumbBounds(thumbX, itemY, thumbW, itemH);
		}
	    }


 protected void layoutVScrollbar(JScrollBar sb)
    {
        Dimension sbSize = sb.getSize();
        Insets sbInsets = sb.getInsets();

	/*
	 * Width and left edge of the buttons and thumb.
	 */
	int itemW = sbSize.width - (sbInsets.left + sbInsets.right);
	int itemX = sbInsets.left;

        /* Nominal locations of the buttons, assuming their preferred
	 * size will fit.
	 */
        int decrButtonH = 0;//decrButton.getPreferredSize().height; *** THE CHANGE IS HERE ***
        int decrButtonY = sbInsets.top;

        int incrButtonH = 0;//incrButton.getPreferredSize().height; *** AND HERE ***
        int incrButtonY = sbSize.height - (sbInsets.bottom + incrButtonH);

        /* The thumb must fit within the height left over after we
	 * subtract the preferredSize of the buttons and the insets.
	 */
        int sbInsetsH = sbInsets.top + sbInsets.bottom;
        int sbButtonsH = decrButtonH + incrButtonH;
        float trackH = sbSize.height - (sbInsetsH + sbButtonsH);

        /* Compute the height and origin of the thumb.   The case
	 * where the thumb is at the bottom edge is handled specially
	 * to avoid numerical problems in computing thumbY.  Enforce
	 * the thumbs min/max dimensions.  If the thumb doesn't
	 * fit in the track (trackH) we'll hide it later.
	 */
	float min = sb.getMinimum();
	float extent = sb.getVisibleAmount();
	float range = sb.getMaximum() - min;
	float value = sb.getValue();

        int thumbH = (range <= 0)
	    ? getMaximumThumbSize().height : (int)(trackH * (extent / range));
	thumbH = Math.max(thumbH, getMinimumThumbSize().height);
	thumbH = Math.min(thumbH, getMaximumThumbSize().height);

	int thumbY = incrButtonY - thumbH;
	if (sb.getValue() < (sb.getMaximum() - sb.getVisibleAmount())) {
	    float thumbRange = trackH - thumbH;
	    thumbY = (int)(0.5f + (thumbRange * ((value - min) / (range - extent))));
	    thumbY +=  decrButtonY + decrButtonH;
	}

        /* If the buttons don't fit, allocate half of the available
	 * space to each and move the lower one (incrButton) down.
	 */
        int sbAvailButtonH = (sbSize.height - sbInsetsH);
        if (sbAvailButtonH < sbButtonsH) {
            incrButtonH = decrButtonH = sbAvailButtonH / 2;
            incrButtonY = sbSize.height - (sbInsets.bottom + incrButtonH);
        }
        decrButton.setBounds(itemX, decrButtonY, itemW, decrButtonH);
        incrButton.setBounds(itemX, incrButtonY, itemW, incrButtonH);

	/* Update the trackRect field.
	 */
	int itrackY = decrButtonY + decrButtonH;
	int itrackH = incrButtonY - itrackY;
	trackRect.setBounds(itemX, itrackY, itemW, itrackH);

	/* If the thumb isn't going to fit, zero it's bounds.  Otherwise
	 * make sure it fits between the buttons.  Note that setting the
	 * thumbs bounds will cause a repaint.
	 */
	if(thumbH >= (int)trackH)	{
	    setThumbBounds(0, 0, 0, 0);
	}
	else {
	    if ((thumbY + thumbH) > incrButtonY) {
		thumbY = incrButtonY - thumbH;
	    }
	    if (thumbY  < (decrButtonY + decrButtonH)) {
		thumbY = decrButtonY + decrButtonH + 1;
	    }
	    setThumbBounds(itemX, thumbY, itemW, thumbH);
	}
    }
}

/*
  Copyright (c) 2004 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
