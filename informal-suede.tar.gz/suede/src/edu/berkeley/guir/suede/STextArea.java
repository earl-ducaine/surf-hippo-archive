package edu.berkeley.guir.suede;

import java.awt.*;

public class STextArea extends javax.swing.JTextArea
{
    private static final Insets INSETS = new Insets(0,6,0,6);
    
    private Shape bgShape;
    private Color stroke;
    
	public STextArea(Shape shape)
	{
        bgShape = shape;
        setBounds(bgShape.getBounds());
        setOpaque(false);
        setBorder(javax.swing.BorderFactory.createEmptyBorder());
	}

    public void setStroke(Color c) {
        stroke = c;
    }

    public Insets getInsets() {
        return INSETS;   
    }
    
    public void setShape(Shape shape) {
        bgShape = shape;
        setBounds(bgShape.getBounds());
    }

    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D)g;
        g2d.setColor(Color.white);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.fill(bgShape);
        g2d.setColor(stroke);
        g2d.draw(bgShape);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        //System.out.println("col width: "+ super.getColumnWidth()); //width in pixels of the m character
        //System.out.println("row height: "+ super.getRowHeight()); //height in pixels of the font, including leading
        super.paintComponent(g);
    }

}