package edu.berkeley.guir.damask.view.pattern;

import java.io.*;
import java.net.URL;
import java.util.*;
import java.util.logging.Logger;

import org.jdom.*;
import org.jdom.input.SAXBuilder;

import edu.berkeley.guir.damask.pattern.Pattern;
import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;

/**
 * Searches a set of patterns for a given keyword.
 *  
 * <P>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * @author Qing Li
 * @author <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */
public class PatternsSearcher {
   //main variables
   private URL patternsListURL;
   private File xmlfile;
   private Document doc;
   private Element root;
   private String patternID;
   private String collectionID;

   //list variables
   private List imagelinks = new LinkedList();
   private List cpattlinks = new LinkedList();
   private List rpattlinks = new LinkedList();
   //string content variables;
   private String name;
   private String problem = "";
   private String context = "";
   private String solution = "";
   private String diagram = "";
   private String illustration = "";
   private String relatedpatterns = "";
   private String credits = "";

   private static final Logger logger =
      Logger.getLogger(PatternsSearcher.class.getName());

   /**
    * Sets the set of patterns to search over to the patterns listed within
    * the file at the specified URL.
    */
   public PatternsSearcher(final URL patternsListURL) {
      this.patternsListURL = patternsListURL;
   }

   /**
    * Sets the set of patterns to search over to the patterns listed within
    * the file at the specified URL.
    */
   public void setPatternsList(final URL patternsListURL) {
      clearAll();
      this.patternsListURL = patternsListURL;
   }

   /**
    * Searches patterns for the specified search term.
    */
   public List/*<String>*/ searchPatterns(String keyString) {
      final List results = new ArrayList();

      keyString = keyString.trim();
      if (keyString.length() == 0) {
         return results;
      }

      // Parse key string into list of key strings
      // For example, "shopping cart" checkout is parsed into
      // ["shopping cart", "checkout"]
      final List keyStrings = new ArrayList();
      boolean insideQuote = false;
      StringBuffer sb = new StringBuffer();
      for (int i = 0, n = keyString.length(); i < n; i++) {
         final char c = keyString.charAt(i);
         if (insideQuote) {
            if (c == '\"') {
               insideQuote = false;
               keyStrings.add(sb.toString());
               sb = new StringBuffer();
            }
            else {
               sb.append(c);
            }
         }
         else {
            if (c == '\"') {
               insideQuote = true;
            }
            else if (Character.isWhitespace(c)) {
               if (sb.length() != 0) {
                  keyStrings.add(sb.toString());
                  sb = new StringBuffer();
               }
            }
            else {
               sb.append(c);
            }
         }
      }
      if (sb.length() != 0) {
         keyStrings.add(sb.toString());
      }

      try {
         final BufferedReader buffreader = new BufferedReader(
               new InputStreamReader(patternsListURL.openStream()));
         String fileline;
         while ((fileline = buffreader.readLine()) != null) {
            SAXBuilder builder = new SAXBuilder();
            doc = builder.build(Pattern.class.getResource(fileline));
            root = doc.getRootElement();
            fillAttributes(root);
            searchForString(keyStrings, results);
            clearAll();
         }
      }
      catch (FileNotFoundException fnfe) {
         DamaskAppExceptionHandler.log(fnfe);
      }
      catch (JDOMException e) {
         //TODO change
         logger.severe(xmlfile + " is not well-formed.");
         DamaskAppExceptionHandler.log(e);
      }
      catch (IOException e) {
         //TODO change
         DamaskAppExceptionHandler.log(e);
      }
      return results;
   }

   private void clearAll() {
      imagelinks.clear();
      cpattlinks.clear();
      rpattlinks.clear();
      problem = "";
      context = "";
      solution = "";
      diagram = "";
      illustration = "";
      relatedpatterns = "";
      credits = "";
   }

   private void fillAttributes(Element element) {
      final String elementName = element.getName();
      if (elementName.equals("name")) {
         name = element.getText();
      }
      else if (elementName.equals("pattern")) {
         patternID = element.getAttributeValue("patternID");
         collectionID = element.getAttributeValue("collectionID");
      }
      else if (elementName.equals("illustration")) {
         List illuList = element.getContent();
         illustration = listToString(illuList, illustration).trim() + "\n";
      }
      else if (elementName.equals("problem")) {
         List probList = element.getContent();
         problem = listToString(probList, problem).trim() + "\n";
      }
      else if (elementName.equals("context")) {
         List contList = element.getContent();
         context = listToString(contList, context).trim() + "\n";
      }
      else if (elementName.equals("solution")) {
         List soluList = element.getContent();
         solution = listToString(soluList, solution).trim() + "\n";
      }
      else if (elementName.equals("diagram")) {
         List diagList = element.getContent();
         diagram = listToString(diagList, diagram).trim() + "\n";
      }
      else if (elementName.equals("related-patterns")) {
         List pattList = element.getContent();
         relatedpatterns = listToString(pattList, relatedpatterns).trim()
               + "\n";
      }
      else if (elementName.equals("credits")) {
         List credList = element.getContent();
         credits = listToString(credList, credits).trim() + "\n";
      }
      List children = element.getChildren();
      Iterator iterator = children.iterator();
      while (iterator.hasNext()) {
         Element child = (Element) iterator.next();
         fillAttributes(child);
      }
   }

   private String listToString(List l, String s) {
      Iterator iterator = l.iterator();
      while (iterator.hasNext()) {
         Object obj = iterator.next();
         if (obj instanceof Text) {
            s = s + ((Text) obj).getText();
         }
         else if (obj instanceof Element) {
            s = s + ((Element) obj).getText();
         }
      }
      return s;
   }

   private String getSearchResultString(final String sectionName) {
      return
         "<a href=\"" +
         PatternBrowser.createPatternLinkURLString(collectionID, patternID) +
         "\">" + name + "</a> - " + sectionName;
   }

   private void searchForString(final List/* <String> */keyStrings,
         final String section, final String sectionName,
         final List/* <String> */results) {

      final String sectionLowerCase = section.toLowerCase();
      boolean found = true;

      for (Iterator i = keyStrings.iterator(); i.hasNext();) {
         final String keyString = (String) i.next();
         final String keyStringLowerCase = keyString.toLowerCase();
         if (sectionLowerCase.indexOf(keyStringLowerCase) < 0) {
            found = false;
         }
      }
      if (found) {
         results.add(getSearchResultString(sectionName));
      }
   }

   private void searchForString(final List/*<String>*/ keyStrings,
         final List/*<String>*/ results) {

      searchForString(keyStrings, name, "Name", results);
      searchForString(keyStrings, illustration, "Illustration", results);
      searchForString(keyStrings, context, "Background", results);
      searchForString(keyStrings, problem, "Problem", results);
      searchForString(keyStrings, solution, "Solution", results);
      searchForString(keyStrings, diagram, "Solution", results);
      searchForString(keyStrings, relatedpatterns, "Related Patterns", results);
      searchForString(keyStrings, credits, "Credits", results);
   }

}