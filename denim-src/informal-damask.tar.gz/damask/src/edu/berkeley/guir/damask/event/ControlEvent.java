package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.component.Control;

/** 
 * An event that indicates a change to a control.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-01-2004 James Lin
 *                               Created ControlEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-01-2004
 */
public class ControlEvent extends EventObject {
   
   private final Type eventType;
   private final DeviceType deviceType;
   
   //===========================================================================

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type STATE_CHANGED =
      new Type("control's state changed");
   public static final Type SIGNIFICANCE_CHANGED =
      new Type("significance of control's state changed");
   public static final Type PAGE_REGION_CHANGED =
      new Type("control's page region changed");

   //===========================================================================

   /**
    * Constructs a ControlEvent.
    * 
    * @param source the control that is affected
    */
   public ControlEvent(
      final InteractionElement source,
      final Type eventType,
      final DeviceType deviceType) {

      super(source);
      this.eventType = eventType;
      this.deviceType = deviceType;
   }
   
   //===========================================================================

   /**
    * Returns the originator of the event.
    * 
    * @return the Control object that originated the event, or
    * null if the object is not a Control.
    */
   public Control getControl() {
      if (source instanceof Control) {
         return (Control)source;
      }
      else {
         return null;
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the device type associated with this event.
    */
   public DeviceType getDeviceType() {
      return deviceType;
   }
}
