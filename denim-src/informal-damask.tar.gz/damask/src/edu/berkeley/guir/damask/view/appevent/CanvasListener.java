package edu.berkeley.guir.damask.view.appevent;

import java.util.EventListener;

/** 
 * The listener interface for receiving events indicating that a canvas
 * has been changed.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-11-2004 James Lin
 *                               Created CanvasListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 01-11-2004
 */
public interface CanvasListener extends EventListener {
   
   /**
    * Invoked when the selection objects in a canvas has changed.
    */
   void selectionChanged(CanvasEvent e);
   
   /**
    * Invoked when the selected page in a canvas has changed.
    */
   void selectedPageChanged(CanvasEvent e);
}
