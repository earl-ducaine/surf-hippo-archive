//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.objects;

import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.collection.*;
import edu.berkeley.guir.lib.satin.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.util.*;
import edu.berkeley.guir.lib.satin.watch.*;

/**
 * A Group of Graphical objects. Unlike GraphicalObjectCollections,
 * GraphicalObjectGroups can be rendered on screen. 
 *
 * <P>
 * If you subclass this class, be sure to implement deep-clone chaining by
 * overriding {@link #deepClone()}. This is necessary for copy /
 * cut / paste to work in Satin. Deep-clone chaining is essentially the same 
 * as {@link GraphicalObjectImpl#clone(GraphicalObjectImpl) clone chaining}.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 * 
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Oct 06 1998, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-1.1.0, Feb 26 2001, JL
 *               * Changed return type of getRelativeLayer() from String to int
 *               * Changed return type of getAbsoluteLayer() from String to
 *                 List of Integers
 * 			   - SATIN-v2.1-2.0.0, Nov 21, 2002, YL
 * 				 Enabled event dispatching cache
 *            - SATIN-v2.1-2.0.0, Mar 29, 2003, YL
 *              Added removeSilently and removeAllSilently
 * 			  - SATIN-v2.1-2.0.0, Mar 29, 2003, YL
 * 				 Added to implement SwingPeerContainer
 * 				 
 * 	 
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2
 * @version SATIN-v2.1-2.0.0, Mar 29, 2003
 */
public class GraphicalObjectGroupImpl
	extends    GraphicalObjectImpl
	implements GraphicalObjectGroup,
				  GraphicalObjectCollection,  //// <- for JavaDoc purposes
				  GraphicalObject, 
				  Watchable,
				  Watcher,
				  Shape,
				  StrokeListener,
				  SwingPeerContainer {

	//===========================================================================
	//===   CLASS VARIABLES   ===================================================

	static final long serialVersionUID = -2021211329861762769L;

	//-----------------------------------------------------------------

	//// Strategy classes for stroke dispatching.
	//// The implementations for these were so similar I decided to
	//// abstract them out a little more.
	static DispatchNewStrategy    dispatchNew    = new DispatchNewStrategy();
	static DispatchUpdateStrategy dispatchUpdate = new DispatchUpdateStrategy();
	static DispatchSingleStrategy dispatchSingle = new DispatchSingleStrategy();

	//-----------------------------------------------------------------

	//// Strategy classes for how Graphical Objects are retrieved.
	static GetType getTypeContainedBy = new GetTypeContainedBy();
	static GetType getTypeContains    = new GetTypeContains();
	static GetType getTypeIntersects  = new GetTypeIntersects();

	//===   CLASS VARIABLES   ===================================================
	//===========================================================================



	//===========================================================================
	//===   DELEGATION INNER CLASSES   ==========================================

	/**
	 * Specifies how strokes are handled internally.
	 */
	final class InternalInteractionHandler
		extends InteractionHandler {

		public InternalInteractionHandler() {
			super(GraphicalObjectGroupImpl.this);
		} // of default constructor

		//--------------------------------------------------------------
      
		public InternalInteractionHandler(InternalInteractionHandler handler) {
			super(handler);
		}
      
		//--------------------------------------------------------------

		public void redispatchNewStroke(NewStrokeEvent evt) {
			onStroke(evt, dispatchNew);
		} // of redispatchNewStroke

		//--------------------------------------------------------------

		public void redispatchUpdateStroke(UpdateStrokeEvent evt) {
			onStroke(evt, dispatchUpdate);
		} // of redispatchUpdateStroke

		//--------------------------------------------------------------

		public void redispatchSingleStroke(SingleStrokeEvent evt) {
			//debug.println("internal redispatchSingleStroke: " + GraphicalObjectLib.toShortString(attach));
			onStroke(evt, dispatchSingle);
		} // of redispatchSingleStroke

		//--------------------------------------------------------------
      
		private void onStroke(StrokeEvent evt, DispatchStrategy strategy) {
         
			TimedStroke     stk    = evt.getStroke();
         
			GraphicalObject gob = null;
         
//			  if(stk.getNumPoints()==1)
		 if(evt instanceof NewStrokeEvent)
			{
    
				gob = getDispatchee(stk);
				evt.appendDispatchee(gob);
    
			}
			else
			{
   
				gob = getCachedDispatchee(evt);
   
				if (gob!=null)
				{
					if(!gob.shapeContains(stk)) {
						evt.removeDispatchee(gob);
					  gob = null;
					}
				}
			}
         

		////2.1
			
		  if (gob != null) {
				//// 2.2. Now dispatch, letting the strategy object handle the
				////      specifics of which method is called.
			 strategy.redispatch(gob, evt);
		  }

		} // of onStroke

		//===========================================================================
		//===   CLONE   =============================================================

		public Object clone() {
			return (new InternalInteractionHandler(this));
		} // of clone

		//===   CLONE   =============================================================
		//===========================================================================
	} // of inner class InternalInteractionHandler

	//===========================================================================

	abstract static class DispatchStrategy {
		public abstract void redispatch(GraphicalObject gob, SatinEvent evt);
	} // of inner class Dispatch

	//-----------------------------------------------------------------

	static final class DispatchNewStrategy extends DispatchStrategy {
		public void redispatch(GraphicalObject gob, SatinEvent evt) {
			 gob.onNewStroke((NewStrokeEvent) evt);
		} // of redispatch
	} // of inner class DispatchNewStrategy 

	//-----------------------------------------------------------------

	static final class DispatchUpdateStrategy extends DispatchStrategy {
		public void redispatch(GraphicalObject gob, SatinEvent evt) {
//				System.out.println("redispatching to: " + GraphicalObjectLib.toShortString(gob));
			 gob.onUpdateStroke((UpdateStrokeEvent) evt);
		} // of redispatch
	} // of inner class DispatchUpdateStrategy 

	//-----------------------------------------------------------------

	static final class DispatchSingleStrategy extends DispatchStrategy {
		public void redispatch(GraphicalObject gob, SatinEvent evt) {
			//debug.println("redispatching to: " + GraphicalObjectLib.toShortString(gob));
			gob.onSingleStroke((SingleStrokeEvent) evt);
		} // of redispatch
	} // of inner class DispatchSingleStrategy 

	//===   DELEGATION INNER CLASSES   ==========================================
	//===========================================================================



	//===========================================================================
	//===   NONLOCAL VARIABLES   ================================================

	//// Our collection of contained GraphicalObjects.
	//// GraphicalObjects near the front are at the top, while
	//// GraphicalObjects near the end are at the bottom.
	GraphicalObjectCollectionImpl gobcol = new GraphicalObjectCollectionImpl();

	//// flag for whether to ignore messages from children when they are deleted
	//// this flag is true when the parent wants to delete its children but
	//// also wants to ignore their delete messages, to avoid a circular
	//// notification loop
	private boolean ignoreChildDelete = false;
   
	//// see getAllowDeepGet and setAllowDeepGet
	private boolean allowDeepGet = true;

	//===   NONLOCAL VARIABLES   ================================================
	//===========================================================================



	//===========================================================================
	//===   PROTECTED METHODS FOR ACCESSING HANDLERS   ==========================

	/**
	 * Create an InteractionHandler for Graphical Object Groups.
	 */
	protected InteractionHandler createNewInteractionHandler() {
		return(new InternalInteractionHandler());
	} // of method

	//===   PROTECTED METHODS FOR ACCESSING HANDLERS   ==========================
	//===========================================================================



	//===========================================================================
	//===   COLLECTION METHODS   ================================================

	/**
	 * This adds a GraphicalObject to the top of the group, keeping its relative
	 * coordinates the same.
	 *
	 * @see   GraphicalObjectGroup#KEEP_REL_POS
	 * @param gob is a GraphicalObject whose coordinates have already
	 *            been transformed to this group's coordinate system.
	 */
	public GraphicalObject add(GraphicalObject gob) {
		return (addToFront(gob));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * This adds a GraphicalObject to the bottom of the group, keeping its
	 * relative coordinates the same.
	 *
	 * @see   GraphicalObjectGroup#KEEP_REL_POS
	 * @param gob is a GraphicalObject whose coordinates have already
	 *            been transformed to this group's coordinate system.
	 */
	public GraphicalObject addToBack(GraphicalObject gob) {
		return (add(gobcol.numElements(), gob));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * This adds a GraphicalObject to the top of the group, keeping its relative
	 * coordinates the same.
	 *
	 * @see   GraphicalObjectGroup#KEEP_REL_POS
	 * @param gob is a GraphicalObject whose coordinates have already
	 *            been transformed to this group's coordinate system.
	 */
	public GraphicalObject addToFront(GraphicalObject gob) {
		return (add(0, gob));
	} // of method
   
	//-----------------------------------------------------------------

	/**
	 * This adds a GraphicalObject to the group at the specified layer, keeping
	 * its relative coordinates the same.
	 *
	 * @see   GraphicalObjectGroup#KEEP_REL_POS
	 * @param index is the layer to add the GraphicalObject to. Lower numbers
	 *              indicate the front (higher layers), while higher numbers 
	 *              indicate the back (lower layers).
	 * @param gob   is a GraphicalObject whose coordinates have already
	 *              been transformed to this group's local coordinate system.
	 */
	public GraphicalObject add(int index, GraphicalObject gob) {
		return (add(index, gob, DEFAULT_POS_POLICY));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject add(GraphicalObject gob, int pos) {
		return (addToFront(gob, pos));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject addToBack(GraphicalObject gob, int pos) {
		return (add(gobcol.numElements(), gob, pos));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject addToFront(GraphicalObject gob, int pos) {
		return (add(0, gob, pos));
	} // of method

	//-----------------------------------------------------------------
   
	/**
	 * Calls initAfterAddToSheet() on gob and all of gob's descendants.
	 */
	private void callInitAfterAddToSheet(GraphicalObject gob) {
		gob.initAfterAddToSheet();
		if (gob instanceof GraphicalObjectGroup) {
			GraphicalObjectGroup grp = (GraphicalObjectGroup)gob;
			Iterator it = grp.getForwardIterator();
			while (it.hasNext()) {
				GraphicalObject child = (GraphicalObject)it.next();
				callInitAfterAddToSheet(child);
			}
		}
	}

	//-----------------------------------------------------------------
   
	public GraphicalObject add(int index, GraphicalObject gob, int pos) {

        this.getRenderCache().setCacheInvalide();
        
		//// 0. Disable notifying others of transformations.
		gob.disableNotify();
		gob.disableDamage();

		//// 1. Convert the coordinates of the Graphical Object to 
		////    be local to this group.
		if (pos == KEEP_ABS_POS) {
			GraphicalObjectLib.toLocalCoordinates(gob, this);
		}

		//// 2. Set the parent, add self as a watcher for changes (observer).
		gob.setParentGroup(this);
		gob.addWatcher(this);

		//// 3. Add the Graphical Object.
		gobcol.add(index, gob);

		//// 4. Re-enable notifications.
		gob.enableNotify();
		gob.enableDamage();

		//// 5. Update the bounding points.
		updateGroupBounds(gob);

		//// 6. Tell the object that was just added that it has been added.
		gob.initAfterAdd();
		if (getSheet() != null) {
			callInitAfterAddToSheet(gob);
		}
      
		//// 7. Notify watchers of repaint.
		damage(DAMAGE_LATER, gob);

		return (gob);
	} // of method

	//-----------------------------------------------------------------

	public void clear() {
		//// 1. Get the current bounds.
		Rectangle2D bounds = getBounds2D(COORD_ABS);

		//// 2. Clear everything we have.
		gobcol.clear();

		//// 3. Update the bounding points.
		updateGroupBounds();

		//// 4. Notify watchers of repaint.
		damage(DAMAGE_LATER, bounds);
	} // of method

	//-----------------------------------------------------------------

	public boolean contains(GraphicalObject gob) {
		return (gobcol.contains(gob));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject get(int index) {
		return (gobcol.get(index));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject getFirst() {
		return (gobcol.getFirst());
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject getLast() {
		return (gobcol.getLast());
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObject getID(long id) {
		return (gobcol.getID(id));
	} // of method

	//-----------------------------------------------------------------

	public Rectangle2D getCollectionBounds2D(int cdsys) {
		return (gobcol.getCollectionBounds2D(cdsys));
	} // of method

	//-----------------------------------------------------------------

	public Rectangle2D getCollectionBounds2D(int cdsys, Rectangle2D rect) {
		return (gobcol.getCollectionBounds2D(cdsys, rect));
	} // of method

	//-----------------------------------------------------------------

	public int indexOf(GraphicalObject gob) {
		return (gobcol.indexOf(gob));
	} // of method

	//-----------------------------------------------------------------

	public boolean isEmpty() {
		return (gobcol.isEmpty());
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Actually does nothing, since the ordering is imposed by the Group.
	 * I suppose you could want to sort on things like color and size and so on.
	 */
	public void sort(Comparator c) {
		//// ignore
	} // of method

	//-----------------------------------------------------------------

	public int numElements() {
		return (gobcol.numElements());
	} // of method

	//-----------------------------------------------------------------
   
	public GraphicalObject removeSilently(GraphicalObject gob) {
      
		//// 0. If the group does not contain the object, just return.
		if (!this.contains(gob)) {
			return (gob);
		}
      
		//// 2. Remove the Graphical Object.
		gobcol.remove(gob);

		//// 4. Remove self as parent.
		gob.setParentGroup(null);
		gob.removeWatcher(this);

		return (gob);
      
	}
   
   
	//-----------------------------------------------------------------
   
	public GraphicalObject remove(GraphicalObject gob) {
		//// 0. If the group does not contain the object, just return.
		if (!this.contains(gob)) {
			return (gob);
		}
        
        this.getRenderCache().setCacheInvalide();
      
		//// 1. Get the current bounds.
		Rectangle2D bounds = getBounds2D(COORD_ABS);

		//// 2. Remove the Graphical Object.
		gobcol.remove(gob);

		//// 3. Update the bounding points.
		updateGroupBounds();

		//// 4. Remove self as parent.
		gob.setParentGroup(null);
		gob.removeWatcher(this);

		//// 5. Notify watchers of repaint.
		damage(DAMAGE_LATER, bounds);

		return (gob);
	} // of method

	//-----------------------------------------------------------------

	public Iterator getForwardIterator() {
		return (gobcol.getForwardIterator());
	} // of method

	//-----------------------------------------------------------------

	public Iterator getReverseIterator() {
		return (gobcol.getReverseIterator());
	} // of method

	//===   COLLECTION METHODS   ================================================
	//===========================================================================




	//===========================================================================
	//===   Location METHODS   ==================================================

	/**
	 * Specifies how bounds are updated when a Graphical Object is added.
	 */
	protected void updateGroupBounds(GraphicalObject gob) {
		//// A. Acquire soft-state objects.
		Rectangle2D oldBounds = (Rectangle2D) poolRects.getObject();
		Rectangle2D newBounds = (Rectangle2D) poolRects.getObject();

		//// 1. Get the old bounds.
		getBounds2D(COORD_ABS, null, oldBounds);
		gob.getBounds2D(COORD_ABS, null, newBounds);

		//// 2. Get the union if we have more than one item.
		////    If we only have one item, then use that as the bounds.
		if (numElements() > 1) {
			Rectangle2D.union(oldBounds, newBounds, newBounds);
		}

		//// 3. Proceed only if the bounds have been modified.
		double dw = Math.abs(newBounds.getWidth()  - oldBounds.getWidth());
		double dh = Math.abs(newBounds.getHeight() - oldBounds.getHeight());
		if (dw > FLOATING_PT_TOLERANCE || dh > FLOATING_PT_TOLERANCE) {
			AffineTransform oldTx = getTransform(COORD_REL);

			disableDamage();
			disableNotify();

			setBoundingPoints2D(COORD_ABS, newBounds);
			setTransform(oldTx);

			enableDamage();
			enableNotify();
		}

		//// B. Release soft-state objects.
		poolRects.releaseObject(oldBounds);
		poolRects.releaseObject(newBounds);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Recalculate all of the bounds for this group.
	 */
	protected void updateGroupBounds() {
		//// A. Acquire soft-state objects.
		Rectangle2D oldBounds = (Rectangle2D) poolRects.getObject();
		Rectangle2D newBounds = (Rectangle2D) poolRects.getObject();
		newBounds.setRect(0, 0, 0, 0);

		//// 1. Iterate over every contained object and get their bounds.
		Iterator        it = gobcol.getForwardIterator();
		GraphicalObject gob;

		if (it.hasNext()) {
			gob       = (GraphicalObject) it.next();
			oldBounds = gob.getBounds2D(COORD_ABS, null, oldBounds);
		}

		while (it.hasNext()) {
			gob       = (GraphicalObject) it.next();
			newBounds = gob.getBounds2D(COORD_ABS, null, newBounds);
			Rectangle2D.union(oldBounds, newBounds, oldBounds);
		}

		//// 2. Now set the bounds.
		AffineTransform oldTx = getTransform(COORD_REL);

		disableDamage();
		disableNotify();

		setBoundingPoints2D(COORD_ABS, newBounds);
		setTransform(oldTx);

		enableDamage();
		enableNotify();


		//// B. Release soft-state objects.
		poolRects.releaseObject(oldBounds);
		poolRects.releaseObject(newBounds);
	} // of method

	//===   Location METHODS   ==================================================
	//===========================================================================



	//===========================================================================
	//===   LAYER METHODS   =====================================================

	public int getRelativeLayer(GraphicalObject gob) {
		return gobcol.indexOf(gob);
	} // of method

	//-----------------------------------------------------------------

	public void setRelativeLayer(GraphicalObject gob, int layer) {
		//// 1. Do bounds checking first.
		if (layer < 0) {
			return;
		}

		//// 2.1. If the specified layer exceeds boundaries, just move to
		////      the back of the list.
		OrderedList list  = gobcol.getOrderedList();
		int         index = list.indexOf(gob);
		if (layer >= list.size()) {
			list.moveToBack(index);
		}
		//// 2.2. Otherwise, just move to the Location.
		else {
			list.moveTo(index, layer);
		}

		//// 3. Notify watchers of repaint.
		damage(DAMAGE_LATER, gob);
	} // of method

	//-----------------------------------------------------------------

	public List getAbsoluteLayer(GraphicalObject gob) {
		return (gob.getAbsoluteLayer());
	} // of method

	//-----------------------------------------------------------------

	public void bringUpALayer(GraphicalObject gob) {
		//// 0. Initializations.
		OrderedList list = gobcol.getOrderedList();
		int         pos  = gobcol.indexOf(gob);

		//// 1. Shift to left, since we draw from last element to first.
		list.swap(pos, pos - 1);

		//// 2. Notify watchers of repaint.
		damage(DAMAGE_LATER, gob);
	} // of method

	//-----------------------------------------------------------------

	public void bringUpNLayers(GraphicalObject gob, int n) {
		//// 0. Initializations.
		OrderedList list = gobcol.getOrderedList();
		int         pos  = gobcol.indexOf(gob);

		//// 1. Shift to left, since we draw from last element to first.
		////    Either we shift left n spaces (pos - n), or we move directly
		////    to top.
		list.moveTo(pos, Math.min(0, pos - n));

		//// 2. Notify watchers of repaint.
		damage(DAMAGE_LATER, gob);
	} // of method

	//-----------------------------------------------------------------

	public void bringDownALayer(GraphicalObject gob) {
		//// 0. Initializations.
		OrderedList list = gobcol.getOrderedList();
		int          pos = gobcol.indexOf(gob);

		//// 1. Shift to right, since we draw from last element to first.
		list.swap(pos, pos + 1);

		//// 2. Notify watchers of repaint.
		damage(DAMAGE_LATER, gob);
	} // of method

	//-----------------------------------------------------------------

	public void bringDownNLayers(GraphicalObject gob, int n) {
		//// 0. Initializations.
		OrderedList list = gobcol.getOrderedList();
		int         pos  = gobcol.indexOf(gob);

		//// 1. Shift to right, since we draw from last element to first.
		////    Either we shift right n spaces (pos + n), or we move directly
		////    to the end.
		list.moveTo(pos, Math.min(list.size() - 1, pos + n));

		//// 2. Notify watchers of repaint.
		damage(DAMAGE_LATER, gob);
	} // of method

	//-----------------------------------------------------------------

	public void bringToTopLayer(GraphicalObject gob) {
		//// 0. Initializations.
		OrderedList list = gobcol.getOrderedList();
		int         pos  = gobcol.indexOf(gob);

		//// 1. Shift to the front, the last element drawn.
		list.moveToFront(pos);

		//// 2. Notify watchers of repaint.
		damage(DAMAGE_LATER, gob);
	} // of method

	//-----------------------------------------------------------------

	public void bringToBottomLayer(GraphicalObject gob) {
		//// 0. Initializations.
		OrderedList list = gobcol.getOrderedList();
		int         pos  = gobcol.indexOf(gob);

		//// 1. Shift to the end, the lastelement drawn.
		list.moveToBack(pos);

		//// 2. Notify watchers of repaint.
		damage(DAMAGE_LATER, gob);
	} // of method

	//===   LAYER METHODS   =====================================================
	//===========================================================================

	//===========================================================================
	//===   MODIFIER METHODS   ==================================================

	public void removeAllSilently(GraphicalObjectCollection gobcol) {
		//// 1. Get the damage bounds.
		Iterator        it     = gobcol.getForwardIterator();
		GraphicalObject gob;

		while (it.hasNext()) {
			gob = (GraphicalObject) it.next();
			removeSilently(gob);
		}
	} // of method



	//===========================================================================
	//===   MODIFIER METHODS   ==================================================

	public void removeAll(GraphicalObjectCollection gobcol) {
        
        this.getRenderCache().setCacheInvalide();
        
		//// 1. Get the damage bounds.
		Rectangle2D     rect   = gobcol.getCollectionBounds2D(COORD_ABS);
		Iterator        it     = gobcol.getForwardIterator();
		GraphicalObject gob;

		while (it.hasNext()) {
			gob = (GraphicalObject) it.next();
			remove(gob);
		}

		damage(DAMAGE_LATER, rect);
	} // of method

	//===   MODIFIER METHODS   ==================================================
	//===========================================================================



	//===========================================================================
	//===   GROUP QUERY METHODS   ===============================================

	public boolean getAllowDeepGet() {
		return allowDeepGet;
	}
   
	//-----------------------------------------------------------------
   
	/**
	 * Set whether this group allows 
	 * {@link GraphicalObjectGroup#getGraphicalObjects(int,Point2D,int,int,int,double,GraphicalObjectCollection)}
	 * with depth set {@link SatinConstants#DEEP} to query this group's children.
	 */
	public void setAllowDeepGet(boolean flag) {
		allowDeepGet = flag;
	}
   
	//-----------------------------------------------------------------
   
	/**
	 * Helper method to handle the depth parameter for method 
	 * {@link GraphicalObjectGroup#getGraphicalObjects(int,Point2D,int,int,int,double,GraphicalObjectCollection)}
	 */
	private GraphicalObjectCollection handleDepth(int depth) {
		//// 1. If depth is DEEP, then flatten the current group (ie this).
		////    Otherwise, if SHALLOW, keep it as is.
		GraphicalObjectCollection search;
		switch (depth) {
			case DEEP:
				search = GraphicalObjectLib.flatten(this.gobcol);
				break;
			case SHALLOW:
				search = this.gobcol;
				break;
			default:
				throw new RuntimeException("Invalid depth parameter");
		}
		return (search);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Helper method to handle the get-type algorithm parameter for method 
	 * {@link GraphicalObjectGroup#getGraphicalObjects(int,Point2D,int,int,int,double,GraphicalObjectCollection)}
	 */
	private GetType handleGetTypeAlgorithm(int gettype) {
		GetType getalg = null;

		switch (gettype) {
			case INTERSECTS:
				getalg = getTypeIntersects;
				break;
			case CONTAINEDBY:
				getalg = getTypeContainedBy;
				break;
			case CONTAINS:  /* and case NEAR */
				getalg = getTypeContains;
				break;
			case ABOVE:
				throw new RuntimeException("Not implemented yet");
			case BELOW:
				throw new RuntimeException("Not implemented yet");
			default:
				throw new RuntimeException("Invalid get-type parameter");
		}

		return (getalg);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Helper method to handle the number parameter for method 
	 * {@link GraphicalObjectGroup#getGraphicalObjects(int,Point2D,int,int,int,double,GraphicalObjectCollection)}
	 */
	private GraphicalObjectCollection 
	handleNumber(GraphicalObjectCollection out, int num) {

		if (out.numElements() > 0) {
			switch (num) {
				case ALL:
					break;
				case FIRST:
					GraphicalObject gob;
					gob = GraphicalObjectLib.getTopmostLeaf(out);
					if (gob == null) {
						gob = GraphicalObjectLib.getTopmostBranch(out);
					}
					out.clear();
					out.add(gob);
					break;
				default:
					throw new RuntimeException("Invalid number-of-items parameter");
			}
		}

		return (out);
	} // of method

	//-----------------------------------------------------------------
   
	private void getDeepGraphicalObjects(Object ptOrShape,
													 GraphicalObject in,
													 double thresh,
													 GetType getalg,
													 GraphicalObjectCollection out) {
      
		// 1. Check if in meets the criteria.
		GraphicalObjectCollection inCol = new GraphicalObjectCollectionImpl();
		GraphicalObjectCollection outCol = new GraphicalObjectCollectionImpl();
		GraphicalObjectCollection recursiveSearch = new GraphicalObjectCollectionImpl();
      
		inCol.add(in);
      
		if (ptOrShape instanceof Point2D) {
			getalg.get((Point2D)ptOrShape, inCol, thresh, outCol);
		}
		else if (ptOrShape instanceof Shape) {
			getalg.get((Shape)ptOrShape, inCol, thresh, outCol);
		}
		else {
			// ptOrShape must be Point2D or Shape
			assert false; 
		}
      
		//// 1.1. If the algorithm is "Contained by", add any objects that
		////      intersect the given shape.
		if (getalg instanceof GetTypeContainedBy &&
			 in instanceof GraphicalObjectGroup) {
			if (ptOrShape instanceof Point2D) {
				getTypeIntersects.get((Point2D)ptOrShape, inCol, thresh, recursiveSearch);
			}
			else {
				getTypeIntersects.get((Shape)ptOrShape, inCol, thresh, recursiveSearch);
			}
		}
      
		// 2. If not, exit.
		if (outCol.isEmpty() && recursiveSearch.isEmpty()) {
			return;
		}
		// getalg.get is *messed up*
		assert !outCol.isEmpty() && outCol.get(0) == in;
      
		// 3. If so, then if in is a group...
		if (in instanceof GraphicalObjectGroup) {
			GraphicalObjectGroup inGrp = (GraphicalObjectGroup)in;
			int numOut = out.numElements();
         
			// 3.1. ...find out if any of in's children meet the criteria.
			if (inGrp.getAllowDeepGet() == true) {
				Iterator it = inGrp.getForwardIterator();
				while (it.hasNext()) {
					GraphicalObject gob = (GraphicalObject)it.next();
					getDeepGraphicalObjects(ptOrShape, gob, thresh, getalg, out);
				}
			}
         
			// 3.2. If not, add in.
			if (out.numElements() == numOut && !outCol.isEmpty()) {
				out.add(in);
			}
		}
      
		// 4. Otherwise, add in.
		else {
			if (!outCol.isEmpty()) {
				out.add(in);
			}
		}
	}
   
	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, Point2D pt, int num, int depth, int gettype,
							  double thresh, GraphicalObjectCollection out) {

		//// A. Get soft-state.
		Point2D ptTmp = (Point2D) poolPoints.getObject();

		//// 1. Create storage space if necessary.
		if (out == null) {
			out = new GraphicalObjectCollectionImpl();
		}

		//// 2. Fix the coordinate system for the point to absolute.
		switch (cdsys) {
			case COORD_ABS:
				ptTmp.setLocation(pt.getX(), pt.getY());
				break;
			case COORD_REL:
				AffineTransform tx = (AffineTransform) poolTx.getObject();
				if (this.getParentGroup() != null) {
					this.getParentGroup().getTransform(COORD_ABS, tx);
				}
				tx.transform(pt, ptTmp);
				poolTx.releaseObject(tx);
				break;
			case COORD_LOCAL:
				GraphicalObjectLib.localToAbsolute(this, pt, ptTmp);
				break;
			default:
				throw new RuntimeException("Invalid coordinate-system parameter");
		}

		//// 3. Retrieve using the threshold.
		GraphicalObjectCollection search = handleDepth(SHALLOW);
		GetType getalg = handleGetTypeAlgorithm(gettype);
		getalg.get(ptTmp, search, thresh, out);
            
		//// 4. If depth is DEEP, then recursively search the results for deeper
		////    graphical objects that meet the search criteria.
		if (depth == DEEP && getAllowDeepGet() == true) {
			GraphicalObjectCollection shallowOut =
				new GraphicalObjectCollectionImpl(out);
			out.clear();
			Iterator it = shallowOut.getForwardIterator();
         
			while (it.hasNext()) {
				GraphicalObject gob = (GraphicalObject)it.next();
				getDeepGraphicalObjects(ptTmp, gob, thresh, getalg, out);
			}
		}
		else {
			// Invalid depth parameter
			assert depth == SHALLOW;
		}

		//// 5. If num is FIRST, then get the "FIRST" object.
		////    Otherwise, if ALL, return all of them.
		out = handleNumber(out, num);

		//// B. Release soft-state.
		poolPoints.releaseObject(ptTmp);

		return (out);
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, double x, double y, int num, int depth, 
					 int gettype, double thresh, GraphicalObjectCollection out) {

		//// A. Acquire soft-state.
		Point2D pt = (Point2D) poolPoints.getObject();

		//// 1. Set the location and let's get the items there.
		GraphicalObjectCollection gobcol;

		pt.setLocation(x, y);
		gobcol = getGraphicalObjects(cdsys, pt, num, depth, gettype, thresh, out);

		//// B. Release soft-state.
		poolPoints.releaseObject(pt);

		return (gobcol);
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, Shape s, int num, int depth, int gettype,
							  double thresh, GraphicalObjectCollection out) {

		//// A. Acquire soft-state.
		Polygon2D       poly = (Polygon2D) poolPolys.getObject();
		AffineTransform tx   = (AffineTransform) poolTx.getObject();

		//// 1. Create storage space if necessary.
		if (out == null) {
			out = new GraphicalObjectCollectionImpl();
		}

		//// 2. Get the Polygon in absolute coordinates.
		switch (cdsys) {
			case COORD_ABS:
				break;
			case COORD_REL:
				if (this.getParentGroup() != null) {
					this.getParentGroup().getTransform(COORD_ABS, tx);
				}
				break;
			case COORD_LOCAL:
				getTransform(COORD_ABS, tx);
				break;
			default:
				throw new RuntimeException("Invalid coordinate-system parameter");
		}
		poly.setToPathIterator(s.getPathIterator(tx));

		//// 3. Retrieve using the threshold.
		GraphicalObjectCollection search = handleDepth(SHALLOW);
		GetType getalg = handleGetTypeAlgorithm(gettype);
		getalg.get(poly, search, thresh, out);
      
		//// 4. If depth is DEEP, then recursively search the results for
		////    deeper graphical objects that meet the search criteria.
		if (depth == DEEP && getAllowDeepGet() == true) {
			GraphicalObjectCollection shallowOut =
				new GraphicalObjectCollectionImpl(out);
			out.clear();
         
			//// 4.1. If the algorithm is "Contained by", add any objects that
			////      intersect the given shape.
			if (getalg instanceof GetTypeContainedBy) {
				getTypeIntersects.get(poly, search, thresh, shallowOut);
			}
      
			Iterator it = shallowOut.getForwardIterator();
         
			while (it.hasNext()) {
				GraphicalObject gob = (GraphicalObject)it.next();
				getDeepGraphicalObjects(poly, gob, thresh, getalg, out);
			}
		}
		else {
			// Invalid depth parameter
			assert depth == SHALLOW;
		}

		//// 5. If num is FIRST, then get the "FIRST" object.
		////    Otherwise, if ALL, return all of them.
		out = handleNumber(out, num);

		//// B. Release soft-state.
		poolPolys.releaseObject(poly);
		poolTx.releaseObject(tx);
      
		return (out);
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(GraphicalObject gob, int num, int depth, int gettype,
							  double thresh, GraphicalObjectCollection out) {

		//// A. Acquire soft-state.
		Polygon2D poly = (Polygon2D) poolPolys.getObject();

		//// 1. Get the bounds.
		GraphicalObjectCollection gobcol;

		gob.getBoundingPoints2D(COORD_ABS, null, poly);
		gobcol = getGraphicalObjects(COORD_ABS, poly, num, depth, gettype,
											  thresh, out);

		//// B. Release soft-state.
		poolPolys.releaseObject(poly);

		return (gobcol);
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, Point2D pt, int num, int depth, int gettype) {

		return (getGraphicalObjects(cdsys, pt, num, depth, gettype,
															DEFAULT_SELECT_THRESHOLD, null));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, double x, double y, int num, int depth, 
							  int gettype) {

		return (getGraphicalObjects(cdsys, x, y, num, depth, gettype,
															DEFAULT_SELECT_THRESHOLD, null));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(int cdsys, Shape s, int num, int depth, int gettype) {

		return (getGraphicalObjects(cdsys, s, num, depth, gettype,
															DEFAULT_SELECT_THRESHOLD, null));
	} // of method

	//-----------------------------------------------------------------

	public GraphicalObjectCollection
	getGraphicalObjects(GraphicalObject gob, int num, int depth, int gettype) {
               
		return (getGraphicalObjects(gob, num, depth, gettype,
															DEFAULT_SELECT_THRESHOLD, null));
	} // of method

	 /**
	  * Added by Shen for RadarView in Denim be able 
	  * to get the graphicalObjectCollection from 
	  * and calculate out the dimension
	  *
	  * @return a value of type 'GraphicalObjectCollection'
	  */
	 public GraphicalObjectCollection getGraphicalObjects(){
	return gobcol;
	 }

	//===   GROUP QUERY METHODS   ===============================================
	//===========================================================================



	//===========================================================================
	//===   WATCH METHODS   =====================================================

	public void onNotify(Watchable w, Object arg) {
		//// 1. Handle it ourself. Ignore for now.

	} // of method

	//-----------------------------------------------------------------

	/**
	 * Recalculate the bounding points.
	 */
	public void onUpdate(Watchable w, Object arg) {
		//// 1. Handle it ourself. Ignore for now.
		setBoundingPoints2D(COORD_LOCAL, getCollectionBounds2D(COORD_ABS));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Recalculate the bounding points.
	 */
	public void onUpdate(Watchable w, String strProperty, 
			Object oldVal, Object newVal) {
		//// 1. Handle it ourself. Ignore for now.
		setBoundingPoints2D(COORD_LOCAL, getCollectionBounds2D(COORD_ABS));
	} // of method

	//-----------------------------------------------------------------

	public void onDelete(Watchable w) {
		if (!ignoreChildDelete) {
			//// 1. Delete the object.
			if (w instanceof GraphicalObject) {
				//System.out.println("Group.onDelete: removing " + ((GraphicalObjectImpl)w).toString());
				remove((GraphicalObject) w);
			}
		}
	} // of method

	//-----------------------------------------------------------------

	public void notifyWatchersDelete() {
		//System.out.println("Group.notifyWatchersDelete() - " + getClass() + ":" + getUniqueID());
		//System.out.println("0. gobcol:" + gobcol);
		super.notifyWatchersDelete();

		ignoreChildDelete = true;
		gobcol.setIgnoreChildDelete(true);
		// Notify watchers of all children that delete has occurred.
		Iterator iter = gobcol.getForwardIterator();
		while (iter.hasNext()) {
			//System.out.println("iterator number: " + ((ListIterator)iter).nextIndex());
			//System.out.println("gobcol: " + gobcol);
			((GraphicalObject)iter.next()).notifyWatchersDelete();
		}
		ignoreChildDelete = false;
		gobcol.setIgnoreChildDelete(false);
		//System.out.println("done notifyWatchersDelete()");
	} // of method
   
	//===   WATCH METHODS   =====================================================
	//===========================================================================



	//===========================================================================
	//===   DISPATCHING METHODS   ===============================================

	/**
	 * Given a stroke, figure out which of our children it will be dispatched
	 * to. Only figures this out for the current level, ie direct children, not
	 * children of children.
	 *
	 * <P>
	 * Override this method for more interesting behavior on how strokes 
	 * should be dispatched.
	 *
	 * @return the GraphicalObject to dispatch to, or null if there isn't one.
	 */
	protected GraphicalObject getDispatchee(TimedStroke stk) {
		Iterator        it = getForwardIterator();
		GraphicalObject gob;

		//// 1. Go through our contained objects, top to bottom.
		////    If any of them entirely contain the stroke, then return
		////    that GraphicalObject.
		//debug.println("getting dispatchee on " + GraphicalObjectLib.toShortString(stk));
		while (it.hasNext()) {
			gob = (GraphicalObject) it.next();
			if (gob.shapeContains(stk)) {
				return (gob);
			}
		}

		return (null);
	} // of method
   
	//-----------------------------------------------------------------
   
	protected GraphicalObject  getCachedDispatchee(StrokeEvent evt) {
			return evt.getNextDispatchee(this);
	}

	//===   DISPATCHING METHODS   ===============================================
	//===========================================================================



	//===========================================================================
	//===   GRAPHICAL OBJECT SHAPE METHODS   ====================================

	protected boolean shapeContainsInternal(Point2D pt) {
		boolean         flagReturn = false;
		Iterator        it         = getForwardIterator();
		GraphicalObject gob;

		while (it.hasNext()) {
			gob = (GraphicalObject) it.next();
			if (gob.shapeContains(COORD_REL, pt)) {
				flagReturn = true;
				break;
			}
		}

		return (flagReturn);
	} // of method

	//-----------------------------------------------------------------

	protected boolean shapeContainsInternal(Shape s) {
		boolean         flagReturn = false;
		Iterator        it         = getForwardIterator();
		GraphicalObject gob;

		while (it.hasNext()) {
			gob = (GraphicalObject) it.next();
			if (gob.shapeContains(COORD_REL, s)) {
				flagReturn = true;
				break;
			}
		}

		return (flagReturn);
	} // of method

	//-----------------------------------------------------------------

	protected boolean shapeIntersectsInternal(Shape s) {
		boolean         flagReturn = false;
		Iterator        it         = getForwardIterator();
		GraphicalObject gob;

		while (it.hasNext()) {
			gob = (GraphicalObject) it.next();
			if (gob.shapeIntersects(COORD_REL, s)) {
				flagReturn = true;
				break;
			}
		}

		return (flagReturn);
	} // of method

	//===   GRAPHICAL OBJECT SHAPE METHODS   ====================================
	//===========================================================================



	//===========================================================================
	//===   RENDERING   =========================================================

	protected void defaultRender(SatinGraphics g) {
		//// 1. Paint all of the gobs in our collection of gobs.
		////    Note that we paint backwards, since things on the bottom
		////    will be painted on top of by things on top.

		GraphicalObject gob;
		Iterator        it = gobcol.getReverseIterator();

		//// 2. Paint each of the children.
		while (it.hasNext()) {
			gob = (GraphicalObject) it.next();

			//// 2.1. Set the Graphics drawing style, draw, and 
			////      then restore the drawing style.
			try {
				g.pushStyle(gob.getStyleRef());
				g.pushTransform(gob.getTransformRef());
				gob.render(g);
				g.popTransform();
				g.popStyle();
			}
			catch (Exception e) {
				gob.render(g);
			}
		}

	} // of method

	//===   RENDERING   =========================================================
	//===========================================================================



	//===========================================================================
	//===   TOSTRING   ==========================================================

	/**
	 * List what Graphical Objects are contained.
	 */
	public String toDebugString() {
		//// A. Acquire soft-state.
		StringBuffer strbuf = (StringBuffer) poolStrbuf.getObject();

		//// 1. Append data.
		strbuf.append(super.toDebugString());
		strbuf.append("\nWatcher IDs:    " +hashCode() + ", " +gobcol.hashCode());
		strbuf.append("\nContained GObs: " + gobcol.toString());

		//// B. Release soft-state.
		String str = strbuf.toString();
		poolStrbuf.releaseObject(strbuf);

		return (str);
	} // of method

	//===   TOSTRING   ==========================================================
	//===========================================================================



	//===========================================================================
	//===   CLONE   =============================================================

	/**
	 * So that my clone will not sleep alone.
	 *
	 * @see    #deepClone()
	 * @return a shallow clone of this object.
	 */
	public Object clone() {
		//// 1. Clone the data structure holding the screen objects.
		return (clone(new GraphicalObjectGroupImpl()));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * For clone chaining purposes.
	 *
	 * @see    GraphicalObjectImpl#clone(GraphicalObjectImpl)
	 * @param  gobgrpClone is the object to clone into (ie gobgrpClone is
	 *         the clone that will be returned).
	 * @return a reference to gobgrpClone.
	 */
	protected GraphicalObjectGroupImpl 
	clone(GraphicalObjectGroupImpl gobgrpClone) {
		//// 1. First call the superclass clone for clone chaining.
		super.clone(gobgrpClone);

		//// 2. Now set the parent group and add watchers for each of the
		////    elements in this group.
		Iterator        it = this.getForwardIterator();
		GraphicalObject gob;

		while (it.hasNext()) {
			gob      = (GraphicalObject) it.next();
			gobgrpClone.addToBack(gob);
		}

		return (gobgrpClone);
	} // of method

	//-----------------------------------------------------------------

	/**
	 * Make a deep clone of the GraphicalObjectGroup.
	 *
	 * @see #clone()
	 */
	public Object deepClone() {
		//// 1. Deep clone a new group.
		return (deepClone(new GraphicalObjectGroupImpl()));
	} // of method

	//-----------------------------------------------------------------

	/**
	 * For deep-clone chaining. If you override this method in a subclass, be
	 * sure to call this method, just as you would have to for normal clone
	 * chaining.
	 *
	 * @see #clone()
	 * @see #deepClone()
	 * @see GraphicalObjectImpl#clone(GraphicalObjectImpl)
	 * @param newGobGrp is the object that will be a clone of the current
	 *                  object. That is, we copy our parameters into newGobGrp.
	 */
	protected GraphicalObjectGroupImpl 
	deepClone(GraphicalObjectGroupImpl newGobGrp) {
		//// 1. First call the superclass clone for clone chaining.
		super.clone(newGobGrp);

		//// 2. Clear out the items in the cloned group.
		newGobGrp.clear();

		//// 3. Now set the parent group and add watchers for each of the
		////    elements in this group.
		Iterator        it = this.getForwardIterator();
		GraphicalObject gob;
		GraphicalObject gobClone;

		while (it.hasNext()) {
			gob      = (GraphicalObject) it.next();
			gobClone = (GraphicalObject) gob.deepClone();
			gobClone.clearWatchers();
			newGobGrp.addToBack(gobClone);
		}

		return (newGobGrp);
	} // of method

	//===   CLONE   =============================================================
	//===========================================================================

	public void addSwingPeer(SwingPeer peer, Sheet sheet) {
		this.addToFront(peer, KEEP_REL_POS);
		if(this.getSheet()==null)
			sheet.add(peer.getRealComponent());
		else
			this.getSheet().add(peer.getRealComponent());
	}
	
	public void removeSwingPeer(SwingPeer peer) {
		this.remove(peer);
		this.getSheet().remove(peer.getRealComponent());	
	}


	//===========================================================================
	//===   SELF-TESTING MAIN   =================================================

/*
	public static void main(String[] argv) {
		GraphicalObjectGroupImpl gobgrp = new GraphicalObjectGroupImpl();
		gobgrp.addToBack(new GObText());
		gobgrp.addToBack(new GObText());
		gobgrp.addToBack(new GObText());

		System.out.println("------------");
		System.out.println(gobgrp.deepClone());
	} // of main
*/

/*
	public static void main(String[] argv) {
		GraphicalObjectGroupImpl group = new GraphicalObjectGroupImpl();

		TimedStroke stk;
		stk = new TimedStroke();
		stk.addPoint(3, 5);
		stk.addPoint(4, 6);
		stk.addPoint(5, 7);
		group.addToFront(stk);

		stk = new TimedStroke();
		stk.addPoint(13, 15);
		stk.addPoint(14, 16);
		stk.addPoint(15, 17);
		group.addToFront(stk);

		System.out.println(group.getBounds());

	} // of main
*/

	//===   SELF-TESTING MAIN   =================================================
	//===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
	notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
	notice, this list of conditions and the following disclaimer in the
	documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
	must display the following acknowledgement:

		This product includes software developed by the Group for User 
		Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
	derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/



