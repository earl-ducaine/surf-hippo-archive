package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.*;

/** 
 * An event that indicates that an interaction graph has been changed in
 * some way.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  06-12-2004 James Lin
 *                               Created InteractionGraphEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 06-12-2004
 */
public class InteractionGraphEvent extends EventObject {
   
   private Type eventType;
   private DeviceType deviceType;
   
   //===========================================================================

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type HOME_PAGE_CHANGED =
      new Type("interaction element's home page changed");

   //===========================================================================

   /**
    * Constructs a InteractionGraphEvent, which gets fired when an
    * InteractionGraph is changed in some way.
    * 
    * @param source the interaction graph that is affected
    */
   public InteractionGraphEvent(
      final InteractionGraph source,
      final Type eventType,
      final DeviceType deviceType) {

      super(source);
      this.eventType = eventType;
      this.deviceType = deviceType;
   }
   
   //===========================================================================

   /**
    * Returns the originator of the event.
    * 
    * @return the interaction graph that originated the event, or
    * null if the object is not an interaction graph.
    */
   public InteractionGraph getGraph() {
      if (source instanceof InteractionGraph) {
         return (InteractionGraph)source;
      }
      else {
         return null;
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the device type associated with this event.
    */
   public DeviceType getDeviceType() {
      return deviceType;
   }
}
