package edu.berkeley.guir.damask.view;

import java.awt.*;
import java.awt.geom.*;
import java.awt.print.PageFormat;
import java.beans.PropertyChangeListener;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.swing.event.EventListenerList;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;
import edu.berkeley.guir.damask.event.InteractionElementListener;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.PRoot;
import edu.umd.cs.piccolo.activities.*;
import edu.umd.cs.piccolo.event.PInputEventListener;
import edu.umd.cs.piccolo.util.*;

/** 
 * An interface that merges methods from InteractionElementView and PPath, so
 * that a variable whose type or ancestor type is
 * InteractionElementViewInterface does not need to be cast to
 * InteractionElementView or PPath.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <pre>
 * Revisions:  1.0.0  08-24-2004 James Lin
 *                               Created.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 */

public interface InteractionElementViewInterface {
   /**
    * Frees up any resources associated with this object.
    */
   void dispose();

   /**
    * Returns the layer that this node is in.
    */
   DamaskLayer getLayer();

   /**
    * Returns the model object, of which this object is a view. 
    */
   InteractionElement getModel();

   /**
    * Returns, if the parent of this object is a selectable parent, whether this
    * object is selectable.
    */
   boolean isSelectable();

   /**
    * Sets, if the parent of this object is a selectable parent, whether this
    * object is selectable.
    */
   void setSelectable(final boolean flag);

   /**
    * Returns whether this object is resizable.
    */
   boolean isResizable();

   /**
    * Sets whether this object is resizable.
    */
   void setResizable(final boolean flag);

   /**
    * Returns whether this object gets stretched when it is resized (as opposed
    * to only its bounds getting resized).
    */
   boolean isStretchedWhenResized();

   /**
    * Sets whether this object gets stretched when it is resized (as opposed
    * to only its bounds getting resized).
    */
   void setStretchedWhenResized(final boolean flag);

   /**
    * Returns whether this object can be moved when selected.
    */
   boolean isMovable();

   /**
    * Sets whether this object can be moved when selected.
    */
   void setMovable(final boolean flag);

   /**
    * Returns whether the selection handles attached to this object should be
    * sticky-Z.
    */
   boolean getUseStickyZHandles();

   /**
    * Sets whether the selection handles attached to this object should be
    * sticky-Z.
    */
   void setUseStickyZHandles(final boolean flag);

   /**
    * Returns the device type for which this object is a view for.
    */
   DeviceType getDeviceType();

   boolean clipFullPick(PPickPath pickPath);

   // The code above was copied from edu.umd.cs.piccolox.nodes.PClip.
   InteractionElementListener getElementHandler();
   
   // Methods from DamaskPPath
   /**
    * The property name that identifies a change of this node's stroke paint
    * (see {@link #getStrokePaint getStrokePaint}). Both old and new value will
    * be set correctly to Paint objects in any property change event.
    */
   public static final String PROPERTY_STROKE_PAINT = "strokePaint";

   /**
    * The property name that identifies a change of this node's stroke (see
    * {@link #getStroke getStroke}). Both old and new value will be set
    * correctly to Stroke objects in any property change event.
    */
   public static final String PROPERTY_STROKE = "stroke";

   /**
    * The property name that identifies a change of this node's path (see
    * {@link #getPathReference getPathReference}).  In any property change
    * event the new value will be a reference to this node's path,  but old
    * value will always be null.
    */
   public static final String PROPERTY_PATH = "path";

   //****************************************************************
   Paint getStrokePaint();

   void setStrokePaint(Paint aPaint);

   Stroke getStroke();

   void setStroke(Stroke aStroke);

   /**
    * Set the bounds of this path. This method works by scaling the path
    * to fit into the specified bounds. This normally works well, but if
    * the specified base bounds get too small then it is impossible to
    * expand the path shape again since all its numbers have tended to zero,
    * so application code may need to take this into consideration.
    */
   boolean setBounds(double x, double y, double width, double height);

   Rectangle2D getPathBoundsWithStroke();

   void updateBoundsFromPath();

   GeneralPath getPathReference();

   void moveTo(float x, float y);

   void lineTo(float x, float y);

   void quadTo(float x1, float y1, float x2, float y2);

   void curveTo(float x1, float y1, float x2, float y2, float x3, float y3);

   void append(Shape aShape, boolean connect);

   void setPathTo(Shape aShape);

   void setPathToRectangle(float x, float y, float width, float height);

   void setPathToEllipse(float x, float y, float width, float height);

   void setPathToPolyline(Point2D[] points);

   void setPathToPolyline(float[] xp, float[] yp);

   void closePath();

   void reset();
   
   // Methods from PNode

   /** 
    * The property name that identifies a change in this node's client
    * propertie (see {@link #getClientProperty getClientProperty}). In
    * an property change event the new value will be a reference to the map of
    * client properties but old value will always be null. 
    */
   public static final String PROPERTY_CLIENT_PROPERTIES = "clientProperties";

   /** 
    * The property name that identifies a change of this node's bounds (see
    * {@link #getBounds getBounds}, {@link #getBoundsReference
    * getBoundsReference}). In any property change event the new value will be
    * a reference to this node's bounds, but old value will always be null.
    */
   public static final String PROPERTY_BOUNDS = "bounds";

   /** 
    * The property name that identifies a change of this node's full bounds
    * (see {@link #getFullBounds getFullBounds}, {@link #getFullBoundsReference
    * getFullBoundsReference}). In any property change event the new value will
    * be a reference to this node's full bounds cache, but old value will
    * always be null.
    */
   public static final String PROPERTY_FULL_BOUNDS = "fullBounds";

   /** 
    * The property name that identifies a change of this node's transform (see
    * {@link #getTransform getTransform}, {@link #getTransformReference
    * getTransformReference}). In any property change event the new value will
    * be a reference to this node's transform, but old value will always be
    * null.
    */
   public static final String PROPERTY_TRANSFORM = "transform";

   /** 
    * The property name that identifies a change of this node's visibility (see
    * {@link #getVisible getVisible}). Both old value and new value will be
    * null in any property change event.
    */
   public static final String PROPERTY_VISIBLE = "visible";

   /** 
    * The property name that identifies a change of this node's paint (see
    * {@link #getPaint getPaint}). Both old value and new value will be set
    * correctly in any property change event.
    */
   public static final String PROPERTY_PAINT = "paint";

   /** 
    * The property name that identifies a change of this node's transparency
    * (see {@link #getTransparency getTransparency}). Both old value and new
    * value will be null in any property change event.
    */
   public static final String PROPERTY_TRANSPARENCY = "transparency";

   /** 
    * The property name that identifies a change of this node's pickable status
    * (see {@link #getPickable getPickable}). Both old value and new value will
    * be null in any property change event.
    */
   public static final String PROPERTY_PICKABLE = "pickable";

   /** 
    * The property name that identifies a change of this node's children
    * pickable status (see {@link #getChildrenPickable getChildrenPickable}).
    * Both old value and new value will be null in any property change event.
    */
   public static final String PROPERTY_CHILDREN_PICKABLE = "childrenPickable";

   /** 
    * The property name that identifies a change in the set of this node's direct children
    * (see {@link #getChildrenReference getChildrenReference}, {@link #getChildrenIterator getChildrenIterator}).
    * In any property change event the new value will be a reference to this node's children,
    * but  old value will always be null. */
   public static final String PROPERTY_CHILDREN = "children";

   /** 
    * The property name that identifies a change of this node's parent
    * (see {@link #getParent getParent}). 
    * Both old value and new value will be set correctly in any property change event. 
    */
   public static final String PROPERTY_PARENT = "parent";

   //****************************************************************
   PInterpolatingActivity animateToBounds(
      double x,
      double y,
      double width,
      double height,
      long duration);

   /**
    * Animate this node's transform from its current location when the
    * activity starts to the specified location, scale, and rotation. If this
    * node descends from the root then the activity will be scheduled, else the
    * returned activity should be scheduled manually. If two different
    * transform activities are scheduled for the same node at the same time,
    * they will both be applied to the node, but the last one scheduled will be
    * applied last on each frame, so it will appear to have replaced the
    * original. Generally you will not want to do that.
    * 
    * @param duration amount of time that the animation should take
    * @param theta final theta value (in radians) for the animation
    * @return the newly scheduled activity
    */
   PTransformActivity animateToPositionScaleRotation(
      double x,
      double y,
      double scale,
      double theta,
      long duration);

   /**
    * Animate this node's transform from its current values when the activity
    * starts to the new values specified in the given transform. If this node
    * descends from the root then the activity will be scheduled, else the
    * returned activity should be scheduled manually. If two different
    * transform activities are scheduled for the same node at the same time,
    * they will both be applied to the node, but the last one scheduled will be
    * applied last on each frame, so it will appear to have replaced the
    * original. Generally you will not want to do that.
    *
    * @param destTransform the final transform value
    * @param duration amount of time that the animation should take
    * @return the newly scheduled activity
    */
   PTransformActivity animateToTransform(
      AffineTransform destTransform,
      long duration);

   /**
    * Animate this node's transparency from its current value to the 
    * new value specified. Transparency values must range from zero to one. 
    * If this node descends from the root then the activity will be 
    * scheduled, else the returned activity should be scheduled manually.
    * If two different transparency activities are scheduled for the same
    * node at the same time, they will both be applied to the node, but the 
    * last one scheduled will be applied last on each frame, so it will appear 
    * to have replaced the original. Generally you will not want to do that.
    *
    * @param zeroToOne final transparency value.
    * @param duration amount of time that the animation should take
    * @return the newly scheduled activity
    */
   PInterpolatingActivity animateToTransparency(float zeroToOne, long duration);

   /**
    * Schedule the given activity with the root, note that only scheduled
    * activities will be stepped. If the activity is successfully added true is
    * returned, else false. 
    * 
    * @param activity new activity to schedule
    * @return true if the activity is successfully scheduled.
    */
   boolean addActivity(PActivity activity);

   //****************************************************************
   Object getClientProperty(Object key);

   /**
    * Add an arbitrary key/value "client property" to this node.
    * <p>
    * The <code>get/addClientProperty<code> methods provide access to
    * a small per-instance hashtable. Callers can use get/addClientProperty
    * to annotate nodes that were created by another module.
    * <p>
    * If value is null this method will remove the property.
    */
   void addClientProperty(Object key, Object value);

   /**
    * Returns an Iterator that will traverse all of the keys
    * maped to client values.
    *
    * @return an Iterator over client property keys
    */
   Iterator getClientPropertyKeysIterator();

   //****************************************************************
   Object clone();

   //****************************************************************
   Point2D localToParent(Point2D localPoint);

   /**
    * Transform the given dimension from this node's local coordinate system to
    * its parent's local coordinate system. Note that this will modify the dimension
    * parameter.
    * 
    * @param localDimension dimension in local coordinate system to be transformed.
    * @return dimension in parent's local coordinate system
    */
   Dimension2D localToParent(Dimension2D localDimension);

   /**
    * Transform the given rectangle from this node's local coordinate system to
    * its parent's local coordinate system. Note that this will modify the rectangle
    * parameter.
    * 
    * @param localRectangle rectangle in local coordinate system to be transformed.
    * @return rectangle in parent's local coordinate system
    */
   Rectangle2D localToParent(Rectangle2D localRectangle);

   /**
    * Transform the given point from this node's parent's local coordinate system to
    * the local coordinate system of this node. Note that this will modify the point
    * parameter.
    * 
    * @param parentPoint point in parent's coordinate system to be transformed.
    * @return point in this node's local coordinate system
    */
   Point2D parentToLocal(Point2D parentPoint);

   /**
    * Transform the given dimension from this node's parent's local coordinate system to
    * the local coordinate system of this node. Note that this will modify the dimension
    * parameter.
    * 
    * @param parentDimension dimension in parent's coordinate system to be transformed.
    * @return dimension in this node's local coordinate system
    */
   Dimension2D parentToLocal(Dimension2D parentDimension);

   /**
    * Transform the given rectangle from this node's parent's local coordinate system to
    * the local coordinate system of this node. Note that this will modify the rectangle
    * parameter.
    * 
    * @param parentRectangle rectangle in parent's coordinate system to be transformed.
    * @return rectangle in this node's local coordinate system
    */
   Rectangle2D parentToLocal(Rectangle2D parentRectangle);

   /**
    * Transform the given point from this node's local coordinate system to
    * the global coordinate system. Note that this will modify the point
    * parameter.
    * 
    * @param localPoint point in local coordinate system to be transformed.
    * @return point in global coordinates
    */
   Point2D localToGlobal(Point2D localPoint);

   /**
    * Transform the given dimension from this node's local coordinate system to
    * the global coordinate system. Note that this will modify the dimension
    * parameter.
    * 
    * @param localDimension dimension in local coordinate system to be transformed.
    * @return dimension in global coordinates
    */
   Dimension2D localToGlobal(Dimension2D localDimension);

   /**
    * Transform the given rectangle from this node's local coordinate system to
    * the global coordinate system. Note that this will modify the rectangle
    * parameter.
    * 
    * @param localRectangle rectangle in local coordinate system to be transformed.
    * @return rectangle in global coordinates
    */
   Rectangle2D localToGlobal(Rectangle2D localRectangle);

   /**
    * Transform the given point from global coordinates to this node's 
    * local coordinate system. Note that this will modify the point
    * parameter.
    * 
    * @param globalPoint point in global coordinates to be transformed.
    * @return point in this node's local coordinate system.
    */
   Point2D globalToLocal(Point2D globalPoint);

   /**
    * Transform the given dimension from global coordinates to this node's 
    * local coordinate system. Note that this will modify the dimension
    * parameter.
    * 
    * @param globalDimension dimension in global coordinates to be transformed.
    * @return dimension in this node's local coordinate system.
    */
   Dimension2D globalToLocal(Dimension2D globalDimension);

   /**
    * Transform the given rectangle from global coordinates to this node's 
    * local coordinate system. Note that this will modify the rectangle
    * parameter.
    * 
    * @param globalRectangle rectangle in global coordinates to be transformed.
    * @return rectangle in this node's local coordinate system.
    */
   Rectangle2D globalToLocal(Rectangle2D globalRectangle);

   /**
    * Return the transform that converts local coordinates at this node 
    * to the global coordinate system.
    * 
    * @return The concatenation of transforms from the top node down to this node.
    */
   PAffineTransform getLocalToGlobalTransform(PAffineTransform dest);

   /**
    * Return the transform that converts global coordinates 
    * to local coordinates of this node.
    * 
    * @return The inverse of the concatenation of transforms from the root down to this node.
    */
   PAffineTransform getGlobalToLocalTransform(PAffineTransform dest);

   //****************************************************************
   EventListenerList getListenerList();

   /**
    * Adds the specified input event listener to receive input events 
    * from this node.
    *
    * @param listener the new input listener
    */
   void addInputEventListener(PInputEventListener listener);

   /**
    * Removes the specified input event listener so that it no longer 
    * receives input events from this node.
    *
    * @param listener the input listener to remove
    */
   void removeInputEventListener(PInputEventListener listener);

   /**
    * Add a PropertyChangeListener to the listener list.
    * The listener is registered for all properties.
    * See the fields in PNode and subclasses that start
    * with PROPERTY_ to find out which properties exist.
    * @param listener   The PropertyChangeListener to be added
    */
   void addPropertyChangeListener(PropertyChangeListener listener);

   /**
    * Add a PropertyChangeListener for a specific property.  The listener
    * will be invoked only when a call on firePropertyChange names that
    * specific property. See the fields in PNode and subclasses that start
    * with PROPERTY_ to find out which properties are supported.
    * @param propertyName  The name of the property to listen on.
    * @param listener   The PropertyChangeListener to be added
    */
   void addPropertyChangeListener(
      String propertyName,
      PropertyChangeListener listener);

   /**
    * Remove a PropertyChangeListener from the listener list.
    * This removes a PropertyChangeListener that was registered
    * for all properties.
    *
    * @param listener   The PropertyChangeListener to be removed
    */
   void removePropertyChangeListener(PropertyChangeListener listener);

   /**
    * Remove a PropertyChangeListener for a specific property.
    *
    * @param propertyName  The name of the property that was listened on.
    * @param listener   The PropertyChangeListener to be removed
    */
   void removePropertyChangeListener(
      String propertyName,
      PropertyChangeListener listener);

   //****************************************************************
   PBounds getBounds();

   /**
    * Return a direct reference to this node's bounds. These bounds 
    * are stored in the local coordinate system of this node and do 
    * not include the bounds of any of this node's children. The value
    * returned should not be modified.
    */
   PBounds getBoundsReference();

   /**
    * Notify this node that you will beging to repeadily call <code>setBounds</code>. 
    * When you are done call <code>endResizeBounds</code> to let the node know that
    * you are done.
    */
   void startResizeBounds();

   /**
    * Notify this node that you have finished a resize bounds sequence.
    */
   void endResizeBounds();

   /**
    * Set the bounds of this node to the given value. These bounds 
    * are stored in the local coordinate system of this node.
    * 
    * @return true if the bounds changed.
    */
   boolean setBounds(Rectangle2D newBounds);

   /**
    * Set the empty bit of this bounds to true.
    */
   void resetBounds();

   /**
    * Return the x position (in local coords) of this node's bounds.
    */
   double getX();

   /**
    * Return the y position (in local coords) of this node's bounds.
    */
   double getY();

   /**
    * Return the width (in local coords) of this node's bounds.
    */
   double getWidth();

   /**
    * Return the height (in local coords) of this node's bounds.
    */
   double getHeight();

   /**
    * Center the bounds of this node so that they are centered on the given
    * point specified on the local coords of this node.
    * 
    * @return true if the bounds changed.
    */
   boolean centerBoundsOnPoint(double localX, double localY);

   /**
    * Return true if this node intersects the given rectangle specified in
    * local bounds. If the geometry of this node is complex this method can become
    * expensive, it is therefore recommended that <code>fullIntersects</code> is used
    * for quick rejects before calling this method.
    * 
    * @param localBounds the bounds to test for intersection against
    * @return true if the given rectangle intersects this nodes geometry.
    */
   boolean intersects(Rectangle2D localBounds);

   //****************************************************************
   PBounds getFullBounds();

   /**
    * Return a reference to this node's full bounds cache. These bounds are 
    * stored in the parent coordinate system of this node and they include the
    * union of this node's bounds and all the bounds of it's descendents. The bounds
    * returned by this method should not be modified.
    * 
    * @return a reference to this node's full bounds cache. 
    */
   PBounds getFullBoundsReference();

   /**
    * Compute and return the full bounds of this node. If the dstBounds
    * parameter is not null then it will be used to return the results instead
    * of creating a new PBounds.
    * 
    * @param dstBounds if not null the new bounds will be stored here
    * @return the full bounds in the parent coordinate system of this node
    */
   PBounds computeFullBounds(PBounds dstBounds);

   /**
    * Compute and return the union of the full bounds of all the 
    * children of this node. If the dstBounds parameter is not null 
    * then it will be used to return the results instead of creating 
    * a new PBounds.
    * 
    * @param dstBounds if not null the new bounds will be stored here
    */
   PBounds getUnionOfChildrenBounds(PBounds dstBounds);

   /**
    * Return a copy of the full bounds of this node in the global 
    * coordinate system.
    * 
    * @return the full bounds in global coordinate system.
    */
   PBounds getGlobalFullBounds();

   /**
    * Return true if the full bounds of this node intersects with the
    * specified bounds.
    * 
    * @param parentBounds the bounds to test for intersection against (specified in parent's coordinate system)
    * @return true if this nodes full bounds intersect the given bounds.
    */
   boolean fullIntersects(Rectangle2D parentBounds);

   /**
    * This method should be called when the bounds of this node are changed.
    * It invalidates the full bounds of this node, and also notifies each of 
    * this nodes children that their parent's bounds have changed. As a result 
    * of this method getting called this nodes layoutChildren will be called.
    */
   void signalBoundsChanged();

   /**
    * Invalidate this node's layout, so that later 
    * layoutChildren will get called.
    */
   void invalidateLayout();

   /**
    * Invalidates the full bounds of this node, and sets the child bounds invalid flag
    * on each of this node's ancestors.
    */
   void invalidateFullBounds();

   //****************************************************************
   double getRotation();

   /**
    * Sets the rotation of this nodes transform in radians. This will
    * affect this node and all its descendents.
    * 
    * @param theta rotation in radians
    */
   void setRotation(double theta);

   /**
    * Rotates this node by theta (in radians) about the 0,0 point. 
    * This will affect this node and all its descendents.
    * 
    * @param theta the amount to rotate by in radians
    */
   void rotate(double theta);

   /**
    * Rotates this node by theta (in radians), and then translates the node so
    * that the x, y position of its fullBounds stays constant.
    * 
    * @param theta the amount to rotate by in radians
    */
   void rotateInPlace(double theta);

   /**
    * Rotates this node by theta (in radians) about the given 
    * point. This will affect this node and all its descendents.
    * 
    * @param theta the amount to rotate by in radians
    */
   void rotateAboutPoint(double theta, Point2D point);

   /**
    * Rotates this node by theta (in radians) about the given 
    * point. This will affect this node and all its descendents.
    * 
    * @param theta the amount to rotate by in radians
    */
   void rotateAboutPoint(double theta, double x, double y);

   /**
    * Return the total amount of rotation applied to this node by its own
    * transform together with the transforms of all its ancestors. The value
    * returned will be between 0 and 2pi radians.
    * 
    * @return the total amount of rotation applied to this node in radians
    */
   double getGlobalRotation();

   /**
    * Set the global rotation (in radians) of this node. This is implemented by
    * rotating this nodes transform the required amount so that the nodes
    * global rotation is as requested.
    * 
    * @param theta the amount to rotate by in radians relative to the global coord system.
    */
   void setGlobalRotation(double theta);

   /**
    * Return the scale applied by this node's transform. The scale is 
    * effecting this node and all its descendents.
    * 
    * @return scale applied by this nodes transform.
    */
   double getScale();

   /**
    * Set the scale of this node's transform. The scale will 
    * affect this node and all its descendents.
    * 
    * @param scale the scale to set the transform to
    */
   void setScale(double scale);

   /**
    * Scale this nodes transform by the given amount. This will affect this
    * node and all of its descendents.
    * 
    * @param scale the amount to scale by
    */
   void scale(double scale);

   /**
    * Scale this nodes transform by the given amount about the specified
    * point. This will affect this node and all of its descendents.
    * 
    * @param scale the amount to scale by
    * @param point the point to scale about
    */
   void scaleAboutPoint(double scale, Point2D point);

   /**
    * Scale this nodes transform by the given amount about the specified
    * point. This will affect this node and all of its descendents.
    * 
    * @param scale the amount to scale by
    */
   void scaleAboutPoint(double scale, double x, double y);

   /**
    * Return the global scale that is being applied to this node by its transform
    * together with the transforms of all its ancestors.
    */
   double getGlobalScale();

   /**
    * Set the global scale of this node. This is implemented by scaling
    * this nodes transform the required amount so that the nodes global scale
    * is as requested.
    * 
    * @param scale the desired global scale
    */
   void setGlobalScale(double scale);

   /**
    * Return the offset that is being applied to this node by its
    * transform. This offset effects this node and all of its descendents
    * and is specified in the parent coordinate system. This returns the
    * values that are in the m02 and m12 positions in the affine transform.
    * 
    * @return a point representing the x and y offset
    */
   Point2D getOffset();

   /**
    * Set the offset that is being applied to this node by its
    * transform. This offset effects this node and all of its descendents and
    * is specified in the nodes parent coordinate system. This directly sets the values
    * of the m02 and m12 positions in the affine transform. Unlike "PNode.translate()" it
    * is not effected by the transforms scale.
    * 
    * @param point a point representing the x and y offset
    */
   void setOffset(Point2D point);

   /**
    * Set the offset that is being applied to this node by its
    * transform. This offset effects this node and all of its descendents and
    * is specified in the nodes parent coordinate system. This directly sets the values
    * of the m02 and m12 positions in the affine transform. Unlike "PNode.translate()" it
    * is not effected by the transforms scale.
    * 
    * @param x amount of x offset
    * @param y amount of y offset
    */
   void setOffset(double x, double y);

   /**
    * Offset this node relative to the parents coordinate system, and is NOT
    * effected by this nodes current scale or rotation. This is implemented
    * by directly adding dx to the m02 position and dy to the m12 position in the
    * affine transform.
    */
   void offset(double dx, double dy);

   /**
    * Translate this node's transform by the given amount, using the standard affine
    * transform translate method. This translation effects this node and all of its 
    * descendents.
    */
   void translate(double dx, double dy);

   /**
    * Return the global translation that is being applied to this node by its transform
    * together with the transforms of all its ancestors.
    */
   Point2D getGlobalTranslation();

   /**
    * Set the global translation of this node. This is implemented by translating
    * this nodes transform the required amount so that the nodes global scale
    * is as requested.
    * 
    * @param globalPoint the desired global translation
    */
   void setGlobalTranslation(Point2D globalPoint);

   /**
    * Transform this nodes transform by the given transform.
    * 
    * @param aTransform the transform to apply.
    */
   void transformBy(AffineTransform aTransform);

   /**
    * This will calculate the necessary transform in order to make this
    * node appear at a particular position relative to the
    * specified bounding box.  The source point specifies a point in the
    * unit square (0, 0) - (1, 1) that represents an anchor point on the
    * corresponding node to this transform.  The destination point specifies
    * an anchor point on the reference node.  The position method then
    * computes the transform that results in transforming this node so that
    * the source anchor point coincides with the reference anchor
    * point. This can be useful for layout algorithms as it is
    * straightforward to position one object relative to another.
    * <p>
    * For example, If you have two nodes, A and B, and you call
    * <PRE>
    *     Point2D srcPt = new Point2D.Double(1.0, 0.0);
    *     Point2D destPt = new Point2D.Double(0.0, 0.0);
    *     A.position(srcPt, destPt, B.getGlobalBounds(), 750, null);
    * </PRE>
    * The result is that A will move so that its upper-right corner is at
    * the same place as the upper-left corner of B, and the transition will
    * be smoothly animated over a period of 750 milliseconds.
    * @param srcPt The anchor point on this transform's node (normalized to a unit square)
    * @param destPt The anchor point on destination bounds (normalized to a unit square)
    * @param destBounds The bounds (in global coordinates) used to calculate this transform's node
    * @param millis Number of milliseconds over which to perform the animation
    */
   void position(
      Point2D srcPt,
      Point2D destPt,
      Rectangle2D destBounds,
      int millis);

   /**
    * Return a copy of the transform associated with this node.
    * 
    * @return copy of this node's transform
    */
   PAffineTransform getTransform();

   /**
    * Return a reference to the transform associated with this node.
    * This returned transform should not be modified. PNode transforms are
    * created lazily when needed. If you access the transform reference
    * before the transform has been created it may return null. The 
    * createNewTransformIfNull parameter is used to specify that the PNode
    * should create a new transform (and assign that transform to the nodes
    * local transform variable) instead of returning null.
    * 
    * @return reference to this node's transform
    */
   PAffineTransform getTransformReference(boolean createNewTransformIfNull);

   /**
    * Return an inverted copy of the transform associated with this node.
    * 
    * @return inverted copy of this node's transform
    */
   PAffineTransform getInverseTransform();

   /**
    * Set the transform applied to this node.
    * 
    * @param newTransform the new transform value
    */
   void setTransform(AffineTransform newTransform);

   //****************************************************************
   boolean getPaintInvalid();

   /**
    * Mark this node as having invalid paint. If this is set the node 
    * will later be repainted. Node this method is most often 
    * used internally.
    * 
    * @param paintInvalid true if this node should be repainted
    */
   void setPaintInvalid(boolean paintInvalid);

   /**
    * Return true if this node has a child with invalid paint.
    * 
    * @return true if this node has a child with invalid paint
    */
   boolean getChildPaintInvalid();

   /**
    * Mark this node as having a child with invalid paint. 
    * 
    * @param childPaintInvalid true if this node has a child with invalid paint
    */
   void setChildPaintInvalid(boolean childPaintInvalid);

   /**
    * Invalidate this node's paint, and mark all of its ancestors as having a node
    * with invalid paint.
    */
   void invalidatePaint();

   /**
    * Repaint this node and any of its descendents if they have invalid paint.
    */
   void validateFullPaint();

   /**
    * Mark the area on the screen represented by this nodes full bounds 
    * as needing a repaint.
    */
   void repaint();

   /**
    * Pass the given repaint request up the tree, so that any cameras
    * can invalidate that region on their associated canvas.
    * 
    * @param localBounds the bounds to repaint
    * @param childOrThis if childOrThis does not equal this then this nodes transform will be applied to the localBounds param 
    */
   void repaintFrom(PBounds localBounds, PNode childOrThis);

   //****************************************************************
   boolean getVisible();

   /**
    * Set the visibility of this node and its descendents.
    * 
    * @param isVisible true if this node and its descendents are visible
    */
   void setVisible(boolean isVisible);

   /**
    * Return the paint used to paint this node. This value may be null.
    */
   Paint getPaint();

   /**
    * Set the paint used to paint this node. This value may be set to null.
    */
   void setPaint(Paint newPaint);

   /**
    * Return the transparency used when painting this node. Note that this
    * transparency is also applied to all of the node�s descendents.
    */
   float getTransparency();

   /**
    * Set the transparency used to paint this node. Note that this transparency
    * applies to this node and all of its descendents.
    */
   void setTransparency(float zeroToOne);

   /**
    * Paint this node and all of its descendents. Most subclasses do not need to
    * override this method, they should override <code>paint</code> or
    * <code>paintAfterChildren</code> instead.
    * 
    * @param paintContext the paint context to use for painting this node and its children
    */
   void fullPaint(PPaintContext paintContext);

   /**
    * Return a new Image representing this node and all of its children. The image size will
    * be equal to the size of this nodes full bounds.
    * 
    * @return a new image representing this node and its descendents
    */
   Image toImage();

   /**
    * Return a new Image of the requested size representing this 
    * node and all of its children. If backGroundPaint is null the resulting
    * image will have transparent regions, else those regions will be filled
    * with the backgroundPaint.
    * 
    * @return a new image representing this node and its descendents
    */
   Image toImage(int width, int height, Paint backGroundPaint);

   /**
    * Constructs a new PrinterJob, allows the user to select which printer
    * to print to, And then prints the node.
    */
   void print();

   /**
    * Prints the node into the given Graphics context using the specified
    * format. The zero based index of the requested page is specified by
    * pageIndex. If the requested page does not exist then this method returns
    * NO_SUCH_PAGE; otherwise PAGE_EXISTS is returned. If the printable object
    * aborts the print job then it throws a PrinterException.
    * 
    * @param graphics    the context into which the node is drawn
    * @param pageFormat  the size and orientation of the page
    * @param pageIndex   the zero based index of the page to be drawn
    */
   int print(Graphics graphics, PageFormat pageFormat, int pageIndex);

   //****************************************************************
   boolean getPickable();

   /**
    * Set the pickable flag for this node. Only pickable nodes can
    * receive input events.  Nodes are pickable by default.
    * 
    * @param isPickable true if this node is pickable
    */
   void setPickable(boolean isPickable);

   /**
    * Return true if the children of this node should be picked. If this flag
    * is false then this node will not try to pick its children. Children
    * are pickable by default.
    * 
    * @return true if this node tries to pick its children
    */
   boolean getChildrenPickable();

   /**
    * Set the children pickable flag. If this flag is false then this 
    * node will not try to pick its children. Children are pickable by
    * default.
    * 
    * @param areChildrenPickable true if this node tries to pick its children
    */
   void setChildrenPickable(boolean areChildrenPickable);

   /**
    * Try to pick this node and all of its descendents. Most subclasses should not
    * need to override this method. Instead they should override <code>pick</code> or
    * <code>pickAfterChildren</code>.
    * 
    * @param pickPath the pick path to add the node to if its picked
    * @return true if this node or one of its descendents was picked.
    */
   boolean fullPick(PPickPath pickPath);

   //****************************************************************
   void addChild(PNode child);

   /**
    * Add a node to be a new child of this node at the specified index.
    * If child was previously a child of another node, it is removed 
    * from that node first.
    * 
    * @param child the new child to add to this node
    */
   void addChild(int index, PNode child);

   /**
    * Add a collection of nodes to be children of this node. If these nodes
    * already have parents they will first be removed from those parents.
    * 
    * @param nodes a collection of nodes to be added to this node
    */
   void addChildren(Collection nodes);

   /**
    * Return true if this node is an ancestor of the parameter node.
    * 
    * @param node a possible descendent node
    * @return true if this node is an ancestor of the given node
    */
   boolean isAncestorOf(PNode node);

   /**
    * Return true if this node is a descendent of the parameter node.
    * 
    * @param node a possible ancestor node
    * @return true if this nodes descends from the given node
    */
   boolean isDescendentOf(PNode node);

   /**
    * Return true if this node descends from the root.
    */
   boolean isDescendentOfRoot();

   /**
    * Change the order of this node in its parent's children list so that
    * it will draw in back of all of its other sibling nodes.
    */
   void moveToBack();

   /**
    * Change the order of the given child node in this node's children list so that
    * it will draw in back of all of the other child nodes.
    * 
    * @param child the child node that should be moved to back
    */
   void moveToBack(PNode child);

   /**
    * Change the order of this node in its parent's children list so that
    * it will draw in front of all of its other sibling nodes.
    */
   void moveToFront();

   /**
    * Change the order of the given child node in this node's children list so that
    * it will draw in front of all of the other child nodes.
    * 
    * @param child the child node that should be moved to the front
    */
   void moveToFront(PNode child);

   /**
    * Return the parent of this node. This will be null if this node has not been
    * added to a parent yet.
    * 
    * @return this nodes parent or null
    */
   PNode getParent();

   /**
    * Set the parent of this node. Note this is set automatically when adding and
    * removing children.
    */
   void setParent(PNode newParent);

   /**
    * Return the index where the given child is stored.
    */
   int indexOfChild(PNode child);

   /**
    * Remove the given child from this node's children list. Any 
    * subsequent children are shifted to the left (one is subtracted 
    * from their indices). The removed child�s parent is set to null.
    * 
    * @param child the child to remove
    * @return the removed child
    */
   PNode removeChild(PNode child);

   /**
    * Remove the child at the specified position of this group node's children.
    * Any subsequent children are shifted to the left (one is subtracted from
    * their indices).   The removed child�s parent is set to null.
    * 
    * @param index the index of the child to remove
    * @return the removed child
    */
   PNode removeChild(int index);

   /**
    * Remove all the children in the given collection from this node�s
    * list of children. All removed nodes will have their parent set to
    * null.
    * 
    * @param childrenNodes the collection of children to remove
    */
   void removeChildren(Collection childrenNodes);

   /**
    * Remove all the children from this node. Node this method is more efficient then
    * removing each child individually.
    */
   void removeAllChildren();

   /**
    * Delete this node by removing it from its parent�s list of children.
    */
   void removeFromParent();

   /**
    * Set the parent of this node, and transform the node in such a way that it
    * doesn't move in global coordinates.
    * 
    * @param newParent The new parent of this node.
    */
   void reparent(PNode newParent);

   /**
    * Swaps this node out of the scene graph tree, and replaces it with the specified
    * replacement node.  This node is left dangling, and it is up to the caller to
    * manage it.  The replacement node will be added to this node's parent in the same
    * position as this was.  That is, if this was the 3rd child of its parent, then
    * after calling replaceWith(), the replacement node will also be the 3rd child of its parent.
    * If this node has no parent when replace is called, then nothing will be done at all.
    *
    * @param replacementNode the new node that replaces the current node in the scene graph tree.
    */
   void replaceWith(PNode replacementNode);

   /**
    * Return the number of children that this node has.
    * 
    * @return the number of children
    */
   int getChildrenCount();

   /**
    * Return the child node at the specified index.
    * 
    * @param index a child index
    * @return the child node at the specified index
    */
   PNode getChild(int index);

   /**
    * Return a reference to the list used to manage this node�s
    * children. This list should not be modified.
    * 
    * @return reference to the children list
    */
   List getChildrenReference();

   /**
    * Return an iterator over this node�s direct descendent children.
    *
    * @return iterator over this nodes children  
    */
   Iterator getChildrenIterator();

   /**
    * Return the root node (instance of PRoot). If this node does not
    * descend from a PRoot then null will be returned.
    */
   PRoot getRoot();

   /**
    * Return a collection containing this node and all of its descendent nodes.
    * 
    * @return a new collection containing this node and all descendents
    */
   Collection getAllNodes();

   /**
    * Return a collection containing the subset of this node and all of 
    * its descendent nodes that are accepted by the given node filter. If the 
    * filter is null then all nodes will be accepted. If the results parameter 
    * is not null then it will be used to collect this subset instead of 
    * creating a new collection.
    * 
    * @param filter the filter used to determine the subset
    * @return a collection containing this node and all descendents
    */
   Collection getAllNodes(PNodeFilter filter, Collection results);
}
