//// See bottom of source code for software license

package edu.berkeley.guir.denim;

import edu.berkeley.guir.lib.awt.geom.Polygon2D;
import edu.berkeley.guir.lib.satin.graphics.SatinGraphics;
import edu.berkeley.guir.lib.satin.image.SatinImageLib;
import edu.berkeley.guir.lib.satin.objects.*;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.*;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.graphics.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.view.*;
import edu.berkeley.guir.lib.satin.watch.*;
import edu.berkeley.guir.lib.satin.image.*;


/* <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * 				Created on Aug 7, 2004 by YL
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 */

public class SketchPanel extends PatchImpl {

    Rectangle2D stkBounds = null;
    
    public SketchPanel(Rectangle2D rect) {
        super(rect);
        this.setSelectable(false);
    }
    
    //-----------------------------------------------------------------

    protected void defaultRender(SatinGraphics g)
    {
        renderChildren(g);
        g.setColor(Color.blue);
        if(stkBounds!=null)
            g.draw(stkBounds);
    }
    
    public void handleSingleStroke(SingleStrokeEvent evt)
    {
        //// 1. Add it ourself.
        if (!evt.isConsumed() && super.getStrokeEventFilter().isEventAccepted(evt))
        {
            this.disableDamage();
            
            TimedStroke stk = evt.getStroke();
            InsertCommand cmd = new InsertCommand(this, stk);

            cmd.setAddPolicy(GraphicalObjectGroup.KEEP_ABS_POS);
            cmdqueue.doCommand(cmd);
            
            if(stkBounds==null)
                stkBounds = stk.getBounds2D(COORD_REL);
            
            Rectangle2D.union(stk.getBounds2D(COORD_REL), stkBounds, stkBounds);
            
            this.enableDamage();
            this.damage(DAMAGE_NOW, stkBounds);
            
            evt.setConsumed();
            evt.setShouldRender(false);
        }
    } // of handleSingleStroke
}



//==============================================================================

/*
Copyright (c) 2004 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
    must display the following acknowledgement:

        This product includes software developed by the Group for User 
        Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
    derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/