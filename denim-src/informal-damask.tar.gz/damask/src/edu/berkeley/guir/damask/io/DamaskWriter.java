package edu.berkeley.guir.damask.io;

import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.math.BigInteger;
import java.util.*;

import javax.imageio.ImageIO;
import javax.xml.bind.*;
import javax.xml.transform.Result;

import org.apache.commons.codec.binary.Base64;
import org.w3c.dom.Node;
import org.xml.sax.ContentHandler;

import edu.berkeley.guir.damask.io.generated.*;
import edu.berkeley.guir.damask.view.DamaskAppExceptionHandler;
import edu.berkeley.guir.lib.awt.geom.GeomLib;
import edu.berkeley.guir.lib.awt.geom.Polygon2D;

/**
 * Saves a Damask design to a disk, stream, URL, or DOM tree.
 *
 * <p>
 * This software is distributed under the
 * <a href="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</a>.
 *
 * <pre>
 * Revisions:  1.0.0  03-12-2004 James Lin
 *                               Created DamaskMarshaller.
 * </pre>
 *
 * @author  <a href="http://www.cs.berkeley.edu/~jimlin/">James Lin</a>
 * @version Version 1.0.0, 03-12-2004
 */
public class DamaskWriter {

   private static final java.util.regex.Pattern INVALID_ID_CHARS =
      java.util.regex.Pattern.compile("[^\\.\\-\\w]");
   // any character except period, hyphen, underscore, letter, or number

   private static Map/*<edu.berkeley.guir.damask.InteractionElement, Object>*/
      xmlElements = new HashMap();

   private static ObjectFactory objFactory = new ObjectFactory();
   private static JAXBContext jc = null;
   private static Marshaller marshaller = null;
   static {
      try {
         jc = JAXBContext.newInstance("edu.berkeley.guir.damask.io.generated");
         marshaller = jc.createMarshaller();
         marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
      }
      catch (JAXBException e) {
         DamaskAppExceptionHandler.log(e);
      }
   }

   /**
    * Prevents instantiation.
    */
   private DamaskWriter() {
   }


   private static Marshaller getMarshaller() throws JAXBException {
      return marshaller;
   }


   /**
    * Takes the specified interaction graph and frame and writes out an
    * XML representation to the specified stream.
    */
   public static void save(
      final edu.berkeley.guir.damask.InteractionGraph realGraph,
      final edu.berkeley.guir.damask.view.DamaskFrame frame,
      final OutputStream outStream)
      throws JAXBException {

      final Damask damask = writeDamask(realGraph, frame);
      getMarshaller().marshal(damask, outStream);
   }


   /**
    * Takes the specified interaction graph and frame and writes out SAX 2
    * events.
    */
   public static void save(
      final edu.berkeley.guir.damask.InteractionGraph realGraph,
      final edu.berkeley.guir.damask.view.DamaskFrame frame,
      final ContentHandler contentHandler)
      throws JAXBException {

      final Damask damask = writeDamask(realGraph, frame);
      getMarshaller().marshal(damask, contentHandler);
   }


   /**
    * Takes the specified interaction graph and frame and writes out a
    * DOM tree.
    */
   public static void save(
      final edu.berkeley.guir.damask.InteractionGraph realGraph,
      final edu.berkeley.guir.damask.view.DamaskFrame frame,
      final Node node)
      throws JAXBException {

      final Damask damask = writeDamask(realGraph, frame);
      getMarshaller().marshal(damask, node);
   }


   /**
    * Takes the specified interaction graph and frame and writes into the
    * specified transformation result tree
    */
   public static void save(
      final edu.berkeley.guir.damask.InteractionGraph realGraph,
      final edu.berkeley.guir.damask.view.DamaskFrame frame,
      final Result result)
      throws JAXBException {

      final Damask damask = writeDamask(realGraph, frame);
      getMarshaller().marshal(damask, result);
   }


   /**
    * Takes the specified interaction graph and frame and writes out an
    * XML representation to the specified writer.
    */
   public static void save(
      final edu.berkeley.guir.damask.InteractionGraph realGraph,
      final edu.berkeley.guir.damask.view.DamaskFrame frame,
      final Writer writer)
      throws JAXBException {

      final Damask damask = writeDamask(realGraph, frame);
      getMarshaller().marshal(damask, writer);
   }


   /**
    * Takes the specified interaction graph and frame, and creates a content
    * tree to be written out as XML.
    */
   private static Damask writeDamask(
      final edu.berkeley.guir.damask.InteractionGraph realGraph,
      final edu.berkeley.guir.damask.view.DamaskFrame frame)
      throws JAXBException {

      xmlElements.clear();

      final Damask damask = objFactory.createDamask();

      final Design design = objFactory.createDesign();
      damask.setDesign(design);

      // Add templates to the design
      final Templates templates = objFactory.createTemplates();
      design.setTemplates(templates);
      for (Iterator i = realGraph.getTemplates().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.dialog.Dialog realTemplate =
            (edu.berkeley.guir.damask.dialog.Dialog)i.next();
         templates.getTemplate().add(writeDialog(realTemplate));
      }

      // Add dialogs to the design
      final Dialogs dialogs = objFactory.createDialogs();
      design.setDialogs(dialogs);
      for (Iterator i = realGraph.getDialogs().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.dialog.Dialog realDialog =
            (edu.berkeley.guir.damask.dialog.Dialog)i.next();
         dialogs.getDialog().add(writeDialog(realDialog));
      }

      // Add home pages to design
      final HomePages homePages = objFactory.createHomePages();
      design.setHomePages(homePages);
      for (Iterator i =
         edu.berkeley.guir.damask.Damask.getSupportedDeviceTypes().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         final edu.berkeley.guir.damask.dialog.Page realHomePage =
            realGraph.getHomePage(realDeviceType);

         if (realHomePage != null) {
            final HomePage homePage = objFactory.createHomePage();
            homePage.setDeviceType(realDeviceType.toString());
            homePage.setPage(xmlElements.get(realHomePage));

            homePages.getHomePage().add(homePage);
         }
      }

      // Fill in control objects, adding voice info if necessary
      for (Iterator i = xmlElements.keySet().iterator(); i.hasNext(); ) {
         final Object key = i.next();
         if (key instanceof edu.berkeley.guir.damask.component.Control) {
            final edu.berkeley.guir.damask.component.Control realControl =
               (edu.berkeley.guir.damask.component.Control)key;
            final Object control = xmlElements.get(realControl);
            if ((realControl.getDialog() != null) &&
                (realControl.isVisibleToDeviceType(
                    edu.berkeley.guir.damask.DeviceType.VOICE))) {
               VoiceViewProperties voiceProperties =
                  writeVoiceViewProperties(realControl);
               try {
                  control
                     .getClass()
                     .getMethod(
                        "setVoiceViewProperties",
                        new Class[] {VoiceViewProperties.class})
                     .invoke(
                        control, new Object[] {voiceProperties});
               }
               // None of these exceptions should ever happen
               catch (IllegalArgumentException e) {
                  DamaskAppExceptionHandler.log(e);
               }
               catch (SecurityException e) {
                  DamaskAppExceptionHandler.log(e);
               }
               catch (IllegalAccessException e) {
                  DamaskAppExceptionHandler.log(e);
               }
               catch (InvocationTargetException e) {
                  DamaskAppExceptionHandler.log(e);
               }
               catch (NoSuchMethodException e) {
                  DamaskAppExceptionHandler.log(e);
               }
            }
         }
      }

      // Add connections to the design
      final Connections connections = objFactory.createConnections();
      design.setConnections(connections);
      for (Iterator i = realGraph.getConnections().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.connection.Connection realConnection =
            (edu.berkeley.guir.damask.connection.Connection)i.next();
         connections.getConnection().add(writeConnection(realConnection));
      }

      // Add pattern instances to the graph
      final PatternInstances patternInstances =
         objFactory.createPatternInstances();
      design.setPatternInstances(patternInstances);
      for (Iterator i = realGraph.getPatternInstances().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.pattern.PatternInstance
            realPatternInstance =
            (edu.berkeley.guir.damask.pattern.PatternInstance)i.next();
         patternInstances.getPatternInstance().add(
            writePatternInstance(realPatternInstance));
      }

      xmlElements.clear();
      
      return damask;
   }


   /**
    * Takes the specified dialog, and creates a content tree fragment to be
    * written out as XML.
    */
   private static Dialog writeDialog(
      final edu.berkeley.guir.damask.dialog.Dialog realDialog)
      throws JAXBException {

      final Dialog dialog = objFactory.createDialog();
      xmlElements.put(realDialog, dialog);
      dialog.setId(writeId(realDialog));

      dialog.setConditionsCount(
         createBigInteger(realDialog.getNumConditions()));

      // Write out the bounds and transforms
      final BoundsAndTransforms boundsAndTransforms =
         writeBoundsAndTransforms(realDialog);
      if (!boundsAndTransforms.getBoundsAndTransform().isEmpty()) {
         dialog.setBoundsAndTransforms(boundsAndTransforms);
      }
      
      final Controls controls = objFactory.createControls();
      dialog.setControls(controls);

      final Pages pages = objFactory.createPages();
      dialog.setPages(pages);

      // Create page objects for all of the pages so that the control objects
      // have something to reference.
      for (Iterator i = realDialog.getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();
         for (Iterator j = realDialog.getPages(realDeviceType).iterator();
            j.hasNext();
            ) {
            final edu.berkeley.guir.damask.dialog.Page realPage =
               (edu.berkeley.guir.damask.dialog.Page)j.next();

            //HACK real page's bounds should never be null
            if (realPage.getBounds() == null) {
               continue;
            }
            
            final Page page = objFactory.createPage();
            xmlElements.put(realPage, page);
            pages.getPage().add(page);

            page.setId(writeId(realPage));
            page.setDeviceType(realPage.getDeviceType().toString());
            
            final TemplateRefs templateRefs = objFactory.createTemplateRefs();
            page.setTemplateRefs(templateRefs);
            for (Iterator k = realPage.getTemplates().iterator(); k.hasNext();){
               final edu.berkeley.guir.damask.dialog.Page
                  realTemplatePage =
                  (edu.berkeley.guir.damask.dialog.Page)k.next();
               final TemplateRef templateRef = objFactory.createTemplateRef();
               templateRef.setRef(xmlElements.get(realTemplatePage));
               templateRefs.getTemplateRef().add(templateRef);
            }
            page.setBounds(writeBounds(realPage.getBounds()));
            page.setTransform(writeTransform(realPage.getTransform()));

            final Title title = objFactory.createTitle();
            page.setTitle(title);
            final edu.berkeley.guir.damask.component.Content realTitleContent =
               realPage.getTitle();
            final Content titleContent = writeContent(realTitleContent); 
            title.setContent(titleContent);
            titleContent.setVoiceViewProperties(
               writeVoiceViewProperties(realTitleContent));
         }
      }

      // Fill in the page objects, creating control objects if necessary.
      for (Iterator i = realDialog.getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();
         for (Iterator j = realDialog.getPages(realDeviceType).iterator();
            j.hasNext();
            ) {
            final edu.berkeley.guir.damask.dialog.Page realPage =
               (edu.berkeley.guir.damask.dialog.Page)j.next();
            final Page page = (Page)xmlElements.get(realPage);
            //HACK
            if (page != null) {
               addControlsToPage(realPage, page, controls);
            }
         }
      }
      
      // Write out the groups
      final Groups groups = objFactory.createGroups();
      dialog.setGroups(groups);

      for (Iterator i = realDialog.getGroups().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.component.ComponentGroup realGroup =
            (edu.berkeley.guir.damask.component.ComponentGroup)i.next();

         final Group group = objFactory.createGroup();
         xmlElements.put(realGroup, group);
         groups.getGroup().add(group);

         group.setId(writeId(realGroup));

         group.setBoundsAndTransformsForGroup(
            writeBoundsAndTransformsForGroup(realGroup));
      }

      for (Iterator i = realDialog.getGroups().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.component.ComponentGroup realGroup =
            (edu.berkeley.guir.damask.component.ComponentGroup)i.next();

         final Group group = (Group)xmlElements.get(realGroup);

         final Components components = objFactory.createComponents();
         group.setComponents(components);
         for (Iterator j = realGroup.getChildren().iterator(); j.hasNext(); ) {
            final edu.berkeley.guir.damask.component.Component realComponent =
               (edu.berkeley.guir.damask.component.Component)j.next();
            final ComponentRef componentRef = objFactory.createComponentRef();
            componentRef.setRef(xmlElements.get(realComponent));
            components.getComponentRef().add(componentRef);
         }
      }

      return dialog;
   }


   /**
    * Creates an XML-compatible ID for the specified interaction element.
    */
   private static String writeId(
      final edu.berkeley.guir.damask.InteractionElement realElement) {

      // Replace the invalid characters in the ID string with underscores.
      java.util.regex.Matcher matcher =
         INVALID_ID_CHARS.matcher(realElement.getId().toString());

      return matcher.replaceAll("_");
   }


   /**
    * Creates a big integer from the specified integer.
    */
   private static BigInteger createBigInteger(final int num) {
      return new BigInteger(Integer.toString(num));
   }


   /**
    * Takes the specified bounds, and creates a content tree fragment to be
    * written out as XML.
    */
   private static Bounds writeBounds(final Rectangle2D realBounds)
      throws JAXBException {

      final Bounds bounds = objFactory.createBounds();
      bounds.setX(realBounds.getX());
      bounds.setY(realBounds.getY());
      bounds.setWidth(realBounds.getWidth());
      bounds.setHeight(realBounds.getHeight());

      return bounds;
   }


   /**
    * Takes the specified transform, and creates a content tree fragment to be
    * written out as XML.
    */
   private static Transform writeTransform(final AffineTransform realTransform)
      throws JAXBException {

      final Transform transform = objFactory.createTransform();
      transform.setScaleX(realTransform.getScaleX());
      transform.setScaleY(realTransform.getScaleY());
      transform.setShearX(realTransform.getShearX());
      transform.setShearY(realTransform.getShearY());
      transform.setTranslateX(realTransform.getTranslateX());
      transform.setTranslateY(realTransform.getTranslateY());

      return transform;
   }


   /**
    * Fills in the specified Page content tree object with information from the
    * specified page, creating content tree objects within the specified
    * Controls object if necessary.
    */
   private static void addControlsToPage(
      final edu.berkeley.guir.damask.dialog.Page realPage,
      final Page page,
      final Controls controls) throws JAXBException {

      final Regions regions = objFactory.createRegions();
      page.setRegions(regions);

      for (Iterator i = realPage.getRegions().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.dialog.PageRegion realRegion =
            (edu.berkeley.guir.damask.dialog.PageRegion)i.next();

         final Region region = objFactory.createRegion();
         xmlElements.put(realRegion, region);
         regions.getRegion().add(region);

         region.setName(realRegion.getName().toString());
         region.setInset(createBigInteger(realRegion.getInset()));

         final List regionControls = region.getControlRef();

         for (Iterator j = realRegion.getControls().iterator(); j.hasNext(); ) {
            final edu.berkeley.guir.damask.component.Control realControl =
               (edu.berkeley.guir.damask.component.Control)j.next();
            Object control = xmlElements.get(realControl);
            if (control == null) {
               control = writeControl(realControl);
               controls.getControl().add(control);
               xmlElements.put(realControl, control);
            }
            final ControlRef controlRef = objFactory.createControlRef();
            controlRef.setRef(control);
            regionControls.add(controlRef);
         }
      }
   }


   /**
    * Takes the specified control, and creates a content tree fragment to be
    * written out as XML.
    */
   private static Object writeControl(
      final edu.berkeley.guir.damask.component.Control realControl)
      throws JAXBException {

      final Object control;

      if (realControl
         instanceof edu.berkeley.guir.damask.component.Content) {

         control = objFactory.createControlsContent();
         writeIntoContent(
            (edu.berkeley.guir.damask.component.Content)realControl,
            (Content)control);
      }
      else if (realControl
         instanceof edu.berkeley.guir.damask.component.TextInput) {

         control = objFactory.createControlsTextInput();
         writeIntoTextInput(
            (edu.berkeley.guir.damask.component.TextInput)realControl,
            (TextInput)control);
      }
      else if (realControl
         instanceof edu.berkeley.guir.damask.component.Trigger) {

         control = objFactory.createControlsTrigger();
         writeIntoTrigger(
            (edu.berkeley.guir.damask.component.Trigger)realControl,
            (Trigger)control);
      }
      else if (realControl
         instanceof edu.berkeley.guir.damask.component.SelectOne) {

         control = objFactory.createControlsSelectOne();
         writeIntoSelectOne(
            (edu.berkeley.guir.damask.component.SelectOne)realControl,
            (SelectOne)control);
      }
      else if (realControl
         instanceof edu.berkeley.guir.damask.component.SelectMany) {

         control = objFactory.createControlsSelectMany();
         writeIntoSelectMany(
            (edu.berkeley.guir.damask.component.SelectMany)realControl,
            (SelectMany)control);
      }
      else {
         control = null;
      }

      return control;
   }


   /**
    * Takes the specified content, and creates a content tree fragment to be
    * written out as XML.
    */
   private static Content writeContent(
      final edu.berkeley.guir.damask.component.Content realContent)
      throws JAXBException {

      final Content content = objFactory.createContent();
      writeIntoContent(realContent, content);
      return content;
   }

   /**
    * Fills in the content tree fragment with data from the specified content.
    */
   private static void writeIntoContent(
      final edu.berkeley.guir.damask.component.Content realContent,
      final Content content)

      throws JAXBException {

      xmlElements.put(realContent, content);
      content.setId(writeId(realContent));
      content.setBoundsAndTransforms(writeBoundsAndTransforms(realContent));
      content.setStates(writeStates(realContent));
      content.setSignificances(writeSignificances(realContent));

      // Write out the text content.
      final String realText = realContent.getText();
      if (realText != null) {
         final TextContent textContent = objFactory.createTextContent();

         textContent.setText(realText);

         final TextSizes textSizes = objFactory.createTextSizes();
         textContent.setTextSizes(textSizes);

         for (Iterator i = realContent.getDeviceTypesVisibleTo().iterator();
            i.hasNext();
            ) {
            final edu.berkeley.guir.damask.DeviceType realDeviceType =
               (edu.berkeley.guir.damask.DeviceType)i.next();
            final TextSize textSize = objFactory.createTextSize();
            textSize.setDeviceType(realDeviceType.toString());
            textSize.setSize(
               createBigInteger(realContent.getTextSize(realDeviceType)));

            textSizes.getTextSize().add(textSize);
         }

         if (realContent.getVoicePromptText() != null) {
            textContent.setVoiceText(realContent.getVoicePromptText());
         }
         
         content.setTextContent(textContent);
      }

      // Write out the image content.
      final BufferedImage realImage = realContent.getImage();
      if (realImage != null) {
         try {
            final ImageContent imageContent = objFactory.createImageContent();
            imageContent.setType("image/png");
            imageContent.setEncoding("base64");
            final ByteArrayOutputStream imageOutStream =
               new ByteArrayOutputStream();
            ImageIO.write(realImage, "png", imageOutStream);
            final byte[] imageData = imageOutStream.toByteArray();
            final String imageDataStr =
               new String(Base64.encodeBase64(imageData));
            imageContent.setImageData(imageDataStr);

            content.setImageContent(imageContent);
         }
         catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }

      // Write out the strokes content.
      final Collection/*<GeneralPath>*/ realStrokes = realContent.getStrokes();
      if (!realStrokes.isEmpty()) {
         final Polylines strokesContent = objFactory.createPolylines();

         for (Iterator i = realStrokes.iterator(); i.hasNext(); ) {
            final GeneralPath realStroke = (GeneralPath)i.next();
            final Polyline polyline = writePolyline(realStroke);
            strokesContent.getPolyline().add(polyline);
         }

         content.setStrokesContent(strokesContent);
      }

      // Write out the preferred display modes.
      final DisplayModes displayModes = objFactory.createDisplayModes();
      content.setDisplayModes(displayModes);

      for (Iterator i = realContent.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         final edu.berkeley.guir.damask.component.Content.DisplayMode
            realDisplayMode =
            realContent.getPreferredDisplayMode(realDeviceType);

         final DisplayMode displayMode = objFactory.createDisplayMode();
         displayMode.setDeviceType(realDeviceType.toString());
         displayMode.setMode(realDisplayMode.toString());

         displayModes.getDisplayMode().add(displayMode);
      }
   }


   /**
    * Takes the specified text input, and creates a content tree fragment to be
    * written out as XML.
    */
   private static void writeIntoTextInput(
      final edu.berkeley.guir.damask.component.TextInput realTextInput,
      final TextInput textInput)
      throws JAXBException {

      xmlElements.put(realTextInput, textInput);
      textInput.setId(writeId(realTextInput));
      textInput.setBoundsAndTransforms(writeBoundsAndTransforms(realTextInput));
      textInput.setStates(writeStates(realTextInput));
      textInput.setSignificances(writeSignificances(realTextInput));

      // Write out the borders.
      final Borders borders = objFactory.createBorders();

      for (Iterator i = realTextInput.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         final GeneralPath realBorder = realTextInput.getBorder(realDeviceType);

         if (realBorder != null) {
            final Border border = objFactory.createBorder();
            border.setDeviceType(realDeviceType.toString());
            border.setPolyline(writePolyline(realBorder));
            borders.getBorder().add(border);
         }
      }
      if (!borders.getBorder().isEmpty()) {
         textInput.setBorders(borders);
      }
   }


   /**
    * Takes the specified trigger, and creates a content tree fragment to be
    * written out as XML.
    */
   private static void writeIntoTrigger(
      final edu.berkeley.guir.damask.component.Trigger realTrigger,
      final Trigger trigger)
      throws JAXBException {

      xmlElements.put(realTrigger, trigger);
      trigger.setId(writeId(realTrigger));
      trigger.setBoundsAndTransforms(writeBoundsAndTransforms(realTrigger));
      trigger.setStates(writeStates(realTrigger));
      trigger.setSignificances(writeSignificances(realTrigger));

      // Write out the borders.
      final Borders borders = objFactory.createBorders();

      for (Iterator i = realTrigger.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         final GeneralPath realBorder = realTrigger.getBorder(realDeviceType);

         if (realBorder != null) {
            final Border border = objFactory.createBorder();
            border.setDeviceType(realDeviceType.toString());
            border.setPolyline(writePolyline(realBorder));
            borders.getBorder().add(border);
         }
      }
      if (!borders.getBorder().isEmpty()) {
         trigger.setBorders(borders);
      }

      // Write out the styles.
      final Styles styles = objFactory.createStyles();

      for (Iterator i = realTrigger.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         final edu.berkeley.guir.damask.component.Trigger.Style realStyle =
            realTrigger.getStyle(realDeviceType);

         if (realStyle != null) {
            final Style style = objFactory.createStyle();
            style.setDeviceType(realDeviceType.toString());
            style.setName(realStyle.toString());
            styles.getStyle().add(style);
         }
      }
      if (!styles.getStyle().isEmpty()) {
         trigger.setStyles(styles);
      }

      // Write out the content.
      trigger.setContent(writeContent(realTrigger.getContent()));
   }


   /**
    * Takes the specified select-one, and creates a content tree fragment to be
    * written out as XML.
    */
   private static void writeIntoSelectOne(
      final edu.berkeley.guir.damask.component.SelectOne realSelectOne,
      final SelectOne selectOne)
      throws JAXBException {

      xmlElements.put(realSelectOne, selectOne);
      selectOne.setId(writeId(realSelectOne));
      selectOne.setBoundsAndTransforms(writeBoundsAndTransforms(realSelectOne));

      // Write out the styles.
      final Styles styles = objFactory.createStyles();

      for (Iterator i = realSelectOne.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         final edu.berkeley.guir.damask.component.SelectOne.Style realStyle =
            realSelectOne.getStyle(realDeviceType);

         if (realStyle != null) {
            final Style style = objFactory.createStyle();
            style.setDeviceType(realDeviceType.toString());
            style.setName(realStyle.toString());
            styles.getStyle().add(style);
         }
      }
      if (!styles.getStyle().isEmpty()) {
         selectOne.setStyles(styles);
      }

      // Write out the items.
      final Items items = objFactory.createItems();

      for (Iterator i = realSelectOne.getItems().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.component.SelectOne.Item realItem =
            (edu.berkeley.guir.damask.component.SelectOne.Item)i.next();

         final Item item = writeSelectItem(realItem);
         items.getItem().add(item);
      }
      selectOne.setItems(items);
      
      // Now that the items have been written, write out the states
      // and significances.
      selectOne.setStates(writeStates(realSelectOne));
      selectOne.setSignificances(writeSignificances(realSelectOne));
   }


   /**
    * Takes the specified select-one, and creates a content tree fragment to be
    * written out as XML.
    */
   private static void writeIntoSelectMany(
      final edu.berkeley.guir.damask.component.SelectMany realSelectMany,
      final SelectMany selectMany)
      throws JAXBException {

      xmlElements.put(realSelectMany, selectMany);
      selectMany.setId(writeId(realSelectMany));
      selectMany.setBoundsAndTransforms(writeBoundsAndTransforms(realSelectMany));

      // Write out the styles.
      final Styles styles = objFactory.createStyles();

      for (Iterator i = realSelectMany.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         final edu.berkeley.guir.damask.component.SelectMany.Style realStyle =
            realSelectMany.getStyle(realDeviceType);

         if (realStyle != null) {
            final Style style = objFactory.createStyle();
            style.setDeviceType(realDeviceType.toString());
            style.setName(realStyle.toString());
            styles.getStyle().add(style);
         }
      }
      if (!styles.getStyle().isEmpty()) {
         selectMany.setStyles(styles);
      }

      // Write out the items.
      final Items items = objFactory.createItems();

      for (Iterator i = realSelectMany.getItems().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.component.SelectMany.Item realItem =
            (edu.berkeley.guir.damask.component.SelectMany.Item)i.next();

         final Item item = writeSelectItem(realItem);
         items.getItem().add(item);
      }
      selectMany.setItems(items);

      // Now that the items have been written, write out the states
      // and significances.
      selectMany.setStates(writeStates(realSelectMany));
      selectMany.setSignificances(writeSignificances(realSelectMany));
   }


   /**
    * Takes the specified item, and creates a content tree fragment to be
    * written out as XML.
    */
   private static Item writeSelectItem(
      final edu.berkeley.guir.damask.component.Select.Item realSelectItem)
      throws JAXBException {

      final Item item = objFactory.createItem();
      xmlElements.put(realSelectItem, item);
      item.setId(writeId(realSelectItem));
      item.setBoundsAndTransforms(writeBoundsAndTransforms(realSelectItem));

      item.setContent(writeContent(realSelectItem.getContent()));

      return item;
   }


   /**
    * Takes the specified control, and creates a content tree fragment,
    * containing the control's bounds and transforms, to be written out
    * as XML.
    */
   private static BoundsAndTransforms writeBoundsAndTransforms(
      final edu.berkeley.guir.damask.InteractionElement realElement)
      throws JAXBException {

      final BoundsAndTransforms boundsAndTransforms =
         objFactory.createBoundsAndTransforms();

      for (Iterator i = realElement.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         if (!((realDeviceType == edu.berkeley.guir.damask.DeviceType.VOICE) &&
               (realElement instanceof
                edu.berkeley.guir.damask.component.Component))) {
            final BoundsAndTransform boundsAndTransform =
               objFactory.createBoundsAndTransform();
            boundsAndTransform.setDeviceType(realDeviceType.toString());
            boundsAndTransform.setBounds(
               writeBounds(realElement.getBounds(realDeviceType)));
            boundsAndTransform.setTransform(
               writeTransform(realElement.getTransform(realDeviceType)));
            boundsAndTransforms.getBoundsAndTransform().add(boundsAndTransform);
         }
      }

      return boundsAndTransforms;
   }


   /**
    * Takes the specified control, and creates a content tree fragment,
    * containing the control's bounds and transforms, to be written out
    * as XML.
    */
   private static BoundsAndTransformsForGroup writeBoundsAndTransformsForGroup(
      final edu.berkeley.guir.damask.component.ComponentGroup realGroup)
      throws JAXBException {

      final BoundsAndTransformsForGroup boundsAndTransformsForGroup =
         objFactory.createBoundsAndTransformsForGroup();

      for (Iterator i = realGroup.getPageRegions().iterator(); i.hasNext(); ) {
         final edu.berkeley.guir.damask.dialog.PageRegion realRegion =
            (edu.berkeley.guir.damask.dialog.PageRegion)i.next();

         final BoundsAndTransformInRegion boundsAndTransformInRegion =
            objFactory.createBoundsAndTransformInRegion();
         boundsAndTransformInRegion.setPage(xmlElements.get(realRegion.getPage()));
         boundsAndTransformInRegion.setRegion(realRegion.getName().toString());
         boundsAndTransformInRegion.setBounds(
            writeBounds(realGroup.getBoundsInPageRegion(realRegion)));
         boundsAndTransformInRegion.setTransform(
            writeTransform(realGroup.getTransformInPageRegion(realRegion)));

         boundsAndTransformsForGroup.getBoundsAndTransformInRegion().add(
            boundsAndTransformInRegion);
      }

      return boundsAndTransformsForGroup;
   }

   
   /**
    * Takes the specified control, and creates a content tree fragment,
    * containing the control's voice UI properties, to be written out
    * as XML.
    */
   private static VoiceViewProperties writeVoiceViewProperties(
      final edu.berkeley.guir.damask.component.Control realControl)
      throws JAXBException {

      final VoiceViewProperties props =
         objFactory.createVoiceViewProperties();

      final Rectangle2D promptBounds = realControl.getVoicePromptBounds();
      if (promptBounds != null) {
         final Prompt prompt = objFactory.createPrompt();
         props.setPrompt(prompt);
         prompt.setBounds(writeBounds(promptBounds));
         prompt.setText(realControl.getVoicePromptText());
      }

      boolean hasResponse = false;
      final Response response = objFactory.createResponse();
      
      final Lines lines = objFactory.createLines();
      response.setLines(lines);
      
      final int numConditions;
      final edu.berkeley.guir.damask.dialog.Dialog dialogOfRealControl =
         realControl.getDialog();
      if (dialogOfRealControl == null) {
         numConditions = 0;
      }
      else {
         numConditions = dialogOfRealControl.getNumConditions();
      }
      
      for (int i = 0; i < numConditions; i++) {
         final Line2D realLine = realControl.getVoiceResponseLine(i);
         if (realLine != null) {
            hasResponse = true;
            final ResponseLine line = objFactory.createResponseLine();
            line.setCondition(createBigInteger(i));
            line.setX1(realLine.getX1());
            line.setY1(realLine.getY1());
            line.setX2(realLine.getX2());
            line.setY2(realLine.getY2());
            lines.getResponseLine().add(line);
         }
      }
      
      if (realControl instanceof
            edu.berkeley.guir.damask.component.SelectMany.Item) {
         final List/*<String>*/ textList = realControl.getVoiceResponseTextList();
         if (!textList.isEmpty()) {
            final Texts texts = objFactory.createTexts();
            for (int i = 0, n = textList.size(); i < n; i++) {
               texts.getText().add(textList.get(i));
            }
            response.setTexts(texts);
         }
      }
      
      if (hasResponse) {
         props.setResponse(response);
      }

      props.setTransform(
         writeTransform(realControl.getTransform(
            edu.berkeley.guir.damask.DeviceType.VOICE)));

      return props;
   }

   /**
    * Takes the specified control, and creates a content tree fragment,
    * containing the control's state, to be written out as XML.
    */
   private static States writeStates(
      final edu.berkeley.guir.damask.component.Control realControl)
      throws JAXBException {

      final States states = objFactory.createStates();

      final edu.berkeley.guir.damask.dialog.Dialog realDialog =
         realControl.getDialog();

      if (realDialog != null) {
         final StatesForDialog statesForDialog = objFactory.createStatesForDialog();
         statesForDialog.setDialog(xmlElements.get(realDialog));

         for (int j = 0, n = realDialog.getNumConditions(); j < n; j++) {
            final Object realState =
               realControl.getStateForCondition(realDialog, j);

            if (realState != null) {
               final StateForCondition condition =
                  objFactory.createStateForCondition();
               condition.setConditionNum(createBigInteger(j));

               if (realState instanceof Collection) {
                  final MultiState multiState =
                     objFactory.createMultiState();
                  for (Iterator k = ((Collection)realState).iterator();
                     k.hasNext();
                     ) {
                     final Object oneRealState = k.next();
                     multiState.getState().add(writeState(oneRealState));
                  }
                  condition.setMultiState(multiState);
               }
               else {
                  if (realState instanceof Integer) {
                     condition.setIntegerState(
                        objFactory.createStateIntegerState(
                           new BigInteger(((Integer)realState).toString())
                        )
                     );
                  }
                  else if (realState instanceof Boolean) {
                     condition.setBooleanState(
                        objFactory.createStateBooleanState(
                           ((Boolean)realState).booleanValue()
                        )
                     );
                  }
                  else if (realState instanceof String) {
                     condition.setStringState(
                        objFactory.createStateStringState(
                           (String)realState
                        )
                     );
                  }
                  else if (
                     realState
                     instanceof edu.berkeley.guir.damask.InteractionElement) {
                     condition.setIDREFState(
                        objFactory.createStateIDREFState(
                           xmlElements.get(realState)
                        )
                     );
                  }
               }
               statesForDialog.getStateForCondition().add(condition);
            }
         }
         states.getStatesForDialog().add(statesForDialog);
      }

      return states;
   }
   /**
    * Takes the specified state, and creates a content tree fragment to be
    * written out as XML.
    */
   private static Object writeState(final Object realState)
      throws JAXBException {

      final Object state;

      if (realState instanceof Integer) {
         state =
            objFactory.createStateIntegerState(
               new BigInteger(((Integer)realState).toString()));
      }
      else if (realState instanceof Boolean) {
         state =
            objFactory.createStateBooleanState(
               ((Boolean)realState).booleanValue());
      }
      else if (realState instanceof String) {
         state = objFactory.createStateStringState((String)realState);
      }
      else if (
         realState instanceof edu.berkeley.guir.damask.InteractionElement) {
         state =
            objFactory.createStateIDREFState(xmlElements.get(realState));
      }
      else {
         state = null;
      }

      return state;
   }


   /**
    * Takes the specified control, and creates a content tree fragment,
    * containing how significant the control's state is for particular
    * conditions, to be written out as XML.
    */
   private static Significances writeSignificances(
      final edu.berkeley.guir.damask.component.Control realControl)
      throws JAXBException {

      final Significances sigs = objFactory.createSignificances();

      final edu.berkeley.guir.damask.dialog.Dialog realDialog =
         realControl.getDialog();

      if (realDialog != null) {
         final SignificancesForDialog sigsForDialog =
            objFactory.createSignificancesForDialog();
         sigsForDialog.setDialog(xmlElements.get(realDialog));

         for (int j = 0, n = realDialog.getNumConditions(); j < n; j++) {
            final Significance sig = objFactory.createSignificance();
            sig.setCondition(createBigInteger(j));
            sig.setValue(
               realControl.isStateSignificantForCondition(realDialog, j));
            sigsForDialog.getSignificance().add(sig);
         }

         sigs.getSignificancesForDialog().add(sigsForDialog);
      }

      return sigs;
   }


   /**
    * Takes the specified control, and creates a content tree fragment,
    * containing how significant the control's state is for particular
    * conditions, to be written out as XML.
    */
   private static Polyline writePolyline(final GeneralPath genPath)
      throws JAXBException {

      final Polygon2D realPoly =
         GeomLib.pathIteratorToPolygon2D(genPath.getPathIterator(null));

      final Polyline polyline = objFactory.createPolyline();

      for (int i = 0, n = realPoly.npoints; i < n; i++) {
         final Point point = objFactory.createPoint();
         point.setX(realPoly.xpoints[i]);
         point.setY(realPoly.ypoints[i]);
         polyline.getPoint().add(point);
      }

      return polyline;
   }


   /**
    * Takes the specified connection, and creates a content tree fragment to be
    * written out as XML.
    */
   private static Connection writeConnection(
      final edu.berkeley.guir.damask.connection.Connection realConnection)
      throws JAXBException {

      final edu.berkeley.guir.damask.DeviceType origRealDeviceType =
         realConnection.getOrigSpecifiedDeviceType();

      final Connection connection = objFactory.createConnection();
      xmlElements.put(realConnection, connection);
      connection.setId(writeId(realConnection));
      connection.setOrigDeviceType(origRealDeviceType.toString());
      connection.setForAllDeviceTypes(realConnection.isForAllDeviceTypes());
      connection.setSourceForOrigDeviceType(
         xmlElements.get(
            realConnection.getConnectionSource(origRealDeviceType)));
      connection.setDestForOrigDeviceType(
         xmlElements.get(
            realConnection.getConnectionDest(origRealDeviceType)));
      if (realConnection instanceof
      edu.berkeley.guir.damask.connection.NavConnection) {
         final edu.berkeley.guir.damask.connection.NavConnection
            realNavConnection =
            (edu.berkeley.guir.damask.connection.NavConnection)realConnection;
         connection.setUserEvent(
            writeUserEvent(realNavConnection.getUserEvent()));
         connection.setCondition(
            createBigInteger(realNavConnection.getCondition()));
      }

      // Write out the shapes.
      for (Iterator i = realConnection.getDeviceTypesVisibleTo().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.DeviceType realDeviceType =
            (edu.berkeley.guir.damask.DeviceType)i.next();

         final GeneralPath realShape = realConnection.getShape(realDeviceType);
         if (realShape != null) {
            final ConnectionShape shape = objFactory.createConnectionShape();
            connection.getConnectionShape().add(shape);
            shape.setDeviceType(realDeviceType.toString());
            shape.setPolyline(writePolyline(realShape));
         }
      }

      return connection;
   }


   /**
    * Takes the specified control, and creates a content tree fragment to be
    * written out as XML.
    */
   private static UserEvent writeUserEvent(
      final edu.berkeley.guir.damask.userevent.DamaskUserEvent realUserEvent)
      throws JAXBException {

      final Element userEventElement;

      if (realUserEvent
         instanceof edu.berkeley.guir.damask.userevent.HoverOverEvent) {

         userEventElement = objFactory.createUserEventHoverOverEvent();
         ((HoverOverEvent)userEventElement).setSource(
            xmlElements.get(
               realUserEvent.getSource()));
      }
      else if (realUserEvent
         instanceof edu.berkeley.guir.damask.userevent.HoverOffEvent) {

         userEventElement = objFactory.createUserEventHoverOffEvent();
         ((HoverOffEvent)userEventElement).setSource(
            xmlElements.get(
               realUserEvent.getSource()));
      }
      else if (realUserEvent
         instanceof edu.berkeley.guir.damask.userevent.InvokeEvent) {

         userEventElement = objFactory.createUserEventInvokeEvent();
         ((InvokeEvent)userEventElement).setSource(
            xmlElements.get(
               realUserEvent.getSource()));
      }
      else if (realUserEvent
         instanceof edu.berkeley.guir.damask.userevent.SecondaryInvokeEvent) {

         userEventElement = objFactory.createUserEventSecondaryInvokeEvent();
         ((SecondaryInvokeEvent)userEventElement).setSource(
            xmlElements.get(
               realUserEvent.getSource()));
      }
      else if (realUserEvent
         instanceof edu.berkeley.guir.damask.userevent.SelectEvent) {

         userEventElement = objFactory.createUserEventSelectEvent();
         ((SelectEvent)userEventElement).setSource(
            xmlElements.get(
               realUserEvent.getSource()));
      }
      else {
         userEventElement = null;
      }

      final UserEvent userEvent = objFactory.createUserEvent();
      userEvent.setUserEvent(userEventElement);
      return userEvent;
   }


   /**
    * Takes the specified pattern instance, and creates a content tree
    * fragment to be written out as XML.
    */
   private static PatternInstance writePatternInstance(
      final edu.berkeley.guir.damask.pattern.PatternInstance realPatternInstance)
      throws JAXBException {

      final PatternInstance patternInstance = objFactory.createPatternInstance();
      xmlElements.put(realPatternInstance, patternInstance);
      patternInstance.setId(writeId(realPatternInstance));
      patternInstance.setPatternID(realPatternInstance.getPattern().getID());
      patternInstance.setCollectionID(
         realPatternInstance.getPattern().getCollectionID());

      // Write out the members.
      for (Iterator i = realPatternInstance.getMembers().iterator();
         i.hasNext();
         ) {
         final edu.berkeley.guir.damask.pattern.PatternInstanceMember
         realMember =
            (edu.berkeley.guir.damask.pattern.PatternInstanceMember)i.next();

         final ElementRef elementRef = objFactory.createElementRef();
         final Object element = xmlElements.get(realMember);
         if (element != null) {
            elementRef.setRef(element);
            patternInstance.getElementRef().add(elementRef);
         }
      }

      return patternInstance;
   }
}
