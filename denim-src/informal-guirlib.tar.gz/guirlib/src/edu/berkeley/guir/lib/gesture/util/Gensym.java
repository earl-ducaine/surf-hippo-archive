package edu.berkeley.guir.lib.gesture.util;

import java.util.*;

public class Gensym {
  protected static int globalCounter = 1;
  protected static HashMap indices = new HashMap();
  
  protected Gensym() {}

  public static String next()
  {
    String result = "" + globalCounter;
    globalCounter += 1;
    return result;
  }

  public static String next(String prefix)
  {
    if (!indices.containsKey(prefix)) {
      indices.put(prefix, new Integer(1));
    }

    Integer index = (Integer) indices.get(prefix);
    String result = prefix + index;
    index = new Integer(index.intValue() + 1);
    indices.put(prefix, index);
    return result;
  }
}
