package edu.berkeley.guir.denim.interpreters;

import java.awt.*;
import java.awt.geom.*;
import edu.berkeley.guir.denim.command.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.interpreter.*;

/**
 * <p>
 * Resizes Denim objects.
 * </p>
 * 
 * <p>
 * Ideally:
 * </p>
 * 
 * <ul>
 * <li>If the selected object is a component instance, then resizing stretches
 * the contents of the instance</li>
 * <li>Otherwise, resizing only changes the bounds of the object</li>
 * </ul>
 * 
 * <p>
 * Currently, it always stretches.
 * </p>
 * 
 * <P>
 * This software is distributed under the <A
 * HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt"> Berkeley Software
 * License </A>.
 * 
 * <PRE>
 * 
 * Revisions: 1.0.0 08-18-1999 JL Created class ResizePatchInterpreter, based on
 * ...satin.interpreter.command.ResizeSelectedInterpreter Sometime later JL
 * Renamed ResizeInterpreter.
 * 
 * </PRE>
 * 
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin </A>( <A
 *         HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu </A>)
 * @since JDK 1.2.2
 * @version Version 1.0.0, 10-31-1999
 */
public class ResizeInterpreter extends InterpreterImpl {

    //===========================================================================
    //=== CONSTANTS =========================================================

    static final long serialVersionUID = 2466088861502648686L;

    private static final int BOUNDS_THRESHOLD = 5;

    private static final int SCALE_THRESHOLD = 1;

    private static final int TOPLEFT = 8;

    private static final int TOP = 9;

    private static final int TOPRIGHT = 10;

    private static final int RIGHT = 11;

    private static final int BOTTOMRIGHT = 12;

    private static final int BOTTOM = 13;

    private static final int BOTTOMLEFT = 14;

    private static final int LEFT = 15;

    //=== CONSTANTS =========================================================
    //===========================================================================

    //===========================================================================
    //=== NONLOCAL VARIABLES ================================================

    protected GraphicalObject selgob; // the gob to resize

    protected int position; // TOPLEFT, TOP, RIGHT, etc...

    protected boolean isResizing; // true if the interpreter

    // is being used

    private Rectangle2D mOldResizingBounds = null;

    //=== NONLOCAL VARIABLES ================================================
    //===========================================================================

    //===========================================================================
    //=== CONSTRUCTORS ======================================================

    /**
     * Constructs a resize interpreter.
     */
    public ResizeInterpreter() {
        super();
        commonInitializations();
    } // of constructor

    //-----------------------------------------------------------------

    /**
     * Constructs a resize interpreter as a copy of the given interpreter.
     */
    public ResizeInterpreter(ResizeInterpreter intrp) {
        commonInitializations();
    } // of copy constructor

    //-----------------------------------------------------------------

    /**
     * Perform initializations common to all constructors.
     */
    private void commonInitializations() {
        isResizing = false;
        setName("Denim Resize Selected Item Interpreter");
    } // of commonInitializations

    //=== CONSTRUCTORS ======================================================
    //===========================================================================

    //===========================================================================
    //=== MISCELLANEOUS METHODS =============================================

    /**
     * Returns whether the given point is near the given bounds.
     */
    private boolean isNearBounds(Rectangle2D bds, Point2D pt) {
        Line2D line = new Line2D.Float();
        Point2D ptCorner = new Point2D.Float();

        //// 1. First case, top-left of rectangle...
        ptCorner.setLocation(bds.getX(), bds.getY());
        if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
            position = TOPLEFT;
            return (true);
        }

        //// 2. Second case, top-right of rectangle...
        ptCorner.setLocation(bds.getX() + bds.getWidth(), bds.getY());
        if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
            position = TOPRIGHT;
            return (true);
        }

        //// 3. Third case, bottom-right of rectangle...
        ptCorner.setLocation(bds.getX() + bds.getWidth(), bds.getY()
                + bds.getHeight());
        if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
            position = BOTTOMRIGHT;
            return (true);
        }

        //// 4. Fourth case, bottom-left of rectangle...
        ptCorner.setLocation(bds.getX(), bds.getY() + bds.getHeight());
        if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
            position = BOTTOMLEFT;
            return (true);
        }

        //// 5. First case, top of rectangle...
        line.setLine(bds.getX(), bds.getY(), bds.getX() + bds.getWidth(), bds
                .getY());
        if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
            position = TOP;
            return (true);
        }

        //// 6. Second case, right side of rectangle...
        line.setLine(bds.getX() + bds.getWidth(), bds.getY(), bds.getX()
                + bds.getWidth(), bds.getY() + bds.getHeight());
        if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
            position = RIGHT;
            return (true);
        }

        //// 7. Third case, bottom side of rectangle...
        line.setLine(bds.getX(), bds.getY() + bds.getHeight(), bds.getX()
                + bds.getWidth(), bds.getY() + bds.getHeight());
        if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
            position = BOTTOM;
            return (true);
        }

        //// 8. Fourth case, left side of rectangle...
        line.setLine(bds.getX(), bds.getY(), bds.getX(), bds.getY()
                + bds.getHeight());
        if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
            position = LEFT;
            return (true);
        }

        return (false);
    } // of isNearBounds

    //-----------------------------------------------------------------

    /**
     * Returns a string representation for the given rectangle.
     */
    private String rectStr(Rectangle2D rect) {
        return "" + rect.getX() + ", " + rect.getY() + "; "
                + (rect.getX() + rect.getWidth()) + ", "
                + (rect.getY() + rect.getHeight());
    }

    //-----------------------------------------------------------------

    /**
     * Returns the new size of the denimComponentInstance
     */
    protected Point2D getNewDimension(Rectangle2D oldBounds, Point2D pt,
            double width, double height) {
        double xTopleft = oldBounds.getX();
        double yTopleft = oldBounds.getY();
        double w = oldBounds.getWidth();
        double h = oldBounds.getHeight();
        Point2D result = new Point2D.Double();
        double ptx = pt.getX();
        double pty = pt.getY();
        result.setLocation(width, height);

        switch (position) {
        case RIGHT:
            result.setLocation((ptx - xTopleft) * width / w, height);
            break;
        case BOTTOMRIGHT:
            result.setLocation((ptx - xTopleft) * width / w, (pty - yTopleft)
                    * height / h);
            break;
        case BOTTOM:
            result.setLocation(width, (pty - yTopleft) * height / h);
            break;
        } // of switch
        //we only need to test the right and bottom sides because these are
        // textarea,
        //textfield, and radiobutton etc. Doesn't make sense to expand them to
        // the left
        //to the top
        return result;
    }

    /**
     * Returns the bounding box of the given rectangle and point.
     */
    protected Rectangle2D getNewBounds(Rectangle2D oldBounds, Point2D pt) {
        Rectangle2D bounds = new Rectangle2D.Float();

        double x1 = oldBounds.getX();
        double y1 = oldBounds.getY();
        double x2 = oldBounds.getX() + oldBounds.getWidth();
        double y2 = oldBounds.getY() + oldBounds.getHeight();

        switch (position) {
        case TOPLEFT:
            x1 = pt.getX();
            y1 = pt.getY();
            break;
        case TOP:
            y1 = pt.getY();
            break;
        case TOPRIGHT:
            x2 = pt.getX();
            y1 = pt.getY();
            break;
        case RIGHT:
            x2 = pt.getX();
            break;
        case BOTTOMRIGHT:
            x2 = pt.getX();
            y2 = pt.getY();
            break;
        case BOTTOM:
            y2 = pt.getY();
            break;
        case BOTTOMLEFT:
            x1 = pt.getX();
            y2 = pt.getY();
            break;
        case LEFT:
            x1 = pt.getX();
            break;
        } // of switch

        bounds.setRect(x1, y1, x2 - x1, y2 - y1);

        return (bounds);
    } // of getNewBounds

    //=== MISCELLANEOUS METHODS =============================================
    //===========================================================================

    //===========================================================================
    //=== STROKE METHODS ====================================================

    /**
     * Start resizing when the user starts to drag a resize handle.
     * 
     * <p>
     * HACK: Currently, we are punting and handling resizing of only one
     * graphical object. No use doing a lot of work if we haven't even
     * implemented the "real" resize gesture yet.
     */
    public void handleNewStroke(NewStrokeEvent evt) {
        TimedStroke stk = evt.getStroke();
        DenimSheet sheet = (DenimSheet) (getAttachedGraphicalObject()
                .getSheet());
        selgob = null;
        mOldResizingBounds = null;

        //// 1. If the user clicked near the bounding box of the selected
        //// objects, then create a patch containing the selected objects
        //// for later manipulation
        GraphicalObjectCollection selCol = cmdsubsys.getSelectedCollection();
        if (selCol != null && selCol.numElements() == 1) {
            selgob = (GraphicalObject) cmdsubsys.getSelected().next();
            Debug.println("oldBounds: "
                    + rectStr(selgob.getBounds2D(COORD_REL)));

            if (isNearBounds(selgob.getBounds2D(COORD_ABS), stk
                    .getStartPoint2D(COORD_ABS))) {
                Debug.println("inbound");
                evt.setConsumed();
                evt.setShouldRender(false);
                isResizing = true;
                if (selgob instanceof DenimTextFieldInstance) {
                    GraphicalObject oldgob = sheet.getGobWithFocus();
                    GraphicalObject gobJ = (GraphicalObject) ((DenimTextFieldInstance) selgob)
                            .getJCWrapper();
                    sheet.setGobWithFocus(gobJ);
                    if (oldgob != null) {
                        oldgob.damage(DAMAGE_NOW);
                    }
                }
            } else {
                selgob = null;
            }
        }
    } // of handleNewStroke

    //-----------------------------------------------------------------

    /**
     * Resize the select object as the user drags a resize handle.
     */
    public void handleUpdateStroke(UpdateStrokeEvent evt) {

        if (selgob != null) {
            TimedStroke stk = evt.getStroke();
            Point2D pt = GraphicalObjectLib.absoluteToLocal(selgob
                    .getParentGroup(), stk.getEndPoint2D(COORD_ABS));
            Rectangle2D oldBounds = selgob.getBounds();
            Rectangle2D newBounds = getNewBounds(oldBounds, pt);
            GraphicalObject attachedGob = getAttachedGraphicalObject();

            double scale = GraphicalObjectLib.getScaleFactor(COORD_ABS,
                    attachedGob);
            AffineTransform tx;

            Debug.println("update:");
            Debug.println("   oldBounds: " + rectStr(oldBounds));
            Debug.println("   pt: " + pt);
            Debug.println("   newBounds: " + rectStr(newBounds));
            Debug.println(selgob.getClass());

            if (newBounds.getWidth() > SCALE_THRESHOLD
                    && newBounds.getHeight() > SCALE_THRESHOLD) {
                Rectangle2D box = new Rectangle2D.Double();
                if (mOldResizingBounds != null) {
                    Rectangle2D.union(mOldResizingBounds, newBounds, box);
                    box = GeomLib.transformRectangle(selgob.getParentGroup()
                            .getTransform(COORD_ABS), box);
                    /*
                     * selgob.getSheet().repaint(new Rectangle(
                     * (int)box.getMinX()-10, (int)box.getMinY()-10,
                     * (int)box.getWidth()+20, (int)box.getHeight()+20));
                     */
                    selgob.getSheet().damage(
                            DAMAGE_NOW,
                            new Rectangle((int) box.getMinX() - 10, (int) box
                                    .getMinY() - 10, (int) box.getWidth() + 20,
                                    (int) box.getHeight() + 20));
                }

                mOldResizingBounds = (Rectangle2D) newBounds.clone();

                Graphics2D g2d = (Graphics2D) this.getAttachedGraphicalObject()
                        .getSheet().getGraphics();
                Rectangle2D absBounds = new Rectangle2D.Double();
                GeomLib.transformRectangle(selgob.getParentGroup()
                        .getTransform(COORD_ABS), newBounds, absBounds);
                g2d.draw(absBounds);
            }

            evt.setConsumed();
            evt.setShouldRender(false);
        }
    } // of handleUpdateStroke

    //-----------------------------------------------------------------

    /**
     * Finish resizing when the user stops dragging a resize handle.
     */
    public void handleSingleStroke(SingleStrokeEvent evt) {
        if (isResizing && selgob != null && this.mOldResizingBounds != null) {
            MacroCommand cmd = new MacroCommand();
            cmd.addCommand(new ResizeCommand(selgob, this.mOldResizingBounds));
            cmd.addCommand(new SetSheetModifiedCommand((DenimSheet) selgob
                    .getSheet(), true));
            cmdqueue.doCommand(cmd);
            
            evt.setConsumed();
            evt.setShouldRender(false);
            isResizing = false;
        }
    }

    //=== STROKE METHODS ====================================================
    //===========================================================================

    //===========================================================================
    //=== CLONE =============================================================

    /**
     * Clones this interpreter.
     */
    public Object clone() {
        return (new ResizeInterpreter(this));
    } // of clone

    //=== CLONE =============================================================
    //===========================================================================

} // of class

//==============================================================================

/*
 * Copyright (c) 1999-2001 Regents of the University of California. All rights
 * reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. All advertising materials mentioning features or use of this software must
 * display the following acknowledgement:
 * 
 * This product includes software developed by the Group for User Interface
 * Research at the University of California at Berkeley.
 * 
 * 4. The name of the University may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
