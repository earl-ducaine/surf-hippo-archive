package edu.berkeley.guir.damask.view;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.ButtonModel;
import javax.swing.JToggleButton;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.pattern.PatternInstance;
import edu.berkeley.guir.damask.view.appevent.LayerEventSource;
import edu.berkeley.guir.damask.view.appevent.LayerListener;
import edu.berkeley.guir.damask.view.visual.VisualLayer;
import edu.berkeley.guir.damask.view.voice.VoiceLayer;
import edu.umd.cs.piccolo.*;

/** 
 * Listens to the model and modifies the scenegraph appropriately. There is
 * one layer per device type.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-09-2003 James Lin
 *                               Created LayerDirector.
 *                    11-19-2003 James Lin
 *                               Renamed to DamaskLayer, made a child class
 *                               of PLayer.
 *                    07-14-2004 James Lin
 *                               Split VisualLayer from DamaskLayer.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-09-2003
 */
public abstract class DamaskLayer extends PLayer {
   public static final int THIS_LAYER_ALPHA = 255;
   public static final int OTHER_LAYER_ALPHA = 80;

   private static Logger logger = Logger.getLogger(DamaskLayer.class.getName());

   private final DamaskDocument doc;
   private final DeviceType deviceType;
   private final double pageTitleScale;
   private DeviceTypeLayer deviceTypeLayer;

   private final JToggleButton.ToggleButtonModel allDevicesButtonModel =
      new JToggleButton.ToggleButtonModel();
   private final JToggleButton.ToggleButtonModel thisDeviceButtonModel =
      new JToggleButton.ToggleButtonModel();
   
   private TemplatePane templatePane; 

   protected final Map/*<InteractionElement, InteractionElementView>*/ views =
      new HashMap/*<InteractionElement, InteractionElementView>*/();
   
   private final LayerEventSource eventSource = new LayerEventSource();
   
   protected final List/*<WeakReference<InteractionElementView>>*/
      trackedViews = new ArrayList/*<WeakReference<InteractionElementView>>*/();
   protected boolean trackViews = false;

   //---------------------------------------------------------------------------

   public static class DeviceTypeLayer {
      private String name;

      private DeviceTypeLayer(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
      
      public static final DeviceTypeLayer ALL = new DeviceTypeLayer("all");
      public static final DeviceTypeLayer DEVICE = new DeviceTypeLayer("device");
   }
   

   //---------------------------------------------------------------------------

   /**
    * Constructs a new layer that displays a view of the specified document
    * for the specified device type.
    *  
    * @param doc         the document to display
    * @param deviceType  the device type from which perspective to display
    *                     the document
    */
   public DamaskLayer(final DamaskDocument doc, final DeviceType deviceType) {
      this(doc, deviceType, 1.0);
   }

   /**
    * Constructs a new layer that displays a view of the specified document
    * for the specified device type.
    * 
    * @param doc             the document to display
    * @param deviceType      the device type from which perspective to display
    *                         the document
    * @param pageTitleScale  the scale at which page titles should be drawn 
    */
   public DamaskLayer(
      final DamaskDocument doc,
      final DeviceType deviceType,
      final double pageTitleScale) {

//      addChild(new DamaskPPath(new Line2D.Double(-15, 0, 15, 0)));
//      addChild(new DamaskPPath(new Line2D.Double(0, -15, 0, 15)));
      
      deviceType.verifyTypeIsNotAll();
      this.doc = doc;
      this.deviceType = deviceType;
      this.pageTitleScale = pageTitleScale;
      
      final InteractionGraph graph = doc.getGraph();
      final GraphHandler graphHandler = new GraphHandler();
      graph.addElementContainerListener(graphHandler);
      graph.addInteractionGraphListener(graphHandler);

      // Add the template pane
      templatePane = new TemplatePane();
      addChild(0, templatePane);
      
      initBeforeAddingViews();
      
      // Create views for dialogs in this graph.
      for (Iterator i = graph.getDialogs(deviceType).iterator(); i.hasNext();) {
         final Dialog dialog = (Dialog)i.next();
         //System.out.println("adding view for " + dialog);
         addViewForElement(dialog);
      }
      //System.out.println("done with dialogs");

      // Create views for connections in this graph.
      for (Iterator i = graph.getConnections(deviceType).iterator();
         i.hasNext(); ) {
         final Connection connection = (Connection)i.next();
         addViewForElement(connection);
      }
      //System.out.println("done with connections");

      // Create views for pattern instances in this graph.
      for (Iterator i = graph.getPatternInstances().iterator(); i.hasNext();) {
         final PatternInstance pi = (PatternInstance)i.next();
         addViewForElement(pi);
      }
      //System.out.println("done with pattern instances");
      
      // Listen to changes in model for layer buttons
      allDevicesButtonModel.addChangeListener(new LayerButtonModelHandler());
      thisDeviceButtonModel.addChangeListener(new LayerButtonModelHandler());
      //System.out.println("done with listening to layer buttons");

      // Set the initial layer
      if (Damask.PATTERNS_AND_LAYERS) {
         setDeviceTypeLayer(DeviceTypeLayer.ALL);
      }
      else {
         setDeviceTypeLayer(DeviceTypeLayer.DEVICE);
      }
      //System.out.println("done with setting initial layer");
      
      // Listen for cameras being added to or removed from this layer.
      addPropertyChangeListener(PLayer.PROPERTY_CAMERAS, new CamerasHandler());
      //System.out.println("done with cameras");
      
      // Indicate which page view is the home page.
      updateHomePage();
      //System.out.println("done with updating home page");
   }


   /**
    * Called before views of elements in the graph are created and added
    * in the constructor.
    */
   protected void initBeforeAddingViews() {
   }


   /**
    * Returns a new instance of a concrete subclass of DamaskCanvas,
    * depending on the specified device type.
    */
   public static DamaskLayer create(
         final DamaskDocument doc,
         final DeviceType deviceType) {

      return create(doc, deviceType, 1.0);
   }
   

   /**
    * Returns a new instance of a concrete subclass of DamaskCanvas,
    * depending on the specified device type.
    */
   public static DamaskLayer create(
         final DamaskDocument doc,
         final DeviceType deviceType,
         final double pageTitleScale) {

      if (deviceType.isVisual()) {
         return new VisualLayer(doc, deviceType, pageTitleScale);
      }
      else {
         return new VoiceLayer(doc, deviceType, pageTitleScale);
      }
   }


   /**
    * Adds the specified listener to receive canvas events.
    */
   public synchronized void addLayerListener(final LayerListener listener) {
      eventSource.addLayerListener(listener);
   }


   /**
    * Removes the specified listener so that it no longer receives
    * canvas events.
    */
   public synchronized void removeLayerListener(final LayerListener listener) {
      eventSource.removeLayerListener(listener);
   }

   
   /**
    * Fires selectionChanged events to listeners.
    */
   protected void fireDeviceTypeLayerChanged() {
      eventSource.fireDeviceTypeLayerChanged(this);
   }


   /**
    * Returns the scale at which page titles should be drawn.
    */
   public double getPageTitleScale() {
      return pageTitleScale;
   }


   /**
    * Returns the template pane.
    */
   public TemplatePane getTemplatePane() {
      return templatePane;
   }

   
   /**
    * Returns the document that this layer is displaying.
    */
   public DamaskDocument getDocument() {
      return doc;
   }


   /**
    * Returns the type of device that the design in this layer is for.
    */
   public DeviceType getDeviceType() {
      return deviceType;
   }


   /**
    * Returns the current device-type layer of this layer. This determines
    * whether elements added to this layer is intended for all device types
    * or only the device type of this layer. 
    */
   public DeviceTypeLayer getDeviceTypeLayer() {
      return deviceTypeLayer;
   }


   /**
    * Returns which device type a new element being added should support. 
    */
   public DeviceType getDeviceTypeForNewElement() {
      if (deviceTypeLayer == DeviceTypeLayer.ALL) {
         return DeviceType.ALL;
      }
      else {
         return deviceType;
      }
   }

   /**
    * Returns the model of the all devices button.
    */
   protected ButtonModel getAllDevicesButtonModel() {
      return allDevicesButtonModel;
   }

   /**
    * Returns the model of the this device button.
    */
   protected ButtonModel getThisDeviceButtonModel() {
      return thisDeviceButtonModel;
   }

   /**
    * Sets the current device-type layer of this layer. This determines
    * whether elements added to this layer is intended for all device types
    * or only the device type of this layer. 
    */
   public void setDeviceTypeLayer(final DeviceTypeLayer deviceTypeLayer) {
      if (deviceTypeLayer == DeviceTypeLayer.ALL) {
         allDevicesButtonModel.setSelected(true);
      }
      else {
         thisDeviceButtonModel.setSelected(true);
      }
   }
   

   /**
    * Sets the current device-type layer of this layer. This determines
    * whether elements added to this layer is intended for all device types
    * or only the device type of this layer. 
    */
   protected void internalSetDeviceTypeLayer(final DeviceTypeLayer deviceTypeLayer) {
      this.deviceTypeLayer = deviceTypeLayer;
      logger.info(this + ": Device type layer changed to " + deviceTypeLayer);
      fireDeviceTypeLayerChanged();
   }

   
   /**
    * Called when the slider's model changes.
    */
   protected void layerButtonModelStateChanged(final ChangeEvent e) {
      if (e.getSource() == allDevicesButtonModel) {
         if (allDevicesButtonModel.isSelected()) {
            internalSetDeviceTypeLayer(DeviceTypeLayer.ALL);
         }
      }
      else if (e.getSource() == thisDeviceButtonModel) {
         if (thisDeviceButtonModel.isSelected()) {
            internalSetDeviceTypeLayer(DeviceTypeLayer.DEVICE);
         }
      }
      else {
         assert false;
      }
   }

   
   /**
    * Listens to the model for the layer radio buttons.
    */
   private class LayerButtonModelHandler implements ChangeListener {
      public void stateChanged(ChangeEvent e) {
         layerButtonModelStateChanged(e);
      }
   }

   
   /**
    * Returns the object that is in this layer associated with the specified 
    * model object.
    */
   public InteractionElementView getView(final InteractionElement model) {
      return DamaskAppUtils.getView(this, model);
   }


   /**
    * Returns the objects that are in this layer associated with the specified 
    * model object.
    */
   public List/*<InteractionElementView>*/ getViews(
      final InteractionElement model) {
      
      return DamaskAppUtils.getViews(this, model);
   }

   
   /**
    * Returns a collection of DamaskCanvas that are looking at this layer.
    */
   protected Collection/*<DamaskCanvas>*/ getDamaskCanvases() {
      final Set canvases = new HashSet();
      for (Iterator i = getCamerasReference().iterator(); i.hasNext(); ) {
         final PCamera camera = (PCamera)i.next();
         final PComponent component = camera.getComponent();
         if (component instanceof DamaskCanvas) {
            canvases.add(component);
         }
      }
      return canvases;
   }


   /**
    * Makes the children of the specified node selectable in all DamaskCanvases
    * that point to this layer.
    */
   public void addSelectableParent(final PNode node) {
      for (Iterator i = getDamaskCanvases().iterator(); i.hasNext();) {
         final DamaskCanvas canvas = (DamaskCanvas)i.next();
         canvas.getSelectionEventHandler().addSelectableParent(node);
      }
   }


   /**
    * Makes the children of the specified node not selectable in all
    * DamaskCanvases that point to this layer.
    */
   public void removeSelectableParent(final PNode node) {
      for (Iterator i = getDamaskCanvases().iterator(); i.hasNext();) {
         final DamaskCanvas canvas = (DamaskCanvas)i.next();
         canvas.getSelectionEventHandler().removeSelectableParent(node);
      }
   }


   /**
    * Makes no children of this layer selectable in all
    * DamaskCanvases that point to this layer.
    */
   public void clearSelectableParents() {
      for (Iterator i = getDamaskCanvases().iterator(); i.hasNext();) {
         final DamaskCanvas canvas = (DamaskCanvas)i.next();
         canvas.getSelectionEventHandler().setSelectableParents(
            Collections.EMPTY_LIST);
      }
   }


   /**
    * Adds the proper view for the specified element.
    */
   protected abstract void addViewForElement(final InteractionElement element);

   
   /**
    * Removes the proper view for the specified element.
    */
   protected abstract void removeViewForElement(final InteractionElement element);
   
   
   /**
    * Start keeping track of views being added to this object.
    */
   public void startTrackingNewAdditions() {
      trackViews = true;
      
   }
   
   
   /**
    * Stop keeping track of views being added to this object.
    */
   public void stopTrackingNewAdditions() {
      trackViews = false;
   }
   
   
   /**
    * Stop keeping track of views being added to this object.
    */
   public void clearTrackedNewAdditions() {
      trackedViews.clear();
   }
   

   /**
    * Returns a list of weak references to views that are being tracked.
    */
   public List/*<WeakReference<InteractionElementView>>*/ getTrackedNewAdditions() {
      return trackedViews;
   }

   
   /**
    * Adds the specified view to the list of views being tracked.  
    */
   public void trackAddition(final InteractionElementView view) {
      if (trackViews) {
         trackedViews.add(new WeakReference(view));
      }
   }
   
   
   /**
    * Places the home page indicator on the appropriate views of that page..
    */
   public abstract void updateHomePage();
   
   // @Override
   public String toString() {
      return DamaskUtils.toShortString(this) + " (" +
        getDocument() + " - " + getDeviceType() + ")";
   }
   
   //------------------------------------------------------------------------

   /**
    * Listens to events from an interaction graph. 
    */
   private class GraphHandler
      implements ElementContainerListener, InteractionGraphListener {

      public void elementAdded(ElementContainerEvent e) {
         final Object container = e.getSource();
         assert doc.getGraph().equals(container) :
            "ERROR: event source " + container + " is not " + doc.getGraph();

         final InteractionElement element = e.getElement();
         addViewForElement(element);
      }

      public void elementRemoved(ElementContainerEvent e) {
         final Object container = e.getSource();
         assert doc.getGraph().equals(container) :
            "ERROR: event source " + container + " is not " + doc.getGraph();

         final InteractionElement element = e.getElement();

         removeViewForElement(element);
      }

      public void homePageChanged(InteractionGraphEvent e) {
         final InteractionGraph graph = e.getGraph();
         assert getDocument().getGraph().equals(graph) :
            "ERROR: event source " + graph + " is not " + getDocument().getGraph();
         updateHomePage();
      }
   }
   
   //------------------------------------------------------------------------

   /**
    * Listens to changes to the layer's list of cameras. 
    */
   private class CamerasHandler implements PropertyChangeListener {
      public void propertyChange(PropertyChangeEvent evt) {
         clearSelectableParents();
      }
   }
}
