package edu.berkeley.guir.suede;
 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

/**
 *Things that must be changed for model/viewer rewrite:
 *
 * - remove m_nodemodel. Operations that needed this variable should be moved to
 *      be entirely in the view class.
 */

public abstract class AbstNodeView  extends JComponent {
   
  public  static final int         STROKE_WIDTH     = 2;
  public  static final int         ARC              = 30; 
  public  static final BasicStroke PIXEL_STROKE     = new BasicStroke(1);
  public  static final BasicStroke STROKE           = new BasicStroke(STROKE_WIDTH);
  public  static final int         ASCII_A          = 64;
  public  static final Dimension   IN_GROUP_SIZE    = new Dimension(100, 24);
  private static final int         RESIZE_THRESHOLD = 3;
  private static final int         LINK_THRESHOLD   = 20;

  // These are used for direct manipulation dragging of nodes
  private   Point              mouseDownPoint;
  private   int                pressLocationX;  
  private   int                pressLocationY;  
  protected AbstNodeModel      m_nodemodel;
  private   NodeMouseListener  mouseListener = new NodeMouseListener();
  
   /////////Hongvan's code////////////////////
   protected JPopupMenu popup = new JPopupMenu();
   protected RolloverMenuItem newPromptCard = new RolloverMenuItem("Create New Prompt Card", Color.black, Color.white, Color.darkGray);
   protected RolloverMenuItem newResponseCard = new RolloverMenuItem("Create New Response Card", Color.black, Color.white, Color.darkGray);
   protected RolloverMenuItem copy = new RolloverMenuItem("Copy", Color.black, Color.white, Color.darkGray);
   protected RolloverMenuItem cut = new RolloverMenuItem("Cut", Color.black, Color.white, Color.darkGray);
   protected RolloverMenuItem paste = new RolloverMenuItem("Paste", Color.black, Color.white, Color.darkGray);
   protected MouseEvent mouseEvent;//store the current MouseEvent to be used in subclasses
   /////////////////////////////////////////
   
  public AbstNodeView() {
  }

  public AbstNodeView(SuedeModel model, AbstNodeModel nodeModel) {
	m_nodemodel  = nodeModel;
	m_nodemodel.setSuedeModel(model);
	setLayout(null);
	setOpaque(false);
	setVisible(true);
    
	addMouseListener(mouseListener);
	addMouseMotionListener(mouseListener); 
    
	////////////////////Hongvan's code//////////////////////////
		 newPromptCard.addActionListener (new PromptCardActionListener());
		 newResponseCard.addActionListener (new ResponseCardActionListener());
		 copy.addActionListener (new CopyActionListener());
		 cut.addActionListener (new CutActionListener());
		 paste.addActionListener (new PasteActionListener());
		 popup.add(newPromptCard);
		 popup.add(newResponseCard);
		 popup.add(copy); popup.add(cut); popup.add(paste);
		 /////////////////////////////////////////////////////////////
  }
   
  public void setCenter (int x, int y) {
	m_nodemodel.setLocation(x - getWidth()/2, y - getHeight()/2);
  }

  
  public Point getCenter () {
	return m_nodemodel.getCenter();
	//return new Point(getX() + getWidth()/2, getY() + getHeight()/2);
  }
  
  
  public AbstNodeModel getNodeModel() {
	 return m_nodemodel;
  }


  public Component add(Component c) {
	super.add(c);
	c.addMouseListener(mouseListener);
	c.addMouseMotionListener(mouseListener);
	return c;
  }
  
  public void remove(Component c) {
	super.remove(c);
	c.removeMouseListener(mouseListener);
	c.removeMouseMotionListener(mouseListener);
  }
  
  // by default, outbound links diosplay a balloon
  // subclasses can choose to override this
  public boolean getDrawBalloon() {
	return true;
  }

  public String getGroupName() {
	return m_nodemodel.getGroupName();
	/*if (m_group!=null) {
	  return m_group.getName();     
	}
	return "";*/
   }
    
  public void setGroupName(String name) {
	m_nodemodel.setGroupName(name);
	//m_groupname = name;
    
	// this used to set the group's name to the name passed in.  not necessary in our cases.
	// in all cases the group is the caretaker of its own name.  don't put this back.  - aks, 06/01/00    
  }


  public String getAsciiName() {
	return "";
  }

  // left for subclasses to handle
  public void handleMouseReleased (Component c) {}

  // left for subclasses to handle
  public void handleMouseDragged () {}
  
  // left for subclasses to handle
  public void handleMouseClicked (MouseEvent e) {
  }

  ////////////Hongvan's code////////////////////
  //left for subclasses to handle
  public void handleMousePressed (MouseEvent e) {}
  /////////////////////////////////////////////////
  
  public class NodeMouseListener extends MouseAdapter implements MouseMotionListener {
	private boolean mouseExited = false;
	//private boolean linkGesture = false;
	private boolean drag_motion = false;
	private JComponent feedback;
	private boolean opAllowed = true;

	public void mouseClicked(MouseEvent e) {
      
		// don't put deleting here until deleting groups is fixed.
		// look for it in SingleNodeView.  Needs to be implemented in
		// SGroupNodeView
      
		handleMouseClicked(e);
	}
    
    
	public void mousePressed(MouseEvent e){
	  Point p = e.getPoint();
	  SContentPane pane = (m_nodemodel.getSuedeModel()).getContentPane();
	  javax.swing.SwingUtilities.convertPointToScreen(p, e.getComponent());
	  opAllowed = m_nodemodel.isOperable(p);
	  javax.swing.SwingUtilities.convertPointFromScreen(p, pane);
	  mouseDownPoint = p;
	  pressLocationX    = AbstNodeView.this.getX();
	  pressLocationY    = AbstNodeView.this.getY();
	  mouseExited       = false;
	  if (SwingUtilities.isLeftMouseButton(e)&& opAllowed) {
		 feedback = new SFeedbackLink(0, 0);
		 feedback.setSize(pane.getWidth(), pane.getHeight());
		 pane.add(feedback, JLayeredPane.DRAG_LAYER);
		 ((SFeedbackLink)feedback).setFColor(AbstLinkView.LINK_COLOR);
		 feedback.setVisible(false);
	  } 
	  //else {}
	  ////////////Hongvan's code///////////////////////////////////////
	   //handling pop up menu for copy/cut/paste
	  else if (SwingUtilities.isRightMouseButton(e) && opAllowed) {
		  mouseEvent = e;
		  handleMousePressed(e);
	  }
	  /////////////////////////////////////////////////////////
	}
        
	public void mouseEntered(MouseEvent e) { mouseExited = false;}
    
    
	public void mouseExited(MouseEvent e) { mouseExited = true;}
    

	public void mouseReleased(MouseEvent e){
		SContentPane pane = (m_nodemodel.getSuedeModel()).getContentPane();
		if (feedback!=null)
			pane.remove(feedback);
		Point p = e.getPoint();
		javax.swing.SwingUtilities.convertPointToScreen(p, e.getComponent());
		javax.swing.SwingUtilities.convertPointFromScreen(p, pane);
		Component target = pane.getComponentAt(p);
		if(opAllowed) {
			if ((mouseExited)&&(SwingUtilities.isLeftMouseButton(e))
				&& ((Math.sqrt((p.y-mouseDownPoint.y)*(p.y-mouseDownPoint.y)
				+(p.x-mouseDownPoint.x)*(p.x-mouseDownPoint.x)))>=LINK_THRESHOLD)) {
				if ((target instanceof AbstNodeView) && !(target instanceof StartNodeView)) {
					AbstNodeView targetNode = (AbstNodeView)target;
					(m_nodemodel.getSuedeModel()).addLink((SFeedbackLink)feedback);
               
				} else  {            
					if (!(m_nodemodel instanceof StartNodeModel)) {
						(m_nodemodel.getSuedeModel()).addLink((SFeedbackLink)feedback);
					}
              
				}
				pane.repaint();
			}
			else if(SwingUtilities.isLeftMouseButton(e)) {
				if((p.y-mouseDownPoint.y)>RESIZE_THRESHOLD) {
					m_nodemodel.expand();
				}
				else if((p.y - mouseDownPoint.y)<-RESIZE_THRESHOLD) {
					m_nodemodel.collapse();
				}
				else {}
				pane.repaint();
			}
			//handling pop up menu for copy/cut/paste
			else if (SwingUtilities.isRightMouseButton(e) && mouseExited == false) {
				mouseEvent = e;
				//HV Oct1703
				if (!drag_motion)
					handleMousePressed (e);
				else {//pop up menu won't be shown	
					drag_motion = false;
				}
			}
			else  {
				target = pane.getGroupAt(p);
				//pane.add(SAbstractNodeView.this, SContentPane.NODE_LAYER);
				handleMouseReleased(target);
			}
		}
	}

	public void mouseMoved(MouseEvent e) {}   
    
	public void mouseDragged(MouseEvent e) {
		Point p = e.getPoint();
		SContentPane pane = (m_nodemodel.getSuedeModel()).getContentPane();
		javax.swing.SwingUtilities.convertPointToScreen(p, e.getComponent());
		javax.swing.SwingUtilities.convertPointFromScreen(p, pane);
		if(opAllowed) {
			drag_motion = true;
			if (!SwingUtilities.isLeftMouseButton(e)) {
			m_nodemodel.setLocation(p.x - mouseDownPoint.x + pressLocationX, 
						p.y - mouseDownPoint.y + pressLocationY  );
			handleMouseDragged();
			pane.repaint();
			}
			else {
			if(mouseExited) {
				((SFeedbackLink)feedback).setStart(mouseDownPoint.x, mouseDownPoint.y);
				((SFeedbackLink)feedback).setFinish(p.x, p.y);
				if(((Math.sqrt((p.y-mouseDownPoint.y)*(p.y-mouseDownPoint.y)
				+(p.x-mouseDownPoint.x)*(p.x-mouseDownPoint.x)))>=LINK_THRESHOLD))
					feedback.setVisible(true);
				feedback.repaint();
			 }
				else
				feedback.setVisible(false);
			}
		}
		else
			drag_motion = false;
	}
  }   
  
	/////////////////////////Hongvan's code//////////////////////
	private class PromptCardActionListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
		handleCreateNewPromptCard ();
		}
	}
            
	private class ResponseCardActionListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
		handleCreateNewResponseCard ();
		}
	}
            
	private class CopyActionListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			handleCopyAction ();
		}
	}
            
	private class CutActionListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			handleCutAction ();
	}
	}
            
	private class PasteActionListener implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			handlePasteAction ();
				}
			}
    
			/** Left the subclass to handle these functions */
	public void handleCreateNewPromptCard () {
	}
    
	public void handleCreateNewResponseCard () {
	}
    
	public void handleCopyAction () {
	}
    
	public void handleCutAction () {
	}
    
	public void handlePasteAction () {
	}
	//////////////////////////////////////////////////////////////////////////
	//{{DECLARE_CONTROLS
	//}}
}