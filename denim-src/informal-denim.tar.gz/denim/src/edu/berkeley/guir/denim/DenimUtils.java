package edu.berkeley.guir.denim;

import edu.berkeley.guir.denim.awt.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.denim.interpreters.*;
import edu.berkeley.guir.denim.view.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.collection.*;
import edu.berkeley.guir.lib.io.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.gesture.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.net.*;
import java.io.*; 
import java.text.*;
import java.awt.event.*;

/**
 * Various utilities for Denim
 *
 * <PRE>
 * Revisions:  1.0.0  11-22-1999 JL
 *                    Created class DenimUtils.
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *         <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @since   JDK 1.2.2
 * @version Version 1.0.0, 11-22-1999
 */

public class DenimUtils
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   private static final int   BOUNDS_THRESHOLD = 20;

   private static final int   TOPLEFT     = 8;
   private static final int   TOP         = 9;
   private static final int   TOPRIGHT    = 10;
   private static final int   RIGHT       = 11;
   private static final int   BOTTOMRIGHT = 12;
   private static final int   BOTTOM      = 13;
   private static final int   BOTTOMLEFT  = 14;
   private static final int   LEFT        = 15;

   //===   CONSTANTS   =========================================================
   //===========================================================================


   //===========================================================================
   //===   CLASS VARIABLES AND INITIALIZATIONS   ===============================

   private static Cursor blankCursor;
   private static Cursor waitCursor;
   private static Cursor defaultCursor;

   static {
      Toolkit tk = Toolkit.getDefaultToolkit();
      Image cursorImage = tk.getImage
         (Denim.class.getResource("images/cursors/blank.gif"));
      blankCursor = tk.createCustomCursor(cursorImage,
                                          new Point(0, 0), "none");
      waitCursor = Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
      defaultCursor = Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR);
   }

   private static int position;

   private static MouseRecorder mouseRecorder = new MouseRecorder();
   private static MouseMotionRecorder mouseMotionRecorder = new MouseMotionRecorder();
   private static KeyRecorder keyRecorder = new KeyRecorder();
   private static boolean isRecording = false;

   private static DenimLoggingEventQueue LEQ;
   private static boolean recording = false;


   //===   CLASS VARIABLES AND INITIALIZATIONS   ===============================
   //===========================================================================


   //===========================================================================
   //===   INNER CLASS MOUSE LISTENERS   =======================================

   public static void printMouseEvent(MouseEvent e) {
      System.out.println(DenimUtils.toShortClassName(e.getSource()) +
                         '\t' + e.paramString());
   }

   /**
    * Keeps track of mouse movements.
    */
   public static class MouseRecorder extends MouseAdapter {
      private String filename;

      public void setFilename(String filename) {
         this.filename = filename;
      }

      public void mouseClicked(MouseEvent e) {
         printMouseEvent(e);
      }

      public void mousePressed(MouseEvent e) {
         printMouseEvent(e);
      }

      public void mouseReleased(MouseEvent e) {
         printMouseEvent(e);
      }
   } // of inner class

   //-----------------------------------------------------------------

   public static class MouseMotionRecorder implements MouseMotionListener {
      private String filename;

      public void setFilename(String filename) {
         this.filename = filename;
      }

      public void mouseDragged(MouseEvent e) {
         printMouseEvent(e);
      } // of mouseDragged

      public void mouseMoved(MouseEvent e) {
         printMouseEvent(e);
      } // of mouseMoved
   } // of inner class

   //-----------------------------------------------------------------

   public static void printKeyEvent(KeyEvent e) {
      System.out.println(DenimUtils.toShortClassName(e.getSource()) +
                         '\t' + e.paramString());
   }

   public static class KeyRecorder extends KeyAdapter {
      private String filename;

      public void setFilename(String filename) {
         this.filename = filename;
      }

      public void keyPressed(KeyEvent e) {
         printKeyEvent(e);
      }

      public void keyReleased(KeyEvent e) {
         printKeyEvent(e);
      }
   }

   //===   INNER CLASS MOUSE LISTENERS   =======================================
   //===========================================================================

   private static void enableRecordingListeners(Component c, String filename) {
      c.addMouseListener(mouseRecorder);
      c.addMouseMotionListener(mouseMotionRecorder);
      c.addKeyListener(keyRecorder);

      if (c instanceof Container) {
         Container container = (Container)c;
         Component[] children = container.getComponents();
         for (int i = 0; i < children.length; i++) {
            enableRecordingListeners(children[i], filename);
         }
      }
   }

   //-----------------------------------------------------------------

   private static void disableRecordingListeners(Component c) {
      c.removeMouseListener(mouseRecorder);
      c.removeMouseMotionListener(mouseMotionRecorder);
      c.removeKeyListener(keyRecorder);

      if (c instanceof Container) {
         Container container = (Container)c;
         Component[] children = container.getComponents();
         for (int i = 0; i < children.length; i++) {
            disableRecordingListeners(children[i]);
         }
      }
   }
   //-----------------------------------------------------------------

   /*Recording features*/

   /**
    * Begins recording events with default file name.
    */
   public static void startRecording() {
      startRecording("");
   }

   /**
    * Begins recording events.
    *
    * @param filename   name of file to record events
    */
   public static void startRecording(String filename) {
      java.util.List denimWindows = Denim.getWindows();

      if (recording) {
         System.out.println("Recording already in progress.");
      }
      else {
         try {
            if (filename.equals("")) {
               LEQ = new DenimLoggingEventQueue(denimWindows);
            }
            else {
               LEQ = new DenimLoggingEventQueue(denimWindows, filename);
            }
            Toolkit tk = Toolkit.getDefaultToolkit();
            EventQueue q  = tk.getSystemEventQueue();
            q.push(LEQ);
            recording = true;
         }
         catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
         }
      }
   }

   /**
    * Stop recording events and close file.
    */
   public static void stopRecording() {
      if (!recording) {
         System.out.println("Cannot stop recording--no recording in progress.");
      }
      else {
         recording = false;
         LEQ.close();
         LEQ.pop();
      }
   }

   /**
    * Play back recorded events from file.
    *
    * @param filename   file from which to play back events
    */
   public static void play(String filename, float speedFactor) {
      System.out.println("Playing file: " +
                         FileLib.addFileNameExtension(filename, "txt"));
      java.util.List denimWindows = Denim.getWindows();
      try {
         DenimEventPlayer EP = new DenimEventPlayer(denimWindows, filename, false /* don't skip restore */, speedFactor);
         EP.play();
      }
      catch (IOException e) {
         System.out.println(e);
         e.printStackTrace();
      }
      catch (AWTException e) {
         System.out.println("Cannot playback events");
         System.out.println(e);
         e.printStackTrace();
      }
   }

   /**
    * Play back recorded events from file, without the Denim-specific
    * restoration of the window state.  Intended for replay only, but
    * may work even without having run "play" first.
    *
    * @param filename   file from which to play back events
    */
   public static void replay(String filename, float speedFactor) {
      System.out.println("Quick-playing from file: " +
                         FileLib.addFileNameExtension(filename, "txt"));
      try {
         java.util.List denimWindows = Denim.getWindows();
         DenimEventPlayer EP = new DenimEventPlayer(denimWindows, filename, true /* skip restore */, speedFactor);
         EP.play();
      }
      catch (IOException e) {
         System.out.println(e);
         e.printStackTrace();
      }
      catch (AWTException e) {
         System.out.println("Cannot playback events");
         System.out.println(e);
         e.printStackTrace();
      }
   }
   //-------------------------------------------------------------------

   /**
    * Returns a blank cursor.
    */
   public static Cursor getBlankCursor() {
      return blankCursor;
   }

   //-----------------------------------------------------------------

   /**
    * Returns a wait cursor.
    */
   public static Cursor getWaitCursor() {
      return waitCursor;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the default cursor.
    */
   public static Cursor getDefaultCursor() {
      return defaultCursor;
   }

   //-----------------------------------------------------------------

   /**
    * Creates the interpreters associated with the tools and adds them
    * to the given interpreter mediator.
    */
   public static void setupToolInterpreters(MultiInterpreter im) {
      //// Setup the interpreters related to the tools
      setupToolInterpreter(new EraserInterpreter(), im);
      setupToolInterpreter(new BlankRubberStampInterpreter(), im);
      setupToolInterpreter(new RubberStampInterpreter(), im);
      setupToolInterpreter(new HandInterpreter(), im);
      setupToolInterpreter(new GroupInterpreter(), im);
      setupToolInterpreter(new InkAnnotationInterpreter(), im);
      setupToolInterpreter(new AudioAnnotationInterpreter(), im);
   }

   //-----------------------------------------------------------------

   /**
    * Sets up an interpreter related to a tool, and adds it to the
    * given interpreter mediator.
    */
   private static void setupToolInterpreter(Interpreter interp,
                                            MultiInterpreter im) {
      interp.setAcceptRightButton(false);
      interp.setEnabled(false);
      im.add(interp);
   }

   //-----------------------------------------------------------------

   /**
    * Returns a timed stroke of one line with the specified absolute
    * coordinates. Used by setCrosshairsLocation().
    */
   public static TimedStroke makeStrokeFromLine(int x1, int y1,
                                                int x2, int y2,
                                                Color color) {
      Polygon poly = new Polygon();

      poly.addPoint(x1, y1);
      poly.addPoint(x2, y2);

      TimedStroke stk   = new TimedStroke(poly);
      Style       style = stk.getStyleRef();

      style.setDrawColor(color);

      return stk;
   }

   //-----------------------------------------------------------------

   private static final double sliderScales[] = {ZOOM_NOTCH_0,
                                                 ZOOM_NOTCH_5,
                                                 ZOOM_NOTCH_10,
                                                 ZOOM_NOTCH_15,
                                                 ZOOM_NOTCH_20,
                                                 ZOOM_NOTCH_25,
                                                 ZOOM_NOTCH_30,
                                                 ZOOM_NOTCH_35,
                                                 ZOOM_NOTCH_40,
                                                 ZOOM_NOTCH_45,
                                                 ZOOM_NOTCH_50,
                                                 ZOOM_NOTCH_55,
                                                 ZOOM_NOTCH_60,
                                                 ZOOM_NOTCH_65,
                                                 ZOOM_NOTCH_70,
                                                 ZOOM_NOTCH_75,
                                                 ZOOM_NOTCH_80,
                                                 ZOOM_NOTCH_85,
                                                 ZOOM_NOTCH_90,
                                                 ZOOM_NOTCH_95,
                                                 ZOOM_NOTCH_100};
   /**
    * Returns what value the zoom slider should be, at the given
    * absolute scale factor of the sheet, or -1 if there is no good value.
    */
   public static int getZoomSliderValue(double sheetAbsScale) {
      for (int i = 0; i < sliderScales.length; i++) {
         if (sliderScales[i] - 0.01 < sheetAbsScale &&
             sheetAbsScale < sliderScales[i] + 0.01) {
            return i * 5;
         }
      }
      return -1;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the graphical object within the given group that is closest
    * to the given absolute coordinates.
    */
   public static GraphicalObject getNearestComponentAtAbsPtExcept
         (GraphicalObjectGroup gobgrp, Point2D absPt, Class except) {

      GraphicalObject gob = null;
      GraphicalObjectCollection gobcol =
         gobgrp.getGraphicalObjects(COORD_ABS, absPt, ALL, SHALLOW, NEAR);

      float minDist = Float.POSITIVE_INFINITY;

      Iterator it = gobcol.getForwardIterator();
      while (it.hasNext()) {
         GraphicalObject iGob = (GraphicalObject)it.next();

         if (!(except.isInstance(iGob))) {
            float distance = iGob.getBoundingPoints2D(COORD_ABS)
                                 .minDistance(absPt.getX(), absPt.getY());
   
            if (distance < minDist) {
               minDist = distance;
               gob = iGob;
            }
         }
      }

      return gob;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the graphical object within the given group at the given
    * absolute coordinates that is not an instance of the given class.
    */
   public static GraphicalObject getTopmostComponentAtAbsPtExcept
         (GraphicalObjectGroup gobgrp, Point2D absPt, Class except) {

      GraphicalObject gob = null;
      GraphicalObjectCollection gobcol =
         gobgrp.getGraphicalObjects(COORD_ABS, absPt, ALL, SHALLOW, NEAR);

      //// 1. Get the shallowest object at the current point
      Iterator i = gobcol.getForwardIterator();
      int smallestRelLayer = Integer.MAX_VALUE;
      while (i.hasNext()) {
         GraphicalObject iGob = (GraphicalObject)i.next();
         //debug.println("inspecting: " + DenimUtils.toShortString(iGob));
         if (!except.isInstance(iGob)) {
            int layer = iGob.getRelativeLayer();
            if (layer < smallestRelLayer) {
               gob = iGob;
               smallestRelLayer = layer;
            }
         }
      }

      return gob;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the graphical object within the given group that contains
    * the given absolute coordinates.
    */
   public static GraphicalObject getTopmostComponentContainingAbsPt
         (GraphicalObjectGroup gobgrp, Point2D absPt) {

      GraphicalObject gob = null;
      GraphicalObjectCollection gobcol =
         gobgrp.getGraphicalObjects(COORD_ABS, absPt, ALL, SHALLOW, NEAR);

      //// 1. Get the shallowest object at the current point
      Iterator i = gobcol.getForwardIterator();
      int smallestRelLayer = Integer.MAX_VALUE;
      while (i.hasNext()) {
         GraphicalObject iGob = (GraphicalObject)i.next();
         //debug.println("inspecting: " + DenimUtils.toShortString(iGob));
         if (iGob.getBoundingPoints2D(COORD_ABS).contains(absPt)) {
            int layer = iGob.getRelativeLayer();
            if (layer < smallestRelLayer) {
               gob = iGob;
               smallestRelLayer = layer;
            }
         }
      }

      return gob;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the graphical object within the given group that contains
    * the given absolute coordinates, whose type is one of the given
    * types.
    */
   public static GraphicalObject getTopmostComponentContainingAbsPtOfType
         (GraphicalObjectGroup gobgrp, Point2D absPt, Class[] allowed) {

      GraphicalObject gob = null;
      GraphicalObjectCollection gobcol =
         gobgrp.getGraphicalObjects(COORD_ABS, absPt, ALL, SHALLOW, NEAR);

      Iterator i = gobcol.getForwardIterator();
      int smallestRelLayer = Integer.MAX_VALUE;
      while (i.hasNext()) {
         GraphicalObject iGob = (GraphicalObject)i.next();
         //debug.println("inspecting: " + DenimUtils.toShortString(iGob));
         if (iGob.getBoundingPoints2D(COORD_ABS).contains(absPt)) {
            boolean goodType = false;
            for (int j = 0; j < allowed.length; j++) {
               goodType = goodType || (allowed[j].isInstance(iGob));
            }
            if (goodType) {
               int layer = iGob.getRelativeLayer();
               if (layer < smallestRelLayer) {
                  gob = iGob;
                  smallestRelLayer = layer;
               }
            }
         }
      }

      return gob;
   }

   //-----------------------------------------------------------------

   /**
    * Returns whether the given graphical object is within a custom
    * component.
    */
   public static boolean isInCustomComponent(GraphicalObject gob) {
      if (getCustomComponent(gob) != null) {
         return true;
      }
      else {
         return false;
      }
   }

   ///-----------------------------------------------------------------
   
   /**
    * Returns the graphical object of the custom component in which the given 
    * graphical object is, if it is not in one -- returns null
    */
   public static GraphicalObject getCustomComponent(GraphicalObject gob) {
      GraphicalObject gobTmp = gob;
      while (gobTmp != null &&
             !(gobTmp instanceof DenimCustomComponent)) {
         gobTmp = gobTmp.getParentGroup();
      }
      
      return gobTmp;
   }

   /**
    * Returns the custom component within the given group at the given absolute
    * coordinates, or null if there isn't one.
    */
   public static DenimCustomComponent findCustomComponent
       (GraphicalObjectGroup gobgrp, Point2D absPt) {

       GraphicalObject startObj ;
      
       //// 1. Get the shallowest object at the current point that is of a 
       ////Framed patch class
       startObj = DenimUtils.getTopmostComponentContainingAbsPt
	   (gobgrp, absPt);
       
       //// 2. If it is a FramedPatch, then go one level deeper
       if (startObj instanceof FramedPatch) {
	   FramedPatch fp = (FramedPatch)startObj;
	   
	   startObj = DenimUtils.getTopmostComponentContainingAbsPt
	       (fp, absPt);
	   
	   //// If it is a DenimCustomComponent, then return it 
	   if (startObj instanceof DenimCustomComponent) {
	       return ((DenimCustomComponent)startObj);
	   }
	 
       }
       return null;
   }
   //----------------------------------------------------------------

   /**
    * Returns the panel containing the given graphical object.
    */
   public static DenimPanel getContainingPanel(GraphicalObject gob) {
      GraphicalObjectGroup parentTmp = gob.getParentGroup();
      while (!(parentTmp instanceof DenimPanel) && parentTmp != null) {
         parentTmp = parentTmp.getParentGroup();
      }

      return (DenimPanel)parentTmp;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the panel within the given group at the given absolute
    * coordinates, or null if there isn't one.
    */
   public static DenimPanel findPanel(GraphicalObjectGroup gobgrp,
                                        Point2D absPt) {
         
      GraphicalObject startObj;
      Class[] allowed =
         {
            DenimPanel.class,
            FramedPatch.class,
            DenimCustomComponentInstance.class };

      ////  Get the shallowest object at the current point (except arrows)
      startObj =
         DenimUtils.getTopmostComponentContainingAbsPtOfType(
            gobgrp,
            absPt,
            allowed);

      ////  If it is a FramedPatch then keep going deeper through the 
      ////  custom component
      if (startObj instanceof FramedPatch) {
         FramedPatch fp = (FramedPatch) startObj;

         startObj = DenimUtils.getTopmostComponentContainingAbsPt(fp, absPt);


         //// If it is a DenimCustomComponent, then go one level deeper
         if (startObj instanceof DenimCustomComponent) {
            startObj =
               DenimUtils.getTopmostComponentContainingAbsPt(
                  (DenimCustomComponent) startObj,
                  absPt);
         }

      }
      //// Else - If it is a Custom Component Instance then go one level deeper
      else if (startObj instanceof DenimCustomComponentInstance) {

         startObj =
            DenimUtils.getTopmostComponentContainingAbsPt(
               (DenimCustomComponentInstance) startObj,
               absPt);
      }

      if (startObj instanceof DenimPanel) {

         return (DenimPanel) startObj;
      }
      else {
         return null;
      }
   }

   //-----------------------------------------------------------------

   /**
    * Returns the deepest Denim group within the given graphical object group
    * at the given absolute coordinates, or null if there isn't one.
    */
   public static DenimGroup findDeepestNestedDenimGroup(
      GraphicalObjectGroup gobgrp,
      Point2D absPt) {
      
      DenimGroup result = null;
      DenimGroup candidate = null;
      
      for (Iterator it = gobgrp.getForwardIterator(); it.hasNext(); ) {
         Object obj = it.next();
         if (obj instanceof DenimGroup) {
            candidate = (DenimGroup)obj;
            if (candidate.shapeContains(COORD_ABS, absPt)) {
               result = findDeepestNestedDenimGroup(candidate, absPt);
               if (result == null) {
                  result = candidate;
               }
               break;
            }
         }
      }
      
      return result;
   }

   //-----------------------------------------------------------------

   /**
    * Returns what the relative scale of the given object would be if
    * the absolute scale of the object were the one given and the parent
    * of the object were the one given.
    */
   public static AffineTransform
                            getScaleTransformAt(GraphicalObject gob,
                                                double absScale,
                                                GraphicalObjectGroup parent) {
      AffineTransform xform = parent.getInverseTransform(COORD_ABS);
      xform.concatenate
         (AffineTransform.getScaleInstance(absScale, absScale));
      return xform;
   }

   //-----------------------------------------------------------------

   /**
    * Returns what the absolute scale of the given object would be at
    * the given scale factor of the object's sheet.
    */
   public static double getAbsScaleFactorAt(GraphicalObject gob,
                                            double sheetScale) {
      return getAbsTransformAt(gob, sheetScale).getScaleX();
   }

   //-----------------------------------------------------------------

   /**
    * Returns a transform such that the scale is set to the scale of
    * the object, as if the object were at the given scale factor of the
    * object's sheet.
    */
   public static AffineTransform getTransformAt(GraphicalObject gob,
                                                double sheetScale) {
      // 1. Get absolute transform
      AffineTransform tx = getAbsTransformAt(gob, sheetScale);

      // 2. Strip away all ancestor's transforms
      tx.preConcatenate(gob.getParentGroup().getInverseTransform(COORD_ABS));
      /*try {
      GraphicalObjectGroup ancestor = gob.getParentGroup();
      while (ancestor != null) {
      tx.preConcatenate(ancestor.getTransform(COORD_REL).
      createInverse());
      ancestor = ancestor.getParentGroup();
      }
      }
      catch (NoninvertibleTransformException e) {
      e.printStackTrace();
      return null;
      }*/

      return tx;
   }

   //-----------------------------------------------------------------

   /**
    * Returns a transform such that the scale is set to the absolute scale of
    * the object, as if the object were at the given scale factor of the
    * object's sheet.
    */
   private static AffineTransform getAbsTransformAt(GraphicalObject gob,
                                                    double sheetScale) {
      // 1. Get object's complete transform
      AffineTransform absTx = gob.getTransform(COORD_ABS);

      // 2. Strip away sheet's transform
      absTx.preConcatenate(gob.getSheet().getInverseTransform(COORD_ABS));
      /*try {
      absTx.preConcatenate(gob.getSheet().getTransform(COORD_ABS).
      createInverse());
      }
      catch (NoninvertibleTransformException e) {
      e.printStackTrace();
      return null;
      }*/

      // 3. Create new transform with scale set to the given scale factor,
      //    and preconcatenate it
      absTx.preConcatenate(AffineTransform.getScaleInstance(
                                                            sheetScale, sheetScale));

      return absTx;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the real absolute transform of the given graphical object.
    *
    * @param gob the object whose transform to return
    */
   public static AffineTransform getTrueAbsXform(GraphicalObject gob) {
      AffineTransform outTx = new AffineTransform();
      GraphicalObject gobTmp = gob;

      //// 1. Use preConcatenate() for optimization purposes, since
      ////    we don't want to make copies of transforms unnecessarily.
      ////    Just be sure to evaluate from left-to-right.
      while (gobTmp != null) {
         if (gobTmp instanceof DenimLabel) {
            DenimLabel label = (DenimLabel)gobTmp;
            outTx.preConcatenate(label.getLabelView().getStickyTransform());
         }
         else if (gobTmp instanceof PanelBar) {
            PanelBar panelBar = (PanelBar)gobTmp;
            outTx.preConcatenate(panelBar.getStickyTransform());
         }
         outTx.preConcatenate(gobTmp.getTransformRef());
         gobTmp = gobTmp.getParentGroup();
      }

      return outTx;
   }

   //-----------------------------------------------------------------

   /**
    * Returns the real inverse absolute transform of the given graphical
    * object.
    *
    * @param gob the object whose transform to return
    */
   public static AffineTransform getTrueInvAbsXform(GraphicalObject gob) {
      AffineTransform tx = getTrueAbsXform(gob);
      AffineTransform outTx = null;
      try {
         outTx = tx.createInverse();
      }
      catch (NoninvertibleTransformException ex) {
         // this should never happen
         assert false; // "Transform should be invertible"
      }

      return outTx;
   }

   //-----------------------------------------------------------------

   /**
    * Returns a point in absolute coordinates corresponding to the given
    * point in the given graphical object's local coordinate system.
    *
    * @param gob the object whose coordinate system the pt parameter is in
    * @param pt a point which is in gob's coordinate system
    */
   public static Point2D trueLocalToAbs(GraphicalObject gob,
                                        Point2D pt) {
      return getTrueAbsXform(gob).transform(pt, null);
   }

   //-----------------------------------------------------------------

   /**
    * Returns a point in the coordinate system of the given graphical object
    * corresponding to the given point in absolute coordinates.
    *
    * @param gob the object whose coordinate system the returned point is in
    * @param pt a point in absolute coordinates
    */
   public static Point2D trueAbsToLocal(GraphicalObject gob,
                                        Point2D pt) {
      return getTrueInvAbsXform(gob).transform(pt, null);
   }

   //-----------------------------------------------------------------


   /**
    * Returns a rectangle in absolute coordinates corresponding to the given
    * rectangle in the given graphical object's local coordinate system.
    *
    * @param gob the object whose coordinate system the rect parameter is in
    * @param rect a rectangle which is in gob's coordinate system
    */
   public static Rectangle2D trueLocalToAbs(GraphicalObject gob,
                                            Rectangle2D rect) {
      return GeomLib.transformRectangle(getTrueAbsXform(gob), rect);
   }

   //-----------------------------------------------------------------

   /**
    * Returns a rectangle in the coordinate system of the given graphical
    * object corresponding to the given rectangle in absolute coordinates.
    *
    * @param gob the object whose coordinate system the returned point is in
    * @param rect a rectangle in absolute coordinates
    */
   public static Rectangle2D trueAbsToLocal(GraphicalObject gob,
                                            Rectangle2D rect) {
      return GeomLib.transformRectangle(getTrueInvAbsXform(gob), rect);
   }

   //-----------------------------------------------------------------

   /**
    * Adds the given graphical object to the given graphical object group,
    * keeping the absolute coordinates of the graphical object the same.
    *
    * @param gobgrp the group to add into
    * @param gob the object to add
    */
   public static void trueAddKeepAbs(GraphicalObjectGroup gobgrp,
                                     GraphicalObject gob) {
      //// Basically, figure out the absolute transforms for both
      //// Graphical Objects. Move the first Graphical Object first
      //// to absolute coordinates, then back into the other's
      //// coordinate system.
      AffineTransform txOld = gob.getTransform(COORD_ABS);
      AffineTransform txApply = DenimUtils.getTrueInvAbsXform(gobgrp);
      txApply.concatenate(txOld);
      gob.setTransform(txApply);
      gobgrp.add(gob, GraphicalObjectGroup.KEEP_REL_POS);
   }

   //-----------------------------------------------------------------

   /**
    * Returns the absolute bounds of the given graphical object.
    *
    * @param gob the graphical object whose bounds will be returned.
    */
   public static Rectangle2D getTrueAbsBds(GraphicalObject gob) {
      if (gob instanceof DenimLabel) {
         DenimLabel label = (DenimLabel)gob;
         return DenimUtils.trueLocalToAbs(label,
                                          label.getUnstickyLocalBounds());
      }
      else if (gob instanceof PanelBar) {
         PanelBar panelBar = (PanelBar)gob;
         return DenimUtils.trueLocalToAbs(panelBar,
                                          panelBar.getUnstickyLocalBounds());
      }
      else {
         return DenimUtils.trueLocalToAbs(gob, gob.getBounds2D(COORD_LOCAL));
      }
   }

   //-----------------------------------------------------------------

   /**
    * Returns whether the given point is near the given bounds.
    */
   private static boolean isNearBounds(Rectangle2D bds, Point2D pt) {
      Line2D    line     = new Line2D.Float();
      Point2D   ptCorner = new Point2D.Float();

      //// 1. First case, top-left of rectangle...
      ptCorner.setLocation(bds.getX(),
                           bds.getY());
      if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
         position = TOPLEFT;
         return (true);
      }

      //// 2. Second case, top-right of rectangle...
      ptCorner.setLocation(bds.getX() + bds.getWidth(),
                           bds.getY());
      if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
         position = TOPRIGHT;
         return (true);
      }

      //// 3. Third case, bottom-right of rectangle...
      ptCorner.setLocation(bds.getX() + bds.getWidth(),
                           bds.getY() + bds.getHeight());
      if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
         position = BOTTOMRIGHT;
         return (true);
      }

      //// 4. Fourth case, bottom-left of rectangle...
      ptCorner.setLocation(bds.getX(),
                           bds.getY() + bds.getHeight());
      if (ptCorner.distance(pt) < BOUNDS_THRESHOLD) {
         position = BOTTOMLEFT;
         return (true);
      }

      //// 5. First case, top of rectangle...
      line.setLine(bds.getX(), bds.getY(),
                   bds.getX() + bds.getWidth(), bds.getY());
      if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
         position = TOP;
         return (true);
      }

      //// 6. Second case, right side of rectangle...
      line.setLine(bds.getX() + bds.getWidth(), bds.getY(),
                   bds.getX() + bds.getWidth(), bds.getY() + bds.getHeight());
      if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
         position = RIGHT;
         return (true);
      }

      //// 7. Third case, bottom side of rectangle...
      line.setLine(bds.getX(), bds.getY() + bds.getHeight(),
                   bds.getX() + bds.getWidth(), bds.getY() + bds.getHeight());
      if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
         position = BOTTOM;
         return (true);
      }

      //// 8. Fourth case, left side of rectangle...
      line.setLine(bds.getX(), bds.getY(),
                   bds.getX(), bds.getY() + bds.getHeight());
      if (line.ptSegDist(pt) < BOUNDS_THRESHOLD) {
         position = LEFT;
         return (true);
      }

      return (false);

   } // of isNearBounds

   //-----------------------------------------------------------------

   /**
    * Returns the bounding box of the given rectangle and point.
    */
   public static Rectangle2D getNewBounds(Rectangle2D oldBounds, Point2D pt) {
      Rectangle2D bounds = new Rectangle2D.Float();

      double x1 = oldBounds.getX();
      double y1 = oldBounds.getY();
      double x2 = oldBounds.getX() + oldBounds.getWidth();
      double y2 = oldBounds.getY() + oldBounds.getHeight();

      if (isNearBounds(oldBounds, pt)) {

         switch (position) {
         case TOPLEFT:     x1 = pt.getX();
                           y1 = pt.getY();
                           break;
         case TOP:         y1 = pt.getY();
                           break;
         case TOPRIGHT:    x2 = pt.getX();
                           y1 = pt.getY();
                           break;
         case RIGHT:       x2 = pt.getX();
                           break;
         case BOTTOMRIGHT: x2 = pt.getX();
                           y2 = pt.getY();
                           break;
         case BOTTOM:      y2 = pt.getY();
                           break;
         case BOTTOMLEFT:  x1 = pt.getX();
                           y2 = pt.getY();
                           break;
         case LEFT:        x1 = pt.getX();
                           break;
         } // of switch

         bounds.setRect(x1, y1, x2 - x1, y2 - y1);

         return bounds;
      }
      else {
         return oldBounds;
      }
   }

   //-----------------------------------------------------------------

   /**
    * Returns the union of two rectangles. If one of the rectangles is
    * null, then returns the other one.
    */
   public static Rectangle2D createUnion(Rectangle2D r1, Rectangle2D r2) {
      if (r1 == null) {
         return r2;
      }
      else if (r2 == null) {
         return r1;
      }
      else {
         return r1.createUnion(r2);
      }
   }

   //--------------------------------------------------------------

   /**
    * Returns the center of the union of the bounding boxes of the objects
    * in the collection whose iterator has been passed to this method.
    * In the case of DenimPanels, it ignores labels and uses the sketch
    * instead.
    *
    * @param it the iterator of the collection of which the center will
    *           be found
    */
   public static Point2D getCollectionCenter(Iterator it) {
      Rectangle2D     r  = null;
      Point2D         pt = null;
      GraphicalObject gob;

      while (it.hasNext()) {
         gob = (GraphicalObject) it.next();
         if (gob instanceof DenimSheet.Crosshairs ||
             gob instanceof Arrow) {
            continue;
         }

         //// Zoom in on sketches, not on labels.
         if (gob instanceof DenimPanel) {
            gob = ((DenimPanel) gob).getSketch();
         }

         Rectangle2D ir = gob.getBounds2D(COORD_ABS);
         // Filter out objects with huge widths and heights, since
         // those objects are probably buggy
         if (ir.getWidth() <= 1000 && ir.getHeight() <= 1000) {
            if (r == null) {
               r = ir;
            }
            else {
               r = r.createUnion(ir);
            }
         }
      }

      if (r != null) {
         pt = new Point2D.Float();
         pt.setLocation(r.getX() + r.getWidth()  / 2.0,
                        r.getY() + r.getHeight() / 2.0);
      }
      return (pt);
   } // of method

   //-----------------------------------------------------------------

   /**
    * Returns a sequence of the given string repeated the given number
    * of times.
    */
   public static String repeatString(String s, int n) {
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < n; i++) {
         sb.append(s);
      }
      return sb.toString();
   }

   //-----------------------------------------------------------------

   /**
    * Returns a short string representation of a graphical object.
    * Mainly for debugging.
    */
   public static String toMedString(GraphicalObjectCollection gobcol) {
      StringBuffer sb = new StringBuffer();
      Iterator it = gobcol.getForwardIterator();
      sb.append("[");
      while (it.hasNext()) {
         GraphicalObject gob = (GraphicalObject)it.next();
         sb.append(toMedString(gob));
         if (it.hasNext()) {
            sb.append(", ");
         }
      }
      sb.append("]");
      return sb.toString();
   }

   //-----------------------------------------------------------------

   /**
    * Returns a short string representation of a graphical object
    * collection. Mainly for debugging.
    */
   public static String toShortString(GraphicalObjectCollection gobcol) {
      StringBuffer sb = new StringBuffer();
      Iterator it = gobcol.getForwardIterator();
      sb.append("[");
      while (it.hasNext()) {
         GraphicalObject gob = (GraphicalObject)it.next();
         sb.append(toShortString(gob));
         if (it.hasNext()) {
            sb.append(", ");
         }
      }
      sb.append("]");
      return sb.toString();
   }

   //-----------------------------------------------------------------

   /**
    * Returns a short string representation of a graphical object
    * group. Mainly for debugging.
    */
   public static String toShortString(GraphicalObjectGroup gobgrp) {
      return toShortString((GraphicalObject)gobgrp);
   }

   //-----------------------------------------------------------------

   /**
    * Returns a short string representation of a graphical object.
    * Mainly for debugging.
    */
   public static String toMedString(GraphicalObjectGroup gobgrp) {
      return toMedString(gobgrp, 0);
   }

   //-----------------------------------------------------------------

   /**
    * Returns a short string representation of a graphical object.
    * Mainly for debugging.
    */
   public static String toMedString(GraphicalObject gob) {
      if (gob instanceof GraphicalObjectGroup) {
         return toMedString((GraphicalObjectGroup)gob, 0);
      }
      else {
         return toMedString(gob, 0);
      }
   }

   //-----------------------------------------------------------------

   /**
    * Returns a short string representation of a graphical object.
    * Mainly for debugging.
    */
   private static String toMedString(GraphicalObjectGroup gobgrp, int indent) {
      if (gobgrp == null) {
         return null;
      }
      else {
         StringBuffer sb = new StringBuffer();

         sb.append(repeatString("   ", indent));
         sb.append(toShortString(gobgrp));
         sb.append("\n");

         /*sb.append(repeatString("   ", indent));
         sb.append("* Abs bds: ");
         sb.append(toShortString(gobgrp.getBounds2D(COORD_ABS)));
         sb.append("\n");*/

         sb.append(repeatString("   ", indent));
         sb.append("* Xform: ");
         sb.append(toShortString(gobgrp.getTransformRef()));
         sb.append("\n");

         if (gobgrp instanceof DenimLabel) {
            LabelViewWrapper labelView = ((DenimLabel)gobgrp).getLabelView();
            sb.append(repeatString("   ", indent));
            sb.append("* Sticky Xform: ");
            sb.append(toShortString(labelView.getStickyTransform()));
            sb.append("\n");

            sb.append(repeatString("   ", indent));
            sb.append("* Unsticky bds: ");
            sb.append(toShortString(labelView.getUnstickyLocalBounds()));
            sb.append("\n");
         }

         sb.append(repeatString("   ", indent));
         sb.append("* Local bds: ");
         sb.append(toShortString(gobgrp.getBounds2D(COORD_LOCAL)));
         sb.append("\n");

         sb.append(repeatString("   ", indent));
         sb.append("[\n");
         Iterator it = gobgrp.getForwardIterator();
         while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject)it.next();
            if (gob instanceof GraphicalObjectGroup) {
               sb.append(DenimUtils.toMedString((GraphicalObjectGroup)gob,
                                                indent + 1));
            }
            else {
               sb.append(DenimUtils.toMedString(gob, indent + 1));
            }
         }
         sb.append(repeatString("   ", indent));
         sb.append("]\n");
         return sb.toString();
      }
   }

   //-----------------------------------------------------------------

   /**
    * Returns a short string representation of a graphical object.
    * Mainly for debugging.
    */
   private static String toMedString(GraphicalObject gob, int indent) {
      StringBuffer sb = new StringBuffer();
      sb.append(repeatString("   ", indent));
      sb.append(toShortString(gob));
      /*if (gob instanceof Arrow) {
      Arrow arrow = (Arrow)gob;
      sb.append(" - ");
      if (arrow.getType() == Arrow.ORG) {
      sb.append("Org");
      }
      else {
      sb.append("Nav");
      }
      sb.append(": ");
      sb.append(arrow.getOrigSource().getUniqueID());
      sb.append(" -> ");
      sb.append(arrow.getOrigDest().getUniqueID());
      //sb.append(" - (" + toShortString(arrow.getStartPoint2D(COORD_REL)) +
      //        ")-(" + toShortString(arrow.getEndPoint2D(COORD_REL)) + ")");
      }*/
      sb.append("\n");

      /*sb.append(repeatString("   ", indent));
      sb.append("* Abs bds: ");
      sb.append(toShortString(gob.getBounds2D(COORD_ABS)));
      sb.append("\n");*/

      /*sb.append(repeatString("   ", indent));
      sb.append("* Xform: ");
      sb.append(toShortString(gob.getTransformRef()));
      sb.append("\n");

      sb.append(repeatString("   ", indent));
      sb.append("* Local bds: ");
      sb.append(toShortString(gob.getBounds2D(COORD_LOCAL)));
      sb.append("\n");*/

      return sb.toString();
   }


   //-----------------------------------------------------------------

   /**
    * Returns a short string representation of a graphical object.
    * Mainly for debugging.
    */
   public static String toShortString(GraphicalObject gob) {
      if (gob == null) {
         return null;
      }
      else {
         String s = toShortClassName(gob) + ":" + gob.getUniqueID();
         if (gob instanceof Arrow) {
            Arrow arrow = (Arrow)gob;
            s += " (" + toShortString(arrow.getOrigSource()) + "/" +
                 toShortString(arrow.getSource()) + " - " +
                 toShortString(arrow.getOrigDest()) + "/" +
                 toShortString(arrow.getDest()) + ")";
         }
         else if (gob instanceof DenimRadioButtonInstanceContainer) {
            DenimRadioButtonInstanceContainer container = 
               (DenimRadioButtonInstanceContainer)gob;
            Set radioButtons = container.getRadioButtons();
            s += " (radio: ";
            for (Iterator it = radioButtons.iterator(); it.hasNext(); ) {
               s += Long.toString(((GraphicalObject)it.next()).getUniqueID()) + ", ";
            }
            s += ")";
         }
         return s;
      }
   }

   //-----------------------------------------------------------------

   /**
    * Returns a string representation of a point. Does not print out
    * the class of the point.
    */
   public static String toShortString(Point2D pt) {
      if (pt == null) {
         return null;
      }
      DecimalFormat df = (DecimalFormat)NumberFormat.getInstance();
      df.applyPattern("0.00");
      return "" +
             df.format(pt.getX()) + ", " +
             df.format(pt.getY());
   }

   //-----------------------------------------------------------------

   /**
    * Returns a string representation of a rectangle. Does not print out
    * the class of the rectangle.
    */
   public static String toShortString(Rectangle2D rect) {
      if (rect == null) {
         return null;
      }
      DecimalFormat df = (DecimalFormat)NumberFormat.getInstance();
      df.applyPattern("0.00");
      return "" +
             df.format(rect.getX()) + ", " +
             df.format(rect.getY()) + " - " +
             df.format(rect.getWidth()) + ", " +
             df.format(rect.getHeight());
   }

   //-----------------------------------------------------------------

   /**
    * Returns a string representation of an AffineTransform.
    */
   public static String toShortString(AffineTransform tx) {
      if (tx == null) {
         return null;
      }
      DecimalFormat df = (DecimalFormat)NumberFormat.getInstance();
      df.applyPattern("0.00");
      return "[scl: " +
             df.format(tx.getScaleX()) + ", " +
             df.format(tx.getScaleY()) +
             " | xlat: " +
             df.format(tx.getTranslateX()) + ", " +
             df.format(tx.getTranslateY()) +
             " | shr: " +
             df.format(tx.getShearX()) + ", " +
             df.format(tx.getShearY()) + "]";
   }

   //-----------------------------------------------------------------

   /**
    * Returns a string representation of a Map2D for debugging. Uses the short
    * string representation for a graphical object.
    */
   public static String toShortString(Map2D map) {
      if (map == null) {
         return null;
      }
      StringBuffer sb = new StringBuffer();
      Set cols = map.getCols();
      if (cols == null) {
         return null;
      }
      Iterator colIt = cols.iterator();
      sb.append('\t');
      while (colIt.hasNext()) {
         Object colHeader = colIt.next();
         sb.append(colHeader);
         sb.append('\t');
      }
      sb.append('\n');

      Set rows = map.getRows();
      if (rows == null) {
         return null;
      }
      Iterator rowIt = rows.iterator();
      while (rowIt.hasNext()) {
         Object rowHeader = rowIt.next();
         if (rowHeader instanceof GraphicalObject) {
            sb.append(DenimUtils.toShortString((GraphicalObject)rowHeader));
         }
         else {
            sb.append(rowHeader);
         }
         sb.append('\t');
         colIt = map.getCols().iterator();
         while (colIt.hasNext()) {
            Object colHeader = colIt.next();
            Object data = map.get(rowHeader, colHeader);
            if (data instanceof GraphicalObject) {
               sb.append(DenimUtils.toShortString((GraphicalObject)data));
            }
            else {
               sb.append(data);
            }
            sb.append('\t');
         }
         sb.append('\n');
      }

      return sb.toString();
   }


   //-----------------------------------------------------------------

   /**
    * Returns the name of a class without the package name.
    */
   public static String toShortClassName(Object obj) {
      if (obj == null) {
         return null;
      }
      String className = obj.getClass().getName();
      String packageName = obj.getClass().getPackage().getName();

      String shortClassName = className.substring(packageName.length());
      if (shortClassName.charAt(0) == '.') {
         shortClassName = shortClassName.substring(1);
      }
      return shortClassName;
   }


   //-----------------------------------------------------------------

   /**
    * Prints out the bounds and transform of the given graphical object to
    * the debug window.
    *
    * @param gob the object whose bounds and transform will be printed
    * @param label a string that is printed before the bounds
    */
   public static void debugPrintBounds(GraphicalObject gob, String label) {
      if (gob == null) {
         Debug.println(label + ": given object is null, has no bounds");
      }
      else {
         Debug.println(label + " " + toShortString(gob));
         Debug.println("  Absolute : " + gob.getBounds2D(COORD_ABS));
         Debug.println("  Relative : " + gob.getBounds2D(COORD_REL));
         Debug.println("  Local    : " + gob.getBounds2D(COORD_LOCAL));
         Debug.println("  Transform: " + gob.getTransformRef());
      }
   }


   //-----------------------------------------------------------------

   /**
    * Prints out the transform of the given graphical object to
    * and all of its children.
    *
    * @param gob the object whose bounds and transform will be printed
    * @param label a string that is printed before the bounds
    */
   public static void debugPrintTransformDescendants(GraphicalObject gob,
                                                     String label) {
      Debug.println(label + ":");
      debugPrintTransformDescendants(gob, 0);
   }

   //-----------------------------------------------------------------

   private static void debugPrintTransformDescendants(GraphicalObject gob,
                                                      int level) {
      if (gob == null) {
         Debug.println("given object is null, has no transform");
      }
      else {
         StringBuffer sb = new StringBuffer();
         for (int i = 0; i <= level; i++) {
            sb.append("  ");
         }
         Debug.println(sb.toString() + toShortString(gob) +
                       " xform: " + gob.getTransformRef());

         if (gob instanceof GraphicalObjectCollection) {
            GraphicalObjectCollection gobcol = (GraphicalObjectCollection)gob;
            Iterator it = gobcol.getForwardIterator();
            while (it.hasNext()) {
               debugPrintTransformDescendants((GraphicalObject)it.next(),
                                              level + 1);
            }
         }
      }
   }

   //-----------------------------------------------------------------

   /**
    * Prints out the transform of the given graphical object to
    * and all of its parents.
    *
    * @param gob the object whose bounds and transform will be printed
    * @param label a string that is printed before the bounds
    */
   public static void debugPrintTransformAncestors(GraphicalObject gob,
                                                   String label) {
      if (gob == null) {
         Debug.println(label + ": given object is null, has no transform");
      }
      else {
         Debug.println(label + " - " + toShortString(gob) +
                       " xform: " + gob.getTransformRef());
         GraphicalObjectGroup parent = gob.getParentGroup();
         while (parent != null) {
            Debug.println("  " + toShortString(parent) +
                          " xform: " + parent.getTransformRef());
            parent = parent.getParentGroup();
         }
      }
   }

   //-----------------------------------------------------------------

   /**
    * Post the given map of key-value string pairs to the given URL. Returns
    * the response as a list of strings.
    *
    * More or less swiped from the NotePals upload client for CrossPad.
    */
   public static java.util.List postToURL(URL postURL, Map map) {
      Iterator it = map.entrySet().iterator();
      String query = "";
      while (it.hasNext()) {
         Map.Entry entry = (Map.Entry)it.next();
         try {
            query += URLEncoder.encode((String)entry.getKey(), "UTF-8") + "=" +
                     URLEncoder.encode((String)entry.getValue(), "UTF-8");
         }
         catch (UnsupportedEncodingException e) {
            System.err.println("Impossible: all Java platforms must support UTF-8");
            e.printStackTrace();
         }
         if (it.hasNext()) {
            query += "&";
         }
      }

      java.util.List lineList = null;

      try {

         // open the connection and prepare it to POST

         URLConnection uc = postURL.openConnection();
         uc.setDoOutput(true);
         uc.setDoInput(true);
         uc.setAllowUserInteraction(false);
         DataOutputStream dos = new DataOutputStream(uc.getOutputStream());

         // The POST line, the Accept line, and
         // the content-type headers are sent by the URLConnection.
         // We just need to send the data
         dos.writeBytes(query);
         dos.close();


         // Read the response
         BufferedReader dis =
                             new BufferedReader(new InputStreamReader(uc.getInputStream()));
         String nextline;
         lineList = new ArrayList();
         while ((nextline = dis.readLine()) != null) {
            lineList.add(nextline);
         }
         dis.close();

         Debug.println("Results of post:");
         for (int i = 0; i < lineList.size(); i++) {
            Debug.println(lineList.get(i));
         }

      }
      catch (Exception e) {
         System.err.println(e);
         e.printStackTrace();
      }

      return lineList;
   }

   //-----------------------------------------------------------------

   /**
    * Gets a gesture stroke used for feedback purposes
    *
    * @param currentClassifier the classifier that the look of the
    * stroke is taken from
    * @param gestureName the name of the gesture category in the
    * classifier that the look of the stroke is taken from (the first
    * example gesture is used)
    */
   public static TimedStroke getGestureFeedbackStroke(Classifier
                                                      currentClassifier,
                                                      String gestureName) {
      // Get the look of the "ideal" gesture from the training set
      TimedPolygon idealGesturePts =
         currentClassifier.getIdealGesturePoints(gestureName);

	   TimedStroke gestureFeedbackStroke=null;
      if (idealGesturePts != null) {
         gestureFeedbackStroke = new TimedStroke(idealGesturePts);
         gestureFeedbackStroke.setSelectable(false);
      }
      else {
         Debug.println("getIdealGesturePoints returned null.");
      }
      
      return gestureFeedbackStroke;
   }

   //-----------------------------------------------------------------

   /**
    * Get a small dot stroke used for feedback purposes
    *
    * @param location the coordinates that the dot should appear at
    */
   public static TimedStroke getDotFeedbackStroke(Point2D location) {
      // Calc the look of a dot illustrating the gesture's starting point
      Polygon dotCoords = new Polygon();
      int x = (int) location.getX();
      int y = (int) location.getY();
      dotCoords.addPoint(x+0,y+0);
      dotCoords.addPoint(x+0,y+3);
      dotCoords.addPoint(x+2,y+2);
      dotCoords.addPoint(x+3,y+0);
      dotCoords.addPoint(x+2,y-2);
      dotCoords.addPoint(x+0,y-1);
      dotCoords.addPoint(x-2,y-1);
      dotCoords.addPoint(x-3,y+0);
      dotCoords.addPoint(x-2,y+2);
      TimedStroke dotStroke = new TimedStroke(dotCoords);
      dotStroke.setSelectable(false);

      return dotStroke;
   }

   //-----------------------------------------------------------------

   /**
    * Draws a feedback stroke to the user
    *
    * @param currentClassifier the classifier that the look of the
    * stroke is taken from
    * @param gestureName the name of the gesture category in the
    * classifier that the look of the stroke is taken from (the first
    * example gesture is used)
    * @param sheet the sheet in which the stroke is rendered
    * @param location the rendering position
    */
   public static void provideFeedback(Classifier currentClassifier, String gestureName,
                                      DenimSheet sheet, Point2D location) {
      // Create a style for the feedback

      Style feedbackStyle = sheet.getRightCurrentStyle();
      feedbackStyle.setDrawColor(new Color
         (0, 204, 0, feedbackStyle.getDrawColor().getAlpha()));

      // Create a stroke showing the ideal gesture
      TimedStroke gestureStroke = getGestureFeedbackStroke(currentClassifier, gestureName);
 	  if (gestureStroke!=null) {
         gestureStroke.setStyle(feedbackStyle);
         sheet.add(gestureStroke, GraphicalObjectGroup.KEEP_ABS_POS);
         gestureStroke.moveTo(COORD_ABS, location);

         // Create a small circular stroke denoting the beginning
         TimedStroke dotStroke = getDotFeedbackStroke(gestureStroke.getStartPoint2D(COORD_ABS));
         dotStroke.setStyle(feedbackStyle);
         sheet.add(dotStroke, GraphicalObjectGroup.KEEP_ABS_POS);

         // Set a timer to remove the feedback again
         javax.swing.Timer theTimer = new javax.swing.Timer
            (1000, new FeedbackTimerAction(gestureStroke, dotStroke, sheet));
         theTimer.setRepeats(false);
         theTimer.start();
 	  }
   }

   //-----------------------------------------------------------------

   /**
    * FeedbackTimerAction used by method provideFeedback
    *
    */
   private static class FeedbackTimerAction
      implements ActionListener {

      public TimedStroke theGestureStroke;
      public TimedStroke theDotStroke;
      public DenimSheet theSheet;

      public FeedbackTimerAction (TimedStroke aGestureStroke, TimedStroke aDotStroke, DenimSheet aSheet) {
         super();
         theGestureStroke = aGestureStroke;
         theDotStroke = aDotStroke;
         theSheet = aSheet;
      }

      public void actionPerformed(ActionEvent aEvt) {
         theSheet.remove(theGestureStroke);
         theSheet.remove(theDotStroke);
      }
   }
}

//==============================================================================

/*
  Copyright (c) 1999-2001 Regents of the University of California.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  3. All advertising materials mentioning features or use of this software
  must display the following acknowledgement:

  This product includes software developed by the Group for User
  Interface Research at the University of California at Berkeley.

  4. The name of the University may not be used to endorse or promote products
  derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGE.
*/
