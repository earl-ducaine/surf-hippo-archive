package edu.berkeley.guir.lib.gesture.features;

import edu.berkeley.guir.lib.gesture.*;
import java.awt.Polygon;
import java.lang.Math;

/**
 * Sharpness of the entire gesture.  (Technically, the sum of the square of
 * the angle at each point.)
 */
public class Sharpness extends Feature {
  public final double minValue = 0;
  public final double maxValue = Double.POSITIVE_INFINITY;
  
  public Sharpness()
  {
    super();
  }

  public Sharpness(Gesture g)
  {
    super(g);
  }

  public String getName()
  {
    return new String("sharpness");
  }

  /**
   * Return maximum value this feature can have
   */
  public double getMinValue()
  {
    return minValue;
  }
  
  /**
   * Return minimum value this feature can have
   */
  public double getMaxValue()
  {
    return maxValue;
  }

  /**
   * Non-incremental computation.  Should set value to new value and
   * valueOk to true.
   */
  protected void computeValue()
  {
    Polygon points = gesture.getPointsRef();
    value = 0;
    for (int i = 2; i < points.npoints; i++) {
      double dx = points.xpoints[i] - points.xpoints[i-1];
      double dy = points.ypoints[i] - points.ypoints[i-1];
      double dx2 = points.xpoints[i-1] - points.xpoints[i-2];
      double dy2 = points.ypoints[i-1] - points.ypoints[i-2];
      double theta = Math.atan2(dx*dy2 - dx2*dy, dx*dx2 + dy*dy2);
      value += theta*theta;
    }
    valueOk = true;
  }

  /**
   * Change @gesture so that the feature changes (ideally by the
   * scale factor).
   */
  public void scale(double factor)
  {
    // todo
  }
}
