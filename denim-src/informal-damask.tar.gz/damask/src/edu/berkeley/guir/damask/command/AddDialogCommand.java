package edu.berkeley.guir.damask.command;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.Iterator;

import edu.berkeley.guir.damask.*;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.dialog.Dialog;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.lib.satin.command.UndoableCommand;

/**
 * A command that creates a dialog (and page) within a graph.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  09-18-2003 James Lin
 *                               Created CreatePageCommand.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 09-18-2003
 */
public class AddDialogCommand
   extends UndoableCommand
   implements ModifyGraphCommand {
   
   private final InteractionGraph graph;
   private final Dialog dialog;


   /**
    * Constructs the command.
    *  
    * @param graph the interaction graph that the dialog should be added to
    * @param title the title of the first page of the dialog
    * @param deviceType the type of device for which to specify the bounds of
    * the first page 
    * @param dialogPageBounds the bounds of the first page of the new dialog,
    * for the given device type 
    * @param addToAllDevices true if the page should be made visible to all
    * devices
    */      
   public AddDialogCommand(final InteractionGraph graph, final Dialog dialog) {
      this.graph = graph;
      this.dialog = dialog;
   }


   /**
    * Constructs the command.
    *  
    * @param graph the interaction graph that the dialog should be added to
    * @param title the title of the first page of the dialog
    * @param deviceType the type of device for which to specify the bounds of
    * the first page 
    * @param dialogPageBounds the bounds of the first page of the new dialog,
    * for the given device type 
    * @param addToAllDevices true if the page should be made visible to all
    * devices
    */      
   public AddDialogCommand(
      final InteractionGraph graph,
      final Content title,
      final DeviceType deviceType,
      final boolean addToAllDevices,
      final Rectangle2D dialogPageBounds,
      final AffineTransform dialogPageTransform) {

      deviceType.verifyTypeIsNotAll();

      this.graph = graph;

      // Create a dialog and page
      dialog = new Dialog(addToAllDevices ? DeviceType.ALL : deviceType, title); 

      // Set the bounds and transform of the new dialog
      setInitialBoundsAndTransform(dialog,
                                   deviceType,
                                   dialogPageBounds,
                                   dialogPageTransform);
      
      final double x = dialogPageBounds.getX();
      final double y = dialogPageBounds.getY();
      for (Iterator i = dialog.getDeviceTypesVisibleTo().iterator(); i.hasNext(); ) {
         final DeviceType aDeviceType = (DeviceType)i.next();
         if (aDeviceType != deviceType) {
            setInitialBoundsAndTransform(dialog,
                                         aDeviceType,
                                         new Rectangle2D.Double(x, y,
                                               aDeviceType.getDefaultWidth(),
                                               aDeviceType.getDefaultHeight()),
                                         dialogPageTransform);
         }
      }
   }
   
   private void setInitialBoundsAndTransform(final Dialog dialog,
         final DeviceType deviceType, final Rectangle2D bounds,
         final AffineTransform transform) {
      final Page firstPage = dialog.getFirstPage(deviceType);
      if (deviceType == DeviceType.VOICE) {
         dialog.setTransform(deviceType, transform);
         dialog.setBounds(deviceType, bounds);
         firstPage.setTransform(new AffineTransform());
         firstPage.setBounds(bounds);
      }
      else {
         firstPage.setTransform(transform);
         firstPage.setBounds(bounds);
      }
   }

   // Overrides method in superclass.   
   public String getPresentationName() {
      return "Create dialog " + dialog.toLongString();
   }

   // Overrides method in superclass.   
   public boolean canRedo() {
      return true;
   }
   
   // Overrides method in superclass.   
   public void run() {
      graph.add(dialog);
   }
   
   // Overrides method in superclass.   
   public void redo() {
      run();
   }

   // Overrides method in superclass.   
   public void undo() {
      graph.remove(dialog);
   }
}
