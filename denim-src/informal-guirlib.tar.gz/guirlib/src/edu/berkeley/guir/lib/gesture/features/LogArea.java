package edu.berkeley.guir.lib.gesture.features;

import java.awt.Rectangle;
import edu.berkeley.guir.lib.gesture.Feature;
import edu.berkeley.guir.lib.gesture.Gesture;

public class LogArea extends Feature {
  public LogArea()
  {
    super();
  }

  public LogArea(Gesture g)
  {
    super(g);
  }

  public String getName()
  {
    // todo
    return "log(area)";
  }
  
  public double getMinValue()
  {
    return Double.MIN_VALUE;
  }
  
  public double getMaxValue()
  {
    return Double.MAX_VALUE;
  }
  
  protected void computeValue()
  {
    Rectangle bounds = gesture.getBounds();
    double boundsLength = Math.sqrt((bounds.width * bounds.width) +
				    (bounds.height * bounds.height));

    value = 2 * Math.log(boundsLength);
    valueOk = true;
  }

  public void scale(double factor)
  {
  }
}
