package edu.berkeley.guir.lib.gesture;

import java.util.Iterator;
import java.util.List;
import edu.berkeley.guir.lib.gesture.util.CollectionListener;

/** A collection of GestureObjects.  Emits a collectionEvent when any
    contained GestureObject is added, removed, or changes. */
public interface GestureContainer extends GestureObject {
  String NAME_PROP = "name";
  /** Used to report that a child has been added or removed.  If a
      child has been added, the old value is null and the new value is
      the new child.  If a child has been removed, the new value is
      null and the old value is the child.  Cannot be used with
      getProperty() or setProperty(). */
  String CHILDREN_PROP = "children";
  /** Used to report property change of a child object.  New value is
      the PropertyChangeEvent as reported by the child. Cannot be used
      with getProperty() or setProperty(). (That would be
      meaningless.) */
  String CHILD_CHANGE_PROP = "child changed";

  /** Returns the child object at index i. */
  GestureObject getChild(int i);
  /** Remove a child from this container.  (Or do nothing if
      gestureObj is not a child of this. */
  void remove(GestureObject gestureObj);
  Iterator iterator();
  List getEnabledChildren();
  int size();
  void add(GestureObject obj);
  /** Returns an array of all the valid types for children of this
      container. */
  Class[] getChildTypes();
  boolean isChildType(Class type);

  /** Set the property on the entire subtree */
  void setPropertyOnTree(String propName, Object value);
  
  void setName(String name);
  String getName();
  void addCollectionListener(CollectionListener l);
  void removeCollectionListener(CollectionListener l);
}
