package edu.berkeley.guir.damask.view.visual;

import java.awt.*;
import java.awt.event.*;
import java.util.logging.Logger;

import javax.swing.*;

import edu.berkeley.guir.damask.DamaskUtils;
import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.dialog.Page;
import edu.berkeley.guir.damask.view.DamaskApp;
import edu.berkeley.guir.damask.view.appevent.RunCanvasEvent;
import edu.berkeley.guir.damask.view.appevent.RunCanvasListener;
import edu.umd.cs.piccolox.swing.PScrollPane;

/** 
 * The window that contains the Damask application in Run mode for Smartphones.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  11-25-2003 James Lin
 *                               Created DamaskRunFrame
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 11-25-2003
 */
public class DamaskPhoneRunFrame extends JFrame {
   // Logger
   private static final Logger logger =
      Logger.getLogger(DamaskPhoneRunFrame.class.getName());
   
   private final DamaskRunCanvas canvas;
   private final PScrollPane scrollPane;

   private final JPanel mainKeypad, southKeypad, northKeypad;
   private JPanel southKeypadSouth, southKeypadNorth;
   private JPanel northKeypadWest, northKeypadEast, northKeypadCenter;
   private JButton send,
      end,
      one,
      two,
      three,
      four,
      five,
      six,
      seven,
      eight,
      nine,
      zero,
      asterisk,
      pound;

   private JButton leftdot, rightdot, home, back;
   private JButton left, right, top, bottom, ok;

   /**
    * Constructs a Run window that displays pages from the specified document,
    * and makes the window visible.
    */
   public DamaskPhoneRunFrame(final String documentName, final Page page) {
      final DeviceType deviceType = page.getDeviceType();

      setTitle(documentName + " [Run - " + deviceType + "] - Damask");

      canvas = new DamaskRunCanvas();
      canvas.addRunCanvasListener(new RunCanvasHandler());

      final Container contentPane = getContentPane();
      contentPane.setLayout(new BorderLayout());

      scrollPane = new PScrollPane(canvas);
      canvas.setContainingScrollPane(scrollPane);
      contentPane.add(scrollPane, BorderLayout.CENTER);

      //Add keypad 
      mainKeypad = new JPanel(new BorderLayout());
      southKeypad = new JPanel(new BorderLayout());

      northKeypad = new JPanel(new BorderLayout());
      mainKeypad.add(southKeypad, BorderLayout.SOUTH);
      mainKeypad.add(northKeypad, BorderLayout.NORTH);
      contentPane.add(mainKeypad, BorderLayout.SOUTH);
      initKeypad();
      // View the current page, and make the window the same size as the
      // device type's default dimensions
      canvas.goToPage(page);

      setVisible(true);
      final Insets insets = getInsets();
      canvas.setPreferredSize(
         new Dimension(
            deviceType.getDefaultWidth() + insets.left + insets.right,
            deviceType.getDefaultHeight()
               + (int)canvas.getCurrentPageView().getOffset().getY()
               + insets.top
               + insets.bottom));
      scrollPane.getViewport().setViewPosition(new Point(0, 0));

      pack();
      
      final WindowHandler winHandler = new WindowHandler();
      addWindowListener(winHandler);
      addWindowFocusListener(winHandler);
      logger.info(this + " opened with view of " +
                  canvas.getCurrentPageView().getModel());
   }

   /**
    * initialize the southKeypad for the smartPhone.
    *
    */
   private void initKeypad() {
      send = new JButton("Send");
      end = new JButton("End");
      one = new JButton("1");
      two = new JButton("2");
      three = new JButton("3");
      four = new JButton("4");
      five = new JButton("5");
      six = new JButton("6");
      seven = new JButton("7");
      eight = new JButton("8");
      nine = new JButton("9");
      asterisk = new JButton("*");
      zero = new JButton("0");
      pound = new JButton("#");

      leftdot = new JButton("...");
      rightdot = new JButton("...");
      home = new JButton("Home");
      back = new JButton(new BackAction());

      top = new JButton(getRadarIcon("top.gif"));
      bottom = new JButton(getRadarIcon("bottom.gif"));
      left = new JButton(getRadarIcon("left.gif"));
      right = new JButton(getRadarIcon("right.gif"));
      ok = new JButton("ok");

      southKeypadNorth = new JPanel(new BorderLayout());
      southKeypadSouth = new JPanel();
      northKeypadWest = new JPanel();
      northKeypadEast = new JPanel();
      northKeypadCenter = new JPanel(new BorderLayout());

      southKeypadNorth.add(send, BorderLayout.WEST);
      southKeypadNorth.add(end, BorderLayout.EAST);

      southKeypadSouth.setLayout(new GridLayout(0, 3));
      southKeypadSouth.add(one);
      southKeypadSouth.add(two);
      southKeypadSouth.add(three);
      southKeypadSouth.add(four);
      southKeypadSouth.add(five);
      southKeypadSouth.add(six);
      southKeypadSouth.add(seven);
      southKeypadSouth.add(eight);
      southKeypadSouth.add(nine);
      southKeypadSouth.add(asterisk);
      southKeypadSouth.add(zero);
      southKeypadSouth.add(pound);

      northKeypadWest.setLayout(new GridLayout(2, 0));
      northKeypadEast.setLayout(new GridLayout(2, 0));

      northKeypadWest.add(leftdot);
      northKeypadWest.add(home);
      northKeypadEast.add(rightdot);
      northKeypadEast.add(back);

      northKeypadCenter.add(ok, BorderLayout.CENTER);
      northKeypadCenter.add(top, BorderLayout.NORTH);
      northKeypadCenter.add(bottom, BorderLayout.SOUTH);
      northKeypadCenter.add(left, BorderLayout.WEST);
      northKeypadCenter.add(right, BorderLayout.EAST);

      southKeypad.add(southKeypadSouth, BorderLayout.SOUTH);
      southKeypad.add(southKeypadNorth, BorderLayout.NORTH);

      northKeypad.add(northKeypadWest, BorderLayout.WEST);
      northKeypad.add(northKeypadEast, BorderLayout.EAST);
      northKeypad.add(northKeypadCenter, BorderLayout.CENTER);
   }

   /**
   	* Gets an image for the radar view. 
   	*/
   protected ImageIcon getRadarIcon(final String fileName) {
      final Image image =
         Toolkit.getDefaultToolkit().createImage(
            DamaskApp.class.getResource("images/radar/" + fileName));
      return new ImageIcon(image);
   }

   /**
    * Enables or disables the Back and Forward buttons, depending on
    * whether there are pages in their respective stacks.
    */

   protected void updateButtonsEnabled() {
      //	backButton.setEnabled(canvas.canGoBack());
      //	forwardButton.setEnabled(canvas.canGoForward());      
      back.setEnabled(canvas.canGoBack());
   }
   
   
   // @Override
   public String toString() {
      return DamaskUtils.toShortString(this);
   }

   
   /**
    * The Back action.
    */
   private class BackAction extends AbstractAction {
      public BackAction() {
         super("Back");
         putValue(SHORT_DESCRIPTION, "Go back to the previous page");
         putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_LEFT));
      }

      public void actionPerformed(ActionEvent e) {
         canvas.goBack();
         logger.info(DamaskPhoneRunFrame.this + ": back -> " +
                     canvas.getCurrentPageView().getModel());
      }
   }

   /**
    * Listens to events from DamaskRunCanvas.
    */
   private class RunCanvasHandler implements RunCanvasListener {
      public void loadCompleted(RunCanvasEvent e) {
         logger.info(DamaskPhoneRunFrame.this + " loaded with view of " +
                     canvas.getCurrentPageView().getModel());
         updateButtonsEnabled();
         scrollPane.getVerticalScrollBar().setValue(
            scrollPane.getVerticalScrollBar().getMinimum());
      }
   }

   /**
    * Responds to window events.
    */
   private class WindowHandler extends WindowAdapter {
      public void windowClosing(WindowEvent e) {
         logger.info(DamaskPhoneRunFrame.this + " closed");
      }

      public void windowGainedFocus(WindowEvent e) {
         logger.info(DamaskPhoneRunFrame.this + " gained focus");
      }

      public void windowLostFocus(WindowEvent e) {
         logger.info(DamaskPhoneRunFrame.this + " lost focus");
      }
   }
}
