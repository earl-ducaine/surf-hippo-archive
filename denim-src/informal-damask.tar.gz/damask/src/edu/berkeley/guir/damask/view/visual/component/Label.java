package edu.berkeley.guir.damask.view.visual.component;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.command.EditContentCommand;
import edu.berkeley.guir.damask.command.SetContentDisplayModeCommand;
import edu.berkeley.guir.damask.component.Content;
import edu.berkeley.guir.damask.component.Trigger;
import edu.berkeley.guir.damask.connection.NavConnection;
import edu.berkeley.guir.damask.event.*;
import edu.berkeley.guir.damask.view.*;
import edu.berkeley.guir.damask.view.appdialogs.FileDialogUtils;
import edu.berkeley.guir.damask.view.nodes.DamaskPPath;
import edu.berkeley.guir.damask.view.visual.dialog.PageRegionView;
import edu.berkeley.guir.lib.satin.command.MacroCommand;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.nodes.*;
import edu.umd.cs.piccolo.util.PDimension;
import edu.umd.cs.piccolo.util.PPaintContext;
import edu.umd.cs.piccolox.handles.PHandle;

/** 
 * A label, which is a view of a piece of Damask content.
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  10-18-2003 James Lin
 *                               Created Label.
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 10-18-2003
 */
public class Label extends ControlView {
   public static final int TEXT_PADDING = 2;
   
   private static final int EMPTY_LABEL_WIDTH = 100;
   private static final int EMPTY_LABEL_HEIGHT = 100;
   private static final Color EMPTY_LABEL_COLOR = Color.LIGHT_GRAY;
   private static final Color STROKES_BACKGROUND =
      new Color(0, 255, 0, 15);
   private static final Stroke EMPTY_LABEL_STROKE =
      new BasicStroke(
         1,
         BasicStroke.CAP_BUTT,
         BasicStroke.JOIN_MITER,
         1,
         new float[] { 2, 2 },
         0);
   private static final Map/*<Content.DisplayMode, String>*/ EMPTY_LABEL_TEXT =
      new HashMap/*<Content.DisplayMode, String>*/();
   static {
      EMPTY_LABEL_TEXT.put(Content.INK, "Sketch\nhere");
      EMPTY_LABEL_TEXT.put(Content.TEXT, "Type\nhere");
      EMPTY_LABEL_TEXT.put(Content.IMAGE, "Click here to\ninsert image");
   }

   private boolean empty = false;
   private final ContentHandler labelHandler = new ContentHandler();
   private final PText text = new PText();
   private final PImage image = new PImage();
   private final PNode strokes = new PNode();  // children are DamaskPPaths
   private final Map/*<GeneralPath, PNode>*/ pathStrokes =
      new HashMap/*<GeneralPath, PNode>*/();
   
   // shown if there is no info for the current display mode
   private final PPath placeholder =
      new PPath(new Rectangle(0, 0, EMPTY_LABEL_WIDTH, EMPTY_LABEL_HEIGHT));
   private final PText placeholderText = new PText();
   private static final int PLACEHOLDER_TEXT_SIZE = 18;
   
   private Color labelColor = Color.BLACK;
	   
   private Content.DisplayMode displayMode;

   /**
    * Constructs a label.
    */
   public Label(final Content content) {
      this(content, true);
   }
   
   /**
    * Constructs a label.
    * 
    * @param content the content for which this view is created
    * @param autoUpdateBoundsTransform true if this instance should
    * automatically adjust the bounds and transform of the view by
    * listening to changes in the model
    */
   public Label(
      final Content content,
      final boolean autoUpdateBoundsTransform) {

      super(content, autoUpdateBoundsTransform);
      
      content.addInteractionElementListener(labelHandler);
      content.addContentEventListener(labelHandler);
      
      // Setup the label's text
      text.setPickable(false);
      setTextString(content.getText());
      
      // Setup the label's image
      if (content.getImage() != null) {
         image.setImage(content.getImage());
      }
      image.setPickable(false);
      
      // Setup the label's ink
      strokes.setPickable(false);
      
      // Create the node that is shown if there is no info for the
      // current display mode
      placeholder.setPickable(false);
      placeholder.setStroke(EMPTY_LABEL_STROKE);
      placeholder.setStrokePaint(EMPTY_LABEL_COLOR);

      placeholderText.setPickable(false);
      placeholderText.setConstrainWidthToTextWidth(true);
      placeholderText.setConstrainHeightToTextHeight(true);
      
      DamaskAppUtils.setFontSize(placeholderText, PLACEHOLDER_TEXT_SIZE);
      placeholder.addChild(placeholderText);

      addInputEventListener(new InputEventHandler());
   }


   // Overrides method in parent class.
   protected void initAfterAddToParent() {
      super.initAfterAddToParent();

      final Content content = (Content)getModel();
      final Rectangle2D newBounds = content.getBounds(getDeviceType());
      
      // Offset the text just a little bit
      text.setBounds(newBounds);
      text.offset(TEXT_PADDING, TEXT_PADDING);
      setTextSize(content.getTextSize(getDeviceType()));
      
      image.setBounds(newBounds);

      // The strokes don't need their bounds to be set, since each
      // stroke stores its own coordinates. 
      setStrokes(content.getStrokes());

      // Figure out which type of information to display in the label view
      setDisplayMode(content.getPreferredDisplayMode(getDeviceType()));
   }

   // Overrides method in parent class.
   public void dispose() {
      super.dispose();
      final Content content = (Content)getModel();
      content.removeInteractionElementListener(labelHandler);
      content.removeContentEventListener(labelHandler);
   }


   // Overrides method in parent class.
   public PageRegionView getPageRegionView() {
      // Because a LabelView can be inside of another ControlView as well as
      // in a PageRegionView, we need to walk the hierarchy until we find
      // a PageRegionView.
      PNode node = getParent();
      while (!(node instanceof PageRegionView) && (node != null)) {
         node = node.getParent();
      }
      return (PageRegionView)node;
   }

   
   /**
    * Returns the display mode of this label view. 
    */
   public Content.DisplayMode getDisplayMode() {
      return displayMode;
   }


   /**
    * Returns null, since labels don't have state.
    */
   public Object getState() {
      return null;
   }


   /**
    * Has no effect, since labels don't have state.
    */
   public void setState(final Object state) {
   }


   /**
    * Returns a representation of what a label looks like by default.
    */
   public static PNode createTempView() {
      final PNode node = new PNode();
      node.addChild(new PText("Label"));
      return node;
   }

   /**
    * Show the placeholder, used when the label has no data in the specified
    * display mode. 
    */
   private void showPlaceholder() {
      placeholderText.setText(
         ((String)EMPTY_LABEL_TEXT.get(displayMode)));
      placeholderText
         .setTransform(
            AffineTransform.getTranslateInstance(
               (placeholder.getWidth() - placeholderText.getWidth()) / 2,
               (placeholder.getHeight() - placeholderText.getHeight()) / 2));
      
      addChild(placeholder);
      setBounds(placeholder.getPathReference().getBounds2D());
   }

   
   /**
    * Returns whether the label has any data to show in the current display
    * mode.
    */
   public boolean isEmpty() {
      return empty;
   }
   
   
   /**
    * Show or hide the placeholder, depending on whether the label has any
    * data in the current display mode. 
    */
   private void refreshContents() {
      empty = false;
      for (Iterator i = new ArrayList(getChildrenReference()).iterator();
         i.hasNext();
         ) {
         final PNode child = (PNode)i.next();
         if (!(child instanceof PHandle)) {
            removeChild(child);
         }
      }
      
      setPaint(DamaskAppUtils.NO_COLOR);
      if (displayMode == Content.IMAGE) {
         if (image.getImage() == null) {
            empty = true;
         }
         else if (image.getParent() == null) {
            addChild(image);
         }
      }
      else if (displayMode == Content.TEXT) {
         if (((Content)getModel()).getText().length() == 0) {
            empty = true;
         }
         else if (text.getParent() == null) {
            addChild(text);
         }
      }
      else {
         if (strokes.getChildrenCount() == 0) {
            empty = true;
         }
         else if (strokes.getParent() == null) {
            addChild(strokes);
            if (!isInRunMode()) {
               setPaint(STROKES_BACKGROUND);
            }
         }
      }
      
      if (empty) {
         showPlaceholder();
      }
      else {
         setBounds(getModel().getBounds(getDeviceType()));
      }
   }


   // Overrides method in parent class.
   public void fullPaint(PPaintContext paintContext) {
      
      // HACK so that voice empty responses do not show up in other
      // device types
      final boolean inTriggerView =
         getParent() instanceof ControlView &&
         ((ControlView)getParent()).getModel() instanceof Trigger;
      final DeviceType deviceType = getDeviceType();
      boolean dontShow = false;
      if (inTriggerView) {
         final Trigger trigger = (Trigger)((ControlView)getParent()).getModel();
         for (Iterator i = trigger.getOutConnections().iterator(); i.hasNext(); ) {
            final NavConnection connection = (NavConnection)i.next();
            if (connection.isVisibleToDeviceType(deviceType) &&
                connection.getSource(deviceType).getPage(deviceType) ==
                connection.getDest(deviceType).getPage(deviceType)) {
               dontShow = true;
               break;
            }
         }
      }
      dontShow |= (empty && displayMode == Content.TEXT && inTriggerView);
      if (!dontShow) {
         super.fullPaint(paintContext);
      }
   }
   
   /**
    * Sets the display mode of this label. 
    */
   public void setDisplayMode(final Content.DisplayMode displayMode) {
      this.displayMode = displayMode;
      
      refreshContents();
   }

   
   /**
    * Returns a node, each of whose children is a stroke contained in this
    * label. 
    */
   public PNode getStrokesContainer() {
      return strokes;
   }


   /**
    * Adds a stroke with the specified path to this label.
    */
   protected void addStroke(final GeneralPath genPath) {
      final Content content = (Content)getModel();
      final Rectangle2D bounds = content.getBounds(getDeviceType());
      final Rectangle2D fullBounds = content.getFullSizeBounds(Content.INK);
      final double stretchX;
      final double stretchY;
      
      if (fullBounds.getWidth() == 0) {
         stretchX = 1;
      }
      else {
         stretchX = bounds.getWidth() / fullBounds.getWidth();
      }
      
      if (fullBounds.getHeight() == 0) {
         stretchY = 1;
      }
      else {
         stretchY = bounds.getHeight() / fullBounds.getHeight();
      }

      final Rectangle2D genPathBounds = genPath.getBounds2D();
      final Rectangle2D scaledGenPathBounds =
         new Rectangle2D.Double(
            ((genPathBounds.getX() - fullBounds.getX()) * stretchX)
               + bounds.getX(),
            ((genPathBounds.getY() - fullBounds.getY()) * stretchY)
               + bounds.getY(),
            stretchX * genPathBounds.getWidth(),
            stretchY * genPathBounds.getHeight());

      final GeneralPath scaledGenPath = (GeneralPath)genPath.clone();
      DamaskAppUtils.resizeGeneralPath(scaledGenPath, scaledGenPathBounds);
      final DamaskPPath path = new DamaskPPath(scaledGenPath);
      
      path.setPickable(false);
      strokes.addChild(path);
      pathStrokes.put(genPath, path);
   }


   /**
    * Removes a stroke with the specified index from this label.
    */
   protected void removeStroke(final GeneralPath genPath) {
      final PNode path = (PNode)pathStrokes.remove(genPath);
      final int index = strokes.indexOfChild(path);
      if (index >= 0) {
         strokes.removeChild(index);
      }
   }


   /**
    * Sets the strokes in this label.
    * 
    * @param strokesCollection a Collection of GeneralPath
    */
   protected void setStrokes(
      final Collection/*<GeneralPath>*/ strokesCollection) {
      
      strokes.removeAllChildren();
      strokes.setTransform(new AffineTransform());
      
      // Resize the strokes to fit the bounds
      if (!strokesCollection.isEmpty()) { 
         for (Iterator i = strokesCollection.iterator(); i.hasNext(); ) {
            final GeneralPath genPath = (GeneralPath)i.next();
            addStroke(genPath);
         }
      }
   }

   /**
    * Returns the text contained in this label. 
    */
   public PText getText() {
      return text;
   }
   
   
   /**
    * Sets the text contained in this label.
    */
   protected void setTextString(final String newString) {
      text.setText(newString);
   }
   
   
   /**
    * Sets the size of the text contained in this label.
    */
   protected void setTextSize(final int size) {
      DamaskAppUtils.setFontSize(getText(), size);
   }
   
   
   /**
    * Returns the color of the label text and strokes.
    */
   public Color getLabelColor() {
      return labelColor;
   }
   
   
   /**
    * Sets the color of the label text and strokes. (The label's image is
    * unaffected.) 
    */
   public void setLabelColor(final Color color) {
      labelColor = color;
      text.setPaint(color);
      for (Iterator i = strokes.getChildrenIterator(); i.hasNext(); ) {
         final DamaskPPath stroke = (DamaskPPath)i.next();
         stroke.setStrokePaint(color);
      }
   }

   
   // @Override
   public void setInRunMode(boolean flag) {
      super.setInRunMode(flag);
      if (displayMode == Content.INK) {
         if (!flag) {
            setPaint(STROKES_BACKGROUND);
         }
         else {
            setPaint(DamaskAppUtils.NO_COLOR);
         }
      }
   }


   // Overrides abstract method in parent class.
   public Object getEditableContents() {
      return getContent();
   }

   /**
    * Returns the content of this component view, which is itself.
    */
   public Label getContent() {
      return this;
   }

   /**
    * Sets the size of this label when it is empty, i.e., when it is in
    * a display mode that has no data.
    */
   public Dimension2D getEmptySize() {
      return new PDimension(placeholder.getWidth(), placeholder.getHeight());
   }

   /**
    * Sets the size of this label when it is empty, i.e., when it is in
    * a display mode that has no data.
    */
   public void setEmptySize(final Dimension2D size) {
      placeholder.setPathTo(
         new Rectangle2D.Double(0, 0, size.getWidth(), size.getHeight()));
   }


   /**
    * Opens a dialog box allowing the user to choose an image file, which will
    * be used as the image representation of this label.
    */
   public void tryToChangeImage(final DamaskCanvas canvas) {
      final File imageFile = FileDialogUtils.showImageOpenDialog(canvas);
      if (imageFile != null) {
         try {
            final BufferedImage newImage = ImageIO.read(imageFile);
            final MacroCommand cmd = new MacroCommand();
            final Content content = (Content)Label.this.getModel();
            cmd.addCommand(new EditContentCommand(content, newImage));
            cmd.addCommand(
               new SetContentDisplayModeCommand(
                  content,
                  content.getDeviceType(),
                  Content.IMAGE));
            canvas.getDocument().getCommandQueue().doCommand(canvas, cmd);
                     
         }
         catch (IOException e) {
            JOptionPane.showMessageDialog(
               canvas,
               "There is a problem reading "
                  + imageFile
                  + ".\n\n"
                  + e.getMessage(),
               "Damask",
               JOptionPane.ERROR_MESSAGE);
            DamaskAppExceptionHandler.log(e);
         }
      }
   }


   /**
    * Handles events from the label's model object. 
    */
   private class ContentHandler
      implements InteractionElementListener, ContentListener {
      
      public void elementBoundsUpdated(InteractionElementEvent e) {
         if (e.getDeviceType() == getDeviceType()) {
            if (getDisplayMode() == Content.INK) {
               // Resize the strokes to fit the new bounds.
               final Content content = (Content)e.getElement();
               setStrokes(content.getStrokes());
            }
            refreshContents();
         }
      }

      public void elementTransformUpdated(InteractionElementEvent e) {
      }

      public void elementBorderUpdated(InteractionElementEvent e) {
      }

      public void strokeAdded(ContentEvent e) {
         assert e.getContent()
            == getModel() : "should be listening to events from "
               + getModel()
               + " not "
               + e.getContent();
         addStroke((GeneralPath)e.getNewValue());
      }

      public void strokeRemoved(ContentEvent e) {
         assert e.getContent()
            == getModel() : "should be listening to events from "
               + getModel()
               + " not "
               + e.getContent();
         removeStroke((GeneralPath)e.getNewValue());
      }

      public void strokesChanged(ContentEvent e) {
         assert e.getContent()
            == getModel() : "should be listening to events from "
               + getModel()
               + " not "
               + e.getContent();
         final Content content = e.getContent();
         setStrokes(content.getStrokes());
      }

      public void textChanged(ContentEvent e) {
         assert e.getContent()
            == getModel() : "should be listening to events from "
               + getModel()
               + " not "
               + e.getContent();
         final Content content = e.getContent();

         setTextString(content.getText());
         setTextSize(content.getTextSize(getDeviceType()));
         refreshContents();
      }

      public void imageChanged(ContentEvent e) {
         assert e.getContent()
            == getModel() : "should be listening to events from "
               + getModel()
               + " not "
               + e.getContent();
         final Content content = e.getContent();
         if (content.getImage() != null) {
            image.setImage(content.getImage());
         }
      }

      public void preferredDisplayModeChanged(ContentEvent e) {
         assert e.getContent()
            == getModel() : "should be listening to events from "
               + getModel()
               + " not "
               + e.getContent();
         final Content content = e.getContent();

         setDisplayMode(content.getPreferredDisplayMode(getDeviceType()));
      }

      // @Override
      public void promptTextIsSyncedWithText(ContentEvent e) {
      }

      // @Override
      public void promptTextIsUnsyncedWithText(ContentEvent e) {
      }
   }
   
   
   /**
    * Handles mouse and keyboard events on this label.
    */
   private class InputEventHandler extends PBasicInputEventHandler {
      public InputEventHandler() {
         getEventFilter().setAndMask(InputEvent.BUTTON1_MASK);
      }
      public void mouseClicked(PInputEvent event) {
         if ((displayMode == Content.IMAGE) && (image.getImage() == null)) {
            final DamaskCanvas canvas = (DamaskCanvas)event.getComponent();
            tryToChangeImage(canvas);
         }
      }
   }
}
