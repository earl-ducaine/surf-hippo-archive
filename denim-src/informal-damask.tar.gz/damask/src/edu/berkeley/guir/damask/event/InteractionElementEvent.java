package edu.berkeley.guir.damask.event;

import java.util.EventObject;

import edu.berkeley.guir.damask.DeviceType;
import edu.berkeley.guir.damask.InteractionElement;

/** 
 * An event that indicates that an interaction element has been moved
 * or its content has been updated.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-08-2003 James Lin
 *                               Created InteractionElementEvent
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-08-2003
 */
public class InteractionElementEvent extends EventObject {
   
   private Type eventType;
   private DeviceType deviceType;
   
   //===========================================================================

   public static class Type {
      private String name;

      private Type(String name) {
         this.name = name;
      }

      public String toString() {
         return name;
      }
   }
   
   //---------------------------------------------------------------------------

   public static final Type BOUNDS_UPDATED =
      new Type("interaction element's bounds updated");
   public static final Type TRANSFORM_UPDATED =
      new Type("interaction element's transform updated");
   public static final Type BORDER_UPDATED =
      new Type("interaction element's border updated");

   //===========================================================================

   /**
    * Constructs a InteractionElementEvent, which gets fired when an
    * InteractionElement is moved or its content is updated.
    * 
    * @param source the interaction element that is affected
    */
   public InteractionElementEvent(InteractionElement source, Type eventType) {
      super(source);
      this.eventType = eventType;
      this.deviceType = DeviceType.ALL;
   }

   //===========================================================================

   /**
    * Constructs a InteractionElementEvent, which gets fired when an
    * InteractionElement is moved or its content is updated.
    * 
    * @param source the interaction element that is affected
    */
   public InteractionElementEvent(
      InteractionElement source,
      Type eventType,
      DeviceType deviceType) {

      super(source);
      this.eventType = eventType;
      this.deviceType = deviceType;
   }
   
   //===========================================================================

   /**
    * Returns the originator of the event.
    * 
    * @return the InteractionElement object that originated the event, or
    * null if the object is not an InteractionElement.
    */
   public InteractionElement getElement() {
      if (source instanceof InteractionElement) {
         return (InteractionElement)source;
      }
      else {
         return null;
      }
   }
   
   //===========================================================================
   
   /**
    * Returns the type of the event.
    */
   public Type getEventType() {
      return eventType;
   }
   
   //===========================================================================
   
   /**
    * Returns the device type associated with this event.
    */
   public DeviceType getDeviceType() {
      return deviceType;
   }
}
