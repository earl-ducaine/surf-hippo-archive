/*
 * RemoteSocketManager.java
 * Created on November 6, 2001, 3:33 PM
 */

package edu.berkeley.guir.lib.satin.remote;

import java.util.*;
import edu.berkeley.guir.lib.satin.command.*;

/**
 * @author  Scott Klemmer, Katie Everitt
 * @version 1.3
 */
public class RemoteSocketMgr extends Thread {
   
   private Vector              m_inSockets     = new Vector();
   private Vector              m_outSockets    = new Vector();
    
   private Vector              m_inEvents      = new Vector();
   private Vector              m_outEvents     = new Vector();
   private RemoteCommandQueue  m_listener      = null;
	private IOEvent             m_latest_awareness  = null;
	   
   private int                 m_portBase;
   private int                 m_inPort;
   private int                 m_outPort;
    
   
   /** Creates new RemoteSocket */
   public RemoteSocketMgr(int port) {
      m_portBase = port;
   }
   

   public void setRemoteHost(String hostName, int localOffset, int remoteOffset) {
      m_inPort = m_portBase + localOffset;   m_outPort = m_portBase + remoteOffset;
      
      m_inSockets.add(new RemoteIncomingSocket(this,  m_inPort));
      m_outSockets.add(new RemoteOutgoingSocket(this, m_outPort));
      System.out.println("RemoteSocketManager before start");
      start();
      System.out.println("RemoteSocketManager after start");
      ((RemoteOutgoingSocket)m_outSockets.get(0)).connectToHost(hostName);
   }

    
   public void setRemoteListener(RemoteCommandQueue listener) {
      m_listener = listener;
   }
    

   /**
   * This thread loops through all of the incoming events and asks them to be handled
   */
   public void run() {
      while (true) {
         if ((!m_inEvents.isEmpty()) && (m_listener!=null)) { //don't pop events off the queue unless someone is listening
				System.out.println("()()()()()()()()()() remove event from m_inEvents in RemoteSocketManager!");
               IOEvent event = (IOEvent) m_inEvents.remove(0); // gets the front of the vector
               m_listener.handleRemoteEvent(event);
         } else try {
               Thread.sleep(50);
         } catch (InterruptedException e) {}
      }
   }
    
    
   /**
   * Add an event to the queue of things to be sent off to the Remote system
   */
   public void postOutgoingEvent(String xml) {
      System.out.println("postOutgoingEvent");
      m_outEvents.add(new IOEvent( xml, m_outPort));
   }
 
 
	/**
	 * This method sets the lower priority awareness varible
	 * it will be sent if there are no other events in the queue waiting to be sent
	 * 
	 * there is only one, no queue at present because we don't want to send current events,
	 * only the latest
	 */
   public void postOutgoingAwarenessUpdate(String xml){ 
      System.out.println("postOutgoingAwarenessUpdate");
   	m_latest_awareness = new IOEvent( xml, m_outPort);	
   }     
    
   /**
   * The Outgoing socket periodically queries this method to see if there's anything to send.
   * If there is, we return it, and the method that calls this sends it off.
   */
   public IOEvent getOutgoingEvent(int portNum) {
      if ( !m_outEvents.isEmpty()) {
         System.out.println("()()()()()()()()()() There are " + m_outEvents.size() + " events in the Outgoing queue ");
         int i, first = -1, len = m_outEvents.size();
         //IOEvent gve = null;
         for (i = len-1; i >= 0; i--) {
               if ( ((IOEvent)m_outEvents.get(i)).getPort() == portNum ) {
                  first = i;
                  i = -2; // EXIT FOR LOOP
               }
         }
         if (first == -1) return null;
         else return (IOEvent) m_outEvents.remove(first);
         
        // if we have nothing in the queue to send, send a lower priority awareness events 
      } else if (m_latest_awareness  != null) {
      	System.out.println("red rover red rover, let awareness come over");
			final IOEvent awareness  = (IOEvent) m_latest_awareness ;
			m_latest_awareness  = null;
			return awareness;
      } else return null;
      
   }
   



   /**
    * Called by the incoming socket when it receives a new message
    * It adds the corresponding event to the rear of the queue
    * note: Events get pulled off the queue in the run() method above
    */
   public void postIncomingEvent(IOEvent rEvent) {
      //debug.println("posting incoming event: " + rEvent.toString());
      m_inEvents.add(rEvent);
   }


/*
   public void notifySocketClosed() {
      m_inEvents.add(new IOEvent(IOEvent.SOCKET_CLOSED_EVENT, m_inPort));  
   } */
   
}