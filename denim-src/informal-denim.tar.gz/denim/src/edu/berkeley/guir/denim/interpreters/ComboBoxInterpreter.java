package edu.berkeley.guir.denim.interpreters;

/**
 * @author shen
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */

import edu.berkeley.guir.denim.*;
import edu.berkeley.guir.denim.components.*;
import edu.berkeley.guir.lib.awt.geom.*;
import edu.berkeley.guir.lib.debugging.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.interpreter.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import java.awt.*;
import java.awt.geom.*;


/**
 * Inserts instances of the component associated with the combo box.
 */
public class ComboBoxInterpreter
   extends DefaultInterpreterImpl
   implements DenimConstants {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   DenimComponent component;
   DenimComponentInstance newInstance;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   /**
	* Constructs a rubber stamp interpreter.
	*/
   public ComboBoxInterpreter() {
	  super();
	  commonInitializations();
   }

   //-----------------------------------------------------------------

   /**
	* Constructs a combo box interpreter as a copy of the given interpreter.
	*/
   public ComboBoxInterpreter(ComboBoxInterpreter intrp) {
	  // Since this interpreter is stateless, we can do this safely.
	  this();
   }

   //-----------------------------------------------------------------

   /**
	* Perform initializations common to all constructors.
	*/
   private void commonInitializations() {
	  setName("Denim Combo Box Interpreter");
   }

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   XXXXX METHODS   =====================================================

   /**
	* Sets the component which the combo box interpreter should insert an
	* instance of.
	*/
   public void setComponentType(DenimComponent c) {
	  component = c;
   }

   //===   XXXXX METHODS   =====================================================
   //===========================================================================



   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   /**
	* Puts an instance of the combo box's component at the point where the user
	* tapped the combo box.
	*/
   public void handleNewStroke(NewStrokeEvent evt) {
	  DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject();
	  sheet.setGobWithFocus(null);
	  TimedStroke stk  = evt.getStroke();
	  Point2D p        = stk.getEndPoint2D(COORD_ABS);
	  Point2D localPt  = GraphicalObjectLib.absoluteToLocal(sheet, p);

	  newInstance = component.newInstance();

	  sheet.add(newInstance, GraphicalObjectGroup.KEEP_REL_POS);
	  newInstance.moveTo(COORD_REL, localPt);

	  evt.setConsumed();
   }

   //-----------------------------------------------------------------

   /**
	* Moves the instance of the combo box's component to the point where the
	* user has "dragged" the combo box.
	*/
   public void handleUpdateStroke(UpdateStrokeEvent evt) {
	  DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject();
	  TimedStroke stk  = evt.getStroke();
	  Point2D p        = stk.getEndPoint2D(COORD_ABS);
	  Point2D localPt  = GraphicalObjectLib.absoluteToLocal(sheet, p);

	  newInstance.moveTo(COORD_REL, localPt);
	  Debug.println("move to: " + localPt.getX() + ", " + localPt.getY());

	  evt.setConsumed();
   }

   //-----------------------------------------------------------------

   /**
	* Inserts the instance of the combo box's component at the point where the
	* user released the combo box.
	*/

   public void handleSingleStroke(SingleStrokeEvent evt) {
	  DenimSheet sheet = (DenimSheet)getAttachedGraphicalObject();
	  TimedStroke stk  = evt.getStroke();
	  Point2D p        = stk.getEndPoint2D(COORD_ABS);
	  Point2D localPt  = GraphicalObjectLib.absoluteToLocal(sheet, p);



	  sheet.disableDamage();

	  // 1. Now that the designer has stopped dragging the instance around,
	  //    we can remove it from the sheet.
	  /*Rectangle2D absBounds = newInstance.getBounds2D(COORD_ABS);

	  Debug.println("newInstance abs bounds: " + newInstance.getBounds2D(COORD_ABS));
	  Debug.println("newInstance abs xform: " + newInstance.getTransform(COORD_ABS));
	  Debug.println("newInstance xform: " + newInstance.getTransformRef());

	  GraphicalObjectGroup nParent = newInstance.getParentGroup();
	  while (nParent != null) {
		 Debug.println("  " + DenimUtils.toShortString(nParent) + " xform: " + nParent.getTransformRef());
		 nParent = nParent.getParentGroup();
	  }

	  DenimPanel dpanel = (DenimPanel)newInstance.getDisplayedState();
	  Debug.println("panel xform: " + dpanel.getTransformRef());
	  Debug.println("sketch xform: " + dpanel.getSketch().getTransformRef());
	  Debug.displayObjectTree(dpanel.getSketch());*/


	  sheet.remove(newInstance);

	  if (newInstance instanceof DenimCustomComponentInstance) {
		 DenimPanel instPanel = (DenimPanel)newInstance.getDisplayedState();
		 instPanel.getLabel().setVisible(false);
		 instPanel.getLabel().getPhrase().setVisible(false);
	  }


	  // 2. Find the panel which contains the point where mouse was clicked
	  GraphicalObject shallow = DenimUtils.findPanel(sheet, p);

	  DenimPanel panel;
	  DenimSketch sketch;
	  MacroCommand macro = new MacroCommand();

	  // 3. a) If there is a panel, add the instance to the panel
	  if (shallow instanceof DenimPanel) {
		 Debug.println("Found panel");
		 panel = (DenimPanel)shallow;
		 sketch = panel.getSketch();
		 macro.addCommand(new InsertCommand(sketch, newInstance,
											GraphicalObjectGroup.KEEP_REL_POS));

		 // Calculate new transform that will keep the instance in the same
		 // absolute location
		 GraphicalObjectGroup parent = sketch;
		 AffineTransform newXform = new AffineTransform();
		 while (parent.getUniqueID() != sheet.getUniqueID()) {
			Debug.println("  Adding inverse of " + DenimUtils.toShortString(parent));
			newXform.concatenate(parent.getInverseTransform(COORD_REL));
			parent = parent.getParentGroup();
		 }
		 newXform.concatenate(newInstance.getTransform(COORD_REL));
		 macro.addCommand(new SetTransformCommand(newInstance, newXform));
	  }
	  else {
		 Debug.println("Creating panel");
		 
		 // modified by Shelley Shen 02/19/2003

		 // create a panel
		 panel = new DenimPanel(new Rectangle(0, 0, 1, 1)); 
		 
		 macro.addCommand(new InsertCommand(sheet, panel,
											GraphicalObjectGroup.KEEP_REL_POS));
											
	     // find out absolute scale factor according to the zoomslider's level
	   	 double scaleFactor = sheet.getAbsScale();

	  	 AffineTransform txToApply;

	  	 int x = (int)(p.getX());
	  	 int y = (int)(p.getY());
	  	 txToApply = AffineTransformLib.scaleAndCenterAt(scaleFactor, x, y,
	  	 												 sheet.getBounds2D(COORD_ABS));

	  	 double w,h;

	     txToApply.preConcatenate(sheet.getInverseTransform(COORD_ABS));
	  	 
	  	 w = DenimSketch.getDefaultSketchWidth() * txToApply.getScaleX(); int width = (int)w;
	  	 h = DenimSketch.getDefaultSketchHeight() * txToApply.getScaleY(); int height = (int)h;
	  	 
	  	 // create a new denim sketch and put it into the panel
	  	 sketch = new DenimSketch(new Rectangle(0,0,width,height));

		 panel.setSketch(sketch);

		 // create a label for the panel
		 TypedText labelText = new TypedText("Label");
		 labelText.moveTo(COORD_REL,
						  sketch.getBounds2D(COORD_ABS).getX(),
						  sketch.getBounds2D(COORD_ABS).getY() -
							labelText.getBounds2D(COORD_ABS).getHeight());
		 sheet.add(labelText, GraphicalObjectGroup.KEEP_ABS_POS);

		 DenimLabel label = new DenimLabel(labelText);
		 panel.setLabel(label);
		 Debug.println("label abs bounds = " + label.getBounds2D(COORD_ABS));

		 // add the instance to the new panel's sketch
		 newInstance.moveTo(COORD_REL, 0, 0);
		 macro.addCommand(new InsertCommand(sketch, newInstance,
											GraphicalObjectGroup.KEEP_REL_POS));
		 macro.addCommand(new SetLocationCommand(panel,
										  localPt.getX(), localPt.getY()));

	  }

	  // 4. Insert the instance into the panel at the clicked point
	  cmdqueue.doCommand(macro);

	  // TODO: make this an undoable command
	  panel.componentInstanceIsAdded(newInstance);

	  /*
	  Debug.println("panel abs bounds: " + panel.getBounds2D(COORD_ABS));
	  Debug.println("newInstance rel bounds: " + newInstance.getBounds2D(COORD_REL));
	  Debug.println("newInstance abs bounds: " + newInstance.getBounds2D(COORD_ABS));
	  Debug.println("newInstance abs xform: " + newInstance.getTransform(COORD_ABS));
	  Debug.println("newInstance xform: " + newInstance.getTransformRef());
	  nParent = newInstance.getParentGroup();
	  while (nParent != null) {
		 Debug.println("  " + DenimUtils.toShortString(nParent) + " xform: " + nParent.getTransformRef());
		 nParent = nParent.getParentGroup();
	  }
	  dpanel = (DenimPanel)newInstance.getDisplayedState();
	  Debug.println("panel xform: " + dpanel.getTransformRef());
	  Debug.println("sketch xform: " + dpanel.getSketch().getTransformRef());
	  Debug.displayObjectTree(dpanel.getSketch());*/
	  sheet.enableDamage();
	  sheet.damage(DAMAGE_LATER);

	  evt.setConsumed();
   }

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   /**
	* Clones this interpreter.
	*/
   public Object clone() {
	  return (new ComboBoxInterpreter(this));
   } // of clone

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

