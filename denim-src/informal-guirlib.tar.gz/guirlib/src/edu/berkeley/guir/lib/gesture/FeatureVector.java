package edu.berkeley.guir.lib.gesture;

import java.awt.Point;
import java.io.*;
import java.util.Observable;
import java.util.Observer;

import edu.berkeley.guir.lib.gesture.features.*;

/**
 * Vector of all features.  When a new feature is added, this class
 * must change.
 */
public class FeatureVector extends Observable
implements Serializable, Observer {
  // should this be final?
  final public static Class[] defaultFeatureClasses = {
    InitAngleCosine.class, InitAngleSine.class, BoundsSize.class,
    BoundsAngle.class, EndsDistance.class, EndsAngleCosine.class,
    EndsAngleSine.class, TotalLength.class, TotalAngle.class,
    TotalAbsAngle.class, Sharpness.class
  };
  protected Feature[] features;
  protected Gesture gesture;
  protected Class[] featureClasses;
  
  public FeatureVector()
  {
    try {
      init(defaultFeatureClasses);
    }
    catch (IllegalAccessException e) {
      System.err.println("FeatureVector: problem initializing default feature classes: " + e);
    }
    catch (InstantiationException e) {
      System.err.println("FeatureVector: problem initializing default feature classes: " + e);
    }
  }

  public FeatureVector(Class[] featureClasses)
    throws IllegalAccessException, InstantiationException
  {
    init(featureClasses);
  }

  protected void init(Class[] featureClasses)
       throws IllegalAccessException, InstantiationException
  {
    this.featureClasses = featureClasses;
    features = new Feature[featureClasses.length];
    for (int i = 0; i < featureClasses.length; i++) {
      features[i] = (Feature) featureClasses[i].newInstance();
    }
  }
  
  public FeatureVector(Gesture g)
  {
    this();
    setGesture(g);
  }
  
  public FeatureVector(Gesture g, Class[] featureClasses)
       throws IllegalAccessException, InstantiationException
  {
    this(featureClasses);
    setGesture(g);
  }

  public Class getFeatureType(int featureNum)
  {
    return featureClasses[featureNum];
  }
  
  public void newPoint(Point p)
  {
    int i;
    for (i = 0; i < features.length; i++) {
      features[i].newPoint(p);
    }
  }

  public void setGesture(Gesture g)
  {
    if (g != gesture) {
      int i;
      for (i = 0; i < features.length; i++) {
	features[i].setGesture(g);
	features[i].addObserver(this);
      }
      gesture = g;
      update(null, null);
    }
  }

  public Gesture getGesture()
  {
    return gesture;
  }

  public double getValue(int featureNum)
  {
    return features[featureNum].getValue();
  }
  
  public Feature getFeature(int featureNum)
  {
    return features[featureNum];
  }
  
  public double[] getValues()
  {
    int i;
    double[] result = new double[features.length];
    
    for (i = 0; i < features.length; i++) {
      result[i] = features[i].getValue();
    }
    return result;
  }

  public Feature[] getFeatures()
  {
    return features;
  }

  public int size()
  {
    return featureClasses.length;
  }
  
  public static int defaultSize()
  {
    return defaultFeatureClasses.length;
  }
  
  public void update(Observable feature, Object arg)
  {
    setChanged();
    notifyObservers(arg);
  }

  public static Feature singleFeature(Gesture g, int featureNum)
  {
    return singleFeature(g, featureNum, defaultFeatureClasses);
  }

  public static Feature singleFeature(Gesture g, int featureNum,
				      Class[] featureClasses)
  {
    return FeatureFactory.getFeature(featureClasses[featureNum], g);
  }
  
  /**
   * Restore observer status
   */
  private void readObject(ObjectInputStream in)
       throws IOException, ClassNotFoundException
  {
    in.defaultReadObject();
    for (int i = 0; i < features.length; i++) {
      features[i].addObserver(this);
    }
  }
}
