package edu.berkeley.guir.damask.view.appevent;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.view.DamaskCanvas;

/** 
 * A source of canvas events.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  01-11-2004 James Lin
 *                               Created CanvasEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 01-11-2004
 */
public class CanvasEventSource {
   
   private Vector/*<CanvasListener>*/ eventListeners = new Vector();


   /**
    * Adds the specified listener to receive canvas events.
    */
   public synchronized void addCanvasListener(final CanvasListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }


   /**
    * Removes the specified listener so that it no longer receives
    * canvas events.
    */
   public synchronized void removeCanvasListener(final CanvasListener listener) {
      eventListeners.remove(listener);
   }

   
   /**
    * Fires selectionChanged events to listeners.
    */
   public void fireSelectionChanged(final DamaskCanvas canvas) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final CanvasEvent event =
         new CanvasEvent(canvas, CanvasEvent.SELECTION_CHANGED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final CanvasListener listener = (CanvasListener)i.next();
         listener.selectionChanged(event);
      }
   }

   
   /**
    * Fires selectedPageChanged events to listeners.
    */
   public void fireSelectedPageChanged(final DamaskCanvas canvas) {
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final CanvasEvent event =
         new CanvasEvent(canvas, CanvasEvent.SELECTED_PAGE_CHANGED);

      for (Iterator i = el.iterator(); i.hasNext(); ) {
         final CanvasListener listener = (CanvasListener)i.next();
         listener.selectedPageChanged(event);
      }
   }
}
