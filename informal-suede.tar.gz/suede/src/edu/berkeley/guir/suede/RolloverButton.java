package edu.berkeley.guir.suede;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RolloverButton extends JButton {
    private static final int SPACE = 16;
    
    private Color bg;
    private Color fg;
    private Color roll;
    
    public RolloverButton(String s, Color b, Color f, Color r) {
        super(s);
        bg =b;   fg = f;  roll = r;
        setVisible(true);   setOpaque(true);
        setBackground(bg);  setForeground(fg);
        setFocusPainted(false);
        setContentAreaFilled(true);
        setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, fg));
        addMouseListener(new RollListener());
    }
            
    public int setXHeight(int x, int h) {
        this.setBounds(x,0,getIdealWidth(), h);
        return x+getIdealWidth();
    }
                
    public int getIdealWidth() { return getPreferredSize().width + SPACE;   }
            
    private class RollListener implements MouseListener {
        public void mouseClicked(MouseEvent e) {}
        public void mouseExited(MouseEvent e)  { setBackground(bg); }
        public void mouseEntered(MouseEvent e) { setBackground(roll); }
        public void mousePressed(MouseEvent e) {}
        public void mouseReleased(MouseEvent e){}
    }
}
