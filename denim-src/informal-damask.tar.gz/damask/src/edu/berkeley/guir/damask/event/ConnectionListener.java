package edu.berkeley.guir.damask.event;

import java.util.EventListener;

/** 
 * The listener interface for receiving events regarding when a
 * connection's source, destination, or event class has been changed. 
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-11-2003 James Lin
 *                               Created ConnectionListener
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A> (
 *          <A HREF="mailto:jimlin@cs.berkeley.edu">jimlin@cs.berkeley.edu</A> )
 * @version Version 1.0.0, 08-11-2003
 */
public interface ConnectionListener extends EventListener {
   
   /**
    * Invoked when the source of a connection is changed.
    */
   void sourceChanged(ConnectionEvent e);

   /**
    * Invoked when the destination of a connection is changed.
    */
   void destChanged(ConnectionEvent e);

   /**
    * Invoked when the shape of a connection is changed.
    */
   void shapeChanged(ConnectionEvent e);

   /**
    * Invoked when the user event of a connection is changed.
    */
   void userEventChanged(ConnectionEvent e);
   
   /**
    * Invoked when the condition of a connection is changed. 
    */
   void conditionChanged(ConnectionEvent e);
}
