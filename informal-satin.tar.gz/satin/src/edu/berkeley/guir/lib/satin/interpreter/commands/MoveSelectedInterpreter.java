//// See bottom of source code for software license

package edu.berkeley.guir.lib.satin.interpreter.commands;

import java.awt.geom.*;
import java.util.*;
import edu.berkeley.guir.lib.satin.objects.*;
import edu.berkeley.guir.lib.satin.command.*;
import edu.berkeley.guir.lib.satin.event.*;
import edu.berkeley.guir.lib.satin.stroke.*;
import edu.berkeley.guir.lib.satin.interpreter.*;

/**
 * By default accepts left button only.
 *
 * <P>
 * This software is distributed under the 
 * <A HREF="http://guir.cs.berkeley.edu/projects/COPYRIGHT.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  - SATIN-v1.0-1.0.0, Aug 02 1999, JH
 *               Created class
 *             - SATIN-v2.1-1.0.0, Aug 11 2000, JH
 *               Touched for SATIN release
 *             - SATIN-v2.1-2.0.0, Nov 7 2002, YL
 *               Added access to overSelected
 *             - SATIN-v2.1-2.0.0, Jan 28 2003, YL
 *               Refined the access to overSelected   
 * 
 * </PRE>
 *
 * @author <A HREF="http://www.cs.berkeley.edu/~jasonh/">Jason Hong</A> (
 *         <A HREF="mailto:jasonh@cs.berkeley.edu">jasonh@cs.berkeley.edu</A> )
 * @author <A HREF="http://www.cs.berkeley.edu/~yangli/">Yang Li</A> (
 *         <A HREF="mailto:yangli@cs.berkeley.edu">yangli@cs.berkeley.edu</A> )
 * 
 * @since   JDK 1.2.2
 * @version SATIN-v2.1-2.0.0,  Jan 28 2003
 */
public class MoveSelectedInterpreter 
   extends InterpreterImpl {

   //===========================================================================
   //===   CONSTANTS   =========================================================

   static final long serialVersionUID = 1104683975462911745L;

   //===   CONSTANTS   =========================================================
   //===========================================================================



   //===========================================================================
   //===   NONLOCAL VARIABLES   ================================================

   boolean          isOverSelected;   // true if the user started dragging
                                      // over a selected object
   double           lastX;            // last absolute x-coordinate
   double           lastY;            // last absolute y-coordinate
   
   Point2D[]        oldRelLocs;       // initial relative locations of selected
                                      // objects
   Point2D[]        newRelLocs;       // new relative locations of selected
                                      // objects

   boolean          flagShallow = true;

   //===   NONLOCAL VARIABLES   ================================================
   //===========================================================================



   //===========================================================================
   //===   CONSTRUCTORS   ======================================================

   public MoveSelectedInterpreter() {
      commonInitializations();
   } // of constructor

   //-----------------------------------------------------------------

   private void commonInitializations() {
      setName("Move Selected Item Interpreter");
      setAcceptMiddleButton(false);
      setAcceptRightButton(false);
   } // of commonInitializations

   //===   CONSTRUCTORS   ======================================================
   //===========================================================================



   //===========================================================================
   //===   ACCESSOR / MODIFIER METHODS   =======================================

   public void setDeep() {
      flagShallow = false;
   } // of setDeep

   //-----------------------------------------------------------------

   public void setShallow() {
      flagShallow = true;
   } // of setShallow

   //===   ACCESSOR / MODIFIER METHODS   =======================================
   //===========================================================================


   public Point2D[] getOldPosition() {
   	  return oldRelLocs;
   }

   //-----------------------------------------------------------------	

   public void setOldPosition(Point2D[] oldPos) {
   	  oldRelLocs = oldPos;
   }
      
   //-----------------------------------------------------------------	

	public boolean isOverSelected() {
		return isOverSelected;
	}

   //-----------------------------------------------------------------	

	public void setOverSelected(boolean b) {
		isOverSelected = b;
	}

   //-----------------------------------------------------------------
   	
	public double getLastX() {
		return lastX;
	}
	
   //-----------------------------------------------------------------

	public double getLastY() {
		return lastY;
	}

   //-----------------------------------------------------------------
   	
	public void setLastX(double x) {
		lastX = x;
	}

   //-----------------------------------------------------------------
   	
	public void setLastY(double y) {
		lastY = y;
	}
	
   //===========================================================================
   //===   NOTIFICATION METHODS   ==============================================

   public void handleNewStroke(NewStrokeEvent evt) {
      TimedStroke     stk      = evt.getStroke();
      GraphicalObject attached = getAttachedGraphicalObject();
      GraphicalObject gobTmp   = null;

      //// 1. See if we are over a selected GraphicalObject.
      isOverSelected = false;
      if (attached instanceof GraphicalObjectGroup) {
         Point2D                   ptPress = stk.getStartPoint2D(COORD_ABS);
         GraphicalObjectGroup      gobgrp  = (GraphicalObjectGroup) attached;
         GraphicalObjectCollection gobcol;


         if (flagShallow == true) {
            gobcol = gobgrp.getGraphicalObjects(COORD_ABS, ptPress, ALL, 
                                         SHALLOW, NEAR);
            gobTmp = GraphicalObjectLib.getTopmostGraphicalObject(gobcol);
         }
         else {
            gobcol = gobgrp.getGraphicalObjects(COORD_ABS, ptPress, ALL, 
                                         DEEP, NEAR);
            gobTmp = GraphicalObjectLib.getTopmostGraphicalObject(gobcol);
            
            //// Get the shallowest ancestor that is selected
            if (gobTmp != null) {
               GraphicalObjectGroup parent = gobTmp.getParentGroup();
               while (parent != null) {
                  if (cmdsubsys.isSelected(parent)) {
                     gobTmp = parent;
                  }
                  parent = parent.getParentGroup();
               }
            }
         }

         //// 1.1. If the item is selected, then keep a reference to it.
         ////      Also calculate the diff in x,y from where we clicked and
         ////      the GraphicalObject's top-left corner.
         if (cmdsubsys.isSelected(gobTmp)) {
            isOverSelected = true;
            evt.setConsumed();
            evt.setShouldRender(false);

            //// 1.1.1. Calculate the diff between where we clicked and the
            ////        GraphicalObject's top-left corner.
            lastX = ptPress.getX();
            lastY = ptPress.getY();
            
            //// 1.1.2. Store the original relative locations of the
            ////        selected objects.
            GraphicalObjectCollection selObjs =
               cmdsubsys.getSelectedCollection();
            oldRelLocs = new Point2D[selObjs.numElements()];
            int i = 0;
            Iterator it = selObjs.getForwardIterator();
            while (it.hasNext()) {
               GraphicalObject gob = (GraphicalObject)it.next();
               oldRelLocs[i] = gob.getLocation2D(COORD_REL);
               i++;
            }
         }
      }
   } // of handleNewStroke

   //-----------------------------------------------------------------

   public void handleUpdateStroke(UpdateStrokeEvent evt) {
      //// 1. Otherwise, move the selected object.
      if (isOverSelected) {
         TimedStroke     stk = evt.getStroke();
         Point2D         pt  = stk.getEndPoint2D(COORD_ABS);

         Iterator i = cmdsubsys.getSelected();
         while (i.hasNext()) {
            GraphicalObject gob = (GraphicalObject)i.next();
            gob.moveBy(COORD_ABS, pt.getX() - lastX, pt.getY() - lastY);
         }
         lastX = pt.getX();
         lastY = pt.getY();
         
         evt.setConsumed();
         evt.setShouldRender(false);
      }
   } // of handleUpdateStroke

   //-----------------------------------------------------------------

   public void handleSingleStroke(SingleStrokeEvent evt) {
      //// 1. Set event as consumed, since we already used it.
      if (isOverSelected) {
         evt.setConsumed();
         evt.setShouldRender(false);
            
         //// 1.1. Store the new relative locations of the
         ////      selected objects.
         GraphicalObjectCollection selObjs =
            cmdsubsys.getSelectedCollection();
         newRelLocs = new Point2D[selObjs.numElements()];
         int i = 0;
         Iterator it = selObjs.getForwardIterator();
         while (it.hasNext()) {
            GraphicalObject gob = (GraphicalObject)it.next();
            newRelLocs[i] = gob.getLocation2D(COORD_REL);
            i++;
         }
         
         //// 1.2. Check if the objects actually moved. (Checking one is
         ////      enough.)  If not, skip all of the cut/paste/undo/redo steps.
         if (!oldRelLocs[0].equals(newRelLocs[0])) {
            cmdqueue.doCommand(createMoveCommand());
         }
      }
      getAttachedGraphicalObject().damage(DAMAGE_LATER);
   } // of handleSingleStroke

   // Create a command to be used for undo/redo only, since we have
   // moved the objects already.  However, this can be
   // overridden to actually do something the first time around,
   // in order to "drop" the objects into a different container.
   protected Command createMoveCommand() {
      return new PhantomMoveCommand(cmdsubsys.getSelected(),
                                                      oldRelLocs,
                                                      newRelLocs);
   }

   //===   NOTIFICATION METHODS   ==============================================
   //===========================================================================



   //===========================================================================
   //===   CLONE   =============================================================

   public Object clone() {
      return (new MoveSelectedInterpreter());
   } // of method

   //===   CLONE   =============================================================
   //===========================================================================

} // of class

//==============================================================================

/*
Copyright (c) 2000 Regents of the University of California.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:

      This product includes software developed by the Group for User 
      Interface Research at the University of California at Berkeley.

4. The name of the University may not be used to endorse or promote products 
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/
