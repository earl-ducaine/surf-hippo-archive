package edu.berkeley.guir.damask.event;

import java.util.Iterator;
import java.util.Vector;

import edu.berkeley.guir.damask.connection.Connection;
import edu.berkeley.guir.damask.connection.ConnectionSource;

/** 
 * A source of ConnectionEndpointEvents.  
 *
 * <P>
 * This software is distributed under the
 * <A HREF="http://guir.berkeley.edu/projects/copyright.txt">
 * Berkeley Software License</A>.
 *
 * <PRE>
 * Revisions:  1.0.0  08-19-2004 James Lin
 *                               Created ConnectionEndpointEventSource
 * </PRE>
 *
 * @author  <A HREF="http://www.cs.berkeley.edu/~jimlin/">James Lin</A>
 * @version Version 1.0.0, 08-19-2004
 */
public class ConnectionSourceEventSource {
   
   private Vector/*<ConnectionSourceListener>*/ eventListeners = new Vector();
   
   //---------------------------------------------------------------------------

   /**
    * Adds the specified container listener to receive container events from
    * this graph.
    */
   public synchronized void addConnectionSourceListener(final ConnectionSourceListener listener) {
      if (!eventListeners.contains(listener)) {
         eventListeners.add(listener);
      }
   }

   //---------------------------------------------------------------------------

   /**
    * Removes the specified container listener so that it no longer receives
    * container events from this graph.
    */
   public synchronized void removeConnectionSourceListener(
      final ConnectionSourceListener listener) {

      eventListeners.remove(listener);
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires outConnectionAdded events to listeners.
    */
   public void fireOutConnectionAdded(
      final ConnectionSource e, final Connection connection) {
      
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ConnectionSourceEvent event =
         new ConnectionSourceEvent(
            e, ConnectionSourceEvent.OUT_CONNECTION_ADDED, connection);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ConnectionSourceListener listener =
            (ConnectionSourceListener)i.next();
         listener.outConnectionAdded(event);
      }
   }

   //---------------------------------------------------------------------------
   
   /**
    * Fires outConnectionRemoved events to listeners.
    */
   public void fireOutConnectionRemoved(
      final ConnectionSource e, final Connection connection) {
      
      final Vector el;
      synchronized (this) {
         el = (Vector) eventListeners.clone();
      }

      if (el.isEmpty()) {
         return;
      }

      final ConnectionSourceEvent event =
         new ConnectionSourceEvent(
            e, ConnectionSourceEvent.OUT_CONNECTION_REMOVED, connection);

      for (Iterator i = el.iterator(); i.hasNext();) {
         final ConnectionSourceListener listener =
            (ConnectionSourceListener)i.next();
         listener.outConnectionRemoved(event);
      }
   }
}
